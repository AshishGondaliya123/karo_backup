<style>
    label.error{
        color:red;
    }
    .mandate{
        color:red;
    }
</style>
<div class="dash_right_section">
    <h2 class="main-heading">Referred By</h2>
    <?php if (isset($_REQUEST['act'])) { ?>
        <?php if ($_REQUEST['act'] == 'update') { ?>
            <?php
            $attributes = array('class' => 'referredby', 'id' => 'referredby');
            echo form_open('referredby/updatereferred', $attributes);
            $values = explode("|", base64_decode($_REQUEST['id']));
           
            ?>
            <div class="dash_column">
                <div><?php echo $this->session->flashdata('message'); ?></div>

                <div class="row">
                    <div class="form-group col-md-4">
                        <input id="ReferedById" name="ReferedById" value="<?php echo base64_encode($values[0]); ?>" type="hidden" class="form-control specialchr">
                        <label for="name">Referred By<span class="mandate">*</span></label>
                        <input id="refered_by_name" name="refered_by_name" type="text" class="form-control" placeholder="Enter referred by" value="<?php echo $values[1]; ?>">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="name">Address</label>
                        <textarea class="form-control" name="address" placeholder="Address"><?php echo $values[6]; ?></textarea>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="name">State</label>
                        <select id="state" name="state"  class="form-control" onchange="getcities(this.value, 'city');">
                            <option value=""> Select State</option>
                            <?php foreach ($states as $state) { ?>
                                <option value="<?php echo $state['city_state']; ?>" <?php if ($values[3] == $state['city_state']) {
                        echo "selected='selected'";
                    } ?> ><?php echo $state['city_state']; ?></option>
        <?php } ?>
                        </select>
                    </div>
                    

                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                        <label for="name">City</label>
                        <select id="city" name="city"  class="form-control" onchange="">
                            <option value=""> Select City</option>  
                            <?php
                            if (!empty($cities)) {
                                foreach ($cities as $city) {
                                    if ($city['city_name'] == $values[5]) {
                                        $selected = "selected='selected'";
                                    } else {
                                        $selected = '';
                                    }
                                    echo "<option value='" . $city['city_name'] . "' " . $selected . ">" . $city['city_name'] . "</option>";
                                }
                            }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Pin Code</label>
                            <input id="zipcode" name="zipcode" type="text" class="form-control" placeholder="Enter pin code" value="<?php echo $values[4]; ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Contact No</label>
                            <input id="contact_no" name="contact_no" type="text" class="form-control" placeholder="Enter contact no" value="<?php echo $values[2]; ?>">
                        </div>
                    </div>
                    
                    <input type="submit" class="btn btn-primary save" name="save" value="Save">
                    <div class="clearfix"></div>
                </div>
            </form>
        <?php }
    } else { ?>
        <?php
        $attributes = array('class' => 'referredby', 'id' => 'referredby');
        echo form_open('referredby/index', $attributes);
        ?>
        <div class="dash_column">
            <div><?php echo $this->session->flashdata('message'); ?></div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label for="name">Referred By Company Name<span class="mandate">*</span></label>
                    <input id="refered_by_name" name="refered_by_name" type="text" class="form-control" placeholder="Enter referred by name">
                </div>
                <div class="form-group col-md-4">
                <label for="name">Address</label>
                <textarea class="form-control" name="address" placeholder="Address"></textarea>
            </div>
                <div class="form-group col-md-4">
                    <label for="name">State</label>
                    <select id="state" name="state"  class="form-control" onchange="getcities(this.value, 'city');">
                        <option value=""> Select State</option>
        <?php foreach ($states as $state) { ?>
                            <option value="<?php echo $state['city_state']; ?>"><?php echo $state['city_state']; ?></option>
        <?php } ?>
                    </select>
                </div>
                

            </div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label for="name">City</label>
                    <select id="city" name="city"  class="form-control" onchange="">
                        <option value=""> Select City</option>    
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="name">Pin Code</label>
                    <input id="zipcode" name="zipcode" type="text" class="form-control" placeholder="Enter pin code">
                </div>
                <div class="form-group col-md-4">
                    <label for="name">Contact No</label>
                    <input id="contact_no" name="contact_no" type="text" class="form-control" placeholder="Enter contact no">
                </div>
            </div>
            
            <input type="submit" class="btn btn-primary save" name="save" value="Save">
            <div class="clearfix"></div>
        </div>
        </form>
    <?php } ?>
    <div class="dash_column">
        <div class="tbl">
             <table id="disease" class="table table-striped table-bordered">

                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Contact No</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Pin Code</th>                
                        <th>Address</th>
                         <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    <?php
    if (!empty($referedby)) {
        foreach ($referedby as $referred) {
            ?>
                            <tr>
                                <td><?php echo $referred['ReferedByName']; ?></td>
                                <td><?php echo $referred['ContactNo']; ?></td>
                                <td><?php echo $referred['City']; ?></td>
                                <td><?php echo $referred['State']; ?></td>
                                <td><?php echo $referred['ZipCode']; ?></td>
                                <td><?php echo $referred['Address']; ?></td>
                                <td> <?php
                            if ($referred['IsActive'] == '1') {
                                echo "Active";
                            } else {
                                echo "Inactive";
                            }
                            ?></td>
                                <td><a class='btn btn-info btn-xs' href="?act=update&id=<?php echo base64_encode($referred['ReferedById'] . "|" . $referred['ReferedByName'] . "|" . $referred['ContactNo'] . "|" . $referred['State'] . "|" . $referred['ZipCode'] . "|" . $referred['City'] . "|" . $referred['Address']); ?>" title="Edit"><i class="fa fa-edit"></i></a>
                                <a id='editref' href="<?php echo site_url(); ?>/referredby/changestatus?status=<?php echo $referred['IsActive']; ?>&id=<?php echo base64_encode($referred['ReferedById']); ?>" title="<?php
                                       if ($referred['IsActive'] == '1') {
                                           echo "click here to inactive";
                                       } else {
                                           echo "click here to active";
                                       }
                                       ?>" class="btn btn-<?php if ($referred['IsActive'] == '0') {
                                echo "primary";
                            } else {
                                echo "danger";
                            } ?> btn-xs" onclick="return confirm('Are you sure  to <?php if ($referred['IsActive'] == '1') {
                                echo "Inactive";
                            } else {
                                echo "Active";
                            } ?> this referred by');">
                            <?php
                            if ($referred['IsActive'] == '1') {
                                //echo "Deactivate";?>
                                <i class="fa fa-toggle-off"></i>
                           <?php } else {
                                //echo "Activate";?>
                                <i class="fa fa-toggle-on"></i>
                           <?php }
                            ?>
                                    </a></td>
                            </tr>
        <?php }
    }
    ?>   

            </tbody>
        </table>
    </div>
</div>


</div>