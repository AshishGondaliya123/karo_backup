<!DOCTYPE html>
<html>
<head>
    <title>Karo Reset Password</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>karoclient/css/style.css" />
    <style>
        label.error{
            color:red;
        },
        #resetpass .error {
        color: red;
        }
    </style>
</head>

<body>
    <div class="sign-Sec">  
  <div class="table_cell">
   <?php $id=$_REQUEST['id'];
   $attributes = array('class' => 'resetpass', 'id' => 'resetpass');
   echo form_open('login/resetpassword?id='.$id,$attributes);?>
  <div class="sign-Col">
  <div class="user"><img src="<?php echo base_url(); ?>karoclient/images/karo_logo.png"></div>
  <p>Create a new password. Then re-enter to confirm your new password.</p>
  <h2>Reset Password</h2>
  <div class="form-group">
  <label>New Password</label>
  <input name="rpassword" id="rpassword" class="form-control" type="password" placeholder="Password">
  </div>
  <div class="form-group">
  <label>Confirm New Password</label>
  <input name="cpassword" id="cpassword" class="form-control" type="password" placeholder="Confirm Password">
  </div>
  <div class="form-group">
  <button type="submit" class="btn btn-info submit">Submit</button>
  </div>
 <div class="clearfix"></div>
  </div>
  </form>
  </div>
  
  </div>
    

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url(); ?>karoclient/js/bootstrap.min.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>karoclient/js/jquery.validate.min.js"></script>

<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

 <script>

        $( "#resetpass" ).validate({
        rules: {  

         rpassword: {required: true, minlength: 6},
         cpassword: {required: true, minlength: 6, equalTo: "#rpassword"},

        },
        submitHandler: function (form) {

         form.submit();

      }

      });
        </script>