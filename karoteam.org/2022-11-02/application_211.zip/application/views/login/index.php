<!DOCTYPE html>
<html>
<head>
    <title>KARO Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url(); ?>karoclient/css/style.css" />
    <style type="text/css">
#forgetPassLink .error {
    color: red;
}

    </style>
</head>

<body>
    <div class="sign-Sec">
     <div class="table_cell">
  <div class="sign-Col">
  <div class="user"><a href="#"><img src="<?php echo base_url(); ?>karoclient/images/karo_logo.png"></a></div>
  <p>Enter your credentials to access KARO.</p>
  <h2>SIGN IN</h2>
        <div class="panel panel-default">
            <div class="panel-body">
                <?php
                if($this->session->flashdata('message'))
                {
                    echo '
                    <div class="alert alert-success">
                        '.$this->session->flashdata("message").'
                    </div>
                    ';
                }
                ?>
               <?php echo form_open('login/validation');?>
                
                    <div class="form-group">
                        <label>Enter Email Address</label>
                        <input type="text" name="user_email" class="form-control" value="<?php echo set_value('user_email'); ?>" />
                        <span class="text-danger"><?php echo form_error('user_email'); ?></span>
                    </div>
                    <div class="form-group">
                        <label>Enter Password</label>
                        <input type="password" name="user_password" class="form-control" value="<?php echo set_value('user_password'); ?>" />
                        <span class="text-danger"><?php echo form_error('user_password'); ?></span>
                    </div>
                    <div class="form-group">
                    <div class="checkSec pull-left">
<label>
<div class="checkbx">
Remember me
<input type="checkbox" name="#">
</label>
<span></span>
</div>			 
</div>
<div class="pull-right">
  <a href="#" data-toggle="modal" data-target="#myModal">Forgot Password?</a>
 
</div>
<div class="clearfix"></div>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="login" value="Login" class="btn btn-info" /><!--<a href="<?php //echo base_url(); ?>register">Register</a>-->
                    </div>
                    <!--
                    <ul class="social">
                    <li><a href="#" class="facebook"></a></li>
                    <li><a href="#" class="g-plus"></a></li>
                    <li><a href="#" class="twiter"></a></li>
                    </ul>
                   -->
                    
                </form>
            </div>
        </div>
    </div>
    </div>
    </div>
    <div class="modal fade forget-sec" id="myModal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Forgot Password</h4>
        </div>
          <?php 
        $attributes = array('class' => 'forgetPassLink', 'id' => 'forgetPassLink');
          echo form_open('login/forgotpassword',$attributes);?>
        <div class="modal-body">
       
        <div class="inputRow">
          <label>Email address</label>
          <input name="forgetemail" id="forgetemail" class="form-control" type="text" >
          </div>
          <div class="inputRow">
          <button type="submit" class="btn btn-default submit">Submit</button>
            </div>
            <div class="clearfix"></div>
           
        </div>
      </from>
       
      </div>
    </div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url(); ?>karoclient/js/bootstrap.min.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>karoclient/js/jquery.validate.min.js"></script>

<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

 <script>

        $( "#forgetPassLink" ).validate({
        rules: {  

         forgetemail: {required: true }

        },
        submitHandler: function (form) {

         form.submit();

      }

      });
        </script>

</body>
</html>