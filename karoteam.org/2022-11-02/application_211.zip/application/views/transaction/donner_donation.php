
<style type="text/css">
   #donner_donation .error{
            color:red;
          }
</style>

<div class="dash_right_section">
<h2 class="main-heading">Donor Donation</h2>
<div class="dash_column">
<div><?php echo $this->session->flashdata('message');?></div>
         <?php
            $attributes = array('class' => 'donner_donation', 'id' => 'donner_donation');
            echo form_open('Transaction/saveDonerDonation', $attributes);
            ?>
    
        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">Donor <span class="mandate">*</span></label>
                <select class="form-control" name="doner" id="doner">
                    <option value="">Select donor</option>
                    <?php
                        if($active_donner)
                        {
                            foreach ($active_donner as $key => $value) { ?>
                            <option value="<?php echo $value['donner_id'];?>"> <?php echo $value['name'];?></option>
                            <?php }}?>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="name">Donation Amount <span class="mandate">*</span></label>
                <input type="text" id="donation_amount" name="donation_amount" class="form-control" placeholder="Enter donation amount">
            </div>
             
        </div>
        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">Donation Date <span class="mandate">*</span></label>
                <input id="donation_date" name="donation_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="">
                <!-- <input type="date" name="donation date" class="form-control form_date" placeholder="Enter secondary contact" id="example-datetime-local-input" > -->
            </div>
            <div class="form-group col-md-6">
                <label for="name">Payment Mode <span class="mandate">*</span></label>
                <select class="form-control" name="donation_mode" id="donation_mode">
                    <option value="" selected>Select donation mode</option>
                    <?php if($donation_mode){
                        foreach ($donation_mode as $k => $v) {?>
                        <option value="<?php echo $v->PaymentId ;?>"><?php echo $v->PaymentMode ;?></option>
                        <?php }
                        }?>
                </select>
            </div>
            
             
        </div>
        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">Bank Name <span class="mandate rmmandate">*</span> </label>
                <input type="text" id="bank_name" name="bank_name" class="form-control" placeholder="Enter bank name">
            </div>
            <div class="form-group col-md-6">
                <label for="name"><span id="chequenolbl">Reference No.</span> <span class="mandate rmmandate">*</span></label>
                <input type="text" id="cheque" name="cheque" class="form-control" placeholder="Enter reference no.">
            </div>
            
            
             
        </div>

        <!-- <div class="row">
            <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx" style="font-size: 13px;font-weight: 400;color:#989da2;font-family:roboto;">
                                             Donation Receive
                                            <input type="checkbox" value="1" name="IsDonationReceive" id='IsDonationReceive' >
                                            <span></span>
                                        </div>           
                                    </label></div>
        </div> -->
        <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="add" class="btn btn-primary save">Submit</button>
            </div>
        </div>
    </div>                
<div class="dash_column">
    <div class="tbl">
        <table class="table  table-bordered" id="donor_donation">
            <thead>
                <tr>
                    <th>Donor</th>
                    <th>Donation Date</th>
                    <th>Donation Amount</th>
                    <th hidden>Created date</th>
                    <!-- <th>Donation status</th> -->
                </tr>
            </thead>
            <tbody>
            <?php
                if($result){
                    foreach ($result as $dk => $dv) {
                        ?>
                <tr>
                    <td><?php echo $dv->OrganizationName ? $dv->OrganizationName :$dv->FirstName.' '.$dv->MiddleName.' '.$dv->LastName;?></td>
                    <td><?php echo date('d/m/Y',strtotime($dv->DonationDate));?></td>
                    <td><?php echo numberformat($dv->DonationAmount);?></td>
                    <td hidden><?php echo $dv->CreatedDate?></td>
                    <!-- <td><?php echo ($dv->IsDonationReceive == 1)?'Received' : 'Pending';?></td> -->

                </tr>
                   <?php }} ?>
                
                </tbody></table>
    </div>
</div>            


</div>