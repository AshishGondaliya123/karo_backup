<style type="text/css">
    .error{
        color:red !important;
    }
	
	
    .jconfirm-box-container.jconfirm-animated.col-md-4.col-md-offset-4.col-sm-6.col-sm-offset-3.col-xs-10.col-xs-offset-1.jconfirm-no-transition {
        width: 700px !important;
        margin-left: 25%;
    }

</style>
<div class="dash_right_section">
<h2 class="main-heading">Refund Amount Details</h2>
<div class="dash_column">

        <?php if($this->session->flashdata('message'))echo $this->session->flashdata('message'); ?>
        <?php
        $attributes = array('class' => 'refund_amount_details', 'id' => 'refund_amount_details');
        echo form_open('Transaction/refundAmount', $attributes);
        ?>
		
	
            <div class="">
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="name">From Date</label>
                        <input id="from_date" name="from_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $from_date ? $from_date:'';?>">
                        <!-- <input type="date" name="donation date" class="form-control form_date" placeholder="Enter secondary contact" id="example-datetime-local-input" > -->
                    </div>
                    <div class="form-group col-md-6">
                        <label for="name">To Date </label>
                        <input id="to_date" name="to_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $to_date ? $to_date:'';?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="name"> Patient KARO Case Number / CASE NO / Patient ID / Patient Name</label>
                        <span class="mandate">*</span>
                        <input id="karo_no" name="karo_no"  type="text" class="form-control" placeholder="Enter KARO no" value="<?php echo isset($karo) ? $karo : ""; ?>">
                        <label class="error karoerror" style="display: none">Please enter KARO no.</label>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="department">Department</label>
                        <select class="form-control" name="department" id="department">
                            <option value="">Select Department</option>
                            <?php
                            if($active_department){
                                foreach ($active_department as $key => $value) { ?>
                                    <option value="<?php echo $value['DeptId'];?>" <?=(!empty($_POST['department']) && $_POST['department']==$value['DeptId']?"selected":"")?>> <?php echo $value['DeptName'];?></option>
                            <?php }
                            }?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <button type="submit" name="filter_save" value="filter" class="btn btn-primary save">Submit</button>
                    </div>
                </div>
            </div>
		
     
        <?php
        echo form_close();
        ?>
    </div>
	

    <div class="dash_column">
        <div class="tbl">
            <table class="table table-striped table-bordered" width="100%" id="disbursed_amount_refund_tbl">
                <thead>
                    <tr>
                        <th hidden>Id</th>
                        <th>Patient ID</th>
                        <th>Patient Name</th>
                        <th>Total Amount Disburesd</th>
                        <th>Amount Refunded</th>
                        <th>Refund Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result) {
                        foreach ($result as $key => $value) {
                            ?>
                            <tr>
                                <td hidden><?php echo $value['id']; ?></td>
                                <td><a  href="<?php echo base_url() . 'index.php/patientmaster/index?uid=' . $value['id'] ?>" title="Patient Detail" target="_blank"><?php echo $value['patient_id'] ?></a></td>
                                <td><?php echo $value['patient_name']; ?></td>
                                <td><?php echo numberformat($value['total_amount']); ?></td>
                                <td><?php echo numberformat($value['refund_amount']); ?></td>
                                <td><?php echo ($value['refund_date']!="" && $value['refund_date']!="0000-00-00")?date('d/m/Y', strtotime($value['refund_date'])):""; ?></td>
                                <td>
                                <a class="btn btn-success btn-xs donr_detail" id="deep" data-id="<?php echo $value['caseId']; ?>" data-type ="displaydisb" title="Edit Disbursal List" <?php if((empty($value['patient_name'])) || $value['total_amount']==0.00) echo "disabled";?>><i class="fa fa-edit"></i></a>
                                <a class="btn btn-info btn-xs donr_detail" id="deep" data-id="<?php echo $value['caseId']; ?>"  data-type ="displaydisb" title="Display Disbursal List" <?php if((empty($value['patient_name'])) || $value['total_amount']==0.00) echo "disabled";?>><i class="fa fa-money"></i></a></td>
                                <!--<td><a class="btn btn-info btn-xs donr_detail" href="<?php //echo base_url() . 'index.php/Transaction/refundAmount?cid=' . $value['id']        ?>" title="Disburse Detail"><i class="fa fa-money"></i></a></td>-->
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
	

    <div class="dash_column donor_name" id="donor_name" style="display:none">
        <?php //echo $this->session->flashdata('message'); ?>
        <form action="<?php echo base_url(); ?>index.php/Transaction/saverefund" method="post" class='amount_by_donor' id='refund_amount_by_donor' enctype='multipart/form-data'>
            <div class="row">
			
			    <div class="form-group col-md-4">
                    <label for="name">Sanction Id<span class="mandate">*</span></label>
                    <div id="sanction_id_list"></div>
                </div>
			      
                <div class="form-group col-md-4">
                    <label for="name">Donor <span class="mandate">*</span></label>
					<select class="form-control" name="donor_list" id="donor_list">
                    <option value="">Select donor</option>
  
                </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="name">Donate Amount</label>
                    <input type="text" name="donate_amount_donor" id="donate_amount" class="form-control" placeholder="Total amount disbursed by selected donor." readonly  >
                </div>
				
				<input type="hidden" name="disbId" id="disbId" class="form-control" placeholder="Total amount disbursed by selected donor." readonly  >
                
				
            </div>
            <div class="row">
			
			    <div class="form-group col-md-4">
                    <label for="name">Mode Of Refund <span class="mandate">*</span></label>
                    <select class="form-control" name="refund_mode" id="refund_mode">
                        <option value="">Select disbursed mode</option>
                        <?php
                        if ($mode) {
                            foreach ($mode as $key => $value) {
                                ?>
                                <option value="<?php echo $value->PaymentId; ?>"><?php echo $value->PaymentMode; ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="name">Cheque /UTR No.<span class="mandate del_mandate">*</span></label>
                    <input type="text" name="cheque_no" id="cheque_dd" class="form-control" placeholder="Enter cheque / UTR no."  >
                </div>
				<div class="form-group col-md-4">
                    <label for="name">Bank Name<span class="mandate del_mandate">*</span></label>
                    <input type="text" name="bank" id="bank" class="form-control" placeholder="Enter bank name"  >
                </div>
				
               
            </div>
			
            <div class="row">
			<div class="form-group col-md-4">
                    <label for="name">Refund Amount<span class="mandate">*</span></label>
                    <input type="text" name="refund_amount" id="refund_amount" class="form-control" placeholder="Enter refund amount"  >
                    <!-- <input type="date" name="disbursed_date" class="form-control date defaultdater" placeholder="Enter disbursed date" > -->
                </div>
			 <div class="form-group col-md-4" >
                    <label for="name">Refund Date<span class="mandate">*</span></label>
                    <input type="hidden" name="sanction_date" id="sanction_dt" value="<?php echo $sanction_date[0]['sanction_date'] ? $sanction_date[0]['sanction_date'] : ''; ?>">
                    <input id="disbursed_date" name="refund_date" readonly="" type="date" class="form-control date " placeholder="Select disbursed Date" value="">
                </div>
                <div class="form-group col-md-4">
                    <label for="name">Refund Reason<span class="mandate">*</span></label>
                    <textarea name="refund_reason"  rows="5" id="refund_reason" class="form-control text-add" placeholder="Enter refund reason"  ></textarea>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label for="name">Reference 1  <span class="mandate">*</span></label>
                    <input type="text" id="reference_first" name="reference_first" class="form-control" placeholder=""  >
                </div>
                <div class="form-group col-md-4">
                    <label for="Upload"> <span ></span></label>
                    <input type="file" name="reciept_upload1" id="reciept_upload1" class="form-control file" placeholder=""  >
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label for="name">Reference 2 </label>
                    <input type="text" id="reference_two" name="reference_two" class="form-control" placeholder=""  >
                </div>
                <div class="form-group col-md-4">
                    <label for="Upload">  </label>
                    <input type="file" name="reciept_upload2" id="reciept_upload2" class="form-control file" placeholder=""  >
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <input type="hidden" name="patient_id" value="<?php echo $patient_id; ?>"/>
                    <input type="hidden" name="case_id" value="<?php echo $case_id; ?>"/>
                    <button type="submit" name="save_btn" value="submit" class="btn btn-primary save">Submit</button>
                </div>
            </div>
        </form>
    </div>
	
	<div class="dash_column donor_name" style="display:none">
    <div class="tbl">
  <table class="table table-bordered" id="table_refund_amount">
            <thead>
                <tr>
                        <th>Refund Date</th>
						<th>Sanction Id</th>
                        <th>Donor Name</th>
                        <th>Donor Disbursed Amount</th>
                        <th>Refund Amount</th>
                        <th>Payment Mode</th>
                        <th>Bank Name</th>
                        <th>Cheque No.</th>
                        <th>Reference Name</th>
                        <th>Download receipt</th>
                </tr>
            </thead>
            <tbody>
            <?php

                    if ($resultsreflis) {
                        foreach ($resultsreflis as $key => $value) {


                            ?>
                            <tr id="<?php echo $value->id; ?>">
                                <td><?php echo date('d/m/Y', strtotime($value->refund_date)); ?></td>
								<td><?php echo $value->sanction_id; ?></td>
                                <td><?php echo $value->Doner; ?></td>
                                <td><?php echo numberformat($value->donate_amount); ?></td>
                                <td><?php echo numberformat($value->refund_amount); ?></td>
                                <td><?php echo $value->PaymentMode; ?></td>
                                <td><?php echo $value->bank_name; ?></td>
                                <td><?php echo $value->cheque_no; ?></td>
                                <td><?php echo $value->reference_first; ?></td>
                                <td><?php if ($value->reference_1) { ?><a  id="view_disbursed_rept" href="<?php echo $value->reference_1; ?>" download><i class="fa fa-download"></i></a> <?php } ?></td>
                            </tr>
                                   <?php
                        }
                    }
                    ?>
                </tbody></table>
    </div>
</div>
	</div>