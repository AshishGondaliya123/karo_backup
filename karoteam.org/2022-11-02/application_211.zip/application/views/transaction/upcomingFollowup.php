<style type="text/css">
    #patient_upcoming_followup_details .error{
        color:red;
    }
</style>
<div class="dash_right_section">
    <h2 class="main-heading pull-left">Upcoming Followup</h2>
    <div class="clearfix"></div>
    <div class="dash_column">
        <?php if ($this->session->flashdata('message')) echo $this->session->flashdata('message'); ?>
        <?php
        $attributes = array('class' => 'patient_upcoming_followup_details', 'id' => 'patient_upcoming_followup_details');
        echo form_open('Transaction/upcomingFollowup', $attributes);
        ?>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">From Date <span class="mandate">*</span></label>
                <input  id="from_date" name="from_date" readonly="" type="date" class="form-control defaultdate " placeholder="Select Date" value="<?php echo $from_date ? $from_date : ''; ?>">
                <!-- <input type="date" name="donation date" class="form-control form_date" placeholder="Enter secondary contact" id="example-datetime-local-input" > -->
            </div>
            <div class="form-group col-md-4">
                <label for="name">To Date <span class="mandate">*</span></label>
                <input name="to_date" readonly="" type="date" class="form-control defaultdate" placeholder="Select Date" value="<?php echo $to_date ? $to_date : ''; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="department">Department</label>
                <select class="form-control" name="department" id="department">
                    <option value="">Select Department</option>
                    <?php
                    if($active_department){
                        foreach ($active_department as $key => $value) { ?>
                            <option value="<?php echo $value['DeptId'];?>" <?=(!empty($_POST['department']) && $_POST['department']==$value['DeptId']?"selected":"")?>> <?php echo $value['DeptName'];?></option>
                    <?php }
                    }?>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="add" class="btn btn-primary save">Submit</button>
            </div>
        </div>
    </div> 
    <?php if ($from_date && $to_date) { ?>
        <h4 class="third_heading">Showing Patient Upcoming Followup Details <span> From (<?php echo date('d/m/Y', strtotime($from_date)); ?>) To (<?php echo date('d/m/Y', strtotime($to_date)); ?>)</span></h4>
    <?php } ?>  
    <div class="dash_column family">
        <div class="tbl">
            <table id="upcoming_followup_tbl" class="table table-striped table-bordered" width="100%">
                <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>Name of patient</th>
                        <th>Department</th>
                        <th>Follow Up Done</th>
                        <th>Due date</th>
                        <th>Notes</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result) {
                        foreach ($result as $key => $value) {
                            ?>
                            <tr><td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value['id'] ?>" title="Case Detail" target="_blank"><?php echo $value['patient_id'];?></a></td>
                                <td><?php echo $value['patient_name']; ?></td>
                                <td><?php echo $value['DeptName']; ?></td>
                                <td><?php echo $value['follow_up_done']; ?></td>
                                <td><?php echo $value['next_followup_date']; ?></td>
                                <td><?php echo $value['remark']; ?></td>
                                <td>
                                    <a class="btn btn-success btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value['id'] ?>" title="Edit Follow Up"><i class="fa fa-edit"></i></a>
                                    <a class="btn btn-warning btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value['id'] ?>" title="Detail"><i class="fa fa-info-circle"></i></a>
                                </td>   
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="clearfix"></div>
    </div>
</div>