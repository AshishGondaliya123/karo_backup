<?php
class Referredby_model extends CI_Model {
    function savereferedby($refered_by_name,$city,$state,$zipcode,$contact_no,$address) {
        $CreatedByUserId = $this->session->userdata('UsertId');
        $query = $this->db->get_where('referedby', array('ReferedByName' => $refered_by_name));      
        if($query->num_rows()==0){
        $query="insert into referedby (ReferedByName,City,State,ZipCode,ContactNo,Address,IsActive,CreatedByUserId)values('".$refered_by_name."','".$city."','".$state."','".$zipcode."','".$contact_no."','".$address."','1','".$CreatedByUserId."')";
            if($this->db->query($query)){
				return '<div class="alert alert-success">Saved successfully</div>';
			}else{
				return '<div class="alert alert-danger">Something went wrong</div>';
			}
        }else{
            return '<div class="alert alert-danger">Referred by already exist</div>';
        }
    }
    function getreferedby() {
        $this->db->order_by('ReferedById', 'DESC');  //actual field name of id
        // $query=$this->db->get_where('referedby',array('IsActive' => '1'));
        $query=$this->db->get_where('referedby');
        return $query->result_array();
    }
    function getstates() {
        $this->db->order_by('city_id', 'ASC');
        $this->db->group_by('city_state');
        $query=$this->db->get('cities');
        return $query->result_array();
    }
    function getcities($statename) {
        if(trim($statename)=='Andaman'){
          $statename =  'Andaman & Nicobar';
        }
        $this->db->order_by('city_name', 'asc'); 
        $query = $this->db->get_where('cities', array('city_state' => $statename));
        //print_r($this->db->last_query());  die;      
        return $query->result_array();       
    }
    function changeStatus($id,$status) {       
        $query="update referedby set IsActive='".$status."' where ReferedById='".$id."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
    }
   
    function updatereferedby($refered_by_name,$city,$state,$zipcode,$contact_no,$address,$ReferedById) { 
        $query = $this->db->get_where('referedby', array('ReferedByName' => $refered_by_name,'ReferedById !=' => $ReferedById));      
        if($query->num_rows()==0){
       $query="update referedby set ReferedByName = '".$refered_by_name."',City = '".$city."',State = '".$state."',ZipCode = '".$zipcode."',ContactNo = '".$contact_no."',Address = '".$address."' where ReferedById='".$ReferedById."'";
        if($this->db->query($query)){
            return '<div class="alert alert-success">Updated successfully</div>';
        }else{
            return '<div class="alert alert-danger">Something went wrong</div>';
        }
        }else{
             return '<div class="alert alert-danger">Referred by already exist</div>';
        }
    }
}
?>