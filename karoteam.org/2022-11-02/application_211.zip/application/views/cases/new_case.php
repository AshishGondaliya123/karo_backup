<?php
if ($active_doner) {
    $doner_option = '<option value="">Select Donor</option>';
    foreach ($active_doner as $key => $value) {
        $doner_option.= '<option value = "' . $value['doner_id'] . '">' . $value['name'] . '</option>';
    }
}
// prx($result);
?>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        var doner_option = '<?php echo $doner_option; ?>';
        $('#active_doner').html(doner_option);
    });
</script>

<div class="dash_right_section">
    <h2 class="main-heading pull-left">New Cases</h2>
    <div class="custom-search-input pull-right">
        <!-- <div class="input-group col-md-12">
            <input type="text" class="  search-query form-control" placeholder="Search by Patient Name or ID" />
            <span class="input-group-btn">
                <button class="btn btn-primary color-theme" type="button">
                    <span class=" fa fa-search"></span>
                </button>
            </span>
        </div> -->
    </div>

    <div class="clearfix"></div>
    <div class="dash_column family">
    <!-- <input type="submit" class="btn btn-primary add" value="Export to Excel" style="margin-bottom:20px !important"> -->
        <div class="tbl">
            <table id="new_case_tbl" class="table table-striped table-bordered" width="100%">

                <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>Reg.Date</th>
                        <th>Name of patient</th>
                        <th>Department</th>
                        <th>Hospital</th>
                        <th>DOB</th>
                        <th>Contact numbers</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result) {
                        foreach ($result as $k => $v) {
                            ?>
                            <tr>
							<td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $v->id ?>" title="Case Detail" target="_blank"><?php echo $v->patient_id; ?></a></td>
                                <td><?php echo $v->registration_date; ?></td>
                                <td><?php echo $v->patient_name; ?></td>
                                <td><?php echo $v->DeptName; ?></td>
                                <td><?php echo $v->HospitalName; ?></td>
                                <td><?php echo ($v->dob == "00/00/0000") ? "-" : $v->dob; ?></td>
                                <td><?php
                                    echo $v->patient_phone;
                                    if ($v->caregiver_phone)
                                        echo ", " . $v->caregiver_phone;
                                    ?></td>
                                <td style="width:80px">

                                    <button class="btn btn-success btn-xs approved" data-toggle="modal" !href="#approved"  id="approved" data-caseid="<?php echo $v->case_id; ?>" data-reqamt ="<?php echo $v->required_fund; ?>" title="Approve" <?php if ((empty($v->DiseaseName) && empty($v->HospitalName)) || empty($v->required_fund)) echo "disabled"; ?> ><i class="fa fa-check"></i></button>
                                    <button class="btn btn-danger btn-xs reject_hold_btn" data-toggle="modal" data-id="<?php echo $v->case_id; ?>" data-type="reject" title="Reject" <?php if (empty($v->DiseaseName) && empty($v->HospitalName) || empty($v->required_fund)) echo "disabled"; ?> ><i class="fa fa-close"></i></button>
                                    <button class="btn btn-info btn-xs reject_hold_btn"  data-toggle="modal" data-id="<?php echo $v->case_id; ?>" data-type ="hold" title="Hold" <?php if (empty($v->DiseaseName) && empty($v->HospitalName) || empty($v->required_fund)) echo "disabled"; ?>><i class="fa fa-pause"></i></button>
                                    <a class="btn btn-warning btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $v->id ?>" title="Detail"><i class="fa fa-info-circle"></i></a>
<!--                                    <button class="btn btn-info btn-xs disb_btn"  data-toggle="modal" data-id="<?php echo $v->case_id; ?>" data-type ="displaydisb" title="Display Disbursal List"><i class="fa fa-eye"></i></button>-->
                                </td>
                            </tr>

                            <?php
                        }
                    }
                    ?>

                </tbody>
            </table>
        </div>

        <div class="clearfix"></div>
    </div>
    <div id="approved_modal" class="modal fade in">
        <div class="modal-dialog">
            <div class="modal-content">
                <a class="close" data-dismiss="modal"><span>X</span></a>
                <div class="modal-body">
                    <div id="top-msg1" class="top-msg" hidden></div>
                    <div class="form-group">
                        <label class="control-label"  for="username">Required Amount <span class="mandate">*</span></label>
                        <input type="text"  name="username" placeholder="Required Amount" class="form-control rgt rmv" id ="req_amt"readonly>
                    </div>
                    <div class="form-group">
                        <label class="control-label"  for="username">Donor <span class="mandate">*</span></label>
                        <select class="form-control rgt" name="active_doner" id="active_doner">

                        </select>
                        <input type="hidden" name="hidden_case_id" id="hidden_case_id">

                    </div>
                    <div class="form-group">
                        <label class="control-label "  for="avaliable_donner_amt">Donor Available Amount </label>
                        <input class="form-control rgt" type="text" name="avaliable_donner_amt" id="avaliable_donner_amt" readonly="true">

                    </div>
                    <div class="form-group">
                        <label class="control-label"  for="username">Sanction Amount <span class="mandate">*</span> </label>
                        <input type="text"  name="username" placeholder="" class="form-control rgt  allownumericwithdecimal" id ="approve_amt">
                    </div>
					
					<div class="form-group" >
             <label class="control-label"  for="sanc_date">Sanction Date <span class="mandate">*</span> </label>
             <input id="sanct_date" name="sanct_date" readonly="" type="date" class="form-control date" placeholder="Select Date" value="" >
           </div>

                    <div class="clearfix"></div>
                </div>
                <div class="modal-footer">

                    <button class="btn btn-primary add close_modal" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary add" id="approve_submit">Submit</button>

                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dalog -->
    </div>
    <div id="Reject_hold" class="modal fade in">
        <div class="modal-dialog">
            <div class="modal-content">
                <a class=" close" data-dismiss="modal"><span>X</span></a>

                <div class="modal-body">
                    <div id="top-msg" class="top-msg" hidden></div>
                    <div class="form-group" >
                        <label for="name" id="reason_for"> </label>
                        <textarea class="adress reject_hold_reason" name="Reason" id="reason" rows="2"></textarea>
                        <input type="hidden" name="hidden_patient_id" id="hidden_patient_id" data-type ="">
                        <input type="hidden" name="hidden_action" id="hidden_action" data-type ="">


                    </div>
                </div>
                <div class="modal-footer">

                    <button class="btn btn-primary add close_modal" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary add reject-hold-submit">Submit</button>

                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dalog -->
    </div>

    <div id="dis_modal" class="modal fade in">
        <div class="modal-dialog">
            <div class="modal-content">
                <a class=" close" data-dismiss="modal"><span>X</span></a>
                <div class="modal-body">
                    <div id="top-msg" class="top-msg" hidden></div>
                    <div class="form-group" >
                        <label for="name" id="reason_for">Patient Disburse Amount Details</label>
                        <div id="disb_list"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary add close_modal" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dalog -->
    </div>
    
</div>