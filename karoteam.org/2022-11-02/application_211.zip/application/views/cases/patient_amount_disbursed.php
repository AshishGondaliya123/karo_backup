<style type="text/css">
    #amount_disbursed .error{
        color:red;
    }
    th {
        text-align: center;
    }
    td {
        text-align: center;
    }
    .ss {
        background: #f0643b;
        color: #fff;
        border: none;
        padding: 10px 30px;
        font-size: 14px;
        float: right;
        margin-top: -2px !important;
        margin-right: 725px;
        border-radius: 0px;
    }
    .ss1 {
        background: #f0643b;
        color: #fff;
        border: none;
        padding: 11px 29px;
        font-size: 14px;
        float: right;
        margin-top: -2px !important;
        /* margin-right: 725px; */
        border-radius: 0px;
        margin: 2px;
    }
	
	   .jconfirm-box-container.jconfirm-animated.col-md-4.col-md-offset-4.col-sm-6.col-sm-offset-3.col-xs-10.col-xs-offset-1.jconfirm-no-transition {
        width: 600px !important;
        margin-left: 25%;
    }
	
	.edit{
		    background: #f0643b;
    color: #fff;
    border: none;
    padding: 10px 30px;
    font-size: 15px;
    /*float: right;
    margin: 0 !important;*/
	}
</style>
<div class="dash_right_section">
    <h2 class="main-heading">Patient Amount Disbursed</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle green"><img src="<?php echo base_url('karoclient/images/patient-id.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Patient Id </h3>
                    <p><?php if ($patient_details[0]['patient_id']) echo $patient_details[0]['patient_id']; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle yellow"><img src="<?php echo base_url('karoclient/images/case.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Case No.</h3>
                    <p><?php if ($patient_details[0]['case_number']) echo $patient_details[0]['case_number']; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink"><img src="<?php echo base_url('karoclient/images/patient-name.png'); ?> "></div>
                <div class="cirtext">
                    <h3>Patient Name</h3>
                    <p><?php if ($patient_details[0]['patient_name']) echo $patient_details[0]['patient_name']; ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php
    $cid = $case_id;
    ?>
    <div class="dash_column">
        <?php echo $this->session->flashdata('message'); ?>
		<form method="post" class="amount_disbursed" id="amount_disbursed" enctype="multipart/form-data">
        <?php
        // $attributes = array('class' => 'amount_disbursed', 'id' => 'amount_disbursed', 'enctype' => 'multipart/form-data');
        echo form_open_multipart("Caseinfo/getAmountDisbursed?cid=$cid", $attributes);
        ?>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">Required Amount</label>
                <input type="text" id="fund_required" name="fund_required" class="form-control" placeholder="Enter fund_required" readonly="" value="<?php if ($patient_details[0]['required_fund']) echo $patient_details[0]['required_fund']; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Approved Amount</label>
                <input type="text" id="approved_amount" name="approved_amount" class="form-control" placeholder="Enter approved amount" readonly="" value="<?php if ($patient_details[0]['approved_amount']) echo $patient_details[0]['approved_amount']; ?>">
            </div>
			
			
            <div class="form-group col-md-4">
                <label for="name">Sanction Id <span class="mandate">*</span></label>
                <select class="form-control" name="sanction_id" id="sanction_id" onchange="donerByDateAjax(this.value)">
                    <option value="">Select sanction id</option>
                    <?php
                    if ($sanction_rehelp_date) {
                        foreach ($sanction_rehelp_date as $v) {
							//prx($v);
                            ?>
                            <option  value="<?php echo $v->id; ?>"><?php echo $v->id; ?></option>
                            <?php
                        }
                    }
                    ?>
                </select>
            </div>
        </div>   
        <div class="row">
				
			 <div class="form-group col-md-4">
                <label for="name">Donor <span class="mandate">*</span></label>
                
				<select class="form-control" name="disbursed_donor" id="disbursed_donor">
                    <option value="">Select donor</option>
                    <?php
                    // if ($disbursed_donner) {
                        // foreach ($disbursed_donner as $k => $v) {
                            // ?>
                            <!-- <option data-avaliabledonneramt="<?php //echo $v->avaliable_amt ? $v->avaliable_amt : 0; ?>" data-donoramount="<?php //echo $v->donner_approved_amount ? $v->donner_approved_amount : 0; ?>" value="<?php //echo $v->doner_id; ?>"><?php ///echo $v->FirstName . ' ' . $v->MiddleName . ' ' . $v->lastname; ?></option>-->
                            <?php
                        // }
                    // }
                    ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="name">Total amount approved by selected donor</label>
                <input type="text" name="total_dis_amt_donor" id="total_dis_amt_donor" class="form-control" placeholder="Total amount disbursed by selected donor." readonly  >
            </div>
            <div class="form-group col-md-4">
                <label for="name">Disbursed Amount <span class="mandate">*</span></label>
                <input type="text" id="disbursed_amount" name="disbursed_amount" class="form-control allowdecimal" placeholder="Enter disbursed amount">
                <input type="hidden" id="total_disbursed_amount" name="total_disbursed_amount" class="form-control" value="<?php //if ($total_approved_amount) echo $total_approved_amount; ?>">
            </div>
		
			
          
        </div>
        <div class="row">
		
		  <div class="form-group col-md-4">
                <label for="name">Payment mode <span class="mandate">*</span></label>
                <select class="form-control" name="disbursed_mode" id="disbursed_mode">
                    <option value="">Select disbursed mode</option>
                    <?php
                    if ($mode) {
                        foreach ($mode as $key => $value) {
                            ?>
                            <option value="<?php echo $value->PaymentId; ?>"><?php echo $value->PaymentMode; ?></option>
                            <?php
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="name">Disbursed Date<span class="mandate">*</span></label>
                <input type="hidden" name="sanction_date" id="sanction_dt" value="<?php echo $sanction_date[0]['sanction_date'] ? $sanction_date[0]['sanction_date'] : ''; ?>">
                <input id="disbursed_date" name="disbursed_date" readonly="" type="date" class="form-control date " placeholder="Select disbursed Date" value="">

                <!-- <input type="date" name="disbursed_date" class="form-control date defaultdater" placeholder="Enter disbursed date" > -->
            </div>
            <div class="form-group col-md-4">
                <label for="name">Bank Name<span class="mandate rmmandate"></span></label>
                <input type="text" name="bank_name" id="bank_name" class="form-control" placeholder="Enter bank name"  >
            </div>
           
        </div>
        <div class="row">
		
		 <div class="form-group col-md-4">
                <label for="name">Cheque / DD No.<span class="mandate rmmandate"></span></label>
                <input type="text" name="cheque_dd" id="cheque_dd" class="form-control" placeholder="Enter cheque / dd no."  >
            </div>
            <div class="form-group col-md-4" style="display: none;">
                <label for="name">avaliable donner amount<span class="mandate"></span></label>
                <input type="hidden" id="avaliable_donner_amt" name="avaliable_donner_amt" class="form-control" placeholder="Enter cheque / dd no."  >
            </div>
            <div class="form-group col-md-4">
                <label for="name">Reciept No./Memo No.  <span class="mandate"></span></label>
                <input type="text" id="reciept_memo_no" name="reciept_memo_no" class="form-control" placeholder="Enter Reciept No./Memo No."  >
            </div>
            <div class="form-group col-md-4">
                <label for="Upload">Upload Reciept <span class="mandate"></span></label>
                <input type="file" name="reciept_upload" id="reciept_upload" class="form-control file" placeholder=""  >
            </div>
        </div>      
        <div class="row">
            <div class="col-md-12">
			<a class="btn btn-primary edit" href="<?php echo base_url() . 'index.php/Caseinfo/loadRehelpDetails?patient_id=' . $patient_details[0]['patient_id'] . '&cid=' . $cid; ?>" title="Rehelp" > Edit Sanction Detail</a>
               
				<button type="submit" name="save" value="add" class="btn btn-primary save">Submit</button>
            </div>
        </div>
		</form>
    </div>


    <div class="dash_column">
        <div class="tbl">
            <table class="table table-striped table-bordered" width="100%" id="disbursed_amount_tbl">
                <thead>
                    <tr>
					    <th>Sanction Id</th>
                        <th>Disbursed Date</th>
                        <th>Donor Name</th>
                        <th>Disbursed Amount</th>
                        <th>Reciept No./Memo No.</th>  
<!--                        <th>Donor Name</th>-->
                        <th>Payment Mode</th>
                        <th>Bank Name</th>
                        <th>Cheque / DD No.</th>
                        <th>Download Reciept</th>
                        <th>Action</th>                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result) {
                        foreach ($result as $key => $value) {
                            $CI = &get_instance();
                            $CI->load->model('case_model', 'cm');
                            ?>
                            <tr id="<?php echo $value['id']; ?>">
							    <td><?php echo $value['sanction_id']; ?></td>
                                <td>
                                    <?php
                                    $date = date('d/m/Y', strtotime($value['DisburesedDate']));
                                    if (strpos($date, '-0001') !== false) {
                                        echo 'N/A';
                                    } else {
                                        echo $date;
                                    }
                                    ?>
                                </td>
                                <td><?php echo $value['FirstName'] . ' ' . $value['MiddleName'] . ' ' . $value['lastname']; ?></td>
                                <td><?php echo numberformat($value['DisbursedAmt']); ?></td>
                                <td><?php echo $value['receipt_no']; ?></td>
        <!--                                <td>
                                <?php
                                $getDonorDetails = $CI->cm->getDonorDetailsById($value['DonorId']);
                                echo $getDonorDetails[0]->FirstName;
                                ?>
                                </td>-->
                                <td>
                                    <?php
                                    $getPaymentMode = $CI->cm->getPaymentModeById($value['PaymentModeId']);
                                    echo $getPaymentMode[0]->PaymentMode;
                                    ?>
                                </td>
                                <td><?php echo $value['DisbursedBank']; ?></td>
                                <td><?php echo $value['DisbursedRefNo']; ?></td>
                                <!-- 
                                <td><?php if ($value['receipt_file']) { ?><button type="button" class="btn btn-info btn-xs" id="view_disbursed_receipt" value ="<?php echo $value['receipt_file']; ?>"><i class="fa fa-eye"></i></button> <?php } ?></td> -->
                                <td><?php if ($value['receipt_file']) { ?><a  id="view_disbursed_rept" href="<?php echo $value['receipt_file']; ?>" download><i class="fa fa-download"></i></a> <?php } ?></td>
                                <td>
                                    <a href="<?php echo base_url() . "index.php/caseinfo/editcasedisbursedetails?cid=" . $_GET["cid"] . "&did=" . $value['id']; ?>">
                                        <button style="" class="btn btn-info btn-xs disb_btn" title="Edit"><i class="fa fa-pencil btn-success"></i></button>
                                    </a>

                                   <a  href="javascript:void(0)">
                                                <button class="btn btn-info btn-xs disb_btn" style="background:#d9534f;" href="javascript:void(0)" title="Delete" onclick="deletDisburseIf(<?php echo $value['id']; ?>,'<?php echo $value['DonorId']; ?>');"><i class="fa fa-trash"></i></button>
												</a>

                                </td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
            <button class="btn btn-primary disb_btn_list ss" data-toggle="modal" data-id="<?php echo $_GET["cid"]; ?>" data-type ="displaydisblist">View Deleted Disbursal List</button>
            <br/>
        </div>
    </div>            
</div>

<div id="receipt_modal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <!-- <h4 class="modal-title">Modal Header</h4> -->
            </div>
            <div class="modal-body" id="receipt_img">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary save" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div id="dis_modal_delete" class="modal fade in">
    <div class="modal-dialog">
        <div class="modal-content">
            <a class=" close" data-dismiss="modal"><span>X</span></a>
            <div class="modal-body">
                <div id="top-msg" class="top-msg" hidden=""></div>
				<form method="post" action="<?php echo base_url(); ?>index.php/Caseinfo/getAmountDisbursed?cid=$cid>

                <div class="form-group">
                    <label for="name" id="reason_for">Reason For Delete</label>
                    <textarea class="adress delete_reason" name="Reason" id="reason" rows="2" placeholder="Enter Reason for Delete" oninput="validate(this)"></textarea>
                    <input type="hidden" name="dis_row_id" id="dis_row_id">
                </div>
          
            <div class="modal-footer">
                <button class="btn btn-primary disdelete close_modal ss1" data-dismiss="modal" onclick="remove_text();">Cancel</button>
                <button class="btn btn-primary disdelete ss1" name="disdelete" onclick="deleteDisburse();">Submit</button>
            </div>
			</div>
			</form>
        </div><!-- /.modal-content -->
    </div>
</div>

<div id="dis_delete_modal" class="modal fade in">
    <div class="modal-dialog" style="width: 1000px;">
        <div class="modal-content">
            <a class=" close" data-dismiss="modal"><span>X</span></a>
            <div class="modal-body">
                <div id="top-msg" class="top-msg" hidden></div>
                <div class="form-group" >
                    <label for="name" id="reason_for" style="text-decoration: underline;margin-left: 39%;font-size: 19px;color: black;">Amount Deleted Disbursal List</label>
                    <div id="delete_disb_list"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary add close_modal" data-dismiss="modal">Close</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dalog -->
</div>

