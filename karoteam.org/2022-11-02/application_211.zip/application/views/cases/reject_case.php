<?php
if($active_doner){
    $doner_option ='<option value="">Select Donor</option>';
      foreach ($active_doner as $key => $value) {
        $doner_option.= '<option value = "'.$value['doner_id'].'">'.$value['name'].'</option>';
}}
// prx($result);
?>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
var doner_option = '<?php echo $doner_option;?>';
$('#active_doner').html(doner_option);
});
</script>

<div class="dash_right_section">
<h2 class="main-heading pull-left">Rejected Cases</h2>
<div class="custom-search-input pull-right">
                            <!-- <div class="input-group col-md-12">
                                <input type="text" class="  search-query form-control" placeholder="Search by Patient Name or ID" />
                                <span class="input-group-btn">
                                    <button class="btn btn-primary color-theme" type="button">
                                        <span class=" fa fa-search"></span>
                                    </button>
                                </span>
                            </div> -->
                        </div>

<div class="clearfix"></div>
<div class="dash_column family">
<!-- <input type="submit" class="btn btn-primary add" value="Export to Excel" style="margin-bottom:20px !important"> -->
<div class="tbl">
 <table id="reject_case_tbl" class="table table-striped table-bordered" width="100%">

        <thead>
            <tr>
                <th>Reg. Date</th>
                <th>Case No.</th>
                <th>Patient ID</th>
                <th>Name of Patient</th>
                <th>Case Status Reason</th>
                <th>No. of Follow Up</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if($result){
            foreach ($result as $key => $value) {?>

           <tr>
             <td><?php echo $value['registration_date'];  ?></td>
             <td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value['id'] ?>" title="Case Detail" target="_blank"><?php echo $value['case_number'];?></a></td>
             <td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value['id'] ?>" title="Case Detail" target="_blank"><?php echo $value['patient_id']; ?></a></td>
             <td><?php echo $value['patient_name'];?></td>
             <td><?php echo $value['status_reason'];?></td>
             <td><?php echo $value['no_of_followup'];?></td>
             <td><a class="btn btn-warning btn-xs" href="<?php echo base_url().'index.php/patientcase/index?cid='.$value['id']?>" title="Detail"><i class="fa fa-info-circle"></i></a>
             <button class="btn btn-success btn-xs approved" data-toggle="modal" !href="#approved"  id="approved" data-caseid="<?php echo $value['id'];?>" data-reqamt ="<?php echo $value['required_fund'];?>" title="Approve" ><i class="fa fa-check"></i></button>
<a class="btn btn-info btn-xs" href="<?php echo base_url() . 'index.php/Caseinfo/getAmountDisbursed?cid=' . $value['id'] ?>" title="Disburse"><i class="fa fa-money"></i></a>
                                    <?php
                                    $ci =& get_instance();
                                    $ci->load->model('Case_model');
                                    $data = $ci->Case_model->displayDisburselListById($value['id']);
                                    if(!empty($data)){
                                    ?>
                                    <button style="background:#f0643b;" class="btn btn-info btn-xs disb_btn"  data-toggle="modal" data-id="<?php echo $value['id']; ?>" data-type ="displaydisb" title="Display Disbursal List"><i class="fa fa-eye"></i></button>
                                    <?php 
                                    }
                                    ?>
<!--                                    <button class="btn btn-info btn-xs disb_btn"  data-toggle="modal" data-id="<?php echo $value['id']; ?>" data-type ="displaydisb" title="Display Disbursal List"><i class="fa fa-eye"></i></button>-->

             </td>
           </tr>

           <?php }}?>
        </tbody>
</table>
            </div>

<div class="clearfix"></div>
</div>


</div>



<div id="approved_modal" class="modal fade in">
        <div class="modal-dialog">
            <div class="modal-content">
                    <a class="close" data-dismiss="modal"><span>X</span></a>
                <div class="modal-body">
                <div id="top-msg1" class="top-msg" hidden></div>
<div class="form-group">
<label class="control-label"  for="username">Required Amount <span class="mandate">*</span></label>
<input type="text"  name="username" placeholder="Required Amount" class="form-control rgt rmv" id ="req_amt"readonly>
</div>
<div class="form-group">
<label class="control-label"  for="username">Donor <span class="mandate">*</span></label>
<select class="form-control rgt" name="active_doner" id="active_doner">

                </select>
               <input type="hidden" name="hidden_case_id" id="hidden_case_id">

</div>
<div class="form-group">
<label class="control-label "  for="avaliable_donner_amt">Donor Available Amount </label>
   <input class="form-control rgt" type="text" name="avaliable_donner_amt" id="avaliable_donner_amt" readonly="true">

</div>
<div class="form-group">
<label class="control-label"  for="username">Sanction Amount <span class="mandate">*</span></label>
<input type="text"  name="username" placeholder="" class="form-control rgt  allownumericwithdecimal" id ="approve_amt">
</div>

		<div class="form-group" >
             <label class="control-label"  for="sanc_date">Sanction Date <span class="mandate">*</span> </label>
             <input id="sanct_date" name="sanct_date" readonly="" type="date" class="form-control date" placeholder="Select Date" value="" >
           </div>

           <div class="clearfix"></div>
                </div>
                <div class="modal-footer">

                        <button class="btn btn btn-primary add close_modal" data-dismiss="modal">Cancel</button>
                        <button class="btn btn btn-primary add" id="approve_submit">Submit</button>

                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dalog -->
    </div>
<div id="dis_modal" class="modal fade in">
    <div class="modal-dialog">
        <div class="modal-content">
            <a class=" close" data-dismiss="modal"><span>X</span></a>
            <div class="modal-body">
                <div id="top-msg" class="top-msg" hidden></div>
                <div class="form-group" >
                    <label for="name" id="reason_for">Patient Disburse Amount Details</label>
                    <div id="disb_list"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary add close_modal" data-dismiss="modal">Close</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dalog -->
</div>
