<style type="text/css">
    #rehelp_form .error{
        color:red;
    }
    .fileList {
        padding: 0;
        list-style: none;
    }
    .fileList li {
        display: inline-block;
        padding: 15px 10px;
        box-shadow: 0px 0px 4px rgba(0,0,0,10%);
        margin-top: 10px;
        width: 100%;
        position:relative
    }
    .removeFile {
        position: absolute;
        right: 25px;
        font-size:0;
    }
    .removeFile::after {
        position: absolute;
        content: "\f00d";
        color: #666;
        font-size: 14px;
        font-family: FontAwesome;
        font-weight: normal;
    }
    .removeFile:hover::after{ color:#000}
    .filCol{box-shadow: 0px 0px 4px rgba(0,0,0,10%); padding:8px; margin-bottom:10px;}
    .filCol .first {
        font-size: 13px;
        font-weight: 400;
        color: #989da2;
        font-family: roboto;
    }
    .filCol .last{ float:right;}

    input[type="file"] {
        display: block;
    }
    .imageThumb {
        max-height: 75px;
        border: 2px solid;
        padding: 1px;
        cursor: pointer;
    }
    .pip {
        display: inline-block;
        margin: 10px 10px 0 0;
    }
    .remove {
        display: block;
        background: #f0643b;
        border: 1px solid black;
        color: white;
        text-align: center;
        cursor: pointer;
        margin-bottom:10px;
    }
    .remove:hover {
        background: #337ab7;
        color:White;
    }
    .pip {
        display: inline-block;
        margin: 10px 10px 0 0;
        width: 100%;
        border: 1px solid #ddd;
        padding: 7px;
    }
    .remove {
        display: block;
        background: #f0643b;
        /* border: 1px solid black; */
        color: white;
        text-align: center;
        cursor: pointer;
        margin-bottom: 10px;
        float: right;
        padding: 5px;
        margin-top: -24px;
        border-radius: 50%;
        height: 22px;
        line-height: 15px;
        font-weight: 600;
    }
</style>
<?php
if ($active_doner) {
    $doner_option = '<option value="">Select Donor</option>';
    foreach ($active_doner as $key => $value) {
        $doner_option.= '<option value = "' . $value['doner_id'] . '">' . $value['name'] . '</option>';
    }
}
?>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        var doner_option = '<?php echo $doner_option; ?>';
        $('#active_doner').html(doner_option);
    });
</script>
<?php
$cid = $case_id;
$patient_id = $result[0]->patient_id;
?>
<?php
//$attributes = array('class' => 'rehelp_form', 'id' => 'rehelp_form');
//echo form_open("Caseinfo/saveRehelpDetails?cid=$cid&patient_id=$patient_id", $attributes);
?>

<div class="dash_right_section">
    <h2 class="main-heading">Rehelp</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle green"><img src="<?php echo base_url('karoclient/images/patient-id.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Patient Id </h3>
                    <p><?php echo $result[0]->patient_id; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink"><img src="<?php echo base_url('karoclient/images/patient-name.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Patient Name</h3>
                    <p><?php echo $result[0]->patient_name; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle blue"><img src="<?php echo base_url('karoclient/images/mobile.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Mobile No.</h3>
                    <p><?php echo $result[0]->patient_phone; ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <form class='rehelp_form' id='rehelp_form' action="<?php echo base_url(); ?>index.php/Caseinfo/saveRehelpDetails?cid=<?php echo $cid; ?>&patient_id=<?php echo $patient_id; ?>" method="post">
        <div class="dash_column">
            <?php echo $this->session->flashdata('message'); ?>
            <div id="top-msg1" hidden></div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="name">Date</label>
                    <input id="rehelp_date" name="rehelp_date" readonly="" type="date" class="form-control date defaultdater" placeholder="Select Date" value="<?php echo date('Y-m-d'); ?>" readOnly>
                </div>
                <div class="form-group">
                    <label for="name">Requested amount <span class="mandate">*</span> </label>
                    <input id="rehelp_req_amt" name="rehelp_req_amt" type="text" class="form-control allownumericwithdecimal" placeholder="Enter requested amount" maxlength="12">
                </div>
            </div>
            <div class="form-group col-md-6">
                <label for="name">Prescribed Treatment <span class="mandate">*</span></label>
                <textarea class="form-control text-add" value="" placeholder="Prescribed Treatment" name="rehelp_treatment" id="rehelp_treatment"></textarea>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group col-md-6" >
                        <label for="name">Donor <span class="mandate">*</span></label>
                        <select class="form-control rgt" name="active_doner" id="active_doner">

                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="name">Approved amount <span class="mandate">*</span></label>
                        <input id="rehelp_approve_amt" name="rehelp_approve_amt" type="text" class="form-control allownumericwithdecimal" placeholder="Enter approved amount" maxlength="12">
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group col-md-6">
                                <label for="name">Donor Available Amount </label>
                                <input id="avaliable_donner_amt" name="avaliable_donner_amt" type="text" class="form-control allownumericwithdecimal" readonly>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" id="file_urls" name="file_urls" value='<?php echo!empty($documents) ? $documents['file_urls'] : "" ?>'>
            <div class="form-group col-md-6 files" id="files1">
                <h3 class="sub-haeding">Upload Documents</h3>
                <div id="top-msg" class="top-msg" hidden></div>  
                <input type="file" name="files1" id ="fUpload"multiple="" class="form-control file">
                <br>
                <span id="successMsg" style="color: green;"></span>
                <input type="button" id="uploadBtn" value="Upload Files" class="btn btn-primary add" style="float:right;">
                <ul class="fileList"></ul>

            </div>
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12">
                    <input type="hidden" value="rehelp" id="page_name"/>
                    <input type="hidden" value="" id="file_count" name="file_count"/>
                    <button type="submit" name="save" value="add" class="btn btn-primary save">Submit</button>
                </div>
            </div>
        </div>
    </form>

    <div class="dash_column">
        <div class="tbl">
            <p style="text-align:center;color:green"><?php echo $this->session->flashdata('msg1'); ?></p>
            <table class="table table-striped table-bordered" width="100%" id="rehelplist">
                <thead>
                    <tr>
                        <th>Donor Name</th>
                        <th>Required Amount(Rs.)</th>
                        <th>Approved Amount(Rs.)</th>
                        <th>Approval Date</th>
                        <th>Action</th>   
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rehelp_data as $rehelp) { ?>
                        <tr id="">
                            <td>
                                <?php
                                $CI = &get_instance();
                                $CI->load->model('case_model', 'cm');
                                $getDonorDetails = $CI->cm->getDonorDetailsById($rehelp->doner_id);
                                echo $getDonorDetails[0]->FirstName;
                                ?>
                            </td>
                            <td><?php echo $rehelp->required_fund; ?></td>
                            <td><?php echo $rehelp->approved_amount; ?></td>
                            <td><?php echo (empty($rehelp->rehelp_date)) ? $rehelp->created_at : $rehelp->rehelp_date; ?></td>
                            <td>
                                <a style="background:#f0643b;" class="btn btn-info btn-xs rehelp_btn"  data-toggle="modal" data-id="<?php echo $rehelp->id; ?>" data-type ="displaydisb" title="Display List" onclick="set_val(<?php echo $rehelp->id; ?>);"><i class="fa fa-eye"></i></a>
                                <?php if ($isAdmin = $this->session->userdata('IsAdmin')) { ?>
                                    <a href="<?php echo base_url(); ?>index.php/caseinfo/editrehelp/?patient_id=<?php echo $_GET["patient_id"]; ?>&rid=<?php echo $rehelp->id; ?>&cid=<?php echo $cid; ?>" style="" class="btn btn-info btn-xs" title="Edit"><i class="fa fa-edit btn-success"></i></a>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>     

</div>

<div id="rehelpdis_modal" class="modal fade in">
    <div class="modal-dialog" style="width: 1000px;">
        <div class="modal-content">
            <a class=" close" id="cross" data-dismiss="modal"><span>X</span></a>
            <div class="modal-body">
                <div id="top-msg" class="top-msg" hidden></div>
                <div class="form-group" >
                    <label for="name" id="reason_for" style="text-decoration: underline;margin-left: 39%;font-size: 19px;color: black;">Rehelp Uploaded Documents</label>
                    <div id="disb_list"></div>
                </div>

                <form action="<?php echo base_url(); ?>index.php/caseinfo/uploaddocs" method="post" enctype="multipart/form-data">
                    <div class="field" align="left">
                        <h4>Upload Documents</h4>
                        <input type="file" id="uploadfiles" name="uploadfiles[]" multiple required/>
                        <br/>
                        <input type="hidden" name="cid" value="<?php echo $cid; ?>"/>
                        <input type="hidden" name="pid" value="<?php echo $patient_id; ?>"/>
                        <input type="hidden" name="rid" id="rehelpid" value=""/>
                        <input type="hidden" name="file_names" id="file_names" value=""/>
                    </div>
                    <div style="position: static;display: flow-root;padding-top: 15px;">
                        <button class="btn btn-primary add close_modal " type="submit" data-dismiss="modal" id="close"  style="float:right">Close</button>
                        <button type="submit" name="edit" value="edit" class="btn btn-primary add edit"  style="float:right">Submit</button>

                    </div>
                </form>

            </div>
            <!--<div class="modal-footer">
                
            </div>-->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dalog -->
</div>

<script type="text/javascript">

    function set_val(id) {
        alert(id);
        $("#rehelpid").val(id);
    }

    $(document).ready(function () {
        $('#fUpload').change(function () {
            var fp = $("#fUpload");
            var lg = fp[0].files.length; // get length
            var items = fp[0].files;
            var fileSize = 0;

            if (lg > 0) {
                for (var i = 0; i < lg; i++) {
                    // fileSize = fileSize+items[i].size; // get file size
                    fileSize = items[i].size; // get file size

                }
                if (fileSize > 5242880) { //file size is in bytes
                    $('#fUpload').val('');
                    $('#top-msg').addClass('alert alert-danger').text('File size must not be more than 5 MB');
                    $('#top-msg').show();
                    setTimeout(function () {
                        $('#top-msg').hide();

                    }, 2000);

                }
            }
        });
    });
    
    var primates = new Array();

    $(document).ready(function () {
        if (window.File && window.FileList && window.FileReader) {
            $("#uploadfiles").on("change", function (e) {
                var fi = document.getElementById('uploadfiles');
                //var files = e.target.files, filesLength = files.length;
                for (var i = 0; i <= fi.files.length - 1; i++) {
                    var fname = fi.files.item(i).name;      // THE NAME OF THE FILE.
                    var fsize = fi.files.item(i).size;
                    //var f = files[i];
                    $("<span class=\"pip\" id="+fname+">" +
                            fname + " - " + fsize +
                            "Bytes<br/><span class=\"remove\">X</span>" +
                            "</span>").insertAfter("#uploadfiles");
                    $(".remove").click(function () {
                        var val=$(this).parent(".pip").attr('id');
                        primates.push(val);
                        $(this).parent(".pip").remove();
                        $("#file_names").val(primates);
						$("#uploadfiles").val('');
                    });
//                    var fileReader = new FileReader();
//                    fileReader.onload = (function (e) {
//                         var file = e.target;
//
////                        $("<span class=\"pip\">" +
//                                "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + f.name + "\"/>" +
//                                "<br/><span class=\"remove\">Remove image</span>" +
////                                "</span>").insertAfter("#uploadfiles");
////                        $(".remove").click(function () {
////                            $(this).parent(".pip").remove();
////                        });
//
//                        
//
//                    });
//                    fileReader.readAsDataURL(f);
                }
                
            });
        } else {
            alert("Your browser doesn't support to File API")
        }
    });
	
		         function clearInput () {

    $("#uploadfiles").val('');
    $('#rehelpdis_modal').modal('hide');

};

$("#close").on("click",function(){
    clearInput()
});

$("#cross").on("click",function(){
    clearInput()
});

$("body").on("click","#file_modal",function(){
        clearInput();
   });
</script>
