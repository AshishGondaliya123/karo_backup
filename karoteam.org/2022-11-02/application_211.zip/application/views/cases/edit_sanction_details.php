<style type="text/css">
    #rehelp_form .error{
        color:red;
    }
    .fileList {
        padding: 0;
        list-style: none;
    }
    .fileList li {
        display: inline-block;
        padding: 15px 10px;
        box-shadow: 0px 0px 4px rgba(0,0,0,10%);
        margin-top: 10px;
        width: 100%;
        position:relative
    }
    .removeFile {
        position: absolute;
        right: 25px;
        font-size:0;
    }
    .removeFile::after {
        position: absolute;
        content: "\f00d";
        color: #666;
        font-size: 14px;
        font-family: FontAwesome;
        font-weight: normal;
    }
    .removeFile:hover::after{ color:#000}
    .filCol{box-shadow: 0px 0px 4px rgba(0,0,0,10%); padding:8px; margin-bottom:10px;}
    .filCol .first {
        font-size: 13px;
        font-weight: 400;
        color: #989da2;
        font-family: roboto;
    }
    .filCol .last{ float:right;}

    input[type="file"] {
        display: block;
    }
    .imageThumb {
        max-height: 75px;
        border: 2px solid;
        padding: 1px;
        cursor: pointer;
    }
    .pip {
        display: inline-block;
        margin: 10px 10px 0 0;
    }
    .remove {
        display: block;
        background: #f0643b;
        border: 1px solid black;
        color: white;
        text-align: center;
        cursor: pointer;
        margin-bottom:10px;
    }
    .remove:hover {
        background: #337ab7;
        color:White;
    }
    .pip {
        display: inline-block;
        margin: 10px 10px 0 0;
        width: 100%;
        border: 1px solid #ddd;
        padding: 7px;
    }
    .remove {
        display: block;
        background: #f0643b;
        /* border: 1px solid black; */
        color: white;
        text-align: center;
        cursor: pointer;
        margin-bottom: 10px;
        float: right;
        padding: 5px;
        margin-top: -24px;
        border-radius: 50%;
        height: 22px;
        line-height: 15px;
        font-weight: 600;
    }
</style>
<?php
if ($active_doner) {
    $doner_option = '<option value="">Select Donor</option>';
    foreach ($active_doner as $key => $value) {
        $doner_option.= '<option value = "' . $value['doner_id'] . '" >' . $value['name'] . '</option>';
    }
}
?>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        var doner_option = '<?php echo $doner_option; ?>';
        $('#active_doner').html(doner_option);
    });
</script>
<?php
$cid = $case_id;
$patient_id = $result[0]->patient_id;
?>
<?php
//$attributes = array('class' => 'rehelp_form', 'id' => 'rehelp_form');
//echo form_open("Caseinfo/saveRehelpDetails?cid=$cid&patient_id=$patient_id", $attributes);
?>

<div class="dash_right_section">
    <h2 class="main-heading">Patient Sanction Details</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle green"><img src="<?php echo base_url('karoclient/images/patient-id.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Patient Id </h3>
                    <p><?php echo $result[0]->patient_id; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink"><img src="<?php echo base_url('karoclient/images/patient-name.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Patient Name</h3>
                    <p><?php echo $result[0]->patient_name; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle blue"><img src="<?php echo base_url('karoclient/images/mobile.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Mobile No.</h3>
                    <p><?php echo $result[0]->patient_phone; ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    	                    <p><a class="btn btn-primary" href="<?php echo base_url() . 'index.php/Caseinfo/getAmountDisbursed?cid=' . $case_id ?>" title="Case Detail" >Go to Disbursed page</a></p>


    <div class="dash_column">

        <div class="tbl">
            <p style="text-align:center;color:green"><?php echo $this->session->flashdata('msg1'); ?></p>
            <table class="table table-striped table-bordered" width="100%" id="rehelplist">
                <thead>
                    <tr>
                        <th>Donor Name</th>
                        <th>Required Amount(Rs.)</th>
                        <th>Approved Amount(Rs.)</th>
                        <th>Approval Date</th>
                        <th>Action</th>   
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rehelp_data as $rehelp) { ?>
                        <tr id="">
                            <td>
                                <?php
                                $CI = &get_instance();
                                $CI->load->model('case_model', 'cm');
                                $getDonorDetails = $CI->cm->getDonorDetailsById($rehelp->doner_id);
                                echo $getDonorDetails[0]->FirstName;
                                ?>
                            </td>
                            <td><?php echo $rehelp->required_fund; ?></td>
                            <td><?php echo $rehelp->approved_amount; ?></td>
                            <td><?php echo (empty($rehelp->rehelp_date)) ? $rehelp->created_at : $rehelp->rehelp_date; ?></td>
                            <td>
                                <?php if ($isAdmin = $this->session->userdata('IsAdmin')) { ?>
                                    <a  class="btn btn-info btn-xs sanction_edit" id="" style="outline:none;" onclick='openEditModel(<?php echo json_encode($rehelp); ?>)' tabindex="-1" data-type ="displayPhn" data-target="#dis_modal"><i class="fa fa-edit btn-success"></i></a>
                                
								<?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>     

</div>

<div id="dis_modal" class="modal fade in">
        <div class="modal-dialog">
            <div class="modal-content">
                <a class="close" data-dismiss="modal"><span>X</span></a>
                <div class="modal-body">
                    <div id="top-msg1" class="top-msg"></div>
                    
                    <div class="form-group">
                        <label class="control-label"  for="username">Donor <span class="mandate">*</span></label>
                        <select class="form-control rgt" name="active_doner" id="active_doner">

                        </select>
                        <input type="hidden" name="hidden_case_id" id="hidden_case_id">
						<input type="hidden" name="hidden_app_id" id="hidden_app_id">

                    </div>
                    <div class="form-group">
                        <label class="control-label "  for="avaliable_donner_amt">Donor Available Amount </label>
                        <input class="form-control rgt" type="text" name="avaliable_donner_amt" id="avaliable_donner_amt" readonly="true">

                    </div>
                    <div class="form-group">
                        <label class="control-label"  for="username">Sanction Amount <span class="mandate">*</span> </label>
                        <input type="text"  name="approve_amt" placeholder="" class="form-control rgt  allownumericwithdecimal" id ="approve_amt" >
                    </div>
					
					<div class="form-group" >
             <label class="control-label"  for="sanc_date">Sanction Date <span class="mandate">*</span> </label>
             <input id="sanct_date" name="sanct_date" readonly="" type="date" class="form-control date" placeholder="Select Date" >
           </div>

                    <div class="clearfix"></div>
                </div>
                <div class="modal-footer">

                    <button class="btn btn-primary add close_modal" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary add close_modal" id="approve_edit">Submit</button>

                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dalog -->
    </div>



<script type="text/javascript">

    function set_val(id) {
        alert(id);
        $("#rehelpid").val(id);
    }

    $(document).ready(function () {
        $('#fUpload').change(function () {
            var fp = $("#fUpload");
            var lg = fp[0].files.length; // get length
            var items = fp[0].files;
            var fileSize = 0;

            if (lg > 0) {
                for (var i = 0; i < lg; i++) {
                    // fileSize = fileSize+items[i].size; // get file size
                    fileSize = items[i].size; // get file size

                }
                if (fileSize > 5242880) { //file size is in bytes
                    $('#fUpload').val('');
                    $('#top-msg').addClass('alert alert-danger').text('File size must not be more than 5 MB');
                    $('#top-msg').show();
                    setTimeout(function () {
                        $('#top-msg').hide();

                    }, 2000);

                }
            }
        });
    });
    
    var primates = new Array();

    $(document).ready(function () {
        if (window.File && window.FileList && window.FileReader) {
            $("#uploadfiles").on("change", function (e) {
                var fi = document.getElementById('uploadfiles');
                //var files = e.target.files, filesLength = files.length;
                for (var i = 0; i <= fi.files.length - 1; i++) {
                    var fname = fi.files.item(i).name;      // THE NAME OF THE FILE.
                    var fsize = fi.files.item(i).size;
                    //var f = files[i];
                    $("<span class=\"pip\" id="+fname+">" +
                            fname + " - " + fsize +
                            "Bytes<br/><span class=\"remove\">X</span>" +
                            "</span>").insertAfter("#uploadfiles");
                    $(".remove").click(function () {
                        var val=$(this).parent(".pip").attr('id');
                        primates.push(val);
                        $(this).parent(".pip").remove();
                        $("#file_names").val(primates);
						$("#uploadfiles").val('');
                    });
//                    var fileReader = new FileReader();
//                    fileReader.onload = (function (e) {
//                         var file = e.target;
//
////                        $("<span class=\"pip\">" +
//                                "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + f.name + "\"/>" +
//                                "<br/><span class=\"remove\">Remove image</span>" +
////                                "</span>").insertAfter("#uploadfiles");
////                        $(".remove").click(function () {
////                            $(this).parent(".pip").remove();
////                        });
//
//                        
//
//                    });
//                    fileReader.readAsDataURL(f);
                }
                
            });
        } else {
            alert("Your browser doesn't support to File API")
        }
    });
	
		         function clearInput () {

    $("#uploadfiles").val('');
    $('#rehelpdis_modal').modal('hide');

};

$("#close").on("click",function(){
    clearInput()
});

$("#cross").on("click",function(){
    clearInput()
});

$("body").on("click","#file_modal",function(){
        clearInput();
   });
</script>
