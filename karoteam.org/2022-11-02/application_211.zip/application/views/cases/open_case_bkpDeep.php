<style>
    th{
        text-align: center;
    }
    td{
        text-align: center;
    }
</style>
<div class="dash_right_section">
    <h2 class="main-heading pull-left">Open Cases</h2>
    <div class="custom-search-input pull-right">
        <!-- <div class="input-group col-md-12">
            <input type="text" class="  search-query form-control" placeholder="Search by Patient Name or ID" />
            <span class="input-group-btn">
                <button class="btn btn-primary color-theme" type="button">
                    <span class=" fa fa-search"></span>
                </button>
            </span>
        </div> -->
    </div>

    <div class="clearfix"></div>
    <div class="dash_column family">
    <!-- <input type="submit" class="btn btn-primary add" value="Export to Excel" style="margin-bottom:20px !important"> -->
        <div class="tbl">
            <table id="open_case_tbl" class="table table-striped table-bordered" width="100%">

                <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>Reg. Date</th>
                        <th>Patient Name</th>
                        <th>Dept.</th>
                        <th>Hospital</th>
                        <th>Amount Sanctioned</th>
                        <th>Amount Disbursed</th>
                        <th>Next Followup</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result) {
                        foreach ($result as $key => $value) {
                            ?>
                            <tr>
                                <td><?php echo $value['patient_id']; ?></td>
                                <td><?php echo $value['registration_date']; ?></td>
                                <td><?php echo $value['patient_name']; ?></td>
                                <td><?php echo $value['DeptName']; ?></td>
                                <td><?php echo $value['HospitalName']; ?></td>
                                <td><?php echo $value['approved_amount']; ?></td>
                                <td><?php if ($value['DisbursedAmt'])
                        echo $value['DisbursedAmt'];
                    else
                        echo 0;
                    ?></td>
                                <td><?php echo $value['next_followup_date']; ?></td>

                                <td style="width:80px;"> <a class="btn btn-warning btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value['id'] ?>" title="Detail"><i class="fa fa-info-circle"></i></a>
                                    <a class="btn btn-info btn-xs" href="<?php echo base_url() . 'index.php/Caseinfo/getAmountDisbursed?cid=' . $value['id'] ?>" title="Disburse"><i class="fa fa-money"></i></a>
                                    <?php
                                    $ci =& get_instance();
                                    $ci->load->model('Case_model');
                                    $data = $ci->Case_model->displayDisburselListById($value['id']);
                                    if(!empty($data)){
                                    ?>
                                    <button style="background:#f0643b;" class="btn btn-info btn-xs disb_btn"  data-toggle="modal" data-id="<?php echo $value['id']; ?>" data-type ="displaydisb" title="Display Disbursal List"><i class="fa fa-eye"></i></button>
                                    <?php 
                                    }
                                    ?>
                                </td>
                            </tr>

    <?php }
}
?>

                </tbody>
            </table>
        </div>

        <div class="clearfix"></div>
    </div>


</div>
<div id="dis_modal" class="modal fade in">
    <div class="modal-dialog" style="width: 1000px;">
            <div class="modal-content">
                <a class=" close" data-dismiss="modal"><span>X</span></a>
                <div class="modal-body">
                    <div id="top-msg" class="top-msg" hidden></div>
                    <div class="form-group" >
                    <label for="name" id="reason_for" style="text-decoration: underline;margin-left: 39%;font-size: 19px;color: black;">Patient Disburse Amount Details</label>
                        <div id="disb_list"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary add close_modal" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dalog -->
    </div>