<?php

class Patient_model extends CI_Model {

    function getPatient($id = 0) {
        $role = $this->session->userdata("IsAdmin");
        if ($id) {
            $query = $this->db->get_where('patient_master', array('id' => $id));
            if ($query->num_rows() > 0) {
                return $query->result_array();
            }
        } else {
            // $query = $this->db->get_where('patient_master', array('1' => 1));
            // if ($query->num_rows() > 0) {
            //     return $query->result_array();
            // }

            if ($role == 1) {
                $this->db->select('pm.* ,DATE_FORMAT(pm.registration_date,"%d/%m/%Y") AS reg_date,pcd.hospital_name as hospital_id ,hm.HospitalName');
                $this->db->from('patient_case_details pcd');
                $this->db->join('patient_master pm ', 'pm.patient_id = pcd.patient_id', 'left');
                $this->db->join('hospitalmaster hm', 'hm.HospitalId = pcd.hospital_name', 'left');
                $query = $this->db->get();
                $result = $query->result_array();
            } else {
                $user_id = $this->session->userdata('UsertId');
                $query = "SELECT pm.*,DATE_FORMAT(pm.registration_date,'%d/%m/%Y') AS reg_date, pcd.hospital_name as hospital_id, hm.HospitalName FROM patient_case_details pcd "
                        . "LEFT JOIN patient_master pm ON pm.patient_id = pcd.patient_id "
                        . "LEFT JOIN hospitalmaster hm ON hm.HospitalId = pcd.hospital_name "
                        . "where pm.created_by = $user_id";
                $query = $this->db->query($query);
                $result = $query->result_array();
            }
            return $result;
        }
    }

    function getPatientById($patient_id) {
        $query = $this->db->get_where('patient_master', array('patient_id' => $patient_id));
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    function getPatientFamily($id) {
        $query = $this->db->get_where('patient_family_details', array('patient_id' => $id));
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    function savePatient($patientData, $id = 0) {
        if ($id) {
            $patientData["updated_by"] = $this->session->userdata('UsertId');
            $this->db->where('id', $id);
            $str1 = $this->db->update('patient_master', $patientData);
            $patient_id = $id;
        } else {
            $patientData['created_by'] = $this->session->get_userdata('UsertId')['UsertId'];
            $patientData["created_at"] = date("Y-m-d H:i:s");
            $str1 = $this->db->insert('patient_master', $patientData);
            //opening a new case of patient
            $patient_id = $this->db->insert_id();
            $casedata["patient_id"] = $patientData["patient_id"];
            $casedata["case_number"] = $patientData["patient_case"];
            $casedata['created_by'] = $this->session->userdata('UsertId');
            $str1 = $this->db->insert('patient_case_details', $casedata);
        }
        return $patient_id;
    }


    function getTableData($params)
    {
        $this->db->select($params['select']);
        if($params['where'])
        $this->db->where($params['where']);

        $query = $this->db->get($params['table']); 
                $result =  $query->result();
                return $result;

    }

    function insertDataIntoTable($table,$insert_data)
    {
        return $this->db->insert($table,$insert_data);
    }

    function updateDataIntoTable($table,$update_data,$where_data)
    {
        $this->db->where($where_data);
        // echo $this->db->last_query();exit;
        
        return $this->db->update($table, $update_data);
    }

}

?>