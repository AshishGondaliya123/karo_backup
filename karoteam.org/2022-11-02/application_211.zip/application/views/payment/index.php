
<div class="dash_right_section">
<div><?php echo $this->session->flashdata('message');?></div>
    <h2 class="main-heading">Payment</h2>
  <?php if(isset($_REQUEST['act'])){?>
     <?php if($_REQUEST['act']=='update'){?>
    <?php echo form_open('payment/changepaymentName');?>
        <div class="dash_column">
            <div class="diseases">
                
                <div class="form-group">
                    <label for="name">Payment Mode</label>
					 <span class="mandate">*</span>
                    <?php $values = explode("_", base64_decode($_REQUEST['id']));?>
                    <input id="payment_id" name="payment_id" value="<?php echo base64_encode($values[0]); ?>" type="hidden" class="form-control specialchr">
                    <input id="PaymentMode" name="PaymentMode" type="text" class="form-control specialchr" value = "<?php echo $values[1]; ?>" maxlength="100" placeholder="Enter disease name" onkeypress ="removeValidation();">
                    <span id="errormsg" style="color:red"></span>
                </div>
                <input type="submit" name="save" class="btn btn-primary save" value="Save" onclick="return checkfield('PaymentMode');">
                <div class="clearfix"></div>
                
            </div>
        </div>
    </form>
     <?php } }else{ ?>
    <?php echo form_open('payment/index');?>
        <div class="dash_column">
            <div class="payment">
                
                <div class="form-group">
                    <label for="name">Payment Mode</label>
					<span class="mandate">*</span>
                    <input id="PaymentMode" name="PaymentMode" type="text" class="form-control specialchr" maxlength="100" placeholder="Enter Payment Mode" onkeypress ="removeValidation();">
                    <span id="errormsg" style="color:red"></span>
                </div>
                <input type="submit" name="save" class="btn btn-primary save" value="Save" onclick="return checkfield('PaymentMode');">
                <div class="clearfix"></div>
                <div><?php //echo $this->session->flashdata('message');?></div>
            </div>
        </div>
    </form>
  <?php } ?>
    <div class="dash_column">
        <div class="tbl">
            <table id="disease" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Payment Mode</th>  
                          <th>Status</th>         
                        <th>Actions</th>
                       
                    </tr>
                </thead>
                <?php if (!empty($payment)) {
                    foreach ($payment as $pay) {
                        ?>
                        <tr>
                            <td><?php echo $pay['PaymentMode']; ?></td>
							<td> <?php
                                    if ($pay['IsActive'] == '1') {
                                        echo "Active";
                                    } else {
                                        echo "Inactive";
                                    }
                                    ?></td>
                            <td><a class='btn btn-info btn-xs' href="?act=update&id=<?php echo base64_encode($pay['PaymentId']."_".$pay['PaymentMode']); ?>" title="Edit"><i class="fa fa-edit"></i></a>
                            <a href="javascript:void(0);" data-url="<?php echo site_url(); ?>/payment/changestatus?status=<?php echo $pay['IsActive']; ?>&id=<?php echo base64_encode($pay['PaymentId']); ?>" title="<?php
                                    if ($pay['IsActive'] == '1') {
                                        echo "click here to inactive";
                                    } else {
                                         echo "click here to active";
                                    }
                                    ?>" class="btn btn-<?php if ($pay['IsActive'] == '0') {
                                echo "primary";
                            } else {
                                echo "danger";
                            } ?> btn-xs" onclick="changeStatusDynamically($(this),'Are you sure you want to <?php if ($pay['IsActive'] == '1') {echo "Inactive";} else { echo "Active"; } ?> this payment mode ?');">
                                    <?php
                            if ($referred['IsActive'] == '1') {
                                //echo "Deactivate";?>
                                <i class="fa fa-toggle-off"></i>
                                  <?php } else {
                                //echo "Activate";?>
                                <i class="fa fa-toggle-on"></i>
                           <?php }
                                    ?>
                                </a></td>
                        </tr>
    <?php }
} ?>   


            </table>
        </div>
    </div>
</div>