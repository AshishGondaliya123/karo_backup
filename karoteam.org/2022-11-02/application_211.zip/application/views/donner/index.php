<style>
    label.error{
        color:red;
    }
    span.error{
        color:red;
    }
    .mandate{
        color:red;
    }
    .tbl .table.donor_table td:first-child {
    word-break: break-all;
    width: 325px !important;
}   
</style>
<div class="dash_right_section">
    <h2 class="main-heading">Donor</h2>
    <?php if (isset($_REQUEST['act'])) { ?>
        <?php if ($_REQUEST['act'] == 'update') { ?>
            <?php
            $attributes = array('class' => 'donner', 'id' => 'donner');
            echo form_open('donner/updatedonner', $attributes);
            ?>
   <div class="dash_column">
        <div><?php echo $this->session->flashdata('message'); ?></div>

                <div class="row">
        <div class="form-group col-md-4">
        <label for="name">Donor Type <span class="mandate">*</span></label>
        <div style="margin-top:0px;">
        <label class="customradio col-md-6" style="margin-top:10px;"><span class="radiotextsty">Individual</span>
        <input type="radio" name="dtype" class="donner-type" value="Individual" <?php echo ($DonnerByID['0']['DonerType']=='Individual')?"checked=checked":''; ?> >
        <span class="checkmark"></span>
        </label>
        <label class="customradio col-md-6" style="margin-top:10px;"><span class="radiotextsty">Organization</span>
        <input type="radio" name="dtype" class="donner-type" value="Organisation" <?php echo ($DonnerByID['0']['DonerType']=='Organisation')?"checked=checked":''; ?> >
        <span class="checkmark"></span>
        </label>

        <label id="dtype-error" class="error" for="dtype"></label>

        </div>

        </div>
        <div class="form-group col-md-8">
        <input type="text" id="OrganizationName" name="OrganizationName" class="form-control" style="margin-top:15px;<?php echo ($DonnerByID['0']['DonerType']=='Individual')?"display: none":''; ?>"placeholder="Enter Organization" value="<?php echo $DonnerByID[0]['OrganizationName']? $DonnerByID[0]['OrganizationName'] :'';?>" >
        </div>
        </div>
       
        <div class="row">
            <input id="DonerId" name="DonerId" value="<?php echo base64_encode($DonnerByID['0']['DonerId']); ?>" type="hidden" class="form-control specialchr">
            <div class="form-group col-md-4">
                <label for="name">First Name<span class="mandate">*</span></label>
                <input id="first_name" name="first_name" type="text" class="form-control" placeholder="Enter first name" value="<?php echo $DonnerByID['0']['FirstName']; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Middle Name</label>
                <input id="middle_name" name="middle_name" type="text" class="form-control" placeholder="Enter middle name" value="<?php echo $DonnerByID['0']['MiddleName']; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Last Name</label>
                <input id="last_name" name="last_name" type="text" class="form-control" placeholder="Enter last name" value="<?php echo $DonnerByID['0']['LastName']; ?>">
            </div>
        </div>
        <div class="row">
           <div class="form-group col-md-4">
                <label for="name">Mobile No </label>
                <input id="mobile_no" name="mobile_no" type="text" class="form-control" placeholder="Enter Mobile No" value="<?php echo $DonnerByID['0']['MobileNO']? $DonnerByID['0']['MobileNO'] :'';?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Address<span class="mandate">*</span></label>
                <textarea class="form-control" name="address" id="address" rows="3"><?php echo $DonnerByID['0']['DonerAddress'];?></textarea>
            </div>
            <div class="form-group col-md-4">
               <label for="name">Country<span class="mandate">*</span></label>
               <select name="country" id="country" class="form-control" onchange="checkcountry(this.value);">
                <option value="">--Select Country--</option>
                <?php foreach ($countries as $country) { ?>
                        <option value="<?php echo $country['country_name']; ?>" <?php if ($DonnerByID['0']['Country'] == $country['country_name']) {
                        echo "selected='selected'"; } ?>><?php echo $country['country_name']; ?></option>
                <?php } ?>
                </select>
            </div>
            
             
        </div>
        <div class="row">
           <div class="form-group col-md-4">
                <label for="name">State<span class="mandate">*</span></label>
                <span class="notforindia" style="<?php if($DonnerByID['0']['Country']=='India'){ echo "display:none;";}else{ echo "display:block";} ?>">
                    <input type="text" id="state" name="otherstate" class="form-control" placeholder="Enter State" value="<?php echo $DonnerByID['0']['State'];?>">
                </span>
                <span class="forindia" style="<?php if($DonnerByID['0']['Country']=='India'){ echo "display:block;";}else{ echo "display:none";} ?>">
                <select id="state" name="state"  class="form-control" onchange="getcities(this.value, 'city');">
                    <option value=""> Select State</option>
                     <?php foreach ($states as $state) { ?>
                        <option value="<?php echo $state['city_state']; ?>" <?php if ($DonnerByID['0']['State'] == $state['city_state']) {
                        echo "selected='selected'"; } ?>><?php echo $state['city_state']; ?></option>
                    <?php } ?>
                </select>
                </span>
            </div>
            <div class="form-group col-md-4">
                <label for="name">City<span class="mandate">*</span></label>
                <span class="notforindia" style="<?php if($DonnerByID['0']['Country']=='India'){ echo "display:none;";}else{ echo "display:block";} ?>">
                    <input type="text" id="citytext" name="othercity" class="form-control" placeholder="Enter City" value="<?php echo $DonnerByID['0']['City'];?>">
                </span>
                <span class="forindia" style="<?php if($DonnerByID['0']['Country']=='India'){ echo "display:block;";}else{ echo "display:none";} ?>">
                    <select class="form-control" name="city" id="city">
                        <option value="">--Select City--</option>
                     <option value=""> Select City</option>  
                            <?php
                            if (!empty($cities)) {
                                foreach ($cities as $city) {
                                    if ($city['city_name'] == $DonnerByID['0']['City']) {
                                        $selected = "selected='selected'";
                                    } else {
                                        $selected = '';
                                    }
                                    echo "<option value='" . $city['city_name'] . "' " . $selected . ">" . $city['city_name'] . "</option>";
                                }
                            }
                                ?>
                    </select>
                </span>
            </div>
            <div class="form-group col-md-4">
                <label for="name">Pin Code<span class="mandate">*</span></label>
                <input type="text" id="zipcode" name="zipcode" class="form-control" placeholder="Enter pin code"  value="<?php echo $DonnerByID['0']['ZipCode'];?>">
            </div>
             
        </div>
       
        <div class="row">
        <div class="form-group col-md-4">
                <label for="name">Contact No<span class="mandate">*</span></label>
                <input type="text" id="primary_contact" name="primary_contact" class="form-control" placeholder="Enter primary contact" value="<?php echo $DonnerByID['0']['ContactNo'];?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Email Id<span class="mandate">*</span></label>
                <input type="text" id="emailid" name="emailid" class="form-control" placeholder="Enter Email" value="<?php echo $DonnerByID['0']['EmailId'];?>" onblur="checkDonoremail(this.value,'donor_email_error','<?php echo $DonnerByID['0']['DonerId'];?>');" >
                <span id="donor_email_error" class="error"></span>
            </div>
            <div class="form-group col-md-4">
                <label for="name">PAN Card</label>
                <input type="text" id="pan_card" name="pan_card" class="form-control" placeholder="Enter PAN Card" value="<?php echo $DonnerByID['0']['PANCardNumber'];?>">
            </div>
        </div>

        <div class="row">
            
            <div class="col-md-12">
                <button type="submit" name="save" value="save" class="btn btn-primary save">Save</button>
            </div>
        </div>
    </div>
    <?php
    }
    }else{
   
    $attributes = array('class' => 'donner', 'id' => 'donner');
    echo form_open_multipart('donner/index', $attributes);
    ?>
    <div class="dash_column">
        <div><?php echo $this->session->flashdata('message'); ?></div>
               <div class="row">
        <div class="form-group col-md-4">
        <label for="name">Donor Type <span class="mandate">*</span></label>
        <div style="margin-top:0px;">
        <label class="customradio col-md-6" style="margin-top:10px;"><span class="radiotextsty">Individual</span>
        <input type="radio" name="dtype" value="Individual" class="donner-type" checked="">
        <span class="checkmark"></span>
        </label>
        <label class="customradio col-md-6" style="margin-top:10px;"><span class="radiotextsty">Organization</span>
        <input type="radio" name="dtype" value="Organisation" class="donner-type">
        <span class="checkmark"></span>
        </label>

        <label id="dtype-error" class="error" for="dtype"></label>

        </div>

        </div>
        <div class="form-group col-md-8">
        <input  type="text" id="OrganizationName" name="OrganizationName" class="form-control" style="margin-top:15px; display: none;" placeholder="Enter Organization" value="" >
        </div>
        </div>

        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">First Name<span class="mandate">*</span></label>
                <input id="first_name" name="first_name" type="text" class="form-control" placeholder="Enter first name">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Middle Name</label>
                <input id="middle_name" name="middle_name" type="text" class="form-control" placeholder="Enter middle name">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Last Name</label>
                <input id="last_name" name="last_name" type="text" class="form-control" placeholder="Enter last name">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">Mobile No </label>
                <input id="mobile_no" name="mobile_no" type="text" class="form-control" placeholder="Enter Mobile No">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Address<span class="mandate">*</span></label>
                <textarea class="form-control" name="address" id="address" rows="3"></textarea>
            </div>
            <div class="form-group col-md-4">
               <label for="name">Country<span class="mandate">*</span></label>
               <select name="country" id="country" class="form-control" onchange="checkcountry(this.value);">
                <option value="">--Select Country--</option>
                <?php foreach ($countries as $country) { ?>
                        <option value="<?php echo $country['country_name']; ?>"><?php echo $country['country_name']; ?></option>
                <?php } ?>
                </select>
            </div>
            
             
        </div>
        <div class="row">
           <div class="form-group col-md-4">
                <label for="name">State<span class="mandate">*</span></label>
                <span class="notforindia">
                    <input type="text" id="state" name="otherstate" class="form-control" placeholder="Enter State">
                </span>
                <span class="forindia" style="display:none;">
                <select id="state" name="state"  class="form-control" onchange="getcities(this.value, 'city');">
                    <option value=""> Select State</option>
                    <?php foreach ($states as $state) { ?>
                        <option value="<?php echo $state['city_state']; ?>"><?php echo $state['city_state']; ?></option>
                    <?php } ?>
                </select>
                </span>
            </div>
            <div class="form-group col-md-4">
                <label for="name">City<span class="mandate">*</span></label>
                <span class="notforindia">
                    <input type="text" id="citytext" name="othercity" class="form-control" placeholder="Enter City">
                </span>
                <span class="forindia" style="display:none;">
                    <select class="form-control" name="city" id="city"><option value="">--Select City--</option></select>
                </span>
            </div>
            <div class="form-group col-md-4">
                <label for="name">Pin Code<span class="mandate">*</span></label>
                <input type="text" id="zipcode" name="zipcode" class="form-control" placeholder="Enter pin code">
            </div>
             
        </div>
       
        <div class="row">
        <div class="form-group col-md-4">
                <label for="name">Contact No<span class="mandate">*</span></label>
                <input type="text" id="primary_contact" name="primary_contact" class="form-control" placeholder="Enter primary contact">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Email Id<span class="mandate">*</span></label>
                <input type="text" id="emailid" name="emailid" class="form-control" placeholder="Enter Email" onblur="checkDonoremail(this.value,'donor_email_error','');" >
                <span id="donor_email_error" class="error"></span>
            </div>
            <div class="form-group col-md-4">
                <label for="name">PAN Card</label>
                <input type="text" id="pan_card" name="pan_card" class="form-control" placeholder="Enter PAN Card">
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="save" class="btn btn-primary save">Save</button>
            </div>
        </div>
    </div>
</form> 
    <?php } ?>
<div class="dash_column">
    <div class="tbl">
        <table id="disease" class="table table-striped table-bordered donor_table">
            <thead>
                <tr>
                    <th>Email Id</th>
                    <th>Name</th>
                    <th>Donor Type</th>
                    <th>Country</th>
                    <th>State</th>
                    <th>City</th>
                    <th>Contact</th>                      
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                 <?php
    if (!empty($donnerData)) {
        foreach ($donnerData as $donner) {
            ?>
                <tr>
                    <td><?php echo $donner['EmailId']; ?></td>
                    <td><?php echo $donner['OrganizationName']?$donner['OrganizationName']:$donner['FirstName']; ?></td>
                    <td><?php echo $donner['DonerType']; ?></td>
                    <td><?php echo $donner['Country']; ?></td>
                    <td><?php echo $donner['State']; ?>.</td>
                    <td><?php echo $donner['City']; ?></td>
                    <td><?php echo $donner['ContactNo']; ?></td> 
                    <td><a class="btn btn-info btn-xs" href="?act=update&id=<?php echo base64_encode($donner['DonerId']);?>" title="Edit"><i class="fa fa-edit"></i></a></td>
                    
                </tr>
    <?php } } ?>
            </tbody></table>
    </div>
</div>
</div>