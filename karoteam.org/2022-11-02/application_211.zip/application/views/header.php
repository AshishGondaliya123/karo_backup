<!DOCTYPE html>
<html>
    <head>
        <title>KARO</title>
        <link rel="icon" href="<?php echo base_url(); ?>karoclient/images/favicon-1.png" type="image/png" sizes="32x32"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <!--link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>karoclient/css/jquery.dataTables.min.css"  media="screen,projection"/-->
        <!-- for new data table -->
        <link type="text/css" rel="stylesheet"  href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"  media="screen,projection"/>
        <link type="text/css" rel="stylesheet"  href="https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css"  media="screen,projection"/>

        <link rel="stylesheet" href="<?php echo base_url(); ?>karoclient/css/jquery.datetimepicker.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>karoclient/css/style.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>karoclient/css/new_style.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>karoclient/css/dashboard.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>karoclient/css/jquery-ui.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
    </head>
    <body class="dash_bg">
        <header class="dashboard_header">
            <div class="logo">
                <a href="#">
                    <img src="<?php echo base_url(); ?>karoclient/images/logo.png">
                </a>
            </div>
            <div class="accountSec">
                <?php
                $userImg = '';
                if ($this->session->userdata('UserImage')) {
                    $userImg = base_url() . 'karoclient/usersprofile/' . $this->session->userdata('UserImage');
                } else {
                    $userImg = base_url() . 'karoclient/images/user-1.jpg';
                }
                ?>
                <a href="#" class="userImg">
                    <img src="<?php echo $userImg; ?>" alt="Pooja Singh" title="User">
                </a>
                <div class="userName">
                    <a href="#">
                        <?php echo $this->session->userdata('FirstName') . " " . $this->session->userdata('LastName'); ?>
                    </a>
                    <i class="fa fa-caret-down"></i>
                </div>
                <ul>
                    <!--                    <li><a href="#">My Profile</a></li>-->
                    <li>
                        <a href="<?php echo site_url(); ?>/login/logout">Log Out</a>
                    </li>
                </ul>
            </div>
        </header>
        <div class="dash_left_section">
            <ul class="side_nav">
                <?php $routers = array("diseases", "location", "payment", "patientclassification", "referredby", "patientstatus", "users", "donner", "hospital"); ?>
                <li>
                    <a href="<?php echo site_url(); ?>/dashboard"<?php
                    if ($this->router->fetch_class() == 'dashboard') {
                        echo "class='active'";
                    }
                    ?>>
                        <i class="pro_icon dashboard"></i>Dashboard
                    </a>
                </li>
                <li>
                    <a href="<?php echo site_url(); ?>followup"<?php
                    
                    if ($this->router->fetch_class() == 'followup') {
                        echo "class='active'";
                    }
                    ?>>
                        <i class="pro_icon transaction"></i>Follow Ups
                    </a>
                </li>
                <li class="drop_menu <?php
                if ($this->router->fetch_class() == 'patientmaster') {
                    echo "open";
                }
                ?>">
                    <a href="javascript:void(0)"><i class="pro_icon schedule"></i> Patient </a>
                    <span class="plus"></span>
                    <ul class="sub_nv">
                        <li>
                            <a href="<?php echo site_url(); ?>/patientmaster"<?php
                            if ($this->router->fetch_class() == 'patientmaster' && !in_array($this->router->fetch_method(), array('viewpatient', 'viewSelectedPatient'))) {
                                echo "class='active'";
                            }
                            ?>>Add Patient</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url(); ?>/patientmaster/viewpatient" <?php
                            if ($this->router->fetch_method() == 'viewpatient' && $this->router->fetch_class() == 'patientmaster') {
                                echo "class='active'";
                            }
                            ?>>View Patient</a>
                        </li>
                    </ul>
                </li>
                <li class="drop_menu <?php
                if ($this->router->fetch_class() == 'Caseinfo') {
                    echo "open";
                }
                ?>">
                    <a href="javascript:void(0)" ><i class="pro_icon leave"></i> Case </a>
                    <span class="plus"></span>
                    <ul class="sub_nv">
                        <li><a href="<?php echo site_url(); ?>/Caseinfo/getCaseData?case=new" class="<?php if ((explode('=', $_SERVER[REQUEST_URI])[1] == 'new') && ($this->router->fetch_method() == 'getCaseData' )) echo "active"; ?>">New Cases</a></li>
                        <li><a href="<?php echo site_url(); ?>/Caseinfo/getCaseData?case=open" class="<?php if ((explode('=', $_SERVER[REQUEST_URI])[1] == 'open') && ($this->router->fetch_method() == 'getCaseData' )) echo "active"; ?>">Open Cases</a></li>
                        <li><a href="<?php echo site_url(); ?>/Caseinfo/getCaseData?case=closed" class="<?php if ((explode('=', $_SERVER[REQUEST_URI])[1] == 'closed') && ($this->router->fetch_method() == 'getCaseData' )) echo "active"; ?>">Closed Cases</a></li>
                        <li><a href="<?php echo site_url(); ?>/Caseinfo/getCaseData?case=hold" class="<?php if ((explode('=', $_SERVER[REQUEST_URI])[1] == 'hold') && ($this->router->fetch_method() == 'getCaseData' )) echo "active"; ?>" >Hold Cases</a></li>
                        <li><a href="<?php echo site_url(); ?>/Caseinfo/getCaseData?case=reject" class="<?php if ((explode('=', $_SERVER[REQUEST_URI])[1] == 'reject') && ($this->router->fetch_method() == 'getCaseData' )) echo "active"; ?>">Rejected Cases</a></li>
                        <li><a href="<?php echo site_url(); ?>/Caseinfo/getCaseData?case=all" class="<?php if ((explode('=', $_SERVER[REQUEST_URI])[1] == 'all') && ($this->router->fetch_method() == 'getCaseData' )) echo "active"; ?>">All Cases</a></li>
                    </ul>
                </li>
                <li class="drop_menu <?php
                if ($this->router->fetch_class() == 'Transaction') {
                    echo "open";
                }
                ?>"><a href="javascript:void(0)" ><i class="pro_icon transaction"></i> Transaction </a>
                    <span class="plus"></span>
                    <ul class="sub_nv">
                        <li <?php echo ($this->session->userdata('IsAdmin') != 1) ? 'hidden' : ''; ?>>
                            <a href="<?php echo site_url(); ?>/Transaction/saveDonerDonation" <?php
                            if ($this->router->fetch_method() == 'saveDonerDonation' && $this->router->fetch_class() == 'Transaction') {
                                echo "class='active'";
                            }
                            ?>>Donor Donation
                            </a>
                        </li>
                       <!--  <li>
                            <a href="<?php echo site_url(); ?>/Transaction/upcomingFollowup" <?php
                            /* if ($this->router->fetch_method() == 'upcomingFollowup' && $this->router->fetch_class() == 'Transaction') {
                                echo "class='active'";
                            } */
                            ?>>Upcoming Followup</a>
                        </li> -->

                        <!-- <li><a href="#">Patient Amount</a></li> -->

                        <li <?php echo ($this->session->userdata('IsAdmin') != 1) ? 'hidden' : ''; ?>>
                            <a href="<?php echo site_url(); ?>/Transaction/refundAmount" <?php
                            if ($this->router->fetch_method() == 'refundAmount' && $this->router->fetch_class() == 'Transaction') {
                                echo "class='active'";
                            }
                            ?>>Refund Amount
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="drop_menu <?php
                if ($this->router->fetch_class() == 'Reports' || ($this->router->fetch_method() == 'viewSelectedPatient' && $this->router->fetch_class() == 'patientmaster')) {
                    echo "open";
                }
                ?>">
                    <a href="javascript:void(0)" ><i class="pro_icon leave"></i> Reports </a>
                    <span class="plus"></span>
                    <ul class="sub_nv">
                        <li>
                            <a href="<?php echo site_url(); ?>/Reports/getPatientsReports" <?php
                            if ($this->router->fetch_method() == 'getPatientsReports' && $this->router->fetch_class() == 'Reports') {
                                echo "class='active'";
                            } else if ($this->router->fetch_method() == 'viewSelectedPatient' && $this->router->fetch_class() == 'patientmaster') {
                                echo "class='active'";
                            }
                            ?>>Patient Details</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url(); ?>/Reports/getPatientsCaseReports" <?php
                            if ($this->router->fetch_method() == 'getPatientsCaseReports' && $this->router->fetch_class() == 'Reports') {
                                echo "class='active'";
                            }
                            ?>>Patient Closed Case Details</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url(); ?>/Reports/getDonorWisePatientDetails" <?php
                            if ($this->router->fetch_method() == 'getDonorWisePatientDetails' && $this->router->fetch_class() == 'Reports') {
                                echo "class='active'";
                            }
                            ?>>Donor Wise Patient Details</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url(); ?>/Reports/getPatientsWiseFinacialReports" <?php
                            if ($this->router->fetch_method() == 'getPatientsWiseFinacialReports' && $this->router->fetch_class() == 'Reports') {
                                echo "class='active'";
                            }
                            ?>>Patient Wise Finacial Details</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url(); ?>/Reports/getPatientsDonorWiseFinacialReports" <?php
                            if ($this->router->fetch_method() == 'getPatientsDonorWiseFinacialReports' && $this->router->fetch_class() == 'Reports') {
                                echo "class='active'";
                            }
                            ?>>Donor Wise Finacial Details</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url(); ?>/Reports/getDeleteDisbursedReports" <?php
                            if ($this->router->fetch_method() == 'getDeleteDisbursedReports' && $this->router->fetch_class() == 'Reports') {
                                echo "class='active'";
                            }
                            ?>>Delete Disbursed Details</a>
                        </li>
                        <!-- <li><a href="#">Patient Amount</a></li> -->
                    </ul>
                </li>
                <li class="drop_menu <?php
                if (in_array($this->router->fetch_class(), $routers)) {
                    echo "open";
                }
                ?>">
                    <a href="javascript:void(0)">
                        <i class="pro_icon intraday"></i>Master
                    </a>
                    <span class="plus"></span>
                    <ul class="sub_nv">
                        <!--                        <li>
                                                    <a href="<?php echo site_url(); ?>/diseases" <?php
                        if ($this->router->fetch_class() == 'diseases') {
                            echo "class='active'";
                        }
                        ?>>Diseases</a>
                                                </li>-->
                                                <!-- <li><a href="<?php echo site_url(); ?>/location" <?php
                        if ($this->router->fetch_class() == 'location') {
                            echo "class='active'";
                        }
                        ?>>Location</a></li>
                                                <li><a href="<?php echo site_url(); ?>/patientclassification" <?php
                        if ($this->router->fetch_class() == 'patientclassification') {
                            echo "class='active'";
                        }
                        ?>>Patient Classification</a></li>
                                                <li><a href="<?php echo site_url(); ?>/patientstatus" <?php
                        if ($this->router->fetch_class() == 'patientstatus') {
                            echo "class='active'";
                        }
                        ?>>Patient Status</a></li> -->
                        <li>
                            <a href="<?php echo site_url(); ?>/payment" <?php
                            if ($this->router->fetch_class() == 'payment') {
                                echo "class='active'";
                            }
                            ?>>Payment </a>
                        </li>
                        <li hidden>
                            <a href="<?php echo site_url(); ?>/referredby" <?php
                            if ($this->router->fetch_class() == 'referedby') {
                                echo "class='active'";
                            }
                            ?>>Referred By</a>
                        </li>
                        <?php if ($this->session->userdata('IsAdmin') == 1) { ?>

                            <li>
                                <a href="<?php echo site_url(); ?>/users" <?php
                                if ($this->router->fetch_class() == 'users') {
                                    echo "class='active'";
                                }
                                ?>>Users</a>
                            </li>
                        <?php } ?>

                        <li>
                            <a href="<?php echo site_url(); ?>/hospital" <?php
                            if ($this->router->fetch_class() == 'hospital' && strpos($_SERVER['REQUEST_URI'], '/hospital/dept') == false && strpos($_SERVER['REQUEST_URI'], '/save_dept') == false) {
                                echo "class='active'";
                            }
                            ?>>Hospitals </a>
                        </li>
                        <li>
                            <a href="<?php echo site_url(); ?>/donner" <?php
                            if ($this->router->fetch_class() == 'donner') {
                                echo "class='active'";
                            }
                            ?>>Donor</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url(); ?>/hospital/dept" <?php
                            if (strpos($_SERVER['REQUEST_URI'], '/hospital/dept') !== false || strpos($_SERVER['REQUEST_URI'], '/save_dept') !== false) {
                                echo "class='active'";
                            }
                            ?>>Department</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- <div class="side_nav_btn"> <p>Navigation</p><a href="javascript:void(0)" class="collapse_nav"> <span></span> <span class="mdll"></span> <span></span> </a> </div>-->
            <!--
              <ul class="side_nav">
                <li class="drop_menu"><a href="javascript:void(0)" class="active"><i class="pro_icon schedule"></i> Patient </a>
                <span class="plus"></span>
                <ul class="sub_nv">
                                    <li><a href="#">Add patient</a></li>
                                    <li><a href="#">View patient</a></li>
                            </ul>
                </li>
                <li class="drop_menu"><a href="javascript:void(0)" ><i class="pro_icon leave"></i> Case </a>
                <span class="plus"></span>
                <ul class="sub_nv">
                                    <li><a href="#">New Case</a></li>
                                    <li><a href="#">Open Case</a></li>
                                    <li><a href="#">Closed Case</a></li>
                                    <li><a href="#">Hold Case</a></li>
                        <li><a href="#">Rejected Case</a></li>
                        <li><a href="#">All </a></li>
                            </ul>
                </li>
                <li class="drop_menu">
                            <a href="javascript:void(0)"><i class="pro_icon intraday"></i>Master</a>
                    <span class="plus"></span>
                            <ul class="sub_nv">
                                    <li><a href="#">User Master</a></li>
                                    <li><a href="#">Refered By</a></li>
                                    <li><a href="#">Hospitals Master</a></li>
                                    <li><a href="<?php echo site_url(); ?>/diseases">Diseases Master</a></li>
                                    <li><a href="<?php echo site_url(); ?>/location">Location Master</a></li>
                                    <li><a href="<?php echo site_url(); ?>/patientclassification">Patient Classification Master</a></li>
                                    <li><a href="<?php echo site_url(); ?>/patientstatus">Patient Status Master</a></li>
                                    <li><a href="<?php echo site_url(); ?>/payment">Payment  Master</a></li>
                                    <li><a href="#">Donner Master</a></li>
                            </ul>
                </li>
                <li class="drop_menu">
                            <a href="javascript:void(0)"><i class="pro_icon more"></i>Follow Up</a>
                    <span class="plus"></span>
                            <ul class="sub_nv">
                                    <li><a href="#">Update Follow Up</a></li>
                            </ul>
                </li>
                <li class="drop_menu">
                            <a href="javascript:void(0)"><i class="pro_icon reports"></i>Reports</a>
                    <span class="plus"></span>
                            <ul class="sub_nv">
                                    <li><a href="#">Case Status Report</a></li>
                                    <li><a href="#">Follow Up Report</a></li>
                                    <li><a href="#">Monthaly Reports</a></li>
                                    <li><a href="#">Icon</a></li>
                            </ul>
                </li>


              </ul>
            -->
        </div>
