<style>
.btn-xs{ margin-right:5px !important; margin-top:0;}
</style>
<div class="dash_right_section">
<div><?php echo $this->session->flashdata('message');?></div>
    <h2 class="main-heading">Diseases</h2>
  <?php if(isset($_REQUEST['act'])){?>
     <?php if($_REQUEST['act']=='update'){?>
    <?php echo form_open('diseases/changediseasesName');?>
    
        <div class="dash_column">
            <div class="diseases">
                <div class="form-group">
                    <label for="name">Disease Name</label>
					 <span class="mandate">*</span>
                    <?php $values = explode("_", base64_decode($_REQUEST['id']));?>
                    <input id="diseases_id" name="diseases_id" value="<?php echo base64_encode($values[0]); ?>" type="hidden" class="form-control specialchr">
                    <input id="diseases_name" name="diseases_name" maxlength="100" type="text" class="form-control specialchr" value = "<?php echo $values[1]; ?>" placeholder="Enter disease name" onkeypress ="removeValidation();">
                    <span id="errormsg" style="color:red"></span>
                </div>
                <input type="submit" name="save" class="btn btn-primary save" value="Save" onclick="return checkfield('diseases_name');">
                <div class="clearfix"></div>
                
            </div>
        </div>
    </form>
     <?php } }else{ ?>
    <?php echo form_open('diseases/index');?>
    <!--<div><?php //echo $this->session->flashdata('message');?></div>-->
        <div class="dash_column">
            <div class="diseases">
                <div class="form-group">
                    <label for="name">Disease Name</label>
					 <span class="mandate">*</span>
                    <input id="diseases_name" name="diseases_name" maxlength="100" type="text" class="form-control specialchr" placeholder="Enter disease name" onkeypress ="removeValidation();">
                    <span id="errormsg" style="color:red"></span>
                </div>
                <input type="submit" name="save" class="btn btn-primary save" value="Save" onclick="return checkfield('diseases_name');">
                <div class="clearfix"></div>
                
            </div>
        </div>
    </form>
  <?php } ?>
    <div class="dash_column">
        <div class="tbl">
            <table id="disease" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Disease Name</th> 
                         <th>Status</th>          
                        <th>Actions</th>
                        
                      
                       
                    </tr>
                </thead>
                <?php if (!empty($diseases)) {
                    foreach ($diseases as $disease) {
                        ?>
                        <tr>
                            <td><?php echo $disease['DiseaseName']; ?></td>
                            <td>    <?php
                                    if ($disease['IsActive'] == '1') {
                                        echo "Active";
                                    } else {
                                        echo "Inactive";
                                    }
                                    ?></td>

                            <td><a class='btn btn-info btn-xs' href="?act=update&id=<?php echo base64_encode($disease['DiseaseId']."_".$disease['DiseaseName']); ?>" title="Edit"><i class="fa fa-edit"></i></a>
                          
                            <a href="javascript:void(0);" data-url="<?php echo site_url(); ?>/diseases/changestatus?status=<?php echo $disease['IsActive']; ?>&id=<?php echo base64_encode($disease['DiseaseId']); ?>" title="<?php
                                    if ($disease['IsActive'] == '1') {
                                        echo "click here to inactive";
                                    } else {
                                         echo "click here to active";
                                    }
                                    ?>" class="btn btn-<?php if ($disease['IsActive'] == '0') {
                                echo "primary";
                            } else {
                                echo "danger";
                            } ?> btn-xs" onclick="changeStatusDynamically($(this),'Are you sure to <?php if ($disease['IsActive'] == '1') {echo "Inactive";} else { echo "Active"; } ?> this disease name ?');">
                                    <?php
                                    if ($disease['IsActive'] == '1') {
                                        //echo "Deativate";?>
                                        <i class="fa fa-toggle-off"></i>
                                   <?php } else {
                                        //echo "Activate";?>
                                        <i class="fa fa-toggle-on"></i>
                                    <?php }
                                    ?>
                                    
                                </a>
                               
                                </td>
                                
                        </tr>
    <?php }
} ?>   


            </table>
        </div>
    </div>
</div>