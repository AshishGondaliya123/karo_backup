<table align="center" width="700" border="0" cellspacing="0" cellpadding="0" style="width:50%; max-width:500px; margin:30px auto; ">
  <tr>
    <td style="padding:30px 35px; border:1px solid #dfe3e8; border-radius: 4px; box-shadow:0px 2px 10px rgba(0,0,0,5%);" valign="top" bgcolor="#fff" align="center"><table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
        <tbody>
          <tr>
            <td style="font-family:'Open Sans', Arial, sans-serif; font-size:16px; line-height:25px; color:#252f39; padding-bottom:20px;" valign="top">You've requested to reset your Karo password with
              the email <a href="#" target="_blank" style="color:#1155cc; text-decoration:underline;"><?php echo $email ; ?>.</a></td>
          </tr>
          <tr>
            <td style="font-family:'Open Sans', Arial, sans-serif; font-size:16px; line-height:25px; color:#252f39; padding-bottom:20px;" valign="top">If you didn't request this, you can ignore this email.</td>
          </tr>
          <tr>
            <td style="font-family:'Open Sans', Arial, sans-serif; font-size:16px; color:#252f39;" valign="top"><a href="<?php echo site_url().'/login/resetpassword?id='.$veryfylink; ?>" style="border-radius:4px; padding:12px 26px; background:#ff6600; color:#fff; display:inline-block; text-decoration:none; font-weight:600;" target="_blank">Reset password</a></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr>
    <td style="padding:30px 0px;"  valign="top" align="center"><table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
        <tbody>
          <tr>
            <td style="font-family:'Open Sans', Arial, sans-serif; font-size:16px; line-height:25px; color:#252f39; " valign="top" align="center"><a href="http://karosoftware.esoftech.in/" target="_blank" title="Karo"><img src="http://karosoftware.esoftech.in/karoclient/images/karo_logo.png"></a></td>
          </tr>
          <tr>
            <td style="font-family:'Open Sans', Arial, sans-serif; font-size:14px; line-height:30px; color:#6f757d; " valign="top" align="center">© Karo | All Rights Reserved.</td>
          </tr>
        </tbody>
      </table></td>
  </tr>
</table>
