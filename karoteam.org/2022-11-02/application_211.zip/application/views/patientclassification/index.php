
<div class="dash_right_section">
 <div><?php echo $this->session->flashdata('message');?></div>
    <h2 class="main-heading">Patient Classification</h2>
  <?php if(isset($_REQUEST['act'])){?>
     <?php if($_REQUEST['act']=='update'){?>
    <?php echo form_open('patientclassification/changepatientclassificationName');?>
        <div class="dash_column">
            <div class="diseases">
                
                <div class="form-group">
                    <label for="name">Classification Name</label>
                    <?php $values = explode("_", base64_decode($_REQUEST['id']));?>
                    <input id="ClassificationId" name="ClassificationId" value="<?php echo base64_encode($values[0]); ?>" type="hidden" class="form-control specialchr">
                    <input id="ClassificationName" name="ClassificationName" type="text" class="form-control specialchr" value = "<?php echo $values[1]; ?>" placeholder="Enter Classification Name" maxlength="100" onkeypress ="removeValidation();">
                    <span id="errormsg" style="color:red"></span>
                </div>
                <input type="submit" name="save" class="btn btn-primary save" value="Save" onclick="return checkfield('ClassificationName');">
                <div class="clearfix"></div>
               
            </div>
        </div>
    </form>
     <?php } }else{ ?>
    <?php echo form_open('patientclassification/index');?>
        <div class="dash_column">
            <div class="payment">
                
                <div class="form-group">
                    <label for="name">Classification Name</label>
                    <input id="ClassificationName" name="ClassificationName" type="text" class="form-control specialchr" placeholder="Enter Classification Name" maxlength="100" onkeypress ="removeValidation();">
                    <span id="errormsg" style="color:red"></span>
                </div>
                <input type="submit" name="save" class="btn btn-primary save" value="Save" onclick="return checkfield('ClassificationName');">
                <div class="clearfix"></div>
                <div><?php //echo $this->session->flashdata('message');?></div>
            </div>
        </div>
    </form>
  <?php } ?>
    <div class="dash_column">
        <div class="tbl">
            <table id="disease" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Classification Name</th>
                        <th>Status</th>          
                        <th>Action</th>
                        <th></th>
                        
                    </tr>
                </thead>
                <?php if (!empty($patientclassification)) {
                    foreach ($patientclassification as $classification) {
                        ?>
                        <tr>
                            <td><?php echo $classification['ClassificationName']; ?></td>
 <td> <?php
                                    if ($classification['IsActive'] == '1') {
                                        echo "Active";
                                    } else {
                                        echo "Inactive";
                                    }
                                    ?></td>
                            <td><a class='btn btn-info btn-xs' href="?act=update&id=<?php echo base64_encode($classification['ClassificationId']."_".$classification['ClassificationName']); ?>"> Edit</a></td>
                            <td><a href="<?php echo site_url(); ?>/patientclassification/changestatus?status=<?php echo $classification['IsActive']; ?>&id=<?php echo base64_encode($classification['ClassificationId']); ?>" title="<?php
                                    if ($classification['IsActive'] == '1') {
                                        echo "click here to inactive";
                                    } else {
                                         echo "click here to active";
                                    }
                                    ?>" class="btn btn-<?php if ($classification['IsActive'] == '0') {
                                echo "primary";
                            } else {
                                echo "danger";
                            } ?> btn-xs" onclick="return confirm('Are you sure  to <?php if ($classification['IsActive'] == '1') {echo "Inactive";} else { echo "Active"; } ?> this patient classification');">
                                    <?php
                                    if ($classification['IsActive'] == '1') {
                                        echo "Deactivate";
                                    } else {
                                        echo "Activate";
                                    }
                                    ?>
                                </a></td>
                        </tr>
    <?php }
} ?>   


            </table>
        </div>
    </div>
</div>