
<div class="dash_right_section">
<div><?php echo $this->session->flashdata('message');?></div>
    <h2 class="main-heading">Location</h2>
  <?php if(isset($_REQUEST['act'])){?>
     <?php if($_REQUEST['act']=='update'){?>
    <?php echo form_open('location/changelocationName');?>
        <div class="dash_column">
            <div class="diseases">
                
                <div class="form-group">
                    <label for="name">Location Name</label>
                    <?php $values = explode("_", base64_decode($_REQUEST['id']));?>
                    <input id="location_id" name="location_id" value="<?php echo base64_encode($values[0]); ?>" type="hidden" class="form-control specialchr">
                    <input id="location_name" name="location_name" type="text" class="form-control specialchr" value = "<?php echo $values[1]; ?>" placeholder="Enter Location name" maxlength="100" onkeypress ="removeValidation();">
                    <span id="errormsg" style="color:red"></span>
                </div>
                <input type="submit" name="save" class="btn btn-primary save" value="Save" onclick="return checkfield('location_name');">
                <div class="clearfix"></div>
                
            </div>
        </div>
    </form>
     <?php } }else{ ?>
    <?php echo form_open('location/index');?>
        <div class="dash_column">
            <div class="location">
                
                <div class="form-group">
                    <label for="name">Location Name</label>
                    <input id="location_name" name="location_name" type="text" class="form-control specialchr" placeholder="Enter Location name" maxlength="100" onkeypress ="removeValidation();">
                    <span id="errormsg" style="color:red"></span>
                </div>
                <input type="submit" name="save" class="btn btn-primary save" value="Save" onclick="return checkfield('location_name');">
                <div class="clearfix"></div>
                <div><?php //echo $this->session->flashdata('message');?></div>
            </div>
        </div>
    </form>
  <?php } ?>
    <div class="dash_column">
        <div class="tbl">
            <table id="disease" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Location Name</th> 
                        <th>Status</th>          
                        <th>Action</th>
                        <th></th>
                    </tr>
                </thead>
                <?php if (!empty($location)) {
                    foreach ($location as $loc) {
                        ?>
                        <tr>
                            <td><?php echo $loc['LocationName']; ?></td>
    <td> <?php
                                    if ($loc['IsActive'] == '1') {
                                        echo "Active";
                                    } else {
                                        echo "Inactive";
                                    }
                                    ?></td>
                            <td><a class='btn btn-info btn-xs' href="?act=update&id=<?php echo base64_encode($loc['LocationId']."_".$loc['LocationName']); ?>"> Edit</a></td>
                        
                            <td><a href="<?php echo site_url(); ?>/location/changestatus?status=<?php echo $loc['IsActive']; ?>&id=<?php echo base64_encode($loc['LocationId']); ?>" title="<?php
                                    if ($loc['IsActive'] == '1') {
                                        echo "click here to inactivate";
                                    } else {
                                         echo "click here to activate";
                                    }
                                    ?>" class="btn btn-<?php if ($loc['IsActive'] == '0') {
                                echo "primary";
                            } else {
                                echo "danger";
                            } ?> btn-xs" onclick="return confirm('Are you sure to <?php if ($loc['IsActive'] == '1') {echo "Inactive";} else { echo "Active"; } ?> this location name');">
                                    <?php
                                    if ($loc['IsActive'] == '1') {
                                        echo "Deactivate";
                                    } else {
                                        echo "Activate";
                                    }
                                    ?>
                                </a></td>
                        </tr>
    <?php }
} ?>   


            </table>
        </div>
    </div>
</div>