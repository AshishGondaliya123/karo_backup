<style type="text/css">
    #birthday .error{
    color: red;
    display: block;
    width: px;
    position: absolute;
    top: 160px;
	margin-left:580px;
	margin-bottom:20px;
    }
	
	</style>

<div class="dash_right_section">
    <h2 class="main-heading pull-left">Upcoming Birthdays</h2>
    <div class="clearfix"></div>
    <div class="dash_column">
        <div class="tbl">

            <div style="text-align: center;margin-bottom: 30px;">
                <form action="<?php echo base_url(); ?>index.php/dashboard/upcomingBirthdays" method="post" id="birthday" >
                    <label>Birthday's Filter<span class="mandate">*</span></label>
                    <select name="filter" style="height: 30px;">
                        <option value="" <?php echo ($f == "") ? "selected" : ""; ?>>--Select--</option>
                       <!-- <option value="current" <?php echo ($f == "current") ? "selected" : ""; ?>>Current Month</option>
                        <option value="next" <?php echo ($f == "next") ? "selected" : ""; ?>>Next Month</option>-->
						
						<option value="1" <?php echo ($f == "1") ? "selected" : ""; ?>>January</option>
                        <option value="2" <?php echo ($f == "2") ? "selected" : ""; ?>>Feburary</option>
						<option value="3" <?php echo ($f == "3") ? "selected" : ""; ?>>March</option>
						<option value="4" <?php echo ($f == "4") ? "selected" : ""; ?>>April</option>
						<option value="5" <?php echo ($f == "5") ? "selected" : ""; ?>>May</option>
						<option value="6" <?php echo ($f == "6") ? "selected" : ""; ?>>June</option>
						<option value="7" <?php echo ($f == "7") ? "selected" : ""; ?>>July</option>
						<option value="8" <?php echo ($f == "8") ? "selected" : ""; ?>>August</option>
						<option value="9" <?php echo ($f == "9") ? "selected" : ""; ?>>September</option>
						<option value="10" <?php echo ($f == "10") ? "selected" : ""; ?>>October</option>
						<option value="11" <?php echo ($f == "11") ? "selected" : ""; ?>>November</option>
						<option value="12" <?php echo ($f == "12") ? "selected" : ""; ?>>December</option>
                    </select>
                          <input type="submit" value="Submit" name="btnFilter" class="btn btn-primary" style="margin-top: -4px;height: 30px;background: #ff6600;
    border: 0px;"/>
	
                </form>
            </div>
            <table id="upcoming_birthdays_tbl" class="table table-striped table-bordered" width="100%">
                <thead>
                    <tr>
                        <th>Patient No.</th>
                        <th>Patient Name</th>
                        <th>Contact No.</th>
						<th>DOB</th>
						<th>Age</th>
                        <th>Birthday</th>
                        <!-- <th>Assign To</th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($upcoming_birdays) {
                        if (($f != "")) {
                            foreach ($upcoming_birdays as $key => $value) {
                              
                                    ?>
                                    <tr>
                                        <td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value->id ?>" title="Case Detail" target="_blank"><?php echo $value->patient_id; ?><a></td>
                                        <td><?php echo $value->patient_name; ?></td>
                                        <td><?php echo $value->patient_phone; ?></td>
										<td><?php echo $value->dob; ?></td>
										<td><?php echo $value->patient_age; ?></td>
                                        <td><?php echo $value->patient_dob; ?></td>
                                        <!-- <td>scxc</td> -->
                                    </tr>
                                    <?php
                               
                            }
                        } else {
                            foreach ($upcoming_birdays as $key => $value) {
                                ?>
                                <tr>
                                    <td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value->id ?>" title="Case Detail" target="_blank"><?php echo $value->patient_id; ?></a></td>
                                    <td><?php echo $value->patient_name; ?></td>
                                    <td><?php echo $value->patient_phone; ?></td>
									<td><?php echo $value->dob; ?></td>
									<td><?php echo $value->patient_age; ?></td>
                                    <td><?php echo $value->patient_dob; ?></td>
                                    <!-- <td>scxc</td> -->
                                </tr>
                                <?php
                            }
                        }
                    }
                    ?>
                </tbody>
                   
            </table>
        </div>
        <div class="clearfix"></div>
    </div>
</div>