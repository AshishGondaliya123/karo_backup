

<style>
    th{
        text-align: center;
    }
    td{
        text-align: center;
    }
</style>
<div class="dash_right_section">
    <h2 class="main-heading pull-left">Open Cases</h2>
    <div class="custom-search-input pull-right">
        <!-- <div class="input-group col-md-12">
            <input type="text" class="  search-query form-control" placeholder="Search by Patient Name or ID" />
            <span class="input-group-btn">
                <button class="btn btn-primary color-theme" type="button">
                    <span class=" fa fa-search"></span>
                </button>
            </span>
        </div> -->
    </div>

    <div class="clearfix"></div>
    <div class="dash_column family">
    <!-- <input type="submit" class="btn btn-primary add" value="Export to Excel" style="margin-bottom:20px !important"> -->
        <div class="tbl">
            <table id="open_case_tbl" class="table table-striped table-bordered" width="100%">

                <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>Reg.Date</th>
                        <th>Name of patient</th>
                        <th>Donor</th>
                        <th>Donate Amount</th>
                        <th>Amount sanctioned</th>
                        <th>Amount disbursed</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>

                            </tr>



                </tbody>
            </table>
        </div>

        <div class="clearfix"></div>
    </div>


</div>
