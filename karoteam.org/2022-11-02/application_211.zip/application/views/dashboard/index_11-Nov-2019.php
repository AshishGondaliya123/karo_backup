<style type="text/css">
    .tbl .table tr.today-class td{color: #31708f;background-color: #d9edf7}
    .tbl .table tr.tomorrow-class td{color: #8a6d3b;background-color: #fcf8e3}
    .patient_name_class{width: 300px}
    .disease-name-class{width: 250px}
    .upbd{margin: 0}
    .upbd a {color: #ff6600;text-decoration: none;font-weight: 400;font-size: 15px;display: block;margin-top: 20px;text-transform: uppercase}
</style>

<div class="dash_right_section">
    <div class="row">
        <div class="col-md-12">
            <div class="pull-left">
                <h2 class="main-heading">
                    <?php
                    if ($this->session->userdata('IsAdmin') == 1) {
                        echo "Admin DashBoard";
                    } else {
                        echo "Social Worker DashBoard";
                    }
                    ?>
                </h2>
            </div>
            <div class="pull-right">
                <h3 class="upbd">
                    <a href="<?php echo base_url() . 'index.php/dashboard/upcomingBirthdays'; ?>" target="_blank">Upcoming Birthday's</a>
                </h3>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle green">
                    <img src="<?php echo base_url('karoclient/images/new.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=new'; ?>" target="_blank">New Cases</a>
                    </h3>
                    <p><?php echo $count['New'] ? $count['New'] : 0; ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink">
                    <img src="<?php echo base_url('karoclient/images/open.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=open'; ?>"  target="_blank">Open Cases</a>
                    </h3>
                    <p><?php echo $count['open'] ? $count['open'] : 0; ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink">
                    <img src="<?php echo base_url('karoclient/images/close.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=closed'; ?>"  target="_blank">Closed Cases</a>
                    </h3>
                    <p><?php echo $count['closed'] ? $count['closed'] : 0; ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle green">
                    <img src="<?php echo base_url('karoclient/images/hold.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=hold'; ?>" target="_blank">Hold Cases</a>
                    </h3>
                    <p><?php echo $count['hold'] ? $count['hold'] : 0; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink">
                    <img src="<?php echo base_url('karoclient/images/reject.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=reject'; ?>"  target="_blank">Rejected Cases</a>
                    </h3>
                    <p><?php echo $count['reject'] ? $count['reject'] : 0; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink">
                    <img src="<?php echo base_url('karoclient/images/all.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=all'; ?>"  target="_blank">All Cases</a>
                    </h3>
                    <p><?php echo $count['all'] ? $count['all'] : 0; ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="dash_column">
                <div class="tbl">
                    <h3 class="shding" style="margin-bottom:15px">Upcoming Follow Up</h3>
                    <div style="max-height:267px; overflow:auto">
                        <table id="" class="table table-striped table-bordered" width="100%" style="margin:0;">
                            <thead>
                                <tr>
                                    <th>Patient ID</th>
                                    <!-- <th>Date</th> -->
                                    <th>Name of patient</th>
                                    <th>Disease</th>
                                    <!-- <th>Hospital</th> -->
                                    <th>Follow Up Done</th>
                                    <th>Due Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($follow_up) {
                                    foreach ($follow_up as $key => $value) {
                                        ?>
                                        <tr class ="<?php echo $value['next_followup_date'] == date('Y-m-d') ? 'today-class' : 'tomorrow-class' ?>">
                                            <td><?php echo $value['patient_id']; ?></td>
                                            <!-- <td><?php //echo $value['registration_date'];                                ?></td> -->
                                            <td class="patient_name_class"><?php echo $value['patient_name']; ?></td>
                                            <td class="disease-name-class"><?php echo $value['DiseaseName']; ?></td>
                                            <!-- <td><?php //echo $value['HospitalName'];                                ?></td> -->
                                            <td><?php echo $value['follow_up_done']; ?></td>
                                            <td><?php echo $value['next_followup_date']; ?></td>
                                            <td>
                                                <a class="btn btn-warning btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value['id'] ?>" title="Detail">
                                                    <i class="fa fa-info-circle"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <!--        <div class="col-md-6">
                    <div class="dash_column">
                        <h3 class="shding">Total Cases</h3>
                        <canvas id="case-chart" width="800" height="450"></canvas>
                    </div>
                </div>-->
        <div class="col-md-6">
            <div class="dash_column">
                <h3 class="shding">Age Wise Patients</h3>
                <canvas id="ageChart" width="800" height="450" onclick="openChartData('ageChart', event)"></canvas>
            </div>
        </div>
        <div class="col-md-6">
            <div class="dash_column">
                <h3 class="shding">Gender Wise Patients</h3>
                <canvas id="genderChart" width="800" height="450" onclick="openChartData('genderChart', event)"></canvas>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="dash_column">
                <h3 class="shding">State Wise Patients</h3>
                <canvas id="stateChart" width="800" height="450" onclick="openChartData('stateChart', event)"></canvas>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="dash_column">
                <h3 class="shding">Disease Wise Patients</h3>
                <canvas id="diseaseChart" width="800" height="450" onclick="openChartData('diseaseChart', event)"></canvas>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="dash_column">
                <h3 class="shding">Hospital Wise Patients</h3>
                <canvas id="hospitalChart" width="800" height="450" onclick="openChartData('hospitalChart', event)"></canvas>
            </div>
        </div>
    </div>
    <!--
    <canvas id="case-chart" width="800" height="450"></canvas>
    <canvas id="disease-chart" width="800" height="450"></canvas>
    <canvas id="hospital-chart" width="800" height="450"></canvas> -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
    <script type="text/javascript">
//        new Chart(document.getElementById("case-chart"), {
//            type: 'pie',
//            data: {
//                labels: <?php //echo $case_label;                           ?>,
//                datasets: <?php //echo $case_datasets;                           ?>,
//            },
//            options: {
//                title: {
//                    display: true,
//                    // text: 'Case'
//                },
//                legend: {
//                    display: true,
//                    position: "bottom",
//                    labels: {
//                        fontColor: "#333",
//                        fontSize: 16
//                    },
//                    // onClick: (e) => e.stopPropagation()
//                },
//                tooltips: {
//                    callbacks: {
//                        label: function (tooltipItem, data) {
//                            var allData = data.datasets[tooltipItem.datasetIndex].data;
//                            var tooltipLabel = data.labels[tooltipItem.index];
//                            var tooltipData = allData[tooltipItem.index];
//                            var total = 0;
//                            for (var i in allData) {
//                                total += parseFloat(allData[i]);
//                            }
//                            var tooltipPercentage = ((tooltipData / total) * 100).toFixed(2);
//                            return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
//                        }
//                    }
//                }
//            }
//        });

                    // Age Pie Chart
                    var ageChart = new Chart(document.getElementById("ageChart"), {
                        type: 'pie',
                        data: {labels: <?php echo $ageLabels; ?>, datasets: <?php echo $ageDatasets; ?>, data: <?php echo $age_id; ?>},
                        options: {
                            title: {display: true},
                            legend: {display: true, position: "bottom", labels: {fontColor: "#333", fontSize: 16}, onClick: (e) => e.stopPropagation()},
                            tooltips: {
                                callbacks: {
                                    label: function (tooltipItem, data) {
                                        var allData = data.datasets[tooltipItem.datasetIndex].data;
                                        var tooltipLabel = data.labels[tooltipItem.index];
                                        var tooltipData = allData[tooltipItem.index];
                                        var total = 0;
                                        for (var i in allData) {
                                            total += parseFloat(allData[i]);
                                        }
                                        var tooltipPercentage = ((tooltipData / total) * 100).toFixed(2);
                                        return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                                    }
                                }
                            }
                        }
                    });
                    // Gender Pie Chart
                    var genderChart = new Chart(document.getElementById("genderChart"), {
                        type: 'pie',
                        data: {labels: <?php echo $genderLabels; ?>, datasets: <?php echo $genderDataset; ?>, data: <?php echo $gender; ?>},
                        options: {
                            title: {display: true},
                            legend: {display: true, position: "bottom", labels: {fontColor: "#333", fontSize: 16}, onClick: (e) => e.stopPropagation()},
                            tooltips: {
                                callbacks: {
                                    label: function (tooltipItem, data) {
                                        var allData = data.datasets[tooltipItem.datasetIndex].data;
                                        var tooltipLabel = data.labels[tooltipItem.index];
                                        var tooltipData = allData[tooltipItem.index];
                                        var total = 0;
                                        for (var i in allData) {
                                            total += parseFloat(allData[i]);
                                        }
                                        var tooltipPercentage = ((tooltipData / total) * 100).toFixed(2);
                                        return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                                    }
                                }
                            }
                        }
                    });
                    // State Bar Chart
                    var stateChart = new Chart(document.getElementById("stateChart"), {
                        type: 'bar',
                        data: {labels: <?php echo $stateLabels; ?>, datasets: <?php echo $stateCount; ?>, data: <?php echo $state_id; ?>},
                        options: {
                            legend: {display: false, onClick: (e) => e.stopPropagation()},
                            title: {display: true},
                            scales: {yAxes: [{ticks: {beginAtZero: true}}], xAxes: [{ticks: {autoSkip: false}}]}
                        }
                    });
                    // Disease Bar Chart
                    var diseaseChart = new Chart(document.getElementById("diseaseChart"), {
                        type: 'bar',
                        data: {labels: <?php echo $disease_label; ?>, datasets: <?php echo $disease_datasets; ?>, data: <?php echo $disease_id; ?>},
                        options: {
                            legend: {display: false, onClick: (e) => e.stopPropagation()},
                            title: {display: true},
                            scales: {yAxes: [{ticks: {beginAtZero: true}}], xAxes: [{ticks: {autoSkip: false}}]}
                        }
                    });
                    // Hospital Bar Chart
                    var hospitalChart = new Chart(document.getElementById("hospitalChart"), {
                        type: 'bar',
                        data: {labels: <?php echo $hospital_label; ?>, datasets: <?php echo $hospital_datasets; ?>, data: <?php echo $hospital_id; ?>},
                        options: {
                            legend: {display: false, onClick: (e) => e.stopPropagation()},
                            title: {display: true},
                            scales: {yAxes: [{ticks: {beginAtZero: true}}], xAxes: [{ticks: {autoSkip: false}}]}
                        }
                    });
                    function openChartData(chartId, evt) {
                        if (chartId == 'ageChart') {
                            var category = 'age';
                            var chartObj = ageChart;
                        } else if (chartId == 'genderChart') {
                            var category = 'gender';
                            var chartObj = genderChart;
                        } else if (chartId == 'stateChart') {
                            var category = 'state';
                            var chartObj = stateChart;
                        } else if (chartId == 'diseaseChart') {
                            var category = 'disease';
                            var chartObj = diseaseChart;
                        } else if (chartId == 'hospitalChart') {
                            var category = 'hospital';
                            var chartObj = hospitalChart;
                        }
                        var chartElm = document.getElementById(chartId);
                        //chartElm.onclick = function (evt) {
                            var activePoints = chartObj.getElementsAtEvent(evt);
                            if (activePoints[0]) {
                                var idx = activePoints[0]['_index'];
                                var chartData = activePoints[0]['_chart'].config.data;
                                var value = chartData.data[idx];
                                var label = chartData.labels[idx];
                                var url = "<?php echo base_url(); ?>index.php/patientmaster/viewSelectedPatient/?category=" + category + "&id=" + value + "&label=" + label;
                                window.open(url, '_blank');
                            }
                        //};
                    }
    </script>