<style type="text/css">
    .tbl .table tr.today-class td{color: #31708f;background-color: #d9edf7}
    .tbl .table tr.tomorrow-class td{color: #8a6d3b;background-color: #fcf8e3}
    .patient_name_class{width: 300px}
    .disease-name-class{width: 250px}
    .upbd{margin: 0}
    .upbd a {color: #ff6600;text-decoration: none;font-weight: 400;font-size: 15px;display: block;margin-top: 20px;text-transform: uppercase}
    .shding.bold{font-weight:500;}
    .no_data {
        text-align: center;
        font-size: 16px;
        color: #8c8c8c;
        font-weight: 400;
    }
</style>
<?php
   $CI = &get_instance();
   $params = [];
?>
<div class="dash_right_section">
    <div class="row">
        <div class="col-md-12">
            <div class="pull-left">
                <h2 class="main-heading">
                    <?php
                    if ($this->session->userdata('IsAdmin') == 1) {
                        echo "Admin DashBoard";
                    } else {
                        echo "Social Worker DashBoard";
                    }
                    ?>
                </h2>
            </div>
            <div class="pull-right">
                <h3 class="upbd">
                    <a href="<?php echo base_url() . 'index.php/dashboard/upcomingBirthdays'; ?>" target="_blank">Upcoming Birthdays</a>
                </h3>
            </div>
        </div>
    </div>

    <div class="row">  
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle green">
                    <img src="<?php echo base_url('karoclient/images/new.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=new'; ?>" target="_blank">New Patients</a>
                    </h3>
                    <p><?php 
                 
                        $params['pcd.case_status'] = "new";
                        $new_case = $CI->cm->getCaseDetails($params);
                        echo numberformat(count($new_case));
//echo $count['New'] ? $count['New'] : 0; 
                    ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink">
                    <img src="<?php echo base_url('karoclient/images/open.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=open'; ?>"  target="_blank">Open Patients</a>
                    </h3>
					
                    <p><?php
					$params['pcd.case_status'] = "open";
                        $open_case = $CI->cm->getCaseDetails($params);
                        echo numberformat(count($open_case));

				//	echo $count['open'] ? $count['open'] : 0; ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink">
                    <img src="<?php echo base_url('karoclient/images/close.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=closed'; ?>"  target="_blank">Closed Patients</a>
                    </h3>
                    <p><?php 
					$params['pcd.case_status'] = "closed";
                        $closed_case = $CI->cm->getCaseDetails($params);
                        echo numberformat(count($closed_case));
					//echo $count['closed'] ? $count['closed'] : 0; ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle green">
                    <img src="<?php echo base_url('karoclient/images/hold.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=hold'; ?>" target="_blank">Hold Patients</a>
                    </h3>
                    <p><?php 
					$params['pcd.case_status'] = "hold";
                        $hold_case = $CI->cm->getCaseDetails($params);
                        echo numberformat(count($hold_case));
					//echo $count['hold'] ? $count['hold'] : 0; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink">
                    <img src="<?php echo base_url('karoclient/images/reject.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=reject'; ?>"  target="_blank">Rejected Patients</a>
                    </h3>
                    <p><?php 
					$params['pcd.case_status'] = "reject";
                        $reject_case = $CI->cm->getCaseDetails($params);
                        echo numberformat(count($reject_case));
					//echo $count['reject'] ? $count['reject'] : 0; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink">
                    <img src="<?php echo base_url('karoclient/images/all.png'); ?>" />
                </div>
                <div class="cirtext">
                    <h3>
                        <a href="<?php echo base_url() . 'index.php/Caseinfo/getCaseData?case=all'; ?>"  target="_blank">All Patients</a>
                    </h3>
                    <p><?php 
                    $params['pcd.case_status'] = "all";
                    $patient_details = $CI->cm->getOpenCaseDetails($params);
                    $case_id = array_column($patient_details, 'id');
                    $follow_up1 = $CI->cm->getNumberOfFollowupData($case_id);
                    $status_reason = $CI->cm->getStatusReason($case_id, $params['pcd.case_status']);

                    $result = array();

                    if ($patient_details)
                        foreach ($patient_details as $key => $value) {
                            if ($status_reason)
                                $patient_details[$key]['status_reason'] = $status_reason[$value['id']]['case_status_reason'];

                            if ($follow_up1)
                                foreach ($follow_up1 as $k => $v) {
                                    if ($value['id'] == $v['case_id']) {
                                        $patient_details[$key]['no_of_followup'] = $v['no_of_followup'];
                                        break;
                                    } else
                                        $patient_details[$key]['no_of_followup'] = 0;
                                } else
                                $patient_details[$key]['no_of_followup'] = 0;
                        }

                    echo numberformat(count($patient_details));
                    //echo $count['all'] ? $count['all'] : 0; ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="dash_column">
                <div class="tbl">
                    <h3 class="shding bold" style="margin-bottom:15px">Upcoming Follow Up</h3>
                    <div style="max-height:267px; overflow:auto">
                        <table id="" class="table table-striped table-bordered" width="100%" style="margin:0;">
                            <thead>
                                <tr>
                                    <th>Patient ID</th>
                                    <!-- <th>Date</th> -->
                                    <th>Name of patient</th>
                                    <!--  <th>Disease</th>-->
                                    <!-- <th>Hospital</th> -->
                                    <th>Department</th>
                                    <th>Follow Up Done</th>
                                    <th>Due Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($follow_up) {
                                    foreach ($follow_up as $key => $value) {
                                        ?>
                                        <tr class ="<?php echo $value['next_followup_date'] == date('Y-m-d') ? 'today-class' : 'tomorrow-class' ?>">
                                            <td><?php echo $value['patient_id']; ?></td>
                                            <!-- <td><?php //echo $value['registration_date'];                                   ?></td> -->
                                            <td class="patient_name_class"><?php echo $value['patient_name']; ?></td>
                                            <td class="disease-name-class"><?php echo $value['DeptName']; ?></td>
                                            <!-- <td><?php //echo $value['HospitalName'];                                   ?></td> -->
                                            <td><?php echo $value['follow_up_done']; ?></td>
                                            <td><?php echo $value['next_followup_date']; ?></td>
                                            <td>
                                                <a class="btn btn-warning btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $value['id'] ?>" title="Detail">
                                                    <i class="fa fa-info-circle"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if ($isAdmin = $this->session->userdata('IsAdmin')) { ?>
        <div class="row">
            <div class="col-md-12">
                <div class="dash_column">
                    <h3 class="shding bold">Donor Wise Patients Donate/Sanction/Disbursed/Balance Amount</h3>
                    <canvas id="donorChart" width="800" height="450" onclick="openChartData('donorChart', event)"></canvas>
                    <h4 class="no_data"><?php echo (empty($donor_datasets) || $donor_datasets == "[null]") ? "No data found" : ""; ?></h4>
                </div>
            </div>
        </div>
    <?php } ?>
    <div class="row">
        <div class="col-md-12">
            <div class="dash_column">
                <h3 class="shding bold">Department Wise Patients</h3>
                <canvas id="diseaseChart" width="800" height="450" onclick="openChartData('diseaseChart', event)"></canvas>
                <h4 class="no_data"><?php echo (empty($disease_datasets) || $disease_datasets == "[null]") ? "No data found" : ""; ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="dash_column">
                <h3 class="shding bold">Hospital Wise Patients</h3>
                <canvas id="hospitalChart" width="800" height="450" onclick="openChartData('hospitalChart', event)"></canvas>
                <h4 class="no_data"><?php echo (empty($hospital_datasets) || $hospital_datasets == "[null]") ? "No data found" : ""; ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <!--        <div class="col-md-6">
                    <div class="dash_column">
                        <h3 class="shding">Total Cases</h3>
                        <canvas id="case-chart" width="800" height="450"></canvas>
                    </div>
                </div>-->
        <div class="col-md-12">
            <div class="col-md-6">
                <div class="dash_column">
                    <h3 class="shding bold">Age Wise Patients</h3>
                    <canvas id="ageChart" width="100%" height="50%" onclick="openChartData('ageChart', event)"></canvas>
                    <h4 class="no_data"><?php echo (empty($ageDatasets) || $ageDatasets == "[null]") ? "No data found" : ""; ?></h4>
                </div>
            </div>
            <div class="col-md-6">
                <div class="dash_column">
                    <h3 class="shding bold">Gender Wise Patients</h3>
                    <canvas id="genderChart" width="100%" height="50%" onclick="openChartData('genderChart', event)"></canvas>
                    <h4 class="no_data"><?php echo (empty($genderDataset) || $genderDataset == "[null]") ? "No data found" : ""; ?></h4>
                </div>
            </div>
        </div>
      <!--  <div class="col-md-6">
            <div class="dash_column">
                <h3 class="shding bold">Age Wise Patients(Without DOB)</h3>
                <canvas id="ageChartDob" width="100%" height="50%" onclick="openChartData('ageChartDob', event)"></canvas>
                <h4 class="no_data"><?php //echo (empty($ageDatasets2) || $ageDatasets2 == "[null]") ? "No data found" : ""; ?></h4>
            </div>
        </div>-->


    </div>
    <!-- <div class="row">
        <div class="col-md-6">
            
        </div>
        <div class="col-md-6">
            <div class="dash_column">
                <h3 class="shding bold"></h3>
                <div style="width:482px; height:241px"></div>

            </div>
        </div>
    </div> -->
    <div class="row">
        <div class="col-md-12">
            <div class="dash_column">
                <h3 class="shding bold">Representative Wise Patients</h3>
                <canvas id="userChart" width="800" height="450" onclick="openChartData('userChart', event)"></canvas>
                <h4 class="no_data"><?php echo (empty($user_datasets) || $user_datasets == "[null]") ? "No data found" : ""; ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="dash_column">
                <h3 class="shding bold">State Wise Patients</h3>
                <canvas id="stateChart" width="800" height="450" onclick="openChartData('stateChart', event)"></canvas>
                <h4 class="no_data"><?php echo (empty($stateCount) || $stateCount == "[null]") ? "No data found" : ""; ?></h4>
            </div>
        </div>
    </div>
    
    <!--
    <canvas id="case-chart" width="800" height="450"></canvas>
    <canvas id="disease-chart" width="800" height="450"></canvas>
    <canvas id="hospital-chart" width="800" height="450"></canvas> -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
	
    <script type="text/javascript">
//        new Chart(document.getElementById("case-chart"), {
//            type: 'pie',
//            data: {
//                labels: <?php //echo $case_label;                              ?>,
//                datasets: <?php //echo $case_datasets;                              ?>,
//            },
//            options: {
//                title: {
//                    display: true,
//                    // text: 'Case'
//                },
//                legend: {
//                    display: true,
//                    position: "bottom",
//                    labels: {
//                        fontColor: "#333",
//                        fontSize: 16
//                    },
//                    // onClick: (e) => e.stopPropagation()
//                },
//                tooltips: {
//                    callbacks: {
//                        label: function (tooltipItem, data) {
//                            var allData = data.datasets[tooltipItem.datasetIndex].data;
//                            var tooltipLabel = data.labels[tooltipItem.index];
//                            var tooltipData = allData[tooltipItem.index];
//                            var total = 0;
//                            for (var i in allData) {
//                                total += parseFloat(allData[i]);
//                            }
//                            var tooltipPercentage = ((tooltipData / total) * 100).toFixed(2);
//                            return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
//                        }
//                    }
//                }
//            }
//        });

                            // Age Pie Chart
<?php if (empty($ageDatasets)) {

    ?>

<?php } else {
    ?>	
                        var ageChart = new Chart(document.getElementById("ageChart"), {
						
                        type: 'pie',
                                data: {labels: <?php echo $ageLabels; ?>, datasets: <?php echo $ageDatasets; ?>, data: <?php echo $age_id; ?>},
                                options: {
                                title: {display: true},
                                        legend: {display: true, position: "left", labels: {fontColor: "#333", fontSize: 16}, onClick: (e) => e.stopPropagation()},
                                        tooltips: {
                                            callbacks: {
                                                label: function (tooltipItem, data) {
                                                    var allData = data.datasets[tooltipItem.datasetIndex].data;
                                                            var tooltipLabel = data.labels[tooltipItem.index];
                                                            var tooltipData = allData[tooltipItem.index];
                                                            var total = 0;
                                                            for (var i in allData) {
                                                    total += parseFloat(allData[i]);
                                                }
                                                var tooltipPercentage = ((tooltipData / total) * 100).toFixed(2);
                                                    return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                                            }
                                        }
                                        }
                                }
                        });
<?php } ?>

// <?php if (empty($ageDatasets2)) {
    
// } else {
    // ?>
                        // var ageChartDob = new Chart(document.getElementById("ageChartDob"), {
                        // type: 'pie',
                                // data: {labels: <?php echo $ageLabels2; ?>, datasets: <?php echo $ageDatasets2; ?>, data: <?php echo $age_id2; ?>},
                                // options: {
                                // title: {display: true},
                                        // legend: {display: true, position: "left", labels: {fontColor: "#333", fontSize: 16}, onClick: (e) => e.stopPropagation()},
                                        // tooltips: {
                                        // callbacks: {
                                        // label: function (tooltipItem, data) {
                                        // var allData = data.datasets[tooltipItem.datasetIndex].data;
                                                // var tooltipLabel = data.labels[tooltipItem.index];
                                                // var tooltipData = allData[tooltipItem.index];
                                                // var total = 0;
                                                // for (var i in allData) {
                                        // total += parseFloat(allData[i]);
                                        // }
                                        // var tooltipPercentage = ((tooltipData / total) * 100).toFixed(2);
                                                // return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                                        // }
                                        // }
                                        // }
                                // }
                        // });
// <?php } ?>
                    // Gender Pie Chart

<?php if (empty($genderDataset)) {
    
} else {
    ?>
                        var genderChart = new Chart(document.getElementById("genderChart"), {
                        type: 'pie',
                                data: {labels: <?php echo $genderLabels; ?>, datasets: <?php echo $genderDataset; ?>, data: <?php echo $gender; ?>},
                                options: {
                                title: {display: true},
                                        legend: {display: true, position: "bottom", labels: {fontColor: "#333", fontSize: 16}, onClick: (e) => e.stopPropagation()},
                                        tooltips: {
                                        callbacks: {
                                        label: function (tooltipItem, data) {
                                        var allData = data.datasets[tooltipItem.datasetIndex].data;
                                                var tooltipLabel = data.labels[tooltipItem.index];
                                                var tooltipData = allData[tooltipItem.index];
                                                var total = 0;
                                                for (var i in allData) {
                                        total += parseFloat(allData[i]);
                                        }
                                        var tooltipPercentage = ((tooltipData / total) * 100).toFixed(2);
                                                return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                                        }
                                        }
                                        }
                                }
                        });
<?php } ?>

<?php if (empty($stateCount)) {
    
} else {
    ?>
                        // State Bar Chart
                        var stateChart = new Chart(document.getElementById("stateChart"), {
                        type: 'bar',
                                data: {labels: <?php echo $stateLabels; ?>, datasets: <?php echo $stateCount; ?>, data: <?php echo $state_id; ?>},
                                options: {
                                legend: {display: false, onClick: (e) => e.stopPropagation()},
                                        title: {display: true},
                                        scales: {yAxes: [{ticks: {beginAtZero: true}}], xAxes: [{ticks: {autoSkip: false}}]}
                                }
                        });
<?php } ?>

<?php if (empty($disease_datasets)) {
    
} else {
    ?>
                        // Disease Bar Chart
                        var diseaseChart = new Chart(document.getElementById("diseaseChart"), {
                        type: 'bar',
                                data: {labels: <?php echo $disease_label; ?>, datasets: <?php echo $disease_datasets; ?>, data: <?php echo $disease_id; ?>},
                                options: {
                                legend: {display: false, onClick: (e) => e.stopPropagation()},
                                        title: {display: true},
                                        scales: {yAxes: [{ticks: {beginAtZero: true}}], xAxes: [{ticks: {autoSkip: false}}]}
                                }
                        });
<?php } ?>

<?php if (empty($hospital_datasets)) {
    
} else {
    ?>
                        // Hospital Bar Chart
                        var hospitalChart = new Chart(document.getElementById("hospitalChart"), {
                        type: 'bar',
                                data: {labels: <?php echo $hospital_label; ?>, datasets: <?php echo $hospital_datasets; ?>, data: <?php echo $hospital_id; ?>},
                                options: {
                                legend: {display: false, onClick: (e) => e.stopPropagation()},
                                        title: {display: true},
                                        scales: {yAxes: [{ticks: {beginAtZero: true}}], xAxes: [{ticks: {autoSkip: false}}]}
                                }
                        });
<?php } ?>

<?php if (empty($user_datasets)) {
    
} else {
    ?>
                        // User Wise Bar Chart
                        if (document.getElementById("userChart")) {
                        var userChart = new Chart(document.getElementById("userChart"), {
                        type: 'bar',
                                data: {labels: <?php echo $user_label; ?>, datasets: <?php echo $user_datasets; ?>, data: <?php echo $user_id; ?>},
                                options: {
                                legend: {display: false, onClick: (e) => e.stopPropagation()},
                                        title: {display: true},
                                        scales: {yAxes: [{ticks: {beginAtZero: true}}], xAxes: [{ticks: {autoSkip: false}}]}
                                }
                        });
                        }
<?php } ?>

<?php if (empty($donor_datasets)) {

} else {
    ?>
        // Donor Wise Bar Chart  
        var ctx = document.getElementById('donorChart');

        var donorChart = new Chart(ctx, {


            type: 'bar',
            data: { labels:<?php echo $donor_label; ?>,datasets: <?php echo $donor_datasets ?>,data: <?php echo $donor_id; ?>
                },

            options: {

                legend: {display: true, onClick: (e) => e.stopPropagation()},
                        title: {display: true},
                        scales: {yAxes: [{stacked: true}], 
                        xAxes: [{stacked: true}]}

                }


                // type: 'bar',
                // data:  {
                    // labels: <?php echo $donor_label; ?>,
                    // datasets: <?php echo $donor_datasets ?>,
                    // data: <?php echo $donor_id; ?>
                    // },
                    // data:  {labels: ["Empire Industries Ltd.","Kotak Mahindra Bank Ltd.","Tech Mahindra Foundation","Voltas Ltd.","Mahindra Foundation","HT Parekh Foundation","Universal Compfort Product Ltd.","KARO  ","Janus Consultants LLP","IREP Credit Capital","Westwind  Association","Unutilized  Fund"], datasets: [{"data":["34353271.00","15159000.00","1150000.00","1466540.00","59676247.00","13920958.00","2393000.00","5616000.00","300000.00","360000.00","200000.00","844703.00"],"label":"Total Approved Amount","backgroundColor":["#876cb1","#d5d871","#d24e06","#8a3aae","#11477e","#bd4755","#840e19","#4d872f","#81dc1a","#793888","#3ef073","#a65488"]},{"data":["39346771.00","20000000.00","15094456.00","1800000.00","70000000.00","19500000.00","2500000.00","13900001.00","400000.00","500000.00","200000.00","1659703.00"],"label":"Total Donated Amount","backgroundColor":["#d6378b","#cbb02a","#6b026e","#a50473","#1876ce","#624fa3","#0535ec","#9f8b60","#457592","#e1fb35","#df4ca5","#52b641"]},{"data":["19967236.00","6600000.00","750000.00","555000.00","36603506.00","9280000.00","1279000.00","1190971.00"],"label":"Total Disbursed Amount","backgroundColor":["#418b0f","#cffac6","#f2d81d","#d8620f","#0c177d","#2aea47","#e9b129","#7364f3"]}], data: ["1","2","3","4","5","6","7","8","9","10","11","12"]},
                
                
                    
                    // options: {

                // legend: {display: true, onClick: (e) => e.stopPropagation()},
                        // title: {display: true},
                            // scales: {yAxes: [{stacked: true}], 
                        // xAxes: [{stacked: true}]}

                // }
        }); 
						


<?php } ?>

                function openChartData(chartId, evt) {
                    if (chartId == 'ageChartDob') {
                    var category = 'agedob';
                            var chartObj = ageChartDob;
                    } 
					else if (chartId == 'ageChart') {
                    var category = 'age';
                           var chartObj = ageChart;
                    } else if (chartId == 'genderChart') {
                    var category = 'gender';
                            var chartObj = genderChart;
                    } else if (chartId == 'stateChart') {
                    var category = 'state';
                            var chartObj = stateChart;
                    } else if (chartId == 'diseaseChart') {
                    var category = 'disease';
                            var chartObj = diseaseChart;
                    } else if (chartId == 'hospitalChart') {
                    var category = 'hospital';
                            var chartObj = hospitalChart;
                    } else if (chartId == 'userChart') {
                    var category = 'user1';
                            var chartObj = userChart;
                    }else if (chartId == 'donorChart') {
                    var category = 'donor';
                            var chartObj = donorChart;
                    }
                    var chartElm = document.getElementById(chartId);
                            //chartElm.onclick = function (evt) {
                            var activePoints = chartObj.getElementsAtEvent(evt);
                            if (activePoints[0]) {
                    var idx = activePoints[0]['_index'];
                            var chartData = activePoints[0]['_chart'].config.data;
                            var value = chartData.data[idx];
                            var label = chartData.labels[idx];
                            
                            if(category === "donor"){
                                var url = "<?php echo base_url(); ?>index.php/Reports/filterPatientsDonorWiseFinacialReports/?category=" + category + "&donor=" + value + "&label=" + label;
                            }else{
                                var url = "<?php echo base_url(); ?>index.php/patientmaster/viewSelectedPatient/?category=" + category + "&id=" + value + "&label=" + label;
                            }
                            
                            window.open(url, '_blank');
                    }
                    //};
                }
    </script>