<style>
    label.error{
        color:red;
    }
    .mandate{
        color:red;
    }
</style>
<div class="dash_right_section">
    <h2 class="main-heading">Hospitals Master</h2>
    <?php if (isset($_REQUEST['act'])) { ?>
        <?php if ($_REQUEST['act'] == 'update') { ?>
            <?php
            $attributes = array('class' => 'hospital', 'id' => 'hospital');
            echo form_open('hospital/updatehospital', $attributes);
            $values = explode("|", base64_decode($_REQUEST['id']));
            ?>
            <div class="dash_column">
                <div><?php echo $this->session->flashdata('message'); ?></div>

                <div class="row">
                    <div class="form-group col-md-4">
                        <input id="HospitalId" name="HospitalId" value="<?php echo base64_encode($values[0]); ?>" type="hidden" class="form-control specialchr">
                        <label for="name">Hospital Name<span class="mandate">*</span></label>
                        <input id="HospitalName" name="HospitalName" type="text" class="form-control" placeholder="Enter Hospital Name" value="<?php echo $values[1]; ?>">
                    </div>
                    <div class="form-group  col-md-4">
                        <label for="name">Address<span class="mandate">*</span></label>
                        <textarea class="form-control" name="address" placeholder="Address"><?php echo $values[6]; ?></textarea>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="name">State<span class="mandate">*</span></label>
                        <select id="state" name="state"  class="form-control" onchange="getcities(this.value, 'city');">
                            <option value=""> Select State</option>
                            <?php foreach ($states as $state) { ?>
                                <option value="<?php echo $state['city_state']; ?>" <?php if ($values[3] == $state['city_state']) {
                        echo "selected='selected'";
                    } ?> ><?php echo $state['city_state']; ?></option>
        <?php } ?>
                        </select>
                    </div>
                    

                    </div>
                    <div class="row">
                    <div class="form-group col-md-4">
                        <label for="name">City<span class="mandate">*</span></label>
                        <select id="city" name="city"  class="form-control" onchange="">
                            <option value=""> Select City</option>  
                            <?php
                            if (!empty($cities)) {
                                foreach ($cities as $city) {
                                    if ($city['city_name'] == $values[5]) {
                                        $selected = "selected='selected'";
                                    } else {
                                        $selected = '';
                                    }
                                    echo "<option value='" . $city['city_name'] . "' " . $selected . ">" . $city['city_name'] . "</option>";
                                }
                            }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Pin Code<span class="mandate">*</span></label>
                            <input id="zipcode" name="zipcode" type="text" class="form-control" placeholder="Enter Pin code" value="<?php echo $values[4]; ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Contact No<span class="mandate">*</span></label>
                            <input id="contact_no" name="contact_no" type="text" class="form-control" placeholder="Enter contact no" value="<?php echo $values[2]; ?>">
                        </div>
                    </div>
                    <input type="submit" class="btn btn-primary save" name="save" value="Save">
                    <div class="clearfix"></div>
                </div>
            </form>
        <?php }
    } else { ?>
        <?php
        $attributes = array('class' => 'hospital', 'id' => 'hospital');
        echo form_open('hospital/index', $attributes);
        ?>
        <div class="dash_column">
            <div><?php echo $this->session->flashdata('message'); ?></div>
            <div class="row">
                <div class="form-group col-md-4">
                    <label for="name">Hospital Name<span class="mandate">*</span></label>
                    <input id="HospitalName" name="HospitalName" type="text" class="form-control" placeholder="Enter Hospital Name">
                </div>
                <div class="form-group col-md-4">
                <label for="name">Address<span class="mandate">*</span></label>
                <textarea class="form-control" name="address" placeholder="Address"></textarea>
            </div>
                <div class="form-group col-md-4">
                    <label for="name">State<span class="mandate">*</span></label>
                    <select id="state" name="state"  class="form-control" onchange="getcities(this.value, 'city');">
                        <option value=""> Select State</option>
        <?php foreach ($states as $state) { ?>
                            <option value="<?php echo $state['city_state']; ?>"><?php echo $state['city_state']; ?></option>
        <?php } ?>
                    </select>
                </div>
                

            </div>
            <div class="row">
            <div class="form-group col-md-4">
                    <label for="name">City<span class="mandate">*</span></label>
                    <select id="city" name="city"  class="form-control" onchange="">
                        <option value=""> Select City</option>    
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="name">Pin Code<span class="mandate">*</span></label>
                    <input id="zipcode" name="zipcode" type="text" class="form-control" placeholder="Enter pin code">
                </div>
                <div class="form-group col-md-4">
                    <label for="name">Contact No<span class="mandate">*</span></label>
                    <input id="contact_no" name="contact_no" type="text" class="form-control" placeholder="Enter contact no">
                </div>
            </div>
            
            <input type="submit" class="btn btn-primary save" name="save" value="Save">
            <div class="clearfix"></div>
        </div>
        </form>
    <?php } ?>
    <div class="dash_column">
        <div class="tbl">
             <table id="disease" class="table table-striped table-bordered">

                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Contact No</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Pin Code</th>                
                        <th>Address</th>
                         <th>Status</th>
                        <th>Action</th>
                        <!-- <th></th> -->
                    </tr>
                </thead>
                <tbody>
    <?php
    if (!empty($hospitals)) {
        foreach ($hospitals as $hospital) {
            ?>
                            <tr>
                                <td><?php echo $hospital['HospitalName']; ?></td>
                                <td><?php echo $hospital['ContactNo']; ?></td>
                                <td><?php echo $hospital['City']; ?></td>
                                <td><?php echo $hospital['State']; ?></td>
                                <td><?php echo $hospital['ZipCode']; ?></td>
                                <td><?php echo $hospital['Address']; ?></td>
                                 <td> <?php
                            if ($hospital['IsActive'] == '1') {
                                echo "Active";
                            } else {
                                echo "Inactive";
                            }
                            ?></td>
                                <td><a class='btn btn-info btn-xs' href="?act=update&id=<?php echo base64_encode($hospital['HospitalId'] . "|" . $hospital['HospitalName'] . "|" . $hospital['ContactNo'] . "|" . $hospital['State'] . "|" . $hospital['ZipCode'] . "|" . $hospital['City'] . "|" . $hospital['Address']); ?>" title="Edit"><i class="fa fa-edit"></i></a>

                                <a id='editref' href="javascript:void(0);" data-url="<?php echo site_url(); ?>/hospital/changestatus?status=<?php echo $hospital['IsActive']; ?>&id=<?php echo base64_encode($hospital['HospitalId']); ?>" title="<?php
                                       if ($hospital['IsActive'] == '1') {
                                           echo "click here to inactive";
                                       } else {
                                           echo "click here to active";
                                       }
                                       ?>" class="btn btn-<?php if ($hospital['IsActive'] == '0') {
                                echo "primary";
                            } else {
                                echo "danger";
                            } ?> btn-xs" onclick="changeStatusDynamically($(this),'Are you sure you want to <?php if ($hospital['IsActive'] == '1') {
                                echo "Deactivate";
                            } else {
                                echo "Activate";
                            } ?> this hospital ?');">
                            <?php
                            if ($hospital['IsActive'] == '1') {
                                // echo "Deactivate";
                                echo '<i class="fa fa-toggle-off"></i>';

                            } else {
                                // echo "Activate";
                                echo '<i class="fa fa-toggle-on"></i>';

                            }
                            ?>
                                    </a></td>
                            </tr>
        <?php }
    }
    ?>   

            </tbody>
        </table>
    </div>
</div>


</div>