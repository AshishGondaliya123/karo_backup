<style>
    .btn-xs{ margin-right:5px !important; margin-top:0;}
</style>
<div class="dash_right_section">
    <div><?php echo $this->session->flashdata('message'); ?></div>
    <h2 class="main-heading">DEPARTMENT MASTER</h2>
    <?php if (isset($_REQUEST['act'])) { ?>
        <?php if ($_REQUEST['act'] == 'update') { ?>
            <?php echo form_open('hospital/changedeptName'); ?>
            <div class="dash_column">
                <div class="diseases">
                    <div class="form-group">
                        <label for="name">Department Name</label>
                        <span class="mandate">*</span>
                        <?php $values = explode("_", base64_decode($_REQUEST['id'])); ?>
                        <input id="dept_id" name="dept_id" value="<?php echo base64_encode($values[0]); ?>" type="hidden" class="form-control specialchr">
                        <input id="dept_name" name="dept_name" maxlength="100" type="text" class="form-control" value = "<?php echo $values[1]; ?>" placeholder="Enter department name" onkeypress ="removeValidation();">
                        <span id="errormsg" style="color:red"></span>
                    </div>
                    <input type="submit" name="save" class="btn btn-primary save" value="Update" onclick="return checkfield('dept_name');">
                    <div class="clearfix"></div>

                </div>
            </div>
        </form>
        <?php
    }
} else {
    ?>
    <?php echo form_open('hospital/save_dept'); ?>
    <div class="dash_column">
        <div class="diseases">
            <div class="form-group">
                <label for="name">Department Name</label>
                <span class="mandate">*</span>
                <input id="dept_name" name="dept_name" maxlength="100" type="text" class="form-control" placeholder="Enter department name" onkeypress ="removeValidation();">
                <span id="errormsg" style="color:red"></span>
            </div>
            <input type="submit" name="save" class="btn btn-primary save" value="Save" onclick="return checkfield('dept_name');">
            <div class="clearfix"></div>

        </div>
    </div>
    </form>
<?php } ?>
<div class="dash_column">
    <div class="tbl">
        <table id="disease" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Department Name</th> 
                    <th>Status</th>          
                    <th>Actions</th>
                </tr>
            </thead>
            <?php
            if (!empty($department)) {
                foreach ($department as $department) {
                    ?>
                    <tr>
                        <td><?php echo $department['DeptName']; ?></td>
                        <td>    <?php
                            if ($department['IsActive'] == '1') {
                                echo "Active";
                            } else {
                                echo "Inactive";
                            }
                            ?></td>

                        <td><a class='btn btn-info btn-xs' href="?act=update&id=<?php echo base64_encode($department['DeptId'] . "_" . $department['DeptName']); ?>" title="Edit"><i class="fa fa-edit"></i></a>

                            <a href="javascript:void(0);" data-url="<?php echo site_url(); ?>/hospital/changedeptstatus?status=<?php echo $department['IsActive']; ?>&id=<?php echo base64_encode($department['DeptId']); ?>" title="<?php
                            if ($department['IsActive'] == '1') {
                                echo "click here to inactive";
                            } else {
                                echo "click here to active";
                            }
                            ?>" class="btn btn-<?php
                               if ($department['IsActive'] == '0') {
                                   echo "primary";
                               } else {
                                   echo "danger";
                               }
                               ?> btn-xs" onclick="changeStatusDynamically($(this), 'Are you sure to <?php
                               if ($department['IsActive'] == '1') {
                                   echo "Inactive";
                               } else {
                                   echo "Active";
                               }
                               ?> this disease name ?');">
                                   <?php
                                   if ($department['IsActive'] == '1') {
                                       //echo "Deativate";
                                       ?>
                                    <i class="fa fa-toggle-off"></i>
                                    <?php
                                } else {
                                    //echo "Activate";
                                    ?>
                                    <i class="fa fa-toggle-on"></i>
                                <?php }
                                ?>
                            </a>
                        </td>
                    </tr>
                    <?php
                }
            }
            ?>   
        </table>
    </div>
</div>
</div>