<style>
    label.error{
        color:red;
    }
    .mandate{
        color:red;
    }

.hide {
  display: none;
}

.clear {
  float: none;
  clear: both;
}

.rating {
    width: 110px;
    unicode-bidi: bidi-override;
    direction: rtl;
    text-align: center;
    position: relative;
}

.rating > label {
    float: right;
    display: inline;
    padding: 0;
    margin: 0;
    position: relative;
    width: 1.1em;
    cursor: pointer;
    color: #000;
	font-size:20px;
}

.rating > label:hover,
.rating > label:hover ~ label,
.rating > input.radio-btn:checked ~ label {
    color: transparent;
}

.rating > label:hover:before,
.rating > label:hover ~ label:before,
.rating > input.radio-btn:checked ~ label:before,
.rating > input.radio-btn:checked ~ label:before {
    content: "\2605";
    position: absolute;
    left: 0;
    color: #ff6600;
}
    /*.rating:not(:checked) > input {
        position:absolute;
        top:-9999px;
        clip:rect(0,0,0,0);
    }

    .rating:not(:checked) > label {
        float:left;
        overflow:hidden;
        white-space:nowrap;
        cursor:pointer;
        font-size:190%;
        color:#ddd;
    }

    .rating:not(:checked) > label:before {
        content: '★ ';
    }

    .rating > input:checked ~ label {
        color:  #ff6600;

    }

    .rating:not(:checked) > label:hover,
    .rating:not(:checked) > label:hover ~ label {
        color:  #ff6600;

    }

    .rating > input:checked + label:hover,
    .rating > input:checked + label:hover ~ label,
    .rating > input:checked ~ label:hover,
    .rating > input:checked ~ label:hover ~ label,
    .rating > label:hover ~ input:checked ~ label {
        color: #ff6600;

    }

    .rating > label:active {
        position:relative;
        top:2px;
        left:2px;
    }*/
    .fileList li {
        display: inline-block;
        padding: 15px 10px;
        box-shadow: 0px 0px 4px rgba(0,0,0,10%);
        margin-top: 10px;
        width: 100%;
        position:relative
    }
    .removeFile {
        position: absolute;
        right: 25px;
        font-size:0;
    }
    .removeFile::after {
        position: absolute;
        content: "\f00d";
        color: #666;
        font-size: 14px;
        font-family: FontAwesome;
        font-weight: normal;
    }
    .removeFile:hover::after{ color:#000}
    .filCol{box-shadow: 0px 0px 4px rgba(0,0,0,10%); padding:8px; margin-bottom:10px;}
    .filCol .first {
        font-size: 13px;
        font-weight: 400;
        color: #989da2;
        font-family: roboto;
    }
    .filCol .last{ float:right;}
    .medication.doc .checkSec{ margin-bottom:15px;}
	.tbl .table td:last-child, .tbl .table th:last-child {
	width: auto !important;

}
</style>

<?php
$cid = $case["id"];
?>

                                <input type="hidden" name="icount" value="<?php echo count($followup)-1;?>" id="icount">

<!--==============================Start Page=====================================-->
<div class="dash_right_section">
    <div>
        <?php if ($this->session->flashdata('msg')) { ?>
            <div class="alert alert-success"><?php echo $this->session->flashdata('msg'); ?></div>
        <?php } ?>
    </div>
    <h2 class="main-heading">Case</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle green"><img src="<?php echo base_url('karoclient/images/patient-id.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Patient Id </h3>
                    <p><?php echo $patient['patient_id'] ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink"><img src="<?php echo base_url('karoclient/images/patient-name.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Patient Name</h3>
                    <p><?php echo $patient['patient_name'] ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle blue"><img src="<?php echo base_url('karoclient/images/mobile.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Mobile No.</h3>
                    <p><?php echo!empty($patient['patient_phone']) ? $patient['patient_phone'] : $patient['caregiver_phone'] ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle yellow"><img src="<?php echo base_url('karoclient/images/case.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Case No.</h3>
                    <p><?php echo $case['case_number'] ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle green"><img src="<?php echo base_url('karoclient/images/status.png'); ?>"></div>
                <div class="cirtext">
                    <h3>Case Status</h3>
                    <p><?php echo $case['case_status'] ? $case['case_status'] : "New" ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="circle pink"><img src="<?php echo base_url('karoclient/images/user.png'); ?>"></div>
                <div class="cirtext">
                    <h3>KARO User</h3>
                    <!-- <p><?php echo $createdby['UserName'] ?></p> -->
                    <p><?php echo $createdby; ?></p>

                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="tab-sec">
        <?php $task = $this->input->get('task'); ?>
        <ul class="nav nav-tabs">
            <li class="active" id="med_details"><a href="#medical_details" data-toggle="tab" aria-expanded="true">Medical Details</a></li>
            <li class="" id="fin_details"><a href="#financial_details" data-toggle="tab" aria-expanded="false">Financial Details</a></li>
            <li class=""><a href="#documents" data-toggle="tab" aria-expanded="false">Documents Provided By Patient</a></li>
            <li class=""><a href="#karo_notes" data-toggle="tab" aria-expanded="false">Karo Notes</a></li>
            <li class="" id="fol_details"><a href="#follow_up_details" data-toggle="tab" aria-expanded="false">Follow Up Details</a></li>
        </ul>
        <div class="clearfix"></div>  
        <div class="panel-body">
            <div class="tab-content">
                <div class="tab-pane fade active in" id="medical_details">
                    <?php
                    $attributes = array('name' => 'save_case', 'id' => 'save_case');
                    echo form_open("patientcase/save/?cid=$cid", $attributes);
                    ?>
                    <h3 class="sub-haeding">Patient's Medical Details</h3>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">Blood Group</label>
                            <select id="blood_group" name='blood_group' class="form-control">
                                <option value='' <?php echo ($case && $case['blood_group'] == '') ? "selected" : "" ?>>Blood Group</option>
                                <option value='AB+' <?php echo ($case && $case['blood_group'] == 'AB+') ? "selected" : "" ?>>Blood Group AB+</option>
                                <option value='AB-' <?php echo ($case && $case['blood_group'] == 'AB-') ? "selected" : "" ?>>Blood Group AB-</option>
                                <option value='A+' <?php echo ($case && $case['blood_group'] == 'A+') ? "selected" : "" ?>>Blood Group A+</option>
                                <option value='A-' <?php echo ($case && $case['blood_group'] == 'A_') ? "selected" : "" ?>>Blood Group A-</option>
                                <option value='B+' <?php echo ($case && $case['blood_group'] == 'B+') ? "selected" : "" ?>>Blood Group B+</option>
                                <option value='B-' <?php echo ($case && $case['blood_group'] == 'B_') ? "selected" : "" ?>>Blood Group B-</option>
                                <option value='O+' <?php echo ($case && $case['blood_group'] == 'O+') ? "selected" : "" ?>>Blood Group O+</option>
                                <option value='O-' <?php echo ($case && $case['blood_group'] == 'O-') ? "selected" : "" ?>>Blood Group O-</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="name">Hospital Name</label>
                            <span class="mandate">*</span>
                            <select id="hospital_name" name='hospital_name' class="form-control">
                                <option value="">Select Hospital Name </option>
                                <?php
                                if ($hospital_name) {
                                    foreach ($hospital_name as $k => $v) {
                                        ?>
                                        <option value="<?php echo $v['HospitalId']; ?>" <?php echo ($v['HospitalId'] == $case['hospital_name']) ? "selected" : "" ?>  ><?php echo $v['HospitalName']; ?> </option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                            <!--<input id="hospital_name" name='hospital_name' value='<?php echo ($case && $case['hospital_name']) ? $case['hospital_name'] : "" ?>' type="text" class="form-control" placeholder="Enter hospital name">-->
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">Department and Ward</label>
                            <span class="mandate">*</span>
                            <input id="department_name" name="department_name" maxlength="50" value='<?php echo ($case && $case['department_name']) ? $case['department_name'] : "" ?>' type="text" class="form-control" placeholder="Enter department/ward">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="name">Doctor's Name</label>
                            <span class="mandate">*</span>
                            <input id="doctor_name" maxlength="50" name="doctor_name" value='<?php echo ($case && $case['doctor_name']) ? $case['doctor_name'] : "" ?>' type="text" class="form-control" placeholder="Enter doctor name">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">Current diagnosed illness</label>
                                <span class="mandate">*</span>
                                <select id="disease_name" name='disease_diagnosed' class="form-control">
                                    <option value="">Select Disease Name</option>
                                    <?php
                                    if ($diseases) {
                                        foreach ($diseases as $k1 => $v1) {
                                            ?>
                                            <option value="<?php echo $v1['DiseaseId']; ?>" <?php echo ($v1['DiseaseId'] == $case['disease_diagnosed']) ? "selected" : "" ?> ><?php echo $v1['DiseaseName']; ?> </option>

                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="name">Diagnosed details and medical requirement's</label>
                                <span class="mandate">*</span>
                                <textarea class="form-control text-add" rows="5"  id="current_diagnosed_detail"  name="current_diagnosed_detail" placeholder="Current diagnosed detail"><?php echo ($case && trim($case['current_diagnosed_detail'])) ? $case['current_diagnosed_detail'] : "" ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group control-group">
                                <label for="name">When was illness/problem detected</label>
                                <span class="mandate">*</span>
                                <input id="problem_detected_date" name="problem_detected_date" type="text" class="form-control defaultdater" value='<?php echo ($case && $case['problem_detected_date']) ? $case['problem_detected_date'] : "" ?>' placeholder="Enter illness/problem date" readonly>
                                <span class="add-on"><i class="icon-remove"></i></span>
                                <span class="add-on"><i class="icon-th"></i></span>
                                <input type="hidden" id="dtp_input1" value="" />
                            </div>
                            <div class="form-group">
                                <label for="name">How much of the treatment is currently completed</label>
                                <span class="mandate">*</span>
                                <textarea id="treatment_completed_details" name="treatment_completed_details" class="form-control text-add valid" placeholder="Enter treatment completed details" rows="5" style="height:100px;"><?php echo ($case && $case['treatment_completed_details']) ? trim($case['treatment_completed_details']) : "" ?></textarea>
                            </div>
                        </div>
                    </div>
                    <hr/>
                    <h3 class="sub-haeding">Path to Healing</h3>
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="name">How long does the doctor say it will take to heal completely and what needs to be done to ensure that</label>
                            <span class="mandate">*</span>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Week</span>
                                        <input type="radio"  name="healing_time" value='Week' <?php echo ($case && $case['healing_time'] == 'Week') ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Month</span>
                                        <input type="radio"  name="healing_time" value='Month' <?php echo ($case && $case['healing_time'] == 'Month') ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Year</span>
                                        <input type="radio"  name="healing_time" value='Year' <?php echo ($case && $case['healing_time'] == 'Year') ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Life long</span>
                                        <input type="radio"  name="healing_time" value='Life long' <?php echo ($case && $case['healing_time'] == 'Life long') ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <label id="healing_time-error" class="error" for="healing_time" style="display:none">This field is required.</label>
                        </div>
                        <div class="form-group col-md-12">
                            <textarea class="form-control text-add" rows="5" maxlength="500" id="path_to_heal" name="path_to_heal" placeholder="Enter path to heal"><?php echo ($case && $case['path_to_heal']) ? $case['path_to_heal'] : "" ?></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="name">What medication is patient taking currently</label>
                            <span class="mandate">*</span>
                            <div class="medication">
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Pre surgery / Transplant 
                                            <input type="checkbox" value="pre_surgery_or_transplant" name="medication[]" id='pre_surgery_or_transplant' <?php echo ($case && $case['pre_surgery_or_transplant'] == '1') ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Medicines  
                                            <input type="checkbox" value="medicines" name="medication[]" id='medicines' <?php echo ($case && $case['medicines'] == '1') ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Hospitalized   
                                            <input type="checkbox" value="hospitalized" name="medication[]" id="hospitalized" <?php echo ($case && $case['hospitalized'] == '1') ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Post-surgery / Treatment   
                                            <input type="checkbox" value="post-surgery_or_treatment" name="medication[]" id='post-surgery_or_treatment' <?php echo ($case && $case['post-surgery_or_treatment'] == '1') ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>

                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Exercise   
                                            <input type="checkbox" value="exercise" name="medication[]" id='exercise' <?php echo ($case && $case['exercise'] == '1') ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            
                            <label id="medication[]-error" class="error" for="medication[]" style="display:none">This field is required.</label>
                        </div>
                        <div class="form-group col-md-12">
                        <textarea id ="medicines_details" name="medicines_details" class="form-control text-add" rows="5" placeholder="Enter medicine details" style="<?php echo ($case['medicines'] !=1)?'display: none':'';?>"><?php echo ($case && $case['medicines_details']) ? trim($case['medicines_details']) : ""; ?></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12 caseBtn">
                            <input type='submit' class="form-group button primary btn btn-primary add" id='submit1' value='Submit'>

                            <?php if ($case['case_status'] == 'open') { ?>


                                <a class="btn btn-primary add" data-toggle="modal" data-caseid="<?php echo $cid; ?>" data-type="closed" title="Close"  id="class_close_open_case">Close</a>

                                <a class="btn btn-primary add" href="<?php echo base_url() . 'index.php/Caseinfo/loadRehelp?patient_id=' . $patient['patient_id'] . '&cid=' . $cid; ?>" title="Rehelp" >Rehelp</a>
                            <?php } if ($case['case_status'] == 'closed') { ?>
                                <a class="btn btn-primary add" href="<?php echo base_url() . 'index.php/Caseinfo/loadRehelp?patient_id=' . $patient['patient_id'] . '&cid=' . $cid; ?>" title="Rehelp" >Reopen</a>



                            <?php } ?>
                        </div>
                    </div>

                    <div class="clearfix"></div>
                    </form>

                </div>
                <div class="tab-pane fade" id="financial_details">

                    <?php
                    $attributes = array('name' => 'save_financial', 'id' => 'save_financial');
                    echo form_open("patientcase/savefin/?cid=$cid", $attributes);
                    ?>
                    <input type="hidden" name="financial[finance_id]" id="finance_id" value="<?php echo ($finance && $finance['id']) ? $finance['id'] : "" ?>">
                    <h3 class="sub-haeding">Financial Details</h3>

                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="name">Assets owned by patient/patient's guardian and family (e.g.: house, land, shop, vehicle etc)</label>
                            <div class="medication">
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            House
                                            <input type="checkbox" name="financial[owned_house]" id="owned_house" value="1" <?php echo ($finance && $finance['owned_house'] == '1') ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Land  
                                            <input type="checkbox" name="financial[owned_land]" id="owned_land" value="1" <?php echo ($finance && $finance['owned_land'] == '1') ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Shop 
                                            <input type="checkbox" name="financial[owned_shop]" id="owned_shop" value="1" <?php echo ($finance && $finance['owned_shop'] == '1') ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Vehicle
                                            <input type="checkbox" name="financial[owned_vechicle]" id="owned_vechicle"  value="1" <?php echo ($finance && $finance['owned_vechicle'] == '1') ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Other
                                            <input type="checkbox" name="financial[owned_other]" id="owned_other" value="1" <?php echo ($finance && $finance['owned_other'] == '1') ? "checked='true'" : "" ?> onchange="this.checked == true ? document.getElementById('other_accets_details').style.display = '' : document.getElementById('other_accets_details').style.display = 'none';$('#other_accets_details').val('')">
                                            <span></span>
                                        </div>			 
                                    </label></div>


                                    <textarea maxlength="500" name="financial[other_accets_details]"   placeholder="Other assets details" id="other_accets_details" class="form-control"  style="height:auto;<?php if($finance['owned_other'] != 1) echo "display:none;";?> "><?php echo ($finance && $finance['other_accets_details']) ? trim($finance['other_accets_details']) : ""; ?></textarea>

                                <!-- <textarea  name="financial[other_accets_details]"   placeholder="Other assets details" id="other_accets_details" class="form-control" style="height:auto;<?php if(empty($finance['other_assets_details'])) echo "display:none;";?> ">
                                    <?php echo ($finance && $finance['other_accets_details']) ? $finance['other_assets_details'] : "" ?> 
                                </textarea> -->
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="form-group" style="margin:0 15px;">
                            <label for="name" >Fixed monthly costs of patient</label>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Rent</label>
                            <input maxlength="20" name="financial[rent_amount]" placeholder="0.00" id="rent_amount" value="<?php echo ($finance && $finance['rent_amount']) ? $finance['rent_amount'] : "" ?>" type="text" class="form-control allowdecimal ">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">School Fee</label>
                            <input maxlength="20" id="school_fees_amount" placeholder="0.00" name="financial[school_fees_amount]" type="text" class="form-control allowdecimal" value="<?php echo ($finance && $finance['school_fees_amount']) ? $finance['school_fees_amount'] : "" ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Cable</label>
                            <input maxlength="20" id="cable_amount" name="financial[cable_amount]" placeholder="0.00" value="<?php echo ($finance && $finance['cable_amount']) ? $finance['cable_amount'] : "" ?>" type="text" class="form-control allowdecimal" >
                        </div>

                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="name">Electricity</label>
                            <input maxlength="20" id="electric_city_amount" placeholder="0.00" name="financial[electric_city_amount]" value="<?php echo ($finance && $finance['electric_city_amount']) ? $finance['electric_city_amount'] : "" ?>" type="text" class="form-control allowdecimal" >
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Food</label>
                            <input maxlength="20" id="food_amount" name="financial[food_amount]" placeholder="0.00" type="text" value="<?php echo ($finance && $finance['food_amount']) ? $finance['food_amount'] : "" ?>" class="form-control allowdecimal" >
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Transport</label>
                            <input maxlength="20" id="transport_amount" name="financial[transport_amount]" placeholder="0.00" value="<?php echo ($finance && $finance['transport_amount']) ? $finance['transport_amount'] : "" ?>" type="text" class="form-control allowdecimal" >
                        </div>

                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="name">Other</label>
                            <input maxlength="20" id="other_expense_amount" name="financial[other_expense_amount]" placeholder="0.00" value="<?php echo ($finance && $finance['other_expense_amount']) ? $finance['other_expense_amount'] : "" ?>" type="text" class="form-control allowdecimal" >
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">How much has patient spent on treatment already</label>
                            <input maxlength="20" class="form-control allowdecimal" value="<?php echo ($finance && $finance['money_already_expend']) ? $finance['money_already_expend'] : "" ?>" id="money_already_expend" name="financial[money_already_expend]" placeholder="0.00">
                        </div> 
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="name">Did he/she have to sell any assets to pay for treatment so far?</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[sale_any_assest]" value="1" <?php echo ($finance && $finance['sale_any_assest'] == 1) ? "checked='true'" : "" ?> onclick ="if( $(this).prop('checked')) $('#sale_assest_detail').show();">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[sale_any_assest]" value="0" <?php echo ($finance && !$finance['sale_any_assest']) ? "checked='true'" : "" ?> onclick ="if( $(this).prop('checked')) $('#sale_assest_detail').hide(); $('#sale_assest_detail').val('')">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                            <br>
                            <textarea maxlength="500" id="sale_assest_detail" name="financial[sale_assest_detail]" class="form-control text-add" style="margin:10px 0 0  ;<?php echo ($finance && ($finance['sale_any_assest'] ==1)) ? "display:block" : "display:none" ?>"><?php echo ($finance && $finance['sale_assest_detail']) ? $finance['sale_assest_detail'] : "" ?></textarea>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Does he / she have any loans or mortgages <br>currently?</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[any_loan]" value="1" <?php echo ($finance && $finance['any_loan'] == 1) ? "checked='true'" : "" ?> onclick="if($(this).prop('checked')) $('#loan_detail').show();" >
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[any_loan]" value="0" <?php echo ($finance && !$finance['any_loan']) ? "checked='true'" : "" ?> onclick="if($(this).prop('checked')) $('#loan_detail').hide(); $('#loan_detail').val('');">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                            <br>
                            <textarea maxlength="500" id="loan_detail" name="financial[loan_detail]" class="form-control text-add" style="margin:10px 0 0; <?php echo ($finance && $finance['loan_detail']) ? "display:block" : "display:none" ?>"><?php echo ($finance && $finance['loan_detail']) ? $finance['loan_detail'] : "" ?></textarea>

                           <!--  <input id="loan_detail" name="financial[loan_detail]" value="<?php echo ($finance && $finance['loan_detail']) ? $finance['loan_detail'] : "" ?>" type="text" class="form-control" style="<?php echo ($finance && $finance['loan_detail'] == 1) ? "display:block" : "display:none" ?>"> -->
                        </div>
                        <div class="form-group col-md-4">
                            <label for="name">Does the patient have insurance? Add details of insurance / mediclaim</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[insurance_or_Medicalim]" value="1" <?php echo ($finance && $finance['insurance_or_Medicalim'] == 1) ? "checked='true'" : "" ?> onclick="if($(this).prop('checked')) $('#insurance_detail').show();">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[insurance_or_Medicalim]" value="0" <?php echo ($finance && !$finance['insurance_or_Medicalim']) ? "checked='true'" : "" ?> onclick="if($(this).prop('checked')) $('#insurance_detail').hide(); $('#insurance_detail').val('');">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                            <br>
                            <textarea maxlength="500" id="insurance_detail" name="financial[insurance_detail]" class="form-control text-add" style="margin:10px 0 0 ; <?php echo ($finance && $finance['insurance_detail']) ? "display:block" : "display:none" ?>"><?php echo ($finance && $finance['insurance_detail']) ? $finance['insurance_detail'] : "" ?></textarea>
                            
                            <!-- <input id="insurance_detail" name="financial[insurance_detail]" value="<?php echo ($finance && $finance['insurance_detail']) ? $finance['insurance_detail'] : "" ?>" style="<?php echo ($finance && $finance['insurance_or_Medicalim'] == 1) ? "display:block" : "display:none" ?>"  type="text" class="form-control"> -->
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="name">How did patient manage treatment expenses so far?</label>
                            <div class="medication">
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Own savings
                                            <input type="checkbox" name="financial[treatment_expenses_own]" id="treatment_expenses_own" value="1" <?php echo ($finance && $finance['treatment_expenses_own'] == 1) ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Relatives  
                                            <input type="checkbox" name="financial[treatment_expenses_relatives]" id="treatment_expenses_relatives" value="1" <?php echo ($finance && $finance['treatment_expenses_relatives'] == 1) ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Friends
                                            <input type="checkbox" name="financial[treatment_expenses_friend]" id="treatment_expenses_friend" value="1" <?php echo ($finance && $finance['treatment_expenses_friend'] == 1) ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Loan
                                            <input type="checkbox" name="financial[treatment_expenses_loan]" id="treatment_expenses_loan" value="1" <?php echo ($finance && $finance['treatment_expenses_loan'] == 1) ? "checked='true'" : "" ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec">
                                    <label>
                                        <div class="checkbx">
                                            Other trusts
                                            <input type="checkbox" name="financial[treatment_expenses_othertrust]" id="treatment_expenses_othertrust" value="1" <?php echo ($finance && $finance['treatment_expenses_othertrust'] == 1) ? "checked='true'" : "" ?> style="display: none;" onchange="this.checked == true ? document.getElementById('other_trust_amount').style.display = '' : document.getElementById('other_trust_amount').style.display = 'none';$('#other_trust_amount').val('')">
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="medication">
                                    <label for="name"></label>
                                    <textarea maxlength="500" name="financial[other_trust_amount]"   placeholder="Other trust details" id="other_trust_amount" class="form-control" style="height:auto;<?php if($finance['treatment_expenses_othertrust'] != 1) echo "display:none;";?> "  ><?php echo ($finance && $finance['other_trust_amount']) ? trim($finance['other_trust_amount']) : "" ?></textarea>
                                    
                                </div>

                            </div>
                        </div>
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">Amount required by patient <span class="mandate">*</span></label>
                            <input placeholder="Amount of current funding required by patient detail" maxlength="20" id="required_fund" value="<?php echo ($finance && $finance['required_fund']) ? $finance['required_fund'] : "" ?>" name="financial[required_fund]" type="text" class="form-control allowdecimal" <?php if ($case['case_status'] == 'open') echo "readOnly"; ?>>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="name">Is funding requirement one time or recurring? </label>
                            <select id="fund_requirement" name="financial[fund_requirement]" class="form-control">
                                <option <?php echo ($finance && $finance['fund_requirement'] == "") ? "selected" : "" ?>>-Select One-</option>
                                <option value="OT" <?php echo ($finance && $finance['fund_requirement'] == "OT") ? "selected" : "" ?>>One time</option>
                                <option value="REC" <?php echo ($finance && $finance['fund_requirement'] == "REC") ? "selected" : "" ?>>Recurring</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">Is funding requirement short term ( < 6 months ) or long term ( > 6 months ) ?</label>
                            <select id="requirement_for" name="financial[requirement_for]" class="form-control">
                                <option value="" <?php echo ($finance && $finance['requirement_for'] == "") ? "selected" : "" ?>>-Select One-</option>
                                <option value="ST" <?php echo ($finance && $finance['requirement_for'] == "ST") ? "selected" : "" ?>>Short term ( < 6 months )</option>
                                <option value="LT" <?php echo ($finance && $finance['requirement_for'] == "LT") ? "selected" : "" ?>>Long term ( > 6 months )</option>
                            </select>
                        </div>  

                        <div class="form-group col-md-6">
                            <label for="name">Amount approved to patient</label>
                            <input id="approved_amount" value="<?php echo ($finance && $finance['approved_amount']) ? $finance['approved_amount'] : "" ?>" name="financial[approved_amount]" type="text" class="form-control" readOnly>
                        </div>
                    </div>
                    <hr/>

                    <div class="row">
                        <div class="col-md-12 form-group">
                            <label for="name">What the aforementioned funding will cover</label>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="name">Surgery</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[funding_cover_surgery]" value="1" <?php echo ($finance && $finance['funding_cover_surgery'] == 1) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[funding_cover_surgery]" value="0" <?php echo ($finance && !$finance['funding_cover_surgery']) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="name">Treatment</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[funding_cover_treatment]" value="1" <?php echo ($finance && $finance['funding_cover_treatment'] == "1") ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[funding_cover_treatment]" value="0" <?php echo ($finance && !$finance['funding_cover_treatment']) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="name">Medication</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[funding_cover_meditation]" value="1" <?php echo ($finance && $finance['funding_cover_meditation'] == 1) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio" name="financial[funding_cover_meditation]" value="0" <?php echo ($finance && !$finance['funding_cover_meditation']) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="name">Day to day expenses</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[funding_cover_dalyexpense]" value="1" <?php echo ($finance && $finance['funding_cover_dalyexpense']== 1) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[funding_cover_dalyexpense]" value="0" <?php echo ($finance && $finance['funding_cover_dalyexpense']==0) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-3">
                            <label for="name">Travelling</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[funding_cover_travelling]" value="1" <?php echo ($finance && $finance['funding_cover_travelling'] ==1) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[funding_cover_travelling]" value="0" <?php echo ($finance && $finance['funding_cover_travelling']==0) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group col-md-3">
                            <label for="name">Food</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[funding_cover_food]" value="1" <?php echo ($finance && $finance['funding_cover_food'] == 1) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[funding_cover_food]" value="0" <?php echo ($finance && $finance['funding_cover_food'] == 0) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group col-md-3">
                            <label for="name">Other</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[funding_cover_other]" value="1" <?php echo ($finance && $finance['funding_cover_other'] ==1) ? "checked='true'" : "" ?> onclick ="if( $(this).prop('checked')) $('#funding_cover_other_details').show();" >
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[funding_cover_other]" value="0" <?php echo ($finance && $finance['funding_cover_other']==0) ? "checked='true'" : "" ?> onclick ="if( $(this).prop('checked')) $('#funding_cover_other_details').hide(); $('#funding_cover_other_details').val(''); " >
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                            <br>
                            
                                 <textarea placeholder="Other Details" maxlength="500" id="funding_cover_other_details" name="financial[funding_cover_other_details]" class="form-control text-add" style="margin:10px 0 0  ;<?php echo ($finance && ($finance['funding_cover_other'] ==1)) ? "display:block" : "display:none" ?>"><?php echo ($finance && $finance['funding_cover_other_details']) ? $finance['funding_cover_other_details'] : "" ?></textarea>
<!-- 
                            <input id="funding_cover_other_details" value="<?php echo ($finance && $finance['funding_cover_other_details']) ? $finance['funding_cover_other_details'] : "" ?>" style="<?php echo ($finance && $finance['funding_cover_other'] == 1) ? "display:block" : "display:none" ?>" placeholder="Other Details" name="financial[funding_cover_other_details]" type="text" class="form-control"> -->

                        </div>

                        </div>
                        <hr/>
                        <div class="row">
                        <div class="col-md-12 form-group">
                            <label for="name">How much has PBF / PBCF covered? Any proof of this available?</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio"  name="financial[pbf_pcf]" value="1" <?php echo ($finance && $finance['pbf_pcf'] == 1) ? "checked='true'" : "" ?> onclick="if($(this).prop('checked')) $('#pbf_pcf_amt').show();" maxlength ="15">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio"  name="financial[pbf_pcf]" value="0" <?php echo ($finance && $finance['pbf_pcf'] == 0) ? "checked='true'" : "" ?> onclick="if($(this).prop('checked')) $('#pbf_pcf_amt').hide(); $('#pbf_pcf_amt').val(''); " >
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">NA</span>
                                        <input type="radio"  name="financial[pbf_pcf]" value="2" <?php echo ($finance && $finance['pbf_pcf'] == 2) ? "checked='true'" : "" ?> onclick="if($(this).prop('checked')) $('#pbf_pcf_amt').hide(); $('#pbf_pcf_amt').val('');">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                        <input maxlenght="15" type="text" id= "pbf_pcf_amt" name="financial[pbf_pcf_amt]" value="<?php echo $finance['pbf_pcf_amt']?$finance['pbf_pcf_amt']:'';?>" class="form-control allowdecimal" style=" <?php echo ($finance['pbf_pcf']!=1) ? "display: none;" : "" ?> ">
                        </div>

</div>
<hr/>
<div class="row">
                        <div class="col-md-12 form-group">
                            <label for="name">If denied previous funding, reason for denial</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Because of their policy</span>
                                        <input type="radio"  name="financial[prev_funding]" value="1" <?php echo ($finance && $finance['prev_funding'] == 1) ? "checked='checked'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Rules and regulations</span>
                                        <input type="radio"  name="financial[prev_funding]" value="0" <?php echo ($finance && $finance['prev_funding'] == 0) ? "checked='checked'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">NA</span>
                                        <input type="radio"  name="financial[prev_funding]" value="2" <?php echo ($finance && $finance['prev_funding'] == 2) ? "checked='checked'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>

                            </div><br/>
                            
                            <textarea maxlength="500" id="funding_cover_other_details" name="financial[fund_specify]" class="form-control" style="margin:10px 0 0; height:auto;" placeholder="Reason for denial"><?php echo (!empty($finance['fund_specify'])) ? $finance['fund_specify'] : "" ?></textarea>
                        </div>
         </div>
        <hr/> 
         <div class="row">               
                        <div class="tbl col-md-12" >
                            <table id="" class="table table-striped table-bordered" width="100%">

                                <thead>
                                    <tr>
                                        <th colspan="2">Other trusts supported / applied - </th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $x = 0;
                                    do {
                                        ?>
                                        <tr>
                                            <td><input id="" value="<?php echo $case_trust[$x]['col1']; ?>" name="trust[trust_row<?php echo $x; ?>][]" type="text" class="form-control"></td>
                                            <td><input id="" value="<?php echo $case_trust[$x]['col2']; ?>" name="trust[trust_row<?php echo $x; ?>][]" type="text" class="form-control"></td>
                                            <td><input id="" value="<?php echo $case_trust[$x]['col3']; ?>" name="trust[trust_row<?php echo $x; ?>][]" type="text" class="form-control"></td>
                                            <td><input id="" value="<?php echo $case_trust[$x]['col4']; ?>" name="trust[trust_row<?php echo $x; ?>][]" type="text" class="form-control"></td>
                                    <input type="hidden" name="trust[trust_row<?php echo $x; ?>][]" value="<?php echo $case_trust[$x]['id']; ?>"/>
                                    </tr>
                                    <?php
                                    $x++;
                                } while ($x <= 2);
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 caseBtn">
                            <input type="submit" id="submit2" value="Submit" class="btn btn-primary add">
                        </div>
                    </div>
                    </form>
                </div>
                <div class="tab-pane fade" id="documents">
                    <?php
                    $attributes = array('name' => 'save_document', 'id' => 'save_document');
                    echo form_open_multipart("patientcase/savedoc/?cid=$cid", $attributes);
                    //print_r($documents); exit;
                    ?>
                    <h3 class="sub-haeding">Documents Provided By Patient</h3>
                    <div class="row">
                        <div class="form-group col-md-12">
                            <div class="medication doc row">
                                <div class="checkSec col-md-6">
                                    <input type="hidden" id="document_id" name="document_id" value="<?php echo!empty($documents) ? $documents['id'] : '' ?>">
                                    <label>
                                        <div class="checkbx">
                                            Birth certificate 
                                            <input type="checkbox" name="birth_certificates" id="birth_certificates" <?php echo!empty($documents && $documents['birth_certificates']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Income certificate
                                            <input type="checkbox" name="income_certificate" id="income_certificate" <?php echo!empty($documents && $documents['income_certificate']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Ration card 
                                            <input type="checkbox" name="ration_card" id="ration_card" <?php echo!empty($documents && $documents['ration_card']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            HLA Match report 
                                            <input type="checkbox" name="hla_match_report" id="hla_match_report" <?php echo!empty($documents && $documents['hla_match_report']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Adhaar card  
                                            <input type="checkbox" name="adhaar_card" id="adhaar_card" <?php echo!empty($documents && $documents['adhaar_card']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Affidavit 
                                            <input type="checkbox" name="affidavit" id="affidavit" <?php echo!empty($documents && $documents['affidavit']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Salary slips/proof 
                                            <input type="checkbox" name="salary_slips" id="salary_slips" <?php echo!empty($documents && $documents['salary_slips']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Doctor’s letter
                                            <input type="checkbox" name="doctors_letter" id="doctors_letter" <?php echo!empty($documents && $documents['doctors_letter']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Pan card / Election ID
                                            <input type="checkbox" name="pan_card_or_election_id" id="pan_card_or_election_id" <?php echo!empty($documents && $documents['pan_card_or_election_id']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Appeal letter from hospital attesting to physical condition and funds required
                                            <input type="checkbox" name="appeal_letter" id="appeal_letter" <?php echo!empty($documents && $documents['appeal_letter']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Photograph
                                            <input type="checkbox" name="photograph" id="photograph" <?php echo!empty($documents && $documents['photograph']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Medical Report
                                            <input type="checkbox" name="medical_report" id="medical_report" <?php echo!empty($documents && $documents['medical_report']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Insurance papers
                                            <input type="checkbox" name="insurance_paper" id="insurance_paper" <?php echo!empty($documents && $documents['insurance_paper']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            Medical bills for current ailment
                                            <input type="checkbox" name="medical_bills_current" id="medical_bills_current" <?php echo!empty($documents && $documents['medical_bills_current']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label></div>
                                <div class="checkSec col-md-6">
                                    <label>
                                        <div class="checkbx">
                                            References and contact details of people outside family
                                            <input type="checkbox" name="ref_or_contact_people" id="ref_or_contact_people" <?php echo!empty($documents && $documents['ref_or_contact_people']) ? "checked='true'" : '' ?>>
                                            <span></span>
                                        </div>			 
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-6 files" id="files1">
                            <h3 class="sub-haeding">Upload Document</h3>
                            <div id="top-msg" class="top-msg" hidden></div>  
                            <input type="file" name="files1" multiple class="form-control file" id = "multi_doc_upload">
                            <br />
                            <span id="successMsg" style="color: green"></span>
                            <input type="button" id="uploadBtn" value="Upload Files" style=" float:right" class="btn btn-primary add">
                            <ul class="fileList"></ul>
                            
                            <input type="hidden" id="file_urls" name="file_urls" value='<?php echo!empty($documents) ? $documents['file_urls'] : "" ?>'>
                            <?php
                            $arr = !empty($documents) ? json_decode($documents['file_urls'], true) : array();
                            ?>
                        </div>
                        <div class="form-group col-md-6 files">
                            <h3 class="sub-haeding">Uploaded Document</h3>
                            <div class="uplCol">
							<?php
                            if (!empty($arr)) {
                                foreach ($arr as $key => $link) {
                                    $linkarr = explode("/", $link);
                                    ?>
                                    <div class="filCol">      
                                        <a class="first" href='<?php echo $link; ?>' target="_blank" download title="documents">(<?php echo $key + 1; ?>) <?php echo $linkarr[count($linkarr) - 1]; ?></a> <a href="javascript:void(0)" id="delFile<?php echo $key + 1; ?>" class="btn btn-danger fa fa-trash-o space last" onclick="if (confirm('are you sure to delete this file')) {
                                                            deleteUploadedFile('<?php echo $documents['id'] ?>', '<?php echo $linkarr[count($linkarr) - 1]; ?>', this)
                                                        }"></a> <br/>
                                        <div class="clearfix"></div>
                                    </div> 
                                    <?php
                                }
                            }
                            ?>
                            </div>
                        </div>
                        
                            <div class="col-md-12 caseBtn">
                                <input type="submit" id="submit3" value="Submit" class="btn btn-primary add">
                            </div>
                        
                    </div>
                    </form>
                </div>
                <div class="tab-pane fade" id="karo_notes">
                    <?php
                    $attributes = array('name' => 'save_notes', 'id' => 'save_notes');
                    echo form_open("patientcase/savenotes/?cid=$cid", $attributes);
                    $userName = $user[0]['FirstName'] ." ".$user[0]['MiddleName'] ." ". $user[0]['LastName'];
                    ?>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">Social Worker Name</label>
                            <?php if ($this->session->userdata("IsAdmin") != 1) { ?>
                            <input name="social_worker_name" placeholder="" id="" value="<?php echo $notes['social_worker_name'] ? $notes['social_worker_name']:$userName; ?>" readonly type="text" class="form-control col-md-6">
                            <?php } else{ ?>
                            <select class="form-control" name="social_worker_name" id="disbursed_donor">
                    <option value="">Select Social Worker</option>
                    <?php
                        if($social_workers){
                            foreach ($social_workers as $k => $v) {
                                ?>
                            <option  value="<?php echo $v['UserId'];?>"  <?php echo $notes['social_worker_id'] == $v['UserId'] ? "selected" : "";?>><?php echo $v['FirstName'].' '.$v['MiddleName'].' '.$v['lastname'];?></option>
                                <?php
                            }
                        }
                    ?>
                </select>
                            <?php }?>
                            <input type="hidden" id="note_id" name="note_id" value="<?php echo (!empty($notes) && $notes['id']) ? $notes['id'] : "" ?>">
                            <input type="hidden" id="UserId" name="UserId" value="<?php echo $user[0]['UserId']; ?>">
                        </div>
                    </div>
                    <h3 class="sub-haeding">Social Worker Notes</h3>
                    <h3 class="sub-haeding">Profiling</h3>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">Upon profiling, does the social worker deem this case to be genuine? </label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio" name="profiling_is_genuine" value="1" <?php echo (!empty($notes) && $notes['profiling_is_genuine'] == 1) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio" name="profiling_is_genuine" value="0" <?php echo (!empty($notes) && $notes['profiling_is_genuine'] == 0) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="name">Grade the urgency level of treatment</label>
                            <!--<div class="rating">
                                <input class="star_rating" type="radio" id="star5" name="rating" value="5"  /><label for="star5" title=""></label>
                                <input class="star_rating"  type="radio" id="star4" name="rating" value="4" /><label for="star4" title=""></label>
                                <input class="star_rating"  type="radio" id="star3" name="rating" value="3" /><label for="star3" title=""></label>
                                <input class="star_rating"  type="radio" id="star2" name="rating" value="2" /><label for="star2" title=""></label>
                                <input class="star_rating" type="radio" id="star1" name="rating" value="1" /><label for="star1" title=""></label>
                            </div>-->
                            <div class="rating">
            <input id="star5" name="rating" type="radio" value="5" class="radio-btn hide" <?php echo (!empty($notes) && $notes['rating'] == 5) ? "checked='true'" : "" ?> />
            <label for="star5" >☆</label>
            <input id="star4" name="rating" type="radio" value="4" class="radio-btn hide" <?php echo (!empty($notes) && $notes['rating'] == 4) ? "checked='true'" : "" ?>/>
            <label for="star4" >☆</label>
            <input id="star3" name="rating" type="radio" value="3" class="radio-btn hide" <?php echo (!empty($notes) && $notes['rating'] == 3) ? "checked='true'" : "" ?>/>
            <label for="star3" >☆</label>
            <input id="star2" name="rating" type="radio" value="2" class="radio-btn hide" <?php echo (!empty($notes) && $notes['rating'] == 2) ? "checked='true'" : "" ?>/>
            <label for="star2" >☆</label>
            <input id="star1" name="rating" type="radio" value="1" class="radio-btn hide" <?php echo (!empty($notes) && $notes['rating'] == 1) ? "checked='true'" : "" ?>/>
            <label for="star1" >☆</label>
            <div class="clear"></div>
        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">Does the social worker recommend further investigation?</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Yes</span>
                                        <input type="radio" id="investigation_recommend1" name="investigation_recommend" value="1" <?php echo (!empty($notes) && $notes['investigation_recommend'] == 1) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">No</span>
                                        <input type="radio" id="investigation_recommend2" name="investigation_recommend" value="0" <?php echo (!empty($notes) && $notes['investigation_recommend'] == 0) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="name">How does the social worker want to take this case forward?</label>
                            <div class="medication">
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Accept</span>
                                        <input type="radio" id="case_status1" name="case_status" value="1" <?php echo (!empty($notes) && $notes['case_status'] == 1) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="form-check-inline">
                                    <label class="customradio"><span class="radiotextsty">Reject</span>
                                        <input type="radio" id="case_status2" name="case_status" value="0" <?php echo (!empty($notes) && $notes['case_status'] == 0) ? "checked='true'" : "" ?>>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="name">Comments</label>
                        <textarea id="remarks" name="remarks" class="form-control valid" rows="" style="height:100px;"><?php echo (!empty($notes) && trim($notes['remarks'])) ? $notes['remarks'] : "" ?></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-12 caseBtn">
                            <input type="submit" class="form-group button primary btn btn-primary add" id="submit4" value="Submit">
                        </div>
                    </div>
                    </form>
                </div>
                <div class="tab-pane fade" id="follow_up_details">
                    <?php
                    $attributes = array('name' => 'save_followup', 'id' => 'save_followup');
                    echo form_open("patientcase/followup/?cid=$cid", $attributes);
                    ?>
                    <h3 class="sub-haeding">Patient Follow Up</h3>
                    <div class="tbl">
                        <table id="followup_table" class="table table-striped table-bordered followup_table" width="100%" valign="center" >
                            <thead>
                                <tr>
                                    <th>Follow Up Done</th>
                                    <th>Follow Up Date</th>
                                    <th>Remarks</th>
                                    <th>Next FollowUp Date</th>
                                    <th>Remove</th>
                                </tr>
                            </thead>
                            <tbody id="followup_container">
                                <?php
                                if (!empty($followup)) {
                                    foreach ($followup as $key => $follwup) {
                                        ?>
                                        <tr>
                                            <td>
                                            <br/>
                                            <div class="checkSec col-md-3">
                        <label>
                            <div class="checkbx">
                                <input type="hidden" id="f_id<?php echo $key ?>" name="f_id[]" value="<?php echo ($follwup) ? $follwup['id'] : "" ?>"> <input type="checkbox"  name="folowup_done[]" value="1" <?php echo $follwup['folowup_done'] == 1 ? "checked='true'" : ""; ?>>
                                <span></span>
                            </div>			 
                    </label></div>
                                            
                                            </td>
                                            <td>
                                            <br/>
                                                <div class="control-group">
                                                    <input id="followup_date<?php echo $key ?>" name="followup_date[]" type="text" class="form-control defaultdate" value="<?php echo $follwup['followup_date']; ?>" readonly>
                                                    <span class="add-on"><i class="icon-remove"></i></span>
                                                    <span class="add-on"><i class="icon-th"></i></span>
                                                    <input type="hidden" id="dtp_input3" value="" /><br/>
                                                </div>
                                            </td>
                                            <td><textarea id="remark<?php echo $key ?>" name="remark[]" type="text" class="form-control" value=""> <?php echo $follwup['remark']; ?></textarea></td>
                                            <td>
                                            <br/>
                                                <div class="control-group">
                                                    <input id="next_followup_date<?php echo $key ?>" name="next_followup_date[]" type="text" class="form-control defaultdate followup_td" readonly value="<?php echo $follwup['next_followup_date']; ?>">
                                                    <span class="add-on"><i class="icon-remove"></i></span>
                                                    <span class="add-on"><i class="icon-th"></i></span>

                                                    <input type="hidden" id="dtp_input4" value="" /><br/>
                                                </div>
                                            </td>
                                            <td>
                                            <br/>
                                                <div class="control-group">
                                                    <a href="#" class="btn btn-danger fa fa-trash-o space" value="" onclick="deleteFollowupRow($(this), '<?php echo $key ?>');"></a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                } else {
                                    ?>
                                    <tr>
                                        <td> 
                                        <br/>
                                        <div class="checkSec col-md-3">
                        <label>
                            <div class="checkbx">
                                <input type="checkbox"  name="folowup_done[]" value="1" >
                                
                                <span></span>
                            </div>			 
                    </label></div>
                                        </td>
                                        <td>
                                        <br/>
                                            <div class="control-group">

                                                <input id="followup_date0" name="followup_date[]" type="text" class="form-control defaultdate" readonly>
                                                <span class="add-on"><i class="icon-remove"></i></span>
                                                <span class="add-on"><i class="icon-th"></i></span>
                                                <input type="hidden" id="dtp_input5" value="" /><br/>
                                            </div>
                                        </td>
                                        <td><textarea id="remark0" name="remark[]" type="text" class="form-control"></textarea></td>
                                        <td>
                                        <br/>
                                            <div class="control-group">
                                                <input id="next_followup_date0" name="next_followup_date[]" type="text" class="form-control defaultdate" readonly>
                                                <span class="add-on"><i class="icon-remove"></i></span>
                                                <span class="add-on"><i class="icon-th"></i></span>
                                                <input type="hidden" id="dtp_input6" value="" /><br/>
                                            </div>
                                        </td>
                                        <td>
                                        <br/>
                                            <div class="control-group">
                                                <a href="#" class="btn btn-danger fa fa-trash-o space" value="" onclick="deleteFollowupRow($(this), 0);"></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                            <tr>
                                <td colspan="5"><input type="button" class="btn btn-primary add" value="Add" style="float:right" onclick="return addMoreFollowup();"></td>
                            </tr>
                        </table>
                    </div>
                    <div class="follow-btn caseBtn">
                        <input type="submit" class="btn btn-primary add" value="Submit">
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<div id="modal_close_open_case" class="modal fade in">
    <div class="modal-dialog">
        <div class="modal-content">
            
            <!-- <h4 class="modal-title"></h4>
                    <a class=" close" data-dismiss="modal"><span>X</span></a> -->
<a class="close" data-dismiss="modal"><span>X</span></a>
            <div class="modal-body">
                <div id="top-msg_closed" class="top-msg_closed" hidden></div>    
                <div class="form-group" >
                    <label for="name" id="reason_for"> Closing remarks</label>
                    <textarea class="adress" name="Reason" id="reason_close" rows="2"  placeholder="Enter the reason" ></textarea>
                    <input type="hidden" name="hidden_case_id" id="hidden_case_id" data-type ="">


                </div>
            </div>
            <div class="modal-footer">
             
                    <button class="btn btn btn-primary add " data-dismiss="modal">Cancel</button>
                    <button class="btn btn btn-primary add" id= "close-open-submit">Submit</button>
                
            </div>

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dalog -->
</div>
<script>
    updateList = function () {
        var input = document.getElementById('file');
        var output = document.getElementById('fileList');

        output.innerHTML = '<ul>';
        for (var i = 0; i < input.files.length; ++i) {
            output.innerHTML += '<li>' + input.files.item(i).name + '</li>';
        }
        output.innerHTML += '</ul>';
    }
</script>
