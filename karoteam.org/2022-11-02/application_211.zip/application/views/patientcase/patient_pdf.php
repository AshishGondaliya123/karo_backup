<div style="margin:0 auto; width:100%; font-family: 'Open Sans', sans-serif; border:1px solid #f1f1f1;background:#fff;">
    <table width="100%" style=" color:#666666;  padding:25px 30px 45px 30px;" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td>
                <table  width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="40%" >
                            <table cellspacing="0" cellpadding="0" border="0" style="white-space:nowrap; border-collapse: collapse;" >
                                <tr>
                                    <td style="font-size:13px; color:#000;">
                                        <p>Date –<?php echo date('d F, Y', strtotime($ptMasterDetails[0]->registration_date)); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                        <td width="20%" align="center" >
                            <table width="100%" cellspacing="0" cellpadding="0" border="0" style="white-space:nowrap; border-collapse: collapse; text-align:center;" >
                                <tr>
                                    <td align="center" style="text-align:center; padding:10px; "><p style="text-align:center; padding:10px; background:#ff6600;"><img src="<?php echo $logo; ?>" style="text-align:center; display: block; margin: 0 auto"></p></td>
                                </tr>
                            </table>
                        </td>
                        <td width="40%" align="right">
                            <table cellspacing="0" cellpadding="0" border="1" style="white-space:nowrap; border-collapse: collapse;" >
                                <tr>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd">Home Visit</td>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo ($ptMasterDetails[0]->registration_site == 'HM') ? 'YES' : ''; ?></td>
                                </tr>
                                <tr>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd">Hospital Visit</td>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo ($ptMasterDetails[0]->registration_site == 'HV') ? 'YES' : ''; ?></td>
                                </tr>
                                <tr>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd">In Office</td>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo ($ptMasterDetails[0]->registration_site == 'IO') ? 'YES' : ''; ?></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <table  width="100%"  cellspacing="0" cellpadding="0" style="border-collapse: collapse;  border: 0px solid #ddd;">
                    <tr>
                        <td colspan="2" align="center" style="font-size:16px; font-weight:bold; color:#000; padding:8px;">MEDICAL ASSISTANCE REQUEST FORM</td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px;">Patient Case: <span style="border-bottom:1px solid #000;"><?php echo $ptMasterDetails[0]->patient_case ? $ptMasterDetails[0]->patient_case : ''; ?></span></td>
                        <td rowspan="3" style="font-size:13px; color:#000; padding:0px; border:1px solid #000; height:140px; width:140px;"><img src="<?php echo $ptMasterDetails[0]->patient_image ? $ptMasterDetails[0]->patient_image : ''; ?>" width="140px" height="140px"/></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px;">Patient KARO Case Number: <span style="border-bottom:1px solid #000;"><?php echo $ptMasterDetails[0]->patient_karo_case_no ? $ptMasterDetails[0]->patient_karo_case_no : ''; ?></span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px;">Team Member: <span style="border-bottom:1px solid #000;"><?php echo $ptMasterDetails[0]->representative_name ? $ptMasterDetails[0]->representative_name : ''; ?></span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px;">Referred To KARO By: <span style="border-bottom:1px solid #000;"><?php echo $ptMasterDetails[0]->ReferedByName ? $ptMasterDetails[0]->ReferedByName : ''; ?></span></td>
                    </tr>
                    <tr><td style="font-size:13px; color:#000; padding:8px;">Referral Name: <span style="border-bottom:1px solid #000;"><?php echo $ptMasterDetails[0]->referral_name ? $ptMasterDetails[0]->referral_name : ''; ?></span></td></tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px;">Contact Details of Referral: <span style="border-bottom:1px solid #000;"><?php echo $ptMasterDetails[0]->Contact_Details_Of_Referral ? $ptMasterDetails[0]->Contact_Details_Of_Referral : ''; ?></span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px;">Current diagnosed illness: <span style="border-bottom:1px solid #000;"><?php echo $ptMedicalDetails[0]->disease_diagnosed ? $ptMedicalDetails[0]->disease_diagnosed : ''; ?></span></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td height="30"></td>
        </tr>
        <tr>
            <td>
                <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
                    <tr>
                        <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">PATIENT'S PERSONAL DETAILS</td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
                                <tr>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Name:</td>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->patient_name ?></td>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">DOB:</td>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo ($ptMasterDetails[0]->patient_dob == "0000-00-00") ? "" : date('d/m/Y', strtotime($ptMasterDetails[0]->patient_dob)) ?></td>
                                </tr>
                                <tr>
                                    <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Age:</td>
                                    <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo str_replace(",", " ", $ptMasterDetails[0]->Patient_Age); ?></td>
                                    <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Gender:</td>
                                    <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->Patient_Gender ?></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Language Spoken:</td>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo str_replace('Other', ' ', $ptMasterDetails[0]->Language_Spoken); ?></td>
                                </tr>

                                <?php if (trim($ptMasterDetails[0]->Patient_Permanent_Address) == trim($ptMasterDetails[0]->Patient_Address)) { ?>
                                    <tr>
                                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Home address / where they currently reside(Permanent Address)</td>
                                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->Patient_Permanent_Address ?></td>
                                    </tr>
                                <?php } else { ?>
                                    <tr>
                                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Home address / where they currently reside(Permanent Address)</td>
                                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->Patient_Permanent_Address ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Patient Temporary Address</td>
                                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->Patient_Address ?></td>
                                    </tr>
                                <?php } ?>

                                <tr>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Telephone / contact number (to include that of family members as well if any)</td>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->ContactNOs ?></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Caregiver Name</td>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo empty($ptMasterDetails[0]->caregiver_name) ? "" : $ptMasterDetails[0]->caregiver_name; ?></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Caregiver Phone</td>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo empty($ptMasterDetails[0]->caregiver_phone) ? "" : $ptMasterDetails[0]->caregiver_phone; ?></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Caregiver Name</td>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo empty($ptMasterDetails[0]->caregiver_name2) ? "" : $ptMasterDetails[0]->caregiver_name2; ?></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Caregiver Phone</td>
                                    <td colspan="2" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo empty($ptMasterDetails[0]->caregiver_phone2) ? "" : $ptMasterDetails[0]->caregiver_phone2; ?></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td height="30"></td>
        </tr>
        <tr>
            <td width="100%">
                <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;" >
                    <tr>
                        <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">PATIENT'S FAMILY DETAILS</td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Total No. Of people in close (immediate or extended) family:</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">
                            <?php
                            $cnt = 0;
                            foreach ($ptFamilyDetails as $row) {
                                if (!empty($row->Relative_Name)) {
                                    $cnt = $cnt + 1;
                                }
                            }
                            echo ($cnt == 0) ? "" : $cnt;
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;" >
                                <?php
                                if ($ptFamilyDetails) {
                                    ?>
                                    <tr>
                                        <th align="left" bgcolor="#f0643b" style="font-size:13px; color:#fff; padding:8px ; border: 1px solid #ddd;">Name</th>
                                        <th align="left" bgcolor="#f0643b" style="font-size:13px; color:#fff; padding:8px ; border: 1px solid #ddd;">Relation</th>
                                        <th align="left" bgcolor="#f0643b" style="font-size:13px; color:#fff; padding:8px ; border: 1px solid #ddd;">Age</th>
                                        <th align="left" bgcolor="#f0643b" style="font-size:13px; color:#fff; padding:8px ; border: 1px solid #ddd;">Occupation</th>
                                        <th colspan="2" align="left" bgcolor="#f0643b" style="font-size:13px; color:#fff; padding:8px ; border: 1px solid #ddd;">Income (In RS)</th>
                                        <th align="left" bgcolor="#f0643b" style="font-size:13px; color:#fff; padding:8px ; border: 1px solid #ddd;">Details</th>

                                    </tr>
                                    <?php
                                    foreach ($ptFamilyDetails as $row) {
                                        //if ($row->relative_age != "YY,MM" && (!empty($row->relative_age))) {
                                        $age_string = explode(",", $row->relative_age);

                                        $age_year = (empty($age_string[0]) || $age_string[0] == "YY") ? "" : $age_string[0] . " Year(s) ";

                                        if (empty($age_string[1]) || $age_string[1] == "MM") {
                                            $age_month = "";
                                        } else if ($age_string[0] == "YY" && $age_string[1] != "MM") {
                                            $age_month = $age_string[1] . " Month(s)";
                                        } else if ($age_string[0] != "YY" && $age_string[1] != "MM") {
                                            $age_month = ", " . $age_string[1] . " Month(s)";
                                        }

                                        $final_age = $age_year . $age_month;
                                        if (!empty($row->Relative_Name)) {
                                            ?>
                                            <tr>
                                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->Relative_Name; ?></td>
                                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->relation; ?></td>
                                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $final_age; ?></td>
                                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->occupation; ?></td>
                                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo numberformat($row->salary); ?> </td>
                                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->duration; ?></td>
                                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->income_details ? $row->income_details : ''; ?></td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>
                                <?php } ?> 
                            </table>
                        </td>
                    </tr>  
                </table>
            </td>
        </tr>
        <tr>
            <td height="30"></td>
        </tr>
        <tr>
            <td>
                <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
                    <tr>
                        <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">PATIENT'S MEDICAL DETAILS</td>
                    </tr>
                    <?php if ($ptMedicalDetails) { ?>
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Blood Group: </td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Blood_Group ? $ptMedicalDetails[0]->Blood_Group : ''; ?></td>
                        </tr>
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Hospital Name and address: </td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Hospital_Name_Address ? $ptMedicalDetails[0]->Hospital_Name_Address : ''; ?></td>
                        </tr>
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Department and Ward: </td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">
                                <?php
                                echo $ptMedicalDetails[0]->Department ? $ptMedicalDetails[0]->Department : '';
                                //if (isset($ptMedicalDetails[0]->Department)) {
                                //    $ci = & get_instance();
                                //    $data = $ci->patientcase_model->getDeptName($ptMedicalDetails[0]->Department);
                                //    echo $data[0]->DeptName;
                                //} else {
                                //    echo "";
                                //}
                                ?>
                            </td>
                        </tr>
            <!--                        <tr>
                            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Current diagnosed illness: </td>
                            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->disease_diagnosed ? $ptMedicalDetails[0]->disease_diagnosed : ''; ?></td>
                        </tr>-->
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Diagnosed details and medical requirement's: </td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Disease_Detail ? $ptMedicalDetails[0]->Disease_Detail : ''; ?></td>
                        </tr>
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Doctor's Name: </td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Doctor_Name ? $ptMedicalDetails[0]->Doctor_Name : ''; ?></td>
                        </tr>
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Current diagnosed illness / problem and details of what is medically required next: </td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->disease_diagnosed ? $ptMedicalDetails[0]->disease_diagnosed : ''; ?></td>
                        </tr>
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">When was illness/problem detected: </td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php //echo ($ptMedicalDetails[0]->Disease_Detect_date!=0000-00-00) ? date('d/m/Y',strtotime($ptMedicalDetails[0]->Disease_Detect_date)):'';                                                                                                                              ?><?php echo $ptMedicalDetails[0]->Disease_Detect_date ? $ptMedicalDetails[0]->Disease_Detect_date : ''; ?></td>
                        </tr>
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">How much of the treatment is currently completed: </td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Treatment_Complete_Details ? $ptMedicalDetails[0]->Treatment_Complete_Details : ''; ?></td>
                        </tr>
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><p style=" border-bottom: 1px solid #000;"><strong>PATH TO HEALING:</strong></p><p>How long does the doctor say it will take to heal completely and what needs to be done to ensure that</p></td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>Week -<?php echo $ptMedicalDetails[0]->Healing_Time == 'Week' ? 'YES' : ''; ?> </p><p>  Month - <?php echo $ptMedicalDetails[0]->Healing_Time == 'Month' ? 'YES' : ''; ?> </p> <p>Year - <?php echo $ptMedicalDetails[0]->Healing_Time == 'Year' ? 'YES' : ''; ?>  </p><p>Life long - <?php echo $ptMedicalDetails[0]->Healing_Time == 'Life long' ? 'YES' : ''; ?></p></td>
                        </tr>
                        <tr>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Current Treatment status: </td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>Pre surgery - <?php echo trim($ptMedicalDetails[0]->Pre_Surgery) ? 'YES' : ''; ?>  </p>
                                <p>Pre Transplant -  <?php echo trim($ptMedicalDetails[0]->pre_transplant) ? 'YES' : ''; ?> </p>
                                <p>Medicines -  <?php echo trim($ptMedicalDetails[0]->Medicine) ? 'YES' : ''; ?> </p>
                                <p>Hospitalized - <?php echo trim($ptMedicalDetails[0]->Hospitalized) ? 'YES' : ''; ?>   </p>
                                <p>Post Surgery -  <?php echo trim($ptMedicalDetails[0]->Post_Surgery) ? 'YES' : ''; ?></p>
                                <p>Post Transplant -  <?php echo trim($ptMedicalDetails[0]->post_treatment) ? 'YES' : ''; ?></p>     
                                <p>Exercise -  <?php echo trim($ptMedicalDetails[0]->Excercise) ? 'YES' : ''; ?> </p>
                                <!-- <p>Medicines specify - <?php echo trim($ptMedicalDetails[0]->medicines_details) ? $ptMedicalDetails[0]->medicines_details : ''; ?>  </p> -->
                            </td>
                        </tr>
            <!--                        <tr>
                            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Diagnosed details and medical requirement's</td>
                            <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><p><?php echo $ptMedicalDetails[0]->current_diagnosed_detail ? $ptMedicalDetails[0]->current_diagnosed_detail : ''; ?></p></td>
                        </tr>-->
                    <?php } ?>
                </table>
            </td>
        </tr>
        <tr>
            <td height="30"></td>
        </tr>
        <tr>
            <td>
                <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
                    <tr>
                        <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">FINANCIAL DETAILS</td>
                    </tr>
                    <?php //if($ptFinancialDetails){       ?>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Assets owned by patient/patient’s guardian and family (e.g.: house, land, shop, vehicle etc)</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><p><?php echo $ptFinancialDetails[0]->owned_house; ?> </p>
                            <p><?php echo $ptFinancialDetails[0]->owned_land; ?> </p>
                            <p><?php echo $ptFinancialDetails[0]->owned_shop; ?> </p>
                            <p><?php echo $ptFinancialDetails[0]->owned_vechicle; ?> </p>
                            <p><?php echo $ptFinancialDetails[0]->owned_other; ?> </p></td>
                    </tr>
                    <tr>
                        <?php
//                        echo "<pre>";
//                        print_r($ptFinancialDetails);
//                        exit;
                        ?>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Fixed monthly costs of patient (rent, school fee, cable, electricity, food, transport, etc)</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">
                            <p>
                                <?php
                                $rent_amount = str_replace("Rent - Rs ", "", $ptFinancialDetails[0]->rent_amount);
                                if (empty(number_format($rent_amount, 2, '.', ','))) {
                                    echo "Rent - No ";
                                } else {
                                    echo "Rent - Rs " . numberformat($rent_amount);
                                }
                                ?> 
                            </p>
                            <p>
                                <?php
                                $school_fees_amount = str_replace("School Fee - Rs ", "", $ptFinancialDetails[0]->school_fees_amount);
                                if (empty(number_format($school_fees_amount, 2, '.', ','))) {
                                    echo "School Fee - No";
                                } else {
                                    echo "School Fee - Rs " . numberformat($school_fees_amount);
                                }
                                ?> 
                            </p>
                            <p>
                                <?php
                                $cable_amount = str_replace("Cable - Rs ", "", $ptFinancialDetails[0]->cable_amount);
                                if (empty(number_format($cable_amount, 2, '.', ','))) {
                                    echo "Cable - No";
                                } else {
                                    echo "Cable - Rs " . numberformat($cable_amount);
                                }
                                ?> 
                            </p>
                            <p>
                                <?php
                                $electric_city_amount = str_replace("Electricity - Rs ", "", $ptFinancialDetails[0]->electric_city_amount);
                                if (empty(number_format($electric_city_amount, 2, '.', ','))) {
                                    echo "Electricity - No";
                                } else {
                                    echo "Electricity - Rs " . numberformat($electric_city_amount);
                                }
                                ?> 
                            </p>
                            <p>
                                <?php
                                $food_amount = str_replace("Food - Rs ", "", $ptFinancialDetails[0]->food_amount);
                                if (empty(number_format($food_amount, 2, '.', ','))) {
                                    echo "Food - No";
                                } else {
                                    echo "Food - Rs " . numberformat($food_amount);
                                }
                                ?> 
                            </p>
                            <p>
                                <?php
                                $transport_amount = str_replace("Transport - Rs ", "", $ptFinancialDetails[0]->transport_amount);
                                if (empty(number_format($transport_amount, 2, '.', ','))) {
                                    echo "Transport - No";
                                } else {
                                    echo "Transport - Rs " . numberformat($transport_amount);
                                }
                                ?> 
                            </p>
                            <p>
                                <?php
                                $other_expense_amount = str_replace("Other - Rs ", "", $ptFinancialDetails[0]->other_expense_amount);
                                if (empty(number_format($other_expense_amount, 2, '.', ','))) {
                                    echo "Other - No";
                                } else {
                                    echo "Other - Rs " . numberformat($other_expense_amount);
                                }
                                ?> 
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">How much has patient spent on treatment already</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->money_already_expend ? 'RS ' . numberformat($ptFinancialDetails[0]->money_already_expend) : ''; ?></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Did he/she have to sell any assets to pay for treatment so far?</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->sale_any_assest; ?></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Does he / she have any loans or mortgages currently?</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->loan_detail; ?></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Does the patient have insurance? Add details of insurance / mediclaim</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->insurance_detail; ?></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">How did patient manage treatment expenses so far?</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><p><?php echo $ptFinancialDetails[0]->treatment_expenses_own; ?> </p>
                            <p><?php echo $ptFinancialDetails[0]->treatment_expenses_friend; ?> </p>
                            <p><?php echo $ptFinancialDetails[0]->treatment_expenses_relatives; ?> </p>
                            <p><?php echo $ptFinancialDetails[0]->treatment_expenses_loan; ?> </p>
                            <p><?php
                                echo $ptFinancialDetails[0]->treatment_expenses_othertrust;
                                echo trim($ptFinancialDetails[0]->other_trust_amount) ? number_format($ptFinancialDetails[0]->other_trust_amount, 2, '.', ',') : '';
                                ?> </p></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Amount of current funding required by patient</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->required_fund ? 'RS ' . numberformat($ptFinancialDetails[0]->required_fund) : ''; ?></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Is funding requirement short term or long term?<br> Short term = < 6 months, <br>Long term = > 6 months</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>Short Term – <?php echo trim($ptFinancialDetails[0]->Fund_Required_For) == 'Short Term' ? 'YES' : ''; ?> </p>
                            <p>Long Term – <?php echo trim($ptFinancialDetails[0]->Fund_Required_For) == 'Long Term' ? 'YES' : ''; ?> </p></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">Is funding requirement one time or recurring</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>One time – <?php echo trim($ptFinancialDetails[0]->fund_requirement) == 'OT' ? 'YES' : ''; ?> </p>
                            <p>Recurring – <?php echo trim($ptFinancialDetails[0]->fund_requirement) == 'REC' ? 'YES' : ''; ?> </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">What the aforementioned funding will cover</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">
                            <?php
                            $CI = & get_instance();
                            $getFinanceDetails = $CI->patientcase_model->getFinanceDetails($_GET["patient_id"]);
                            ?>
                            <p>Surgery / Transplant – <?php echo ($getFinanceDetails[0]->funding_cover_surgery == 1) ? 'YES' : ''; ?> </p>
                            <p>Treatment – <?php echo ($getFinanceDetails[0]->funding_cover_treatment == 1) ? 'YES' : ''; ?> </p>
                            <p>Medication – <?php echo ($getFinanceDetails[0]->funding_cover_meditation == 1) ? 'YES' : ''; ?> </p>
                            <p>Day to day expenses – <?php echo ($getFinanceDetails[0]->funding_cover_dalyexpense == 1) ? 'YES' : ''; ?> </p>
                            <p>Travelling - <?php echo ($getFinanceDetails[0]->funding_cover_travelling == 1) ? 'YES' : ''; ?> </p>
                            <p>Food - <?php echo ($getFinanceDetails[0]->funding_cover_food == 1) ? 'YES' : ''; ?> </p>
                            <p>Any Other - <?php echo trim($getFinanceDetails[0]->funding_cover_other) ? $ptFinancialDetails[0]->funding_cover_other : ''; ?> </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">How much has PBF / PBCF covered? Any proof of this available?</td>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><p><?php echo $ptFinancialDetails[0]->pbf_pcf == 1 ? $checkbox_checked : $checkbox_uncheck; ?>   Yes <?php echo $ptFinancialDetails[0]->pbf_pcf_amt > 0 ? ' - RS ' . number_format($ptFinancialDetails[0]->pbf_pcf_amt, 2, '.', ',') : ''; ?> </p>
                            <p><?php echo ($ptFinancialDetails[0]->pbf_pcf == 0 && !empty($ptFinancialDetails)) ? $checkbox_checked : $checkbox_uncheck; ?>  No</p>
                            <p><?php echo $ptFinancialDetails[0]->pbf_pcf == 2 ? $checkbox_checked : $checkbox_uncheck; ?>  NA</p></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;">If denied previous funding, reason for denial</td>
                        <td style="font-size:12px; color:#000; padding:8px ; border: 1px solid #ddd;"><p><?php echo $ptFinancialDetails[0]->prev_funding == 1 ? $checkbox_checked : $checkbox_uncheck; ?>  Because of their policy</p>
                            <p><?php echo ($ptFinancialDetails[0]->prev_funding == 0 && !empty($ptFinancialDetails)) ? $checkbox_checked : $checkbox_uncheck; ?>  Rules and regulations </p>
                            <p><?php echo $ptFinancialDetails[0]->prev_funding == 2 ? $checkbox_checked : $checkbox_uncheck; ?>  NA</p>
                            <p><?php echo $ptFinancialDetails[0]->fund_specify ? ' - ' . $ptFinancialDetails[0]->fund_specify : '' ?></p>
                        </td>
                    </tr>
                    <?php //}               ?>
                </table>
            </td>
        </tr>
        <tr>
            <td height="30"></td>
        </tr>
        <tr>
            <td>
                <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
                    <tr>
                        <td colspan="3" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">Other trusts supported / applied</td>
                    </tr>
                    <tr>
                        <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><b>Trust Name</b></td>
                        <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><b>Status</b></td>
                        <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd; text-align: right;"><b>Amount</b></td>
                    </tr>
                    <?php
                    if ($ptOtherDetails) {
                        $Total = 0.00;
                        foreach ($ptOtherDetails as $key => $value) {
                            $Total += $value->amount;
                            ?>
                            <tr>
                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $value->trust_name; ?></td>
                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $value->trust_status; ?></td>
                                <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd; text-align: right;"><?php echo numberformat($value->amount); ?></td>

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 <!-- <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $value->col3; ?></td>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 <td style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $value->col4; ?></td> -->
                            </tr>
                            <?php
                        }
                    } if ($ptOtherDetails) {
                        ?>
                        <tr><td colspan="3" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd; text-align: right;"><b>Total - RS <?php echo numberformat((float) $Total); ?> </b></td></tr>
                    <?php } ?>
                </table>
            </td>
        </tr>
        <tr>
            <td height="30"></td>
        </tr>
        <tr>
            <td>
                <table  width="100%"  cellspacing="0" cellpadding="0" style="border-collapse: collapse;  border: 1px solid #ddd;">
                    <tr>
                        <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">DOCUMENTS PROVIDED BY PATIENT</td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->Birth_certificate ? $checkbox_checked : $checkbox_uncheck; ?>  Birth certificate</span></td>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->salary_slips ? $checkbox_checked : $checkbox_uncheck; ?>  Salary slips / proof</span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->income_certificate ? $checkbox_checked : $checkbox_uncheck; ?>  Income certificate</span></td>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->ration_card ? $checkbox_checked : $checkbox_uncheck; ?>  Ration card</span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->doctors_letter ? $checkbox_checked : $checkbox_uncheck; ?>  Doctor’s letter</span></td>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->adhaar_card ? $checkbox_checked : $checkbox_uncheck; ?>  Aadhar Card</span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->pan_card_or_election_id ? $checkbox_checked : $checkbox_uncheck; ?>  Pan card / Election ID</span></td>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->appeal_letter ? $checkbox_checked : $checkbox_uncheck; ?>  Appeal letter from hospital attesting to physical condition and funds required</span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->photograph ? $checkbox_checked : $checkbox_uncheck; ?>  Photograph</span></td>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->insurance_paper ? $checkbox_checked : $checkbox_uncheck; ?>  Insurance papers</span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->medical_bills_current ? $checkbox_checked : $checkbox_uncheck; ?>  Medical bills for current ailment</span></td>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->ref_or_contact_people ? $checkbox_checked : $checkbox_uncheck; ?> References and contact details of people outside family</span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->hla_match_report ? $checkbox_checked : $checkbox_uncheck; ?>  HLA Match report</span></td>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->affidavit ? $checkbox_checked : $checkbox_uncheck; ?> Affidavit</span></td>
                    </tr>
                    <tr>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->medical_report ? $checkbox_checked : $checkbox_uncheck; ?> Medical report</span></td>
                        <td style="font-size:13px; color:#000; padding:8px ;"><span><?php echo $ptDocumentDetails[0]->transplant_doc ? $checkbox_checked : $checkbox_uncheck; ?> Transplant Related Documents</span></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td height="30"></td>
        </tr>
        <tr>
            <td>
                <table  width="100%"  cellspacing="0" cellpadding="0" style="border-collapse: collapse;  border: 1px solid #ddd;">
                    <tr>
                        <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">KARO NOTES</td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ; font-weight:bold;">Social Worker Name:  <span style="font-weight:normal;"><?php echo $ptNotesDetails[0]->SocailWorkerName ? $ptNotesDetails[0]->SocailWorkerName : ''; ?></span></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ;">Social Worker Notes</td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ; font-weight:bold;">Profiling:</td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ;"></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ;">Upon profiling, does the social worker deem this case to be genuine? – <span><?php echo $ptNotesDetails[0]->IsProfileGenuine ? $ptNotesDetails[0]->IsProfileGenuine : ''; ?></span></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ;">Grade the urgency level of treatment – <span><?php echo $ptNotesDetails[0]->Rating; ?></span></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ;">Does the social worker recommend further investigation? – <span><?php echo $ptNotesDetails[0]->Investigation_Recommend ? $ptNotesDetails[0]->Investigation_Recommend : ''; ?></span></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ;">How does the social worker want to take this case forward? – <span><?php echo $ptNotesDetails[0]->Case_Status ? $ptNotesDetails[0]->Case_Status : ''; ?></span></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ;"></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ;  font-weight:bold;">Comments: <p style="font-weight:normal;"><?php echo $ptNotesDetails[0]->remarks ? $ptNotesDetails[0]->remarks : ''; ?></p></td>
                    </tr>
                </table>
            </td>
        </tr>
		
		 <tr>
            <td height="30"></td>
        </tr>

            <tr>
            <td>
                <table  width="100%"  cellspacing="0" cellpadding="0" style="border-collapse: collapse;  border: 1px solid #ddd;">
                    <tr>
                        <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">KARO INTERVENTION</td>
                    </tr>
                     <tr>
                        <td  style="font-size:13px; color:#000; padding:8px ;">Case approved by the trustees-  <span style="font-weight:normal;"></span></td>
						<td align="left" style="font-size:13px; color:#000; padding:8px ;" ><?php echo ($karoIntervention[0]->ApprovalDate == "") ? "" : date('d/m/Y',strtotime($karoIntervention[0]->ApprovalDate)); ?></td>
                    </tr>
                    <tr>
                        <td  style="font-size:13px; color:#000; padding:8px ;">Action taken by the trustee- </td>
						<td align="left" style="font-size:13px; color:#000; padding:8px ; "><?php echo $karoIntervention[0]->CurrentSttatus ? $karoIntervention[0]->CurrentSttatus : ''; ?></td>
                    </tr>
                    <tr>
                        <td  style="font-size:13px; color:#000; padding:8px ;">Amount Approved- </td>
						<td align="left" style="font-size:13px; color:#000; padding:8px ;"><?php echo preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$karoIntervention[0]->TotalApprovedAmount) ? preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$karoIntervention[0]->TotalApprovedAmount) : ''; ?></td>
                    </tr>
                    <tr>
                        <td  style="font-size:13px; color:#000; padding:8px ;">Sanction letter sent- </td>
						<td align="left" style="font-size:13px; color:#000; padding:8px ; "><?php echo $karoIntervention[0]->DonerName ? $karoIntervention[0]->DonerName : ''; ?></td>
                    </tr>
					 <tr>
                        <td colspan="2" style="font-size:13px; color:#000; padding:8px ;">&nbsp; </td>
                    </tr>
					<?php foreach($KaroInterventionDetails as $KaroIntervention1 ){
                   
						?>
					 <tr>
                                    
                        <th align="left" colspan=2 style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo ($KaroIntervention1->RecurringSupport == '1') ? 'Recurring Support' : 'Support'; ?></th>
                     </tr>
					 <tr>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd">Approval Date</td>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo date('d/m/Y',strtotime($KaroIntervention1->CaseDate)) ? date('d/m/Y',strtotime($KaroIntervention1->CaseDate)) : ''; ?></td>
                    </tr>
					 <tr>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd">Approval Amount</td>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$KaroIntervention1->AmountApproved) ? preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$KaroIntervention1->AmountApproved) : ''; ?></td>
                    </tr>
					 <tr>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd">Doner</td>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo $KaroIntervention1->DonerName ? $KaroIntervention1->DonerName : ''; ?></td>
                    </tr>
					 <tr>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd">Reason</td>
                                    <td align="left" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo $KaroIntervention1->Reason ? $KaroIntervention1->Reason : ''; ?></td>
                    </tr>
					 <?php } ?>
					 
                   <tr>
                        <td colspan="2" style="font-size:14px; color:#000; padding:8px ;  font-weight:bold; margin-top:20px;">Fund disbursals updates:
                                                       <table border="1"   style="border-collapse: collapse ;margin-top:20px">
                                <tr>
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Our Intervetnion</th>
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Sanction Date</th>
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Sanction Amount</th>
									<th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Disburse Date</th>
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Disburse  Amount</th>
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Doner</th>
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Bank</th>
									<th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Trans. Mode</th>
									<th  align="left" style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Receipt No</th>
									<th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">File Upload</th>
                                </tr>
                                <?php 
								 $total_sanc=0.00;
								 $total_disb=0.00;
								 							// for($i=1;$i<=5;$i++){
										// $t=	$i;					
									 
									// }
									$seq=0;
								foreach($disbursedAmountDetails as $dis_details ){
                                 									
								$total_sanc +=$dis_details->TransAmt;
								$total_disb +=$dis_details->DisburseAmt;
								if($dis_details->TransType != 'Support' && ($dis_details->case_status == 'rehelp' || $dis_details->case_status == 'reopen')){ 
								$seq = $seq+1;
								}
								
								
								?>
                                 <tr>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";>
									<?php 
                                         //echo  $dis_details->TransType ? $dis_details->TransType.'-'.$seq : '';
										 echo (($dis_details->TransType == '') ? '' : (($seq == 0) ? $dis_details->TransType : $dis_details->TransType.'-'.$seq ));
									?>
									
									</td>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo ($dis_details->TransDate == "") ? "" : $dis_details->TransDate; ?></td>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$dis_details->TransAmt) ? preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$dis_details->TransAmt) : ''; ?></td>
									<td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo ($dis_details->DisburseDate == "") ? "" : date('d/m/Y',strtotime($dis_details->DisburseDate)); ?></td>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$dis_details->DisburseAmt) ? preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$dis_details->DisburseAmt) : ''; ?></td>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->DonerName ? $dis_details->DonerName : ''; ?></td>
									<td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->Bank ? $dis_details->Bank : ''; ?></td>
									<td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->PaymentMethod ? $dis_details->PaymentMethod : ''; ?></td>
									<td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->RecdeiptNo ? $dis_details->RecdeiptNo : ''; ?></td>
									<td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->ReceiptUploaded ? $dis_details->ReceiptUploaded : ''; ?></td>
                                    
                                </tr>
                                <?php } ?>
								<tr><td colspan="10" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd; text-align: right;"><b>Total Sanction Amount - RS <?php echo preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$total_sanc); ?> </b></td></tr>
								<tr><td colspan="10" style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd; text-align: right;"><b>Total Disbursed Amount - RS <?php echo preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$total_disb); ?> </b></td></tr>
                            </table>
                        </td>
                    </tr>
					
					<tr>
					 <?php if ($refundAmountDetails) { ?>
                        <td colspan="2" style="font-size:14px; color:#000; padding:8px ;  font-weight:bold; margin-top:20px">Fund Refund Details:
                                                       <table border="1"   style="border-collapse: collapse ; margin-top:20px">
									
                                <tr>
                                    
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Refund Date</th>
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Refund Amount</th>
									
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Doner</th>
                                    <th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Bank</th>
									<th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Trans. Mode</th>
									<th  align="left" style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">Cheque No</th>
									<th  align="left"  style="font-size:13px; color:#000000	; padding:8px ; border: 1px solid #ddd;">File Upload</th>
                                </tr>
                                  <?php foreach($refundAmountDetails as $dis_details ){ ?>
                                 <tr>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo ($dis_details->TransDate == "") ? "" : date('d/m/Y',strtotime($dis_details->TransDate)); ?></td>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$dis_details->TransAmt) ? preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,",$dis_details->TransAmt) : ''; ?></td>
                                    <td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->DonerName ? $dis_details->DonerName : ''; ?></td>
									<td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->Bank ? $dis_details->Bank : ''; ?></td>
									<td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->PaymentMethod ? $dis_details->PaymentMethod : ''; ?></td>
									<td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->TransNo ? $dis_details->TransNo : ''; ?></td>
									<td  style="font-size:13px; color:#000; padding:8px ; border: 1px solid #ddd";><?php echo $dis_details->ReceiptUploaded ? $dis_details->ReceiptUploaded : ''; ?></td>
                                    
                                </tr>
<?php }} ?>
                            </table>
                        </td>
                    </tr>
					

                </table>
            </td>
        </tr>
    </table>
</div>