
<div style="margin:0 auto; width:100%; font-family: 'Open Sans', sans-serif; border:1px solid #f1f1f1;background:#fff;">
  <table width="100%" style=" color:#666666;  padding:25px 30px 45px 30px;" border="0" cellspacing="0" cellpadding="0">
    
    
    <tr>
      <td>
      <table  width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td style="font-size:14px; color:#000;"><p>Date –<?php echo  date('d F, Y',strtotime($ptMasterDetails[0]->registration_date));?> </p></td>
            <td align="center"><img src="<?php echo $logo; ?>" style="text-align: center;"></td>
            <td align="right">
            <table cellspacing="0" cellpadding="0" border="1" style="white-space:nowrap; border-collapse: collapse;" >
        <tr>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd">Home Visit</td>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo ($ptMasterDetails[0]->registration_site== 'HM') ? 'YES' :'' ; ?> </td>
        </tr>
        <tr>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd">Hospital Visit</td>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo ($ptMasterDetails[0]->registration_site== 'HV') ? 'YES' :'' ; ?> </td>
        </tr>
        <tr>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd">In Office</td>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd"><?php echo ($ptMasterDetails[0]->registration_site== 'IO') ? 'YES' :'' ; ?> </td>
        </tr>
</table>
            </td>
          </tr>
  
        </table>
      </td>
    </tr>
    <tr>
    <td>
    <table  width="100%"  cellspacing="0" cellpadding="0" style="border-collapse: collapse;  border: 0px solid #ddd;">
    <tr>
    <td colspan="2" align="center" style="font-size:16px; font-weight:600; color:#000; padding:8px;">MEDICAL ASSISTANCE REQUEST FORM</td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px;">Patient Case: <span style="border-bottom:1px solid #000;"> <?php echo $ptMasterDetails[0]->patient_case ? $ptMasterDetails[0]->patient_case:'' ; ?></span></td>
    <td rowspan="3" style="font-size:14px; color:#000; padding:0px; border:1px solid #000; height:140px; width:140px;"><img src="<?php echo $ptMasterDetails[0]->patient_image ? $ptMasterDetails[0]->patient_image : '';?>" width="140px" height="140px"/></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px;">Referred To KARO By: <span style="border-bottom:1px solid #000;"><?php echo $ptMasterDetails[0]->ReferedByName ? $ptMasterDetails[0]->ReferedByName:'' ; ?></span></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px;">Contact Details of Referral: <span style="border-bottom:1px solid #000;"><?php echo $ptMasterDetails[0]->Contact_Details_Of_Referral ? $ptMasterDetails[0]->Contact_Details_Of_Referral:'' ; ?></span></td>
    </tr>
    </table>
    </td>
    </tr>
    <tr>
    <td height="30"></td>
    </tr>
    <tr>
    <td>
    <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
    <tr>
    <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">PATIENT'S PERSONAL DETAILS</td>
    </tr>
    <tr>
    <td colspan="2">
    <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Name:</td>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->patient_name ?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Age:</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->Patient_Age ?></td>
     <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Gender:</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->Patient_Gender ?></td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Language Spoken:</td>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo str_replace('Other', ' ', $ptMasterDetails[0]->Language_Spoken );?></td>
    </tr>
     <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Address:</td>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->Patient_Address ?></td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Telephone/Contact Number:</td>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->ContactNOs ?></td>
    </tr>
    </table>
    </td>
    </tr>
   
    
   
    </table>
    </td>
    </tr>
    
    <tr>
    <td height="30"></td>
    </tr>
    <tr>
    <td width="100%">
    <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;" >
    <tr>
    <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">PATIENT'S FAMILY DETAILS</td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Total No. Of people in close (immediate or extended) family:</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMasterDetails[0]->TotalFamilyMembers? $ptMasterDetails[0]->TotalFamilyMembers:'';?></td>
    </tr>
    <tr>
    <td colspan="2">
    <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;" >
    <?php if($ptFamilyDetails) {?>
    <tr>
        <th align="left" bgcolor="#f0643b" style="font-size:14px; color:#fff; padding:8px ; border: 1px solid #ddd;">Name</th>
        <th align="left" bgcolor="#f0643b" style="font-size:14px; color:#fff; padding:8px ; border: 1px solid #ddd;">Relation</th>
        <th align="left" bgcolor="#f0643b" style="font-size:14px; color:#fff; padding:8px ; border: 1px solid #ddd;">Age</th>
        <th align="left" bgcolor="#f0643b" style="font-size:14px; color:#fff; padding:8px ; border: 1px solid #ddd;">Occupation</th>
        <th align="left" bgcolor="#f0643b" style="font-size:14px; color:#fff; padding:8px ; border: 1px solid #ddd;">Salary/Fees</th>

    </tr>
    <?php foreach($ptFamilyDetails as $row){ ?>
    <tr>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->Relative_Name; ?></td>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->relative_age; ?></td>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->relation; ?></td>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->occupation; ?></td>
            <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $row->salary; ?></td>

        </tr>
        <?php } ?>
    <?php } ?> 
    </table>
    </td>
    </tr>  
    </table>
    </td>
    </tr>
    
    <tr>
    <td height="30"></td>
    </tr>
    <tr>
    <td>
    <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
    <tr>
    <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">PATIENT'S MEDICAL DETAILS</td>
    </tr>
    <?php if($ptMedicalDetails){?>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Blood Group: </td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Blood_Group ? $ptMedicalDetails[0]->Blood_Group:''; ?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Hospital Name and address: </td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Hospital_Name_Address ? $ptMedicalDetails[0]->Hospital_Name_Address:''; ?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Department and Ward: </td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Department ? $ptMedicalDetails[0]->Department:''; ?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Doctor's Name: </td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Doctor_Name ? $ptMedicalDetails[0]->Doctor_Name:''; ?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Current diagnosed illness / problem and details of what is medically required next: </td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Disease_Diagnosed ? $ptMedicalDetails[0]->Disease_Diagnosed:''; ?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">When was illness/problem detected: </td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Disease_Detail ? $ptMedicalDetails[0]->Disease_Detail:''; ?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">How much of the treatment is currently completed: </td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptMedicalDetails[0]->Treatment_Complete_Details ? $ptMedicalDetails[0]->Treatment_Complete_Details:''; ?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><strong>PATH TO HEALING:</strong> </td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>Week -<?php echo $ptMedicalDetails[0]->Healing_Time == 'Week' ? 'YES':''; ?> </p><p>  Month - <?php echo $ptMedicalDetails[0]->Healing_Time == 'Month' ? 'YES':''; ?> </p> <p>Year - <?php echo $ptMedicalDetails[0]->Healing_Time == 'Year' ? 'YES':''; ?>  </p><p>Life long - <?php echo $ptMedicalDetails[0]->Healing_Time == 'Life long' ? 'YES':''; ?></p></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">What medication is patient taking currently: </td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>Pre surgery - <?php echo trim($ptMedicalDetails[0]->Pre_Surgery) ? 'YES' :'';?>  </p>
     <p>Hospitalized / Surgery / Transplant - <?php echo trim($ptMedicalDetails[0]->Hospitalized) ? 'YES' :'';?>   </p>
     <p>Post-surgery / treatment -  <?php echo trim($ptMedicalDetails[0]->Post_Surgery) ? 'YES' :'';?></p>
     <p>Exercise -  <?php echo trim($ptMedicalDetails[0]->Excercise) ? 'YES' :'';?> </p>
     <p>Medicines specify - <?php echo trim($ptMedicalDetails[0]->medicines_details) ? $ptMedicalDetails[0]->medicines_details :''; ?>  </p></td>
    </tr>
     <?php  } ?>
    </table>
    </td>
    </tr>
    
    <tr>
    <td height="30"></td>
    </tr>
    <tr>
    <td>
    <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
    <tr>
    <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">FINANCIAL DETAILS</td>
    </tr>
    <?php if($ptFinancialDetails){?>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Assets owned by patient/patient’s guardian and family (e.g.: house, land, shop, vehicle etc)</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p><?php echo $ptFinancialDetails[0]->owned_house; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->owned_land; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->owned_shop; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->owned_vechicle; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->owned_other; ?> </p></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Fixed monthly costs of patient (rent, school fee, cable, electricity, food, transport, etc)</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p><?php echo $ptFinancialDetails[0]->rent_amount; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->school_fees_amount; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->cable_amount; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->electric_city_amount; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->food_amount; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->transport_amount; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->other_expense_amount; ?> </p></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">How much has patient spent on treatment already</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->money_already_expend;?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Did he/she have to sell any assets to pay for treatment so far?</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->sale_any_assest;?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Does he / she have any loans or mortgages currently?</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->loan_detail;?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Does the patient have insurance? Add details of insurance / mediclaim</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->insurance_detail;?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">How did patient manage treatment expenses so far?</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p><?php echo $ptFinancialDetails[0]->treatment_expenses_own; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->treatment_expenses_friend; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->treatment_expenses_relatives; ?> </p>
        <p><?php echo $ptFinancialDetails[0]->treatment_expenses_othertrust; echo trim($ptFinancialDetails[0]->other_trust_amount) ? $ptFinancialDetails[0]->other_trust_amount :'';  ?> </p></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Amount of current funding required by patient</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $ptFinancialDetails[0]->required_fund;?></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Is funding requirement short term or long term? Short term = < 6 months, Long term = > 6 months</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>Short Term – <?php echo trim($ptFinancialDetails[0]->Fund_Required_For) =='Short Term' ? 'YES' :''; ?> </p>
        <p>Long Term – <?php echo trim($ptFinancialDetails[0]->Fund_Required_For) =='Long Term' ? 'YES' :''; ?> </p></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">Is funding requirement one time or recurring</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>One time – <?php echo trim($ptFinancialDetails[0]->fund_requirement) =='OT' ? 'YES' :''; ?> </p>
        <p>Recurring – <?php echo trim($ptFinancialDetails[0]->fund_requirement) =='REC' ? 'YES' :''; ?> </p>
        </td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">What the aforementioned funding will cover</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>Surgery / Transplant – <?php echo trim($ptFinancialDetails[0]->funding_cover_surgery) ? 'YES' :''; ?> </p>
        <p>Treatment – <?php echo trim($ptFinancialDetails[0]->funding_cover_treatment) ? 'YES' :''; ?> </p>
        <p>Medication – <?php echo trim($ptFinancialDetails[0]->funding_cover_meditation) ? 'YES' :''; ?> </p>
        <p>Day to day expenses – <?php echo trim($ptFinancialDetails[0]->funding_cover_dalyexpense) ? 'YES' :''; ?> </p>
        <p>(travelling / food / any other) – <?php echo $ptFinancialDetails[0]->funding_cover_travelling.' '.$ptFinancialDetails[0]->funding_cover_food .' '.$ptFinancialDetails[0]->funding_cover_other ; ?> </p></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">How much has PBF / PBCF covered? Any proof of this available?</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>Yes<input type="checkbox" name="" <?php echo $ptFinancialDetails[0]->pbf_pcf=='Yes'? 'checked="checked"':'';?> > <?php echo $ptFinancialDetails[0]->pbf_pcf_amt > 0? $ptFinancialDetails[0]->pbf_pcf_amt:'';?></p>
       <p>No<input type="checkbox" name="" <?php echo $ptFinancialDetails[0]->pbf_pcf=='No'? 'checked="checked"':'';?> > </p>
       <p>NA<input type="checkbox" name="" <?php echo $ptFinancialDetails[0]->pbf_pcf=='NA'? 'checked="checked"':'';?> ></p></td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;">If denied previous funding, reason for denial</td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><p>Because of their policy  <input type="checkbox" name="" <?php echo $ptFinancialDetails[0]->prev_funding==1? 'checked="checked"':'';?> > </p>
        <p>Rules and regulations <input type="checkbox" name="" <?php echo $ptFinancialDetails[0]->prev_funding== 0 ? 'checked="checked"':'';?> > </p>
       <p>NA<input type="checkbox" name="" <?php echo $ptFinancialDetails[0]->prev_funding=='2'? 'checked="checked"':'';?> ></p></td>
    </tr>
    <?php }?>
    </table>
    </td>
    </tr>
    
    <tr>
    <td height="30"></td>
    </tr>
    <tr>
    <td>
    <table  width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd"><b>Other trusts supported / applied </b> -</td>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd">KARO</td>
    </tr>
    <?php if($ptOtherDetails){ 
        foreach ($ptOtherDetails as $key => $value) { ?>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $value->col1; ?></td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $value->col2; ?></td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $value->col3; ?></td>
    <td style="font-size:14px; color:#000; padding:8px ; border: 1px solid #ddd;"><?php echo $value->col4; ?></td>
    </tr>
    <?php }}?>
    </table>
    </td>
    </tr>
    
    <tr>
    <td height="30"></td>
    </tr>
    <tr>
    <td>
    <table  width="100%"  cellspacing="0" cellpadding="0" style="border-collapse: collapse;  border: 1px solid #ddd;">
    <tr>
    <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">DOCUMENTS PROVIDED BY PATIENT</td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span><input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->Birth_certificate ?'checked="checked"':''; ?> > Birth certificate / Income certificate <input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->income_certificate ?'checked="checked"':''; ?> ></span>
    </td>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span> Salary slips / proof <input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->salary_slips ?'checked="checked"':''; ?> > </span>
    </td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span><input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->ration_card ?'checked="checked"':''; ?> > Ration card / Aadhar Card <input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->adhaar_card ?'checked="checked"':''; ?> ></span>
    </td>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span>Doctor’s letter <input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->doctors_letter ?'checked="checked"':''; ?> ></span>
    </td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span><input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->pan_card_or_election_id ?'checked="checked"':''; ?> > Pan card / Election ID </span>
    </td>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span>Appeal letter from hospital attesting to physical condition and funds required <input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->appeal_letter ?'checked="checked"':''; ?> ></span>
    </td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span>Photograph <input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->photograph ?'checked="checked"':''; ?> ></span>
    </td>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span>Insurance papers <input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->insurance_paper ?'checked="checked"':''; ?> ></span>
    </td>
    </tr>
    <tr>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span>Medical bills for current ailment <input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->medical_bills_current ?'checked="checked"':''; ?> ></span>
    </td>
    <td style="font-size:14px; color:#000; padding:8px ;">
    <span>References and contact details of people outside family <input type="checkbox" name="" <?php echo $ptDocumentDetails[0]->ref_or_contact_people ?'checked="checked"':''; ?>></span>
    </td>
    </tr>
    </table>
    </td>
    </tr>
    
    <tr>
    <td height="30"></td>
    </tr>
    <tr>
    <td>
    <table  width="100%"  cellspacing="0" cellpadding="0" style="border-collapse: collapse;  border: 1px solid #ddd;">
    <tr>
    <td colspan="2" bgcolor="#f0643b" style="font-size:16px; font-weight:600; color:#fff; padding:8px ; border: 1px solid #f0643b;">KARO NOTES</td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; font-weight:bold;">Social Worker Name: <?php echo $ptNotesDetails[0]->SocailWorkerName ? $ptNotesDetails[0]->SocailWorkerName : ''; ?></td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ;">Social Worker Notes</td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ; font-weight:bold;">Profiling:</td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ;"></td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ;">Upon profiling, does the social worker deem this case to be genuine? – <p><?php echo $ptNotesDetails[0]->IsProfileGenuine ? $ptNotesDetails[0]->IsProfileGenuine : '';?></p></td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ;">Grade the urgency level of treatment – <p><?php echo $ptNotesDetails[0]->Rating ;?></p></td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ;">Does the social worker recommend further investigation? – <p><?php echo $ptNotesDetails[0]->Investigation_Recommend ? $ptNotesDetails[0]->Investigation_Recommend : '';?></p></td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ;">How does the social worker want to take this case forward? – <p><?php echo $ptNotesDetails[0]->Case_Status ? $ptNotesDetails[0]->Case_Status : '';?></p></td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ;"></td>
    </tr>
    <tr>
    <td colspan="2" style="font-size:14px; color:#000; padding:8px ;  font-weight:bold;">Comments: <p><?php echo $ptNotesDetails[0]->remarks ? $ptNotesDetails[0]->remarks : '';?></p></td>
    </tr>
    </table>
    </td>
    </tr>
 </table>

</div>










