<style>
    label.error{
        color:red;
    }
    span.error{
        color:red;
    }
    .mandate{
        color:red;
    }
	
</style>
<div class="dash_right_section">
    <h2 class="main-heading">Users</h2>

    <?php if (isset($_REQUEST['act'])) { ?>
        <?php if ($_REQUEST['act'] == 'update') { ?>
            <?php
            $attributes = array('class' => 'users', 'id' => 'users');
            echo form_open_multipart('users/updateuser', $attributes);
           
            ?>
            
    <div class="dash_column">
        <div><?php echo $this->session->flashdata('message'); ?></div>
         <div class="row">
<div class="col-md-offset-8 col-md-4">
<div class="dash_column">
<div class="user-profile">
<div class="user_img"><img src="<?php echo base_url(); ?>karoclient/usersprofile/<?php echo $userByID['0']['UserImage']; ?>"></div>
</div>
</div>
</div>
<div class="clearfix"></div>
</div>   
        <div class="row">
            <div class="form-group col-md-12">
                <label for="name">Email ID<span class="mandate">*</span></label>
                <input id="UserId" name="UserId" value="<?php echo base64_encode($userByID['0']['UserId']); ?>" type="hidden" class="form-control specialchr">
                <input maxlength="100" id="primary_email" name="primary_email" type="text" class="form-control" placeholder="Enter email" onblur="checkemailforUpdtae(this.value,'primary_email_error','<?php echo $userByID['0']['UserId']; ?>');" value="<?php echo $userByID['0']['PrimaryEmailId']; ?>">
                <span id="primary_email_error" class="error"></span>
            </div>
           
           
        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">First Name<span class="mandate">*</span></label>
                <input maxlength="100" id="first_name" name="first_name" type="text" class="form-control" placeholder="Enter first name" value="<?php echo $userByID['0']['FirstName']; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Middle Name</label>
                <input maxlength="100" id="middle_name" name="middle_name" type="text" class="form-control" placeholder="Enter middle name" value="<?php echo $userByID['0']['MiddleName']; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Last Name</label>
                <input maxlength="100" id="last_name" name="last_name" type="text" class="form-control" placeholder="Enter last name" value="<?php echo $userByID['0']['LastName']; ?>">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">Gender<span class="mandate">*</span></label>
                <div style="margin-top:10px;">
                    <label class="customradio col-md-4"><span class="radiotextsty">Male</span>
                        <input type="radio" name="gender" value="Male" <?php if($userByID['0']['Gender']=='Male'){echo "checked=checked";}?>>
                        <span class="checkmark"></span>
                    </label>
                    <label class="customradio col-md-4"><span class="radiotextsty">Female</span>
                        <input type="radio" name="gender" value="Female" <?php if($userByID['0']['Gender']=='Female'){echo "checked=checked";}?>>
                        <span class="checkmark"></span>
                    </label>
                    <label id="gender-error" class="error" for="gender"></label>
                </div>
            </div>
            <div class="form-group col-md-4">
                <label for="name">Age(Years)<span class="mandate">*</span></label>
                <input type="text" id="age" name="age" class="form-control" value="<?php echo $userByID['0']['Age']; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">User Image</label>
                <input type="file" name="userimage" class="form-control file" id="" aria-describedby="">
                <?php if($userByID['0']['UserImage']!=''){?>
                <input id="preuserimage" name="preuserimage" value="<?php echo $userByID['0']['UserImage']; ?>" type="hidden" class="form-control">
                <?php } ?>
            </div>


        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">Address</label>
                <textarea class="form-control" name="address" id="address" rows="3"><?php echo $userByID['0']['Address']; ?></textarea>
            </div>
            <div class="form-group col-md-4">
                <label for="name">State<span class="mandate">*</span></label>
                <select id="state" name="state"  class="form-control" onchange="getcities(this.value, 'city');">
                    <option value=""> Select State</option>
                    <?php foreach ($states as $state) { ?>
                        <option value="<?php echo $state['city_state']; ?>" <?php if ($userByID['0']['State'] == $state['city_state']) {
                        echo "selected='selected'"; } ?>><?php echo $state['city_state']; ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="name">City<span class="mandate">*</span></label>
                <select class="form-control" name="city" id="city">
                    <option value=""> Select City</option>  
                            <?php
                            if (!empty($cities)) {
                                foreach ($cities as $city) {
                                    if ($city['city_name'] == $userByID['0']['City']) {
                                        $selected = "selected='selected'";
                                    } else {
                                        $selected = '';
                                    }
                                    echo "<option value='" . $city['city_name'] . "' " . $selected . ">" . $city['city_name'] . "</option>";
                                }
                            }
                                ?>
                </select>
            </div>

            

        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">Pin Code<span class="mandate">*</span></label>
                <input type="text" id="zipcode" name="zipcode" class="form-control" placeholder="Enter pin code" value="<?php echo $userByID['0']['ZipCode']; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Primary Contact No<span class="mandate">*</span></label>
                <input maxlength="100" type="text" id="primary_contact" name="primary_contact" class="form-control" placeholder="Enter primary contact no." value="<?php echo $userByID['0']['PrimaryContactNo']; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Secondary Contact No</label>
                <input maxlength="100" type="text" id="secondary_contact" name="secondary_contact" class="form-control" placeholder="Enter secondary contact no." value="<?php echo $userByID['0']['SecondaryContactNo']; ?>">
            </div>
             
        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">User Type<span class="mandate">*</span></label>
                <select class="form-control" name="user_type" id="user_type">
                    <option value="">Select User Type</option>
                    <option value="Trustee" <?php if ($userByID['0']['UserType'] == 'Trustee') { echo "selected='selected'"; } ?>>Trustee</option>
                    <option value="Director" <?php if ($userByID['0']['UserType'] == 'Director') { echo "selected='selected'"; } ?>>Director</option>
                    <option value="Manager" <?php if ($userByID['0']['UserType'] == 'Manager') { echo "selected='selected'"; } ?>>Manager</option>
                    <option value="Social Worker" <?php if ($userByID['0']['UserType'] == 'Social Worker') { echo "selected='selected'"; } ?>>Social Worker</option>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="name">Is Active</label>
                <select class="form-control" name="is_active" id="is_active">
                    <option value="1" <?php if ($userByID['0']['IsActive'] == '1') { echo "selected='selected'"; } ?>>Yes</option>
                    <option value="0" <?php if ($userByID['0']['IsActive'] == '0') { echo "selected='selected'"; } ?>>No</option>
                </select>
            </div>
            <div class="form-group col-md-4" style="display:none">
                <label for="name">Is Admin</label>
                <select class="form-control" name="is_admin" id="is_admin">
                    <option value="1" <?php if ($userByID['0']['IsAdmin'] == '1') { echo "selected='selected'"; } ?>>Yes</option>
                    <option value="0" <?php if ($userByID['0']['IsAdmin'] == '0') { echo "selected='selected'"; } ?>>No</option>
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="save" class="btn btn-primary save">Save</button>
            </div>
        </div>
    </div>
    <?php
    }
    }else{
   
    $attributes = array('class' => 'users', 'id' => 'users');
    echo form_open_multipart('users/index', $attributes);
    ?>
    <div class="dash_column">
        <div><?php echo $this->session->flashdata('message'); ?></div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">Email ID<span class="mandate">*</span></label>
                <input maxlength="100" id="primary_email" name="primary_email" type="text" class="form-control" placeholder="Enter email" onblur="checkemail(this.value,'primary_email_error');">
                <span id="primary_email_error" class="error"></span>
            </div>
            <div class="form-group col-md-4">
                <label for="name">Password<span class="mandate">*</span></label>
                <input maxlength="100" id="password" name="password" type="password" class="form-control" placeholder="Enter password">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Confirm Password<span class="mandate">*</span></label>
                <input maxlength="100" id="confirm_password" name="confirm_password" type="password" class="form-control" placeholder="Enter password">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">First Name<span class="mandate">*</span></label>
                <input maxlength="100" id="first_name" name="first_name" type="text" class="form-control" placeholder="Enter first name">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Middle Name</label>
                <input maxlength="100" id="middle_name" name="middle_name" type="text" class="form-control" placeholder="Enter middle name">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Last Name</label>
                <input maxlength="100" id="last_name" name="last_name" type="text" class="form-control" placeholder="Enter last name">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">Gender<span class="mandate">*</span></label>
                <div style="margin-top:10px;">
                    <label class="customradio col-md-4"><span class="radiotextsty">Male</span>
                        <input type="radio" name="gender" value="Male">
                        <span class="checkmark"></span>
                    </label>
                    <label class="customradio col-md-4"><span class="radiotextsty">Female</span>
                        <input type="radio" name="gender" value="Female">
                        <span class="checkmark"></span>
                    </label>
                    <label id="gender-error" class="error" for="gender"></label>
                </div>
            </div>
            <div class="form-group col-md-4">
                <label for="name">Age(Years)<span class="mandate">*</span></label>
                <input maxlength="3" type="text" id="age" name="age" class="form-control" placeholder="Enter the Age">
            </div>
            <div class="form-group col-md-4">
                <label for="name">User Image</label>
                <input type="file" name="userimage" class="form-control file" id="" aria-describedby="">
            </div>


        </div>
        <div class="row">
        <div class="form-group col-md-4">
                <label for="name">Address</label>
                <textarea class="form-control" name="address" id="address" rows="3" placeholder="Enter the Address"></textarea>
            </div>
            <div class="form-group col-md-4">
                <label for="name">State<span class="mandate">*</span></label>
                <select id="state" name="state"  class="form-control" onchange="getcities(this.value, 'city');">
                    <option value=""> Select State</option>
                    <?php foreach ($states as $state) { ?>
                        <option value="<?php echo $state['city_state']; ?>"><?php echo $state['city_state']; ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="name">City<span class="mandate">*</span></label>
                <select class="form-control" name="city" id="city">
                    <option value="">Select City</option>
                </select>
            </div>

            

        </div>
        <div class="row">
        <div class="form-group col-md-4">
                <label for="name">Pin Code<span class="mandate">*</span></label>
                <input maxlength="10" type="text" id="zipcode" name="zipcode" class="form-control" placeholder="Enter pin code">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Primary Contact No<span class="mandate">*</span></label>
                <input maxlength="15" type="text" id="primary_contact" name="primary_contact" class="form-control" placeholder="Enter primary contact no.">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Secondary Contact No</label>
                <input type="text" id="secondary_contact" name="secondary_contact" class="form-control" placeholder="Enter secondary contact no.">
            </div>
             
        </div>
        <div class="row">
        <div class="form-group col-md-4">
                <label for="name">User Type<span class="mandate">*</span></label>
                <select class="form-control" name="user_type" id="user_type">
                    <option value="">Select User Type</option>
                    <option value="Trustee">Trustee</option>
                    <option value="Director">Director</option>
                    <option value="Manager">Manager</option>
                    <option value="Social Worker">Social Worker</option>
                </select>
            </div>
            
            <div class="form-group col-md-4">
                <label for="name">Is Active</label>
                <select class="form-control" name="is_active" id="is_active">
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                </select>
            </div>
            <div class="form-group col-md-4" style="display:none;">
                <label for="name">Is Admin</label>
                <select class="form-control" name="is_admin" id="is_admin">
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="save" class="btn btn-primary save">Save</button>
            </div>
        </div>
    </div>
</form> 
    <?php } ?>
<div class="dash_column">
    <div class="tbl">
         <table id="disease" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Email Id</th>
                    <th>Name</th>
                    <th>State</th>
                    <th>City</th>
                    <th>Contact</th>                   
                    <th>Admin</th>   
                    <th>Status</th>                 
                    <th>Action</th>
                    <!-- <th></th> -->
                </tr>
            </thead>
            <tbody>
                 <?php
    if (!empty($getUsers)) {
        foreach ($getUsers as $getUser) {
            ?>
                <tr>
                    <td><?php echo $getUser['PrimaryEmailId']; ?></td>
                    <td><?php echo $getUser['FirstName']; ?></td>
                    <td><?php echo $getUser['State']; ?>.</td>
                    <td><?php echo $getUser['City']; ?></td>
                    <td><?php echo $getUser['PrimaryContactNo']; ?></td>
                    <td><?php echo ($getUser['IsAdmin']==1)?'Yes':'No'; ?></td>
                    <td>      <?php
                            if ($getUser['IsActive'] == '1') {
                                echo "Active";
                            } else {
                                echo "Inactive";
                            }
                            ?></td>
                    <td><a class="btn btn-info btn-xs" href="?act=update&id=<?php echo base64_encode($getUser['UserId']);?>" title="Edit"> <i class="fa fa-edit"></i></a>
                    
                        <a id='editref' href="javascript:void(0);" data-url="<?php echo site_url(); ?>/users/changestatus?status=<?php echo $getUser['IsActive']; ?>&id=<?php echo base64_encode($getUser['UserId']); ?>" title="<?php
                                       if ($getUser['IsActive'] == '1') {
                                           echo "click here to inactive";
                                       } else {
                                           echo "click here to active";
                                       }
                                       ?>" class="btn btn-<?php if ($getUser['IsActive'] == '0') {
                                echo "primary";
                            } else {
                                echo "danger";
                            } ?> btn-xs" onclick="changeStatusDynamically($(this),'Are you sure you want to <?php if ($getUser['IsActive'] == '1') {
                                echo "Dectivate";
                            } else {
                                echo "Activate";
                            } ?> this user ?');">
                            <?php
                            if ($getUser['IsActive'] == '1') {
                                // echo "Dectivate";
                                echo '<i class="fa fa-toggle-off"></i>';

                            } else {
                                // echo "Activate";
                                echo '<i class="fa fa-toggle-on"></i>';

                            }
                            ?>
                                    </a>
                        
                    </td>
                    
                    
                </tr>
    <?php } } ?>
            </tbody></table>
    </div>
</div>
</div>