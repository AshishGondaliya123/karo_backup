<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="dash_right_section">
    <h2 class="main-heading pull-left">Patient Details</h2>
    <div class="clearfix"></div>
    <h5 class="main-heading pull-left"><?php echo $label; ?></h5>
    <div class="clearfix"></div>
    <div class="dash_column family">
        <div class="tbl">
            <table id="view_patient_tbl" class="table table-striped table-bordered" width="100%">
                <thead>
                    <tr>
                        <th>Patient Id</th>
                        <th>Referral Name</th>
                        <th>Team Member</th>
                        <th>Name of Patient</th>
                        <?php
                        if (isset($show_column) && $show_column != '') {
                            echo "<th>";
                            if ($show_column == 'patient_age') {
                                echo 'Age';
                            } else if ($show_column == 'patient_dob') {
                                echo 'DOB';
                            } else if ($show_column == 'patient_gender') {
                                echo 'Gender';
                            } else if ($show_column == 'pp_state') {
                                echo "State";
                            } else if ($show_column == 'disease') {
                                echo "Department Name";
                            } else if ($show_column == 'userName') {
                                echo "User Name";
                            }
                            echo "</th>";
                        }
                        ?>
                        <th >Contact Numbers</th>
                        <th>Name of Hospital</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- commented to display hospital name -->
                    <?php
                    foreach ($patient as $p) {
                        ?>
                        <tr>
                            <td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $p['case_id'] ?>" title="Case Detail" target="_blank"><?php echo $p['patient_id'] ?></a></td>
                            <td><?php echo $p['referral_name'] ?></td>
                            <td><?php echo $p['re_name'] ?></td>
                            <td><?php echo $p['patient_name'] ?></td>
                            <?php if (isset($show_column) && $show_column != '') { ?>
                                <td><?php
                                    if ($show_column == "disease") {
                                        echo $_GET["label"];
                                    } else {
                                        echo $p[$show_column];
                                    }
                                    ?></td>
                            <?php } ?>
                            <td>
                                <?php echo!empty($p['patient_phone']) ? $p['patient_phone'] : '' ?>,
                                <?php echo $p['caregiver_phone'] . (empty($p['caregiver_phone2']) ? "" : ",<br/>" . $p['caregiver_phone2']); ?>
                            </td>
						<!--	<td><?php //echo!empty($p['patient_phone']) ? $p['patient_phone'] : '' ?></td>
							<td><?php //echo $p['caregiver_phone'] ?></td>
							<td><?php //echo (empty($p['caregiver_phone2']) ? "" :  $p['caregiver_phone2']); ?></td>-->
                            <td><?php echo $p['HospitalName'] ?></td>
                            <td width="300" >
                                <a class="btn btn-success btn-xs" href="<?php echo base_url() . 'index.php/patientmaster/index?uid=' . $p['id'] ?>" title="Edit Patient"><i class="fa fa-edit"></i></a>
                                <a class="btn btn-warning btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $p['case_id'] ?>" title="Case Detail"><i class="fa fa-info-circle"></i></a>
                                <a class="btn btn-primary btn-xs" href="<?php echo base_url() . 'index.php/patientcase/exportptdata?patient_id=' . $p['patient_id'] ?>" title="Patient Pdf" ><i class="fa fa-file-pdf-o"></i></a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <div class="clearfix"></div>
    </div>
</div>