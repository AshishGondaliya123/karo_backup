<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<style>
    .jconfirm-box-container.jconfirm-animated.col-md-4.col-md-offset-4.col-sm-6.col-sm-offset-3.col-xs-10.col-xs-offset-1.jconfirm-no-transition {
        width: 600px !important;
        margin-left: 25%;
    }
</style>
<div class="dash_right_section">
    <h2 class="main-heading pull-left">View Patient</h2>
    <div class="clearfix"></div>
    <div class="dash_column">
        <div><?php echo $this->session->flashdata('message');?></div>
        <?php
            $attributes = array('class' => 'view_patient', 'id' => 'view_patient');
            echo form_open('Patientmaster/viewpatient', $attributes);
        ?>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="department">Department</label>
                <select class="form-control" name="department" id="department">
                    <option value="">Select Department</option>
                    <?php
                    if($active_department){
                        foreach ($active_department as $key => $value) { ?>
                            <option value="<?php echo $value['DeptId'];?>" <?=(!empty($_POST['department']) && $_POST['department']==$value['DeptId']?"selected":"")?>> <?php echo $value['DeptName'];?></option>
                    <?php }
                    }?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="hospital">Hospital</label>
                <select class="form-control" name="hospital" id="hospital">
                    <option value="">Select Hospital</option>
                    <?php
                        if($active_hospital)
                        {
                            foreach ($active_hospital as $key => $value) { ?>
                            <option value="<?php echo $value['HospitalId'];?>" <?=(!empty($_POST['hospital']) && $_POST['hospital']==$value['HospitalId']?"selected":"")?>> <?php echo $value['HospitalName'];?></option>
                            <?php }}?>
                </select>
            </div>
             
            <div class="form-group col-md-4">
                <label for="representative_name">Team Member</label>
                <select class="form-control" name="representative_name" id="representative_name">
                    <option value="">Select Team Member</option>
                    <?php
                    foreach ($active_user as  $uv) { ?>
                        <option value="<?php echo $uv['UserId']; ?>" <?=(!empty($_POST['representative_name']) && $uv['representative_name']==$value['UserId']?"selected":"")?>><?php echo $uv['full_name']; ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group col-md-4">
                <label for="status">Status</label>
                <select class="form-control" name="status" id="status">
                    <option value="">All Cases</option>
                    <option value="New" <?=(!empty($_POST['status']) && $_POST['status']=="New"?"selected":"")?>>New</option>
                    <option value="open" <?=(!empty($_POST['status']) && $_POST['status']=="open"?"selected":"")?>>Open</option>
                    <option value="closed" <?=(!empty($_POST['status']) && $_POST['status']=="closed"?"selected":"")?>>Closed</option>
                    <option value="hold" <?=(!empty($_POST['status']) && $_POST['status']=="hold"?"selected":"")?>>Hold</option>
                    <option value="reject" <?=(!empty($_POST['status']) && $_POST['status']=="reject"?"selected":"")?>>Rejected</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="add" class="btn btn-primary save">Submit</button>
            </div>
        </div>
    </div> 
    <div class="dash_column family">
        <div class="tbl">
            <table id="view_patient_tbl" class="table table-striped table-bordered" width="100%">
                <thead>
                    <tr>
                        <th>Patient Id</th>
                        <th>Patient Name</th>
                        <th>Department</th>
                        <th>Hospital</th>
                        <th>Contact Numbers</th>
                        <th>Referral Name</th>
                        <th>Team Member</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- commented to display hospital name -->
                    <?php
                    foreach ($patient as $p) {
                        ?>
                        <tr id="remove<?php echo $p['id']; ?>">
						<td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $p['Caseid'] ?>" title="Case Detail" target="_blank"><?php echo $p['patient_id'] ?></a></td>
                            <td><?php echo $p['patient_name'] ?></td>
                            <td><?php echo $p['DepartmentName'] ?></td>
                            <td><?php echo $p['HospitalName'] ?></td>
                            <td>
                                <?php echo!empty($p['patient_phone']) ? $p['patient_phone'] . "," : ""; ?>
                                <br/>
                                <?php echo!empty($p['caregiver_phone']) ? $p['caregiver_phone'] . "," : ""; ?>
                                <br/>
                                <?php echo!empty($p['caregiver_phone2']) ? $p['caregiver_phone2'] : ""; ?>
                            </td>
                            <td><?php echo $p['referral_name'] ?></td>
                            <td><?php echo $p['team_member'] ?></td>
                            <td><?php echo ucwords($p['case_status']) ?></td>
                            <td width="300" >
                                <a class="btn btn-success btn-xs" href="<?php echo base_url() . 'index.php/patientmaster/index?uid=' . $p['id'] ?>" title="Edit Patient"><i class="fa fa-edit"></i></a>
                                <a class="btn btn-warning btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $p['Caseid'] ?>" title="Case Detail"><i class="fa fa-info-circle"></i></a>
                                <a class="btn btn-primary btn-xs" href="<?php echo base_url() . 'index.php/patientcase/exportptdata?patient_id=' . $p['patient_id'] ?>" title="Patient Pdf" target="_blank" ><i class="fa fa-file-pdf-o"></i></a>
                                <a class="btn btn-info btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $p['Caseid'].'&tabstatus=2' ?>" title="Disburse Funds"><i class="fa fa-money"></i></a> 
                                <a class="btn btn-info btn-xs" href="javascript:void(0)" title="Patient Transfer" onclick="openpatienttransfermodal(<?=$p['id']?>)"><i class="fa fa-user"></i></a> 
                                <!--akash rai 5 march 2020-->
                                <?php
                                $ci = & get_instance();
                                $state = $ci->patient_model->getCaseState($p['patient_id']);
                                ?>
                                <?php if ($this->session->userdata("IsAdmin") == 1) { ?>
                                    <a class="btn btn-danger btn-xs reject_hold_btn" href="javascript:void(0)" title="Delete Patient" onclick="remove_patient(<?php echo $p['id']; ?>, '<?php echo $p['patient_id']; ?>');"><i class="fa fa-trash"></i></a>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<div id="patienttransfer_modal" class="modal fade in">
    <div class="modal-dialog" style="width:500px;">
        <div class="modal-content">
            <a class=" close" data-dismiss="modal"><span>X</span></a>
            <div class="modal-header">
                <h4>Transfer patient to another user</h4>
            </div>
            <div class="modal-body">
                <div id="top-msg" class="top-msg" hidden></div>
                <div class="form-group row" >
                    <div class="col-md-12" >
                        <div id="assign_err" hidden></div>
                        <input type="hidden" id="patient_id" name="patient_id">
                        <label for="name"  style="font-size: 19px;color: black;">Select User</label>
                        <select id="assiged_user" name="assiged_user" class="form-control">
                            <option value="">Select User </option>
                            <?php
                            if ($active_user) {
                                foreach ($active_user as $uk => $uv) {
                                    if ($this->session->userdata('UsertId') == $uv["UserId"]) {
                                        
                                    } else {
                                        ?>
                                        <option value="<?php echo $uv['UserId']; ?>"> <?php echo $uv['full_name']; ?></option>
                                        <?php
                                    }
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary add close_modal" data-dismiss="modal">Close</button>
                <button class="btn btn-primary add" onclick="transferpatient()">Submit</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dalog -->
</div>

<script>
    function openpatienttransfermodal(pid) {
        $('#patient_id').val(pid);
        $("#patienttransfer_modal").modal("show");
    }
    function transferpatient() {
        var userid = $("#assiged_user").val();
        if(userid==0){
            $('#assign_err').addClass('alert alert-danger').text('Please Select User');
            $('#assign_err').show();
            setTimeout(function () {
                $("#assign_err").hide();
            }, 3000);
        }else{
            $.confirm({
                title: 'Confirm!',
                content: 'Are you sure you want to assign the patient to other user ?',
                buttons: {
                    cancel: function () {
                        // $.alert('Canceled!');
                    },
                    confirm: function () {
                        $.ajax({
                            url: baseurl + "index.php/patientmaster/assignedpatientToDiffUser?UserId=" + userid + "&patient_id=" + $('#patient_id').val(),
                            type: "GET",
                            contentType: false,
                            cache: false,
                            processData: false,
                            beforeSend: function ()
                            {
                                //$("#preview").fadeOut();
                                //$("#err").fadeOut(this);
                            },
                            success: function (data)
                            {
                                if (data == 'success') {
                                    window.location.reload();
                                } else
                                {
                                    $('#assign_err').addClass('alert alert-danger').text('Yet patient not created to assign some one');
                                    $('#assign_err').show();
                                    setTimeout(function () {
                                        $("#assign_err").hide();
                                    }, 3000);

                                }

                            },
                            error: function (e)
                            {
                                //$("#err").html(e).fadeIn();
                            }
                        });
                    },
                }
            });
        }
    }
    $('#assign_user_btn').click(function () {
    if ($('#assiged_user').val().length == 0)
    {
        $('#assign_err').addClass('alert alert-danger').text('Please Select User');
        $('#assign_err').show();
        setTimeout(function () {
            $("#assign_err").hide();
        }, 3000);
    } else
    {
        $.confirm({
            title: 'Confirm!',
            content: 'Are you sure you want to assign the patient to other user ?',
            buttons: {
                cancel: function () {
                    // $.alert('Canceled!');
                },
                confirm: function () {
                    $.ajax({
                        url: baseurl + "index.php/patientmaster/assignedDiffUser?Assigned_UserId=" + $('#assiged_user').val() + "&patient_case=" + $('#patient_case').val(),
                        type: "GET",
                        contentType: false,
                        cache: false,
                        processData: false,
                        beforeSend: function ()
                        {
                            //$("#preview").fadeOut();
                            //$("#err").fadeOut(this);
                        },
                        success: function (data)
                        {
                            if (data == 'success') {
                                window.location.replace(baseurl + 'index.php/patientmaster/viewpatient/');
                            } else
                            {
                                $('#assign_err').addClass('alert alert-danger').text('Yet patient not created to assign some one');
                                $('#assign_err').show();
                                setTimeout(function () {
                                    $("#assign_err").hide();
                                }, 3000);

                            }

                        },
                        error: function (e)
                        {
                            //$("#err").html(e).fadeIn();
                        }
                    });
                },
            }
        });

    }

});
</script>