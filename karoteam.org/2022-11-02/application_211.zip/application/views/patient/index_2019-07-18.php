<?php
if ($patient && !empty($patient)) {
    $patent_case = $patient["patient_case"];
    $refered_by = $patient["refered_by"];
    $pid = $patient["id"];
    $patient_id = $patient["patient_id"];
}

$referd_array =array('Doctor','MSW','Self','Others');
?>
<style>
    label.error{
        color: red;
    }

</style>
<div class="dash_right_section">
    <?php if ($this->session->flashdata('msg')) { ?>

        <div><div class="alert alert-success"><?php echo $this->session->flashdata('msg'); ?></div></div>
    <?php } ?>
    <?php
    $attributes = array('name' => 'upload_image', 'id' => 'upload_image');
    echo (!empty($pid)) ? form_open_multipart("patientmaster/save/?uid=$pid", $attributes) : form_open_multipart('patientmaster/save', $attributes);
    ?>
    <div class="row">
        <div class="col-md-8">
            <div class="dash_column">
                <div class="row">
                    <h3 class="sub-haeding pull-left col-md-8">Medical Assistance Request Form</h3>
                    <div class="form-group pull-right col-md-4">
                        <select id="registration_site" name="registration_site" class="form-control " aria-invalid="">
                            <option value="">Select site</option>
                            <option value="HM" <?php echo ($patient && "HM" == $patient['registration_site']) ? "selected" : "" ?>>Home Visit</option>
                            <option value="HV" <?php echo ($patient && "HV" == $patient['registration_site']) ? "selected" : "" ?>>Hospital Visit</option>
                            <option value="IO" <?php echo ($patient && "IO" == $patient['registration_site']) ? "selected" : "" ?>>In Office</option>
                        </select>
                    </div>
                </div>     
                <div class="form-group">
                    <label for="name">Patient Case Number</label>
                    <input type="hidden" id="patient_id" name="patient_id" value="<?php echo $patient_id ?>">
                    <input id="patient_case_show" disabled type="text" class="form-control" value="<?php echo ($patient && $patent_case) ? $patent_case : $case_id ?>">
                    <input id="patient_case" name="patient_case" type="hidden" class="form-control" value="<?php echo ($patient && $patent_case) ? $patent_case : $case_id ?>">
                </div>
                <div class="form-group">
                    <label for="name">Referred To KARO By</label>
                    <span class="mandate">*</span>
                    <select id="refered_by" name="refered_by"  class="form-control">
                        <option value=""> Select Refered By</option>
                        <?php foreach ($referd_array as $row){?>
                            <option value="<?php echo $row;?>" <?php echo $patient['refered_by'] == $row ?'selected':'';?>><?php echo $row;?></option>
                        <?php }?>
                        <!-- <option <?php echo in_array($patient['refered_by'],$referd_array)?'':'selected';?>>Others</option> -->
   
                        <!-- <?php foreach ($referedby as $refered) { ?>
                            <option value="<?php echo $refered['ReferedById']; ?>" title="<?php echo $refered['ContactNo']; ?>" <?php echo ($patient && $refered_by == $refered['ReferedById']) ? "selected" : "" ?> ><?php echo $refered['ReferedByName']; ?></option>
                        <?php } ?> -->
                    </select>
                    <!-- <input <?php echo in_array($patient['refered_by'],$referd_array)?'hidden':'';?> id="other_refered_by" type="text" name="other_refered_by" value='<?php echo $patient['refered_by'] ? $patient['refered_by']:''; ?>'/> -->
                </div>
                <div class="form-group">



                <label for="name">Contact Details of Referral <span class="mandate">*</span></label>
<input id="referral_details" name="referral_details"  type="text" class="form-control" placeholder="Contact Details of Referral" value="<?php echo ($patient && $patient['referral_details']) ? $patient['referral_details'] : "" ?>">
</div>
<div class="form-group">
<label for="name">Date</label>
 <span class="mandate">*</span>
<input id="registration_date" name="registration_date" readonly type="text" class="form-control " placeholder="Select Date" value='<?php echo ($patient && $patient['registration_date']) ? date('Y-m-d',strtotime($patient['registration_date'])) : date('Y-m-d') ?>'>
</div>


             

            </div>
        </div>
        <div class="col-md-4">
            <div class="dash_column">
                <div class="profile">
                    <div class="img_circle" id="preview">
                        <?php if ($patient && !empty($patient['patient_image'])) { ?>
                            <img src="<?php echo base_url() . $patient['patient_image'] ?>" /><input type="hidden" name="patient_image" value="<?php echo $patient['patient_image'] ?>">

                        <?php } else { ?>
                            <img src="<?php echo base_url('karoclient/images/user.jpg'); ?>">


                        <?php } ?>
                    </div>
                    <input type="file" id="image" name="image" class="edit-col">
                            <div id="top-msg" class="top-msg" hidden></div>  
                    
                    <?php if ($patient && !empty($patient['patient_image'])) { ?>
                        <p><?php echo "" . $patient['patient_name'] ?></p>
                        <p>Patient ID :  <span><?php echo $patient['patient_id'] ?></span></p>
                    <?php } else { ?>

                        <p class="support">Supported formats: jpg, jpeg, png, gif.</p>
                        <p class="support"> File size:2mb</p>
                    <?php } ?>
                    <input type="button" id="upload_img" name="upload_img" value="Upload Image" class="btn btn-primary">
                    <p id="status"></p>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="dash_column">
        <h3 class="sub-haeding">Patient's Personal Details</h3>
        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">Patient Name</label>
                <span class="mandate">*</span>
                <input id="patient_name" name="patient_name" value="<?php echo ($patient) ? $patient['patient_name'] : "" ?>" type="text" class="form-control" placeholder="Enter patient name" maxlength="50">
            </div>
            <div class="form-group col-md-6">
                <label for="name">Age(Years)</label>
                <span class="mandate">*</span>
                <input id="patient_age" name="patient_age" type="text" value="<?php echo ($patient) ? $patient['patient_age'] : "" ?>" class="form-control" placeholder="Enter patient age" maxlength="3">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">Gender</label>
                <span class="mandate">*</span>
                <div class="form-check-inline" style="margin-top:10px;">
                    <label class="customradio col-md-4"><span class="radiotextsty">Male</span>
                        <input type="radio" name="patient_gender" value="Male" <?php echo ($patient['patient_gender'] == 'Male') ? "checked" : ""; ?>>
                        <span class="checkmark"></span>
                    </label> 
                    <label class="customradio col-md-4"><span class="radiotextsty">Female</span>
                        <input type="radio" name="patient_gender" value="Female" <?php echo ($patient['patient_gender'] == 'Female') ? "checked" : ""; ?>>
                        <span class="checkmark"></span>
                    </label>
                    <br />
                    <label id="patient_gender-error" class="error" for="patient_gender" style="display: none;">This field is required.</label>
                </div> 
            </div>
            <div class="form-group col-md-6">
                <label for="name">Language </label>
                <span class="mandate">*</span>
                <div class="row" style="margin-top:10px;">
                    <div class="checkSec col-md-3">
                        <label>
                            <div class="checkbx">
                                Hindi 
                                <input type="checkbox" name="patient_language[]" value="Hindi"  <?php echo ($patient && strstr($patient['patient_language'], 'Hindi')) ? "checked" : "" ?>>
                                </label>
                                <span></span>
                            </div>			 
                    </div>
                    <div class="checkSec col-md-3">
                        <label>
                            <div class="checkbx">
                                English  
                                <input type="checkbox" id='patient_language' name="patient_language[]" value="English" <?php echo ($patient && strstr($patient['patient_language'], 'English')) ? "checked" : "" ?>>
                                </label>
                                <span></span>
                            </div>			 
                    </div>
                    <div class="checkSec col-md-3">
                        <label>
                            <div class="checkbx">
                                Marathi   
                                <input type="checkbox" name="patient_language[]" value="Marathi" <?php echo ($patient && strstr($patient['patient_language'], 'Marathi')) ? "checked" : "" ?>>
                                </label>
                                <span></span>
                            </div>			 
                    </div>
                    <div class="checkSec col-md-3">
                        <label>
                            <div class="checkbx">
                                Other   
                                <input type="checkbox" name="patient_language[]" value="Other" <?php echo ($patient && strstr($patient['patient_language'], 'Other')) ? "checked" : "" ?> onchange="this.checked == true ? document.getElementById('patient_language_other').style.display = '' : document.getElementById('patient_language_other').style.display = 'none'">
                                </label>
                                <span></span>
                            </div>			 
                    </div>
                </div>
                <label id="patient_language[]-error" class="error" for="patient_language[]" style="display: none;">This field is required.</label>
                <input id="patient_language_other" name="patient_language_other" value="<?php echo ($patient) ? $patient['patient_language_other'] : "" ?>" type="text" class="form-control" <?php echo ($patient && !strstr($patient['patient_language'], 'Other')) ? "style='display:none'" : (empty($patient)) ? "style='display:none'" : "style='display:block'" ?> <?php echo (empty($patient)) ? "style='display:none'" : "" ?> placeholder="Other Language">
            </div>
        </div>
        <hr/>
        <div class="row">
            <div class="col-md-6">
                <h3 class="sub-haeding">Temporary Address</h3>
                <div class="form-group">
                    <label for="name">Street Address</label>
                    <span class="mandate">*</span>
                    <input id="pt_address" name="pt_address" type="text" class="form-control" placeholder="address" value="<?php echo ($patient) ? $patient['pt_address'] : "" ?>" onchange="sameAddressLine();">
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="name">State</label>
                        <span class="mandate">*</span>
                        <select id="pt_state" name="pt_state"  class="form-control" onchange="getcities(this.value, 'pt_city');
                                sameaddress();">
                            <option value=""> Select State</option>
                            <?php foreach ($states as $state) { ?>
                                <option value="<?php echo $state['city_state']; ?>" <?php echo ($patient && $patient['pt_state'] == $state['city_state']) ? "selected" : "" ?>><?php echo $state['city_state']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="name">City</label>
                        <span class="mandate">*</span>
                        <select id="pt_city" name="pt_city"  class="form-control" onchange="samecity();">
                            <option value=""> Select City</option> 
                            <?php
                            if ($ptcities) {
                                foreach ($ptcities as $city) {
                                    ?>
                                    <option value="<?php echo $city['city_name']; ?>" <?php echo ($patient && $patient['pt_city'] == $city['city_name']) ? "selected" : "" ?> ><?php echo $city['city_name']; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="name">Pin Code</label>
                        <span class="mandate">*</span>
                        <input id="pt_zip" name="pt_zip" type="text" value="<?php echo ($patient) ? $patient['pt_zip'] : "" ?>" class="form-control" placeholder="Enter pin code" onchange="samezip();" maxlength="6">
                    </div>
                    <div class="form-group col-md-6">
                        <div style="margin-top:35px;">
                            <div class="checkSec">
                                <label>
                                    <div class="checkbx">
                                        Same as temporary address 
                                        <input type="checkbox"  id="same_address" name="check_add" onchange="this.checked ? sameaddress() : '';" <?php echo (($patient['check_add'] == "on") ? "checked" : ""); ?>>
                                        <span></span>
                                    </div>			 
                                </label></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <h3 class="sub-haeding">Permanent Address</h3>
                <div class="form-group">
                    <label for="name">Street Address</label>
                    <span class="mandate">*</span>
                    <input id="pp_address" name="pp_address" type="text" class="form-control" placeholder="address" value="<?php echo ($patient) ? $patient['pp_address'] : "" ?>">
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="name">State</label>
                        <span class="mandate">*</span>
                        <select id="pp_state" name="pp_state"  class="form-control" onchange="getcities(this.value, 'pp_city');">
                            <option value=""> Select State</option>
                            <?php foreach ($states as $state) { ?>
                                <option value="<?php echo $state['city_state']; ?>" <?php echo ($patient && $patient['pp_state'] == $state['city_state']) ? "selected" : "" ?> ><?php echo $state['city_state']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="name">City</label>
                        <span class="mandate">*</span>
                        <select id="pp_city" name="pp_city"  class="form-control" onchange="">
                            <option value=""> Select City</option>
                            <?php
                            if ($ppcities) {
                                foreach ($ppcities as $city) {
                                    ?>
                                    <option value="<?php echo $city['city_name']; ?>" <?php echo ($patient && $patient['pp_city'] == $city['city_name']) ? "selected" : "" ?> ><?php echo $city['city_name']; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="name">Pin Code</label>
                        <span class="mandate">*</span>
                        <input id="pp_zip" name="pp_zip" type="text" class="form-control" placeholder="Enter pin code" value="<?php echo ($patient) ? $patient['pp_zip'] : "" ?>" maxlength="6">
                    </div>
                </div>
            </div>
        </div>
        <hr/>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="name">Patient Mobile No.</label>
                    <span class="mandate">*</span>
                    <input id="patient_phone" name="patient_phone" type="text" value="<?php echo ($patient) ? $patient['patient_phone'] : "" ?>" class="form-control" placeholder="Enter contact no" maxlength="10">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="name">Caregiver Name</label>
                    <span class="mandate">*</span>
                    <input id="caregiver_name" name="caregiver_name" type="text" value="<?php echo ($patient) ? $patient['caregiver_name'] : "" ?>" class="form-control" placeholder="Enter caregiver name" maxlength="50">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="name">Caregiver Mobile No.</label>
                    <span class="mandate">*</span>
                    <input id="caregiver_phone" name="caregiver_phone" value="<?php echo ($patient) ? $patient['caregiver_phone'] : "" ?>" type="text" class="form-control" placeholder="Enter caregiver phone number" maxlength="10">
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="dash_column family">
        <h3 class="sub-haeding">Patient's Family Details</h3>
        <p>Total no. of people in close (immediate or extended) family</p>
        <p style="color:red;font-size: 12px;" id="fmessage"></p>
        <div class="tbl">
            <table id="patient_family" class="table table-striped table-bordered" width="100%">
                <thead>
                    <tr>
<!--                        <th><em style="color:red">*</em> Name</th>
                        <th><em style="color:red">*</em> Relation</th>
                        <th><em style="color:red">*</em> Age (Years)</th>-->
                        <th>Name</th>
                        <th>Relation</th>
                        <th>Age (Years)</th>
                        <th>Occupation</th>
                        <th>Salary/Fees</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody id="family_container">
                    <?php
                    if (!empty($pfamily_data)) {
                        foreach ($pfamily_data as $key => $family) {
                            ?>
                            <tr>
                                <td><input id="relative_name<?php echo $key ?>" name="relative_name[]" maxlength="50" type="text" class="form-control rname" value="<?php echo $family['relative_name']; ?>"></td>
                                <td><input id="relation<?php echo $key ?>" name="relation[]" type="text" maxlength="20" class="form-control relation" value="<?php echo $family['relation']; ?>"></td>
                                <td><input id="relative_age<?php echo $key ?>" name="relative_age[]" maxlength="3" type="text" class="form-control rage" value="<?php echo $family['relative_age']; ?>"></td>
                                <td><input id="occupation<?php echo $key ?>" name="occupation[]" type="text" maxlength="20" class="form-control roccupation" value="<?php echo $family['occupation']; ?>"></td>
                                <td><input type="hidden" id="family_id<?php echo $key ?>" name="family_id[]" value="<?php echo ($family) ? $family['id'] : "" ?>"><input id="salary<?php echo $key ?>" name="salary[]" type="text" maxlength="16" class="form-control rsalary" value="<?php echo $family['salary']; ?>"></td>
                                <td>
                                    <a class="btn btn-danger fa fa-trash-o space" href="javascript:void(0);" onclick="deleteRow($(this), '<?php echo $key ?>')"></a>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
    <!--                        <tr>
    <td><input id="relative_name0" name="relative_name[]" maxlength="50" type="text" class="form-control rname"></td>
    <td><input id="relation0" name="relation[]" type="text" maxlength="20" class="form-control relation"></td>
    <td><input id="relative_age0" name="relative_age[]" maxlength="3" type="text" class="form-control rage"></td>
    <td><input id="occupation0" name="occupation[]" maxlength="20" type="text" class="form-control roccupation" ></td>
    <td><input id="salary0" name="salary[]" maxlength="10" type="text" class="form-control rsalary"></td>
    <td><a class="btn btn-danger fa fa-trash-o space" href="javascript:void(0);" onclick="deleteRow($(this), 0)"></a></td>
    </tr>
    <tr>
    <td><input id="relative_name1" name="relative_name[]" maxlength="50" type="text" class="form-control rname"></td>
    <td><input id="relation1" name="relation[]" maxlength="20" type="text" class="form-control relation"></td>
    <td><input id="relative_age1" name="relative_age[]" maxlength="3" type="text" class="form-control rage"></td>
    <td><input id="occupation1" name="occupation[]" maxlength="20" type="text" class="form-control roccupation"></td>
    <td><input id="salary1" name="salary[]" maxlength="10" type="text" class="form-control rsalary"></td>
    <td><a class="btn btn-danger fa fa-trash-o space" href="javascript:void(0);" onclick="deleteRow($(this), 1)"></a></td>
    </tr>-->
                    <?php } ?>
                </tbody>
                <tr>
                    <td colspan="6"><input type="button" onclick="return addMore();" class="btn btn-primary add"  style="float:right" value="Add"></td>
                </tr>
            </table>
        </div>
        <div class="follow-btn">
            <input type="hidden" value="" id="frows" name="frows">
            &nbsp; <input type="submit" class="btn btn-danger add" value="submit">
        </div>
        <div class="clearfix"></div>
    </div>
</form>
</div>
<script>
    function inEdit() {
        var field = 'q';
        var url = window.location.href;
        if (url.indexOf('?' + field + '=') != -1)
            return true;
        else if (url.indexOf('&' + field + '=') != -1)
            return true;
        return false
    }

    if (!inEdit()) {
        //   var checkbox = document.getElementById('patient_language');
        // var radio = document.getElementsByName('patient_gender');
        //radio[0].checked = "checked";
        //   checkbox.checked = "checked";
    } else {

    }

    var cid = '<?php echo $this->input->get('cid') ?>';
    if (cid.length > 0) {
        window.setTimeout("redirect(" + cid + ")", 2000);
    }

    function redirect(cid) {
        window.location.href ="<?php echo  base_url() ?>index.php/patientcase/index/?cid=" + cid;
    }
</script>
