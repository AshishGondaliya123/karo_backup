<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="dash_right_section">
    <h2 class="main-heading pull-left">Patient Details</h2>

    <div class="clearfix"></div>

    <h5 class="main-heading pull-left"><?php echo $label; ?></h5>

    <div class="clearfix"></div>
    <div class="dash_column family">
        <div class="tbl">
            <table id="view_patient_tbl" class="table table-striped table-bordered" width="100%">
                <thead>
                    <tr>
                        <th>Patient Id</th>
                        <th>Referral Name</th>
                        <th>Name of Patient</th>
                        <th>Mobile No.</th>
                        <th>Caregiver Name</th>
                        <th>Caregiver Contact</th>
                        <th>Name of Hospital</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- commented to display hospital name -->
                    <?php
                    foreach ($patient as $p) {
                        ?>
                        <tr>
                            <td><?php echo $p['patient_id'] ?></td>
                            <td><?php echo $p['referral_name'] ?></td>
                            <td><?php echo $p['patient_name'] ?></td>
                            <td><?php echo!empty($p['patient_phone']) ? $p['patient_phone'] : '' ?></td>
                            <td><?php echo $p['caregiver_name'] ?></td>
                            <td><?php echo $p['caregiver_phone'] ?></td>
                            <td><?php echo $p['HospitalName'] ?></td>
                            <td width="300" >
                                <a class="btn btn-success btn-xs" href="<?php echo base_url() . 'index.php/patientmaster/index?uid=' . $p['id'] ?>" title="Edit Patient"><i class="fa fa-edit"></i></a>
                                <a class="btn btn-warning btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $p['id'] ?>" title="Case Detail"><i class="fa fa-info-circle"></i></a>
                                <a class="btn btn-primary btn-xs" href="<?php echo base_url() . 'index.php/patientcase/exportptdata?patient_id=' . $p['patient_id'] ?>" title="Patient Pdf" ><i class="fa fa-file-pdf-o"></i></a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <div class="clearfix"></div>
    </div>
</div>