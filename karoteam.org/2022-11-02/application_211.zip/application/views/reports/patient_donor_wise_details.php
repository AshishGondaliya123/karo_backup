
<style type="text/css">
   #patient_Donor_wise_finacial_details .error{
            color:red;
          }
          .tx h3 {
font-size: 15px;
color: #337ab7;
text-transform: uppercase;
margin: 0 0 10px;
font-weight: 500;
}   
.tx p{ margin:0;}

third_heading {
color: #585858;
text-transform: uppercase;
font-size: 16px;
margin: 15px 0;
}
.third_heading span {
color: #337ab7;
}      
</style>

<div class="dash_right_section">
<h2 class="main-heading">Donor Wise Financial Details</h2>
<div class="dash_column">

<?php if($this->session->flashdata('message'))echo $this->session->flashdata('message');?>
         <?php
            $attributes = array('class' => 'patient_Donor_wise_finacial_details', 'id' => 'patient_Donor_wise_finacial_details');
            echo form_open('Reports/getPatientsDonorWiseFinacialReports', $attributes);
            ?>
    
        
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">From Date <span class="mandate"></span></label>
                <input id="from_date" name="from_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $from_date ? $from_date:'';?>">
                <!-- <input type="date" name="donation date" class="form-control form_date" placeholder="Enter secondary contact" id="example-datetime-local-input" > -->
            </div>
            <div class="form-group col-md-4">
                <label for="name">To Date <span class="mandate"></span></label>
                <input id="to_date" name="to_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $to_date ? $to_date:'';?>">
            </div>
            
             
        
             <div class="form-group col-md-4">
               <label for="name">Donor <span class="mandate">*</span> </label>
                <select class="form-control" name="donor" id="donor">
                    <option value="">Select donor</option>
                    <?php
                        if($active_donor){
                            foreach ($active_donor as $k => $v) {
                                ?>
                            <option value="<?php echo $v->DonerId;?>" <?php echo $v->DonerId == $selected_donor?'selected' :'';?>><?php echo $v->firstName.' '.$v->middleName.' '.$v->lastName;?></option>
                                <?php
                            }
                        }
                    ?>
                </select>
             </div>
            
        </div>
		
		<div class="row">
           <div class="form-group col-md-4">
                  <label for="name">Patient Name <span class="mandate"></span> </label>
                  <input id="patient_name" name="patient_name"  type="text" class="form-control" placeholder="Enter patient name" value="<?php echo $patient_name ? $patient_name:'';?>">
                  <label class="error patienterror" style="display: none">Please enter patient name.</label>
           </div>

            <div class="form-group col-md-4">
                <label for="name"> Patient KARO Case Number /  CASE NO / Patient ID<span class="mandate"></span></label>
                <input id="karo_no" name="karo_no"  type="text" class="form-control" placeholder="Enter KARO no" value="<?php echo $karo ? $karo:'';?>">
                <label class="error karoerror" style="display: none">Please enter KARO no.</label>
            </div>

             <div class="form-group col-md-4">
             <label for="name">Registration Date <span class="mandate"></span></label>
             <input id="reg_date" name="reg_date" readonly=""  type="date" class="form-control" placeholder="Select Date" value="<?php echo $reg_date ? $reg_date:'';?>">
             <label class="error regerror" style="display: none">Please enter registration date.</label>
           </div>
        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="department">Department</label>
                <select class="form-control" name="department" id="department">
                    <option value="">Select Department</option>
                    <?php
                    if($active_department){
                        foreach ($active_department as $key => $value) { ?>
                            <option value="<?php echo $value['DeptId'];?>" <?=(!empty($_POST['department']) && $_POST['department']==$value['DeptId']?"selected":"")?>> <?php echo $value['DeptName'];?></option>
                    <?php }
                    }?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="hospital">Hospital</label>
                <select class="form-control" name="hospital" id="hospital">
                    <option value="">Select Hospital</option>
                    <?php
                        if($active_hospital)
                        {
                            foreach ($active_hospital as $key => $value) { ?>
                            <option value="<?php echo $value['HospitalId'];?>" <?=(!empty($_POST['hospital']) && $_POST['hospital']==$value['HospitalId']?"selected":"")?>> <?php echo $value['HospitalName'];?></option>
                            <?php }}?>
                </select>
            </div> 
        </div>
        <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="add" class="btn btn-primary save">Submit</button>
            </div>
        </div>
    </div>  
<?php if($from_date && $to_date && $donor){?>
    <h4 class="third_heading">Showing Patient Financial Details <span>From (<?php echo date('d/m/Y',strtotime($from_date));?>) To (<?php echo date('d/m/Y',strtotime($to_date));?>)</span><br>
Of Donor <span><?php echo $donor;?></span></h4>
    <?php }?>  

    <div class="row">
<div class="col-md-4">
<div class="dash_column">
<div class="tx">
<h3>Total Donate Amount</h3>
<p><span><?php echo $total_donation_amount[0]['Total_DonateAmount']? numberformat($total_donation_amount[0]['Total_DonateAmount']):'0.00';?></span></p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="dash_column">
<div class="tx">
<h3>Total Sanction Amount</h3>
<p><span><?php echo $total_approved_amount[0]['donor_approved_amount']? numberformat($total_approved_amount[0]['donor_approved_amount']): '0.00';?></span></p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="dash_column">
<div class="tx">
<h3>Total Disbursed Amount</h3>
<p><span><?php echo $total_disbursed_amount[0]['Total_DisbursedAmt']?numberformat($total_disbursed_amount[0]['Total_DisbursedAmt']):'0.00';?></span></p>
</div>
</div>
</div>
</div> 
            
<div class="dash_column">
    <div class="tbl">
        <table class="table  table-bordered" id="patientwise_donor_details_tbl">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Case NO.</th>
                    <th hidden>Case Status</th>
                    <th>Payment Mode</th>
                    <th>Sanctioned Amount</th>
                    <th>Sanction Date</th>
                    <th>Disbursed Amount</th>
                    <th>Disbursed Date</th>

                </tr>
            </thead>
            <tbody>
            <?php
                if($result){
                    foreach ($result as $dk => $dv) {
						?>
                    <tr>
                    <td><?php echo $dv['Patient'];?></td>
                    <td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $dv['CaseId'] ?>" title="Case Detail" target="_blank"><?php echo $dv['CASE_NO'];?></a></td>
                    <td hidden><?php echo $dv['CASEStatus'];?></td>
                    <td><?php echo $dv['PaymentMode'];?></td>
                    <td><?php echo numberformat($dv['SanctionedAmount']);?></td>
                    <td><?php echo $dv['SanctionDate'];?></td>
                    <td><?php echo numberformat($dv['Disbursed_Amt']);?></td>
                    <td><?php echo $dv['Disbursed_Date'];?></td>

                        
                    </tr>
                        
                   <?php }} ?>
                
                </tbody></table>
    </div>

</div> 

</div>
