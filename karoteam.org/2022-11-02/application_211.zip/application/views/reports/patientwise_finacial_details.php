
<style type="text/css">
   #patientwise_finacial_details .error{
            color:red;
          }
  </style>

<div class="dash_right_section">
<h2 class="main-heading">Patient Wise Finacial Details</h2>
<div class="dash_column">

<?php if($this->session->flashdata('message'))echo $this->session->flashdata('message');?>
         <?php
            $attributes = array('class' => 'patientwise_finacial_details', 'id' => 'patientwise_finacial_details');
            echo form_open('Reports/getPatientsWiseFinacialReports', $attributes);
            ?>
    
        
        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">From Date</label>
                <input id="from_date" name="from_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $from_date ? $from_date:'';?>">
                <!-- <input type="date" name="donation date" class="form-control form_date" placeholder="Enter secondary contact" id="example-datetime-local-input" > -->
            </div>
            <div class="form-group col-md-6">
                <label for="name">To Date </label>
                <input id="to_date" name="to_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $to_date ? $to_date:'';?>">
            </div>
        </div>
        <div class="row">
           <div class="form-group col-md-6">
                <label for="name">Patient Name <span class="mandate"></span> </label>
                <input id="patient_name" name="patient_name"  type="text" class="form-control" placeholder="Enter patient name" value="<?php echo $patient_name ? $patient_name:'';?>">
                <label class="error patienterror" style="display: none">Please enter patient name.</label>
           </div>

            <div class="form-group col-md-6">
                <label for="name"> Patient KARO Case Number /  CASE NO / Patient ID<span class="mandate"></span></label>
                <input id="karo_no" name="karo_no"  type="text" class="form-control" placeholder="Enter KARO no" value="<?php echo $karo ? $karo:'';?>">
                <label class="error karoerror" style="display: none">Please enter KARO no.</label>
            </div>
        </div>

        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">Registration Date <span class="mandate"></span></label>
                <input id="reg_date" name="reg_date" readonly="" type="date" class="form-control" placeholder="Select Date" value="<?php echo $reg_date ? $reg_date:'';?>">
                <label class="error regerror" style="display: none">Please enter registration date.</label>
            </div>
            <div class="form-group col-md-6">
                <label for="department">Department</label>
                <select class="form-control" name="department" id="department">
                    <option value="">Select Department</option>
                    <?php
                    if($active_department){
                        foreach ($active_department as $key => $value) { ?>
                            <option value="<?php echo $value['DeptId'];?>" <?=(!empty($_POST['department']) && $_POST['department']==$value['DeptId']?"selected":"")?>> <?php echo $value['DeptName'];?></option>
                    <?php }
                    }?>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">Donor <span class="mandate"></span> </label>
                <select class="form-control" name="donor" id="donor">
                    <option value="">Select donor</option>
                    <?php
                    if (count($active_donor) > 0) {
                        foreach ($active_donor as $k => $v) {
                            ?>
                            <option value="<?php echo $v->DonerId; ?>" <?php echo $v->DonerId == $selected_donor ? 'selected' : ''; ?>>
                                <?php echo $v->firstName . ' ' . $v->middleName . ' ' . $v->lastName; ?>
                            </option>
                            <?php
                        }
                    }
                    ?>
                </select>
                <label class="error donorerror" style="display: none">Please select donor.</label>
            </div>
            <div class="form-group col-md-6">
                <label for="hospital">Hospital</label>
                <select class="form-control" name="hospital" id="hospital">
                    <option value="">Select Hospital</option>
                    <?php
                        if($active_hospital)
                        {
                            foreach ($active_hospital as $key => $value) { ?>
                            <option value="<?php echo $value['HospitalId'];?>" <?=(!empty($_POST['hospital']) && $_POST['hospital']==$value['HospitalId']?"selected":"")?>> <?php echo $value['HospitalName'];?></option>
                            <?php }}?>
                </select>
            </div>  
        </div>
        <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="add" class="btn btn-primary save">Submit</button>
            </div>
        </div>
    </div> 
<?php if($from_date && $to_date){?>
    <h4 class="third_heading">Showing Patient Wise Financial Details <span> From (<?php echo date('d/m/Y',strtotime($from_date));?>) To (<?php echo date('d/m/Y',strtotime($to_date));?>)</span></h4>
    <?php }?>               
<div class="dash_column">
    <div class="tbl">
        <table class="table  table-bordered" id="patientwise_finacial_details_tbl">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Case NO.</th>
                    <th hidden>Case Status</th>
                    <th>Payment Mode</th>
                    <th>Sanctioned Amount</th>
                    <th>Sanction Date</th>
                    <th>Disbursed Amount</th>
                    <th>Disbursed Date</th>

                </tr>
            </thead>
            <tbody>
            <?php
                if($result){
                    foreach ($result as $dk => $dv) {
					?>
                    <tr>
                    <td><?php echo $dv['Patient'];?></td>
                   <td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $dv['CaseId'] ?>" title="Case Detail" target="_blank"><?php echo $dv['CASE_NO'];?></a></td>
                    <td hidden><?php echo $dv['CASEStatus'];?></td>
                    <td><?php echo $dv['PaymentMode'];?></td>
                    <td><?php echo numberformat($dv['SanctionedAmount']);?></td>
                    <td><?php echo $dv['SanctionDate'];?></td>
                    <td><?php echo numberformat($dv['Disbursed_Amt']);?></td>
                    <td><?php echo $dv['Disbursed_Date'];?></td>

                        
                    </tr>
                        
                   <?php }} ?>
                
                </tbody></table>
    </div>
</div>            
</div>

