<style type="text/css">
    #patient_Donor_wise_finacial_details .error{
        color:red;
    }
    .tx h3 {
        font-size: 15px;
        color: #337ab7;
        text-transform: uppercase;
        margin: 0 0 10px;
        font-weight: 500;
    }   
    .tx p{ margin:0;}

    third_heading {
        color: #585858;
        text-transform: uppercase;
        font-size: 16px;
        margin: 15px 0;
    }
    .third_heading span {
        color: #337ab7;
    }      
</style>

<div class="dash_right_section">
    <h2 class="main-heading">Patient Details</h2>
    <h2 class="main-heading">Donor Name:<?php echo $label; ?></h2>

    <div class="row">
        <div class="col-md-3">
            <div class="dash_column">
                <div class="tx">
                    <h3>Total Donate Amount</h3>
                    <p><span><?php echo $total_disbursed_amount[0]['Total_DonateAmount'] ? numberformat($total_disbursed_amount[0]['Total_DonateAmount']) : '0.00'; ?></span></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="dash_column">
                <div class="tx">
                    <h3>Total Sanction Amount</h3>
                    <p><span><?php echo $total_disbursed_amount[0]['approved_amount'] ? numberformat($total_disbursed_amount[0]['approved_amount']) : '0.00'; ?></span></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="dash_column">
                <div class="tx">
                    <h3>Total Disbursed Amount</h3>
                    <p><span><?php echo $total_disbursed_amount[0]['disbursed_amount'] ? numberformat($total_disbursed_amount[0]['disbursed_amount']) : '0.00'; ?></span></p>
                </div>
            </div>
        </div>
		<div class="col-md-3">
            <div class="dash_column">
                <div class="tx">
                    <h3>Balance Amount</h3>
                    <p><span><?php echo $total_disbursed_amount[0]['BalanceAmount'] ? numberformat($total_disbursed_amount[0]['BalanceAmount']) : '0.00'; ?></span></p>
                </div>
            </div>
        </div>
    </div> 

    <div class="dash_column">
        <div class="tbl">
            <table class="table  table-bordered" id="patientwise_donor_details_tbl">
                <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>Patient Name</th>
                        <th>Hospital Name</th>
                        <th>Treatment</th>
                        <th hidden>Case Status</th>
                        <th>Payment Mode</th>
                        <th>Sanctioned Amount</th>
                        <th>Sanction Date</th>
                        <th>Disbursed Amount</th>
                        <th>Disbursed Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result) {
                        foreach ($result as $dk => $dv) {
							  $ci = & get_instance();
                                    $ci->load->model("report_model", "rm");
                                    $data = $ci->rm->getCaseDetailsById($dv['CASE_NO']);
                            ?>
                            <tr>
                                <td><a  href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $data[0]->id ?>" title="Case Detail" target="_blank"><?php echo $dv['CASE_NO']; ?></a></td>
                                <td><?php echo $dv['Patient']; ?></td>
                                <td><?php echo $dv['HospitalName']; ?></td>
                                <td><?php echo $dv['TreatmentCompleted']; ?></td>
                                <td hidden><?php echo $dv['CASEStatus']; ?></td>
                                <td><?php echo $dv['PaymentMode']; ?></td>
                                <td><?php echo numberformat($dv['SanctionedAmount']); ?></td>
                                <td><?php echo $dv['SanctionDate']; ?></td>
                                <td><?php echo numberformat($dv['Disbursed_Amt']); ?></td>
                                <td><?php echo $dv['Disbursed_Date']; ?></td>
                                <td>
                                    <?php
                                  
                                    ?>
                                    <a class="btn btn-success btn-xs" href="<?php echo base_url() . 'index.php/patientmaster/index?uid=' . $data[0]->id; ?>" title="Edit Patient"><i class="fa fa-edit"></i></a>
                                    <a class="btn btn-warning btn-xs" href="<?php echo base_url() . 'index.php/patientcase/index?cid=' . $data[0]->id; ?>" title="Case Detail"><i class="fa fa-info-circle"></i></a>
                                    <a class="btn btn-primary btn-xs" href="<?php echo base_url() . 'index.php/patientcase/exportptdata?patient_id=' . $data[0]->patient_id; ?>" title="Patient Pdf" ><i class="fa fa-file-pdf-o"></i></a>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div> 
</div>
