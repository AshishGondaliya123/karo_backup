<style type="text/css">
    #patient_details_report .error{color:red}
    .tbl .table td:last-child, .tbl .table th:last-child {width: auto !important;text-align: left !important}
    .table.table-bordered.report td:last-child {word-break: break-all}
    .pd-table td{width:400px}
    .dt-button{position: relative;top: 45px;z-index: 9;background: #f0643b !important;color: #fff !important;border: none !important;padding: 10px 30px !important;font-size: 15px !important;margin: 0 !important;border-radius:2px}
</style>

<div class="dash_right_section">
    <h2 class="main-heading">Patient Details</h2>
    <div class="dash_column">
        <?php if ($this->session->flashdata('msg')) echo $this->session->flashdata('msg'); ?>
        <div id="top_pt_msg" hidden></div>
        <?php //$attributes = array('class' => 'patient_details_report', 'id' => 'patient_details_report'); ?>
        <?php //echo form_open('Reports/getPatientsReports', $attributes); ?>

        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">From Date <span class="mandate"></span></label>
                <input id="from_date" name="from_date" readonly="" type="date" class="form-control" placeholder="Select Date" value="">
            </div>
            <div class="form-group col-md-6">
                <label for="name">To Date <span class="mandate"></span></label>
                <input id="to_date" name="to_date" readonly="" type="date" class="form-control" placeholder="Select Date" value="">
            </div>
        </div>

        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">Patient Cases</label>
                <span class="mandate"></span>
                <div class="row" style="margin-top:10px;">
                    <div class="checkSec col-md-2">
                        <label>
                            <div class="checkbx">New<input type="checkbox" id="new" name="patient_cases[]" value="New"/><span></span></div>
                        </label></div>
                    <div class="checkSec col-md-2">
                        <label>
                            <div class="checkbx">Open<input type="checkbox" id="open" name="patient_cases[]" value="open"/><span></span>
                            </div>
                        </label>
                    </div>
                    <div class="checkSec col-md-2">
                        <label>
                            <div class="checkbx">Hold<input type="checkbox" id="hold" name="patient_cases[]" value="hold"/><span></span></div>
                        </label>
                    </div>
                    <div class="checkSec col-md-2">
                        <label>
                            <div class="checkbx">Closed<input type="checkbox" id="close" name="patient_cases[]" value="closed"/><span></span></div>
                        </label>
                    </div>
                    <div class="checkSec col-md-2">
                        <label>
                            <div class="checkbx">Rejected<input type="checkbox" id="reject" name="patient_cases[]" value="reject"/><span></span></div>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <button type="button" name="save" id ="submitdate"value="add" class="btn btn-primary save">Submit</button>
            </div>
        </div>
    </div>
    <div id="date_info"></div>
    <div class="dash_column">
        <div id="excel_report_pt" hidden> </div>
        <div class="tbl">
            <table id="patient_details_tbl" class="floated--table table-striped pd-table" width="100%"></table>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
    $("#submitdate").click(function () {
        var to_date = $('#to_date').val();
        var from_date = $('#from_date').val();

        if (to_date == '') {
            to_date = '<?php echo date('Y-m-d'); ?>';
        }

        if (to_date < from_date) {
            $('#top_pt_msg').addClass('alert alert-danger').text('To Date should be greater than or equal to From Date');
            $('#top_pt_msg').show();
            setTimeout(function () {
                $('.alert-danger').hide();
            }, 2000);
            return false;
        }

        var patientCases = [];
        $.each($("input[name='patient_cases[]']:checked"), function () {
            patientCases.push($(this).val());
        });
        $('#top_pt_msg').hide();


        $.ajax({
            url: baseurl + 'index.php/Reports/ajaxPatientDetails/',
            type: "post",
            data: {from_date: from_date, to_date: to_date, patient_cases: patientCases},
            success: function (response) {
                var result = JSON.parse(response);
                var dataSet = result.data;

                $('#patient_details_tbl').DataTable({
                    // dom: 'lBfrtip',
                    data: dataSet,
                    // "bDestroy": true,
                    "paging": true,
                    "lengthChange": false,
                    "pageLength": 3,
                    // "scrollY": 500,
                    // "scrollX": 500,
                    // scrollX: "100%"
                    colReorder: true,
                    columnDefs: [{type: 'formatted-num', targets: 0}],
                    'pagingType': 'full_numbers',
                    /*
                     buttons: [
                     {
                     extend: 'csvHtml5',
                     title : "case_name",
                     },
                     {
                     extend: 'excelHtml5',
                     title : "case_name",
                     },
                     {
                     extend: 'pdfHtml5',
                     title : "case_name",
                     orientation: 'landscape', pageSize: 'A4',
                     },
                     ],*/
                    columns: [
                        {title: "CaseNo"},
                        {title: "Registration Date"},
                        {title: "Patient Name"},
                        {title: "Address", className: "ptAddressclass"},
                        {title: "Location"},
                        {title: "DOB"},
                        {title: "Gender"},
                        {title: "Contact No"},
                        {title: "Referred To"},
                        {title: "Referred By"},
                        {title: "Name Of Treating Doctor"},
                        {title: "Responsible Karo Representative"},
                        {title: "Case Receive Date"},
                        {title: "Disease Name"},
                        {title: "Depatment Of The Hospital"},
                        {title: "Required Fund"},
                        {title: "Initial Team Evaluation"},
                        {title: "Disbursed Amount"},
                        {title: "Approved Amount"},
                        {title: "Case Status"},
                        {title: "Additional Comment", className: "ptadditionclass"},
                    ],
                    destroy: true,
                });


                $('#excel_report_pt').html('<a class="dt-button" href="' + baseurl + 'index.php/Reports/generatePatientExcelReport?report_type=patient&from_date=' + from_date + '&to_date=' + to_date + '&patient_cases=' + patientCases + '">Export to Excel</a>')
                // $('#excel_report_pt').show();
                var fmdate = from_date.split('-');
                var todate = to_date.split('-');
                var sptodate = todate[2] + '/' + todate[1] + '/' + todate[0];

                if (from_date != '') {
                    var msg = '<h4 class="third_heading">Showing Patient Details <span>From (' + fmdate[2] + '/' + fmdate[1] + '/' + fmdate[0] + ') To (' + sptodate + ')</span></h4>';
                } else {
                    var msg = '<h4 class="third_heading">Showing Patient Details <span>Till: ' + sptodate + ' (Today)</span></h4>';
                }
                $('#date_info').html(msg);
                $('#date_info').show();
                if (result.status == 'failure') {
                    $('#top_pt_msg').removeClass().addClass('alert alert-danger').text('Record not found.')
                    $('#excel_report_pt').hide();
                } else {
                    $('#top_pt_msg').removeClass().addClass('alert alert-success').text('Patient Details fetch Successfully.')
                    $('#excel_report_pt').show();
                }
                $('#top_pt_msg').show();
                setTimeout(function () {
                    $('.alert-success').hide();
                }, 2000);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {}
        });
    });
</script>
