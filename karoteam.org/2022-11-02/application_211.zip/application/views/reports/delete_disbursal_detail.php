
<style type="text/css">
   #delete_disbursed_details .error{
            color:red;
          }
  </style>

<div class="dash_right_section">
<h2 class="main-heading">Delete Disbursed Details</h2>
<div class="dash_column">

<?php if($this->session->flashdata('message'))echo $this->session->flashdata('message');?>
 <div id="top_pt_msg" hidden></div>
         <?php
            $attributes = array('class' => 'delete_disbursed_details', 'id' => 'delete_disbursed_details');
            echo form_open('Reports/getDeleteDisbursedReports', $attributes);
            ?>


        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">From Date</label>
                <input id="from_date" name="from_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $from_date ? $from_date:'';?>">
                <!-- <input type="date" name="donation date" class="form-control form_date" placeholder="Enter secondary contact" id="example-datetime-local-input" > -->
            </div>
            <div class="form-group col-md-4">
                <label for="name">To Date </label>
                <input id="to_date" name="to_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $to_date ? $to_date:'';?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">Donor <span class="mandate"></span> </label>
                <select class="form-control" name="donor" id="donor">
                    <option value="">Select donor</option>
                    <?php
                    if (count($active_donor) > 0) {
                        foreach ($active_donor as $k => $v) {
                            ?>
                            <option value="<?php echo $v->DonerId; ?>" <?php echo $v->DonerId == $selected_donor ? 'selected' : ''; ?>>
                                <?php echo $v->firstName . ' ' . $v->middleName . ' ' . $v->lastName; ?>
                            </option>
                            <?php
                        }
                    }
                    ?>
                </select>
                <label class="error donorerror" style="display: none">Please select donor.</label>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="department">Department</label>
                <select class="form-control" name="department" id="department">
                    <option value="">Select Department</option>
                    <?php
                    if($active_department){
                        foreach ($active_department as $key => $value) { ?>
                            <option value="<?php echo $value['DeptId'];?>" <?=(!empty($_POST['department']) && $_POST['department']==$value['DeptId']?"selected":"")?>> <?php echo $value['DeptName'];?></option>
                    <?php }
                    }?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="hospital">Hospital</label>
                <select class="form-control" name="hospital" id="hospital">
                    <option value="">Select Hospital</option>
                    <?php
                        if($active_hospital)
                        {
                            foreach ($active_hospital as $key => $value) { ?>
                            <option value="<?php echo $value['HospitalId'];?>" <?=(!empty($_POST['hospital']) && $_POST['hospital']==$value['HospitalId']?"selected":"")?>> <?php echo $value['HospitalName'];?></option>
                            <?php }}?>
                </select>
            </div> 
        </div>
        <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="add" id="submitdate" class="btn btn-primary save">Submit</button>
            </div>
        </div>
    </div>
<?php if($from_date && $to_date){?>
    <h4 class="third_heading">Showing Delete Disbursed Details <span> From (<?php echo date('d/m/Y',strtotime($from_date));?>) To (<?php echo date('d/m/Y',strtotime($to_date));?>)</span></h4>
    <?php }?>
<div class="dash_column">
    <div class="tbl">
        <table class="table  table-bordered" id="delete_disbursed_details_tbl">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Donor Name</th>
                    <th>Disbursed Amount</th>
                    <th>Disbursed Date</th>
                    <th>Payment Mode</th>
                    <th>Bank Name</th>
                    <th>Reference No.</th>
                    <th>Receipt No.</th>
                    <th>Download Receipt</th>

                </tr>
            </thead>
            <tbody>
            <?php
                if($result){
                    foreach ($result as $dk => $dv) {?>
                    <tr>
                    <td><?php echo $dv['patient_name'];?></td>
                    <td><?php echo $dv['Doner'];?></td>
                    <td><?php echo numberformat($dv['DisbursedAmt']);?></td>
                    <td><?php echo date('d/m/y',strtotime($dv['DisburesedDate']));?></td>
                    <td><?php echo $dv['PaymentMode'];?></td>
                    <td><?php echo $dv['DisbursedBank'];?></td>
                    <td><?php echo $dv['DisbursedRefNo'];?></td>
                    <td><?php echo $dv['receipt_no'];?></td>
                    <td><?php if ($dv['receipt_file']) { ?><a  href="<?php echo $dv['receipt_file']; ?>" download><i class="fa fa-download"></i></a> <?php } ?></td>

                    </tr>

                   <?php }} ?>

                </tbody></table>
    </div>
</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
    $("#submitdate").click(function () {
        var to_date = $('#to_date').val();
        var from_date = $('#from_date').val();

        if (to_date < from_date) {
            $('#top_pt_msg').addClass('alert alert-danger').text('To Date should be greater than or equal to From Date');
            $('#top_pt_msg').show();
            setTimeout(function () {
                $('.alert-danger').hide();
            }, 2000);
            return false;
        }
	});
		</script>
