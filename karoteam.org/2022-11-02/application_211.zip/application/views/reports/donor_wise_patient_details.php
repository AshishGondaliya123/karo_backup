<style type="text/css">
    #donor_wise_patient_details .error{color:red}
    .tx h3 {font-size: 15px;color: #337ab7;text-transform: uppercase;margin: 0 0 10px;font-weight: 500}
    .tx p{ margin:0;}
    third_heading {color: #585858;text-transform: uppercase;font-size: 16px;margin: 15px 0}
    .third_heading span {color: #337ab7}
    .error{color: red !important}
    .dt-button{position: relative;top: 45px;z-index: 9;background: #f0643b !important;color: #fff !important;border: none !important;padding: 10px 30px !important;font-size: 15px !important;margin: 0 !important;border-radius:2px}
</style>

<div class="dash_right_section">
    <h2 class="main-heading">Donor Wise Patient Details</h2>
    <div class="dash_column">
        <?php if ($this->session->flashdata('message')) echo $this->session->flashdata('message'); ?>
        <?php //$attributes = array('class' => 'donor_wise_patient_details', 'id' => 'donor_wise_patient_details'); ?>
        <?php //echo form_open('Reports/getDonorWisePatientDetails', $attributes); ?>
        <div id="top_pt_msg" hidden></div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="name">From Date <span class="mandate"></span></label>
                <input id="from_date" name="from_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $from_date ? $from_date : ''; ?>">
            </div>
            <div class="form-group col-md-4">
                <label for="name">To Date <span class="mandate"></span></label>
                <input id="to_date" name="to_date" readonly="" type="date" class="form-control " placeholder="Select Date" value="<?php echo $to_date ? $to_date : ''; ?>">
            </div>

            <div class="form-group col-md-4">
                <label for="name">Donor <span class="mandate"></span> </label>
                <select class="form-control" name="donor" id="donor">
                    <option value="">Select donor</option>
                    <?php
                    if (count($active_donor) > 0) {
                        foreach ($active_donor as $k => $v) {
                            ?>
                            <option value="<?php echo $v->DonerId; ?>" <?php echo $v->DonerId == $selected_donor ? 'selected' : ''; ?>>
                                <?php echo $v->firstName . ' ' . $v->middleName . ' ' . $v->lastName; ?>
                            </option>
                            <?php
                        }
                    }
                    ?>
                </select>
                <label class="error donorerror" style="display: none">Please select donor.</label>
            </div>
        </div>
		
		<div class="row">
           <div class="form-group col-md-4">
           <label for="name">Patient Name <span class="mandate"></span> </label>
           <input id="patient_name" name="patient_name"  type="text" class="form-control" placeholder="Enter patient name" value="">
           <label class="error patienterror" style="display: none">Please enter patient name.</label>
           </div>

            <div class="form-group col-md-4">
                <label for="name"> Patient KARO Case Number /  CASE NO / Patient ID<span class="mandate"></span></label>
                <input id="karo_no" name="karo_no"  type="text" class="form-control" placeholder="Enter KARO no" value="">
                <label class="error karoerror" style="display: none">Please enter KARO no.</label>
            </div>


           <div class="form-group col-md-4">
             <label for="name">Registration Date <span class="mandate"></span></label>
             <input id="reg_date" name="reg_date" readonly=""  type="date" class="form-control" placeholder="Select Date" value="">
             <label class="error regerror" style="display: none">Please enter registration date.</label>
           </div>
       
        </div>
        <div class="row">
            <div class="form-group col-md-4">
                <label for="department">Department</label>
                <select class="form-control" name="department" id="department">
                    <option value="">Select Department</option>
                    <?php
                    if($active_department){
                        foreach ($active_department as $key => $value) { ?>
                            <option value="<?php echo $value['DeptId'];?>" <?=(!empty($_POST['department']) && $_POST['department']==$value['DeptId']?"selected":"")?>> <?php echo $value['DeptName'];?></option>
                    <?php }
                    }?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="hospital">Hospital</label>
                <select class="form-control" name="hospital" id="hospital">
                    <option value="">Select Hospital</option>
                    <?php
                        if($active_hospital)
                        {
                            foreach ($active_hospital as $key => $value) { ?>
                            <option value="<?php echo $value['HospitalId'];?>" <?=(!empty($_POST['hospital']) && $_POST['hospital']==$value['HospitalId']?"selected":"")?>> <?php echo $value['HospitalName'];?></option>
                            <?php }}?>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <button type="submit" id="submitdate" name="save" value="add" class="btn btn-primary save">Submit</button>
            </div>
        </div>
    </div>
    <div id="date_info"></div>
    <div class="dash_column">
        <div id="excel_report_pt" hidden> </div>
        <div class="tbl">
            <table id="donor_wise_patient_details_tbl" class="floated--table table-striped pd-table" width="100%"></table>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
    $("#submitdate").click(function (e) {
        var donorId = $('#donor').val();
        var to_date = $('#to_date').val();
        var from_date = $('#from_date').val();

        if (donorId == '') {
            $('.donorerror').show();
            return false;
        } else {
            $('.donorerror').hide();
        }

        if (to_date == '') {
            to_date = '<?php echo date('Y-m-d'); ?>';
        }

        if (to_date < from_date) {
            $('#top_pt_msg').addClass('alert alert-danger').text('To Date should be greater than or equal to From Date');
            $('#top_pt_msg').show();
            setTimeout(function () {
                $('.alert-danger').hide();
            }, 2000);
            return false;
        }

        $('#top_pt_msg').hide();
		
		var patientId = $('#patient_name').val();
        // alert(patientId);
        var department = $('#department').val();
        var hospital = $('#hospital').val();
        var karoNo = $('#karo_no').val();
        var regDate =$('#reg_date').val();
       
        $.ajax({
            url: baseurl + 'index.php/Reports/getAjaxDonorWisePatientDetails/',
            type: "post",
            data: {from_date: from_date, to_date: to_date, donor_id: donorId, patient_name: patientId,karo_no: karoNo,reg_date:regDate,department:department,hospital:hospital},
            success: function (response) {
                var result = JSON.parse(response);
                var dataSet = result.data;

                $('#donor_wise_patient_details_tbl').DataTable({
                    // dom: 'lBfrtip',
                    data: dataSet,
                    // "bDestroy": true,
                    "paging": true,
                    "lengthChange": false,
                    "pageLength": 3,
                    // "scrollY": 500,
                    // "scrollX": 500,
                    // scrollX: "100%"
                    colReorder: true,
                    columnDefs: [{type: 'formatted-num', targets: 0}],
                    'pagingType': 'full_numbers',
                    /*
                     buttons: [
                     {
                     extend: 'csvHtml5',
                     title : "case_name",
                     },
                     {
                     extend: 'excelHtml5',
                     title : "case_name",
                     },
                     {
                     extend: 'pdfHtml5',
                     title : "case_name",
                     orientation: 'landscape', pageSize: 'A4',
                     },
                     ],*/
                    columns: [
                       {title: "CaseNo","render": function(data1, type, row, meta){
							
							var caseID = row[1]; 
           
                data1 = '<a target="_blank" href="<?php echo base_url()?>index.php/patientcase/index?cid=' +  caseID  + '">' + data1 + '</a>';
            

            return data1;
         }},
		                {title: "CaseId" ,"visible": false},
                        {title: "Registration Date"},
                        {title: "Patient Name"},
                        {title: "Address", className: "ptAddressclass"},
                        {title: "Location"},
                        {title: "DOB"},
                        {title: "Age"},
                        {title: "Gender"},
                        {title: "Contact No"},
                        {title: "Referred To"},
                        {title: "Referred By"},
                        {title: "Name Of Treating Doctor"},
                        {title: "Team Member"},
                        {title: "Case Receive Date"},
                        {title: "Disease Name"},
                        {title: "Depatment Of The Hospital"},
                        {title: "Required Fund"},
                        {title: "Initial Team Evaluation"},
                        {title: "Disbursed Amount"},
                        {title: "Approved Amount"},
                        {title: "Case Status"},
                        {title: "Additional Comment", className: "ptadditionclass"},
                    ],
                    'columnDefs': [ {
                        'targets': [6], /* column index */
                        'orderable': false, /* true or false */
                     },{ 
                            "render": function(data, type, row) {
                                return Number(data).toLocaleString('en-IN', {
                                    maximumFractionDigits: 2,
                                    style: 'currency',
                                    currency: 'INR'
                                });
                            },
                            targets: [17,19,20] 
                        }],
                    destroy: true,
                });


                $('#excel_report_pt').html('<a class="dt-button" href="' + baseurl + 'index.php/Reports/generatePatientExcelReport?report_type=donor&donor_id=' + donorId + '&from_date=' + from_date + '&to_date=' + to_date + '">Export to Excel</a>')
                // $('#excel_report_pt').show();
                var fmdate = from_date.split('-');
                var todate = to_date.split('-');
                var sptodate = todate[2] + '/' + todate[1] + '/' + todate[0];

                if (from_date != '') {
                    var msg = '<h4 class="third_heading">Showing Patient Details <span>From (' + fmdate[2] + '/' + fmdate[1] + '/' + fmdate[0] + ') To (' + sptodate + ')</span></h4>';
                } else {
                    var msg = '<h4 class="third_heading">Showing Patient Details <span>Till: ' + sptodate + ' (Today)</span></h4>';
                }
                $('#date_info').html(msg);
                $('#date_info').show();
                if (result.status == 'failure') {
                    $('#top_pt_msg').removeClass().addClass('alert alert-danger').text('Record not found.')
                    $('#excel_report_pt').hide();
                } else {
                    $('#top_pt_msg').removeClass().addClass('alert alert-success').text('Patient Details fetch Successfully.')
                    $('#excel_report_pt').show();
                }
                $('#top_pt_msg').show();
                setTimeout(function () {
                    $('.alert-success').hide();
                }, 2000);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {}
        });
    });
</script>
