
<style type="text/css">
    #rehelp_form .error{
            color:red;
          }
.fileList {
	padding: 0;
	list-style: none;
}
.fileList li {
	display: inline-block;
	padding: 15px 10px;
	box-shadow: 0px 0px 4px rgba(0,0,0,10%);
	margin-top: 10px;
	width: 100%;
	position:relative
}
.removeFile {
	position: absolute;
	right: 25px;
	font-size:0;
}
.removeFile::after {
	position: absolute;
	content: "\f00d";
	color: #666;
	font-size: 14px;
	font-family: FontAwesome;
	font-weight: normal;
}
.removeFile:hover::after{ color:#000}
.filCol{box-shadow: 0px 0px 4px rgba(0,0,0,10%); padding:8px; margin-bottom:10px;}
.filCol .first {
	font-size: 13px;
	font-weight: 400;
	color: #989da2;
	font-family: roboto;
}
.filCol .last{ float:right;}
</style>
<?php
if($active_doner){
    $doner_option ='<option value="">Select Donor</option>';
      foreach ($active_doner as $key => $value) {
        $doner_option.= '<option value = "'.$value['doner_id'].'">'.$value['name'].'</option>';
}}
// prx($result);
?>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
var doner_option = '<?php echo $doner_option;?>';
$('#active_doner').html(doner_option);
});
</script>

<?php
$cid = $case_id;
$patient_id = $result[0]->patient_id;
?>

  <?php
        $attributes = array('class' => 'rehelp_form', 'id' => 'rehelp_form');
        echo form_open("Caseinfo/saveRehelpDetails?cid=$cid&patient_id=$patient_id", $attributes);
            ?>
<div class="dash_right_section">
<h2 class="main-heading">Rehelp</h2>
<div class="row">
<div class="col-md-4">
<div class="dash_column">
<div class="circle green"><img src="<?php echo base_url('karoclient/images/patient-id.png'); ?>"></div>
<div class="cirtext">
<h3>Patient Id </h3>
<p><?php echo $result[0]->patient_id; ?></p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="dash_column">
<div class="circle pink"><img src="<?php echo base_url('karoclient/images/patient-name.png'); ?>"></div>
<div class="cirtext">
<h3>Patient Name</h3>
<p><?php echo $result[0]->patient_name;?></p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="dash_column">
<div class="circle blue"><img src="<?php echo base_url('karoclient/images/mobile.png'); ?>"></div>
<div class="cirtext">
<h3>Mobile No.</h3>
<p><?php echo $result[0]->patient_phone;?></p>
</div>
</div>
</div>
</div>
<div class="clearfix"></div>
<div class="dash_column">
<?php echo $this->session->flashdata('message');?>
       
<div class="col-md-6">
<div class="form-group">
<label for="name">Date</label>
 <input id="rehelp_date" name="rehelp_date" readonly="" type="text" class="form-control date defaultdater" placeholder="Select Date" value="<?php echo date('Y-m-d H:i:s');?>" readOnly>
</div>
<div class="form-group">
<label for="name">Requested amount </label>
<input id="rehelp_req_amt" name="rehelp_req_amt" type="text" class="form-control allownumericwithdecimal" placeholder="Enter requested amount" maxlength="12">
</div>
</div>
<div class="form-group col-md-6">
<label for="name">Prescribed Treatment</label>
<textarea class="form-control text-add" value="" placeholder="Prescribed Treatment" name="rehelp_treatment" id="rehelp_treatment"></textarea>
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group col-md-6">
<label for="name">Approved amount</label>
<input id="rehelp_approve_amt" name="rehelp_approve_amt" type="text" class="form-control allownumericwithdecimal" placeholder="Enter approved amount" maxlength="12">
</div>
<div class="form-group col-md-6 " >
<label for="name">Donor</label>
<select class="form-control rgt" name="active_doner" id="active_doner" >
                                        
                </select>

</div>
</div>
</div>
<input type="hidden" id="file_urls" name="file_urls" value='<?php echo !empty($documents)?$documents['file_urls']:""?>'>

<div class="form-group col-md-6 files" id="files1">
                            <h3 class="sub-haeding">Document – Scan</h3>
                            <div id="top-msg" class="top-msg" hidden></div>  
                            <input type="file" name="files1" id ="fUpload"multiple="" class="form-control file">
                            <br>
                            <input type="button" id="uploadBtn" value="Upload Files" class="btn btn-danger add">
                            <ul class="fileList"></ul>
                            <span id="successMsg"></span>
                                                    </div>
<div class="clearfix"></div>

 <div class="row">
            <div class="col-md-12">
                <button type="submit" name="save" value="add" class="btn btn-primary save">Submit</button>
            </div>
        </div>
</div>
</div>


</div>



<script type="text/javascript">
    $(document).ready(function(){
        $('#fUpload').change(function(){
               var fp = $("#fUpload");
               var lg = fp[0].files.length; // get length
               var items = fp[0].files;
               var fileSize = 0;
           
           if (lg > 0) {
               for (var i = 0; i < lg; i++) {
                   fileSize = fileSize+items[i].size; // get file size
               }
               if(fileSize > 5242880) { //file size is in bytes
                 $('#fUpload').val('');
                $('#top-msg').addClass('alert alert-danger').text('File size must not be more than 5 MB');
                $('#top-msg').show();
                setTimeout(function(){
                 $('#top-msg').hide();

                 }, 2000);
                
               }
           }
        });
    });
    </script>
