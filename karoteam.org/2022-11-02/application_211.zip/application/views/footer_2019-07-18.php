<?php
echo $this->session->set_flashdata('message', '');
$case_name = $case_name ? $case_name : '';
?>
<script type="text/javascript">

    base_url = "<?php echo base_url(); ?>";
    case_name = "<?php echo 'Karo_' . $case_name . '_case_' . date('Y-m-d'); ?>";
    is_admin ="<?php echo ($this->session->userdata('IsAdmin')!=1)? 'hidden':'';?>";

</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
<script src="<?php echo base_url(); ?>karoclient/js/jquery-ui.js"></script> 
<script src="<?php echo base_url(); ?>karoclient/js/bootstrap.min.js"></script> 
<script src="<?php echo base_url(); ?>karoclient/js/custom.js"></script> 
<!--script type="text/javascript" src="<?php echo base_url(); ?>karoclient/js/jquery.dataTables.min.js"></script-->

<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.19/sorting/natural.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.19/pagination/ellipses.js"></script>

<script src="<?php echo base_url(); ?>karoclient/js/custom_datatable.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>karoclient/js/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>karoclient/js/validation.js"></script>
<!-- <script type="text/javascript" src="<?php echo base_url(); ?>karoclient/js/jquery.datetimepicker.full.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script src="<?php echo base_url(); ?>karoclient/js/patient_validation.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $('#disease').DataTable({
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        'pagingType': 'full_numbers'});
    });
</script>
<script type="text/javascript">
    /*$('.form_datetime').datetimepicker({
        language:  'fr',
        weekStart: 1,
        todayBtn: 1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        forceParse: 0,
        showMeridian: 1
    });
    $('.form_date,.form_date-1,.form_date-2').datetimepicker({
        language: 'fr',
        weekStart: 1,
        todayBtn: 1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        minView: 2,
        forceParse: 0
    });
    $('.form_time').datetimepicker({
        language: 'fr',
        weekStart: 1,
        todayBtn: 1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 1,
        minView: 0,
        maxView: 1,
        forceParse: 0
    });*/
</script>
</body>
<style type="text/css">
    table.dataTable thead .sorting::after,
    table.dataTable thead .sorting_asc::after {
        display:none;
    }

    table.dataTable thead .sorting_desc::after {
        display:none;
    }

    table.dataTable thead .sorting {
        background-image: url(https://datatables.net/media/images/sort_both.png);
        background-repeat: no-repeat;
        background-position: center right;
    }

    table.dataTable thead .sorting_asc {
        background-image: url(https://datatables.net/media/images/sort_asc.png);
        background-repeat: no-repeat;
        background-position: center right;
    }

    table.dataTable thead .sorting_desc {
        background-image: url(https://datatables.net/media/images/sort_desc.png);
        background-repeat: no-repeat;
        background-position: center right;
    }
</style>
</html>