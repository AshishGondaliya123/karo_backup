<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Patientstatus extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else if (empty($this->session->userdata('IsAdmin'))) {
            redirect('dashboard');
        }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('patientstatus_model');
    }

    function index() {
        /* Check submit button */
        if ($this->input->post('save')) {
            $PatientStatus = trim($this->input->post('PatientStatus'));
            if ($PatientStatus != '') {
                $save = $this->patientstatus_model->savePatientStatus($PatientStatus);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter Patient Status</div>');
            }
        }
        $PatientStatus = $this->patientstatus_model->getPatientStatus();
        $getPatientStatusData['PatientStatus'] = $PatientStatus;
        $this->load->view('header');
        $this->load->view('patientstatus/index', $getPatientStatusData);
        $this->load->view('footer');
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->patientstatus_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('patientstatus');
        }
    }

    function changepatientstatus() {
        if ($this->input->post('save')) {
            $PatientStatus = ltrim($this->input->post('PatientStatus'));
            $PatientStatusId = base64_decode($this->input->post('PatientStatusId'));
            if ($PatientStatus != '' && $PatientStatusId != '') {
                $save = $this->patientstatus_model->changePatientStatus($PatientStatus, $PatientStatusId);
                $this->session->set_flashdata('message', $save);
            }
            redirect('patientstatus');
        }
    }

}

?>
