<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Donner extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } 
        // else if (empty($this->session->userdata('IsAdmin'))) {
        //     redirect('dashboard');
        // }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('referredby_model');
        $this->load->model('donner_model');
    }

    function index() {
        /* Check submit button */
        if ($this->input->post('save')) {
            // prx($this->input->post());die;
            $FirstName = trim($this->input->post('first_name'));
            $MiddleName = trim($this->input->post('middle_name'));
            $LastName = trim($this->input->post('last_name'));
            $DonerType = trim($this->input->post('dtype'));
            $DonerAddress = trim(str_replace("'", "`", $this->input->post('address')));
            $Country = trim($this->input->post('country'));
            if ($Country == 'India') {
                $State = trim($this->input->post('state'));
                $City = trim($this->input->post('city'));
            } else {
                $State = trim($this->input->post('otherstate'));
                $City = trim($this->input->post('othercity'));
            }
            $ZipCode = trim($this->input->post('zipcode'));
            $ContactNo = trim($this->input->post('primary_contact'));
            $EmailId = trim($this->input->post('emailid'));
            $PANCardNumber = trim($this->input->post('pan_card')); //die;
            $OrganizationName =trim($this->input->post('OrganizationName'));
            $MobileNo = trim($this->input->post('mobile_no'));
            if ($FirstName != '' && $DonerType != '' && $State != '' && $ZipCode != '' && $ContactNo != '' && $EmailId != '') {
                $save = $this->donner_model->savedonner($FirstName, $MiddleName, $LastName, $DonerType, $DonerAddress, $Country, $State, $City, $ZipCode, $ContactNo, $EmailId, $PANCardNumber,$OrganizationName,$MobileNo);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all required fields</div>');
            }
        }
        $getdonner = $this->donner_model->getdonner();
        $getcountry = $this->donner_model->getcountry();
        $getState = $this->referredby_model->getstates();

        //$getcity = $this->referredby_model->getreferedby();
        $getdonnerData['donnerData'] = $getdonner;
        $getdonnerData['states'] = $getState;
        $getdonnerData['countries'] = $getcountry;
        if (isset($_REQUEST['act'])) {
            if ($_REQUEST['act'] == 'update') {
                $DonnerData = $this->donner_model->getDonnerById(base64_decode($_REQUEST['id']));
                $getdonnerData['DonnerByID'] = $DonnerData;
                $city = $this->getcities($DonnerData[0]['State']);
                $getdonnerData['cities'] = $city;
            }
        }
        // prx($getdonnerData);
        $this->load->view('header');
        $this->load->view('donner/index', $getdonnerData);
        $this->load->view('footer');
    }

    function citiesByState() {
        $state = $_REQUEST['state'];
        if ($_REQUEST['cityid'] != '') {
            $cityname = $_REQUEST['cityid'];
        } else {
            $cityname = '';
        }
        $getcities = $this->referredby_model->getcities($state);
        echo "<option value=''>--Select City--</option>";
        foreach ($getcities as $city) {
            if ($city['city_name'] == $cityname) {
                $selected = "selected='selected'";
            } else {
                $selected = '';
            }
            echo "<option value='" . $city['city_name'] . "' " . $selected . ">" . $city['city_name'] . "</option>";
        }
    }

    function getcities($state) {
        $getcities = $this->referredby_model->getcities($state);
        return $getcities;
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->donner_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('donner');
        }
    }

    function updatedonner() {
        if ($this->input->post('save')) {
            // prx($this->input->post());
            $FirstName = trim($this->input->post('first_name'));
            $MiddleName = trim($this->input->post('middle_name'));
            $LastName = trim($this->input->post('last_name'));
            $DonerType = trim($this->input->post('dtype'));
            $DonerAddress = trim(str_replace("'", "`", $this->input->post('address')));
            $Country = trim($this->input->post('country'));
            if ($Country == 'India') {
                $State = trim($this->input->post('state'));
                $City = trim($this->input->post('city'));
            } else {
                $State = trim($this->input->post('otherstate'));
                $City = trim($this->input->post('othercity'));
            }
            $ZipCode = trim($this->input->post('zipcode'));
            $ContactNo = trim($this->input->post('primary_contact'));
            $EmailId = trim($this->input->post('emailid'));
            $PANCardNumber = trim($this->input->post('pan_card')); //die;
            $DonerId = $this->input->post('DonerId');
            $OrganizationName =trim($this->input->post('OrganizationName'));
            $MobileNo = trim($this->input->post('mobile_no'));
            if ($FirstName != '' && $DonerType != '' && $State != '' && $ZipCode != '' && $ContactNo != '' && $EmailId != '' && $DonerId != '') {
                $save = $this->donner_model->updatedonner($FirstName, $MiddleName, $LastName, $DonerType, $DonerAddress, $Country, $State, $City, $ZipCode, $ContactNo, $EmailId, $PANCardNumber, $DonerId,$OrganizationName,$MobileNo);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all requred fileds</div>');
            }
            redirect('donner');
        }
    }

    public function checkDonoremail()
    {
            if (isset($_REQUEST['email'])) {
                $checkemail = $this->donner_model->checkDonoremail($_REQUEST['email'],$_REQUEST['donnerId']);
                echo $checkemail;
            }
    }

}

?>
