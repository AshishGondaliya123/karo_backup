<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hospital extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        }
        //  else if (empty($this->session->userdata('IsAdmin'))) {
        //     redirect('dashboard');
        // }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('hospital_model');
    }

    function index() {
        /* Check submit button */
        if ($this->input->post('save')) {

            $HospitalName = trim($this->input->post('HospitalName'));
            $city = trim($this->input->post('city'));
            $state = trim($this->input->post('state'));
            $zipcode = trim($this->input->post('zipcode'));
            $contact_no = trim($this->input->post('contact_no'));
            $address = trim(str_replace("'", "`", $this->input->post('address')));
            if ($HospitalName != '' && $city != '' && $state != '' && $zipcode != '' && $contact_no != '' && $address != '') {
                $save = $this->hospital_model->savehospital($HospitalName, $city, $state, $zipcode, $contact_no, $address);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all required fields</div>');
            }
        }
        $gethospital = $this->hospital_model->gethospital();
        $getState = $this->hospital_model->getstates();

        //$getcity = $this->hospital_model->getreferedby();
        $gethospitalData['hospitals'] = $gethospital;
        $gethospitalData['states'] = $getState;
        if (isset($_REQUEST['act'])) {
            if ($_REQUEST['act'] == 'update') {
                $values = explode("|", base64_decode($_REQUEST['id']));
                $city = $this->getcities($values[3]);
                $gethospitalData['cities'] = $city;
            }
        }
        $this->load->view('header');
        $this->load->view('hospital/index', $gethospitalData);
        $this->load->view('footer');
    }

    function citiesByState() {
        $state = $_REQUEST['state'];
        if ($_REQUEST['cityid'] != '') {
            $cityname = $_REQUEST['cityid'];
        } else {
            $cityname = '';
        }
        $getcities = $this->hospital_model->getcities($state);
        echo "<option value=''>--Select City--</option>";
        foreach ($getcities as $city) {
            if ($city['city_name'] == $cityname) {
                $selected = "selected='selected'";
            } else {
                $selected = '';
            }
            echo "<option value='" . $city['city_name'] . "' " . $selected . ">" . $city['city_name'] . "</option>";
        }
    }

    function getcities($state) {
        $getcities = $this->hospital_model->getcities($state);
        return $getcities;
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->hospital_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('hospital');
        }
    }

    function updatehospital() {
        if ($this->input->post('save')) {
            //print_r($this->input->post());die;
            $HospitalName = trim($this->input->post('HospitalName'));
            $city = trim($this->input->post('city'));
            $state = trim($this->input->post('state'));
            $zipcode = trim($this->input->post('zipcode'));
            $contact_no = trim($this->input->post('contact_no'));
            $address = trim(str_replace("'", "`", $this->input->post('address')));
            $HospitalId = base64_decode($this->input->post('HospitalId'));
            if ($HospitalName != '' && $city != '' && $state != '' && $zipcode != '' && $contact_no != '' && $address != '' && $HospitalId != '') {
                $save = $this->hospital_model->updatehospital($HospitalName, $city, $state, $zipcode, $contact_no, $address, $HospitalId);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter all requred fileds</div>');
            }
            redirect('hospital');
        }
    }

    function dept() {
        $data["department"] = $this->hospital_model->getDept();
        $this->load->view('header');
        $this->load->view('hospital/depart', $data);
        $this->load->view('footer');
    }

    function save_dept() {
        /* Check submit button */
        if ($this->input->post('save')) {
            $dept_name = trim($this->input->post('dept_name'));
            if ($dept_name != '') {
                $save = $this->hospital_model->saveDept($dept_name);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter department name</div>');
            }
        }
        $data["department"] = $this->hospital_model->getDept();
        $this->load->view('header');
        $this->load->view('hospital/depart', $data);
        $this->load->view('footer');
    }

    function changedeptName() {
        if ($this->input->post('save')) {
            $dept_name = ltrim($this->input->post('dept_name'));
            $dept_id = base64_decode($this->input->post('dept_id'));
            if ($dept_name != '' && $dept_id != '') {
                $save = $this->hospital_model->changeDeptName($dept_name, $dept_id);
                $this->session->set_flashdata('message', $save);
            }
            redirect('hospital/dept');
        }
    }

    function changedeptstatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->hospital_model->changeDeptStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('hospital/dept');
        }
    }

}

?>
