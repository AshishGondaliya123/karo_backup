<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Patientclassification extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        } else if (empty($this->session->userdata('IsAdmin'))) {
            redirect('dashboard');
        }
        $this->load->library('form_validation');
        $this->load->library('encrypt');
        $this->load->model('patientclassification_model');
    }

    function index() {
        /* Check submit button */
        if ($this->input->post('save')) {
            $this->form_validation->set_rules('ClassificationName', 'Classification Name', 'required|trim|xss_clean|is_unique[patientclassification.ClassificationName]');
            $patientclassification_name = trim($this->input->post('ClassificationName'));
            ;
            if ($patientclassification_name != '') {
                $save = $this->patientclassification_model->savepatientclassification($patientclassification_name);
                $this->session->set_flashdata('message', $save);
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter patientclassification name</div>');
            }
        }
        $getpatientclassification = $this->patientclassification_model->getpatientclassification();
        $getpatientclassificationData['patientclassification'] = $getpatientclassification;
        $this->load->view('header');
        $this->load->view('patientclassification/index', $getpatientclassificationData);
        $this->load->view('footer');
    }

    function changestatus() {
        if ($_REQUEST['id'] != '') {
            $id = base64_decode($_REQUEST['id']);
            if ($_REQUEST['status'] == 1) {
                $status = 0;
            } else {
                $status = 1;
            }
            $save = $this->patientclassification_model->changeStatus($id, $status);
            $this->session->set_flashdata('message', $save);
            redirect('patientclassification');
        }
    }

    function changepatientclassificationName() {
        if ($this->input->post('save')) {
            $patientclassification_name = ltrim($this->input->post('ClassificationName'));
            $ClassificationId = base64_decode($this->input->post('ClassificationId'));
            if ($patientclassification_name != '' && $ClassificationId != '') {
                $save = $this->patientclassification_model->changepatientclassificationName($patientclassification_name, $ClassificationId);
                $this->session->set_flashdata('message', $save);
            }
            redirect('patientclassification');
        }
    }

}

?>
