<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Transaction extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('UsertId')) {
            redirect('login');
        }
        $this->load->library('form_validation');
        $this->load->model('case_model', 'cm');
    }

    public function saveDonerDonation() {
        $data = [];
        $active_donner = $this->cm->getActiveDoner();
        if ($active_donner)
            foreach ($active_donner as $key => $value) {
                $data['active_donner'][$key]['donner_id'] = $value->DonerId;
                $data['active_donner'][$key]['name'] = $value->firstName . ' ' . $value->middleName . ' ' . $value->lastName;
            }
        $where_data['IsActive'] = 1;
        $donation_mode = $this->cm->selectDataFromTable('paymentmaster', ' ', $where_data);
        if ($donation_mode)
            $data['donation_mode'] = $donation_mode;
        if ($this->input->post('save')) {
            $post = $this->input->post();
            if (empty($post['doner']) || empty($post['donation_amount']) || empty($post['donation_date']) || empty($post['donation_mode'])) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter details </div>');
            } else {
                $insert_data['DonerId'] = $post['doner'];
                $insert_data['DonationDate'] = date('y-m-d', strtotime($post['donation_date']));
                $insert_data['DonationAmount'] = $post['donation_amount'];
                $insert_data['PaymentModeId'] = $post['donation_mode'];
                $insert_data['DonationBank'] = trim($post['bank_name']);
                $insert_data['DonationRefNo'] = trim($post['cheque']);
                // $insert_data['IsDonationReceive'] = $post['IsDonationReceive'];
                $insert_data['CreatedById'] = $this->session->userdata('UsertId');
                $insert_data['CreatedDate'] = date('Y-m-d H:i:s');
                $this->cm->insertDataIntoTable('doner_donation_detail', $insert_data);

                $this->session->set_flashdata('message', '<div class="alert alert-success">Amount saved successfully</div>');
            }
        }
        $data['result'] = $this->cm->getDonnerDetails();
        $this->load->view('header');
        $this->load->view('transaction/donner_donation', $data);
        $this->load->view('footer');
    }

    public function upcomingFollowup() {
        $post = $this->input->post();
        if ($post['save']) {
            
            $patient_details = $this->cm->getOpenCaseDetails($params);
            $follow_up = $this->cm->getNextFollowupDate(0, $post['from_date'], $post['to_date'], $post['department']);

            if ($follow_up) {
                foreach ($follow_up as $key => $value) {
                    foreach ($patient_details as $k => $v) {
                        if ($value['case_id'] == $v['id']) {
                            $follow_up[$key] = $v;
                            $follow_up[$key]['follow_up_done'] = $value['folowup_done'] == 1 ? 'YES' : 'NO';
                            $follow_up[$key]['next_followup_date'] = $value['next_followup_date'];
                            $follow_up[$key]['remark'] = $value['remark'];
                            break;
                        }
                    }
                }
            }
            $data['from_date'] = $post['from_date'];
            $data['to_date'] = $post['to_date'];
        }
        $data['result'] = $follow_up;
        
        $this->load->model('hospital_model', 'hm');
        $data['active_department'] = $this->hm->getActiveDept();

        $this->load->view('header');
        $this->load->view('transaction/upcomingFollowup', $data);
        $this->load->view('footer');
    }

    //Deepa....refund amount
    function refundAmount() {
        $post = $this->input->post();
        if ($post['filter_save']) {
            $patient_details = $this->cm->viewForRefundAmount($post);
            $data['result'] = $patient_details;
            $data['karo'] = $post['karo_no'];

          if ($data['result']){
                $this->session->set_flashdata('message', '<div class="alert alert-success msg"> Patient Finacial details fetch successfully</div>');
		  } else{
                $this->session->set_flashdata('message', '<div class="alert alert-danger msg"> Record not found </div>');
        }
		}
        $where_data['IsActive'] = 1;
        $data['mode'] = $this->cm->selectDataFromTable('paymentmaster', ' ', $where_data);
        $data['patient_id'] = $patient_details[0]['patient_id'];
        $data['case_id'] = $patient_details[0]['patient_case'];
		
		
		$caseId = $patient_details[0]["id"];
		$data["resultsreflis"] = $this->cm->getRefundByDonor($caseId);
				
        $this->load->model('hospital_model', 'hm');
        $data['active_department'] = $this->hm->getActiveDept();
        
        $this->load->view('header');
        $this->load->view('transaction/refund_amount', $data);
        $this->load->view('footer');
    }
	
	function getSanctionIdList(){
		
		  $get = $this->input->post('CaseId');

        $sanction_id = $this->cm->getSanctionId($get);

        $html = "";
        $html .="<select class='form-control' name='sanction_id' id='sanction_id' onchange='donerBySanctIdAjax(this.value)'><option value=''>Select sanction id</option>";
        foreach ($sanction_id as $sanction) {
            $html .="<option value='" . $sanction->sanction_id . "'>" . $sanction->sanction_id . "</option>";
        }
        $html .="</select>";
        echo $html;
	}
	
	function donorBySanctionId(){
        $s_id =  $this->input->post('sanc_Id');
	//	prx($s_id );
	   
		$sanc_doner=$this->cm->getDonorDetail($s_id);
				
				
				 $html = "";
       // $html .="<select class='form-control' name='donor_list' id='donor_list'><option value=''>Select donor</option>";
        foreach ($sanc_doner as $donor) {
            $html .="<option value='" . $donor->d . "' data-donoramount='" . $donor->total . "' data-disbId='" . $donor->id . "'>" . $donor->Doner . "</option>";
        }
        $html .="</select>";
        echo $html;
		
		
	}

    // function getAmountDisburse() {
        // $get = $this->input->post('CaseId');

        // $donor_disbured_amt = $this->cm->getDonorDetail($get);

        // $html = "";
        // $html .="<select class='form-control' name='disburse_donor' id='disburse_donor'><option value=''>Select donor</option>";
        // foreach ($donor_disbured_amt as $donor) {
            // $html .="<option value='" . $donor->d . "' data-donoramount='" . $donor->total . "' data-disbId='" . $donor->id . "'>" . $donor->Doner . "</option>";
        // }
        // $html .="</select>";
        // echo $html;
    // }
	
	

    function saverefund() {
        $get = $this->input->get();

        if ($this->input->post('save_btn')) {
            $post = $this->input->post();
            if (empty($post['refund_mode']) || empty($post['refund_date']) || empty($post['refund_reason']) || empty($post['refund_amount'])) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Please enter details </div>');
            } else {
                $config['upload_path'] = 'karoclient/refund_img/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg|pdf|csv|txt|doc|docx|GIF|JPG|PNG|JPEG|PDF|DOC|DOCX|xls|xlsx|CSV|TXT';
				$config['max_size'] = '2048';
                //Load upload library and initialize configuration
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if (!empty($_FILES['reciept_upload1']['name'])) {
                    if ($this->upload->do_upload('reciept_upload1')) {
                        $uploadData1 = $this->upload->data();
                        $upload = base_url() . "karoclient/refund_img/" . $uploadData1['file_name'];
                    } else {
                        $upload = '';
                    }
                } else {
                    $upload = '';
                }

                if (!empty($_FILES['reciept_upload2']['name'])) {
                    if ($this->upload->do_upload('reciept_upload2')) {
                        $uploadData2 = $this->upload->data();
                        $uploads = base_url() . "karoclient/refund_img/" . $uploadData2['file_name'];
                    } else {
                        $uploads = '';
                    }
                } else {
                    $uploads = '';
                }

                $insert_data['patient_id'] = $post['patient_id'];
                $insert_data['case_id'] = $post['case_id'];
				$insert_data['sanction_id'] = $post['sanction_id'];
                $insert_data['donor_id'] = $post['donor_list'];
                $insert_data['donate_amount'] = $post['donate_amount_donor'];
                $insert_data['mode_of_refund'] = $post['refund_mode'];
                $insert_data['cheque_no'] = trim($post['cheque_no']);
				$insert_data['bank_name'] = trim($post['bank']);
                $insert_data['refund_amount'] = $post['refund_amount'];
                $insert_data['refund_date'] = date('y-m-d', strtotime($post['refund_date']));
                $insert_data['refund_reason'] = trim($post['refund_reason']);
                $insert_data['reference_1'] = $upload;
                $insert_data['reference_2'] = $uploads;
                $insert_data['reference_first'] = $post['reference_first'];
                $insert_data['reference_second'] = $post['reference_two'];

                $insert_data['created_at'] = date('Y-m-d H:i:s');

                $this->cm->insertDataIntoTable('refund_amount_details', $insert_data);
				
				//prx($post['disbId']);
				
				$this->cm->updateStatusForRefund($post['disbId']);

                $this->session->set_flashdata('message', '<div class="alert alert-success">Amount saved successfully</div>');
            }
        }
	
        redirect('/Transaction/refundAmount');
    }
	
	
	
	
	

}
