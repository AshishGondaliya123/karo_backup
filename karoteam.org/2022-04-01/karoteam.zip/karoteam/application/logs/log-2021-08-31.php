<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-31 18:48:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-31 18:48:30 --> Config Class Initialized
INFO - 2021-08-31 18:48:30 --> Hooks Class Initialized
DEBUG - 2021-08-31 18:48:30 --> UTF-8 Support Enabled
INFO - 2021-08-31 18:48:30 --> Utf8 Class Initialized
INFO - 2021-08-31 18:48:30 --> URI Class Initialized
INFO - 2021-08-31 18:48:30 --> Router Class Initialized
INFO - 2021-08-31 18:48:30 --> Output Class Initialized
INFO - 2021-08-31 18:48:30 --> Security Class Initialized
DEBUG - 2021-08-31 18:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-31 18:48:30 --> Input Class Initialized
INFO - 2021-08-31 18:48:30 --> Language Class Initialized
ERROR - 2021-08-31 18:48:30 --> 404 Page Not Found: TelerikWebUIWebResourceaxd/index
