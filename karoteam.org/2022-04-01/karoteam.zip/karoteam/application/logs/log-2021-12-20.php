<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-20 00:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:11:09 --> Config Class Initialized
INFO - 2021-12-20 00:11:09 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:11:09 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:11:09 --> Utf8 Class Initialized
INFO - 2021-12-20 00:11:09 --> URI Class Initialized
DEBUG - 2021-12-20 00:11:09 --> No URI present. Default controller set.
INFO - 2021-12-20 00:11:09 --> Router Class Initialized
INFO - 2021-12-20 00:11:09 --> Output Class Initialized
INFO - 2021-12-20 00:11:09 --> Security Class Initialized
DEBUG - 2021-12-20 00:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:11:09 --> Input Class Initialized
INFO - 2021-12-20 00:11:09 --> Language Class Initialized
INFO - 2021-12-20 00:11:09 --> Loader Class Initialized
INFO - 2021-12-20 00:11:09 --> Helper loaded: url_helper
INFO - 2021-12-20 00:11:09 --> Helper loaded: form_helper
INFO - 2021-12-20 00:11:09 --> Helper loaded: common_helper
INFO - 2021-12-20 00:11:09 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:11:09 --> Controller Class Initialized
INFO - 2021-12-20 00:11:09 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:11:09 --> Encrypt Class Initialized
DEBUG - 2021-12-20 00:11:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 00:11:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 00:11:09 --> Email Class Initialized
INFO - 2021-12-20 00:11:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 00:11:09 --> Calendar Class Initialized
INFO - 2021-12-20 00:11:09 --> Model "Login_model" initialized
INFO - 2021-12-20 00:11:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 00:11:09 --> Final output sent to browser
DEBUG - 2021-12-20 00:11:09 --> Total execution time: 0.0263
ERROR - 2021-12-20 00:11:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:11:12 --> Config Class Initialized
INFO - 2021-12-20 00:11:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:11:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:11:12 --> Utf8 Class Initialized
INFO - 2021-12-20 00:11:12 --> URI Class Initialized
INFO - 2021-12-20 00:11:12 --> Router Class Initialized
INFO - 2021-12-20 00:11:12 --> Output Class Initialized
INFO - 2021-12-20 00:11:12 --> Security Class Initialized
DEBUG - 2021-12-20 00:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:11:12 --> Input Class Initialized
INFO - 2021-12-20 00:11:12 --> Language Class Initialized
INFO - 2021-12-20 00:11:12 --> Loader Class Initialized
INFO - 2021-12-20 00:11:12 --> Helper loaded: url_helper
INFO - 2021-12-20 00:11:12 --> Helper loaded: form_helper
INFO - 2021-12-20 00:11:12 --> Helper loaded: common_helper
INFO - 2021-12-20 00:11:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:11:12 --> Controller Class Initialized
INFO - 2021-12-20 00:11:12 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:11:12 --> Encrypt Class Initialized
DEBUG - 2021-12-20 00:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 00:11:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 00:11:12 --> Email Class Initialized
INFO - 2021-12-20 00:11:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 00:11:12 --> Calendar Class Initialized
INFO - 2021-12-20 00:11:12 --> Model "Login_model" initialized
INFO - 2021-12-20 00:11:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-20 00:11:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:11:12 --> Config Class Initialized
INFO - 2021-12-20 00:11:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:11:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:11:12 --> Utf8 Class Initialized
INFO - 2021-12-20 00:11:12 --> URI Class Initialized
INFO - 2021-12-20 00:11:12 --> Router Class Initialized
INFO - 2021-12-20 00:11:12 --> Output Class Initialized
INFO - 2021-12-20 00:11:12 --> Security Class Initialized
DEBUG - 2021-12-20 00:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:11:12 --> Input Class Initialized
INFO - 2021-12-20 00:11:12 --> Language Class Initialized
INFO - 2021-12-20 00:11:12 --> Loader Class Initialized
INFO - 2021-12-20 00:11:12 --> Helper loaded: url_helper
INFO - 2021-12-20 00:11:12 --> Helper loaded: form_helper
INFO - 2021-12-20 00:11:12 --> Helper loaded: common_helper
INFO - 2021-12-20 00:11:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:11:12 --> Controller Class Initialized
INFO - 2021-12-20 00:11:12 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:11:12 --> Encrypt Class Initialized
INFO - 2021-12-20 00:11:12 --> Model "Login_model" initialized
INFO - 2021-12-20 00:11:12 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 00:11:12 --> Model "Case_model" initialized
INFO - 2021-12-20 00:11:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:11:29 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 00:11:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:11:29 --> Final output sent to browser
DEBUG - 2021-12-20 00:11:29 --> Total execution time: 16.4121
ERROR - 2021-12-20 00:11:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:11:32 --> Config Class Initialized
INFO - 2021-12-20 00:11:32 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:11:32 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:11:32 --> Utf8 Class Initialized
INFO - 2021-12-20 00:11:32 --> URI Class Initialized
INFO - 2021-12-20 00:11:32 --> Router Class Initialized
INFO - 2021-12-20 00:11:32 --> Output Class Initialized
INFO - 2021-12-20 00:11:32 --> Security Class Initialized
DEBUG - 2021-12-20 00:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:11:32 --> Input Class Initialized
INFO - 2021-12-20 00:11:32 --> Language Class Initialized
ERROR - 2021-12-20 00:11:32 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 00:19:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:19:20 --> Config Class Initialized
INFO - 2021-12-20 00:19:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:19:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:19:20 --> Utf8 Class Initialized
INFO - 2021-12-20 00:19:20 --> URI Class Initialized
INFO - 2021-12-20 00:19:20 --> Router Class Initialized
INFO - 2021-12-20 00:19:20 --> Output Class Initialized
INFO - 2021-12-20 00:19:20 --> Security Class Initialized
DEBUG - 2021-12-20 00:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:19:20 --> Input Class Initialized
INFO - 2021-12-20 00:19:20 --> Language Class Initialized
INFO - 2021-12-20 00:19:20 --> Loader Class Initialized
INFO - 2021-12-20 00:19:20 --> Helper loaded: url_helper
INFO - 2021-12-20 00:19:20 --> Helper loaded: form_helper
INFO - 2021-12-20 00:19:20 --> Helper loaded: common_helper
INFO - 2021-12-20 00:19:20 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:19:20 --> Controller Class Initialized
INFO - 2021-12-20 00:19:20 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:19:20 --> Encrypt Class Initialized
INFO - 2021-12-20 00:19:20 --> Model "Login_model" initialized
INFO - 2021-12-20 00:19:20 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 00:19:20 --> Model "Case_model" initialized
ERROR - 2021-12-20 00:19:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:19:25 --> Config Class Initialized
INFO - 2021-12-20 00:19:25 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:19:25 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:19:25 --> Utf8 Class Initialized
INFO - 2021-12-20 00:19:25 --> URI Class Initialized
INFO - 2021-12-20 00:19:25 --> Router Class Initialized
INFO - 2021-12-20 00:19:25 --> Output Class Initialized
INFO - 2021-12-20 00:19:25 --> Security Class Initialized
DEBUG - 2021-12-20 00:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:19:25 --> Input Class Initialized
INFO - 2021-12-20 00:19:25 --> Language Class Initialized
INFO - 2021-12-20 00:19:25 --> Loader Class Initialized
INFO - 2021-12-20 00:19:25 --> Helper loaded: url_helper
INFO - 2021-12-20 00:19:25 --> Helper loaded: form_helper
INFO - 2021-12-20 00:19:25 --> Helper loaded: common_helper
INFO - 2021-12-20 00:19:25 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:19:25 --> Controller Class Initialized
INFO - 2021-12-20 00:19:25 --> Form Validation Class Initialized
INFO - 2021-12-20 00:19:25 --> Model "Case_model" initialized
INFO - 2021-12-20 00:19:25 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 00:19:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:19:25 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2021-12-20 00:19:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:19:25 --> Final output sent to browser
DEBUG - 2021-12-20 00:19:25 --> Total execution time: 0.5863
ERROR - 2021-12-20 00:19:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:19:26 --> Config Class Initialized
INFO - 2021-12-20 00:19:26 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:19:26 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:19:26 --> Utf8 Class Initialized
INFO - 2021-12-20 00:19:26 --> URI Class Initialized
INFO - 2021-12-20 00:19:26 --> Router Class Initialized
INFO - 2021-12-20 00:19:26 --> Output Class Initialized
INFO - 2021-12-20 00:19:26 --> Security Class Initialized
DEBUG - 2021-12-20 00:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:19:26 --> Input Class Initialized
INFO - 2021-12-20 00:19:26 --> Language Class Initialized
ERROR - 2021-12-20 00:19:26 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-20 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:19:39 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 00:19:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:19:39 --> Final output sent to browser
DEBUG - 2021-12-20 00:19:39 --> Total execution time: 18.7326
ERROR - 2021-12-20 00:19:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:19:40 --> Config Class Initialized
INFO - 2021-12-20 00:19:40 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:19:40 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:19:40 --> Utf8 Class Initialized
INFO - 2021-12-20 00:19:40 --> URI Class Initialized
INFO - 2021-12-20 00:19:40 --> Router Class Initialized
INFO - 2021-12-20 00:19:40 --> Output Class Initialized
INFO - 2021-12-20 00:19:40 --> Security Class Initialized
DEBUG - 2021-12-20 00:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:19:40 --> Input Class Initialized
INFO - 2021-12-20 00:19:40 --> Language Class Initialized
ERROR - 2021-12-20 00:19:40 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 00:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:19:44 --> Config Class Initialized
INFO - 2021-12-20 00:19:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:19:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:19:44 --> Utf8 Class Initialized
INFO - 2021-12-20 00:19:44 --> URI Class Initialized
INFO - 2021-12-20 00:19:44 --> Router Class Initialized
INFO - 2021-12-20 00:19:44 --> Output Class Initialized
INFO - 2021-12-20 00:19:44 --> Security Class Initialized
DEBUG - 2021-12-20 00:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:19:44 --> Input Class Initialized
INFO - 2021-12-20 00:19:44 --> Language Class Initialized
INFO - 2021-12-20 00:19:44 --> Loader Class Initialized
INFO - 2021-12-20 00:19:44 --> Helper loaded: url_helper
INFO - 2021-12-20 00:19:44 --> Helper loaded: form_helper
INFO - 2021-12-20 00:19:44 --> Helper loaded: common_helper
INFO - 2021-12-20 00:19:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:19:44 --> Controller Class Initialized
INFO - 2021-12-20 00:19:44 --> Form Validation Class Initialized
INFO - 2021-12-20 00:19:44 --> Model "Case_model" initialized
INFO - 2021-12-20 00:19:44 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 00:19:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:19:47 --> Model "Case_model" initialized
INFO - 2021-12-20 00:19:50 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2021-12-20 00:19:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:19:50 --> Final output sent to browser
DEBUG - 2021-12-20 00:19:50 --> Total execution time: 5.1998
ERROR - 2021-12-20 00:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:19:50 --> Config Class Initialized
INFO - 2021-12-20 00:19:50 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:19:50 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:19:50 --> Utf8 Class Initialized
INFO - 2021-12-20 00:19:50 --> URI Class Initialized
INFO - 2021-12-20 00:19:50 --> Router Class Initialized
INFO - 2021-12-20 00:19:50 --> Output Class Initialized
INFO - 2021-12-20 00:19:50 --> Security Class Initialized
DEBUG - 2021-12-20 00:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:19:50 --> Input Class Initialized
INFO - 2021-12-20 00:19:50 --> Language Class Initialized
ERROR - 2021-12-20 00:19:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 00:20:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:20:02 --> Config Class Initialized
INFO - 2021-12-20 00:20:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:20:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:20:02 --> Utf8 Class Initialized
INFO - 2021-12-20 00:20:02 --> URI Class Initialized
INFO - 2021-12-20 00:20:02 --> Router Class Initialized
INFO - 2021-12-20 00:20:02 --> Output Class Initialized
INFO - 2021-12-20 00:20:02 --> Security Class Initialized
DEBUG - 2021-12-20 00:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:20:02 --> Input Class Initialized
INFO - 2021-12-20 00:20:02 --> Language Class Initialized
INFO - 2021-12-20 00:20:02 --> Loader Class Initialized
INFO - 2021-12-20 00:20:02 --> Helper loaded: url_helper
INFO - 2021-12-20 00:20:02 --> Helper loaded: form_helper
INFO - 2021-12-20 00:20:02 --> Helper loaded: common_helper
INFO - 2021-12-20 00:20:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:20:02 --> Controller Class Initialized
INFO - 2021-12-20 00:20:02 --> Form Validation Class Initialized
INFO - 2021-12-20 00:20:02 --> Model "Case_model" initialized
INFO - 2021-12-20 00:20:02 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 00:20:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:20:04 --> File loaded: /home3/karoteam/public_html/application/views/cases/patient_amount_disbursed.php
INFO - 2021-12-20 00:20:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:20:04 --> Final output sent to browser
DEBUG - 2021-12-20 00:20:04 --> Total execution time: 2.2123
ERROR - 2021-12-20 00:20:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:20:05 --> Config Class Initialized
INFO - 2021-12-20 00:20:05 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:20:05 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:20:05 --> Utf8 Class Initialized
INFO - 2021-12-20 00:20:05 --> URI Class Initialized
INFO - 2021-12-20 00:20:05 --> Router Class Initialized
INFO - 2021-12-20 00:20:05 --> Output Class Initialized
INFO - 2021-12-20 00:20:05 --> Security Class Initialized
DEBUG - 2021-12-20 00:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:20:05 --> Input Class Initialized
INFO - 2021-12-20 00:20:05 --> Language Class Initialized
ERROR - 2021-12-20 00:20:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 00:20:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:20:35 --> Config Class Initialized
INFO - 2021-12-20 00:20:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:20:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:20:35 --> Utf8 Class Initialized
INFO - 2021-12-20 00:20:35 --> URI Class Initialized
INFO - 2021-12-20 00:20:35 --> Router Class Initialized
INFO - 2021-12-20 00:20:35 --> Output Class Initialized
INFO - 2021-12-20 00:20:35 --> Security Class Initialized
DEBUG - 2021-12-20 00:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:20:35 --> Input Class Initialized
INFO - 2021-12-20 00:20:35 --> Language Class Initialized
INFO - 2021-12-20 00:20:35 --> Loader Class Initialized
INFO - 2021-12-20 00:20:35 --> Helper loaded: url_helper
INFO - 2021-12-20 00:20:35 --> Helper loaded: form_helper
INFO - 2021-12-20 00:20:35 --> Helper loaded: common_helper
INFO - 2021-12-20 00:20:35 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:20:35 --> Controller Class Initialized
INFO - 2021-12-20 00:20:35 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:20:35 --> Encrypt Class Initialized
INFO - 2021-12-20 00:20:35 --> Model "Login_model" initialized
INFO - 2021-12-20 00:20:35 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 00:20:35 --> Model "Case_model" initialized
INFO - 2021-12-20 00:20:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-20 00:20:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:20:45 --> Config Class Initialized
INFO - 2021-12-20 00:20:45 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:20:45 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:20:45 --> Utf8 Class Initialized
INFO - 2021-12-20 00:20:45 --> URI Class Initialized
INFO - 2021-12-20 00:20:45 --> Router Class Initialized
INFO - 2021-12-20 00:20:45 --> Output Class Initialized
INFO - 2021-12-20 00:20:45 --> Security Class Initialized
DEBUG - 2021-12-20 00:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:20:45 --> Input Class Initialized
INFO - 2021-12-20 00:20:45 --> Language Class Initialized
INFO - 2021-12-20 00:20:45 --> Loader Class Initialized
INFO - 2021-12-20 00:20:45 --> Helper loaded: url_helper
INFO - 2021-12-20 00:20:45 --> Helper loaded: form_helper
INFO - 2021-12-20 00:20:45 --> Helper loaded: common_helper
INFO - 2021-12-20 00:20:45 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:20:53 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 00:20:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:20:53 --> Final output sent to browser
DEBUG - 2021-12-20 00:20:53 --> Total execution time: 17.2120
INFO - 2021-12-20 00:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:20:53 --> Controller Class Initialized
INFO - 2021-12-20 00:20:53 --> Form Validation Class Initialized
INFO - 2021-12-20 00:20:53 --> Model "Case_model" initialized
INFO - 2021-12-20 00:20:53 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 00:20:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:20:53 --> Model "Case_model" initialized
INFO - 2021-12-20 00:20:53 --> File loaded: /home3/karoteam/public_html/application/views/cases/hold_case.php
INFO - 2021-12-20 00:20:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:20:53 --> Final output sent to browser
DEBUG - 2021-12-20 00:20:53 --> Total execution time: 7.5273
ERROR - 2021-12-20 00:20:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:20:53 --> Config Class Initialized
INFO - 2021-12-20 00:20:53 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:20:53 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:20:53 --> Utf8 Class Initialized
INFO - 2021-12-20 00:20:53 --> URI Class Initialized
INFO - 2021-12-20 00:20:53 --> Router Class Initialized
INFO - 2021-12-20 00:20:53 --> Output Class Initialized
INFO - 2021-12-20 00:20:53 --> Security Class Initialized
DEBUG - 2021-12-20 00:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:20:53 --> Input Class Initialized
INFO - 2021-12-20 00:20:53 --> Language Class Initialized
ERROR - 2021-12-20 00:20:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:20:53 --> Config Class Initialized
INFO - 2021-12-20 00:20:53 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:20:53 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:20:53 --> Utf8 Class Initialized
INFO - 2021-12-20 00:20:53 --> Loader Class Initialized
INFO - 2021-12-20 00:20:53 --> URI Class Initialized
INFO - 2021-12-20 00:20:53 --> Helper loaded: url_helper
INFO - 2021-12-20 00:20:53 --> Router Class Initialized
INFO - 2021-12-20 00:20:53 --> Helper loaded: form_helper
INFO - 2021-12-20 00:20:53 --> Output Class Initialized
INFO - 2021-12-20 00:20:53 --> Helper loaded: common_helper
INFO - 2021-12-20 00:20:53 --> Security Class Initialized
DEBUG - 2021-12-20 00:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:20:53 --> Input Class Initialized
INFO - 2021-12-20 00:20:53 --> Language Class Initialized
ERROR - 2021-12-20 00:20:53 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-20 00:20:53 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:20:53 --> Controller Class Initialized
INFO - 2021-12-20 00:20:53 --> Form Validation Class Initialized
INFO - 2021-12-20 00:20:53 --> Model "Case_model" initialized
INFO - 2021-12-20 00:20:53 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 00:20:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:20:53 --> Model "Case_model" initialized
INFO - 2021-12-20 00:20:54 --> File loaded: /home3/karoteam/public_html/application/views/cases/hold_case.php
INFO - 2021-12-20 00:20:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:20:54 --> Final output sent to browser
DEBUG - 2021-12-20 00:20:54 --> Total execution time: 0.2102
ERROR - 2021-12-20 00:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:20:54 --> Config Class Initialized
INFO - 2021-12-20 00:20:54 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:20:54 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:20:54 --> Utf8 Class Initialized
INFO - 2021-12-20 00:20:54 --> URI Class Initialized
INFO - 2021-12-20 00:20:54 --> Router Class Initialized
INFO - 2021-12-20 00:20:54 --> Output Class Initialized
INFO - 2021-12-20 00:20:54 --> Security Class Initialized
DEBUG - 2021-12-20 00:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:20:54 --> Input Class Initialized
INFO - 2021-12-20 00:20:54 --> Language Class Initialized
ERROR - 2021-12-20 00:20:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 00:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:21:19 --> Config Class Initialized
INFO - 2021-12-20 00:21:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:21:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:21:19 --> Utf8 Class Initialized
INFO - 2021-12-20 00:21:19 --> URI Class Initialized
INFO - 2021-12-20 00:21:19 --> Router Class Initialized
INFO - 2021-12-20 00:21:19 --> Output Class Initialized
INFO - 2021-12-20 00:21:19 --> Security Class Initialized
DEBUG - 2021-12-20 00:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:21:19 --> Input Class Initialized
INFO - 2021-12-20 00:21:19 --> Language Class Initialized
INFO - 2021-12-20 00:21:19 --> Loader Class Initialized
INFO - 2021-12-20 00:21:19 --> Helper loaded: url_helper
INFO - 2021-12-20 00:21:19 --> Helper loaded: form_helper
INFO - 2021-12-20 00:21:19 --> Helper loaded: common_helper
INFO - 2021-12-20 00:21:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:21:19 --> Controller Class Initialized
INFO - 2021-12-20 00:21:19 --> Form Validation Class Initialized
INFO - 2021-12-20 00:21:19 --> Model "Case_model" initialized
INFO - 2021-12-20 00:21:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:21:19 --> File loaded: /home3/karoteam/public_html/application/views/transaction/donner_donation.php
INFO - 2021-12-20 00:21:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:21:19 --> Final output sent to browser
DEBUG - 2021-12-20 00:21:19 --> Total execution time: 0.0289
ERROR - 2021-12-20 00:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:21:19 --> Config Class Initialized
INFO - 2021-12-20 00:21:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:21:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:21:19 --> Utf8 Class Initialized
INFO - 2021-12-20 00:21:19 --> URI Class Initialized
INFO - 2021-12-20 00:21:19 --> Router Class Initialized
INFO - 2021-12-20 00:21:19 --> Output Class Initialized
INFO - 2021-12-20 00:21:19 --> Security Class Initialized
DEBUG - 2021-12-20 00:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:21:19 --> Input Class Initialized
INFO - 2021-12-20 00:21:19 --> Language Class Initialized
ERROR - 2021-12-20 00:21:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 00:22:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:22:34 --> Config Class Initialized
INFO - 2021-12-20 00:22:34 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:22:34 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:22:34 --> Utf8 Class Initialized
INFO - 2021-12-20 00:22:34 --> URI Class Initialized
INFO - 2021-12-20 00:22:34 --> Router Class Initialized
INFO - 2021-12-20 00:22:34 --> Output Class Initialized
INFO - 2021-12-20 00:22:34 --> Security Class Initialized
DEBUG - 2021-12-20 00:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:22:34 --> Input Class Initialized
INFO - 2021-12-20 00:22:34 --> Language Class Initialized
INFO - 2021-12-20 00:22:34 --> Loader Class Initialized
INFO - 2021-12-20 00:22:34 --> Helper loaded: url_helper
INFO - 2021-12-20 00:22:34 --> Helper loaded: form_helper
INFO - 2021-12-20 00:22:34 --> Helper loaded: common_helper
INFO - 2021-12-20 00:22:34 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:22:34 --> Controller Class Initialized
INFO - 2021-12-20 00:22:34 --> Form Validation Class Initialized
INFO - 2021-12-20 00:22:34 --> Model "Case_model" initialized
INFO - 2021-12-20 00:22:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:22:34 --> File loaded: /home3/karoteam/public_html/application/views/transaction/donner_donation.php
INFO - 2021-12-20 00:22:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:22:34 --> Final output sent to browser
DEBUG - 2021-12-20 00:22:34 --> Total execution time: 0.0280
ERROR - 2021-12-20 00:22:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:22:34 --> Config Class Initialized
INFO - 2021-12-20 00:22:34 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:22:34 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:22:34 --> Utf8 Class Initialized
INFO - 2021-12-20 00:22:34 --> URI Class Initialized
INFO - 2021-12-20 00:22:34 --> Router Class Initialized
INFO - 2021-12-20 00:22:34 --> Output Class Initialized
INFO - 2021-12-20 00:22:34 --> Security Class Initialized
DEBUG - 2021-12-20 00:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:22:34 --> Input Class Initialized
INFO - 2021-12-20 00:22:34 --> Language Class Initialized
ERROR - 2021-12-20 00:22:34 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 00:22:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:22:44 --> Config Class Initialized
INFO - 2021-12-20 00:22:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:22:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:22:44 --> Utf8 Class Initialized
INFO - 2021-12-20 00:22:44 --> URI Class Initialized
INFO - 2021-12-20 00:22:44 --> Router Class Initialized
INFO - 2021-12-20 00:22:44 --> Output Class Initialized
INFO - 2021-12-20 00:22:44 --> Security Class Initialized
DEBUG - 2021-12-20 00:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:22:44 --> Input Class Initialized
INFO - 2021-12-20 00:22:44 --> Language Class Initialized
INFO - 2021-12-20 00:22:44 --> Loader Class Initialized
INFO - 2021-12-20 00:22:44 --> Helper loaded: url_helper
INFO - 2021-12-20 00:22:44 --> Helper loaded: form_helper
INFO - 2021-12-20 00:22:44 --> Helper loaded: common_helper
INFO - 2021-12-20 00:22:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:22:44 --> Controller Class Initialized
INFO - 2021-12-20 00:22:44 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:22:44 --> Encrypt Class Initialized
INFO - 2021-12-20 00:22:44 --> Model "Login_model" initialized
INFO - 2021-12-20 00:22:44 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 00:22:44 --> Model "Case_model" initialized
ERROR - 2021-12-20 00:22:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:22:52 --> Config Class Initialized
INFO - 2021-12-20 00:22:52 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:22:52 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:22:52 --> Utf8 Class Initialized
INFO - 2021-12-20 00:22:52 --> URI Class Initialized
INFO - 2021-12-20 00:22:52 --> Router Class Initialized
INFO - 2021-12-20 00:22:52 --> Output Class Initialized
INFO - 2021-12-20 00:22:52 --> Security Class Initialized
DEBUG - 2021-12-20 00:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:22:52 --> Input Class Initialized
INFO - 2021-12-20 00:22:52 --> Language Class Initialized
INFO - 2021-12-20 00:22:52 --> Loader Class Initialized
INFO - 2021-12-20 00:22:52 --> Helper loaded: url_helper
INFO - 2021-12-20 00:22:52 --> Helper loaded: form_helper
INFO - 2021-12-20 00:22:52 --> Helper loaded: common_helper
INFO - 2021-12-20 00:22:52 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:22:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:23:02 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 00:23:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:23:02 --> Final output sent to browser
DEBUG - 2021-12-20 00:23:02 --> Total execution time: 17.6417
INFO - 2021-12-20 00:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:23:02 --> Controller Class Initialized
INFO - 2021-12-20 00:23:02 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:23:02 --> Encrypt Class Initialized
INFO - 2021-12-20 00:23:02 --> Model "Login_model" initialized
INFO - 2021-12-20 00:23:02 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 00:23:02 --> Model "Case_model" initialized
ERROR - 2021-12-20 00:23:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:23:02 --> Config Class Initialized
INFO - 2021-12-20 00:23:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:23:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:23:02 --> Utf8 Class Initialized
INFO - 2021-12-20 00:23:02 --> URI Class Initialized
INFO - 2021-12-20 00:23:02 --> Router Class Initialized
INFO - 2021-12-20 00:23:02 --> Output Class Initialized
INFO - 2021-12-20 00:23:02 --> Security Class Initialized
DEBUG - 2021-12-20 00:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:23:02 --> Input Class Initialized
INFO - 2021-12-20 00:23:02 --> Language Class Initialized
INFO - 2021-12-20 00:23:02 --> Loader Class Initialized
INFO - 2021-12-20 00:23:02 --> Helper loaded: url_helper
INFO - 2021-12-20 00:23:02 --> Helper loaded: form_helper
INFO - 2021-12-20 00:23:02 --> Helper loaded: common_helper
INFO - 2021-12-20 00:23:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:23:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:23:18 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 00:23:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:23:18 --> Final output sent to browser
DEBUG - 2021-12-20 00:23:18 --> Total execution time: 25.8388
INFO - 2021-12-20 00:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:23:18 --> Controller Class Initialized
INFO - 2021-12-20 00:23:18 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:23:18 --> Encrypt Class Initialized
INFO - 2021-12-20 00:23:18 --> Model "Login_model" initialized
INFO - 2021-12-20 00:23:18 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 00:23:18 --> Model "Case_model" initialized
ERROR - 2021-12-20 00:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:23:23 --> Config Class Initialized
INFO - 2021-12-20 00:23:23 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:23:23 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:23:23 --> Utf8 Class Initialized
INFO - 2021-12-20 00:23:23 --> URI Class Initialized
INFO - 2021-12-20 00:23:23 --> Router Class Initialized
INFO - 2021-12-20 00:23:23 --> Output Class Initialized
INFO - 2021-12-20 00:23:23 --> Security Class Initialized
DEBUG - 2021-12-20 00:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:23:23 --> Input Class Initialized
INFO - 2021-12-20 00:23:23 --> Language Class Initialized
INFO - 2021-12-20 00:23:23 --> Loader Class Initialized
INFO - 2021-12-20 00:23:23 --> Helper loaded: url_helper
INFO - 2021-12-20 00:23:23 --> Helper loaded: form_helper
INFO - 2021-12-20 00:23:23 --> Helper loaded: common_helper
INFO - 2021-12-20 00:23:23 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:23:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:23:34 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 00:23:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:23:34 --> Final output sent to browser
DEBUG - 2021-12-20 00:23:34 --> Total execution time: 32.1242
INFO - 2021-12-20 00:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:23:34 --> Controller Class Initialized
INFO - 2021-12-20 00:23:34 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:23:34 --> Encrypt Class Initialized
INFO - 2021-12-20 00:23:34 --> Model "Login_model" initialized
INFO - 2021-12-20 00:23:34 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 00:23:34 --> Model "Case_model" initialized
INFO - 2021-12-20 00:23:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:23:51 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 00:23:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:23:52 --> Final output sent to browser
DEBUG - 2021-12-20 00:23:52 --> Total execution time: 28.9161
ERROR - 2021-12-20 00:48:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:48:01 --> Config Class Initialized
INFO - 2021-12-20 00:48:01 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:48:01 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:48:01 --> Utf8 Class Initialized
INFO - 2021-12-20 00:48:01 --> URI Class Initialized
DEBUG - 2021-12-20 00:48:01 --> No URI present. Default controller set.
INFO - 2021-12-20 00:48:01 --> Router Class Initialized
INFO - 2021-12-20 00:48:01 --> Output Class Initialized
INFO - 2021-12-20 00:48:01 --> Security Class Initialized
DEBUG - 2021-12-20 00:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:48:01 --> Input Class Initialized
INFO - 2021-12-20 00:48:01 --> Language Class Initialized
INFO - 2021-12-20 00:48:01 --> Loader Class Initialized
INFO - 2021-12-20 00:48:01 --> Helper loaded: url_helper
INFO - 2021-12-20 00:48:01 --> Helper loaded: form_helper
INFO - 2021-12-20 00:48:01 --> Helper loaded: common_helper
INFO - 2021-12-20 00:48:01 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:48:01 --> Controller Class Initialized
INFO - 2021-12-20 00:48:01 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:48:01 --> Encrypt Class Initialized
DEBUG - 2021-12-20 00:48:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 00:48:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 00:48:01 --> Email Class Initialized
INFO - 2021-12-20 00:48:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 00:48:01 --> Calendar Class Initialized
INFO - 2021-12-20 00:48:01 --> Model "Login_model" initialized
ERROR - 2021-12-20 00:48:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:48:02 --> Config Class Initialized
INFO - 2021-12-20 00:48:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:48:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:48:02 --> Utf8 Class Initialized
INFO - 2021-12-20 00:48:02 --> URI Class Initialized
INFO - 2021-12-20 00:48:02 --> Router Class Initialized
INFO - 2021-12-20 00:48:02 --> Output Class Initialized
INFO - 2021-12-20 00:48:02 --> Security Class Initialized
DEBUG - 2021-12-20 00:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:48:02 --> Input Class Initialized
INFO - 2021-12-20 00:48:02 --> Language Class Initialized
INFO - 2021-12-20 00:48:02 --> Loader Class Initialized
INFO - 2021-12-20 00:48:02 --> Helper loaded: url_helper
INFO - 2021-12-20 00:48:02 --> Helper loaded: form_helper
INFO - 2021-12-20 00:48:02 --> Helper loaded: common_helper
INFO - 2021-12-20 00:48:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:48:02 --> Controller Class Initialized
INFO - 2021-12-20 00:48:02 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:48:02 --> Encrypt Class Initialized
INFO - 2021-12-20 00:48:02 --> Model "Diseases_model" initialized
INFO - 2021-12-20 00:48:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:48:02 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2021-12-20 00:48:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:48:02 --> Final output sent to browser
DEBUG - 2021-12-20 00:48:02 --> Total execution time: 0.0809
ERROR - 2021-12-20 00:48:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:48:02 --> Config Class Initialized
INFO - 2021-12-20 00:48:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:48:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:48:02 --> Utf8 Class Initialized
INFO - 2021-12-20 00:48:02 --> URI Class Initialized
INFO - 2021-12-20 00:48:02 --> Router Class Initialized
INFO - 2021-12-20 00:48:02 --> Output Class Initialized
INFO - 2021-12-20 00:48:02 --> Security Class Initialized
DEBUG - 2021-12-20 00:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:48:02 --> Input Class Initialized
INFO - 2021-12-20 00:48:02 --> Language Class Initialized
ERROR - 2021-12-20 00:48:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 00:48:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:48:18 --> Config Class Initialized
INFO - 2021-12-20 00:48:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:48:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:48:18 --> Utf8 Class Initialized
INFO - 2021-12-20 00:48:18 --> URI Class Initialized
INFO - 2021-12-20 00:48:18 --> Router Class Initialized
INFO - 2021-12-20 00:48:18 --> Output Class Initialized
INFO - 2021-12-20 00:48:18 --> Security Class Initialized
DEBUG - 2021-12-20 00:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:48:18 --> Input Class Initialized
INFO - 2021-12-20 00:48:18 --> Language Class Initialized
INFO - 2021-12-20 00:48:18 --> Loader Class Initialized
INFO - 2021-12-20 00:48:18 --> Helper loaded: url_helper
INFO - 2021-12-20 00:48:18 --> Helper loaded: form_helper
INFO - 2021-12-20 00:48:18 --> Helper loaded: common_helper
INFO - 2021-12-20 00:48:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:48:18 --> Controller Class Initialized
INFO - 2021-12-20 00:48:18 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:48:18 --> Encrypt Class Initialized
INFO - 2021-12-20 00:48:18 --> Model "Login_model" initialized
INFO - 2021-12-20 00:48:18 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 00:48:18 --> Model "Case_model" initialized
INFO - 2021-12-20 00:48:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:48:35 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 00:48:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:48:35 --> Final output sent to browser
DEBUG - 2021-12-20 00:48:35 --> Total execution time: 16.3371
ERROR - 2021-12-20 00:48:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:48:35 --> Config Class Initialized
INFO - 2021-12-20 00:48:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:48:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:48:35 --> Utf8 Class Initialized
INFO - 2021-12-20 00:48:35 --> URI Class Initialized
INFO - 2021-12-20 00:48:35 --> Router Class Initialized
INFO - 2021-12-20 00:48:35 --> Output Class Initialized
INFO - 2021-12-20 00:48:35 --> Security Class Initialized
DEBUG - 2021-12-20 00:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:48:35 --> Input Class Initialized
INFO - 2021-12-20 00:48:35 --> Language Class Initialized
ERROR - 2021-12-20 00:48:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 00:55:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:55:53 --> Config Class Initialized
INFO - 2021-12-20 00:55:53 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:55:53 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:55:53 --> Utf8 Class Initialized
INFO - 2021-12-20 00:55:53 --> URI Class Initialized
INFO - 2021-12-20 00:55:53 --> Router Class Initialized
INFO - 2021-12-20 00:55:53 --> Output Class Initialized
INFO - 2021-12-20 00:55:53 --> Security Class Initialized
DEBUG - 2021-12-20 00:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:55:53 --> Input Class Initialized
INFO - 2021-12-20 00:55:53 --> Language Class Initialized
INFO - 2021-12-20 00:55:53 --> Loader Class Initialized
INFO - 2021-12-20 00:55:53 --> Helper loaded: url_helper
INFO - 2021-12-20 00:55:53 --> Helper loaded: form_helper
INFO - 2021-12-20 00:55:53 --> Helper loaded: common_helper
INFO - 2021-12-20 00:55:53 --> Database Driver Class Initialized
DEBUG - 2021-12-20 00:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 00:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 00:55:53 --> Controller Class Initialized
INFO - 2021-12-20 00:55:53 --> Form Validation Class Initialized
DEBUG - 2021-12-20 00:55:53 --> Encrypt Class Initialized
INFO - 2021-12-20 00:55:53 --> Model "Login_model" initialized
INFO - 2021-12-20 00:55:53 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 00:55:53 --> Model "Case_model" initialized
INFO - 2021-12-20 00:56:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 00:56:10 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 00:56:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 00:56:10 --> Final output sent to browser
DEBUG - 2021-12-20 00:56:10 --> Total execution time: 17.0398
ERROR - 2021-12-20 00:56:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 00:56:11 --> Config Class Initialized
INFO - 2021-12-20 00:56:11 --> Hooks Class Initialized
DEBUG - 2021-12-20 00:56:11 --> UTF-8 Support Enabled
INFO - 2021-12-20 00:56:11 --> Utf8 Class Initialized
INFO - 2021-12-20 00:56:11 --> URI Class Initialized
INFO - 2021-12-20 00:56:11 --> Router Class Initialized
INFO - 2021-12-20 00:56:11 --> Output Class Initialized
INFO - 2021-12-20 00:56:11 --> Security Class Initialized
DEBUG - 2021-12-20 00:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 00:56:11 --> Input Class Initialized
INFO - 2021-12-20 00:56:11 --> Language Class Initialized
ERROR - 2021-12-20 00:56:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 02:25:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:25:34 --> Config Class Initialized
INFO - 2021-12-20 02:25:34 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:25:34 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:25:34 --> Utf8 Class Initialized
INFO - 2021-12-20 02:25:34 --> URI Class Initialized
INFO - 2021-12-20 02:25:34 --> Router Class Initialized
INFO - 2021-12-20 02:25:34 --> Output Class Initialized
INFO - 2021-12-20 02:25:34 --> Security Class Initialized
DEBUG - 2021-12-20 02:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:25:34 --> Input Class Initialized
INFO - 2021-12-20 02:25:34 --> Language Class Initialized
INFO - 2021-12-20 02:25:34 --> Loader Class Initialized
INFO - 2021-12-20 02:25:34 --> Helper loaded: url_helper
INFO - 2021-12-20 02:25:34 --> Helper loaded: form_helper
INFO - 2021-12-20 02:25:34 --> Helper loaded: common_helper
INFO - 2021-12-20 02:25:34 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:25:34 --> Controller Class Initialized
INFO - 2021-12-20 02:25:34 --> Form Validation Class Initialized
INFO - 2021-12-20 02:25:34 --> Model "Case_model" initialized
INFO - 2021-12-20 02:25:34 --> Model "Hospital_model" initialized
INFO - 2021-12-20 02:25:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 02:25:34 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2021-12-20 02:25:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 02:25:34 --> Final output sent to browser
DEBUG - 2021-12-20 02:25:34 --> Total execution time: 0.0346
ERROR - 2021-12-20 02:25:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:25:35 --> Config Class Initialized
INFO - 2021-12-20 02:25:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:25:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:25:35 --> Utf8 Class Initialized
INFO - 2021-12-20 02:25:35 --> URI Class Initialized
INFO - 2021-12-20 02:25:35 --> Router Class Initialized
INFO - 2021-12-20 02:25:35 --> Output Class Initialized
INFO - 2021-12-20 02:25:35 --> Security Class Initialized
DEBUG - 2021-12-20 02:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:25:35 --> Input Class Initialized
INFO - 2021-12-20 02:25:35 --> Language Class Initialized
ERROR - 2021-12-20 02:25:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 02:27:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:27:41 --> Config Class Initialized
INFO - 2021-12-20 02:27:41 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:27:41 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:27:41 --> Utf8 Class Initialized
INFO - 2021-12-20 02:27:41 --> URI Class Initialized
INFO - 2021-12-20 02:27:41 --> Router Class Initialized
INFO - 2021-12-20 02:27:41 --> Output Class Initialized
INFO - 2021-12-20 02:27:41 --> Security Class Initialized
DEBUG - 2021-12-20 02:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:27:41 --> Input Class Initialized
INFO - 2021-12-20 02:27:41 --> Language Class Initialized
INFO - 2021-12-20 02:27:41 --> Loader Class Initialized
INFO - 2021-12-20 02:27:41 --> Helper loaded: url_helper
INFO - 2021-12-20 02:27:41 --> Helper loaded: form_helper
INFO - 2021-12-20 02:27:41 --> Helper loaded: common_helper
INFO - 2021-12-20 02:27:41 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:27:41 --> Controller Class Initialized
INFO - 2021-12-20 02:27:41 --> Form Validation Class Initialized
DEBUG - 2021-12-20 02:27:41 --> Encrypt Class Initialized
INFO - 2021-12-20 02:27:41 --> Model "Login_model" initialized
INFO - 2021-12-20 02:27:41 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 02:27:41 --> Model "Case_model" initialized
INFO - 2021-12-20 02:27:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 02:27:58 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 02:27:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 02:27:58 --> Final output sent to browser
DEBUG - 2021-12-20 02:27:58 --> Total execution time: 16.7208
ERROR - 2021-12-20 02:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:27:58 --> Config Class Initialized
INFO - 2021-12-20 02:27:58 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:27:58 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:27:58 --> Utf8 Class Initialized
INFO - 2021-12-20 02:27:58 --> URI Class Initialized
INFO - 2021-12-20 02:27:58 --> Router Class Initialized
INFO - 2021-12-20 02:27:58 --> Output Class Initialized
INFO - 2021-12-20 02:27:58 --> Security Class Initialized
DEBUG - 2021-12-20 02:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:27:58 --> Input Class Initialized
INFO - 2021-12-20 02:27:58 --> Language Class Initialized
ERROR - 2021-12-20 02:27:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 02:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:31:43 --> Config Class Initialized
INFO - 2021-12-20 02:31:43 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:31:43 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:31:43 --> Utf8 Class Initialized
INFO - 2021-12-20 02:31:43 --> URI Class Initialized
INFO - 2021-12-20 02:31:43 --> Router Class Initialized
INFO - 2021-12-20 02:31:43 --> Output Class Initialized
INFO - 2021-12-20 02:31:43 --> Security Class Initialized
DEBUG - 2021-12-20 02:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:31:43 --> Input Class Initialized
INFO - 2021-12-20 02:31:43 --> Language Class Initialized
INFO - 2021-12-20 02:31:43 --> Loader Class Initialized
INFO - 2021-12-20 02:31:43 --> Helper loaded: url_helper
INFO - 2021-12-20 02:31:43 --> Helper loaded: form_helper
INFO - 2021-12-20 02:31:43 --> Helper loaded: common_helper
INFO - 2021-12-20 02:31:43 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:31:43 --> Controller Class Initialized
INFO - 2021-12-20 02:31:43 --> Form Validation Class Initialized
DEBUG - 2021-12-20 02:31:43 --> Encrypt Class Initialized
INFO - 2021-12-20 02:31:43 --> Model "Patient_model" initialized
INFO - 2021-12-20 02:31:43 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 02:31:43 --> Model "Referredby_model" initialized
INFO - 2021-12-20 02:31:43 --> Model "Prefix_master" initialized
INFO - 2021-12-20 02:31:43 --> Model "Hospital_model" initialized
INFO - 2021-12-20 02:31:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 02:31:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-20 02:31:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 02:31:43 --> Final output sent to browser
DEBUG - 2021-12-20 02:31:43 --> Total execution time: 0.0426
ERROR - 2021-12-20 02:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:31:43 --> Config Class Initialized
INFO - 2021-12-20 02:31:43 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:31:43 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:31:43 --> Utf8 Class Initialized
INFO - 2021-12-20 02:31:43 --> URI Class Initialized
INFO - 2021-12-20 02:31:43 --> Router Class Initialized
INFO - 2021-12-20 02:31:43 --> Output Class Initialized
INFO - 2021-12-20 02:31:43 --> Security Class Initialized
DEBUG - 2021-12-20 02:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:31:43 --> Input Class Initialized
INFO - 2021-12-20 02:31:43 --> Language Class Initialized
ERROR - 2021-12-20 02:31:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 02:32:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:32:04 --> Config Class Initialized
INFO - 2021-12-20 02:32:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:32:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:32:04 --> Utf8 Class Initialized
INFO - 2021-12-20 02:32:04 --> URI Class Initialized
INFO - 2021-12-20 02:32:04 --> Router Class Initialized
INFO - 2021-12-20 02:32:04 --> Output Class Initialized
INFO - 2021-12-20 02:32:04 --> Security Class Initialized
DEBUG - 2021-12-20 02:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:32:04 --> Input Class Initialized
INFO - 2021-12-20 02:32:04 --> Language Class Initialized
INFO - 2021-12-20 02:32:04 --> Loader Class Initialized
INFO - 2021-12-20 02:32:04 --> Helper loaded: url_helper
INFO - 2021-12-20 02:32:04 --> Helper loaded: form_helper
INFO - 2021-12-20 02:32:04 --> Helper loaded: common_helper
INFO - 2021-12-20 02:32:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:32:04 --> Controller Class Initialized
INFO - 2021-12-20 02:32:04 --> Form Validation Class Initialized
DEBUG - 2021-12-20 02:32:04 --> Encrypt Class Initialized
INFO - 2021-12-20 02:32:04 --> Model "Login_model" initialized
INFO - 2021-12-20 02:32:04 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 02:32:04 --> Model "Case_model" initialized
INFO - 2021-12-20 02:32:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 02:32:20 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 02:32:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 02:32:20 --> Final output sent to browser
DEBUG - 2021-12-20 02:32:20 --> Total execution time: 16.2903
ERROR - 2021-12-20 02:32:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:32:21 --> Config Class Initialized
INFO - 2021-12-20 02:32:21 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:32:21 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:32:21 --> Utf8 Class Initialized
INFO - 2021-12-20 02:32:21 --> URI Class Initialized
INFO - 2021-12-20 02:32:21 --> Router Class Initialized
INFO - 2021-12-20 02:32:21 --> Output Class Initialized
INFO - 2021-12-20 02:32:21 --> Security Class Initialized
DEBUG - 2021-12-20 02:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:32:21 --> Input Class Initialized
INFO - 2021-12-20 02:32:21 --> Language Class Initialized
ERROR - 2021-12-20 02:32:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 02:35:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:35:20 --> Config Class Initialized
INFO - 2021-12-20 02:35:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:35:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:35:20 --> Utf8 Class Initialized
INFO - 2021-12-20 02:35:20 --> URI Class Initialized
INFO - 2021-12-20 02:35:20 --> Router Class Initialized
INFO - 2021-12-20 02:35:20 --> Output Class Initialized
INFO - 2021-12-20 02:35:20 --> Security Class Initialized
DEBUG - 2021-12-20 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:35:20 --> Input Class Initialized
INFO - 2021-12-20 02:35:20 --> Language Class Initialized
INFO - 2021-12-20 02:35:20 --> Loader Class Initialized
INFO - 2021-12-20 02:35:20 --> Helper loaded: url_helper
INFO - 2021-12-20 02:35:20 --> Helper loaded: form_helper
INFO - 2021-12-20 02:35:20 --> Helper loaded: common_helper
INFO - 2021-12-20 02:35:20 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:35:20 --> Controller Class Initialized
INFO - 2021-12-20 02:35:20 --> Form Validation Class Initialized
DEBUG - 2021-12-20 02:35:20 --> Encrypt Class Initialized
INFO - 2021-12-20 02:35:20 --> Model "Payment_model" initialized
INFO - 2021-12-20 02:35:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 02:35:20 --> File loaded: /home3/karoteam/public_html/application/views/payment/index.php
INFO - 2021-12-20 02:35:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 02:35:20 --> Final output sent to browser
DEBUG - 2021-12-20 02:35:20 --> Total execution time: 0.0291
ERROR - 2021-12-20 02:35:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:35:20 --> Config Class Initialized
INFO - 2021-12-20 02:35:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:35:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:35:20 --> Utf8 Class Initialized
INFO - 2021-12-20 02:35:20 --> URI Class Initialized
INFO - 2021-12-20 02:35:20 --> Router Class Initialized
INFO - 2021-12-20 02:35:20 --> Output Class Initialized
INFO - 2021-12-20 02:35:20 --> Security Class Initialized
DEBUG - 2021-12-20 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:35:20 --> Input Class Initialized
INFO - 2021-12-20 02:35:20 --> Language Class Initialized
ERROR - 2021-12-20 02:35:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 02:35:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:35:24 --> Config Class Initialized
INFO - 2021-12-20 02:35:24 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:35:24 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:35:24 --> Utf8 Class Initialized
INFO - 2021-12-20 02:35:24 --> URI Class Initialized
INFO - 2021-12-20 02:35:24 --> Router Class Initialized
INFO - 2021-12-20 02:35:24 --> Output Class Initialized
INFO - 2021-12-20 02:35:24 --> Security Class Initialized
DEBUG - 2021-12-20 02:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:35:24 --> Input Class Initialized
INFO - 2021-12-20 02:35:24 --> Language Class Initialized
INFO - 2021-12-20 02:35:24 --> Loader Class Initialized
INFO - 2021-12-20 02:35:24 --> Helper loaded: url_helper
INFO - 2021-12-20 02:35:24 --> Helper loaded: form_helper
INFO - 2021-12-20 02:35:24 --> Helper loaded: common_helper
INFO - 2021-12-20 02:35:24 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:35:24 --> Controller Class Initialized
INFO - 2021-12-20 02:35:24 --> Form Validation Class Initialized
DEBUG - 2021-12-20 02:35:24 --> Encrypt Class Initialized
INFO - 2021-12-20 02:35:24 --> Model "Login_model" initialized
INFO - 2021-12-20 02:35:24 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 02:35:24 --> Model "Case_model" initialized
INFO - 2021-12-20 02:35:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-20 02:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:35:39 --> Config Class Initialized
INFO - 2021-12-20 02:35:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:35:39 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:35:39 --> Utf8 Class Initialized
INFO - 2021-12-20 02:35:39 --> URI Class Initialized
INFO - 2021-12-20 02:35:39 --> Router Class Initialized
INFO - 2021-12-20 02:35:39 --> Output Class Initialized
INFO - 2021-12-20 02:35:39 --> Security Class Initialized
DEBUG - 2021-12-20 02:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:35:39 --> Input Class Initialized
INFO - 2021-12-20 02:35:39 --> Language Class Initialized
INFO - 2021-12-20 02:35:39 --> Loader Class Initialized
INFO - 2021-12-20 02:35:39 --> Helper loaded: url_helper
INFO - 2021-12-20 02:35:39 --> Helper loaded: form_helper
INFO - 2021-12-20 02:35:39 --> Helper loaded: common_helper
INFO - 2021-12-20 02:35:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:35:41 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 02:35:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 02:35:41 --> Final output sent to browser
DEBUG - 2021-12-20 02:35:41 --> Total execution time: 17.1003
INFO - 2021-12-20 02:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:35:41 --> Controller Class Initialized
INFO - 2021-12-20 02:35:41 --> Form Validation Class Initialized
DEBUG - 2021-12-20 02:35:41 --> Encrypt Class Initialized
INFO - 2021-12-20 02:35:41 --> Model "Patient_model" initialized
INFO - 2021-12-20 02:35:41 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 02:35:41 --> Model "Referredby_model" initialized
INFO - 2021-12-20 02:35:41 --> Model "Prefix_master" initialized
INFO - 2021-12-20 02:35:41 --> Model "Hospital_model" initialized
INFO - 2021-12-20 02:35:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 02:35:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-20 02:35:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-20 02:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:35:47 --> Config Class Initialized
INFO - 2021-12-20 02:35:47 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:35:47 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:35:47 --> Utf8 Class Initialized
INFO - 2021-12-20 02:35:47 --> URI Class Initialized
INFO - 2021-12-20 02:35:47 --> Router Class Initialized
INFO - 2021-12-20 02:35:47 --> Output Class Initialized
INFO - 2021-12-20 02:35:47 --> Security Class Initialized
DEBUG - 2021-12-20 02:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:35:47 --> Input Class Initialized
INFO - 2021-12-20 02:35:47 --> Language Class Initialized
ERROR - 2021-12-20 02:35:47 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-20 02:35:48 --> Final output sent to browser
DEBUG - 2021-12-20 02:35:48 --> Total execution time: 6.9836
ERROR - 2021-12-20 02:36:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:36:15 --> Config Class Initialized
INFO - 2021-12-20 02:36:15 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:36:15 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:36:15 --> Utf8 Class Initialized
INFO - 2021-12-20 02:36:15 --> URI Class Initialized
INFO - 2021-12-20 02:36:15 --> Router Class Initialized
INFO - 2021-12-20 02:36:15 --> Output Class Initialized
INFO - 2021-12-20 02:36:15 --> Security Class Initialized
DEBUG - 2021-12-20 02:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:36:15 --> Input Class Initialized
INFO - 2021-12-20 02:36:15 --> Language Class Initialized
INFO - 2021-12-20 02:36:15 --> Loader Class Initialized
INFO - 2021-12-20 02:36:15 --> Helper loaded: url_helper
INFO - 2021-12-20 02:36:15 --> Helper loaded: form_helper
INFO - 2021-12-20 02:36:15 --> Helper loaded: common_helper
INFO - 2021-12-20 02:36:15 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:36:15 --> Controller Class Initialized
INFO - 2021-12-20 02:36:15 --> Form Validation Class Initialized
INFO - 2021-12-20 02:36:15 --> Model "Case_model" initialized
INFO - 2021-12-20 02:36:15 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 02:36:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 02:36:19 --> Model "Case_model" initialized
ERROR - 2021-12-20 02:36:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:36:24 --> Config Class Initialized
INFO - 2021-12-20 02:36:24 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:36:24 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:36:24 --> Utf8 Class Initialized
INFO - 2021-12-20 02:36:24 --> URI Class Initialized
INFO - 2021-12-20 02:36:24 --> Router Class Initialized
INFO - 2021-12-20 02:36:24 --> Output Class Initialized
INFO - 2021-12-20 02:36:24 --> Security Class Initialized
DEBUG - 2021-12-20 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:36:24 --> Input Class Initialized
INFO - 2021-12-20 02:36:24 --> Language Class Initialized
INFO - 2021-12-20 02:36:24 --> Loader Class Initialized
INFO - 2021-12-20 02:36:24 --> Helper loaded: url_helper
INFO - 2021-12-20 02:36:24 --> Helper loaded: form_helper
INFO - 2021-12-20 02:36:24 --> Helper loaded: common_helper
INFO - 2021-12-20 02:36:24 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:36:24 --> File loaded: /home3/karoteam/public_html/application/views/cases/all_case.php
INFO - 2021-12-20 02:36:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 02:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:36:24 --> Controller Class Initialized
INFO - 2021-12-20 02:36:24 --> Form Validation Class Initialized
INFO - 2021-12-20 02:36:24 --> Model "Case_model" initialized
INFO - 2021-12-20 02:36:24 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 02:36:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 02:36:24 --> Model "Case_model" initialized
INFO - 2021-12-20 02:36:24 --> File loaded: /home3/karoteam/public_html/application/views/cases/hold_case.php
INFO - 2021-12-20 02:36:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 02:36:24 --> Final output sent to browser
DEBUG - 2021-12-20 02:36:24 --> Total execution time: 0.2241
ERROR - 2021-12-20 02:36:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:36:25 --> Config Class Initialized
INFO - 2021-12-20 02:36:25 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:36:25 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:36:25 --> Utf8 Class Initialized
INFO - 2021-12-20 02:36:25 --> URI Class Initialized
INFO - 2021-12-20 02:36:25 --> Router Class Initialized
INFO - 2021-12-20 02:36:25 --> Output Class Initialized
INFO - 2021-12-20 02:36:25 --> Security Class Initialized
DEBUG - 2021-12-20 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:36:25 --> Input Class Initialized
INFO - 2021-12-20 02:36:25 --> Language Class Initialized
ERROR - 2021-12-20 02:36:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 02:36:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:36:36 --> Config Class Initialized
INFO - 2021-12-20 02:36:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:36:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:36:36 --> Utf8 Class Initialized
INFO - 2021-12-20 02:36:36 --> URI Class Initialized
INFO - 2021-12-20 02:36:36 --> Router Class Initialized
INFO - 2021-12-20 02:36:36 --> Output Class Initialized
INFO - 2021-12-20 02:36:36 --> Security Class Initialized
DEBUG - 2021-12-20 02:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:36:36 --> Input Class Initialized
INFO - 2021-12-20 02:36:36 --> Language Class Initialized
INFO - 2021-12-20 02:36:36 --> Loader Class Initialized
INFO - 2021-12-20 02:36:36 --> Helper loaded: url_helper
INFO - 2021-12-20 02:36:36 --> Helper loaded: form_helper
INFO - 2021-12-20 02:36:36 --> Helper loaded: common_helper
INFO - 2021-12-20 02:36:36 --> Database Driver Class Initialized
DEBUG - 2021-12-20 02:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 02:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 02:36:36 --> Controller Class Initialized
INFO - 2021-12-20 02:36:36 --> Form Validation Class Initialized
INFO - 2021-12-20 02:36:36 --> Model "Case_model" initialized
INFO - 2021-12-20 02:36:36 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 02:36:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 02:36:39 --> Model "Case_model" initialized
INFO - 2021-12-20 02:36:41 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2021-12-20 02:36:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 02:36:42 --> Final output sent to browser
DEBUG - 2021-12-20 02:36:42 --> Total execution time: 5.0248
ERROR - 2021-12-20 02:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 02:36:43 --> Config Class Initialized
INFO - 2021-12-20 02:36:43 --> Hooks Class Initialized
DEBUG - 2021-12-20 02:36:43 --> UTF-8 Support Enabled
INFO - 2021-12-20 02:36:43 --> Utf8 Class Initialized
INFO - 2021-12-20 02:36:43 --> URI Class Initialized
INFO - 2021-12-20 02:36:43 --> Router Class Initialized
INFO - 2021-12-20 02:36:43 --> Output Class Initialized
INFO - 2021-12-20 02:36:43 --> Security Class Initialized
DEBUG - 2021-12-20 02:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 02:36:43 --> Input Class Initialized
INFO - 2021-12-20 02:36:43 --> Language Class Initialized
ERROR - 2021-12-20 02:36:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 04:51:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 04:51:35 --> Config Class Initialized
INFO - 2021-12-20 04:51:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:51:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:51:35 --> Utf8 Class Initialized
INFO - 2021-12-20 04:51:35 --> URI Class Initialized
INFO - 2021-12-20 04:51:35 --> Router Class Initialized
INFO - 2021-12-20 04:51:35 --> Output Class Initialized
INFO - 2021-12-20 04:51:35 --> Security Class Initialized
DEBUG - 2021-12-20 04:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:51:35 --> Input Class Initialized
INFO - 2021-12-20 04:51:35 --> Language Class Initialized
INFO - 2021-12-20 04:51:35 --> Loader Class Initialized
INFO - 2021-12-20 04:51:35 --> Helper loaded: url_helper
INFO - 2021-12-20 04:51:35 --> Helper loaded: form_helper
INFO - 2021-12-20 04:51:35 --> Helper loaded: common_helper
INFO - 2021-12-20 04:51:35 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:51:35 --> Controller Class Initialized
ERROR - 2021-12-20 04:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 04:51:36 --> Config Class Initialized
INFO - 2021-12-20 04:51:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:51:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:51:36 --> Utf8 Class Initialized
INFO - 2021-12-20 04:51:36 --> URI Class Initialized
INFO - 2021-12-20 04:51:36 --> Router Class Initialized
INFO - 2021-12-20 04:51:36 --> Output Class Initialized
INFO - 2021-12-20 04:51:36 --> Security Class Initialized
DEBUG - 2021-12-20 04:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:51:36 --> Input Class Initialized
INFO - 2021-12-20 04:51:36 --> Language Class Initialized
INFO - 2021-12-20 04:51:36 --> Loader Class Initialized
INFO - 2021-12-20 04:51:36 --> Helper loaded: url_helper
INFO - 2021-12-20 04:51:36 --> Helper loaded: form_helper
INFO - 2021-12-20 04:51:36 --> Helper loaded: common_helper
INFO - 2021-12-20 04:51:36 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:51:36 --> Controller Class Initialized
INFO - 2021-12-20 04:51:36 --> Form Validation Class Initialized
DEBUG - 2021-12-20 04:51:36 --> Encrypt Class Initialized
DEBUG - 2021-12-20 04:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 04:51:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 04:51:36 --> Email Class Initialized
INFO - 2021-12-20 04:51:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 04:51:36 --> Calendar Class Initialized
INFO - 2021-12-20 04:51:36 --> Model "Login_model" initialized
INFO - 2021-12-20 04:51:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 04:51:36 --> Final output sent to browser
DEBUG - 2021-12-20 04:51:36 --> Total execution time: 0.0222
ERROR - 2021-12-20 06:02:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:02:33 --> Config Class Initialized
INFO - 2021-12-20 06:02:33 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:02:33 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:02:33 --> Utf8 Class Initialized
INFO - 2021-12-20 06:02:33 --> URI Class Initialized
DEBUG - 2021-12-20 06:02:33 --> No URI present. Default controller set.
INFO - 2021-12-20 06:02:33 --> Router Class Initialized
INFO - 2021-12-20 06:02:33 --> Output Class Initialized
INFO - 2021-12-20 06:02:33 --> Security Class Initialized
DEBUG - 2021-12-20 06:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:02:33 --> Input Class Initialized
INFO - 2021-12-20 06:02:33 --> Language Class Initialized
INFO - 2021-12-20 06:02:33 --> Loader Class Initialized
INFO - 2021-12-20 06:02:33 --> Helper loaded: url_helper
INFO - 2021-12-20 06:02:33 --> Helper loaded: form_helper
INFO - 2021-12-20 06:02:33 --> Helper loaded: common_helper
INFO - 2021-12-20 06:02:33 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:02:33 --> Controller Class Initialized
INFO - 2021-12-20 06:02:33 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:02:33 --> Encrypt Class Initialized
DEBUG - 2021-12-20 06:02:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 06:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 06:02:33 --> Email Class Initialized
INFO - 2021-12-20 06:02:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 06:02:33 --> Calendar Class Initialized
INFO - 2021-12-20 06:02:33 --> Model "Login_model" initialized
INFO - 2021-12-20 06:02:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 06:02:33 --> Final output sent to browser
DEBUG - 2021-12-20 06:02:33 --> Total execution time: 0.0388
ERROR - 2021-12-20 06:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:02:39 --> Config Class Initialized
INFO - 2021-12-20 06:02:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:02:39 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:02:39 --> Utf8 Class Initialized
INFO - 2021-12-20 06:02:39 --> URI Class Initialized
INFO - 2021-12-20 06:02:39 --> Router Class Initialized
INFO - 2021-12-20 06:02:39 --> Output Class Initialized
INFO - 2021-12-20 06:02:39 --> Security Class Initialized
DEBUG - 2021-12-20 06:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:02:39 --> Input Class Initialized
INFO - 2021-12-20 06:02:39 --> Language Class Initialized
INFO - 2021-12-20 06:02:39 --> Loader Class Initialized
INFO - 2021-12-20 06:02:39 --> Helper loaded: url_helper
INFO - 2021-12-20 06:02:39 --> Helper loaded: form_helper
INFO - 2021-12-20 06:02:39 --> Helper loaded: common_helper
INFO - 2021-12-20 06:02:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:02:39 --> Controller Class Initialized
INFO - 2021-12-20 06:02:39 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:02:39 --> Encrypt Class Initialized
DEBUG - 2021-12-20 06:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 06:02:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 06:02:39 --> Email Class Initialized
INFO - 2021-12-20 06:02:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 06:02:39 --> Calendar Class Initialized
INFO - 2021-12-20 06:02:39 --> Model "Login_model" initialized
INFO - 2021-12-20 06:02:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-20 06:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:02:39 --> Config Class Initialized
INFO - 2021-12-20 06:02:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:02:39 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:02:39 --> Utf8 Class Initialized
INFO - 2021-12-20 06:02:39 --> URI Class Initialized
INFO - 2021-12-20 06:02:39 --> Router Class Initialized
INFO - 2021-12-20 06:02:39 --> Output Class Initialized
INFO - 2021-12-20 06:02:39 --> Security Class Initialized
DEBUG - 2021-12-20 06:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:02:39 --> Input Class Initialized
INFO - 2021-12-20 06:02:39 --> Language Class Initialized
INFO - 2021-12-20 06:02:39 --> Loader Class Initialized
INFO - 2021-12-20 06:02:39 --> Helper loaded: url_helper
INFO - 2021-12-20 06:02:39 --> Helper loaded: form_helper
INFO - 2021-12-20 06:02:39 --> Helper loaded: common_helper
INFO - 2021-12-20 06:02:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:02:39 --> Controller Class Initialized
INFO - 2021-12-20 06:02:39 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:02:39 --> Encrypt Class Initialized
INFO - 2021-12-20 06:02:39 --> Model "Login_model" initialized
INFO - 2021-12-20 06:02:39 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 06:02:39 --> Model "Case_model" initialized
INFO - 2021-12-20 06:02:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2021-12-20 06:02:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:02:59 --> Config Class Initialized
INFO - 2021-12-20 06:02:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:02:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:02:59 --> Utf8 Class Initialized
INFO - 2021-12-20 06:02:59 --> URI Class Initialized
INFO - 2021-12-20 06:02:59 --> Router Class Initialized
INFO - 2021-12-20 06:02:59 --> Output Class Initialized
INFO - 2021-12-20 06:02:59 --> Security Class Initialized
DEBUG - 2021-12-20 06:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:02:59 --> Input Class Initialized
INFO - 2021-12-20 06:02:59 --> Language Class Initialized
INFO - 2021-12-20 06:02:59 --> Loader Class Initialized
INFO - 2021-12-20 06:02:59 --> Helper loaded: url_helper
INFO - 2021-12-20 06:02:59 --> Helper loaded: form_helper
INFO - 2021-12-20 06:02:59 --> Helper loaded: common_helper
INFO - 2021-12-20 06:02:59 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:03:03 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 06:03:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 06:03:03 --> Final output sent to browser
DEBUG - 2021-12-20 06:03:03 --> Total execution time: 23.9959
INFO - 2021-12-20 06:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:03:03 --> Controller Class Initialized
INFO - 2021-12-20 06:03:03 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:03:03 --> Encrypt Class Initialized
DEBUG - 2021-12-20 06:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 06:03:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 06:03:03 --> Email Class Initialized
INFO - 2021-12-20 06:03:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 06:03:03 --> Calendar Class Initialized
INFO - 2021-12-20 06:03:03 --> Model "Login_model" initialized
INFO - 2021-12-20 06:03:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-20 06:03:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:03:04 --> Config Class Initialized
INFO - 2021-12-20 06:03:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:03:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:03:04 --> Utf8 Class Initialized
INFO - 2021-12-20 06:03:04 --> URI Class Initialized
INFO - 2021-12-20 06:03:04 --> Router Class Initialized
INFO - 2021-12-20 06:03:04 --> Output Class Initialized
INFO - 2021-12-20 06:03:04 --> Security Class Initialized
DEBUG - 2021-12-20 06:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:03:04 --> Input Class Initialized
INFO - 2021-12-20 06:03:04 --> Language Class Initialized
INFO - 2021-12-20 06:03:04 --> Loader Class Initialized
INFO - 2021-12-20 06:03:04 --> Helper loaded: url_helper
INFO - 2021-12-20 06:03:04 --> Helper loaded: form_helper
INFO - 2021-12-20 06:03:04 --> Helper loaded: common_helper
INFO - 2021-12-20 06:03:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:03:04 --> Controller Class Initialized
INFO - 2021-12-20 06:03:04 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:03:04 --> Encrypt Class Initialized
INFO - 2021-12-20 06:03:04 --> Model "Login_model" initialized
INFO - 2021-12-20 06:03:04 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 06:03:04 --> Model "Case_model" initialized
INFO - 2021-12-20 06:03:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 06:03:30 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 06:03:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 06:03:30 --> Final output sent to browser
DEBUG - 2021-12-20 06:03:30 --> Total execution time: 25.7938
ERROR - 2021-12-20 06:03:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:03:31 --> Config Class Initialized
INFO - 2021-12-20 06:03:31 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:03:31 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:03:31 --> Utf8 Class Initialized
INFO - 2021-12-20 06:03:31 --> URI Class Initialized
INFO - 2021-12-20 06:03:31 --> Router Class Initialized
INFO - 2021-12-20 06:03:31 --> Output Class Initialized
INFO - 2021-12-20 06:03:31 --> Security Class Initialized
DEBUG - 2021-12-20 06:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:03:31 --> Input Class Initialized
INFO - 2021-12-20 06:03:31 --> Language Class Initialized
ERROR - 2021-12-20 06:03:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 06:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:05:38 --> Config Class Initialized
INFO - 2021-12-20 06:05:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:05:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:05:38 --> Utf8 Class Initialized
INFO - 2021-12-20 06:05:38 --> URI Class Initialized
INFO - 2021-12-20 06:05:38 --> Router Class Initialized
INFO - 2021-12-20 06:05:38 --> Output Class Initialized
INFO - 2021-12-20 06:05:38 --> Security Class Initialized
DEBUG - 2021-12-20 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:05:38 --> Input Class Initialized
INFO - 2021-12-20 06:05:38 --> Language Class Initialized
INFO - 2021-12-20 06:05:38 --> Loader Class Initialized
INFO - 2021-12-20 06:05:38 --> Helper loaded: url_helper
INFO - 2021-12-20 06:05:38 --> Helper loaded: form_helper
INFO - 2021-12-20 06:05:38 --> Helper loaded: common_helper
INFO - 2021-12-20 06:05:38 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:05:38 --> Controller Class Initialized
INFO - 2021-12-20 06:05:38 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:05:38 --> Encrypt Class Initialized
INFO - 2021-12-20 06:05:38 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:05:38 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:05:38 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:05:38 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:05:38 --> Model "Hospital_model" initialized
INFO - 2021-12-20 06:05:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 06:05:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-20 06:05:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 06:05:38 --> Final output sent to browser
DEBUG - 2021-12-20 06:05:38 --> Total execution time: 0.1480
ERROR - 2021-12-20 06:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:05:39 --> Config Class Initialized
INFO - 2021-12-20 06:05:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:05:39 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:05:39 --> Utf8 Class Initialized
INFO - 2021-12-20 06:05:39 --> URI Class Initialized
INFO - 2021-12-20 06:05:39 --> Router Class Initialized
INFO - 2021-12-20 06:05:39 --> Output Class Initialized
INFO - 2021-12-20 06:05:39 --> Security Class Initialized
DEBUG - 2021-12-20 06:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:05:39 --> Input Class Initialized
INFO - 2021-12-20 06:05:39 --> Language Class Initialized
ERROR - 2021-12-20 06:05:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 06:06:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:06:00 --> Config Class Initialized
INFO - 2021-12-20 06:06:00 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:06:00 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:06:00 --> Utf8 Class Initialized
INFO - 2021-12-20 06:06:00 --> URI Class Initialized
INFO - 2021-12-20 06:06:00 --> Router Class Initialized
INFO - 2021-12-20 06:06:00 --> Output Class Initialized
INFO - 2021-12-20 06:06:00 --> Security Class Initialized
DEBUG - 2021-12-20 06:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:06:00 --> Input Class Initialized
INFO - 2021-12-20 06:06:00 --> Language Class Initialized
INFO - 2021-12-20 06:06:00 --> Loader Class Initialized
INFO - 2021-12-20 06:06:00 --> Helper loaded: url_helper
INFO - 2021-12-20 06:06:00 --> Helper loaded: form_helper
INFO - 2021-12-20 06:06:00 --> Helper loaded: common_helper
INFO - 2021-12-20 06:06:00 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:06:00 --> Controller Class Initialized
INFO - 2021-12-20 06:06:00 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:06:00 --> Encrypt Class Initialized
INFO - 2021-12-20 06:06:00 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:06:00 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:06:00 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:06:00 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:06:00 --> Model "Hospital_model" initialized
INFO - 2021-12-20 06:06:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 06:06:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2021-12-20 06:06:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2021-12-20 06:06:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:06:08 --> Config Class Initialized
INFO - 2021-12-20 06:06:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:06:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:06:08 --> Utf8 Class Initialized
INFO - 2021-12-20 06:06:08 --> URI Class Initialized
INFO - 2021-12-20 06:06:08 --> Router Class Initialized
INFO - 2021-12-20 06:06:08 --> Output Class Initialized
INFO - 2021-12-20 06:06:08 --> Security Class Initialized
DEBUG - 2021-12-20 06:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:06:08 --> Input Class Initialized
INFO - 2021-12-20 06:06:08 --> Language Class Initialized
ERROR - 2021-12-20 06:06:08 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-12-20 06:06:09 --> Final output sent to browser
DEBUG - 2021-12-20 06:06:09 --> Total execution time: 6.8403
ERROR - 2021-12-20 06:22:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:22:13 --> Config Class Initialized
INFO - 2021-12-20 06:22:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:22:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:22:13 --> Utf8 Class Initialized
INFO - 2021-12-20 06:22:13 --> URI Class Initialized
DEBUG - 2021-12-20 06:22:13 --> No URI present. Default controller set.
INFO - 2021-12-20 06:22:13 --> Router Class Initialized
INFO - 2021-12-20 06:22:13 --> Output Class Initialized
INFO - 2021-12-20 06:22:13 --> Security Class Initialized
DEBUG - 2021-12-20 06:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:22:13 --> Input Class Initialized
INFO - 2021-12-20 06:22:13 --> Language Class Initialized
INFO - 2021-12-20 06:22:13 --> Loader Class Initialized
INFO - 2021-12-20 06:22:13 --> Helper loaded: url_helper
INFO - 2021-12-20 06:22:13 --> Helper loaded: form_helper
INFO - 2021-12-20 06:22:13 --> Helper loaded: common_helper
INFO - 2021-12-20 06:22:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:22:13 --> Controller Class Initialized
INFO - 2021-12-20 06:22:13 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:22:13 --> Encrypt Class Initialized
DEBUG - 2021-12-20 06:22:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 06:22:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 06:22:13 --> Email Class Initialized
INFO - 2021-12-20 06:22:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 06:22:13 --> Calendar Class Initialized
INFO - 2021-12-20 06:22:13 --> Model "Login_model" initialized
INFO - 2021-12-20 06:22:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 06:22:13 --> Final output sent to browser
DEBUG - 2021-12-20 06:22:13 --> Total execution time: 0.0377
ERROR - 2021-12-20 06:27:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:27:30 --> Config Class Initialized
INFO - 2021-12-20 06:27:30 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:27:30 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:27:30 --> Utf8 Class Initialized
INFO - 2021-12-20 06:27:30 --> URI Class Initialized
DEBUG - 2021-12-20 06:27:30 --> No URI present. Default controller set.
INFO - 2021-12-20 06:27:30 --> Router Class Initialized
INFO - 2021-12-20 06:27:30 --> Output Class Initialized
INFO - 2021-12-20 06:27:30 --> Security Class Initialized
DEBUG - 2021-12-20 06:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:27:30 --> Input Class Initialized
INFO - 2021-12-20 06:27:30 --> Language Class Initialized
INFO - 2021-12-20 06:27:30 --> Loader Class Initialized
INFO - 2021-12-20 06:27:30 --> Helper loaded: url_helper
INFO - 2021-12-20 06:27:30 --> Helper loaded: form_helper
INFO - 2021-12-20 06:27:30 --> Helper loaded: common_helper
INFO - 2021-12-20 06:27:30 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:27:31 --> Controller Class Initialized
INFO - 2021-12-20 06:27:31 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:27:31 --> Encrypt Class Initialized
DEBUG - 2021-12-20 06:27:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 06:27:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 06:27:31 --> Email Class Initialized
INFO - 2021-12-20 06:27:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 06:27:31 --> Calendar Class Initialized
INFO - 2021-12-20 06:27:31 --> Model "Login_model" initialized
INFO - 2021-12-20 06:27:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 06:27:31 --> Final output sent to browser
DEBUG - 2021-12-20 06:27:31 --> Total execution time: 0.0245
ERROR - 2021-12-20 06:29:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:29:40 --> Config Class Initialized
INFO - 2021-12-20 06:29:40 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:29:40 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:29:40 --> Utf8 Class Initialized
INFO - 2021-12-20 06:29:40 --> URI Class Initialized
INFO - 2021-12-20 06:29:40 --> Router Class Initialized
INFO - 2021-12-20 06:29:40 --> Output Class Initialized
INFO - 2021-12-20 06:29:40 --> Security Class Initialized
DEBUG - 2021-12-20 06:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:29:40 --> Input Class Initialized
INFO - 2021-12-20 06:29:40 --> Language Class Initialized
INFO - 2021-12-20 06:29:40 --> Loader Class Initialized
INFO - 2021-12-20 06:29:40 --> Helper loaded: url_helper
INFO - 2021-12-20 06:29:40 --> Helper loaded: form_helper
INFO - 2021-12-20 06:29:40 --> Helper loaded: common_helper
INFO - 2021-12-20 06:29:40 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:29:40 --> Controller Class Initialized
INFO - 2021-12-20 06:29:40 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:29:40 --> Encrypt Class Initialized
INFO - 2021-12-20 06:29:40 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:29:40 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:29:40 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:29:40 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:29:40 --> Model "Hospital_model" initialized
INFO - 2021-12-20 06:29:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 06:29:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-20 06:29:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 06:29:40 --> Final output sent to browser
DEBUG - 2021-12-20 06:29:40 --> Total execution time: 0.0432
ERROR - 2021-12-20 06:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:29:41 --> Config Class Initialized
INFO - 2021-12-20 06:29:41 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:29:41 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:29:41 --> Utf8 Class Initialized
INFO - 2021-12-20 06:29:41 --> URI Class Initialized
INFO - 2021-12-20 06:29:41 --> Router Class Initialized
INFO - 2021-12-20 06:29:41 --> Output Class Initialized
INFO - 2021-12-20 06:29:41 --> Security Class Initialized
DEBUG - 2021-12-20 06:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:29:41 --> Input Class Initialized
INFO - 2021-12-20 06:29:41 --> Language Class Initialized
ERROR - 2021-12-20 06:29:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 06:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:31:26 --> Config Class Initialized
INFO - 2021-12-20 06:31:26 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:31:26 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:31:26 --> Utf8 Class Initialized
INFO - 2021-12-20 06:31:26 --> URI Class Initialized
INFO - 2021-12-20 06:31:26 --> Router Class Initialized
INFO - 2021-12-20 06:31:26 --> Output Class Initialized
INFO - 2021-12-20 06:31:26 --> Security Class Initialized
DEBUG - 2021-12-20 06:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:31:26 --> Input Class Initialized
INFO - 2021-12-20 06:31:26 --> Language Class Initialized
INFO - 2021-12-20 06:31:26 --> Loader Class Initialized
INFO - 2021-12-20 06:31:26 --> Helper loaded: url_helper
INFO - 2021-12-20 06:31:26 --> Helper loaded: form_helper
INFO - 2021-12-20 06:31:26 --> Helper loaded: common_helper
INFO - 2021-12-20 06:31:27 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:31:27 --> Controller Class Initialized
INFO - 2021-12-20 06:31:27 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:31:27 --> Final output sent to browser
DEBUG - 2021-12-20 06:31:27 --> Total execution time: 0.0203
ERROR - 2021-12-20 06:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:31:43 --> Config Class Initialized
INFO - 2021-12-20 06:31:43 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:31:43 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:31:43 --> Utf8 Class Initialized
INFO - 2021-12-20 06:31:43 --> URI Class Initialized
INFO - 2021-12-20 06:31:43 --> Router Class Initialized
INFO - 2021-12-20 06:31:43 --> Output Class Initialized
INFO - 2021-12-20 06:31:43 --> Security Class Initialized
DEBUG - 2021-12-20 06:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:31:43 --> Input Class Initialized
INFO - 2021-12-20 06:31:43 --> Language Class Initialized
INFO - 2021-12-20 06:31:43 --> Loader Class Initialized
INFO - 2021-12-20 06:31:43 --> Helper loaded: url_helper
INFO - 2021-12-20 06:31:43 --> Helper loaded: form_helper
INFO - 2021-12-20 06:31:43 --> Helper loaded: common_helper
INFO - 2021-12-20 06:31:43 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:31:43 --> Controller Class Initialized
INFO - 2021-12-20 06:31:43 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:31:43 --> Final output sent to browser
DEBUG - 2021-12-20 06:31:43 --> Total execution time: 0.0210
ERROR - 2021-12-20 06:31:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:31:59 --> Config Class Initialized
INFO - 2021-12-20 06:31:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:31:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:31:59 --> Utf8 Class Initialized
INFO - 2021-12-20 06:31:59 --> URI Class Initialized
INFO - 2021-12-20 06:31:59 --> Router Class Initialized
INFO - 2021-12-20 06:31:59 --> Output Class Initialized
INFO - 2021-12-20 06:31:59 --> Security Class Initialized
DEBUG - 2021-12-20 06:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:31:59 --> Input Class Initialized
INFO - 2021-12-20 06:31:59 --> Language Class Initialized
INFO - 2021-12-20 06:31:59 --> Loader Class Initialized
INFO - 2021-12-20 06:31:59 --> Helper loaded: url_helper
INFO - 2021-12-20 06:31:59 --> Helper loaded: form_helper
INFO - 2021-12-20 06:31:59 --> Helper loaded: common_helper
INFO - 2021-12-20 06:31:59 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:31:59 --> Controller Class Initialized
INFO - 2021-12-20 06:31:59 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:31:59 --> Encrypt Class Initialized
INFO - 2021-12-20 06:31:59 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:31:59 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:31:59 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:31:59 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:31:59 --> Model "Hospital_model" initialized
INFO - 2021-12-20 06:32:00 --> Final output sent to browser
DEBUG - 2021-12-20 06:32:00 --> Total execution time: 0.0294
ERROR - 2021-12-20 06:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:32:08 --> Config Class Initialized
INFO - 2021-12-20 06:32:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:32:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:32:08 --> Utf8 Class Initialized
INFO - 2021-12-20 06:32:08 --> URI Class Initialized
INFO - 2021-12-20 06:32:08 --> Router Class Initialized
INFO - 2021-12-20 06:32:08 --> Output Class Initialized
INFO - 2021-12-20 06:32:08 --> Security Class Initialized
DEBUG - 2021-12-20 06:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:32:08 --> Input Class Initialized
INFO - 2021-12-20 06:32:08 --> Language Class Initialized
INFO - 2021-12-20 06:32:08 --> Loader Class Initialized
INFO - 2021-12-20 06:32:08 --> Helper loaded: url_helper
INFO - 2021-12-20 06:32:08 --> Helper loaded: form_helper
INFO - 2021-12-20 06:32:08 --> Helper loaded: common_helper
INFO - 2021-12-20 06:32:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:32:08 --> Controller Class Initialized
INFO - 2021-12-20 06:32:08 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:32:08 --> Encrypt Class Initialized
INFO - 2021-12-20 06:32:08 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:32:08 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:32:08 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:32:08 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:32:08 --> Model "Hospital_model" initialized
INFO - 2021-12-20 06:32:08 --> Final output sent to browser
DEBUG - 2021-12-20 06:32:08 --> Total execution time: 0.0289
ERROR - 2021-12-20 06:34:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:34:11 --> Config Class Initialized
INFO - 2021-12-20 06:34:11 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:34:11 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:34:11 --> Utf8 Class Initialized
INFO - 2021-12-20 06:34:11 --> URI Class Initialized
DEBUG - 2021-12-20 06:34:11 --> No URI present. Default controller set.
INFO - 2021-12-20 06:34:11 --> Router Class Initialized
INFO - 2021-12-20 06:34:11 --> Output Class Initialized
INFO - 2021-12-20 06:34:11 --> Security Class Initialized
DEBUG - 2021-12-20 06:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:34:11 --> Input Class Initialized
INFO - 2021-12-20 06:34:11 --> Language Class Initialized
INFO - 2021-12-20 06:34:11 --> Loader Class Initialized
INFO - 2021-12-20 06:34:11 --> Helper loaded: url_helper
INFO - 2021-12-20 06:34:11 --> Helper loaded: form_helper
INFO - 2021-12-20 06:34:11 --> Helper loaded: common_helper
INFO - 2021-12-20 06:34:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:34:11 --> Controller Class Initialized
INFO - 2021-12-20 06:34:11 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:34:11 --> Encrypt Class Initialized
DEBUG - 2021-12-20 06:34:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 06:34:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 06:34:11 --> Email Class Initialized
INFO - 2021-12-20 06:34:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 06:34:11 --> Calendar Class Initialized
INFO - 2021-12-20 06:34:11 --> Model "Login_model" initialized
INFO - 2021-12-20 06:34:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 06:34:11 --> Final output sent to browser
DEBUG - 2021-12-20 06:34:11 --> Total execution time: 0.0257
ERROR - 2021-12-20 06:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:35:47 --> Config Class Initialized
INFO - 2021-12-20 06:35:47 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:35:47 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:35:47 --> Utf8 Class Initialized
INFO - 2021-12-20 06:35:47 --> URI Class Initialized
INFO - 2021-12-20 06:35:47 --> Router Class Initialized
INFO - 2021-12-20 06:35:47 --> Output Class Initialized
INFO - 2021-12-20 06:35:47 --> Security Class Initialized
DEBUG - 2021-12-20 06:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:35:47 --> Input Class Initialized
INFO - 2021-12-20 06:35:47 --> Language Class Initialized
INFO - 2021-12-20 06:35:47 --> Loader Class Initialized
INFO - 2021-12-20 06:35:47 --> Helper loaded: url_helper
INFO - 2021-12-20 06:35:47 --> Helper loaded: form_helper
INFO - 2021-12-20 06:35:47 --> Helper loaded: common_helper
INFO - 2021-12-20 06:35:47 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:35:47 --> Controller Class Initialized
INFO - 2021-12-20 06:35:47 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:35:47 --> Encrypt Class Initialized
INFO - 2021-12-20 06:35:47 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:35:47 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:35:47 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:35:47 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:35:47 --> Model "Hospital_model" initialized
ERROR - 2021-12-20 06:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:35:48 --> Config Class Initialized
INFO - 2021-12-20 06:35:48 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:35:48 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:35:48 --> Utf8 Class Initialized
INFO - 2021-12-20 06:35:48 --> URI Class Initialized
INFO - 2021-12-20 06:35:48 --> Router Class Initialized
INFO - 2021-12-20 06:35:48 --> Output Class Initialized
INFO - 2021-12-20 06:35:48 --> Security Class Initialized
DEBUG - 2021-12-20 06:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:35:48 --> Input Class Initialized
INFO - 2021-12-20 06:35:48 --> Language Class Initialized
INFO - 2021-12-20 06:35:48 --> Loader Class Initialized
INFO - 2021-12-20 06:35:48 --> Helper loaded: url_helper
INFO - 2021-12-20 06:35:48 --> Helper loaded: form_helper
INFO - 2021-12-20 06:35:48 --> Helper loaded: common_helper
INFO - 2021-12-20 06:35:48 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:35:48 --> Controller Class Initialized
INFO - 2021-12-20 06:35:48 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:35:48 --> Encrypt Class Initialized
INFO - 2021-12-20 06:35:48 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:35:48 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:35:48 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:35:48 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:35:48 --> Model "Hospital_model" initialized
ERROR - 2021-12-20 06:35:48 --> Severity: error --> Exception: Too few arguments to function Patient_model::getPatient(), 1 passed in /home3/karoteam/public_html/application/controllers/Patientmaster.php on line 25 and exactly 5 expected /home3/karoteam/public_html/application/models/Patient_model.php 6
ERROR - 2021-12-20 06:35:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:35:56 --> Config Class Initialized
INFO - 2021-12-20 06:35:56 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:35:56 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:35:56 --> Utf8 Class Initialized
INFO - 2021-12-20 06:35:56 --> URI Class Initialized
INFO - 2021-12-20 06:35:56 --> Router Class Initialized
INFO - 2021-12-20 06:35:56 --> Output Class Initialized
INFO - 2021-12-20 06:35:56 --> Security Class Initialized
DEBUG - 2021-12-20 06:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:35:56 --> Input Class Initialized
INFO - 2021-12-20 06:35:56 --> Language Class Initialized
INFO - 2021-12-20 06:35:56 --> Loader Class Initialized
INFO - 2021-12-20 06:35:56 --> Helper loaded: url_helper
INFO - 2021-12-20 06:35:56 --> Helper loaded: form_helper
INFO - 2021-12-20 06:35:56 --> Helper loaded: common_helper
INFO - 2021-12-20 06:35:56 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:35:56 --> Controller Class Initialized
INFO - 2021-12-20 06:35:56 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:35:56 --> Encrypt Class Initialized
INFO - 2021-12-20 06:35:56 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:35:56 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:35:56 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:35:56 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:35:56 --> Model "Hospital_model" initialized
INFO - 2021-12-20 06:35:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 06:35:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-20 06:35:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 06:35:56 --> Final output sent to browser
DEBUG - 2021-12-20 06:35:56 --> Total execution time: 0.0412
ERROR - 2021-12-20 06:36:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:36:04 --> Config Class Initialized
INFO - 2021-12-20 06:36:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:36:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:36:04 --> Utf8 Class Initialized
INFO - 2021-12-20 06:36:04 --> URI Class Initialized
INFO - 2021-12-20 06:36:04 --> Router Class Initialized
INFO - 2021-12-20 06:36:04 --> Output Class Initialized
INFO - 2021-12-20 06:36:04 --> Security Class Initialized
DEBUG - 2021-12-20 06:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:36:04 --> Input Class Initialized
INFO - 2021-12-20 06:36:04 --> Language Class Initialized
INFO - 2021-12-20 06:36:04 --> Loader Class Initialized
INFO - 2021-12-20 06:36:04 --> Helper loaded: url_helper
INFO - 2021-12-20 06:36:04 --> Helper loaded: form_helper
INFO - 2021-12-20 06:36:04 --> Helper loaded: common_helper
INFO - 2021-12-20 06:36:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:36:04 --> Controller Class Initialized
INFO - 2021-12-20 06:36:04 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:36:04 --> Encrypt Class Initialized
INFO - 2021-12-20 06:36:04 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:36:04 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:36:04 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:36:04 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:36:04 --> Model "Hospital_model" initialized
ERROR - 2021-12-20 06:36:04 --> Query error: Duplicate entry 'KAROP00003212' for key 'patient_id' - Invalid query: INSERT INTO `patient_master` (`registration_site`, `patient_id`, `patient_case`, `patient_karo_case_no`, `representative_name`, `refered_by`, `referral_name`, `referral_details`, `registration_date`, `patient_name`, `patient_dob`, `patient_age`, `patient_gender`, `patient_language`, `patient_language_other`, `pp_address`, `pp_state`, `pp_city`, `pp_zip`, `check_add`, `pt_address`, `pt_state`, `pt_city`, `pt_zip`, `patient_phone`, `caregiver_name`, `caregiver_phone`, `patient_phone2`, `caregiver_name2`, `caregiver_phone2`, `created_by`, `created_at`) VALUES ('IO', 'KAROP00003212', 'KAROC00003212', '', '1', 'MSW', 'Yogesh Patil', '', '2021-12-20', 'Bhavesh Sudhakar Chavan', '--', '', 'Male', 'Hindi,Marathi', '', 'Room No - 005, Harishchandra Nagar, New Santoshi Mata Chawl, Atali Road, Ambivali West', 'Maharashtra', 'Thane', '421102', 'on', 'Room No - 005, Harishchandra Nagar, New Santoshi Mata Chawl, Atali Road, Ambivali West', 'Maharashtra', 'Thane', '421102', '9664102557', 'Sudhakar Chavan', '9664102557', '', '', '', '1', '2021-12-20 06:36:04')
DEBUG - 2021-12-20 06:36:04 --> DB Transaction Failure
INFO - 2021-12-20 06:36:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-12-20 06:36:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 06:36:07 --> Config Class Initialized
INFO - 2021-12-20 06:36:07 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:36:07 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:36:07 --> Utf8 Class Initialized
INFO - 2021-12-20 06:36:07 --> URI Class Initialized
INFO - 2021-12-20 06:36:07 --> Router Class Initialized
INFO - 2021-12-20 06:36:07 --> Output Class Initialized
INFO - 2021-12-20 06:36:07 --> Security Class Initialized
DEBUG - 2021-12-20 06:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:36:07 --> Input Class Initialized
INFO - 2021-12-20 06:36:07 --> Language Class Initialized
INFO - 2021-12-20 06:36:07 --> Loader Class Initialized
INFO - 2021-12-20 06:36:07 --> Helper loaded: url_helper
INFO - 2021-12-20 06:36:07 --> Helper loaded: form_helper
INFO - 2021-12-20 06:36:07 --> Helper loaded: common_helper
INFO - 2021-12-20 06:36:07 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:36:07 --> Controller Class Initialized
INFO - 2021-12-20 06:36:07 --> Form Validation Class Initialized
DEBUG - 2021-12-20 06:36:07 --> Encrypt Class Initialized
INFO - 2021-12-20 06:36:07 --> Model "Patient_model" initialized
INFO - 2021-12-20 06:36:07 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 06:36:07 --> Model "Referredby_model" initialized
INFO - 2021-12-20 06:36:07 --> Model "Prefix_master" initialized
INFO - 2021-12-20 06:36:07 --> Model "Hospital_model" initialized
INFO - 2021-12-20 06:36:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 06:36:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-20 06:36:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 06:36:07 --> Final output sent to browser
DEBUG - 2021-12-20 06:36:07 --> Total execution time: 0.0351
ERROR - 2021-12-20 08:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 08:05:44 --> Config Class Initialized
INFO - 2021-12-20 08:05:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:05:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:05:44 --> Utf8 Class Initialized
INFO - 2021-12-20 08:05:44 --> URI Class Initialized
DEBUG - 2021-12-20 08:05:44 --> No URI present. Default controller set.
INFO - 2021-12-20 08:05:44 --> Router Class Initialized
INFO - 2021-12-20 08:05:44 --> Output Class Initialized
INFO - 2021-12-20 08:05:44 --> Security Class Initialized
DEBUG - 2021-12-20 08:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:05:44 --> Input Class Initialized
INFO - 2021-12-20 08:05:44 --> Language Class Initialized
INFO - 2021-12-20 08:05:44 --> Loader Class Initialized
INFO - 2021-12-20 08:05:44 --> Helper loaded: url_helper
INFO - 2021-12-20 08:05:44 --> Helper loaded: form_helper
INFO - 2021-12-20 08:05:44 --> Helper loaded: common_helper
INFO - 2021-12-20 08:05:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:05:44 --> Controller Class Initialized
INFO - 2021-12-20 08:05:44 --> Form Validation Class Initialized
DEBUG - 2021-12-20 08:05:44 --> Encrypt Class Initialized
DEBUG - 2021-12-20 08:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 08:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 08:05:44 --> Email Class Initialized
INFO - 2021-12-20 08:05:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 08:05:44 --> Calendar Class Initialized
INFO - 2021-12-20 08:05:44 --> Model "Login_model" initialized
INFO - 2021-12-20 08:05:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 08:05:44 --> Final output sent to browser
DEBUG - 2021-12-20 08:05:44 --> Total execution time: 0.0274
ERROR - 2021-12-20 12:07:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 12:07:52 --> Config Class Initialized
INFO - 2021-12-20 12:07:52 --> Hooks Class Initialized
DEBUG - 2021-12-20 12:07:52 --> UTF-8 Support Enabled
INFO - 2021-12-20 12:07:52 --> Utf8 Class Initialized
INFO - 2021-12-20 12:07:52 --> URI Class Initialized
DEBUG - 2021-12-20 12:07:52 --> No URI present. Default controller set.
INFO - 2021-12-20 12:07:52 --> Router Class Initialized
INFO - 2021-12-20 12:07:52 --> Output Class Initialized
INFO - 2021-12-20 12:07:52 --> Security Class Initialized
DEBUG - 2021-12-20 12:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 12:07:52 --> Input Class Initialized
INFO - 2021-12-20 12:07:52 --> Language Class Initialized
INFO - 2021-12-20 12:07:52 --> Loader Class Initialized
INFO - 2021-12-20 12:07:52 --> Helper loaded: url_helper
INFO - 2021-12-20 12:07:52 --> Helper loaded: form_helper
INFO - 2021-12-20 12:07:52 --> Helper loaded: common_helper
INFO - 2021-12-20 12:07:52 --> Database Driver Class Initialized
DEBUG - 2021-12-20 12:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 12:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 12:07:52 --> Controller Class Initialized
INFO - 2021-12-20 12:07:52 --> Form Validation Class Initialized
DEBUG - 2021-12-20 12:07:52 --> Encrypt Class Initialized
DEBUG - 2021-12-20 12:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 12:07:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 12:07:52 --> Email Class Initialized
INFO - 2021-12-20 12:07:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 12:07:52 --> Calendar Class Initialized
INFO - 2021-12-20 12:07:52 --> Model "Login_model" initialized
INFO - 2021-12-20 12:07:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 12:07:52 --> Final output sent to browser
DEBUG - 2021-12-20 12:07:52 --> Total execution time: 0.0363
ERROR - 2021-12-20 14:21:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 14:21:17 --> Config Class Initialized
INFO - 2021-12-20 14:21:17 --> Hooks Class Initialized
DEBUG - 2021-12-20 14:21:17 --> UTF-8 Support Enabled
INFO - 2021-12-20 14:21:17 --> Utf8 Class Initialized
INFO - 2021-12-20 14:21:17 --> URI Class Initialized
DEBUG - 2021-12-20 14:21:17 --> No URI present. Default controller set.
INFO - 2021-12-20 14:21:17 --> Router Class Initialized
INFO - 2021-12-20 14:21:17 --> Output Class Initialized
INFO - 2021-12-20 14:21:17 --> Security Class Initialized
DEBUG - 2021-12-20 14:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 14:21:17 --> Input Class Initialized
INFO - 2021-12-20 14:21:17 --> Language Class Initialized
INFO - 2021-12-20 14:21:17 --> Loader Class Initialized
INFO - 2021-12-20 14:21:17 --> Helper loaded: url_helper
INFO - 2021-12-20 14:21:17 --> Helper loaded: form_helper
INFO - 2021-12-20 14:21:17 --> Helper loaded: common_helper
INFO - 2021-12-20 14:21:17 --> Database Driver Class Initialized
DEBUG - 2021-12-20 14:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 14:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 14:21:17 --> Controller Class Initialized
INFO - 2021-12-20 14:21:17 --> Form Validation Class Initialized
DEBUG - 2021-12-20 14:21:17 --> Encrypt Class Initialized
DEBUG - 2021-12-20 14:21:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 14:21:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 14:21:17 --> Email Class Initialized
INFO - 2021-12-20 14:21:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 14:21:17 --> Calendar Class Initialized
INFO - 2021-12-20 14:21:17 --> Model "Login_model" initialized
INFO - 2021-12-20 14:21:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 14:21:17 --> Final output sent to browser
DEBUG - 2021-12-20 14:21:17 --> Total execution time: 0.0238
ERROR - 2021-12-20 14:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 14:21:18 --> Config Class Initialized
INFO - 2021-12-20 14:21:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 14:21:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 14:21:18 --> Utf8 Class Initialized
INFO - 2021-12-20 14:21:18 --> URI Class Initialized
INFO - 2021-12-20 14:21:18 --> Router Class Initialized
INFO - 2021-12-20 14:21:18 --> Output Class Initialized
INFO - 2021-12-20 14:21:18 --> Security Class Initialized
DEBUG - 2021-12-20 14:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 14:21:18 --> Input Class Initialized
INFO - 2021-12-20 14:21:18 --> Language Class Initialized
ERROR - 2021-12-20 14:21:18 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-20 14:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 14:21:44 --> Config Class Initialized
INFO - 2021-12-20 14:21:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 14:21:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 14:21:44 --> Utf8 Class Initialized
INFO - 2021-12-20 14:21:44 --> URI Class Initialized
INFO - 2021-12-20 14:21:44 --> Router Class Initialized
INFO - 2021-12-20 14:21:44 --> Output Class Initialized
INFO - 2021-12-20 14:21:44 --> Security Class Initialized
DEBUG - 2021-12-20 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 14:21:44 --> Input Class Initialized
INFO - 2021-12-20 14:21:44 --> Language Class Initialized
INFO - 2021-12-20 14:21:44 --> Loader Class Initialized
INFO - 2021-12-20 14:21:44 --> Helper loaded: url_helper
INFO - 2021-12-20 14:21:44 --> Helper loaded: form_helper
INFO - 2021-12-20 14:21:44 --> Helper loaded: common_helper
INFO - 2021-12-20 14:21:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 14:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 14:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 14:21:44 --> Controller Class Initialized
INFO - 2021-12-20 14:21:44 --> Form Validation Class Initialized
DEBUG - 2021-12-20 14:21:44 --> Encrypt Class Initialized
DEBUG - 2021-12-20 14:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 14:21:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 14:21:44 --> Email Class Initialized
INFO - 2021-12-20 14:21:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 14:21:44 --> Calendar Class Initialized
INFO - 2021-12-20 14:21:44 --> Model "Login_model" initialized
INFO - 2021-12-20 14:21:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 14:21:44 --> Final output sent to browser
DEBUG - 2021-12-20 14:21:44 --> Total execution time: 0.0214
ERROR - 2021-12-20 14:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 14:21:44 --> Config Class Initialized
INFO - 2021-12-20 14:21:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 14:21:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 14:21:44 --> Utf8 Class Initialized
INFO - 2021-12-20 14:21:44 --> URI Class Initialized
DEBUG - 2021-12-20 14:21:44 --> No URI present. Default controller set.
INFO - 2021-12-20 14:21:44 --> Router Class Initialized
INFO - 2021-12-20 14:21:44 --> Output Class Initialized
INFO - 2021-12-20 14:21:44 --> Security Class Initialized
DEBUG - 2021-12-20 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 14:21:44 --> Input Class Initialized
INFO - 2021-12-20 14:21:44 --> Language Class Initialized
INFO - 2021-12-20 14:21:44 --> Loader Class Initialized
INFO - 2021-12-20 14:21:44 --> Helper loaded: url_helper
INFO - 2021-12-20 14:21:44 --> Helper loaded: form_helper
INFO - 2021-12-20 14:21:44 --> Helper loaded: common_helper
INFO - 2021-12-20 14:21:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 14:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 14:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 14:21:44 --> Controller Class Initialized
INFO - 2021-12-20 14:21:44 --> Form Validation Class Initialized
DEBUG - 2021-12-20 14:21:44 --> Encrypt Class Initialized
DEBUG - 2021-12-20 14:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 14:21:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 14:21:44 --> Email Class Initialized
INFO - 2021-12-20 14:21:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 14:21:44 --> Calendar Class Initialized
INFO - 2021-12-20 14:21:44 --> Model "Login_model" initialized
INFO - 2021-12-20 14:21:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 14:21:44 --> Final output sent to browser
DEBUG - 2021-12-20 14:21:44 --> Total execution time: 0.0271
ERROR - 2021-12-20 14:21:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 14:21:45 --> Config Class Initialized
INFO - 2021-12-20 14:21:45 --> Hooks Class Initialized
DEBUG - 2021-12-20 14:21:45 --> UTF-8 Support Enabled
INFO - 2021-12-20 14:21:45 --> Utf8 Class Initialized
INFO - 2021-12-20 14:21:45 --> URI Class Initialized
INFO - 2021-12-20 14:21:45 --> Router Class Initialized
INFO - 2021-12-20 14:21:45 --> Output Class Initialized
INFO - 2021-12-20 14:21:45 --> Security Class Initialized
DEBUG - 2021-12-20 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 14:21:45 --> Input Class Initialized
INFO - 2021-12-20 14:21:45 --> Language Class Initialized
INFO - 2021-12-20 14:21:45 --> Loader Class Initialized
INFO - 2021-12-20 14:21:45 --> Helper loaded: url_helper
INFO - 2021-12-20 14:21:45 --> Helper loaded: form_helper
INFO - 2021-12-20 14:21:45 --> Helper loaded: common_helper
INFO - 2021-12-20 14:21:45 --> Database Driver Class Initialized
DEBUG - 2021-12-20 14:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 14:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 14:21:45 --> Controller Class Initialized
INFO - 2021-12-20 14:21:45 --> Form Validation Class Initialized
DEBUG - 2021-12-20 14:21:45 --> Encrypt Class Initialized
DEBUG - 2021-12-20 14:21:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 14:21:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 14:21:45 --> Email Class Initialized
INFO - 2021-12-20 14:21:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 14:21:45 --> Calendar Class Initialized
INFO - 2021-12-20 14:21:45 --> Model "Login_model" initialized
ERROR - 2021-12-20 14:21:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 14:21:46 --> Config Class Initialized
INFO - 2021-12-20 14:21:46 --> Hooks Class Initialized
DEBUG - 2021-12-20 14:21:46 --> UTF-8 Support Enabled
INFO - 2021-12-20 14:21:46 --> Utf8 Class Initialized
INFO - 2021-12-20 14:21:46 --> URI Class Initialized
INFO - 2021-12-20 14:21:46 --> Router Class Initialized
INFO - 2021-12-20 14:21:46 --> Output Class Initialized
INFO - 2021-12-20 14:21:46 --> Security Class Initialized
DEBUG - 2021-12-20 14:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 14:21:46 --> Input Class Initialized
INFO - 2021-12-20 14:21:46 --> Language Class Initialized
INFO - 2021-12-20 14:21:46 --> Loader Class Initialized
INFO - 2021-12-20 14:21:46 --> Helper loaded: url_helper
INFO - 2021-12-20 14:21:46 --> Helper loaded: form_helper
INFO - 2021-12-20 14:21:46 --> Helper loaded: common_helper
INFO - 2021-12-20 14:21:46 --> Database Driver Class Initialized
DEBUG - 2021-12-20 14:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 14:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 14:21:46 --> Controller Class Initialized
INFO - 2021-12-20 14:21:46 --> Form Validation Class Initialized
DEBUG - 2021-12-20 14:21:46 --> Encrypt Class Initialized
DEBUG - 2021-12-20 14:21:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 14:21:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 14:21:46 --> Email Class Initialized
INFO - 2021-12-20 14:21:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 14:21:46 --> Calendar Class Initialized
INFO - 2021-12-20 14:21:46 --> Model "Login_model" initialized
ERROR - 2021-12-20 15:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 15:24:06 --> Config Class Initialized
INFO - 2021-12-20 15:24:06 --> Hooks Class Initialized
DEBUG - 2021-12-20 15:24:06 --> UTF-8 Support Enabled
INFO - 2021-12-20 15:24:06 --> Utf8 Class Initialized
INFO - 2021-12-20 15:24:06 --> URI Class Initialized
DEBUG - 2021-12-20 15:24:06 --> No URI present. Default controller set.
INFO - 2021-12-20 15:24:06 --> Router Class Initialized
INFO - 2021-12-20 15:24:06 --> Output Class Initialized
INFO - 2021-12-20 15:24:06 --> Security Class Initialized
DEBUG - 2021-12-20 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 15:24:06 --> Input Class Initialized
INFO - 2021-12-20 15:24:06 --> Language Class Initialized
INFO - 2021-12-20 15:24:06 --> Loader Class Initialized
INFO - 2021-12-20 15:24:06 --> Helper loaded: url_helper
INFO - 2021-12-20 15:24:06 --> Helper loaded: form_helper
INFO - 2021-12-20 15:24:06 --> Helper loaded: common_helper
INFO - 2021-12-20 15:24:06 --> Database Driver Class Initialized
DEBUG - 2021-12-20 15:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 15:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 15:24:06 --> Controller Class Initialized
INFO - 2021-12-20 15:24:06 --> Form Validation Class Initialized
DEBUG - 2021-12-20 15:24:06 --> Encrypt Class Initialized
DEBUG - 2021-12-20 15:24:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 15:24:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 15:24:06 --> Email Class Initialized
INFO - 2021-12-20 15:24:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 15:24:06 --> Calendar Class Initialized
INFO - 2021-12-20 15:24:06 --> Model "Login_model" initialized
INFO - 2021-12-20 15:24:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 15:24:06 --> Final output sent to browser
DEBUG - 2021-12-20 15:24:06 --> Total execution time: 0.0239
ERROR - 2021-12-20 23:49:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 23:49:01 --> Config Class Initialized
INFO - 2021-12-20 23:49:01 --> Hooks Class Initialized
DEBUG - 2021-12-20 23:49:01 --> UTF-8 Support Enabled
INFO - 2021-12-20 23:49:01 --> Utf8 Class Initialized
INFO - 2021-12-20 23:49:01 --> URI Class Initialized
DEBUG - 2021-12-20 23:49:01 --> No URI present. Default controller set.
INFO - 2021-12-20 23:49:01 --> Router Class Initialized
INFO - 2021-12-20 23:49:01 --> Output Class Initialized
INFO - 2021-12-20 23:49:01 --> Security Class Initialized
DEBUG - 2021-12-20 23:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 23:49:01 --> Input Class Initialized
INFO - 2021-12-20 23:49:01 --> Language Class Initialized
INFO - 2021-12-20 23:49:01 --> Loader Class Initialized
INFO - 2021-12-20 23:49:01 --> Helper loaded: url_helper
INFO - 2021-12-20 23:49:01 --> Helper loaded: form_helper
INFO - 2021-12-20 23:49:01 --> Helper loaded: common_helper
INFO - 2021-12-20 23:49:01 --> Database Driver Class Initialized
DEBUG - 2021-12-20 23:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 23:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 23:49:01 --> Controller Class Initialized
INFO - 2021-12-20 23:49:01 --> Form Validation Class Initialized
DEBUG - 2021-12-20 23:49:01 --> Encrypt Class Initialized
DEBUG - 2021-12-20 23:49:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 23:49:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 23:49:01 --> Email Class Initialized
INFO - 2021-12-20 23:49:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 23:49:01 --> Calendar Class Initialized
INFO - 2021-12-20 23:49:01 --> Model "Login_model" initialized
INFO - 2021-12-20 23:49:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-20 23:49:01 --> Final output sent to browser
DEBUG - 2021-12-20 23:49:01 --> Total execution time: 0.0248
ERROR - 2021-12-20 23:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 23:49:19 --> Config Class Initialized
INFO - 2021-12-20 23:49:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 23:49:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 23:49:19 --> Utf8 Class Initialized
INFO - 2021-12-20 23:49:19 --> URI Class Initialized
INFO - 2021-12-20 23:49:19 --> Router Class Initialized
INFO - 2021-12-20 23:49:19 --> Output Class Initialized
INFO - 2021-12-20 23:49:19 --> Security Class Initialized
DEBUG - 2021-12-20 23:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 23:49:19 --> Input Class Initialized
INFO - 2021-12-20 23:49:19 --> Language Class Initialized
INFO - 2021-12-20 23:49:19 --> Loader Class Initialized
INFO - 2021-12-20 23:49:19 --> Helper loaded: url_helper
INFO - 2021-12-20 23:49:19 --> Helper loaded: form_helper
INFO - 2021-12-20 23:49:19 --> Helper loaded: common_helper
INFO - 2021-12-20 23:49:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 23:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 23:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 23:49:19 --> Controller Class Initialized
INFO - 2021-12-20 23:49:19 --> Form Validation Class Initialized
DEBUG - 2021-12-20 23:49:19 --> Encrypt Class Initialized
DEBUG - 2021-12-20 23:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-20 23:49:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-20 23:49:19 --> Email Class Initialized
INFO - 2021-12-20 23:49:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-20 23:49:19 --> Calendar Class Initialized
INFO - 2021-12-20 23:49:19 --> Model "Login_model" initialized
INFO - 2021-12-20 23:49:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-12-20 23:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 23:49:19 --> Config Class Initialized
INFO - 2021-12-20 23:49:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 23:49:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 23:49:19 --> Utf8 Class Initialized
INFO - 2021-12-20 23:49:19 --> URI Class Initialized
INFO - 2021-12-20 23:49:19 --> Router Class Initialized
INFO - 2021-12-20 23:49:19 --> Output Class Initialized
INFO - 2021-12-20 23:49:19 --> Security Class Initialized
DEBUG - 2021-12-20 23:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 23:49:19 --> Input Class Initialized
INFO - 2021-12-20 23:49:19 --> Language Class Initialized
INFO - 2021-12-20 23:49:19 --> Loader Class Initialized
INFO - 2021-12-20 23:49:19 --> Helper loaded: url_helper
INFO - 2021-12-20 23:49:19 --> Helper loaded: form_helper
INFO - 2021-12-20 23:49:19 --> Helper loaded: common_helper
INFO - 2021-12-20 23:49:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 23:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 23:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 23:49:19 --> Controller Class Initialized
INFO - 2021-12-20 23:49:19 --> Form Validation Class Initialized
DEBUG - 2021-12-20 23:49:19 --> Encrypt Class Initialized
INFO - 2021-12-20 23:49:19 --> Model "Login_model" initialized
INFO - 2021-12-20 23:49:19 --> Model "Dashboard_model" initialized
INFO - 2021-12-20 23:49:19 --> Model "Case_model" initialized
INFO - 2021-12-20 23:49:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 23:49:37 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2021-12-20 23:49:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 23:49:37 --> Final output sent to browser
DEBUG - 2021-12-20 23:49:37 --> Total execution time: 17.9374
ERROR - 2021-12-20 23:49:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 23:49:40 --> Config Class Initialized
INFO - 2021-12-20 23:49:40 --> Hooks Class Initialized
DEBUG - 2021-12-20 23:49:40 --> UTF-8 Support Enabled
INFO - 2021-12-20 23:49:40 --> Utf8 Class Initialized
INFO - 2021-12-20 23:49:40 --> URI Class Initialized
INFO - 2021-12-20 23:49:40 --> Router Class Initialized
INFO - 2021-12-20 23:49:40 --> Output Class Initialized
INFO - 2021-12-20 23:49:40 --> Security Class Initialized
DEBUG - 2021-12-20 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 23:49:40 --> Input Class Initialized
INFO - 2021-12-20 23:49:40 --> Language Class Initialized
ERROR - 2021-12-20 23:49:40 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-12-20 23:50:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 23:50:35 --> Config Class Initialized
INFO - 2021-12-20 23:50:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 23:50:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 23:50:35 --> Utf8 Class Initialized
INFO - 2021-12-20 23:50:35 --> URI Class Initialized
INFO - 2021-12-20 23:50:35 --> Router Class Initialized
INFO - 2021-12-20 23:50:35 --> Output Class Initialized
INFO - 2021-12-20 23:50:35 --> Security Class Initialized
DEBUG - 2021-12-20 23:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 23:50:35 --> Input Class Initialized
INFO - 2021-12-20 23:50:35 --> Language Class Initialized
INFO - 2021-12-20 23:50:35 --> Loader Class Initialized
INFO - 2021-12-20 23:50:35 --> Helper loaded: url_helper
INFO - 2021-12-20 23:50:35 --> Helper loaded: form_helper
INFO - 2021-12-20 23:50:35 --> Helper loaded: common_helper
INFO - 2021-12-20 23:50:35 --> Database Driver Class Initialized
DEBUG - 2021-12-20 23:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 23:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 23:50:35 --> Controller Class Initialized
INFO - 2021-12-20 23:50:35 --> Form Validation Class Initialized
DEBUG - 2021-12-20 23:50:35 --> Encrypt Class Initialized
INFO - 2021-12-20 23:50:35 --> Model "Patient_model" initialized
INFO - 2021-12-20 23:50:35 --> Model "Patientcase_model" initialized
INFO - 2021-12-20 23:50:35 --> Model "Referredby_model" initialized
INFO - 2021-12-20 23:50:35 --> Model "Prefix_master" initialized
INFO - 2021-12-20 23:50:35 --> Model "Hospital_model" initialized
INFO - 2021-12-20 23:50:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2021-12-20 23:50:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2021-12-20 23:50:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2021-12-20 23:50:35 --> Final output sent to browser
DEBUG - 2021-12-20 23:50:35 --> Total execution time: 0.0292
ERROR - 2021-12-20 23:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-20 23:50:36 --> Config Class Initialized
INFO - 2021-12-20 23:50:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 23:50:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 23:50:36 --> Utf8 Class Initialized
INFO - 2021-12-20 23:50:36 --> URI Class Initialized
INFO - 2021-12-20 23:50:36 --> Router Class Initialized
INFO - 2021-12-20 23:50:36 --> Output Class Initialized
INFO - 2021-12-20 23:50:36 --> Security Class Initialized
DEBUG - 2021-12-20 23:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 23:50:36 --> Input Class Initialized
INFO - 2021-12-20 23:50:36 --> Language Class Initialized
ERROR - 2021-12-20 23:50:36 --> 404 Page Not Found: Karoclient/usersprofile
