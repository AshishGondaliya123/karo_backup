<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-04 00:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 00:29:56 --> Config Class Initialized
INFO - 2021-12-04 00:29:56 --> Hooks Class Initialized
DEBUG - 2021-12-04 00:29:56 --> UTF-8 Support Enabled
INFO - 2021-12-04 00:29:56 --> Utf8 Class Initialized
INFO - 2021-12-04 00:29:56 --> URI Class Initialized
DEBUG - 2021-12-04 00:29:56 --> No URI present. Default controller set.
INFO - 2021-12-04 00:29:56 --> Router Class Initialized
INFO - 2021-12-04 00:29:56 --> Output Class Initialized
INFO - 2021-12-04 00:29:56 --> Security Class Initialized
DEBUG - 2021-12-04 00:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 00:29:56 --> Input Class Initialized
INFO - 2021-12-04 00:29:56 --> Language Class Initialized
INFO - 2021-12-04 00:29:56 --> Loader Class Initialized
INFO - 2021-12-04 00:29:56 --> Helper loaded: url_helper
INFO - 2021-12-04 00:29:56 --> Helper loaded: form_helper
INFO - 2021-12-04 00:29:56 --> Helper loaded: common_helper
INFO - 2021-12-04 00:29:56 --> Database Driver Class Initialized
DEBUG - 2021-12-04 00:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 00:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 00:29:56 --> Controller Class Initialized
INFO - 2021-12-04 00:29:56 --> Form Validation Class Initialized
DEBUG - 2021-12-04 00:29:56 --> Encrypt Class Initialized
DEBUG - 2021-12-04 00:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 00:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 00:29:56 --> Email Class Initialized
INFO - 2021-12-04 00:29:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 00:29:56 --> Calendar Class Initialized
INFO - 2021-12-04 00:29:56 --> Model "Login_model" initialized
INFO - 2021-12-04 00:29:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 00:29:56 --> Final output sent to browser
DEBUG - 2021-12-04 00:29:56 --> Total execution time: 0.0245
ERROR - 2021-12-04 00:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 00:32:28 --> Config Class Initialized
INFO - 2021-12-04 00:32:28 --> Hooks Class Initialized
DEBUG - 2021-12-04 00:32:28 --> UTF-8 Support Enabled
INFO - 2021-12-04 00:32:28 --> Utf8 Class Initialized
INFO - 2021-12-04 00:32:28 --> URI Class Initialized
DEBUG - 2021-12-04 00:32:28 --> No URI present. Default controller set.
INFO - 2021-12-04 00:32:28 --> Router Class Initialized
INFO - 2021-12-04 00:32:28 --> Output Class Initialized
INFO - 2021-12-04 00:32:28 --> Security Class Initialized
DEBUG - 2021-12-04 00:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 00:32:28 --> Input Class Initialized
INFO - 2021-12-04 00:32:28 --> Language Class Initialized
INFO - 2021-12-04 00:32:28 --> Loader Class Initialized
INFO - 2021-12-04 00:32:28 --> Helper loaded: url_helper
INFO - 2021-12-04 00:32:28 --> Helper loaded: form_helper
INFO - 2021-12-04 00:32:28 --> Helper loaded: common_helper
INFO - 2021-12-04 00:32:28 --> Database Driver Class Initialized
DEBUG - 2021-12-04 00:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 00:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 00:32:28 --> Controller Class Initialized
INFO - 2021-12-04 00:32:28 --> Form Validation Class Initialized
DEBUG - 2021-12-04 00:32:28 --> Encrypt Class Initialized
DEBUG - 2021-12-04 00:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 00:32:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 00:32:28 --> Email Class Initialized
INFO - 2021-12-04 00:32:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 00:32:28 --> Calendar Class Initialized
INFO - 2021-12-04 00:32:28 --> Model "Login_model" initialized
INFO - 2021-12-04 00:32:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 00:32:28 --> Final output sent to browser
DEBUG - 2021-12-04 00:32:28 --> Total execution time: 0.0267
ERROR - 2021-12-04 01:09:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 01:09:42 --> Config Class Initialized
INFO - 2021-12-04 01:09:42 --> Hooks Class Initialized
DEBUG - 2021-12-04 01:09:42 --> UTF-8 Support Enabled
INFO - 2021-12-04 01:09:42 --> Utf8 Class Initialized
INFO - 2021-12-04 01:09:42 --> URI Class Initialized
DEBUG - 2021-12-04 01:09:42 --> No URI present. Default controller set.
INFO - 2021-12-04 01:09:42 --> Router Class Initialized
INFO - 2021-12-04 01:09:42 --> Output Class Initialized
INFO - 2021-12-04 01:09:42 --> Security Class Initialized
DEBUG - 2021-12-04 01:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 01:09:42 --> Input Class Initialized
INFO - 2021-12-04 01:09:42 --> Language Class Initialized
INFO - 2021-12-04 01:09:42 --> Loader Class Initialized
INFO - 2021-12-04 01:09:42 --> Helper loaded: url_helper
INFO - 2021-12-04 01:09:42 --> Helper loaded: form_helper
INFO - 2021-12-04 01:09:42 --> Helper loaded: common_helper
INFO - 2021-12-04 01:09:42 --> Database Driver Class Initialized
DEBUG - 2021-12-04 01:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 01:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 01:09:42 --> Controller Class Initialized
INFO - 2021-12-04 01:09:42 --> Form Validation Class Initialized
DEBUG - 2021-12-04 01:09:42 --> Encrypt Class Initialized
DEBUG - 2021-12-04 01:09:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 01:09:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 01:09:42 --> Email Class Initialized
INFO - 2021-12-04 01:09:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 01:09:42 --> Calendar Class Initialized
INFO - 2021-12-04 01:09:42 --> Model "Login_model" initialized
INFO - 2021-12-04 01:09:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 01:09:42 --> Final output sent to browser
DEBUG - 2021-12-04 01:09:42 --> Total execution time: 0.0213
ERROR - 2021-12-04 01:38:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 01:38:13 --> Config Class Initialized
INFO - 2021-12-04 01:38:13 --> Hooks Class Initialized
DEBUG - 2021-12-04 01:38:13 --> UTF-8 Support Enabled
INFO - 2021-12-04 01:38:13 --> Utf8 Class Initialized
INFO - 2021-12-04 01:38:13 --> URI Class Initialized
DEBUG - 2021-12-04 01:38:13 --> No URI present. Default controller set.
INFO - 2021-12-04 01:38:13 --> Router Class Initialized
INFO - 2021-12-04 01:38:13 --> Output Class Initialized
INFO - 2021-12-04 01:38:13 --> Security Class Initialized
DEBUG - 2021-12-04 01:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 01:38:13 --> Input Class Initialized
INFO - 2021-12-04 01:38:13 --> Language Class Initialized
INFO - 2021-12-04 01:38:13 --> Loader Class Initialized
INFO - 2021-12-04 01:38:13 --> Helper loaded: url_helper
INFO - 2021-12-04 01:38:13 --> Helper loaded: form_helper
INFO - 2021-12-04 01:38:13 --> Helper loaded: common_helper
INFO - 2021-12-04 01:38:13 --> Database Driver Class Initialized
DEBUG - 2021-12-04 01:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 01:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 01:38:13 --> Controller Class Initialized
INFO - 2021-12-04 01:38:13 --> Form Validation Class Initialized
DEBUG - 2021-12-04 01:38:13 --> Encrypt Class Initialized
DEBUG - 2021-12-04 01:38:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 01:38:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 01:38:13 --> Email Class Initialized
INFO - 2021-12-04 01:38:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 01:38:13 --> Calendar Class Initialized
INFO - 2021-12-04 01:38:13 --> Model "Login_model" initialized
INFO - 2021-12-04 01:38:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 01:38:13 --> Final output sent to browser
DEBUG - 2021-12-04 01:38:13 --> Total execution time: 0.0265
ERROR - 2021-12-04 03:23:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:23:17 --> Config Class Initialized
INFO - 2021-12-04 03:23:17 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:23:17 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:23:17 --> Utf8 Class Initialized
INFO - 2021-12-04 03:23:17 --> URI Class Initialized
DEBUG - 2021-12-04 03:23:17 --> No URI present. Default controller set.
INFO - 2021-12-04 03:23:17 --> Router Class Initialized
INFO - 2021-12-04 03:23:17 --> Output Class Initialized
INFO - 2021-12-04 03:23:17 --> Security Class Initialized
DEBUG - 2021-12-04 03:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:23:17 --> Input Class Initialized
INFO - 2021-12-04 03:23:17 --> Language Class Initialized
INFO - 2021-12-04 03:23:17 --> Loader Class Initialized
INFO - 2021-12-04 03:23:17 --> Helper loaded: url_helper
INFO - 2021-12-04 03:23:17 --> Helper loaded: form_helper
INFO - 2021-12-04 03:23:17 --> Helper loaded: common_helper
INFO - 2021-12-04 03:23:17 --> Database Driver Class Initialized
DEBUG - 2021-12-04 03:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 03:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 03:23:17 --> Controller Class Initialized
INFO - 2021-12-04 03:23:17 --> Form Validation Class Initialized
DEBUG - 2021-12-04 03:23:17 --> Encrypt Class Initialized
DEBUG - 2021-12-04 03:23:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 03:23:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 03:23:17 --> Email Class Initialized
INFO - 2021-12-04 03:23:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 03:23:17 --> Calendar Class Initialized
INFO - 2021-12-04 03:23:17 --> Model "Login_model" initialized
INFO - 2021-12-04 03:23:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 03:23:17 --> Final output sent to browser
DEBUG - 2021-12-04 03:23:17 --> Total execution time: 0.0247
ERROR - 2021-12-04 03:40:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:47 --> Config Class Initialized
INFO - 2021-12-04 03:40:47 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:47 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:47 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:47 --> URI Class Initialized
DEBUG - 2021-12-04 03:40:47 --> No URI present. Default controller set.
INFO - 2021-12-04 03:40:47 --> Router Class Initialized
INFO - 2021-12-04 03:40:47 --> Output Class Initialized
INFO - 2021-12-04 03:40:47 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:47 --> Input Class Initialized
INFO - 2021-12-04 03:40:47 --> Language Class Initialized
INFO - 2021-12-04 03:40:47 --> Loader Class Initialized
INFO - 2021-12-04 03:40:47 --> Helper loaded: url_helper
INFO - 2021-12-04 03:40:47 --> Helper loaded: form_helper
INFO - 2021-12-04 03:40:47 --> Helper loaded: common_helper
INFO - 2021-12-04 03:40:47 --> Database Driver Class Initialized
DEBUG - 2021-12-04 03:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 03:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 03:40:47 --> Controller Class Initialized
INFO - 2021-12-04 03:40:47 --> Form Validation Class Initialized
DEBUG - 2021-12-04 03:40:47 --> Encrypt Class Initialized
DEBUG - 2021-12-04 03:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 03:40:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 03:40:47 --> Email Class Initialized
INFO - 2021-12-04 03:40:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 03:40:47 --> Calendar Class Initialized
INFO - 2021-12-04 03:40:47 --> Model "Login_model" initialized
INFO - 2021-12-04 03:40:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 03:40:47 --> Final output sent to browser
DEBUG - 2021-12-04 03:40:47 --> Total execution time: 0.0236
ERROR - 2021-12-04 03:40:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:47 --> Config Class Initialized
INFO - 2021-12-04 03:40:47 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:47 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:47 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:47 --> URI Class Initialized
DEBUG - 2021-12-04 03:40:47 --> No URI present. Default controller set.
INFO - 2021-12-04 03:40:47 --> Router Class Initialized
INFO - 2021-12-04 03:40:47 --> Output Class Initialized
INFO - 2021-12-04 03:40:47 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:47 --> Input Class Initialized
INFO - 2021-12-04 03:40:47 --> Language Class Initialized
INFO - 2021-12-04 03:40:47 --> Loader Class Initialized
INFO - 2021-12-04 03:40:47 --> Helper loaded: url_helper
INFO - 2021-12-04 03:40:47 --> Helper loaded: form_helper
INFO - 2021-12-04 03:40:47 --> Helper loaded: common_helper
INFO - 2021-12-04 03:40:47 --> Database Driver Class Initialized
DEBUG - 2021-12-04 03:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 03:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 03:40:47 --> Controller Class Initialized
INFO - 2021-12-04 03:40:47 --> Form Validation Class Initialized
DEBUG - 2021-12-04 03:40:47 --> Encrypt Class Initialized
DEBUG - 2021-12-04 03:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 03:40:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 03:40:47 --> Email Class Initialized
INFO - 2021-12-04 03:40:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 03:40:47 --> Calendar Class Initialized
INFO - 2021-12-04 03:40:47 --> Model "Login_model" initialized
INFO - 2021-12-04 03:40:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 03:40:47 --> Final output sent to browser
DEBUG - 2021-12-04 03:40:47 --> Total execution time: 0.0248
ERROR - 2021-12-04 03:40:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:47 --> Config Class Initialized
INFO - 2021-12-04 03:40:47 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:47 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:47 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:47 --> URI Class Initialized
INFO - 2021-12-04 03:40:47 --> Router Class Initialized
INFO - 2021-12-04 03:40:47 --> Output Class Initialized
INFO - 2021-12-04 03:40:47 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:47 --> Input Class Initialized
INFO - 2021-12-04 03:40:47 --> Language Class Initialized
ERROR - 2021-12-04 03:40:47 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-04 03:40:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:48 --> Config Class Initialized
INFO - 2021-12-04 03:40:48 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:48 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:48 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:48 --> URI Class Initialized
DEBUG - 2021-12-04 03:40:48 --> No URI present. Default controller set.
INFO - 2021-12-04 03:40:48 --> Router Class Initialized
INFO - 2021-12-04 03:40:48 --> Output Class Initialized
INFO - 2021-12-04 03:40:48 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:48 --> Input Class Initialized
INFO - 2021-12-04 03:40:48 --> Language Class Initialized
INFO - 2021-12-04 03:40:48 --> Loader Class Initialized
INFO - 2021-12-04 03:40:48 --> Helper loaded: url_helper
INFO - 2021-12-04 03:40:48 --> Helper loaded: form_helper
INFO - 2021-12-04 03:40:48 --> Helper loaded: common_helper
INFO - 2021-12-04 03:40:48 --> Database Driver Class Initialized
DEBUG - 2021-12-04 03:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 03:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 03:40:48 --> Controller Class Initialized
INFO - 2021-12-04 03:40:48 --> Form Validation Class Initialized
DEBUG - 2021-12-04 03:40:48 --> Encrypt Class Initialized
DEBUG - 2021-12-04 03:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 03:40:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 03:40:48 --> Email Class Initialized
INFO - 2021-12-04 03:40:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 03:40:48 --> Calendar Class Initialized
INFO - 2021-12-04 03:40:48 --> Model "Login_model" initialized
INFO - 2021-12-04 03:40:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 03:40:48 --> Final output sent to browser
DEBUG - 2021-12-04 03:40:48 --> Total execution time: 0.0224
ERROR - 2021-12-04 03:40:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:49 --> Config Class Initialized
INFO - 2021-12-04 03:40:49 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:49 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:49 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:49 --> URI Class Initialized
INFO - 2021-12-04 03:40:49 --> Router Class Initialized
INFO - 2021-12-04 03:40:49 --> Output Class Initialized
INFO - 2021-12-04 03:40:49 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:49 --> Input Class Initialized
INFO - 2021-12-04 03:40:49 --> Language Class Initialized
ERROR - 2021-12-04 03:40:49 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-04 03:40:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:49 --> Config Class Initialized
INFO - 2021-12-04 03:40:49 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:49 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:49 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:49 --> URI Class Initialized
INFO - 2021-12-04 03:40:49 --> Router Class Initialized
INFO - 2021-12-04 03:40:49 --> Output Class Initialized
INFO - 2021-12-04 03:40:49 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:49 --> Input Class Initialized
INFO - 2021-12-04 03:40:49 --> Language Class Initialized
ERROR - 2021-12-04 03:40:49 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-04 03:40:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:50 --> Config Class Initialized
INFO - 2021-12-04 03:40:50 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:50 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:50 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:50 --> URI Class Initialized
INFO - 2021-12-04 03:40:50 --> Router Class Initialized
INFO - 2021-12-04 03:40:50 --> Output Class Initialized
INFO - 2021-12-04 03:40:50 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:50 --> Input Class Initialized
INFO - 2021-12-04 03:40:50 --> Language Class Initialized
ERROR - 2021-12-04 03:40:50 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-04 03:40:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:50 --> Config Class Initialized
INFO - 2021-12-04 03:40:50 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:50 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:50 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:50 --> URI Class Initialized
INFO - 2021-12-04 03:40:50 --> Router Class Initialized
INFO - 2021-12-04 03:40:50 --> Output Class Initialized
INFO - 2021-12-04 03:40:50 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:50 --> Input Class Initialized
INFO - 2021-12-04 03:40:50 --> Language Class Initialized
ERROR - 2021-12-04 03:40:50 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-04 03:40:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:51 --> Config Class Initialized
INFO - 2021-12-04 03:40:51 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:51 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:51 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:51 --> URI Class Initialized
INFO - 2021-12-04 03:40:51 --> Router Class Initialized
INFO - 2021-12-04 03:40:51 --> Output Class Initialized
INFO - 2021-12-04 03:40:51 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:51 --> Input Class Initialized
INFO - 2021-12-04 03:40:51 --> Language Class Initialized
ERROR - 2021-12-04 03:40:51 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-04 03:40:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:51 --> Config Class Initialized
INFO - 2021-12-04 03:40:51 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:51 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:51 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:51 --> URI Class Initialized
INFO - 2021-12-04 03:40:51 --> Router Class Initialized
INFO - 2021-12-04 03:40:51 --> Output Class Initialized
INFO - 2021-12-04 03:40:51 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:51 --> Input Class Initialized
INFO - 2021-12-04 03:40:51 --> Language Class Initialized
ERROR - 2021-12-04 03:40:51 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-04 03:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:52 --> Config Class Initialized
INFO - 2021-12-04 03:40:52 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:52 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:52 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:52 --> URI Class Initialized
INFO - 2021-12-04 03:40:52 --> Router Class Initialized
INFO - 2021-12-04 03:40:52 --> Output Class Initialized
INFO - 2021-12-04 03:40:52 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:52 --> Input Class Initialized
INFO - 2021-12-04 03:40:52 --> Language Class Initialized
ERROR - 2021-12-04 03:40:52 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-12-04 03:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:52 --> Config Class Initialized
INFO - 2021-12-04 03:40:52 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:52 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:52 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:52 --> URI Class Initialized
INFO - 2021-12-04 03:40:52 --> Router Class Initialized
INFO - 2021-12-04 03:40:52 --> Output Class Initialized
INFO - 2021-12-04 03:40:52 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:52 --> Input Class Initialized
INFO - 2021-12-04 03:40:52 --> Language Class Initialized
ERROR - 2021-12-04 03:40:52 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-04 03:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:53 --> Config Class Initialized
INFO - 2021-12-04 03:40:53 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:53 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:53 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:53 --> URI Class Initialized
INFO - 2021-12-04 03:40:53 --> Router Class Initialized
INFO - 2021-12-04 03:40:53 --> Output Class Initialized
INFO - 2021-12-04 03:40:53 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:53 --> Input Class Initialized
INFO - 2021-12-04 03:40:53 --> Language Class Initialized
ERROR - 2021-12-04 03:40:53 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-04 03:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:53 --> Config Class Initialized
INFO - 2021-12-04 03:40:53 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:53 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:53 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:53 --> URI Class Initialized
INFO - 2021-12-04 03:40:53 --> Router Class Initialized
INFO - 2021-12-04 03:40:53 --> Output Class Initialized
INFO - 2021-12-04 03:40:53 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:53 --> Input Class Initialized
INFO - 2021-12-04 03:40:53 --> Language Class Initialized
ERROR - 2021-12-04 03:40:53 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-04 03:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:54 --> Config Class Initialized
INFO - 2021-12-04 03:40:54 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:54 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:54 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:54 --> URI Class Initialized
INFO - 2021-12-04 03:40:54 --> Router Class Initialized
INFO - 2021-12-04 03:40:54 --> Output Class Initialized
INFO - 2021-12-04 03:40:54 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:54 --> Input Class Initialized
INFO - 2021-12-04 03:40:54 --> Language Class Initialized
ERROR - 2021-12-04 03:40:54 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-04 03:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:54 --> Config Class Initialized
INFO - 2021-12-04 03:40:54 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:54 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:54 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:54 --> URI Class Initialized
INFO - 2021-12-04 03:40:54 --> Router Class Initialized
INFO - 2021-12-04 03:40:54 --> Output Class Initialized
INFO - 2021-12-04 03:40:54 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:54 --> Input Class Initialized
INFO - 2021-12-04 03:40:54 --> Language Class Initialized
ERROR - 2021-12-04 03:40:54 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-12-04 03:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:55 --> Config Class Initialized
INFO - 2021-12-04 03:40:55 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:55 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:55 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:55 --> URI Class Initialized
INFO - 2021-12-04 03:40:55 --> Router Class Initialized
INFO - 2021-12-04 03:40:55 --> Output Class Initialized
INFO - 2021-12-04 03:40:55 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:55 --> Input Class Initialized
INFO - 2021-12-04 03:40:55 --> Language Class Initialized
ERROR - 2021-12-04 03:40:55 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-04 03:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:55 --> Config Class Initialized
INFO - 2021-12-04 03:40:55 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:55 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:55 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:55 --> URI Class Initialized
INFO - 2021-12-04 03:40:55 --> Router Class Initialized
INFO - 2021-12-04 03:40:55 --> Output Class Initialized
INFO - 2021-12-04 03:40:55 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:55 --> Input Class Initialized
INFO - 2021-12-04 03:40:55 --> Language Class Initialized
ERROR - 2021-12-04 03:40:55 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-04 03:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:56 --> Config Class Initialized
INFO - 2021-12-04 03:40:56 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:56 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:56 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:56 --> URI Class Initialized
INFO - 2021-12-04 03:40:56 --> Router Class Initialized
INFO - 2021-12-04 03:40:56 --> Output Class Initialized
INFO - 2021-12-04 03:40:56 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:56 --> Input Class Initialized
INFO - 2021-12-04 03:40:56 --> Language Class Initialized
ERROR - 2021-12-04 03:40:56 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-04 03:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 03:40:56 --> Config Class Initialized
INFO - 2021-12-04 03:40:56 --> Hooks Class Initialized
DEBUG - 2021-12-04 03:40:56 --> UTF-8 Support Enabled
INFO - 2021-12-04 03:40:56 --> Utf8 Class Initialized
INFO - 2021-12-04 03:40:56 --> URI Class Initialized
INFO - 2021-12-04 03:40:56 --> Router Class Initialized
INFO - 2021-12-04 03:40:56 --> Output Class Initialized
INFO - 2021-12-04 03:40:56 --> Security Class Initialized
DEBUG - 2021-12-04 03:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 03:40:56 --> Input Class Initialized
INFO - 2021-12-04 03:40:56 --> Language Class Initialized
ERROR - 2021-12-04 03:40:56 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-04 06:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 06:54:53 --> Config Class Initialized
INFO - 2021-12-04 06:54:53 --> Hooks Class Initialized
DEBUG - 2021-12-04 06:54:53 --> UTF-8 Support Enabled
INFO - 2021-12-04 06:54:53 --> Utf8 Class Initialized
INFO - 2021-12-04 06:54:53 --> URI Class Initialized
DEBUG - 2021-12-04 06:54:53 --> No URI present. Default controller set.
INFO - 2021-12-04 06:54:53 --> Router Class Initialized
INFO - 2021-12-04 06:54:53 --> Output Class Initialized
INFO - 2021-12-04 06:54:53 --> Security Class Initialized
DEBUG - 2021-12-04 06:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 06:54:53 --> Input Class Initialized
INFO - 2021-12-04 06:54:53 --> Language Class Initialized
INFO - 2021-12-04 06:54:53 --> Loader Class Initialized
INFO - 2021-12-04 06:54:53 --> Helper loaded: url_helper
INFO - 2021-12-04 06:54:53 --> Helper loaded: form_helper
INFO - 2021-12-04 06:54:53 --> Helper loaded: common_helper
INFO - 2021-12-04 06:54:53 --> Database Driver Class Initialized
DEBUG - 2021-12-04 06:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 06:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 06:54:53 --> Controller Class Initialized
INFO - 2021-12-04 06:54:53 --> Form Validation Class Initialized
DEBUG - 2021-12-04 06:54:53 --> Encrypt Class Initialized
DEBUG - 2021-12-04 06:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 06:54:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 06:54:53 --> Email Class Initialized
INFO - 2021-12-04 06:54:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 06:54:53 --> Calendar Class Initialized
INFO - 2021-12-04 06:54:53 --> Model "Login_model" initialized
INFO - 2021-12-04 06:54:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 06:54:53 --> Final output sent to browser
DEBUG - 2021-12-04 06:54:53 --> Total execution time: 0.0250
ERROR - 2021-12-04 10:39:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 10:39:24 --> Config Class Initialized
INFO - 2021-12-04 10:39:24 --> Hooks Class Initialized
DEBUG - 2021-12-04 10:39:24 --> UTF-8 Support Enabled
INFO - 2021-12-04 10:39:24 --> Utf8 Class Initialized
INFO - 2021-12-04 10:39:24 --> URI Class Initialized
DEBUG - 2021-12-04 10:39:24 --> No URI present. Default controller set.
INFO - 2021-12-04 10:39:24 --> Router Class Initialized
INFO - 2021-12-04 10:39:24 --> Output Class Initialized
INFO - 2021-12-04 10:39:24 --> Security Class Initialized
DEBUG - 2021-12-04 10:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 10:39:24 --> Input Class Initialized
INFO - 2021-12-04 10:39:24 --> Language Class Initialized
INFO - 2021-12-04 10:39:24 --> Loader Class Initialized
INFO - 2021-12-04 10:39:24 --> Helper loaded: url_helper
INFO - 2021-12-04 10:39:24 --> Helper loaded: form_helper
INFO - 2021-12-04 10:39:24 --> Helper loaded: common_helper
INFO - 2021-12-04 10:39:24 --> Database Driver Class Initialized
DEBUG - 2021-12-04 10:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 10:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 10:39:24 --> Controller Class Initialized
INFO - 2021-12-04 10:39:24 --> Form Validation Class Initialized
DEBUG - 2021-12-04 10:39:24 --> Encrypt Class Initialized
DEBUG - 2021-12-04 10:39:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 10:39:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 10:39:24 --> Email Class Initialized
INFO - 2021-12-04 10:39:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 10:39:24 --> Calendar Class Initialized
INFO - 2021-12-04 10:39:24 --> Model "Login_model" initialized
INFO - 2021-12-04 10:39:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 10:39:24 --> Final output sent to browser
DEBUG - 2021-12-04 10:39:24 --> Total execution time: 0.0248
ERROR - 2021-12-04 10:39:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 10:39:26 --> Config Class Initialized
INFO - 2021-12-04 10:39:26 --> Hooks Class Initialized
DEBUG - 2021-12-04 10:39:26 --> UTF-8 Support Enabled
INFO - 2021-12-04 10:39:26 --> Utf8 Class Initialized
INFO - 2021-12-04 10:39:26 --> URI Class Initialized
DEBUG - 2021-12-04 10:39:26 --> No URI present. Default controller set.
INFO - 2021-12-04 10:39:26 --> Router Class Initialized
INFO - 2021-12-04 10:39:26 --> Output Class Initialized
INFO - 2021-12-04 10:39:26 --> Security Class Initialized
DEBUG - 2021-12-04 10:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 10:39:26 --> Input Class Initialized
INFO - 2021-12-04 10:39:26 --> Language Class Initialized
INFO - 2021-12-04 10:39:26 --> Loader Class Initialized
INFO - 2021-12-04 10:39:26 --> Helper loaded: url_helper
INFO - 2021-12-04 10:39:26 --> Helper loaded: form_helper
INFO - 2021-12-04 10:39:26 --> Helper loaded: common_helper
INFO - 2021-12-04 10:39:26 --> Database Driver Class Initialized
DEBUG - 2021-12-04 10:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 10:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 10:39:26 --> Controller Class Initialized
INFO - 2021-12-04 10:39:26 --> Form Validation Class Initialized
DEBUG - 2021-12-04 10:39:26 --> Encrypt Class Initialized
DEBUG - 2021-12-04 10:39:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 10:39:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 10:39:26 --> Email Class Initialized
INFO - 2021-12-04 10:39:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 10:39:26 --> Calendar Class Initialized
INFO - 2021-12-04 10:39:26 --> Model "Login_model" initialized
INFO - 2021-12-04 10:39:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 10:39:26 --> Final output sent to browser
DEBUG - 2021-12-04 10:39:26 --> Total execution time: 0.0304
ERROR - 2021-12-04 14:16:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 14:16:16 --> Config Class Initialized
INFO - 2021-12-04 14:16:16 --> Hooks Class Initialized
DEBUG - 2021-12-04 14:16:16 --> UTF-8 Support Enabled
INFO - 2021-12-04 14:16:16 --> Utf8 Class Initialized
INFO - 2021-12-04 14:16:16 --> URI Class Initialized
DEBUG - 2021-12-04 14:16:16 --> No URI present. Default controller set.
INFO - 2021-12-04 14:16:16 --> Router Class Initialized
INFO - 2021-12-04 14:16:16 --> Output Class Initialized
INFO - 2021-12-04 14:16:16 --> Security Class Initialized
DEBUG - 2021-12-04 14:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 14:16:16 --> Input Class Initialized
INFO - 2021-12-04 14:16:16 --> Language Class Initialized
INFO - 2021-12-04 14:16:16 --> Loader Class Initialized
INFO - 2021-12-04 14:16:16 --> Helper loaded: url_helper
INFO - 2021-12-04 14:16:16 --> Helper loaded: form_helper
INFO - 2021-12-04 14:16:16 --> Helper loaded: common_helper
INFO - 2021-12-04 14:16:16 --> Database Driver Class Initialized
DEBUG - 2021-12-04 14:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 14:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 14:16:16 --> Controller Class Initialized
INFO - 2021-12-04 14:16:16 --> Form Validation Class Initialized
DEBUG - 2021-12-04 14:16:16 --> Encrypt Class Initialized
DEBUG - 2021-12-04 14:16:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 14:16:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 14:16:16 --> Email Class Initialized
INFO - 2021-12-04 14:16:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 14:16:16 --> Calendar Class Initialized
INFO - 2021-12-04 14:16:16 --> Model "Login_model" initialized
INFO - 2021-12-04 14:16:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 14:16:16 --> Final output sent to browser
DEBUG - 2021-12-04 14:16:16 --> Total execution time: 0.0303
ERROR - 2021-12-04 14:16:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 14:16:18 --> Config Class Initialized
INFO - 2021-12-04 14:16:18 --> Hooks Class Initialized
DEBUG - 2021-12-04 14:16:18 --> UTF-8 Support Enabled
INFO - 2021-12-04 14:16:18 --> Utf8 Class Initialized
INFO - 2021-12-04 14:16:18 --> URI Class Initialized
INFO - 2021-12-04 14:16:18 --> Router Class Initialized
INFO - 2021-12-04 14:16:18 --> Output Class Initialized
INFO - 2021-12-04 14:16:18 --> Security Class Initialized
DEBUG - 2021-12-04 14:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 14:16:18 --> Input Class Initialized
INFO - 2021-12-04 14:16:18 --> Language Class Initialized
ERROR - 2021-12-04 14:16:18 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-04 14:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 14:16:42 --> Config Class Initialized
INFO - 2021-12-04 14:16:42 --> Hooks Class Initialized
DEBUG - 2021-12-04 14:16:42 --> UTF-8 Support Enabled
INFO - 2021-12-04 14:16:42 --> Utf8 Class Initialized
INFO - 2021-12-04 14:16:42 --> URI Class Initialized
INFO - 2021-12-04 14:16:42 --> Router Class Initialized
INFO - 2021-12-04 14:16:42 --> Output Class Initialized
INFO - 2021-12-04 14:16:42 --> Security Class Initialized
DEBUG - 2021-12-04 14:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 14:16:42 --> Input Class Initialized
INFO - 2021-12-04 14:16:42 --> Language Class Initialized
INFO - 2021-12-04 14:16:42 --> Loader Class Initialized
INFO - 2021-12-04 14:16:42 --> Helper loaded: url_helper
INFO - 2021-12-04 14:16:42 --> Helper loaded: form_helper
INFO - 2021-12-04 14:16:42 --> Helper loaded: common_helper
INFO - 2021-12-04 14:16:42 --> Database Driver Class Initialized
DEBUG - 2021-12-04 14:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 14:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 14:16:42 --> Controller Class Initialized
INFO - 2021-12-04 14:16:42 --> Form Validation Class Initialized
DEBUG - 2021-12-04 14:16:42 --> Encrypt Class Initialized
DEBUG - 2021-12-04 14:16:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 14:16:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 14:16:42 --> Email Class Initialized
INFO - 2021-12-04 14:16:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 14:16:42 --> Calendar Class Initialized
INFO - 2021-12-04 14:16:42 --> Model "Login_model" initialized
INFO - 2021-12-04 14:16:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 14:16:42 --> Final output sent to browser
DEBUG - 2021-12-04 14:16:42 --> Total execution time: 0.0234
ERROR - 2021-12-04 14:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 14:16:42 --> Config Class Initialized
INFO - 2021-12-04 14:16:42 --> Hooks Class Initialized
DEBUG - 2021-12-04 14:16:42 --> UTF-8 Support Enabled
INFO - 2021-12-04 14:16:42 --> Utf8 Class Initialized
INFO - 2021-12-04 14:16:42 --> URI Class Initialized
INFO - 2021-12-04 14:16:42 --> Router Class Initialized
INFO - 2021-12-04 14:16:42 --> Output Class Initialized
INFO - 2021-12-04 14:16:42 --> Security Class Initialized
DEBUG - 2021-12-04 14:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 14:16:42 --> Input Class Initialized
INFO - 2021-12-04 14:16:42 --> Language Class Initialized
INFO - 2021-12-04 14:16:42 --> Loader Class Initialized
INFO - 2021-12-04 14:16:42 --> Helper loaded: url_helper
INFO - 2021-12-04 14:16:42 --> Helper loaded: form_helper
INFO - 2021-12-04 14:16:42 --> Helper loaded: common_helper
INFO - 2021-12-04 14:16:42 --> Database Driver Class Initialized
DEBUG - 2021-12-04 14:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 14:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 14:16:42 --> Controller Class Initialized
INFO - 2021-12-04 14:16:42 --> Form Validation Class Initialized
DEBUG - 2021-12-04 14:16:42 --> Encrypt Class Initialized
DEBUG - 2021-12-04 14:16:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 14:16:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 14:16:42 --> Email Class Initialized
INFO - 2021-12-04 14:16:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 14:16:42 --> Calendar Class Initialized
INFO - 2021-12-04 14:16:42 --> Model "Login_model" initialized
ERROR - 2021-12-04 14:16:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 14:16:43 --> Config Class Initialized
INFO - 2021-12-04 14:16:43 --> Hooks Class Initialized
DEBUG - 2021-12-04 14:16:43 --> UTF-8 Support Enabled
INFO - 2021-12-04 14:16:43 --> Utf8 Class Initialized
INFO - 2021-12-04 14:16:43 --> URI Class Initialized
INFO - 2021-12-04 14:16:43 --> Router Class Initialized
INFO - 2021-12-04 14:16:43 --> Output Class Initialized
INFO - 2021-12-04 14:16:43 --> Security Class Initialized
DEBUG - 2021-12-04 14:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 14:16:43 --> Input Class Initialized
INFO - 2021-12-04 14:16:43 --> Language Class Initialized
INFO - 2021-12-04 14:16:43 --> Loader Class Initialized
INFO - 2021-12-04 14:16:43 --> Helper loaded: url_helper
INFO - 2021-12-04 14:16:43 --> Helper loaded: form_helper
INFO - 2021-12-04 14:16:43 --> Helper loaded: common_helper
INFO - 2021-12-04 14:16:43 --> Database Driver Class Initialized
DEBUG - 2021-12-04 14:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 14:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 14:16:43 --> Controller Class Initialized
INFO - 2021-12-04 14:16:43 --> Form Validation Class Initialized
DEBUG - 2021-12-04 14:16:43 --> Encrypt Class Initialized
DEBUG - 2021-12-04 14:16:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 14:16:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 14:16:43 --> Email Class Initialized
INFO - 2021-12-04 14:16:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 14:16:43 --> Calendar Class Initialized
INFO - 2021-12-04 14:16:43 --> Model "Login_model" initialized
ERROR - 2021-12-04 14:16:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 14:16:44 --> Config Class Initialized
INFO - 2021-12-04 14:16:44 --> Hooks Class Initialized
DEBUG - 2021-12-04 14:16:44 --> UTF-8 Support Enabled
INFO - 2021-12-04 14:16:44 --> Utf8 Class Initialized
INFO - 2021-12-04 14:16:44 --> URI Class Initialized
DEBUG - 2021-12-04 14:16:44 --> No URI present. Default controller set.
INFO - 2021-12-04 14:16:44 --> Router Class Initialized
INFO - 2021-12-04 14:16:44 --> Output Class Initialized
INFO - 2021-12-04 14:16:44 --> Security Class Initialized
DEBUG - 2021-12-04 14:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 14:16:44 --> Input Class Initialized
INFO - 2021-12-04 14:16:44 --> Language Class Initialized
INFO - 2021-12-04 14:16:44 --> Loader Class Initialized
INFO - 2021-12-04 14:16:44 --> Helper loaded: url_helper
INFO - 2021-12-04 14:16:44 --> Helper loaded: form_helper
INFO - 2021-12-04 14:16:44 --> Helper loaded: common_helper
INFO - 2021-12-04 14:16:44 --> Database Driver Class Initialized
DEBUG - 2021-12-04 14:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 14:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 14:16:44 --> Controller Class Initialized
INFO - 2021-12-04 14:16:44 --> Form Validation Class Initialized
DEBUG - 2021-12-04 14:16:44 --> Encrypt Class Initialized
DEBUG - 2021-12-04 14:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 14:16:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 14:16:44 --> Email Class Initialized
INFO - 2021-12-04 14:16:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 14:16:44 --> Calendar Class Initialized
INFO - 2021-12-04 14:16:44 --> Model "Login_model" initialized
INFO - 2021-12-04 14:16:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 14:16:44 --> Final output sent to browser
DEBUG - 2021-12-04 14:16:44 --> Total execution time: 0.0274
ERROR - 2021-12-04 18:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 18:53:29 --> Config Class Initialized
INFO - 2021-12-04 18:53:29 --> Hooks Class Initialized
DEBUG - 2021-12-04 18:53:29 --> UTF-8 Support Enabled
INFO - 2021-12-04 18:53:29 --> Utf8 Class Initialized
INFO - 2021-12-04 18:53:29 --> URI Class Initialized
DEBUG - 2021-12-04 18:53:29 --> No URI present. Default controller set.
INFO - 2021-12-04 18:53:29 --> Router Class Initialized
INFO - 2021-12-04 18:53:29 --> Output Class Initialized
INFO - 2021-12-04 18:53:29 --> Security Class Initialized
DEBUG - 2021-12-04 18:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 18:53:29 --> Input Class Initialized
INFO - 2021-12-04 18:53:29 --> Language Class Initialized
INFO - 2021-12-04 18:53:29 --> Loader Class Initialized
INFO - 2021-12-04 18:53:29 --> Helper loaded: url_helper
INFO - 2021-12-04 18:53:29 --> Helper loaded: form_helper
INFO - 2021-12-04 18:53:29 --> Helper loaded: common_helper
INFO - 2021-12-04 18:53:29 --> Database Driver Class Initialized
DEBUG - 2021-12-04 18:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 18:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 18:53:29 --> Controller Class Initialized
INFO - 2021-12-04 18:53:29 --> Form Validation Class Initialized
DEBUG - 2021-12-04 18:53:29 --> Encrypt Class Initialized
DEBUG - 2021-12-04 18:53:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 18:53:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 18:53:29 --> Email Class Initialized
INFO - 2021-12-04 18:53:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 18:53:29 --> Calendar Class Initialized
INFO - 2021-12-04 18:53:29 --> Model "Login_model" initialized
INFO - 2021-12-04 18:53:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 18:53:29 --> Final output sent to browser
DEBUG - 2021-12-04 18:53:29 --> Total execution time: 0.0353
ERROR - 2021-12-04 19:58:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 19:58:09 --> Config Class Initialized
INFO - 2021-12-04 19:58:09 --> Hooks Class Initialized
DEBUG - 2021-12-04 19:58:09 --> UTF-8 Support Enabled
INFO - 2021-12-04 19:58:09 --> Utf8 Class Initialized
INFO - 2021-12-04 19:58:09 --> URI Class Initialized
INFO - 2021-12-04 19:58:09 --> Router Class Initialized
INFO - 2021-12-04 19:58:09 --> Output Class Initialized
INFO - 2021-12-04 19:58:09 --> Security Class Initialized
DEBUG - 2021-12-04 19:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 19:58:09 --> Input Class Initialized
INFO - 2021-12-04 19:58:09 --> Language Class Initialized
ERROR - 2021-12-04 19:58:09 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-12-04 19:58:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 19:58:10 --> Config Class Initialized
INFO - 2021-12-04 19:58:10 --> Hooks Class Initialized
DEBUG - 2021-12-04 19:58:10 --> UTF-8 Support Enabled
INFO - 2021-12-04 19:58:10 --> Utf8 Class Initialized
INFO - 2021-12-04 19:58:10 --> URI Class Initialized
INFO - 2021-12-04 19:58:10 --> Router Class Initialized
INFO - 2021-12-04 19:58:10 --> Output Class Initialized
INFO - 2021-12-04 19:58:10 --> Security Class Initialized
DEBUG - 2021-12-04 19:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 19:58:10 --> Input Class Initialized
INFO - 2021-12-04 19:58:10 --> Language Class Initialized
ERROR - 2021-12-04 19:58:10 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-12-04 19:58:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 19:58:10 --> Config Class Initialized
INFO - 2021-12-04 19:58:10 --> Hooks Class Initialized
DEBUG - 2021-12-04 19:58:10 --> UTF-8 Support Enabled
INFO - 2021-12-04 19:58:10 --> Utf8 Class Initialized
INFO - 2021-12-04 19:58:10 --> URI Class Initialized
DEBUG - 2021-12-04 19:58:10 --> No URI present. Default controller set.
INFO - 2021-12-04 19:58:10 --> Router Class Initialized
INFO - 2021-12-04 19:58:10 --> Output Class Initialized
INFO - 2021-12-04 19:58:10 --> Security Class Initialized
DEBUG - 2021-12-04 19:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 19:58:10 --> Input Class Initialized
INFO - 2021-12-04 19:58:10 --> Language Class Initialized
INFO - 2021-12-04 19:58:10 --> Loader Class Initialized
INFO - 2021-12-04 19:58:10 --> Helper loaded: url_helper
INFO - 2021-12-04 19:58:10 --> Helper loaded: form_helper
INFO - 2021-12-04 19:58:10 --> Helper loaded: common_helper
INFO - 2021-12-04 19:58:10 --> Database Driver Class Initialized
DEBUG - 2021-12-04 19:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 19:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 19:58:10 --> Controller Class Initialized
INFO - 2021-12-04 19:58:10 --> Form Validation Class Initialized
DEBUG - 2021-12-04 19:58:10 --> Encrypt Class Initialized
DEBUG - 2021-12-04 19:58:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 19:58:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 19:58:10 --> Email Class Initialized
INFO - 2021-12-04 19:58:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 19:58:10 --> Calendar Class Initialized
INFO - 2021-12-04 19:58:10 --> Model "Login_model" initialized
INFO - 2021-12-04 19:58:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 19:58:10 --> Final output sent to browser
DEBUG - 2021-12-04 19:58:10 --> Total execution time: 0.0236
ERROR - 2021-12-04 20:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 20:23:28 --> Config Class Initialized
INFO - 2021-12-04 20:23:28 --> Hooks Class Initialized
DEBUG - 2021-12-04 20:23:28 --> UTF-8 Support Enabled
INFO - 2021-12-04 20:23:28 --> Utf8 Class Initialized
INFO - 2021-12-04 20:23:28 --> URI Class Initialized
DEBUG - 2021-12-04 20:23:28 --> No URI present. Default controller set.
INFO - 2021-12-04 20:23:28 --> Router Class Initialized
INFO - 2021-12-04 20:23:28 --> Output Class Initialized
INFO - 2021-12-04 20:23:28 --> Security Class Initialized
DEBUG - 2021-12-04 20:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 20:23:28 --> Input Class Initialized
INFO - 2021-12-04 20:23:28 --> Language Class Initialized
INFO - 2021-12-04 20:23:28 --> Loader Class Initialized
INFO - 2021-12-04 20:23:28 --> Helper loaded: url_helper
INFO - 2021-12-04 20:23:28 --> Helper loaded: form_helper
INFO - 2021-12-04 20:23:28 --> Helper loaded: common_helper
INFO - 2021-12-04 20:23:28 --> Database Driver Class Initialized
DEBUG - 2021-12-04 20:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 20:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 20:23:28 --> Controller Class Initialized
INFO - 2021-12-04 20:23:28 --> Form Validation Class Initialized
DEBUG - 2021-12-04 20:23:28 --> Encrypt Class Initialized
DEBUG - 2021-12-04 20:23:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 20:23:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 20:23:28 --> Email Class Initialized
INFO - 2021-12-04 20:23:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 20:23:28 --> Calendar Class Initialized
INFO - 2021-12-04 20:23:28 --> Model "Login_model" initialized
INFO - 2021-12-04 20:23:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 20:23:28 --> Final output sent to browser
DEBUG - 2021-12-04 20:23:28 --> Total execution time: 0.0223
ERROR - 2021-12-04 21:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 21:19:36 --> Config Class Initialized
INFO - 2021-12-04 21:19:36 --> Hooks Class Initialized
DEBUG - 2021-12-04 21:19:36 --> UTF-8 Support Enabled
INFO - 2021-12-04 21:19:36 --> Utf8 Class Initialized
INFO - 2021-12-04 21:19:36 --> URI Class Initialized
DEBUG - 2021-12-04 21:19:36 --> No URI present. Default controller set.
INFO - 2021-12-04 21:19:36 --> Router Class Initialized
INFO - 2021-12-04 21:19:36 --> Output Class Initialized
INFO - 2021-12-04 21:19:36 --> Security Class Initialized
DEBUG - 2021-12-04 21:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 21:19:36 --> Input Class Initialized
INFO - 2021-12-04 21:19:36 --> Language Class Initialized
INFO - 2021-12-04 21:19:36 --> Loader Class Initialized
INFO - 2021-12-04 21:19:36 --> Helper loaded: url_helper
INFO - 2021-12-04 21:19:36 --> Helper loaded: form_helper
INFO - 2021-12-04 21:19:36 --> Helper loaded: common_helper
INFO - 2021-12-04 21:19:36 --> Database Driver Class Initialized
DEBUG - 2021-12-04 21:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 21:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 21:19:37 --> Controller Class Initialized
INFO - 2021-12-04 21:19:37 --> Form Validation Class Initialized
DEBUG - 2021-12-04 21:19:37 --> Encrypt Class Initialized
DEBUG - 2021-12-04 21:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 21:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 21:19:37 --> Email Class Initialized
INFO - 2021-12-04 21:19:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 21:19:37 --> Calendar Class Initialized
INFO - 2021-12-04 21:19:37 --> Model "Login_model" initialized
INFO - 2021-12-04 21:19:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 21:19:37 --> Final output sent to browser
DEBUG - 2021-12-04 21:19:37 --> Total execution time: 0.7765
ERROR - 2021-12-04 23:29:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:29:55 --> Config Class Initialized
INFO - 2021-12-04 23:29:55 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:29:55 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:29:55 --> Utf8 Class Initialized
INFO - 2021-12-04 23:29:55 --> URI Class Initialized
DEBUG - 2021-12-04 23:29:55 --> No URI present. Default controller set.
INFO - 2021-12-04 23:29:55 --> Router Class Initialized
INFO - 2021-12-04 23:29:55 --> Output Class Initialized
INFO - 2021-12-04 23:29:55 --> Security Class Initialized
DEBUG - 2021-12-04 23:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:29:55 --> Input Class Initialized
INFO - 2021-12-04 23:29:55 --> Language Class Initialized
INFO - 2021-12-04 23:29:55 --> Loader Class Initialized
INFO - 2021-12-04 23:29:55 --> Helper loaded: url_helper
INFO - 2021-12-04 23:29:55 --> Helper loaded: form_helper
INFO - 2021-12-04 23:29:55 --> Helper loaded: common_helper
INFO - 2021-12-04 23:29:55 --> Database Driver Class Initialized
DEBUG - 2021-12-04 23:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 23:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 23:29:55 --> Controller Class Initialized
INFO - 2021-12-04 23:29:55 --> Form Validation Class Initialized
DEBUG - 2021-12-04 23:29:55 --> Encrypt Class Initialized
DEBUG - 2021-12-04 23:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 23:29:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 23:29:55 --> Email Class Initialized
INFO - 2021-12-04 23:29:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 23:29:55 --> Calendar Class Initialized
INFO - 2021-12-04 23:29:55 --> Model "Login_model" initialized
INFO - 2021-12-04 23:29:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 23:29:55 --> Final output sent to browser
DEBUG - 2021-12-04 23:29:55 --> Total execution time: 0.0241
ERROR - 2021-12-04 23:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:29:56 --> Config Class Initialized
INFO - 2021-12-04 23:29:56 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:29:56 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:29:56 --> Utf8 Class Initialized
INFO - 2021-12-04 23:29:56 --> URI Class Initialized
DEBUG - 2021-12-04 23:29:56 --> No URI present. Default controller set.
INFO - 2021-12-04 23:29:56 --> Router Class Initialized
INFO - 2021-12-04 23:29:56 --> Output Class Initialized
INFO - 2021-12-04 23:29:56 --> Security Class Initialized
DEBUG - 2021-12-04 23:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:29:56 --> Input Class Initialized
INFO - 2021-12-04 23:29:56 --> Language Class Initialized
INFO - 2021-12-04 23:29:56 --> Loader Class Initialized
INFO - 2021-12-04 23:29:56 --> Helper loaded: url_helper
INFO - 2021-12-04 23:29:56 --> Helper loaded: form_helper
INFO - 2021-12-04 23:29:56 --> Helper loaded: common_helper
INFO - 2021-12-04 23:29:56 --> Database Driver Class Initialized
DEBUG - 2021-12-04 23:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 23:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 23:29:56 --> Controller Class Initialized
INFO - 2021-12-04 23:29:56 --> Form Validation Class Initialized
DEBUG - 2021-12-04 23:29:56 --> Encrypt Class Initialized
DEBUG - 2021-12-04 23:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 23:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 23:29:56 --> Email Class Initialized
INFO - 2021-12-04 23:29:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 23:29:56 --> Calendar Class Initialized
INFO - 2021-12-04 23:29:56 --> Model "Login_model" initialized
INFO - 2021-12-04 23:29:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 23:29:56 --> Final output sent to browser
DEBUG - 2021-12-04 23:29:56 --> Total execution time: 0.0225
ERROR - 2021-12-04 23:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:29:56 --> Config Class Initialized
INFO - 2021-12-04 23:29:56 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:29:56 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:29:56 --> Utf8 Class Initialized
INFO - 2021-12-04 23:29:56 --> URI Class Initialized
INFO - 2021-12-04 23:29:56 --> Router Class Initialized
INFO - 2021-12-04 23:29:56 --> Output Class Initialized
INFO - 2021-12-04 23:29:56 --> Security Class Initialized
DEBUG - 2021-12-04 23:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:29:56 --> Input Class Initialized
INFO - 2021-12-04 23:29:56 --> Language Class Initialized
ERROR - 2021-12-04 23:29:56 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-04 23:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:29:57 --> Config Class Initialized
INFO - 2021-12-04 23:29:57 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:29:57 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:29:57 --> Utf8 Class Initialized
INFO - 2021-12-04 23:29:57 --> URI Class Initialized
DEBUG - 2021-12-04 23:29:57 --> No URI present. Default controller set.
INFO - 2021-12-04 23:29:57 --> Router Class Initialized
INFO - 2021-12-04 23:29:57 --> Output Class Initialized
INFO - 2021-12-04 23:29:57 --> Security Class Initialized
DEBUG - 2021-12-04 23:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:29:57 --> Input Class Initialized
INFO - 2021-12-04 23:29:57 --> Language Class Initialized
INFO - 2021-12-04 23:29:57 --> Loader Class Initialized
INFO - 2021-12-04 23:29:57 --> Helper loaded: url_helper
INFO - 2021-12-04 23:29:57 --> Helper loaded: form_helper
INFO - 2021-12-04 23:29:57 --> Helper loaded: common_helper
INFO - 2021-12-04 23:29:57 --> Database Driver Class Initialized
DEBUG - 2021-12-04 23:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 23:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 23:29:57 --> Controller Class Initialized
INFO - 2021-12-04 23:29:57 --> Form Validation Class Initialized
DEBUG - 2021-12-04 23:29:57 --> Encrypt Class Initialized
DEBUG - 2021-12-04 23:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 23:29:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 23:29:57 --> Email Class Initialized
INFO - 2021-12-04 23:29:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 23:29:57 --> Calendar Class Initialized
INFO - 2021-12-04 23:29:57 --> Model "Login_model" initialized
INFO - 2021-12-04 23:29:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 23:29:57 --> Final output sent to browser
DEBUG - 2021-12-04 23:29:57 --> Total execution time: 0.0219
ERROR - 2021-12-04 23:29:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:29:58 --> Config Class Initialized
INFO - 2021-12-04 23:29:58 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:29:58 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:29:58 --> Utf8 Class Initialized
INFO - 2021-12-04 23:29:58 --> URI Class Initialized
INFO - 2021-12-04 23:29:58 --> Router Class Initialized
INFO - 2021-12-04 23:29:58 --> Output Class Initialized
INFO - 2021-12-04 23:29:58 --> Security Class Initialized
DEBUG - 2021-12-04 23:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:29:58 --> Input Class Initialized
INFO - 2021-12-04 23:29:58 --> Language Class Initialized
ERROR - 2021-12-04 23:29:58 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-04 23:29:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:29:58 --> Config Class Initialized
INFO - 2021-12-04 23:29:58 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:29:58 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:29:58 --> Utf8 Class Initialized
INFO - 2021-12-04 23:29:58 --> URI Class Initialized
INFO - 2021-12-04 23:29:58 --> Router Class Initialized
INFO - 2021-12-04 23:29:58 --> Output Class Initialized
INFO - 2021-12-04 23:29:58 --> Security Class Initialized
DEBUG - 2021-12-04 23:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:29:58 --> Input Class Initialized
INFO - 2021-12-04 23:29:58 --> Language Class Initialized
ERROR - 2021-12-04 23:29:58 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-04 23:29:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:29:59 --> Config Class Initialized
INFO - 2021-12-04 23:29:59 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:29:59 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:29:59 --> Utf8 Class Initialized
INFO - 2021-12-04 23:29:59 --> URI Class Initialized
INFO - 2021-12-04 23:29:59 --> Router Class Initialized
INFO - 2021-12-04 23:29:59 --> Output Class Initialized
INFO - 2021-12-04 23:29:59 --> Security Class Initialized
DEBUG - 2021-12-04 23:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:29:59 --> Input Class Initialized
INFO - 2021-12-04 23:29:59 --> Language Class Initialized
ERROR - 2021-12-04 23:29:59 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-04 23:29:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:29:59 --> Config Class Initialized
INFO - 2021-12-04 23:29:59 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:29:59 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:29:59 --> Utf8 Class Initialized
INFO - 2021-12-04 23:29:59 --> URI Class Initialized
INFO - 2021-12-04 23:29:59 --> Router Class Initialized
INFO - 2021-12-04 23:29:59 --> Output Class Initialized
INFO - 2021-12-04 23:29:59 --> Security Class Initialized
DEBUG - 2021-12-04 23:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:29:59 --> Input Class Initialized
INFO - 2021-12-04 23:29:59 --> Language Class Initialized
ERROR - 2021-12-04 23:29:59 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-04 23:30:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:00 --> Config Class Initialized
INFO - 2021-12-04 23:30:00 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:00 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:00 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:00 --> URI Class Initialized
INFO - 2021-12-04 23:30:00 --> Router Class Initialized
INFO - 2021-12-04 23:30:00 --> Output Class Initialized
INFO - 2021-12-04 23:30:00 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:00 --> Input Class Initialized
INFO - 2021-12-04 23:30:00 --> Language Class Initialized
ERROR - 2021-12-04 23:30:00 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-04 23:30:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:00 --> Config Class Initialized
INFO - 2021-12-04 23:30:00 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:00 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:00 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:00 --> URI Class Initialized
INFO - 2021-12-04 23:30:00 --> Router Class Initialized
INFO - 2021-12-04 23:30:00 --> Output Class Initialized
INFO - 2021-12-04 23:30:00 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:00 --> Input Class Initialized
INFO - 2021-12-04 23:30:00 --> Language Class Initialized
ERROR - 2021-12-04 23:30:00 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-04 23:30:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:01 --> Config Class Initialized
INFO - 2021-12-04 23:30:01 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:01 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:01 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:01 --> URI Class Initialized
INFO - 2021-12-04 23:30:01 --> Router Class Initialized
INFO - 2021-12-04 23:30:01 --> Output Class Initialized
INFO - 2021-12-04 23:30:01 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:01 --> Input Class Initialized
INFO - 2021-12-04 23:30:01 --> Language Class Initialized
ERROR - 2021-12-04 23:30:01 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-12-04 23:30:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:01 --> Config Class Initialized
INFO - 2021-12-04 23:30:01 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:01 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:01 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:01 --> URI Class Initialized
INFO - 2021-12-04 23:30:01 --> Router Class Initialized
INFO - 2021-12-04 23:30:01 --> Output Class Initialized
INFO - 2021-12-04 23:30:01 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:01 --> Input Class Initialized
INFO - 2021-12-04 23:30:01 --> Language Class Initialized
ERROR - 2021-12-04 23:30:01 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-04 23:30:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:02 --> Config Class Initialized
INFO - 2021-12-04 23:30:02 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:02 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:02 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:02 --> URI Class Initialized
INFO - 2021-12-04 23:30:02 --> Router Class Initialized
INFO - 2021-12-04 23:30:02 --> Output Class Initialized
INFO - 2021-12-04 23:30:02 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:02 --> Input Class Initialized
INFO - 2021-12-04 23:30:02 --> Language Class Initialized
ERROR - 2021-12-04 23:30:02 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-04 23:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:03 --> Config Class Initialized
INFO - 2021-12-04 23:30:03 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:03 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:03 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:03 --> URI Class Initialized
INFO - 2021-12-04 23:30:03 --> Router Class Initialized
INFO - 2021-12-04 23:30:03 --> Output Class Initialized
INFO - 2021-12-04 23:30:03 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:03 --> Input Class Initialized
INFO - 2021-12-04 23:30:03 --> Language Class Initialized
ERROR - 2021-12-04 23:30:03 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-04 23:30:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:05 --> Config Class Initialized
INFO - 2021-12-04 23:30:05 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:05 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:05 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:05 --> URI Class Initialized
INFO - 2021-12-04 23:30:05 --> Router Class Initialized
INFO - 2021-12-04 23:30:05 --> Output Class Initialized
INFO - 2021-12-04 23:30:05 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:05 --> Input Class Initialized
INFO - 2021-12-04 23:30:05 --> Language Class Initialized
ERROR - 2021-12-04 23:30:05 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-04 23:30:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:05 --> Config Class Initialized
INFO - 2021-12-04 23:30:05 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:05 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:05 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:05 --> URI Class Initialized
INFO - 2021-12-04 23:30:05 --> Router Class Initialized
INFO - 2021-12-04 23:30:05 --> Output Class Initialized
INFO - 2021-12-04 23:30:05 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:05 --> Input Class Initialized
INFO - 2021-12-04 23:30:05 --> Language Class Initialized
ERROR - 2021-12-04 23:30:05 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-04 23:30:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:06 --> Config Class Initialized
INFO - 2021-12-04 23:30:06 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:06 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:06 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:06 --> URI Class Initialized
INFO - 2021-12-04 23:30:06 --> Router Class Initialized
INFO - 2021-12-04 23:30:06 --> Output Class Initialized
INFO - 2021-12-04 23:30:06 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:06 --> Input Class Initialized
INFO - 2021-12-04 23:30:06 --> Language Class Initialized
ERROR - 2021-12-04 23:30:06 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-04 23:30:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:06 --> Config Class Initialized
INFO - 2021-12-04 23:30:06 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:06 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:06 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:06 --> URI Class Initialized
INFO - 2021-12-04 23:30:06 --> Router Class Initialized
INFO - 2021-12-04 23:30:06 --> Output Class Initialized
INFO - 2021-12-04 23:30:06 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:06 --> Input Class Initialized
INFO - 2021-12-04 23:30:06 --> Language Class Initialized
ERROR - 2021-12-04 23:30:06 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-04 23:30:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:30:07 --> Config Class Initialized
INFO - 2021-12-04 23:30:07 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:30:07 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:30:07 --> Utf8 Class Initialized
INFO - 2021-12-04 23:30:07 --> URI Class Initialized
INFO - 2021-12-04 23:30:07 --> Router Class Initialized
INFO - 2021-12-04 23:30:07 --> Output Class Initialized
INFO - 2021-12-04 23:30:07 --> Security Class Initialized
DEBUG - 2021-12-04 23:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:30:07 --> Input Class Initialized
INFO - 2021-12-04 23:30:07 --> Language Class Initialized
ERROR - 2021-12-04 23:30:07 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-04 23:41:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-04 23:41:37 --> Config Class Initialized
INFO - 2021-12-04 23:41:37 --> Hooks Class Initialized
DEBUG - 2021-12-04 23:41:37 --> UTF-8 Support Enabled
INFO - 2021-12-04 23:41:37 --> Utf8 Class Initialized
INFO - 2021-12-04 23:41:37 --> URI Class Initialized
DEBUG - 2021-12-04 23:41:37 --> No URI present. Default controller set.
INFO - 2021-12-04 23:41:37 --> Router Class Initialized
INFO - 2021-12-04 23:41:37 --> Output Class Initialized
INFO - 2021-12-04 23:41:37 --> Security Class Initialized
DEBUG - 2021-12-04 23:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-04 23:41:37 --> Input Class Initialized
INFO - 2021-12-04 23:41:37 --> Language Class Initialized
INFO - 2021-12-04 23:41:37 --> Loader Class Initialized
INFO - 2021-12-04 23:41:37 --> Helper loaded: url_helper
INFO - 2021-12-04 23:41:37 --> Helper loaded: form_helper
INFO - 2021-12-04 23:41:37 --> Helper loaded: common_helper
INFO - 2021-12-04 23:41:37 --> Database Driver Class Initialized
DEBUG - 2021-12-04 23:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-04 23:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-04 23:41:37 --> Controller Class Initialized
INFO - 2021-12-04 23:41:37 --> Form Validation Class Initialized
DEBUG - 2021-12-04 23:41:37 --> Encrypt Class Initialized
DEBUG - 2021-12-04 23:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-04 23:41:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-04 23:41:37 --> Email Class Initialized
INFO - 2021-12-04 23:41:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-04 23:41:37 --> Calendar Class Initialized
INFO - 2021-12-04 23:41:37 --> Model "Login_model" initialized
INFO - 2021-12-04 23:41:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-04 23:41:37 --> Final output sent to browser
DEBUG - 2021-12-04 23:41:37 --> Total execution time: 0.0230
