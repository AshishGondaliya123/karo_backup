<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-31 01:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 01:13:06 --> Config Class Initialized
INFO - 2022-01-31 01:13:06 --> Hooks Class Initialized
DEBUG - 2022-01-31 01:13:06 --> UTF-8 Support Enabled
INFO - 2022-01-31 01:13:06 --> Utf8 Class Initialized
INFO - 2022-01-31 01:13:06 --> URI Class Initialized
DEBUG - 2022-01-31 01:13:06 --> No URI present. Default controller set.
INFO - 2022-01-31 01:13:06 --> Router Class Initialized
INFO - 2022-01-31 01:13:06 --> Output Class Initialized
INFO - 2022-01-31 01:13:06 --> Security Class Initialized
DEBUG - 2022-01-31 01:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 01:13:06 --> Input Class Initialized
INFO - 2022-01-31 01:13:06 --> Language Class Initialized
INFO - 2022-01-31 01:13:06 --> Loader Class Initialized
INFO - 2022-01-31 01:13:06 --> Helper loaded: url_helper
INFO - 2022-01-31 01:13:06 --> Helper loaded: form_helper
INFO - 2022-01-31 01:13:06 --> Helper loaded: common_helper
INFO - 2022-01-31 01:13:06 --> Database Driver Class Initialized
DEBUG - 2022-01-31 01:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 01:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 01:13:06 --> Controller Class Initialized
INFO - 2022-01-31 01:13:06 --> Form Validation Class Initialized
DEBUG - 2022-01-31 01:13:06 --> Encrypt Class Initialized
DEBUG - 2022-01-31 01:13:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 01:13:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 01:13:06 --> Email Class Initialized
INFO - 2022-01-31 01:13:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 01:13:06 --> Calendar Class Initialized
INFO - 2022-01-31 01:13:06 --> Model "Login_model" initialized
INFO - 2022-01-31 01:13:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 01:13:06 --> Final output sent to browser
DEBUG - 2022-01-31 01:13:06 --> Total execution time: 0.0244
ERROR - 2022-01-31 10:05:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 10:05:55 --> Config Class Initialized
INFO - 2022-01-31 10:05:55 --> Hooks Class Initialized
DEBUG - 2022-01-31 10:05:55 --> UTF-8 Support Enabled
INFO - 2022-01-31 10:05:55 --> Utf8 Class Initialized
INFO - 2022-01-31 10:05:55 --> URI Class Initialized
DEBUG - 2022-01-31 10:05:55 --> No URI present. Default controller set.
INFO - 2022-01-31 10:05:55 --> Router Class Initialized
INFO - 2022-01-31 10:05:55 --> Output Class Initialized
INFO - 2022-01-31 10:05:55 --> Security Class Initialized
DEBUG - 2022-01-31 10:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 10:05:55 --> Input Class Initialized
INFO - 2022-01-31 10:05:55 --> Language Class Initialized
INFO - 2022-01-31 10:05:55 --> Loader Class Initialized
INFO - 2022-01-31 10:05:55 --> Helper loaded: url_helper
INFO - 2022-01-31 10:05:55 --> Helper loaded: form_helper
INFO - 2022-01-31 10:05:55 --> Helper loaded: common_helper
INFO - 2022-01-31 10:05:55 --> Database Driver Class Initialized
DEBUG - 2022-01-31 10:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 10:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 10:05:55 --> Controller Class Initialized
INFO - 2022-01-31 10:05:55 --> Form Validation Class Initialized
DEBUG - 2022-01-31 10:05:55 --> Encrypt Class Initialized
DEBUG - 2022-01-31 10:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:05:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 10:05:55 --> Email Class Initialized
INFO - 2022-01-31 10:05:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 10:05:55 --> Calendar Class Initialized
INFO - 2022-01-31 10:05:55 --> Model "Login_model" initialized
INFO - 2022-01-31 10:05:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 10:05:55 --> Final output sent to browser
DEBUG - 2022-01-31 10:05:55 --> Total execution time: 0.0952
ERROR - 2022-01-31 10:17:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 10:17:49 --> Config Class Initialized
INFO - 2022-01-31 10:17:49 --> Hooks Class Initialized
DEBUG - 2022-01-31 10:17:49 --> UTF-8 Support Enabled
INFO - 2022-01-31 10:17:49 --> Utf8 Class Initialized
INFO - 2022-01-31 10:17:49 --> URI Class Initialized
DEBUG - 2022-01-31 10:17:49 --> No URI present. Default controller set.
INFO - 2022-01-31 10:17:49 --> Router Class Initialized
INFO - 2022-01-31 10:17:49 --> Output Class Initialized
INFO - 2022-01-31 10:17:49 --> Security Class Initialized
DEBUG - 2022-01-31 10:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 10:17:49 --> Input Class Initialized
INFO - 2022-01-31 10:17:49 --> Language Class Initialized
INFO - 2022-01-31 10:17:49 --> Loader Class Initialized
INFO - 2022-01-31 10:17:49 --> Helper loaded: url_helper
INFO - 2022-01-31 10:17:49 --> Helper loaded: form_helper
INFO - 2022-01-31 10:17:49 --> Helper loaded: common_helper
INFO - 2022-01-31 10:17:49 --> Database Driver Class Initialized
DEBUG - 2022-01-31 10:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 10:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 10:17:49 --> Controller Class Initialized
INFO - 2022-01-31 10:17:49 --> Form Validation Class Initialized
DEBUG - 2022-01-31 10:17:49 --> Encrypt Class Initialized
DEBUG - 2022-01-31 10:17:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:17:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 10:17:49 --> Email Class Initialized
INFO - 2022-01-31 10:17:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 10:17:49 --> Calendar Class Initialized
INFO - 2022-01-31 10:17:49 --> Model "Login_model" initialized
INFO - 2022-01-31 10:17:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 10:17:49 --> Final output sent to browser
DEBUG - 2022-01-31 10:17:49 --> Total execution time: 0.0358
ERROR - 2022-01-31 10:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 10:17:51 --> Config Class Initialized
INFO - 2022-01-31 10:17:51 --> Hooks Class Initialized
DEBUG - 2022-01-31 10:17:51 --> UTF-8 Support Enabled
INFO - 2022-01-31 10:17:51 --> Utf8 Class Initialized
INFO - 2022-01-31 10:17:51 --> URI Class Initialized
INFO - 2022-01-31 10:17:51 --> Router Class Initialized
INFO - 2022-01-31 10:17:51 --> Output Class Initialized
INFO - 2022-01-31 10:17:51 --> Security Class Initialized
DEBUG - 2022-01-31 10:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 10:17:51 --> Input Class Initialized
INFO - 2022-01-31 10:17:51 --> Language Class Initialized
ERROR - 2022-01-31 10:17:51 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-31 10:17:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 10:17:52 --> Config Class Initialized
INFO - 2022-01-31 10:17:52 --> Hooks Class Initialized
DEBUG - 2022-01-31 10:17:52 --> UTF-8 Support Enabled
INFO - 2022-01-31 10:17:52 --> Utf8 Class Initialized
INFO - 2022-01-31 10:17:52 --> URI Class Initialized
DEBUG - 2022-01-31 10:17:52 --> No URI present. Default controller set.
INFO - 2022-01-31 10:17:52 --> Router Class Initialized
INFO - 2022-01-31 10:17:52 --> Output Class Initialized
INFO - 2022-01-31 10:17:52 --> Security Class Initialized
DEBUG - 2022-01-31 10:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 10:17:52 --> Input Class Initialized
INFO - 2022-01-31 10:17:52 --> Language Class Initialized
INFO - 2022-01-31 10:17:52 --> Loader Class Initialized
INFO - 2022-01-31 10:17:52 --> Helper loaded: url_helper
INFO - 2022-01-31 10:17:52 --> Helper loaded: form_helper
INFO - 2022-01-31 10:17:52 --> Helper loaded: common_helper
INFO - 2022-01-31 10:17:52 --> Database Driver Class Initialized
DEBUG - 2022-01-31 10:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 10:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 10:17:52 --> Controller Class Initialized
INFO - 2022-01-31 10:17:52 --> Form Validation Class Initialized
DEBUG - 2022-01-31 10:17:52 --> Encrypt Class Initialized
DEBUG - 2022-01-31 10:17:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 10:17:52 --> Email Class Initialized
INFO - 2022-01-31 10:17:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 10:17:52 --> Calendar Class Initialized
INFO - 2022-01-31 10:17:52 --> Model "Login_model" initialized
INFO - 2022-01-31 10:17:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 10:17:52 --> Final output sent to browser
DEBUG - 2022-01-31 10:17:52 --> Total execution time: 0.0332
ERROR - 2022-01-31 10:17:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 10:17:54 --> Config Class Initialized
INFO - 2022-01-31 10:17:54 --> Hooks Class Initialized
DEBUG - 2022-01-31 10:17:54 --> UTF-8 Support Enabled
INFO - 2022-01-31 10:17:54 --> Utf8 Class Initialized
INFO - 2022-01-31 10:17:54 --> URI Class Initialized
INFO - 2022-01-31 10:17:54 --> Router Class Initialized
INFO - 2022-01-31 10:17:54 --> Output Class Initialized
INFO - 2022-01-31 10:17:54 --> Security Class Initialized
DEBUG - 2022-01-31 10:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 10:17:54 --> Input Class Initialized
INFO - 2022-01-31 10:17:54 --> Language Class Initialized
ERROR - 2022-01-31 10:17:54 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-01-31 10:17:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 10:17:55 --> Config Class Initialized
INFO - 2022-01-31 10:17:55 --> Hooks Class Initialized
DEBUG - 2022-01-31 10:17:55 --> UTF-8 Support Enabled
INFO - 2022-01-31 10:17:55 --> Utf8 Class Initialized
INFO - 2022-01-31 10:17:55 --> URI Class Initialized
DEBUG - 2022-01-31 10:17:55 --> No URI present. Default controller set.
INFO - 2022-01-31 10:17:55 --> Router Class Initialized
INFO - 2022-01-31 10:17:55 --> Output Class Initialized
INFO - 2022-01-31 10:17:55 --> Security Class Initialized
DEBUG - 2022-01-31 10:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 10:17:55 --> Input Class Initialized
INFO - 2022-01-31 10:17:55 --> Language Class Initialized
INFO - 2022-01-31 10:17:55 --> Loader Class Initialized
INFO - 2022-01-31 10:17:55 --> Helper loaded: url_helper
INFO - 2022-01-31 10:17:55 --> Helper loaded: form_helper
INFO - 2022-01-31 10:17:55 --> Helper loaded: common_helper
INFO - 2022-01-31 10:17:55 --> Database Driver Class Initialized
DEBUG - 2022-01-31 10:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 10:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 10:17:55 --> Controller Class Initialized
INFO - 2022-01-31 10:17:55 --> Form Validation Class Initialized
DEBUG - 2022-01-31 10:17:55 --> Encrypt Class Initialized
DEBUG - 2022-01-31 10:17:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:17:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 10:17:55 --> Email Class Initialized
INFO - 2022-01-31 10:17:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 10:17:55 --> Calendar Class Initialized
INFO - 2022-01-31 10:17:55 --> Model "Login_model" initialized
INFO - 2022-01-31 10:17:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 10:17:55 --> Final output sent to browser
DEBUG - 2022-01-31 10:17:55 --> Total execution time: 0.0347
ERROR - 2022-01-31 14:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 14:16:20 --> Config Class Initialized
INFO - 2022-01-31 14:16:20 --> Hooks Class Initialized
DEBUG - 2022-01-31 14:16:20 --> UTF-8 Support Enabled
INFO - 2022-01-31 14:16:20 --> Utf8 Class Initialized
INFO - 2022-01-31 14:16:20 --> URI Class Initialized
DEBUG - 2022-01-31 14:16:20 --> No URI present. Default controller set.
INFO - 2022-01-31 14:16:20 --> Router Class Initialized
INFO - 2022-01-31 14:16:20 --> Output Class Initialized
INFO - 2022-01-31 14:16:20 --> Security Class Initialized
DEBUG - 2022-01-31 14:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 14:16:20 --> Input Class Initialized
INFO - 2022-01-31 14:16:20 --> Language Class Initialized
INFO - 2022-01-31 14:16:20 --> Loader Class Initialized
INFO - 2022-01-31 14:16:20 --> Helper loaded: url_helper
INFO - 2022-01-31 14:16:20 --> Helper loaded: form_helper
INFO - 2022-01-31 14:16:20 --> Helper loaded: common_helper
INFO - 2022-01-31 14:16:20 --> Database Driver Class Initialized
DEBUG - 2022-01-31 14:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 14:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 14:16:20 --> Controller Class Initialized
INFO - 2022-01-31 14:16:20 --> Form Validation Class Initialized
DEBUG - 2022-01-31 14:16:20 --> Encrypt Class Initialized
DEBUG - 2022-01-31 14:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:16:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 14:16:20 --> Email Class Initialized
INFO - 2022-01-31 14:16:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 14:16:20 --> Calendar Class Initialized
INFO - 2022-01-31 14:16:20 --> Model "Login_model" initialized
INFO - 2022-01-31 14:16:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 14:16:20 --> Final output sent to browser
DEBUG - 2022-01-31 14:16:20 --> Total execution time: 0.0451
ERROR - 2022-01-31 14:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 14:16:24 --> Config Class Initialized
INFO - 2022-01-31 14:16:24 --> Hooks Class Initialized
DEBUG - 2022-01-31 14:16:24 --> UTF-8 Support Enabled
INFO - 2022-01-31 14:16:24 --> Utf8 Class Initialized
INFO - 2022-01-31 14:16:24 --> URI Class Initialized
INFO - 2022-01-31 14:16:24 --> Router Class Initialized
INFO - 2022-01-31 14:16:24 --> Output Class Initialized
INFO - 2022-01-31 14:16:24 --> Security Class Initialized
DEBUG - 2022-01-31 14:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 14:16:24 --> Input Class Initialized
INFO - 2022-01-31 14:16:24 --> Language Class Initialized
ERROR - 2022-01-31 14:16:24 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-31 14:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 14:17:27 --> Config Class Initialized
INFO - 2022-01-31 14:17:27 --> Hooks Class Initialized
DEBUG - 2022-01-31 14:17:27 --> UTF-8 Support Enabled
INFO - 2022-01-31 14:17:27 --> Utf8 Class Initialized
INFO - 2022-01-31 14:17:27 --> URI Class Initialized
INFO - 2022-01-31 14:17:27 --> Router Class Initialized
INFO - 2022-01-31 14:17:27 --> Output Class Initialized
INFO - 2022-01-31 14:17:27 --> Security Class Initialized
DEBUG - 2022-01-31 14:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 14:17:27 --> Input Class Initialized
INFO - 2022-01-31 14:17:27 --> Language Class Initialized
INFO - 2022-01-31 14:17:27 --> Loader Class Initialized
INFO - 2022-01-31 14:17:27 --> Helper loaded: url_helper
INFO - 2022-01-31 14:17:27 --> Helper loaded: form_helper
INFO - 2022-01-31 14:17:27 --> Helper loaded: common_helper
INFO - 2022-01-31 14:17:27 --> Database Driver Class Initialized
DEBUG - 2022-01-31 14:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 14:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 14:17:27 --> Controller Class Initialized
INFO - 2022-01-31 14:17:27 --> Form Validation Class Initialized
DEBUG - 2022-01-31 14:17:27 --> Encrypt Class Initialized
DEBUG - 2022-01-31 14:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:17:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 14:17:27 --> Email Class Initialized
INFO - 2022-01-31 14:17:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 14:17:27 --> Calendar Class Initialized
INFO - 2022-01-31 14:17:27 --> Model "Login_model" initialized
ERROR - 2022-01-31 14:17:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 14:17:28 --> Config Class Initialized
INFO - 2022-01-31 14:17:28 --> Hooks Class Initialized
DEBUG - 2022-01-31 14:17:28 --> UTF-8 Support Enabled
INFO - 2022-01-31 14:17:28 --> Utf8 Class Initialized
INFO - 2022-01-31 14:17:28 --> URI Class Initialized
INFO - 2022-01-31 14:17:28 --> Router Class Initialized
INFO - 2022-01-31 14:17:28 --> Output Class Initialized
INFO - 2022-01-31 14:17:28 --> Security Class Initialized
DEBUG - 2022-01-31 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 14:17:28 --> Input Class Initialized
INFO - 2022-01-31 14:17:28 --> Language Class Initialized
INFO - 2022-01-31 14:17:28 --> Loader Class Initialized
INFO - 2022-01-31 14:17:28 --> Helper loaded: url_helper
INFO - 2022-01-31 14:17:28 --> Helper loaded: form_helper
INFO - 2022-01-31 14:17:28 --> Helper loaded: common_helper
INFO - 2022-01-31 14:17:28 --> Database Driver Class Initialized
DEBUG - 2022-01-31 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 14:17:28 --> Controller Class Initialized
INFO - 2022-01-31 14:17:28 --> Form Validation Class Initialized
DEBUG - 2022-01-31 14:17:28 --> Encrypt Class Initialized
DEBUG - 2022-01-31 14:17:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 14:17:28 --> Email Class Initialized
INFO - 2022-01-31 14:17:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 14:17:28 --> Calendar Class Initialized
INFO - 2022-01-31 14:17:28 --> Model "Login_model" initialized
ERROR - 2022-01-31 14:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 14:17:29 --> Config Class Initialized
INFO - 2022-01-31 14:17:29 --> Hooks Class Initialized
DEBUG - 2022-01-31 14:17:29 --> UTF-8 Support Enabled
INFO - 2022-01-31 14:17:29 --> Utf8 Class Initialized
INFO - 2022-01-31 14:17:29 --> URI Class Initialized
INFO - 2022-01-31 14:17:29 --> Router Class Initialized
INFO - 2022-01-31 14:17:29 --> Output Class Initialized
INFO - 2022-01-31 14:17:29 --> Security Class Initialized
DEBUG - 2022-01-31 14:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 14:17:29 --> Input Class Initialized
INFO - 2022-01-31 14:17:29 --> Language Class Initialized
INFO - 2022-01-31 14:17:29 --> Loader Class Initialized
INFO - 2022-01-31 14:17:29 --> Helper loaded: url_helper
INFO - 2022-01-31 14:17:29 --> Helper loaded: form_helper
INFO - 2022-01-31 14:17:29 --> Helper loaded: common_helper
INFO - 2022-01-31 14:17:29 --> Database Driver Class Initialized
DEBUG - 2022-01-31 14:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 14:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 14:17:29 --> Controller Class Initialized
INFO - 2022-01-31 14:17:29 --> Form Validation Class Initialized
DEBUG - 2022-01-31 14:17:29 --> Encrypt Class Initialized
DEBUG - 2022-01-31 14:17:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 14:17:29 --> Email Class Initialized
INFO - 2022-01-31 14:17:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 14:17:29 --> Calendar Class Initialized
INFO - 2022-01-31 14:17:29 --> Model "Login_model" initialized
INFO - 2022-01-31 14:17:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 14:17:29 --> Final output sent to browser
DEBUG - 2022-01-31 14:17:29 --> Total execution time: 0.0324
ERROR - 2022-01-31 14:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 14:17:31 --> Config Class Initialized
INFO - 2022-01-31 14:17:31 --> Hooks Class Initialized
DEBUG - 2022-01-31 14:17:31 --> UTF-8 Support Enabled
INFO - 2022-01-31 14:17:31 --> Utf8 Class Initialized
INFO - 2022-01-31 14:17:31 --> URI Class Initialized
DEBUG - 2022-01-31 14:17:31 --> No URI present. Default controller set.
INFO - 2022-01-31 14:17:31 --> Router Class Initialized
INFO - 2022-01-31 14:17:31 --> Output Class Initialized
INFO - 2022-01-31 14:17:31 --> Security Class Initialized
DEBUG - 2022-01-31 14:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 14:17:31 --> Input Class Initialized
INFO - 2022-01-31 14:17:31 --> Language Class Initialized
INFO - 2022-01-31 14:17:31 --> Loader Class Initialized
INFO - 2022-01-31 14:17:31 --> Helper loaded: url_helper
INFO - 2022-01-31 14:17:31 --> Helper loaded: form_helper
INFO - 2022-01-31 14:17:31 --> Helper loaded: common_helper
INFO - 2022-01-31 14:17:31 --> Database Driver Class Initialized
DEBUG - 2022-01-31 14:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 14:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 14:17:31 --> Controller Class Initialized
INFO - 2022-01-31 14:17:31 --> Form Validation Class Initialized
DEBUG - 2022-01-31 14:17:31 --> Encrypt Class Initialized
DEBUG - 2022-01-31 14:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:17:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 14:17:31 --> Email Class Initialized
INFO - 2022-01-31 14:17:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 14:17:31 --> Calendar Class Initialized
INFO - 2022-01-31 14:17:31 --> Model "Login_model" initialized
INFO - 2022-01-31 14:17:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 14:17:31 --> Final output sent to browser
DEBUG - 2022-01-31 14:17:31 --> Total execution time: 0.0286
ERROR - 2022-01-31 15:24:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 15:24:05 --> Config Class Initialized
INFO - 2022-01-31 15:24:05 --> Hooks Class Initialized
DEBUG - 2022-01-31 15:24:05 --> UTF-8 Support Enabled
INFO - 2022-01-31 15:24:05 --> Utf8 Class Initialized
INFO - 2022-01-31 15:24:05 --> URI Class Initialized
DEBUG - 2022-01-31 15:24:05 --> No URI present. Default controller set.
INFO - 2022-01-31 15:24:05 --> Router Class Initialized
INFO - 2022-01-31 15:24:05 --> Output Class Initialized
INFO - 2022-01-31 15:24:05 --> Security Class Initialized
DEBUG - 2022-01-31 15:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 15:24:05 --> Input Class Initialized
INFO - 2022-01-31 15:24:05 --> Language Class Initialized
INFO - 2022-01-31 15:24:05 --> Loader Class Initialized
INFO - 2022-01-31 15:24:05 --> Helper loaded: url_helper
INFO - 2022-01-31 15:24:05 --> Helper loaded: form_helper
INFO - 2022-01-31 15:24:05 --> Helper loaded: common_helper
INFO - 2022-01-31 15:24:05 --> Database Driver Class Initialized
DEBUG - 2022-01-31 15:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 15:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 15:24:05 --> Controller Class Initialized
INFO - 2022-01-31 15:24:05 --> Form Validation Class Initialized
DEBUG - 2022-01-31 15:24:05 --> Encrypt Class Initialized
DEBUG - 2022-01-31 15:24:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:24:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 15:24:05 --> Email Class Initialized
INFO - 2022-01-31 15:24:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 15:24:05 --> Calendar Class Initialized
INFO - 2022-01-31 15:24:05 --> Model "Login_model" initialized
INFO - 2022-01-31 15:24:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 15:24:05 --> Final output sent to browser
DEBUG - 2022-01-31 15:24:05 --> Total execution time: 0.0239
ERROR - 2022-01-31 15:53:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 15:53:19 --> Config Class Initialized
INFO - 2022-01-31 15:53:19 --> Hooks Class Initialized
DEBUG - 2022-01-31 15:53:19 --> UTF-8 Support Enabled
INFO - 2022-01-31 15:53:19 --> Utf8 Class Initialized
INFO - 2022-01-31 15:53:19 --> URI Class Initialized
DEBUG - 2022-01-31 15:53:19 --> No URI present. Default controller set.
INFO - 2022-01-31 15:53:19 --> Router Class Initialized
INFO - 2022-01-31 15:53:19 --> Output Class Initialized
INFO - 2022-01-31 15:53:19 --> Security Class Initialized
DEBUG - 2022-01-31 15:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 15:53:19 --> Input Class Initialized
INFO - 2022-01-31 15:53:19 --> Language Class Initialized
INFO - 2022-01-31 15:53:19 --> Loader Class Initialized
INFO - 2022-01-31 15:53:19 --> Helper loaded: url_helper
INFO - 2022-01-31 15:53:19 --> Helper loaded: form_helper
INFO - 2022-01-31 15:53:19 --> Helper loaded: common_helper
INFO - 2022-01-31 15:53:19 --> Database Driver Class Initialized
DEBUG - 2022-01-31 15:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 15:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 15:53:19 --> Controller Class Initialized
INFO - 2022-01-31 15:53:19 --> Form Validation Class Initialized
DEBUG - 2022-01-31 15:53:19 --> Encrypt Class Initialized
DEBUG - 2022-01-31 15:53:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:53:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 15:53:19 --> Email Class Initialized
INFO - 2022-01-31 15:53:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 15:53:19 --> Calendar Class Initialized
INFO - 2022-01-31 15:53:19 --> Model "Login_model" initialized
INFO - 2022-01-31 15:53:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 15:53:19 --> Final output sent to browser
DEBUG - 2022-01-31 15:53:19 --> Total execution time: 0.0247
ERROR - 2022-01-31 16:28:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-31 16:28:31 --> Config Class Initialized
INFO - 2022-01-31 16:28:31 --> Hooks Class Initialized
DEBUG - 2022-01-31 16:28:31 --> UTF-8 Support Enabled
INFO - 2022-01-31 16:28:31 --> Utf8 Class Initialized
INFO - 2022-01-31 16:28:31 --> URI Class Initialized
DEBUG - 2022-01-31 16:28:31 --> No URI present. Default controller set.
INFO - 2022-01-31 16:28:31 --> Router Class Initialized
INFO - 2022-01-31 16:28:31 --> Output Class Initialized
INFO - 2022-01-31 16:28:31 --> Security Class Initialized
DEBUG - 2022-01-31 16:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-31 16:28:31 --> Input Class Initialized
INFO - 2022-01-31 16:28:31 --> Language Class Initialized
INFO - 2022-01-31 16:28:31 --> Loader Class Initialized
INFO - 2022-01-31 16:28:31 --> Helper loaded: url_helper
INFO - 2022-01-31 16:28:31 --> Helper loaded: form_helper
INFO - 2022-01-31 16:28:31 --> Helper loaded: common_helper
INFO - 2022-01-31 16:28:31 --> Database Driver Class Initialized
DEBUG - 2022-01-31 16:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-31 16:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-31 16:28:31 --> Controller Class Initialized
INFO - 2022-01-31 16:28:31 --> Form Validation Class Initialized
DEBUG - 2022-01-31 16:28:31 --> Encrypt Class Initialized
DEBUG - 2022-01-31 16:28:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:28:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-31 16:28:31 --> Email Class Initialized
INFO - 2022-01-31 16:28:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-31 16:28:31 --> Calendar Class Initialized
INFO - 2022-01-31 16:28:31 --> Model "Login_model" initialized
INFO - 2022-01-31 16:28:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-31 16:28:31 --> Final output sent to browser
DEBUG - 2022-01-31 16:28:31 --> Total execution time: 0.0246
