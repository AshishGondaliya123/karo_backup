<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-12 07:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 07:26:06 --> Config Class Initialized
INFO - 2022-02-12 07:26:06 --> Hooks Class Initialized
DEBUG - 2022-02-12 07:26:06 --> UTF-8 Support Enabled
INFO - 2022-02-12 07:26:06 --> Utf8 Class Initialized
INFO - 2022-02-12 07:26:06 --> URI Class Initialized
DEBUG - 2022-02-12 07:26:06 --> No URI present. Default controller set.
INFO - 2022-02-12 07:26:06 --> Router Class Initialized
INFO - 2022-02-12 07:26:06 --> Output Class Initialized
INFO - 2022-02-12 07:26:06 --> Security Class Initialized
DEBUG - 2022-02-12 07:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 07:26:06 --> Input Class Initialized
INFO - 2022-02-12 07:26:06 --> Language Class Initialized
INFO - 2022-02-12 07:26:06 --> Loader Class Initialized
INFO - 2022-02-12 07:26:06 --> Helper loaded: url_helper
INFO - 2022-02-12 07:26:06 --> Helper loaded: form_helper
INFO - 2022-02-12 07:26:06 --> Helper loaded: common_helper
INFO - 2022-02-12 07:26:06 --> Database Driver Class Initialized
DEBUG - 2022-02-12 07:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 07:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 07:26:06 --> Controller Class Initialized
INFO - 2022-02-12 07:26:06 --> Form Validation Class Initialized
DEBUG - 2022-02-12 07:26:06 --> Encrypt Class Initialized
DEBUG - 2022-02-12 07:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 07:26:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 07:26:06 --> Email Class Initialized
INFO - 2022-02-12 07:26:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 07:26:06 --> Calendar Class Initialized
INFO - 2022-02-12 07:26:06 --> Model "Login_model" initialized
INFO - 2022-02-12 07:26:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-12 07:26:06 --> Final output sent to browser
DEBUG - 2022-02-12 07:26:06 --> Total execution time: 0.0226
ERROR - 2022-02-12 07:53:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 07:53:51 --> Config Class Initialized
INFO - 2022-02-12 07:53:51 --> Hooks Class Initialized
DEBUG - 2022-02-12 07:53:51 --> UTF-8 Support Enabled
INFO - 2022-02-12 07:53:51 --> Utf8 Class Initialized
INFO - 2022-02-12 07:53:51 --> URI Class Initialized
DEBUG - 2022-02-12 07:53:51 --> No URI present. Default controller set.
INFO - 2022-02-12 07:53:51 --> Router Class Initialized
INFO - 2022-02-12 07:53:51 --> Output Class Initialized
INFO - 2022-02-12 07:53:51 --> Security Class Initialized
DEBUG - 2022-02-12 07:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 07:53:51 --> Input Class Initialized
INFO - 2022-02-12 07:53:51 --> Language Class Initialized
INFO - 2022-02-12 07:53:51 --> Loader Class Initialized
INFO - 2022-02-12 07:53:51 --> Helper loaded: url_helper
INFO - 2022-02-12 07:53:51 --> Helper loaded: form_helper
INFO - 2022-02-12 07:53:51 --> Helper loaded: common_helper
INFO - 2022-02-12 07:53:51 --> Database Driver Class Initialized
DEBUG - 2022-02-12 07:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 07:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 07:53:51 --> Controller Class Initialized
INFO - 2022-02-12 07:53:51 --> Form Validation Class Initialized
DEBUG - 2022-02-12 07:53:51 --> Encrypt Class Initialized
DEBUG - 2022-02-12 07:53:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 07:53:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 07:53:51 --> Email Class Initialized
INFO - 2022-02-12 07:53:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 07:53:51 --> Calendar Class Initialized
INFO - 2022-02-12 07:53:51 --> Model "Login_model" initialized
INFO - 2022-02-12 07:53:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-12 07:53:51 --> Final output sent to browser
DEBUG - 2022-02-12 07:53:51 --> Total execution time: 0.0326
ERROR - 2022-02-12 10:04:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 10:04:37 --> Config Class Initialized
INFO - 2022-02-12 10:04:37 --> Hooks Class Initialized
DEBUG - 2022-02-12 10:04:37 --> UTF-8 Support Enabled
INFO - 2022-02-12 10:04:37 --> Utf8 Class Initialized
INFO - 2022-02-12 10:04:37 --> URI Class Initialized
DEBUG - 2022-02-12 10:04:37 --> No URI present. Default controller set.
INFO - 2022-02-12 10:04:37 --> Router Class Initialized
INFO - 2022-02-12 10:04:37 --> Output Class Initialized
INFO - 2022-02-12 10:04:37 --> Security Class Initialized
DEBUG - 2022-02-12 10:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 10:04:37 --> Input Class Initialized
INFO - 2022-02-12 10:04:37 --> Language Class Initialized
INFO - 2022-02-12 10:04:37 --> Loader Class Initialized
INFO - 2022-02-12 10:04:37 --> Helper loaded: url_helper
INFO - 2022-02-12 10:04:37 --> Helper loaded: form_helper
INFO - 2022-02-12 10:04:37 --> Helper loaded: common_helper
INFO - 2022-02-12 10:04:37 --> Database Driver Class Initialized
DEBUG - 2022-02-12 10:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 10:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 10:04:37 --> Controller Class Initialized
INFO - 2022-02-12 10:04:37 --> Form Validation Class Initialized
DEBUG - 2022-02-12 10:04:37 --> Encrypt Class Initialized
DEBUG - 2022-02-12 10:04:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 10:04:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 10:04:37 --> Email Class Initialized
INFO - 2022-02-12 10:04:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 10:04:37 --> Calendar Class Initialized
INFO - 2022-02-12 10:04:37 --> Model "Login_model" initialized
INFO - 2022-02-12 10:04:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-12 10:04:37 --> Final output sent to browser
DEBUG - 2022-02-12 10:04:37 --> Total execution time: 0.0303
ERROR - 2022-02-12 10:06:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 10:06:15 --> Config Class Initialized
INFO - 2022-02-12 10:06:15 --> Hooks Class Initialized
DEBUG - 2022-02-12 10:06:15 --> UTF-8 Support Enabled
INFO - 2022-02-12 10:06:15 --> Utf8 Class Initialized
INFO - 2022-02-12 10:06:15 --> URI Class Initialized
DEBUG - 2022-02-12 10:06:15 --> No URI present. Default controller set.
INFO - 2022-02-12 10:06:15 --> Router Class Initialized
INFO - 2022-02-12 10:06:15 --> Output Class Initialized
INFO - 2022-02-12 10:06:15 --> Security Class Initialized
DEBUG - 2022-02-12 10:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 10:06:15 --> Input Class Initialized
INFO - 2022-02-12 10:06:15 --> Language Class Initialized
INFO - 2022-02-12 10:06:15 --> Loader Class Initialized
INFO - 2022-02-12 10:06:15 --> Helper loaded: url_helper
INFO - 2022-02-12 10:06:15 --> Helper loaded: form_helper
INFO - 2022-02-12 10:06:15 --> Helper loaded: common_helper
INFO - 2022-02-12 10:06:15 --> Database Driver Class Initialized
DEBUG - 2022-02-12 10:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 10:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 10:06:15 --> Controller Class Initialized
INFO - 2022-02-12 10:06:15 --> Form Validation Class Initialized
DEBUG - 2022-02-12 10:06:15 --> Encrypt Class Initialized
DEBUG - 2022-02-12 10:06:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 10:06:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 10:06:15 --> Email Class Initialized
INFO - 2022-02-12 10:06:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 10:06:15 --> Calendar Class Initialized
INFO - 2022-02-12 10:06:15 --> Model "Login_model" initialized
INFO - 2022-02-12 10:06:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-12 10:06:15 --> Final output sent to browser
DEBUG - 2022-02-12 10:06:15 --> Total execution time: 0.0221
ERROR - 2022-02-12 10:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 10:06:29 --> Config Class Initialized
INFO - 2022-02-12 10:06:29 --> Hooks Class Initialized
DEBUG - 2022-02-12 10:06:29 --> UTF-8 Support Enabled
INFO - 2022-02-12 10:06:29 --> Utf8 Class Initialized
INFO - 2022-02-12 10:06:29 --> URI Class Initialized
DEBUG - 2022-02-12 10:06:29 --> No URI present. Default controller set.
INFO - 2022-02-12 10:06:29 --> Router Class Initialized
INFO - 2022-02-12 10:06:29 --> Output Class Initialized
INFO - 2022-02-12 10:06:29 --> Security Class Initialized
DEBUG - 2022-02-12 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 10:06:29 --> Input Class Initialized
INFO - 2022-02-12 10:06:29 --> Language Class Initialized
INFO - 2022-02-12 10:06:29 --> Loader Class Initialized
INFO - 2022-02-12 10:06:29 --> Helper loaded: url_helper
INFO - 2022-02-12 10:06:29 --> Helper loaded: form_helper
INFO - 2022-02-12 10:06:29 --> Helper loaded: common_helper
INFO - 2022-02-12 10:06:29 --> Database Driver Class Initialized
DEBUG - 2022-02-12 10:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 10:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 10:06:29 --> Controller Class Initialized
INFO - 2022-02-12 10:06:29 --> Form Validation Class Initialized
DEBUG - 2022-02-12 10:06:29 --> Encrypt Class Initialized
DEBUG - 2022-02-12 10:06:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 10:06:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 10:06:29 --> Email Class Initialized
INFO - 2022-02-12 10:06:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 10:06:29 --> Calendar Class Initialized
INFO - 2022-02-12 10:06:29 --> Model "Login_model" initialized
INFO - 2022-02-12 10:06:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-12 10:06:29 --> Final output sent to browser
DEBUG - 2022-02-12 10:06:29 --> Total execution time: 0.0285
ERROR - 2022-02-12 10:09:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 10:09:17 --> Config Class Initialized
INFO - 2022-02-12 10:09:17 --> Hooks Class Initialized
DEBUG - 2022-02-12 10:09:17 --> UTF-8 Support Enabled
INFO - 2022-02-12 10:09:17 --> Utf8 Class Initialized
INFO - 2022-02-12 10:09:17 --> URI Class Initialized
DEBUG - 2022-02-12 10:09:17 --> No URI present. Default controller set.
INFO - 2022-02-12 10:09:17 --> Router Class Initialized
INFO - 2022-02-12 10:09:17 --> Output Class Initialized
INFO - 2022-02-12 10:09:17 --> Security Class Initialized
DEBUG - 2022-02-12 10:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 10:09:17 --> Input Class Initialized
INFO - 2022-02-12 10:09:17 --> Language Class Initialized
INFO - 2022-02-12 10:09:17 --> Loader Class Initialized
INFO - 2022-02-12 10:09:17 --> Helper loaded: url_helper
INFO - 2022-02-12 10:09:17 --> Helper loaded: form_helper
INFO - 2022-02-12 10:09:17 --> Helper loaded: common_helper
INFO - 2022-02-12 10:09:17 --> Database Driver Class Initialized
DEBUG - 2022-02-12 10:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 10:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 10:09:17 --> Controller Class Initialized
INFO - 2022-02-12 10:09:17 --> Form Validation Class Initialized
DEBUG - 2022-02-12 10:09:17 --> Encrypt Class Initialized
DEBUG - 2022-02-12 10:09:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 10:09:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 10:09:17 --> Email Class Initialized
INFO - 2022-02-12 10:09:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 10:09:17 --> Calendar Class Initialized
INFO - 2022-02-12 10:09:17 --> Model "Login_model" initialized
INFO - 2022-02-12 10:09:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-12 10:09:17 --> Final output sent to browser
DEBUG - 2022-02-12 10:09:17 --> Total execution time: 0.0231
ERROR - 2022-02-12 14:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 14:24:11 --> Config Class Initialized
INFO - 2022-02-12 14:24:11 --> Hooks Class Initialized
DEBUG - 2022-02-12 14:24:11 --> UTF-8 Support Enabled
INFO - 2022-02-12 14:24:11 --> Utf8 Class Initialized
INFO - 2022-02-12 14:24:11 --> URI Class Initialized
DEBUG - 2022-02-12 14:24:11 --> No URI present. Default controller set.
INFO - 2022-02-12 14:24:11 --> Router Class Initialized
INFO - 2022-02-12 14:24:11 --> Output Class Initialized
INFO - 2022-02-12 14:24:11 --> Security Class Initialized
DEBUG - 2022-02-12 14:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 14:24:11 --> Input Class Initialized
INFO - 2022-02-12 14:24:11 --> Language Class Initialized
INFO - 2022-02-12 14:24:11 --> Loader Class Initialized
INFO - 2022-02-12 14:24:11 --> Helper loaded: url_helper
INFO - 2022-02-12 14:24:11 --> Helper loaded: form_helper
INFO - 2022-02-12 14:24:11 --> Helper loaded: common_helper
INFO - 2022-02-12 14:24:11 --> Database Driver Class Initialized
DEBUG - 2022-02-12 14:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 14:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 14:24:11 --> Controller Class Initialized
INFO - 2022-02-12 14:24:11 --> Form Validation Class Initialized
DEBUG - 2022-02-12 14:24:11 --> Encrypt Class Initialized
DEBUG - 2022-02-12 14:24:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:24:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 14:24:11 --> Email Class Initialized
INFO - 2022-02-12 14:24:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 14:24:11 --> Calendar Class Initialized
INFO - 2022-02-12 14:24:11 --> Model "Login_model" initialized
INFO - 2022-02-12 14:24:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-12 14:24:11 --> Final output sent to browser
DEBUG - 2022-02-12 14:24:11 --> Total execution time: 0.0248
ERROR - 2022-02-12 14:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 14:24:11 --> Config Class Initialized
INFO - 2022-02-12 14:24:11 --> Hooks Class Initialized
DEBUG - 2022-02-12 14:24:11 --> UTF-8 Support Enabled
INFO - 2022-02-12 14:24:11 --> Utf8 Class Initialized
INFO - 2022-02-12 14:24:11 --> URI Class Initialized
INFO - 2022-02-12 14:24:11 --> Router Class Initialized
INFO - 2022-02-12 14:24:11 --> Output Class Initialized
INFO - 2022-02-12 14:24:11 --> Security Class Initialized
DEBUG - 2022-02-12 14:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 14:24:11 --> Input Class Initialized
INFO - 2022-02-12 14:24:11 --> Language Class Initialized
ERROR - 2022-02-12 14:24:11 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-12 14:24:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 14:24:19 --> Config Class Initialized
INFO - 2022-02-12 14:24:19 --> Hooks Class Initialized
DEBUG - 2022-02-12 14:24:19 --> UTF-8 Support Enabled
INFO - 2022-02-12 14:24:19 --> Utf8 Class Initialized
INFO - 2022-02-12 14:24:19 --> URI Class Initialized
INFO - 2022-02-12 14:24:19 --> Router Class Initialized
INFO - 2022-02-12 14:24:19 --> Output Class Initialized
INFO - 2022-02-12 14:24:19 --> Security Class Initialized
DEBUG - 2022-02-12 14:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 14:24:19 --> Input Class Initialized
INFO - 2022-02-12 14:24:19 --> Language Class Initialized
INFO - 2022-02-12 14:24:19 --> Loader Class Initialized
INFO - 2022-02-12 14:24:19 --> Helper loaded: url_helper
INFO - 2022-02-12 14:24:19 --> Helper loaded: form_helper
INFO - 2022-02-12 14:24:19 --> Helper loaded: common_helper
INFO - 2022-02-12 14:24:19 --> Database Driver Class Initialized
DEBUG - 2022-02-12 14:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 14:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 14:24:19 --> Controller Class Initialized
INFO - 2022-02-12 14:24:19 --> Form Validation Class Initialized
DEBUG - 2022-02-12 14:24:19 --> Encrypt Class Initialized
DEBUG - 2022-02-12 14:24:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:24:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 14:24:19 --> Email Class Initialized
INFO - 2022-02-12 14:24:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 14:24:19 --> Calendar Class Initialized
INFO - 2022-02-12 14:24:19 --> Model "Login_model" initialized
ERROR - 2022-02-12 14:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 14:24:20 --> Config Class Initialized
INFO - 2022-02-12 14:24:20 --> Hooks Class Initialized
DEBUG - 2022-02-12 14:24:20 --> UTF-8 Support Enabled
INFO - 2022-02-12 14:24:20 --> Utf8 Class Initialized
INFO - 2022-02-12 14:24:20 --> URI Class Initialized
INFO - 2022-02-12 14:24:20 --> Router Class Initialized
INFO - 2022-02-12 14:24:20 --> Output Class Initialized
INFO - 2022-02-12 14:24:20 --> Security Class Initialized
DEBUG - 2022-02-12 14:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 14:24:20 --> Input Class Initialized
INFO - 2022-02-12 14:24:20 --> Language Class Initialized
INFO - 2022-02-12 14:24:20 --> Loader Class Initialized
INFO - 2022-02-12 14:24:20 --> Helper loaded: url_helper
INFO - 2022-02-12 14:24:20 --> Helper loaded: form_helper
INFO - 2022-02-12 14:24:20 --> Helper loaded: common_helper
INFO - 2022-02-12 14:24:20 --> Database Driver Class Initialized
DEBUG - 2022-02-12 14:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 14:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 14:24:20 --> Controller Class Initialized
INFO - 2022-02-12 14:24:20 --> Form Validation Class Initialized
DEBUG - 2022-02-12 14:24:20 --> Encrypt Class Initialized
DEBUG - 2022-02-12 14:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:24:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 14:24:20 --> Email Class Initialized
INFO - 2022-02-12 14:24:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 14:24:20 --> Calendar Class Initialized
INFO - 2022-02-12 14:24:20 --> Model "Login_model" initialized
ERROR - 2022-02-12 14:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 14:24:21 --> Config Class Initialized
INFO - 2022-02-12 14:24:21 --> Hooks Class Initialized
DEBUG - 2022-02-12 14:24:21 --> UTF-8 Support Enabled
INFO - 2022-02-12 14:24:21 --> Utf8 Class Initialized
INFO - 2022-02-12 14:24:21 --> URI Class Initialized
INFO - 2022-02-12 14:24:21 --> Router Class Initialized
INFO - 2022-02-12 14:24:21 --> Output Class Initialized
INFO - 2022-02-12 14:24:21 --> Security Class Initialized
DEBUG - 2022-02-12 14:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 14:24:21 --> Input Class Initialized
INFO - 2022-02-12 14:24:21 --> Language Class Initialized
INFO - 2022-02-12 14:24:21 --> Loader Class Initialized
INFO - 2022-02-12 14:24:21 --> Helper loaded: url_helper
INFO - 2022-02-12 14:24:21 --> Helper loaded: form_helper
INFO - 2022-02-12 14:24:21 --> Helper loaded: common_helper
INFO - 2022-02-12 14:24:21 --> Database Driver Class Initialized
DEBUG - 2022-02-12 14:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 14:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 14:24:21 --> Controller Class Initialized
INFO - 2022-02-12 14:24:21 --> Form Validation Class Initialized
DEBUG - 2022-02-12 14:24:21 --> Encrypt Class Initialized
DEBUG - 2022-02-12 14:24:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:24:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 14:24:21 --> Email Class Initialized
INFO - 2022-02-12 14:24:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 14:24:21 --> Calendar Class Initialized
INFO - 2022-02-12 14:24:21 --> Model "Login_model" initialized
INFO - 2022-02-12 14:24:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-12 14:24:21 --> Final output sent to browser
DEBUG - 2022-02-12 14:24:21 --> Total execution time: 0.0354
ERROR - 2022-02-12 14:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 14:24:21 --> Config Class Initialized
INFO - 2022-02-12 14:24:21 --> Hooks Class Initialized
DEBUG - 2022-02-12 14:24:21 --> UTF-8 Support Enabled
INFO - 2022-02-12 14:24:21 --> Utf8 Class Initialized
INFO - 2022-02-12 14:24:22 --> URI Class Initialized
DEBUG - 2022-02-12 14:24:22 --> No URI present. Default controller set.
INFO - 2022-02-12 14:24:22 --> Router Class Initialized
INFO - 2022-02-12 14:24:22 --> Output Class Initialized
INFO - 2022-02-12 14:24:22 --> Security Class Initialized
DEBUG - 2022-02-12 14:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 14:24:22 --> Input Class Initialized
INFO - 2022-02-12 14:24:22 --> Language Class Initialized
INFO - 2022-02-12 14:24:22 --> Loader Class Initialized
INFO - 2022-02-12 14:24:22 --> Helper loaded: url_helper
INFO - 2022-02-12 14:24:22 --> Helper loaded: form_helper
INFO - 2022-02-12 14:24:22 --> Helper loaded: common_helper
INFO - 2022-02-12 14:24:22 --> Database Driver Class Initialized
DEBUG - 2022-02-12 14:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-12 14:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-12 14:24:22 --> Controller Class Initialized
INFO - 2022-02-12 14:24:22 --> Form Validation Class Initialized
DEBUG - 2022-02-12 14:24:22 --> Encrypt Class Initialized
DEBUG - 2022-02-12 14:24:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:24:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-12 14:24:22 --> Email Class Initialized
INFO - 2022-02-12 14:24:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-12 14:24:22 --> Calendar Class Initialized
INFO - 2022-02-12 14:24:22 --> Model "Login_model" initialized
INFO - 2022-02-12 14:24:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-12 14:24:22 --> Final output sent to browser
DEBUG - 2022-02-12 14:24:22 --> Total execution time: 0.0219
ERROR - 2022-02-12 20:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-12 20:53:38 --> Config Class Initialized
INFO - 2022-02-12 20:53:38 --> Hooks Class Initialized
DEBUG - 2022-02-12 20:53:38 --> UTF-8 Support Enabled
INFO - 2022-02-12 20:53:38 --> Utf8 Class Initialized
INFO - 2022-02-12 20:53:38 --> URI Class Initialized
INFO - 2022-02-12 20:53:38 --> Router Class Initialized
INFO - 2022-02-12 20:53:38 --> Output Class Initialized
INFO - 2022-02-12 20:53:38 --> Security Class Initialized
DEBUG - 2022-02-12 20:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-12 20:53:38 --> Input Class Initialized
INFO - 2022-02-12 20:53:38 --> Language Class Initialized
ERROR - 2022-02-12 20:53:38 --> 404 Page Not Found: Wp-content/index
