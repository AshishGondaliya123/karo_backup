<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-12 01:19:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 01:19:15 --> Config Class Initialized
INFO - 2022-01-12 01:19:15 --> Hooks Class Initialized
DEBUG - 2022-01-12 01:19:15 --> UTF-8 Support Enabled
INFO - 2022-01-12 01:19:15 --> Utf8 Class Initialized
INFO - 2022-01-12 01:19:15 --> URI Class Initialized
INFO - 2022-01-12 01:19:15 --> Router Class Initialized
INFO - 2022-01-12 01:19:15 --> Output Class Initialized
INFO - 2022-01-12 01:19:15 --> Security Class Initialized
DEBUG - 2022-01-12 01:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 01:19:15 --> Input Class Initialized
INFO - 2022-01-12 01:19:15 --> Language Class Initialized
ERROR - 2022-01-12 01:19:15 --> 404 Page Not Found: Wp-content/index
ERROR - 2022-01-12 03:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:50 --> Config Class Initialized
INFO - 2022-01-12 03:35:50 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:50 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:50 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:50 --> URI Class Initialized
DEBUG - 2022-01-12 03:35:50 --> No URI present. Default controller set.
INFO - 2022-01-12 03:35:50 --> Router Class Initialized
INFO - 2022-01-12 03:35:50 --> Output Class Initialized
INFO - 2022-01-12 03:35:50 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:50 --> Input Class Initialized
INFO - 2022-01-12 03:35:50 --> Language Class Initialized
INFO - 2022-01-12 03:35:50 --> Loader Class Initialized
INFO - 2022-01-12 03:35:50 --> Helper loaded: url_helper
INFO - 2022-01-12 03:35:50 --> Helper loaded: form_helper
INFO - 2022-01-12 03:35:50 --> Helper loaded: common_helper
INFO - 2022-01-12 03:35:50 --> Database Driver Class Initialized
DEBUG - 2022-01-12 03:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 03:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 03:35:50 --> Controller Class Initialized
INFO - 2022-01-12 03:35:50 --> Form Validation Class Initialized
DEBUG - 2022-01-12 03:35:50 --> Encrypt Class Initialized
DEBUG - 2022-01-12 03:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 03:35:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 03:35:50 --> Email Class Initialized
INFO - 2022-01-12 03:35:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 03:35:50 --> Calendar Class Initialized
INFO - 2022-01-12 03:35:50 --> Model "Login_model" initialized
INFO - 2022-01-12 03:35:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 03:35:50 --> Final output sent to browser
DEBUG - 2022-01-12 03:35:50 --> Total execution time: 0.0318
ERROR - 2022-01-12 03:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:50 --> Config Class Initialized
INFO - 2022-01-12 03:35:50 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:50 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:50 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:50 --> URI Class Initialized
DEBUG - 2022-01-12 03:35:50 --> No URI present. Default controller set.
INFO - 2022-01-12 03:35:50 --> Router Class Initialized
INFO - 2022-01-12 03:35:50 --> Output Class Initialized
INFO - 2022-01-12 03:35:50 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:50 --> Input Class Initialized
INFO - 2022-01-12 03:35:50 --> Language Class Initialized
INFO - 2022-01-12 03:35:50 --> Loader Class Initialized
INFO - 2022-01-12 03:35:50 --> Helper loaded: url_helper
INFO - 2022-01-12 03:35:50 --> Helper loaded: form_helper
INFO - 2022-01-12 03:35:50 --> Helper loaded: common_helper
INFO - 2022-01-12 03:35:50 --> Database Driver Class Initialized
DEBUG - 2022-01-12 03:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 03:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 03:35:50 --> Controller Class Initialized
INFO - 2022-01-12 03:35:50 --> Form Validation Class Initialized
DEBUG - 2022-01-12 03:35:50 --> Encrypt Class Initialized
DEBUG - 2022-01-12 03:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 03:35:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 03:35:50 --> Email Class Initialized
INFO - 2022-01-12 03:35:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 03:35:50 --> Calendar Class Initialized
INFO - 2022-01-12 03:35:50 --> Model "Login_model" initialized
INFO - 2022-01-12 03:35:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 03:35:50 --> Final output sent to browser
DEBUG - 2022-01-12 03:35:50 --> Total execution time: 0.0272
ERROR - 2022-01-12 03:35:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:51 --> Config Class Initialized
INFO - 2022-01-12 03:35:51 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:51 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:51 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:51 --> URI Class Initialized
INFO - 2022-01-12 03:35:51 --> Router Class Initialized
INFO - 2022-01-12 03:35:51 --> Output Class Initialized
INFO - 2022-01-12 03:35:51 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:51 --> Input Class Initialized
INFO - 2022-01-12 03:35:51 --> Language Class Initialized
ERROR - 2022-01-12 03:35:51 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-12 03:35:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:51 --> Config Class Initialized
INFO - 2022-01-12 03:35:51 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:51 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:51 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:51 --> URI Class Initialized
DEBUG - 2022-01-12 03:35:51 --> No URI present. Default controller set.
INFO - 2022-01-12 03:35:51 --> Router Class Initialized
INFO - 2022-01-12 03:35:51 --> Output Class Initialized
INFO - 2022-01-12 03:35:51 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:51 --> Input Class Initialized
INFO - 2022-01-12 03:35:51 --> Language Class Initialized
INFO - 2022-01-12 03:35:51 --> Loader Class Initialized
INFO - 2022-01-12 03:35:51 --> Helper loaded: url_helper
INFO - 2022-01-12 03:35:51 --> Helper loaded: form_helper
INFO - 2022-01-12 03:35:51 --> Helper loaded: common_helper
INFO - 2022-01-12 03:35:51 --> Database Driver Class Initialized
DEBUG - 2022-01-12 03:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 03:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 03:35:51 --> Controller Class Initialized
INFO - 2022-01-12 03:35:51 --> Form Validation Class Initialized
DEBUG - 2022-01-12 03:35:51 --> Encrypt Class Initialized
DEBUG - 2022-01-12 03:35:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 03:35:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 03:35:51 --> Email Class Initialized
INFO - 2022-01-12 03:35:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 03:35:51 --> Calendar Class Initialized
INFO - 2022-01-12 03:35:51 --> Model "Login_model" initialized
INFO - 2022-01-12 03:35:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 03:35:51 --> Final output sent to browser
DEBUG - 2022-01-12 03:35:51 --> Total execution time: 0.0271
ERROR - 2022-01-12 03:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:52 --> Config Class Initialized
INFO - 2022-01-12 03:35:52 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:52 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:52 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:52 --> URI Class Initialized
INFO - 2022-01-12 03:35:52 --> Router Class Initialized
INFO - 2022-01-12 03:35:52 --> Output Class Initialized
INFO - 2022-01-12 03:35:52 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:52 --> Input Class Initialized
INFO - 2022-01-12 03:35:52 --> Language Class Initialized
ERROR - 2022-01-12 03:35:52 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-12 03:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:52 --> Config Class Initialized
INFO - 2022-01-12 03:35:52 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:52 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:52 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:52 --> URI Class Initialized
INFO - 2022-01-12 03:35:52 --> Router Class Initialized
INFO - 2022-01-12 03:35:52 --> Output Class Initialized
INFO - 2022-01-12 03:35:52 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:52 --> Input Class Initialized
INFO - 2022-01-12 03:35:52 --> Language Class Initialized
ERROR - 2022-01-12 03:35:52 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-12 03:35:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:53 --> Config Class Initialized
INFO - 2022-01-12 03:35:53 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:53 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:53 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:53 --> URI Class Initialized
INFO - 2022-01-12 03:35:53 --> Router Class Initialized
INFO - 2022-01-12 03:35:53 --> Output Class Initialized
INFO - 2022-01-12 03:35:53 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:53 --> Input Class Initialized
INFO - 2022-01-12 03:35:53 --> Language Class Initialized
ERROR - 2022-01-12 03:35:53 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-12 03:35:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:53 --> Config Class Initialized
INFO - 2022-01-12 03:35:53 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:53 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:53 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:53 --> URI Class Initialized
INFO - 2022-01-12 03:35:53 --> Router Class Initialized
INFO - 2022-01-12 03:35:53 --> Output Class Initialized
INFO - 2022-01-12 03:35:53 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:53 --> Input Class Initialized
INFO - 2022-01-12 03:35:53 --> Language Class Initialized
ERROR - 2022-01-12 03:35:53 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-12 03:35:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:54 --> Config Class Initialized
INFO - 2022-01-12 03:35:54 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:54 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:54 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:54 --> URI Class Initialized
INFO - 2022-01-12 03:35:54 --> Router Class Initialized
INFO - 2022-01-12 03:35:54 --> Output Class Initialized
INFO - 2022-01-12 03:35:54 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:54 --> Input Class Initialized
INFO - 2022-01-12 03:35:54 --> Language Class Initialized
ERROR - 2022-01-12 03:35:54 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-12 03:35:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:54 --> Config Class Initialized
INFO - 2022-01-12 03:35:54 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:54 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:54 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:54 --> URI Class Initialized
INFO - 2022-01-12 03:35:54 --> Router Class Initialized
INFO - 2022-01-12 03:35:54 --> Output Class Initialized
INFO - 2022-01-12 03:35:54 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:54 --> Input Class Initialized
INFO - 2022-01-12 03:35:54 --> Language Class Initialized
ERROR - 2022-01-12 03:35:54 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-12 03:35:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:54 --> Config Class Initialized
INFO - 2022-01-12 03:35:54 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:54 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:54 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:54 --> URI Class Initialized
INFO - 2022-01-12 03:35:54 --> Router Class Initialized
INFO - 2022-01-12 03:35:54 --> Output Class Initialized
INFO - 2022-01-12 03:35:54 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:54 --> Input Class Initialized
INFO - 2022-01-12 03:35:54 --> Language Class Initialized
ERROR - 2022-01-12 03:35:54 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-12 03:35:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:55 --> Config Class Initialized
INFO - 2022-01-12 03:35:55 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:55 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:55 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:55 --> URI Class Initialized
INFO - 2022-01-12 03:35:55 --> Router Class Initialized
INFO - 2022-01-12 03:35:55 --> Output Class Initialized
INFO - 2022-01-12 03:35:55 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:55 --> Input Class Initialized
INFO - 2022-01-12 03:35:55 --> Language Class Initialized
ERROR - 2022-01-12 03:35:55 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-12 03:35:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:55 --> Config Class Initialized
INFO - 2022-01-12 03:35:55 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:55 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:55 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:55 --> URI Class Initialized
INFO - 2022-01-12 03:35:55 --> Router Class Initialized
INFO - 2022-01-12 03:35:55 --> Output Class Initialized
INFO - 2022-01-12 03:35:55 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:55 --> Input Class Initialized
INFO - 2022-01-12 03:35:55 --> Language Class Initialized
ERROR - 2022-01-12 03:35:55 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-12 03:35:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:56 --> Config Class Initialized
INFO - 2022-01-12 03:35:56 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:56 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:56 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:56 --> URI Class Initialized
INFO - 2022-01-12 03:35:56 --> Router Class Initialized
INFO - 2022-01-12 03:35:56 --> Output Class Initialized
INFO - 2022-01-12 03:35:56 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:56 --> Input Class Initialized
INFO - 2022-01-12 03:35:56 --> Language Class Initialized
ERROR - 2022-01-12 03:35:56 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-12 03:35:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:56 --> Config Class Initialized
INFO - 2022-01-12 03:35:56 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:56 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:56 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:56 --> URI Class Initialized
INFO - 2022-01-12 03:35:56 --> Router Class Initialized
INFO - 2022-01-12 03:35:56 --> Output Class Initialized
INFO - 2022-01-12 03:35:56 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:56 --> Input Class Initialized
INFO - 2022-01-12 03:35:56 --> Language Class Initialized
ERROR - 2022-01-12 03:35:56 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-12 03:35:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:57 --> Config Class Initialized
INFO - 2022-01-12 03:35:57 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:57 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:57 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:57 --> URI Class Initialized
INFO - 2022-01-12 03:35:57 --> Router Class Initialized
INFO - 2022-01-12 03:35:57 --> Output Class Initialized
INFO - 2022-01-12 03:35:57 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:57 --> Input Class Initialized
INFO - 2022-01-12 03:35:57 --> Language Class Initialized
ERROR - 2022-01-12 03:35:57 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-12 03:35:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:57 --> Config Class Initialized
INFO - 2022-01-12 03:35:57 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:57 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:57 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:57 --> URI Class Initialized
INFO - 2022-01-12 03:35:57 --> Router Class Initialized
INFO - 2022-01-12 03:35:57 --> Output Class Initialized
INFO - 2022-01-12 03:35:57 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:57 --> Input Class Initialized
INFO - 2022-01-12 03:35:57 --> Language Class Initialized
ERROR - 2022-01-12 03:35:57 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-12 03:35:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:57 --> Config Class Initialized
INFO - 2022-01-12 03:35:57 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:57 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:57 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:57 --> URI Class Initialized
INFO - 2022-01-12 03:35:57 --> Router Class Initialized
INFO - 2022-01-12 03:35:57 --> Output Class Initialized
INFO - 2022-01-12 03:35:57 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:57 --> Input Class Initialized
INFO - 2022-01-12 03:35:57 --> Language Class Initialized
ERROR - 2022-01-12 03:35:57 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-12 03:35:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:58 --> Config Class Initialized
INFO - 2022-01-12 03:35:58 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:58 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:58 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:58 --> URI Class Initialized
INFO - 2022-01-12 03:35:58 --> Router Class Initialized
INFO - 2022-01-12 03:35:58 --> Output Class Initialized
INFO - 2022-01-12 03:35:58 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:58 --> Input Class Initialized
INFO - 2022-01-12 03:35:58 --> Language Class Initialized
ERROR - 2022-01-12 03:35:58 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-12 03:35:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 03:35:58 --> Config Class Initialized
INFO - 2022-01-12 03:35:58 --> Hooks Class Initialized
DEBUG - 2022-01-12 03:35:58 --> UTF-8 Support Enabled
INFO - 2022-01-12 03:35:58 --> Utf8 Class Initialized
INFO - 2022-01-12 03:35:58 --> URI Class Initialized
INFO - 2022-01-12 03:35:58 --> Router Class Initialized
INFO - 2022-01-12 03:35:58 --> Output Class Initialized
INFO - 2022-01-12 03:35:58 --> Security Class Initialized
DEBUG - 2022-01-12 03:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 03:35:58 --> Input Class Initialized
INFO - 2022-01-12 03:35:58 --> Language Class Initialized
ERROR - 2022-01-12 03:35:58 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-12 04:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:28 --> Config Class Initialized
INFO - 2022-01-12 04:24:28 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:28 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:28 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:28 --> URI Class Initialized
DEBUG - 2022-01-12 04:24:28 --> No URI present. Default controller set.
INFO - 2022-01-12 04:24:28 --> Router Class Initialized
INFO - 2022-01-12 04:24:28 --> Output Class Initialized
INFO - 2022-01-12 04:24:28 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:28 --> Input Class Initialized
INFO - 2022-01-12 04:24:28 --> Language Class Initialized
INFO - 2022-01-12 04:24:28 --> Loader Class Initialized
INFO - 2022-01-12 04:24:28 --> Helper loaded: url_helper
INFO - 2022-01-12 04:24:28 --> Helper loaded: form_helper
INFO - 2022-01-12 04:24:28 --> Helper loaded: common_helper
INFO - 2022-01-12 04:24:28 --> Database Driver Class Initialized
DEBUG - 2022-01-12 04:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 04:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 04:24:28 --> Controller Class Initialized
INFO - 2022-01-12 04:24:28 --> Form Validation Class Initialized
DEBUG - 2022-01-12 04:24:28 --> Encrypt Class Initialized
DEBUG - 2022-01-12 04:24:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 04:24:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 04:24:28 --> Email Class Initialized
INFO - 2022-01-12 04:24:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 04:24:28 --> Calendar Class Initialized
INFO - 2022-01-12 04:24:28 --> Model "Login_model" initialized
INFO - 2022-01-12 04:24:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 04:24:28 --> Final output sent to browser
DEBUG - 2022-01-12 04:24:28 --> Total execution time: 0.0242
ERROR - 2022-01-12 04:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:29 --> Config Class Initialized
INFO - 2022-01-12 04:24:29 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:29 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:29 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:29 --> URI Class Initialized
DEBUG - 2022-01-12 04:24:29 --> No URI present. Default controller set.
INFO - 2022-01-12 04:24:29 --> Router Class Initialized
INFO - 2022-01-12 04:24:29 --> Output Class Initialized
INFO - 2022-01-12 04:24:29 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:29 --> Input Class Initialized
INFO - 2022-01-12 04:24:29 --> Language Class Initialized
INFO - 2022-01-12 04:24:29 --> Loader Class Initialized
INFO - 2022-01-12 04:24:29 --> Helper loaded: url_helper
INFO - 2022-01-12 04:24:29 --> Helper loaded: form_helper
INFO - 2022-01-12 04:24:29 --> Helper loaded: common_helper
INFO - 2022-01-12 04:24:29 --> Database Driver Class Initialized
DEBUG - 2022-01-12 04:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 04:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 04:24:29 --> Controller Class Initialized
INFO - 2022-01-12 04:24:29 --> Form Validation Class Initialized
DEBUG - 2022-01-12 04:24:29 --> Encrypt Class Initialized
DEBUG - 2022-01-12 04:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 04:24:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 04:24:29 --> Email Class Initialized
INFO - 2022-01-12 04:24:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 04:24:29 --> Calendar Class Initialized
INFO - 2022-01-12 04:24:29 --> Model "Login_model" initialized
INFO - 2022-01-12 04:24:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 04:24:29 --> Final output sent to browser
DEBUG - 2022-01-12 04:24:29 --> Total execution time: 0.0473
ERROR - 2022-01-12 04:24:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:30 --> Config Class Initialized
INFO - 2022-01-12 04:24:30 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:30 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:30 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:30 --> URI Class Initialized
INFO - 2022-01-12 04:24:30 --> Router Class Initialized
INFO - 2022-01-12 04:24:30 --> Output Class Initialized
INFO - 2022-01-12 04:24:30 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:30 --> Input Class Initialized
INFO - 2022-01-12 04:24:30 --> Language Class Initialized
ERROR - 2022-01-12 04:24:30 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-12 04:24:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:31 --> Config Class Initialized
INFO - 2022-01-12 04:24:31 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:31 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:31 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:31 --> URI Class Initialized
DEBUG - 2022-01-12 04:24:31 --> No URI present. Default controller set.
INFO - 2022-01-12 04:24:31 --> Router Class Initialized
INFO - 2022-01-12 04:24:31 --> Output Class Initialized
INFO - 2022-01-12 04:24:31 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:31 --> Input Class Initialized
INFO - 2022-01-12 04:24:31 --> Language Class Initialized
INFO - 2022-01-12 04:24:31 --> Loader Class Initialized
INFO - 2022-01-12 04:24:31 --> Helper loaded: url_helper
INFO - 2022-01-12 04:24:31 --> Helper loaded: form_helper
INFO - 2022-01-12 04:24:31 --> Helper loaded: common_helper
INFO - 2022-01-12 04:24:31 --> Database Driver Class Initialized
DEBUG - 2022-01-12 04:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 04:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 04:24:31 --> Controller Class Initialized
INFO - 2022-01-12 04:24:31 --> Form Validation Class Initialized
DEBUG - 2022-01-12 04:24:31 --> Encrypt Class Initialized
DEBUG - 2022-01-12 04:24:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 04:24:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 04:24:31 --> Email Class Initialized
INFO - 2022-01-12 04:24:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 04:24:31 --> Calendar Class Initialized
INFO - 2022-01-12 04:24:31 --> Model "Login_model" initialized
INFO - 2022-01-12 04:24:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 04:24:31 --> Final output sent to browser
DEBUG - 2022-01-12 04:24:31 --> Total execution time: 0.0615
ERROR - 2022-01-12 04:24:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:31 --> Config Class Initialized
INFO - 2022-01-12 04:24:31 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:32 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:32 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:32 --> URI Class Initialized
INFO - 2022-01-12 04:24:32 --> Router Class Initialized
INFO - 2022-01-12 04:24:32 --> Output Class Initialized
INFO - 2022-01-12 04:24:32 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:32 --> Input Class Initialized
INFO - 2022-01-12 04:24:32 --> Language Class Initialized
ERROR - 2022-01-12 04:24:32 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-12 04:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:32 --> Config Class Initialized
INFO - 2022-01-12 04:24:32 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:32 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:32 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:32 --> URI Class Initialized
INFO - 2022-01-12 04:24:32 --> Router Class Initialized
INFO - 2022-01-12 04:24:32 --> Output Class Initialized
INFO - 2022-01-12 04:24:32 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:32 --> Input Class Initialized
INFO - 2022-01-12 04:24:32 --> Language Class Initialized
ERROR - 2022-01-12 04:24:32 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-12 04:24:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:33 --> Config Class Initialized
INFO - 2022-01-12 04:24:33 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:33 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:33 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:33 --> URI Class Initialized
INFO - 2022-01-12 04:24:33 --> Router Class Initialized
INFO - 2022-01-12 04:24:33 --> Output Class Initialized
INFO - 2022-01-12 04:24:33 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:33 --> Input Class Initialized
INFO - 2022-01-12 04:24:33 --> Language Class Initialized
ERROR - 2022-01-12 04:24:33 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-12 04:24:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:33 --> Config Class Initialized
INFO - 2022-01-12 04:24:33 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:33 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:33 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:33 --> URI Class Initialized
INFO - 2022-01-12 04:24:33 --> Router Class Initialized
INFO - 2022-01-12 04:24:33 --> Output Class Initialized
INFO - 2022-01-12 04:24:33 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:33 --> Input Class Initialized
INFO - 2022-01-12 04:24:33 --> Language Class Initialized
ERROR - 2022-01-12 04:24:33 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-12 04:24:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:34 --> Config Class Initialized
INFO - 2022-01-12 04:24:34 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:34 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:34 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:34 --> URI Class Initialized
INFO - 2022-01-12 04:24:34 --> Router Class Initialized
INFO - 2022-01-12 04:24:34 --> Output Class Initialized
INFO - 2022-01-12 04:24:34 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:34 --> Input Class Initialized
INFO - 2022-01-12 04:24:34 --> Language Class Initialized
ERROR - 2022-01-12 04:24:34 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-12 04:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:37 --> Config Class Initialized
INFO - 2022-01-12 04:24:37 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:37 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:37 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:37 --> URI Class Initialized
INFO - 2022-01-12 04:24:37 --> Router Class Initialized
INFO - 2022-01-12 04:24:37 --> Output Class Initialized
INFO - 2022-01-12 04:24:37 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:37 --> Input Class Initialized
INFO - 2022-01-12 04:24:37 --> Language Class Initialized
ERROR - 2022-01-12 04:24:37 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-12 04:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:37 --> Config Class Initialized
INFO - 2022-01-12 04:24:37 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:37 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:37 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:37 --> URI Class Initialized
INFO - 2022-01-12 04:24:37 --> Router Class Initialized
INFO - 2022-01-12 04:24:37 --> Output Class Initialized
INFO - 2022-01-12 04:24:37 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:37 --> Input Class Initialized
INFO - 2022-01-12 04:24:37 --> Language Class Initialized
ERROR - 2022-01-12 04:24:37 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-12 04:24:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:38 --> Config Class Initialized
INFO - 2022-01-12 04:24:38 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:38 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:38 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:38 --> URI Class Initialized
INFO - 2022-01-12 04:24:38 --> Router Class Initialized
INFO - 2022-01-12 04:24:38 --> Output Class Initialized
INFO - 2022-01-12 04:24:38 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:38 --> Input Class Initialized
INFO - 2022-01-12 04:24:38 --> Language Class Initialized
ERROR - 2022-01-12 04:24:38 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-12 04:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:39 --> Config Class Initialized
INFO - 2022-01-12 04:24:39 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:39 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:39 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:39 --> URI Class Initialized
INFO - 2022-01-12 04:24:39 --> Router Class Initialized
INFO - 2022-01-12 04:24:39 --> Output Class Initialized
INFO - 2022-01-12 04:24:39 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:39 --> Input Class Initialized
INFO - 2022-01-12 04:24:39 --> Language Class Initialized
ERROR - 2022-01-12 04:24:39 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-12 04:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:39 --> Config Class Initialized
INFO - 2022-01-12 04:24:39 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:39 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:39 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:39 --> URI Class Initialized
INFO - 2022-01-12 04:24:39 --> Router Class Initialized
INFO - 2022-01-12 04:24:39 --> Output Class Initialized
INFO - 2022-01-12 04:24:39 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:39 --> Input Class Initialized
INFO - 2022-01-12 04:24:39 --> Language Class Initialized
ERROR - 2022-01-12 04:24:39 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-12 04:24:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:40 --> Config Class Initialized
INFO - 2022-01-12 04:24:40 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:40 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:40 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:40 --> URI Class Initialized
INFO - 2022-01-12 04:24:40 --> Router Class Initialized
INFO - 2022-01-12 04:24:40 --> Output Class Initialized
INFO - 2022-01-12 04:24:40 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:40 --> Input Class Initialized
INFO - 2022-01-12 04:24:40 --> Language Class Initialized
ERROR - 2022-01-12 04:24:40 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-12 04:24:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:41 --> Config Class Initialized
INFO - 2022-01-12 04:24:41 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:41 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:41 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:41 --> URI Class Initialized
INFO - 2022-01-12 04:24:41 --> Router Class Initialized
INFO - 2022-01-12 04:24:41 --> Output Class Initialized
INFO - 2022-01-12 04:24:41 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:41 --> Input Class Initialized
INFO - 2022-01-12 04:24:41 --> Language Class Initialized
ERROR - 2022-01-12 04:24:41 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-12 04:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:42 --> Config Class Initialized
INFO - 2022-01-12 04:24:42 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:42 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:42 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:42 --> URI Class Initialized
INFO - 2022-01-12 04:24:42 --> Router Class Initialized
INFO - 2022-01-12 04:24:42 --> Output Class Initialized
INFO - 2022-01-12 04:24:42 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:42 --> Input Class Initialized
INFO - 2022-01-12 04:24:42 --> Language Class Initialized
ERROR - 2022-01-12 04:24:42 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-12 04:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:43 --> Config Class Initialized
INFO - 2022-01-12 04:24:43 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:43 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:43 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:43 --> URI Class Initialized
INFO - 2022-01-12 04:24:43 --> Router Class Initialized
INFO - 2022-01-12 04:24:43 --> Output Class Initialized
INFO - 2022-01-12 04:24:43 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:43 --> Input Class Initialized
INFO - 2022-01-12 04:24:43 --> Language Class Initialized
ERROR - 2022-01-12 04:24:43 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-12 04:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:43 --> Config Class Initialized
INFO - 2022-01-12 04:24:43 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:43 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:43 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:43 --> URI Class Initialized
INFO - 2022-01-12 04:24:43 --> Router Class Initialized
INFO - 2022-01-12 04:24:43 --> Output Class Initialized
INFO - 2022-01-12 04:24:43 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:43 --> Input Class Initialized
INFO - 2022-01-12 04:24:43 --> Language Class Initialized
ERROR - 2022-01-12 04:24:43 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-12 04:24:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:24:44 --> Config Class Initialized
INFO - 2022-01-12 04:24:44 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:24:44 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:24:44 --> Utf8 Class Initialized
INFO - 2022-01-12 04:24:44 --> URI Class Initialized
INFO - 2022-01-12 04:24:44 --> Router Class Initialized
INFO - 2022-01-12 04:24:44 --> Output Class Initialized
INFO - 2022-01-12 04:24:44 --> Security Class Initialized
DEBUG - 2022-01-12 04:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:24:44 --> Input Class Initialized
INFO - 2022-01-12 04:24:44 --> Language Class Initialized
ERROR - 2022-01-12 04:24:44 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-12 04:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 04:34:39 --> Config Class Initialized
INFO - 2022-01-12 04:34:39 --> Hooks Class Initialized
DEBUG - 2022-01-12 04:34:39 --> UTF-8 Support Enabled
INFO - 2022-01-12 04:34:39 --> Utf8 Class Initialized
INFO - 2022-01-12 04:34:39 --> URI Class Initialized
DEBUG - 2022-01-12 04:34:39 --> No URI present. Default controller set.
INFO - 2022-01-12 04:34:39 --> Router Class Initialized
INFO - 2022-01-12 04:34:39 --> Output Class Initialized
INFO - 2022-01-12 04:34:39 --> Security Class Initialized
DEBUG - 2022-01-12 04:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 04:34:39 --> Input Class Initialized
INFO - 2022-01-12 04:34:39 --> Language Class Initialized
INFO - 2022-01-12 04:34:39 --> Loader Class Initialized
INFO - 2022-01-12 04:34:39 --> Helper loaded: url_helper
INFO - 2022-01-12 04:34:39 --> Helper loaded: form_helper
INFO - 2022-01-12 04:34:39 --> Helper loaded: common_helper
INFO - 2022-01-12 04:34:39 --> Database Driver Class Initialized
DEBUG - 2022-01-12 04:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 04:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 04:34:39 --> Controller Class Initialized
INFO - 2022-01-12 04:34:39 --> Form Validation Class Initialized
DEBUG - 2022-01-12 04:34:39 --> Encrypt Class Initialized
DEBUG - 2022-01-12 04:34:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 04:34:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 04:34:39 --> Email Class Initialized
INFO - 2022-01-12 04:34:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 04:34:39 --> Calendar Class Initialized
INFO - 2022-01-12 04:34:39 --> Model "Login_model" initialized
INFO - 2022-01-12 04:34:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 04:34:39 --> Final output sent to browser
DEBUG - 2022-01-12 04:34:39 --> Total execution time: 0.0251
ERROR - 2022-01-12 06:55:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 06:55:37 --> Config Class Initialized
INFO - 2022-01-12 06:55:37 --> Hooks Class Initialized
DEBUG - 2022-01-12 06:55:37 --> UTF-8 Support Enabled
INFO - 2022-01-12 06:55:37 --> Utf8 Class Initialized
INFO - 2022-01-12 06:55:37 --> URI Class Initialized
DEBUG - 2022-01-12 06:55:37 --> No URI present. Default controller set.
INFO - 2022-01-12 06:55:37 --> Router Class Initialized
INFO - 2022-01-12 06:55:37 --> Output Class Initialized
INFO - 2022-01-12 06:55:37 --> Security Class Initialized
DEBUG - 2022-01-12 06:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 06:55:37 --> Input Class Initialized
INFO - 2022-01-12 06:55:37 --> Language Class Initialized
INFO - 2022-01-12 06:55:37 --> Loader Class Initialized
INFO - 2022-01-12 06:55:37 --> Helper loaded: url_helper
INFO - 2022-01-12 06:55:37 --> Helper loaded: form_helper
INFO - 2022-01-12 06:55:37 --> Helper loaded: common_helper
INFO - 2022-01-12 06:55:37 --> Database Driver Class Initialized
DEBUG - 2022-01-12 06:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 06:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 06:55:38 --> Controller Class Initialized
INFO - 2022-01-12 06:55:38 --> Form Validation Class Initialized
DEBUG - 2022-01-12 06:55:38 --> Encrypt Class Initialized
DEBUG - 2022-01-12 06:55:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 06:55:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 06:55:38 --> Email Class Initialized
INFO - 2022-01-12 06:55:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 06:55:38 --> Calendar Class Initialized
INFO - 2022-01-12 06:55:38 --> Model "Login_model" initialized
INFO - 2022-01-12 06:55:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 06:55:38 --> Final output sent to browser
DEBUG - 2022-01-12 06:55:38 --> Total execution time: 0.4446
ERROR - 2022-01-12 14:22:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 14:22:43 --> Config Class Initialized
INFO - 2022-01-12 14:22:43 --> Hooks Class Initialized
DEBUG - 2022-01-12 14:22:43 --> UTF-8 Support Enabled
INFO - 2022-01-12 14:22:43 --> Utf8 Class Initialized
INFO - 2022-01-12 14:22:43 --> URI Class Initialized
DEBUG - 2022-01-12 14:22:43 --> No URI present. Default controller set.
INFO - 2022-01-12 14:22:43 --> Router Class Initialized
INFO - 2022-01-12 14:22:43 --> Output Class Initialized
INFO - 2022-01-12 14:22:43 --> Security Class Initialized
DEBUG - 2022-01-12 14:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 14:22:43 --> Input Class Initialized
INFO - 2022-01-12 14:22:43 --> Language Class Initialized
INFO - 2022-01-12 14:22:43 --> Loader Class Initialized
INFO - 2022-01-12 14:22:43 --> Helper loaded: url_helper
INFO - 2022-01-12 14:22:43 --> Helper loaded: form_helper
INFO - 2022-01-12 14:22:43 --> Helper loaded: common_helper
INFO - 2022-01-12 14:22:43 --> Database Driver Class Initialized
DEBUG - 2022-01-12 14:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 14:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 14:22:43 --> Controller Class Initialized
INFO - 2022-01-12 14:22:43 --> Form Validation Class Initialized
DEBUG - 2022-01-12 14:22:43 --> Encrypt Class Initialized
DEBUG - 2022-01-12 14:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:22:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 14:22:43 --> Email Class Initialized
INFO - 2022-01-12 14:22:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 14:22:43 --> Calendar Class Initialized
INFO - 2022-01-12 14:22:43 --> Model "Login_model" initialized
INFO - 2022-01-12 14:22:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 14:22:43 --> Final output sent to browser
DEBUG - 2022-01-12 14:22:43 --> Total execution time: 0.0360
ERROR - 2022-01-12 14:22:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 14:22:43 --> Config Class Initialized
INFO - 2022-01-12 14:22:43 --> Hooks Class Initialized
DEBUG - 2022-01-12 14:22:43 --> UTF-8 Support Enabled
INFO - 2022-01-12 14:22:43 --> Utf8 Class Initialized
INFO - 2022-01-12 14:22:43 --> URI Class Initialized
INFO - 2022-01-12 14:22:43 --> Router Class Initialized
INFO - 2022-01-12 14:22:43 --> Output Class Initialized
INFO - 2022-01-12 14:22:43 --> Security Class Initialized
DEBUG - 2022-01-12 14:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 14:22:43 --> Input Class Initialized
INFO - 2022-01-12 14:22:43 --> Language Class Initialized
ERROR - 2022-01-12 14:22:43 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-12 14:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 14:22:53 --> Config Class Initialized
INFO - 2022-01-12 14:22:53 --> Hooks Class Initialized
DEBUG - 2022-01-12 14:22:53 --> UTF-8 Support Enabled
INFO - 2022-01-12 14:22:53 --> Utf8 Class Initialized
INFO - 2022-01-12 14:22:53 --> URI Class Initialized
INFO - 2022-01-12 14:22:53 --> Router Class Initialized
INFO - 2022-01-12 14:22:53 --> Output Class Initialized
INFO - 2022-01-12 14:22:53 --> Security Class Initialized
DEBUG - 2022-01-12 14:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 14:22:53 --> Input Class Initialized
INFO - 2022-01-12 14:22:53 --> Language Class Initialized
INFO - 2022-01-12 14:22:53 --> Loader Class Initialized
INFO - 2022-01-12 14:22:53 --> Helper loaded: url_helper
INFO - 2022-01-12 14:22:53 --> Helper loaded: form_helper
INFO - 2022-01-12 14:22:53 --> Helper loaded: common_helper
INFO - 2022-01-12 14:22:53 --> Database Driver Class Initialized
DEBUG - 2022-01-12 14:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 14:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 14:22:53 --> Controller Class Initialized
INFO - 2022-01-12 14:22:53 --> Form Validation Class Initialized
DEBUG - 2022-01-12 14:22:53 --> Encrypt Class Initialized
DEBUG - 2022-01-12 14:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:22:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 14:22:53 --> Email Class Initialized
INFO - 2022-01-12 14:22:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 14:22:53 --> Calendar Class Initialized
INFO - 2022-01-12 14:22:53 --> Model "Login_model" initialized
INFO - 2022-01-12 14:22:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 14:22:53 --> Final output sent to browser
DEBUG - 2022-01-12 14:22:53 --> Total execution time: 0.0231
ERROR - 2022-01-12 14:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 14:22:54 --> Config Class Initialized
INFO - 2022-01-12 14:22:54 --> Hooks Class Initialized
DEBUG - 2022-01-12 14:22:54 --> UTF-8 Support Enabled
INFO - 2022-01-12 14:22:54 --> Utf8 Class Initialized
INFO - 2022-01-12 14:22:54 --> URI Class Initialized
DEBUG - 2022-01-12 14:22:54 --> No URI present. Default controller set.
INFO - 2022-01-12 14:22:54 --> Router Class Initialized
INFO - 2022-01-12 14:22:54 --> Output Class Initialized
INFO - 2022-01-12 14:22:54 --> Security Class Initialized
DEBUG - 2022-01-12 14:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 14:22:54 --> Input Class Initialized
INFO - 2022-01-12 14:22:54 --> Language Class Initialized
INFO - 2022-01-12 14:22:54 --> Loader Class Initialized
INFO - 2022-01-12 14:22:54 --> Helper loaded: url_helper
INFO - 2022-01-12 14:22:54 --> Helper loaded: form_helper
INFO - 2022-01-12 14:22:54 --> Helper loaded: common_helper
INFO - 2022-01-12 14:22:54 --> Database Driver Class Initialized
DEBUG - 2022-01-12 14:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 14:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 14:22:54 --> Controller Class Initialized
INFO - 2022-01-12 14:22:54 --> Form Validation Class Initialized
DEBUG - 2022-01-12 14:22:54 --> Encrypt Class Initialized
DEBUG - 2022-01-12 14:22:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:22:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 14:22:54 --> Email Class Initialized
INFO - 2022-01-12 14:22:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 14:22:54 --> Calendar Class Initialized
INFO - 2022-01-12 14:22:54 --> Model "Login_model" initialized
INFO - 2022-01-12 14:22:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 14:22:54 --> Final output sent to browser
DEBUG - 2022-01-12 14:22:54 --> Total execution time: 0.0223
ERROR - 2022-01-12 14:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 14:22:55 --> Config Class Initialized
INFO - 2022-01-12 14:22:55 --> Hooks Class Initialized
DEBUG - 2022-01-12 14:22:55 --> UTF-8 Support Enabled
INFO - 2022-01-12 14:22:55 --> Utf8 Class Initialized
INFO - 2022-01-12 14:22:55 --> URI Class Initialized
INFO - 2022-01-12 14:22:55 --> Router Class Initialized
INFO - 2022-01-12 14:22:55 --> Output Class Initialized
INFO - 2022-01-12 14:22:55 --> Security Class Initialized
DEBUG - 2022-01-12 14:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 14:22:55 --> Input Class Initialized
INFO - 2022-01-12 14:22:55 --> Language Class Initialized
INFO - 2022-01-12 14:22:55 --> Loader Class Initialized
INFO - 2022-01-12 14:22:55 --> Helper loaded: url_helper
INFO - 2022-01-12 14:22:55 --> Helper loaded: form_helper
INFO - 2022-01-12 14:22:55 --> Helper loaded: common_helper
INFO - 2022-01-12 14:22:55 --> Database Driver Class Initialized
DEBUG - 2022-01-12 14:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 14:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 14:22:55 --> Controller Class Initialized
INFO - 2022-01-12 14:22:55 --> Form Validation Class Initialized
DEBUG - 2022-01-12 14:22:55 --> Encrypt Class Initialized
DEBUG - 2022-01-12 14:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:22:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 14:22:55 --> Email Class Initialized
INFO - 2022-01-12 14:22:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 14:22:55 --> Calendar Class Initialized
INFO - 2022-01-12 14:22:55 --> Model "Login_model" initialized
ERROR - 2022-01-12 14:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 14:22:55 --> Config Class Initialized
INFO - 2022-01-12 14:22:55 --> Hooks Class Initialized
DEBUG - 2022-01-12 14:22:55 --> UTF-8 Support Enabled
INFO - 2022-01-12 14:22:55 --> Utf8 Class Initialized
INFO - 2022-01-12 14:22:55 --> URI Class Initialized
INFO - 2022-01-12 14:22:55 --> Router Class Initialized
INFO - 2022-01-12 14:22:55 --> Output Class Initialized
INFO - 2022-01-12 14:22:55 --> Security Class Initialized
DEBUG - 2022-01-12 14:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 14:22:55 --> Input Class Initialized
INFO - 2022-01-12 14:22:55 --> Language Class Initialized
INFO - 2022-01-12 14:22:55 --> Loader Class Initialized
INFO - 2022-01-12 14:22:55 --> Helper loaded: url_helper
INFO - 2022-01-12 14:22:55 --> Helper loaded: form_helper
INFO - 2022-01-12 14:22:55 --> Helper loaded: common_helper
INFO - 2022-01-12 14:22:55 --> Database Driver Class Initialized
DEBUG - 2022-01-12 14:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 14:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 14:22:55 --> Controller Class Initialized
INFO - 2022-01-12 14:22:55 --> Form Validation Class Initialized
DEBUG - 2022-01-12 14:22:55 --> Encrypt Class Initialized
DEBUG - 2022-01-12 14:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:22:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 14:22:55 --> Email Class Initialized
INFO - 2022-01-12 14:22:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 14:22:55 --> Calendar Class Initialized
INFO - 2022-01-12 14:22:55 --> Model "Login_model" initialized
ERROR - 2022-01-12 15:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 15:12:02 --> Config Class Initialized
INFO - 2022-01-12 15:12:02 --> Hooks Class Initialized
DEBUG - 2022-01-12 15:12:02 --> UTF-8 Support Enabled
INFO - 2022-01-12 15:12:02 --> Utf8 Class Initialized
INFO - 2022-01-12 15:12:02 --> URI Class Initialized
DEBUG - 2022-01-12 15:12:02 --> No URI present. Default controller set.
INFO - 2022-01-12 15:12:02 --> Router Class Initialized
INFO - 2022-01-12 15:12:02 --> Output Class Initialized
INFO - 2022-01-12 15:12:02 --> Security Class Initialized
DEBUG - 2022-01-12 15:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 15:12:02 --> Input Class Initialized
INFO - 2022-01-12 15:12:02 --> Language Class Initialized
INFO - 2022-01-12 15:12:02 --> Loader Class Initialized
INFO - 2022-01-12 15:12:02 --> Helper loaded: url_helper
INFO - 2022-01-12 15:12:02 --> Helper loaded: form_helper
INFO - 2022-01-12 15:12:02 --> Helper loaded: common_helper
INFO - 2022-01-12 15:12:02 --> Database Driver Class Initialized
DEBUG - 2022-01-12 15:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 15:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 15:12:02 --> Controller Class Initialized
INFO - 2022-01-12 15:12:02 --> Form Validation Class Initialized
DEBUG - 2022-01-12 15:12:02 --> Encrypt Class Initialized
DEBUG - 2022-01-12 15:12:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:12:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 15:12:02 --> Email Class Initialized
INFO - 2022-01-12 15:12:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 15:12:02 --> Calendar Class Initialized
INFO - 2022-01-12 15:12:02 --> Model "Login_model" initialized
INFO - 2022-01-12 15:12:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 15:12:02 --> Final output sent to browser
DEBUG - 2022-01-12 15:12:02 --> Total execution time: 0.0362
ERROR - 2022-01-12 17:17:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 17:17:01 --> Config Class Initialized
INFO - 2022-01-12 17:17:01 --> Hooks Class Initialized
DEBUG - 2022-01-12 17:17:01 --> UTF-8 Support Enabled
INFO - 2022-01-12 17:17:01 --> Utf8 Class Initialized
INFO - 2022-01-12 17:17:01 --> URI Class Initialized
INFO - 2022-01-12 17:17:01 --> Router Class Initialized
INFO - 2022-01-12 17:17:01 --> Output Class Initialized
INFO - 2022-01-12 17:17:01 --> Security Class Initialized
DEBUG - 2022-01-12 17:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 17:17:01 --> Input Class Initialized
INFO - 2022-01-12 17:17:01 --> Language Class Initialized
ERROR - 2022-01-12 17:17:01 --> 404 Page Not Found: Filemanager/dialog.php
ERROR - 2022-01-12 17:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 17:17:02 --> Config Class Initialized
INFO - 2022-01-12 17:17:02 --> Hooks Class Initialized
DEBUG - 2022-01-12 17:17:02 --> UTF-8 Support Enabled
INFO - 2022-01-12 17:17:02 --> Utf8 Class Initialized
INFO - 2022-01-12 17:17:02 --> URI Class Initialized
INFO - 2022-01-12 17:17:02 --> Router Class Initialized
INFO - 2022-01-12 17:17:02 --> Output Class Initialized
INFO - 2022-01-12 17:17:02 --> Security Class Initialized
DEBUG - 2022-01-12 17:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 17:17:02 --> Input Class Initialized
INFO - 2022-01-12 17:17:02 --> Language Class Initialized
ERROR - 2022-01-12 17:17:02 --> 404 Page Not Found: Assets/filemanager
ERROR - 2022-01-12 21:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-12 21:04:42 --> Config Class Initialized
INFO - 2022-01-12 21:04:42 --> Hooks Class Initialized
DEBUG - 2022-01-12 21:04:42 --> UTF-8 Support Enabled
INFO - 2022-01-12 21:04:42 --> Utf8 Class Initialized
INFO - 2022-01-12 21:04:42 --> URI Class Initialized
DEBUG - 2022-01-12 21:04:42 --> No URI present. Default controller set.
INFO - 2022-01-12 21:04:42 --> Router Class Initialized
INFO - 2022-01-12 21:04:42 --> Output Class Initialized
INFO - 2022-01-12 21:04:42 --> Security Class Initialized
DEBUG - 2022-01-12 21:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-12 21:04:42 --> Input Class Initialized
INFO - 2022-01-12 21:04:42 --> Language Class Initialized
INFO - 2022-01-12 21:04:42 --> Loader Class Initialized
INFO - 2022-01-12 21:04:42 --> Helper loaded: url_helper
INFO - 2022-01-12 21:04:42 --> Helper loaded: form_helper
INFO - 2022-01-12 21:04:42 --> Helper loaded: common_helper
INFO - 2022-01-12 21:04:42 --> Database Driver Class Initialized
DEBUG - 2022-01-12 21:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-12 21:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-12 21:04:42 --> Controller Class Initialized
INFO - 2022-01-12 21:04:42 --> Form Validation Class Initialized
DEBUG - 2022-01-12 21:04:42 --> Encrypt Class Initialized
DEBUG - 2022-01-12 21:04:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 21:04:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-12 21:04:42 --> Email Class Initialized
INFO - 2022-01-12 21:04:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-12 21:04:42 --> Calendar Class Initialized
INFO - 2022-01-12 21:04:42 --> Model "Login_model" initialized
INFO - 2022-01-12 21:04:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-12 21:04:42 --> Final output sent to browser
DEBUG - 2022-01-12 21:04:42 --> Total execution time: 0.0242
