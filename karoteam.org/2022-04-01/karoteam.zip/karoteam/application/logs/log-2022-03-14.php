<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-14 00:06:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:06:51 --> Config Class Initialized
INFO - 2022-03-14 00:06:51 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:06:51 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:06:51 --> Utf8 Class Initialized
INFO - 2022-03-14 00:06:51 --> URI Class Initialized
DEBUG - 2022-03-14 00:06:51 --> No URI present. Default controller set.
INFO - 2022-03-14 00:06:51 --> Router Class Initialized
INFO - 2022-03-14 00:06:51 --> Output Class Initialized
INFO - 2022-03-14 00:06:51 --> Security Class Initialized
DEBUG - 2022-03-14 00:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:06:51 --> Input Class Initialized
INFO - 2022-03-14 00:06:51 --> Language Class Initialized
INFO - 2022-03-14 00:06:51 --> Loader Class Initialized
INFO - 2022-03-14 00:06:51 --> Helper loaded: url_helper
INFO - 2022-03-14 00:06:51 --> Helper loaded: form_helper
INFO - 2022-03-14 00:06:51 --> Helper loaded: common_helper
INFO - 2022-03-14 00:06:51 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:06:51 --> Controller Class Initialized
INFO - 2022-03-14 00:06:51 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:06:51 --> Encrypt Class Initialized
DEBUG - 2022-03-14 00:06:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 00:06:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 00:06:51 --> Email Class Initialized
INFO - 2022-03-14 00:06:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 00:06:51 --> Calendar Class Initialized
INFO - 2022-03-14 00:06:51 --> Model "Login_model" initialized
INFO - 2022-03-14 00:06:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 00:06:51 --> Final output sent to browser
DEBUG - 2022-03-14 00:06:51 --> Total execution time: 0.0329
ERROR - 2022-03-14 00:06:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:06:53 --> Config Class Initialized
INFO - 2022-03-14 00:06:53 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:06:53 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:06:53 --> Utf8 Class Initialized
INFO - 2022-03-14 00:06:53 --> URI Class Initialized
DEBUG - 2022-03-14 00:06:53 --> No URI present. Default controller set.
INFO - 2022-03-14 00:06:53 --> Router Class Initialized
INFO - 2022-03-14 00:06:53 --> Output Class Initialized
INFO - 2022-03-14 00:06:53 --> Security Class Initialized
DEBUG - 2022-03-14 00:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:06:53 --> Input Class Initialized
INFO - 2022-03-14 00:06:53 --> Language Class Initialized
INFO - 2022-03-14 00:06:53 --> Loader Class Initialized
INFO - 2022-03-14 00:06:53 --> Helper loaded: url_helper
INFO - 2022-03-14 00:06:53 --> Helper loaded: form_helper
INFO - 2022-03-14 00:06:53 --> Helper loaded: common_helper
INFO - 2022-03-14 00:06:53 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:06:53 --> Controller Class Initialized
INFO - 2022-03-14 00:06:53 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:06:53 --> Encrypt Class Initialized
DEBUG - 2022-03-14 00:06:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 00:06:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 00:06:53 --> Email Class Initialized
INFO - 2022-03-14 00:06:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 00:06:53 --> Calendar Class Initialized
INFO - 2022-03-14 00:06:53 --> Model "Login_model" initialized
INFO - 2022-03-14 00:06:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 00:06:53 --> Final output sent to browser
DEBUG - 2022-03-14 00:06:53 --> Total execution time: 0.0254
ERROR - 2022-03-14 00:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:07:01 --> Config Class Initialized
INFO - 2022-03-14 00:07:01 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:07:01 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:07:01 --> Utf8 Class Initialized
INFO - 2022-03-14 00:07:01 --> URI Class Initialized
INFO - 2022-03-14 00:07:01 --> Router Class Initialized
INFO - 2022-03-14 00:07:01 --> Output Class Initialized
INFO - 2022-03-14 00:07:01 --> Security Class Initialized
DEBUG - 2022-03-14 00:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:07:01 --> Input Class Initialized
INFO - 2022-03-14 00:07:01 --> Language Class Initialized
INFO - 2022-03-14 00:07:01 --> Loader Class Initialized
INFO - 2022-03-14 00:07:01 --> Helper loaded: url_helper
INFO - 2022-03-14 00:07:01 --> Helper loaded: form_helper
INFO - 2022-03-14 00:07:01 --> Helper loaded: common_helper
INFO - 2022-03-14 00:07:01 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:07:01 --> Controller Class Initialized
INFO - 2022-03-14 00:07:01 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:07:01 --> Encrypt Class Initialized
DEBUG - 2022-03-14 00:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 00:07:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 00:07:01 --> Email Class Initialized
INFO - 2022-03-14 00:07:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 00:07:01 --> Calendar Class Initialized
INFO - 2022-03-14 00:07:01 --> Model "Login_model" initialized
INFO - 2022-03-14 00:07:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-14 00:07:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:07:02 --> Config Class Initialized
INFO - 2022-03-14 00:07:02 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:07:02 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:07:02 --> Utf8 Class Initialized
INFO - 2022-03-14 00:07:02 --> URI Class Initialized
INFO - 2022-03-14 00:07:02 --> Router Class Initialized
INFO - 2022-03-14 00:07:02 --> Output Class Initialized
INFO - 2022-03-14 00:07:02 --> Security Class Initialized
DEBUG - 2022-03-14 00:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:07:02 --> Input Class Initialized
INFO - 2022-03-14 00:07:02 --> Language Class Initialized
INFO - 2022-03-14 00:07:02 --> Loader Class Initialized
INFO - 2022-03-14 00:07:02 --> Helper loaded: url_helper
INFO - 2022-03-14 00:07:02 --> Helper loaded: form_helper
INFO - 2022-03-14 00:07:02 --> Helper loaded: common_helper
INFO - 2022-03-14 00:07:02 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:07:02 --> Controller Class Initialized
INFO - 2022-03-14 00:07:02 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:07:02 --> Encrypt Class Initialized
INFO - 2022-03-14 00:07:02 --> Model "Login_model" initialized
INFO - 2022-03-14 00:07:02 --> Model "Dashboard_model" initialized
INFO - 2022-03-14 00:07:02 --> Model "Case_model" initialized
INFO - 2022-03-14 00:07:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:07:34 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-14 00:07:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:07:34 --> Final output sent to browser
DEBUG - 2022-03-14 00:07:34 --> Total execution time: 31.9142
ERROR - 2022-03-14 00:07:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:07:58 --> Config Class Initialized
INFO - 2022-03-14 00:07:58 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:07:58 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:07:58 --> Utf8 Class Initialized
INFO - 2022-03-14 00:07:58 --> URI Class Initialized
INFO - 2022-03-14 00:07:58 --> Router Class Initialized
INFO - 2022-03-14 00:07:58 --> Output Class Initialized
INFO - 2022-03-14 00:07:58 --> Security Class Initialized
DEBUG - 2022-03-14 00:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:07:58 --> Input Class Initialized
INFO - 2022-03-14 00:07:58 --> Language Class Initialized
INFO - 2022-03-14 00:07:58 --> Loader Class Initialized
INFO - 2022-03-14 00:07:58 --> Helper loaded: url_helper
INFO - 2022-03-14 00:07:58 --> Helper loaded: form_helper
INFO - 2022-03-14 00:07:58 --> Helper loaded: common_helper
INFO - 2022-03-14 00:07:58 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:07:58 --> Controller Class Initialized
INFO - 2022-03-14 00:07:58 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:07:58 --> Encrypt Class Initialized
INFO - 2022-03-14 00:07:58 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:07:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:07:58 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:07:58 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:07:58 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:07:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:08:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 00:08:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:08:08 --> Final output sent to browser
DEBUG - 2022-03-14 00:08:08 --> Total execution time: 7.6377
ERROR - 2022-03-14 00:13:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:13:51 --> Config Class Initialized
INFO - 2022-03-14 00:13:51 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:13:51 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:13:51 --> Utf8 Class Initialized
INFO - 2022-03-14 00:13:51 --> URI Class Initialized
INFO - 2022-03-14 00:13:51 --> Router Class Initialized
INFO - 2022-03-14 00:13:51 --> Output Class Initialized
INFO - 2022-03-14 00:13:51 --> Security Class Initialized
DEBUG - 2022-03-14 00:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:13:51 --> Input Class Initialized
INFO - 2022-03-14 00:13:51 --> Language Class Initialized
INFO - 2022-03-14 00:13:51 --> Loader Class Initialized
INFO - 2022-03-14 00:13:51 --> Helper loaded: url_helper
INFO - 2022-03-14 00:13:51 --> Helper loaded: form_helper
INFO - 2022-03-14 00:13:51 --> Helper loaded: common_helper
INFO - 2022-03-14 00:13:51 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:13:51 --> Controller Class Initialized
INFO - 2022-03-14 00:13:51 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:13:51 --> Encrypt Class Initialized
INFO - 2022-03-14 00:13:51 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:13:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:13:51 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:13:51 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:13:51 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:13:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:13:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:13:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:13:51 --> Final output sent to browser
DEBUG - 2022-03-14 00:13:51 --> Total execution time: 0.0660
ERROR - 2022-03-14 00:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:14:33 --> Config Class Initialized
INFO - 2022-03-14 00:14:33 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:14:33 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:14:33 --> Utf8 Class Initialized
INFO - 2022-03-14 00:14:33 --> URI Class Initialized
INFO - 2022-03-14 00:14:33 --> Router Class Initialized
INFO - 2022-03-14 00:14:33 --> Output Class Initialized
INFO - 2022-03-14 00:14:33 --> Security Class Initialized
DEBUG - 2022-03-14 00:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:14:33 --> Input Class Initialized
INFO - 2022-03-14 00:14:33 --> Language Class Initialized
INFO - 2022-03-14 00:14:33 --> Loader Class Initialized
INFO - 2022-03-14 00:14:33 --> Helper loaded: url_helper
INFO - 2022-03-14 00:14:33 --> Helper loaded: form_helper
INFO - 2022-03-14 00:14:33 --> Helper loaded: common_helper
INFO - 2022-03-14 00:14:33 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:14:33 --> Controller Class Initialized
INFO - 2022-03-14 00:14:33 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:14:33 --> Encrypt Class Initialized
INFO - 2022-03-14 00:14:33 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:14:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:14:33 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:14:33 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:14:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:14:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:14:34 --> Config Class Initialized
INFO - 2022-03-14 00:14:34 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:14:34 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:14:34 --> Utf8 Class Initialized
INFO - 2022-03-14 00:14:34 --> URI Class Initialized
INFO - 2022-03-14 00:14:34 --> Router Class Initialized
INFO - 2022-03-14 00:14:34 --> Output Class Initialized
INFO - 2022-03-14 00:14:34 --> Security Class Initialized
DEBUG - 2022-03-14 00:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:14:34 --> Input Class Initialized
INFO - 2022-03-14 00:14:34 --> Language Class Initialized
INFO - 2022-03-14 00:14:34 --> Loader Class Initialized
INFO - 2022-03-14 00:14:34 --> Helper loaded: url_helper
INFO - 2022-03-14 00:14:34 --> Helper loaded: form_helper
INFO - 2022-03-14 00:14:34 --> Helper loaded: common_helper
INFO - 2022-03-14 00:14:34 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:14:34 --> Controller Class Initialized
INFO - 2022-03-14 00:14:34 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:14:34 --> Encrypt Class Initialized
INFO - 2022-03-14 00:14:34 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:14:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:14:34 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:14:34 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:14:34 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:14:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:14:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:14:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:14:34 --> Final output sent to browser
DEBUG - 2022-03-14 00:14:34 --> Total execution time: 0.0720
ERROR - 2022-03-14 00:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:14:35 --> Config Class Initialized
INFO - 2022-03-14 00:14:35 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:14:35 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:14:35 --> Utf8 Class Initialized
INFO - 2022-03-14 00:14:35 --> URI Class Initialized
INFO - 2022-03-14 00:14:35 --> Router Class Initialized
INFO - 2022-03-14 00:14:35 --> Output Class Initialized
INFO - 2022-03-14 00:14:35 --> Security Class Initialized
DEBUG - 2022-03-14 00:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:14:35 --> Input Class Initialized
INFO - 2022-03-14 00:14:35 --> Language Class Initialized
INFO - 2022-03-14 00:14:35 --> Loader Class Initialized
INFO - 2022-03-14 00:14:35 --> Helper loaded: url_helper
INFO - 2022-03-14 00:14:35 --> Helper loaded: form_helper
INFO - 2022-03-14 00:14:35 --> Helper loaded: common_helper
INFO - 2022-03-14 00:14:35 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:14:35 --> Controller Class Initialized
INFO - 2022-03-14 00:14:35 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:14:35 --> Encrypt Class Initialized
INFO - 2022-03-14 00:14:35 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:14:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:14:35 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:14:35 --> Model "Users_model" initialized
INFO - 2022-03-14 00:14:35 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:14:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:14:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:14:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:14:35 --> Final output sent to browser
DEBUG - 2022-03-14 00:14:35 --> Total execution time: 0.1590
ERROR - 2022-03-14 00:15:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:15:48 --> Config Class Initialized
INFO - 2022-03-14 00:15:48 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:15:48 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:15:48 --> Utf8 Class Initialized
INFO - 2022-03-14 00:15:48 --> URI Class Initialized
INFO - 2022-03-14 00:15:48 --> Router Class Initialized
INFO - 2022-03-14 00:15:48 --> Output Class Initialized
INFO - 2022-03-14 00:15:48 --> Security Class Initialized
DEBUG - 2022-03-14 00:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:15:48 --> Input Class Initialized
INFO - 2022-03-14 00:15:48 --> Language Class Initialized
INFO - 2022-03-14 00:15:48 --> Loader Class Initialized
INFO - 2022-03-14 00:15:48 --> Helper loaded: url_helper
INFO - 2022-03-14 00:15:48 --> Helper loaded: form_helper
INFO - 2022-03-14 00:15:48 --> Helper loaded: common_helper
INFO - 2022-03-14 00:15:48 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:15:48 --> Controller Class Initialized
INFO - 2022-03-14 00:15:48 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:15:48 --> Encrypt Class Initialized
INFO - 2022-03-14 00:15:48 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:15:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:15:48 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:15:48 --> Model "Users_model" initialized
INFO - 2022-03-14 00:15:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:15:49 --> Config Class Initialized
INFO - 2022-03-14 00:15:49 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:15:49 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:15:49 --> Utf8 Class Initialized
INFO - 2022-03-14 00:15:49 --> URI Class Initialized
INFO - 2022-03-14 00:15:49 --> Router Class Initialized
INFO - 2022-03-14 00:15:49 --> Output Class Initialized
INFO - 2022-03-14 00:15:49 --> Security Class Initialized
DEBUG - 2022-03-14 00:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:15:49 --> Input Class Initialized
INFO - 2022-03-14 00:15:49 --> Language Class Initialized
INFO - 2022-03-14 00:15:49 --> Loader Class Initialized
INFO - 2022-03-14 00:15:49 --> Helper loaded: url_helper
INFO - 2022-03-14 00:15:49 --> Helper loaded: form_helper
INFO - 2022-03-14 00:15:49 --> Helper loaded: common_helper
INFO - 2022-03-14 00:15:49 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:15:49 --> Controller Class Initialized
INFO - 2022-03-14 00:15:49 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:15:49 --> Encrypt Class Initialized
INFO - 2022-03-14 00:15:49 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:15:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:15:49 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:15:49 --> Model "Users_model" initialized
INFO - 2022-03-14 00:15:49 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:15:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:15:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:15:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:15:49 --> Final output sent to browser
DEBUG - 2022-03-14 00:15:49 --> Total execution time: 0.0857
ERROR - 2022-03-14 00:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:16:23 --> Config Class Initialized
INFO - 2022-03-14 00:16:23 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:16:23 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:16:23 --> Utf8 Class Initialized
INFO - 2022-03-14 00:16:23 --> URI Class Initialized
INFO - 2022-03-14 00:16:23 --> Router Class Initialized
INFO - 2022-03-14 00:16:23 --> Output Class Initialized
INFO - 2022-03-14 00:16:23 --> Security Class Initialized
DEBUG - 2022-03-14 00:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:16:23 --> Input Class Initialized
INFO - 2022-03-14 00:16:23 --> Language Class Initialized
INFO - 2022-03-14 00:16:23 --> Loader Class Initialized
INFO - 2022-03-14 00:16:23 --> Helper loaded: url_helper
INFO - 2022-03-14 00:16:23 --> Helper loaded: form_helper
INFO - 2022-03-14 00:16:23 --> Helper loaded: common_helper
INFO - 2022-03-14 00:16:23 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:16:23 --> Controller Class Initialized
INFO - 2022-03-14 00:16:23 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:16:23 --> Encrypt Class Initialized
INFO - 2022-03-14 00:16:23 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:16:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:16:23 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:16:23 --> Model "Users_model" initialized
INFO - 2022-03-14 00:16:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:16:24 --> Config Class Initialized
INFO - 2022-03-14 00:16:24 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:16:24 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:16:24 --> Utf8 Class Initialized
INFO - 2022-03-14 00:16:24 --> URI Class Initialized
INFO - 2022-03-14 00:16:24 --> Router Class Initialized
INFO - 2022-03-14 00:16:24 --> Output Class Initialized
INFO - 2022-03-14 00:16:24 --> Security Class Initialized
DEBUG - 2022-03-14 00:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:16:24 --> Input Class Initialized
INFO - 2022-03-14 00:16:24 --> Language Class Initialized
INFO - 2022-03-14 00:16:24 --> Loader Class Initialized
INFO - 2022-03-14 00:16:24 --> Helper loaded: url_helper
INFO - 2022-03-14 00:16:24 --> Helper loaded: form_helper
INFO - 2022-03-14 00:16:24 --> Helper loaded: common_helper
INFO - 2022-03-14 00:16:24 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:16:24 --> Controller Class Initialized
INFO - 2022-03-14 00:16:24 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:16:24 --> Encrypt Class Initialized
INFO - 2022-03-14 00:16:24 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:16:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:16:24 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:16:24 --> Model "Users_model" initialized
INFO - 2022-03-14 00:16:24 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:16:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:16:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:16:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:16:24 --> Final output sent to browser
DEBUG - 2022-03-14 00:16:24 --> Total execution time: 0.1288
ERROR - 2022-03-14 00:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:18:27 --> Config Class Initialized
INFO - 2022-03-14 00:18:27 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:18:27 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:18:27 --> Utf8 Class Initialized
INFO - 2022-03-14 00:18:27 --> URI Class Initialized
INFO - 2022-03-14 00:18:27 --> Router Class Initialized
INFO - 2022-03-14 00:18:27 --> Output Class Initialized
INFO - 2022-03-14 00:18:27 --> Security Class Initialized
DEBUG - 2022-03-14 00:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:18:27 --> Input Class Initialized
INFO - 2022-03-14 00:18:27 --> Language Class Initialized
INFO - 2022-03-14 00:18:27 --> Loader Class Initialized
INFO - 2022-03-14 00:18:27 --> Helper loaded: url_helper
INFO - 2022-03-14 00:18:27 --> Helper loaded: form_helper
INFO - 2022-03-14 00:18:27 --> Helper loaded: common_helper
INFO - 2022-03-14 00:18:27 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:18:27 --> Controller Class Initialized
INFO - 2022-03-14 00:18:27 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:18:27 --> Encrypt Class Initialized
INFO - 2022-03-14 00:18:27 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:18:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:18:27 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:18:27 --> Model "Users_model" initialized
INFO - 2022-03-14 00:18:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:18:27 --> Config Class Initialized
INFO - 2022-03-14 00:18:27 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:18:27 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:18:27 --> Utf8 Class Initialized
INFO - 2022-03-14 00:18:27 --> URI Class Initialized
INFO - 2022-03-14 00:18:27 --> Router Class Initialized
INFO - 2022-03-14 00:18:27 --> Output Class Initialized
INFO - 2022-03-14 00:18:27 --> Security Class Initialized
DEBUG - 2022-03-14 00:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:18:27 --> Input Class Initialized
INFO - 2022-03-14 00:18:27 --> Language Class Initialized
INFO - 2022-03-14 00:18:27 --> Loader Class Initialized
INFO - 2022-03-14 00:18:27 --> Helper loaded: url_helper
INFO - 2022-03-14 00:18:27 --> Helper loaded: form_helper
INFO - 2022-03-14 00:18:27 --> Helper loaded: common_helper
INFO - 2022-03-14 00:18:27 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:18:27 --> Controller Class Initialized
INFO - 2022-03-14 00:18:27 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:18:27 --> Encrypt Class Initialized
INFO - 2022-03-14 00:18:27 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:18:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:18:27 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:18:27 --> Model "Users_model" initialized
INFO - 2022-03-14 00:18:27 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:18:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:18:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:18:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:18:28 --> Final output sent to browser
DEBUG - 2022-03-14 00:18:28 --> Total execution time: 0.0773
ERROR - 2022-03-14 00:20:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:20:52 --> Config Class Initialized
INFO - 2022-03-14 00:20:52 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:20:52 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:20:52 --> Utf8 Class Initialized
INFO - 2022-03-14 00:20:52 --> URI Class Initialized
INFO - 2022-03-14 00:20:52 --> Router Class Initialized
INFO - 2022-03-14 00:20:52 --> Output Class Initialized
INFO - 2022-03-14 00:20:52 --> Security Class Initialized
DEBUG - 2022-03-14 00:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:20:52 --> Input Class Initialized
INFO - 2022-03-14 00:20:52 --> Language Class Initialized
INFO - 2022-03-14 00:20:52 --> Loader Class Initialized
INFO - 2022-03-14 00:20:52 --> Helper loaded: url_helper
INFO - 2022-03-14 00:20:52 --> Helper loaded: form_helper
INFO - 2022-03-14 00:20:52 --> Helper loaded: common_helper
INFO - 2022-03-14 00:20:52 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:20:52 --> Controller Class Initialized
INFO - 2022-03-14 00:20:52 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:20:52 --> Encrypt Class Initialized
INFO - 2022-03-14 00:20:52 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:20:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:20:52 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:20:52 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:20:52 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:20:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:21:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 00:21:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:21:04 --> Final output sent to browser
DEBUG - 2022-03-14 00:21:04 --> Total execution time: 10.0910
ERROR - 2022-03-14 00:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:23:35 --> Config Class Initialized
INFO - 2022-03-14 00:23:35 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:23:35 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:23:35 --> Utf8 Class Initialized
INFO - 2022-03-14 00:23:35 --> URI Class Initialized
INFO - 2022-03-14 00:23:35 --> Router Class Initialized
INFO - 2022-03-14 00:23:35 --> Output Class Initialized
INFO - 2022-03-14 00:23:35 --> Security Class Initialized
DEBUG - 2022-03-14 00:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:23:35 --> Input Class Initialized
INFO - 2022-03-14 00:23:35 --> Language Class Initialized
INFO - 2022-03-14 00:23:35 --> Loader Class Initialized
INFO - 2022-03-14 00:23:35 --> Helper loaded: url_helper
INFO - 2022-03-14 00:23:35 --> Helper loaded: form_helper
INFO - 2022-03-14 00:23:35 --> Helper loaded: common_helper
INFO - 2022-03-14 00:23:35 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:23:35 --> Controller Class Initialized
INFO - 2022-03-14 00:23:35 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:23:35 --> Encrypt Class Initialized
INFO - 2022-03-14 00:23:35 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:23:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:23:35 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:23:35 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:23:35 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:23:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:23:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:23:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:23:35 --> Final output sent to browser
DEBUG - 2022-03-14 00:23:35 --> Total execution time: 0.0757
ERROR - 2022-03-14 00:27:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:27:49 --> Config Class Initialized
INFO - 2022-03-14 00:27:49 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:27:49 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:27:49 --> Utf8 Class Initialized
INFO - 2022-03-14 00:27:49 --> URI Class Initialized
INFO - 2022-03-14 00:27:49 --> Router Class Initialized
INFO - 2022-03-14 00:27:49 --> Output Class Initialized
INFO - 2022-03-14 00:27:49 --> Security Class Initialized
DEBUG - 2022-03-14 00:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:27:49 --> Input Class Initialized
INFO - 2022-03-14 00:27:49 --> Language Class Initialized
INFO - 2022-03-14 00:27:49 --> Loader Class Initialized
INFO - 2022-03-14 00:27:49 --> Helper loaded: url_helper
INFO - 2022-03-14 00:27:49 --> Helper loaded: form_helper
INFO - 2022-03-14 00:27:49 --> Helper loaded: common_helper
INFO - 2022-03-14 00:27:49 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:27:49 --> Controller Class Initialized
INFO - 2022-03-14 00:27:49 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:27:49 --> Encrypt Class Initialized
INFO - 2022-03-14 00:27:49 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:27:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:27:49 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:27:49 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:27:49 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:27:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:27:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 00:27:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:28:01 --> Final output sent to browser
DEBUG - 2022-03-14 00:28:01 --> Total execution time: 10.3174
ERROR - 2022-03-14 00:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:28:35 --> Config Class Initialized
INFO - 2022-03-14 00:28:35 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:28:35 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:28:35 --> Utf8 Class Initialized
INFO - 2022-03-14 00:28:35 --> URI Class Initialized
INFO - 2022-03-14 00:28:35 --> Router Class Initialized
INFO - 2022-03-14 00:28:35 --> Output Class Initialized
INFO - 2022-03-14 00:28:35 --> Security Class Initialized
DEBUG - 2022-03-14 00:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:28:35 --> Input Class Initialized
INFO - 2022-03-14 00:28:35 --> Language Class Initialized
INFO - 2022-03-14 00:28:35 --> Loader Class Initialized
INFO - 2022-03-14 00:28:35 --> Helper loaded: url_helper
INFO - 2022-03-14 00:28:35 --> Helper loaded: form_helper
INFO - 2022-03-14 00:28:35 --> Helper loaded: common_helper
INFO - 2022-03-14 00:28:35 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:28:35 --> Controller Class Initialized
INFO - 2022-03-14 00:28:35 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:28:35 --> Encrypt Class Initialized
INFO - 2022-03-14 00:28:35 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:28:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:28:35 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:28:35 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:28:35 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:28:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:28:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:28:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:28:35 --> Final output sent to browser
DEBUG - 2022-03-14 00:28:35 --> Total execution time: 0.0761
ERROR - 2022-03-14 00:29:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:29:20 --> Config Class Initialized
INFO - 2022-03-14 00:29:20 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:29:20 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:29:20 --> Utf8 Class Initialized
INFO - 2022-03-14 00:29:20 --> URI Class Initialized
INFO - 2022-03-14 00:29:20 --> Router Class Initialized
INFO - 2022-03-14 00:29:20 --> Output Class Initialized
INFO - 2022-03-14 00:29:20 --> Security Class Initialized
DEBUG - 2022-03-14 00:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:29:20 --> Input Class Initialized
INFO - 2022-03-14 00:29:20 --> Language Class Initialized
INFO - 2022-03-14 00:29:20 --> Loader Class Initialized
INFO - 2022-03-14 00:29:20 --> Helper loaded: url_helper
INFO - 2022-03-14 00:29:20 --> Helper loaded: form_helper
INFO - 2022-03-14 00:29:20 --> Helper loaded: common_helper
INFO - 2022-03-14 00:29:20 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:29:20 --> Controller Class Initialized
INFO - 2022-03-14 00:29:20 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:29:20 --> Encrypt Class Initialized
INFO - 2022-03-14 00:29:20 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:29:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:29:20 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:29:20 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:29:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:29:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:29:20 --> Config Class Initialized
INFO - 2022-03-14 00:29:20 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:29:20 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:29:20 --> Utf8 Class Initialized
INFO - 2022-03-14 00:29:20 --> URI Class Initialized
INFO - 2022-03-14 00:29:20 --> Router Class Initialized
INFO - 2022-03-14 00:29:20 --> Output Class Initialized
INFO - 2022-03-14 00:29:20 --> Security Class Initialized
DEBUG - 2022-03-14 00:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:29:20 --> Input Class Initialized
INFO - 2022-03-14 00:29:20 --> Language Class Initialized
INFO - 2022-03-14 00:29:21 --> Loader Class Initialized
INFO - 2022-03-14 00:29:21 --> Helper loaded: url_helper
INFO - 2022-03-14 00:29:21 --> Helper loaded: form_helper
INFO - 2022-03-14 00:29:21 --> Helper loaded: common_helper
INFO - 2022-03-14 00:29:21 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:29:21 --> Controller Class Initialized
INFO - 2022-03-14 00:29:21 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:29:21 --> Encrypt Class Initialized
INFO - 2022-03-14 00:29:21 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:29:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:29:21 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:29:21 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:29:21 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:29:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:29:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:29:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:29:21 --> Final output sent to browser
DEBUG - 2022-03-14 00:29:21 --> Total execution time: 0.1422
ERROR - 2022-03-14 00:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:29:21 --> Config Class Initialized
INFO - 2022-03-14 00:29:21 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:29:21 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:29:21 --> Utf8 Class Initialized
INFO - 2022-03-14 00:29:21 --> URI Class Initialized
INFO - 2022-03-14 00:29:21 --> Router Class Initialized
INFO - 2022-03-14 00:29:21 --> Output Class Initialized
INFO - 2022-03-14 00:29:21 --> Security Class Initialized
DEBUG - 2022-03-14 00:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:29:21 --> Input Class Initialized
INFO - 2022-03-14 00:29:21 --> Language Class Initialized
INFO - 2022-03-14 00:29:21 --> Loader Class Initialized
INFO - 2022-03-14 00:29:21 --> Helper loaded: url_helper
INFO - 2022-03-14 00:29:21 --> Helper loaded: form_helper
INFO - 2022-03-14 00:29:21 --> Helper loaded: common_helper
INFO - 2022-03-14 00:29:21 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:29:21 --> Controller Class Initialized
INFO - 2022-03-14 00:29:21 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:29:21 --> Encrypt Class Initialized
INFO - 2022-03-14 00:29:21 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:29:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:29:21 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:29:21 --> Model "Users_model" initialized
INFO - 2022-03-14 00:29:21 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:29:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:29:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:29:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:29:22 --> Final output sent to browser
DEBUG - 2022-03-14 00:29:22 --> Total execution time: 0.0853
ERROR - 2022-03-14 00:30:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:30:24 --> Config Class Initialized
INFO - 2022-03-14 00:30:24 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:30:24 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:30:24 --> Utf8 Class Initialized
INFO - 2022-03-14 00:30:24 --> URI Class Initialized
INFO - 2022-03-14 00:30:24 --> Router Class Initialized
INFO - 2022-03-14 00:30:24 --> Output Class Initialized
INFO - 2022-03-14 00:30:24 --> Security Class Initialized
DEBUG - 2022-03-14 00:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:30:24 --> Input Class Initialized
INFO - 2022-03-14 00:30:24 --> Language Class Initialized
INFO - 2022-03-14 00:30:24 --> Loader Class Initialized
INFO - 2022-03-14 00:30:24 --> Helper loaded: url_helper
INFO - 2022-03-14 00:30:24 --> Helper loaded: form_helper
INFO - 2022-03-14 00:30:24 --> Helper loaded: common_helper
INFO - 2022-03-14 00:30:24 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:30:24 --> Controller Class Initialized
INFO - 2022-03-14 00:30:24 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:30:24 --> Encrypt Class Initialized
INFO - 2022-03-14 00:30:24 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:30:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:30:24 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:30:24 --> Model "Users_model" initialized
INFO - 2022-03-14 00:30:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:30:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:30:25 --> Config Class Initialized
INFO - 2022-03-14 00:30:25 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:30:25 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:30:25 --> Utf8 Class Initialized
INFO - 2022-03-14 00:30:25 --> URI Class Initialized
INFO - 2022-03-14 00:30:25 --> Router Class Initialized
INFO - 2022-03-14 00:30:25 --> Output Class Initialized
INFO - 2022-03-14 00:30:25 --> Security Class Initialized
DEBUG - 2022-03-14 00:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:30:25 --> Input Class Initialized
INFO - 2022-03-14 00:30:25 --> Language Class Initialized
INFO - 2022-03-14 00:30:25 --> Loader Class Initialized
INFO - 2022-03-14 00:30:25 --> Helper loaded: url_helper
INFO - 2022-03-14 00:30:25 --> Helper loaded: form_helper
INFO - 2022-03-14 00:30:25 --> Helper loaded: common_helper
INFO - 2022-03-14 00:30:25 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:30:25 --> Controller Class Initialized
INFO - 2022-03-14 00:30:25 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:30:25 --> Encrypt Class Initialized
INFO - 2022-03-14 00:30:25 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:30:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:30:25 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:30:25 --> Model "Users_model" initialized
INFO - 2022-03-14 00:30:25 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:30:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:30:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:30:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:30:25 --> Final output sent to browser
DEBUG - 2022-03-14 00:30:25 --> Total execution time: 0.0670
ERROR - 2022-03-14 00:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:32:28 --> Config Class Initialized
INFO - 2022-03-14 00:32:28 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:32:28 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:32:28 --> Utf8 Class Initialized
INFO - 2022-03-14 00:32:28 --> URI Class Initialized
INFO - 2022-03-14 00:32:28 --> Router Class Initialized
INFO - 2022-03-14 00:32:28 --> Output Class Initialized
INFO - 2022-03-14 00:32:28 --> Security Class Initialized
DEBUG - 2022-03-14 00:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:32:28 --> Input Class Initialized
INFO - 2022-03-14 00:32:28 --> Language Class Initialized
INFO - 2022-03-14 00:32:28 --> Loader Class Initialized
INFO - 2022-03-14 00:32:28 --> Helper loaded: url_helper
INFO - 2022-03-14 00:32:28 --> Helper loaded: form_helper
INFO - 2022-03-14 00:32:28 --> Helper loaded: common_helper
INFO - 2022-03-14 00:32:28 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:32:28 --> Controller Class Initialized
INFO - 2022-03-14 00:32:28 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:32:28 --> Encrypt Class Initialized
INFO - 2022-03-14 00:32:28 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:32:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:32:28 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:32:28 --> Model "Users_model" initialized
INFO - 2022-03-14 00:32:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:32:28 --> Config Class Initialized
INFO - 2022-03-14 00:32:28 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:32:28 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:32:28 --> Utf8 Class Initialized
INFO - 2022-03-14 00:32:28 --> URI Class Initialized
INFO - 2022-03-14 00:32:28 --> Router Class Initialized
INFO - 2022-03-14 00:32:28 --> Output Class Initialized
INFO - 2022-03-14 00:32:28 --> Security Class Initialized
DEBUG - 2022-03-14 00:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:32:28 --> Input Class Initialized
INFO - 2022-03-14 00:32:28 --> Language Class Initialized
INFO - 2022-03-14 00:32:28 --> Loader Class Initialized
INFO - 2022-03-14 00:32:28 --> Helper loaded: url_helper
INFO - 2022-03-14 00:32:28 --> Helper loaded: form_helper
INFO - 2022-03-14 00:32:28 --> Helper loaded: common_helper
INFO - 2022-03-14 00:32:28 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:32:28 --> Controller Class Initialized
INFO - 2022-03-14 00:32:28 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:32:28 --> Encrypt Class Initialized
INFO - 2022-03-14 00:32:28 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:32:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:32:28 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:32:28 --> Model "Users_model" initialized
INFO - 2022-03-14 00:32:28 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:32:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:32:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:32:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:32:29 --> Final output sent to browser
DEBUG - 2022-03-14 00:32:29 --> Total execution time: 0.1112
ERROR - 2022-03-14 00:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:39:13 --> Config Class Initialized
INFO - 2022-03-14 00:39:13 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:39:13 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:39:13 --> Utf8 Class Initialized
INFO - 2022-03-14 00:39:13 --> URI Class Initialized
INFO - 2022-03-14 00:39:13 --> Router Class Initialized
INFO - 2022-03-14 00:39:13 --> Output Class Initialized
INFO - 2022-03-14 00:39:13 --> Security Class Initialized
DEBUG - 2022-03-14 00:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:39:13 --> Input Class Initialized
INFO - 2022-03-14 00:39:13 --> Language Class Initialized
INFO - 2022-03-14 00:39:13 --> Loader Class Initialized
INFO - 2022-03-14 00:39:13 --> Helper loaded: url_helper
INFO - 2022-03-14 00:39:13 --> Helper loaded: form_helper
INFO - 2022-03-14 00:39:13 --> Helper loaded: common_helper
INFO - 2022-03-14 00:39:13 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:39:13 --> Controller Class Initialized
ERROR - 2022-03-14 00:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:39:13 --> Config Class Initialized
INFO - 2022-03-14 00:39:13 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:39:13 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:39:13 --> Utf8 Class Initialized
INFO - 2022-03-14 00:39:13 --> URI Class Initialized
INFO - 2022-03-14 00:39:13 --> Router Class Initialized
INFO - 2022-03-14 00:39:13 --> Output Class Initialized
INFO - 2022-03-14 00:39:13 --> Security Class Initialized
DEBUG - 2022-03-14 00:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:39:13 --> Input Class Initialized
INFO - 2022-03-14 00:39:13 --> Language Class Initialized
INFO - 2022-03-14 00:39:13 --> Loader Class Initialized
INFO - 2022-03-14 00:39:13 --> Helper loaded: url_helper
INFO - 2022-03-14 00:39:13 --> Helper loaded: form_helper
INFO - 2022-03-14 00:39:13 --> Helper loaded: common_helper
INFO - 2022-03-14 00:39:13 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:39:13 --> Controller Class Initialized
INFO - 2022-03-14 00:39:13 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:39:13 --> Encrypt Class Initialized
DEBUG - 2022-03-14 00:39:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 00:39:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 00:39:13 --> Email Class Initialized
INFO - 2022-03-14 00:39:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 00:39:13 --> Calendar Class Initialized
INFO - 2022-03-14 00:39:13 --> Model "Login_model" initialized
INFO - 2022-03-14 00:39:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 00:39:13 --> Final output sent to browser
DEBUG - 2022-03-14 00:39:13 --> Total execution time: 0.0446
ERROR - 2022-03-14 00:39:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:39:46 --> Config Class Initialized
INFO - 2022-03-14 00:39:46 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:39:46 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:39:46 --> Utf8 Class Initialized
INFO - 2022-03-14 00:39:46 --> URI Class Initialized
INFO - 2022-03-14 00:39:46 --> Router Class Initialized
INFO - 2022-03-14 00:39:46 --> Output Class Initialized
INFO - 2022-03-14 00:39:46 --> Security Class Initialized
DEBUG - 2022-03-14 00:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:39:46 --> Input Class Initialized
INFO - 2022-03-14 00:39:46 --> Language Class Initialized
INFO - 2022-03-14 00:39:46 --> Loader Class Initialized
INFO - 2022-03-14 00:39:46 --> Helper loaded: url_helper
INFO - 2022-03-14 00:39:46 --> Helper loaded: form_helper
INFO - 2022-03-14 00:39:46 --> Helper loaded: common_helper
INFO - 2022-03-14 00:39:46 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:39:46 --> Controller Class Initialized
INFO - 2022-03-14 00:39:46 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:39:46 --> Encrypt Class Initialized
DEBUG - 2022-03-14 00:39:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 00:39:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 00:39:46 --> Email Class Initialized
INFO - 2022-03-14 00:39:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 00:39:46 --> Calendar Class Initialized
INFO - 2022-03-14 00:39:46 --> Model "Login_model" initialized
INFO - 2022-03-14 00:39:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-14 00:39:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:39:47 --> Config Class Initialized
INFO - 2022-03-14 00:39:47 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:39:47 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:39:47 --> Utf8 Class Initialized
INFO - 2022-03-14 00:39:47 --> URI Class Initialized
INFO - 2022-03-14 00:39:47 --> Router Class Initialized
INFO - 2022-03-14 00:39:47 --> Output Class Initialized
INFO - 2022-03-14 00:39:47 --> Security Class Initialized
DEBUG - 2022-03-14 00:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:39:47 --> Input Class Initialized
INFO - 2022-03-14 00:39:47 --> Language Class Initialized
INFO - 2022-03-14 00:39:47 --> Loader Class Initialized
INFO - 2022-03-14 00:39:47 --> Helper loaded: url_helper
INFO - 2022-03-14 00:39:47 --> Helper loaded: form_helper
INFO - 2022-03-14 00:39:47 --> Helper loaded: common_helper
INFO - 2022-03-14 00:39:47 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:39:47 --> Controller Class Initialized
INFO - 2022-03-14 00:39:47 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:39:47 --> Encrypt Class Initialized
INFO - 2022-03-14 00:39:47 --> Model "Login_model" initialized
INFO - 2022-03-14 00:39:47 --> Model "Dashboard_model" initialized
INFO - 2022-03-14 00:39:47 --> Model "Case_model" initialized
INFO - 2022-03-14 00:39:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:39:49 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-14 00:39:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:39:49 --> Final output sent to browser
DEBUG - 2022-03-14 00:39:49 --> Total execution time: 2.3419
ERROR - 2022-03-14 00:40:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:40:42 --> Config Class Initialized
INFO - 2022-03-14 00:40:42 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:40:42 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:40:42 --> Utf8 Class Initialized
INFO - 2022-03-14 00:40:42 --> URI Class Initialized
INFO - 2022-03-14 00:40:42 --> Router Class Initialized
INFO - 2022-03-14 00:40:42 --> Output Class Initialized
INFO - 2022-03-14 00:40:42 --> Security Class Initialized
DEBUG - 2022-03-14 00:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:40:42 --> Input Class Initialized
INFO - 2022-03-14 00:40:42 --> Language Class Initialized
INFO - 2022-03-14 00:40:42 --> Loader Class Initialized
INFO - 2022-03-14 00:40:42 --> Helper loaded: url_helper
INFO - 2022-03-14 00:40:42 --> Helper loaded: form_helper
INFO - 2022-03-14 00:40:42 --> Helper loaded: common_helper
INFO - 2022-03-14 00:40:42 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:40:42 --> Controller Class Initialized
INFO - 2022-03-14 00:40:42 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:40:42 --> Encrypt Class Initialized
INFO - 2022-03-14 00:40:42 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:40:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:40:42 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:40:42 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:40:42 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:40:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:40:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 00:40:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:40:42 --> Final output sent to browser
DEBUG - 2022-03-14 00:40:42 --> Total execution time: 0.0902
ERROR - 2022-03-14 00:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:40:52 --> Config Class Initialized
INFO - 2022-03-14 00:40:52 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:40:52 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:40:52 --> Utf8 Class Initialized
INFO - 2022-03-14 00:40:52 --> URI Class Initialized
INFO - 2022-03-14 00:40:52 --> Router Class Initialized
INFO - 2022-03-14 00:40:52 --> Output Class Initialized
INFO - 2022-03-14 00:40:52 --> Security Class Initialized
DEBUG - 2022-03-14 00:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:40:52 --> Input Class Initialized
INFO - 2022-03-14 00:40:52 --> Language Class Initialized
INFO - 2022-03-14 00:40:52 --> Loader Class Initialized
INFO - 2022-03-14 00:40:52 --> Helper loaded: url_helper
INFO - 2022-03-14 00:40:52 --> Helper loaded: form_helper
INFO - 2022-03-14 00:40:52 --> Helper loaded: common_helper
INFO - 2022-03-14 00:40:52 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:40:52 --> Controller Class Initialized
INFO - 2022-03-14 00:40:52 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:40:52 --> Encrypt Class Initialized
INFO - 2022-03-14 00:40:52 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:40:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:40:52 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:40:52 --> Model "Users_model" initialized
INFO - 2022-03-14 00:40:52 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:40:52 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-14 00:40:53 --> Final output sent to browser
DEBUG - 2022-03-14 00:40:53 --> Total execution time: 1.2860
ERROR - 2022-03-14 00:47:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:47:34 --> Config Class Initialized
INFO - 2022-03-14 00:47:34 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:47:34 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:47:34 --> Utf8 Class Initialized
INFO - 2022-03-14 00:47:34 --> URI Class Initialized
INFO - 2022-03-14 00:47:34 --> Router Class Initialized
INFO - 2022-03-14 00:47:34 --> Output Class Initialized
INFO - 2022-03-14 00:47:34 --> Security Class Initialized
DEBUG - 2022-03-14 00:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:47:34 --> Input Class Initialized
INFO - 2022-03-14 00:47:34 --> Language Class Initialized
INFO - 2022-03-14 00:47:34 --> Loader Class Initialized
INFO - 2022-03-14 00:47:34 --> Helper loaded: url_helper
INFO - 2022-03-14 00:47:34 --> Helper loaded: form_helper
INFO - 2022-03-14 00:47:34 --> Helper loaded: common_helper
INFO - 2022-03-14 00:47:34 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:47:34 --> Controller Class Initialized
INFO - 2022-03-14 00:47:34 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:47:34 --> Encrypt Class Initialized
INFO - 2022-03-14 00:47:34 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:47:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:47:34 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:47:34 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:47:34 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:47:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:47:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:47:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:47:34 --> Final output sent to browser
DEBUG - 2022-03-14 00:47:34 --> Total execution time: 0.0704
ERROR - 2022-03-14 00:48:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:48:03 --> Config Class Initialized
INFO - 2022-03-14 00:48:03 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:48:03 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:48:03 --> Utf8 Class Initialized
INFO - 2022-03-14 00:48:03 --> URI Class Initialized
INFO - 2022-03-14 00:48:03 --> Router Class Initialized
INFO - 2022-03-14 00:48:03 --> Output Class Initialized
INFO - 2022-03-14 00:48:03 --> Security Class Initialized
DEBUG - 2022-03-14 00:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:48:03 --> Input Class Initialized
INFO - 2022-03-14 00:48:03 --> Language Class Initialized
INFO - 2022-03-14 00:48:03 --> Loader Class Initialized
INFO - 2022-03-14 00:48:03 --> Helper loaded: url_helper
INFO - 2022-03-14 00:48:03 --> Helper loaded: form_helper
INFO - 2022-03-14 00:48:03 --> Helper loaded: common_helper
INFO - 2022-03-14 00:48:03 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:48:03 --> Controller Class Initialized
INFO - 2022-03-14 00:48:03 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:48:03 --> Encrypt Class Initialized
INFO - 2022-03-14 00:48:03 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:48:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:48:03 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:48:03 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:48:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:48:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:48:03 --> Config Class Initialized
INFO - 2022-03-14 00:48:03 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:48:03 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:48:03 --> Utf8 Class Initialized
INFO - 2022-03-14 00:48:03 --> URI Class Initialized
INFO - 2022-03-14 00:48:03 --> Router Class Initialized
INFO - 2022-03-14 00:48:03 --> Output Class Initialized
INFO - 2022-03-14 00:48:03 --> Security Class Initialized
DEBUG - 2022-03-14 00:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:48:03 --> Input Class Initialized
INFO - 2022-03-14 00:48:03 --> Language Class Initialized
INFO - 2022-03-14 00:48:03 --> Loader Class Initialized
INFO - 2022-03-14 00:48:03 --> Helper loaded: url_helper
INFO - 2022-03-14 00:48:03 --> Helper loaded: form_helper
INFO - 2022-03-14 00:48:03 --> Helper loaded: common_helper
INFO - 2022-03-14 00:48:03 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:48:03 --> Controller Class Initialized
INFO - 2022-03-14 00:48:03 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:48:03 --> Encrypt Class Initialized
INFO - 2022-03-14 00:48:03 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:48:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:48:03 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:48:03 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:48:03 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:48:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:48:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:48:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:48:03 --> Final output sent to browser
DEBUG - 2022-03-14 00:48:03 --> Total execution time: 0.0599
ERROR - 2022-03-14 00:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:48:04 --> Config Class Initialized
INFO - 2022-03-14 00:48:04 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:48:04 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:48:04 --> Utf8 Class Initialized
INFO - 2022-03-14 00:48:04 --> URI Class Initialized
INFO - 2022-03-14 00:48:04 --> Router Class Initialized
INFO - 2022-03-14 00:48:04 --> Output Class Initialized
INFO - 2022-03-14 00:48:04 --> Security Class Initialized
DEBUG - 2022-03-14 00:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:48:04 --> Input Class Initialized
INFO - 2022-03-14 00:48:04 --> Language Class Initialized
INFO - 2022-03-14 00:48:04 --> Loader Class Initialized
INFO - 2022-03-14 00:48:04 --> Helper loaded: url_helper
INFO - 2022-03-14 00:48:04 --> Helper loaded: form_helper
INFO - 2022-03-14 00:48:04 --> Helper loaded: common_helper
INFO - 2022-03-14 00:48:04 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:48:04 --> Controller Class Initialized
INFO - 2022-03-14 00:48:04 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:48:04 --> Encrypt Class Initialized
INFO - 2022-03-14 00:48:04 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:48:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:48:04 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:48:04 --> Model "Users_model" initialized
INFO - 2022-03-14 00:48:04 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:48:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:48:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:48:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:48:05 --> Final output sent to browser
DEBUG - 2022-03-14 00:48:05 --> Total execution time: 0.0767
ERROR - 2022-03-14 00:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:49:08 --> Config Class Initialized
INFO - 2022-03-14 00:49:08 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:49:08 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:49:08 --> Utf8 Class Initialized
INFO - 2022-03-14 00:49:08 --> URI Class Initialized
INFO - 2022-03-14 00:49:08 --> Router Class Initialized
INFO - 2022-03-14 00:49:08 --> Output Class Initialized
INFO - 2022-03-14 00:49:08 --> Security Class Initialized
DEBUG - 2022-03-14 00:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:49:08 --> Input Class Initialized
INFO - 2022-03-14 00:49:08 --> Language Class Initialized
INFO - 2022-03-14 00:49:08 --> Loader Class Initialized
INFO - 2022-03-14 00:49:08 --> Helper loaded: url_helper
INFO - 2022-03-14 00:49:08 --> Helper loaded: form_helper
INFO - 2022-03-14 00:49:08 --> Helper loaded: common_helper
INFO - 2022-03-14 00:49:08 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:49:08 --> Controller Class Initialized
INFO - 2022-03-14 00:49:08 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:49:08 --> Encrypt Class Initialized
INFO - 2022-03-14 00:49:08 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:49:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:49:08 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:49:08 --> Model "Users_model" initialized
INFO - 2022-03-14 00:49:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:49:09 --> Config Class Initialized
INFO - 2022-03-14 00:49:09 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:49:09 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:49:09 --> Utf8 Class Initialized
INFO - 2022-03-14 00:49:09 --> URI Class Initialized
INFO - 2022-03-14 00:49:09 --> Router Class Initialized
INFO - 2022-03-14 00:49:09 --> Output Class Initialized
INFO - 2022-03-14 00:49:09 --> Security Class Initialized
DEBUG - 2022-03-14 00:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:49:09 --> Input Class Initialized
INFO - 2022-03-14 00:49:09 --> Language Class Initialized
INFO - 2022-03-14 00:49:09 --> Loader Class Initialized
INFO - 2022-03-14 00:49:09 --> Helper loaded: url_helper
INFO - 2022-03-14 00:49:09 --> Helper loaded: form_helper
INFO - 2022-03-14 00:49:09 --> Helper loaded: common_helper
INFO - 2022-03-14 00:49:09 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:49:09 --> Controller Class Initialized
INFO - 2022-03-14 00:49:09 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:49:09 --> Encrypt Class Initialized
INFO - 2022-03-14 00:49:09 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:49:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:49:09 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:49:09 --> Model "Users_model" initialized
INFO - 2022-03-14 00:49:09 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:49:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:49:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:49:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:49:09 --> Final output sent to browser
DEBUG - 2022-03-14 00:49:09 --> Total execution time: 0.1699
ERROR - 2022-03-14 00:50:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:50:37 --> Config Class Initialized
INFO - 2022-03-14 00:50:37 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:50:37 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:50:37 --> Utf8 Class Initialized
INFO - 2022-03-14 00:50:37 --> URI Class Initialized
INFO - 2022-03-14 00:50:37 --> Router Class Initialized
INFO - 2022-03-14 00:50:37 --> Output Class Initialized
INFO - 2022-03-14 00:50:37 --> Security Class Initialized
DEBUG - 2022-03-14 00:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:50:37 --> Input Class Initialized
INFO - 2022-03-14 00:50:37 --> Language Class Initialized
INFO - 2022-03-14 00:50:37 --> Loader Class Initialized
INFO - 2022-03-14 00:50:37 --> Helper loaded: url_helper
INFO - 2022-03-14 00:50:37 --> Helper loaded: form_helper
INFO - 2022-03-14 00:50:37 --> Helper loaded: common_helper
INFO - 2022-03-14 00:50:37 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:50:37 --> Controller Class Initialized
INFO - 2022-03-14 00:50:37 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:50:37 --> Encrypt Class Initialized
INFO - 2022-03-14 00:50:37 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:50:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:50:37 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:50:37 --> Model "Users_model" initialized
INFO - 2022-03-14 00:50:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:50:38 --> Config Class Initialized
INFO - 2022-03-14 00:50:38 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:50:38 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:50:38 --> Utf8 Class Initialized
INFO - 2022-03-14 00:50:38 --> URI Class Initialized
INFO - 2022-03-14 00:50:38 --> Router Class Initialized
INFO - 2022-03-14 00:50:38 --> Output Class Initialized
INFO - 2022-03-14 00:50:38 --> Security Class Initialized
DEBUG - 2022-03-14 00:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:50:38 --> Input Class Initialized
INFO - 2022-03-14 00:50:38 --> Language Class Initialized
INFO - 2022-03-14 00:50:38 --> Loader Class Initialized
INFO - 2022-03-14 00:50:38 --> Helper loaded: url_helper
INFO - 2022-03-14 00:50:38 --> Helper loaded: form_helper
INFO - 2022-03-14 00:50:38 --> Helper loaded: common_helper
INFO - 2022-03-14 00:50:38 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:50:38 --> Controller Class Initialized
INFO - 2022-03-14 00:50:38 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:50:38 --> Encrypt Class Initialized
INFO - 2022-03-14 00:50:38 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:50:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:50:38 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:50:38 --> Model "Users_model" initialized
INFO - 2022-03-14 00:50:38 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:50:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:50:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:50:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:50:38 --> Final output sent to browser
DEBUG - 2022-03-14 00:50:38 --> Total execution time: 0.0498
ERROR - 2022-03-14 00:52:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:52:04 --> Config Class Initialized
INFO - 2022-03-14 00:52:04 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:52:04 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:52:04 --> Utf8 Class Initialized
INFO - 2022-03-14 00:52:04 --> URI Class Initialized
INFO - 2022-03-14 00:52:04 --> Router Class Initialized
INFO - 2022-03-14 00:52:04 --> Output Class Initialized
INFO - 2022-03-14 00:52:04 --> Security Class Initialized
DEBUG - 2022-03-14 00:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:52:04 --> Input Class Initialized
INFO - 2022-03-14 00:52:04 --> Language Class Initialized
INFO - 2022-03-14 00:52:04 --> Loader Class Initialized
INFO - 2022-03-14 00:52:04 --> Helper loaded: url_helper
INFO - 2022-03-14 00:52:04 --> Helper loaded: form_helper
INFO - 2022-03-14 00:52:04 --> Helper loaded: common_helper
INFO - 2022-03-14 00:52:04 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:52:04 --> Controller Class Initialized
INFO - 2022-03-14 00:52:04 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:52:04 --> Encrypt Class Initialized
INFO - 2022-03-14 00:52:04 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:52:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:52:04 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:52:04 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:52:04 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:52:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:52:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:52:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:52:04 --> Final output sent to browser
DEBUG - 2022-03-14 00:52:04 --> Total execution time: 0.0866
ERROR - 2022-03-14 00:52:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:52:46 --> Config Class Initialized
INFO - 2022-03-14 00:52:46 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:52:46 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:52:46 --> Utf8 Class Initialized
INFO - 2022-03-14 00:52:46 --> URI Class Initialized
INFO - 2022-03-14 00:52:46 --> Router Class Initialized
INFO - 2022-03-14 00:52:46 --> Output Class Initialized
INFO - 2022-03-14 00:52:46 --> Security Class Initialized
DEBUG - 2022-03-14 00:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:52:46 --> Input Class Initialized
INFO - 2022-03-14 00:52:46 --> Language Class Initialized
INFO - 2022-03-14 00:52:46 --> Loader Class Initialized
INFO - 2022-03-14 00:52:46 --> Helper loaded: url_helper
INFO - 2022-03-14 00:52:46 --> Helper loaded: form_helper
INFO - 2022-03-14 00:52:46 --> Helper loaded: common_helper
INFO - 2022-03-14 00:52:46 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:52:46 --> Controller Class Initialized
INFO - 2022-03-14 00:52:46 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:52:46 --> Encrypt Class Initialized
INFO - 2022-03-14 00:52:46 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:52:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:52:46 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:52:46 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:52:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:52:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:52:47 --> Config Class Initialized
INFO - 2022-03-14 00:52:47 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:52:47 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:52:47 --> Utf8 Class Initialized
INFO - 2022-03-14 00:52:47 --> URI Class Initialized
INFO - 2022-03-14 00:52:47 --> Router Class Initialized
INFO - 2022-03-14 00:52:47 --> Output Class Initialized
INFO - 2022-03-14 00:52:47 --> Security Class Initialized
DEBUG - 2022-03-14 00:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:52:47 --> Input Class Initialized
INFO - 2022-03-14 00:52:47 --> Language Class Initialized
INFO - 2022-03-14 00:52:47 --> Loader Class Initialized
INFO - 2022-03-14 00:52:47 --> Helper loaded: url_helper
INFO - 2022-03-14 00:52:47 --> Helper loaded: form_helper
INFO - 2022-03-14 00:52:47 --> Helper loaded: common_helper
INFO - 2022-03-14 00:52:47 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:52:47 --> Controller Class Initialized
INFO - 2022-03-14 00:52:47 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:52:47 --> Encrypt Class Initialized
INFO - 2022-03-14 00:52:47 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:52:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:52:47 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:52:47 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:52:47 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:52:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:52:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:52:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:52:47 --> Final output sent to browser
DEBUG - 2022-03-14 00:52:47 --> Total execution time: 0.0520
ERROR - 2022-03-14 00:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:52:48 --> Config Class Initialized
INFO - 2022-03-14 00:52:48 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:52:48 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:52:48 --> Utf8 Class Initialized
INFO - 2022-03-14 00:52:48 --> URI Class Initialized
INFO - 2022-03-14 00:52:48 --> Router Class Initialized
INFO - 2022-03-14 00:52:48 --> Output Class Initialized
INFO - 2022-03-14 00:52:48 --> Security Class Initialized
DEBUG - 2022-03-14 00:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:52:48 --> Input Class Initialized
INFO - 2022-03-14 00:52:48 --> Language Class Initialized
INFO - 2022-03-14 00:52:48 --> Loader Class Initialized
INFO - 2022-03-14 00:52:48 --> Helper loaded: url_helper
INFO - 2022-03-14 00:52:48 --> Helper loaded: form_helper
INFO - 2022-03-14 00:52:48 --> Helper loaded: common_helper
INFO - 2022-03-14 00:52:48 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:52:48 --> Controller Class Initialized
INFO - 2022-03-14 00:52:48 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:52:48 --> Encrypt Class Initialized
INFO - 2022-03-14 00:52:48 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:52:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:52:48 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:52:48 --> Model "Users_model" initialized
INFO - 2022-03-14 00:52:48 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:52:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:52:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:52:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:52:48 --> Final output sent to browser
DEBUG - 2022-03-14 00:52:48 --> Total execution time: 0.0585
ERROR - 2022-03-14 00:53:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:53:04 --> Config Class Initialized
INFO - 2022-03-14 00:53:04 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:53:04 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:53:04 --> Utf8 Class Initialized
INFO - 2022-03-14 00:53:04 --> URI Class Initialized
INFO - 2022-03-14 00:53:04 --> Router Class Initialized
INFO - 2022-03-14 00:53:04 --> Output Class Initialized
INFO - 2022-03-14 00:53:04 --> Security Class Initialized
DEBUG - 2022-03-14 00:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:53:04 --> Input Class Initialized
INFO - 2022-03-14 00:53:04 --> Language Class Initialized
INFO - 2022-03-14 00:53:04 --> Loader Class Initialized
INFO - 2022-03-14 00:53:04 --> Helper loaded: url_helper
INFO - 2022-03-14 00:53:04 --> Helper loaded: form_helper
INFO - 2022-03-14 00:53:04 --> Helper loaded: common_helper
INFO - 2022-03-14 00:53:04 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:53:04 --> Controller Class Initialized
INFO - 2022-03-14 00:53:04 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:53:04 --> Encrypt Class Initialized
INFO - 2022-03-14 00:53:04 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:53:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:53:04 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:53:04 --> Model "Users_model" initialized
INFO - 2022-03-14 00:53:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:53:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:53:05 --> Config Class Initialized
INFO - 2022-03-14 00:53:05 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:53:05 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:53:05 --> Utf8 Class Initialized
INFO - 2022-03-14 00:53:05 --> URI Class Initialized
INFO - 2022-03-14 00:53:05 --> Router Class Initialized
INFO - 2022-03-14 00:53:05 --> Output Class Initialized
INFO - 2022-03-14 00:53:05 --> Security Class Initialized
DEBUG - 2022-03-14 00:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:53:05 --> Input Class Initialized
INFO - 2022-03-14 00:53:05 --> Language Class Initialized
INFO - 2022-03-14 00:53:05 --> Loader Class Initialized
INFO - 2022-03-14 00:53:05 --> Helper loaded: url_helper
INFO - 2022-03-14 00:53:05 --> Helper loaded: form_helper
INFO - 2022-03-14 00:53:05 --> Helper loaded: common_helper
INFO - 2022-03-14 00:53:05 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:53:05 --> Controller Class Initialized
INFO - 2022-03-14 00:53:05 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:53:05 --> Encrypt Class Initialized
INFO - 2022-03-14 00:53:05 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:53:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:53:05 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:53:05 --> Model "Users_model" initialized
INFO - 2022-03-14 00:53:05 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:53:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:53:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:53:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:53:05 --> Final output sent to browser
DEBUG - 2022-03-14 00:53:05 --> Total execution time: 0.0582
ERROR - 2022-03-14 00:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:53:12 --> Config Class Initialized
INFO - 2022-03-14 00:53:12 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:53:12 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:53:12 --> Utf8 Class Initialized
INFO - 2022-03-14 00:53:12 --> URI Class Initialized
INFO - 2022-03-14 00:53:12 --> Router Class Initialized
INFO - 2022-03-14 00:53:12 --> Output Class Initialized
INFO - 2022-03-14 00:53:12 --> Security Class Initialized
DEBUG - 2022-03-14 00:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:53:12 --> Input Class Initialized
INFO - 2022-03-14 00:53:12 --> Language Class Initialized
INFO - 2022-03-14 00:53:12 --> Loader Class Initialized
INFO - 2022-03-14 00:53:12 --> Helper loaded: url_helper
INFO - 2022-03-14 00:53:12 --> Helper loaded: form_helper
INFO - 2022-03-14 00:53:12 --> Helper loaded: common_helper
INFO - 2022-03-14 00:53:12 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:53:12 --> Controller Class Initialized
INFO - 2022-03-14 00:53:12 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:53:12 --> Encrypt Class Initialized
INFO - 2022-03-14 00:53:12 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:53:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:53:12 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:53:12 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:53:12 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:53:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:53:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 00:53:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:53:12 --> Final output sent to browser
DEBUG - 2022-03-14 00:53:12 --> Total execution time: 0.0487
ERROR - 2022-03-14 00:53:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:53:21 --> Config Class Initialized
INFO - 2022-03-14 00:53:21 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:53:21 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:53:21 --> Utf8 Class Initialized
INFO - 2022-03-14 00:53:21 --> URI Class Initialized
INFO - 2022-03-14 00:53:21 --> Router Class Initialized
INFO - 2022-03-14 00:53:21 --> Output Class Initialized
INFO - 2022-03-14 00:53:21 --> Security Class Initialized
DEBUG - 2022-03-14 00:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:53:21 --> Input Class Initialized
INFO - 2022-03-14 00:53:21 --> Language Class Initialized
INFO - 2022-03-14 00:53:21 --> Loader Class Initialized
INFO - 2022-03-14 00:53:21 --> Helper loaded: url_helper
INFO - 2022-03-14 00:53:21 --> Helper loaded: form_helper
INFO - 2022-03-14 00:53:21 --> Helper loaded: common_helper
INFO - 2022-03-14 00:53:21 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:53:21 --> Controller Class Initialized
INFO - 2022-03-14 00:53:21 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:53:21 --> Encrypt Class Initialized
INFO - 2022-03-14 00:53:21 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:53:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:53:21 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:53:21 --> Model "Users_model" initialized
INFO - 2022-03-14 00:53:21 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:53:21 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-14 00:53:22 --> Final output sent to browser
DEBUG - 2022-03-14 00:53:22 --> Total execution time: 1.1397
ERROR - 2022-03-14 00:54:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:54:12 --> Config Class Initialized
INFO - 2022-03-14 00:54:12 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:54:12 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:54:12 --> Utf8 Class Initialized
INFO - 2022-03-14 00:54:12 --> URI Class Initialized
INFO - 2022-03-14 00:54:12 --> Router Class Initialized
INFO - 2022-03-14 00:54:12 --> Output Class Initialized
INFO - 2022-03-14 00:54:12 --> Security Class Initialized
DEBUG - 2022-03-14 00:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:54:12 --> Input Class Initialized
INFO - 2022-03-14 00:54:12 --> Language Class Initialized
INFO - 2022-03-14 00:54:12 --> Loader Class Initialized
INFO - 2022-03-14 00:54:12 --> Helper loaded: url_helper
INFO - 2022-03-14 00:54:12 --> Helper loaded: form_helper
INFO - 2022-03-14 00:54:12 --> Helper loaded: common_helper
INFO - 2022-03-14 00:54:12 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:54:12 --> Controller Class Initialized
INFO - 2022-03-14 00:54:12 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:54:12 --> Encrypt Class Initialized
INFO - 2022-03-14 00:54:12 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:54:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:54:12 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:54:12 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:54:12 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:54:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:54:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:54:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:54:12 --> Final output sent to browser
DEBUG - 2022-03-14 00:54:12 --> Total execution time: 0.1048
ERROR - 2022-03-14 00:54:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:54:21 --> Config Class Initialized
INFO - 2022-03-14 00:54:21 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:54:21 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:54:21 --> Utf8 Class Initialized
INFO - 2022-03-14 00:54:21 --> URI Class Initialized
INFO - 2022-03-14 00:54:21 --> Router Class Initialized
INFO - 2022-03-14 00:54:21 --> Output Class Initialized
INFO - 2022-03-14 00:54:21 --> Security Class Initialized
DEBUG - 2022-03-14 00:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:54:21 --> Input Class Initialized
INFO - 2022-03-14 00:54:21 --> Language Class Initialized
INFO - 2022-03-14 00:54:21 --> Loader Class Initialized
INFO - 2022-03-14 00:54:21 --> Helper loaded: url_helper
INFO - 2022-03-14 00:54:21 --> Helper loaded: form_helper
INFO - 2022-03-14 00:54:21 --> Helper loaded: common_helper
INFO - 2022-03-14 00:54:21 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:54:21 --> Controller Class Initialized
INFO - 2022-03-14 00:54:21 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:54:21 --> Encrypt Class Initialized
INFO - 2022-03-14 00:54:21 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:54:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:54:21 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:54:21 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:54:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:54:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:54:22 --> Config Class Initialized
INFO - 2022-03-14 00:54:22 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:54:22 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:54:22 --> Utf8 Class Initialized
INFO - 2022-03-14 00:54:22 --> URI Class Initialized
INFO - 2022-03-14 00:54:22 --> Router Class Initialized
INFO - 2022-03-14 00:54:22 --> Output Class Initialized
INFO - 2022-03-14 00:54:22 --> Security Class Initialized
DEBUG - 2022-03-14 00:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:54:22 --> Input Class Initialized
INFO - 2022-03-14 00:54:22 --> Language Class Initialized
INFO - 2022-03-14 00:54:22 --> Loader Class Initialized
INFO - 2022-03-14 00:54:22 --> Helper loaded: url_helper
INFO - 2022-03-14 00:54:22 --> Helper loaded: form_helper
INFO - 2022-03-14 00:54:22 --> Helper loaded: common_helper
INFO - 2022-03-14 00:54:22 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:54:22 --> Controller Class Initialized
INFO - 2022-03-14 00:54:22 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:54:22 --> Encrypt Class Initialized
INFO - 2022-03-14 00:54:22 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:54:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:54:22 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:54:22 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:54:22 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:54:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:54:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:54:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:54:22 --> Final output sent to browser
DEBUG - 2022-03-14 00:54:22 --> Total execution time: 0.0612
ERROR - 2022-03-14 00:54:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:54:23 --> Config Class Initialized
INFO - 2022-03-14 00:54:23 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:54:23 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:54:23 --> Utf8 Class Initialized
INFO - 2022-03-14 00:54:23 --> URI Class Initialized
INFO - 2022-03-14 00:54:23 --> Router Class Initialized
INFO - 2022-03-14 00:54:23 --> Output Class Initialized
INFO - 2022-03-14 00:54:23 --> Security Class Initialized
DEBUG - 2022-03-14 00:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:54:23 --> Input Class Initialized
INFO - 2022-03-14 00:54:23 --> Language Class Initialized
INFO - 2022-03-14 00:54:23 --> Loader Class Initialized
INFO - 2022-03-14 00:54:23 --> Helper loaded: url_helper
INFO - 2022-03-14 00:54:23 --> Helper loaded: form_helper
INFO - 2022-03-14 00:54:23 --> Helper loaded: common_helper
INFO - 2022-03-14 00:54:23 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:54:23 --> Controller Class Initialized
INFO - 2022-03-14 00:54:23 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:54:23 --> Encrypt Class Initialized
INFO - 2022-03-14 00:54:23 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:54:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:54:23 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:54:23 --> Model "Users_model" initialized
INFO - 2022-03-14 00:54:23 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:54:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:54:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:54:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:54:23 --> Final output sent to browser
DEBUG - 2022-03-14 00:54:23 --> Total execution time: 0.0585
ERROR - 2022-03-14 00:54:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:54:39 --> Config Class Initialized
INFO - 2022-03-14 00:54:39 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:54:39 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:54:39 --> Utf8 Class Initialized
INFO - 2022-03-14 00:54:39 --> URI Class Initialized
INFO - 2022-03-14 00:54:39 --> Router Class Initialized
INFO - 2022-03-14 00:54:39 --> Output Class Initialized
INFO - 2022-03-14 00:54:39 --> Security Class Initialized
DEBUG - 2022-03-14 00:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:54:39 --> Input Class Initialized
INFO - 2022-03-14 00:54:39 --> Language Class Initialized
INFO - 2022-03-14 00:54:39 --> Loader Class Initialized
INFO - 2022-03-14 00:54:39 --> Helper loaded: url_helper
INFO - 2022-03-14 00:54:39 --> Helper loaded: form_helper
INFO - 2022-03-14 00:54:39 --> Helper loaded: common_helper
INFO - 2022-03-14 00:54:39 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:54:39 --> Controller Class Initialized
INFO - 2022-03-14 00:54:39 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:54:39 --> Encrypt Class Initialized
INFO - 2022-03-14 00:54:39 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:54:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:54:39 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:54:39 --> Model "Users_model" initialized
INFO - 2022-03-14 00:54:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 00:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:54:40 --> Config Class Initialized
INFO - 2022-03-14 00:54:40 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:54:40 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:54:40 --> Utf8 Class Initialized
INFO - 2022-03-14 00:54:40 --> URI Class Initialized
INFO - 2022-03-14 00:54:40 --> Router Class Initialized
INFO - 2022-03-14 00:54:40 --> Output Class Initialized
INFO - 2022-03-14 00:54:40 --> Security Class Initialized
DEBUG - 2022-03-14 00:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:54:40 --> Input Class Initialized
INFO - 2022-03-14 00:54:40 --> Language Class Initialized
INFO - 2022-03-14 00:54:40 --> Loader Class Initialized
INFO - 2022-03-14 00:54:40 --> Helper loaded: url_helper
INFO - 2022-03-14 00:54:40 --> Helper loaded: form_helper
INFO - 2022-03-14 00:54:40 --> Helper loaded: common_helper
INFO - 2022-03-14 00:54:40 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:54:40 --> Controller Class Initialized
INFO - 2022-03-14 00:54:40 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:54:40 --> Encrypt Class Initialized
INFO - 2022-03-14 00:54:40 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:54:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:54:40 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:54:40 --> Model "Users_model" initialized
INFO - 2022-03-14 00:54:40 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:54:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:54:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:54:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:54:40 --> Final output sent to browser
DEBUG - 2022-03-14 00:54:40 --> Total execution time: 0.0833
ERROR - 2022-03-14 00:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:54:44 --> Config Class Initialized
INFO - 2022-03-14 00:54:44 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:54:44 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:54:44 --> Utf8 Class Initialized
INFO - 2022-03-14 00:54:44 --> URI Class Initialized
INFO - 2022-03-14 00:54:44 --> Router Class Initialized
INFO - 2022-03-14 00:54:44 --> Output Class Initialized
INFO - 2022-03-14 00:54:44 --> Security Class Initialized
DEBUG - 2022-03-14 00:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:54:44 --> Input Class Initialized
INFO - 2022-03-14 00:54:44 --> Language Class Initialized
INFO - 2022-03-14 00:54:44 --> Loader Class Initialized
INFO - 2022-03-14 00:54:44 --> Helper loaded: url_helper
INFO - 2022-03-14 00:54:44 --> Helper loaded: form_helper
INFO - 2022-03-14 00:54:44 --> Helper loaded: common_helper
INFO - 2022-03-14 00:54:44 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:54:44 --> Controller Class Initialized
INFO - 2022-03-14 00:54:44 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:54:44 --> Encrypt Class Initialized
INFO - 2022-03-14 00:54:44 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:54:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:54:44 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:54:44 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:54:44 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:54:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:54:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 00:54:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:54:44 --> Final output sent to browser
DEBUG - 2022-03-14 00:54:44 --> Total execution time: 0.2682
ERROR - 2022-03-14 00:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:54:53 --> Config Class Initialized
INFO - 2022-03-14 00:54:53 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:54:53 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:54:53 --> Utf8 Class Initialized
INFO - 2022-03-14 00:54:53 --> URI Class Initialized
INFO - 2022-03-14 00:54:53 --> Router Class Initialized
INFO - 2022-03-14 00:54:53 --> Output Class Initialized
INFO - 2022-03-14 00:54:53 --> Security Class Initialized
DEBUG - 2022-03-14 00:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:54:53 --> Input Class Initialized
INFO - 2022-03-14 00:54:53 --> Language Class Initialized
INFO - 2022-03-14 00:54:53 --> Loader Class Initialized
INFO - 2022-03-14 00:54:53 --> Helper loaded: url_helper
INFO - 2022-03-14 00:54:53 --> Helper loaded: form_helper
INFO - 2022-03-14 00:54:53 --> Helper loaded: common_helper
INFO - 2022-03-14 00:54:53 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:54:53 --> Controller Class Initialized
INFO - 2022-03-14 00:54:53 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:54:53 --> Encrypt Class Initialized
INFO - 2022-03-14 00:54:53 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:54:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:54:53 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:54:53 --> Model "Users_model" initialized
INFO - 2022-03-14 00:54:53 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:54:53 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-14 00:54:54 --> Final output sent to browser
DEBUG - 2022-03-14 00:54:54 --> Total execution time: 1.1043
ERROR - 2022-03-14 00:56:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:56:29 --> Config Class Initialized
INFO - 2022-03-14 00:56:29 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:56:29 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:56:29 --> Utf8 Class Initialized
INFO - 2022-03-14 00:56:29 --> URI Class Initialized
INFO - 2022-03-14 00:56:29 --> Router Class Initialized
INFO - 2022-03-14 00:56:29 --> Output Class Initialized
INFO - 2022-03-14 00:56:29 --> Security Class Initialized
DEBUG - 2022-03-14 00:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:56:29 --> Input Class Initialized
INFO - 2022-03-14 00:56:29 --> Language Class Initialized
INFO - 2022-03-14 00:56:29 --> Loader Class Initialized
INFO - 2022-03-14 00:56:29 --> Helper loaded: url_helper
INFO - 2022-03-14 00:56:29 --> Helper loaded: form_helper
INFO - 2022-03-14 00:56:29 --> Helper loaded: common_helper
INFO - 2022-03-14 00:56:29 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:56:29 --> Controller Class Initialized
INFO - 2022-03-14 00:56:29 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:56:29 --> Encrypt Class Initialized
INFO - 2022-03-14 00:56:29 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:56:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:56:29 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:56:29 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:56:29 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:56:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:56:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:56:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:56:29 --> Final output sent to browser
DEBUG - 2022-03-14 00:56:29 --> Total execution time: 0.0543
ERROR - 2022-03-14 00:56:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:56:46 --> Config Class Initialized
INFO - 2022-03-14 00:56:46 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:56:46 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:56:46 --> Utf8 Class Initialized
INFO - 2022-03-14 00:56:46 --> URI Class Initialized
INFO - 2022-03-14 00:56:46 --> Router Class Initialized
INFO - 2022-03-14 00:56:46 --> Output Class Initialized
INFO - 2022-03-14 00:56:46 --> Security Class Initialized
DEBUG - 2022-03-14 00:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:56:46 --> Input Class Initialized
INFO - 2022-03-14 00:56:46 --> Language Class Initialized
INFO - 2022-03-14 00:56:46 --> Loader Class Initialized
INFO - 2022-03-14 00:56:46 --> Helper loaded: url_helper
INFO - 2022-03-14 00:56:46 --> Helper loaded: form_helper
INFO - 2022-03-14 00:56:46 --> Helper loaded: common_helper
INFO - 2022-03-14 00:56:46 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:56:46 --> Controller Class Initialized
INFO - 2022-03-14 00:56:46 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:56:46 --> Encrypt Class Initialized
INFO - 2022-03-14 00:56:46 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:56:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:56:46 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:56:46 --> Model "Users_model" initialized
INFO - 2022-03-14 00:56:46 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:56:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:56:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 00:56:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:56:46 --> Final output sent to browser
DEBUG - 2022-03-14 00:56:46 --> Total execution time: 0.4884
ERROR - 2022-03-14 00:58:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:58:22 --> Config Class Initialized
INFO - 2022-03-14 00:58:22 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:58:22 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:58:22 --> Utf8 Class Initialized
INFO - 2022-03-14 00:58:22 --> URI Class Initialized
INFO - 2022-03-14 00:58:22 --> Router Class Initialized
INFO - 2022-03-14 00:58:22 --> Output Class Initialized
INFO - 2022-03-14 00:58:22 --> Security Class Initialized
DEBUG - 2022-03-14 00:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:58:22 --> Input Class Initialized
INFO - 2022-03-14 00:58:22 --> Language Class Initialized
INFO - 2022-03-14 00:58:22 --> Loader Class Initialized
INFO - 2022-03-14 00:58:22 --> Helper loaded: url_helper
INFO - 2022-03-14 00:58:22 --> Helper loaded: form_helper
INFO - 2022-03-14 00:58:22 --> Helper loaded: common_helper
INFO - 2022-03-14 00:58:22 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:58:22 --> Controller Class Initialized
INFO - 2022-03-14 00:58:22 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:58:22 --> Encrypt Class Initialized
INFO - 2022-03-14 00:58:22 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:58:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:58:22 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:58:22 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:58:22 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:58:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:58:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 00:58:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:58:22 --> Final output sent to browser
DEBUG - 2022-03-14 00:58:22 --> Total execution time: 0.1173
ERROR - 2022-03-14 00:58:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:58:25 --> Config Class Initialized
INFO - 2022-03-14 00:58:25 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:58:25 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:58:25 --> Utf8 Class Initialized
INFO - 2022-03-14 00:58:25 --> URI Class Initialized
INFO - 2022-03-14 00:58:25 --> Router Class Initialized
INFO - 2022-03-14 00:58:25 --> Output Class Initialized
INFO - 2022-03-14 00:58:25 --> Security Class Initialized
DEBUG - 2022-03-14 00:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:58:25 --> Input Class Initialized
INFO - 2022-03-14 00:58:25 --> Language Class Initialized
INFO - 2022-03-14 00:58:25 --> Loader Class Initialized
INFO - 2022-03-14 00:58:25 --> Helper loaded: url_helper
INFO - 2022-03-14 00:58:25 --> Helper loaded: form_helper
INFO - 2022-03-14 00:58:25 --> Helper loaded: common_helper
INFO - 2022-03-14 00:58:25 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:58:25 --> Controller Class Initialized
INFO - 2022-03-14 00:58:25 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:58:25 --> Encrypt Class Initialized
INFO - 2022-03-14 00:58:25 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:58:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:58:25 --> Model "Referredby_model" initialized
INFO - 2022-03-14 00:58:25 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:58:25 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:58:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 00:58:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 00:58:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 00:58:26 --> Final output sent to browser
DEBUG - 2022-03-14 00:58:26 --> Total execution time: 0.0711
ERROR - 2022-03-14 00:59:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:59:07 --> Config Class Initialized
INFO - 2022-03-14 00:59:07 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:59:07 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:59:07 --> Utf8 Class Initialized
INFO - 2022-03-14 00:59:07 --> URI Class Initialized
INFO - 2022-03-14 00:59:07 --> Router Class Initialized
INFO - 2022-03-14 00:59:07 --> Output Class Initialized
INFO - 2022-03-14 00:59:07 --> Security Class Initialized
DEBUG - 2022-03-14 00:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:59:07 --> Input Class Initialized
INFO - 2022-03-14 00:59:07 --> Language Class Initialized
INFO - 2022-03-14 00:59:07 --> Loader Class Initialized
INFO - 2022-03-14 00:59:07 --> Helper loaded: url_helper
INFO - 2022-03-14 00:59:07 --> Helper loaded: form_helper
INFO - 2022-03-14 00:59:07 --> Helper loaded: common_helper
INFO - 2022-03-14 00:59:07 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:59:07 --> Controller Class Initialized
INFO - 2022-03-14 00:59:07 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:59:07 --> Encrypt Class Initialized
INFO - 2022-03-14 00:59:07 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:59:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:59:07 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:59:07 --> Model "Users_model" initialized
INFO - 2022-03-14 00:59:07 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:59:08 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-14 00:59:08 --> Final output sent to browser
DEBUG - 2022-03-14 00:59:08 --> Total execution time: 0.9759
ERROR - 2022-03-14 00:59:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 00:59:30 --> Config Class Initialized
INFO - 2022-03-14 00:59:30 --> Hooks Class Initialized
DEBUG - 2022-03-14 00:59:30 --> UTF-8 Support Enabled
INFO - 2022-03-14 00:59:30 --> Utf8 Class Initialized
INFO - 2022-03-14 00:59:30 --> URI Class Initialized
INFO - 2022-03-14 00:59:30 --> Router Class Initialized
INFO - 2022-03-14 00:59:30 --> Output Class Initialized
INFO - 2022-03-14 00:59:30 --> Security Class Initialized
DEBUG - 2022-03-14 00:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 00:59:30 --> Input Class Initialized
INFO - 2022-03-14 00:59:30 --> Language Class Initialized
INFO - 2022-03-14 00:59:30 --> Loader Class Initialized
INFO - 2022-03-14 00:59:30 --> Helper loaded: url_helper
INFO - 2022-03-14 00:59:30 --> Helper loaded: form_helper
INFO - 2022-03-14 00:59:30 --> Helper loaded: common_helper
INFO - 2022-03-14 00:59:30 --> Database Driver Class Initialized
DEBUG - 2022-03-14 00:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 00:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 00:59:30 --> Controller Class Initialized
INFO - 2022-03-14 00:59:30 --> Form Validation Class Initialized
DEBUG - 2022-03-14 00:59:30 --> Encrypt Class Initialized
INFO - 2022-03-14 00:59:30 --> Model "Patient_model" initialized
INFO - 2022-03-14 00:59:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 00:59:30 --> Model "Prefix_master" initialized
INFO - 2022-03-14 00:59:30 --> Model "Users_model" initialized
INFO - 2022-03-14 00:59:30 --> Model "Hospital_model" initialized
INFO - 2022-03-14 00:59:30 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-14 00:59:31 --> Final output sent to browser
DEBUG - 2022-03-14 00:59:31 --> Total execution time: 0.9178
ERROR - 2022-03-14 01:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:00:59 --> Config Class Initialized
INFO - 2022-03-14 01:00:59 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:00:59 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:00:59 --> Utf8 Class Initialized
INFO - 2022-03-14 01:00:59 --> URI Class Initialized
INFO - 2022-03-14 01:00:59 --> Router Class Initialized
INFO - 2022-03-14 01:00:59 --> Output Class Initialized
INFO - 2022-03-14 01:00:59 --> Security Class Initialized
DEBUG - 2022-03-14 01:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:00:59 --> Input Class Initialized
INFO - 2022-03-14 01:00:59 --> Language Class Initialized
INFO - 2022-03-14 01:00:59 --> Loader Class Initialized
INFO - 2022-03-14 01:00:59 --> Helper loaded: url_helper
INFO - 2022-03-14 01:00:59 --> Helper loaded: form_helper
INFO - 2022-03-14 01:00:59 --> Helper loaded: common_helper
INFO - 2022-03-14 01:00:59 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:00:59 --> Controller Class Initialized
INFO - 2022-03-14 01:00:59 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:00:59 --> Encrypt Class Initialized
INFO - 2022-03-14 01:00:59 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:00:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:00:59 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:00:59 --> Model "Users_model" initialized
INFO - 2022-03-14 01:00:59 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:00:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:00:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 01:00:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:00:59 --> Final output sent to browser
DEBUG - 2022-03-14 01:00:59 --> Total execution time: 0.0993
ERROR - 2022-03-14 01:01:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:01:11 --> Config Class Initialized
INFO - 2022-03-14 01:01:11 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:01:11 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:01:11 --> Utf8 Class Initialized
INFO - 2022-03-14 01:01:11 --> URI Class Initialized
INFO - 2022-03-14 01:01:11 --> Router Class Initialized
INFO - 2022-03-14 01:01:11 --> Output Class Initialized
INFO - 2022-03-14 01:01:11 --> Security Class Initialized
DEBUG - 2022-03-14 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:01:11 --> Input Class Initialized
INFO - 2022-03-14 01:01:11 --> Language Class Initialized
INFO - 2022-03-14 01:01:11 --> Loader Class Initialized
INFO - 2022-03-14 01:01:11 --> Helper loaded: url_helper
INFO - 2022-03-14 01:01:11 --> Helper loaded: form_helper
INFO - 2022-03-14 01:01:11 --> Helper loaded: common_helper
INFO - 2022-03-14 01:01:11 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:01:11 --> Controller Class Initialized
INFO - 2022-03-14 01:01:11 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:01:11 --> Encrypt Class Initialized
INFO - 2022-03-14 01:01:11 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:01:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:01:11 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:01:11 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:01:11 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:01:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:01:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 01:01:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:01:11 --> Final output sent to browser
DEBUG - 2022-03-14 01:01:11 --> Total execution time: 0.0533
ERROR - 2022-03-14 01:02:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:02:16 --> Config Class Initialized
INFO - 2022-03-14 01:02:16 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:02:16 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:02:16 --> Utf8 Class Initialized
INFO - 2022-03-14 01:02:16 --> URI Class Initialized
INFO - 2022-03-14 01:02:16 --> Router Class Initialized
INFO - 2022-03-14 01:02:16 --> Output Class Initialized
INFO - 2022-03-14 01:02:16 --> Security Class Initialized
DEBUG - 2022-03-14 01:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:02:16 --> Input Class Initialized
INFO - 2022-03-14 01:02:16 --> Language Class Initialized
INFO - 2022-03-14 01:02:16 --> Loader Class Initialized
INFO - 2022-03-14 01:02:16 --> Helper loaded: url_helper
INFO - 2022-03-14 01:02:16 --> Helper loaded: form_helper
INFO - 2022-03-14 01:02:16 --> Helper loaded: common_helper
INFO - 2022-03-14 01:02:16 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:02:16 --> Controller Class Initialized
INFO - 2022-03-14 01:02:16 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:02:16 --> Encrypt Class Initialized
INFO - 2022-03-14 01:02:16 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:02:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:02:16 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:02:16 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:02:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 01:02:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:02:16 --> Config Class Initialized
INFO - 2022-03-14 01:02:16 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:02:16 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:02:16 --> Utf8 Class Initialized
INFO - 2022-03-14 01:02:16 --> URI Class Initialized
INFO - 2022-03-14 01:02:16 --> Router Class Initialized
INFO - 2022-03-14 01:02:16 --> Output Class Initialized
INFO - 2022-03-14 01:02:16 --> Security Class Initialized
DEBUG - 2022-03-14 01:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:02:16 --> Input Class Initialized
INFO - 2022-03-14 01:02:16 --> Language Class Initialized
INFO - 2022-03-14 01:02:16 --> Loader Class Initialized
INFO - 2022-03-14 01:02:16 --> Helper loaded: url_helper
INFO - 2022-03-14 01:02:16 --> Helper loaded: form_helper
INFO - 2022-03-14 01:02:16 --> Helper loaded: common_helper
INFO - 2022-03-14 01:02:16 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:02:16 --> Controller Class Initialized
INFO - 2022-03-14 01:02:16 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:02:16 --> Encrypt Class Initialized
INFO - 2022-03-14 01:02:16 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:02:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:02:16 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:02:16 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:02:16 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:02:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:02:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 01:02:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:02:16 --> Final output sent to browser
DEBUG - 2022-03-14 01:02:16 --> Total execution time: 0.0522
ERROR - 2022-03-14 01:02:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:02:17 --> Config Class Initialized
INFO - 2022-03-14 01:02:17 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:02:17 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:02:17 --> Utf8 Class Initialized
INFO - 2022-03-14 01:02:17 --> URI Class Initialized
INFO - 2022-03-14 01:02:17 --> Router Class Initialized
INFO - 2022-03-14 01:02:17 --> Output Class Initialized
INFO - 2022-03-14 01:02:17 --> Security Class Initialized
DEBUG - 2022-03-14 01:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:02:17 --> Input Class Initialized
INFO - 2022-03-14 01:02:17 --> Language Class Initialized
INFO - 2022-03-14 01:02:17 --> Loader Class Initialized
INFO - 2022-03-14 01:02:17 --> Helper loaded: url_helper
INFO - 2022-03-14 01:02:17 --> Helper loaded: form_helper
INFO - 2022-03-14 01:02:17 --> Helper loaded: common_helper
INFO - 2022-03-14 01:02:17 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:02:17 --> Controller Class Initialized
INFO - 2022-03-14 01:02:17 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:02:17 --> Encrypt Class Initialized
INFO - 2022-03-14 01:02:17 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:02:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:02:17 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:02:17 --> Model "Users_model" initialized
INFO - 2022-03-14 01:02:17 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:02:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:02:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 01:02:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:02:17 --> Final output sent to browser
DEBUG - 2022-03-14 01:02:17 --> Total execution time: 0.0841
ERROR - 2022-03-14 01:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:02:27 --> Config Class Initialized
INFO - 2022-03-14 01:02:27 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:02:27 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:02:27 --> Utf8 Class Initialized
INFO - 2022-03-14 01:02:27 --> URI Class Initialized
INFO - 2022-03-14 01:02:27 --> Router Class Initialized
INFO - 2022-03-14 01:02:27 --> Output Class Initialized
INFO - 2022-03-14 01:02:27 --> Security Class Initialized
DEBUG - 2022-03-14 01:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:02:27 --> Input Class Initialized
INFO - 2022-03-14 01:02:27 --> Language Class Initialized
INFO - 2022-03-14 01:02:27 --> Loader Class Initialized
INFO - 2022-03-14 01:02:27 --> Helper loaded: url_helper
INFO - 2022-03-14 01:02:27 --> Helper loaded: form_helper
INFO - 2022-03-14 01:02:27 --> Helper loaded: common_helper
INFO - 2022-03-14 01:02:27 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:02:27 --> Controller Class Initialized
INFO - 2022-03-14 01:02:27 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:02:27 --> Encrypt Class Initialized
INFO - 2022-03-14 01:02:27 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:02:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:02:27 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:02:27 --> Model "Users_model" initialized
INFO - 2022-03-14 01:02:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 01:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:02:27 --> Config Class Initialized
INFO - 2022-03-14 01:02:27 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:02:27 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:02:27 --> Utf8 Class Initialized
INFO - 2022-03-14 01:02:27 --> URI Class Initialized
INFO - 2022-03-14 01:02:27 --> Router Class Initialized
INFO - 2022-03-14 01:02:27 --> Output Class Initialized
INFO - 2022-03-14 01:02:27 --> Security Class Initialized
DEBUG - 2022-03-14 01:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:02:27 --> Input Class Initialized
INFO - 2022-03-14 01:02:27 --> Language Class Initialized
INFO - 2022-03-14 01:02:27 --> Loader Class Initialized
INFO - 2022-03-14 01:02:27 --> Helper loaded: url_helper
INFO - 2022-03-14 01:02:27 --> Helper loaded: form_helper
INFO - 2022-03-14 01:02:27 --> Helper loaded: common_helper
INFO - 2022-03-14 01:02:27 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:02:27 --> Controller Class Initialized
INFO - 2022-03-14 01:02:27 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:02:27 --> Encrypt Class Initialized
INFO - 2022-03-14 01:02:27 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:02:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:02:27 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:02:27 --> Model "Users_model" initialized
INFO - 2022-03-14 01:02:27 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:02:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:02:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 01:02:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:02:27 --> Final output sent to browser
DEBUG - 2022-03-14 01:02:27 --> Total execution time: 0.0928
ERROR - 2022-03-14 01:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:02:38 --> Config Class Initialized
INFO - 2022-03-14 01:02:38 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:02:38 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:02:38 --> Utf8 Class Initialized
INFO - 2022-03-14 01:02:38 --> URI Class Initialized
INFO - 2022-03-14 01:02:38 --> Router Class Initialized
INFO - 2022-03-14 01:02:38 --> Output Class Initialized
INFO - 2022-03-14 01:02:38 --> Security Class Initialized
DEBUG - 2022-03-14 01:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:02:38 --> Input Class Initialized
INFO - 2022-03-14 01:02:38 --> Language Class Initialized
INFO - 2022-03-14 01:02:38 --> Loader Class Initialized
INFO - 2022-03-14 01:02:38 --> Helper loaded: url_helper
INFO - 2022-03-14 01:02:38 --> Helper loaded: form_helper
INFO - 2022-03-14 01:02:38 --> Helper loaded: common_helper
INFO - 2022-03-14 01:02:38 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:02:38 --> Controller Class Initialized
INFO - 2022-03-14 01:02:38 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:02:38 --> Encrypt Class Initialized
INFO - 2022-03-14 01:02:38 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:02:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:02:38 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:02:38 --> Model "Users_model" initialized
INFO - 2022-03-14 01:02:38 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:02:39 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-14 01:02:39 --> Final output sent to browser
DEBUG - 2022-03-14 01:02:39 --> Total execution time: 0.9868
ERROR - 2022-03-14 01:07:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:07:53 --> Config Class Initialized
INFO - 2022-03-14 01:07:53 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:07:53 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:07:53 --> Utf8 Class Initialized
INFO - 2022-03-14 01:07:53 --> URI Class Initialized
DEBUG - 2022-03-14 01:07:53 --> No URI present. Default controller set.
INFO - 2022-03-14 01:07:53 --> Router Class Initialized
INFO - 2022-03-14 01:07:53 --> Output Class Initialized
INFO - 2022-03-14 01:07:53 --> Security Class Initialized
DEBUG - 2022-03-14 01:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:07:53 --> Input Class Initialized
INFO - 2022-03-14 01:07:53 --> Language Class Initialized
INFO - 2022-03-14 01:07:53 --> Loader Class Initialized
INFO - 2022-03-14 01:07:53 --> Helper loaded: url_helper
INFO - 2022-03-14 01:07:53 --> Helper loaded: form_helper
INFO - 2022-03-14 01:07:53 --> Helper loaded: common_helper
INFO - 2022-03-14 01:07:53 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:07:53 --> Controller Class Initialized
INFO - 2022-03-14 01:07:53 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:07:53 --> Encrypt Class Initialized
DEBUG - 2022-03-14 01:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 01:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 01:07:53 --> Email Class Initialized
INFO - 2022-03-14 01:07:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 01:07:53 --> Calendar Class Initialized
INFO - 2022-03-14 01:07:53 --> Model "Login_model" initialized
ERROR - 2022-03-14 01:07:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:07:54 --> Config Class Initialized
INFO - 2022-03-14 01:07:54 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:07:54 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:07:54 --> Utf8 Class Initialized
INFO - 2022-03-14 01:07:54 --> URI Class Initialized
INFO - 2022-03-14 01:07:54 --> Router Class Initialized
INFO - 2022-03-14 01:07:54 --> Output Class Initialized
INFO - 2022-03-14 01:07:54 --> Security Class Initialized
DEBUG - 2022-03-14 01:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:07:54 --> Input Class Initialized
INFO - 2022-03-14 01:07:54 --> Language Class Initialized
INFO - 2022-03-14 01:07:54 --> Loader Class Initialized
INFO - 2022-03-14 01:07:54 --> Helper loaded: url_helper
INFO - 2022-03-14 01:07:54 --> Helper loaded: form_helper
INFO - 2022-03-14 01:07:54 --> Helper loaded: common_helper
INFO - 2022-03-14 01:07:54 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:07:54 --> Controller Class Initialized
INFO - 2022-03-14 01:07:54 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:07:54 --> Encrypt Class Initialized
INFO - 2022-03-14 01:07:54 --> Model "Diseases_model" initialized
INFO - 2022-03-14 01:07:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:07:54 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-14 01:07:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:07:54 --> Final output sent to browser
DEBUG - 2022-03-14 01:07:54 --> Total execution time: 0.0371
ERROR - 2022-03-14 01:08:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:08:01 --> Config Class Initialized
INFO - 2022-03-14 01:08:01 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:08:01 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:08:01 --> Utf8 Class Initialized
INFO - 2022-03-14 01:08:01 --> URI Class Initialized
INFO - 2022-03-14 01:08:01 --> Router Class Initialized
INFO - 2022-03-14 01:08:01 --> Output Class Initialized
INFO - 2022-03-14 01:08:01 --> Security Class Initialized
DEBUG - 2022-03-14 01:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:08:01 --> Input Class Initialized
INFO - 2022-03-14 01:08:01 --> Language Class Initialized
INFO - 2022-03-14 01:08:01 --> Loader Class Initialized
INFO - 2022-03-14 01:08:01 --> Helper loaded: url_helper
INFO - 2022-03-14 01:08:01 --> Helper loaded: form_helper
INFO - 2022-03-14 01:08:01 --> Helper loaded: common_helper
INFO - 2022-03-14 01:08:01 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:08:01 --> Controller Class Initialized
INFO - 2022-03-14 01:08:01 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:08:01 --> Encrypt Class Initialized
INFO - 2022-03-14 01:08:01 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:08:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:08:01 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:08:01 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:08:01 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:08:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:08:01 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 01:08:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:08:01 --> Final output sent to browser
DEBUG - 2022-03-14 01:08:01 --> Total execution time: 0.0482
ERROR - 2022-03-14 01:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:09:16 --> Config Class Initialized
INFO - 2022-03-14 01:09:16 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:09:16 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:09:16 --> Utf8 Class Initialized
INFO - 2022-03-14 01:09:16 --> URI Class Initialized
INFO - 2022-03-14 01:09:16 --> Router Class Initialized
INFO - 2022-03-14 01:09:16 --> Output Class Initialized
INFO - 2022-03-14 01:09:16 --> Security Class Initialized
DEBUG - 2022-03-14 01:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:09:16 --> Input Class Initialized
INFO - 2022-03-14 01:09:16 --> Language Class Initialized
INFO - 2022-03-14 01:09:16 --> Loader Class Initialized
INFO - 2022-03-14 01:09:16 --> Helper loaded: url_helper
INFO - 2022-03-14 01:09:16 --> Helper loaded: form_helper
INFO - 2022-03-14 01:09:16 --> Helper loaded: common_helper
INFO - 2022-03-14 01:09:16 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:09:16 --> Controller Class Initialized
INFO - 2022-03-14 01:09:16 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:09:16 --> Encrypt Class Initialized
INFO - 2022-03-14 01:09:16 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:09:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:09:16 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:09:16 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:09:16 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:09:16 --> Final output sent to browser
DEBUG - 2022-03-14 01:09:16 --> Total execution time: 0.0424
ERROR - 2022-03-14 01:11:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:11:25 --> Config Class Initialized
INFO - 2022-03-14 01:11:25 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:11:25 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:11:25 --> Utf8 Class Initialized
INFO - 2022-03-14 01:11:25 --> URI Class Initialized
INFO - 2022-03-14 01:11:25 --> Router Class Initialized
INFO - 2022-03-14 01:11:25 --> Output Class Initialized
INFO - 2022-03-14 01:11:25 --> Security Class Initialized
DEBUG - 2022-03-14 01:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:11:25 --> Input Class Initialized
INFO - 2022-03-14 01:11:25 --> Language Class Initialized
INFO - 2022-03-14 01:11:25 --> Loader Class Initialized
INFO - 2022-03-14 01:11:25 --> Helper loaded: url_helper
INFO - 2022-03-14 01:11:25 --> Helper loaded: form_helper
INFO - 2022-03-14 01:11:25 --> Helper loaded: common_helper
INFO - 2022-03-14 01:11:25 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:11:25 --> Controller Class Initialized
INFO - 2022-03-14 01:11:25 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:11:25 --> Encrypt Class Initialized
INFO - 2022-03-14 01:11:25 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:11:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:11:25 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:11:25 --> Model "Users_model" initialized
INFO - 2022-03-14 01:11:25 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:11:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:11:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 01:11:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:11:25 --> Final output sent to browser
DEBUG - 2022-03-14 01:11:25 --> Total execution time: 0.0741
ERROR - 2022-03-14 01:14:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:14:06 --> Config Class Initialized
INFO - 2022-03-14 01:14:06 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:14:06 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:14:06 --> Utf8 Class Initialized
INFO - 2022-03-14 01:14:06 --> URI Class Initialized
INFO - 2022-03-14 01:14:06 --> Router Class Initialized
INFO - 2022-03-14 01:14:06 --> Output Class Initialized
INFO - 2022-03-14 01:14:06 --> Security Class Initialized
DEBUG - 2022-03-14 01:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:14:06 --> Input Class Initialized
INFO - 2022-03-14 01:14:06 --> Language Class Initialized
INFO - 2022-03-14 01:14:06 --> Loader Class Initialized
INFO - 2022-03-14 01:14:06 --> Helper loaded: url_helper
INFO - 2022-03-14 01:14:06 --> Helper loaded: form_helper
INFO - 2022-03-14 01:14:06 --> Helper loaded: common_helper
INFO - 2022-03-14 01:14:06 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:14:06 --> Controller Class Initialized
INFO - 2022-03-14 01:14:06 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:14:06 --> Final output sent to browser
DEBUG - 2022-03-14 01:14:06 --> Total execution time: 0.0205
ERROR - 2022-03-14 01:14:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:14:37 --> Config Class Initialized
INFO - 2022-03-14 01:14:37 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:14:37 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:14:37 --> Utf8 Class Initialized
INFO - 2022-03-14 01:14:37 --> URI Class Initialized
INFO - 2022-03-14 01:14:37 --> Router Class Initialized
INFO - 2022-03-14 01:14:37 --> Output Class Initialized
INFO - 2022-03-14 01:14:37 --> Security Class Initialized
DEBUG - 2022-03-14 01:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:14:37 --> Input Class Initialized
INFO - 2022-03-14 01:14:37 --> Language Class Initialized
INFO - 2022-03-14 01:14:37 --> Loader Class Initialized
INFO - 2022-03-14 01:14:37 --> Helper loaded: url_helper
INFO - 2022-03-14 01:14:37 --> Helper loaded: form_helper
INFO - 2022-03-14 01:14:37 --> Helper loaded: common_helper
INFO - 2022-03-14 01:14:37 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:14:37 --> Controller Class Initialized
INFO - 2022-03-14 01:14:37 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:14:37 --> Final output sent to browser
DEBUG - 2022-03-14 01:14:37 --> Total execution time: 0.0276
ERROR - 2022-03-14 01:17:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:17:42 --> Config Class Initialized
INFO - 2022-03-14 01:17:42 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:17:42 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:17:42 --> Utf8 Class Initialized
INFO - 2022-03-14 01:17:42 --> URI Class Initialized
INFO - 2022-03-14 01:17:42 --> Router Class Initialized
INFO - 2022-03-14 01:17:42 --> Output Class Initialized
INFO - 2022-03-14 01:17:42 --> Security Class Initialized
DEBUG - 2022-03-14 01:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:17:42 --> Input Class Initialized
INFO - 2022-03-14 01:17:42 --> Language Class Initialized
INFO - 2022-03-14 01:17:42 --> Loader Class Initialized
INFO - 2022-03-14 01:17:42 --> Helper loaded: url_helper
INFO - 2022-03-14 01:17:42 --> Helper loaded: form_helper
INFO - 2022-03-14 01:17:42 --> Helper loaded: common_helper
INFO - 2022-03-14 01:17:42 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:17:42 --> Controller Class Initialized
INFO - 2022-03-14 01:17:42 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:17:42 --> Encrypt Class Initialized
INFO - 2022-03-14 01:17:42 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:17:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:17:42 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:17:42 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:17:42 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:17:42 --> Final output sent to browser
DEBUG - 2022-03-14 01:17:42 --> Total execution time: 0.0341
ERROR - 2022-03-14 01:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:24:57 --> Config Class Initialized
INFO - 2022-03-14 01:24:57 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:24:57 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:24:57 --> Utf8 Class Initialized
INFO - 2022-03-14 01:24:57 --> URI Class Initialized
INFO - 2022-03-14 01:24:57 --> Router Class Initialized
INFO - 2022-03-14 01:24:57 --> Output Class Initialized
INFO - 2022-03-14 01:24:57 --> Security Class Initialized
DEBUG - 2022-03-14 01:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:24:57 --> Input Class Initialized
INFO - 2022-03-14 01:24:57 --> Language Class Initialized
INFO - 2022-03-14 01:24:57 --> Loader Class Initialized
INFO - 2022-03-14 01:24:57 --> Helper loaded: url_helper
INFO - 2022-03-14 01:24:57 --> Helper loaded: form_helper
INFO - 2022-03-14 01:24:57 --> Helper loaded: common_helper
INFO - 2022-03-14 01:24:57 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:24:57 --> Controller Class Initialized
INFO - 2022-03-14 01:24:57 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:24:57 --> Encrypt Class Initialized
INFO - 2022-03-14 01:24:57 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:24:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:24:57 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:24:57 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:24:57 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:24:57 --> Final output sent to browser
DEBUG - 2022-03-14 01:24:57 --> Total execution time: 0.0275
ERROR - 2022-03-14 01:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:24:59 --> Config Class Initialized
INFO - 2022-03-14 01:24:59 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:24:59 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:24:59 --> Utf8 Class Initialized
INFO - 2022-03-14 01:24:59 --> URI Class Initialized
INFO - 2022-03-14 01:24:59 --> Router Class Initialized
INFO - 2022-03-14 01:24:59 --> Output Class Initialized
INFO - 2022-03-14 01:24:59 --> Security Class Initialized
DEBUG - 2022-03-14 01:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:24:59 --> Input Class Initialized
INFO - 2022-03-14 01:24:59 --> Language Class Initialized
INFO - 2022-03-14 01:24:59 --> Loader Class Initialized
INFO - 2022-03-14 01:24:59 --> Helper loaded: url_helper
INFO - 2022-03-14 01:24:59 --> Helper loaded: form_helper
INFO - 2022-03-14 01:24:59 --> Helper loaded: common_helper
INFO - 2022-03-14 01:24:59 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:24:59 --> Controller Class Initialized
INFO - 2022-03-14 01:24:59 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:24:59 --> Encrypt Class Initialized
INFO - 2022-03-14 01:24:59 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:24:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:24:59 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:24:59 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:24:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 01:25:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:25:00 --> Config Class Initialized
INFO - 2022-03-14 01:25:00 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:25:00 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:25:00 --> Utf8 Class Initialized
INFO - 2022-03-14 01:25:00 --> URI Class Initialized
INFO - 2022-03-14 01:25:00 --> Router Class Initialized
INFO - 2022-03-14 01:25:00 --> Output Class Initialized
INFO - 2022-03-14 01:25:00 --> Security Class Initialized
DEBUG - 2022-03-14 01:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:25:00 --> Input Class Initialized
INFO - 2022-03-14 01:25:00 --> Language Class Initialized
INFO - 2022-03-14 01:25:00 --> Loader Class Initialized
INFO - 2022-03-14 01:25:00 --> Helper loaded: url_helper
INFO - 2022-03-14 01:25:00 --> Helper loaded: form_helper
INFO - 2022-03-14 01:25:00 --> Helper loaded: common_helper
INFO - 2022-03-14 01:25:00 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:25:00 --> Controller Class Initialized
INFO - 2022-03-14 01:25:00 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:25:00 --> Encrypt Class Initialized
INFO - 2022-03-14 01:25:00 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:25:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:25:00 --> Model "Referredby_model" initialized
INFO - 2022-03-14 01:25:00 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:25:00 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:25:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:25:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 01:25:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:25:00 --> Final output sent to browser
DEBUG - 2022-03-14 01:25:00 --> Total execution time: 0.0439
ERROR - 2022-03-14 01:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:25:01 --> Config Class Initialized
INFO - 2022-03-14 01:25:01 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:25:01 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:25:01 --> Utf8 Class Initialized
INFO - 2022-03-14 01:25:01 --> URI Class Initialized
INFO - 2022-03-14 01:25:01 --> Router Class Initialized
INFO - 2022-03-14 01:25:01 --> Output Class Initialized
INFO - 2022-03-14 01:25:01 --> Security Class Initialized
DEBUG - 2022-03-14 01:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:25:01 --> Input Class Initialized
INFO - 2022-03-14 01:25:01 --> Language Class Initialized
INFO - 2022-03-14 01:25:01 --> Loader Class Initialized
INFO - 2022-03-14 01:25:01 --> Helper loaded: url_helper
INFO - 2022-03-14 01:25:01 --> Helper loaded: form_helper
INFO - 2022-03-14 01:25:01 --> Helper loaded: common_helper
INFO - 2022-03-14 01:25:01 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:25:01 --> Controller Class Initialized
INFO - 2022-03-14 01:25:01 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:25:01 --> Encrypt Class Initialized
INFO - 2022-03-14 01:25:01 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:25:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:25:01 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:25:01 --> Model "Users_model" initialized
INFO - 2022-03-14 01:25:01 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:25:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:25:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 01:25:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:25:01 --> Final output sent to browser
DEBUG - 2022-03-14 01:25:01 --> Total execution time: 0.1069
ERROR - 2022-03-14 01:33:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:33:34 --> Config Class Initialized
INFO - 2022-03-14 01:33:34 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:33:34 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:33:34 --> Utf8 Class Initialized
INFO - 2022-03-14 01:33:34 --> URI Class Initialized
INFO - 2022-03-14 01:33:34 --> Router Class Initialized
INFO - 2022-03-14 01:33:34 --> Output Class Initialized
INFO - 2022-03-14 01:33:34 --> Security Class Initialized
DEBUG - 2022-03-14 01:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:33:34 --> Input Class Initialized
INFO - 2022-03-14 01:33:34 --> Language Class Initialized
INFO - 2022-03-14 01:33:34 --> Loader Class Initialized
INFO - 2022-03-14 01:33:34 --> Helper loaded: url_helper
INFO - 2022-03-14 01:33:34 --> Helper loaded: form_helper
INFO - 2022-03-14 01:33:34 --> Helper loaded: common_helper
INFO - 2022-03-14 01:33:34 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:33:34 --> Controller Class Initialized
INFO - 2022-03-14 01:33:34 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:33:34 --> Encrypt Class Initialized
INFO - 2022-03-14 01:33:34 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:33:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:33:34 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:33:34 --> Model "Users_model" initialized
INFO - 2022-03-14 01:33:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 01:33:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:33:34 --> Config Class Initialized
INFO - 2022-03-14 01:33:34 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:33:34 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:33:34 --> Utf8 Class Initialized
INFO - 2022-03-14 01:33:34 --> URI Class Initialized
INFO - 2022-03-14 01:33:34 --> Router Class Initialized
INFO - 2022-03-14 01:33:34 --> Output Class Initialized
INFO - 2022-03-14 01:33:34 --> Security Class Initialized
DEBUG - 2022-03-14 01:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:33:34 --> Input Class Initialized
INFO - 2022-03-14 01:33:34 --> Language Class Initialized
INFO - 2022-03-14 01:33:34 --> Loader Class Initialized
INFO - 2022-03-14 01:33:34 --> Helper loaded: url_helper
INFO - 2022-03-14 01:33:34 --> Helper loaded: form_helper
INFO - 2022-03-14 01:33:34 --> Helper loaded: common_helper
INFO - 2022-03-14 01:33:34 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:33:34 --> Controller Class Initialized
INFO - 2022-03-14 01:33:34 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:33:34 --> Encrypt Class Initialized
INFO - 2022-03-14 01:33:34 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:33:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:33:34 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:33:34 --> Model "Users_model" initialized
INFO - 2022-03-14 01:33:34 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:33:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:33:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 01:33:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:33:34 --> Final output sent to browser
DEBUG - 2022-03-14 01:33:34 --> Total execution time: 0.0720
ERROR - 2022-03-14 01:37:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:37:36 --> Config Class Initialized
INFO - 2022-03-14 01:37:36 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:37:36 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:37:36 --> Utf8 Class Initialized
INFO - 2022-03-14 01:37:36 --> URI Class Initialized
INFO - 2022-03-14 01:37:36 --> Router Class Initialized
INFO - 2022-03-14 01:37:36 --> Output Class Initialized
INFO - 2022-03-14 01:37:36 --> Security Class Initialized
DEBUG - 2022-03-14 01:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:37:36 --> Input Class Initialized
INFO - 2022-03-14 01:37:36 --> Language Class Initialized
INFO - 2022-03-14 01:37:36 --> Loader Class Initialized
INFO - 2022-03-14 01:37:36 --> Helper loaded: url_helper
INFO - 2022-03-14 01:37:36 --> Helper loaded: form_helper
INFO - 2022-03-14 01:37:36 --> Helper loaded: common_helper
INFO - 2022-03-14 01:37:36 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:37:36 --> Controller Class Initialized
INFO - 2022-03-14 01:37:36 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:37:36 --> Encrypt Class Initialized
INFO - 2022-03-14 01:37:36 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:37:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:37:36 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:37:36 --> Model "Users_model" initialized
INFO - 2022-03-14 01:37:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 01:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:37:37 --> Config Class Initialized
INFO - 2022-03-14 01:37:37 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:37:37 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:37:37 --> Utf8 Class Initialized
INFO - 2022-03-14 01:37:37 --> URI Class Initialized
INFO - 2022-03-14 01:37:37 --> Router Class Initialized
INFO - 2022-03-14 01:37:37 --> Output Class Initialized
INFO - 2022-03-14 01:37:37 --> Security Class Initialized
DEBUG - 2022-03-14 01:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:37:37 --> Input Class Initialized
INFO - 2022-03-14 01:37:37 --> Language Class Initialized
INFO - 2022-03-14 01:37:37 --> Loader Class Initialized
INFO - 2022-03-14 01:37:37 --> Helper loaded: url_helper
INFO - 2022-03-14 01:37:37 --> Helper loaded: form_helper
INFO - 2022-03-14 01:37:37 --> Helper loaded: common_helper
INFO - 2022-03-14 01:37:37 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:37:37 --> Controller Class Initialized
INFO - 2022-03-14 01:37:37 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:37:37 --> Encrypt Class Initialized
INFO - 2022-03-14 01:37:37 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:37:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:37:37 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:37:37 --> Model "Users_model" initialized
INFO - 2022-03-14 01:37:37 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:37:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:37:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 01:37:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:37:37 --> Final output sent to browser
DEBUG - 2022-03-14 01:37:37 --> Total execution time: 0.0820
ERROR - 2022-03-14 01:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:39:08 --> Config Class Initialized
INFO - 2022-03-14 01:39:08 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:39:08 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:39:08 --> Utf8 Class Initialized
INFO - 2022-03-14 01:39:08 --> URI Class Initialized
INFO - 2022-03-14 01:39:08 --> Router Class Initialized
INFO - 2022-03-14 01:39:08 --> Output Class Initialized
INFO - 2022-03-14 01:39:08 --> Security Class Initialized
DEBUG - 2022-03-14 01:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:39:08 --> Input Class Initialized
INFO - 2022-03-14 01:39:08 --> Language Class Initialized
INFO - 2022-03-14 01:39:08 --> Loader Class Initialized
INFO - 2022-03-14 01:39:08 --> Helper loaded: url_helper
INFO - 2022-03-14 01:39:08 --> Helper loaded: form_helper
INFO - 2022-03-14 01:39:08 --> Helper loaded: common_helper
INFO - 2022-03-14 01:39:08 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:39:08 --> Controller Class Initialized
INFO - 2022-03-14 01:39:08 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:39:08 --> Encrypt Class Initialized
INFO - 2022-03-14 01:39:08 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:39:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:39:08 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:39:08 --> Model "Users_model" initialized
INFO - 2022-03-14 01:39:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 01:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 01:39:08 --> Config Class Initialized
INFO - 2022-03-14 01:39:08 --> Hooks Class Initialized
DEBUG - 2022-03-14 01:39:08 --> UTF-8 Support Enabled
INFO - 2022-03-14 01:39:08 --> Utf8 Class Initialized
INFO - 2022-03-14 01:39:08 --> URI Class Initialized
INFO - 2022-03-14 01:39:08 --> Router Class Initialized
INFO - 2022-03-14 01:39:08 --> Output Class Initialized
INFO - 2022-03-14 01:39:08 --> Security Class Initialized
DEBUG - 2022-03-14 01:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 01:39:08 --> Input Class Initialized
INFO - 2022-03-14 01:39:08 --> Language Class Initialized
INFO - 2022-03-14 01:39:08 --> Loader Class Initialized
INFO - 2022-03-14 01:39:08 --> Helper loaded: url_helper
INFO - 2022-03-14 01:39:08 --> Helper loaded: form_helper
INFO - 2022-03-14 01:39:08 --> Helper loaded: common_helper
INFO - 2022-03-14 01:39:08 --> Database Driver Class Initialized
DEBUG - 2022-03-14 01:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 01:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 01:39:08 --> Controller Class Initialized
INFO - 2022-03-14 01:39:08 --> Form Validation Class Initialized
DEBUG - 2022-03-14 01:39:08 --> Encrypt Class Initialized
INFO - 2022-03-14 01:39:08 --> Model "Patient_model" initialized
INFO - 2022-03-14 01:39:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 01:39:08 --> Model "Prefix_master" initialized
INFO - 2022-03-14 01:39:08 --> Model "Users_model" initialized
INFO - 2022-03-14 01:39:08 --> Model "Hospital_model" initialized
INFO - 2022-03-14 01:39:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 01:39:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 01:39:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 01:39:08 --> Final output sent to browser
DEBUG - 2022-03-14 01:39:08 --> Total execution time: 0.0579
ERROR - 2022-03-14 02:21:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:21:46 --> Config Class Initialized
INFO - 2022-03-14 02:21:46 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:21:46 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:21:46 --> Utf8 Class Initialized
INFO - 2022-03-14 02:21:46 --> URI Class Initialized
INFO - 2022-03-14 02:21:46 --> Router Class Initialized
INFO - 2022-03-14 02:21:46 --> Output Class Initialized
INFO - 2022-03-14 02:21:46 --> Security Class Initialized
DEBUG - 2022-03-14 02:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:21:46 --> Input Class Initialized
INFO - 2022-03-14 02:21:46 --> Language Class Initialized
INFO - 2022-03-14 02:21:46 --> Loader Class Initialized
INFO - 2022-03-14 02:21:46 --> Helper loaded: url_helper
INFO - 2022-03-14 02:21:46 --> Helper loaded: form_helper
INFO - 2022-03-14 02:21:46 --> Helper loaded: common_helper
INFO - 2022-03-14 02:21:46 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:21:46 --> Controller Class Initialized
INFO - 2022-03-14 02:21:46 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:21:46 --> Encrypt Class Initialized
INFO - 2022-03-14 02:21:46 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:21:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:21:46 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:21:46 --> Model "Users_model" initialized
INFO - 2022-03-14 02:21:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 02:21:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:21:47 --> Config Class Initialized
INFO - 2022-03-14 02:21:47 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:21:47 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:21:47 --> Utf8 Class Initialized
INFO - 2022-03-14 02:21:47 --> URI Class Initialized
INFO - 2022-03-14 02:21:47 --> Router Class Initialized
INFO - 2022-03-14 02:21:47 --> Output Class Initialized
INFO - 2022-03-14 02:21:47 --> Security Class Initialized
DEBUG - 2022-03-14 02:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:21:47 --> Input Class Initialized
INFO - 2022-03-14 02:21:47 --> Language Class Initialized
INFO - 2022-03-14 02:21:47 --> Loader Class Initialized
INFO - 2022-03-14 02:21:47 --> Helper loaded: url_helper
INFO - 2022-03-14 02:21:47 --> Helper loaded: form_helper
INFO - 2022-03-14 02:21:47 --> Helper loaded: common_helper
INFO - 2022-03-14 02:21:47 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:21:47 --> Controller Class Initialized
INFO - 2022-03-14 02:21:47 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:21:47 --> Encrypt Class Initialized
INFO - 2022-03-14 02:21:47 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:21:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:21:47 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:21:47 --> Model "Users_model" initialized
INFO - 2022-03-14 02:21:47 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:21:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:21:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 02:21:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:21:47 --> Final output sent to browser
DEBUG - 2022-03-14 02:21:47 --> Total execution time: 0.2829
ERROR - 2022-03-14 02:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:21:57 --> Config Class Initialized
INFO - 2022-03-14 02:21:57 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:21:57 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:21:57 --> Utf8 Class Initialized
INFO - 2022-03-14 02:21:57 --> URI Class Initialized
INFO - 2022-03-14 02:21:57 --> Router Class Initialized
INFO - 2022-03-14 02:21:57 --> Output Class Initialized
INFO - 2022-03-14 02:21:57 --> Security Class Initialized
DEBUG - 2022-03-14 02:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:21:57 --> Input Class Initialized
INFO - 2022-03-14 02:21:57 --> Language Class Initialized
INFO - 2022-03-14 02:21:57 --> Loader Class Initialized
INFO - 2022-03-14 02:21:57 --> Helper loaded: url_helper
INFO - 2022-03-14 02:21:57 --> Helper loaded: form_helper
INFO - 2022-03-14 02:21:57 --> Helper loaded: common_helper
INFO - 2022-03-14 02:21:57 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:21:57 --> Controller Class Initialized
INFO - 2022-03-14 02:21:57 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:21:57 --> Encrypt Class Initialized
INFO - 2022-03-14 02:21:57 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:21:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:21:57 --> Model "Referredby_model" initialized
INFO - 2022-03-14 02:21:57 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:21:57 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:21:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:21:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 02:21:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:21:57 --> Final output sent to browser
DEBUG - 2022-03-14 02:21:57 --> Total execution time: 0.0851
ERROR - 2022-03-14 02:22:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:22:23 --> Config Class Initialized
INFO - 2022-03-14 02:22:24 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:22:24 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:22:24 --> Utf8 Class Initialized
INFO - 2022-03-14 02:22:24 --> URI Class Initialized
INFO - 2022-03-14 02:22:24 --> Router Class Initialized
INFO - 2022-03-14 02:22:24 --> Output Class Initialized
INFO - 2022-03-14 02:22:24 --> Security Class Initialized
DEBUG - 2022-03-14 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:22:24 --> Input Class Initialized
INFO - 2022-03-14 02:22:24 --> Language Class Initialized
INFO - 2022-03-14 02:22:24 --> Loader Class Initialized
INFO - 2022-03-14 02:22:24 --> Helper loaded: url_helper
INFO - 2022-03-14 02:22:24 --> Helper loaded: form_helper
INFO - 2022-03-14 02:22:24 --> Helper loaded: common_helper
INFO - 2022-03-14 02:22:24 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:22:24 --> Controller Class Initialized
INFO - 2022-03-14 02:22:24 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:22:24 --> Encrypt Class Initialized
INFO - 2022-03-14 02:22:24 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:22:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:22:24 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:22:24 --> Model "Users_model" initialized
INFO - 2022-03-14 02:22:24 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:22:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:22:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 02:22:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:22:24 --> Final output sent to browser
DEBUG - 2022-03-14 02:22:24 --> Total execution time: 0.0735
ERROR - 2022-03-14 02:22:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:22:28 --> Config Class Initialized
INFO - 2022-03-14 02:22:28 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:22:28 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:22:28 --> Utf8 Class Initialized
INFO - 2022-03-14 02:22:28 --> URI Class Initialized
INFO - 2022-03-14 02:22:28 --> Router Class Initialized
INFO - 2022-03-14 02:22:28 --> Output Class Initialized
INFO - 2022-03-14 02:22:28 --> Security Class Initialized
DEBUG - 2022-03-14 02:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:22:28 --> Input Class Initialized
INFO - 2022-03-14 02:22:28 --> Language Class Initialized
INFO - 2022-03-14 02:22:28 --> Loader Class Initialized
INFO - 2022-03-14 02:22:28 --> Helper loaded: url_helper
INFO - 2022-03-14 02:22:28 --> Helper loaded: form_helper
INFO - 2022-03-14 02:22:28 --> Helper loaded: common_helper
INFO - 2022-03-14 02:22:28 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:22:28 --> Controller Class Initialized
INFO - 2022-03-14 02:22:28 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:22:28 --> Encrypt Class Initialized
INFO - 2022-03-14 02:22:28 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:22:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:22:28 --> Model "Referredby_model" initialized
INFO - 2022-03-14 02:22:28 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:22:28 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:22:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:22:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 02:22:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:22:28 --> Final output sent to browser
DEBUG - 2022-03-14 02:22:28 --> Total execution time: 0.1093
ERROR - 2022-03-14 02:22:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:22:59 --> Config Class Initialized
INFO - 2022-03-14 02:22:59 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:22:59 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:22:59 --> Utf8 Class Initialized
INFO - 2022-03-14 02:22:59 --> URI Class Initialized
INFO - 2022-03-14 02:22:59 --> Router Class Initialized
INFO - 2022-03-14 02:22:59 --> Output Class Initialized
INFO - 2022-03-14 02:22:59 --> Security Class Initialized
DEBUG - 2022-03-14 02:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:22:59 --> Input Class Initialized
INFO - 2022-03-14 02:22:59 --> Language Class Initialized
INFO - 2022-03-14 02:22:59 --> Loader Class Initialized
INFO - 2022-03-14 02:22:59 --> Helper loaded: url_helper
INFO - 2022-03-14 02:22:59 --> Helper loaded: form_helper
INFO - 2022-03-14 02:22:59 --> Helper loaded: common_helper
INFO - 2022-03-14 02:22:59 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:22:59 --> Controller Class Initialized
INFO - 2022-03-14 02:22:59 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:22:59 --> Encrypt Class Initialized
INFO - 2022-03-14 02:22:59 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:22:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:22:59 --> Model "Referredby_model" initialized
INFO - 2022-03-14 02:22:59 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:22:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 02:23:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:23:00 --> Config Class Initialized
INFO - 2022-03-14 02:23:00 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:23:00 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:23:00 --> Utf8 Class Initialized
INFO - 2022-03-14 02:23:00 --> URI Class Initialized
INFO - 2022-03-14 02:23:00 --> Router Class Initialized
INFO - 2022-03-14 02:23:00 --> Output Class Initialized
INFO - 2022-03-14 02:23:00 --> Security Class Initialized
DEBUG - 2022-03-14 02:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:23:00 --> Input Class Initialized
INFO - 2022-03-14 02:23:00 --> Language Class Initialized
INFO - 2022-03-14 02:23:00 --> Loader Class Initialized
INFO - 2022-03-14 02:23:00 --> Helper loaded: url_helper
INFO - 2022-03-14 02:23:00 --> Helper loaded: form_helper
INFO - 2022-03-14 02:23:00 --> Helper loaded: common_helper
INFO - 2022-03-14 02:23:00 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:23:00 --> Controller Class Initialized
INFO - 2022-03-14 02:23:00 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:23:00 --> Encrypt Class Initialized
INFO - 2022-03-14 02:23:00 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:23:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:23:00 --> Model "Referredby_model" initialized
INFO - 2022-03-14 02:23:00 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:23:00 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:23:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:23:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 02:23:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:23:00 --> Final output sent to browser
DEBUG - 2022-03-14 02:23:00 --> Total execution time: 0.0457
ERROR - 2022-03-14 02:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:23:01 --> Config Class Initialized
INFO - 2022-03-14 02:23:01 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:23:01 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:23:01 --> Utf8 Class Initialized
INFO - 2022-03-14 02:23:01 --> URI Class Initialized
INFO - 2022-03-14 02:23:01 --> Router Class Initialized
INFO - 2022-03-14 02:23:01 --> Output Class Initialized
INFO - 2022-03-14 02:23:01 --> Security Class Initialized
DEBUG - 2022-03-14 02:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:23:01 --> Input Class Initialized
INFO - 2022-03-14 02:23:01 --> Language Class Initialized
INFO - 2022-03-14 02:23:01 --> Loader Class Initialized
INFO - 2022-03-14 02:23:01 --> Helper loaded: url_helper
INFO - 2022-03-14 02:23:01 --> Helper loaded: form_helper
INFO - 2022-03-14 02:23:01 --> Helper loaded: common_helper
INFO - 2022-03-14 02:23:01 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:23:01 --> Controller Class Initialized
INFO - 2022-03-14 02:23:01 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:23:01 --> Encrypt Class Initialized
INFO - 2022-03-14 02:23:01 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:23:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:23:01 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:23:01 --> Model "Users_model" initialized
INFO - 2022-03-14 02:23:01 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:23:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:23:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 02:23:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:23:01 --> Final output sent to browser
DEBUG - 2022-03-14 02:23:01 --> Total execution time: 0.0754
ERROR - 2022-03-14 02:26:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:26:23 --> Config Class Initialized
INFO - 2022-03-14 02:26:23 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:26:23 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:26:23 --> Utf8 Class Initialized
INFO - 2022-03-14 02:26:23 --> URI Class Initialized
INFO - 2022-03-14 02:26:23 --> Router Class Initialized
INFO - 2022-03-14 02:26:23 --> Output Class Initialized
INFO - 2022-03-14 02:26:23 --> Security Class Initialized
DEBUG - 2022-03-14 02:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:26:23 --> Input Class Initialized
INFO - 2022-03-14 02:26:23 --> Language Class Initialized
INFO - 2022-03-14 02:26:23 --> Loader Class Initialized
INFO - 2022-03-14 02:26:23 --> Helper loaded: url_helper
INFO - 2022-03-14 02:26:23 --> Helper loaded: form_helper
INFO - 2022-03-14 02:26:23 --> Helper loaded: common_helper
INFO - 2022-03-14 02:26:23 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:26:23 --> Controller Class Initialized
INFO - 2022-03-14 02:26:23 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:26:23 --> Encrypt Class Initialized
INFO - 2022-03-14 02:26:23 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:26:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:26:23 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:26:23 --> Model "Users_model" initialized
INFO - 2022-03-14 02:26:23 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:26:23 --> Upload Class Initialized
INFO - 2022-03-14 02:26:23 --> Final output sent to browser
DEBUG - 2022-03-14 02:26:23 --> Total execution time: 0.1449
ERROR - 2022-03-14 02:26:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:26:35 --> Config Class Initialized
INFO - 2022-03-14 02:26:35 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:26:35 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:26:35 --> Utf8 Class Initialized
INFO - 2022-03-14 02:26:35 --> URI Class Initialized
INFO - 2022-03-14 02:26:35 --> Router Class Initialized
INFO - 2022-03-14 02:26:35 --> Output Class Initialized
INFO - 2022-03-14 02:26:35 --> Security Class Initialized
DEBUG - 2022-03-14 02:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:26:35 --> Input Class Initialized
INFO - 2022-03-14 02:26:35 --> Language Class Initialized
INFO - 2022-03-14 02:26:35 --> Loader Class Initialized
INFO - 2022-03-14 02:26:35 --> Helper loaded: url_helper
INFO - 2022-03-14 02:26:35 --> Helper loaded: form_helper
INFO - 2022-03-14 02:26:35 --> Helper loaded: common_helper
INFO - 2022-03-14 02:26:35 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:26:35 --> Controller Class Initialized
INFO - 2022-03-14 02:26:35 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:26:35 --> Encrypt Class Initialized
INFO - 2022-03-14 02:26:35 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:26:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:26:35 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:26:35 --> Model "Users_model" initialized
INFO - 2022-03-14 02:26:35 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:26:35 --> Upload Class Initialized
INFO - 2022-03-14 02:26:35 --> Final output sent to browser
DEBUG - 2022-03-14 02:26:35 --> Total execution time: 0.0823
ERROR - 2022-03-14 02:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:27:08 --> Config Class Initialized
INFO - 2022-03-14 02:27:08 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:27:08 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:27:08 --> Utf8 Class Initialized
INFO - 2022-03-14 02:27:08 --> URI Class Initialized
INFO - 2022-03-14 02:27:08 --> Router Class Initialized
INFO - 2022-03-14 02:27:08 --> Output Class Initialized
INFO - 2022-03-14 02:27:08 --> Security Class Initialized
DEBUG - 2022-03-14 02:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:27:08 --> Input Class Initialized
INFO - 2022-03-14 02:27:08 --> Language Class Initialized
INFO - 2022-03-14 02:27:08 --> Loader Class Initialized
INFO - 2022-03-14 02:27:08 --> Helper loaded: url_helper
INFO - 2022-03-14 02:27:08 --> Helper loaded: form_helper
INFO - 2022-03-14 02:27:08 --> Helper loaded: common_helper
INFO - 2022-03-14 02:27:08 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:27:08 --> Controller Class Initialized
INFO - 2022-03-14 02:27:08 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:27:08 --> Encrypt Class Initialized
INFO - 2022-03-14 02:27:08 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:27:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:27:08 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:27:08 --> Model "Users_model" initialized
INFO - 2022-03-14 02:27:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 02:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:27:08 --> Config Class Initialized
INFO - 2022-03-14 02:27:08 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:27:08 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:27:08 --> Utf8 Class Initialized
INFO - 2022-03-14 02:27:08 --> URI Class Initialized
INFO - 2022-03-14 02:27:08 --> Router Class Initialized
INFO - 2022-03-14 02:27:08 --> Output Class Initialized
INFO - 2022-03-14 02:27:08 --> Security Class Initialized
DEBUG - 2022-03-14 02:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:27:08 --> Input Class Initialized
INFO - 2022-03-14 02:27:08 --> Language Class Initialized
INFO - 2022-03-14 02:27:08 --> Loader Class Initialized
INFO - 2022-03-14 02:27:08 --> Helper loaded: url_helper
INFO - 2022-03-14 02:27:08 --> Helper loaded: form_helper
INFO - 2022-03-14 02:27:08 --> Helper loaded: common_helper
INFO - 2022-03-14 02:27:08 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:27:09 --> Controller Class Initialized
INFO - 2022-03-14 02:27:09 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:27:09 --> Encrypt Class Initialized
INFO - 2022-03-14 02:27:09 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:27:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:27:09 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:27:09 --> Model "Users_model" initialized
INFO - 2022-03-14 02:27:09 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:27:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:27:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 02:27:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:27:09 --> Final output sent to browser
DEBUG - 2022-03-14 02:27:09 --> Total execution time: 0.0748
ERROR - 2022-03-14 02:27:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:27:45 --> Config Class Initialized
INFO - 2022-03-14 02:27:45 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:27:45 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:27:45 --> Utf8 Class Initialized
INFO - 2022-03-14 02:27:45 --> URI Class Initialized
INFO - 2022-03-14 02:27:45 --> Router Class Initialized
INFO - 2022-03-14 02:27:45 --> Output Class Initialized
INFO - 2022-03-14 02:27:45 --> Security Class Initialized
DEBUG - 2022-03-14 02:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:27:45 --> Input Class Initialized
INFO - 2022-03-14 02:27:45 --> Language Class Initialized
INFO - 2022-03-14 02:27:45 --> Loader Class Initialized
INFO - 2022-03-14 02:27:45 --> Helper loaded: url_helper
INFO - 2022-03-14 02:27:45 --> Helper loaded: form_helper
INFO - 2022-03-14 02:27:45 --> Helper loaded: common_helper
INFO - 2022-03-14 02:27:45 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:27:45 --> Controller Class Initialized
INFO - 2022-03-14 02:27:45 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:27:45 --> Encrypt Class Initialized
INFO - 2022-03-14 02:27:45 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:27:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:27:45 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:27:45 --> Model "Users_model" initialized
INFO - 2022-03-14 02:27:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 02:27:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:27:46 --> Config Class Initialized
INFO - 2022-03-14 02:27:46 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:27:46 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:27:46 --> Utf8 Class Initialized
INFO - 2022-03-14 02:27:46 --> URI Class Initialized
INFO - 2022-03-14 02:27:46 --> Router Class Initialized
INFO - 2022-03-14 02:27:46 --> Output Class Initialized
INFO - 2022-03-14 02:27:46 --> Security Class Initialized
DEBUG - 2022-03-14 02:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:27:46 --> Input Class Initialized
INFO - 2022-03-14 02:27:46 --> Language Class Initialized
INFO - 2022-03-14 02:27:46 --> Loader Class Initialized
INFO - 2022-03-14 02:27:46 --> Helper loaded: url_helper
INFO - 2022-03-14 02:27:46 --> Helper loaded: form_helper
INFO - 2022-03-14 02:27:46 --> Helper loaded: common_helper
INFO - 2022-03-14 02:27:46 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:27:46 --> Controller Class Initialized
INFO - 2022-03-14 02:27:46 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:27:46 --> Encrypt Class Initialized
INFO - 2022-03-14 02:27:46 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:27:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:27:46 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:27:46 --> Model "Users_model" initialized
INFO - 2022-03-14 02:27:46 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:27:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:27:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 02:27:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:27:46 --> Final output sent to browser
DEBUG - 2022-03-14 02:27:46 --> Total execution time: 0.0718
ERROR - 2022-03-14 02:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:28:21 --> Config Class Initialized
INFO - 2022-03-14 02:28:21 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:28:21 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:28:21 --> Utf8 Class Initialized
INFO - 2022-03-14 02:28:21 --> URI Class Initialized
INFO - 2022-03-14 02:28:21 --> Router Class Initialized
INFO - 2022-03-14 02:28:21 --> Output Class Initialized
INFO - 2022-03-14 02:28:21 --> Security Class Initialized
DEBUG - 2022-03-14 02:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:28:21 --> Input Class Initialized
INFO - 2022-03-14 02:28:21 --> Language Class Initialized
INFO - 2022-03-14 02:28:21 --> Loader Class Initialized
INFO - 2022-03-14 02:28:21 --> Helper loaded: url_helper
INFO - 2022-03-14 02:28:21 --> Helper loaded: form_helper
INFO - 2022-03-14 02:28:21 --> Helper loaded: common_helper
INFO - 2022-03-14 02:28:21 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:28:21 --> Controller Class Initialized
INFO - 2022-03-14 02:28:21 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:28:21 --> Encrypt Class Initialized
INFO - 2022-03-14 02:28:21 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:28:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:28:21 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:28:21 --> Model "Users_model" initialized
INFO - 2022-03-14 02:28:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 02:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:28:22 --> Config Class Initialized
INFO - 2022-03-14 02:28:22 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:28:22 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:28:22 --> Utf8 Class Initialized
INFO - 2022-03-14 02:28:22 --> URI Class Initialized
INFO - 2022-03-14 02:28:22 --> Router Class Initialized
INFO - 2022-03-14 02:28:22 --> Output Class Initialized
INFO - 2022-03-14 02:28:22 --> Security Class Initialized
DEBUG - 2022-03-14 02:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:28:22 --> Input Class Initialized
INFO - 2022-03-14 02:28:22 --> Language Class Initialized
INFO - 2022-03-14 02:28:22 --> Loader Class Initialized
INFO - 2022-03-14 02:28:22 --> Helper loaded: url_helper
INFO - 2022-03-14 02:28:22 --> Helper loaded: form_helper
INFO - 2022-03-14 02:28:22 --> Helper loaded: common_helper
INFO - 2022-03-14 02:28:22 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:28:22 --> Controller Class Initialized
INFO - 2022-03-14 02:28:22 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:28:22 --> Encrypt Class Initialized
INFO - 2022-03-14 02:28:22 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:28:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:28:22 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:28:22 --> Model "Users_model" initialized
INFO - 2022-03-14 02:28:22 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:28:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:28:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 02:28:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:28:22 --> Final output sent to browser
DEBUG - 2022-03-14 02:28:22 --> Total execution time: 0.2246
ERROR - 2022-03-14 02:28:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:28:26 --> Config Class Initialized
INFO - 2022-03-14 02:28:26 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:28:26 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:28:26 --> Utf8 Class Initialized
INFO - 2022-03-14 02:28:26 --> URI Class Initialized
INFO - 2022-03-14 02:28:26 --> Router Class Initialized
INFO - 2022-03-14 02:28:26 --> Output Class Initialized
INFO - 2022-03-14 02:28:26 --> Security Class Initialized
DEBUG - 2022-03-14 02:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:28:26 --> Input Class Initialized
INFO - 2022-03-14 02:28:26 --> Language Class Initialized
INFO - 2022-03-14 02:28:26 --> Loader Class Initialized
INFO - 2022-03-14 02:28:26 --> Helper loaded: url_helper
INFO - 2022-03-14 02:28:26 --> Helper loaded: form_helper
INFO - 2022-03-14 02:28:26 --> Helper loaded: common_helper
INFO - 2022-03-14 02:28:26 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:28:26 --> Controller Class Initialized
INFO - 2022-03-14 02:28:26 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:28:26 --> Encrypt Class Initialized
INFO - 2022-03-14 02:28:26 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:28:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:28:26 --> Model "Referredby_model" initialized
INFO - 2022-03-14 02:28:26 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:28:26 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:28:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:28:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 02:28:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:28:27 --> Final output sent to browser
DEBUG - 2022-03-14 02:28:27 --> Total execution time: 0.0600
ERROR - 2022-03-14 02:28:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:28:43 --> Config Class Initialized
INFO - 2022-03-14 02:28:43 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:28:43 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:28:43 --> Utf8 Class Initialized
INFO - 2022-03-14 02:28:43 --> URI Class Initialized
INFO - 2022-03-14 02:28:43 --> Router Class Initialized
INFO - 2022-03-14 02:28:43 --> Output Class Initialized
INFO - 2022-03-14 02:28:43 --> Security Class Initialized
DEBUG - 2022-03-14 02:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:28:43 --> Input Class Initialized
INFO - 2022-03-14 02:28:43 --> Language Class Initialized
INFO - 2022-03-14 02:28:43 --> Loader Class Initialized
INFO - 2022-03-14 02:28:43 --> Helper loaded: url_helper
INFO - 2022-03-14 02:28:43 --> Helper loaded: form_helper
INFO - 2022-03-14 02:28:43 --> Helper loaded: common_helper
INFO - 2022-03-14 02:28:43 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:28:43 --> Controller Class Initialized
INFO - 2022-03-14 02:28:43 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:28:43 --> Encrypt Class Initialized
INFO - 2022-03-14 02:28:43 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:28:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:28:43 --> Model "Referredby_model" initialized
INFO - 2022-03-14 02:28:43 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:28:43 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:28:43 --> Upload Class Initialized
INFO - 2022-03-14 02:28:43 --> Final output sent to browser
DEBUG - 2022-03-14 02:28:43 --> Total execution time: 0.0337
ERROR - 2022-03-14 02:28:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:28:58 --> Config Class Initialized
INFO - 2022-03-14 02:28:58 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:28:58 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:28:58 --> Utf8 Class Initialized
INFO - 2022-03-14 02:28:58 --> URI Class Initialized
INFO - 2022-03-14 02:28:58 --> Router Class Initialized
INFO - 2022-03-14 02:28:58 --> Output Class Initialized
INFO - 2022-03-14 02:28:58 --> Security Class Initialized
DEBUG - 2022-03-14 02:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:28:58 --> Input Class Initialized
INFO - 2022-03-14 02:28:58 --> Language Class Initialized
INFO - 2022-03-14 02:28:58 --> Loader Class Initialized
INFO - 2022-03-14 02:28:58 --> Helper loaded: url_helper
INFO - 2022-03-14 02:28:58 --> Helper loaded: form_helper
INFO - 2022-03-14 02:28:58 --> Helper loaded: common_helper
INFO - 2022-03-14 02:28:58 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:28:58 --> Controller Class Initialized
INFO - 2022-03-14 02:28:58 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:28:58 --> Encrypt Class Initialized
INFO - 2022-03-14 02:28:58 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:28:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:28:58 --> Model "Referredby_model" initialized
INFO - 2022-03-14 02:28:58 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:28:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 02:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:28:59 --> Config Class Initialized
INFO - 2022-03-14 02:28:59 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:28:59 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:28:59 --> Utf8 Class Initialized
INFO - 2022-03-14 02:28:59 --> URI Class Initialized
INFO - 2022-03-14 02:28:59 --> Router Class Initialized
INFO - 2022-03-14 02:28:59 --> Output Class Initialized
INFO - 2022-03-14 02:28:59 --> Security Class Initialized
DEBUG - 2022-03-14 02:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:28:59 --> Input Class Initialized
INFO - 2022-03-14 02:28:59 --> Language Class Initialized
INFO - 2022-03-14 02:28:59 --> Loader Class Initialized
INFO - 2022-03-14 02:28:59 --> Helper loaded: url_helper
INFO - 2022-03-14 02:28:59 --> Helper loaded: form_helper
INFO - 2022-03-14 02:28:59 --> Helper loaded: common_helper
INFO - 2022-03-14 02:28:59 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:28:59 --> Controller Class Initialized
INFO - 2022-03-14 02:28:59 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:28:59 --> Encrypt Class Initialized
INFO - 2022-03-14 02:28:59 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:28:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:28:59 --> Model "Referredby_model" initialized
INFO - 2022-03-14 02:28:59 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:28:59 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:28:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:28:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 02:28:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:28:59 --> Final output sent to browser
DEBUG - 2022-03-14 02:28:59 --> Total execution time: 0.0459
ERROR - 2022-03-14 02:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:29:00 --> Config Class Initialized
INFO - 2022-03-14 02:29:00 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:29:00 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:29:00 --> Utf8 Class Initialized
INFO - 2022-03-14 02:29:00 --> URI Class Initialized
INFO - 2022-03-14 02:29:00 --> Router Class Initialized
INFO - 2022-03-14 02:29:00 --> Output Class Initialized
INFO - 2022-03-14 02:29:00 --> Security Class Initialized
DEBUG - 2022-03-14 02:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:29:00 --> Input Class Initialized
INFO - 2022-03-14 02:29:00 --> Language Class Initialized
INFO - 2022-03-14 02:29:00 --> Loader Class Initialized
INFO - 2022-03-14 02:29:00 --> Helper loaded: url_helper
INFO - 2022-03-14 02:29:00 --> Helper loaded: form_helper
INFO - 2022-03-14 02:29:00 --> Helper loaded: common_helper
INFO - 2022-03-14 02:29:00 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:29:00 --> Controller Class Initialized
INFO - 2022-03-14 02:29:00 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:29:00 --> Encrypt Class Initialized
INFO - 2022-03-14 02:29:00 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:29:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:29:00 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:29:00 --> Model "Users_model" initialized
INFO - 2022-03-14 02:29:00 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:29:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:29:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 02:29:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:29:00 --> Final output sent to browser
DEBUG - 2022-03-14 02:29:00 --> Total execution time: 0.0593
ERROR - 2022-03-14 02:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:29:07 --> Config Class Initialized
INFO - 2022-03-14 02:29:07 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:29:07 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:29:07 --> Utf8 Class Initialized
INFO - 2022-03-14 02:29:07 --> URI Class Initialized
INFO - 2022-03-14 02:29:07 --> Router Class Initialized
INFO - 2022-03-14 02:29:07 --> Output Class Initialized
INFO - 2022-03-14 02:29:07 --> Security Class Initialized
DEBUG - 2022-03-14 02:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:29:07 --> Input Class Initialized
INFO - 2022-03-14 02:29:07 --> Language Class Initialized
INFO - 2022-03-14 02:29:07 --> Loader Class Initialized
INFO - 2022-03-14 02:29:07 --> Helper loaded: url_helper
INFO - 2022-03-14 02:29:07 --> Helper loaded: form_helper
INFO - 2022-03-14 02:29:07 --> Helper loaded: common_helper
INFO - 2022-03-14 02:29:07 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:29:07 --> Controller Class Initialized
INFO - 2022-03-14 02:29:07 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:29:07 --> Encrypt Class Initialized
INFO - 2022-03-14 02:29:07 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:29:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:29:07 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:29:07 --> Model "Users_model" initialized
INFO - 2022-03-14 02:29:07 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 02:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 02:29:08 --> Config Class Initialized
INFO - 2022-03-14 02:29:08 --> Hooks Class Initialized
DEBUG - 2022-03-14 02:29:08 --> UTF-8 Support Enabled
INFO - 2022-03-14 02:29:08 --> Utf8 Class Initialized
INFO - 2022-03-14 02:29:08 --> URI Class Initialized
INFO - 2022-03-14 02:29:08 --> Router Class Initialized
INFO - 2022-03-14 02:29:08 --> Output Class Initialized
INFO - 2022-03-14 02:29:08 --> Security Class Initialized
DEBUG - 2022-03-14 02:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 02:29:08 --> Input Class Initialized
INFO - 2022-03-14 02:29:08 --> Language Class Initialized
INFO - 2022-03-14 02:29:08 --> Loader Class Initialized
INFO - 2022-03-14 02:29:08 --> Helper loaded: url_helper
INFO - 2022-03-14 02:29:08 --> Helper loaded: form_helper
INFO - 2022-03-14 02:29:08 --> Helper loaded: common_helper
INFO - 2022-03-14 02:29:08 --> Database Driver Class Initialized
DEBUG - 2022-03-14 02:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 02:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 02:29:08 --> Controller Class Initialized
INFO - 2022-03-14 02:29:08 --> Form Validation Class Initialized
DEBUG - 2022-03-14 02:29:08 --> Encrypt Class Initialized
INFO - 2022-03-14 02:29:08 --> Model "Patient_model" initialized
INFO - 2022-03-14 02:29:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 02:29:08 --> Model "Prefix_master" initialized
INFO - 2022-03-14 02:29:08 --> Model "Users_model" initialized
INFO - 2022-03-14 02:29:08 --> Model "Hospital_model" initialized
INFO - 2022-03-14 02:29:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 02:29:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 02:29:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 02:29:08 --> Final output sent to browser
DEBUG - 2022-03-14 02:29:08 --> Total execution time: 0.0788
ERROR - 2022-03-14 03:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:28:34 --> Config Class Initialized
INFO - 2022-03-14 03:28:34 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:28:34 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:28:34 --> Utf8 Class Initialized
INFO - 2022-03-14 03:28:34 --> URI Class Initialized
INFO - 2022-03-14 03:28:34 --> Router Class Initialized
INFO - 2022-03-14 03:28:34 --> Output Class Initialized
INFO - 2022-03-14 03:28:34 --> Security Class Initialized
DEBUG - 2022-03-14 03:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:28:34 --> Input Class Initialized
INFO - 2022-03-14 03:28:34 --> Language Class Initialized
INFO - 2022-03-14 03:28:34 --> Loader Class Initialized
INFO - 2022-03-14 03:28:34 --> Helper loaded: url_helper
INFO - 2022-03-14 03:28:34 --> Helper loaded: form_helper
INFO - 2022-03-14 03:28:34 --> Helper loaded: common_helper
INFO - 2022-03-14 03:28:34 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:28:34 --> Controller Class Initialized
INFO - 2022-03-14 03:28:34 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:28:34 --> Encrypt Class Initialized
INFO - 2022-03-14 03:28:34 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:28:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:28:34 --> Model "Referredby_model" initialized
INFO - 2022-03-14 03:28:34 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:28:34 --> Model "Hospital_model" initialized
INFO - 2022-03-14 03:28:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 03:28:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 03:28:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 03:28:34 --> Final output sent to browser
DEBUG - 2022-03-14 03:28:34 --> Total execution time: 0.1100
ERROR - 2022-03-14 03:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:28:40 --> Config Class Initialized
INFO - 2022-03-14 03:28:40 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:28:40 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:28:40 --> Utf8 Class Initialized
INFO - 2022-03-14 03:28:40 --> URI Class Initialized
INFO - 2022-03-14 03:28:40 --> Router Class Initialized
INFO - 2022-03-14 03:28:40 --> Output Class Initialized
INFO - 2022-03-14 03:28:40 --> Security Class Initialized
DEBUG - 2022-03-14 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:28:40 --> Input Class Initialized
INFO - 2022-03-14 03:28:40 --> Language Class Initialized
INFO - 2022-03-14 03:28:40 --> Loader Class Initialized
INFO - 2022-03-14 03:28:40 --> Helper loaded: url_helper
INFO - 2022-03-14 03:28:40 --> Helper loaded: form_helper
INFO - 2022-03-14 03:28:40 --> Helper loaded: common_helper
INFO - 2022-03-14 03:28:40 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:28:40 --> Controller Class Initialized
INFO - 2022-03-14 03:28:40 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:28:40 --> Encrypt Class Initialized
INFO - 2022-03-14 03:28:40 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:28:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:28:40 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:28:40 --> Model "Users_model" initialized
INFO - 2022-03-14 03:28:40 --> Model "Hospital_model" initialized
INFO - 2022-03-14 03:28:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 03:28:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 03:28:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 03:28:41 --> Final output sent to browser
DEBUG - 2022-03-14 03:28:41 --> Total execution time: 0.1694
ERROR - 2022-03-14 03:28:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:28:45 --> Config Class Initialized
INFO - 2022-03-14 03:28:45 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:28:45 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:28:45 --> Utf8 Class Initialized
INFO - 2022-03-14 03:28:45 --> URI Class Initialized
INFO - 2022-03-14 03:28:45 --> Router Class Initialized
INFO - 2022-03-14 03:28:45 --> Output Class Initialized
INFO - 2022-03-14 03:28:45 --> Security Class Initialized
DEBUG - 2022-03-14 03:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:28:45 --> Input Class Initialized
INFO - 2022-03-14 03:28:45 --> Language Class Initialized
INFO - 2022-03-14 03:28:45 --> Loader Class Initialized
INFO - 2022-03-14 03:28:45 --> Helper loaded: url_helper
INFO - 2022-03-14 03:28:45 --> Helper loaded: form_helper
INFO - 2022-03-14 03:28:45 --> Helper loaded: common_helper
INFO - 2022-03-14 03:28:45 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:28:45 --> Controller Class Initialized
INFO - 2022-03-14 03:28:45 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:28:45 --> Encrypt Class Initialized
INFO - 2022-03-14 03:28:45 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:28:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:28:45 --> Model "Referredby_model" initialized
INFO - 2022-03-14 03:28:45 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:28:45 --> Model "Hospital_model" initialized
INFO - 2022-03-14 03:28:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 03:28:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 03:28:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 03:28:45 --> Final output sent to browser
DEBUG - 2022-03-14 03:28:45 --> Total execution time: 0.0599
ERROR - 2022-03-14 03:29:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:29:32 --> Config Class Initialized
INFO - 2022-03-14 03:29:32 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:29:32 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:29:32 --> Utf8 Class Initialized
INFO - 2022-03-14 03:29:32 --> URI Class Initialized
INFO - 2022-03-14 03:29:32 --> Router Class Initialized
INFO - 2022-03-14 03:29:32 --> Output Class Initialized
INFO - 2022-03-14 03:29:32 --> Security Class Initialized
DEBUG - 2022-03-14 03:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:29:32 --> Input Class Initialized
INFO - 2022-03-14 03:29:32 --> Language Class Initialized
INFO - 2022-03-14 03:29:32 --> Loader Class Initialized
INFO - 2022-03-14 03:29:32 --> Helper loaded: url_helper
INFO - 2022-03-14 03:29:32 --> Helper loaded: form_helper
INFO - 2022-03-14 03:29:32 --> Helper loaded: common_helper
INFO - 2022-03-14 03:29:32 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:29:32 --> Controller Class Initialized
INFO - 2022-03-14 03:29:32 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:29:32 --> Encrypt Class Initialized
INFO - 2022-03-14 03:29:32 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:29:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:29:32 --> Model "Referredby_model" initialized
INFO - 2022-03-14 03:29:32 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:29:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 03:29:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:29:32 --> Config Class Initialized
INFO - 2022-03-14 03:29:32 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:29:32 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:29:32 --> Utf8 Class Initialized
INFO - 2022-03-14 03:29:32 --> URI Class Initialized
INFO - 2022-03-14 03:29:32 --> Router Class Initialized
INFO - 2022-03-14 03:29:32 --> Output Class Initialized
INFO - 2022-03-14 03:29:32 --> Security Class Initialized
DEBUG - 2022-03-14 03:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:29:32 --> Input Class Initialized
INFO - 2022-03-14 03:29:32 --> Language Class Initialized
INFO - 2022-03-14 03:29:32 --> Loader Class Initialized
INFO - 2022-03-14 03:29:32 --> Helper loaded: url_helper
INFO - 2022-03-14 03:29:32 --> Helper loaded: form_helper
INFO - 2022-03-14 03:29:32 --> Helper loaded: common_helper
INFO - 2022-03-14 03:29:32 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:29:32 --> Controller Class Initialized
INFO - 2022-03-14 03:29:32 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:29:32 --> Encrypt Class Initialized
INFO - 2022-03-14 03:29:32 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:29:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:29:32 --> Model "Referredby_model" initialized
INFO - 2022-03-14 03:29:32 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:29:32 --> Model "Hospital_model" initialized
INFO - 2022-03-14 03:29:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 03:29:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 03:29:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 03:29:32 --> Final output sent to browser
DEBUG - 2022-03-14 03:29:32 --> Total execution time: 0.0474
ERROR - 2022-03-14 03:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:29:33 --> Config Class Initialized
INFO - 2022-03-14 03:29:33 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:29:33 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:29:33 --> Utf8 Class Initialized
INFO - 2022-03-14 03:29:33 --> URI Class Initialized
INFO - 2022-03-14 03:29:33 --> Router Class Initialized
INFO - 2022-03-14 03:29:33 --> Output Class Initialized
INFO - 2022-03-14 03:29:33 --> Security Class Initialized
DEBUG - 2022-03-14 03:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:29:33 --> Input Class Initialized
INFO - 2022-03-14 03:29:33 --> Language Class Initialized
INFO - 2022-03-14 03:29:33 --> Loader Class Initialized
INFO - 2022-03-14 03:29:33 --> Helper loaded: url_helper
INFO - 2022-03-14 03:29:33 --> Helper loaded: form_helper
INFO - 2022-03-14 03:29:33 --> Helper loaded: common_helper
INFO - 2022-03-14 03:29:33 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:29:33 --> Controller Class Initialized
INFO - 2022-03-14 03:29:33 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:29:33 --> Encrypt Class Initialized
INFO - 2022-03-14 03:29:33 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:29:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:29:33 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:29:33 --> Model "Users_model" initialized
INFO - 2022-03-14 03:29:33 --> Model "Hospital_model" initialized
INFO - 2022-03-14 03:29:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 03:29:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 03:29:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 03:29:33 --> Final output sent to browser
DEBUG - 2022-03-14 03:29:33 --> Total execution time: 0.0620
ERROR - 2022-03-14 03:30:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:30:24 --> Config Class Initialized
INFO - 2022-03-14 03:30:24 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:30:24 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:30:24 --> Utf8 Class Initialized
INFO - 2022-03-14 03:30:24 --> URI Class Initialized
INFO - 2022-03-14 03:30:24 --> Router Class Initialized
INFO - 2022-03-14 03:30:24 --> Output Class Initialized
INFO - 2022-03-14 03:30:24 --> Security Class Initialized
DEBUG - 2022-03-14 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:30:24 --> Input Class Initialized
INFO - 2022-03-14 03:30:24 --> Language Class Initialized
INFO - 2022-03-14 03:30:24 --> Loader Class Initialized
INFO - 2022-03-14 03:30:24 --> Helper loaded: url_helper
INFO - 2022-03-14 03:30:24 --> Helper loaded: form_helper
INFO - 2022-03-14 03:30:24 --> Helper loaded: common_helper
INFO - 2022-03-14 03:30:24 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:30:24 --> Controller Class Initialized
INFO - 2022-03-14 03:30:24 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:30:24 --> Encrypt Class Initialized
INFO - 2022-03-14 03:30:24 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:30:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:30:24 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:30:24 --> Model "Users_model" initialized
INFO - 2022-03-14 03:30:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 03:30:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:30:24 --> Config Class Initialized
INFO - 2022-03-14 03:30:24 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:30:24 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:30:24 --> Utf8 Class Initialized
INFO - 2022-03-14 03:30:24 --> URI Class Initialized
INFO - 2022-03-14 03:30:24 --> Router Class Initialized
INFO - 2022-03-14 03:30:24 --> Output Class Initialized
INFO - 2022-03-14 03:30:24 --> Security Class Initialized
DEBUG - 2022-03-14 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:30:24 --> Input Class Initialized
INFO - 2022-03-14 03:30:24 --> Language Class Initialized
INFO - 2022-03-14 03:30:24 --> Loader Class Initialized
INFO - 2022-03-14 03:30:24 --> Helper loaded: url_helper
INFO - 2022-03-14 03:30:24 --> Helper loaded: form_helper
INFO - 2022-03-14 03:30:24 --> Helper loaded: common_helper
INFO - 2022-03-14 03:30:24 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:30:24 --> Controller Class Initialized
INFO - 2022-03-14 03:30:24 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:30:24 --> Encrypt Class Initialized
INFO - 2022-03-14 03:30:24 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:30:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:30:24 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:30:24 --> Model "Users_model" initialized
INFO - 2022-03-14 03:30:24 --> Model "Hospital_model" initialized
INFO - 2022-03-14 03:30:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 03:30:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 03:30:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 03:30:24 --> Final output sent to browser
DEBUG - 2022-03-14 03:30:24 --> Total execution time: 0.0937
ERROR - 2022-03-14 03:33:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:33:32 --> Config Class Initialized
INFO - 2022-03-14 03:33:32 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:33:32 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:33:32 --> Utf8 Class Initialized
INFO - 2022-03-14 03:33:32 --> URI Class Initialized
INFO - 2022-03-14 03:33:32 --> Router Class Initialized
INFO - 2022-03-14 03:33:32 --> Output Class Initialized
INFO - 2022-03-14 03:33:32 --> Security Class Initialized
DEBUG - 2022-03-14 03:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:33:32 --> Input Class Initialized
INFO - 2022-03-14 03:33:32 --> Language Class Initialized
INFO - 2022-03-14 03:33:32 --> Loader Class Initialized
INFO - 2022-03-14 03:33:32 --> Helper loaded: url_helper
INFO - 2022-03-14 03:33:32 --> Helper loaded: form_helper
INFO - 2022-03-14 03:33:32 --> Helper loaded: common_helper
INFO - 2022-03-14 03:33:32 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:33:32 --> Controller Class Initialized
INFO - 2022-03-14 03:33:32 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:33:32 --> Encrypt Class Initialized
INFO - 2022-03-14 03:33:32 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:33:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:33:32 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:33:32 --> Model "Users_model" initialized
INFO - 2022-03-14 03:33:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 03:33:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:33:32 --> Config Class Initialized
INFO - 2022-03-14 03:33:32 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:33:32 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:33:32 --> Utf8 Class Initialized
INFO - 2022-03-14 03:33:32 --> URI Class Initialized
INFO - 2022-03-14 03:33:32 --> Router Class Initialized
INFO - 2022-03-14 03:33:32 --> Output Class Initialized
INFO - 2022-03-14 03:33:32 --> Security Class Initialized
DEBUG - 2022-03-14 03:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:33:32 --> Input Class Initialized
INFO - 2022-03-14 03:33:32 --> Language Class Initialized
INFO - 2022-03-14 03:33:32 --> Loader Class Initialized
INFO - 2022-03-14 03:33:32 --> Helper loaded: url_helper
INFO - 2022-03-14 03:33:32 --> Helper loaded: form_helper
INFO - 2022-03-14 03:33:32 --> Helper loaded: common_helper
INFO - 2022-03-14 03:33:32 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:33:32 --> Controller Class Initialized
INFO - 2022-03-14 03:33:32 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:33:32 --> Encrypt Class Initialized
INFO - 2022-03-14 03:33:32 --> Model "Patient_model" initialized
INFO - 2022-03-14 03:33:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 03:33:32 --> Model "Prefix_master" initialized
INFO - 2022-03-14 03:33:32 --> Model "Users_model" initialized
INFO - 2022-03-14 03:33:32 --> Model "Hospital_model" initialized
INFO - 2022-03-14 03:33:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 03:33:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 03:33:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 03:33:32 --> Final output sent to browser
DEBUG - 2022-03-14 03:33:32 --> Total execution time: 0.0760
ERROR - 2022-03-14 03:51:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:51:17 --> Config Class Initialized
INFO - 2022-03-14 03:51:17 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:51:17 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:51:17 --> Utf8 Class Initialized
INFO - 2022-03-14 03:51:17 --> URI Class Initialized
INFO - 2022-03-14 03:51:17 --> Router Class Initialized
INFO - 2022-03-14 03:51:17 --> Output Class Initialized
INFO - 2022-03-14 03:51:17 --> Security Class Initialized
DEBUG - 2022-03-14 03:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:51:17 --> Input Class Initialized
INFO - 2022-03-14 03:51:17 --> Language Class Initialized
INFO - 2022-03-14 03:51:17 --> Loader Class Initialized
INFO - 2022-03-14 03:51:17 --> Helper loaded: url_helper
INFO - 2022-03-14 03:51:17 --> Helper loaded: form_helper
INFO - 2022-03-14 03:51:17 --> Helper loaded: common_helper
INFO - 2022-03-14 03:51:17 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:51:17 --> Controller Class Initialized
ERROR - 2022-03-14 03:51:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 03:51:18 --> Config Class Initialized
INFO - 2022-03-14 03:51:18 --> Hooks Class Initialized
DEBUG - 2022-03-14 03:51:18 --> UTF-8 Support Enabled
INFO - 2022-03-14 03:51:18 --> Utf8 Class Initialized
INFO - 2022-03-14 03:51:18 --> URI Class Initialized
INFO - 2022-03-14 03:51:18 --> Router Class Initialized
INFO - 2022-03-14 03:51:18 --> Output Class Initialized
INFO - 2022-03-14 03:51:18 --> Security Class Initialized
DEBUG - 2022-03-14 03:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 03:51:18 --> Input Class Initialized
INFO - 2022-03-14 03:51:18 --> Language Class Initialized
INFO - 2022-03-14 03:51:18 --> Loader Class Initialized
INFO - 2022-03-14 03:51:18 --> Helper loaded: url_helper
INFO - 2022-03-14 03:51:18 --> Helper loaded: form_helper
INFO - 2022-03-14 03:51:18 --> Helper loaded: common_helper
INFO - 2022-03-14 03:51:18 --> Database Driver Class Initialized
DEBUG - 2022-03-14 03:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 03:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 03:51:18 --> Controller Class Initialized
INFO - 2022-03-14 03:51:18 --> Form Validation Class Initialized
DEBUG - 2022-03-14 03:51:18 --> Encrypt Class Initialized
DEBUG - 2022-03-14 03:51:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 03:51:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 03:51:18 --> Email Class Initialized
INFO - 2022-03-14 03:51:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 03:51:18 --> Calendar Class Initialized
INFO - 2022-03-14 03:51:18 --> Model "Login_model" initialized
INFO - 2022-03-14 03:51:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 03:51:18 --> Final output sent to browser
DEBUG - 2022-03-14 03:51:18 --> Total execution time: 0.0397
ERROR - 2022-03-14 04:00:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:00:13 --> Config Class Initialized
INFO - 2022-03-14 04:00:13 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:00:13 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:00:13 --> Utf8 Class Initialized
INFO - 2022-03-14 04:00:13 --> URI Class Initialized
INFO - 2022-03-14 04:00:13 --> Router Class Initialized
INFO - 2022-03-14 04:00:13 --> Output Class Initialized
INFO - 2022-03-14 04:00:13 --> Security Class Initialized
DEBUG - 2022-03-14 04:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:00:13 --> Input Class Initialized
INFO - 2022-03-14 04:00:13 --> Language Class Initialized
INFO - 2022-03-14 04:00:13 --> Loader Class Initialized
INFO - 2022-03-14 04:00:13 --> Helper loaded: url_helper
INFO - 2022-03-14 04:00:13 --> Helper loaded: form_helper
INFO - 2022-03-14 04:00:13 --> Helper loaded: common_helper
INFO - 2022-03-14 04:00:13 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:00:13 --> Controller Class Initialized
INFO - 2022-03-14 04:00:13 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:00:13 --> Encrypt Class Initialized
DEBUG - 2022-03-14 04:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 04:00:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 04:00:13 --> Email Class Initialized
INFO - 2022-03-14 04:00:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 04:00:13 --> Calendar Class Initialized
INFO - 2022-03-14 04:00:13 --> Model "Login_model" initialized
INFO - 2022-03-14 04:00:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-14 04:00:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:00:13 --> Config Class Initialized
INFO - 2022-03-14 04:00:13 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:00:13 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:00:13 --> Utf8 Class Initialized
INFO - 2022-03-14 04:00:13 --> URI Class Initialized
INFO - 2022-03-14 04:00:13 --> Router Class Initialized
INFO - 2022-03-14 04:00:13 --> Output Class Initialized
INFO - 2022-03-14 04:00:13 --> Security Class Initialized
DEBUG - 2022-03-14 04:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:00:13 --> Input Class Initialized
INFO - 2022-03-14 04:00:13 --> Language Class Initialized
INFO - 2022-03-14 04:00:13 --> Loader Class Initialized
INFO - 2022-03-14 04:00:13 --> Helper loaded: url_helper
INFO - 2022-03-14 04:00:13 --> Helper loaded: form_helper
INFO - 2022-03-14 04:00:13 --> Helper loaded: common_helper
INFO - 2022-03-14 04:00:13 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:00:13 --> Controller Class Initialized
INFO - 2022-03-14 04:00:13 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:00:13 --> Encrypt Class Initialized
INFO - 2022-03-14 04:00:13 --> Model "Login_model" initialized
INFO - 2022-03-14 04:00:13 --> Model "Dashboard_model" initialized
INFO - 2022-03-14 04:00:13 --> Model "Case_model" initialized
INFO - 2022-03-14 04:00:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 04:00:36 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-14 04:00:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 04:00:36 --> Final output sent to browser
DEBUG - 2022-03-14 04:00:36 --> Total execution time: 22.3410
ERROR - 2022-03-14 04:20:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:20:58 --> Config Class Initialized
INFO - 2022-03-14 04:20:58 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:20:58 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:20:58 --> Utf8 Class Initialized
INFO - 2022-03-14 04:20:58 --> URI Class Initialized
INFO - 2022-03-14 04:20:58 --> Router Class Initialized
INFO - 2022-03-14 04:20:58 --> Output Class Initialized
INFO - 2022-03-14 04:20:58 --> Security Class Initialized
DEBUG - 2022-03-14 04:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:20:58 --> Input Class Initialized
INFO - 2022-03-14 04:20:58 --> Language Class Initialized
INFO - 2022-03-14 04:20:58 --> Loader Class Initialized
INFO - 2022-03-14 04:20:58 --> Helper loaded: url_helper
INFO - 2022-03-14 04:20:58 --> Helper loaded: form_helper
INFO - 2022-03-14 04:20:58 --> Helper loaded: common_helper
INFO - 2022-03-14 04:20:58 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:20:58 --> Controller Class Initialized
INFO - 2022-03-14 04:20:58 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:20:58 --> Encrypt Class Initialized
INFO - 2022-03-14 04:20:58 --> Model "Login_model" initialized
INFO - 2022-03-14 04:20:58 --> Model "Dashboard_model" initialized
INFO - 2022-03-14 04:20:58 --> Model "Case_model" initialized
INFO - 2022-03-14 04:21:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 04:21:21 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-14 04:21:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 04:21:21 --> Final output sent to browser
DEBUG - 2022-03-14 04:21:21 --> Total execution time: 22.9175
ERROR - 2022-03-14 04:36:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:36:34 --> Config Class Initialized
INFO - 2022-03-14 04:36:34 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:36:34 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:36:34 --> Utf8 Class Initialized
INFO - 2022-03-14 04:36:34 --> URI Class Initialized
INFO - 2022-03-14 04:36:34 --> Router Class Initialized
INFO - 2022-03-14 04:36:34 --> Output Class Initialized
INFO - 2022-03-14 04:36:34 --> Security Class Initialized
DEBUG - 2022-03-14 04:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:36:34 --> Input Class Initialized
INFO - 2022-03-14 04:36:34 --> Language Class Initialized
INFO - 2022-03-14 04:36:34 --> Loader Class Initialized
INFO - 2022-03-14 04:36:34 --> Helper loaded: url_helper
INFO - 2022-03-14 04:36:34 --> Helper loaded: form_helper
INFO - 2022-03-14 04:36:34 --> Helper loaded: common_helper
INFO - 2022-03-14 04:36:34 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:36:34 --> Controller Class Initialized
INFO - 2022-03-14 04:36:34 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:36:34 --> Encrypt Class Initialized
INFO - 2022-03-14 04:36:34 --> Model "Patient_model" initialized
INFO - 2022-03-14 04:36:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 04:36:34 --> Model "Referredby_model" initialized
INFO - 2022-03-14 04:36:34 --> Model "Prefix_master" initialized
INFO - 2022-03-14 04:36:34 --> Model "Hospital_model" initialized
INFO - 2022-03-14 04:36:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 04:36:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 04:36:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 04:36:43 --> Final output sent to browser
DEBUG - 2022-03-14 04:36:43 --> Total execution time: 6.8642
ERROR - 2022-03-14 04:37:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:37:32 --> Config Class Initialized
INFO - 2022-03-14 04:37:32 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:37:32 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:37:32 --> Utf8 Class Initialized
INFO - 2022-03-14 04:37:32 --> URI Class Initialized
INFO - 2022-03-14 04:37:32 --> Router Class Initialized
INFO - 2022-03-14 04:37:32 --> Output Class Initialized
INFO - 2022-03-14 04:37:32 --> Security Class Initialized
DEBUG - 2022-03-14 04:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:37:32 --> Input Class Initialized
INFO - 2022-03-14 04:37:32 --> Language Class Initialized
INFO - 2022-03-14 04:37:32 --> Loader Class Initialized
INFO - 2022-03-14 04:37:32 --> Helper loaded: url_helper
INFO - 2022-03-14 04:37:32 --> Helper loaded: form_helper
INFO - 2022-03-14 04:37:32 --> Helper loaded: common_helper
INFO - 2022-03-14 04:37:32 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:37:32 --> Controller Class Initialized
INFO - 2022-03-14 04:37:32 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:37:32 --> Encrypt Class Initialized
INFO - 2022-03-14 04:37:32 --> Model "Patient_model" initialized
INFO - 2022-03-14 04:37:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 04:37:32 --> Model "Referredby_model" initialized
INFO - 2022-03-14 04:37:32 --> Model "Prefix_master" initialized
INFO - 2022-03-14 04:37:32 --> Model "Hospital_model" initialized
INFO - 2022-03-14 04:37:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 04:37:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 04:37:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 04:37:32 --> Final output sent to browser
DEBUG - 2022-03-14 04:37:32 --> Total execution time: 0.0948
ERROR - 2022-03-14 04:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:38:31 --> Config Class Initialized
INFO - 2022-03-14 04:38:31 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:38:31 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:38:31 --> Utf8 Class Initialized
INFO - 2022-03-14 04:38:31 --> URI Class Initialized
INFO - 2022-03-14 04:38:31 --> Router Class Initialized
INFO - 2022-03-14 04:38:31 --> Output Class Initialized
INFO - 2022-03-14 04:38:31 --> Security Class Initialized
DEBUG - 2022-03-14 04:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:38:31 --> Input Class Initialized
INFO - 2022-03-14 04:38:31 --> Language Class Initialized
INFO - 2022-03-14 04:38:31 --> Loader Class Initialized
INFO - 2022-03-14 04:38:31 --> Helper loaded: url_helper
INFO - 2022-03-14 04:38:31 --> Helper loaded: form_helper
INFO - 2022-03-14 04:38:31 --> Helper loaded: common_helper
INFO - 2022-03-14 04:38:31 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:38:31 --> Controller Class Initialized
INFO - 2022-03-14 04:38:31 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:38:31 --> Encrypt Class Initialized
INFO - 2022-03-14 04:38:31 --> Model "Patient_model" initialized
INFO - 2022-03-14 04:38:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 04:38:31 --> Model "Referredby_model" initialized
INFO - 2022-03-14 04:38:31 --> Model "Prefix_master" initialized
INFO - 2022-03-14 04:38:31 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 04:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:38:32 --> Config Class Initialized
INFO - 2022-03-14 04:38:32 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:38:32 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:38:32 --> Utf8 Class Initialized
INFO - 2022-03-14 04:38:32 --> URI Class Initialized
INFO - 2022-03-14 04:38:32 --> Router Class Initialized
INFO - 2022-03-14 04:38:32 --> Output Class Initialized
INFO - 2022-03-14 04:38:32 --> Security Class Initialized
DEBUG - 2022-03-14 04:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:38:32 --> Input Class Initialized
INFO - 2022-03-14 04:38:32 --> Language Class Initialized
INFO - 2022-03-14 04:38:32 --> Loader Class Initialized
INFO - 2022-03-14 04:38:32 --> Helper loaded: url_helper
INFO - 2022-03-14 04:38:32 --> Helper loaded: form_helper
INFO - 2022-03-14 04:38:32 --> Helper loaded: common_helper
INFO - 2022-03-14 04:38:32 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:38:32 --> Controller Class Initialized
INFO - 2022-03-14 04:38:32 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:38:32 --> Encrypt Class Initialized
INFO - 2022-03-14 04:38:32 --> Model "Patient_model" initialized
INFO - 2022-03-14 04:38:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 04:38:32 --> Model "Referredby_model" initialized
INFO - 2022-03-14 04:38:32 --> Model "Prefix_master" initialized
INFO - 2022-03-14 04:38:32 --> Model "Hospital_model" initialized
INFO - 2022-03-14 04:38:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 04:38:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-14 04:38:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 04:38:32 --> Final output sent to browser
DEBUG - 2022-03-14 04:38:32 --> Total execution time: 0.0521
ERROR - 2022-03-14 04:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:38:33 --> Config Class Initialized
INFO - 2022-03-14 04:38:33 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:38:33 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:38:33 --> Utf8 Class Initialized
INFO - 2022-03-14 04:38:33 --> URI Class Initialized
INFO - 2022-03-14 04:38:33 --> Router Class Initialized
INFO - 2022-03-14 04:38:33 --> Output Class Initialized
INFO - 2022-03-14 04:38:33 --> Security Class Initialized
DEBUG - 2022-03-14 04:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:38:33 --> Input Class Initialized
INFO - 2022-03-14 04:38:33 --> Language Class Initialized
INFO - 2022-03-14 04:38:33 --> Loader Class Initialized
INFO - 2022-03-14 04:38:33 --> Helper loaded: url_helper
INFO - 2022-03-14 04:38:33 --> Helper loaded: form_helper
INFO - 2022-03-14 04:38:33 --> Helper loaded: common_helper
INFO - 2022-03-14 04:38:33 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:38:33 --> Controller Class Initialized
INFO - 2022-03-14 04:38:33 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:38:33 --> Encrypt Class Initialized
INFO - 2022-03-14 04:38:33 --> Model "Patient_model" initialized
INFO - 2022-03-14 04:38:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 04:38:33 --> Model "Prefix_master" initialized
INFO - 2022-03-14 04:38:33 --> Model "Users_model" initialized
INFO - 2022-03-14 04:38:33 --> Model "Hospital_model" initialized
INFO - 2022-03-14 04:38:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 04:38:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 04:38:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 04:38:33 --> Final output sent to browser
DEBUG - 2022-03-14 04:38:33 --> Total execution time: 0.1146
ERROR - 2022-03-14 04:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:40:00 --> Config Class Initialized
INFO - 2022-03-14 04:40:00 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:40:00 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:40:00 --> Utf8 Class Initialized
INFO - 2022-03-14 04:40:00 --> URI Class Initialized
INFO - 2022-03-14 04:40:00 --> Router Class Initialized
INFO - 2022-03-14 04:40:00 --> Output Class Initialized
INFO - 2022-03-14 04:40:00 --> Security Class Initialized
DEBUG - 2022-03-14 04:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:40:00 --> Input Class Initialized
INFO - 2022-03-14 04:40:00 --> Language Class Initialized
INFO - 2022-03-14 04:40:00 --> Loader Class Initialized
INFO - 2022-03-14 04:40:00 --> Helper loaded: url_helper
INFO - 2022-03-14 04:40:00 --> Helper loaded: form_helper
INFO - 2022-03-14 04:40:00 --> Helper loaded: common_helper
INFO - 2022-03-14 04:40:00 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:40:00 --> Controller Class Initialized
INFO - 2022-03-14 04:40:00 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:40:00 --> Encrypt Class Initialized
INFO - 2022-03-14 04:40:00 --> Model "Patient_model" initialized
INFO - 2022-03-14 04:40:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 04:40:00 --> Model "Prefix_master" initialized
INFO - 2022-03-14 04:40:00 --> Model "Users_model" initialized
INFO - 2022-03-14 04:40:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 04:40:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 04:40:01 --> Config Class Initialized
INFO - 2022-03-14 04:40:01 --> Hooks Class Initialized
DEBUG - 2022-03-14 04:40:01 --> UTF-8 Support Enabled
INFO - 2022-03-14 04:40:01 --> Utf8 Class Initialized
INFO - 2022-03-14 04:40:01 --> URI Class Initialized
INFO - 2022-03-14 04:40:01 --> Router Class Initialized
INFO - 2022-03-14 04:40:01 --> Output Class Initialized
INFO - 2022-03-14 04:40:01 --> Security Class Initialized
DEBUG - 2022-03-14 04:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 04:40:01 --> Input Class Initialized
INFO - 2022-03-14 04:40:01 --> Language Class Initialized
INFO - 2022-03-14 04:40:01 --> Loader Class Initialized
INFO - 2022-03-14 04:40:01 --> Helper loaded: url_helper
INFO - 2022-03-14 04:40:01 --> Helper loaded: form_helper
INFO - 2022-03-14 04:40:01 --> Helper loaded: common_helper
INFO - 2022-03-14 04:40:01 --> Database Driver Class Initialized
DEBUG - 2022-03-14 04:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 04:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 04:40:01 --> Controller Class Initialized
INFO - 2022-03-14 04:40:01 --> Form Validation Class Initialized
DEBUG - 2022-03-14 04:40:01 --> Encrypt Class Initialized
INFO - 2022-03-14 04:40:01 --> Model "Patient_model" initialized
INFO - 2022-03-14 04:40:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 04:40:01 --> Model "Prefix_master" initialized
INFO - 2022-03-14 04:40:01 --> Model "Users_model" initialized
INFO - 2022-03-14 04:40:01 --> Model "Hospital_model" initialized
INFO - 2022-03-14 04:40:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 04:40:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 04:40:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 04:40:01 --> Final output sent to browser
DEBUG - 2022-03-14 04:40:01 --> Total execution time: 0.0845
ERROR - 2022-03-14 05:00:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 05:00:56 --> Config Class Initialized
INFO - 2022-03-14 05:00:56 --> Hooks Class Initialized
DEBUG - 2022-03-14 05:00:56 --> UTF-8 Support Enabled
INFO - 2022-03-14 05:00:56 --> Utf8 Class Initialized
INFO - 2022-03-14 05:00:56 --> URI Class Initialized
INFO - 2022-03-14 05:00:56 --> Router Class Initialized
INFO - 2022-03-14 05:00:56 --> Output Class Initialized
INFO - 2022-03-14 05:00:56 --> Security Class Initialized
DEBUG - 2022-03-14 05:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 05:00:56 --> Input Class Initialized
INFO - 2022-03-14 05:00:56 --> Language Class Initialized
INFO - 2022-03-14 05:00:56 --> Loader Class Initialized
INFO - 2022-03-14 05:00:56 --> Helper loaded: url_helper
INFO - 2022-03-14 05:00:56 --> Helper loaded: form_helper
INFO - 2022-03-14 05:00:56 --> Helper loaded: common_helper
INFO - 2022-03-14 05:00:56 --> Database Driver Class Initialized
DEBUG - 2022-03-14 05:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 05:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 05:00:56 --> Controller Class Initialized
INFO - 2022-03-14 05:00:56 --> Form Validation Class Initialized
DEBUG - 2022-03-14 05:00:56 --> Encrypt Class Initialized
INFO - 2022-03-14 05:00:56 --> Model "Patient_model" initialized
INFO - 2022-03-14 05:00:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 05:00:56 --> Model "Prefix_master" initialized
INFO - 2022-03-14 05:00:56 --> Model "Users_model" initialized
INFO - 2022-03-14 05:00:56 --> Model "Hospital_model" initialized
INFO - 2022-03-14 05:00:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 05:00:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 05:00:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 05:00:56 --> Final output sent to browser
DEBUG - 2022-03-14 05:00:56 --> Total execution time: 0.1546
ERROR - 2022-03-14 05:04:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 05:04:09 --> Config Class Initialized
INFO - 2022-03-14 05:04:09 --> Hooks Class Initialized
DEBUG - 2022-03-14 05:04:09 --> UTF-8 Support Enabled
INFO - 2022-03-14 05:04:09 --> Utf8 Class Initialized
INFO - 2022-03-14 05:04:09 --> URI Class Initialized
INFO - 2022-03-14 05:04:09 --> Router Class Initialized
INFO - 2022-03-14 05:04:09 --> Output Class Initialized
INFO - 2022-03-14 05:04:09 --> Security Class Initialized
DEBUG - 2022-03-14 05:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 05:04:09 --> Input Class Initialized
INFO - 2022-03-14 05:04:09 --> Language Class Initialized
INFO - 2022-03-14 05:04:09 --> Loader Class Initialized
INFO - 2022-03-14 05:04:09 --> Helper loaded: url_helper
INFO - 2022-03-14 05:04:09 --> Helper loaded: form_helper
INFO - 2022-03-14 05:04:09 --> Helper loaded: common_helper
INFO - 2022-03-14 05:04:09 --> Database Driver Class Initialized
DEBUG - 2022-03-14 05:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 05:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 05:04:09 --> Controller Class Initialized
INFO - 2022-03-14 05:04:09 --> Form Validation Class Initialized
DEBUG - 2022-03-14 05:04:09 --> Encrypt Class Initialized
INFO - 2022-03-14 05:04:09 --> Model "Patient_model" initialized
INFO - 2022-03-14 05:04:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 05:04:09 --> Model "Prefix_master" initialized
INFO - 2022-03-14 05:04:09 --> Model "Users_model" initialized
INFO - 2022-03-14 05:04:09 --> Model "Hospital_model" initialized
INFO - 2022-03-14 05:04:09 --> Upload Class Initialized
INFO - 2022-03-14 05:04:09 --> Final output sent to browser
DEBUG - 2022-03-14 05:04:09 --> Total execution time: 0.0602
ERROR - 2022-03-14 05:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 05:04:12 --> Config Class Initialized
INFO - 2022-03-14 05:04:12 --> Hooks Class Initialized
DEBUG - 2022-03-14 05:04:12 --> UTF-8 Support Enabled
INFO - 2022-03-14 05:04:12 --> Utf8 Class Initialized
INFO - 2022-03-14 05:04:12 --> URI Class Initialized
INFO - 2022-03-14 05:04:12 --> Router Class Initialized
INFO - 2022-03-14 05:04:12 --> Output Class Initialized
INFO - 2022-03-14 05:04:12 --> Security Class Initialized
DEBUG - 2022-03-14 05:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 05:04:12 --> Input Class Initialized
INFO - 2022-03-14 05:04:12 --> Language Class Initialized
INFO - 2022-03-14 05:04:12 --> Loader Class Initialized
INFO - 2022-03-14 05:04:12 --> Helper loaded: url_helper
INFO - 2022-03-14 05:04:12 --> Helper loaded: form_helper
INFO - 2022-03-14 05:04:12 --> Helper loaded: common_helper
INFO - 2022-03-14 05:04:12 --> Database Driver Class Initialized
DEBUG - 2022-03-14 05:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 05:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 05:04:12 --> Controller Class Initialized
INFO - 2022-03-14 05:04:12 --> Form Validation Class Initialized
DEBUG - 2022-03-14 05:04:12 --> Encrypt Class Initialized
INFO - 2022-03-14 05:04:12 --> Model "Patient_model" initialized
INFO - 2022-03-14 05:04:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 05:04:12 --> Model "Prefix_master" initialized
INFO - 2022-03-14 05:04:12 --> Model "Users_model" initialized
INFO - 2022-03-14 05:04:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 05:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 05:04:12 --> Config Class Initialized
INFO - 2022-03-14 05:04:12 --> Hooks Class Initialized
DEBUG - 2022-03-14 05:04:12 --> UTF-8 Support Enabled
INFO - 2022-03-14 05:04:12 --> Utf8 Class Initialized
INFO - 2022-03-14 05:04:12 --> URI Class Initialized
INFO - 2022-03-14 05:04:12 --> Router Class Initialized
INFO - 2022-03-14 05:04:12 --> Output Class Initialized
INFO - 2022-03-14 05:04:12 --> Security Class Initialized
DEBUG - 2022-03-14 05:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 05:04:12 --> Input Class Initialized
INFO - 2022-03-14 05:04:12 --> Language Class Initialized
INFO - 2022-03-14 05:04:12 --> Loader Class Initialized
INFO - 2022-03-14 05:04:12 --> Helper loaded: url_helper
INFO - 2022-03-14 05:04:12 --> Helper loaded: form_helper
INFO - 2022-03-14 05:04:12 --> Helper loaded: common_helper
INFO - 2022-03-14 05:04:12 --> Database Driver Class Initialized
DEBUG - 2022-03-14 05:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 05:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 05:04:12 --> Controller Class Initialized
INFO - 2022-03-14 05:04:12 --> Form Validation Class Initialized
DEBUG - 2022-03-14 05:04:12 --> Encrypt Class Initialized
INFO - 2022-03-14 05:04:12 --> Model "Patient_model" initialized
INFO - 2022-03-14 05:04:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 05:04:12 --> Model "Prefix_master" initialized
INFO - 2022-03-14 05:04:12 --> Model "Users_model" initialized
INFO - 2022-03-14 05:04:12 --> Model "Hospital_model" initialized
INFO - 2022-03-14 05:04:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 05:04:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 05:04:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 05:04:13 --> Final output sent to browser
DEBUG - 2022-03-14 05:04:13 --> Total execution time: 0.0745
ERROR - 2022-03-14 05:05:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 05:05:11 --> Config Class Initialized
INFO - 2022-03-14 05:05:11 --> Hooks Class Initialized
DEBUG - 2022-03-14 05:05:11 --> UTF-8 Support Enabled
INFO - 2022-03-14 05:05:11 --> Utf8 Class Initialized
INFO - 2022-03-14 05:05:11 --> URI Class Initialized
INFO - 2022-03-14 05:05:11 --> Router Class Initialized
INFO - 2022-03-14 05:05:11 --> Output Class Initialized
INFO - 2022-03-14 05:05:11 --> Security Class Initialized
DEBUG - 2022-03-14 05:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 05:05:11 --> Input Class Initialized
INFO - 2022-03-14 05:05:11 --> Language Class Initialized
INFO - 2022-03-14 05:05:11 --> Loader Class Initialized
INFO - 2022-03-14 05:05:11 --> Helper loaded: url_helper
INFO - 2022-03-14 05:05:11 --> Helper loaded: form_helper
INFO - 2022-03-14 05:05:11 --> Helper loaded: common_helper
INFO - 2022-03-14 05:05:11 --> Database Driver Class Initialized
DEBUG - 2022-03-14 05:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 05:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 05:05:11 --> Controller Class Initialized
INFO - 2022-03-14 05:05:11 --> Form Validation Class Initialized
DEBUG - 2022-03-14 05:05:11 --> Encrypt Class Initialized
INFO - 2022-03-14 05:05:11 --> Model "Patient_model" initialized
INFO - 2022-03-14 05:05:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 05:05:11 --> Model "Prefix_master" initialized
INFO - 2022-03-14 05:05:11 --> Model "Users_model" initialized
INFO - 2022-03-14 05:05:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-14 05:05:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 05:05:12 --> Config Class Initialized
INFO - 2022-03-14 05:05:12 --> Hooks Class Initialized
DEBUG - 2022-03-14 05:05:12 --> UTF-8 Support Enabled
INFO - 2022-03-14 05:05:12 --> Utf8 Class Initialized
INFO - 2022-03-14 05:05:12 --> URI Class Initialized
INFO - 2022-03-14 05:05:12 --> Router Class Initialized
INFO - 2022-03-14 05:05:12 --> Output Class Initialized
INFO - 2022-03-14 05:05:12 --> Security Class Initialized
DEBUG - 2022-03-14 05:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 05:05:12 --> Input Class Initialized
INFO - 2022-03-14 05:05:12 --> Language Class Initialized
INFO - 2022-03-14 05:05:12 --> Loader Class Initialized
INFO - 2022-03-14 05:05:12 --> Helper loaded: url_helper
INFO - 2022-03-14 05:05:12 --> Helper loaded: form_helper
INFO - 2022-03-14 05:05:12 --> Helper loaded: common_helper
INFO - 2022-03-14 05:05:12 --> Database Driver Class Initialized
DEBUG - 2022-03-14 05:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 05:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 05:05:12 --> Controller Class Initialized
INFO - 2022-03-14 05:05:12 --> Form Validation Class Initialized
DEBUG - 2022-03-14 05:05:12 --> Encrypt Class Initialized
INFO - 2022-03-14 05:05:12 --> Model "Patient_model" initialized
INFO - 2022-03-14 05:05:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 05:05:12 --> Model "Prefix_master" initialized
INFO - 2022-03-14 05:05:12 --> Model "Users_model" initialized
INFO - 2022-03-14 05:05:12 --> Model "Hospital_model" initialized
INFO - 2022-03-14 05:05:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 05:05:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 05:05:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 05:05:12 --> Final output sent to browser
DEBUG - 2022-03-14 05:05:12 --> Total execution time: 0.0862
ERROR - 2022-03-14 05:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 05:53:44 --> Config Class Initialized
INFO - 2022-03-14 05:53:44 --> Hooks Class Initialized
DEBUG - 2022-03-14 05:53:44 --> UTF-8 Support Enabled
INFO - 2022-03-14 05:53:44 --> Utf8 Class Initialized
INFO - 2022-03-14 05:53:44 --> URI Class Initialized
INFO - 2022-03-14 05:53:44 --> Router Class Initialized
INFO - 2022-03-14 05:53:44 --> Output Class Initialized
INFO - 2022-03-14 05:53:44 --> Security Class Initialized
DEBUG - 2022-03-14 05:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 05:53:44 --> Input Class Initialized
INFO - 2022-03-14 05:53:44 --> Language Class Initialized
INFO - 2022-03-14 05:53:44 --> Loader Class Initialized
INFO - 2022-03-14 05:53:44 --> Helper loaded: url_helper
INFO - 2022-03-14 05:53:44 --> Helper loaded: form_helper
INFO - 2022-03-14 05:53:44 --> Helper loaded: common_helper
INFO - 2022-03-14 05:53:44 --> Database Driver Class Initialized
DEBUG - 2022-03-14 05:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 05:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 05:53:44 --> Controller Class Initialized
INFO - 2022-03-14 05:53:44 --> Form Validation Class Initialized
DEBUG - 2022-03-14 05:53:44 --> Encrypt Class Initialized
INFO - 2022-03-14 05:53:44 --> Model "Patient_model" initialized
INFO - 2022-03-14 05:53:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 05:53:44 --> Model "Prefix_master" initialized
INFO - 2022-03-14 05:53:44 --> Model "Users_model" initialized
INFO - 2022-03-14 05:53:44 --> Model "Hospital_model" initialized
INFO - 2022-03-14 05:53:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 05:53:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-14 05:53:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 05:53:44 --> Final output sent to browser
DEBUG - 2022-03-14 05:53:44 --> Total execution time: 0.5503
ERROR - 2022-03-14 05:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 05:53:52 --> Config Class Initialized
INFO - 2022-03-14 05:53:52 --> Hooks Class Initialized
DEBUG - 2022-03-14 05:53:52 --> UTF-8 Support Enabled
INFO - 2022-03-14 05:53:52 --> Utf8 Class Initialized
INFO - 2022-03-14 05:53:52 --> URI Class Initialized
INFO - 2022-03-14 05:53:52 --> Router Class Initialized
INFO - 2022-03-14 05:53:52 --> Output Class Initialized
INFO - 2022-03-14 05:53:52 --> Security Class Initialized
DEBUG - 2022-03-14 05:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 05:53:52 --> Input Class Initialized
INFO - 2022-03-14 05:53:52 --> Language Class Initialized
INFO - 2022-03-14 05:53:52 --> Loader Class Initialized
INFO - 2022-03-14 05:53:52 --> Helper loaded: url_helper
INFO - 2022-03-14 05:53:52 --> Helper loaded: form_helper
INFO - 2022-03-14 05:53:52 --> Helper loaded: common_helper
INFO - 2022-03-14 05:53:52 --> Database Driver Class Initialized
DEBUG - 2022-03-14 05:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 05:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 05:53:52 --> Controller Class Initialized
INFO - 2022-03-14 05:53:52 --> Form Validation Class Initialized
DEBUG - 2022-03-14 05:53:52 --> Encrypt Class Initialized
INFO - 2022-03-14 05:53:52 --> Model "Patient_model" initialized
INFO - 2022-03-14 05:53:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 05:53:52 --> Model "Referredby_model" initialized
INFO - 2022-03-14 05:53:52 --> Model "Prefix_master" initialized
INFO - 2022-03-14 05:53:52 --> Model "Hospital_model" initialized
INFO - 2022-03-14 05:53:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-14 05:53:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-14 05:53:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-14 05:54:01 --> Final output sent to browser
DEBUG - 2022-03-14 05:54:01 --> Total execution time: 7.3557
ERROR - 2022-03-14 05:55:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 05:55:02 --> Config Class Initialized
INFO - 2022-03-14 05:55:02 --> Hooks Class Initialized
DEBUG - 2022-03-14 05:55:02 --> UTF-8 Support Enabled
INFO - 2022-03-14 05:55:02 --> Utf8 Class Initialized
INFO - 2022-03-14 05:55:02 --> URI Class Initialized
INFO - 2022-03-14 05:55:02 --> Router Class Initialized
INFO - 2022-03-14 05:55:02 --> Output Class Initialized
INFO - 2022-03-14 05:55:02 --> Security Class Initialized
DEBUG - 2022-03-14 05:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 05:55:02 --> Input Class Initialized
INFO - 2022-03-14 05:55:02 --> Language Class Initialized
INFO - 2022-03-14 05:55:02 --> Loader Class Initialized
INFO - 2022-03-14 05:55:02 --> Helper loaded: url_helper
INFO - 2022-03-14 05:55:02 --> Helper loaded: form_helper
INFO - 2022-03-14 05:55:02 --> Helper loaded: common_helper
INFO - 2022-03-14 05:55:02 --> Database Driver Class Initialized
DEBUG - 2022-03-14 05:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 05:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 05:55:02 --> Controller Class Initialized
INFO - 2022-03-14 05:55:02 --> Form Validation Class Initialized
DEBUG - 2022-03-14 05:55:02 --> Encrypt Class Initialized
INFO - 2022-03-14 05:55:02 --> Model "Patient_model" initialized
INFO - 2022-03-14 05:55:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-14 05:55:02 --> Model "Prefix_master" initialized
INFO - 2022-03-14 05:55:02 --> Model "Users_model" initialized
INFO - 2022-03-14 05:55:02 --> Model "Hospital_model" initialized
INFO - 2022-03-14 05:55:02 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-14 05:55:04 --> Final output sent to browser
DEBUG - 2022-03-14 05:55:04 --> Total execution time: 2.0597
ERROR - 2022-03-14 06:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 06:40:45 --> Config Class Initialized
INFO - 2022-03-14 06:40:45 --> Hooks Class Initialized
DEBUG - 2022-03-14 06:40:45 --> UTF-8 Support Enabled
INFO - 2022-03-14 06:40:45 --> Utf8 Class Initialized
INFO - 2022-03-14 06:40:45 --> URI Class Initialized
INFO - 2022-03-14 06:40:45 --> Router Class Initialized
INFO - 2022-03-14 06:40:45 --> Output Class Initialized
INFO - 2022-03-14 06:40:45 --> Security Class Initialized
DEBUG - 2022-03-14 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 06:40:45 --> Input Class Initialized
INFO - 2022-03-14 06:40:45 --> Language Class Initialized
INFO - 2022-03-14 06:40:45 --> Loader Class Initialized
INFO - 2022-03-14 06:40:45 --> Helper loaded: url_helper
INFO - 2022-03-14 06:40:45 --> Helper loaded: form_helper
INFO - 2022-03-14 06:40:45 --> Helper loaded: common_helper
INFO - 2022-03-14 06:40:45 --> Database Driver Class Initialized
DEBUG - 2022-03-14 06:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 06:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 06:40:45 --> Controller Class Initialized
INFO - 2022-03-14 06:40:45 --> Form Validation Class Initialized
DEBUG - 2022-03-14 06:40:45 --> Encrypt Class Initialized
DEBUG - 2022-03-14 06:40:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 06:40:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 06:40:45 --> Email Class Initialized
INFO - 2022-03-14 06:40:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 06:40:45 --> Calendar Class Initialized
INFO - 2022-03-14 06:40:45 --> Model "Login_model" initialized
ERROR - 2022-03-14 06:40:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 06:40:46 --> Config Class Initialized
INFO - 2022-03-14 06:40:46 --> Hooks Class Initialized
DEBUG - 2022-03-14 06:40:46 --> UTF-8 Support Enabled
INFO - 2022-03-14 06:40:46 --> Utf8 Class Initialized
INFO - 2022-03-14 06:40:46 --> URI Class Initialized
INFO - 2022-03-14 06:40:46 --> Router Class Initialized
INFO - 2022-03-14 06:40:46 --> Output Class Initialized
INFO - 2022-03-14 06:40:46 --> Security Class Initialized
DEBUG - 2022-03-14 06:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 06:40:46 --> Input Class Initialized
INFO - 2022-03-14 06:40:46 --> Language Class Initialized
INFO - 2022-03-14 06:40:46 --> Loader Class Initialized
INFO - 2022-03-14 06:40:46 --> Helper loaded: url_helper
INFO - 2022-03-14 06:40:46 --> Helper loaded: form_helper
INFO - 2022-03-14 06:40:46 --> Helper loaded: common_helper
INFO - 2022-03-14 06:40:46 --> Database Driver Class Initialized
DEBUG - 2022-03-14 06:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 06:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 06:40:46 --> Controller Class Initialized
INFO - 2022-03-14 06:40:46 --> Form Validation Class Initialized
DEBUG - 2022-03-14 06:40:46 --> Encrypt Class Initialized
DEBUG - 2022-03-14 06:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 06:40:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 06:40:46 --> Email Class Initialized
INFO - 2022-03-14 06:40:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 06:40:46 --> Calendar Class Initialized
INFO - 2022-03-14 06:40:46 --> Model "Login_model" initialized
INFO - 2022-03-14 06:40:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 06:40:46 --> Final output sent to browser
DEBUG - 2022-03-14 06:40:46 --> Total execution time: 0.0227
ERROR - 2022-03-14 06:40:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 06:40:46 --> Config Class Initialized
INFO - 2022-03-14 06:40:46 --> Hooks Class Initialized
DEBUG - 2022-03-14 06:40:46 --> UTF-8 Support Enabled
INFO - 2022-03-14 06:40:46 --> Utf8 Class Initialized
INFO - 2022-03-14 06:40:46 --> URI Class Initialized
INFO - 2022-03-14 06:40:46 --> Router Class Initialized
INFO - 2022-03-14 06:40:46 --> Output Class Initialized
INFO - 2022-03-14 06:40:46 --> Security Class Initialized
DEBUG - 2022-03-14 06:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 06:40:46 --> Input Class Initialized
INFO - 2022-03-14 06:40:46 --> Language Class Initialized
INFO - 2022-03-14 06:40:46 --> Loader Class Initialized
INFO - 2022-03-14 06:40:46 --> Helper loaded: url_helper
INFO - 2022-03-14 06:40:46 --> Helper loaded: form_helper
INFO - 2022-03-14 06:40:46 --> Helper loaded: common_helper
INFO - 2022-03-14 06:40:46 --> Database Driver Class Initialized
DEBUG - 2022-03-14 06:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 06:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 06:40:46 --> Controller Class Initialized
INFO - 2022-03-14 06:40:46 --> Form Validation Class Initialized
DEBUG - 2022-03-14 06:40:46 --> Encrypt Class Initialized
DEBUG - 2022-03-14 06:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 06:40:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 06:40:46 --> Email Class Initialized
INFO - 2022-03-14 06:40:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 06:40:46 --> Calendar Class Initialized
INFO - 2022-03-14 06:40:46 --> Model "Login_model" initialized
ERROR - 2022-03-14 06:40:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 06:40:47 --> Config Class Initialized
INFO - 2022-03-14 06:40:47 --> Hooks Class Initialized
DEBUG - 2022-03-14 06:40:47 --> UTF-8 Support Enabled
INFO - 2022-03-14 06:40:47 --> Utf8 Class Initialized
INFO - 2022-03-14 06:40:47 --> URI Class Initialized
INFO - 2022-03-14 06:40:47 --> Router Class Initialized
INFO - 2022-03-14 06:40:47 --> Output Class Initialized
INFO - 2022-03-14 06:40:47 --> Security Class Initialized
DEBUG - 2022-03-14 06:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 06:40:47 --> Input Class Initialized
INFO - 2022-03-14 06:40:47 --> Language Class Initialized
INFO - 2022-03-14 06:40:47 --> Loader Class Initialized
INFO - 2022-03-14 06:40:47 --> Helper loaded: url_helper
INFO - 2022-03-14 06:40:47 --> Helper loaded: form_helper
INFO - 2022-03-14 06:40:47 --> Helper loaded: common_helper
INFO - 2022-03-14 06:40:47 --> Database Driver Class Initialized
DEBUG - 2022-03-14 06:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 06:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 06:40:47 --> Controller Class Initialized
INFO - 2022-03-14 06:40:47 --> Form Validation Class Initialized
DEBUG - 2022-03-14 06:40:47 --> Encrypt Class Initialized
DEBUG - 2022-03-14 06:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 06:40:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 06:40:47 --> Email Class Initialized
INFO - 2022-03-14 06:40:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 06:40:47 --> Calendar Class Initialized
INFO - 2022-03-14 06:40:47 --> Model "Login_model" initialized
INFO - 2022-03-14 06:40:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 06:40:47 --> Final output sent to browser
DEBUG - 2022-03-14 06:40:47 --> Total execution time: 0.0221
ERROR - 2022-03-14 07:00:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 07:00:36 --> Config Class Initialized
INFO - 2022-03-14 07:00:36 --> Hooks Class Initialized
DEBUG - 2022-03-14 07:00:36 --> UTF-8 Support Enabled
INFO - 2022-03-14 07:00:36 --> Utf8 Class Initialized
INFO - 2022-03-14 07:00:36 --> URI Class Initialized
DEBUG - 2022-03-14 07:00:36 --> No URI present. Default controller set.
INFO - 2022-03-14 07:00:36 --> Router Class Initialized
INFO - 2022-03-14 07:00:36 --> Output Class Initialized
INFO - 2022-03-14 07:00:36 --> Security Class Initialized
DEBUG - 2022-03-14 07:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 07:00:36 --> Input Class Initialized
INFO - 2022-03-14 07:00:36 --> Language Class Initialized
INFO - 2022-03-14 07:00:36 --> Loader Class Initialized
INFO - 2022-03-14 07:00:36 --> Helper loaded: url_helper
INFO - 2022-03-14 07:00:36 --> Helper loaded: form_helper
INFO - 2022-03-14 07:00:36 --> Helper loaded: common_helper
INFO - 2022-03-14 07:00:36 --> Database Driver Class Initialized
DEBUG - 2022-03-14 07:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 07:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 07:00:36 --> Controller Class Initialized
INFO - 2022-03-14 07:00:36 --> Form Validation Class Initialized
DEBUG - 2022-03-14 07:00:36 --> Encrypt Class Initialized
DEBUG - 2022-03-14 07:00:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 07:00:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 07:00:36 --> Email Class Initialized
INFO - 2022-03-14 07:00:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 07:00:36 --> Calendar Class Initialized
INFO - 2022-03-14 07:00:36 --> Model "Login_model" initialized
INFO - 2022-03-14 07:00:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 07:00:36 --> Final output sent to browser
DEBUG - 2022-03-14 07:00:36 --> Total execution time: 0.0391
ERROR - 2022-03-14 07:00:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 07:00:37 --> Config Class Initialized
INFO - 2022-03-14 07:00:37 --> Hooks Class Initialized
DEBUG - 2022-03-14 07:00:37 --> UTF-8 Support Enabled
INFO - 2022-03-14 07:00:37 --> Utf8 Class Initialized
INFO - 2022-03-14 07:00:37 --> URI Class Initialized
INFO - 2022-03-14 07:00:37 --> Router Class Initialized
INFO - 2022-03-14 07:00:37 --> Output Class Initialized
INFO - 2022-03-14 07:00:37 --> Security Class Initialized
DEBUG - 2022-03-14 07:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 07:00:37 --> Input Class Initialized
INFO - 2022-03-14 07:00:37 --> Language Class Initialized
ERROR - 2022-03-14 07:00:37 --> 404 Page Not Found: Register/index
ERROR - 2022-03-14 07:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 07:00:38 --> Config Class Initialized
INFO - 2022-03-14 07:00:38 --> Hooks Class Initialized
DEBUG - 2022-03-14 07:00:38 --> UTF-8 Support Enabled
INFO - 2022-03-14 07:00:38 --> Utf8 Class Initialized
INFO - 2022-03-14 07:00:38 --> URI Class Initialized
INFO - 2022-03-14 07:00:38 --> Router Class Initialized
INFO - 2022-03-14 07:00:38 --> Output Class Initialized
INFO - 2022-03-14 07:00:38 --> Security Class Initialized
DEBUG - 2022-03-14 07:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 07:00:38 --> Input Class Initialized
INFO - 2022-03-14 07:00:38 --> Language Class Initialized
INFO - 2022-03-14 07:00:38 --> Loader Class Initialized
INFO - 2022-03-14 07:00:38 --> Helper loaded: url_helper
INFO - 2022-03-14 07:00:38 --> Helper loaded: form_helper
INFO - 2022-03-14 07:00:38 --> Helper loaded: common_helper
INFO - 2022-03-14 07:00:38 --> Database Driver Class Initialized
DEBUG - 2022-03-14 07:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 07:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 07:00:38 --> Controller Class Initialized
INFO - 2022-03-14 07:00:38 --> Form Validation Class Initialized
DEBUG - 2022-03-14 07:00:38 --> Encrypt Class Initialized
DEBUG - 2022-03-14 07:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 07:00:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 07:00:38 --> Email Class Initialized
INFO - 2022-03-14 07:00:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 07:00:38 --> Calendar Class Initialized
INFO - 2022-03-14 07:00:38 --> Model "Login_model" initialized
INFO - 2022-03-14 07:00:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 07:00:38 --> Final output sent to browser
DEBUG - 2022-03-14 07:00:38 --> Total execution time: 0.0412
ERROR - 2022-03-14 07:00:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 07:00:39 --> Config Class Initialized
INFO - 2022-03-14 07:00:39 --> Hooks Class Initialized
DEBUG - 2022-03-14 07:00:39 --> UTF-8 Support Enabled
INFO - 2022-03-14 07:00:39 --> Utf8 Class Initialized
INFO - 2022-03-14 07:00:39 --> URI Class Initialized
DEBUG - 2022-03-14 07:00:39 --> No URI present. Default controller set.
INFO - 2022-03-14 07:00:39 --> Router Class Initialized
INFO - 2022-03-14 07:00:39 --> Output Class Initialized
INFO - 2022-03-14 07:00:39 --> Security Class Initialized
DEBUG - 2022-03-14 07:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 07:00:39 --> Input Class Initialized
INFO - 2022-03-14 07:00:39 --> Language Class Initialized
INFO - 2022-03-14 07:00:39 --> Loader Class Initialized
INFO - 2022-03-14 07:00:39 --> Helper loaded: url_helper
INFO - 2022-03-14 07:00:39 --> Helper loaded: form_helper
INFO - 2022-03-14 07:00:39 --> Helper loaded: common_helper
INFO - 2022-03-14 07:00:39 --> Database Driver Class Initialized
DEBUG - 2022-03-14 07:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 07:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 07:00:39 --> Controller Class Initialized
INFO - 2022-03-14 07:00:39 --> Form Validation Class Initialized
DEBUG - 2022-03-14 07:00:39 --> Encrypt Class Initialized
DEBUG - 2022-03-14 07:00:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 07:00:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 07:00:39 --> Email Class Initialized
INFO - 2022-03-14 07:00:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 07:00:39 --> Calendar Class Initialized
INFO - 2022-03-14 07:00:39 --> Model "Login_model" initialized
INFO - 2022-03-14 07:00:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 07:00:39 --> Final output sent to browser
DEBUG - 2022-03-14 07:00:39 --> Total execution time: 0.0752
ERROR - 2022-03-14 07:00:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 07:00:40 --> Config Class Initialized
INFO - 2022-03-14 07:00:40 --> Hooks Class Initialized
DEBUG - 2022-03-14 07:00:40 --> UTF-8 Support Enabled
INFO - 2022-03-14 07:00:40 --> Utf8 Class Initialized
INFO - 2022-03-14 07:00:40 --> URI Class Initialized
INFO - 2022-03-14 07:00:40 --> Router Class Initialized
INFO - 2022-03-14 07:00:40 --> Output Class Initialized
INFO - 2022-03-14 07:00:40 --> Security Class Initialized
DEBUG - 2022-03-14 07:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 07:00:40 --> Input Class Initialized
INFO - 2022-03-14 07:00:40 --> Language Class Initialized
INFO - 2022-03-14 07:00:40 --> Loader Class Initialized
INFO - 2022-03-14 07:00:40 --> Helper loaded: url_helper
INFO - 2022-03-14 07:00:40 --> Helper loaded: form_helper
INFO - 2022-03-14 07:00:40 --> Helper loaded: common_helper
INFO - 2022-03-14 07:00:40 --> Database Driver Class Initialized
DEBUG - 2022-03-14 07:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 07:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 07:00:40 --> Controller Class Initialized
INFO - 2022-03-14 07:00:40 --> Form Validation Class Initialized
DEBUG - 2022-03-14 07:00:40 --> Encrypt Class Initialized
DEBUG - 2022-03-14 07:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 07:00:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 07:00:40 --> Email Class Initialized
INFO - 2022-03-14 07:00:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 07:00:40 --> Calendar Class Initialized
INFO - 2022-03-14 07:00:40 --> Model "Login_model" initialized
ERROR - 2022-03-14 07:00:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 07:00:40 --> Config Class Initialized
INFO - 2022-03-14 07:00:40 --> Hooks Class Initialized
DEBUG - 2022-03-14 07:00:40 --> UTF-8 Support Enabled
INFO - 2022-03-14 07:00:40 --> Utf8 Class Initialized
INFO - 2022-03-14 07:00:40 --> URI Class Initialized
INFO - 2022-03-14 07:00:40 --> Router Class Initialized
INFO - 2022-03-14 07:00:40 --> Output Class Initialized
INFO - 2022-03-14 07:00:40 --> Security Class Initialized
DEBUG - 2022-03-14 07:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 07:00:40 --> Input Class Initialized
INFO - 2022-03-14 07:00:40 --> Language Class Initialized
INFO - 2022-03-14 07:00:40 --> Loader Class Initialized
INFO - 2022-03-14 07:00:40 --> Helper loaded: url_helper
INFO - 2022-03-14 07:00:40 --> Helper loaded: form_helper
INFO - 2022-03-14 07:00:40 --> Helper loaded: common_helper
INFO - 2022-03-14 07:00:40 --> Database Driver Class Initialized
DEBUG - 2022-03-14 07:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 07:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 07:00:40 --> Controller Class Initialized
INFO - 2022-03-14 07:00:40 --> Form Validation Class Initialized
DEBUG - 2022-03-14 07:00:40 --> Encrypt Class Initialized
DEBUG - 2022-03-14 07:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 07:00:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 07:00:40 --> Email Class Initialized
INFO - 2022-03-14 07:00:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 07:00:40 --> Calendar Class Initialized
INFO - 2022-03-14 07:00:40 --> Model "Login_model" initialized
INFO - 2022-03-14 07:00:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 07:00:40 --> Final output sent to browser
DEBUG - 2022-03-14 07:00:40 --> Total execution time: 0.0407
ERROR - 2022-03-14 07:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 07:14:29 --> Config Class Initialized
INFO - 2022-03-14 07:14:29 --> Hooks Class Initialized
DEBUG - 2022-03-14 07:14:29 --> UTF-8 Support Enabled
INFO - 2022-03-14 07:14:29 --> Utf8 Class Initialized
INFO - 2022-03-14 07:14:29 --> URI Class Initialized
DEBUG - 2022-03-14 07:14:29 --> No URI present. Default controller set.
INFO - 2022-03-14 07:14:29 --> Router Class Initialized
INFO - 2022-03-14 07:14:29 --> Output Class Initialized
INFO - 2022-03-14 07:14:29 --> Security Class Initialized
DEBUG - 2022-03-14 07:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 07:14:29 --> Input Class Initialized
INFO - 2022-03-14 07:14:29 --> Language Class Initialized
INFO - 2022-03-14 07:14:29 --> Loader Class Initialized
INFO - 2022-03-14 07:14:29 --> Helper loaded: url_helper
INFO - 2022-03-14 07:14:29 --> Helper loaded: form_helper
INFO - 2022-03-14 07:14:29 --> Helper loaded: common_helper
INFO - 2022-03-14 07:14:29 --> Database Driver Class Initialized
DEBUG - 2022-03-14 07:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 07:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 07:14:29 --> Controller Class Initialized
INFO - 2022-03-14 07:14:29 --> Form Validation Class Initialized
DEBUG - 2022-03-14 07:14:29 --> Encrypt Class Initialized
DEBUG - 2022-03-14 07:14:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 07:14:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 07:14:29 --> Email Class Initialized
INFO - 2022-03-14 07:14:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 07:14:29 --> Calendar Class Initialized
INFO - 2022-03-14 07:14:29 --> Model "Login_model" initialized
INFO - 2022-03-14 07:14:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 07:14:29 --> Final output sent to browser
DEBUG - 2022-03-14 07:14:29 --> Total execution time: 0.0233
ERROR - 2022-03-14 09:34:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:22 --> Config Class Initialized
INFO - 2022-03-14 09:34:22 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:22 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:22 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:22 --> URI Class Initialized
DEBUG - 2022-03-14 09:34:22 --> No URI present. Default controller set.
INFO - 2022-03-14 09:34:22 --> Router Class Initialized
INFO - 2022-03-14 09:34:22 --> Output Class Initialized
INFO - 2022-03-14 09:34:22 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:22 --> Input Class Initialized
INFO - 2022-03-14 09:34:22 --> Language Class Initialized
INFO - 2022-03-14 09:34:22 --> Loader Class Initialized
INFO - 2022-03-14 09:34:22 --> Helper loaded: url_helper
INFO - 2022-03-14 09:34:22 --> Helper loaded: form_helper
INFO - 2022-03-14 09:34:22 --> Helper loaded: common_helper
INFO - 2022-03-14 09:34:22 --> Database Driver Class Initialized
DEBUG - 2022-03-14 09:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 09:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:34:22 --> Controller Class Initialized
INFO - 2022-03-14 09:34:22 --> Form Validation Class Initialized
DEBUG - 2022-03-14 09:34:22 --> Encrypt Class Initialized
DEBUG - 2022-03-14 09:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 09:34:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 09:34:22 --> Email Class Initialized
INFO - 2022-03-14 09:34:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 09:34:22 --> Calendar Class Initialized
INFO - 2022-03-14 09:34:22 --> Model "Login_model" initialized
INFO - 2022-03-14 09:34:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 09:34:22 --> Final output sent to browser
DEBUG - 2022-03-14 09:34:22 --> Total execution time: 0.0247
ERROR - 2022-03-14 09:34:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:22 --> Config Class Initialized
INFO - 2022-03-14 09:34:22 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:22 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:22 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:22 --> URI Class Initialized
DEBUG - 2022-03-14 09:34:22 --> No URI present. Default controller set.
INFO - 2022-03-14 09:34:22 --> Router Class Initialized
INFO - 2022-03-14 09:34:22 --> Output Class Initialized
INFO - 2022-03-14 09:34:22 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:22 --> Input Class Initialized
INFO - 2022-03-14 09:34:22 --> Language Class Initialized
INFO - 2022-03-14 09:34:22 --> Loader Class Initialized
INFO - 2022-03-14 09:34:22 --> Helper loaded: url_helper
INFO - 2022-03-14 09:34:22 --> Helper loaded: form_helper
INFO - 2022-03-14 09:34:22 --> Helper loaded: common_helper
INFO - 2022-03-14 09:34:22 --> Database Driver Class Initialized
DEBUG - 2022-03-14 09:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 09:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 09:34:22 --> Controller Class Initialized
INFO - 2022-03-14 09:34:22 --> Form Validation Class Initialized
DEBUG - 2022-03-14 09:34:22 --> Encrypt Class Initialized
DEBUG - 2022-03-14 09:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 09:34:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 09:34:22 --> Email Class Initialized
INFO - 2022-03-14 09:34:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 09:34:22 --> Calendar Class Initialized
INFO - 2022-03-14 09:34:22 --> Model "Login_model" initialized
INFO - 2022-03-14 09:34:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 09:34:22 --> Final output sent to browser
DEBUG - 2022-03-14 09:34:22 --> Total execution time: 0.0217
ERROR - 2022-03-14 09:34:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:23 --> Config Class Initialized
INFO - 2022-03-14 09:34:23 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:23 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:23 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:23 --> URI Class Initialized
INFO - 2022-03-14 09:34:23 --> Router Class Initialized
INFO - 2022-03-14 09:34:23 --> Output Class Initialized
INFO - 2022-03-14 09:34:23 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:23 --> Input Class Initialized
INFO - 2022-03-14 09:34:23 --> Language Class Initialized
ERROR - 2022-03-14 09:34:23 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-14 09:34:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:24 --> Config Class Initialized
INFO - 2022-03-14 09:34:24 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:24 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:24 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:24 --> URI Class Initialized
INFO - 2022-03-14 09:34:24 --> Router Class Initialized
INFO - 2022-03-14 09:34:24 --> Output Class Initialized
INFO - 2022-03-14 09:34:24 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:24 --> Input Class Initialized
INFO - 2022-03-14 09:34:24 --> Language Class Initialized
ERROR - 2022-03-14 09:34:24 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-14 09:34:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:24 --> Config Class Initialized
INFO - 2022-03-14 09:34:24 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:24 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:24 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:24 --> URI Class Initialized
INFO - 2022-03-14 09:34:24 --> Router Class Initialized
INFO - 2022-03-14 09:34:24 --> Output Class Initialized
INFO - 2022-03-14 09:34:24 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:24 --> Input Class Initialized
INFO - 2022-03-14 09:34:24 --> Language Class Initialized
ERROR - 2022-03-14 09:34:24 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-14 09:34:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:25 --> Config Class Initialized
INFO - 2022-03-14 09:34:25 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:25 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:25 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:25 --> URI Class Initialized
INFO - 2022-03-14 09:34:25 --> Router Class Initialized
INFO - 2022-03-14 09:34:25 --> Output Class Initialized
INFO - 2022-03-14 09:34:25 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:25 --> Input Class Initialized
INFO - 2022-03-14 09:34:25 --> Language Class Initialized
ERROR - 2022-03-14 09:34:25 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-14 09:34:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:25 --> Config Class Initialized
INFO - 2022-03-14 09:34:25 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:25 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:25 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:25 --> URI Class Initialized
INFO - 2022-03-14 09:34:25 --> Router Class Initialized
INFO - 2022-03-14 09:34:25 --> Output Class Initialized
INFO - 2022-03-14 09:34:25 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:25 --> Input Class Initialized
INFO - 2022-03-14 09:34:25 --> Language Class Initialized
ERROR - 2022-03-14 09:34:25 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-14 09:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:26 --> Config Class Initialized
INFO - 2022-03-14 09:34:26 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:26 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:26 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:26 --> URI Class Initialized
INFO - 2022-03-14 09:34:26 --> Router Class Initialized
INFO - 2022-03-14 09:34:26 --> Output Class Initialized
INFO - 2022-03-14 09:34:26 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:26 --> Input Class Initialized
INFO - 2022-03-14 09:34:26 --> Language Class Initialized
ERROR - 2022-03-14 09:34:26 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-14 09:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:26 --> Config Class Initialized
INFO - 2022-03-14 09:34:26 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:26 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:26 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:26 --> URI Class Initialized
INFO - 2022-03-14 09:34:26 --> Router Class Initialized
INFO - 2022-03-14 09:34:26 --> Output Class Initialized
INFO - 2022-03-14 09:34:26 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:26 --> Input Class Initialized
INFO - 2022-03-14 09:34:26 --> Language Class Initialized
ERROR - 2022-03-14 09:34:26 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-03-14 09:34:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:27 --> Config Class Initialized
INFO - 2022-03-14 09:34:27 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:27 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:27 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:27 --> URI Class Initialized
INFO - 2022-03-14 09:34:27 --> Router Class Initialized
INFO - 2022-03-14 09:34:27 --> Output Class Initialized
INFO - 2022-03-14 09:34:27 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:27 --> Input Class Initialized
INFO - 2022-03-14 09:34:27 --> Language Class Initialized
ERROR - 2022-03-14 09:34:27 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-03-14 09:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:28 --> Config Class Initialized
INFO - 2022-03-14 09:34:28 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:28 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:28 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:28 --> URI Class Initialized
INFO - 2022-03-14 09:34:28 --> Router Class Initialized
INFO - 2022-03-14 09:34:28 --> Output Class Initialized
INFO - 2022-03-14 09:34:28 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:28 --> Input Class Initialized
INFO - 2022-03-14 09:34:28 --> Language Class Initialized
ERROR - 2022-03-14 09:34:28 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-14 09:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:28 --> Config Class Initialized
INFO - 2022-03-14 09:34:28 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:28 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:28 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:28 --> URI Class Initialized
INFO - 2022-03-14 09:34:28 --> Router Class Initialized
INFO - 2022-03-14 09:34:28 --> Output Class Initialized
INFO - 2022-03-14 09:34:28 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:28 --> Input Class Initialized
INFO - 2022-03-14 09:34:28 --> Language Class Initialized
ERROR - 2022-03-14 09:34:28 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-14 09:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:29 --> Config Class Initialized
INFO - 2022-03-14 09:34:29 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:29 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:29 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:29 --> URI Class Initialized
INFO - 2022-03-14 09:34:29 --> Router Class Initialized
INFO - 2022-03-14 09:34:29 --> Output Class Initialized
INFO - 2022-03-14 09:34:29 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:29 --> Input Class Initialized
INFO - 2022-03-14 09:34:29 --> Language Class Initialized
ERROR - 2022-03-14 09:34:29 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-14 09:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:29 --> Config Class Initialized
INFO - 2022-03-14 09:34:29 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:29 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:29 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:29 --> URI Class Initialized
INFO - 2022-03-14 09:34:29 --> Router Class Initialized
INFO - 2022-03-14 09:34:29 --> Output Class Initialized
INFO - 2022-03-14 09:34:29 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:29 --> Input Class Initialized
INFO - 2022-03-14 09:34:29 --> Language Class Initialized
ERROR - 2022-03-14 09:34:29 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-03-14 09:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:30 --> Config Class Initialized
INFO - 2022-03-14 09:34:30 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:30 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:30 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:30 --> URI Class Initialized
INFO - 2022-03-14 09:34:30 --> Router Class Initialized
INFO - 2022-03-14 09:34:30 --> Output Class Initialized
INFO - 2022-03-14 09:34:30 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:30 --> Input Class Initialized
INFO - 2022-03-14 09:34:30 --> Language Class Initialized
ERROR - 2022-03-14 09:34:30 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-14 09:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:30 --> Config Class Initialized
INFO - 2022-03-14 09:34:30 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:30 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:30 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:30 --> URI Class Initialized
INFO - 2022-03-14 09:34:30 --> Router Class Initialized
INFO - 2022-03-14 09:34:30 --> Output Class Initialized
INFO - 2022-03-14 09:34:30 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:30 --> Input Class Initialized
INFO - 2022-03-14 09:34:30 --> Language Class Initialized
ERROR - 2022-03-14 09:34:30 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-14 09:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:31 --> Config Class Initialized
INFO - 2022-03-14 09:34:31 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:31 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:31 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:31 --> URI Class Initialized
INFO - 2022-03-14 09:34:31 --> Router Class Initialized
INFO - 2022-03-14 09:34:31 --> Output Class Initialized
INFO - 2022-03-14 09:34:31 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:31 --> Input Class Initialized
INFO - 2022-03-14 09:34:31 --> Language Class Initialized
ERROR - 2022-03-14 09:34:31 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-14 09:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 09:34:31 --> Config Class Initialized
INFO - 2022-03-14 09:34:31 --> Hooks Class Initialized
DEBUG - 2022-03-14 09:34:31 --> UTF-8 Support Enabled
INFO - 2022-03-14 09:34:31 --> Utf8 Class Initialized
INFO - 2022-03-14 09:34:31 --> URI Class Initialized
INFO - 2022-03-14 09:34:31 --> Router Class Initialized
INFO - 2022-03-14 09:34:31 --> Output Class Initialized
INFO - 2022-03-14 09:34:31 --> Security Class Initialized
DEBUG - 2022-03-14 09:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 09:34:31 --> Input Class Initialized
INFO - 2022-03-14 09:34:31 --> Language Class Initialized
ERROR - 2022-03-14 09:34:31 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-03-14 10:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 10:18:21 --> Config Class Initialized
INFO - 2022-03-14 10:18:21 --> Hooks Class Initialized
DEBUG - 2022-03-14 10:18:21 --> UTF-8 Support Enabled
INFO - 2022-03-14 10:18:21 --> Utf8 Class Initialized
INFO - 2022-03-14 10:18:21 --> URI Class Initialized
DEBUG - 2022-03-14 10:18:21 --> No URI present. Default controller set.
INFO - 2022-03-14 10:18:21 --> Router Class Initialized
INFO - 2022-03-14 10:18:21 --> Output Class Initialized
INFO - 2022-03-14 10:18:21 --> Security Class Initialized
DEBUG - 2022-03-14 10:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 10:18:21 --> Input Class Initialized
INFO - 2022-03-14 10:18:21 --> Language Class Initialized
INFO - 2022-03-14 10:18:21 --> Loader Class Initialized
INFO - 2022-03-14 10:18:21 --> Helper loaded: url_helper
INFO - 2022-03-14 10:18:21 --> Helper loaded: form_helper
INFO - 2022-03-14 10:18:21 --> Helper loaded: common_helper
INFO - 2022-03-14 10:18:21 --> Database Driver Class Initialized
DEBUG - 2022-03-14 10:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 10:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 10:18:21 --> Controller Class Initialized
INFO - 2022-03-14 10:18:21 --> Form Validation Class Initialized
DEBUG - 2022-03-14 10:18:21 --> Encrypt Class Initialized
DEBUG - 2022-03-14 10:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:18:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 10:18:21 --> Email Class Initialized
INFO - 2022-03-14 10:18:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 10:18:21 --> Calendar Class Initialized
INFO - 2022-03-14 10:18:21 --> Model "Login_model" initialized
INFO - 2022-03-14 10:18:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 10:18:21 --> Final output sent to browser
DEBUG - 2022-03-14 10:18:21 --> Total execution time: 0.0235
ERROR - 2022-03-14 13:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 13:03:59 --> Config Class Initialized
INFO - 2022-03-14 13:03:59 --> Hooks Class Initialized
DEBUG - 2022-03-14 13:03:59 --> UTF-8 Support Enabled
INFO - 2022-03-14 13:03:59 --> Utf8 Class Initialized
INFO - 2022-03-14 13:03:59 --> URI Class Initialized
INFO - 2022-03-14 13:03:59 --> Router Class Initialized
INFO - 2022-03-14 13:03:59 --> Output Class Initialized
INFO - 2022-03-14 13:03:59 --> Security Class Initialized
DEBUG - 2022-03-14 13:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 13:03:59 --> Input Class Initialized
INFO - 2022-03-14 13:03:59 --> Language Class Initialized
ERROR - 2022-03-14 13:03:59 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-03-14 13:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 13:03:59 --> Config Class Initialized
INFO - 2022-03-14 13:03:59 --> Hooks Class Initialized
DEBUG - 2022-03-14 13:03:59 --> UTF-8 Support Enabled
INFO - 2022-03-14 13:03:59 --> Utf8 Class Initialized
INFO - 2022-03-14 13:03:59 --> URI Class Initialized
INFO - 2022-03-14 13:03:59 --> Router Class Initialized
INFO - 2022-03-14 13:03:59 --> Output Class Initialized
INFO - 2022-03-14 13:03:59 --> Security Class Initialized
DEBUG - 2022-03-14 13:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 13:03:59 --> Input Class Initialized
INFO - 2022-03-14 13:03:59 --> Language Class Initialized
ERROR - 2022-03-14 13:03:59 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-03-14 13:04:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 13:04:00 --> Config Class Initialized
INFO - 2022-03-14 13:04:00 --> Hooks Class Initialized
DEBUG - 2022-03-14 13:04:00 --> UTF-8 Support Enabled
INFO - 2022-03-14 13:04:00 --> Utf8 Class Initialized
INFO - 2022-03-14 13:04:00 --> URI Class Initialized
DEBUG - 2022-03-14 13:04:00 --> No URI present. Default controller set.
INFO - 2022-03-14 13:04:00 --> Router Class Initialized
INFO - 2022-03-14 13:04:00 --> Output Class Initialized
INFO - 2022-03-14 13:04:00 --> Security Class Initialized
DEBUG - 2022-03-14 13:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 13:04:00 --> Input Class Initialized
INFO - 2022-03-14 13:04:00 --> Language Class Initialized
INFO - 2022-03-14 13:04:00 --> Loader Class Initialized
INFO - 2022-03-14 13:04:00 --> Helper loaded: url_helper
INFO - 2022-03-14 13:04:00 --> Helper loaded: form_helper
INFO - 2022-03-14 13:04:00 --> Helper loaded: common_helper
INFO - 2022-03-14 13:04:00 --> Database Driver Class Initialized
DEBUG - 2022-03-14 13:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 13:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 13:04:00 --> Controller Class Initialized
INFO - 2022-03-14 13:04:00 --> Form Validation Class Initialized
DEBUG - 2022-03-14 13:04:00 --> Encrypt Class Initialized
DEBUG - 2022-03-14 13:04:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 13:04:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 13:04:00 --> Email Class Initialized
INFO - 2022-03-14 13:04:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 13:04:00 --> Calendar Class Initialized
INFO - 2022-03-14 13:04:00 --> Model "Login_model" initialized
INFO - 2022-03-14 13:04:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 13:04:00 --> Final output sent to browser
DEBUG - 2022-03-14 13:04:00 --> Total execution time: 0.0326
ERROR - 2022-03-14 14:01:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 14:01:11 --> Config Class Initialized
INFO - 2022-03-14 14:01:11 --> Hooks Class Initialized
DEBUG - 2022-03-14 14:01:11 --> UTF-8 Support Enabled
INFO - 2022-03-14 14:01:11 --> Utf8 Class Initialized
INFO - 2022-03-14 14:01:11 --> URI Class Initialized
DEBUG - 2022-03-14 14:01:11 --> No URI present. Default controller set.
INFO - 2022-03-14 14:01:11 --> Router Class Initialized
INFO - 2022-03-14 14:01:11 --> Output Class Initialized
INFO - 2022-03-14 14:01:11 --> Security Class Initialized
DEBUG - 2022-03-14 14:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 14:01:11 --> Input Class Initialized
INFO - 2022-03-14 14:01:11 --> Language Class Initialized
INFO - 2022-03-14 14:01:11 --> Loader Class Initialized
INFO - 2022-03-14 14:01:11 --> Helper loaded: url_helper
INFO - 2022-03-14 14:01:11 --> Helper loaded: form_helper
INFO - 2022-03-14 14:01:11 --> Helper loaded: common_helper
INFO - 2022-03-14 14:01:11 --> Database Driver Class Initialized
DEBUG - 2022-03-14 14:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 14:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 14:01:11 --> Controller Class Initialized
INFO - 2022-03-14 14:01:11 --> Form Validation Class Initialized
DEBUG - 2022-03-14 14:01:11 --> Encrypt Class Initialized
DEBUG - 2022-03-14 14:01:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:01:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 14:01:11 --> Email Class Initialized
INFO - 2022-03-14 14:01:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 14:01:11 --> Calendar Class Initialized
INFO - 2022-03-14 14:01:11 --> Model "Login_model" initialized
INFO - 2022-03-14 14:01:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 14:01:11 --> Final output sent to browser
DEBUG - 2022-03-14 14:01:11 --> Total execution time: 0.1630
ERROR - 2022-03-14 14:18:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 14:18:02 --> Config Class Initialized
INFO - 2022-03-14 14:18:02 --> Hooks Class Initialized
DEBUG - 2022-03-14 14:18:02 --> UTF-8 Support Enabled
INFO - 2022-03-14 14:18:02 --> Utf8 Class Initialized
INFO - 2022-03-14 14:18:02 --> URI Class Initialized
DEBUG - 2022-03-14 14:18:02 --> No URI present. Default controller set.
INFO - 2022-03-14 14:18:02 --> Router Class Initialized
INFO - 2022-03-14 14:18:02 --> Output Class Initialized
INFO - 2022-03-14 14:18:02 --> Security Class Initialized
DEBUG - 2022-03-14 14:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 14:18:02 --> Input Class Initialized
INFO - 2022-03-14 14:18:02 --> Language Class Initialized
INFO - 2022-03-14 14:18:02 --> Loader Class Initialized
INFO - 2022-03-14 14:18:02 --> Helper loaded: url_helper
INFO - 2022-03-14 14:18:02 --> Helper loaded: form_helper
INFO - 2022-03-14 14:18:02 --> Helper loaded: common_helper
INFO - 2022-03-14 14:18:02 --> Database Driver Class Initialized
DEBUG - 2022-03-14 14:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 14:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 14:18:02 --> Controller Class Initialized
INFO - 2022-03-14 14:18:02 --> Form Validation Class Initialized
DEBUG - 2022-03-14 14:18:02 --> Encrypt Class Initialized
DEBUG - 2022-03-14 14:18:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:18:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 14:18:02 --> Email Class Initialized
INFO - 2022-03-14 14:18:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 14:18:02 --> Calendar Class Initialized
INFO - 2022-03-14 14:18:02 --> Model "Login_model" initialized
INFO - 2022-03-14 14:18:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 14:18:02 --> Final output sent to browser
DEBUG - 2022-03-14 14:18:02 --> Total execution time: 0.4074
ERROR - 2022-03-14 14:18:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 14:18:03 --> Config Class Initialized
INFO - 2022-03-14 14:18:03 --> Hooks Class Initialized
DEBUG - 2022-03-14 14:18:03 --> UTF-8 Support Enabled
INFO - 2022-03-14 14:18:03 --> Utf8 Class Initialized
INFO - 2022-03-14 14:18:03 --> URI Class Initialized
INFO - 2022-03-14 14:18:03 --> Router Class Initialized
INFO - 2022-03-14 14:18:03 --> Output Class Initialized
INFO - 2022-03-14 14:18:03 --> Security Class Initialized
DEBUG - 2022-03-14 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 14:18:03 --> Input Class Initialized
INFO - 2022-03-14 14:18:03 --> Language Class Initialized
ERROR - 2022-03-14 14:18:03 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-14 14:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 14:18:21 --> Config Class Initialized
INFO - 2022-03-14 14:18:21 --> Hooks Class Initialized
DEBUG - 2022-03-14 14:18:21 --> UTF-8 Support Enabled
INFO - 2022-03-14 14:18:21 --> Utf8 Class Initialized
INFO - 2022-03-14 14:18:21 --> URI Class Initialized
INFO - 2022-03-14 14:18:21 --> Router Class Initialized
INFO - 2022-03-14 14:18:21 --> Output Class Initialized
INFO - 2022-03-14 14:18:21 --> Security Class Initialized
DEBUG - 2022-03-14 14:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 14:18:21 --> Input Class Initialized
INFO - 2022-03-14 14:18:21 --> Language Class Initialized
INFO - 2022-03-14 14:18:21 --> Loader Class Initialized
INFO - 2022-03-14 14:18:21 --> Helper loaded: url_helper
INFO - 2022-03-14 14:18:21 --> Helper loaded: form_helper
INFO - 2022-03-14 14:18:21 --> Helper loaded: common_helper
INFO - 2022-03-14 14:18:21 --> Database Driver Class Initialized
DEBUG - 2022-03-14 14:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 14:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 14:18:21 --> Controller Class Initialized
INFO - 2022-03-14 14:18:21 --> Form Validation Class Initialized
DEBUG - 2022-03-14 14:18:21 --> Encrypt Class Initialized
DEBUG - 2022-03-14 14:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:18:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 14:18:21 --> Email Class Initialized
INFO - 2022-03-14 14:18:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 14:18:21 --> Calendar Class Initialized
INFO - 2022-03-14 14:18:21 --> Model "Login_model" initialized
INFO - 2022-03-14 14:18:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 14:18:21 --> Final output sent to browser
DEBUG - 2022-03-14 14:18:21 --> Total execution time: 0.0841
ERROR - 2022-03-14 14:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 14:18:22 --> Config Class Initialized
INFO - 2022-03-14 14:18:22 --> Hooks Class Initialized
DEBUG - 2022-03-14 14:18:22 --> UTF-8 Support Enabled
INFO - 2022-03-14 14:18:22 --> Utf8 Class Initialized
INFO - 2022-03-14 14:18:22 --> URI Class Initialized
INFO - 2022-03-14 14:18:22 --> Router Class Initialized
INFO - 2022-03-14 14:18:22 --> Output Class Initialized
INFO - 2022-03-14 14:18:22 --> Security Class Initialized
DEBUG - 2022-03-14 14:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 14:18:22 --> Input Class Initialized
INFO - 2022-03-14 14:18:22 --> Language Class Initialized
INFO - 2022-03-14 14:18:22 --> Loader Class Initialized
INFO - 2022-03-14 14:18:22 --> Helper loaded: url_helper
INFO - 2022-03-14 14:18:22 --> Helper loaded: form_helper
INFO - 2022-03-14 14:18:22 --> Helper loaded: common_helper
INFO - 2022-03-14 14:18:22 --> Database Driver Class Initialized
DEBUG - 2022-03-14 14:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 14:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 14:18:22 --> Controller Class Initialized
INFO - 2022-03-14 14:18:22 --> Form Validation Class Initialized
DEBUG - 2022-03-14 14:18:22 --> Encrypt Class Initialized
DEBUG - 2022-03-14 14:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 14:18:22 --> Email Class Initialized
INFO - 2022-03-14 14:18:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 14:18:22 --> Calendar Class Initialized
INFO - 2022-03-14 14:18:22 --> Model "Login_model" initialized
ERROR - 2022-03-14 14:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 14:18:23 --> Config Class Initialized
INFO - 2022-03-14 14:18:23 --> Hooks Class Initialized
DEBUG - 2022-03-14 14:18:23 --> UTF-8 Support Enabled
INFO - 2022-03-14 14:18:23 --> Utf8 Class Initialized
INFO - 2022-03-14 14:18:23 --> URI Class Initialized
INFO - 2022-03-14 14:18:23 --> Router Class Initialized
INFO - 2022-03-14 14:18:23 --> Output Class Initialized
INFO - 2022-03-14 14:18:23 --> Security Class Initialized
DEBUG - 2022-03-14 14:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 14:18:23 --> Input Class Initialized
INFO - 2022-03-14 14:18:23 --> Language Class Initialized
INFO - 2022-03-14 14:18:23 --> Loader Class Initialized
INFO - 2022-03-14 14:18:23 --> Helper loaded: url_helper
INFO - 2022-03-14 14:18:23 --> Helper loaded: form_helper
INFO - 2022-03-14 14:18:23 --> Helper loaded: common_helper
INFO - 2022-03-14 14:18:23 --> Database Driver Class Initialized
DEBUG - 2022-03-14 14:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 14:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 14:18:23 --> Controller Class Initialized
INFO - 2022-03-14 14:18:23 --> Form Validation Class Initialized
DEBUG - 2022-03-14 14:18:23 --> Encrypt Class Initialized
DEBUG - 2022-03-14 14:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:18:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 14:18:23 --> Email Class Initialized
INFO - 2022-03-14 14:18:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 14:18:23 --> Calendar Class Initialized
INFO - 2022-03-14 14:18:23 --> Model "Login_model" initialized
ERROR - 2022-03-14 14:18:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 14:18:25 --> Config Class Initialized
INFO - 2022-03-14 14:18:25 --> Hooks Class Initialized
DEBUG - 2022-03-14 14:18:25 --> UTF-8 Support Enabled
INFO - 2022-03-14 14:18:25 --> Utf8 Class Initialized
INFO - 2022-03-14 14:18:25 --> URI Class Initialized
DEBUG - 2022-03-14 14:18:25 --> No URI present. Default controller set.
INFO - 2022-03-14 14:18:25 --> Router Class Initialized
INFO - 2022-03-14 14:18:25 --> Output Class Initialized
INFO - 2022-03-14 14:18:25 --> Security Class Initialized
DEBUG - 2022-03-14 14:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 14:18:25 --> Input Class Initialized
INFO - 2022-03-14 14:18:25 --> Language Class Initialized
INFO - 2022-03-14 14:18:25 --> Loader Class Initialized
INFO - 2022-03-14 14:18:25 --> Helper loaded: url_helper
INFO - 2022-03-14 14:18:25 --> Helper loaded: form_helper
INFO - 2022-03-14 14:18:25 --> Helper loaded: common_helper
INFO - 2022-03-14 14:18:25 --> Database Driver Class Initialized
DEBUG - 2022-03-14 14:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 14:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 14:18:25 --> Controller Class Initialized
INFO - 2022-03-14 14:18:25 --> Form Validation Class Initialized
DEBUG - 2022-03-14 14:18:25 --> Encrypt Class Initialized
DEBUG - 2022-03-14 14:18:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:18:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 14:18:25 --> Email Class Initialized
INFO - 2022-03-14 14:18:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 14:18:25 --> Calendar Class Initialized
INFO - 2022-03-14 14:18:25 --> Model "Login_model" initialized
INFO - 2022-03-14 14:18:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 14:18:25 --> Final output sent to browser
DEBUG - 2022-03-14 14:18:25 --> Total execution time: 0.1446
ERROR - 2022-03-14 14:32:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 14:32:42 --> Config Class Initialized
INFO - 2022-03-14 14:32:42 --> Hooks Class Initialized
DEBUG - 2022-03-14 14:32:42 --> UTF-8 Support Enabled
INFO - 2022-03-14 14:32:42 --> Utf8 Class Initialized
INFO - 2022-03-14 14:32:42 --> URI Class Initialized
DEBUG - 2022-03-14 14:32:42 --> No URI present. Default controller set.
INFO - 2022-03-14 14:32:42 --> Router Class Initialized
INFO - 2022-03-14 14:32:42 --> Output Class Initialized
INFO - 2022-03-14 14:32:42 --> Security Class Initialized
DEBUG - 2022-03-14 14:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 14:32:42 --> Input Class Initialized
INFO - 2022-03-14 14:32:42 --> Language Class Initialized
INFO - 2022-03-14 14:32:42 --> Loader Class Initialized
INFO - 2022-03-14 14:32:42 --> Helper loaded: url_helper
INFO - 2022-03-14 14:32:42 --> Helper loaded: form_helper
INFO - 2022-03-14 14:32:42 --> Helper loaded: common_helper
INFO - 2022-03-14 14:32:42 --> Database Driver Class Initialized
DEBUG - 2022-03-14 14:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 14:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 14:32:42 --> Controller Class Initialized
INFO - 2022-03-14 14:32:42 --> Form Validation Class Initialized
DEBUG - 2022-03-14 14:32:42 --> Encrypt Class Initialized
DEBUG - 2022-03-14 14:32:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:32:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 14:32:42 --> Email Class Initialized
INFO - 2022-03-14 14:32:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 14:32:42 --> Calendar Class Initialized
INFO - 2022-03-14 14:32:42 --> Model "Login_model" initialized
INFO - 2022-03-14 14:32:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 14:32:42 --> Final output sent to browser
DEBUG - 2022-03-14 14:32:42 --> Total execution time: 0.1228
ERROR - 2022-03-14 16:58:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 16:58:26 --> Config Class Initialized
INFO - 2022-03-14 16:58:26 --> Hooks Class Initialized
DEBUG - 2022-03-14 16:58:26 --> UTF-8 Support Enabled
INFO - 2022-03-14 16:58:26 --> Utf8 Class Initialized
INFO - 2022-03-14 16:58:26 --> URI Class Initialized
DEBUG - 2022-03-14 16:58:26 --> No URI present. Default controller set.
INFO - 2022-03-14 16:58:26 --> Router Class Initialized
INFO - 2022-03-14 16:58:26 --> Output Class Initialized
INFO - 2022-03-14 16:58:26 --> Security Class Initialized
DEBUG - 2022-03-14 16:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 16:58:26 --> Input Class Initialized
INFO - 2022-03-14 16:58:26 --> Language Class Initialized
INFO - 2022-03-14 16:58:26 --> Loader Class Initialized
INFO - 2022-03-14 16:58:26 --> Helper loaded: url_helper
INFO - 2022-03-14 16:58:26 --> Helper loaded: form_helper
INFO - 2022-03-14 16:58:26 --> Helper loaded: common_helper
INFO - 2022-03-14 16:58:26 --> Database Driver Class Initialized
DEBUG - 2022-03-14 16:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 16:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 16:58:26 --> Controller Class Initialized
INFO - 2022-03-14 16:58:26 --> Form Validation Class Initialized
DEBUG - 2022-03-14 16:58:26 --> Encrypt Class Initialized
DEBUG - 2022-03-14 16:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:58:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 16:58:26 --> Email Class Initialized
INFO - 2022-03-14 16:58:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 16:58:26 --> Calendar Class Initialized
INFO - 2022-03-14 16:58:26 --> Model "Login_model" initialized
INFO - 2022-03-14 16:58:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 16:58:26 --> Final output sent to browser
DEBUG - 2022-03-14 16:58:26 --> Total execution time: 0.0217
ERROR - 2022-03-14 17:05:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-14 17:05:58 --> Config Class Initialized
INFO - 2022-03-14 17:05:58 --> Hooks Class Initialized
DEBUG - 2022-03-14 17:05:58 --> UTF-8 Support Enabled
INFO - 2022-03-14 17:05:58 --> Utf8 Class Initialized
INFO - 2022-03-14 17:05:58 --> URI Class Initialized
DEBUG - 2022-03-14 17:05:58 --> No URI present. Default controller set.
INFO - 2022-03-14 17:05:58 --> Router Class Initialized
INFO - 2022-03-14 17:05:58 --> Output Class Initialized
INFO - 2022-03-14 17:05:58 --> Security Class Initialized
DEBUG - 2022-03-14 17:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-14 17:05:58 --> Input Class Initialized
INFO - 2022-03-14 17:05:58 --> Language Class Initialized
INFO - 2022-03-14 17:05:58 --> Loader Class Initialized
INFO - 2022-03-14 17:05:58 --> Helper loaded: url_helper
INFO - 2022-03-14 17:05:58 --> Helper loaded: form_helper
INFO - 2022-03-14 17:05:58 --> Helper loaded: common_helper
INFO - 2022-03-14 17:05:58 --> Database Driver Class Initialized
DEBUG - 2022-03-14 17:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-14 17:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-14 17:05:58 --> Controller Class Initialized
INFO - 2022-03-14 17:05:58 --> Form Validation Class Initialized
DEBUG - 2022-03-14 17:05:58 --> Encrypt Class Initialized
DEBUG - 2022-03-14 17:05:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 17:05:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-14 17:05:58 --> Email Class Initialized
INFO - 2022-03-14 17:05:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-14 17:05:58 --> Calendar Class Initialized
INFO - 2022-03-14 17:05:58 --> Model "Login_model" initialized
INFO - 2022-03-14 17:05:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-14 17:05:58 --> Final output sent to browser
DEBUG - 2022-03-14 17:05:58 --> Total execution time: 0.0710
