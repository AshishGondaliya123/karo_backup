<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-01 08:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 08:19:44 --> Config Class Initialized
INFO - 2022-03-01 08:19:44 --> Hooks Class Initialized
DEBUG - 2022-03-01 08:19:44 --> UTF-8 Support Enabled
INFO - 2022-03-01 08:19:44 --> Utf8 Class Initialized
INFO - 2022-03-01 08:19:44 --> URI Class Initialized
DEBUG - 2022-03-01 08:19:44 --> No URI present. Default controller set.
INFO - 2022-03-01 08:19:44 --> Router Class Initialized
INFO - 2022-03-01 08:19:44 --> Output Class Initialized
INFO - 2022-03-01 08:19:44 --> Security Class Initialized
DEBUG - 2022-03-01 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 08:19:44 --> Input Class Initialized
INFO - 2022-03-01 08:19:44 --> Language Class Initialized
INFO - 2022-03-01 08:19:44 --> Loader Class Initialized
INFO - 2022-03-01 08:19:44 --> Helper loaded: url_helper
INFO - 2022-03-01 08:19:44 --> Helper loaded: form_helper
INFO - 2022-03-01 08:19:44 --> Helper loaded: common_helper
INFO - 2022-03-01 08:19:44 --> Database Driver Class Initialized
DEBUG - 2022-03-01 08:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 08:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 08:19:44 --> Controller Class Initialized
INFO - 2022-03-01 08:19:44 --> Form Validation Class Initialized
DEBUG - 2022-03-01 08:19:44 --> Encrypt Class Initialized
DEBUG - 2022-03-01 08:19:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 08:19:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 08:19:44 --> Email Class Initialized
INFO - 2022-03-01 08:19:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 08:19:44 --> Calendar Class Initialized
INFO - 2022-03-01 08:19:44 --> Model "Login_model" initialized
INFO - 2022-03-01 08:19:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 08:19:44 --> Final output sent to browser
DEBUG - 2022-03-01 08:19:44 --> Total execution time: 0.0423
ERROR - 2022-03-01 08:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 08:19:45 --> Config Class Initialized
INFO - 2022-03-01 08:19:45 --> Hooks Class Initialized
DEBUG - 2022-03-01 08:19:45 --> UTF-8 Support Enabled
INFO - 2022-03-01 08:19:45 --> Utf8 Class Initialized
INFO - 2022-03-01 08:19:45 --> URI Class Initialized
INFO - 2022-03-01 08:19:45 --> Router Class Initialized
INFO - 2022-03-01 08:19:45 --> Output Class Initialized
INFO - 2022-03-01 08:19:45 --> Security Class Initialized
DEBUG - 2022-03-01 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 08:19:45 --> Input Class Initialized
INFO - 2022-03-01 08:19:45 --> Language Class Initialized
ERROR - 2022-03-01 08:19:45 --> 404 Page Not Found: Wordpress/index
ERROR - 2022-03-01 12:45:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 12:45:20 --> Config Class Initialized
INFO - 2022-03-01 12:45:20 --> Hooks Class Initialized
DEBUG - 2022-03-01 12:45:20 --> UTF-8 Support Enabled
INFO - 2022-03-01 12:45:20 --> Utf8 Class Initialized
INFO - 2022-03-01 12:45:20 --> URI Class Initialized
DEBUG - 2022-03-01 12:45:20 --> No URI present. Default controller set.
INFO - 2022-03-01 12:45:20 --> Router Class Initialized
INFO - 2022-03-01 12:45:20 --> Output Class Initialized
INFO - 2022-03-01 12:45:20 --> Security Class Initialized
DEBUG - 2022-03-01 12:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 12:45:20 --> Input Class Initialized
INFO - 2022-03-01 12:45:20 --> Language Class Initialized
INFO - 2022-03-01 12:45:20 --> Loader Class Initialized
INFO - 2022-03-01 12:45:20 --> Helper loaded: url_helper
INFO - 2022-03-01 12:45:20 --> Helper loaded: form_helper
INFO - 2022-03-01 12:45:20 --> Helper loaded: common_helper
INFO - 2022-03-01 12:45:20 --> Database Driver Class Initialized
DEBUG - 2022-03-01 12:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 12:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 12:45:20 --> Controller Class Initialized
INFO - 2022-03-01 12:45:20 --> Form Validation Class Initialized
DEBUG - 2022-03-01 12:45:20 --> Encrypt Class Initialized
DEBUG - 2022-03-01 12:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:45:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 12:45:20 --> Email Class Initialized
INFO - 2022-03-01 12:45:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 12:45:20 --> Calendar Class Initialized
INFO - 2022-03-01 12:45:20 --> Model "Login_model" initialized
INFO - 2022-03-01 12:45:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 12:45:20 --> Final output sent to browser
DEBUG - 2022-03-01 12:45:20 --> Total execution time: 0.0309
ERROR - 2022-03-01 14:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 14:18:48 --> Config Class Initialized
INFO - 2022-03-01 14:18:48 --> Hooks Class Initialized
DEBUG - 2022-03-01 14:18:48 --> UTF-8 Support Enabled
INFO - 2022-03-01 14:18:48 --> Utf8 Class Initialized
INFO - 2022-03-01 14:18:48 --> URI Class Initialized
DEBUG - 2022-03-01 14:18:48 --> No URI present. Default controller set.
INFO - 2022-03-01 14:18:48 --> Router Class Initialized
INFO - 2022-03-01 14:18:48 --> Output Class Initialized
INFO - 2022-03-01 14:18:48 --> Security Class Initialized
DEBUG - 2022-03-01 14:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 14:18:48 --> Input Class Initialized
INFO - 2022-03-01 14:18:48 --> Language Class Initialized
INFO - 2022-03-01 14:18:48 --> Loader Class Initialized
INFO - 2022-03-01 14:18:48 --> Helper loaded: url_helper
INFO - 2022-03-01 14:18:48 --> Helper loaded: form_helper
INFO - 2022-03-01 14:18:48 --> Helper loaded: common_helper
INFO - 2022-03-01 14:18:48 --> Database Driver Class Initialized
DEBUG - 2022-03-01 14:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 14:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 14:18:48 --> Controller Class Initialized
INFO - 2022-03-01 14:18:48 --> Form Validation Class Initialized
DEBUG - 2022-03-01 14:18:48 --> Encrypt Class Initialized
DEBUG - 2022-03-01 14:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:18:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 14:18:48 --> Email Class Initialized
INFO - 2022-03-01 14:18:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 14:18:48 --> Calendar Class Initialized
INFO - 2022-03-01 14:18:48 --> Model "Login_model" initialized
INFO - 2022-03-01 14:18:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 14:18:48 --> Final output sent to browser
DEBUG - 2022-03-01 14:18:48 --> Total execution time: 0.0481
ERROR - 2022-03-01 14:18:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 14:18:49 --> Config Class Initialized
INFO - 2022-03-01 14:18:49 --> Hooks Class Initialized
DEBUG - 2022-03-01 14:18:49 --> UTF-8 Support Enabled
INFO - 2022-03-01 14:18:49 --> Utf8 Class Initialized
INFO - 2022-03-01 14:18:49 --> URI Class Initialized
INFO - 2022-03-01 14:18:49 --> Router Class Initialized
INFO - 2022-03-01 14:18:49 --> Output Class Initialized
INFO - 2022-03-01 14:18:49 --> Security Class Initialized
DEBUG - 2022-03-01 14:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 14:18:49 --> Input Class Initialized
INFO - 2022-03-01 14:18:49 --> Language Class Initialized
ERROR - 2022-03-01 14:18:49 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-01 14:18:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 14:18:56 --> Config Class Initialized
INFO - 2022-03-01 14:18:56 --> Hooks Class Initialized
DEBUG - 2022-03-01 14:18:56 --> UTF-8 Support Enabled
INFO - 2022-03-01 14:18:56 --> Utf8 Class Initialized
INFO - 2022-03-01 14:18:56 --> URI Class Initialized
INFO - 2022-03-01 14:18:56 --> Router Class Initialized
INFO - 2022-03-01 14:18:56 --> Output Class Initialized
INFO - 2022-03-01 14:18:56 --> Security Class Initialized
DEBUG - 2022-03-01 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 14:18:56 --> Input Class Initialized
INFO - 2022-03-01 14:18:56 --> Language Class Initialized
INFO - 2022-03-01 14:18:56 --> Loader Class Initialized
INFO - 2022-03-01 14:18:56 --> Helper loaded: url_helper
INFO - 2022-03-01 14:18:56 --> Helper loaded: form_helper
INFO - 2022-03-01 14:18:56 --> Helper loaded: common_helper
INFO - 2022-03-01 14:18:56 --> Database Driver Class Initialized
DEBUG - 2022-03-01 14:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 14:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 14:18:56 --> Controller Class Initialized
INFO - 2022-03-01 14:18:56 --> Form Validation Class Initialized
DEBUG - 2022-03-01 14:18:56 --> Encrypt Class Initialized
DEBUG - 2022-03-01 14:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 14:18:56 --> Email Class Initialized
INFO - 2022-03-01 14:18:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 14:18:56 --> Calendar Class Initialized
INFO - 2022-03-01 14:18:56 --> Model "Login_model" initialized
ERROR - 2022-03-01 14:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 14:18:57 --> Config Class Initialized
INFO - 2022-03-01 14:18:57 --> Hooks Class Initialized
DEBUG - 2022-03-01 14:18:57 --> UTF-8 Support Enabled
INFO - 2022-03-01 14:18:57 --> Utf8 Class Initialized
INFO - 2022-03-01 14:18:57 --> URI Class Initialized
INFO - 2022-03-01 14:18:57 --> Router Class Initialized
INFO - 2022-03-01 14:18:57 --> Output Class Initialized
INFO - 2022-03-01 14:18:57 --> Security Class Initialized
DEBUG - 2022-03-01 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 14:18:57 --> Input Class Initialized
INFO - 2022-03-01 14:18:57 --> Language Class Initialized
INFO - 2022-03-01 14:18:57 --> Loader Class Initialized
INFO - 2022-03-01 14:18:57 --> Helper loaded: url_helper
INFO - 2022-03-01 14:18:57 --> Helper loaded: form_helper
INFO - 2022-03-01 14:18:57 --> Helper loaded: common_helper
INFO - 2022-03-01 14:18:57 --> Database Driver Class Initialized
DEBUG - 2022-03-01 14:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 14:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 14:18:57 --> Controller Class Initialized
INFO - 2022-03-01 14:18:57 --> Form Validation Class Initialized
DEBUG - 2022-03-01 14:18:57 --> Encrypt Class Initialized
DEBUG - 2022-03-01 14:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 14:18:57 --> Email Class Initialized
INFO - 2022-03-01 14:18:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 14:18:57 --> Calendar Class Initialized
INFO - 2022-03-01 14:18:57 --> Model "Login_model" initialized
ERROR - 2022-03-01 14:19:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 14:19:00 --> Config Class Initialized
INFO - 2022-03-01 14:19:00 --> Hooks Class Initialized
DEBUG - 2022-03-01 14:19:00 --> UTF-8 Support Enabled
INFO - 2022-03-01 14:19:00 --> Utf8 Class Initialized
INFO - 2022-03-01 14:19:00 --> URI Class Initialized
INFO - 2022-03-01 14:19:00 --> Router Class Initialized
INFO - 2022-03-01 14:19:00 --> Output Class Initialized
INFO - 2022-03-01 14:19:00 --> Security Class Initialized
DEBUG - 2022-03-01 14:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 14:19:00 --> Input Class Initialized
INFO - 2022-03-01 14:19:00 --> Language Class Initialized
INFO - 2022-03-01 14:19:00 --> Loader Class Initialized
INFO - 2022-03-01 14:19:00 --> Helper loaded: url_helper
INFO - 2022-03-01 14:19:00 --> Helper loaded: form_helper
INFO - 2022-03-01 14:19:00 --> Helper loaded: common_helper
INFO - 2022-03-01 14:19:00 --> Database Driver Class Initialized
DEBUG - 2022-03-01 14:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 14:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 14:19:00 --> Controller Class Initialized
INFO - 2022-03-01 14:19:00 --> Form Validation Class Initialized
DEBUG - 2022-03-01 14:19:00 --> Encrypt Class Initialized
DEBUG - 2022-03-01 14:19:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:19:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 14:19:00 --> Email Class Initialized
INFO - 2022-03-01 14:19:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 14:19:00 --> Calendar Class Initialized
INFO - 2022-03-01 14:19:00 --> Model "Login_model" initialized
INFO - 2022-03-01 14:19:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 14:19:00 --> Final output sent to browser
DEBUG - 2022-03-01 14:19:00 --> Total execution time: 0.2501
ERROR - 2022-03-01 14:19:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 14:19:01 --> Config Class Initialized
INFO - 2022-03-01 14:19:01 --> Hooks Class Initialized
DEBUG - 2022-03-01 14:19:01 --> UTF-8 Support Enabled
INFO - 2022-03-01 14:19:01 --> Utf8 Class Initialized
INFO - 2022-03-01 14:19:01 --> URI Class Initialized
DEBUG - 2022-03-01 14:19:01 --> No URI present. Default controller set.
INFO - 2022-03-01 14:19:01 --> Router Class Initialized
INFO - 2022-03-01 14:19:01 --> Output Class Initialized
INFO - 2022-03-01 14:19:01 --> Security Class Initialized
DEBUG - 2022-03-01 14:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 14:19:01 --> Input Class Initialized
INFO - 2022-03-01 14:19:01 --> Language Class Initialized
INFO - 2022-03-01 14:19:01 --> Loader Class Initialized
INFO - 2022-03-01 14:19:01 --> Helper loaded: url_helper
INFO - 2022-03-01 14:19:01 --> Helper loaded: form_helper
INFO - 2022-03-01 14:19:01 --> Helper loaded: common_helper
INFO - 2022-03-01 14:19:01 --> Database Driver Class Initialized
DEBUG - 2022-03-01 14:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 14:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 14:19:01 --> Controller Class Initialized
INFO - 2022-03-01 14:19:01 --> Form Validation Class Initialized
DEBUG - 2022-03-01 14:19:01 --> Encrypt Class Initialized
DEBUG - 2022-03-01 14:19:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:19:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 14:19:01 --> Email Class Initialized
INFO - 2022-03-01 14:19:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 14:19:01 --> Calendar Class Initialized
INFO - 2022-03-01 14:19:01 --> Model "Login_model" initialized
INFO - 2022-03-01 14:19:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 14:19:01 --> Final output sent to browser
DEBUG - 2022-03-01 14:19:01 --> Total execution time: 0.2739
ERROR - 2022-03-01 15:08:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 15:08:55 --> Config Class Initialized
INFO - 2022-03-01 15:08:55 --> Hooks Class Initialized
DEBUG - 2022-03-01 15:08:55 --> UTF-8 Support Enabled
INFO - 2022-03-01 15:08:55 --> Utf8 Class Initialized
INFO - 2022-03-01 15:08:55 --> URI Class Initialized
DEBUG - 2022-03-01 15:08:55 --> No URI present. Default controller set.
INFO - 2022-03-01 15:08:55 --> Router Class Initialized
INFO - 2022-03-01 15:08:55 --> Output Class Initialized
INFO - 2022-03-01 15:08:55 --> Security Class Initialized
DEBUG - 2022-03-01 15:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 15:08:55 --> Input Class Initialized
INFO - 2022-03-01 15:08:55 --> Language Class Initialized
INFO - 2022-03-01 15:08:55 --> Loader Class Initialized
INFO - 2022-03-01 15:08:55 --> Helper loaded: url_helper
INFO - 2022-03-01 15:08:55 --> Helper loaded: form_helper
INFO - 2022-03-01 15:08:55 --> Helper loaded: common_helper
INFO - 2022-03-01 15:08:55 --> Database Driver Class Initialized
DEBUG - 2022-03-01 15:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 15:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 15:08:55 --> Controller Class Initialized
INFO - 2022-03-01 15:08:55 --> Form Validation Class Initialized
DEBUG - 2022-03-01 15:08:55 --> Encrypt Class Initialized
DEBUG - 2022-03-01 15:08:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:08:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 15:08:55 --> Email Class Initialized
INFO - 2022-03-01 15:08:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 15:08:55 --> Calendar Class Initialized
INFO - 2022-03-01 15:08:55 --> Model "Login_model" initialized
INFO - 2022-03-01 15:08:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 15:08:55 --> Final output sent to browser
DEBUG - 2022-03-01 15:08:55 --> Total execution time: 0.0359
ERROR - 2022-03-01 15:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 15:13:10 --> Config Class Initialized
INFO - 2022-03-01 15:13:10 --> Hooks Class Initialized
DEBUG - 2022-03-01 15:13:10 --> UTF-8 Support Enabled
INFO - 2022-03-01 15:13:10 --> Utf8 Class Initialized
INFO - 2022-03-01 15:13:10 --> URI Class Initialized
DEBUG - 2022-03-01 15:13:10 --> No URI present. Default controller set.
INFO - 2022-03-01 15:13:10 --> Router Class Initialized
INFO - 2022-03-01 15:13:10 --> Output Class Initialized
INFO - 2022-03-01 15:13:10 --> Security Class Initialized
DEBUG - 2022-03-01 15:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 15:13:10 --> Input Class Initialized
INFO - 2022-03-01 15:13:10 --> Language Class Initialized
INFO - 2022-03-01 15:13:10 --> Loader Class Initialized
INFO - 2022-03-01 15:13:10 --> Helper loaded: url_helper
INFO - 2022-03-01 15:13:10 --> Helper loaded: form_helper
INFO - 2022-03-01 15:13:10 --> Helper loaded: common_helper
INFO - 2022-03-01 15:13:10 --> Database Driver Class Initialized
DEBUG - 2022-03-01 15:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 15:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 15:13:10 --> Controller Class Initialized
INFO - 2022-03-01 15:13:10 --> Form Validation Class Initialized
DEBUG - 2022-03-01 15:13:10 --> Encrypt Class Initialized
DEBUG - 2022-03-01 15:13:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:13:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 15:13:10 --> Email Class Initialized
INFO - 2022-03-01 15:13:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 15:13:10 --> Calendar Class Initialized
INFO - 2022-03-01 15:13:10 --> Model "Login_model" initialized
INFO - 2022-03-01 15:13:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 15:13:10 --> Final output sent to browser
DEBUG - 2022-03-01 15:13:10 --> Total execution time: 0.0240
ERROR - 2022-03-01 15:49:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 15:49:59 --> Config Class Initialized
INFO - 2022-03-01 15:49:59 --> Hooks Class Initialized
DEBUG - 2022-03-01 15:49:59 --> UTF-8 Support Enabled
INFO - 2022-03-01 15:49:59 --> Utf8 Class Initialized
INFO - 2022-03-01 15:49:59 --> URI Class Initialized
DEBUG - 2022-03-01 15:49:59 --> No URI present. Default controller set.
INFO - 2022-03-01 15:49:59 --> Router Class Initialized
INFO - 2022-03-01 15:49:59 --> Output Class Initialized
INFO - 2022-03-01 15:49:59 --> Security Class Initialized
DEBUG - 2022-03-01 15:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 15:49:59 --> Input Class Initialized
INFO - 2022-03-01 15:49:59 --> Language Class Initialized
INFO - 2022-03-01 15:49:59 --> Loader Class Initialized
INFO - 2022-03-01 15:49:59 --> Helper loaded: url_helper
INFO - 2022-03-01 15:49:59 --> Helper loaded: form_helper
INFO - 2022-03-01 15:49:59 --> Helper loaded: common_helper
INFO - 2022-03-01 15:49:59 --> Database Driver Class Initialized
DEBUG - 2022-03-01 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 15:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 15:49:59 --> Controller Class Initialized
INFO - 2022-03-01 15:49:59 --> Form Validation Class Initialized
DEBUG - 2022-03-01 15:49:59 --> Encrypt Class Initialized
DEBUG - 2022-03-01 15:49:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:49:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 15:49:59 --> Email Class Initialized
INFO - 2022-03-01 15:49:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 15:49:59 --> Calendar Class Initialized
INFO - 2022-03-01 15:49:59 --> Model "Login_model" initialized
INFO - 2022-03-01 15:49:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 15:49:59 --> Final output sent to browser
DEBUG - 2022-03-01 15:49:59 --> Total execution time: 0.0314
ERROR - 2022-03-01 17:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 17:19:28 --> Config Class Initialized
INFO - 2022-03-01 17:19:28 --> Hooks Class Initialized
DEBUG - 2022-03-01 17:19:28 --> UTF-8 Support Enabled
INFO - 2022-03-01 17:19:28 --> Utf8 Class Initialized
INFO - 2022-03-01 17:19:28 --> URI Class Initialized
DEBUG - 2022-03-01 17:19:28 --> No URI present. Default controller set.
INFO - 2022-03-01 17:19:28 --> Router Class Initialized
INFO - 2022-03-01 17:19:28 --> Output Class Initialized
INFO - 2022-03-01 17:19:28 --> Security Class Initialized
DEBUG - 2022-03-01 17:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 17:19:28 --> Input Class Initialized
INFO - 2022-03-01 17:19:28 --> Language Class Initialized
INFO - 2022-03-01 17:19:28 --> Loader Class Initialized
INFO - 2022-03-01 17:19:28 --> Helper loaded: url_helper
INFO - 2022-03-01 17:19:28 --> Helper loaded: form_helper
INFO - 2022-03-01 17:19:28 --> Helper loaded: common_helper
INFO - 2022-03-01 17:19:28 --> Database Driver Class Initialized
DEBUG - 2022-03-01 17:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 17:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 17:19:28 --> Controller Class Initialized
INFO - 2022-03-01 17:19:28 --> Form Validation Class Initialized
DEBUG - 2022-03-01 17:19:28 --> Encrypt Class Initialized
DEBUG - 2022-03-01 17:19:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 17:19:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 17:19:28 --> Email Class Initialized
INFO - 2022-03-01 17:19:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 17:19:28 --> Calendar Class Initialized
INFO - 2022-03-01 17:19:28 --> Model "Login_model" initialized
INFO - 2022-03-01 17:19:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 17:19:28 --> Final output sent to browser
DEBUG - 2022-03-01 17:19:28 --> Total execution time: 0.0278
ERROR - 2022-03-01 20:09:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 20:09:00 --> Config Class Initialized
INFO - 2022-03-01 20:09:00 --> Hooks Class Initialized
DEBUG - 2022-03-01 20:09:00 --> UTF-8 Support Enabled
INFO - 2022-03-01 20:09:00 --> Utf8 Class Initialized
INFO - 2022-03-01 20:09:00 --> URI Class Initialized
DEBUG - 2022-03-01 20:09:00 --> No URI present. Default controller set.
INFO - 2022-03-01 20:09:00 --> Router Class Initialized
INFO - 2022-03-01 20:09:00 --> Output Class Initialized
INFO - 2022-03-01 20:09:00 --> Security Class Initialized
DEBUG - 2022-03-01 20:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 20:09:00 --> Input Class Initialized
INFO - 2022-03-01 20:09:00 --> Language Class Initialized
INFO - 2022-03-01 20:09:00 --> Loader Class Initialized
INFO - 2022-03-01 20:09:00 --> Helper loaded: url_helper
INFO - 2022-03-01 20:09:00 --> Helper loaded: form_helper
INFO - 2022-03-01 20:09:00 --> Helper loaded: common_helper
INFO - 2022-03-01 20:09:00 --> Database Driver Class Initialized
DEBUG - 2022-03-01 20:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 20:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 20:09:00 --> Controller Class Initialized
INFO - 2022-03-01 20:09:00 --> Form Validation Class Initialized
DEBUG - 2022-03-01 20:09:00 --> Encrypt Class Initialized
DEBUG - 2022-03-01 20:09:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 20:09:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 20:09:00 --> Email Class Initialized
INFO - 2022-03-01 20:09:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 20:09:00 --> Calendar Class Initialized
INFO - 2022-03-01 20:09:00 --> Model "Login_model" initialized
INFO - 2022-03-01 20:09:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 20:09:00 --> Final output sent to browser
DEBUG - 2022-03-01 20:09:00 --> Total execution time: 0.0236
ERROR - 2022-03-01 21:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-01 21:59:59 --> Config Class Initialized
INFO - 2022-03-01 21:59:59 --> Hooks Class Initialized
DEBUG - 2022-03-01 21:59:59 --> UTF-8 Support Enabled
INFO - 2022-03-01 21:59:59 --> Utf8 Class Initialized
INFO - 2022-03-01 21:59:59 --> URI Class Initialized
DEBUG - 2022-03-01 21:59:59 --> No URI present. Default controller set.
INFO - 2022-03-01 21:59:59 --> Router Class Initialized
INFO - 2022-03-01 21:59:59 --> Output Class Initialized
INFO - 2022-03-01 21:59:59 --> Security Class Initialized
DEBUG - 2022-03-01 21:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-01 21:59:59 --> Input Class Initialized
INFO - 2022-03-01 21:59:59 --> Language Class Initialized
INFO - 2022-03-01 21:59:59 --> Loader Class Initialized
INFO - 2022-03-01 21:59:59 --> Helper loaded: url_helper
INFO - 2022-03-01 21:59:59 --> Helper loaded: form_helper
INFO - 2022-03-01 21:59:59 --> Helper loaded: common_helper
INFO - 2022-03-01 21:59:59 --> Database Driver Class Initialized
DEBUG - 2022-03-01 21:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-01 21:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-01 21:59:59 --> Controller Class Initialized
INFO - 2022-03-01 21:59:59 --> Form Validation Class Initialized
DEBUG - 2022-03-01 21:59:59 --> Encrypt Class Initialized
DEBUG - 2022-03-01 21:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 21:59:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-01 21:59:59 --> Email Class Initialized
INFO - 2022-03-01 21:59:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-01 21:59:59 --> Calendar Class Initialized
INFO - 2022-03-01 21:59:59 --> Model "Login_model" initialized
INFO - 2022-03-01 21:59:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-01 21:59:59 --> Final output sent to browser
DEBUG - 2022-03-01 21:59:59 --> Total execution time: 0.1395
