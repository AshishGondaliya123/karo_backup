<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-23 01:52:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 01:52:57 --> Config Class Initialized
INFO - 2022-02-23 01:52:57 --> Hooks Class Initialized
DEBUG - 2022-02-23 01:52:57 --> UTF-8 Support Enabled
INFO - 2022-02-23 01:52:57 --> Utf8 Class Initialized
INFO - 2022-02-23 01:52:57 --> URI Class Initialized
DEBUG - 2022-02-23 01:52:57 --> No URI present. Default controller set.
INFO - 2022-02-23 01:52:57 --> Router Class Initialized
INFO - 2022-02-23 01:52:57 --> Output Class Initialized
INFO - 2022-02-23 01:52:57 --> Security Class Initialized
DEBUG - 2022-02-23 01:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 01:52:57 --> Input Class Initialized
INFO - 2022-02-23 01:52:57 --> Language Class Initialized
INFO - 2022-02-23 01:52:57 --> Loader Class Initialized
INFO - 2022-02-23 01:52:57 --> Helper loaded: url_helper
INFO - 2022-02-23 01:52:57 --> Helper loaded: form_helper
INFO - 2022-02-23 01:52:57 --> Helper loaded: common_helper
INFO - 2022-02-23 01:52:57 --> Database Driver Class Initialized
DEBUG - 2022-02-23 01:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 01:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 01:52:57 --> Controller Class Initialized
INFO - 2022-02-23 01:52:57 --> Form Validation Class Initialized
DEBUG - 2022-02-23 01:52:57 --> Encrypt Class Initialized
DEBUG - 2022-02-23 01:52:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 01:52:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 01:52:57 --> Email Class Initialized
INFO - 2022-02-23 01:52:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 01:52:57 --> Calendar Class Initialized
INFO - 2022-02-23 01:52:57 --> Model "Login_model" initialized
INFO - 2022-02-23 01:52:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 01:52:57 --> Final output sent to browser
DEBUG - 2022-02-23 01:52:57 --> Total execution time: 0.1881
ERROR - 2022-02-23 03:53:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 03:53:00 --> Config Class Initialized
INFO - 2022-02-23 03:53:00 --> Hooks Class Initialized
DEBUG - 2022-02-23 03:53:00 --> UTF-8 Support Enabled
INFO - 2022-02-23 03:53:00 --> Utf8 Class Initialized
INFO - 2022-02-23 03:53:00 --> URI Class Initialized
DEBUG - 2022-02-23 03:53:00 --> No URI present. Default controller set.
INFO - 2022-02-23 03:53:00 --> Router Class Initialized
INFO - 2022-02-23 03:53:00 --> Output Class Initialized
INFO - 2022-02-23 03:53:00 --> Security Class Initialized
DEBUG - 2022-02-23 03:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 03:53:00 --> Input Class Initialized
INFO - 2022-02-23 03:53:00 --> Language Class Initialized
INFO - 2022-02-23 03:53:00 --> Loader Class Initialized
INFO - 2022-02-23 03:53:00 --> Helper loaded: url_helper
INFO - 2022-02-23 03:53:00 --> Helper loaded: form_helper
INFO - 2022-02-23 03:53:00 --> Helper loaded: common_helper
INFO - 2022-02-23 03:53:00 --> Database Driver Class Initialized
DEBUG - 2022-02-23 03:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 03:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 03:53:00 --> Controller Class Initialized
INFO - 2022-02-23 03:53:00 --> Form Validation Class Initialized
DEBUG - 2022-02-23 03:53:00 --> Encrypt Class Initialized
DEBUG - 2022-02-23 03:53:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 03:53:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 03:53:00 --> Email Class Initialized
INFO - 2022-02-23 03:53:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 03:53:00 --> Calendar Class Initialized
INFO - 2022-02-23 03:53:00 --> Model "Login_model" initialized
INFO - 2022-02-23 03:53:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 03:53:00 --> Final output sent to browser
DEBUG - 2022-02-23 03:53:00 --> Total execution time: 0.0341
ERROR - 2022-02-23 04:22:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 04:22:53 --> Config Class Initialized
INFO - 2022-02-23 04:22:53 --> Hooks Class Initialized
DEBUG - 2022-02-23 04:22:53 --> UTF-8 Support Enabled
INFO - 2022-02-23 04:22:53 --> Utf8 Class Initialized
INFO - 2022-02-23 04:22:53 --> URI Class Initialized
DEBUG - 2022-02-23 04:22:53 --> No URI present. Default controller set.
INFO - 2022-02-23 04:22:53 --> Router Class Initialized
INFO - 2022-02-23 04:22:53 --> Output Class Initialized
INFO - 2022-02-23 04:22:53 --> Security Class Initialized
DEBUG - 2022-02-23 04:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 04:22:53 --> Input Class Initialized
INFO - 2022-02-23 04:22:53 --> Language Class Initialized
INFO - 2022-02-23 04:22:53 --> Loader Class Initialized
INFO - 2022-02-23 04:22:53 --> Helper loaded: url_helper
INFO - 2022-02-23 04:22:53 --> Helper loaded: form_helper
INFO - 2022-02-23 04:22:53 --> Helper loaded: common_helper
INFO - 2022-02-23 04:22:53 --> Database Driver Class Initialized
DEBUG - 2022-02-23 04:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 04:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 04:22:53 --> Controller Class Initialized
INFO - 2022-02-23 04:22:53 --> Form Validation Class Initialized
DEBUG - 2022-02-23 04:22:53 --> Encrypt Class Initialized
DEBUG - 2022-02-23 04:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 04:22:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 04:22:53 --> Email Class Initialized
INFO - 2022-02-23 04:22:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 04:22:53 --> Calendar Class Initialized
INFO - 2022-02-23 04:22:53 --> Model "Login_model" initialized
INFO - 2022-02-23 04:22:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 04:22:53 --> Final output sent to browser
DEBUG - 2022-02-23 04:22:53 --> Total execution time: 0.0508
ERROR - 2022-02-23 11:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 11:30:22 --> Config Class Initialized
INFO - 2022-02-23 11:30:22 --> Hooks Class Initialized
DEBUG - 2022-02-23 11:30:22 --> UTF-8 Support Enabled
INFO - 2022-02-23 11:30:22 --> Utf8 Class Initialized
INFO - 2022-02-23 11:30:22 --> URI Class Initialized
DEBUG - 2022-02-23 11:30:22 --> No URI present. Default controller set.
INFO - 2022-02-23 11:30:22 --> Router Class Initialized
INFO - 2022-02-23 11:30:22 --> Output Class Initialized
INFO - 2022-02-23 11:30:22 --> Security Class Initialized
DEBUG - 2022-02-23 11:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 11:30:22 --> Input Class Initialized
INFO - 2022-02-23 11:30:22 --> Language Class Initialized
INFO - 2022-02-23 11:30:22 --> Loader Class Initialized
INFO - 2022-02-23 11:30:23 --> Helper loaded: url_helper
INFO - 2022-02-23 11:30:23 --> Helper loaded: form_helper
INFO - 2022-02-23 11:30:23 --> Helper loaded: common_helper
INFO - 2022-02-23 11:30:23 --> Database Driver Class Initialized
DEBUG - 2022-02-23 11:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 11:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 11:30:23 --> Controller Class Initialized
INFO - 2022-02-23 11:30:23 --> Form Validation Class Initialized
DEBUG - 2022-02-23 11:30:23 --> Encrypt Class Initialized
DEBUG - 2022-02-23 11:30:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:30:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 11:30:23 --> Email Class Initialized
INFO - 2022-02-23 11:30:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 11:30:23 --> Calendar Class Initialized
INFO - 2022-02-23 11:30:23 --> Model "Login_model" initialized
INFO - 2022-02-23 11:30:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 11:30:23 --> Final output sent to browser
DEBUG - 2022-02-23 11:30:23 --> Total execution time: 0.0502
ERROR - 2022-02-23 12:09:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 12:09:50 --> Config Class Initialized
INFO - 2022-02-23 12:09:50 --> Hooks Class Initialized
DEBUG - 2022-02-23 12:09:50 --> UTF-8 Support Enabled
INFO - 2022-02-23 12:09:50 --> Utf8 Class Initialized
INFO - 2022-02-23 12:09:50 --> URI Class Initialized
DEBUG - 2022-02-23 12:09:50 --> No URI present. Default controller set.
INFO - 2022-02-23 12:09:50 --> Router Class Initialized
INFO - 2022-02-23 12:09:50 --> Output Class Initialized
INFO - 2022-02-23 12:09:50 --> Security Class Initialized
DEBUG - 2022-02-23 12:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 12:09:50 --> Input Class Initialized
INFO - 2022-02-23 12:09:50 --> Language Class Initialized
INFO - 2022-02-23 12:09:50 --> Loader Class Initialized
INFO - 2022-02-23 12:09:50 --> Helper loaded: url_helper
INFO - 2022-02-23 12:09:50 --> Helper loaded: form_helper
INFO - 2022-02-23 12:09:50 --> Helper loaded: common_helper
INFO - 2022-02-23 12:09:50 --> Database Driver Class Initialized
DEBUG - 2022-02-23 12:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 12:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 12:09:50 --> Controller Class Initialized
INFO - 2022-02-23 12:09:50 --> Form Validation Class Initialized
DEBUG - 2022-02-23 12:09:50 --> Encrypt Class Initialized
DEBUG - 2022-02-23 12:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 12:09:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 12:09:50 --> Email Class Initialized
INFO - 2022-02-23 12:09:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 12:09:50 --> Calendar Class Initialized
INFO - 2022-02-23 12:09:50 --> Model "Login_model" initialized
INFO - 2022-02-23 12:09:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 12:09:50 --> Final output sent to browser
DEBUG - 2022-02-23 12:09:50 --> Total execution time: 0.0372
ERROR - 2022-02-23 14:14:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:26 --> Config Class Initialized
INFO - 2022-02-23 14:14:26 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:26 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:26 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:26 --> URI Class Initialized
DEBUG - 2022-02-23 14:14:26 --> No URI present. Default controller set.
INFO - 2022-02-23 14:14:26 --> Router Class Initialized
INFO - 2022-02-23 14:14:26 --> Output Class Initialized
INFO - 2022-02-23 14:14:26 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:26 --> Input Class Initialized
INFO - 2022-02-23 14:14:26 --> Language Class Initialized
INFO - 2022-02-23 14:14:26 --> Loader Class Initialized
INFO - 2022-02-23 14:14:26 --> Helper loaded: url_helper
INFO - 2022-02-23 14:14:26 --> Helper loaded: form_helper
INFO - 2022-02-23 14:14:26 --> Helper loaded: common_helper
INFO - 2022-02-23 14:14:26 --> Database Driver Class Initialized
DEBUG - 2022-02-23 14:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 14:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 14:14:26 --> Controller Class Initialized
INFO - 2022-02-23 14:14:26 --> Form Validation Class Initialized
DEBUG - 2022-02-23 14:14:26 --> Encrypt Class Initialized
DEBUG - 2022-02-23 14:14:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:14:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 14:14:26 --> Email Class Initialized
INFO - 2022-02-23 14:14:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 14:14:26 --> Calendar Class Initialized
INFO - 2022-02-23 14:14:26 --> Model "Login_model" initialized
INFO - 2022-02-23 14:14:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 14:14:26 --> Final output sent to browser
DEBUG - 2022-02-23 14:14:26 --> Total execution time: 0.0353
ERROR - 2022-02-23 14:14:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:26 --> Config Class Initialized
INFO - 2022-02-23 14:14:26 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:26 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:26 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:26 --> URI Class Initialized
DEBUG - 2022-02-23 14:14:26 --> No URI present. Default controller set.
INFO - 2022-02-23 14:14:26 --> Router Class Initialized
INFO - 2022-02-23 14:14:26 --> Output Class Initialized
INFO - 2022-02-23 14:14:26 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:26 --> Input Class Initialized
INFO - 2022-02-23 14:14:26 --> Language Class Initialized
INFO - 2022-02-23 14:14:26 --> Loader Class Initialized
INFO - 2022-02-23 14:14:26 --> Helper loaded: url_helper
INFO - 2022-02-23 14:14:26 --> Helper loaded: form_helper
INFO - 2022-02-23 14:14:26 --> Helper loaded: common_helper
INFO - 2022-02-23 14:14:26 --> Database Driver Class Initialized
DEBUG - 2022-02-23 14:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 14:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 14:14:26 --> Controller Class Initialized
INFO - 2022-02-23 14:14:26 --> Form Validation Class Initialized
DEBUG - 2022-02-23 14:14:26 --> Encrypt Class Initialized
DEBUG - 2022-02-23 14:14:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:14:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 14:14:26 --> Email Class Initialized
INFO - 2022-02-23 14:14:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 14:14:26 --> Calendar Class Initialized
INFO - 2022-02-23 14:14:26 --> Model "Login_model" initialized
INFO - 2022-02-23 14:14:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 14:14:26 --> Final output sent to browser
DEBUG - 2022-02-23 14:14:26 --> Total execution time: 0.0351
ERROR - 2022-02-23 14:14:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:27 --> Config Class Initialized
INFO - 2022-02-23 14:14:27 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:27 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:27 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:27 --> URI Class Initialized
INFO - 2022-02-23 14:14:27 --> Router Class Initialized
INFO - 2022-02-23 14:14:27 --> Output Class Initialized
INFO - 2022-02-23 14:14:27 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:27 --> Input Class Initialized
INFO - 2022-02-23 14:14:27 --> Language Class Initialized
ERROR - 2022-02-23 14:14:27 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-23 14:14:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:27 --> Config Class Initialized
INFO - 2022-02-23 14:14:27 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:27 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:27 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:27 --> URI Class Initialized
INFO - 2022-02-23 14:14:27 --> Router Class Initialized
INFO - 2022-02-23 14:14:27 --> Output Class Initialized
INFO - 2022-02-23 14:14:27 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:27 --> Input Class Initialized
INFO - 2022-02-23 14:14:27 --> Language Class Initialized
ERROR - 2022-02-23 14:14:27 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-23 14:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:28 --> Config Class Initialized
INFO - 2022-02-23 14:14:28 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:28 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:28 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:28 --> URI Class Initialized
INFO - 2022-02-23 14:14:28 --> Router Class Initialized
INFO - 2022-02-23 14:14:28 --> Output Class Initialized
INFO - 2022-02-23 14:14:28 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:28 --> Input Class Initialized
INFO - 2022-02-23 14:14:28 --> Language Class Initialized
ERROR - 2022-02-23 14:14:28 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-23 14:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:28 --> Config Class Initialized
INFO - 2022-02-23 14:14:28 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:28 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:28 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:28 --> URI Class Initialized
INFO - 2022-02-23 14:14:28 --> Router Class Initialized
INFO - 2022-02-23 14:14:28 --> Output Class Initialized
INFO - 2022-02-23 14:14:28 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:28 --> Input Class Initialized
INFO - 2022-02-23 14:14:28 --> Language Class Initialized
ERROR - 2022-02-23 14:14:28 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-23 14:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:28 --> Config Class Initialized
INFO - 2022-02-23 14:14:28 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:28 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:28 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:28 --> URI Class Initialized
INFO - 2022-02-23 14:14:28 --> Router Class Initialized
INFO - 2022-02-23 14:14:28 --> Output Class Initialized
INFO - 2022-02-23 14:14:28 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:28 --> Input Class Initialized
INFO - 2022-02-23 14:14:28 --> Language Class Initialized
ERROR - 2022-02-23 14:14:28 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-23 14:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:29 --> Config Class Initialized
INFO - 2022-02-23 14:14:29 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:29 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:29 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:29 --> URI Class Initialized
INFO - 2022-02-23 14:14:29 --> Router Class Initialized
INFO - 2022-02-23 14:14:29 --> Output Class Initialized
INFO - 2022-02-23 14:14:29 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:29 --> Input Class Initialized
INFO - 2022-02-23 14:14:29 --> Language Class Initialized
ERROR - 2022-02-23 14:14:29 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-23 14:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:29 --> Config Class Initialized
INFO - 2022-02-23 14:14:29 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:29 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:29 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:29 --> URI Class Initialized
INFO - 2022-02-23 14:14:29 --> Router Class Initialized
INFO - 2022-02-23 14:14:29 --> Output Class Initialized
INFO - 2022-02-23 14:14:29 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:29 --> Input Class Initialized
INFO - 2022-02-23 14:14:29 --> Language Class Initialized
ERROR - 2022-02-23 14:14:29 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-23 14:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:30 --> Config Class Initialized
INFO - 2022-02-23 14:14:30 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:30 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:30 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:30 --> URI Class Initialized
INFO - 2022-02-23 14:14:30 --> Router Class Initialized
INFO - 2022-02-23 14:14:30 --> Output Class Initialized
INFO - 2022-02-23 14:14:30 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:30 --> Input Class Initialized
INFO - 2022-02-23 14:14:30 --> Language Class Initialized
ERROR - 2022-02-23 14:14:30 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-23 14:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:30 --> Config Class Initialized
INFO - 2022-02-23 14:14:30 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:30 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:30 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:30 --> URI Class Initialized
INFO - 2022-02-23 14:14:30 --> Router Class Initialized
INFO - 2022-02-23 14:14:30 --> Output Class Initialized
INFO - 2022-02-23 14:14:30 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:30 --> Input Class Initialized
INFO - 2022-02-23 14:14:30 --> Language Class Initialized
ERROR - 2022-02-23 14:14:30 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-23 14:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:30 --> Config Class Initialized
INFO - 2022-02-23 14:14:30 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:30 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:30 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:30 --> URI Class Initialized
INFO - 2022-02-23 14:14:30 --> Router Class Initialized
INFO - 2022-02-23 14:14:30 --> Output Class Initialized
INFO - 2022-02-23 14:14:30 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:30 --> Input Class Initialized
INFO - 2022-02-23 14:14:30 --> Language Class Initialized
ERROR - 2022-02-23 14:14:30 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-23 14:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:31 --> Config Class Initialized
INFO - 2022-02-23 14:14:31 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:31 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:31 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:31 --> URI Class Initialized
INFO - 2022-02-23 14:14:31 --> Router Class Initialized
INFO - 2022-02-23 14:14:31 --> Output Class Initialized
INFO - 2022-02-23 14:14:31 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:31 --> Input Class Initialized
INFO - 2022-02-23 14:14:31 --> Language Class Initialized
ERROR - 2022-02-23 14:14:31 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-23 14:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:31 --> Config Class Initialized
INFO - 2022-02-23 14:14:31 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:31 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:31 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:31 --> URI Class Initialized
INFO - 2022-02-23 14:14:31 --> Router Class Initialized
INFO - 2022-02-23 14:14:31 --> Output Class Initialized
INFO - 2022-02-23 14:14:31 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:31 --> Input Class Initialized
INFO - 2022-02-23 14:14:31 --> Language Class Initialized
ERROR - 2022-02-23 14:14:31 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-23 14:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:31 --> Config Class Initialized
INFO - 2022-02-23 14:14:31 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:31 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:31 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:31 --> URI Class Initialized
INFO - 2022-02-23 14:14:31 --> Router Class Initialized
INFO - 2022-02-23 14:14:31 --> Output Class Initialized
INFO - 2022-02-23 14:14:31 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:31 --> Input Class Initialized
INFO - 2022-02-23 14:14:31 --> Language Class Initialized
ERROR - 2022-02-23 14:14:31 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-23 14:14:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:32 --> Config Class Initialized
INFO - 2022-02-23 14:14:32 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:32 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:32 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:32 --> URI Class Initialized
INFO - 2022-02-23 14:14:32 --> Router Class Initialized
INFO - 2022-02-23 14:14:32 --> Output Class Initialized
INFO - 2022-02-23 14:14:32 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:32 --> Input Class Initialized
INFO - 2022-02-23 14:14:32 --> Language Class Initialized
ERROR - 2022-02-23 14:14:32 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-23 14:14:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:32 --> Config Class Initialized
INFO - 2022-02-23 14:14:32 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:32 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:32 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:32 --> URI Class Initialized
INFO - 2022-02-23 14:14:32 --> Router Class Initialized
INFO - 2022-02-23 14:14:32 --> Output Class Initialized
INFO - 2022-02-23 14:14:32 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:32 --> Input Class Initialized
INFO - 2022-02-23 14:14:32 --> Language Class Initialized
ERROR - 2022-02-23 14:14:32 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-23 14:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:14:33 --> Config Class Initialized
INFO - 2022-02-23 14:14:33 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:14:33 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:14:33 --> Utf8 Class Initialized
INFO - 2022-02-23 14:14:33 --> URI Class Initialized
INFO - 2022-02-23 14:14:33 --> Router Class Initialized
INFO - 2022-02-23 14:14:33 --> Output Class Initialized
INFO - 2022-02-23 14:14:33 --> Security Class Initialized
DEBUG - 2022-02-23 14:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:14:33 --> Input Class Initialized
INFO - 2022-02-23 14:14:33 --> Language Class Initialized
ERROR - 2022-02-23 14:14:33 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-23 14:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:20:12 --> Config Class Initialized
INFO - 2022-02-23 14:20:12 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:20:12 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:20:12 --> Utf8 Class Initialized
INFO - 2022-02-23 14:20:12 --> URI Class Initialized
DEBUG - 2022-02-23 14:20:12 --> No URI present. Default controller set.
INFO - 2022-02-23 14:20:12 --> Router Class Initialized
INFO - 2022-02-23 14:20:12 --> Output Class Initialized
INFO - 2022-02-23 14:20:12 --> Security Class Initialized
DEBUG - 2022-02-23 14:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:20:12 --> Input Class Initialized
INFO - 2022-02-23 14:20:12 --> Language Class Initialized
INFO - 2022-02-23 14:20:12 --> Loader Class Initialized
INFO - 2022-02-23 14:20:12 --> Helper loaded: url_helper
INFO - 2022-02-23 14:20:12 --> Helper loaded: form_helper
INFO - 2022-02-23 14:20:12 --> Helper loaded: common_helper
INFO - 2022-02-23 14:20:12 --> Database Driver Class Initialized
DEBUG - 2022-02-23 14:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 14:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 14:20:12 --> Controller Class Initialized
INFO - 2022-02-23 14:20:12 --> Form Validation Class Initialized
DEBUG - 2022-02-23 14:20:12 --> Encrypt Class Initialized
DEBUG - 2022-02-23 14:20:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:20:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 14:20:12 --> Email Class Initialized
INFO - 2022-02-23 14:20:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 14:20:12 --> Calendar Class Initialized
INFO - 2022-02-23 14:20:12 --> Model "Login_model" initialized
INFO - 2022-02-23 14:20:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 14:20:12 --> Final output sent to browser
DEBUG - 2022-02-23 14:20:12 --> Total execution time: 0.0361
ERROR - 2022-02-23 14:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:20:12 --> Config Class Initialized
INFO - 2022-02-23 14:20:12 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:20:12 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:20:12 --> Utf8 Class Initialized
INFO - 2022-02-23 14:20:12 --> URI Class Initialized
INFO - 2022-02-23 14:20:12 --> Router Class Initialized
INFO - 2022-02-23 14:20:12 --> Output Class Initialized
INFO - 2022-02-23 14:20:12 --> Security Class Initialized
DEBUG - 2022-02-23 14:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:20:12 --> Input Class Initialized
INFO - 2022-02-23 14:20:12 --> Language Class Initialized
ERROR - 2022-02-23 14:20:12 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-23 14:20:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:20:21 --> Config Class Initialized
INFO - 2022-02-23 14:20:21 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:20:21 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:20:21 --> Utf8 Class Initialized
INFO - 2022-02-23 14:20:21 --> URI Class Initialized
INFO - 2022-02-23 14:20:21 --> Router Class Initialized
INFO - 2022-02-23 14:20:21 --> Output Class Initialized
INFO - 2022-02-23 14:20:21 --> Security Class Initialized
DEBUG - 2022-02-23 14:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:20:21 --> Input Class Initialized
INFO - 2022-02-23 14:20:21 --> Language Class Initialized
INFO - 2022-02-23 14:20:21 --> Loader Class Initialized
INFO - 2022-02-23 14:20:21 --> Helper loaded: url_helper
INFO - 2022-02-23 14:20:21 --> Helper loaded: form_helper
INFO - 2022-02-23 14:20:21 --> Helper loaded: common_helper
INFO - 2022-02-23 14:20:21 --> Database Driver Class Initialized
DEBUG - 2022-02-23 14:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 14:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 14:20:21 --> Controller Class Initialized
INFO - 2022-02-23 14:20:21 --> Form Validation Class Initialized
DEBUG - 2022-02-23 14:20:21 --> Encrypt Class Initialized
DEBUG - 2022-02-23 14:20:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:20:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 14:20:21 --> Email Class Initialized
INFO - 2022-02-23 14:20:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 14:20:21 --> Calendar Class Initialized
INFO - 2022-02-23 14:20:21 --> Model "Login_model" initialized
INFO - 2022-02-23 14:20:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 14:20:21 --> Final output sent to browser
DEBUG - 2022-02-23 14:20:21 --> Total execution time: 0.0215
ERROR - 2022-02-23 14:20:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:20:22 --> Config Class Initialized
INFO - 2022-02-23 14:20:22 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:20:22 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:20:22 --> Utf8 Class Initialized
INFO - 2022-02-23 14:20:22 --> URI Class Initialized
INFO - 2022-02-23 14:20:22 --> Router Class Initialized
INFO - 2022-02-23 14:20:22 --> Output Class Initialized
INFO - 2022-02-23 14:20:22 --> Security Class Initialized
DEBUG - 2022-02-23 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:20:22 --> Input Class Initialized
INFO - 2022-02-23 14:20:22 --> Language Class Initialized
INFO - 2022-02-23 14:20:22 --> Loader Class Initialized
INFO - 2022-02-23 14:20:22 --> Helper loaded: url_helper
INFO - 2022-02-23 14:20:22 --> Helper loaded: form_helper
INFO - 2022-02-23 14:20:22 --> Helper loaded: common_helper
INFO - 2022-02-23 14:20:22 --> Database Driver Class Initialized
DEBUG - 2022-02-23 14:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 14:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 14:20:22 --> Controller Class Initialized
INFO - 2022-02-23 14:20:22 --> Form Validation Class Initialized
DEBUG - 2022-02-23 14:20:22 --> Encrypt Class Initialized
DEBUG - 2022-02-23 14:20:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 14:20:22 --> Email Class Initialized
INFO - 2022-02-23 14:20:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 14:20:22 --> Calendar Class Initialized
INFO - 2022-02-23 14:20:22 --> Model "Login_model" initialized
ERROR - 2022-02-23 14:20:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:20:22 --> Config Class Initialized
INFO - 2022-02-23 14:20:22 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:20:22 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:20:22 --> Utf8 Class Initialized
INFO - 2022-02-23 14:20:22 --> URI Class Initialized
INFO - 2022-02-23 14:20:22 --> Router Class Initialized
INFO - 2022-02-23 14:20:22 --> Output Class Initialized
INFO - 2022-02-23 14:20:22 --> Security Class Initialized
DEBUG - 2022-02-23 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:20:22 --> Input Class Initialized
INFO - 2022-02-23 14:20:22 --> Language Class Initialized
INFO - 2022-02-23 14:20:22 --> Loader Class Initialized
INFO - 2022-02-23 14:20:22 --> Helper loaded: url_helper
INFO - 2022-02-23 14:20:22 --> Helper loaded: form_helper
INFO - 2022-02-23 14:20:22 --> Helper loaded: common_helper
INFO - 2022-02-23 14:20:22 --> Database Driver Class Initialized
DEBUG - 2022-02-23 14:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 14:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 14:20:22 --> Controller Class Initialized
INFO - 2022-02-23 14:20:22 --> Form Validation Class Initialized
DEBUG - 2022-02-23 14:20:22 --> Encrypt Class Initialized
DEBUG - 2022-02-23 14:20:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 14:20:22 --> Email Class Initialized
INFO - 2022-02-23 14:20:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 14:20:22 --> Calendar Class Initialized
INFO - 2022-02-23 14:20:22 --> Model "Login_model" initialized
ERROR - 2022-02-23 14:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 14:20:23 --> Config Class Initialized
INFO - 2022-02-23 14:20:23 --> Hooks Class Initialized
DEBUG - 2022-02-23 14:20:23 --> UTF-8 Support Enabled
INFO - 2022-02-23 14:20:23 --> Utf8 Class Initialized
INFO - 2022-02-23 14:20:23 --> URI Class Initialized
DEBUG - 2022-02-23 14:20:23 --> No URI present. Default controller set.
INFO - 2022-02-23 14:20:23 --> Router Class Initialized
INFO - 2022-02-23 14:20:23 --> Output Class Initialized
INFO - 2022-02-23 14:20:23 --> Security Class Initialized
DEBUG - 2022-02-23 14:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 14:20:23 --> Input Class Initialized
INFO - 2022-02-23 14:20:23 --> Language Class Initialized
INFO - 2022-02-23 14:20:23 --> Loader Class Initialized
INFO - 2022-02-23 14:20:23 --> Helper loaded: url_helper
INFO - 2022-02-23 14:20:23 --> Helper loaded: form_helper
INFO - 2022-02-23 14:20:23 --> Helper loaded: common_helper
INFO - 2022-02-23 14:20:23 --> Database Driver Class Initialized
DEBUG - 2022-02-23 14:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 14:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 14:20:23 --> Controller Class Initialized
INFO - 2022-02-23 14:20:23 --> Form Validation Class Initialized
DEBUG - 2022-02-23 14:20:23 --> Encrypt Class Initialized
DEBUG - 2022-02-23 14:20:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:20:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 14:20:23 --> Email Class Initialized
INFO - 2022-02-23 14:20:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 14:20:23 --> Calendar Class Initialized
INFO - 2022-02-23 14:20:23 --> Model "Login_model" initialized
INFO - 2022-02-23 14:20:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 14:20:23 --> Final output sent to browser
DEBUG - 2022-02-23 14:20:23 --> Total execution time: 0.0358
ERROR - 2022-02-23 15:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 15:12:02 --> Config Class Initialized
INFO - 2022-02-23 15:12:02 --> Hooks Class Initialized
DEBUG - 2022-02-23 15:12:02 --> UTF-8 Support Enabled
INFO - 2022-02-23 15:12:02 --> Utf8 Class Initialized
INFO - 2022-02-23 15:12:02 --> URI Class Initialized
DEBUG - 2022-02-23 15:12:02 --> No URI present. Default controller set.
INFO - 2022-02-23 15:12:02 --> Router Class Initialized
INFO - 2022-02-23 15:12:02 --> Output Class Initialized
INFO - 2022-02-23 15:12:02 --> Security Class Initialized
DEBUG - 2022-02-23 15:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 15:12:02 --> Input Class Initialized
INFO - 2022-02-23 15:12:02 --> Language Class Initialized
INFO - 2022-02-23 15:12:02 --> Loader Class Initialized
INFO - 2022-02-23 15:12:02 --> Helper loaded: url_helper
INFO - 2022-02-23 15:12:02 --> Helper loaded: form_helper
INFO - 2022-02-23 15:12:02 --> Helper loaded: common_helper
INFO - 2022-02-23 15:12:02 --> Database Driver Class Initialized
DEBUG - 2022-02-23 15:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 15:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 15:12:02 --> Controller Class Initialized
INFO - 2022-02-23 15:12:02 --> Form Validation Class Initialized
DEBUG - 2022-02-23 15:12:02 --> Encrypt Class Initialized
DEBUG - 2022-02-23 15:12:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:12:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 15:12:02 --> Email Class Initialized
INFO - 2022-02-23 15:12:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 15:12:02 --> Calendar Class Initialized
INFO - 2022-02-23 15:12:02 --> Model "Login_model" initialized
INFO - 2022-02-23 15:12:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 15:12:02 --> Final output sent to browser
DEBUG - 2022-02-23 15:12:02 --> Total execution time: 0.0311
ERROR - 2022-02-23 15:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-23 15:56:50 --> Config Class Initialized
INFO - 2022-02-23 15:56:50 --> Hooks Class Initialized
DEBUG - 2022-02-23 15:56:50 --> UTF-8 Support Enabled
INFO - 2022-02-23 15:56:50 --> Utf8 Class Initialized
INFO - 2022-02-23 15:56:50 --> URI Class Initialized
DEBUG - 2022-02-23 15:56:50 --> No URI present. Default controller set.
INFO - 2022-02-23 15:56:50 --> Router Class Initialized
INFO - 2022-02-23 15:56:50 --> Output Class Initialized
INFO - 2022-02-23 15:56:50 --> Security Class Initialized
DEBUG - 2022-02-23 15:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-23 15:56:50 --> Input Class Initialized
INFO - 2022-02-23 15:56:50 --> Language Class Initialized
INFO - 2022-02-23 15:56:50 --> Loader Class Initialized
INFO - 2022-02-23 15:56:50 --> Helper loaded: url_helper
INFO - 2022-02-23 15:56:50 --> Helper loaded: form_helper
INFO - 2022-02-23 15:56:50 --> Helper loaded: common_helper
INFO - 2022-02-23 15:56:50 --> Database Driver Class Initialized
DEBUG - 2022-02-23 15:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-23 15:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-23 15:56:50 --> Controller Class Initialized
INFO - 2022-02-23 15:56:50 --> Form Validation Class Initialized
DEBUG - 2022-02-23 15:56:50 --> Encrypt Class Initialized
DEBUG - 2022-02-23 15:56:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:56:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-23 15:56:50 --> Email Class Initialized
INFO - 2022-02-23 15:56:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-23 15:56:50 --> Calendar Class Initialized
INFO - 2022-02-23 15:56:50 --> Model "Login_model" initialized
INFO - 2022-02-23 15:56:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-23 15:56:50 --> Final output sent to browser
DEBUG - 2022-02-23 15:56:50 --> Total execution time: 0.0284
