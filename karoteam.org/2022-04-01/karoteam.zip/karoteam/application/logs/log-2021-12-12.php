<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-12 00:59:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 00:59:46 --> Config Class Initialized
INFO - 2021-12-12 00:59:46 --> Hooks Class Initialized
DEBUG - 2021-12-12 00:59:46 --> UTF-8 Support Enabled
INFO - 2021-12-12 00:59:46 --> Utf8 Class Initialized
INFO - 2021-12-12 00:59:46 --> URI Class Initialized
DEBUG - 2021-12-12 00:59:46 --> No URI present. Default controller set.
INFO - 2021-12-12 00:59:46 --> Router Class Initialized
INFO - 2021-12-12 00:59:46 --> Output Class Initialized
INFO - 2021-12-12 00:59:46 --> Security Class Initialized
DEBUG - 2021-12-12 00:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 00:59:46 --> Input Class Initialized
INFO - 2021-12-12 00:59:46 --> Language Class Initialized
INFO - 2021-12-12 00:59:46 --> Loader Class Initialized
INFO - 2021-12-12 00:59:46 --> Helper loaded: url_helper
INFO - 2021-12-12 00:59:46 --> Helper loaded: form_helper
INFO - 2021-12-12 00:59:46 --> Helper loaded: common_helper
INFO - 2021-12-12 00:59:46 --> Database Driver Class Initialized
DEBUG - 2021-12-12 00:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 00:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 00:59:46 --> Controller Class Initialized
INFO - 2021-12-12 00:59:46 --> Form Validation Class Initialized
DEBUG - 2021-12-12 00:59:46 --> Encrypt Class Initialized
DEBUG - 2021-12-12 00:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 00:59:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 00:59:46 --> Email Class Initialized
INFO - 2021-12-12 00:59:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 00:59:46 --> Calendar Class Initialized
INFO - 2021-12-12 00:59:46 --> Model "Login_model" initialized
INFO - 2021-12-12 00:59:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 00:59:46 --> Final output sent to browser
DEBUG - 2021-12-12 00:59:46 --> Total execution time: 0.0231
ERROR - 2021-12-12 01:43:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 01:43:58 --> Config Class Initialized
INFO - 2021-12-12 01:43:58 --> Hooks Class Initialized
DEBUG - 2021-12-12 01:43:58 --> UTF-8 Support Enabled
INFO - 2021-12-12 01:43:58 --> Utf8 Class Initialized
INFO - 2021-12-12 01:43:58 --> URI Class Initialized
DEBUG - 2021-12-12 01:43:58 --> No URI present. Default controller set.
INFO - 2021-12-12 01:43:58 --> Router Class Initialized
INFO - 2021-12-12 01:43:58 --> Output Class Initialized
INFO - 2021-12-12 01:43:58 --> Security Class Initialized
DEBUG - 2021-12-12 01:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 01:43:58 --> Input Class Initialized
INFO - 2021-12-12 01:43:58 --> Language Class Initialized
INFO - 2021-12-12 01:43:58 --> Loader Class Initialized
INFO - 2021-12-12 01:43:58 --> Helper loaded: url_helper
INFO - 2021-12-12 01:43:58 --> Helper loaded: form_helper
INFO - 2021-12-12 01:43:58 --> Helper loaded: common_helper
INFO - 2021-12-12 01:43:58 --> Database Driver Class Initialized
DEBUG - 2021-12-12 01:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 01:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 01:43:58 --> Controller Class Initialized
INFO - 2021-12-12 01:43:58 --> Form Validation Class Initialized
DEBUG - 2021-12-12 01:43:58 --> Encrypt Class Initialized
DEBUG - 2021-12-12 01:43:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 01:43:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 01:43:58 --> Email Class Initialized
INFO - 2021-12-12 01:43:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 01:43:58 --> Calendar Class Initialized
INFO - 2021-12-12 01:43:58 --> Model "Login_model" initialized
INFO - 2021-12-12 01:43:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 01:43:58 --> Final output sent to browser
DEBUG - 2021-12-12 01:43:58 --> Total execution time: 0.0261
ERROR - 2021-12-12 01:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 01:48:08 --> Config Class Initialized
INFO - 2021-12-12 01:48:08 --> Hooks Class Initialized
DEBUG - 2021-12-12 01:48:08 --> UTF-8 Support Enabled
INFO - 2021-12-12 01:48:08 --> Utf8 Class Initialized
INFO - 2021-12-12 01:48:08 --> URI Class Initialized
DEBUG - 2021-12-12 01:48:08 --> No URI present. Default controller set.
INFO - 2021-12-12 01:48:08 --> Router Class Initialized
INFO - 2021-12-12 01:48:08 --> Output Class Initialized
INFO - 2021-12-12 01:48:08 --> Security Class Initialized
DEBUG - 2021-12-12 01:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 01:48:08 --> Input Class Initialized
INFO - 2021-12-12 01:48:08 --> Language Class Initialized
INFO - 2021-12-12 01:48:08 --> Loader Class Initialized
INFO - 2021-12-12 01:48:08 --> Helper loaded: url_helper
INFO - 2021-12-12 01:48:08 --> Helper loaded: form_helper
INFO - 2021-12-12 01:48:08 --> Helper loaded: common_helper
INFO - 2021-12-12 01:48:08 --> Database Driver Class Initialized
DEBUG - 2021-12-12 01:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 01:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 01:48:08 --> Controller Class Initialized
INFO - 2021-12-12 01:48:08 --> Form Validation Class Initialized
DEBUG - 2021-12-12 01:48:08 --> Encrypt Class Initialized
DEBUG - 2021-12-12 01:48:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 01:48:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 01:48:08 --> Email Class Initialized
INFO - 2021-12-12 01:48:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 01:48:08 --> Calendar Class Initialized
INFO - 2021-12-12 01:48:08 --> Model "Login_model" initialized
INFO - 2021-12-12 01:48:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 01:48:08 --> Final output sent to browser
DEBUG - 2021-12-12 01:48:08 --> Total execution time: 0.0216
ERROR - 2021-12-12 03:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 03:05:01 --> Config Class Initialized
INFO - 2021-12-12 03:05:01 --> Hooks Class Initialized
DEBUG - 2021-12-12 03:05:01 --> UTF-8 Support Enabled
INFO - 2021-12-12 03:05:01 --> Utf8 Class Initialized
INFO - 2021-12-12 03:05:01 --> URI Class Initialized
DEBUG - 2021-12-12 03:05:01 --> No URI present. Default controller set.
INFO - 2021-12-12 03:05:01 --> Router Class Initialized
INFO - 2021-12-12 03:05:01 --> Output Class Initialized
INFO - 2021-12-12 03:05:01 --> Security Class Initialized
DEBUG - 2021-12-12 03:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 03:05:01 --> Input Class Initialized
INFO - 2021-12-12 03:05:01 --> Language Class Initialized
INFO - 2021-12-12 03:05:01 --> Loader Class Initialized
INFO - 2021-12-12 03:05:01 --> Helper loaded: url_helper
INFO - 2021-12-12 03:05:01 --> Helper loaded: form_helper
INFO - 2021-12-12 03:05:01 --> Helper loaded: common_helper
INFO - 2021-12-12 03:05:01 --> Database Driver Class Initialized
DEBUG - 2021-12-12 03:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 03:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 03:05:01 --> Controller Class Initialized
INFO - 2021-12-12 03:05:01 --> Form Validation Class Initialized
DEBUG - 2021-12-12 03:05:01 --> Encrypt Class Initialized
DEBUG - 2021-12-12 03:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 03:05:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 03:05:01 --> Email Class Initialized
INFO - 2021-12-12 03:05:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 03:05:01 --> Calendar Class Initialized
INFO - 2021-12-12 03:05:01 --> Model "Login_model" initialized
INFO - 2021-12-12 03:05:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 03:05:01 --> Final output sent to browser
DEBUG - 2021-12-12 03:05:01 --> Total execution time: 0.0244
ERROR - 2021-12-12 06:03:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 06:03:16 --> Config Class Initialized
INFO - 2021-12-12 06:03:16 --> Hooks Class Initialized
DEBUG - 2021-12-12 06:03:16 --> UTF-8 Support Enabled
INFO - 2021-12-12 06:03:16 --> Utf8 Class Initialized
INFO - 2021-12-12 06:03:16 --> URI Class Initialized
DEBUG - 2021-12-12 06:03:16 --> No URI present. Default controller set.
INFO - 2021-12-12 06:03:16 --> Router Class Initialized
INFO - 2021-12-12 06:03:16 --> Output Class Initialized
INFO - 2021-12-12 06:03:16 --> Security Class Initialized
DEBUG - 2021-12-12 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 06:03:16 --> Input Class Initialized
INFO - 2021-12-12 06:03:16 --> Language Class Initialized
INFO - 2021-12-12 06:03:16 --> Loader Class Initialized
INFO - 2021-12-12 06:03:16 --> Helper loaded: url_helper
INFO - 2021-12-12 06:03:16 --> Helper loaded: form_helper
INFO - 2021-12-12 06:03:16 --> Helper loaded: common_helper
INFO - 2021-12-12 06:03:16 --> Database Driver Class Initialized
DEBUG - 2021-12-12 06:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 06:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 06:03:16 --> Controller Class Initialized
INFO - 2021-12-12 06:03:16 --> Form Validation Class Initialized
DEBUG - 2021-12-12 06:03:16 --> Encrypt Class Initialized
DEBUG - 2021-12-12 06:03:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 06:03:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 06:03:16 --> Email Class Initialized
INFO - 2021-12-12 06:03:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 06:03:16 --> Calendar Class Initialized
INFO - 2021-12-12 06:03:16 --> Model "Login_model" initialized
INFO - 2021-12-12 06:03:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 06:03:16 --> Final output sent to browser
DEBUG - 2021-12-12 06:03:16 --> Total execution time: 0.0534
ERROR - 2021-12-12 08:11:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 08:11:01 --> Config Class Initialized
INFO - 2021-12-12 08:11:01 --> Hooks Class Initialized
DEBUG - 2021-12-12 08:11:01 --> UTF-8 Support Enabled
INFO - 2021-12-12 08:11:01 --> Utf8 Class Initialized
INFO - 2021-12-12 08:11:01 --> URI Class Initialized
DEBUG - 2021-12-12 08:11:01 --> No URI present. Default controller set.
INFO - 2021-12-12 08:11:01 --> Router Class Initialized
INFO - 2021-12-12 08:11:01 --> Output Class Initialized
INFO - 2021-12-12 08:11:01 --> Security Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 08:11:01 --> Input Class Initialized
INFO - 2021-12-12 08:11:01 --> Language Class Initialized
INFO - 2021-12-12 08:11:01 --> Loader Class Initialized
INFO - 2021-12-12 08:11:01 --> Helper loaded: url_helper
INFO - 2021-12-12 08:11:01 --> Helper loaded: form_helper
INFO - 2021-12-12 08:11:01 --> Helper loaded: common_helper
INFO - 2021-12-12 08:11:01 --> Database Driver Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 08:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 08:11:01 --> Controller Class Initialized
INFO - 2021-12-12 08:11:01 --> Form Validation Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Encrypt Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 08:11:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 08:11:01 --> Email Class Initialized
INFO - 2021-12-12 08:11:01 --> Language file loaded: language/english/calendar_lang.php
ERROR - 2021-12-12 08:11:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-12-12 08:11:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 08:11:01 --> Calendar Class Initialized
INFO - 2021-12-12 08:11:01 --> Model "Login_model" initialized
INFO - 2021-12-12 08:11:01 --> Config Class Initialized
INFO - 2021-12-12 08:11:01 --> Hooks Class Initialized
INFO - 2021-12-12 08:11:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 08:11:01 --> Config Class Initialized
INFO - 2021-12-12 08:11:01 --> Hooks Class Initialized
INFO - 2021-12-12 08:11:01 --> Final output sent to browser
DEBUG - 2021-12-12 08:11:01 --> Total execution time: 0.0936
DEBUG - 2021-12-12 08:11:01 --> UTF-8 Support Enabled
INFO - 2021-12-12 08:11:01 --> Utf8 Class Initialized
DEBUG - 2021-12-12 08:11:01 --> UTF-8 Support Enabled
INFO - 2021-12-12 08:11:01 --> Utf8 Class Initialized
INFO - 2021-12-12 08:11:01 --> URI Class Initialized
INFO - 2021-12-12 08:11:01 --> URI Class Initialized
DEBUG - 2021-12-12 08:11:01 --> No URI present. Default controller set.
INFO - 2021-12-12 08:11:01 --> Router Class Initialized
DEBUG - 2021-12-12 08:11:01 --> No URI present. Default controller set.
INFO - 2021-12-12 08:11:01 --> Router Class Initialized
INFO - 2021-12-12 08:11:01 --> Output Class Initialized
INFO - 2021-12-12 08:11:01 --> Output Class Initialized
INFO - 2021-12-12 08:11:01 --> Security Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 08:11:01 --> Input Class Initialized
INFO - 2021-12-12 08:11:01 --> Language Class Initialized
INFO - 2021-12-12 08:11:01 --> Security Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 08:11:01 --> Loader Class Initialized
INFO - 2021-12-12 08:11:01 --> Input Class Initialized
INFO - 2021-12-12 08:11:01 --> Language Class Initialized
INFO - 2021-12-12 08:11:01 --> Helper loaded: url_helper
INFO - 2021-12-12 08:11:01 --> Helper loaded: form_helper
INFO - 2021-12-12 08:11:01 --> Helper loaded: common_helper
INFO - 2021-12-12 08:11:01 --> Loader Class Initialized
INFO - 2021-12-12 08:11:01 --> Helper loaded: url_helper
INFO - 2021-12-12 08:11:01 --> Helper loaded: form_helper
INFO - 2021-12-12 08:11:01 --> Helper loaded: common_helper
INFO - 2021-12-12 08:11:01 --> Database Driver Class Initialized
INFO - 2021-12-12 08:11:01 --> Database Driver Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-12 08:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 08:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 08:11:01 --> Controller Class Initialized
INFO - 2021-12-12 08:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 08:11:01 --> Controller Class Initialized
INFO - 2021-12-12 08:11:01 --> Form Validation Class Initialized
INFO - 2021-12-12 08:11:01 --> Form Validation Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Encrypt Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 08:11:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 08:11:01 --> Encrypt Class Initialized
DEBUG - 2021-12-12 08:11:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 08:11:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 08:11:01 --> Email Class Initialized
INFO - 2021-12-12 08:11:01 --> Email Class Initialized
INFO - 2021-12-12 08:11:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 08:11:01 --> Calendar Class Initialized
INFO - 2021-12-12 08:11:01 --> Model "Login_model" initialized
INFO - 2021-12-12 08:11:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 08:11:01 --> Calendar Class Initialized
INFO - 2021-12-12 08:11:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 08:11:01 --> Model "Login_model" initialized
INFO - 2021-12-12 08:11:01 --> Final output sent to browser
DEBUG - 2021-12-12 08:11:01 --> Total execution time: 0.0988
INFO - 2021-12-12 08:11:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 08:11:01 --> Final output sent to browser
DEBUG - 2021-12-12 08:11:01 --> Total execution time: 0.0993
ERROR - 2021-12-12 08:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 08:15:08 --> Config Class Initialized
INFO - 2021-12-12 08:15:08 --> Hooks Class Initialized
DEBUG - 2021-12-12 08:15:08 --> UTF-8 Support Enabled
INFO - 2021-12-12 08:15:08 --> Utf8 Class Initialized
INFO - 2021-12-12 08:15:08 --> URI Class Initialized
DEBUG - 2021-12-12 08:15:08 --> No URI present. Default controller set.
INFO - 2021-12-12 08:15:08 --> Router Class Initialized
INFO - 2021-12-12 08:15:08 --> Output Class Initialized
INFO - 2021-12-12 08:15:08 --> Security Class Initialized
DEBUG - 2021-12-12 08:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 08:15:08 --> Input Class Initialized
INFO - 2021-12-12 08:15:08 --> Language Class Initialized
INFO - 2021-12-12 08:15:08 --> Loader Class Initialized
INFO - 2021-12-12 08:15:08 --> Helper loaded: url_helper
INFO - 2021-12-12 08:15:08 --> Helper loaded: form_helper
INFO - 2021-12-12 08:15:08 --> Helper loaded: common_helper
INFO - 2021-12-12 08:15:08 --> Database Driver Class Initialized
DEBUG - 2021-12-12 08:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 08:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 08:15:08 --> Controller Class Initialized
INFO - 2021-12-12 08:15:08 --> Form Validation Class Initialized
DEBUG - 2021-12-12 08:15:08 --> Encrypt Class Initialized
DEBUG - 2021-12-12 08:15:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 08:15:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 08:15:08 --> Email Class Initialized
INFO - 2021-12-12 08:15:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 08:15:08 --> Calendar Class Initialized
INFO - 2021-12-12 08:15:08 --> Model "Login_model" initialized
INFO - 2021-12-12 08:15:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 08:15:08 --> Final output sent to browser
DEBUG - 2021-12-12 08:15:08 --> Total execution time: 0.0316
ERROR - 2021-12-12 09:50:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 09:50:42 --> Config Class Initialized
INFO - 2021-12-12 09:50:42 --> Hooks Class Initialized
DEBUG - 2021-12-12 09:50:42 --> UTF-8 Support Enabled
INFO - 2021-12-12 09:50:42 --> Utf8 Class Initialized
INFO - 2021-12-12 09:50:42 --> URI Class Initialized
DEBUG - 2021-12-12 09:50:42 --> No URI present. Default controller set.
INFO - 2021-12-12 09:50:42 --> Router Class Initialized
INFO - 2021-12-12 09:50:42 --> Output Class Initialized
INFO - 2021-12-12 09:50:42 --> Security Class Initialized
DEBUG - 2021-12-12 09:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 09:50:42 --> Input Class Initialized
INFO - 2021-12-12 09:50:42 --> Language Class Initialized
INFO - 2021-12-12 09:50:42 --> Loader Class Initialized
INFO - 2021-12-12 09:50:42 --> Helper loaded: url_helper
INFO - 2021-12-12 09:50:42 --> Helper loaded: form_helper
INFO - 2021-12-12 09:50:42 --> Helper loaded: common_helper
INFO - 2021-12-12 09:50:42 --> Database Driver Class Initialized
DEBUG - 2021-12-12 09:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 09:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 09:50:42 --> Controller Class Initialized
INFO - 2021-12-12 09:50:42 --> Form Validation Class Initialized
DEBUG - 2021-12-12 09:50:42 --> Encrypt Class Initialized
DEBUG - 2021-12-12 09:50:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 09:50:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 09:50:42 --> Email Class Initialized
INFO - 2021-12-12 09:50:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 09:50:42 --> Calendar Class Initialized
INFO - 2021-12-12 09:50:42 --> Model "Login_model" initialized
INFO - 2021-12-12 09:50:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 09:50:42 --> Final output sent to browser
DEBUG - 2021-12-12 09:50:42 --> Total execution time: 0.0254
ERROR - 2021-12-12 13:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 13:10:49 --> Config Class Initialized
INFO - 2021-12-12 13:10:49 --> Hooks Class Initialized
DEBUG - 2021-12-12 13:10:49 --> UTF-8 Support Enabled
INFO - 2021-12-12 13:10:49 --> Utf8 Class Initialized
INFO - 2021-12-12 13:10:49 --> URI Class Initialized
DEBUG - 2021-12-12 13:10:49 --> No URI present. Default controller set.
INFO - 2021-12-12 13:10:49 --> Router Class Initialized
INFO - 2021-12-12 13:10:49 --> Output Class Initialized
INFO - 2021-12-12 13:10:49 --> Security Class Initialized
DEBUG - 2021-12-12 13:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 13:10:49 --> Input Class Initialized
INFO - 2021-12-12 13:10:49 --> Language Class Initialized
INFO - 2021-12-12 13:10:49 --> Loader Class Initialized
INFO - 2021-12-12 13:10:49 --> Helper loaded: url_helper
INFO - 2021-12-12 13:10:49 --> Helper loaded: form_helper
INFO - 2021-12-12 13:10:49 --> Helper loaded: common_helper
INFO - 2021-12-12 13:10:49 --> Database Driver Class Initialized
DEBUG - 2021-12-12 13:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 13:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 13:10:49 --> Controller Class Initialized
INFO - 2021-12-12 13:10:49 --> Form Validation Class Initialized
DEBUG - 2021-12-12 13:10:49 --> Encrypt Class Initialized
DEBUG - 2021-12-12 13:10:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 13:10:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 13:10:49 --> Email Class Initialized
INFO - 2021-12-12 13:10:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 13:10:49 --> Calendar Class Initialized
INFO - 2021-12-12 13:10:49 --> Model "Login_model" initialized
INFO - 2021-12-12 13:10:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 13:10:49 --> Final output sent to browser
DEBUG - 2021-12-12 13:10:49 --> Total execution time: 0.0236
ERROR - 2021-12-12 14:24:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:24:47 --> Config Class Initialized
INFO - 2021-12-12 14:24:47 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:24:47 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:24:47 --> Utf8 Class Initialized
INFO - 2021-12-12 14:24:47 --> URI Class Initialized
DEBUG - 2021-12-12 14:24:47 --> No URI present. Default controller set.
INFO - 2021-12-12 14:24:47 --> Router Class Initialized
INFO - 2021-12-12 14:24:47 --> Output Class Initialized
INFO - 2021-12-12 14:24:47 --> Security Class Initialized
DEBUG - 2021-12-12 14:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:24:47 --> Input Class Initialized
INFO - 2021-12-12 14:24:47 --> Language Class Initialized
INFO - 2021-12-12 14:24:47 --> Loader Class Initialized
INFO - 2021-12-12 14:24:47 --> Helper loaded: url_helper
INFO - 2021-12-12 14:24:47 --> Helper loaded: form_helper
INFO - 2021-12-12 14:24:47 --> Helper loaded: common_helper
INFO - 2021-12-12 14:24:47 --> Database Driver Class Initialized
DEBUG - 2021-12-12 14:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 14:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 14:24:48 --> Controller Class Initialized
INFO - 2021-12-12 14:24:48 --> Form Validation Class Initialized
DEBUG - 2021-12-12 14:24:48 --> Encrypt Class Initialized
DEBUG - 2021-12-12 14:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 14:24:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 14:24:48 --> Email Class Initialized
INFO - 2021-12-12 14:24:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 14:24:48 --> Calendar Class Initialized
INFO - 2021-12-12 14:24:48 --> Model "Login_model" initialized
INFO - 2021-12-12 14:24:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 14:24:48 --> Final output sent to browser
DEBUG - 2021-12-12 14:24:48 --> Total execution time: 0.0841
ERROR - 2021-12-12 14:24:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:24:48 --> Config Class Initialized
INFO - 2021-12-12 14:24:48 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:24:48 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:24:48 --> Utf8 Class Initialized
INFO - 2021-12-12 14:24:48 --> URI Class Initialized
INFO - 2021-12-12 14:24:48 --> Router Class Initialized
INFO - 2021-12-12 14:24:48 --> Output Class Initialized
INFO - 2021-12-12 14:24:48 --> Security Class Initialized
DEBUG - 2021-12-12 14:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:24:48 --> Input Class Initialized
INFO - 2021-12-12 14:24:48 --> Language Class Initialized
ERROR - 2021-12-12 14:24:48 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-12 14:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:24:56 --> Config Class Initialized
INFO - 2021-12-12 14:24:56 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:24:56 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:24:56 --> Utf8 Class Initialized
INFO - 2021-12-12 14:24:56 --> URI Class Initialized
DEBUG - 2021-12-12 14:24:56 --> No URI present. Default controller set.
INFO - 2021-12-12 14:24:56 --> Router Class Initialized
INFO - 2021-12-12 14:24:56 --> Output Class Initialized
INFO - 2021-12-12 14:24:56 --> Security Class Initialized
DEBUG - 2021-12-12 14:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:24:56 --> Input Class Initialized
INFO - 2021-12-12 14:24:56 --> Language Class Initialized
INFO - 2021-12-12 14:24:56 --> Loader Class Initialized
INFO - 2021-12-12 14:24:56 --> Helper loaded: url_helper
INFO - 2021-12-12 14:24:56 --> Helper loaded: form_helper
INFO - 2021-12-12 14:24:56 --> Helper loaded: common_helper
INFO - 2021-12-12 14:24:56 --> Database Driver Class Initialized
DEBUG - 2021-12-12 14:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 14:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 14:24:56 --> Controller Class Initialized
INFO - 2021-12-12 14:24:56 --> Form Validation Class Initialized
DEBUG - 2021-12-12 14:24:56 --> Encrypt Class Initialized
DEBUG - 2021-12-12 14:24:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 14:24:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 14:24:56 --> Email Class Initialized
INFO - 2021-12-12 14:24:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 14:24:56 --> Calendar Class Initialized
INFO - 2021-12-12 14:24:56 --> Model "Login_model" initialized
INFO - 2021-12-12 14:24:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 14:24:56 --> Final output sent to browser
DEBUG - 2021-12-12 14:24:56 --> Total execution time: 0.0335
ERROR - 2021-12-12 14:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:24:56 --> Config Class Initialized
INFO - 2021-12-12 14:24:56 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:24:56 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:24:56 --> Utf8 Class Initialized
INFO - 2021-12-12 14:24:56 --> URI Class Initialized
INFO - 2021-12-12 14:24:56 --> Router Class Initialized
INFO - 2021-12-12 14:24:56 --> Output Class Initialized
INFO - 2021-12-12 14:24:56 --> Security Class Initialized
DEBUG - 2021-12-12 14:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:24:56 --> Input Class Initialized
INFO - 2021-12-12 14:24:56 --> Language Class Initialized
INFO - 2021-12-12 14:24:56 --> Loader Class Initialized
INFO - 2021-12-12 14:24:56 --> Helper loaded: url_helper
INFO - 2021-12-12 14:24:56 --> Helper loaded: form_helper
INFO - 2021-12-12 14:24:56 --> Helper loaded: common_helper
INFO - 2021-12-12 14:24:56 --> Database Driver Class Initialized
DEBUG - 2021-12-12 14:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 14:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 14:24:56 --> Controller Class Initialized
INFO - 2021-12-12 14:24:56 --> Form Validation Class Initialized
DEBUG - 2021-12-12 14:24:56 --> Encrypt Class Initialized
DEBUG - 2021-12-12 14:24:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 14:24:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 14:24:56 --> Email Class Initialized
INFO - 2021-12-12 14:24:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 14:24:56 --> Calendar Class Initialized
INFO - 2021-12-12 14:24:56 --> Model "Login_model" initialized
INFO - 2021-12-12 14:24:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 14:24:56 --> Final output sent to browser
DEBUG - 2021-12-12 14:24:56 --> Total execution time: 0.0224
ERROR - 2021-12-12 14:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:24:57 --> Config Class Initialized
INFO - 2021-12-12 14:24:57 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:24:57 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:24:57 --> Utf8 Class Initialized
INFO - 2021-12-12 14:24:57 --> URI Class Initialized
INFO - 2021-12-12 14:24:57 --> Router Class Initialized
INFO - 2021-12-12 14:24:57 --> Output Class Initialized
INFO - 2021-12-12 14:24:57 --> Security Class Initialized
DEBUG - 2021-12-12 14:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:24:57 --> Input Class Initialized
INFO - 2021-12-12 14:24:57 --> Language Class Initialized
INFO - 2021-12-12 14:24:57 --> Loader Class Initialized
INFO - 2021-12-12 14:24:57 --> Helper loaded: url_helper
INFO - 2021-12-12 14:24:57 --> Helper loaded: form_helper
INFO - 2021-12-12 14:24:57 --> Helper loaded: common_helper
INFO - 2021-12-12 14:24:57 --> Database Driver Class Initialized
DEBUG - 2021-12-12 14:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 14:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 14:24:57 --> Controller Class Initialized
INFO - 2021-12-12 14:24:57 --> Form Validation Class Initialized
DEBUG - 2021-12-12 14:24:57 --> Encrypt Class Initialized
DEBUG - 2021-12-12 14:24:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 14:24:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 14:24:57 --> Email Class Initialized
INFO - 2021-12-12 14:24:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 14:24:57 --> Calendar Class Initialized
INFO - 2021-12-12 14:24:57 --> Model "Login_model" initialized
ERROR - 2021-12-12 14:24:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:24:58 --> Config Class Initialized
INFO - 2021-12-12 14:24:58 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:24:58 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:24:58 --> Utf8 Class Initialized
INFO - 2021-12-12 14:24:58 --> URI Class Initialized
INFO - 2021-12-12 14:24:58 --> Router Class Initialized
INFO - 2021-12-12 14:24:58 --> Output Class Initialized
INFO - 2021-12-12 14:24:58 --> Security Class Initialized
DEBUG - 2021-12-12 14:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:24:58 --> Input Class Initialized
INFO - 2021-12-12 14:24:58 --> Language Class Initialized
INFO - 2021-12-12 14:24:58 --> Loader Class Initialized
INFO - 2021-12-12 14:24:58 --> Helper loaded: url_helper
INFO - 2021-12-12 14:24:58 --> Helper loaded: form_helper
INFO - 2021-12-12 14:24:58 --> Helper loaded: common_helper
INFO - 2021-12-12 14:24:58 --> Database Driver Class Initialized
DEBUG - 2021-12-12 14:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 14:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 14:24:58 --> Controller Class Initialized
INFO - 2021-12-12 14:24:58 --> Form Validation Class Initialized
DEBUG - 2021-12-12 14:24:58 --> Encrypt Class Initialized
DEBUG - 2021-12-12 14:24:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 14:24:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 14:24:58 --> Email Class Initialized
INFO - 2021-12-12 14:24:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 14:24:58 --> Calendar Class Initialized
INFO - 2021-12-12 14:24:58 --> Model "Login_model" initialized
ERROR - 2021-12-12 14:55:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:17 --> Config Class Initialized
INFO - 2021-12-12 14:55:17 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:17 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:17 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:17 --> URI Class Initialized
DEBUG - 2021-12-12 14:55:17 --> No URI present. Default controller set.
INFO - 2021-12-12 14:55:17 --> Router Class Initialized
INFO - 2021-12-12 14:55:17 --> Output Class Initialized
INFO - 2021-12-12 14:55:17 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:17 --> Input Class Initialized
INFO - 2021-12-12 14:55:17 --> Language Class Initialized
INFO - 2021-12-12 14:55:17 --> Loader Class Initialized
INFO - 2021-12-12 14:55:17 --> Helper loaded: url_helper
INFO - 2021-12-12 14:55:17 --> Helper loaded: form_helper
INFO - 2021-12-12 14:55:17 --> Helper loaded: common_helper
INFO - 2021-12-12 14:55:17 --> Database Driver Class Initialized
DEBUG - 2021-12-12 14:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 14:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 14:55:17 --> Controller Class Initialized
INFO - 2021-12-12 14:55:17 --> Form Validation Class Initialized
DEBUG - 2021-12-12 14:55:17 --> Encrypt Class Initialized
DEBUG - 2021-12-12 14:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 14:55:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 14:55:17 --> Email Class Initialized
INFO - 2021-12-12 14:55:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 14:55:17 --> Calendar Class Initialized
INFO - 2021-12-12 14:55:17 --> Model "Login_model" initialized
INFO - 2021-12-12 14:55:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 14:55:17 --> Final output sent to browser
DEBUG - 2021-12-12 14:55:17 --> Total execution time: 0.1576
ERROR - 2021-12-12 14:55:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:18 --> Config Class Initialized
INFO - 2021-12-12 14:55:18 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:18 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:18 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:18 --> URI Class Initialized
DEBUG - 2021-12-12 14:55:18 --> No URI present. Default controller set.
INFO - 2021-12-12 14:55:18 --> Router Class Initialized
INFO - 2021-12-12 14:55:18 --> Output Class Initialized
INFO - 2021-12-12 14:55:18 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:18 --> Input Class Initialized
INFO - 2021-12-12 14:55:18 --> Language Class Initialized
INFO - 2021-12-12 14:55:18 --> Loader Class Initialized
INFO - 2021-12-12 14:55:18 --> Helper loaded: url_helper
INFO - 2021-12-12 14:55:18 --> Helper loaded: form_helper
INFO - 2021-12-12 14:55:18 --> Helper loaded: common_helper
INFO - 2021-12-12 14:55:18 --> Database Driver Class Initialized
DEBUG - 2021-12-12 14:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 14:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 14:55:18 --> Controller Class Initialized
INFO - 2021-12-12 14:55:18 --> Form Validation Class Initialized
DEBUG - 2021-12-12 14:55:18 --> Encrypt Class Initialized
DEBUG - 2021-12-12 14:55:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 14:55:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 14:55:18 --> Email Class Initialized
INFO - 2021-12-12 14:55:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 14:55:18 --> Calendar Class Initialized
INFO - 2021-12-12 14:55:18 --> Model "Login_model" initialized
INFO - 2021-12-12 14:55:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 14:55:18 --> Final output sent to browser
DEBUG - 2021-12-12 14:55:18 --> Total execution time: 0.1114
ERROR - 2021-12-12 14:55:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:19 --> Config Class Initialized
INFO - 2021-12-12 14:55:19 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:19 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:19 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:19 --> URI Class Initialized
INFO - 2021-12-12 14:55:19 --> Router Class Initialized
INFO - 2021-12-12 14:55:19 --> Output Class Initialized
INFO - 2021-12-12 14:55:19 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:19 --> Input Class Initialized
INFO - 2021-12-12 14:55:19 --> Language Class Initialized
ERROR - 2021-12-12 14:55:19 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-12 14:55:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:19 --> Config Class Initialized
INFO - 2021-12-12 14:55:19 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:19 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:19 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:19 --> URI Class Initialized
INFO - 2021-12-12 14:55:19 --> Router Class Initialized
INFO - 2021-12-12 14:55:19 --> Output Class Initialized
INFO - 2021-12-12 14:55:19 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:19 --> Input Class Initialized
INFO - 2021-12-12 14:55:19 --> Language Class Initialized
ERROR - 2021-12-12 14:55:19 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-12 14:55:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:20 --> Config Class Initialized
INFO - 2021-12-12 14:55:20 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:20 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:20 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:20 --> URI Class Initialized
INFO - 2021-12-12 14:55:20 --> Router Class Initialized
INFO - 2021-12-12 14:55:20 --> Output Class Initialized
INFO - 2021-12-12 14:55:20 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:20 --> Input Class Initialized
INFO - 2021-12-12 14:55:20 --> Language Class Initialized
ERROR - 2021-12-12 14:55:20 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-12 14:55:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:20 --> Config Class Initialized
INFO - 2021-12-12 14:55:20 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:20 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:20 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:20 --> URI Class Initialized
INFO - 2021-12-12 14:55:20 --> Router Class Initialized
INFO - 2021-12-12 14:55:20 --> Output Class Initialized
INFO - 2021-12-12 14:55:20 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:20 --> Input Class Initialized
INFO - 2021-12-12 14:55:20 --> Language Class Initialized
ERROR - 2021-12-12 14:55:20 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-12 14:55:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:21 --> Config Class Initialized
INFO - 2021-12-12 14:55:21 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:21 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:21 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:21 --> URI Class Initialized
INFO - 2021-12-12 14:55:21 --> Router Class Initialized
INFO - 2021-12-12 14:55:21 --> Output Class Initialized
INFO - 2021-12-12 14:55:21 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:21 --> Input Class Initialized
INFO - 2021-12-12 14:55:21 --> Language Class Initialized
ERROR - 2021-12-12 14:55:21 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-12 14:55:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:21 --> Config Class Initialized
INFO - 2021-12-12 14:55:21 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:21 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:21 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:21 --> URI Class Initialized
INFO - 2021-12-12 14:55:21 --> Router Class Initialized
INFO - 2021-12-12 14:55:21 --> Output Class Initialized
INFO - 2021-12-12 14:55:21 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:21 --> Input Class Initialized
INFO - 2021-12-12 14:55:21 --> Language Class Initialized
ERROR - 2021-12-12 14:55:21 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-12 14:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:22 --> Config Class Initialized
INFO - 2021-12-12 14:55:22 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:22 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:22 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:22 --> URI Class Initialized
INFO - 2021-12-12 14:55:22 --> Router Class Initialized
INFO - 2021-12-12 14:55:22 --> Output Class Initialized
INFO - 2021-12-12 14:55:22 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:22 --> Input Class Initialized
INFO - 2021-12-12 14:55:22 --> Language Class Initialized
ERROR - 2021-12-12 14:55:22 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-12 14:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:22 --> Config Class Initialized
INFO - 2021-12-12 14:55:22 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:22 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:22 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:22 --> URI Class Initialized
INFO - 2021-12-12 14:55:22 --> Router Class Initialized
INFO - 2021-12-12 14:55:22 --> Output Class Initialized
INFO - 2021-12-12 14:55:22 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:22 --> Input Class Initialized
INFO - 2021-12-12 14:55:22 --> Language Class Initialized
ERROR - 2021-12-12 14:55:22 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-12-12 14:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:23 --> Config Class Initialized
INFO - 2021-12-12 14:55:23 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:23 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:23 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:23 --> URI Class Initialized
INFO - 2021-12-12 14:55:23 --> Router Class Initialized
INFO - 2021-12-12 14:55:23 --> Output Class Initialized
INFO - 2021-12-12 14:55:23 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:23 --> Input Class Initialized
INFO - 2021-12-12 14:55:23 --> Language Class Initialized
ERROR - 2021-12-12 14:55:23 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-12 14:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:23 --> Config Class Initialized
INFO - 2021-12-12 14:55:23 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:23 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:23 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:23 --> URI Class Initialized
INFO - 2021-12-12 14:55:23 --> Router Class Initialized
INFO - 2021-12-12 14:55:23 --> Output Class Initialized
INFO - 2021-12-12 14:55:23 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:23 --> Input Class Initialized
INFO - 2021-12-12 14:55:23 --> Language Class Initialized
ERROR - 2021-12-12 14:55:23 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-12 14:55:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:24 --> Config Class Initialized
INFO - 2021-12-12 14:55:24 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:24 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:24 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:24 --> URI Class Initialized
INFO - 2021-12-12 14:55:24 --> Router Class Initialized
INFO - 2021-12-12 14:55:24 --> Output Class Initialized
INFO - 2021-12-12 14:55:24 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:24 --> Input Class Initialized
INFO - 2021-12-12 14:55:24 --> Language Class Initialized
ERROR - 2021-12-12 14:55:24 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-12 14:55:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:24 --> Config Class Initialized
INFO - 2021-12-12 14:55:24 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:24 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:24 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:24 --> URI Class Initialized
INFO - 2021-12-12 14:55:24 --> Router Class Initialized
INFO - 2021-12-12 14:55:24 --> Output Class Initialized
INFO - 2021-12-12 14:55:24 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:24 --> Input Class Initialized
INFO - 2021-12-12 14:55:24 --> Language Class Initialized
ERROR - 2021-12-12 14:55:24 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-12 14:55:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:25 --> Config Class Initialized
INFO - 2021-12-12 14:55:25 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:25 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:25 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:25 --> URI Class Initialized
INFO - 2021-12-12 14:55:25 --> Router Class Initialized
INFO - 2021-12-12 14:55:25 --> Output Class Initialized
INFO - 2021-12-12 14:55:25 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:25 --> Input Class Initialized
INFO - 2021-12-12 14:55:25 --> Language Class Initialized
ERROR - 2021-12-12 14:55:25 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-12-12 14:55:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:25 --> Config Class Initialized
INFO - 2021-12-12 14:55:25 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:25 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:25 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:25 --> URI Class Initialized
INFO - 2021-12-12 14:55:25 --> Router Class Initialized
INFO - 2021-12-12 14:55:25 --> Output Class Initialized
INFO - 2021-12-12 14:55:25 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:25 --> Input Class Initialized
INFO - 2021-12-12 14:55:25 --> Language Class Initialized
ERROR - 2021-12-12 14:55:25 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-12 14:55:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:26 --> Config Class Initialized
INFO - 2021-12-12 14:55:26 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:26 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:26 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:26 --> URI Class Initialized
INFO - 2021-12-12 14:55:26 --> Router Class Initialized
INFO - 2021-12-12 14:55:26 --> Output Class Initialized
INFO - 2021-12-12 14:55:26 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:26 --> Input Class Initialized
INFO - 2021-12-12 14:55:26 --> Language Class Initialized
ERROR - 2021-12-12 14:55:26 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-12 14:55:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:26 --> Config Class Initialized
INFO - 2021-12-12 14:55:26 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:26 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:26 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:26 --> URI Class Initialized
INFO - 2021-12-12 14:55:26 --> Router Class Initialized
INFO - 2021-12-12 14:55:26 --> Output Class Initialized
INFO - 2021-12-12 14:55:26 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:26 --> Input Class Initialized
INFO - 2021-12-12 14:55:26 --> Language Class Initialized
ERROR - 2021-12-12 14:55:26 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-12 14:55:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:55:27 --> Config Class Initialized
INFO - 2021-12-12 14:55:27 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:55:27 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:55:27 --> Utf8 Class Initialized
INFO - 2021-12-12 14:55:27 --> URI Class Initialized
INFO - 2021-12-12 14:55:27 --> Router Class Initialized
INFO - 2021-12-12 14:55:27 --> Output Class Initialized
INFO - 2021-12-12 14:55:27 --> Security Class Initialized
DEBUG - 2021-12-12 14:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:55:27 --> Input Class Initialized
INFO - 2021-12-12 14:55:27 --> Language Class Initialized
ERROR - 2021-12-12 14:55:27 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-12 14:57:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 14:57:39 --> Config Class Initialized
INFO - 2021-12-12 14:57:39 --> Hooks Class Initialized
DEBUG - 2021-12-12 14:57:39 --> UTF-8 Support Enabled
INFO - 2021-12-12 14:57:39 --> Utf8 Class Initialized
INFO - 2021-12-12 14:57:39 --> URI Class Initialized
DEBUG - 2021-12-12 14:57:39 --> No URI present. Default controller set.
INFO - 2021-12-12 14:57:39 --> Router Class Initialized
INFO - 2021-12-12 14:57:39 --> Output Class Initialized
INFO - 2021-12-12 14:57:39 --> Security Class Initialized
DEBUG - 2021-12-12 14:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 14:57:39 --> Input Class Initialized
INFO - 2021-12-12 14:57:39 --> Language Class Initialized
INFO - 2021-12-12 14:57:39 --> Loader Class Initialized
INFO - 2021-12-12 14:57:39 --> Helper loaded: url_helper
INFO - 2021-12-12 14:57:39 --> Helper loaded: form_helper
INFO - 2021-12-12 14:57:39 --> Helper loaded: common_helper
INFO - 2021-12-12 14:57:39 --> Database Driver Class Initialized
DEBUG - 2021-12-12 14:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 14:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 14:57:39 --> Controller Class Initialized
INFO - 2021-12-12 14:57:39 --> Form Validation Class Initialized
DEBUG - 2021-12-12 14:57:39 --> Encrypt Class Initialized
DEBUG - 2021-12-12 14:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 14:57:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 14:57:39 --> Email Class Initialized
INFO - 2021-12-12 14:57:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 14:57:39 --> Calendar Class Initialized
INFO - 2021-12-12 14:57:39 --> Model "Login_model" initialized
INFO - 2021-12-12 14:57:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 14:57:39 --> Final output sent to browser
DEBUG - 2021-12-12 14:57:39 --> Total execution time: 0.0226
ERROR - 2021-12-12 20:25:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 20:25:21 --> Config Class Initialized
INFO - 2021-12-12 20:25:21 --> Hooks Class Initialized
DEBUG - 2021-12-12 20:25:21 --> UTF-8 Support Enabled
INFO - 2021-12-12 20:25:21 --> Utf8 Class Initialized
INFO - 2021-12-12 20:25:21 --> URI Class Initialized
DEBUG - 2021-12-12 20:25:21 --> No URI present. Default controller set.
INFO - 2021-12-12 20:25:21 --> Router Class Initialized
INFO - 2021-12-12 20:25:21 --> Output Class Initialized
INFO - 2021-12-12 20:25:21 --> Security Class Initialized
DEBUG - 2021-12-12 20:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 20:25:21 --> Input Class Initialized
INFO - 2021-12-12 20:25:21 --> Language Class Initialized
INFO - 2021-12-12 20:25:21 --> Loader Class Initialized
INFO - 2021-12-12 20:25:21 --> Helper loaded: url_helper
INFO - 2021-12-12 20:25:21 --> Helper loaded: form_helper
INFO - 2021-12-12 20:25:21 --> Helper loaded: common_helper
INFO - 2021-12-12 20:25:21 --> Database Driver Class Initialized
DEBUG - 2021-12-12 20:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 20:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 20:25:21 --> Controller Class Initialized
INFO - 2021-12-12 20:25:21 --> Form Validation Class Initialized
DEBUG - 2021-12-12 20:25:21 --> Encrypt Class Initialized
DEBUG - 2021-12-12 20:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 20:25:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 20:25:21 --> Email Class Initialized
INFO - 2021-12-12 20:25:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 20:25:21 --> Calendar Class Initialized
INFO - 2021-12-12 20:25:21 --> Model "Login_model" initialized
INFO - 2021-12-12 20:25:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 20:25:21 --> Final output sent to browser
DEBUG - 2021-12-12 20:25:21 --> Total execution time: 0.0372
ERROR - 2021-12-12 22:55:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-12 22:55:21 --> Config Class Initialized
INFO - 2021-12-12 22:55:21 --> Hooks Class Initialized
DEBUG - 2021-12-12 22:55:21 --> UTF-8 Support Enabled
INFO - 2021-12-12 22:55:21 --> Utf8 Class Initialized
INFO - 2021-12-12 22:55:21 --> URI Class Initialized
DEBUG - 2021-12-12 22:55:21 --> No URI present. Default controller set.
INFO - 2021-12-12 22:55:21 --> Router Class Initialized
INFO - 2021-12-12 22:55:21 --> Output Class Initialized
INFO - 2021-12-12 22:55:21 --> Security Class Initialized
DEBUG - 2021-12-12 22:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-12 22:55:22 --> Input Class Initialized
INFO - 2021-12-12 22:55:22 --> Language Class Initialized
INFO - 2021-12-12 22:55:22 --> Loader Class Initialized
INFO - 2021-12-12 22:55:22 --> Helper loaded: url_helper
INFO - 2021-12-12 22:55:22 --> Helper loaded: form_helper
INFO - 2021-12-12 22:55:22 --> Helper loaded: common_helper
INFO - 2021-12-12 22:55:22 --> Database Driver Class Initialized
DEBUG - 2021-12-12 22:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-12 22:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-12 22:55:22 --> Controller Class Initialized
INFO - 2021-12-12 22:55:22 --> Form Validation Class Initialized
DEBUG - 2021-12-12 22:55:22 --> Encrypt Class Initialized
DEBUG - 2021-12-12 22:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-12 22:55:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-12 22:55:22 --> Email Class Initialized
INFO - 2021-12-12 22:55:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-12 22:55:22 --> Calendar Class Initialized
INFO - 2021-12-12 22:55:22 --> Model "Login_model" initialized
INFO - 2021-12-12 22:55:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-12 22:55:22 --> Final output sent to browser
DEBUG - 2021-12-12 22:55:22 --> Total execution time: 0.0232
