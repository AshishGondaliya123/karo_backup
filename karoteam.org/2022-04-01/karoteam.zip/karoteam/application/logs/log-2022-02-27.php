<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-27 06:18:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:20 --> Config Class Initialized
INFO - 2022-02-27 06:18:20 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:20 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:20 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:20 --> URI Class Initialized
DEBUG - 2022-02-27 06:18:20 --> No URI present. Default controller set.
INFO - 2022-02-27 06:18:20 --> Router Class Initialized
INFO - 2022-02-27 06:18:20 --> Output Class Initialized
INFO - 2022-02-27 06:18:20 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:20 --> Input Class Initialized
INFO - 2022-02-27 06:18:20 --> Language Class Initialized
INFO - 2022-02-27 06:18:20 --> Loader Class Initialized
INFO - 2022-02-27 06:18:20 --> Helper loaded: url_helper
INFO - 2022-02-27 06:18:20 --> Helper loaded: form_helper
INFO - 2022-02-27 06:18:20 --> Helper loaded: common_helper
INFO - 2022-02-27 06:18:20 --> Database Driver Class Initialized
DEBUG - 2022-02-27 06:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 06:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 06:18:20 --> Controller Class Initialized
INFO - 2022-02-27 06:18:20 --> Form Validation Class Initialized
DEBUG - 2022-02-27 06:18:20 --> Encrypt Class Initialized
DEBUG - 2022-02-27 06:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 06:18:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 06:18:20 --> Email Class Initialized
INFO - 2022-02-27 06:18:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 06:18:20 --> Calendar Class Initialized
INFO - 2022-02-27 06:18:20 --> Model "Login_model" initialized
INFO - 2022-02-27 06:18:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 06:18:20 --> Final output sent to browser
DEBUG - 2022-02-27 06:18:20 --> Total execution time: 0.0237
ERROR - 2022-02-27 06:18:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:20 --> Config Class Initialized
INFO - 2022-02-27 06:18:20 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:20 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:20 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:20 --> URI Class Initialized
DEBUG - 2022-02-27 06:18:20 --> No URI present. Default controller set.
INFO - 2022-02-27 06:18:20 --> Router Class Initialized
INFO - 2022-02-27 06:18:20 --> Output Class Initialized
INFO - 2022-02-27 06:18:20 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:20 --> Input Class Initialized
INFO - 2022-02-27 06:18:20 --> Language Class Initialized
INFO - 2022-02-27 06:18:20 --> Loader Class Initialized
INFO - 2022-02-27 06:18:20 --> Helper loaded: url_helper
INFO - 2022-02-27 06:18:20 --> Helper loaded: form_helper
INFO - 2022-02-27 06:18:20 --> Helper loaded: common_helper
INFO - 2022-02-27 06:18:20 --> Database Driver Class Initialized
DEBUG - 2022-02-27 06:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 06:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 06:18:20 --> Controller Class Initialized
INFO - 2022-02-27 06:18:20 --> Form Validation Class Initialized
DEBUG - 2022-02-27 06:18:20 --> Encrypt Class Initialized
DEBUG - 2022-02-27 06:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 06:18:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 06:18:20 --> Email Class Initialized
INFO - 2022-02-27 06:18:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 06:18:20 --> Calendar Class Initialized
INFO - 2022-02-27 06:18:20 --> Model "Login_model" initialized
INFO - 2022-02-27 06:18:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 06:18:20 --> Final output sent to browser
DEBUG - 2022-02-27 06:18:20 --> Total execution time: 0.0248
ERROR - 2022-02-27 06:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:21 --> Config Class Initialized
INFO - 2022-02-27 06:18:21 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:21 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:21 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:21 --> URI Class Initialized
INFO - 2022-02-27 06:18:21 --> Router Class Initialized
INFO - 2022-02-27 06:18:21 --> Output Class Initialized
INFO - 2022-02-27 06:18:21 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:21 --> Input Class Initialized
INFO - 2022-02-27 06:18:21 --> Language Class Initialized
ERROR - 2022-02-27 06:18:21 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-27 06:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:21 --> Config Class Initialized
INFO - 2022-02-27 06:18:21 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:21 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:21 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:21 --> URI Class Initialized
INFO - 2022-02-27 06:18:21 --> Router Class Initialized
INFO - 2022-02-27 06:18:21 --> Output Class Initialized
INFO - 2022-02-27 06:18:21 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:21 --> Input Class Initialized
INFO - 2022-02-27 06:18:21 --> Language Class Initialized
ERROR - 2022-02-27 06:18:21 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-27 06:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:22 --> Config Class Initialized
INFO - 2022-02-27 06:18:22 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:22 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:22 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:22 --> URI Class Initialized
INFO - 2022-02-27 06:18:22 --> Router Class Initialized
INFO - 2022-02-27 06:18:22 --> Output Class Initialized
INFO - 2022-02-27 06:18:22 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:22 --> Input Class Initialized
INFO - 2022-02-27 06:18:22 --> Language Class Initialized
ERROR - 2022-02-27 06:18:22 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-27 06:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:22 --> Config Class Initialized
INFO - 2022-02-27 06:18:22 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:22 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:22 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:22 --> URI Class Initialized
INFO - 2022-02-27 06:18:22 --> Router Class Initialized
INFO - 2022-02-27 06:18:22 --> Output Class Initialized
INFO - 2022-02-27 06:18:22 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:22 --> Input Class Initialized
INFO - 2022-02-27 06:18:22 --> Language Class Initialized
ERROR - 2022-02-27 06:18:22 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-27 06:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:23 --> Config Class Initialized
INFO - 2022-02-27 06:18:23 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:23 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:23 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:23 --> URI Class Initialized
INFO - 2022-02-27 06:18:23 --> Router Class Initialized
INFO - 2022-02-27 06:18:23 --> Output Class Initialized
INFO - 2022-02-27 06:18:23 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:23 --> Input Class Initialized
INFO - 2022-02-27 06:18:23 --> Language Class Initialized
ERROR - 2022-02-27 06:18:23 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-27 06:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:23 --> Config Class Initialized
INFO - 2022-02-27 06:18:23 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:23 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:23 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:23 --> URI Class Initialized
INFO - 2022-02-27 06:18:23 --> Router Class Initialized
INFO - 2022-02-27 06:18:23 --> Output Class Initialized
INFO - 2022-02-27 06:18:23 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:23 --> Input Class Initialized
INFO - 2022-02-27 06:18:23 --> Language Class Initialized
ERROR - 2022-02-27 06:18:23 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-27 06:18:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:24 --> Config Class Initialized
INFO - 2022-02-27 06:18:24 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:24 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:24 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:24 --> URI Class Initialized
INFO - 2022-02-27 06:18:24 --> Router Class Initialized
INFO - 2022-02-27 06:18:24 --> Output Class Initialized
INFO - 2022-02-27 06:18:24 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:24 --> Input Class Initialized
INFO - 2022-02-27 06:18:24 --> Language Class Initialized
ERROR - 2022-02-27 06:18:24 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-27 06:18:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:24 --> Config Class Initialized
INFO - 2022-02-27 06:18:24 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:24 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:24 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:24 --> URI Class Initialized
INFO - 2022-02-27 06:18:24 --> Router Class Initialized
INFO - 2022-02-27 06:18:24 --> Output Class Initialized
INFO - 2022-02-27 06:18:24 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:24 --> Input Class Initialized
INFO - 2022-02-27 06:18:24 --> Language Class Initialized
ERROR - 2022-02-27 06:18:24 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-27 06:18:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:25 --> Config Class Initialized
INFO - 2022-02-27 06:18:25 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:25 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:25 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:25 --> URI Class Initialized
INFO - 2022-02-27 06:18:25 --> Router Class Initialized
INFO - 2022-02-27 06:18:25 --> Output Class Initialized
INFO - 2022-02-27 06:18:25 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:25 --> Input Class Initialized
INFO - 2022-02-27 06:18:25 --> Language Class Initialized
ERROR - 2022-02-27 06:18:25 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-27 06:18:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:25 --> Config Class Initialized
INFO - 2022-02-27 06:18:25 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:25 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:25 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:25 --> URI Class Initialized
INFO - 2022-02-27 06:18:25 --> Router Class Initialized
INFO - 2022-02-27 06:18:25 --> Output Class Initialized
INFO - 2022-02-27 06:18:25 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:25 --> Input Class Initialized
INFO - 2022-02-27 06:18:25 --> Language Class Initialized
ERROR - 2022-02-27 06:18:25 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-27 06:18:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:25 --> Config Class Initialized
INFO - 2022-02-27 06:18:25 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:25 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:25 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:25 --> URI Class Initialized
INFO - 2022-02-27 06:18:25 --> Router Class Initialized
INFO - 2022-02-27 06:18:25 --> Output Class Initialized
INFO - 2022-02-27 06:18:25 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:25 --> Input Class Initialized
INFO - 2022-02-27 06:18:25 --> Language Class Initialized
ERROR - 2022-02-27 06:18:25 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-27 06:18:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:26 --> Config Class Initialized
INFO - 2022-02-27 06:18:26 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:26 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:26 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:26 --> URI Class Initialized
INFO - 2022-02-27 06:18:26 --> Router Class Initialized
INFO - 2022-02-27 06:18:26 --> Output Class Initialized
INFO - 2022-02-27 06:18:26 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:26 --> Input Class Initialized
INFO - 2022-02-27 06:18:26 --> Language Class Initialized
ERROR - 2022-02-27 06:18:26 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-27 06:18:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:26 --> Config Class Initialized
INFO - 2022-02-27 06:18:26 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:26 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:26 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:26 --> URI Class Initialized
INFO - 2022-02-27 06:18:26 --> Router Class Initialized
INFO - 2022-02-27 06:18:26 --> Output Class Initialized
INFO - 2022-02-27 06:18:26 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:26 --> Input Class Initialized
INFO - 2022-02-27 06:18:26 --> Language Class Initialized
ERROR - 2022-02-27 06:18:26 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-27 06:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:27 --> Config Class Initialized
INFO - 2022-02-27 06:18:27 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:27 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:27 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:27 --> URI Class Initialized
INFO - 2022-02-27 06:18:27 --> Router Class Initialized
INFO - 2022-02-27 06:18:27 --> Output Class Initialized
INFO - 2022-02-27 06:18:27 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:27 --> Input Class Initialized
INFO - 2022-02-27 06:18:27 --> Language Class Initialized
ERROR - 2022-02-27 06:18:27 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-27 06:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:27 --> Config Class Initialized
INFO - 2022-02-27 06:18:27 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:27 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:27 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:27 --> URI Class Initialized
INFO - 2022-02-27 06:18:27 --> Router Class Initialized
INFO - 2022-02-27 06:18:27 --> Output Class Initialized
INFO - 2022-02-27 06:18:27 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:27 --> Input Class Initialized
INFO - 2022-02-27 06:18:27 --> Language Class Initialized
ERROR - 2022-02-27 06:18:27 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-27 06:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 06:18:28 --> Config Class Initialized
INFO - 2022-02-27 06:18:28 --> Hooks Class Initialized
DEBUG - 2022-02-27 06:18:28 --> UTF-8 Support Enabled
INFO - 2022-02-27 06:18:28 --> Utf8 Class Initialized
INFO - 2022-02-27 06:18:28 --> URI Class Initialized
INFO - 2022-02-27 06:18:28 --> Router Class Initialized
INFO - 2022-02-27 06:18:28 --> Output Class Initialized
INFO - 2022-02-27 06:18:28 --> Security Class Initialized
DEBUG - 2022-02-27 06:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 06:18:28 --> Input Class Initialized
INFO - 2022-02-27 06:18:28 --> Language Class Initialized
ERROR - 2022-02-27 06:18:28 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-27 07:14:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 07:14:17 --> Config Class Initialized
INFO - 2022-02-27 07:14:17 --> Hooks Class Initialized
DEBUG - 2022-02-27 07:14:17 --> UTF-8 Support Enabled
INFO - 2022-02-27 07:14:17 --> Utf8 Class Initialized
INFO - 2022-02-27 07:14:17 --> URI Class Initialized
INFO - 2022-02-27 07:14:17 --> Router Class Initialized
INFO - 2022-02-27 07:14:17 --> Output Class Initialized
INFO - 2022-02-27 07:14:17 --> Security Class Initialized
DEBUG - 2022-02-27 07:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 07:14:17 --> Input Class Initialized
INFO - 2022-02-27 07:14:17 --> Language Class Initialized
ERROR - 2022-02-27 07:14:17 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-02-27 07:14:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 07:14:17 --> Config Class Initialized
INFO - 2022-02-27 07:14:17 --> Hooks Class Initialized
DEBUG - 2022-02-27 07:14:17 --> UTF-8 Support Enabled
INFO - 2022-02-27 07:14:17 --> Utf8 Class Initialized
INFO - 2022-02-27 07:14:17 --> URI Class Initialized
INFO - 2022-02-27 07:14:17 --> Router Class Initialized
INFO - 2022-02-27 07:14:17 --> Output Class Initialized
INFO - 2022-02-27 07:14:17 --> Security Class Initialized
DEBUG - 2022-02-27 07:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 07:14:17 --> Input Class Initialized
INFO - 2022-02-27 07:14:17 --> Language Class Initialized
ERROR - 2022-02-27 07:14:17 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-02-27 08:46:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 08:46:31 --> Config Class Initialized
INFO - 2022-02-27 08:46:31 --> Hooks Class Initialized
DEBUG - 2022-02-27 08:46:31 --> UTF-8 Support Enabled
INFO - 2022-02-27 08:46:31 --> Utf8 Class Initialized
INFO - 2022-02-27 08:46:31 --> URI Class Initialized
DEBUG - 2022-02-27 08:46:31 --> No URI present. Default controller set.
INFO - 2022-02-27 08:46:31 --> Router Class Initialized
INFO - 2022-02-27 08:46:31 --> Output Class Initialized
INFO - 2022-02-27 08:46:31 --> Security Class Initialized
DEBUG - 2022-02-27 08:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 08:46:31 --> Input Class Initialized
INFO - 2022-02-27 08:46:31 --> Language Class Initialized
INFO - 2022-02-27 08:46:31 --> Loader Class Initialized
INFO - 2022-02-27 08:46:31 --> Helper loaded: url_helper
INFO - 2022-02-27 08:46:31 --> Helper loaded: form_helper
INFO - 2022-02-27 08:46:31 --> Helper loaded: common_helper
INFO - 2022-02-27 08:46:31 --> Database Driver Class Initialized
DEBUG - 2022-02-27 08:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 08:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 08:46:31 --> Controller Class Initialized
INFO - 2022-02-27 08:46:31 --> Form Validation Class Initialized
DEBUG - 2022-02-27 08:46:31 --> Encrypt Class Initialized
DEBUG - 2022-02-27 08:46:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 08:46:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 08:46:31 --> Email Class Initialized
INFO - 2022-02-27 08:46:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 08:46:31 --> Calendar Class Initialized
INFO - 2022-02-27 08:46:31 --> Model "Login_model" initialized
INFO - 2022-02-27 08:46:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 08:46:31 --> Final output sent to browser
DEBUG - 2022-02-27 08:46:31 --> Total execution time: 0.0244
ERROR - 2022-02-27 14:18:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 14:18:02 --> Config Class Initialized
INFO - 2022-02-27 14:18:02 --> Hooks Class Initialized
DEBUG - 2022-02-27 14:18:02 --> UTF-8 Support Enabled
INFO - 2022-02-27 14:18:02 --> Utf8 Class Initialized
INFO - 2022-02-27 14:18:02 --> URI Class Initialized
DEBUG - 2022-02-27 14:18:02 --> No URI present. Default controller set.
INFO - 2022-02-27 14:18:02 --> Router Class Initialized
INFO - 2022-02-27 14:18:02 --> Output Class Initialized
INFO - 2022-02-27 14:18:02 --> Security Class Initialized
DEBUG - 2022-02-27 14:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 14:18:02 --> Input Class Initialized
INFO - 2022-02-27 14:18:02 --> Language Class Initialized
INFO - 2022-02-27 14:18:02 --> Loader Class Initialized
INFO - 2022-02-27 14:18:02 --> Helper loaded: url_helper
INFO - 2022-02-27 14:18:02 --> Helper loaded: form_helper
INFO - 2022-02-27 14:18:02 --> Helper loaded: common_helper
INFO - 2022-02-27 14:18:02 --> Database Driver Class Initialized
DEBUG - 2022-02-27 14:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 14:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 14:18:02 --> Controller Class Initialized
INFO - 2022-02-27 14:18:02 --> Form Validation Class Initialized
DEBUG - 2022-02-27 14:18:02 --> Encrypt Class Initialized
DEBUG - 2022-02-27 14:18:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 14:18:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 14:18:02 --> Email Class Initialized
INFO - 2022-02-27 14:18:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 14:18:02 --> Calendar Class Initialized
INFO - 2022-02-27 14:18:02 --> Model "Login_model" initialized
INFO - 2022-02-27 14:18:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 14:18:02 --> Final output sent to browser
DEBUG - 2022-02-27 14:18:02 --> Total execution time: 0.0681
ERROR - 2022-02-27 14:18:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 14:18:03 --> Config Class Initialized
INFO - 2022-02-27 14:18:03 --> Hooks Class Initialized
DEBUG - 2022-02-27 14:18:03 --> UTF-8 Support Enabled
INFO - 2022-02-27 14:18:03 --> Utf8 Class Initialized
INFO - 2022-02-27 14:18:03 --> URI Class Initialized
INFO - 2022-02-27 14:18:03 --> Router Class Initialized
INFO - 2022-02-27 14:18:03 --> Output Class Initialized
INFO - 2022-02-27 14:18:03 --> Security Class Initialized
DEBUG - 2022-02-27 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 14:18:03 --> Input Class Initialized
INFO - 2022-02-27 14:18:03 --> Language Class Initialized
ERROR - 2022-02-27 14:18:03 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-27 14:18:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 14:18:13 --> Config Class Initialized
INFO - 2022-02-27 14:18:13 --> Hooks Class Initialized
DEBUG - 2022-02-27 14:18:13 --> UTF-8 Support Enabled
INFO - 2022-02-27 14:18:13 --> Utf8 Class Initialized
INFO - 2022-02-27 14:18:13 --> URI Class Initialized
INFO - 2022-02-27 14:18:13 --> Router Class Initialized
INFO - 2022-02-27 14:18:13 --> Output Class Initialized
INFO - 2022-02-27 14:18:13 --> Security Class Initialized
DEBUG - 2022-02-27 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 14:18:13 --> Input Class Initialized
INFO - 2022-02-27 14:18:13 --> Language Class Initialized
INFO - 2022-02-27 14:18:13 --> Loader Class Initialized
INFO - 2022-02-27 14:18:13 --> Helper loaded: url_helper
INFO - 2022-02-27 14:18:13 --> Helper loaded: form_helper
INFO - 2022-02-27 14:18:13 --> Helper loaded: common_helper
INFO - 2022-02-27 14:18:13 --> Database Driver Class Initialized
DEBUG - 2022-02-27 14:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 14:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 14:18:13 --> Controller Class Initialized
INFO - 2022-02-27 14:18:13 --> Form Validation Class Initialized
DEBUG - 2022-02-27 14:18:13 --> Encrypt Class Initialized
DEBUG - 2022-02-27 14:18:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 14:18:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 14:18:13 --> Email Class Initialized
INFO - 2022-02-27 14:18:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 14:18:13 --> Calendar Class Initialized
INFO - 2022-02-27 14:18:13 --> Model "Login_model" initialized
ERROR - 2022-02-27 14:18:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 14:18:14 --> Config Class Initialized
INFO - 2022-02-27 14:18:14 --> Hooks Class Initialized
DEBUG - 2022-02-27 14:18:14 --> UTF-8 Support Enabled
INFO - 2022-02-27 14:18:14 --> Utf8 Class Initialized
INFO - 2022-02-27 14:18:14 --> URI Class Initialized
INFO - 2022-02-27 14:18:14 --> Router Class Initialized
INFO - 2022-02-27 14:18:14 --> Output Class Initialized
INFO - 2022-02-27 14:18:14 --> Security Class Initialized
DEBUG - 2022-02-27 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 14:18:14 --> Input Class Initialized
INFO - 2022-02-27 14:18:14 --> Language Class Initialized
INFO - 2022-02-27 14:18:14 --> Loader Class Initialized
INFO - 2022-02-27 14:18:14 --> Helper loaded: url_helper
INFO - 2022-02-27 14:18:14 --> Helper loaded: form_helper
INFO - 2022-02-27 14:18:14 --> Helper loaded: common_helper
INFO - 2022-02-27 14:18:14 --> Database Driver Class Initialized
DEBUG - 2022-02-27 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 14:18:14 --> Controller Class Initialized
INFO - 2022-02-27 14:18:14 --> Form Validation Class Initialized
DEBUG - 2022-02-27 14:18:14 --> Encrypt Class Initialized
DEBUG - 2022-02-27 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 14:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 14:18:14 --> Email Class Initialized
INFO - 2022-02-27 14:18:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 14:18:14 --> Calendar Class Initialized
INFO - 2022-02-27 14:18:14 --> Model "Login_model" initialized
ERROR - 2022-02-27 14:18:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 14:18:14 --> Config Class Initialized
INFO - 2022-02-27 14:18:14 --> Hooks Class Initialized
DEBUG - 2022-02-27 14:18:14 --> UTF-8 Support Enabled
INFO - 2022-02-27 14:18:14 --> Utf8 Class Initialized
INFO - 2022-02-27 14:18:14 --> URI Class Initialized
INFO - 2022-02-27 14:18:14 --> Router Class Initialized
INFO - 2022-02-27 14:18:14 --> Output Class Initialized
INFO - 2022-02-27 14:18:14 --> Security Class Initialized
DEBUG - 2022-02-27 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 14:18:14 --> Input Class Initialized
INFO - 2022-02-27 14:18:14 --> Language Class Initialized
INFO - 2022-02-27 14:18:14 --> Loader Class Initialized
INFO - 2022-02-27 14:18:14 --> Helper loaded: url_helper
INFO - 2022-02-27 14:18:14 --> Helper loaded: form_helper
INFO - 2022-02-27 14:18:14 --> Helper loaded: common_helper
INFO - 2022-02-27 14:18:14 --> Database Driver Class Initialized
DEBUG - 2022-02-27 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 14:18:14 --> Controller Class Initialized
INFO - 2022-02-27 14:18:14 --> Form Validation Class Initialized
DEBUG - 2022-02-27 14:18:14 --> Encrypt Class Initialized
DEBUG - 2022-02-27 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 14:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 14:18:14 --> Email Class Initialized
INFO - 2022-02-27 14:18:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 14:18:14 --> Calendar Class Initialized
INFO - 2022-02-27 14:18:14 --> Model "Login_model" initialized
INFO - 2022-02-27 14:18:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 14:18:14 --> Final output sent to browser
DEBUG - 2022-02-27 14:18:14 --> Total execution time: 0.0206
ERROR - 2022-02-27 14:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 14:18:15 --> Config Class Initialized
INFO - 2022-02-27 14:18:15 --> Hooks Class Initialized
DEBUG - 2022-02-27 14:18:15 --> UTF-8 Support Enabled
INFO - 2022-02-27 14:18:15 --> Utf8 Class Initialized
INFO - 2022-02-27 14:18:15 --> URI Class Initialized
DEBUG - 2022-02-27 14:18:15 --> No URI present. Default controller set.
INFO - 2022-02-27 14:18:15 --> Router Class Initialized
INFO - 2022-02-27 14:18:15 --> Output Class Initialized
INFO - 2022-02-27 14:18:15 --> Security Class Initialized
DEBUG - 2022-02-27 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 14:18:15 --> Input Class Initialized
INFO - 2022-02-27 14:18:15 --> Language Class Initialized
INFO - 2022-02-27 14:18:15 --> Loader Class Initialized
INFO - 2022-02-27 14:18:15 --> Helper loaded: url_helper
INFO - 2022-02-27 14:18:15 --> Helper loaded: form_helper
INFO - 2022-02-27 14:18:15 --> Helper loaded: common_helper
INFO - 2022-02-27 14:18:15 --> Database Driver Class Initialized
DEBUG - 2022-02-27 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 14:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 14:18:15 --> Controller Class Initialized
INFO - 2022-02-27 14:18:15 --> Form Validation Class Initialized
DEBUG - 2022-02-27 14:18:15 --> Encrypt Class Initialized
DEBUG - 2022-02-27 14:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 14:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 14:18:15 --> Email Class Initialized
INFO - 2022-02-27 14:18:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 14:18:15 --> Calendar Class Initialized
INFO - 2022-02-27 14:18:15 --> Model "Login_model" initialized
INFO - 2022-02-27 14:18:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 14:18:15 --> Final output sent to browser
DEBUG - 2022-02-27 14:18:15 --> Total execution time: 0.0209
ERROR - 2022-02-27 23:36:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:36:37 --> Config Class Initialized
INFO - 2022-02-27 23:36:37 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:36:37 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:36:37 --> Utf8 Class Initialized
INFO - 2022-02-27 23:36:37 --> URI Class Initialized
DEBUG - 2022-02-27 23:36:37 --> No URI present. Default controller set.
INFO - 2022-02-27 23:36:37 --> Router Class Initialized
INFO - 2022-02-27 23:36:37 --> Output Class Initialized
INFO - 2022-02-27 23:36:37 --> Security Class Initialized
DEBUG - 2022-02-27 23:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:36:37 --> Input Class Initialized
INFO - 2022-02-27 23:36:37 --> Language Class Initialized
INFO - 2022-02-27 23:36:37 --> Loader Class Initialized
INFO - 2022-02-27 23:36:37 --> Helper loaded: url_helper
INFO - 2022-02-27 23:36:37 --> Helper loaded: form_helper
INFO - 2022-02-27 23:36:37 --> Helper loaded: common_helper
INFO - 2022-02-27 23:36:37 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:36:37 --> Controller Class Initialized
INFO - 2022-02-27 23:36:37 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:36:37 --> Encrypt Class Initialized
DEBUG - 2022-02-27 23:36:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 23:36:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 23:36:37 --> Email Class Initialized
INFO - 2022-02-27 23:36:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 23:36:37 --> Calendar Class Initialized
INFO - 2022-02-27 23:36:37 --> Model "Login_model" initialized
INFO - 2022-02-27 23:36:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 23:36:37 --> Final output sent to browser
DEBUG - 2022-02-27 23:36:37 --> Total execution time: 0.0251
ERROR - 2022-02-27 23:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:36:43 --> Config Class Initialized
INFO - 2022-02-27 23:36:43 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:36:43 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:36:43 --> Utf8 Class Initialized
INFO - 2022-02-27 23:36:43 --> URI Class Initialized
DEBUG - 2022-02-27 23:36:43 --> No URI present. Default controller set.
INFO - 2022-02-27 23:36:43 --> Router Class Initialized
INFO - 2022-02-27 23:36:43 --> Output Class Initialized
INFO - 2022-02-27 23:36:43 --> Security Class Initialized
DEBUG - 2022-02-27 23:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:36:43 --> Input Class Initialized
INFO - 2022-02-27 23:36:43 --> Language Class Initialized
INFO - 2022-02-27 23:36:43 --> Loader Class Initialized
INFO - 2022-02-27 23:36:43 --> Helper loaded: url_helper
INFO - 2022-02-27 23:36:43 --> Helper loaded: form_helper
INFO - 2022-02-27 23:36:43 --> Helper loaded: common_helper
INFO - 2022-02-27 23:36:43 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:36:43 --> Controller Class Initialized
INFO - 2022-02-27 23:36:43 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:36:43 --> Encrypt Class Initialized
DEBUG - 2022-02-27 23:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 23:36:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 23:36:43 --> Email Class Initialized
INFO - 2022-02-27 23:36:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 23:36:43 --> Calendar Class Initialized
INFO - 2022-02-27 23:36:43 --> Model "Login_model" initialized
INFO - 2022-02-27 23:36:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 23:36:43 --> Final output sent to browser
DEBUG - 2022-02-27 23:36:43 --> Total execution time: 0.0427
ERROR - 2022-02-27 23:37:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:37:00 --> Config Class Initialized
INFO - 2022-02-27 23:37:00 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:37:00 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:37:00 --> Utf8 Class Initialized
INFO - 2022-02-27 23:37:00 --> URI Class Initialized
INFO - 2022-02-27 23:37:00 --> Router Class Initialized
INFO - 2022-02-27 23:37:00 --> Output Class Initialized
INFO - 2022-02-27 23:37:00 --> Security Class Initialized
DEBUG - 2022-02-27 23:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:37:00 --> Input Class Initialized
INFO - 2022-02-27 23:37:00 --> Language Class Initialized
INFO - 2022-02-27 23:37:00 --> Loader Class Initialized
INFO - 2022-02-27 23:37:00 --> Helper loaded: url_helper
INFO - 2022-02-27 23:37:00 --> Helper loaded: form_helper
INFO - 2022-02-27 23:37:00 --> Helper loaded: common_helper
INFO - 2022-02-27 23:37:00 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:37:00 --> Controller Class Initialized
INFO - 2022-02-27 23:37:00 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:37:00 --> Encrypt Class Initialized
DEBUG - 2022-02-27 23:37:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 23:37:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 23:37:00 --> Email Class Initialized
INFO - 2022-02-27 23:37:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 23:37:00 --> Calendar Class Initialized
INFO - 2022-02-27 23:37:00 --> Model "Login_model" initialized
INFO - 2022-02-27 23:37:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-02-27 23:37:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:37:00 --> Config Class Initialized
INFO - 2022-02-27 23:37:00 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:37:00 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:37:00 --> Utf8 Class Initialized
INFO - 2022-02-27 23:37:00 --> URI Class Initialized
INFO - 2022-02-27 23:37:00 --> Router Class Initialized
INFO - 2022-02-27 23:37:00 --> Output Class Initialized
INFO - 2022-02-27 23:37:00 --> Security Class Initialized
DEBUG - 2022-02-27 23:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:37:00 --> Input Class Initialized
INFO - 2022-02-27 23:37:00 --> Language Class Initialized
INFO - 2022-02-27 23:37:00 --> Loader Class Initialized
INFO - 2022-02-27 23:37:00 --> Helper loaded: url_helper
INFO - 2022-02-27 23:37:00 --> Helper loaded: form_helper
INFO - 2022-02-27 23:37:00 --> Helper loaded: common_helper
INFO - 2022-02-27 23:37:00 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:37:00 --> Controller Class Initialized
INFO - 2022-02-27 23:37:00 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:37:00 --> Encrypt Class Initialized
DEBUG - 2022-02-27 23:37:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 23:37:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 23:37:00 --> Email Class Initialized
INFO - 2022-02-27 23:37:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 23:37:00 --> Calendar Class Initialized
INFO - 2022-02-27 23:37:00 --> Model "Login_model" initialized
INFO - 2022-02-27 23:37:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 23:37:00 --> Final output sent to browser
DEBUG - 2022-02-27 23:37:00 --> Total execution time: 0.0219
ERROR - 2022-02-27 23:37:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:37:02 --> Config Class Initialized
INFO - 2022-02-27 23:37:02 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:37:02 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:37:02 --> Utf8 Class Initialized
INFO - 2022-02-27 23:37:02 --> URI Class Initialized
INFO - 2022-02-27 23:37:02 --> Router Class Initialized
INFO - 2022-02-27 23:37:02 --> Output Class Initialized
INFO - 2022-02-27 23:37:02 --> Security Class Initialized
DEBUG - 2022-02-27 23:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:37:02 --> Input Class Initialized
INFO - 2022-02-27 23:37:02 --> Language Class Initialized
INFO - 2022-02-27 23:37:02 --> Loader Class Initialized
INFO - 2022-02-27 23:37:02 --> Helper loaded: url_helper
INFO - 2022-02-27 23:37:02 --> Helper loaded: form_helper
INFO - 2022-02-27 23:37:02 --> Helper loaded: common_helper
INFO - 2022-02-27 23:37:02 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:37:02 --> Controller Class Initialized
INFO - 2022-02-27 23:37:02 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:37:02 --> Encrypt Class Initialized
DEBUG - 2022-02-27 23:37:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 23:37:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 23:37:02 --> Email Class Initialized
INFO - 2022-02-27 23:37:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 23:37:02 --> Calendar Class Initialized
INFO - 2022-02-27 23:37:02 --> Model "Login_model" initialized
INFO - 2022-02-27 23:37:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 23:37:02 --> Final output sent to browser
DEBUG - 2022-02-27 23:37:02 --> Total execution time: 0.0215
ERROR - 2022-02-27 23:41:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:41:16 --> Config Class Initialized
INFO - 2022-02-27 23:41:16 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:41:16 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:41:16 --> Utf8 Class Initialized
INFO - 2022-02-27 23:41:16 --> URI Class Initialized
INFO - 2022-02-27 23:41:16 --> Router Class Initialized
INFO - 2022-02-27 23:41:16 --> Output Class Initialized
INFO - 2022-02-27 23:41:16 --> Security Class Initialized
DEBUG - 2022-02-27 23:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:41:16 --> Input Class Initialized
INFO - 2022-02-27 23:41:16 --> Language Class Initialized
ERROR - 2022-02-27 23:41:16 --> 404 Page Not Found: Admin/index
ERROR - 2022-02-27 23:41:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:41:19 --> Config Class Initialized
INFO - 2022-02-27 23:41:19 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:41:19 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:41:19 --> Utf8 Class Initialized
INFO - 2022-02-27 23:41:19 --> URI Class Initialized
INFO - 2022-02-27 23:41:19 --> Router Class Initialized
INFO - 2022-02-27 23:41:19 --> Output Class Initialized
INFO - 2022-02-27 23:41:19 --> Security Class Initialized
DEBUG - 2022-02-27 23:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:41:19 --> Input Class Initialized
INFO - 2022-02-27 23:41:19 --> Language Class Initialized
INFO - 2022-02-27 23:41:19 --> Loader Class Initialized
INFO - 2022-02-27 23:41:19 --> Helper loaded: url_helper
INFO - 2022-02-27 23:41:19 --> Helper loaded: form_helper
INFO - 2022-02-27 23:41:19 --> Helper loaded: common_helper
INFO - 2022-02-27 23:41:19 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:41:19 --> Controller Class Initialized
INFO - 2022-02-27 23:41:19 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:41:19 --> Encrypt Class Initialized
DEBUG - 2022-02-27 23:41:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 23:41:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 23:41:19 --> Email Class Initialized
INFO - 2022-02-27 23:41:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 23:41:19 --> Calendar Class Initialized
INFO - 2022-02-27 23:41:19 --> Model "Login_model" initialized
INFO - 2022-02-27 23:41:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 23:41:19 --> Final output sent to browser
DEBUG - 2022-02-27 23:41:19 --> Total execution time: 0.0230
ERROR - 2022-02-27 23:42:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:42:47 --> Config Class Initialized
INFO - 2022-02-27 23:42:47 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:42:47 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:42:47 --> Utf8 Class Initialized
INFO - 2022-02-27 23:42:47 --> URI Class Initialized
INFO - 2022-02-27 23:42:47 --> Router Class Initialized
INFO - 2022-02-27 23:42:47 --> Output Class Initialized
INFO - 2022-02-27 23:42:47 --> Security Class Initialized
DEBUG - 2022-02-27 23:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:42:47 --> Input Class Initialized
INFO - 2022-02-27 23:42:47 --> Language Class Initialized
INFO - 2022-02-27 23:42:47 --> Loader Class Initialized
INFO - 2022-02-27 23:42:47 --> Helper loaded: url_helper
INFO - 2022-02-27 23:42:47 --> Helper loaded: form_helper
INFO - 2022-02-27 23:42:47 --> Helper loaded: common_helper
INFO - 2022-02-27 23:42:47 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:42:47 --> Controller Class Initialized
INFO - 2022-02-27 23:42:47 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:42:47 --> Encrypt Class Initialized
DEBUG - 2022-02-27 23:42:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 23:42:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 23:42:47 --> Email Class Initialized
INFO - 2022-02-27 23:42:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 23:42:47 --> Calendar Class Initialized
INFO - 2022-02-27 23:42:47 --> Model "Login_model" initialized
INFO - 2022-02-27 23:42:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-02-27 23:42:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:42:47 --> Config Class Initialized
INFO - 2022-02-27 23:42:47 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:42:47 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:42:47 --> Utf8 Class Initialized
INFO - 2022-02-27 23:42:47 --> URI Class Initialized
INFO - 2022-02-27 23:42:47 --> Router Class Initialized
INFO - 2022-02-27 23:42:47 --> Output Class Initialized
INFO - 2022-02-27 23:42:47 --> Security Class Initialized
DEBUG - 2022-02-27 23:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:42:47 --> Input Class Initialized
INFO - 2022-02-27 23:42:47 --> Language Class Initialized
INFO - 2022-02-27 23:42:47 --> Loader Class Initialized
INFO - 2022-02-27 23:42:47 --> Helper loaded: url_helper
INFO - 2022-02-27 23:42:47 --> Helper loaded: form_helper
INFO - 2022-02-27 23:42:47 --> Helper loaded: common_helper
INFO - 2022-02-27 23:42:47 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:42:47 --> Controller Class Initialized
INFO - 2022-02-27 23:42:47 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:42:47 --> Encrypt Class Initialized
DEBUG - 2022-02-27 23:42:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 23:42:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 23:42:47 --> Email Class Initialized
INFO - 2022-02-27 23:42:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 23:42:47 --> Calendar Class Initialized
INFO - 2022-02-27 23:42:47 --> Model "Login_model" initialized
INFO - 2022-02-27 23:42:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-27 23:42:47 --> Final output sent to browser
DEBUG - 2022-02-27 23:42:47 --> Total execution time: 0.0225
ERROR - 2022-02-27 23:43:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:43:55 --> Config Class Initialized
INFO - 2022-02-27 23:43:55 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:43:55 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:43:55 --> Utf8 Class Initialized
INFO - 2022-02-27 23:43:55 --> URI Class Initialized
INFO - 2022-02-27 23:43:55 --> Router Class Initialized
INFO - 2022-02-27 23:43:55 --> Output Class Initialized
INFO - 2022-02-27 23:43:55 --> Security Class Initialized
DEBUG - 2022-02-27 23:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:43:55 --> Input Class Initialized
INFO - 2022-02-27 23:43:55 --> Language Class Initialized
INFO - 2022-02-27 23:43:55 --> Loader Class Initialized
INFO - 2022-02-27 23:43:55 --> Helper loaded: url_helper
INFO - 2022-02-27 23:43:55 --> Helper loaded: form_helper
INFO - 2022-02-27 23:43:55 --> Helper loaded: common_helper
INFO - 2022-02-27 23:43:55 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:43:55 --> Controller Class Initialized
INFO - 2022-02-27 23:43:55 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:43:55 --> Encrypt Class Initialized
DEBUG - 2022-02-27 23:43:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-27 23:43:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-27 23:43:55 --> Email Class Initialized
INFO - 2022-02-27 23:43:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-27 23:43:55 --> Calendar Class Initialized
INFO - 2022-02-27 23:43:55 --> Model "Login_model" initialized
INFO - 2022-02-27 23:43:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-02-27 23:43:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:43:55 --> Config Class Initialized
INFO - 2022-02-27 23:43:55 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:43:55 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:43:55 --> Utf8 Class Initialized
INFO - 2022-02-27 23:43:55 --> URI Class Initialized
INFO - 2022-02-27 23:43:55 --> Router Class Initialized
INFO - 2022-02-27 23:43:55 --> Output Class Initialized
INFO - 2022-02-27 23:43:55 --> Security Class Initialized
DEBUG - 2022-02-27 23:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:43:55 --> Input Class Initialized
INFO - 2022-02-27 23:43:55 --> Language Class Initialized
INFO - 2022-02-27 23:43:55 --> Loader Class Initialized
INFO - 2022-02-27 23:43:55 --> Helper loaded: url_helper
INFO - 2022-02-27 23:43:55 --> Helper loaded: form_helper
INFO - 2022-02-27 23:43:55 --> Helper loaded: common_helper
INFO - 2022-02-27 23:43:55 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:43:55 --> Controller Class Initialized
INFO - 2022-02-27 23:43:55 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:43:55 --> Encrypt Class Initialized
INFO - 2022-02-27 23:43:55 --> Model "Login_model" initialized
INFO - 2022-02-27 23:43:56 --> Model "Dashboard_model" initialized
INFO - 2022-02-27 23:43:56 --> Model "Case_model" initialized
INFO - 2022-02-27 23:44:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-02-27 23:44:17 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-02-27 23:44:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-02-27 23:44:17 --> Final output sent to browser
DEBUG - 2022-02-27 23:44:17 --> Total execution time: 21.1554
ERROR - 2022-02-27 23:44:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:44:19 --> Config Class Initialized
INFO - 2022-02-27 23:44:19 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:44:19 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:44:19 --> Utf8 Class Initialized
INFO - 2022-02-27 23:44:19 --> URI Class Initialized
INFO - 2022-02-27 23:44:19 --> Router Class Initialized
INFO - 2022-02-27 23:44:19 --> Output Class Initialized
INFO - 2022-02-27 23:44:19 --> Security Class Initialized
DEBUG - 2022-02-27 23:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:44:19 --> Input Class Initialized
INFO - 2022-02-27 23:44:19 --> Language Class Initialized
ERROR - 2022-02-27 23:44:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-02-27 23:44:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:44:48 --> Config Class Initialized
INFO - 2022-02-27 23:44:48 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:44:48 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:44:48 --> Utf8 Class Initialized
INFO - 2022-02-27 23:44:48 --> URI Class Initialized
INFO - 2022-02-27 23:44:48 --> Router Class Initialized
INFO - 2022-02-27 23:44:48 --> Output Class Initialized
INFO - 2022-02-27 23:44:48 --> Security Class Initialized
DEBUG - 2022-02-27 23:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:44:48 --> Input Class Initialized
INFO - 2022-02-27 23:44:48 --> Language Class Initialized
INFO - 2022-02-27 23:44:48 --> Loader Class Initialized
INFO - 2022-02-27 23:44:48 --> Helper loaded: url_helper
INFO - 2022-02-27 23:44:48 --> Helper loaded: form_helper
INFO - 2022-02-27 23:44:48 --> Helper loaded: common_helper
INFO - 2022-02-27 23:44:48 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:44:48 --> Controller Class Initialized
INFO - 2022-02-27 23:44:48 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:44:48 --> Encrypt Class Initialized
INFO - 2022-02-27 23:44:48 --> Model "Login_model" initialized
INFO - 2022-02-27 23:44:48 --> Model "Dashboard_model" initialized
INFO - 2022-02-27 23:44:48 --> Model "Case_model" initialized
INFO - 2022-02-27 23:44:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-02-27 23:45:05 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-02-27 23:45:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-02-27 23:45:05 --> Final output sent to browser
DEBUG - 2022-02-27 23:45:05 --> Total execution time: 17.0712
ERROR - 2022-02-27 23:45:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:45:08 --> Config Class Initialized
INFO - 2022-02-27 23:45:08 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:45:08 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:45:08 --> Utf8 Class Initialized
INFO - 2022-02-27 23:45:08 --> URI Class Initialized
INFO - 2022-02-27 23:45:08 --> Router Class Initialized
INFO - 2022-02-27 23:45:08 --> Output Class Initialized
INFO - 2022-02-27 23:45:08 --> Security Class Initialized
DEBUG - 2022-02-27 23:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:45:08 --> Input Class Initialized
INFO - 2022-02-27 23:45:08 --> Language Class Initialized
ERROR - 2022-02-27 23:45:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-02-27 23:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:45:21 --> Config Class Initialized
INFO - 2022-02-27 23:45:21 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:45:21 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:45:21 --> Utf8 Class Initialized
INFO - 2022-02-27 23:45:21 --> URI Class Initialized
INFO - 2022-02-27 23:45:21 --> Router Class Initialized
INFO - 2022-02-27 23:45:21 --> Output Class Initialized
INFO - 2022-02-27 23:45:21 --> Security Class Initialized
DEBUG - 2022-02-27 23:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:45:21 --> Input Class Initialized
INFO - 2022-02-27 23:45:21 --> Language Class Initialized
INFO - 2022-02-27 23:45:21 --> Loader Class Initialized
INFO - 2022-02-27 23:45:21 --> Helper loaded: url_helper
INFO - 2022-02-27 23:45:21 --> Helper loaded: form_helper
INFO - 2022-02-27 23:45:21 --> Helper loaded: common_helper
INFO - 2022-02-27 23:45:21 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:45:21 --> Controller Class Initialized
INFO - 2022-02-27 23:45:21 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:45:21 --> Encrypt Class Initialized
INFO - 2022-02-27 23:45:21 --> Model "Patient_model" initialized
INFO - 2022-02-27 23:45:21 --> Model "Patientcase_model" initialized
INFO - 2022-02-27 23:45:21 --> Model "Referredby_model" initialized
INFO - 2022-02-27 23:45:21 --> Model "Prefix_master" initialized
INFO - 2022-02-27 23:45:21 --> Model "Hospital_model" initialized
INFO - 2022-02-27 23:45:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-02-27 23:45:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-02-27 23:45:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-02-27 23:45:21 --> Final output sent to browser
DEBUG - 2022-02-27 23:45:21 --> Total execution time: 0.0369
ERROR - 2022-02-27 23:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:45:22 --> Config Class Initialized
INFO - 2022-02-27 23:45:22 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:45:22 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:45:22 --> Utf8 Class Initialized
INFO - 2022-02-27 23:45:22 --> URI Class Initialized
INFO - 2022-02-27 23:45:22 --> Router Class Initialized
INFO - 2022-02-27 23:45:22 --> Output Class Initialized
INFO - 2022-02-27 23:45:22 --> Security Class Initialized
DEBUG - 2022-02-27 23:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:45:22 --> Input Class Initialized
INFO - 2022-02-27 23:45:22 --> Language Class Initialized
ERROR - 2022-02-27 23:45:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-02-27 23:46:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:46:32 --> Config Class Initialized
INFO - 2022-02-27 23:46:32 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:46:32 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:46:32 --> Utf8 Class Initialized
INFO - 2022-02-27 23:46:32 --> URI Class Initialized
INFO - 2022-02-27 23:46:32 --> Router Class Initialized
INFO - 2022-02-27 23:46:32 --> Output Class Initialized
INFO - 2022-02-27 23:46:32 --> Security Class Initialized
DEBUG - 2022-02-27 23:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:46:32 --> Input Class Initialized
INFO - 2022-02-27 23:46:32 --> Language Class Initialized
INFO - 2022-02-27 23:46:32 --> Loader Class Initialized
INFO - 2022-02-27 23:46:32 --> Helper loaded: url_helper
INFO - 2022-02-27 23:46:32 --> Helper loaded: form_helper
INFO - 2022-02-27 23:46:32 --> Helper loaded: common_helper
INFO - 2022-02-27 23:46:32 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:46:32 --> Controller Class Initialized
INFO - 2022-02-27 23:46:32 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:46:32 --> Encrypt Class Initialized
INFO - 2022-02-27 23:46:32 --> Model "Patient_model" initialized
INFO - 2022-02-27 23:46:32 --> Model "Patientcase_model" initialized
INFO - 2022-02-27 23:46:32 --> Model "Referredby_model" initialized
INFO - 2022-02-27 23:46:32 --> Model "Prefix_master" initialized
INFO - 2022-02-27 23:46:32 --> Model "Hospital_model" initialized
INFO - 2022-02-27 23:46:32 --> Upload Class Initialized
INFO - 2022-02-27 23:46:32 --> Final output sent to browser
DEBUG - 2022-02-27 23:46:32 --> Total execution time: 0.0502
ERROR - 2022-02-27 23:46:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:46:58 --> Config Class Initialized
INFO - 2022-02-27 23:46:58 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:46:58 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:46:58 --> Utf8 Class Initialized
INFO - 2022-02-27 23:46:58 --> URI Class Initialized
INFO - 2022-02-27 23:46:58 --> Router Class Initialized
INFO - 2022-02-27 23:46:58 --> Output Class Initialized
INFO - 2022-02-27 23:46:58 --> Security Class Initialized
DEBUG - 2022-02-27 23:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:46:58 --> Input Class Initialized
INFO - 2022-02-27 23:46:58 --> Language Class Initialized
INFO - 2022-02-27 23:46:58 --> Loader Class Initialized
INFO - 2022-02-27 23:46:58 --> Helper loaded: url_helper
INFO - 2022-02-27 23:46:58 --> Helper loaded: form_helper
INFO - 2022-02-27 23:46:58 --> Helper loaded: common_helper
INFO - 2022-02-27 23:46:58 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:46:58 --> Controller Class Initialized
INFO - 2022-02-27 23:46:58 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:46:58 --> Encrypt Class Initialized
INFO - 2022-02-27 23:46:58 --> Model "Patient_model" initialized
INFO - 2022-02-27 23:46:58 --> Model "Patientcase_model" initialized
INFO - 2022-02-27 23:46:58 --> Model "Referredby_model" initialized
INFO - 2022-02-27 23:46:58 --> Model "Prefix_master" initialized
INFO - 2022-02-27 23:46:58 --> Model "Hospital_model" initialized
INFO - 2022-02-27 23:46:58 --> Upload Class Initialized
INFO - 2022-02-27 23:46:58 --> Final output sent to browser
DEBUG - 2022-02-27 23:46:58 --> Total execution time: 0.0288
ERROR - 2022-02-27 23:47:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:47:19 --> Config Class Initialized
INFO - 2022-02-27 23:47:19 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:47:19 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:47:19 --> Utf8 Class Initialized
INFO - 2022-02-27 23:47:19 --> URI Class Initialized
INFO - 2022-02-27 23:47:19 --> Router Class Initialized
INFO - 2022-02-27 23:47:19 --> Output Class Initialized
INFO - 2022-02-27 23:47:19 --> Security Class Initialized
DEBUG - 2022-02-27 23:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:47:19 --> Input Class Initialized
INFO - 2022-02-27 23:47:19 --> Language Class Initialized
INFO - 2022-02-27 23:47:19 --> Loader Class Initialized
INFO - 2022-02-27 23:47:19 --> Helper loaded: url_helper
INFO - 2022-02-27 23:47:19 --> Helper loaded: form_helper
INFO - 2022-02-27 23:47:19 --> Helper loaded: common_helper
INFO - 2022-02-27 23:47:19 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:47:19 --> Controller Class Initialized
INFO - 2022-02-27 23:47:19 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:47:19 --> Encrypt Class Initialized
INFO - 2022-02-27 23:47:19 --> Model "Patient_model" initialized
INFO - 2022-02-27 23:47:19 --> Model "Patientcase_model" initialized
INFO - 2022-02-27 23:47:19 --> Model "Referredby_model" initialized
INFO - 2022-02-27 23:47:19 --> Model "Prefix_master" initialized
INFO - 2022-02-27 23:47:19 --> Model "Hospital_model" initialized
INFO - 2022-02-27 23:47:19 --> Upload Class Initialized
INFO - 2022-02-27 23:47:19 --> Final output sent to browser
DEBUG - 2022-02-27 23:47:19 --> Total execution time: 0.0268
ERROR - 2022-02-27 23:48:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:48:02 --> Config Class Initialized
INFO - 2022-02-27 23:48:02 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:48:02 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:48:02 --> Utf8 Class Initialized
INFO - 2022-02-27 23:48:02 --> URI Class Initialized
INFO - 2022-02-27 23:48:02 --> Router Class Initialized
INFO - 2022-02-27 23:48:02 --> Output Class Initialized
INFO - 2022-02-27 23:48:02 --> Security Class Initialized
DEBUG - 2022-02-27 23:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:48:02 --> Input Class Initialized
INFO - 2022-02-27 23:48:02 --> Language Class Initialized
INFO - 2022-02-27 23:48:02 --> Loader Class Initialized
INFO - 2022-02-27 23:48:02 --> Helper loaded: url_helper
INFO - 2022-02-27 23:48:02 --> Helper loaded: form_helper
INFO - 2022-02-27 23:48:02 --> Helper loaded: common_helper
INFO - 2022-02-27 23:48:02 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:48:02 --> Controller Class Initialized
INFO - 2022-02-27 23:48:02 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:48:02 --> Encrypt Class Initialized
INFO - 2022-02-27 23:48:02 --> Model "Patient_model" initialized
INFO - 2022-02-27 23:48:02 --> Model "Patientcase_model" initialized
INFO - 2022-02-27 23:48:02 --> Model "Referredby_model" initialized
INFO - 2022-02-27 23:48:02 --> Model "Prefix_master" initialized
INFO - 2022-02-27 23:48:02 --> Model "Hospital_model" initialized
INFO - 2022-02-27 23:48:02 --> Upload Class Initialized
INFO - 2022-02-27 23:48:02 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2022-02-27 23:48:02 --> The filetype you are attempting to upload is not allowed.
INFO - 2022-02-27 23:48:02 --> Final output sent to browser
DEBUG - 2022-02-27 23:48:02 --> Total execution time: 0.2571
ERROR - 2022-02-27 23:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:51:46 --> Config Class Initialized
INFO - 2022-02-27 23:51:46 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:51:46 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:51:46 --> Utf8 Class Initialized
INFO - 2022-02-27 23:51:46 --> URI Class Initialized
INFO - 2022-02-27 23:51:46 --> Router Class Initialized
INFO - 2022-02-27 23:51:46 --> Output Class Initialized
INFO - 2022-02-27 23:51:46 --> Security Class Initialized
DEBUG - 2022-02-27 23:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:51:46 --> Input Class Initialized
INFO - 2022-02-27 23:51:46 --> Language Class Initialized
INFO - 2022-02-27 23:51:46 --> Loader Class Initialized
INFO - 2022-02-27 23:51:46 --> Helper loaded: url_helper
INFO - 2022-02-27 23:51:46 --> Helper loaded: form_helper
INFO - 2022-02-27 23:51:46 --> Helper loaded: common_helper
INFO - 2022-02-27 23:51:46 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:51:46 --> Controller Class Initialized
INFO - 2022-02-27 23:51:46 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:51:46 --> Encrypt Class Initialized
INFO - 2022-02-27 23:51:46 --> Model "Patient_model" initialized
INFO - 2022-02-27 23:51:46 --> Model "Patientcase_model" initialized
INFO - 2022-02-27 23:51:46 --> Model "Referredby_model" initialized
INFO - 2022-02-27 23:51:46 --> Model "Prefix_master" initialized
INFO - 2022-02-27 23:51:46 --> Model "Hospital_model" initialized
INFO - 2022-02-27 23:51:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-02-27 23:51:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-02-27 23:51:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-02-27 23:51:46 --> Final output sent to browser
DEBUG - 2022-02-27 23:51:46 --> Total execution time: 0.0267
ERROR - 2022-02-27 23:57:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:57:20 --> Config Class Initialized
INFO - 2022-02-27 23:57:20 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:57:20 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:57:20 --> Utf8 Class Initialized
INFO - 2022-02-27 23:57:20 --> URI Class Initialized
INFO - 2022-02-27 23:57:20 --> Router Class Initialized
INFO - 2022-02-27 23:57:20 --> Output Class Initialized
INFO - 2022-02-27 23:57:20 --> Security Class Initialized
DEBUG - 2022-02-27 23:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:57:20 --> Input Class Initialized
INFO - 2022-02-27 23:57:20 --> Language Class Initialized
INFO - 2022-02-27 23:57:20 --> Loader Class Initialized
INFO - 2022-02-27 23:57:20 --> Helper loaded: url_helper
INFO - 2022-02-27 23:57:20 --> Helper loaded: form_helper
INFO - 2022-02-27 23:57:20 --> Helper loaded: common_helper
INFO - 2022-02-27 23:57:20 --> Database Driver Class Initialized
DEBUG - 2022-02-27 23:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-27 23:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-27 23:57:20 --> Controller Class Initialized
INFO - 2022-02-27 23:57:20 --> Form Validation Class Initialized
DEBUG - 2022-02-27 23:57:20 --> Encrypt Class Initialized
INFO - 2022-02-27 23:57:20 --> Model "Patient_model" initialized
INFO - 2022-02-27 23:57:20 --> Model "Patientcase_model" initialized
INFO - 2022-02-27 23:57:20 --> Model "Referredby_model" initialized
INFO - 2022-02-27 23:57:20 --> Model "Prefix_master" initialized
INFO - 2022-02-27 23:57:20 --> Model "Hospital_model" initialized
INFO - 2022-02-27 23:57:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-02-27 23:57:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-02-27 23:57:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-02-27 23:57:20 --> Final output sent to browser
DEBUG - 2022-02-27 23:57:20 --> Total execution time: 0.0286
ERROR - 2022-02-27 23:57:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-27 23:57:21 --> Config Class Initialized
INFO - 2022-02-27 23:57:21 --> Hooks Class Initialized
DEBUG - 2022-02-27 23:57:21 --> UTF-8 Support Enabled
INFO - 2022-02-27 23:57:21 --> Utf8 Class Initialized
INFO - 2022-02-27 23:57:21 --> URI Class Initialized
INFO - 2022-02-27 23:57:21 --> Router Class Initialized
INFO - 2022-02-27 23:57:21 --> Output Class Initialized
INFO - 2022-02-27 23:57:21 --> Security Class Initialized
DEBUG - 2022-02-27 23:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-27 23:57:21 --> Input Class Initialized
INFO - 2022-02-27 23:57:21 --> Language Class Initialized
ERROR - 2022-02-27 23:57:21 --> 404 Page Not Found: Karoclient/usersprofile
