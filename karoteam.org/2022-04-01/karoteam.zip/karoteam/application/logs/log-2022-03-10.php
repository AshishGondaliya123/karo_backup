<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-10 00:02:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:02:01 --> Config Class Initialized
INFO - 2022-03-10 00:02:01 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:02:01 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:02:01 --> Utf8 Class Initialized
INFO - 2022-03-10 00:02:01 --> URI Class Initialized
INFO - 2022-03-10 00:02:01 --> Router Class Initialized
INFO - 2022-03-10 00:02:01 --> Output Class Initialized
INFO - 2022-03-10 00:02:01 --> Security Class Initialized
DEBUG - 2022-03-10 00:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:02:01 --> Input Class Initialized
INFO - 2022-03-10 00:02:01 --> Language Class Initialized
INFO - 2022-03-10 00:02:01 --> Loader Class Initialized
INFO - 2022-03-10 00:02:01 --> Helper loaded: url_helper
INFO - 2022-03-10 00:02:01 --> Helper loaded: form_helper
INFO - 2022-03-10 00:02:01 --> Helper loaded: common_helper
INFO - 2022-03-10 00:02:01 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:02:01 --> Controller Class Initialized
INFO - 2022-03-10 00:02:01 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:02:01 --> Encrypt Class Initialized
DEBUG - 2022-03-10 00:02:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 00:02:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 00:02:01 --> Email Class Initialized
INFO - 2022-03-10 00:02:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 00:02:01 --> Calendar Class Initialized
INFO - 2022-03-10 00:02:01 --> Model "Login_model" initialized
ERROR - 2022-03-10 00:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:02:02 --> Config Class Initialized
INFO - 2022-03-10 00:02:02 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:02:02 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:02:02 --> Utf8 Class Initialized
INFO - 2022-03-10 00:02:02 --> URI Class Initialized
INFO - 2022-03-10 00:02:02 --> Router Class Initialized
INFO - 2022-03-10 00:02:02 --> Output Class Initialized
INFO - 2022-03-10 00:02:02 --> Security Class Initialized
DEBUG - 2022-03-10 00:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:02:02 --> Input Class Initialized
INFO - 2022-03-10 00:02:02 --> Language Class Initialized
INFO - 2022-03-10 00:02:02 --> Loader Class Initialized
INFO - 2022-03-10 00:02:02 --> Helper loaded: url_helper
INFO - 2022-03-10 00:02:02 --> Helper loaded: form_helper
INFO - 2022-03-10 00:02:02 --> Helper loaded: common_helper
INFO - 2022-03-10 00:02:02 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:02:02 --> Controller Class Initialized
INFO - 2022-03-10 00:02:02 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:02:02 --> Encrypt Class Initialized
DEBUG - 2022-03-10 00:02:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 00:02:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 00:02:02 --> Email Class Initialized
INFO - 2022-03-10 00:02:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 00:02:02 --> Calendar Class Initialized
INFO - 2022-03-10 00:02:02 --> Model "Login_model" initialized
INFO - 2022-03-10 00:02:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 00:02:02 --> Final output sent to browser
DEBUG - 2022-03-10 00:02:02 --> Total execution time: 0.0261
ERROR - 2022-03-10 00:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:02:38 --> Config Class Initialized
INFO - 2022-03-10 00:02:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:02:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:02:38 --> Utf8 Class Initialized
INFO - 2022-03-10 00:02:38 --> URI Class Initialized
DEBUG - 2022-03-10 00:02:38 --> No URI present. Default controller set.
INFO - 2022-03-10 00:02:38 --> Router Class Initialized
INFO - 2022-03-10 00:02:38 --> Output Class Initialized
INFO - 2022-03-10 00:02:38 --> Security Class Initialized
DEBUG - 2022-03-10 00:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:02:38 --> Input Class Initialized
INFO - 2022-03-10 00:02:38 --> Language Class Initialized
INFO - 2022-03-10 00:02:38 --> Loader Class Initialized
INFO - 2022-03-10 00:02:38 --> Helper loaded: url_helper
INFO - 2022-03-10 00:02:38 --> Helper loaded: form_helper
INFO - 2022-03-10 00:02:38 --> Helper loaded: common_helper
INFO - 2022-03-10 00:02:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:02:38 --> Controller Class Initialized
INFO - 2022-03-10 00:02:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:02:38 --> Encrypt Class Initialized
DEBUG - 2022-03-10 00:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 00:02:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 00:02:38 --> Email Class Initialized
INFO - 2022-03-10 00:02:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 00:02:38 --> Calendar Class Initialized
INFO - 2022-03-10 00:02:38 --> Model "Login_model" initialized
INFO - 2022-03-10 00:02:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 00:02:38 --> Final output sent to browser
DEBUG - 2022-03-10 00:02:38 --> Total execution time: 0.0305
ERROR - 2022-03-10 00:02:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:02:59 --> Config Class Initialized
INFO - 2022-03-10 00:02:59 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:02:59 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:02:59 --> Utf8 Class Initialized
INFO - 2022-03-10 00:02:59 --> URI Class Initialized
INFO - 2022-03-10 00:02:59 --> Router Class Initialized
INFO - 2022-03-10 00:03:00 --> Output Class Initialized
INFO - 2022-03-10 00:03:00 --> Security Class Initialized
DEBUG - 2022-03-10 00:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:03:00 --> Input Class Initialized
INFO - 2022-03-10 00:03:00 --> Language Class Initialized
INFO - 2022-03-10 00:03:00 --> Loader Class Initialized
INFO - 2022-03-10 00:03:00 --> Helper loaded: url_helper
INFO - 2022-03-10 00:03:00 --> Helper loaded: form_helper
INFO - 2022-03-10 00:03:00 --> Helper loaded: common_helper
INFO - 2022-03-10 00:03:00 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:03:00 --> Controller Class Initialized
INFO - 2022-03-10 00:03:00 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:03:00 --> Encrypt Class Initialized
DEBUG - 2022-03-10 00:03:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 00:03:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 00:03:00 --> Email Class Initialized
INFO - 2022-03-10 00:03:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 00:03:00 --> Calendar Class Initialized
INFO - 2022-03-10 00:03:00 --> Model "Login_model" initialized
INFO - 2022-03-10 00:03:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 00:03:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:03:00 --> Config Class Initialized
INFO - 2022-03-10 00:03:00 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:03:00 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:03:00 --> Utf8 Class Initialized
INFO - 2022-03-10 00:03:00 --> URI Class Initialized
INFO - 2022-03-10 00:03:00 --> Router Class Initialized
INFO - 2022-03-10 00:03:00 --> Output Class Initialized
INFO - 2022-03-10 00:03:00 --> Security Class Initialized
DEBUG - 2022-03-10 00:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:03:00 --> Input Class Initialized
INFO - 2022-03-10 00:03:00 --> Language Class Initialized
INFO - 2022-03-10 00:03:00 --> Loader Class Initialized
INFO - 2022-03-10 00:03:00 --> Helper loaded: url_helper
INFO - 2022-03-10 00:03:00 --> Helper loaded: form_helper
INFO - 2022-03-10 00:03:00 --> Helper loaded: common_helper
INFO - 2022-03-10 00:03:00 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:03:00 --> Controller Class Initialized
INFO - 2022-03-10 00:03:00 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:03:00 --> Encrypt Class Initialized
INFO - 2022-03-10 00:03:00 --> Model "Login_model" initialized
INFO - 2022-03-10 00:03:00 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 00:03:00 --> Model "Case_model" initialized
INFO - 2022-03-10 00:03:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 00:03:26 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 00:03:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 00:03:26 --> Final output sent to browser
DEBUG - 2022-03-10 00:03:26 --> Total execution time: 26.0249
ERROR - 2022-03-10 00:03:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:03:27 --> Config Class Initialized
INFO - 2022-03-10 00:03:27 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:03:27 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:03:27 --> Utf8 Class Initialized
INFO - 2022-03-10 00:03:27 --> URI Class Initialized
INFO - 2022-03-10 00:03:27 --> Router Class Initialized
INFO - 2022-03-10 00:03:27 --> Output Class Initialized
INFO - 2022-03-10 00:03:27 --> Security Class Initialized
DEBUG - 2022-03-10 00:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:03:27 --> Input Class Initialized
INFO - 2022-03-10 00:03:27 --> Language Class Initialized
ERROR - 2022-03-10 00:03:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 00:25:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:25:20 --> Config Class Initialized
INFO - 2022-03-10 00:25:20 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:25:20 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:25:20 --> Utf8 Class Initialized
INFO - 2022-03-10 00:25:20 --> URI Class Initialized
INFO - 2022-03-10 00:25:20 --> Router Class Initialized
INFO - 2022-03-10 00:25:20 --> Output Class Initialized
INFO - 2022-03-10 00:25:20 --> Security Class Initialized
DEBUG - 2022-03-10 00:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:25:20 --> Input Class Initialized
INFO - 2022-03-10 00:25:20 --> Language Class Initialized
INFO - 2022-03-10 00:25:20 --> Loader Class Initialized
INFO - 2022-03-10 00:25:20 --> Helper loaded: url_helper
INFO - 2022-03-10 00:25:20 --> Helper loaded: form_helper
INFO - 2022-03-10 00:25:20 --> Helper loaded: common_helper
INFO - 2022-03-10 00:25:20 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:25:20 --> Controller Class Initialized
ERROR - 2022-03-10 00:25:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:25:20 --> Config Class Initialized
INFO - 2022-03-10 00:25:20 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:25:20 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:25:20 --> Utf8 Class Initialized
INFO - 2022-03-10 00:25:20 --> URI Class Initialized
INFO - 2022-03-10 00:25:20 --> Router Class Initialized
INFO - 2022-03-10 00:25:20 --> Output Class Initialized
INFO - 2022-03-10 00:25:20 --> Security Class Initialized
DEBUG - 2022-03-10 00:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:25:20 --> Input Class Initialized
INFO - 2022-03-10 00:25:20 --> Language Class Initialized
INFO - 2022-03-10 00:25:20 --> Loader Class Initialized
INFO - 2022-03-10 00:25:20 --> Helper loaded: url_helper
INFO - 2022-03-10 00:25:20 --> Helper loaded: form_helper
INFO - 2022-03-10 00:25:20 --> Helper loaded: common_helper
INFO - 2022-03-10 00:25:20 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:25:21 --> Controller Class Initialized
INFO - 2022-03-10 00:25:21 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:25:21 --> Encrypt Class Initialized
DEBUG - 2022-03-10 00:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 00:25:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 00:25:21 --> Email Class Initialized
INFO - 2022-03-10 00:25:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 00:25:21 --> Calendar Class Initialized
INFO - 2022-03-10 00:25:21 --> Model "Login_model" initialized
INFO - 2022-03-10 00:25:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 00:25:21 --> Final output sent to browser
DEBUG - 2022-03-10 00:25:21 --> Total execution time: 0.1185
ERROR - 2022-03-10 00:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:25:24 --> Config Class Initialized
INFO - 2022-03-10 00:25:24 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:25:24 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:25:24 --> Utf8 Class Initialized
INFO - 2022-03-10 00:25:24 --> URI Class Initialized
INFO - 2022-03-10 00:25:24 --> Router Class Initialized
INFO - 2022-03-10 00:25:24 --> Output Class Initialized
INFO - 2022-03-10 00:25:24 --> Security Class Initialized
DEBUG - 2022-03-10 00:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:25:24 --> Input Class Initialized
INFO - 2022-03-10 00:25:24 --> Language Class Initialized
INFO - 2022-03-10 00:25:24 --> Loader Class Initialized
INFO - 2022-03-10 00:25:24 --> Helper loaded: url_helper
INFO - 2022-03-10 00:25:24 --> Helper loaded: form_helper
INFO - 2022-03-10 00:25:24 --> Helper loaded: common_helper
INFO - 2022-03-10 00:25:24 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:25:24 --> Controller Class Initialized
INFO - 2022-03-10 00:25:24 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:25:24 --> Encrypt Class Initialized
DEBUG - 2022-03-10 00:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 00:25:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 00:25:24 --> Email Class Initialized
INFO - 2022-03-10 00:25:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 00:25:24 --> Calendar Class Initialized
INFO - 2022-03-10 00:25:24 --> Model "Login_model" initialized
INFO - 2022-03-10 00:25:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 00:25:24 --> Final output sent to browser
DEBUG - 2022-03-10 00:25:24 --> Total execution time: 0.0284
ERROR - 2022-03-10 00:25:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:25:41 --> Config Class Initialized
INFO - 2022-03-10 00:25:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:25:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:25:41 --> Utf8 Class Initialized
INFO - 2022-03-10 00:25:41 --> URI Class Initialized
INFO - 2022-03-10 00:25:41 --> Router Class Initialized
INFO - 2022-03-10 00:25:41 --> Output Class Initialized
INFO - 2022-03-10 00:25:41 --> Security Class Initialized
DEBUG - 2022-03-10 00:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:25:41 --> Input Class Initialized
INFO - 2022-03-10 00:25:41 --> Language Class Initialized
INFO - 2022-03-10 00:25:41 --> Loader Class Initialized
INFO - 2022-03-10 00:25:41 --> Helper loaded: url_helper
INFO - 2022-03-10 00:25:41 --> Helper loaded: form_helper
INFO - 2022-03-10 00:25:41 --> Helper loaded: common_helper
INFO - 2022-03-10 00:25:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:25:41 --> Controller Class Initialized
INFO - 2022-03-10 00:25:41 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:25:41 --> Encrypt Class Initialized
DEBUG - 2022-03-10 00:25:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 00:25:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 00:25:41 --> Email Class Initialized
INFO - 2022-03-10 00:25:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 00:25:41 --> Calendar Class Initialized
INFO - 2022-03-10 00:25:41 --> Model "Login_model" initialized
INFO - 2022-03-10 00:25:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 00:25:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:25:41 --> Config Class Initialized
INFO - 2022-03-10 00:25:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:25:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:25:41 --> Utf8 Class Initialized
INFO - 2022-03-10 00:25:41 --> URI Class Initialized
INFO - 2022-03-10 00:25:41 --> Router Class Initialized
INFO - 2022-03-10 00:25:41 --> Output Class Initialized
INFO - 2022-03-10 00:25:41 --> Security Class Initialized
DEBUG - 2022-03-10 00:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:25:41 --> Input Class Initialized
INFO - 2022-03-10 00:25:41 --> Language Class Initialized
INFO - 2022-03-10 00:25:41 --> Loader Class Initialized
INFO - 2022-03-10 00:25:41 --> Helper loaded: url_helper
INFO - 2022-03-10 00:25:41 --> Helper loaded: form_helper
INFO - 2022-03-10 00:25:41 --> Helper loaded: common_helper
INFO - 2022-03-10 00:25:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:25:41 --> Controller Class Initialized
INFO - 2022-03-10 00:25:41 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:25:41 --> Encrypt Class Initialized
INFO - 2022-03-10 00:25:41 --> Model "Login_model" initialized
INFO - 2022-03-10 00:25:41 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 00:25:41 --> Model "Case_model" initialized
INFO - 2022-03-10 00:25:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 00:25:59 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 00:25:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 00:25:59 --> Final output sent to browser
DEBUG - 2022-03-10 00:25:59 --> Total execution time: 18.0871
ERROR - 2022-03-10 00:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:26:00 --> Config Class Initialized
INFO - 2022-03-10 00:26:00 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:26:00 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:26:00 --> Utf8 Class Initialized
INFO - 2022-03-10 00:26:00 --> URI Class Initialized
INFO - 2022-03-10 00:26:00 --> Router Class Initialized
INFO - 2022-03-10 00:26:00 --> Output Class Initialized
INFO - 2022-03-10 00:26:00 --> Security Class Initialized
DEBUG - 2022-03-10 00:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:26:00 --> Input Class Initialized
INFO - 2022-03-10 00:26:00 --> Language Class Initialized
ERROR - 2022-03-10 00:26:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 00:26:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:26:47 --> Config Class Initialized
INFO - 2022-03-10 00:26:47 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:26:47 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:26:47 --> Utf8 Class Initialized
INFO - 2022-03-10 00:26:47 --> URI Class Initialized
INFO - 2022-03-10 00:26:47 --> Router Class Initialized
INFO - 2022-03-10 00:26:47 --> Output Class Initialized
INFO - 2022-03-10 00:26:47 --> Security Class Initialized
DEBUG - 2022-03-10 00:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:26:47 --> Input Class Initialized
INFO - 2022-03-10 00:26:47 --> Language Class Initialized
INFO - 2022-03-10 00:26:47 --> Loader Class Initialized
INFO - 2022-03-10 00:26:47 --> Helper loaded: url_helper
INFO - 2022-03-10 00:26:47 --> Helper loaded: form_helper
INFO - 2022-03-10 00:26:47 --> Helper loaded: common_helper
INFO - 2022-03-10 00:26:47 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:26:47 --> Controller Class Initialized
INFO - 2022-03-10 00:26:47 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:26:47 --> Encrypt Class Initialized
INFO - 2022-03-10 00:26:47 --> Model "Patient_model" initialized
INFO - 2022-03-10 00:26:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 00:26:47 --> Model "Referredby_model" initialized
INFO - 2022-03-10 00:26:47 --> Model "Prefix_master" initialized
INFO - 2022-03-10 00:26:47 --> Model "Hospital_model" initialized
INFO - 2022-03-10 00:26:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 00:26:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 00:26:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-10 00:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:26:54 --> Config Class Initialized
INFO - 2022-03-10 00:26:54 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:26:54 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:26:54 --> Utf8 Class Initialized
INFO - 2022-03-10 00:26:54 --> URI Class Initialized
INFO - 2022-03-10 00:26:54 --> Router Class Initialized
INFO - 2022-03-10 00:26:54 --> Output Class Initialized
INFO - 2022-03-10 00:26:54 --> Security Class Initialized
DEBUG - 2022-03-10 00:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:26:54 --> Input Class Initialized
INFO - 2022-03-10 00:26:54 --> Language Class Initialized
ERROR - 2022-03-10 00:26:54 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-10 00:27:00 --> Final output sent to browser
DEBUG - 2022-03-10 00:27:00 --> Total execution time: 6.1850
ERROR - 2022-03-10 00:39:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:39:07 --> Config Class Initialized
INFO - 2022-03-10 00:39:07 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:39:07 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:39:07 --> Utf8 Class Initialized
INFO - 2022-03-10 00:39:07 --> URI Class Initialized
DEBUG - 2022-03-10 00:39:07 --> No URI present. Default controller set.
INFO - 2022-03-10 00:39:07 --> Router Class Initialized
INFO - 2022-03-10 00:39:07 --> Output Class Initialized
INFO - 2022-03-10 00:39:07 --> Security Class Initialized
DEBUG - 2022-03-10 00:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:39:07 --> Input Class Initialized
INFO - 2022-03-10 00:39:07 --> Language Class Initialized
INFO - 2022-03-10 00:39:07 --> Loader Class Initialized
INFO - 2022-03-10 00:39:07 --> Helper loaded: url_helper
INFO - 2022-03-10 00:39:07 --> Helper loaded: form_helper
INFO - 2022-03-10 00:39:07 --> Helper loaded: common_helper
INFO - 2022-03-10 00:39:07 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:39:07 --> Controller Class Initialized
INFO - 2022-03-10 00:39:07 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:39:07 --> Encrypt Class Initialized
DEBUG - 2022-03-10 00:39:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 00:39:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 00:39:07 --> Email Class Initialized
INFO - 2022-03-10 00:39:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 00:39:07 --> Calendar Class Initialized
INFO - 2022-03-10 00:39:07 --> Model "Login_model" initialized
ERROR - 2022-03-10 00:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:39:08 --> Config Class Initialized
INFO - 2022-03-10 00:39:08 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:39:08 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:39:08 --> Utf8 Class Initialized
INFO - 2022-03-10 00:39:08 --> URI Class Initialized
INFO - 2022-03-10 00:39:08 --> Router Class Initialized
INFO - 2022-03-10 00:39:08 --> Output Class Initialized
INFO - 2022-03-10 00:39:08 --> Security Class Initialized
DEBUG - 2022-03-10 00:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:39:08 --> Input Class Initialized
INFO - 2022-03-10 00:39:08 --> Language Class Initialized
INFO - 2022-03-10 00:39:08 --> Loader Class Initialized
INFO - 2022-03-10 00:39:08 --> Helper loaded: url_helper
INFO - 2022-03-10 00:39:08 --> Helper loaded: form_helper
INFO - 2022-03-10 00:39:08 --> Helper loaded: common_helper
INFO - 2022-03-10 00:39:08 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:39:08 --> Controller Class Initialized
INFO - 2022-03-10 00:39:08 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:39:08 --> Encrypt Class Initialized
INFO - 2022-03-10 00:39:08 --> Model "Diseases_model" initialized
INFO - 2022-03-10 00:39:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 00:39:08 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-10 00:39:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 00:39:08 --> Final output sent to browser
DEBUG - 2022-03-10 00:39:08 --> Total execution time: 0.0240
ERROR - 2022-03-10 00:39:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:39:10 --> Config Class Initialized
INFO - 2022-03-10 00:39:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:39:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:39:10 --> Utf8 Class Initialized
INFO - 2022-03-10 00:39:10 --> URI Class Initialized
INFO - 2022-03-10 00:39:10 --> Router Class Initialized
INFO - 2022-03-10 00:39:10 --> Output Class Initialized
INFO - 2022-03-10 00:39:10 --> Security Class Initialized
DEBUG - 2022-03-10 00:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:39:10 --> Input Class Initialized
INFO - 2022-03-10 00:39:10 --> Language Class Initialized
ERROR - 2022-03-10 00:39:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 00:42:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:42:05 --> Config Class Initialized
INFO - 2022-03-10 00:42:05 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:42:05 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:42:05 --> Utf8 Class Initialized
INFO - 2022-03-10 00:42:05 --> URI Class Initialized
INFO - 2022-03-10 00:42:05 --> Router Class Initialized
INFO - 2022-03-10 00:42:05 --> Output Class Initialized
INFO - 2022-03-10 00:42:05 --> Security Class Initialized
DEBUG - 2022-03-10 00:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:42:05 --> Input Class Initialized
INFO - 2022-03-10 00:42:05 --> Language Class Initialized
INFO - 2022-03-10 00:42:05 --> Loader Class Initialized
INFO - 2022-03-10 00:42:05 --> Helper loaded: url_helper
INFO - 2022-03-10 00:42:05 --> Helper loaded: form_helper
INFO - 2022-03-10 00:42:05 --> Helper loaded: common_helper
INFO - 2022-03-10 00:42:05 --> Database Driver Class Initialized
DEBUG - 2022-03-10 00:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 00:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 00:42:05 --> Controller Class Initialized
INFO - 2022-03-10 00:42:05 --> Form Validation Class Initialized
DEBUG - 2022-03-10 00:42:05 --> Encrypt Class Initialized
INFO - 2022-03-10 00:42:05 --> Model "Patient_model" initialized
INFO - 2022-03-10 00:42:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 00:42:05 --> Model "Referredby_model" initialized
INFO - 2022-03-10 00:42:05 --> Model "Prefix_master" initialized
INFO - 2022-03-10 00:42:05 --> Model "Hospital_model" initialized
INFO - 2022-03-10 00:42:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 00:42:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 00:42:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-10 00:42:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 00:42:14 --> Config Class Initialized
INFO - 2022-03-10 00:42:14 --> Hooks Class Initialized
DEBUG - 2022-03-10 00:42:14 --> UTF-8 Support Enabled
INFO - 2022-03-10 00:42:14 --> Utf8 Class Initialized
INFO - 2022-03-10 00:42:14 --> URI Class Initialized
INFO - 2022-03-10 00:42:14 --> Router Class Initialized
INFO - 2022-03-10 00:42:14 --> Output Class Initialized
INFO - 2022-03-10 00:42:14 --> Security Class Initialized
DEBUG - 2022-03-10 00:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 00:42:14 --> Input Class Initialized
INFO - 2022-03-10 00:42:14 --> Language Class Initialized
ERROR - 2022-03-10 00:42:14 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-10 00:42:19 --> Final output sent to browser
DEBUG - 2022-03-10 00:42:19 --> Total execution time: 7.3028
ERROR - 2022-03-10 01:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:00:43 --> Config Class Initialized
INFO - 2022-03-10 01:00:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:00:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:00:43 --> Utf8 Class Initialized
INFO - 2022-03-10 01:00:43 --> URI Class Initialized
DEBUG - 2022-03-10 01:00:43 --> No URI present. Default controller set.
INFO - 2022-03-10 01:00:43 --> Router Class Initialized
INFO - 2022-03-10 01:00:43 --> Output Class Initialized
INFO - 2022-03-10 01:00:43 --> Security Class Initialized
DEBUG - 2022-03-10 01:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:00:43 --> Input Class Initialized
INFO - 2022-03-10 01:00:43 --> Language Class Initialized
INFO - 2022-03-10 01:00:43 --> Loader Class Initialized
INFO - 2022-03-10 01:00:43 --> Helper loaded: url_helper
INFO - 2022-03-10 01:00:43 --> Helper loaded: form_helper
INFO - 2022-03-10 01:00:43 --> Helper loaded: common_helper
INFO - 2022-03-10 01:00:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:00:43 --> Controller Class Initialized
INFO - 2022-03-10 01:00:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:00:43 --> Encrypt Class Initialized
DEBUG - 2022-03-10 01:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 01:00:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 01:00:43 --> Email Class Initialized
INFO - 2022-03-10 01:00:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 01:00:43 --> Calendar Class Initialized
INFO - 2022-03-10 01:00:43 --> Model "Login_model" initialized
INFO - 2022-03-10 01:00:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 01:00:43 --> Final output sent to browser
DEBUG - 2022-03-10 01:00:43 --> Total execution time: 0.0250
ERROR - 2022-03-10 01:02:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:02:20 --> Config Class Initialized
INFO - 2022-03-10 01:02:20 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:02:20 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:02:20 --> Utf8 Class Initialized
INFO - 2022-03-10 01:02:20 --> URI Class Initialized
INFO - 2022-03-10 01:02:20 --> Router Class Initialized
INFO - 2022-03-10 01:02:20 --> Output Class Initialized
INFO - 2022-03-10 01:02:20 --> Security Class Initialized
DEBUG - 2022-03-10 01:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:02:20 --> Input Class Initialized
INFO - 2022-03-10 01:02:20 --> Language Class Initialized
INFO - 2022-03-10 01:02:20 --> Loader Class Initialized
INFO - 2022-03-10 01:02:20 --> Helper loaded: url_helper
INFO - 2022-03-10 01:02:20 --> Helper loaded: form_helper
INFO - 2022-03-10 01:02:20 --> Helper loaded: common_helper
INFO - 2022-03-10 01:02:20 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:02:20 --> Controller Class Initialized
INFO - 2022-03-10 01:02:20 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:02:20 --> Encrypt Class Initialized
INFO - 2022-03-10 01:02:20 --> Model "Patient_model" initialized
INFO - 2022-03-10 01:02:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 01:02:20 --> Model "Prefix_master" initialized
INFO - 2022-03-10 01:02:20 --> Model "Users_model" initialized
INFO - 2022-03-10 01:02:20 --> Model "Hospital_model" initialized
INFO - 2022-03-10 01:02:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 01:02:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 01:02:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 01:02:20 --> Final output sent to browser
DEBUG - 2022-03-10 01:02:20 --> Total execution time: 0.0940
ERROR - 2022-03-10 01:02:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:02:21 --> Config Class Initialized
INFO - 2022-03-10 01:02:21 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:02:21 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:02:21 --> Utf8 Class Initialized
INFO - 2022-03-10 01:02:21 --> URI Class Initialized
INFO - 2022-03-10 01:02:21 --> Router Class Initialized
INFO - 2022-03-10 01:02:21 --> Output Class Initialized
INFO - 2022-03-10 01:02:21 --> Security Class Initialized
DEBUG - 2022-03-10 01:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:02:21 --> Input Class Initialized
INFO - 2022-03-10 01:02:21 --> Language Class Initialized
ERROR - 2022-03-10 01:02:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 01:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:02:27 --> Config Class Initialized
INFO - 2022-03-10 01:02:27 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:02:27 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:02:27 --> Utf8 Class Initialized
INFO - 2022-03-10 01:02:27 --> URI Class Initialized
DEBUG - 2022-03-10 01:02:27 --> No URI present. Default controller set.
INFO - 2022-03-10 01:02:27 --> Router Class Initialized
INFO - 2022-03-10 01:02:27 --> Output Class Initialized
INFO - 2022-03-10 01:02:27 --> Security Class Initialized
DEBUG - 2022-03-10 01:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:02:27 --> Input Class Initialized
INFO - 2022-03-10 01:02:27 --> Language Class Initialized
INFO - 2022-03-10 01:02:27 --> Loader Class Initialized
INFO - 2022-03-10 01:02:27 --> Helper loaded: url_helper
INFO - 2022-03-10 01:02:27 --> Helper loaded: form_helper
INFO - 2022-03-10 01:02:27 --> Helper loaded: common_helper
INFO - 2022-03-10 01:02:27 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:02:27 --> Controller Class Initialized
INFO - 2022-03-10 01:02:27 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:02:27 --> Encrypt Class Initialized
DEBUG - 2022-03-10 01:02:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 01:02:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 01:02:27 --> Email Class Initialized
INFO - 2022-03-10 01:02:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 01:02:27 --> Calendar Class Initialized
INFO - 2022-03-10 01:02:27 --> Model "Login_model" initialized
INFO - 2022-03-10 01:02:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 01:02:27 --> Final output sent to browser
DEBUG - 2022-03-10 01:02:27 --> Total execution time: 0.0371
ERROR - 2022-03-10 01:03:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:03:03 --> Config Class Initialized
INFO - 2022-03-10 01:03:03 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:03:03 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:03:03 --> Utf8 Class Initialized
INFO - 2022-03-10 01:03:03 --> URI Class Initialized
INFO - 2022-03-10 01:03:03 --> Router Class Initialized
INFO - 2022-03-10 01:03:03 --> Output Class Initialized
INFO - 2022-03-10 01:03:03 --> Security Class Initialized
DEBUG - 2022-03-10 01:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:03:03 --> Input Class Initialized
INFO - 2022-03-10 01:03:03 --> Language Class Initialized
INFO - 2022-03-10 01:03:03 --> Loader Class Initialized
INFO - 2022-03-10 01:03:03 --> Helper loaded: url_helper
INFO - 2022-03-10 01:03:03 --> Helper loaded: form_helper
INFO - 2022-03-10 01:03:03 --> Helper loaded: common_helper
INFO - 2022-03-10 01:03:03 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:03:03 --> Controller Class Initialized
INFO - 2022-03-10 01:03:03 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:03:03 --> Encrypt Class Initialized
DEBUG - 2022-03-10 01:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 01:03:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 01:03:03 --> Email Class Initialized
INFO - 2022-03-10 01:03:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 01:03:03 --> Calendar Class Initialized
INFO - 2022-03-10 01:03:03 --> Model "Login_model" initialized
INFO - 2022-03-10 01:03:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 01:03:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:03:03 --> Config Class Initialized
INFO - 2022-03-10 01:03:03 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:03:03 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:03:03 --> Utf8 Class Initialized
INFO - 2022-03-10 01:03:03 --> URI Class Initialized
INFO - 2022-03-10 01:03:03 --> Router Class Initialized
INFO - 2022-03-10 01:03:03 --> Output Class Initialized
INFO - 2022-03-10 01:03:03 --> Security Class Initialized
DEBUG - 2022-03-10 01:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:03:03 --> Input Class Initialized
INFO - 2022-03-10 01:03:03 --> Language Class Initialized
INFO - 2022-03-10 01:03:03 --> Loader Class Initialized
INFO - 2022-03-10 01:03:03 --> Helper loaded: url_helper
INFO - 2022-03-10 01:03:03 --> Helper loaded: form_helper
INFO - 2022-03-10 01:03:03 --> Helper loaded: common_helper
INFO - 2022-03-10 01:03:03 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:03:03 --> Controller Class Initialized
INFO - 2022-03-10 01:03:03 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:03:03 --> Encrypt Class Initialized
INFO - 2022-03-10 01:03:03 --> Model "Login_model" initialized
INFO - 2022-03-10 01:03:03 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 01:03:03 --> Model "Case_model" initialized
INFO - 2022-03-10 01:03:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 01:03:27 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 01:03:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 01:03:27 --> Final output sent to browser
DEBUG - 2022-03-10 01:03:27 --> Total execution time: 23.2516
ERROR - 2022-03-10 01:03:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:03:27 --> Config Class Initialized
INFO - 2022-03-10 01:03:27 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:03:27 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:03:27 --> Utf8 Class Initialized
INFO - 2022-03-10 01:03:27 --> URI Class Initialized
INFO - 2022-03-10 01:03:27 --> Router Class Initialized
INFO - 2022-03-10 01:03:27 --> Output Class Initialized
INFO - 2022-03-10 01:03:27 --> Security Class Initialized
DEBUG - 2022-03-10 01:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:03:27 --> Input Class Initialized
INFO - 2022-03-10 01:03:27 --> Language Class Initialized
ERROR - 2022-03-10 01:03:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 01:03:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:03:37 --> Config Class Initialized
INFO - 2022-03-10 01:03:37 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:03:37 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:03:37 --> Utf8 Class Initialized
INFO - 2022-03-10 01:03:37 --> URI Class Initialized
INFO - 2022-03-10 01:03:37 --> Router Class Initialized
INFO - 2022-03-10 01:03:37 --> Output Class Initialized
INFO - 2022-03-10 01:03:37 --> Security Class Initialized
DEBUG - 2022-03-10 01:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:03:37 --> Input Class Initialized
INFO - 2022-03-10 01:03:37 --> Language Class Initialized
INFO - 2022-03-10 01:03:37 --> Loader Class Initialized
INFO - 2022-03-10 01:03:37 --> Helper loaded: url_helper
INFO - 2022-03-10 01:03:37 --> Helper loaded: form_helper
INFO - 2022-03-10 01:03:37 --> Helper loaded: common_helper
INFO - 2022-03-10 01:03:37 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:03:37 --> Controller Class Initialized
INFO - 2022-03-10 01:03:37 --> Form Validation Class Initialized
INFO - 2022-03-10 01:03:37 --> Model "Case_model" initialized
INFO - 2022-03-10 01:03:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 01:03:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 01:03:39 --> Model "Case_model" initialized
INFO - 2022-03-10 01:03:43 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2022-03-10 01:03:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-10 01:03:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:03:44 --> Config Class Initialized
INFO - 2022-03-10 01:03:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:03:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:03:44 --> Utf8 Class Initialized
INFO - 2022-03-10 01:03:44 --> URI Class Initialized
INFO - 2022-03-10 01:03:44 --> Router Class Initialized
INFO - 2022-03-10 01:03:44 --> Output Class Initialized
INFO - 2022-03-10 01:03:44 --> Security Class Initialized
DEBUG - 2022-03-10 01:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:03:44 --> Input Class Initialized
INFO - 2022-03-10 01:03:44 --> Language Class Initialized
ERROR - 2022-03-10 01:03:44 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-10 01:03:44 --> Final output sent to browser
DEBUG - 2022-03-10 01:03:44 --> Total execution time: 6.1446
ERROR - 2022-03-10 01:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:03:50 --> Config Class Initialized
INFO - 2022-03-10 01:03:50 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:03:50 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:03:50 --> Utf8 Class Initialized
INFO - 2022-03-10 01:03:50 --> URI Class Initialized
INFO - 2022-03-10 01:03:50 --> Router Class Initialized
INFO - 2022-03-10 01:03:50 --> Output Class Initialized
INFO - 2022-03-10 01:03:50 --> Security Class Initialized
DEBUG - 2022-03-10 01:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:03:50 --> Input Class Initialized
INFO - 2022-03-10 01:03:50 --> Language Class Initialized
INFO - 2022-03-10 01:03:50 --> Loader Class Initialized
INFO - 2022-03-10 01:03:50 --> Helper loaded: url_helper
INFO - 2022-03-10 01:03:50 --> Helper loaded: form_helper
INFO - 2022-03-10 01:03:50 --> Helper loaded: common_helper
INFO - 2022-03-10 01:03:50 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:03:50 --> Controller Class Initialized
INFO - 2022-03-10 01:03:50 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:03:50 --> Encrypt Class Initialized
INFO - 2022-03-10 01:03:50 --> Model "Login_model" initialized
INFO - 2022-03-10 01:03:50 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 01:03:50 --> Model "Case_model" initialized
ERROR - 2022-03-10 01:03:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calcu' at line 7 - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00'  AND patient_master.created_by = 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!=''  AND patient_master.created_by = 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2022-03-10 01:03:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-03-10 01:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:12:55 --> Config Class Initialized
INFO - 2022-03-10 01:12:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:12:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:12:55 --> Utf8 Class Initialized
INFO - 2022-03-10 01:12:55 --> URI Class Initialized
INFO - 2022-03-10 01:12:55 --> Router Class Initialized
INFO - 2022-03-10 01:12:55 --> Output Class Initialized
INFO - 2022-03-10 01:12:55 --> Security Class Initialized
DEBUG - 2022-03-10 01:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:12:55 --> Input Class Initialized
INFO - 2022-03-10 01:12:55 --> Language Class Initialized
INFO - 2022-03-10 01:12:55 --> Loader Class Initialized
INFO - 2022-03-10 01:12:55 --> Helper loaded: url_helper
INFO - 2022-03-10 01:12:55 --> Helper loaded: form_helper
INFO - 2022-03-10 01:12:55 --> Helper loaded: common_helper
INFO - 2022-03-10 01:12:55 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:12:55 --> Controller Class Initialized
INFO - 2022-03-10 01:12:55 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:12:55 --> Encrypt Class Initialized
INFO - 2022-03-10 01:12:55 --> Model "Patient_model" initialized
INFO - 2022-03-10 01:12:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 01:12:55 --> Model "Prefix_master" initialized
INFO - 2022-03-10 01:12:55 --> Model "Users_model" initialized
INFO - 2022-03-10 01:12:55 --> Model "Hospital_model" initialized
INFO - 2022-03-10 01:12:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 01:12:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 01:12:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 01:12:55 --> Final output sent to browser
DEBUG - 2022-03-10 01:12:55 --> Total execution time: 0.0689
ERROR - 2022-03-10 01:12:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:12:56 --> Config Class Initialized
INFO - 2022-03-10 01:12:56 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:12:56 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:12:56 --> Utf8 Class Initialized
INFO - 2022-03-10 01:12:56 --> URI Class Initialized
INFO - 2022-03-10 01:12:56 --> Router Class Initialized
INFO - 2022-03-10 01:12:56 --> Output Class Initialized
INFO - 2022-03-10 01:12:56 --> Security Class Initialized
DEBUG - 2022-03-10 01:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:12:56 --> Input Class Initialized
INFO - 2022-03-10 01:12:56 --> Language Class Initialized
ERROR - 2022-03-10 01:12:56 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 01:23:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:23:21 --> Config Class Initialized
INFO - 2022-03-10 01:23:21 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:23:21 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:23:21 --> Utf8 Class Initialized
INFO - 2022-03-10 01:23:21 --> URI Class Initialized
INFO - 2022-03-10 01:23:21 --> Router Class Initialized
INFO - 2022-03-10 01:23:21 --> Output Class Initialized
INFO - 2022-03-10 01:23:21 --> Security Class Initialized
DEBUG - 2022-03-10 01:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:23:21 --> Input Class Initialized
INFO - 2022-03-10 01:23:21 --> Language Class Initialized
INFO - 2022-03-10 01:23:21 --> Loader Class Initialized
INFO - 2022-03-10 01:23:21 --> Helper loaded: url_helper
INFO - 2022-03-10 01:23:21 --> Helper loaded: form_helper
INFO - 2022-03-10 01:23:21 --> Helper loaded: common_helper
INFO - 2022-03-10 01:23:21 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:23:21 --> Controller Class Initialized
INFO - 2022-03-10 01:23:21 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:23:21 --> Encrypt Class Initialized
INFO - 2022-03-10 01:23:21 --> Model "Patient_model" initialized
INFO - 2022-03-10 01:23:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 01:23:21 --> Model "Prefix_master" initialized
INFO - 2022-03-10 01:23:21 --> Model "Users_model" initialized
INFO - 2022-03-10 01:23:21 --> Model "Hospital_model" initialized
INFO - 2022-03-10 01:23:21 --> Upload Class Initialized
INFO - 2022-03-10 01:23:21 --> Final output sent to browser
DEBUG - 2022-03-10 01:23:21 --> Total execution time: 0.0382
ERROR - 2022-03-10 01:23:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:23:25 --> Config Class Initialized
INFO - 2022-03-10 01:23:25 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:23:25 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:23:25 --> Utf8 Class Initialized
INFO - 2022-03-10 01:23:25 --> URI Class Initialized
INFO - 2022-03-10 01:23:25 --> Router Class Initialized
INFO - 2022-03-10 01:23:25 --> Output Class Initialized
INFO - 2022-03-10 01:23:25 --> Security Class Initialized
DEBUG - 2022-03-10 01:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:23:25 --> Input Class Initialized
INFO - 2022-03-10 01:23:25 --> Language Class Initialized
INFO - 2022-03-10 01:23:25 --> Loader Class Initialized
INFO - 2022-03-10 01:23:25 --> Helper loaded: url_helper
INFO - 2022-03-10 01:23:25 --> Helper loaded: form_helper
INFO - 2022-03-10 01:23:25 --> Helper loaded: common_helper
INFO - 2022-03-10 01:23:25 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:23:25 --> Controller Class Initialized
INFO - 2022-03-10 01:23:25 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:23:25 --> Encrypt Class Initialized
INFO - 2022-03-10 01:23:25 --> Model "Patient_model" initialized
INFO - 2022-03-10 01:23:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 01:23:25 --> Model "Prefix_master" initialized
INFO - 2022-03-10 01:23:25 --> Model "Users_model" initialized
INFO - 2022-03-10 01:23:25 --> Model "Hospital_model" initialized
INFO - 2022-03-10 01:23:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 01:23:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 01:23:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 01:23:25 --> Final output sent to browser
DEBUG - 2022-03-10 01:23:25 --> Total execution time: 0.0733
ERROR - 2022-03-10 01:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:23:26 --> Config Class Initialized
INFO - 2022-03-10 01:23:26 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:23:26 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:23:26 --> Utf8 Class Initialized
INFO - 2022-03-10 01:23:26 --> URI Class Initialized
INFO - 2022-03-10 01:23:26 --> Router Class Initialized
INFO - 2022-03-10 01:23:26 --> Output Class Initialized
INFO - 2022-03-10 01:23:26 --> Security Class Initialized
DEBUG - 2022-03-10 01:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:23:26 --> Input Class Initialized
INFO - 2022-03-10 01:23:26 --> Language Class Initialized
ERROR - 2022-03-10 01:23:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 01:57:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:57:38 --> Config Class Initialized
INFO - 2022-03-10 01:57:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:57:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:57:38 --> Utf8 Class Initialized
INFO - 2022-03-10 01:57:38 --> URI Class Initialized
INFO - 2022-03-10 01:57:38 --> Router Class Initialized
INFO - 2022-03-10 01:57:38 --> Output Class Initialized
INFO - 2022-03-10 01:57:38 --> Security Class Initialized
DEBUG - 2022-03-10 01:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:57:38 --> Input Class Initialized
INFO - 2022-03-10 01:57:38 --> Language Class Initialized
INFO - 2022-03-10 01:57:38 --> Loader Class Initialized
INFO - 2022-03-10 01:57:38 --> Helper loaded: url_helper
INFO - 2022-03-10 01:57:38 --> Helper loaded: form_helper
INFO - 2022-03-10 01:57:38 --> Helper loaded: common_helper
INFO - 2022-03-10 01:57:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:57:38 --> Controller Class Initialized
INFO - 2022-03-10 01:57:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:57:38 --> Encrypt Class Initialized
INFO - 2022-03-10 01:57:38 --> Model "Patient_model" initialized
INFO - 2022-03-10 01:57:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 01:57:38 --> Model "Prefix_master" initialized
INFO - 2022-03-10 01:57:38 --> Model "Users_model" initialized
INFO - 2022-03-10 01:57:38 --> Model "Hospital_model" initialized
INFO - 2022-03-10 01:57:38 --> Final output sent to browser
DEBUG - 2022-03-10 01:57:38 --> Total execution time: 0.0281
ERROR - 2022-03-10 01:58:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:58:32 --> Config Class Initialized
INFO - 2022-03-10 01:58:32 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:58:32 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:58:32 --> Utf8 Class Initialized
INFO - 2022-03-10 01:58:32 --> URI Class Initialized
INFO - 2022-03-10 01:58:32 --> Router Class Initialized
INFO - 2022-03-10 01:58:32 --> Output Class Initialized
INFO - 2022-03-10 01:58:32 --> Security Class Initialized
DEBUG - 2022-03-10 01:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:58:32 --> Input Class Initialized
INFO - 2022-03-10 01:58:32 --> Language Class Initialized
INFO - 2022-03-10 01:58:32 --> Loader Class Initialized
INFO - 2022-03-10 01:58:32 --> Helper loaded: url_helper
INFO - 2022-03-10 01:58:32 --> Helper loaded: form_helper
INFO - 2022-03-10 01:58:32 --> Helper loaded: common_helper
INFO - 2022-03-10 01:58:32 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:58:32 --> Controller Class Initialized
INFO - 2022-03-10 01:58:32 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:58:32 --> Encrypt Class Initialized
INFO - 2022-03-10 01:58:32 --> Model "Patient_model" initialized
INFO - 2022-03-10 01:58:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 01:58:32 --> Model "Prefix_master" initialized
INFO - 2022-03-10 01:58:32 --> Model "Users_model" initialized
INFO - 2022-03-10 01:58:32 --> Model "Hospital_model" initialized
INFO - 2022-03-10 01:58:32 --> Upload Class Initialized
INFO - 2022-03-10 01:58:32 --> Final output sent to browser
DEBUG - 2022-03-10 01:58:32 --> Total execution time: 0.0661
ERROR - 2022-03-10 01:58:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 01:58:56 --> Config Class Initialized
INFO - 2022-03-10 01:58:56 --> Hooks Class Initialized
DEBUG - 2022-03-10 01:58:56 --> UTF-8 Support Enabled
INFO - 2022-03-10 01:58:56 --> Utf8 Class Initialized
INFO - 2022-03-10 01:58:56 --> URI Class Initialized
INFO - 2022-03-10 01:58:56 --> Router Class Initialized
INFO - 2022-03-10 01:58:56 --> Output Class Initialized
INFO - 2022-03-10 01:58:56 --> Security Class Initialized
DEBUG - 2022-03-10 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 01:58:56 --> Input Class Initialized
INFO - 2022-03-10 01:58:56 --> Language Class Initialized
INFO - 2022-03-10 01:58:56 --> Loader Class Initialized
INFO - 2022-03-10 01:58:56 --> Helper loaded: url_helper
INFO - 2022-03-10 01:58:56 --> Helper loaded: form_helper
INFO - 2022-03-10 01:58:56 --> Helper loaded: common_helper
INFO - 2022-03-10 01:58:56 --> Database Driver Class Initialized
DEBUG - 2022-03-10 01:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 01:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 01:58:56 --> Controller Class Initialized
INFO - 2022-03-10 01:58:56 --> Form Validation Class Initialized
DEBUG - 2022-03-10 01:58:56 --> Encrypt Class Initialized
INFO - 2022-03-10 01:58:56 --> Model "Patient_model" initialized
INFO - 2022-03-10 01:58:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 01:58:56 --> Model "Prefix_master" initialized
INFO - 2022-03-10 01:58:56 --> Model "Users_model" initialized
INFO - 2022-03-10 01:58:56 --> Model "Hospital_model" initialized
INFO - 2022-03-10 01:58:56 --> Final output sent to browser
DEBUG - 2022-03-10 01:58:56 --> Total execution time: 0.0294
ERROR - 2022-03-10 02:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 02:18:08 --> Config Class Initialized
INFO - 2022-03-10 02:18:08 --> Hooks Class Initialized
DEBUG - 2022-03-10 02:18:08 --> UTF-8 Support Enabled
INFO - 2022-03-10 02:18:08 --> Utf8 Class Initialized
INFO - 2022-03-10 02:18:08 --> URI Class Initialized
INFO - 2022-03-10 02:18:08 --> Router Class Initialized
INFO - 2022-03-10 02:18:08 --> Output Class Initialized
INFO - 2022-03-10 02:18:08 --> Security Class Initialized
DEBUG - 2022-03-10 02:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 02:18:08 --> Input Class Initialized
INFO - 2022-03-10 02:18:08 --> Language Class Initialized
ERROR - 2022-03-10 02:18:08 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 02:19:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 02:19:48 --> Config Class Initialized
INFO - 2022-03-10 02:19:48 --> Hooks Class Initialized
DEBUG - 2022-03-10 02:19:48 --> UTF-8 Support Enabled
INFO - 2022-03-10 02:19:48 --> Utf8 Class Initialized
INFO - 2022-03-10 02:19:48 --> URI Class Initialized
INFO - 2022-03-10 02:19:48 --> Router Class Initialized
INFO - 2022-03-10 02:19:48 --> Output Class Initialized
INFO - 2022-03-10 02:19:48 --> Security Class Initialized
DEBUG - 2022-03-10 02:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 02:19:48 --> Input Class Initialized
INFO - 2022-03-10 02:19:48 --> Language Class Initialized
INFO - 2022-03-10 02:19:48 --> Loader Class Initialized
INFO - 2022-03-10 02:19:48 --> Helper loaded: url_helper
INFO - 2022-03-10 02:19:48 --> Helper loaded: form_helper
INFO - 2022-03-10 02:19:48 --> Helper loaded: common_helper
INFO - 2022-03-10 02:19:48 --> Database Driver Class Initialized
DEBUG - 2022-03-10 02:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 02:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 02:19:48 --> Controller Class Initialized
INFO - 2022-03-10 02:19:48 --> Form Validation Class Initialized
DEBUG - 2022-03-10 02:19:48 --> Encrypt Class Initialized
INFO - 2022-03-10 02:19:48 --> Model "Patient_model" initialized
INFO - 2022-03-10 02:19:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 02:19:48 --> Model "Prefix_master" initialized
INFO - 2022-03-10 02:19:48 --> Model "Users_model" initialized
INFO - 2022-03-10 02:19:48 --> Model "Hospital_model" initialized
INFO - 2022-03-10 02:19:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 02:19:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 02:19:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 02:19:49 --> Final output sent to browser
DEBUG - 2022-03-10 02:19:49 --> Total execution time: 0.1071
ERROR - 2022-03-10 02:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 02:19:50 --> Config Class Initialized
INFO - 2022-03-10 02:19:50 --> Hooks Class Initialized
DEBUG - 2022-03-10 02:19:50 --> UTF-8 Support Enabled
INFO - 2022-03-10 02:19:50 --> Utf8 Class Initialized
INFO - 2022-03-10 02:19:50 --> URI Class Initialized
INFO - 2022-03-10 02:19:50 --> Router Class Initialized
INFO - 2022-03-10 02:19:50 --> Output Class Initialized
INFO - 2022-03-10 02:19:50 --> Security Class Initialized
DEBUG - 2022-03-10 02:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 02:19:50 --> Input Class Initialized
INFO - 2022-03-10 02:19:50 --> Language Class Initialized
ERROR - 2022-03-10 02:19:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 02:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 02:20:18 --> Config Class Initialized
INFO - 2022-03-10 02:20:18 --> Hooks Class Initialized
DEBUG - 2022-03-10 02:20:18 --> UTF-8 Support Enabled
INFO - 2022-03-10 02:20:18 --> Utf8 Class Initialized
INFO - 2022-03-10 02:20:18 --> URI Class Initialized
INFO - 2022-03-10 02:20:18 --> Router Class Initialized
INFO - 2022-03-10 02:20:18 --> Output Class Initialized
INFO - 2022-03-10 02:20:18 --> Security Class Initialized
DEBUG - 2022-03-10 02:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 02:20:18 --> Input Class Initialized
INFO - 2022-03-10 02:20:18 --> Language Class Initialized
ERROR - 2022-03-10 02:20:18 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 02:50:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 02:50:41 --> Config Class Initialized
INFO - 2022-03-10 02:50:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 02:50:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 02:50:41 --> Utf8 Class Initialized
INFO - 2022-03-10 02:50:41 --> URI Class Initialized
INFO - 2022-03-10 02:50:41 --> Router Class Initialized
INFO - 2022-03-10 02:50:41 --> Output Class Initialized
INFO - 2022-03-10 02:50:41 --> Security Class Initialized
DEBUG - 2022-03-10 02:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 02:50:41 --> Input Class Initialized
INFO - 2022-03-10 02:50:41 --> Language Class Initialized
INFO - 2022-03-10 02:50:41 --> Loader Class Initialized
INFO - 2022-03-10 02:50:41 --> Helper loaded: url_helper
INFO - 2022-03-10 02:50:41 --> Helper loaded: form_helper
INFO - 2022-03-10 02:50:41 --> Helper loaded: common_helper
INFO - 2022-03-10 02:50:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 02:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 02:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 02:50:41 --> Controller Class Initialized
INFO - 2022-03-10 02:50:41 --> Form Validation Class Initialized
DEBUG - 2022-03-10 02:50:41 --> Encrypt Class Initialized
INFO - 2022-03-10 02:50:41 --> Model "Patient_model" initialized
INFO - 2022-03-10 02:50:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 02:50:41 --> Model "Referredby_model" initialized
INFO - 2022-03-10 02:50:41 --> Model "Prefix_master" initialized
INFO - 2022-03-10 02:50:41 --> Model "Hospital_model" initialized
INFO - 2022-03-10 02:50:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 02:50:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 02:50:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 02:50:42 --> Final output sent to browser
DEBUG - 2022-03-10 02:50:42 --> Total execution time: 0.6392
ERROR - 2022-03-10 02:50:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 02:50:43 --> Config Class Initialized
INFO - 2022-03-10 02:50:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 02:50:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 02:50:43 --> Utf8 Class Initialized
INFO - 2022-03-10 02:50:43 --> URI Class Initialized
INFO - 2022-03-10 02:50:43 --> Router Class Initialized
INFO - 2022-03-10 02:50:43 --> Output Class Initialized
INFO - 2022-03-10 02:50:43 --> Security Class Initialized
DEBUG - 2022-03-10 02:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 02:50:43 --> Input Class Initialized
INFO - 2022-03-10 02:50:43 --> Language Class Initialized
ERROR - 2022-03-10 02:50:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 03:07:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:07:39 --> Config Class Initialized
INFO - 2022-03-10 03:07:39 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:07:39 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:07:39 --> Utf8 Class Initialized
INFO - 2022-03-10 03:07:39 --> URI Class Initialized
DEBUG - 2022-03-10 03:07:39 --> No URI present. Default controller set.
INFO - 2022-03-10 03:07:39 --> Router Class Initialized
INFO - 2022-03-10 03:07:39 --> Output Class Initialized
INFO - 2022-03-10 03:07:39 --> Security Class Initialized
DEBUG - 2022-03-10 03:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:07:39 --> Input Class Initialized
INFO - 2022-03-10 03:07:39 --> Language Class Initialized
INFO - 2022-03-10 03:07:39 --> Loader Class Initialized
INFO - 2022-03-10 03:07:39 --> Helper loaded: url_helper
INFO - 2022-03-10 03:07:39 --> Helper loaded: form_helper
INFO - 2022-03-10 03:07:39 --> Helper loaded: common_helper
INFO - 2022-03-10 03:07:39 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:07:39 --> Controller Class Initialized
INFO - 2022-03-10 03:07:39 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:07:39 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:07:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:07:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:07:39 --> Email Class Initialized
INFO - 2022-03-10 03:07:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:07:39 --> Calendar Class Initialized
INFO - 2022-03-10 03:07:39 --> Model "Login_model" initialized
INFO - 2022-03-10 03:07:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 03:07:39 --> Final output sent to browser
DEBUG - 2022-03-10 03:07:39 --> Total execution time: 0.0294
ERROR - 2022-03-10 03:07:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:07:54 --> Config Class Initialized
INFO - 2022-03-10 03:07:54 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:07:54 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:07:54 --> Utf8 Class Initialized
INFO - 2022-03-10 03:07:54 --> URI Class Initialized
INFO - 2022-03-10 03:07:54 --> Router Class Initialized
INFO - 2022-03-10 03:07:54 --> Output Class Initialized
INFO - 2022-03-10 03:07:54 --> Security Class Initialized
DEBUG - 2022-03-10 03:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:07:54 --> Input Class Initialized
INFO - 2022-03-10 03:07:54 --> Language Class Initialized
ERROR - 2022-03-10 03:07:54 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2022-03-10 03:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:12:23 --> Config Class Initialized
INFO - 2022-03-10 03:12:23 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:12:23 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:12:23 --> Utf8 Class Initialized
INFO - 2022-03-10 03:12:23 --> URI Class Initialized
INFO - 2022-03-10 03:12:23 --> Router Class Initialized
INFO - 2022-03-10 03:12:23 --> Output Class Initialized
INFO - 2022-03-10 03:12:23 --> Security Class Initialized
DEBUG - 2022-03-10 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:12:23 --> Input Class Initialized
INFO - 2022-03-10 03:12:23 --> Language Class Initialized
INFO - 2022-03-10 03:12:23 --> Loader Class Initialized
INFO - 2022-03-10 03:12:23 --> Helper loaded: url_helper
INFO - 2022-03-10 03:12:23 --> Helper loaded: form_helper
INFO - 2022-03-10 03:12:23 --> Helper loaded: common_helper
INFO - 2022-03-10 03:12:23 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:12:23 --> Controller Class Initialized
INFO - 2022-03-10 03:12:23 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:12:23 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:12:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:12:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:12:23 --> Email Class Initialized
INFO - 2022-03-10 03:12:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:12:23 --> Calendar Class Initialized
INFO - 2022-03-10 03:12:23 --> Model "Login_model" initialized
INFO - 2022-03-10 03:12:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 03:12:23 --> Final output sent to browser
DEBUG - 2022-03-10 03:12:23 --> Total execution time: 0.0269
ERROR - 2022-03-10 03:12:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:12:46 --> Config Class Initialized
INFO - 2022-03-10 03:12:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:12:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:12:46 --> Utf8 Class Initialized
INFO - 2022-03-10 03:12:46 --> URI Class Initialized
INFO - 2022-03-10 03:12:46 --> Router Class Initialized
INFO - 2022-03-10 03:12:46 --> Output Class Initialized
INFO - 2022-03-10 03:12:46 --> Security Class Initialized
DEBUG - 2022-03-10 03:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:12:46 --> Input Class Initialized
INFO - 2022-03-10 03:12:46 --> Language Class Initialized
INFO - 2022-03-10 03:12:46 --> Loader Class Initialized
INFO - 2022-03-10 03:12:46 --> Helper loaded: url_helper
INFO - 2022-03-10 03:12:46 --> Helper loaded: form_helper
INFO - 2022-03-10 03:12:46 --> Helper loaded: common_helper
INFO - 2022-03-10 03:12:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:12:46 --> Controller Class Initialized
INFO - 2022-03-10 03:12:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:12:46 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:12:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:12:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:12:46 --> Email Class Initialized
INFO - 2022-03-10 03:12:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:12:46 --> Calendar Class Initialized
INFO - 2022-03-10 03:12:46 --> Model "Login_model" initialized
INFO - 2022-03-10 03:12:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 03:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:12:47 --> Config Class Initialized
INFO - 2022-03-10 03:12:47 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:12:47 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:12:47 --> Utf8 Class Initialized
INFO - 2022-03-10 03:12:47 --> URI Class Initialized
INFO - 2022-03-10 03:12:47 --> Router Class Initialized
INFO - 2022-03-10 03:12:47 --> Output Class Initialized
INFO - 2022-03-10 03:12:47 --> Security Class Initialized
DEBUG - 2022-03-10 03:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:12:47 --> Input Class Initialized
INFO - 2022-03-10 03:12:47 --> Language Class Initialized
INFO - 2022-03-10 03:12:47 --> Loader Class Initialized
INFO - 2022-03-10 03:12:47 --> Helper loaded: url_helper
INFO - 2022-03-10 03:12:47 --> Helper loaded: form_helper
INFO - 2022-03-10 03:12:47 --> Helper loaded: common_helper
INFO - 2022-03-10 03:12:47 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:12:47 --> Controller Class Initialized
INFO - 2022-03-10 03:12:47 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:12:47 --> Encrypt Class Initialized
INFO - 2022-03-10 03:12:47 --> Model "Login_model" initialized
INFO - 2022-03-10 03:12:47 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 03:12:47 --> Model "Case_model" initialized
INFO - 2022-03-10 03:12:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:12:47 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 03:12:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:12:47 --> Final output sent to browser
DEBUG - 2022-03-10 03:12:47 --> Total execution time: 0.1846
ERROR - 2022-03-10 03:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:13:10 --> Config Class Initialized
INFO - 2022-03-10 03:13:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:13:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:13:10 --> Utf8 Class Initialized
INFO - 2022-03-10 03:13:10 --> URI Class Initialized
INFO - 2022-03-10 03:13:10 --> Router Class Initialized
INFO - 2022-03-10 03:13:10 --> Output Class Initialized
INFO - 2022-03-10 03:13:10 --> Security Class Initialized
DEBUG - 2022-03-10 03:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:13:10 --> Input Class Initialized
INFO - 2022-03-10 03:13:10 --> Language Class Initialized
INFO - 2022-03-10 03:13:10 --> Loader Class Initialized
INFO - 2022-03-10 03:13:10 --> Helper loaded: url_helper
INFO - 2022-03-10 03:13:10 --> Helper loaded: form_helper
INFO - 2022-03-10 03:13:10 --> Helper loaded: common_helper
INFO - 2022-03-10 03:13:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:13:10 --> Controller Class Initialized
INFO - 2022-03-10 03:13:10 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:13:10 --> Encrypt Class Initialized
INFO - 2022-03-10 03:13:10 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:13:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:13:10 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:13:10 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:13:10 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:13:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:13:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 03:13:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:13:10 --> Final output sent to browser
DEBUG - 2022-03-10 03:13:10 --> Total execution time: 0.0626
ERROR - 2022-03-10 03:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:13:25 --> Config Class Initialized
INFO - 2022-03-10 03:13:25 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:13:25 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:13:25 --> Utf8 Class Initialized
INFO - 2022-03-10 03:13:25 --> URI Class Initialized
INFO - 2022-03-10 03:13:25 --> Router Class Initialized
INFO - 2022-03-10 03:13:25 --> Output Class Initialized
INFO - 2022-03-10 03:13:25 --> Security Class Initialized
DEBUG - 2022-03-10 03:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:13:25 --> Input Class Initialized
INFO - 2022-03-10 03:13:25 --> Language Class Initialized
INFO - 2022-03-10 03:13:25 --> Loader Class Initialized
INFO - 2022-03-10 03:13:25 --> Helper loaded: url_helper
INFO - 2022-03-10 03:13:25 --> Helper loaded: form_helper
INFO - 2022-03-10 03:13:25 --> Helper loaded: common_helper
INFO - 2022-03-10 03:13:25 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:13:25 --> Controller Class Initialized
INFO - 2022-03-10 03:13:25 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:13:25 --> Encrypt Class Initialized
INFO - 2022-03-10 03:13:25 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:13:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:13:25 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:13:25 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:13:25 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:13:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:13:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:13:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:13:25 --> Final output sent to browser
DEBUG - 2022-03-10 03:13:25 --> Total execution time: 0.1607
ERROR - 2022-03-10 03:16:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:16:46 --> Config Class Initialized
INFO - 2022-03-10 03:16:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:16:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:16:46 --> Utf8 Class Initialized
INFO - 2022-03-10 03:16:46 --> URI Class Initialized
INFO - 2022-03-10 03:16:46 --> Router Class Initialized
INFO - 2022-03-10 03:16:46 --> Output Class Initialized
INFO - 2022-03-10 03:16:46 --> Security Class Initialized
DEBUG - 2022-03-10 03:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:16:46 --> Input Class Initialized
INFO - 2022-03-10 03:16:46 --> Language Class Initialized
INFO - 2022-03-10 03:16:46 --> Loader Class Initialized
INFO - 2022-03-10 03:16:46 --> Helper loaded: url_helper
INFO - 2022-03-10 03:16:46 --> Helper loaded: form_helper
INFO - 2022-03-10 03:16:46 --> Helper loaded: common_helper
INFO - 2022-03-10 03:16:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:16:46 --> Controller Class Initialized
INFO - 2022-03-10 03:16:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:16:46 --> Encrypt Class Initialized
INFO - 2022-03-10 03:16:46 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:16:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:16:46 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:16:46 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:16:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:16:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:16:46 --> Config Class Initialized
INFO - 2022-03-10 03:16:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:16:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:16:46 --> Utf8 Class Initialized
INFO - 2022-03-10 03:16:46 --> URI Class Initialized
INFO - 2022-03-10 03:16:46 --> Router Class Initialized
INFO - 2022-03-10 03:16:46 --> Output Class Initialized
INFO - 2022-03-10 03:16:46 --> Security Class Initialized
DEBUG - 2022-03-10 03:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:16:46 --> Input Class Initialized
INFO - 2022-03-10 03:16:46 --> Language Class Initialized
INFO - 2022-03-10 03:16:46 --> Loader Class Initialized
INFO - 2022-03-10 03:16:46 --> Helper loaded: url_helper
INFO - 2022-03-10 03:16:46 --> Helper loaded: form_helper
INFO - 2022-03-10 03:16:46 --> Helper loaded: common_helper
INFO - 2022-03-10 03:16:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:16:46 --> Controller Class Initialized
INFO - 2022-03-10 03:16:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:16:46 --> Encrypt Class Initialized
INFO - 2022-03-10 03:16:46 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:16:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:16:46 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:16:46 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:16:46 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:16:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:16:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:16:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:16:47 --> Final output sent to browser
DEBUG - 2022-03-10 03:16:47 --> Total execution time: 0.2605
ERROR - 2022-03-10 03:16:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:16:48 --> Config Class Initialized
INFO - 2022-03-10 03:16:48 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:16:48 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:16:48 --> Utf8 Class Initialized
INFO - 2022-03-10 03:16:48 --> URI Class Initialized
INFO - 2022-03-10 03:16:48 --> Router Class Initialized
INFO - 2022-03-10 03:16:48 --> Output Class Initialized
INFO - 2022-03-10 03:16:48 --> Security Class Initialized
DEBUG - 2022-03-10 03:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:16:48 --> Input Class Initialized
INFO - 2022-03-10 03:16:48 --> Language Class Initialized
INFO - 2022-03-10 03:16:48 --> Loader Class Initialized
INFO - 2022-03-10 03:16:48 --> Helper loaded: url_helper
INFO - 2022-03-10 03:16:48 --> Helper loaded: form_helper
INFO - 2022-03-10 03:16:48 --> Helper loaded: common_helper
INFO - 2022-03-10 03:16:48 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:16:48 --> Controller Class Initialized
INFO - 2022-03-10 03:16:48 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:16:48 --> Encrypt Class Initialized
INFO - 2022-03-10 03:16:48 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:16:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:16:48 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:16:48 --> Model "Users_model" initialized
INFO - 2022-03-10 03:16:48 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:16:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:16:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:16:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:16:48 --> Final output sent to browser
DEBUG - 2022-03-10 03:16:48 --> Total execution time: 0.0733
ERROR - 2022-03-10 03:17:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:17:19 --> Config Class Initialized
INFO - 2022-03-10 03:17:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:17:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:17:19 --> Utf8 Class Initialized
INFO - 2022-03-10 03:17:19 --> URI Class Initialized
INFO - 2022-03-10 03:17:19 --> Router Class Initialized
INFO - 2022-03-10 03:17:19 --> Output Class Initialized
INFO - 2022-03-10 03:17:19 --> Security Class Initialized
DEBUG - 2022-03-10 03:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:17:19 --> Input Class Initialized
INFO - 2022-03-10 03:17:19 --> Language Class Initialized
INFO - 2022-03-10 03:17:19 --> Loader Class Initialized
INFO - 2022-03-10 03:17:19 --> Helper loaded: url_helper
INFO - 2022-03-10 03:17:19 --> Helper loaded: form_helper
INFO - 2022-03-10 03:17:19 --> Helper loaded: common_helper
INFO - 2022-03-10 03:17:19 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:17:19 --> Controller Class Initialized
INFO - 2022-03-10 03:17:19 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:17:19 --> Encrypt Class Initialized
INFO - 2022-03-10 03:17:19 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:17:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:17:19 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:17:19 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:17:19 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:17:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:17:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:17:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:17:19 --> Final output sent to browser
DEBUG - 2022-03-10 03:17:19 --> Total execution time: 0.0507
ERROR - 2022-03-10 03:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:19:06 --> Config Class Initialized
INFO - 2022-03-10 03:19:06 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:19:06 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:19:06 --> Utf8 Class Initialized
INFO - 2022-03-10 03:19:06 --> URI Class Initialized
INFO - 2022-03-10 03:19:06 --> Router Class Initialized
INFO - 2022-03-10 03:19:06 --> Output Class Initialized
INFO - 2022-03-10 03:19:06 --> Security Class Initialized
DEBUG - 2022-03-10 03:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:19:06 --> Input Class Initialized
INFO - 2022-03-10 03:19:06 --> Language Class Initialized
INFO - 2022-03-10 03:19:06 --> Loader Class Initialized
INFO - 2022-03-10 03:19:06 --> Helper loaded: url_helper
INFO - 2022-03-10 03:19:06 --> Helper loaded: form_helper
INFO - 2022-03-10 03:19:06 --> Helper loaded: common_helper
INFO - 2022-03-10 03:19:06 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:19:06 --> Controller Class Initialized
INFO - 2022-03-10 03:19:06 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:19:06 --> Encrypt Class Initialized
INFO - 2022-03-10 03:19:06 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:19:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:19:06 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:19:06 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:19:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:19:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:19:07 --> Config Class Initialized
INFO - 2022-03-10 03:19:07 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:19:07 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:19:07 --> Utf8 Class Initialized
INFO - 2022-03-10 03:19:07 --> URI Class Initialized
INFO - 2022-03-10 03:19:07 --> Router Class Initialized
INFO - 2022-03-10 03:19:07 --> Output Class Initialized
INFO - 2022-03-10 03:19:07 --> Security Class Initialized
DEBUG - 2022-03-10 03:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:19:07 --> Input Class Initialized
INFO - 2022-03-10 03:19:07 --> Language Class Initialized
INFO - 2022-03-10 03:19:07 --> Loader Class Initialized
INFO - 2022-03-10 03:19:07 --> Helper loaded: url_helper
INFO - 2022-03-10 03:19:07 --> Helper loaded: form_helper
INFO - 2022-03-10 03:19:07 --> Helper loaded: common_helper
INFO - 2022-03-10 03:19:07 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:19:07 --> Controller Class Initialized
INFO - 2022-03-10 03:19:07 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:19:07 --> Encrypt Class Initialized
INFO - 2022-03-10 03:19:07 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:19:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:19:07 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:19:07 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:19:07 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:19:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:19:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:19:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:19:07 --> Final output sent to browser
DEBUG - 2022-03-10 03:19:07 --> Total execution time: 0.0732
ERROR - 2022-03-10 03:19:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:19:08 --> Config Class Initialized
INFO - 2022-03-10 03:19:08 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:19:08 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:19:08 --> Utf8 Class Initialized
INFO - 2022-03-10 03:19:08 --> URI Class Initialized
INFO - 2022-03-10 03:19:08 --> Router Class Initialized
INFO - 2022-03-10 03:19:08 --> Output Class Initialized
INFO - 2022-03-10 03:19:08 --> Security Class Initialized
DEBUG - 2022-03-10 03:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:19:08 --> Input Class Initialized
INFO - 2022-03-10 03:19:08 --> Language Class Initialized
INFO - 2022-03-10 03:19:08 --> Loader Class Initialized
INFO - 2022-03-10 03:19:08 --> Helper loaded: url_helper
INFO - 2022-03-10 03:19:08 --> Helper loaded: form_helper
INFO - 2022-03-10 03:19:08 --> Helper loaded: common_helper
INFO - 2022-03-10 03:19:08 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:19:08 --> Controller Class Initialized
INFO - 2022-03-10 03:19:08 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:19:08 --> Encrypt Class Initialized
INFO - 2022-03-10 03:19:08 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:19:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:19:08 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:19:08 --> Model "Users_model" initialized
INFO - 2022-03-10 03:19:08 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:19:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:19:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:19:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:19:08 --> Final output sent to browser
DEBUG - 2022-03-10 03:19:08 --> Total execution time: 0.0682
ERROR - 2022-03-10 03:19:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:19:35 --> Config Class Initialized
INFO - 2022-03-10 03:19:35 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:19:35 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:19:35 --> Utf8 Class Initialized
INFO - 2022-03-10 03:19:35 --> URI Class Initialized
INFO - 2022-03-10 03:19:35 --> Router Class Initialized
INFO - 2022-03-10 03:19:35 --> Output Class Initialized
INFO - 2022-03-10 03:19:35 --> Security Class Initialized
DEBUG - 2022-03-10 03:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:19:35 --> Input Class Initialized
INFO - 2022-03-10 03:19:35 --> Language Class Initialized
INFO - 2022-03-10 03:19:35 --> Loader Class Initialized
INFO - 2022-03-10 03:19:35 --> Helper loaded: url_helper
INFO - 2022-03-10 03:19:35 --> Helper loaded: form_helper
INFO - 2022-03-10 03:19:35 --> Helper loaded: common_helper
INFO - 2022-03-10 03:19:35 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:19:35 --> Controller Class Initialized
INFO - 2022-03-10 03:19:35 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:19:35 --> Encrypt Class Initialized
INFO - 2022-03-10 03:19:35 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:19:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:19:35 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:19:35 --> Model "Users_model" initialized
INFO - 2022-03-10 03:19:35 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:19:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:19:35 --> Config Class Initialized
INFO - 2022-03-10 03:19:35 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:19:35 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:19:35 --> Utf8 Class Initialized
INFO - 2022-03-10 03:19:35 --> URI Class Initialized
INFO - 2022-03-10 03:19:35 --> Router Class Initialized
INFO - 2022-03-10 03:19:35 --> Output Class Initialized
INFO - 2022-03-10 03:19:35 --> Security Class Initialized
DEBUG - 2022-03-10 03:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:19:35 --> Input Class Initialized
INFO - 2022-03-10 03:19:35 --> Language Class Initialized
INFO - 2022-03-10 03:19:35 --> Loader Class Initialized
INFO - 2022-03-10 03:19:35 --> Helper loaded: url_helper
INFO - 2022-03-10 03:19:35 --> Helper loaded: form_helper
INFO - 2022-03-10 03:19:35 --> Helper loaded: common_helper
INFO - 2022-03-10 03:19:35 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:19:35 --> Controller Class Initialized
INFO - 2022-03-10 03:19:35 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:19:35 --> Encrypt Class Initialized
INFO - 2022-03-10 03:19:35 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:19:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:19:35 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:19:35 --> Model "Users_model" initialized
INFO - 2022-03-10 03:19:35 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:19:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:19:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:19:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:19:36 --> Final output sent to browser
DEBUG - 2022-03-10 03:19:36 --> Total execution time: 0.0810
ERROR - 2022-03-10 03:23:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:23:04 --> Config Class Initialized
INFO - 2022-03-10 03:23:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:23:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:23:04 --> Utf8 Class Initialized
INFO - 2022-03-10 03:23:04 --> URI Class Initialized
INFO - 2022-03-10 03:23:04 --> Router Class Initialized
INFO - 2022-03-10 03:23:04 --> Output Class Initialized
INFO - 2022-03-10 03:23:04 --> Security Class Initialized
DEBUG - 2022-03-10 03:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:23:04 --> Input Class Initialized
INFO - 2022-03-10 03:23:04 --> Language Class Initialized
INFO - 2022-03-10 03:23:04 --> Loader Class Initialized
INFO - 2022-03-10 03:23:04 --> Helper loaded: url_helper
INFO - 2022-03-10 03:23:04 --> Helper loaded: form_helper
INFO - 2022-03-10 03:23:04 --> Helper loaded: common_helper
INFO - 2022-03-10 03:23:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:23:04 --> Controller Class Initialized
ERROR - 2022-03-10 03:23:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:23:04 --> Config Class Initialized
INFO - 2022-03-10 03:23:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:23:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:23:04 --> Utf8 Class Initialized
INFO - 2022-03-10 03:23:04 --> URI Class Initialized
INFO - 2022-03-10 03:23:04 --> Router Class Initialized
INFO - 2022-03-10 03:23:04 --> Output Class Initialized
INFO - 2022-03-10 03:23:04 --> Security Class Initialized
DEBUG - 2022-03-10 03:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:23:04 --> Input Class Initialized
INFO - 2022-03-10 03:23:04 --> Language Class Initialized
INFO - 2022-03-10 03:23:04 --> Loader Class Initialized
INFO - 2022-03-10 03:23:04 --> Helper loaded: url_helper
INFO - 2022-03-10 03:23:04 --> Helper loaded: form_helper
INFO - 2022-03-10 03:23:04 --> Helper loaded: common_helper
INFO - 2022-03-10 03:23:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:23:04 --> Controller Class Initialized
INFO - 2022-03-10 03:23:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:23:04 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:23:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:23:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:23:04 --> Email Class Initialized
INFO - 2022-03-10 03:23:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:23:04 --> Calendar Class Initialized
INFO - 2022-03-10 03:23:04 --> Model "Login_model" initialized
INFO - 2022-03-10 03:23:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 03:23:04 --> Final output sent to browser
DEBUG - 2022-03-10 03:23:04 --> Total execution time: 0.0227
ERROR - 2022-03-10 03:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:23:09 --> Config Class Initialized
INFO - 2022-03-10 03:23:09 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:23:09 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:23:09 --> Utf8 Class Initialized
INFO - 2022-03-10 03:23:09 --> URI Class Initialized
INFO - 2022-03-10 03:23:09 --> Router Class Initialized
INFO - 2022-03-10 03:23:09 --> Output Class Initialized
INFO - 2022-03-10 03:23:09 --> Security Class Initialized
DEBUG - 2022-03-10 03:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:23:09 --> Input Class Initialized
INFO - 2022-03-10 03:23:09 --> Language Class Initialized
INFO - 2022-03-10 03:23:09 --> Loader Class Initialized
INFO - 2022-03-10 03:23:09 --> Helper loaded: url_helper
INFO - 2022-03-10 03:23:09 --> Helper loaded: form_helper
INFO - 2022-03-10 03:23:09 --> Helper loaded: common_helper
INFO - 2022-03-10 03:23:09 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:23:09 --> Controller Class Initialized
INFO - 2022-03-10 03:23:09 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:23:09 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:23:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:23:09 --> Email Class Initialized
INFO - 2022-03-10 03:23:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:23:09 --> Calendar Class Initialized
INFO - 2022-03-10 03:23:09 --> Model "Login_model" initialized
INFO - 2022-03-10 03:23:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 03:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:23:09 --> Config Class Initialized
INFO - 2022-03-10 03:23:09 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:23:09 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:23:09 --> Utf8 Class Initialized
INFO - 2022-03-10 03:23:09 --> URI Class Initialized
INFO - 2022-03-10 03:23:09 --> Router Class Initialized
INFO - 2022-03-10 03:23:09 --> Output Class Initialized
INFO - 2022-03-10 03:23:09 --> Security Class Initialized
DEBUG - 2022-03-10 03:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:23:09 --> Input Class Initialized
INFO - 2022-03-10 03:23:09 --> Language Class Initialized
INFO - 2022-03-10 03:23:09 --> Loader Class Initialized
INFO - 2022-03-10 03:23:09 --> Helper loaded: url_helper
INFO - 2022-03-10 03:23:09 --> Helper loaded: form_helper
INFO - 2022-03-10 03:23:09 --> Helper loaded: common_helper
INFO - 2022-03-10 03:23:09 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:23:09 --> Controller Class Initialized
INFO - 2022-03-10 03:23:09 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:23:09 --> Encrypt Class Initialized
INFO - 2022-03-10 03:23:09 --> Model "Login_model" initialized
INFO - 2022-03-10 03:23:09 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 03:23:09 --> Model "Case_model" initialized
INFO - 2022-03-10 03:23:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-10 03:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:23:23 --> Config Class Initialized
INFO - 2022-03-10 03:23:23 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:23:23 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:23:23 --> Utf8 Class Initialized
INFO - 2022-03-10 03:23:23 --> URI Class Initialized
INFO - 2022-03-10 03:23:23 --> Router Class Initialized
INFO - 2022-03-10 03:23:23 --> Output Class Initialized
INFO - 2022-03-10 03:23:23 --> Security Class Initialized
DEBUG - 2022-03-10 03:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:23:23 --> Input Class Initialized
INFO - 2022-03-10 03:23:23 --> Language Class Initialized
INFO - 2022-03-10 03:23:23 --> Loader Class Initialized
INFO - 2022-03-10 03:23:23 --> Helper loaded: url_helper
INFO - 2022-03-10 03:23:23 --> Helper loaded: form_helper
INFO - 2022-03-10 03:23:23 --> Helper loaded: common_helper
INFO - 2022-03-10 03:23:23 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-10 03:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:23:23 --> Config Class Initialized
INFO - 2022-03-10 03:23:23 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:23:23 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:23:23 --> Utf8 Class Initialized
INFO - 2022-03-10 03:23:23 --> URI Class Initialized
INFO - 2022-03-10 03:23:23 --> Router Class Initialized
INFO - 2022-03-10 03:23:23 --> Output Class Initialized
INFO - 2022-03-10 03:23:23 --> Security Class Initialized
DEBUG - 2022-03-10 03:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:23:23 --> Input Class Initialized
INFO - 2022-03-10 03:23:23 --> Language Class Initialized
INFO - 2022-03-10 03:23:23 --> Loader Class Initialized
INFO - 2022-03-10 03:23:23 --> Helper loaded: url_helper
INFO - 2022-03-10 03:23:23 --> Helper loaded: form_helper
INFO - 2022-03-10 03:23:23 --> Helper loaded: common_helper
INFO - 2022-03-10 03:23:23 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:23:27 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 03:23:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:23:27 --> Final output sent to browser
DEBUG - 2022-03-10 03:23:27 --> Total execution time: 18.2232
INFO - 2022-03-10 03:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:23:27 --> Controller Class Initialized
INFO - 2022-03-10 03:23:27 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:23:27 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:23:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:23:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:23:27 --> Email Class Initialized
INFO - 2022-03-10 03:23:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:23:27 --> Calendar Class Initialized
INFO - 2022-03-10 03:23:27 --> Model "Login_model" initialized
INFO - 2022-03-10 03:23:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-10 03:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:23:27 --> Controller Class Initialized
INFO - 2022-03-10 03:23:27 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:23:27 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:23:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:23:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:23:27 --> Email Class Initialized
INFO - 2022-03-10 03:23:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:23:27 --> Calendar Class Initialized
INFO - 2022-03-10 03:23:27 --> Model "Login_model" initialized
INFO - 2022-03-10 03:23:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 03:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:23:28 --> Config Class Initialized
INFO - 2022-03-10 03:23:28 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:23:28 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:23:28 --> Utf8 Class Initialized
INFO - 2022-03-10 03:23:28 --> URI Class Initialized
INFO - 2022-03-10 03:23:28 --> Router Class Initialized
INFO - 2022-03-10 03:23:28 --> Output Class Initialized
INFO - 2022-03-10 03:23:28 --> Security Class Initialized
DEBUG - 2022-03-10 03:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:23:28 --> Input Class Initialized
INFO - 2022-03-10 03:23:28 --> Language Class Initialized
INFO - 2022-03-10 03:23:28 --> Loader Class Initialized
INFO - 2022-03-10 03:23:28 --> Helper loaded: url_helper
INFO - 2022-03-10 03:23:28 --> Helper loaded: form_helper
INFO - 2022-03-10 03:23:28 --> Helper loaded: common_helper
INFO - 2022-03-10 03:23:28 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:23:28 --> Controller Class Initialized
INFO - 2022-03-10 03:23:28 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:23:28 --> Encrypt Class Initialized
INFO - 2022-03-10 03:23:28 --> Model "Login_model" initialized
INFO - 2022-03-10 03:23:28 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 03:23:28 --> Model "Case_model" initialized
INFO - 2022-03-10 03:23:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:23:46 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 03:23:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:23:46 --> Final output sent to browser
DEBUG - 2022-03-10 03:23:46 --> Total execution time: 17.8391
ERROR - 2022-03-10 03:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:24:53 --> Config Class Initialized
INFO - 2022-03-10 03:24:53 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:24:53 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:24:53 --> Utf8 Class Initialized
INFO - 2022-03-10 03:24:53 --> URI Class Initialized
INFO - 2022-03-10 03:24:53 --> Router Class Initialized
INFO - 2022-03-10 03:24:53 --> Output Class Initialized
INFO - 2022-03-10 03:24:53 --> Security Class Initialized
DEBUG - 2022-03-10 03:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:24:53 --> Input Class Initialized
INFO - 2022-03-10 03:24:53 --> Language Class Initialized
INFO - 2022-03-10 03:24:53 --> Loader Class Initialized
INFO - 2022-03-10 03:24:53 --> Helper loaded: url_helper
INFO - 2022-03-10 03:24:53 --> Helper loaded: form_helper
INFO - 2022-03-10 03:24:53 --> Helper loaded: common_helper
INFO - 2022-03-10 03:24:53 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:24:53 --> Controller Class Initialized
INFO - 2022-03-10 03:24:53 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:24:53 --> Encrypt Class Initialized
INFO - 2022-03-10 03:24:53 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:24:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:24:53 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:24:53 --> Model "Users_model" initialized
INFO - 2022-03-10 03:24:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:24:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:24:54 --> Config Class Initialized
INFO - 2022-03-10 03:24:54 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:24:54 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:24:54 --> Utf8 Class Initialized
INFO - 2022-03-10 03:24:54 --> URI Class Initialized
INFO - 2022-03-10 03:24:54 --> Router Class Initialized
INFO - 2022-03-10 03:24:54 --> Output Class Initialized
INFO - 2022-03-10 03:24:54 --> Security Class Initialized
DEBUG - 2022-03-10 03:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:24:54 --> Input Class Initialized
INFO - 2022-03-10 03:24:54 --> Language Class Initialized
INFO - 2022-03-10 03:24:54 --> Loader Class Initialized
INFO - 2022-03-10 03:24:54 --> Helper loaded: url_helper
INFO - 2022-03-10 03:24:54 --> Helper loaded: form_helper
INFO - 2022-03-10 03:24:54 --> Helper loaded: common_helper
INFO - 2022-03-10 03:24:54 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:24:54 --> Controller Class Initialized
INFO - 2022-03-10 03:24:54 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:24:54 --> Encrypt Class Initialized
INFO - 2022-03-10 03:24:54 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:24:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:24:54 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:24:54 --> Model "Users_model" initialized
INFO - 2022-03-10 03:24:54 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:24:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:24:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:24:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:24:54 --> Final output sent to browser
DEBUG - 2022-03-10 03:24:54 --> Total execution time: 0.0696
ERROR - 2022-03-10 03:25:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:25:51 --> Config Class Initialized
INFO - 2022-03-10 03:25:51 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:25:51 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:25:51 --> Utf8 Class Initialized
INFO - 2022-03-10 03:25:51 --> URI Class Initialized
INFO - 2022-03-10 03:25:51 --> Router Class Initialized
INFO - 2022-03-10 03:25:51 --> Output Class Initialized
INFO - 2022-03-10 03:25:51 --> Security Class Initialized
DEBUG - 2022-03-10 03:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:25:51 --> Input Class Initialized
INFO - 2022-03-10 03:25:51 --> Language Class Initialized
INFO - 2022-03-10 03:25:51 --> Loader Class Initialized
INFO - 2022-03-10 03:25:51 --> Helper loaded: url_helper
INFO - 2022-03-10 03:25:51 --> Helper loaded: form_helper
INFO - 2022-03-10 03:25:51 --> Helper loaded: common_helper
INFO - 2022-03-10 03:25:51 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:25:51 --> Controller Class Initialized
INFO - 2022-03-10 03:25:51 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:25:51 --> Encrypt Class Initialized
INFO - 2022-03-10 03:25:51 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:25:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:25:51 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:25:51 --> Model "Users_model" initialized
INFO - 2022-03-10 03:25:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:25:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:25:51 --> Config Class Initialized
INFO - 2022-03-10 03:25:51 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:25:51 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:25:51 --> Utf8 Class Initialized
INFO - 2022-03-10 03:25:51 --> URI Class Initialized
INFO - 2022-03-10 03:25:51 --> Router Class Initialized
INFO - 2022-03-10 03:25:51 --> Output Class Initialized
INFO - 2022-03-10 03:25:51 --> Security Class Initialized
DEBUG - 2022-03-10 03:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:25:51 --> Input Class Initialized
INFO - 2022-03-10 03:25:51 --> Language Class Initialized
INFO - 2022-03-10 03:25:51 --> Loader Class Initialized
INFO - 2022-03-10 03:25:51 --> Helper loaded: url_helper
INFO - 2022-03-10 03:25:51 --> Helper loaded: form_helper
INFO - 2022-03-10 03:25:51 --> Helper loaded: common_helper
INFO - 2022-03-10 03:25:51 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:25:51 --> Controller Class Initialized
INFO - 2022-03-10 03:25:51 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:25:51 --> Encrypt Class Initialized
INFO - 2022-03-10 03:25:51 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:25:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:25:51 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:25:51 --> Model "Users_model" initialized
INFO - 2022-03-10 03:25:51 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:25:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:25:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:25:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:25:51 --> Final output sent to browser
DEBUG - 2022-03-10 03:25:51 --> Total execution time: 0.0516
ERROR - 2022-03-10 03:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:26:02 --> Config Class Initialized
INFO - 2022-03-10 03:26:02 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:26:02 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:26:02 --> Utf8 Class Initialized
INFO - 2022-03-10 03:26:02 --> URI Class Initialized
DEBUG - 2022-03-10 03:26:02 --> No URI present. Default controller set.
INFO - 2022-03-10 03:26:02 --> Router Class Initialized
INFO - 2022-03-10 03:26:02 --> Output Class Initialized
INFO - 2022-03-10 03:26:02 --> Security Class Initialized
DEBUG - 2022-03-10 03:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:26:02 --> Input Class Initialized
INFO - 2022-03-10 03:26:02 --> Language Class Initialized
INFO - 2022-03-10 03:26:02 --> Loader Class Initialized
INFO - 2022-03-10 03:26:02 --> Helper loaded: url_helper
INFO - 2022-03-10 03:26:02 --> Helper loaded: form_helper
INFO - 2022-03-10 03:26:02 --> Helper loaded: common_helper
INFO - 2022-03-10 03:26:02 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:26:02 --> Controller Class Initialized
INFO - 2022-03-10 03:26:02 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:26:02 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:26:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:26:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:26:02 --> Email Class Initialized
INFO - 2022-03-10 03:26:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:26:02 --> Calendar Class Initialized
INFO - 2022-03-10 03:26:02 --> Model "Login_model" initialized
ERROR - 2022-03-10 03:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:26:02 --> Config Class Initialized
INFO - 2022-03-10 03:26:02 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:26:02 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:26:02 --> Utf8 Class Initialized
INFO - 2022-03-10 03:26:02 --> URI Class Initialized
INFO - 2022-03-10 03:26:02 --> Router Class Initialized
INFO - 2022-03-10 03:26:02 --> Output Class Initialized
INFO - 2022-03-10 03:26:02 --> Security Class Initialized
DEBUG - 2022-03-10 03:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:26:02 --> Input Class Initialized
INFO - 2022-03-10 03:26:02 --> Language Class Initialized
INFO - 2022-03-10 03:26:02 --> Loader Class Initialized
INFO - 2022-03-10 03:26:02 --> Helper loaded: url_helper
INFO - 2022-03-10 03:26:02 --> Helper loaded: form_helper
INFO - 2022-03-10 03:26:02 --> Helper loaded: common_helper
INFO - 2022-03-10 03:26:02 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:26:02 --> Controller Class Initialized
INFO - 2022-03-10 03:26:02 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:26:02 --> Encrypt Class Initialized
INFO - 2022-03-10 03:26:02 --> Model "Diseases_model" initialized
INFO - 2022-03-10 03:26:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:26:02 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-10 03:26:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:26:02 --> Final output sent to browser
DEBUG - 2022-03-10 03:26:02 --> Total execution time: 0.0278
ERROR - 2022-03-10 03:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:26:04 --> Config Class Initialized
INFO - 2022-03-10 03:26:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:26:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:26:04 --> Utf8 Class Initialized
INFO - 2022-03-10 03:26:04 --> URI Class Initialized
DEBUG - 2022-03-10 03:26:04 --> No URI present. Default controller set.
INFO - 2022-03-10 03:26:04 --> Router Class Initialized
INFO - 2022-03-10 03:26:04 --> Output Class Initialized
INFO - 2022-03-10 03:26:04 --> Security Class Initialized
DEBUG - 2022-03-10 03:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:26:04 --> Input Class Initialized
INFO - 2022-03-10 03:26:04 --> Language Class Initialized
INFO - 2022-03-10 03:26:04 --> Loader Class Initialized
INFO - 2022-03-10 03:26:04 --> Helper loaded: url_helper
INFO - 2022-03-10 03:26:04 --> Helper loaded: form_helper
INFO - 2022-03-10 03:26:04 --> Helper loaded: common_helper
INFO - 2022-03-10 03:26:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:26:04 --> Controller Class Initialized
INFO - 2022-03-10 03:26:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:26:04 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:26:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:26:04 --> Email Class Initialized
INFO - 2022-03-10 03:26:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:26:04 --> Calendar Class Initialized
INFO - 2022-03-10 03:26:04 --> Model "Login_model" initialized
ERROR - 2022-03-10 03:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:26:04 --> Config Class Initialized
INFO - 2022-03-10 03:26:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:26:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:26:04 --> Utf8 Class Initialized
INFO - 2022-03-10 03:26:04 --> URI Class Initialized
INFO - 2022-03-10 03:26:04 --> Router Class Initialized
INFO - 2022-03-10 03:26:04 --> Output Class Initialized
INFO - 2022-03-10 03:26:04 --> Security Class Initialized
DEBUG - 2022-03-10 03:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:26:04 --> Input Class Initialized
INFO - 2022-03-10 03:26:04 --> Language Class Initialized
INFO - 2022-03-10 03:26:04 --> Loader Class Initialized
INFO - 2022-03-10 03:26:04 --> Helper loaded: url_helper
INFO - 2022-03-10 03:26:04 --> Helper loaded: form_helper
INFO - 2022-03-10 03:26:04 --> Helper loaded: common_helper
INFO - 2022-03-10 03:26:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:26:04 --> Controller Class Initialized
INFO - 2022-03-10 03:26:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:26:04 --> Encrypt Class Initialized
INFO - 2022-03-10 03:26:04 --> Model "Diseases_model" initialized
INFO - 2022-03-10 03:26:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:26:04 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-10 03:26:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:26:04 --> Final output sent to browser
DEBUG - 2022-03-10 03:26:04 --> Total execution time: 0.0215
ERROR - 2022-03-10 03:26:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:26:16 --> Config Class Initialized
INFO - 2022-03-10 03:26:16 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:26:16 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:26:16 --> Utf8 Class Initialized
INFO - 2022-03-10 03:26:16 --> URI Class Initialized
INFO - 2022-03-10 03:26:16 --> Router Class Initialized
INFO - 2022-03-10 03:26:16 --> Output Class Initialized
INFO - 2022-03-10 03:26:16 --> Security Class Initialized
DEBUG - 2022-03-10 03:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:26:16 --> Input Class Initialized
INFO - 2022-03-10 03:26:16 --> Language Class Initialized
INFO - 2022-03-10 03:26:16 --> Loader Class Initialized
INFO - 2022-03-10 03:26:16 --> Helper loaded: url_helper
INFO - 2022-03-10 03:26:16 --> Helper loaded: form_helper
INFO - 2022-03-10 03:26:16 --> Helper loaded: common_helper
INFO - 2022-03-10 03:26:16 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:26:16 --> Controller Class Initialized
INFO - 2022-03-10 03:26:16 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:26:16 --> Encrypt Class Initialized
INFO - 2022-03-10 03:26:16 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:26:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:26:16 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:26:16 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:26:16 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:26:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:26:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:26:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:26:16 --> Final output sent to browser
DEBUG - 2022-03-10 03:26:16 --> Total execution time: 0.0317
ERROR - 2022-03-10 03:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:26:28 --> Config Class Initialized
INFO - 2022-03-10 03:26:28 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:26:28 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:26:28 --> Utf8 Class Initialized
INFO - 2022-03-10 03:26:28 --> URI Class Initialized
INFO - 2022-03-10 03:26:28 --> Router Class Initialized
INFO - 2022-03-10 03:26:28 --> Output Class Initialized
INFO - 2022-03-10 03:26:28 --> Security Class Initialized
DEBUG - 2022-03-10 03:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:26:28 --> Input Class Initialized
INFO - 2022-03-10 03:26:28 --> Language Class Initialized
INFO - 2022-03-10 03:26:28 --> Loader Class Initialized
INFO - 2022-03-10 03:26:28 --> Helper loaded: url_helper
INFO - 2022-03-10 03:26:28 --> Helper loaded: form_helper
INFO - 2022-03-10 03:26:28 --> Helper loaded: common_helper
INFO - 2022-03-10 03:26:28 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:26:29 --> Controller Class Initialized
INFO - 2022-03-10 03:26:29 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:26:29 --> Encrypt Class Initialized
INFO - 2022-03-10 03:26:29 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:26:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:26:29 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:26:29 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:26:29 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:26:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:26:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:26:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:26:29 --> Final output sent to browser
DEBUG - 2022-03-10 03:26:29 --> Total execution time: 0.6774
ERROR - 2022-03-10 03:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:26:54 --> Config Class Initialized
INFO - 2022-03-10 03:26:54 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:26:54 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:26:54 --> Utf8 Class Initialized
INFO - 2022-03-10 03:26:54 --> URI Class Initialized
INFO - 2022-03-10 03:26:54 --> Router Class Initialized
INFO - 2022-03-10 03:26:54 --> Output Class Initialized
INFO - 2022-03-10 03:26:54 --> Security Class Initialized
DEBUG - 2022-03-10 03:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:26:54 --> Input Class Initialized
INFO - 2022-03-10 03:26:54 --> Language Class Initialized
INFO - 2022-03-10 03:26:54 --> Loader Class Initialized
INFO - 2022-03-10 03:26:54 --> Helper loaded: url_helper
INFO - 2022-03-10 03:26:54 --> Helper loaded: form_helper
INFO - 2022-03-10 03:26:54 --> Helper loaded: common_helper
INFO - 2022-03-10 03:26:54 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:26:54 --> Controller Class Initialized
INFO - 2022-03-10 03:26:54 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:26:54 --> Encrypt Class Initialized
INFO - 2022-03-10 03:26:54 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:26:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:26:54 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:26:54 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:26:54 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:26:54 --> Upload Class Initialized
INFO - 2022-03-10 03:26:54 --> Final output sent to browser
DEBUG - 2022-03-10 03:26:54 --> Total execution time: 0.0375
ERROR - 2022-03-10 03:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:27:35 --> Config Class Initialized
INFO - 2022-03-10 03:27:35 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:27:35 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:27:35 --> Utf8 Class Initialized
INFO - 2022-03-10 03:27:35 --> URI Class Initialized
INFO - 2022-03-10 03:27:35 --> Router Class Initialized
INFO - 2022-03-10 03:27:35 --> Output Class Initialized
INFO - 2022-03-10 03:27:35 --> Security Class Initialized
DEBUG - 2022-03-10 03:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:27:35 --> Input Class Initialized
INFO - 2022-03-10 03:27:35 --> Language Class Initialized
INFO - 2022-03-10 03:27:35 --> Loader Class Initialized
INFO - 2022-03-10 03:27:35 --> Helper loaded: url_helper
INFO - 2022-03-10 03:27:35 --> Helper loaded: form_helper
INFO - 2022-03-10 03:27:35 --> Helper loaded: common_helper
INFO - 2022-03-10 03:27:35 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:27:35 --> Controller Class Initialized
INFO - 2022-03-10 03:27:35 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:27:35 --> Encrypt Class Initialized
INFO - 2022-03-10 03:27:35 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:27:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:27:35 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:27:35 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:27:35 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:27:35 --> Config Class Initialized
INFO - 2022-03-10 03:27:35 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:27:35 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:27:35 --> Utf8 Class Initialized
INFO - 2022-03-10 03:27:35 --> URI Class Initialized
INFO - 2022-03-10 03:27:35 --> Router Class Initialized
INFO - 2022-03-10 03:27:35 --> Output Class Initialized
INFO - 2022-03-10 03:27:35 --> Security Class Initialized
DEBUG - 2022-03-10 03:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:27:35 --> Input Class Initialized
INFO - 2022-03-10 03:27:35 --> Language Class Initialized
INFO - 2022-03-10 03:27:35 --> Loader Class Initialized
INFO - 2022-03-10 03:27:35 --> Helper loaded: url_helper
INFO - 2022-03-10 03:27:35 --> Helper loaded: form_helper
INFO - 2022-03-10 03:27:35 --> Helper loaded: common_helper
INFO - 2022-03-10 03:27:35 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:27:35 --> Controller Class Initialized
INFO - 2022-03-10 03:27:35 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:27:35 --> Encrypt Class Initialized
INFO - 2022-03-10 03:27:35 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:27:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:27:35 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:27:35 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:27:35 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:27:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:27:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:27:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:27:35 --> Final output sent to browser
DEBUG - 2022-03-10 03:27:35 --> Total execution time: 0.0425
ERROR - 2022-03-10 03:27:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:27:36 --> Config Class Initialized
INFO - 2022-03-10 03:27:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:27:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:27:36 --> Utf8 Class Initialized
INFO - 2022-03-10 03:27:36 --> URI Class Initialized
INFO - 2022-03-10 03:27:36 --> Router Class Initialized
INFO - 2022-03-10 03:27:36 --> Output Class Initialized
INFO - 2022-03-10 03:27:36 --> Security Class Initialized
DEBUG - 2022-03-10 03:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:27:36 --> Input Class Initialized
INFO - 2022-03-10 03:27:36 --> Language Class Initialized
INFO - 2022-03-10 03:27:36 --> Loader Class Initialized
INFO - 2022-03-10 03:27:36 --> Helper loaded: url_helper
INFO - 2022-03-10 03:27:36 --> Helper loaded: form_helper
INFO - 2022-03-10 03:27:36 --> Helper loaded: common_helper
INFO - 2022-03-10 03:27:36 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:27:36 --> Controller Class Initialized
INFO - 2022-03-10 03:27:36 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:27:36 --> Encrypt Class Initialized
INFO - 2022-03-10 03:27:36 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:27:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:27:36 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:27:36 --> Model "Users_model" initialized
INFO - 2022-03-10 03:27:36 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:27:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:27:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:27:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:27:36 --> Final output sent to browser
DEBUG - 2022-03-10 03:27:36 --> Total execution time: 0.0521
ERROR - 2022-03-10 03:27:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:27:48 --> Config Class Initialized
INFO - 2022-03-10 03:27:48 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:27:48 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:27:48 --> Utf8 Class Initialized
INFO - 2022-03-10 03:27:48 --> URI Class Initialized
DEBUG - 2022-03-10 03:27:48 --> No URI present. Default controller set.
INFO - 2022-03-10 03:27:48 --> Router Class Initialized
INFO - 2022-03-10 03:27:48 --> Output Class Initialized
INFO - 2022-03-10 03:27:48 --> Security Class Initialized
DEBUG - 2022-03-10 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:27:48 --> Input Class Initialized
INFO - 2022-03-10 03:27:48 --> Language Class Initialized
INFO - 2022-03-10 03:27:48 --> Loader Class Initialized
INFO - 2022-03-10 03:27:48 --> Helper loaded: url_helper
INFO - 2022-03-10 03:27:48 --> Helper loaded: form_helper
INFO - 2022-03-10 03:27:48 --> Helper loaded: common_helper
INFO - 2022-03-10 03:27:48 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:27:48 --> Controller Class Initialized
INFO - 2022-03-10 03:27:48 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:27:48 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:27:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:27:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:27:48 --> Email Class Initialized
INFO - 2022-03-10 03:27:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:27:48 --> Calendar Class Initialized
INFO - 2022-03-10 03:27:48 --> Model "Login_model" initialized
INFO - 2022-03-10 03:27:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 03:27:48 --> Final output sent to browser
DEBUG - 2022-03-10 03:27:48 --> Total execution time: 0.0223
ERROR - 2022-03-10 03:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:27:51 --> Config Class Initialized
INFO - 2022-03-10 03:27:51 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:27:51 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:27:51 --> Utf8 Class Initialized
INFO - 2022-03-10 03:27:51 --> URI Class Initialized
INFO - 2022-03-10 03:27:51 --> Router Class Initialized
INFO - 2022-03-10 03:27:51 --> Output Class Initialized
INFO - 2022-03-10 03:27:51 --> Security Class Initialized
DEBUG - 2022-03-10 03:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:27:51 --> Input Class Initialized
INFO - 2022-03-10 03:27:51 --> Language Class Initialized
INFO - 2022-03-10 03:27:51 --> Loader Class Initialized
INFO - 2022-03-10 03:27:51 --> Helper loaded: url_helper
INFO - 2022-03-10 03:27:51 --> Helper loaded: form_helper
INFO - 2022-03-10 03:27:51 --> Helper loaded: common_helper
INFO - 2022-03-10 03:27:51 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:27:51 --> Controller Class Initialized
INFO - 2022-03-10 03:27:51 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:27:51 --> Encrypt Class Initialized
INFO - 2022-03-10 03:27:51 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:27:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:27:51 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:27:51 --> Model "Users_model" initialized
INFO - 2022-03-10 03:27:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:27:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:27:52 --> Config Class Initialized
INFO - 2022-03-10 03:27:52 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:27:52 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:27:52 --> Utf8 Class Initialized
INFO - 2022-03-10 03:27:52 --> URI Class Initialized
INFO - 2022-03-10 03:27:52 --> Router Class Initialized
INFO - 2022-03-10 03:27:52 --> Output Class Initialized
INFO - 2022-03-10 03:27:52 --> Security Class Initialized
DEBUG - 2022-03-10 03:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:27:52 --> Input Class Initialized
INFO - 2022-03-10 03:27:52 --> Language Class Initialized
INFO - 2022-03-10 03:27:52 --> Loader Class Initialized
INFO - 2022-03-10 03:27:52 --> Helper loaded: url_helper
INFO - 2022-03-10 03:27:52 --> Helper loaded: form_helper
INFO - 2022-03-10 03:27:52 --> Helper loaded: common_helper
INFO - 2022-03-10 03:27:52 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:27:52 --> Controller Class Initialized
INFO - 2022-03-10 03:27:52 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:27:52 --> Encrypt Class Initialized
INFO - 2022-03-10 03:27:52 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:27:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:27:52 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:27:52 --> Model "Users_model" initialized
INFO - 2022-03-10 03:27:52 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:27:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:27:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:27:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:27:52 --> Final output sent to browser
DEBUG - 2022-03-10 03:27:52 --> Total execution time: 0.0566
ERROR - 2022-03-10 03:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:28:21 --> Config Class Initialized
INFO - 2022-03-10 03:28:21 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:28:21 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:28:21 --> Utf8 Class Initialized
INFO - 2022-03-10 03:28:21 --> URI Class Initialized
INFO - 2022-03-10 03:28:21 --> Router Class Initialized
INFO - 2022-03-10 03:28:21 --> Output Class Initialized
INFO - 2022-03-10 03:28:21 --> Security Class Initialized
DEBUG - 2022-03-10 03:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:28:21 --> Input Class Initialized
INFO - 2022-03-10 03:28:21 --> Language Class Initialized
INFO - 2022-03-10 03:28:21 --> Loader Class Initialized
INFO - 2022-03-10 03:28:21 --> Helper loaded: url_helper
INFO - 2022-03-10 03:28:21 --> Helper loaded: form_helper
INFO - 2022-03-10 03:28:21 --> Helper loaded: common_helper
INFO - 2022-03-10 03:28:21 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:28:21 --> Controller Class Initialized
INFO - 2022-03-10 03:28:21 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:28:21 --> Final output sent to browser
DEBUG - 2022-03-10 03:28:21 --> Total execution time: 0.0214
ERROR - 2022-03-10 03:28:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:28:57 --> Config Class Initialized
INFO - 2022-03-10 03:28:57 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:28:57 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:28:57 --> Utf8 Class Initialized
INFO - 2022-03-10 03:28:57 --> URI Class Initialized
INFO - 2022-03-10 03:28:57 --> Router Class Initialized
INFO - 2022-03-10 03:28:57 --> Output Class Initialized
INFO - 2022-03-10 03:28:57 --> Security Class Initialized
DEBUG - 2022-03-10 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:28:57 --> Input Class Initialized
INFO - 2022-03-10 03:28:57 --> Language Class Initialized
INFO - 2022-03-10 03:28:57 --> Loader Class Initialized
INFO - 2022-03-10 03:28:57 --> Helper loaded: url_helper
INFO - 2022-03-10 03:28:57 --> Helper loaded: form_helper
INFO - 2022-03-10 03:28:57 --> Helper loaded: common_helper
INFO - 2022-03-10 03:28:57 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:28:57 --> Controller Class Initialized
INFO - 2022-03-10 03:28:57 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:28:57 --> Encrypt Class Initialized
INFO - 2022-03-10 03:28:57 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:28:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:28:57 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:28:57 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:28:57 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:28:57 --> Final output sent to browser
DEBUG - 2022-03-10 03:28:57 --> Total execution time: 0.0270
ERROR - 2022-03-10 03:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:31:01 --> Config Class Initialized
INFO - 2022-03-10 03:31:01 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:31:01 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:31:01 --> Utf8 Class Initialized
INFO - 2022-03-10 03:31:01 --> URI Class Initialized
INFO - 2022-03-10 03:31:01 --> Router Class Initialized
INFO - 2022-03-10 03:31:01 --> Output Class Initialized
INFO - 2022-03-10 03:31:01 --> Security Class Initialized
DEBUG - 2022-03-10 03:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:31:01 --> Input Class Initialized
INFO - 2022-03-10 03:31:01 --> Language Class Initialized
INFO - 2022-03-10 03:31:01 --> Loader Class Initialized
INFO - 2022-03-10 03:31:01 --> Helper loaded: url_helper
INFO - 2022-03-10 03:31:01 --> Helper loaded: form_helper
INFO - 2022-03-10 03:31:01 --> Helper loaded: common_helper
INFO - 2022-03-10 03:31:01 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:31:01 --> Controller Class Initialized
INFO - 2022-03-10 03:31:01 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:31:01 --> Encrypt Class Initialized
INFO - 2022-03-10 03:31:01 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:31:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:31:01 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:31:01 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:31:01 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:31:01 --> Final output sent to browser
DEBUG - 2022-03-10 03:31:01 --> Total execution time: 0.0304
ERROR - 2022-03-10 03:34:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:34:02 --> Config Class Initialized
INFO - 2022-03-10 03:34:02 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:34:02 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:34:02 --> Utf8 Class Initialized
INFO - 2022-03-10 03:34:02 --> URI Class Initialized
INFO - 2022-03-10 03:34:02 --> Router Class Initialized
INFO - 2022-03-10 03:34:02 --> Output Class Initialized
INFO - 2022-03-10 03:34:02 --> Security Class Initialized
DEBUG - 2022-03-10 03:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:34:02 --> Input Class Initialized
INFO - 2022-03-10 03:34:02 --> Language Class Initialized
INFO - 2022-03-10 03:34:02 --> Loader Class Initialized
INFO - 2022-03-10 03:34:02 --> Helper loaded: url_helper
INFO - 2022-03-10 03:34:02 --> Helper loaded: form_helper
INFO - 2022-03-10 03:34:02 --> Helper loaded: common_helper
INFO - 2022-03-10 03:34:02 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:34:02 --> Controller Class Initialized
INFO - 2022-03-10 03:34:02 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:34:02 --> Encrypt Class Initialized
INFO - 2022-03-10 03:34:02 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:34:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:34:02 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:34:02 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:34:02 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:34:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:34:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 03:34:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:34:02 --> Final output sent to browser
DEBUG - 2022-03-10 03:34:02 --> Total execution time: 0.0748
ERROR - 2022-03-10 03:34:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:34:04 --> Config Class Initialized
INFO - 2022-03-10 03:34:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:34:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:34:04 --> Utf8 Class Initialized
INFO - 2022-03-10 03:34:04 --> URI Class Initialized
INFO - 2022-03-10 03:34:04 --> Router Class Initialized
INFO - 2022-03-10 03:34:04 --> Output Class Initialized
INFO - 2022-03-10 03:34:04 --> Security Class Initialized
DEBUG - 2022-03-10 03:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:34:04 --> Input Class Initialized
INFO - 2022-03-10 03:34:04 --> Language Class Initialized
INFO - 2022-03-10 03:34:04 --> Loader Class Initialized
INFO - 2022-03-10 03:34:04 --> Helper loaded: url_helper
INFO - 2022-03-10 03:34:04 --> Helper loaded: form_helper
INFO - 2022-03-10 03:34:04 --> Helper loaded: common_helper
INFO - 2022-03-10 03:34:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:34:04 --> Controller Class Initialized
INFO - 2022-03-10 03:34:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:34:04 --> Encrypt Class Initialized
INFO - 2022-03-10 03:34:04 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:34:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:34:04 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:34:04 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:34:04 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:34:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:34:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 03:34:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:34:04 --> Final output sent to browser
DEBUG - 2022-03-10 03:34:04 --> Total execution time: 0.0738
ERROR - 2022-03-10 03:34:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:34:15 --> Config Class Initialized
INFO - 2022-03-10 03:34:15 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:34:15 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:34:15 --> Utf8 Class Initialized
INFO - 2022-03-10 03:34:15 --> URI Class Initialized
INFO - 2022-03-10 03:34:15 --> Router Class Initialized
INFO - 2022-03-10 03:34:15 --> Output Class Initialized
INFO - 2022-03-10 03:34:15 --> Security Class Initialized
DEBUG - 2022-03-10 03:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:34:15 --> Input Class Initialized
INFO - 2022-03-10 03:34:15 --> Language Class Initialized
INFO - 2022-03-10 03:34:15 --> Loader Class Initialized
INFO - 2022-03-10 03:34:15 --> Helper loaded: url_helper
INFO - 2022-03-10 03:34:15 --> Helper loaded: form_helper
INFO - 2022-03-10 03:34:15 --> Helper loaded: common_helper
INFO - 2022-03-10 03:34:15 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:34:15 --> Controller Class Initialized
INFO - 2022-03-10 03:34:15 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:34:15 --> Encrypt Class Initialized
INFO - 2022-03-10 03:34:15 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:34:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:34:15 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:34:15 --> Model "Users_model" initialized
INFO - 2022-03-10 03:34:15 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:34:15 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-10 03:34:16 --> Final output sent to browser
DEBUG - 2022-03-10 03:34:16 --> Total execution time: 1.1197
ERROR - 2022-03-10 03:37:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:37:22 --> Config Class Initialized
INFO - 2022-03-10 03:37:22 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:37:22 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:37:22 --> Utf8 Class Initialized
INFO - 2022-03-10 03:37:22 --> URI Class Initialized
INFO - 2022-03-10 03:37:22 --> Router Class Initialized
INFO - 2022-03-10 03:37:22 --> Output Class Initialized
INFO - 2022-03-10 03:37:22 --> Security Class Initialized
DEBUG - 2022-03-10 03:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:37:22 --> Input Class Initialized
INFO - 2022-03-10 03:37:22 --> Language Class Initialized
INFO - 2022-03-10 03:37:22 --> Loader Class Initialized
INFO - 2022-03-10 03:37:22 --> Helper loaded: url_helper
INFO - 2022-03-10 03:37:22 --> Helper loaded: form_helper
INFO - 2022-03-10 03:37:22 --> Helper loaded: common_helper
INFO - 2022-03-10 03:37:22 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:37:22 --> Controller Class Initialized
INFO - 2022-03-10 03:37:22 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:37:22 --> Final output sent to browser
DEBUG - 2022-03-10 03:37:22 --> Total execution time: 0.0211
ERROR - 2022-03-10 03:39:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:39:14 --> Config Class Initialized
INFO - 2022-03-10 03:39:14 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:39:14 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:39:14 --> Utf8 Class Initialized
INFO - 2022-03-10 03:39:14 --> URI Class Initialized
INFO - 2022-03-10 03:39:14 --> Router Class Initialized
INFO - 2022-03-10 03:39:14 --> Output Class Initialized
INFO - 2022-03-10 03:39:14 --> Security Class Initialized
DEBUG - 2022-03-10 03:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:39:14 --> Input Class Initialized
INFO - 2022-03-10 03:39:14 --> Language Class Initialized
INFO - 2022-03-10 03:39:14 --> Loader Class Initialized
INFO - 2022-03-10 03:39:14 --> Helper loaded: url_helper
INFO - 2022-03-10 03:39:14 --> Helper loaded: form_helper
INFO - 2022-03-10 03:39:14 --> Helper loaded: common_helper
INFO - 2022-03-10 03:39:14 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:39:14 --> Controller Class Initialized
ERROR - 2022-03-10 03:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:39:15 --> Config Class Initialized
INFO - 2022-03-10 03:39:15 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:39:15 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:39:15 --> Utf8 Class Initialized
INFO - 2022-03-10 03:39:15 --> URI Class Initialized
INFO - 2022-03-10 03:39:15 --> Router Class Initialized
INFO - 2022-03-10 03:39:15 --> Output Class Initialized
INFO - 2022-03-10 03:39:15 --> Security Class Initialized
DEBUG - 2022-03-10 03:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:39:15 --> Input Class Initialized
INFO - 2022-03-10 03:39:15 --> Language Class Initialized
INFO - 2022-03-10 03:39:15 --> Loader Class Initialized
INFO - 2022-03-10 03:39:15 --> Helper loaded: url_helper
INFO - 2022-03-10 03:39:15 --> Helper loaded: form_helper
INFO - 2022-03-10 03:39:15 --> Helper loaded: common_helper
INFO - 2022-03-10 03:39:15 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:39:15 --> Controller Class Initialized
INFO - 2022-03-10 03:39:15 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:39:15 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:39:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:39:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:39:15 --> Email Class Initialized
INFO - 2022-03-10 03:39:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:39:15 --> Calendar Class Initialized
INFO - 2022-03-10 03:39:15 --> Model "Login_model" initialized
INFO - 2022-03-10 03:39:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 03:39:15 --> Final output sent to browser
DEBUG - 2022-03-10 03:39:15 --> Total execution time: 0.0353
ERROR - 2022-03-10 03:39:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:39:29 --> Config Class Initialized
INFO - 2022-03-10 03:39:29 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:39:29 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:39:29 --> Utf8 Class Initialized
INFO - 2022-03-10 03:39:29 --> URI Class Initialized
INFO - 2022-03-10 03:39:29 --> Router Class Initialized
INFO - 2022-03-10 03:39:29 --> Output Class Initialized
INFO - 2022-03-10 03:39:29 --> Security Class Initialized
DEBUG - 2022-03-10 03:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:39:29 --> Input Class Initialized
INFO - 2022-03-10 03:39:29 --> Language Class Initialized
INFO - 2022-03-10 03:39:29 --> Loader Class Initialized
INFO - 2022-03-10 03:39:29 --> Helper loaded: url_helper
INFO - 2022-03-10 03:39:29 --> Helper loaded: form_helper
INFO - 2022-03-10 03:39:29 --> Helper loaded: common_helper
INFO - 2022-03-10 03:39:29 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:39:29 --> Controller Class Initialized
INFO - 2022-03-10 03:39:29 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:39:29 --> Encrypt Class Initialized
DEBUG - 2022-03-10 03:39:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 03:39:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 03:39:29 --> Email Class Initialized
INFO - 2022-03-10 03:39:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 03:39:29 --> Calendar Class Initialized
INFO - 2022-03-10 03:39:29 --> Model "Login_model" initialized
INFO - 2022-03-10 03:39:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 03:39:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:39:30 --> Config Class Initialized
INFO - 2022-03-10 03:39:30 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:39:30 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:39:30 --> Utf8 Class Initialized
INFO - 2022-03-10 03:39:30 --> URI Class Initialized
INFO - 2022-03-10 03:39:30 --> Router Class Initialized
INFO - 2022-03-10 03:39:30 --> Output Class Initialized
INFO - 2022-03-10 03:39:30 --> Security Class Initialized
DEBUG - 2022-03-10 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:39:30 --> Input Class Initialized
INFO - 2022-03-10 03:39:30 --> Language Class Initialized
INFO - 2022-03-10 03:39:30 --> Loader Class Initialized
INFO - 2022-03-10 03:39:30 --> Helper loaded: url_helper
INFO - 2022-03-10 03:39:30 --> Helper loaded: form_helper
INFO - 2022-03-10 03:39:30 --> Helper loaded: common_helper
INFO - 2022-03-10 03:39:30 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:39:30 --> Controller Class Initialized
INFO - 2022-03-10 03:39:30 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:39:30 --> Encrypt Class Initialized
INFO - 2022-03-10 03:39:30 --> Model "Login_model" initialized
INFO - 2022-03-10 03:39:30 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 03:39:30 --> Model "Case_model" initialized
INFO - 2022-03-10 03:39:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:39:30 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 03:39:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:39:30 --> Final output sent to browser
DEBUG - 2022-03-10 03:39:30 --> Total execution time: 0.1269
ERROR - 2022-03-10 03:39:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:39:38 --> Config Class Initialized
INFO - 2022-03-10 03:39:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:39:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:39:38 --> Utf8 Class Initialized
INFO - 2022-03-10 03:39:38 --> URI Class Initialized
INFO - 2022-03-10 03:39:38 --> Router Class Initialized
INFO - 2022-03-10 03:39:38 --> Output Class Initialized
INFO - 2022-03-10 03:39:38 --> Security Class Initialized
DEBUG - 2022-03-10 03:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:39:38 --> Input Class Initialized
INFO - 2022-03-10 03:39:38 --> Language Class Initialized
INFO - 2022-03-10 03:39:38 --> Loader Class Initialized
INFO - 2022-03-10 03:39:38 --> Helper loaded: url_helper
INFO - 2022-03-10 03:39:38 --> Helper loaded: form_helper
INFO - 2022-03-10 03:39:38 --> Helper loaded: common_helper
INFO - 2022-03-10 03:39:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:39:38 --> Controller Class Initialized
INFO - 2022-03-10 03:39:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:39:38 --> Encrypt Class Initialized
INFO - 2022-03-10 03:39:38 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:39:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:39:38 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:39:38 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:39:38 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:39:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:39:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:39:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:39:38 --> Final output sent to browser
DEBUG - 2022-03-10 03:39:38 --> Total execution time: 0.0290
ERROR - 2022-03-10 03:39:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:39:42 --> Config Class Initialized
INFO - 2022-03-10 03:39:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:39:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:39:42 --> Utf8 Class Initialized
INFO - 2022-03-10 03:39:42 --> URI Class Initialized
INFO - 2022-03-10 03:39:42 --> Router Class Initialized
INFO - 2022-03-10 03:39:42 --> Output Class Initialized
INFO - 2022-03-10 03:39:42 --> Security Class Initialized
DEBUG - 2022-03-10 03:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:39:42 --> Input Class Initialized
INFO - 2022-03-10 03:39:42 --> Language Class Initialized
INFO - 2022-03-10 03:39:42 --> Loader Class Initialized
INFO - 2022-03-10 03:39:42 --> Helper loaded: url_helper
INFO - 2022-03-10 03:39:42 --> Helper loaded: form_helper
INFO - 2022-03-10 03:39:42 --> Helper loaded: common_helper
INFO - 2022-03-10 03:39:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:39:42 --> Controller Class Initialized
INFO - 2022-03-10 03:39:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:39:42 --> Encrypt Class Initialized
INFO - 2022-03-10 03:39:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:39:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:39:42 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:39:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:39:42 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:39:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:39:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 03:39:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:39:42 --> Final output sent to browser
DEBUG - 2022-03-10 03:39:42 --> Total execution time: 0.0619
ERROR - 2022-03-10 03:39:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:39:46 --> Config Class Initialized
INFO - 2022-03-10 03:39:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:39:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:39:46 --> Utf8 Class Initialized
INFO - 2022-03-10 03:39:46 --> URI Class Initialized
INFO - 2022-03-10 03:39:46 --> Router Class Initialized
INFO - 2022-03-10 03:39:46 --> Output Class Initialized
INFO - 2022-03-10 03:39:46 --> Security Class Initialized
DEBUG - 2022-03-10 03:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:39:46 --> Input Class Initialized
INFO - 2022-03-10 03:39:46 --> Language Class Initialized
INFO - 2022-03-10 03:39:46 --> Loader Class Initialized
INFO - 2022-03-10 03:39:46 --> Helper loaded: url_helper
INFO - 2022-03-10 03:39:46 --> Helper loaded: form_helper
INFO - 2022-03-10 03:39:46 --> Helper loaded: common_helper
INFO - 2022-03-10 03:39:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:39:46 --> Controller Class Initialized
INFO - 2022-03-10 03:39:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:39:46 --> Encrypt Class Initialized
INFO - 2022-03-10 03:39:46 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:39:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:39:46 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:39:46 --> Model "Users_model" initialized
INFO - 2022-03-10 03:39:46 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:39:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:39:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:39:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:39:46 --> Final output sent to browser
DEBUG - 2022-03-10 03:39:46 --> Total execution time: 0.0662
ERROR - 2022-03-10 03:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:40:43 --> Config Class Initialized
INFO - 2022-03-10 03:40:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:40:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:40:43 --> Utf8 Class Initialized
INFO - 2022-03-10 03:40:43 --> URI Class Initialized
INFO - 2022-03-10 03:40:43 --> Router Class Initialized
INFO - 2022-03-10 03:40:43 --> Output Class Initialized
INFO - 2022-03-10 03:40:43 --> Security Class Initialized
DEBUG - 2022-03-10 03:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:40:43 --> Input Class Initialized
INFO - 2022-03-10 03:40:43 --> Language Class Initialized
INFO - 2022-03-10 03:40:43 --> Loader Class Initialized
INFO - 2022-03-10 03:40:43 --> Helper loaded: url_helper
INFO - 2022-03-10 03:40:43 --> Helper loaded: form_helper
INFO - 2022-03-10 03:40:43 --> Helper loaded: common_helper
INFO - 2022-03-10 03:40:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:40:43 --> Controller Class Initialized
INFO - 2022-03-10 03:40:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:40:43 --> Encrypt Class Initialized
INFO - 2022-03-10 03:40:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:40:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:40:43 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:40:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:40:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:40:44 --> Config Class Initialized
INFO - 2022-03-10 03:40:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:40:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:40:44 --> Utf8 Class Initialized
INFO - 2022-03-10 03:40:44 --> URI Class Initialized
INFO - 2022-03-10 03:40:44 --> Router Class Initialized
INFO - 2022-03-10 03:40:44 --> Output Class Initialized
INFO - 2022-03-10 03:40:44 --> Security Class Initialized
DEBUG - 2022-03-10 03:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:40:44 --> Input Class Initialized
INFO - 2022-03-10 03:40:44 --> Language Class Initialized
INFO - 2022-03-10 03:40:44 --> Loader Class Initialized
INFO - 2022-03-10 03:40:44 --> Helper loaded: url_helper
INFO - 2022-03-10 03:40:44 --> Helper loaded: form_helper
INFO - 2022-03-10 03:40:44 --> Helper loaded: common_helper
INFO - 2022-03-10 03:40:44 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:40:44 --> Controller Class Initialized
INFO - 2022-03-10 03:40:44 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:40:44 --> Encrypt Class Initialized
INFO - 2022-03-10 03:40:44 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:40:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:40:44 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:40:44 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:40:44 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:40:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:40:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:40:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:40:44 --> Final output sent to browser
DEBUG - 2022-03-10 03:40:44 --> Total execution time: 0.0426
ERROR - 2022-03-10 03:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:40:45 --> Config Class Initialized
INFO - 2022-03-10 03:40:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:40:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:40:45 --> Utf8 Class Initialized
INFO - 2022-03-10 03:40:45 --> URI Class Initialized
INFO - 2022-03-10 03:40:45 --> Router Class Initialized
INFO - 2022-03-10 03:40:45 --> Output Class Initialized
INFO - 2022-03-10 03:40:45 --> Security Class Initialized
DEBUG - 2022-03-10 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:40:45 --> Input Class Initialized
INFO - 2022-03-10 03:40:45 --> Language Class Initialized
INFO - 2022-03-10 03:40:45 --> Loader Class Initialized
INFO - 2022-03-10 03:40:45 --> Helper loaded: url_helper
INFO - 2022-03-10 03:40:45 --> Helper loaded: form_helper
INFO - 2022-03-10 03:40:45 --> Helper loaded: common_helper
INFO - 2022-03-10 03:40:45 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:40:45 --> Controller Class Initialized
INFO - 2022-03-10 03:40:45 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:40:45 --> Encrypt Class Initialized
INFO - 2022-03-10 03:40:45 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:40:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:40:45 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:40:45 --> Model "Users_model" initialized
INFO - 2022-03-10 03:40:45 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:40:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:40:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:40:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:40:45 --> Final output sent to browser
DEBUG - 2022-03-10 03:40:45 --> Total execution time: 0.0531
ERROR - 2022-03-10 03:42:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:42:42 --> Config Class Initialized
INFO - 2022-03-10 03:42:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:42:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:42:42 --> Utf8 Class Initialized
INFO - 2022-03-10 03:42:42 --> URI Class Initialized
INFO - 2022-03-10 03:42:42 --> Router Class Initialized
INFO - 2022-03-10 03:42:42 --> Output Class Initialized
INFO - 2022-03-10 03:42:42 --> Security Class Initialized
DEBUG - 2022-03-10 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:42:42 --> Input Class Initialized
INFO - 2022-03-10 03:42:42 --> Language Class Initialized
INFO - 2022-03-10 03:42:42 --> Loader Class Initialized
INFO - 2022-03-10 03:42:42 --> Helper loaded: url_helper
INFO - 2022-03-10 03:42:42 --> Helper loaded: form_helper
INFO - 2022-03-10 03:42:42 --> Helper loaded: common_helper
INFO - 2022-03-10 03:42:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:42:42 --> Controller Class Initialized
INFO - 2022-03-10 03:42:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:42:42 --> Encrypt Class Initialized
INFO - 2022-03-10 03:42:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:42:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:42:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:42:42 --> Model "Users_model" initialized
INFO - 2022-03-10 03:42:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:42:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:42:42 --> Config Class Initialized
INFO - 2022-03-10 03:42:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:42:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:42:42 --> Utf8 Class Initialized
INFO - 2022-03-10 03:42:42 --> URI Class Initialized
INFO - 2022-03-10 03:42:42 --> Router Class Initialized
INFO - 2022-03-10 03:42:42 --> Output Class Initialized
INFO - 2022-03-10 03:42:42 --> Security Class Initialized
DEBUG - 2022-03-10 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:42:42 --> Input Class Initialized
INFO - 2022-03-10 03:42:42 --> Language Class Initialized
INFO - 2022-03-10 03:42:42 --> Loader Class Initialized
INFO - 2022-03-10 03:42:42 --> Helper loaded: url_helper
INFO - 2022-03-10 03:42:42 --> Helper loaded: form_helper
INFO - 2022-03-10 03:42:42 --> Helper loaded: common_helper
INFO - 2022-03-10 03:42:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:42:42 --> Controller Class Initialized
INFO - 2022-03-10 03:42:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:42:42 --> Encrypt Class Initialized
INFO - 2022-03-10 03:42:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:42:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:42:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:42:42 --> Model "Users_model" initialized
INFO - 2022-03-10 03:42:42 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:42:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:42:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:42:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:42:42 --> Final output sent to browser
DEBUG - 2022-03-10 03:42:42 --> Total execution time: 0.0516
ERROR - 2022-03-10 03:46:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:46:36 --> Config Class Initialized
INFO - 2022-03-10 03:46:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:46:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:46:36 --> Utf8 Class Initialized
INFO - 2022-03-10 03:46:36 --> URI Class Initialized
INFO - 2022-03-10 03:46:36 --> Router Class Initialized
INFO - 2022-03-10 03:46:36 --> Output Class Initialized
INFO - 2022-03-10 03:46:36 --> Security Class Initialized
DEBUG - 2022-03-10 03:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:46:36 --> Input Class Initialized
INFO - 2022-03-10 03:46:36 --> Language Class Initialized
INFO - 2022-03-10 03:46:36 --> Loader Class Initialized
INFO - 2022-03-10 03:46:36 --> Helper loaded: url_helper
INFO - 2022-03-10 03:46:36 --> Helper loaded: form_helper
INFO - 2022-03-10 03:46:36 --> Helper loaded: common_helper
INFO - 2022-03-10 03:46:36 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:46:36 --> Controller Class Initialized
INFO - 2022-03-10 03:46:36 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:46:36 --> Encrypt Class Initialized
INFO - 2022-03-10 03:46:36 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:46:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:46:36 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:46:36 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:46:36 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:46:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:46:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:46:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:46:36 --> Final output sent to browser
DEBUG - 2022-03-10 03:46:36 --> Total execution time: 0.0471
ERROR - 2022-03-10 03:46:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:46:41 --> Config Class Initialized
INFO - 2022-03-10 03:46:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:46:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:46:41 --> Utf8 Class Initialized
INFO - 2022-03-10 03:46:41 --> URI Class Initialized
INFO - 2022-03-10 03:46:41 --> Router Class Initialized
INFO - 2022-03-10 03:46:41 --> Output Class Initialized
INFO - 2022-03-10 03:46:41 --> Security Class Initialized
DEBUG - 2022-03-10 03:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:46:41 --> Input Class Initialized
INFO - 2022-03-10 03:46:41 --> Language Class Initialized
INFO - 2022-03-10 03:46:41 --> Loader Class Initialized
INFO - 2022-03-10 03:46:41 --> Helper loaded: url_helper
INFO - 2022-03-10 03:46:41 --> Helper loaded: form_helper
INFO - 2022-03-10 03:46:41 --> Helper loaded: common_helper
INFO - 2022-03-10 03:46:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:46:41 --> Controller Class Initialized
INFO - 2022-03-10 03:46:41 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:46:41 --> Encrypt Class Initialized
INFO - 2022-03-10 03:46:41 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:46:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:46:41 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:46:41 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:46:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:46:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:46:41 --> Config Class Initialized
INFO - 2022-03-10 03:46:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:46:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:46:41 --> Utf8 Class Initialized
INFO - 2022-03-10 03:46:41 --> URI Class Initialized
INFO - 2022-03-10 03:46:41 --> Router Class Initialized
INFO - 2022-03-10 03:46:41 --> Output Class Initialized
INFO - 2022-03-10 03:46:41 --> Security Class Initialized
DEBUG - 2022-03-10 03:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:46:41 --> Input Class Initialized
INFO - 2022-03-10 03:46:41 --> Language Class Initialized
INFO - 2022-03-10 03:46:41 --> Loader Class Initialized
INFO - 2022-03-10 03:46:41 --> Helper loaded: url_helper
INFO - 2022-03-10 03:46:41 --> Helper loaded: form_helper
INFO - 2022-03-10 03:46:41 --> Helper loaded: common_helper
INFO - 2022-03-10 03:46:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:46:41 --> Controller Class Initialized
INFO - 2022-03-10 03:46:41 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:46:41 --> Encrypt Class Initialized
INFO - 2022-03-10 03:46:41 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:46:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:46:41 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:46:41 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:46:41 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:46:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:46:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:46:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:46:41 --> Final output sent to browser
DEBUG - 2022-03-10 03:46:41 --> Total execution time: 0.0567
ERROR - 2022-03-10 03:46:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:46:42 --> Config Class Initialized
INFO - 2022-03-10 03:46:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:46:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:46:42 --> Utf8 Class Initialized
INFO - 2022-03-10 03:46:42 --> URI Class Initialized
INFO - 2022-03-10 03:46:42 --> Router Class Initialized
INFO - 2022-03-10 03:46:42 --> Output Class Initialized
INFO - 2022-03-10 03:46:42 --> Security Class Initialized
DEBUG - 2022-03-10 03:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:46:42 --> Input Class Initialized
INFO - 2022-03-10 03:46:42 --> Language Class Initialized
INFO - 2022-03-10 03:46:42 --> Loader Class Initialized
INFO - 2022-03-10 03:46:42 --> Helper loaded: url_helper
INFO - 2022-03-10 03:46:42 --> Helper loaded: form_helper
INFO - 2022-03-10 03:46:42 --> Helper loaded: common_helper
INFO - 2022-03-10 03:46:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:46:42 --> Controller Class Initialized
INFO - 2022-03-10 03:46:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:46:42 --> Encrypt Class Initialized
INFO - 2022-03-10 03:46:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:46:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:46:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:46:42 --> Model "Users_model" initialized
INFO - 2022-03-10 03:46:42 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:46:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:46:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:46:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:46:42 --> Final output sent to browser
DEBUG - 2022-03-10 03:46:42 --> Total execution time: 0.0625
ERROR - 2022-03-10 03:47:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:47:10 --> Config Class Initialized
INFO - 2022-03-10 03:47:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:47:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:47:10 --> Utf8 Class Initialized
INFO - 2022-03-10 03:47:10 --> URI Class Initialized
INFO - 2022-03-10 03:47:10 --> Router Class Initialized
INFO - 2022-03-10 03:47:10 --> Output Class Initialized
INFO - 2022-03-10 03:47:10 --> Security Class Initialized
DEBUG - 2022-03-10 03:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:47:10 --> Input Class Initialized
INFO - 2022-03-10 03:47:10 --> Language Class Initialized
INFO - 2022-03-10 03:47:10 --> Loader Class Initialized
INFO - 2022-03-10 03:47:10 --> Helper loaded: url_helper
INFO - 2022-03-10 03:47:10 --> Helper loaded: form_helper
INFO - 2022-03-10 03:47:10 --> Helper loaded: common_helper
INFO - 2022-03-10 03:47:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:47:10 --> Controller Class Initialized
INFO - 2022-03-10 03:47:10 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:47:10 --> Encrypt Class Initialized
INFO - 2022-03-10 03:47:10 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:47:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:47:10 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:47:10 --> Model "Users_model" initialized
INFO - 2022-03-10 03:47:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:47:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:47:10 --> Config Class Initialized
INFO - 2022-03-10 03:47:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:47:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:47:10 --> Utf8 Class Initialized
INFO - 2022-03-10 03:47:10 --> URI Class Initialized
INFO - 2022-03-10 03:47:10 --> Router Class Initialized
INFO - 2022-03-10 03:47:10 --> Output Class Initialized
INFO - 2022-03-10 03:47:10 --> Security Class Initialized
DEBUG - 2022-03-10 03:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:47:10 --> Input Class Initialized
INFO - 2022-03-10 03:47:10 --> Language Class Initialized
INFO - 2022-03-10 03:47:10 --> Loader Class Initialized
INFO - 2022-03-10 03:47:10 --> Helper loaded: url_helper
INFO - 2022-03-10 03:47:10 --> Helper loaded: form_helper
INFO - 2022-03-10 03:47:10 --> Helper loaded: common_helper
INFO - 2022-03-10 03:47:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:47:10 --> Controller Class Initialized
INFO - 2022-03-10 03:47:10 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:47:10 --> Encrypt Class Initialized
INFO - 2022-03-10 03:47:10 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:47:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:47:10 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:47:10 --> Model "Users_model" initialized
INFO - 2022-03-10 03:47:10 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:47:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:47:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:47:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:47:10 --> Final output sent to browser
DEBUG - 2022-03-10 03:47:10 --> Total execution time: 0.0855
ERROR - 2022-03-10 03:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:53:44 --> Config Class Initialized
INFO - 2022-03-10 03:53:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:53:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:53:44 --> Utf8 Class Initialized
INFO - 2022-03-10 03:53:44 --> URI Class Initialized
INFO - 2022-03-10 03:53:44 --> Router Class Initialized
INFO - 2022-03-10 03:53:44 --> Output Class Initialized
INFO - 2022-03-10 03:53:44 --> Security Class Initialized
DEBUG - 2022-03-10 03:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:53:44 --> Input Class Initialized
INFO - 2022-03-10 03:53:44 --> Language Class Initialized
INFO - 2022-03-10 03:53:44 --> Loader Class Initialized
INFO - 2022-03-10 03:53:44 --> Helper loaded: url_helper
INFO - 2022-03-10 03:53:44 --> Helper loaded: form_helper
INFO - 2022-03-10 03:53:44 --> Helper loaded: common_helper
INFO - 2022-03-10 03:53:44 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:53:44 --> Controller Class Initialized
INFO - 2022-03-10 03:53:44 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:53:44 --> Encrypt Class Initialized
INFO - 2022-03-10 03:53:44 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:53:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:53:44 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:53:44 --> Model "Users_model" initialized
INFO - 2022-03-10 03:53:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:53:45 --> Config Class Initialized
INFO - 2022-03-10 03:53:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:53:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:53:45 --> Utf8 Class Initialized
INFO - 2022-03-10 03:53:45 --> URI Class Initialized
INFO - 2022-03-10 03:53:45 --> Router Class Initialized
INFO - 2022-03-10 03:53:45 --> Output Class Initialized
INFO - 2022-03-10 03:53:45 --> Security Class Initialized
DEBUG - 2022-03-10 03:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:53:45 --> Input Class Initialized
INFO - 2022-03-10 03:53:45 --> Language Class Initialized
INFO - 2022-03-10 03:53:45 --> Loader Class Initialized
INFO - 2022-03-10 03:53:45 --> Helper loaded: url_helper
INFO - 2022-03-10 03:53:45 --> Helper loaded: form_helper
INFO - 2022-03-10 03:53:45 --> Helper loaded: common_helper
INFO - 2022-03-10 03:53:45 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:53:45 --> Controller Class Initialized
INFO - 2022-03-10 03:53:45 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:53:45 --> Encrypt Class Initialized
INFO - 2022-03-10 03:53:45 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:53:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:53:45 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:53:45 --> Model "Users_model" initialized
INFO - 2022-03-10 03:53:45 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:53:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:53:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:53:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:53:45 --> Final output sent to browser
DEBUG - 2022-03-10 03:53:45 --> Total execution time: 0.0611
ERROR - 2022-03-10 03:53:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:53:50 --> Config Class Initialized
INFO - 2022-03-10 03:53:50 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:53:50 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:53:50 --> Utf8 Class Initialized
INFO - 2022-03-10 03:53:50 --> URI Class Initialized
INFO - 2022-03-10 03:53:50 --> Router Class Initialized
INFO - 2022-03-10 03:53:50 --> Output Class Initialized
INFO - 2022-03-10 03:53:50 --> Security Class Initialized
DEBUG - 2022-03-10 03:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:53:50 --> Input Class Initialized
INFO - 2022-03-10 03:53:50 --> Language Class Initialized
INFO - 2022-03-10 03:53:50 --> Loader Class Initialized
INFO - 2022-03-10 03:53:50 --> Helper loaded: url_helper
INFO - 2022-03-10 03:53:50 --> Helper loaded: form_helper
INFO - 2022-03-10 03:53:50 --> Helper loaded: common_helper
INFO - 2022-03-10 03:53:50 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:53:50 --> Controller Class Initialized
INFO - 2022-03-10 03:53:50 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:53:50 --> Encrypt Class Initialized
INFO - 2022-03-10 03:53:50 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:53:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:53:50 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:53:50 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:53:50 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:53:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:53:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 03:53:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:53:59 --> Final output sent to browser
DEBUG - 2022-03-10 03:53:59 --> Total execution time: 7.6845
ERROR - 2022-03-10 03:54:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:54:08 --> Config Class Initialized
INFO - 2022-03-10 03:54:08 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:54:08 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:54:08 --> Utf8 Class Initialized
INFO - 2022-03-10 03:54:08 --> URI Class Initialized
INFO - 2022-03-10 03:54:08 --> Router Class Initialized
INFO - 2022-03-10 03:54:08 --> Output Class Initialized
INFO - 2022-03-10 03:54:08 --> Security Class Initialized
DEBUG - 2022-03-10 03:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:54:08 --> Input Class Initialized
INFO - 2022-03-10 03:54:08 --> Language Class Initialized
INFO - 2022-03-10 03:54:08 --> Loader Class Initialized
INFO - 2022-03-10 03:54:08 --> Helper loaded: url_helper
INFO - 2022-03-10 03:54:08 --> Helper loaded: form_helper
INFO - 2022-03-10 03:54:08 --> Helper loaded: common_helper
INFO - 2022-03-10 03:54:08 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:54:08 --> Controller Class Initialized
INFO - 2022-03-10 03:54:08 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:54:08 --> Encrypt Class Initialized
INFO - 2022-03-10 03:54:08 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:54:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:54:08 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:54:08 --> Model "Users_model" initialized
INFO - 2022-03-10 03:54:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:54:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:54:09 --> Config Class Initialized
INFO - 2022-03-10 03:54:09 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:54:09 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:54:09 --> Utf8 Class Initialized
INFO - 2022-03-10 03:54:09 --> URI Class Initialized
INFO - 2022-03-10 03:54:09 --> Router Class Initialized
INFO - 2022-03-10 03:54:09 --> Output Class Initialized
INFO - 2022-03-10 03:54:09 --> Security Class Initialized
DEBUG - 2022-03-10 03:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:54:09 --> Input Class Initialized
INFO - 2022-03-10 03:54:09 --> Language Class Initialized
INFO - 2022-03-10 03:54:09 --> Loader Class Initialized
INFO - 2022-03-10 03:54:09 --> Helper loaded: url_helper
INFO - 2022-03-10 03:54:09 --> Helper loaded: form_helper
INFO - 2022-03-10 03:54:09 --> Helper loaded: common_helper
INFO - 2022-03-10 03:54:09 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:54:09 --> Controller Class Initialized
INFO - 2022-03-10 03:54:09 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:54:09 --> Encrypt Class Initialized
INFO - 2022-03-10 03:54:09 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:54:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:54:09 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:54:09 --> Model "Users_model" initialized
INFO - 2022-03-10 03:54:09 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:54:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:54:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:54:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:54:09 --> Final output sent to browser
DEBUG - 2022-03-10 03:54:09 --> Total execution time: 0.0594
ERROR - 2022-03-10 03:54:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:54:17 --> Config Class Initialized
INFO - 2022-03-10 03:54:17 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:54:17 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:54:17 --> Utf8 Class Initialized
INFO - 2022-03-10 03:54:17 --> URI Class Initialized
INFO - 2022-03-10 03:54:17 --> Router Class Initialized
INFO - 2022-03-10 03:54:17 --> Output Class Initialized
INFO - 2022-03-10 03:54:17 --> Security Class Initialized
DEBUG - 2022-03-10 03:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:54:17 --> Input Class Initialized
INFO - 2022-03-10 03:54:17 --> Language Class Initialized
INFO - 2022-03-10 03:54:17 --> Loader Class Initialized
INFO - 2022-03-10 03:54:17 --> Helper loaded: url_helper
INFO - 2022-03-10 03:54:17 --> Helper loaded: form_helper
INFO - 2022-03-10 03:54:17 --> Helper loaded: common_helper
INFO - 2022-03-10 03:54:17 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:54:17 --> Controller Class Initialized
INFO - 2022-03-10 03:54:17 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:54:17 --> Encrypt Class Initialized
INFO - 2022-03-10 03:54:17 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:54:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:54:17 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:54:17 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:54:17 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:54:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:54:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:54:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:54:17 --> Final output sent to browser
DEBUG - 2022-03-10 03:54:17 --> Total execution time: 0.0516
ERROR - 2022-03-10 03:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:54:27 --> Config Class Initialized
INFO - 2022-03-10 03:54:27 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:54:27 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:54:27 --> Utf8 Class Initialized
INFO - 2022-03-10 03:54:27 --> URI Class Initialized
INFO - 2022-03-10 03:54:27 --> Router Class Initialized
INFO - 2022-03-10 03:54:27 --> Output Class Initialized
INFO - 2022-03-10 03:54:27 --> Security Class Initialized
DEBUG - 2022-03-10 03:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:54:27 --> Input Class Initialized
INFO - 2022-03-10 03:54:27 --> Language Class Initialized
INFO - 2022-03-10 03:54:27 --> Loader Class Initialized
INFO - 2022-03-10 03:54:27 --> Helper loaded: url_helper
INFO - 2022-03-10 03:54:27 --> Helper loaded: form_helper
INFO - 2022-03-10 03:54:27 --> Helper loaded: common_helper
INFO - 2022-03-10 03:54:27 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:54:27 --> Controller Class Initialized
INFO - 2022-03-10 03:54:27 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:54:27 --> Encrypt Class Initialized
INFO - 2022-03-10 03:54:27 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:54:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:54:27 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:54:27 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:54:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:54:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:54:28 --> Config Class Initialized
INFO - 2022-03-10 03:54:28 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:54:28 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:54:28 --> Utf8 Class Initialized
INFO - 2022-03-10 03:54:28 --> URI Class Initialized
INFO - 2022-03-10 03:54:28 --> Router Class Initialized
INFO - 2022-03-10 03:54:28 --> Output Class Initialized
INFO - 2022-03-10 03:54:28 --> Security Class Initialized
DEBUG - 2022-03-10 03:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:54:28 --> Input Class Initialized
INFO - 2022-03-10 03:54:28 --> Language Class Initialized
INFO - 2022-03-10 03:54:28 --> Loader Class Initialized
INFO - 2022-03-10 03:54:28 --> Helper loaded: url_helper
INFO - 2022-03-10 03:54:28 --> Helper loaded: form_helper
INFO - 2022-03-10 03:54:28 --> Helper loaded: common_helper
INFO - 2022-03-10 03:54:28 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:54:28 --> Controller Class Initialized
INFO - 2022-03-10 03:54:28 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:54:28 --> Encrypt Class Initialized
INFO - 2022-03-10 03:54:28 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:54:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:54:28 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:54:28 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:54:28 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:54:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:54:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:54:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:54:28 --> Final output sent to browser
DEBUG - 2022-03-10 03:54:28 --> Total execution time: 0.0634
ERROR - 2022-03-10 03:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:54:29 --> Config Class Initialized
INFO - 2022-03-10 03:54:29 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:54:29 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:54:29 --> Utf8 Class Initialized
INFO - 2022-03-10 03:54:29 --> URI Class Initialized
INFO - 2022-03-10 03:54:29 --> Router Class Initialized
INFO - 2022-03-10 03:54:29 --> Output Class Initialized
INFO - 2022-03-10 03:54:29 --> Security Class Initialized
DEBUG - 2022-03-10 03:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:54:29 --> Input Class Initialized
INFO - 2022-03-10 03:54:29 --> Language Class Initialized
INFO - 2022-03-10 03:54:29 --> Loader Class Initialized
INFO - 2022-03-10 03:54:29 --> Helper loaded: url_helper
INFO - 2022-03-10 03:54:29 --> Helper loaded: form_helper
INFO - 2022-03-10 03:54:29 --> Helper loaded: common_helper
INFO - 2022-03-10 03:54:29 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:54:29 --> Controller Class Initialized
INFO - 2022-03-10 03:54:29 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:54:29 --> Encrypt Class Initialized
INFO - 2022-03-10 03:54:29 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:54:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:54:29 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:54:29 --> Model "Users_model" initialized
INFO - 2022-03-10 03:54:29 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:54:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:54:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:54:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:54:29 --> Final output sent to browser
DEBUG - 2022-03-10 03:54:29 --> Total execution time: 0.0578
ERROR - 2022-03-10 03:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:54:45 --> Config Class Initialized
INFO - 2022-03-10 03:54:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:54:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:54:45 --> Utf8 Class Initialized
INFO - 2022-03-10 03:54:45 --> URI Class Initialized
INFO - 2022-03-10 03:54:45 --> Router Class Initialized
INFO - 2022-03-10 03:54:45 --> Output Class Initialized
INFO - 2022-03-10 03:54:45 --> Security Class Initialized
DEBUG - 2022-03-10 03:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:54:45 --> Input Class Initialized
INFO - 2022-03-10 03:54:45 --> Language Class Initialized
INFO - 2022-03-10 03:54:45 --> Loader Class Initialized
INFO - 2022-03-10 03:54:45 --> Helper loaded: url_helper
INFO - 2022-03-10 03:54:45 --> Helper loaded: form_helper
INFO - 2022-03-10 03:54:45 --> Helper loaded: common_helper
INFO - 2022-03-10 03:54:45 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:54:45 --> Controller Class Initialized
INFO - 2022-03-10 03:54:45 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:54:45 --> Encrypt Class Initialized
INFO - 2022-03-10 03:54:45 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:54:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:54:45 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:54:45 --> Model "Users_model" initialized
INFO - 2022-03-10 03:54:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:54:46 --> Config Class Initialized
INFO - 2022-03-10 03:54:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:54:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:54:46 --> Utf8 Class Initialized
INFO - 2022-03-10 03:54:46 --> URI Class Initialized
INFO - 2022-03-10 03:54:46 --> Router Class Initialized
INFO - 2022-03-10 03:54:46 --> Output Class Initialized
INFO - 2022-03-10 03:54:46 --> Security Class Initialized
DEBUG - 2022-03-10 03:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:54:46 --> Input Class Initialized
INFO - 2022-03-10 03:54:46 --> Language Class Initialized
INFO - 2022-03-10 03:54:46 --> Loader Class Initialized
INFO - 2022-03-10 03:54:46 --> Helper loaded: url_helper
INFO - 2022-03-10 03:54:46 --> Helper loaded: form_helper
INFO - 2022-03-10 03:54:46 --> Helper loaded: common_helper
INFO - 2022-03-10 03:54:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:54:46 --> Controller Class Initialized
INFO - 2022-03-10 03:54:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:54:46 --> Encrypt Class Initialized
INFO - 2022-03-10 03:54:46 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:54:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:54:46 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:54:46 --> Model "Users_model" initialized
INFO - 2022-03-10 03:54:46 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:54:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:54:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:54:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:54:46 --> Final output sent to browser
DEBUG - 2022-03-10 03:54:46 --> Total execution time: 0.0587
ERROR - 2022-03-10 03:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:54:53 --> Config Class Initialized
INFO - 2022-03-10 03:54:53 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:54:53 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:54:53 --> Utf8 Class Initialized
INFO - 2022-03-10 03:54:53 --> URI Class Initialized
INFO - 2022-03-10 03:54:53 --> Router Class Initialized
INFO - 2022-03-10 03:54:53 --> Output Class Initialized
INFO - 2022-03-10 03:54:53 --> Security Class Initialized
DEBUG - 2022-03-10 03:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:54:53 --> Input Class Initialized
INFO - 2022-03-10 03:54:53 --> Language Class Initialized
INFO - 2022-03-10 03:54:53 --> Loader Class Initialized
INFO - 2022-03-10 03:54:53 --> Helper loaded: url_helper
INFO - 2022-03-10 03:54:53 --> Helper loaded: form_helper
INFO - 2022-03-10 03:54:53 --> Helper loaded: common_helper
INFO - 2022-03-10 03:54:53 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:54:53 --> Controller Class Initialized
INFO - 2022-03-10 03:54:53 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:54:53 --> Encrypt Class Initialized
INFO - 2022-03-10 03:54:53 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:54:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:54:53 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:54:53 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:54:53 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:54:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:54:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:54:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:54:53 --> Final output sent to browser
DEBUG - 2022-03-10 03:54:53 --> Total execution time: 0.0478
ERROR - 2022-03-10 03:55:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:55:15 --> Config Class Initialized
INFO - 2022-03-10 03:55:15 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:55:15 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:55:15 --> Utf8 Class Initialized
INFO - 2022-03-10 03:55:15 --> URI Class Initialized
INFO - 2022-03-10 03:55:15 --> Router Class Initialized
INFO - 2022-03-10 03:55:15 --> Output Class Initialized
INFO - 2022-03-10 03:55:15 --> Security Class Initialized
DEBUG - 2022-03-10 03:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:55:15 --> Input Class Initialized
INFO - 2022-03-10 03:55:15 --> Language Class Initialized
INFO - 2022-03-10 03:55:15 --> Loader Class Initialized
INFO - 2022-03-10 03:55:15 --> Helper loaded: url_helper
INFO - 2022-03-10 03:55:15 --> Helper loaded: form_helper
INFO - 2022-03-10 03:55:15 --> Helper loaded: common_helper
INFO - 2022-03-10 03:55:15 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:55:15 --> Controller Class Initialized
INFO - 2022-03-10 03:55:15 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:55:15 --> Encrypt Class Initialized
INFO - 2022-03-10 03:55:15 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:55:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:55:15 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:55:15 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:55:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:55:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:55:16 --> Config Class Initialized
INFO - 2022-03-10 03:55:16 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:55:16 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:55:16 --> Utf8 Class Initialized
INFO - 2022-03-10 03:55:16 --> URI Class Initialized
INFO - 2022-03-10 03:55:16 --> Router Class Initialized
INFO - 2022-03-10 03:55:16 --> Output Class Initialized
INFO - 2022-03-10 03:55:16 --> Security Class Initialized
DEBUG - 2022-03-10 03:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:55:16 --> Input Class Initialized
INFO - 2022-03-10 03:55:16 --> Language Class Initialized
INFO - 2022-03-10 03:55:16 --> Loader Class Initialized
INFO - 2022-03-10 03:55:16 --> Helper loaded: url_helper
INFO - 2022-03-10 03:55:16 --> Helper loaded: form_helper
INFO - 2022-03-10 03:55:16 --> Helper loaded: common_helper
INFO - 2022-03-10 03:55:16 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:55:16 --> Controller Class Initialized
INFO - 2022-03-10 03:55:16 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:55:16 --> Encrypt Class Initialized
INFO - 2022-03-10 03:55:16 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:55:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:55:16 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:55:16 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:55:16 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:55:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:55:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:55:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:55:16 --> Final output sent to browser
DEBUG - 2022-03-10 03:55:16 --> Total execution time: 0.0942
ERROR - 2022-03-10 03:55:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:55:17 --> Config Class Initialized
INFO - 2022-03-10 03:55:17 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:55:17 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:55:17 --> Utf8 Class Initialized
INFO - 2022-03-10 03:55:17 --> URI Class Initialized
INFO - 2022-03-10 03:55:17 --> Router Class Initialized
INFO - 2022-03-10 03:55:17 --> Output Class Initialized
INFO - 2022-03-10 03:55:17 --> Security Class Initialized
DEBUG - 2022-03-10 03:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:55:17 --> Input Class Initialized
INFO - 2022-03-10 03:55:17 --> Language Class Initialized
INFO - 2022-03-10 03:55:17 --> Loader Class Initialized
INFO - 2022-03-10 03:55:17 --> Helper loaded: url_helper
INFO - 2022-03-10 03:55:17 --> Helper loaded: form_helper
INFO - 2022-03-10 03:55:17 --> Helper loaded: common_helper
INFO - 2022-03-10 03:55:17 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:55:17 --> Controller Class Initialized
INFO - 2022-03-10 03:55:17 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:55:17 --> Encrypt Class Initialized
INFO - 2022-03-10 03:55:17 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:55:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:55:17 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:55:17 --> Model "Users_model" initialized
INFO - 2022-03-10 03:55:17 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:55:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:55:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:55:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:55:17 --> Final output sent to browser
DEBUG - 2022-03-10 03:55:17 --> Total execution time: 0.0594
ERROR - 2022-03-10 03:56:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:56:12 --> Config Class Initialized
INFO - 2022-03-10 03:56:12 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:56:12 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:56:12 --> Utf8 Class Initialized
INFO - 2022-03-10 03:56:12 --> URI Class Initialized
INFO - 2022-03-10 03:56:12 --> Router Class Initialized
INFO - 2022-03-10 03:56:12 --> Output Class Initialized
INFO - 2022-03-10 03:56:12 --> Security Class Initialized
DEBUG - 2022-03-10 03:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:56:12 --> Input Class Initialized
INFO - 2022-03-10 03:56:12 --> Language Class Initialized
INFO - 2022-03-10 03:56:12 --> Loader Class Initialized
INFO - 2022-03-10 03:56:12 --> Helper loaded: url_helper
INFO - 2022-03-10 03:56:12 --> Helper loaded: form_helper
INFO - 2022-03-10 03:56:12 --> Helper loaded: common_helper
INFO - 2022-03-10 03:56:12 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:56:12 --> Controller Class Initialized
INFO - 2022-03-10 03:56:12 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:56:12 --> Encrypt Class Initialized
INFO - 2022-03-10 03:56:12 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:56:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:56:12 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:56:12 --> Model "Users_model" initialized
INFO - 2022-03-10 03:56:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:56:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:56:13 --> Config Class Initialized
INFO - 2022-03-10 03:56:13 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:56:13 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:56:13 --> Utf8 Class Initialized
INFO - 2022-03-10 03:56:13 --> URI Class Initialized
INFO - 2022-03-10 03:56:13 --> Router Class Initialized
INFO - 2022-03-10 03:56:13 --> Output Class Initialized
INFO - 2022-03-10 03:56:13 --> Security Class Initialized
DEBUG - 2022-03-10 03:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:56:13 --> Input Class Initialized
INFO - 2022-03-10 03:56:13 --> Language Class Initialized
INFO - 2022-03-10 03:56:13 --> Loader Class Initialized
INFO - 2022-03-10 03:56:13 --> Helper loaded: url_helper
INFO - 2022-03-10 03:56:13 --> Helper loaded: form_helper
INFO - 2022-03-10 03:56:13 --> Helper loaded: common_helper
INFO - 2022-03-10 03:56:13 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:56:13 --> Controller Class Initialized
INFO - 2022-03-10 03:56:13 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:56:13 --> Encrypt Class Initialized
INFO - 2022-03-10 03:56:13 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:56:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:56:13 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:56:13 --> Model "Users_model" initialized
INFO - 2022-03-10 03:56:13 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:56:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:56:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:56:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:56:13 --> Final output sent to browser
DEBUG - 2022-03-10 03:56:13 --> Total execution time: 0.0661
ERROR - 2022-03-10 03:57:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:57:58 --> Config Class Initialized
INFO - 2022-03-10 03:57:58 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:57:58 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:57:58 --> Utf8 Class Initialized
INFO - 2022-03-10 03:57:58 --> URI Class Initialized
INFO - 2022-03-10 03:57:58 --> Router Class Initialized
INFO - 2022-03-10 03:57:58 --> Output Class Initialized
INFO - 2022-03-10 03:57:58 --> Security Class Initialized
DEBUG - 2022-03-10 03:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:57:58 --> Input Class Initialized
INFO - 2022-03-10 03:57:58 --> Language Class Initialized
INFO - 2022-03-10 03:57:58 --> Loader Class Initialized
INFO - 2022-03-10 03:57:58 --> Helper loaded: url_helper
INFO - 2022-03-10 03:57:58 --> Helper loaded: form_helper
INFO - 2022-03-10 03:57:58 --> Helper loaded: common_helper
INFO - 2022-03-10 03:57:58 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:57:58 --> Controller Class Initialized
INFO - 2022-03-10 03:57:58 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:57:58 --> Encrypt Class Initialized
INFO - 2022-03-10 03:57:58 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:57:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:57:58 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:57:58 --> Model "Users_model" initialized
INFO - 2022-03-10 03:57:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 03:57:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:57:58 --> Config Class Initialized
INFO - 2022-03-10 03:57:58 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:57:58 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:57:58 --> Utf8 Class Initialized
INFO - 2022-03-10 03:57:58 --> URI Class Initialized
INFO - 2022-03-10 03:57:58 --> Router Class Initialized
INFO - 2022-03-10 03:57:58 --> Output Class Initialized
INFO - 2022-03-10 03:57:58 --> Security Class Initialized
DEBUG - 2022-03-10 03:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:57:58 --> Input Class Initialized
INFO - 2022-03-10 03:57:58 --> Language Class Initialized
INFO - 2022-03-10 03:57:58 --> Loader Class Initialized
INFO - 2022-03-10 03:57:58 --> Helper loaded: url_helper
INFO - 2022-03-10 03:57:58 --> Helper loaded: form_helper
INFO - 2022-03-10 03:57:58 --> Helper loaded: common_helper
INFO - 2022-03-10 03:57:58 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:57:58 --> Controller Class Initialized
INFO - 2022-03-10 03:57:58 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:57:58 --> Encrypt Class Initialized
INFO - 2022-03-10 03:57:58 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:57:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:57:58 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:57:58 --> Model "Users_model" initialized
INFO - 2022-03-10 03:57:58 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:57:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:57:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:57:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:57:58 --> Final output sent to browser
DEBUG - 2022-03-10 03:57:58 --> Total execution time: 0.0933
ERROR - 2022-03-10 03:58:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:58:21 --> Config Class Initialized
INFO - 2022-03-10 03:58:21 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:58:21 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:58:21 --> Utf8 Class Initialized
INFO - 2022-03-10 03:58:21 --> URI Class Initialized
INFO - 2022-03-10 03:58:21 --> Router Class Initialized
INFO - 2022-03-10 03:58:21 --> Output Class Initialized
INFO - 2022-03-10 03:58:21 --> Security Class Initialized
DEBUG - 2022-03-10 03:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:58:21 --> Input Class Initialized
INFO - 2022-03-10 03:58:21 --> Language Class Initialized
INFO - 2022-03-10 03:58:21 --> Loader Class Initialized
INFO - 2022-03-10 03:58:21 --> Helper loaded: url_helper
INFO - 2022-03-10 03:58:21 --> Helper loaded: form_helper
INFO - 2022-03-10 03:58:21 --> Helper loaded: common_helper
INFO - 2022-03-10 03:58:21 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:58:21 --> Controller Class Initialized
INFO - 2022-03-10 03:58:21 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:58:21 --> Encrypt Class Initialized
INFO - 2022-03-10 03:58:21 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:58:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:58:21 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:58:21 --> Model "Users_model" initialized
INFO - 2022-03-10 03:58:21 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:58:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:58:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 03:58:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:58:22 --> Final output sent to browser
DEBUG - 2022-03-10 03:58:22 --> Total execution time: 0.0621
ERROR - 2022-03-10 03:58:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:58:24 --> Config Class Initialized
INFO - 2022-03-10 03:58:24 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:58:24 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:58:24 --> Utf8 Class Initialized
INFO - 2022-03-10 03:58:24 --> URI Class Initialized
INFO - 2022-03-10 03:58:24 --> Router Class Initialized
INFO - 2022-03-10 03:58:24 --> Output Class Initialized
INFO - 2022-03-10 03:58:24 --> Security Class Initialized
DEBUG - 2022-03-10 03:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:58:24 --> Input Class Initialized
INFO - 2022-03-10 03:58:24 --> Language Class Initialized
INFO - 2022-03-10 03:58:24 --> Loader Class Initialized
INFO - 2022-03-10 03:58:24 --> Helper loaded: url_helper
INFO - 2022-03-10 03:58:24 --> Helper loaded: form_helper
INFO - 2022-03-10 03:58:24 --> Helper loaded: common_helper
INFO - 2022-03-10 03:58:24 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:58:24 --> Controller Class Initialized
INFO - 2022-03-10 03:58:24 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:58:24 --> Encrypt Class Initialized
INFO - 2022-03-10 03:58:24 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:58:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:58:24 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:58:24 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:58:24 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:58:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:58:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 03:58:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:58:24 --> Final output sent to browser
DEBUG - 2022-03-10 03:58:24 --> Total execution time: 0.0608
ERROR - 2022-03-10 03:59:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 03:59:23 --> Config Class Initialized
INFO - 2022-03-10 03:59:23 --> Hooks Class Initialized
DEBUG - 2022-03-10 03:59:23 --> UTF-8 Support Enabled
INFO - 2022-03-10 03:59:23 --> Utf8 Class Initialized
INFO - 2022-03-10 03:59:23 --> URI Class Initialized
INFO - 2022-03-10 03:59:23 --> Router Class Initialized
INFO - 2022-03-10 03:59:23 --> Output Class Initialized
INFO - 2022-03-10 03:59:23 --> Security Class Initialized
DEBUG - 2022-03-10 03:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 03:59:23 --> Input Class Initialized
INFO - 2022-03-10 03:59:23 --> Language Class Initialized
INFO - 2022-03-10 03:59:23 --> Loader Class Initialized
INFO - 2022-03-10 03:59:23 --> Helper loaded: url_helper
INFO - 2022-03-10 03:59:23 --> Helper loaded: form_helper
INFO - 2022-03-10 03:59:23 --> Helper loaded: common_helper
INFO - 2022-03-10 03:59:23 --> Database Driver Class Initialized
DEBUG - 2022-03-10 03:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 03:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 03:59:23 --> Controller Class Initialized
INFO - 2022-03-10 03:59:23 --> Form Validation Class Initialized
DEBUG - 2022-03-10 03:59:23 --> Encrypt Class Initialized
INFO - 2022-03-10 03:59:23 --> Model "Patient_model" initialized
INFO - 2022-03-10 03:59:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 03:59:23 --> Model "Referredby_model" initialized
INFO - 2022-03-10 03:59:23 --> Model "Prefix_master" initialized
INFO - 2022-03-10 03:59:23 --> Model "Hospital_model" initialized
INFO - 2022-03-10 03:59:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 03:59:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 03:59:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 03:59:34 --> Final output sent to browser
DEBUG - 2022-03-10 03:59:34 --> Total execution time: 9.0831
ERROR - 2022-03-10 04:02:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:02:04 --> Config Class Initialized
INFO - 2022-03-10 04:02:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:02:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:02:04 --> Utf8 Class Initialized
INFO - 2022-03-10 04:02:04 --> URI Class Initialized
INFO - 2022-03-10 04:02:04 --> Router Class Initialized
INFO - 2022-03-10 04:02:04 --> Output Class Initialized
INFO - 2022-03-10 04:02:04 --> Security Class Initialized
DEBUG - 2022-03-10 04:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:02:04 --> Input Class Initialized
INFO - 2022-03-10 04:02:04 --> Language Class Initialized
INFO - 2022-03-10 04:02:04 --> Loader Class Initialized
INFO - 2022-03-10 04:02:04 --> Helper loaded: url_helper
INFO - 2022-03-10 04:02:04 --> Helper loaded: form_helper
INFO - 2022-03-10 04:02:04 --> Helper loaded: common_helper
INFO - 2022-03-10 04:02:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:02:04 --> Controller Class Initialized
INFO - 2022-03-10 04:02:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:02:04 --> Encrypt Class Initialized
INFO - 2022-03-10 04:02:04 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:02:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:02:04 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:02:04 --> Model "Users_model" initialized
INFO - 2022-03-10 04:02:04 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:02:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:02:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:02:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:02:04 --> Final output sent to browser
DEBUG - 2022-03-10 04:02:04 --> Total execution time: 0.0831
ERROR - 2022-03-10 04:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:03:25 --> Config Class Initialized
INFO - 2022-03-10 04:03:25 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:03:25 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:03:25 --> Utf8 Class Initialized
INFO - 2022-03-10 04:03:25 --> URI Class Initialized
INFO - 2022-03-10 04:03:25 --> Router Class Initialized
INFO - 2022-03-10 04:03:25 --> Output Class Initialized
INFO - 2022-03-10 04:03:25 --> Security Class Initialized
DEBUG - 2022-03-10 04:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:03:25 --> Input Class Initialized
INFO - 2022-03-10 04:03:25 --> Language Class Initialized
INFO - 2022-03-10 04:03:25 --> Loader Class Initialized
INFO - 2022-03-10 04:03:25 --> Helper loaded: url_helper
INFO - 2022-03-10 04:03:25 --> Helper loaded: form_helper
INFO - 2022-03-10 04:03:25 --> Helper loaded: common_helper
INFO - 2022-03-10 04:03:25 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:03:25 --> Controller Class Initialized
INFO - 2022-03-10 04:03:25 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:03:25 --> Encrypt Class Initialized
INFO - 2022-03-10 04:03:25 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:03:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:03:25 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:03:25 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:03:25 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:03:25 --> Upload Class Initialized
INFO - 2022-03-10 04:03:25 --> Final output sent to browser
DEBUG - 2022-03-10 04:03:25 --> Total execution time: 0.0275
ERROR - 2022-03-10 04:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:10:22 --> Config Class Initialized
INFO - 2022-03-10 04:10:22 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:10:22 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:10:22 --> Utf8 Class Initialized
INFO - 2022-03-10 04:10:22 --> URI Class Initialized
INFO - 2022-03-10 04:10:22 --> Router Class Initialized
INFO - 2022-03-10 04:10:22 --> Output Class Initialized
INFO - 2022-03-10 04:10:22 --> Security Class Initialized
DEBUG - 2022-03-10 04:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:10:22 --> Input Class Initialized
INFO - 2022-03-10 04:10:22 --> Language Class Initialized
INFO - 2022-03-10 04:10:22 --> Loader Class Initialized
INFO - 2022-03-10 04:10:22 --> Helper loaded: url_helper
INFO - 2022-03-10 04:10:22 --> Helper loaded: form_helper
INFO - 2022-03-10 04:10:22 --> Helper loaded: common_helper
INFO - 2022-03-10 04:10:22 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:10:22 --> Controller Class Initialized
INFO - 2022-03-10 04:10:22 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:10:22 --> Encrypt Class Initialized
INFO - 2022-03-10 04:10:22 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:10:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:10:22 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:10:22 --> Model "Users_model" initialized
INFO - 2022-03-10 04:10:22 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:10:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:10:25 --> Config Class Initialized
INFO - 2022-03-10 04:10:25 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:10:25 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:10:25 --> Utf8 Class Initialized
INFO - 2022-03-10 04:10:25 --> URI Class Initialized
INFO - 2022-03-10 04:10:25 --> Router Class Initialized
INFO - 2022-03-10 04:10:25 --> Output Class Initialized
INFO - 2022-03-10 04:10:25 --> Security Class Initialized
DEBUG - 2022-03-10 04:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:10:25 --> Input Class Initialized
INFO - 2022-03-10 04:10:25 --> Language Class Initialized
INFO - 2022-03-10 04:10:25 --> Loader Class Initialized
INFO - 2022-03-10 04:10:25 --> Helper loaded: url_helper
INFO - 2022-03-10 04:10:25 --> Helper loaded: form_helper
INFO - 2022-03-10 04:10:25 --> Helper loaded: common_helper
INFO - 2022-03-10 04:10:25 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:10:25 --> Controller Class Initialized
INFO - 2022-03-10 04:10:25 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:10:25 --> Encrypt Class Initialized
INFO - 2022-03-10 04:10:25 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:10:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:10:25 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:10:25 --> Model "Users_model" initialized
INFO - 2022-03-10 04:10:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:10:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:10:29 --> Config Class Initialized
INFO - 2022-03-10 04:10:29 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:10:29 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:10:29 --> Utf8 Class Initialized
INFO - 2022-03-10 04:10:29 --> URI Class Initialized
INFO - 2022-03-10 04:10:29 --> Router Class Initialized
INFO - 2022-03-10 04:10:29 --> Output Class Initialized
INFO - 2022-03-10 04:10:29 --> Security Class Initialized
DEBUG - 2022-03-10 04:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:10:29 --> Input Class Initialized
INFO - 2022-03-10 04:10:29 --> Language Class Initialized
INFO - 2022-03-10 04:10:29 --> Loader Class Initialized
INFO - 2022-03-10 04:10:29 --> Helper loaded: url_helper
INFO - 2022-03-10 04:10:29 --> Helper loaded: form_helper
INFO - 2022-03-10 04:10:29 --> Helper loaded: common_helper
INFO - 2022-03-10 04:10:29 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:10:29 --> Controller Class Initialized
INFO - 2022-03-10 04:10:29 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:10:29 --> Encrypt Class Initialized
INFO - 2022-03-10 04:10:29 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:10:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:10:29 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:10:29 --> Model "Users_model" initialized
INFO - 2022-03-10 04:10:29 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:10:29 --> Upload Class Initialized
INFO - 2022-03-10 04:10:29 --> Final output sent to browser
DEBUG - 2022-03-10 04:10:29 --> Total execution time: 0.0850
ERROR - 2022-03-10 04:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:10:45 --> Config Class Initialized
INFO - 2022-03-10 04:10:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:10:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:10:45 --> Utf8 Class Initialized
INFO - 2022-03-10 04:10:45 --> URI Class Initialized
INFO - 2022-03-10 04:10:45 --> Router Class Initialized
INFO - 2022-03-10 04:10:45 --> Output Class Initialized
INFO - 2022-03-10 04:10:45 --> Security Class Initialized
DEBUG - 2022-03-10 04:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:10:45 --> Input Class Initialized
INFO - 2022-03-10 04:10:45 --> Language Class Initialized
INFO - 2022-03-10 04:10:45 --> Loader Class Initialized
INFO - 2022-03-10 04:10:45 --> Helper loaded: url_helper
INFO - 2022-03-10 04:10:45 --> Helper loaded: form_helper
INFO - 2022-03-10 04:10:45 --> Helper loaded: common_helper
INFO - 2022-03-10 04:10:45 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:10:46 --> Controller Class Initialized
ERROR - 2022-03-10 04:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:10:46 --> Config Class Initialized
INFO - 2022-03-10 04:10:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:10:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:10:46 --> Utf8 Class Initialized
INFO - 2022-03-10 04:10:46 --> URI Class Initialized
INFO - 2022-03-10 04:10:46 --> Router Class Initialized
INFO - 2022-03-10 04:10:46 --> Output Class Initialized
INFO - 2022-03-10 04:10:46 --> Security Class Initialized
DEBUG - 2022-03-10 04:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:10:46 --> Input Class Initialized
INFO - 2022-03-10 04:10:46 --> Language Class Initialized
INFO - 2022-03-10 04:10:46 --> Loader Class Initialized
INFO - 2022-03-10 04:10:46 --> Helper loaded: url_helper
INFO - 2022-03-10 04:10:46 --> Helper loaded: form_helper
INFO - 2022-03-10 04:10:46 --> Helper loaded: common_helper
INFO - 2022-03-10 04:10:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:10:46 --> Controller Class Initialized
INFO - 2022-03-10 04:10:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:10:46 --> Encrypt Class Initialized
DEBUG - 2022-03-10 04:10:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 04:10:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 04:10:46 --> Email Class Initialized
INFO - 2022-03-10 04:10:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 04:10:46 --> Calendar Class Initialized
INFO - 2022-03-10 04:10:46 --> Model "Login_model" initialized
INFO - 2022-03-10 04:10:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 04:10:46 --> Final output sent to browser
DEBUG - 2022-03-10 04:10:46 --> Total execution time: 0.0213
ERROR - 2022-03-10 04:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:11:06 --> Config Class Initialized
INFO - 2022-03-10 04:11:06 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:11:06 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:11:06 --> Utf8 Class Initialized
INFO - 2022-03-10 04:11:06 --> URI Class Initialized
INFO - 2022-03-10 04:11:06 --> Router Class Initialized
INFO - 2022-03-10 04:11:06 --> Output Class Initialized
INFO - 2022-03-10 04:11:06 --> Security Class Initialized
DEBUG - 2022-03-10 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:11:06 --> Input Class Initialized
INFO - 2022-03-10 04:11:06 --> Language Class Initialized
INFO - 2022-03-10 04:11:06 --> Loader Class Initialized
INFO - 2022-03-10 04:11:06 --> Helper loaded: url_helper
INFO - 2022-03-10 04:11:06 --> Helper loaded: form_helper
INFO - 2022-03-10 04:11:06 --> Helper loaded: common_helper
INFO - 2022-03-10 04:11:06 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:11:06 --> Controller Class Initialized
INFO - 2022-03-10 04:11:06 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:11:06 --> Encrypt Class Initialized
INFO - 2022-03-10 04:11:06 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:11:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:11:06 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:11:06 --> Model "Users_model" initialized
INFO - 2022-03-10 04:11:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:11:52 --> Config Class Initialized
INFO - 2022-03-10 04:11:52 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:11:52 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:11:52 --> Utf8 Class Initialized
INFO - 2022-03-10 04:11:52 --> URI Class Initialized
INFO - 2022-03-10 04:11:52 --> Router Class Initialized
INFO - 2022-03-10 04:11:52 --> Output Class Initialized
INFO - 2022-03-10 04:11:52 --> Security Class Initialized
DEBUG - 2022-03-10 04:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:11:52 --> Input Class Initialized
INFO - 2022-03-10 04:11:52 --> Language Class Initialized
INFO - 2022-03-10 04:11:52 --> Loader Class Initialized
INFO - 2022-03-10 04:11:52 --> Helper loaded: url_helper
INFO - 2022-03-10 04:11:52 --> Helper loaded: form_helper
INFO - 2022-03-10 04:11:52 --> Helper loaded: common_helper
INFO - 2022-03-10 04:11:52 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:11:52 --> Controller Class Initialized
INFO - 2022-03-10 04:11:52 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:11:52 --> Encrypt Class Initialized
INFO - 2022-03-10 04:11:52 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:11:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:11:52 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:11:52 --> Model "Users_model" initialized
INFO - 2022-03-10 04:11:52 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:11:52 --> Upload Class Initialized
INFO - 2022-03-10 04:11:52 --> Final output sent to browser
DEBUG - 2022-03-10 04:11:52 --> Total execution time: 0.0350
ERROR - 2022-03-10 04:11:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:11:55 --> Config Class Initialized
INFO - 2022-03-10 04:11:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:11:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:11:55 --> Utf8 Class Initialized
INFO - 2022-03-10 04:11:55 --> URI Class Initialized
INFO - 2022-03-10 04:11:55 --> Router Class Initialized
INFO - 2022-03-10 04:11:55 --> Output Class Initialized
INFO - 2022-03-10 04:11:55 --> Security Class Initialized
DEBUG - 2022-03-10 04:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:11:55 --> Input Class Initialized
INFO - 2022-03-10 04:11:55 --> Language Class Initialized
INFO - 2022-03-10 04:11:55 --> Loader Class Initialized
INFO - 2022-03-10 04:11:55 --> Helper loaded: url_helper
INFO - 2022-03-10 04:11:55 --> Helper loaded: form_helper
INFO - 2022-03-10 04:11:55 --> Helper loaded: common_helper
INFO - 2022-03-10 04:11:55 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:11:55 --> Controller Class Initialized
INFO - 2022-03-10 04:11:55 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:11:55 --> Encrypt Class Initialized
INFO - 2022-03-10 04:11:55 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:11:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:11:55 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:11:55 --> Model "Users_model" initialized
INFO - 2022-03-10 04:11:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:11:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:11:56 --> Config Class Initialized
INFO - 2022-03-10 04:11:56 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:11:56 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:11:56 --> Utf8 Class Initialized
INFO - 2022-03-10 04:11:56 --> URI Class Initialized
INFO - 2022-03-10 04:11:56 --> Router Class Initialized
INFO - 2022-03-10 04:11:56 --> Output Class Initialized
INFO - 2022-03-10 04:11:56 --> Security Class Initialized
DEBUG - 2022-03-10 04:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:11:56 --> Input Class Initialized
INFO - 2022-03-10 04:11:56 --> Language Class Initialized
INFO - 2022-03-10 04:11:56 --> Loader Class Initialized
INFO - 2022-03-10 04:11:56 --> Helper loaded: url_helper
INFO - 2022-03-10 04:11:56 --> Helper loaded: form_helper
INFO - 2022-03-10 04:11:56 --> Helper loaded: common_helper
INFO - 2022-03-10 04:11:56 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:11:56 --> Controller Class Initialized
INFO - 2022-03-10 04:11:56 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:11:56 --> Encrypt Class Initialized
INFO - 2022-03-10 04:11:56 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:11:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:11:56 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:11:56 --> Model "Users_model" initialized
INFO - 2022-03-10 04:11:56 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:11:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:11:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:11:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:11:56 --> Final output sent to browser
DEBUG - 2022-03-10 04:11:56 --> Total execution time: 0.0644
ERROR - 2022-03-10 04:12:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:12:00 --> Config Class Initialized
INFO - 2022-03-10 04:12:00 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:12:00 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:12:00 --> Utf8 Class Initialized
INFO - 2022-03-10 04:12:00 --> URI Class Initialized
INFO - 2022-03-10 04:12:00 --> Router Class Initialized
INFO - 2022-03-10 04:12:00 --> Output Class Initialized
INFO - 2022-03-10 04:12:00 --> Security Class Initialized
DEBUG - 2022-03-10 04:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:12:00 --> Input Class Initialized
INFO - 2022-03-10 04:12:00 --> Language Class Initialized
INFO - 2022-03-10 04:12:00 --> Loader Class Initialized
INFO - 2022-03-10 04:12:00 --> Helper loaded: url_helper
INFO - 2022-03-10 04:12:00 --> Helper loaded: form_helper
INFO - 2022-03-10 04:12:00 --> Helper loaded: common_helper
INFO - 2022-03-10 04:12:00 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:12:00 --> Controller Class Initialized
INFO - 2022-03-10 04:12:00 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:12:00 --> Encrypt Class Initialized
INFO - 2022-03-10 04:12:00 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:12:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:12:00 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:12:00 --> Model "Users_model" initialized
INFO - 2022-03-10 04:12:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:13:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:13:28 --> Config Class Initialized
INFO - 2022-03-10 04:13:28 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:13:28 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:13:28 --> Utf8 Class Initialized
INFO - 2022-03-10 04:13:28 --> URI Class Initialized
INFO - 2022-03-10 04:13:28 --> Router Class Initialized
INFO - 2022-03-10 04:13:28 --> Output Class Initialized
INFO - 2022-03-10 04:13:28 --> Security Class Initialized
DEBUG - 2022-03-10 04:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:13:28 --> Input Class Initialized
INFO - 2022-03-10 04:13:28 --> Language Class Initialized
ERROR - 2022-03-10 04:13:28 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) /home3/karoteam/public_html/application/controllers/Patientcase.php 92
ERROR - 2022-03-10 04:13:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:13:45 --> Config Class Initialized
INFO - 2022-03-10 04:13:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:13:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:13:45 --> Utf8 Class Initialized
INFO - 2022-03-10 04:13:45 --> URI Class Initialized
INFO - 2022-03-10 04:13:45 --> Router Class Initialized
INFO - 2022-03-10 04:13:45 --> Output Class Initialized
INFO - 2022-03-10 04:13:45 --> Security Class Initialized
DEBUG - 2022-03-10 04:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:13:45 --> Input Class Initialized
INFO - 2022-03-10 04:13:45 --> Language Class Initialized
INFO - 2022-03-10 04:13:45 --> Loader Class Initialized
INFO - 2022-03-10 04:13:45 --> Helper loaded: url_helper
INFO - 2022-03-10 04:13:45 --> Helper loaded: form_helper
INFO - 2022-03-10 04:13:45 --> Helper loaded: common_helper
INFO - 2022-03-10 04:13:45 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:13:45 --> Controller Class Initialized
INFO - 2022-03-10 04:13:45 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:13:45 --> Encrypt Class Initialized
INFO - 2022-03-10 04:13:45 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:13:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:13:45 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:13:45 --> Model "Users_model" initialized
INFO - 2022-03-10 04:13:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:14:31 --> Config Class Initialized
INFO - 2022-03-10 04:14:31 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:14:31 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:14:31 --> Utf8 Class Initialized
INFO - 2022-03-10 04:14:31 --> URI Class Initialized
INFO - 2022-03-10 04:14:31 --> Router Class Initialized
INFO - 2022-03-10 04:14:31 --> Output Class Initialized
INFO - 2022-03-10 04:14:31 --> Security Class Initialized
DEBUG - 2022-03-10 04:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:14:31 --> Input Class Initialized
INFO - 2022-03-10 04:14:31 --> Language Class Initialized
INFO - 2022-03-10 04:14:31 --> Loader Class Initialized
INFO - 2022-03-10 04:14:31 --> Helper loaded: url_helper
INFO - 2022-03-10 04:14:31 --> Helper loaded: form_helper
INFO - 2022-03-10 04:14:31 --> Helper loaded: common_helper
INFO - 2022-03-10 04:14:31 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:14:31 --> Controller Class Initialized
INFO - 2022-03-10 04:14:31 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:14:31 --> Encrypt Class Initialized
INFO - 2022-03-10 04:14:31 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:14:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:14:31 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:14:31 --> Model "Users_model" initialized
INFO - 2022-03-10 04:14:31 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:15:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:15:00 --> Config Class Initialized
INFO - 2022-03-10 04:15:00 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:15:00 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:15:00 --> Utf8 Class Initialized
INFO - 2022-03-10 04:15:00 --> URI Class Initialized
INFO - 2022-03-10 04:15:00 --> Router Class Initialized
INFO - 2022-03-10 04:15:00 --> Output Class Initialized
INFO - 2022-03-10 04:15:00 --> Security Class Initialized
DEBUG - 2022-03-10 04:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:15:00 --> Input Class Initialized
INFO - 2022-03-10 04:15:00 --> Language Class Initialized
INFO - 2022-03-10 04:15:00 --> Loader Class Initialized
INFO - 2022-03-10 04:15:00 --> Helper loaded: url_helper
INFO - 2022-03-10 04:15:00 --> Helper loaded: form_helper
INFO - 2022-03-10 04:15:00 --> Helper loaded: common_helper
INFO - 2022-03-10 04:15:00 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:15:00 --> Controller Class Initialized
INFO - 2022-03-10 04:15:00 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:15:00 --> Encrypt Class Initialized
INFO - 2022-03-10 04:15:00 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:15:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:15:00 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:15:00 --> Model "Users_model" initialized
INFO - 2022-03-10 04:15:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:16:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:16:43 --> Config Class Initialized
INFO - 2022-03-10 04:16:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:16:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:16:43 --> Utf8 Class Initialized
INFO - 2022-03-10 04:16:43 --> URI Class Initialized
INFO - 2022-03-10 04:16:43 --> Router Class Initialized
INFO - 2022-03-10 04:16:43 --> Output Class Initialized
INFO - 2022-03-10 04:16:43 --> Security Class Initialized
DEBUG - 2022-03-10 04:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:16:43 --> Input Class Initialized
INFO - 2022-03-10 04:16:43 --> Language Class Initialized
INFO - 2022-03-10 04:16:43 --> Loader Class Initialized
INFO - 2022-03-10 04:16:43 --> Helper loaded: url_helper
INFO - 2022-03-10 04:16:43 --> Helper loaded: form_helper
INFO - 2022-03-10 04:16:43 --> Helper loaded: common_helper
INFO - 2022-03-10 04:16:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:16:43 --> Controller Class Initialized
INFO - 2022-03-10 04:16:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:16:43 --> Encrypt Class Initialized
INFO - 2022-03-10 04:16:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:16:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:16:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:16:43 --> Model "Users_model" initialized
INFO - 2022-03-10 04:16:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:16:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:16:44 --> Config Class Initialized
INFO - 2022-03-10 04:16:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:16:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:16:44 --> Utf8 Class Initialized
INFO - 2022-03-10 04:16:44 --> URI Class Initialized
INFO - 2022-03-10 04:16:44 --> Router Class Initialized
INFO - 2022-03-10 04:16:44 --> Output Class Initialized
INFO - 2022-03-10 04:16:44 --> Security Class Initialized
DEBUG - 2022-03-10 04:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:16:44 --> Input Class Initialized
INFO - 2022-03-10 04:16:44 --> Language Class Initialized
INFO - 2022-03-10 04:16:44 --> Loader Class Initialized
INFO - 2022-03-10 04:16:44 --> Helper loaded: url_helper
INFO - 2022-03-10 04:16:44 --> Helper loaded: form_helper
INFO - 2022-03-10 04:16:44 --> Helper loaded: common_helper
INFO - 2022-03-10 04:16:44 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:16:44 --> Controller Class Initialized
INFO - 2022-03-10 04:16:44 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:16:44 --> Encrypt Class Initialized
INFO - 2022-03-10 04:16:44 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:16:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:16:44 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:16:44 --> Model "Users_model" initialized
INFO - 2022-03-10 04:16:44 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:16:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:16:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:16:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:16:44 --> Final output sent to browser
DEBUG - 2022-03-10 04:16:44 --> Total execution time: 0.0541
ERROR - 2022-03-10 04:16:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:16:46 --> Config Class Initialized
INFO - 2022-03-10 04:16:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:16:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:16:46 --> Utf8 Class Initialized
INFO - 2022-03-10 04:16:46 --> URI Class Initialized
INFO - 2022-03-10 04:16:46 --> Router Class Initialized
INFO - 2022-03-10 04:16:46 --> Output Class Initialized
INFO - 2022-03-10 04:16:46 --> Security Class Initialized
DEBUG - 2022-03-10 04:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:16:46 --> Input Class Initialized
INFO - 2022-03-10 04:16:46 --> Language Class Initialized
INFO - 2022-03-10 04:16:46 --> Loader Class Initialized
INFO - 2022-03-10 04:16:46 --> Helper loaded: url_helper
INFO - 2022-03-10 04:16:46 --> Helper loaded: form_helper
INFO - 2022-03-10 04:16:46 --> Helper loaded: common_helper
INFO - 2022-03-10 04:16:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:16:46 --> Controller Class Initialized
INFO - 2022-03-10 04:16:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:16:46 --> Encrypt Class Initialized
INFO - 2022-03-10 04:16:46 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:16:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:16:46 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:16:46 --> Model "Users_model" initialized
INFO - 2022-03-10 04:16:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:16:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:16:48 --> Config Class Initialized
INFO - 2022-03-10 04:16:48 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:16:48 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:16:48 --> Utf8 Class Initialized
INFO - 2022-03-10 04:16:48 --> URI Class Initialized
INFO - 2022-03-10 04:16:48 --> Router Class Initialized
INFO - 2022-03-10 04:16:48 --> Output Class Initialized
INFO - 2022-03-10 04:16:48 --> Security Class Initialized
DEBUG - 2022-03-10 04:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:16:48 --> Input Class Initialized
INFO - 2022-03-10 04:16:48 --> Language Class Initialized
INFO - 2022-03-10 04:16:48 --> Loader Class Initialized
INFO - 2022-03-10 04:16:48 --> Helper loaded: url_helper
INFO - 2022-03-10 04:16:48 --> Helper loaded: form_helper
INFO - 2022-03-10 04:16:48 --> Helper loaded: common_helper
INFO - 2022-03-10 04:16:48 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:16:48 --> Controller Class Initialized
INFO - 2022-03-10 04:16:48 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:16:48 --> Encrypt Class Initialized
INFO - 2022-03-10 04:16:48 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:16:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:16:48 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:16:48 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:16:48 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:16:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:16:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 04:16:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:16:48 --> Final output sent to browser
DEBUG - 2022-03-10 04:16:48 --> Total execution time: 0.0428
ERROR - 2022-03-10 04:17:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:17:10 --> Config Class Initialized
INFO - 2022-03-10 04:17:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:17:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:17:10 --> Utf8 Class Initialized
INFO - 2022-03-10 04:17:10 --> URI Class Initialized
INFO - 2022-03-10 04:17:10 --> Router Class Initialized
INFO - 2022-03-10 04:17:10 --> Output Class Initialized
INFO - 2022-03-10 04:17:10 --> Security Class Initialized
DEBUG - 2022-03-10 04:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:17:10 --> Input Class Initialized
INFO - 2022-03-10 04:17:10 --> Language Class Initialized
INFO - 2022-03-10 04:17:10 --> Loader Class Initialized
INFO - 2022-03-10 04:17:10 --> Helper loaded: url_helper
INFO - 2022-03-10 04:17:10 --> Helper loaded: form_helper
INFO - 2022-03-10 04:17:10 --> Helper loaded: common_helper
INFO - 2022-03-10 04:17:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:17:10 --> Controller Class Initialized
INFO - 2022-03-10 04:17:10 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:17:10 --> Encrypt Class Initialized
INFO - 2022-03-10 04:17:10 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:17:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:17:10 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:17:10 --> Model "Users_model" initialized
INFO - 2022-03-10 04:17:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:17:10 --> Severity: error --> Exception: Call to undefined function jsondecode() /home3/karoteam/public_html/application/controllers/Patientcase.php 101
ERROR - 2022-03-10 04:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:17:29 --> Config Class Initialized
INFO - 2022-03-10 04:17:29 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:17:29 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:17:29 --> Utf8 Class Initialized
INFO - 2022-03-10 04:17:29 --> URI Class Initialized
INFO - 2022-03-10 04:17:29 --> Router Class Initialized
INFO - 2022-03-10 04:17:29 --> Output Class Initialized
INFO - 2022-03-10 04:17:29 --> Security Class Initialized
DEBUG - 2022-03-10 04:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:17:29 --> Input Class Initialized
INFO - 2022-03-10 04:17:29 --> Language Class Initialized
INFO - 2022-03-10 04:17:29 --> Loader Class Initialized
INFO - 2022-03-10 04:17:29 --> Helper loaded: url_helper
INFO - 2022-03-10 04:17:29 --> Helper loaded: form_helper
INFO - 2022-03-10 04:17:29 --> Helper loaded: common_helper
INFO - 2022-03-10 04:17:29 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:17:29 --> Controller Class Initialized
INFO - 2022-03-10 04:17:29 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:17:29 --> Encrypt Class Initialized
INFO - 2022-03-10 04:17:29 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:17:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:17:29 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:17:29 --> Model "Users_model" initialized
INFO - 2022-03-10 04:17:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:18:30 --> Config Class Initialized
INFO - 2022-03-10 04:18:30 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:18:30 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:18:30 --> Utf8 Class Initialized
INFO - 2022-03-10 04:18:30 --> URI Class Initialized
INFO - 2022-03-10 04:18:30 --> Router Class Initialized
INFO - 2022-03-10 04:18:30 --> Output Class Initialized
INFO - 2022-03-10 04:18:30 --> Security Class Initialized
DEBUG - 2022-03-10 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:18:30 --> Input Class Initialized
INFO - 2022-03-10 04:18:30 --> Language Class Initialized
INFO - 2022-03-10 04:18:30 --> Loader Class Initialized
INFO - 2022-03-10 04:18:30 --> Helper loaded: url_helper
INFO - 2022-03-10 04:18:30 --> Helper loaded: form_helper
INFO - 2022-03-10 04:18:30 --> Helper loaded: common_helper
INFO - 2022-03-10 04:18:30 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:18:30 --> Controller Class Initialized
INFO - 2022-03-10 04:18:30 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:18:30 --> Encrypt Class Initialized
INFO - 2022-03-10 04:18:30 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:18:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:18:30 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:18:30 --> Model "Users_model" initialized
INFO - 2022-03-10 04:18:30 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:18:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:18:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:18:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:18:31 --> Final output sent to browser
DEBUG - 2022-03-10 04:18:31 --> Total execution time: 0.0585
ERROR - 2022-03-10 04:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:20:42 --> Config Class Initialized
INFO - 2022-03-10 04:20:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:20:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:20:42 --> Utf8 Class Initialized
INFO - 2022-03-10 04:20:42 --> URI Class Initialized
INFO - 2022-03-10 04:20:42 --> Router Class Initialized
INFO - 2022-03-10 04:20:42 --> Output Class Initialized
INFO - 2022-03-10 04:20:42 --> Security Class Initialized
DEBUG - 2022-03-10 04:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:20:42 --> Input Class Initialized
INFO - 2022-03-10 04:20:42 --> Language Class Initialized
INFO - 2022-03-10 04:20:42 --> Loader Class Initialized
INFO - 2022-03-10 04:20:42 --> Helper loaded: url_helper
INFO - 2022-03-10 04:20:42 --> Helper loaded: form_helper
INFO - 2022-03-10 04:20:42 --> Helper loaded: common_helper
INFO - 2022-03-10 04:20:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:20:42 --> Controller Class Initialized
INFO - 2022-03-10 04:20:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:20:42 --> Encrypt Class Initialized
INFO - 2022-03-10 04:20:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:20:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:20:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:20:42 --> Model "Users_model" initialized
INFO - 2022-03-10 04:20:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:21:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:21:42 --> Config Class Initialized
INFO - 2022-03-10 04:21:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:21:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:21:42 --> Utf8 Class Initialized
INFO - 2022-03-10 04:21:42 --> URI Class Initialized
INFO - 2022-03-10 04:21:42 --> Router Class Initialized
INFO - 2022-03-10 04:21:42 --> Output Class Initialized
INFO - 2022-03-10 04:21:42 --> Security Class Initialized
DEBUG - 2022-03-10 04:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:21:42 --> Input Class Initialized
INFO - 2022-03-10 04:21:42 --> Language Class Initialized
INFO - 2022-03-10 04:21:42 --> Loader Class Initialized
INFO - 2022-03-10 04:21:42 --> Helper loaded: url_helper
INFO - 2022-03-10 04:21:42 --> Helper loaded: form_helper
INFO - 2022-03-10 04:21:42 --> Helper loaded: common_helper
INFO - 2022-03-10 04:21:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:21:42 --> Controller Class Initialized
INFO - 2022-03-10 04:21:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:21:42 --> Encrypt Class Initialized
INFO - 2022-03-10 04:21:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:21:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:21:42 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:21:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:21:42 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:21:42 --> Upload Class Initialized
INFO - 2022-03-10 04:21:42 --> Final output sent to browser
DEBUG - 2022-03-10 04:21:42 --> Total execution time: 0.0319
ERROR - 2022-03-10 04:21:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:21:49 --> Config Class Initialized
INFO - 2022-03-10 04:21:49 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:21:49 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:21:49 --> Utf8 Class Initialized
INFO - 2022-03-10 04:21:49 --> URI Class Initialized
INFO - 2022-03-10 04:21:49 --> Router Class Initialized
INFO - 2022-03-10 04:21:49 --> Output Class Initialized
INFO - 2022-03-10 04:21:49 --> Security Class Initialized
DEBUG - 2022-03-10 04:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:21:49 --> Input Class Initialized
INFO - 2022-03-10 04:21:49 --> Language Class Initialized
INFO - 2022-03-10 04:21:49 --> Loader Class Initialized
INFO - 2022-03-10 04:21:49 --> Helper loaded: url_helper
INFO - 2022-03-10 04:21:49 --> Helper loaded: form_helper
INFO - 2022-03-10 04:21:49 --> Helper loaded: common_helper
INFO - 2022-03-10 04:21:49 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:21:49 --> Controller Class Initialized
INFO - 2022-03-10 04:21:49 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:21:49 --> Encrypt Class Initialized
INFO - 2022-03-10 04:21:49 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:21:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:21:49 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:21:49 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:21:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:21:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:21:50 --> Config Class Initialized
INFO - 2022-03-10 04:21:50 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:21:50 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:21:50 --> Utf8 Class Initialized
INFO - 2022-03-10 04:21:50 --> URI Class Initialized
INFO - 2022-03-10 04:21:50 --> Router Class Initialized
INFO - 2022-03-10 04:21:50 --> Output Class Initialized
INFO - 2022-03-10 04:21:50 --> Security Class Initialized
DEBUG - 2022-03-10 04:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:21:50 --> Input Class Initialized
INFO - 2022-03-10 04:21:50 --> Language Class Initialized
INFO - 2022-03-10 04:21:50 --> Loader Class Initialized
INFO - 2022-03-10 04:21:50 --> Helper loaded: url_helper
INFO - 2022-03-10 04:21:50 --> Helper loaded: form_helper
INFO - 2022-03-10 04:21:50 --> Helper loaded: common_helper
INFO - 2022-03-10 04:21:50 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:21:50 --> Controller Class Initialized
INFO - 2022-03-10 04:21:50 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:21:50 --> Encrypt Class Initialized
INFO - 2022-03-10 04:21:50 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:21:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:21:50 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:21:50 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:21:50 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:21:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:21:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 04:21:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:21:50 --> Final output sent to browser
DEBUG - 2022-03-10 04:21:50 --> Total execution time: 0.0426
ERROR - 2022-03-10 04:21:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:21:50 --> Config Class Initialized
INFO - 2022-03-10 04:21:50 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:21:50 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:21:50 --> Utf8 Class Initialized
INFO - 2022-03-10 04:21:50 --> URI Class Initialized
INFO - 2022-03-10 04:21:50 --> Router Class Initialized
INFO - 2022-03-10 04:21:50 --> Output Class Initialized
INFO - 2022-03-10 04:21:50 --> Security Class Initialized
DEBUG - 2022-03-10 04:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:21:50 --> Input Class Initialized
INFO - 2022-03-10 04:21:50 --> Language Class Initialized
INFO - 2022-03-10 04:21:50 --> Loader Class Initialized
INFO - 2022-03-10 04:21:50 --> Helper loaded: url_helper
INFO - 2022-03-10 04:21:50 --> Helper loaded: form_helper
INFO - 2022-03-10 04:21:50 --> Helper loaded: common_helper
INFO - 2022-03-10 04:21:50 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:21:50 --> Controller Class Initialized
INFO - 2022-03-10 04:21:50 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:21:50 --> Encrypt Class Initialized
INFO - 2022-03-10 04:21:50 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:21:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:21:50 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:21:50 --> Model "Users_model" initialized
INFO - 2022-03-10 04:21:50 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:21:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:21:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:21:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:21:51 --> Final output sent to browser
DEBUG - 2022-03-10 04:21:51 --> Total execution time: 0.0653
ERROR - 2022-03-10 04:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:22:07 --> Config Class Initialized
INFO - 2022-03-10 04:22:07 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:22:07 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:22:07 --> Utf8 Class Initialized
INFO - 2022-03-10 04:22:07 --> URI Class Initialized
INFO - 2022-03-10 04:22:07 --> Router Class Initialized
INFO - 2022-03-10 04:22:07 --> Output Class Initialized
INFO - 2022-03-10 04:22:07 --> Security Class Initialized
DEBUG - 2022-03-10 04:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:22:07 --> Input Class Initialized
INFO - 2022-03-10 04:22:07 --> Language Class Initialized
INFO - 2022-03-10 04:22:07 --> Loader Class Initialized
INFO - 2022-03-10 04:22:07 --> Helper loaded: url_helper
INFO - 2022-03-10 04:22:07 --> Helper loaded: form_helper
INFO - 2022-03-10 04:22:07 --> Helper loaded: common_helper
INFO - 2022-03-10 04:22:07 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:22:07 --> Controller Class Initialized
INFO - 2022-03-10 04:22:07 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:22:07 --> Encrypt Class Initialized
INFO - 2022-03-10 04:22:07 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:22:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:22:07 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:22:07 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:22:07 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:22:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:22:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 04:22:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:22:07 --> Final output sent to browser
DEBUG - 2022-03-10 04:22:07 --> Total execution time: 0.0456
ERROR - 2022-03-10 04:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:23:36 --> Config Class Initialized
INFO - 2022-03-10 04:23:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:23:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:23:36 --> Utf8 Class Initialized
INFO - 2022-03-10 04:23:36 --> URI Class Initialized
INFO - 2022-03-10 04:23:36 --> Router Class Initialized
INFO - 2022-03-10 04:23:36 --> Output Class Initialized
INFO - 2022-03-10 04:23:36 --> Security Class Initialized
DEBUG - 2022-03-10 04:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:23:36 --> Input Class Initialized
INFO - 2022-03-10 04:23:36 --> Language Class Initialized
INFO - 2022-03-10 04:23:36 --> Loader Class Initialized
INFO - 2022-03-10 04:23:36 --> Helper loaded: url_helper
INFO - 2022-03-10 04:23:36 --> Helper loaded: form_helper
INFO - 2022-03-10 04:23:36 --> Helper loaded: common_helper
INFO - 2022-03-10 04:23:36 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:23:36 --> Controller Class Initialized
INFO - 2022-03-10 04:23:36 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:23:36 --> Encrypt Class Initialized
INFO - 2022-03-10 04:23:36 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:23:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:23:36 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:23:36 --> Model "Users_model" initialized
INFO - 2022-03-10 04:23:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:23:37 --> Config Class Initialized
INFO - 2022-03-10 04:23:37 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:23:37 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:23:37 --> Utf8 Class Initialized
INFO - 2022-03-10 04:23:37 --> URI Class Initialized
INFO - 2022-03-10 04:23:37 --> Router Class Initialized
INFO - 2022-03-10 04:23:37 --> Output Class Initialized
INFO - 2022-03-10 04:23:37 --> Security Class Initialized
DEBUG - 2022-03-10 04:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:23:37 --> Input Class Initialized
INFO - 2022-03-10 04:23:37 --> Language Class Initialized
INFO - 2022-03-10 04:23:37 --> Loader Class Initialized
INFO - 2022-03-10 04:23:37 --> Helper loaded: url_helper
INFO - 2022-03-10 04:23:37 --> Helper loaded: form_helper
INFO - 2022-03-10 04:23:37 --> Helper loaded: common_helper
INFO - 2022-03-10 04:23:37 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:23:37 --> Controller Class Initialized
INFO - 2022-03-10 04:23:37 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:23:37 --> Encrypt Class Initialized
INFO - 2022-03-10 04:23:37 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:23:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:23:37 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:23:37 --> Model "Users_model" initialized
INFO - 2022-03-10 04:23:37 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:23:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:23:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:23:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:23:37 --> Final output sent to browser
DEBUG - 2022-03-10 04:23:37 --> Total execution time: 0.0565
ERROR - 2022-03-10 04:25:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:25:50 --> Config Class Initialized
INFO - 2022-03-10 04:25:50 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:25:50 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:25:50 --> Utf8 Class Initialized
INFO - 2022-03-10 04:25:50 --> URI Class Initialized
INFO - 2022-03-10 04:25:50 --> Router Class Initialized
INFO - 2022-03-10 04:25:50 --> Output Class Initialized
INFO - 2022-03-10 04:25:50 --> Security Class Initialized
DEBUG - 2022-03-10 04:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:25:50 --> Input Class Initialized
INFO - 2022-03-10 04:25:50 --> Language Class Initialized
INFO - 2022-03-10 04:25:50 --> Loader Class Initialized
INFO - 2022-03-10 04:25:50 --> Helper loaded: url_helper
INFO - 2022-03-10 04:25:50 --> Helper loaded: form_helper
INFO - 2022-03-10 04:25:50 --> Helper loaded: common_helper
INFO - 2022-03-10 04:25:50 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:25:50 --> Controller Class Initialized
INFO - 2022-03-10 04:25:50 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:25:50 --> Encrypt Class Initialized
INFO - 2022-03-10 04:25:50 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:25:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:25:50 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:25:50 --> Model "Users_model" initialized
INFO - 2022-03-10 04:25:50 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:26:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:26:26 --> Config Class Initialized
INFO - 2022-03-10 04:26:26 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:26:26 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:26:26 --> Utf8 Class Initialized
INFO - 2022-03-10 04:26:26 --> URI Class Initialized
INFO - 2022-03-10 04:26:26 --> Router Class Initialized
INFO - 2022-03-10 04:26:26 --> Output Class Initialized
INFO - 2022-03-10 04:26:26 --> Security Class Initialized
DEBUG - 2022-03-10 04:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:26:26 --> Input Class Initialized
INFO - 2022-03-10 04:26:26 --> Language Class Initialized
ERROR - 2022-03-10 04:26:26 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 04:27:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:27:01 --> Config Class Initialized
INFO - 2022-03-10 04:27:01 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:27:01 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:27:01 --> Utf8 Class Initialized
INFO - 2022-03-10 04:27:01 --> URI Class Initialized
INFO - 2022-03-10 04:27:01 --> Router Class Initialized
INFO - 2022-03-10 04:27:01 --> Output Class Initialized
INFO - 2022-03-10 04:27:01 --> Security Class Initialized
DEBUG - 2022-03-10 04:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:27:01 --> Input Class Initialized
INFO - 2022-03-10 04:27:01 --> Language Class Initialized
INFO - 2022-03-10 04:27:01 --> Loader Class Initialized
INFO - 2022-03-10 04:27:01 --> Helper loaded: url_helper
INFO - 2022-03-10 04:27:01 --> Helper loaded: form_helper
INFO - 2022-03-10 04:27:01 --> Helper loaded: common_helper
INFO - 2022-03-10 04:27:01 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:27:01 --> Controller Class Initialized
INFO - 2022-03-10 04:27:01 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:27:01 --> Encrypt Class Initialized
INFO - 2022-03-10 04:27:01 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:27:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:27:01 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:27:01 --> Model "Users_model" initialized
INFO - 2022-03-10 04:27:01 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:27:01 --> Final output sent to browser
DEBUG - 2022-03-10 04:27:01 --> Total execution time: 0.1108
ERROR - 2022-03-10 04:27:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:27:32 --> Config Class Initialized
INFO - 2022-03-10 04:27:32 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:27:32 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:27:32 --> Utf8 Class Initialized
INFO - 2022-03-10 04:27:32 --> URI Class Initialized
INFO - 2022-03-10 04:27:32 --> Router Class Initialized
INFO - 2022-03-10 04:27:32 --> Output Class Initialized
INFO - 2022-03-10 04:27:32 --> Security Class Initialized
DEBUG - 2022-03-10 04:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:27:32 --> Input Class Initialized
INFO - 2022-03-10 04:27:32 --> Language Class Initialized
INFO - 2022-03-10 04:27:32 --> Loader Class Initialized
INFO - 2022-03-10 04:27:32 --> Helper loaded: url_helper
INFO - 2022-03-10 04:27:32 --> Helper loaded: form_helper
INFO - 2022-03-10 04:27:32 --> Helper loaded: common_helper
INFO - 2022-03-10 04:27:32 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:27:32 --> Controller Class Initialized
INFO - 2022-03-10 04:27:32 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:27:32 --> Encrypt Class Initialized
INFO - 2022-03-10 04:27:32 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:27:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:27:32 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:27:32 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:27:32 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:27:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:27:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 04:27:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-10 04:27:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:27:40 --> Config Class Initialized
INFO - 2022-03-10 04:27:40 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:27:40 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:27:40 --> Utf8 Class Initialized
INFO - 2022-03-10 04:27:40 --> URI Class Initialized
INFO - 2022-03-10 04:27:40 --> Router Class Initialized
INFO - 2022-03-10 04:27:40 --> Output Class Initialized
INFO - 2022-03-10 04:27:40 --> Security Class Initialized
DEBUG - 2022-03-10 04:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:27:40 --> Input Class Initialized
INFO - 2022-03-10 04:27:40 --> Language Class Initialized
ERROR - 2022-03-10 04:27:40 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:27:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:27:43 --> Config Class Initialized
INFO - 2022-03-10 04:27:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:27:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:27:43 --> Utf8 Class Initialized
INFO - 2022-03-10 04:27:43 --> URI Class Initialized
INFO - 2022-03-10 04:27:43 --> Router Class Initialized
INFO - 2022-03-10 04:27:43 --> Output Class Initialized
INFO - 2022-03-10 04:27:43 --> Security Class Initialized
DEBUG - 2022-03-10 04:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:27:43 --> Input Class Initialized
INFO - 2022-03-10 04:27:43 --> Language Class Initialized
INFO - 2022-03-10 04:27:43 --> Loader Class Initialized
INFO - 2022-03-10 04:27:43 --> Helper loaded: url_helper
INFO - 2022-03-10 04:27:43 --> Helper loaded: form_helper
INFO - 2022-03-10 04:27:43 --> Helper loaded: common_helper
INFO - 2022-03-10 04:27:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:27:46 --> Final output sent to browser
DEBUG - 2022-03-10 04:27:46 --> Total execution time: 6.8342
INFO - 2022-03-10 04:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:27:46 --> Controller Class Initialized
INFO - 2022-03-10 04:27:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:27:46 --> Encrypt Class Initialized
INFO - 2022-03-10 04:27:46 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:27:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:27:46 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:27:46 --> Model "Users_model" initialized
INFO - 2022-03-10 04:27:46 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:27:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:27:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:27:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:27:46 --> Final output sent to browser
DEBUG - 2022-03-10 04:27:46 --> Total execution time: 3.2440
ERROR - 2022-03-10 04:27:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:27:48 --> Config Class Initialized
INFO - 2022-03-10 04:27:48 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:27:48 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:27:48 --> Utf8 Class Initialized
INFO - 2022-03-10 04:27:48 --> URI Class Initialized
INFO - 2022-03-10 04:27:48 --> Router Class Initialized
INFO - 2022-03-10 04:27:48 --> Output Class Initialized
INFO - 2022-03-10 04:27:48 --> Security Class Initialized
DEBUG - 2022-03-10 04:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:27:48 --> Input Class Initialized
INFO - 2022-03-10 04:27:48 --> Language Class Initialized
ERROR - 2022-03-10 04:27:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:27:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:27:55 --> Config Class Initialized
INFO - 2022-03-10 04:27:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:27:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:27:55 --> Utf8 Class Initialized
INFO - 2022-03-10 04:27:55 --> URI Class Initialized
INFO - 2022-03-10 04:27:55 --> Router Class Initialized
INFO - 2022-03-10 04:27:55 --> Output Class Initialized
INFO - 2022-03-10 04:27:55 --> Security Class Initialized
DEBUG - 2022-03-10 04:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:27:55 --> Input Class Initialized
INFO - 2022-03-10 04:27:55 --> Language Class Initialized
ERROR - 2022-03-10 04:27:55 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 04:28:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:28:24 --> Config Class Initialized
INFO - 2022-03-10 04:28:24 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:28:24 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:28:24 --> Utf8 Class Initialized
INFO - 2022-03-10 04:28:24 --> URI Class Initialized
INFO - 2022-03-10 04:28:24 --> Router Class Initialized
INFO - 2022-03-10 04:28:24 --> Output Class Initialized
INFO - 2022-03-10 04:28:24 --> Security Class Initialized
DEBUG - 2022-03-10 04:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:28:24 --> Input Class Initialized
INFO - 2022-03-10 04:28:24 --> Language Class Initialized
INFO - 2022-03-10 04:28:24 --> Loader Class Initialized
INFO - 2022-03-10 04:28:24 --> Helper loaded: url_helper
INFO - 2022-03-10 04:28:24 --> Helper loaded: form_helper
INFO - 2022-03-10 04:28:24 --> Helper loaded: common_helper
INFO - 2022-03-10 04:28:24 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:28:24 --> Controller Class Initialized
INFO - 2022-03-10 04:28:24 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:28:24 --> Encrypt Class Initialized
INFO - 2022-03-10 04:28:24 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:28:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:28:24 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:28:24 --> Model "Users_model" initialized
INFO - 2022-03-10 04:28:24 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:28:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:28:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:28:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:28:25 --> Final output sent to browser
DEBUG - 2022-03-10 04:28:25 --> Total execution time: 0.0532
ERROR - 2022-03-10 04:28:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:28:26 --> Config Class Initialized
INFO - 2022-03-10 04:28:26 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:28:26 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:28:26 --> Utf8 Class Initialized
INFO - 2022-03-10 04:28:26 --> URI Class Initialized
INFO - 2022-03-10 04:28:26 --> Router Class Initialized
INFO - 2022-03-10 04:28:26 --> Output Class Initialized
INFO - 2022-03-10 04:28:26 --> Security Class Initialized
DEBUG - 2022-03-10 04:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:28:26 --> Input Class Initialized
INFO - 2022-03-10 04:28:26 --> Language Class Initialized
ERROR - 2022-03-10 04:28:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:31:31 --> Config Class Initialized
INFO - 2022-03-10 04:31:31 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:31:31 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:31:31 --> Utf8 Class Initialized
INFO - 2022-03-10 04:31:31 --> URI Class Initialized
INFO - 2022-03-10 04:31:31 --> Router Class Initialized
INFO - 2022-03-10 04:31:31 --> Output Class Initialized
INFO - 2022-03-10 04:31:31 --> Security Class Initialized
DEBUG - 2022-03-10 04:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:31:31 --> Input Class Initialized
INFO - 2022-03-10 04:31:31 --> Language Class Initialized
INFO - 2022-03-10 04:31:31 --> Loader Class Initialized
INFO - 2022-03-10 04:31:31 --> Helper loaded: url_helper
INFO - 2022-03-10 04:31:31 --> Helper loaded: form_helper
INFO - 2022-03-10 04:31:31 --> Helper loaded: common_helper
INFO - 2022-03-10 04:31:31 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:31:31 --> Controller Class Initialized
INFO - 2022-03-10 04:31:31 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:31:31 --> Encrypt Class Initialized
INFO - 2022-03-10 04:31:31 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:31:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:31:31 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:31:31 --> Model "Users_model" initialized
INFO - 2022-03-10 04:31:31 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:31:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:31:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:31:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:31:31 --> Final output sent to browser
DEBUG - 2022-03-10 04:31:31 --> Total execution time: 0.0543
ERROR - 2022-03-10 04:33:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:33:01 --> Config Class Initialized
INFO - 2022-03-10 04:33:01 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:33:01 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:33:01 --> Utf8 Class Initialized
INFO - 2022-03-10 04:33:01 --> URI Class Initialized
INFO - 2022-03-10 04:33:01 --> Router Class Initialized
INFO - 2022-03-10 04:33:01 --> Output Class Initialized
INFO - 2022-03-10 04:33:01 --> Security Class Initialized
DEBUG - 2022-03-10 04:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:33:01 --> Input Class Initialized
INFO - 2022-03-10 04:33:01 --> Language Class Initialized
INFO - 2022-03-10 04:33:01 --> Loader Class Initialized
INFO - 2022-03-10 04:33:01 --> Helper loaded: url_helper
INFO - 2022-03-10 04:33:01 --> Helper loaded: form_helper
INFO - 2022-03-10 04:33:01 --> Helper loaded: common_helper
INFO - 2022-03-10 04:33:01 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:33:01 --> Controller Class Initialized
INFO - 2022-03-10 04:33:01 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:33:01 --> Encrypt Class Initialized
INFO - 2022-03-10 04:33:01 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:33:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:33:01 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:33:01 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:33:01 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:33:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:33:01 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 04:33:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:33:01 --> Final output sent to browser
DEBUG - 2022-03-10 04:33:01 --> Total execution time: 0.0687
ERROR - 2022-03-10 04:33:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:33:05 --> Config Class Initialized
INFO - 2022-03-10 04:33:05 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:33:05 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:33:05 --> Utf8 Class Initialized
INFO - 2022-03-10 04:33:05 --> URI Class Initialized
INFO - 2022-03-10 04:33:05 --> Router Class Initialized
INFO - 2022-03-10 04:33:05 --> Output Class Initialized
INFO - 2022-03-10 04:33:05 --> Security Class Initialized
DEBUG - 2022-03-10 04:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:33:05 --> Input Class Initialized
INFO - 2022-03-10 04:33:05 --> Language Class Initialized
INFO - 2022-03-10 04:33:05 --> Loader Class Initialized
INFO - 2022-03-10 04:33:05 --> Helper loaded: url_helper
INFO - 2022-03-10 04:33:05 --> Helper loaded: form_helper
INFO - 2022-03-10 04:33:05 --> Helper loaded: common_helper
INFO - 2022-03-10 04:33:05 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:33:05 --> Controller Class Initialized
INFO - 2022-03-10 04:33:05 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:33:05 --> Encrypt Class Initialized
INFO - 2022-03-10 04:33:05 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:33:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:33:05 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:33:05 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:33:05 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:33:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:33:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 04:33:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:33:05 --> Final output sent to browser
DEBUG - 2022-03-10 04:33:05 --> Total execution time: 0.0330
ERROR - 2022-03-10 04:33:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:33:06 --> Config Class Initialized
INFO - 2022-03-10 04:33:06 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:33:06 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:33:06 --> Utf8 Class Initialized
INFO - 2022-03-10 04:33:06 --> URI Class Initialized
INFO - 2022-03-10 04:33:06 --> Router Class Initialized
INFO - 2022-03-10 04:33:06 --> Output Class Initialized
INFO - 2022-03-10 04:33:06 --> Security Class Initialized
DEBUG - 2022-03-10 04:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:33:06 --> Input Class Initialized
INFO - 2022-03-10 04:33:06 --> Language Class Initialized
INFO - 2022-03-10 04:33:06 --> Loader Class Initialized
INFO - 2022-03-10 04:33:06 --> Helper loaded: url_helper
INFO - 2022-03-10 04:33:06 --> Helper loaded: form_helper
INFO - 2022-03-10 04:33:06 --> Helper loaded: common_helper
INFO - 2022-03-10 04:33:06 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:33:06 --> Controller Class Initialized
INFO - 2022-03-10 04:33:06 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:33:06 --> Encrypt Class Initialized
INFO - 2022-03-10 04:33:06 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:33:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:33:06 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:33:06 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:33:06 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:33:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:33:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 04:33:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:33:06 --> Final output sent to browser
DEBUG - 2022-03-10 04:33:06 --> Total execution time: 0.0313
ERROR - 2022-03-10 04:34:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:34:02 --> Config Class Initialized
INFO - 2022-03-10 04:34:02 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:34:02 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:34:02 --> Utf8 Class Initialized
INFO - 2022-03-10 04:34:02 --> URI Class Initialized
INFO - 2022-03-10 04:34:02 --> Router Class Initialized
INFO - 2022-03-10 04:34:02 --> Output Class Initialized
INFO - 2022-03-10 04:34:02 --> Security Class Initialized
DEBUG - 2022-03-10 04:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:34:02 --> Input Class Initialized
INFO - 2022-03-10 04:34:02 --> Language Class Initialized
INFO - 2022-03-10 04:34:02 --> Loader Class Initialized
INFO - 2022-03-10 04:34:02 --> Helper loaded: url_helper
INFO - 2022-03-10 04:34:02 --> Helper loaded: form_helper
INFO - 2022-03-10 04:34:02 --> Helper loaded: common_helper
INFO - 2022-03-10 04:34:02 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:34:02 --> Controller Class Initialized
INFO - 2022-03-10 04:34:02 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:34:02 --> Encrypt Class Initialized
DEBUG - 2022-03-10 04:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 04:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 04:34:02 --> Email Class Initialized
INFO - 2022-03-10 04:34:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 04:34:02 --> Calendar Class Initialized
INFO - 2022-03-10 04:34:02 --> Model "Login_model" initialized
INFO - 2022-03-10 04:34:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 04:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:34:03 --> Config Class Initialized
INFO - 2022-03-10 04:34:03 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:34:03 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:34:03 --> Utf8 Class Initialized
INFO - 2022-03-10 04:34:03 --> URI Class Initialized
INFO - 2022-03-10 04:34:03 --> Router Class Initialized
INFO - 2022-03-10 04:34:03 --> Output Class Initialized
INFO - 2022-03-10 04:34:03 --> Security Class Initialized
DEBUG - 2022-03-10 04:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:34:03 --> Input Class Initialized
INFO - 2022-03-10 04:34:03 --> Language Class Initialized
INFO - 2022-03-10 04:34:03 --> Loader Class Initialized
INFO - 2022-03-10 04:34:03 --> Helper loaded: url_helper
INFO - 2022-03-10 04:34:03 --> Helper loaded: form_helper
INFO - 2022-03-10 04:34:03 --> Helper loaded: common_helper
INFO - 2022-03-10 04:34:03 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:34:03 --> Controller Class Initialized
INFO - 2022-03-10 04:34:03 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:34:03 --> Encrypt Class Initialized
INFO - 2022-03-10 04:34:03 --> Model "Login_model" initialized
INFO - 2022-03-10 04:34:03 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 04:34:03 --> Model "Case_model" initialized
INFO - 2022-03-10 04:34:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:34:24 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 04:34:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:34:24 --> Final output sent to browser
DEBUG - 2022-03-10 04:34:24 --> Total execution time: 21.4791
ERROR - 2022-03-10 04:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:34:26 --> Config Class Initialized
INFO - 2022-03-10 04:34:26 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:34:26 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:34:26 --> Utf8 Class Initialized
INFO - 2022-03-10 04:34:26 --> URI Class Initialized
INFO - 2022-03-10 04:34:26 --> Router Class Initialized
INFO - 2022-03-10 04:34:26 --> Output Class Initialized
INFO - 2022-03-10 04:34:26 --> Security Class Initialized
DEBUG - 2022-03-10 04:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:34:26 --> Input Class Initialized
INFO - 2022-03-10 04:34:26 --> Language Class Initialized
ERROR - 2022-03-10 04:34:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:35:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:35:43 --> Config Class Initialized
INFO - 2022-03-10 04:35:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:35:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:35:43 --> Utf8 Class Initialized
INFO - 2022-03-10 04:35:43 --> URI Class Initialized
INFO - 2022-03-10 04:35:43 --> Router Class Initialized
INFO - 2022-03-10 04:35:43 --> Output Class Initialized
INFO - 2022-03-10 04:35:43 --> Security Class Initialized
DEBUG - 2022-03-10 04:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:35:43 --> Input Class Initialized
INFO - 2022-03-10 04:35:43 --> Language Class Initialized
INFO - 2022-03-10 04:35:43 --> Loader Class Initialized
INFO - 2022-03-10 04:35:43 --> Helper loaded: url_helper
INFO - 2022-03-10 04:35:43 --> Helper loaded: form_helper
INFO - 2022-03-10 04:35:43 --> Helper loaded: common_helper
INFO - 2022-03-10 04:35:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:35:43 --> Controller Class Initialized
INFO - 2022-03-10 04:35:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:35:43 --> Encrypt Class Initialized
INFO - 2022-03-10 04:35:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:35:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:35:43 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:35:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:35:43 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:35:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:35:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 04:35:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-10 04:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:35:49 --> Config Class Initialized
INFO - 2022-03-10 04:35:49 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:35:49 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:35:49 --> Utf8 Class Initialized
INFO - 2022-03-10 04:35:49 --> URI Class Initialized
INFO - 2022-03-10 04:35:49 --> Router Class Initialized
INFO - 2022-03-10 04:35:49 --> Output Class Initialized
INFO - 2022-03-10 04:35:49 --> Security Class Initialized
DEBUG - 2022-03-10 04:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:35:49 --> Input Class Initialized
INFO - 2022-03-10 04:35:49 --> Language Class Initialized
ERROR - 2022-03-10 04:35:49 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-10 04:35:50 --> Final output sent to browser
DEBUG - 2022-03-10 04:35:50 --> Total execution time: 5.4701
ERROR - 2022-03-10 04:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:36:20 --> Config Class Initialized
INFO - 2022-03-10 04:36:20 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:36:20 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:36:20 --> Utf8 Class Initialized
INFO - 2022-03-10 04:36:20 --> URI Class Initialized
INFO - 2022-03-10 04:36:20 --> Router Class Initialized
INFO - 2022-03-10 04:36:20 --> Output Class Initialized
INFO - 2022-03-10 04:36:20 --> Security Class Initialized
DEBUG - 2022-03-10 04:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:36:20 --> Input Class Initialized
INFO - 2022-03-10 04:36:20 --> Language Class Initialized
INFO - 2022-03-10 04:36:20 --> Loader Class Initialized
INFO - 2022-03-10 04:36:20 --> Helper loaded: url_helper
INFO - 2022-03-10 04:36:20 --> Helper loaded: form_helper
INFO - 2022-03-10 04:36:20 --> Helper loaded: common_helper
INFO - 2022-03-10 04:36:20 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:36:20 --> Controller Class Initialized
INFO - 2022-03-10 04:36:20 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:36:20 --> Encrypt Class Initialized
INFO - 2022-03-10 04:36:20 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:36:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:36:20 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:36:20 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:36:20 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:36:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:36:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 04:36:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:36:20 --> Final output sent to browser
DEBUG - 2022-03-10 04:36:20 --> Total execution time: 0.0421
ERROR - 2022-03-10 04:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:36:20 --> Config Class Initialized
INFO - 2022-03-10 04:36:20 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:36:20 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:36:20 --> Utf8 Class Initialized
INFO - 2022-03-10 04:36:20 --> URI Class Initialized
INFO - 2022-03-10 04:36:20 --> Router Class Initialized
INFO - 2022-03-10 04:36:20 --> Output Class Initialized
INFO - 2022-03-10 04:36:20 --> Security Class Initialized
DEBUG - 2022-03-10 04:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:36:20 --> Input Class Initialized
INFO - 2022-03-10 04:36:20 --> Language Class Initialized
ERROR - 2022-03-10 04:36:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:37:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:37:41 --> Config Class Initialized
INFO - 2022-03-10 04:37:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:37:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:37:41 --> Utf8 Class Initialized
INFO - 2022-03-10 04:37:41 --> URI Class Initialized
INFO - 2022-03-10 04:37:41 --> Router Class Initialized
INFO - 2022-03-10 04:37:41 --> Output Class Initialized
INFO - 2022-03-10 04:37:41 --> Security Class Initialized
DEBUG - 2022-03-10 04:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:37:41 --> Input Class Initialized
INFO - 2022-03-10 04:37:41 --> Language Class Initialized
INFO - 2022-03-10 04:37:41 --> Loader Class Initialized
INFO - 2022-03-10 04:37:41 --> Helper loaded: url_helper
INFO - 2022-03-10 04:37:41 --> Helper loaded: form_helper
INFO - 2022-03-10 04:37:41 --> Helper loaded: common_helper
INFO - 2022-03-10 04:37:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:37:41 --> Controller Class Initialized
INFO - 2022-03-10 04:37:41 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:37:41 --> Final output sent to browser
DEBUG - 2022-03-10 04:37:41 --> Total execution time: 0.0212
ERROR - 2022-03-10 04:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:38:24 --> Config Class Initialized
INFO - 2022-03-10 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:38:24 --> Utf8 Class Initialized
INFO - 2022-03-10 04:38:24 --> URI Class Initialized
INFO - 2022-03-10 04:38:24 --> Router Class Initialized
INFO - 2022-03-10 04:38:24 --> Output Class Initialized
INFO - 2022-03-10 04:38:24 --> Security Class Initialized
DEBUG - 2022-03-10 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:38:24 --> Input Class Initialized
INFO - 2022-03-10 04:38:24 --> Language Class Initialized
INFO - 2022-03-10 04:38:24 --> Loader Class Initialized
INFO - 2022-03-10 04:38:24 --> Helper loaded: url_helper
INFO - 2022-03-10 04:38:24 --> Helper loaded: form_helper
INFO - 2022-03-10 04:38:24 --> Helper loaded: common_helper
INFO - 2022-03-10 04:38:24 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:38:24 --> Controller Class Initialized
INFO - 2022-03-10 04:38:24 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:38:24 --> Final output sent to browser
DEBUG - 2022-03-10 04:38:24 --> Total execution time: 0.0534
ERROR - 2022-03-10 04:38:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:38:41 --> Config Class Initialized
INFO - 2022-03-10 04:38:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:38:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:38:41 --> Utf8 Class Initialized
INFO - 2022-03-10 04:38:41 --> URI Class Initialized
INFO - 2022-03-10 04:38:41 --> Router Class Initialized
INFO - 2022-03-10 04:38:41 --> Output Class Initialized
INFO - 2022-03-10 04:38:41 --> Security Class Initialized
DEBUG - 2022-03-10 04:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:38:41 --> Input Class Initialized
INFO - 2022-03-10 04:38:41 --> Language Class Initialized
INFO - 2022-03-10 04:38:41 --> Loader Class Initialized
INFO - 2022-03-10 04:38:41 --> Helper loaded: url_helper
INFO - 2022-03-10 04:38:41 --> Helper loaded: form_helper
INFO - 2022-03-10 04:38:41 --> Helper loaded: common_helper
INFO - 2022-03-10 04:38:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:38:41 --> Controller Class Initialized
INFO - 2022-03-10 04:38:41 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:38:41 --> Encrypt Class Initialized
INFO - 2022-03-10 04:38:41 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:38:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:38:41 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:38:41 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:38:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:38:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:38:42 --> Config Class Initialized
INFO - 2022-03-10 04:38:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:38:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:38:42 --> Utf8 Class Initialized
INFO - 2022-03-10 04:38:42 --> URI Class Initialized
INFO - 2022-03-10 04:38:42 --> Router Class Initialized
INFO - 2022-03-10 04:38:42 --> Output Class Initialized
INFO - 2022-03-10 04:38:42 --> Security Class Initialized
DEBUG - 2022-03-10 04:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:38:42 --> Input Class Initialized
INFO - 2022-03-10 04:38:42 --> Language Class Initialized
INFO - 2022-03-10 04:38:42 --> Loader Class Initialized
INFO - 2022-03-10 04:38:42 --> Helper loaded: url_helper
INFO - 2022-03-10 04:38:42 --> Helper loaded: form_helper
INFO - 2022-03-10 04:38:42 --> Helper loaded: common_helper
INFO - 2022-03-10 04:38:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:38:42 --> Controller Class Initialized
INFO - 2022-03-10 04:38:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:38:42 --> Encrypt Class Initialized
INFO - 2022-03-10 04:38:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:38:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:38:42 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:38:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:38:42 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:38:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:38:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 04:38:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:38:42 --> Final output sent to browser
DEBUG - 2022-03-10 04:38:42 --> Total execution time: 0.0450
ERROR - 2022-03-10 04:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:38:43 --> Config Class Initialized
INFO - 2022-03-10 04:38:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:38:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:38:43 --> Utf8 Class Initialized
INFO - 2022-03-10 04:38:43 --> URI Class Initialized
INFO - 2022-03-10 04:38:43 --> Router Class Initialized
INFO - 2022-03-10 04:38:43 --> Output Class Initialized
INFO - 2022-03-10 04:38:43 --> Security Class Initialized
DEBUG - 2022-03-10 04:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:38:43 --> Input Class Initialized
INFO - 2022-03-10 04:38:43 --> Language Class Initialized
ERROR - 2022-03-10 04:38:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:38:43 --> Config Class Initialized
INFO - 2022-03-10 04:38:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:38:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:38:43 --> Utf8 Class Initialized
INFO - 2022-03-10 04:38:43 --> URI Class Initialized
INFO - 2022-03-10 04:38:43 --> Router Class Initialized
INFO - 2022-03-10 04:38:43 --> Output Class Initialized
INFO - 2022-03-10 04:38:43 --> Security Class Initialized
DEBUG - 2022-03-10 04:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:38:43 --> Input Class Initialized
INFO - 2022-03-10 04:38:43 --> Language Class Initialized
INFO - 2022-03-10 04:38:43 --> Loader Class Initialized
INFO - 2022-03-10 04:38:43 --> Helper loaded: url_helper
INFO - 2022-03-10 04:38:43 --> Helper loaded: form_helper
INFO - 2022-03-10 04:38:43 --> Helper loaded: common_helper
INFO - 2022-03-10 04:38:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:38:43 --> Controller Class Initialized
INFO - 2022-03-10 04:38:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:38:43 --> Encrypt Class Initialized
INFO - 2022-03-10 04:38:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:38:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:38:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:38:43 --> Model "Users_model" initialized
INFO - 2022-03-10 04:38:43 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:38:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:38:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:38:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:38:43 --> Final output sent to browser
DEBUG - 2022-03-10 04:38:43 --> Total execution time: 0.0992
ERROR - 2022-03-10 04:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:38:44 --> Config Class Initialized
INFO - 2022-03-10 04:38:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:38:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:38:44 --> Utf8 Class Initialized
INFO - 2022-03-10 04:38:44 --> URI Class Initialized
INFO - 2022-03-10 04:38:44 --> Router Class Initialized
INFO - 2022-03-10 04:38:44 --> Output Class Initialized
INFO - 2022-03-10 04:38:44 --> Security Class Initialized
DEBUG - 2022-03-10 04:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:38:44 --> Input Class Initialized
INFO - 2022-03-10 04:38:44 --> Language Class Initialized
ERROR - 2022-03-10 04:38:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:38:44 --> Config Class Initialized
INFO - 2022-03-10 04:38:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:38:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:38:44 --> Utf8 Class Initialized
INFO - 2022-03-10 04:38:44 --> URI Class Initialized
INFO - 2022-03-10 04:38:44 --> Router Class Initialized
INFO - 2022-03-10 04:38:44 --> Output Class Initialized
INFO - 2022-03-10 04:38:44 --> Security Class Initialized
DEBUG - 2022-03-10 04:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:38:44 --> Input Class Initialized
INFO - 2022-03-10 04:38:44 --> Language Class Initialized
INFO - 2022-03-10 04:38:44 --> Loader Class Initialized
INFO - 2022-03-10 04:38:44 --> Helper loaded: url_helper
INFO - 2022-03-10 04:38:44 --> Helper loaded: form_helper
INFO - 2022-03-10 04:38:44 --> Helper loaded: common_helper
INFO - 2022-03-10 04:38:44 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:38:44 --> Controller Class Initialized
INFO - 2022-03-10 04:38:44 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:38:44 --> Encrypt Class Initialized
INFO - 2022-03-10 04:38:44 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:38:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:38:44 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:38:44 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:38:44 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:38:44 --> Final output sent to browser
DEBUG - 2022-03-10 04:38:44 --> Total execution time: 0.0269
ERROR - 2022-03-10 04:38:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:38:58 --> Config Class Initialized
INFO - 2022-03-10 04:38:58 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:38:58 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:38:58 --> Utf8 Class Initialized
INFO - 2022-03-10 04:38:58 --> URI Class Initialized
INFO - 2022-03-10 04:38:58 --> Router Class Initialized
INFO - 2022-03-10 04:38:58 --> Output Class Initialized
INFO - 2022-03-10 04:38:58 --> Security Class Initialized
DEBUG - 2022-03-10 04:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:38:58 --> Input Class Initialized
INFO - 2022-03-10 04:38:58 --> Language Class Initialized
INFO - 2022-03-10 04:38:58 --> Loader Class Initialized
INFO - 2022-03-10 04:38:58 --> Helper loaded: url_helper
INFO - 2022-03-10 04:38:58 --> Helper loaded: form_helper
INFO - 2022-03-10 04:38:58 --> Helper loaded: common_helper
INFO - 2022-03-10 04:38:58 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:38:58 --> Controller Class Initialized
INFO - 2022-03-10 04:38:58 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:38:58 --> Encrypt Class Initialized
INFO - 2022-03-10 04:38:58 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:38:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:38:58 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:38:58 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:38:58 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:38:58 --> Final output sent to browser
DEBUG - 2022-03-10 04:38:58 --> Total execution time: 0.0265
ERROR - 2022-03-10 04:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:39:18 --> Config Class Initialized
INFO - 2022-03-10 04:39:18 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:39:18 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:39:18 --> Utf8 Class Initialized
INFO - 2022-03-10 04:39:18 --> URI Class Initialized
INFO - 2022-03-10 04:39:18 --> Router Class Initialized
INFO - 2022-03-10 04:39:18 --> Output Class Initialized
INFO - 2022-03-10 04:39:18 --> Security Class Initialized
DEBUG - 2022-03-10 04:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:39:18 --> Input Class Initialized
INFO - 2022-03-10 04:39:18 --> Language Class Initialized
INFO - 2022-03-10 04:39:18 --> Loader Class Initialized
INFO - 2022-03-10 04:39:18 --> Helper loaded: url_helper
INFO - 2022-03-10 04:39:18 --> Helper loaded: form_helper
INFO - 2022-03-10 04:39:18 --> Helper loaded: common_helper
INFO - 2022-03-10 04:39:18 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:39:18 --> Controller Class Initialized
INFO - 2022-03-10 04:39:18 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:39:18 --> Encrypt Class Initialized
INFO - 2022-03-10 04:39:18 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:39:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:39:18 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:39:18 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:39:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:39:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:39:19 --> Config Class Initialized
INFO - 2022-03-10 04:39:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:39:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:39:19 --> Utf8 Class Initialized
INFO - 2022-03-10 04:39:19 --> URI Class Initialized
INFO - 2022-03-10 04:39:19 --> Router Class Initialized
INFO - 2022-03-10 04:39:19 --> Output Class Initialized
INFO - 2022-03-10 04:39:19 --> Security Class Initialized
DEBUG - 2022-03-10 04:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:39:19 --> Input Class Initialized
INFO - 2022-03-10 04:39:19 --> Language Class Initialized
INFO - 2022-03-10 04:39:19 --> Loader Class Initialized
INFO - 2022-03-10 04:39:19 --> Helper loaded: url_helper
INFO - 2022-03-10 04:39:19 --> Helper loaded: form_helper
INFO - 2022-03-10 04:39:19 --> Helper loaded: common_helper
INFO - 2022-03-10 04:39:19 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:39:19 --> Controller Class Initialized
INFO - 2022-03-10 04:39:19 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:39:19 --> Encrypt Class Initialized
INFO - 2022-03-10 04:39:19 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:39:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:39:19 --> Model "Referredby_model" initialized
INFO - 2022-03-10 04:39:19 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:39:19 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:39:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:39:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 04:39:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:39:19 --> Final output sent to browser
DEBUG - 2022-03-10 04:39:19 --> Total execution time: 0.0429
ERROR - 2022-03-10 04:39:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:39:19 --> Config Class Initialized
INFO - 2022-03-10 04:39:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:39:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:39:19 --> Utf8 Class Initialized
INFO - 2022-03-10 04:39:19 --> URI Class Initialized
INFO - 2022-03-10 04:39:19 --> Router Class Initialized
INFO - 2022-03-10 04:39:19 --> Output Class Initialized
INFO - 2022-03-10 04:39:19 --> Security Class Initialized
DEBUG - 2022-03-10 04:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:39:19 --> Input Class Initialized
INFO - 2022-03-10 04:39:19 --> Language Class Initialized
INFO - 2022-03-10 04:39:19 --> Loader Class Initialized
INFO - 2022-03-10 04:39:19 --> Helper loaded: url_helper
INFO - 2022-03-10 04:39:19 --> Helper loaded: form_helper
INFO - 2022-03-10 04:39:19 --> Helper loaded: common_helper
INFO - 2022-03-10 04:39:19 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:39:19 --> Controller Class Initialized
INFO - 2022-03-10 04:39:19 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:39:19 --> Encrypt Class Initialized
INFO - 2022-03-10 04:39:19 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:39:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:39:19 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:39:19 --> Model "Users_model" initialized
INFO - 2022-03-10 04:39:19 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:39:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:39:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:39:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:39:19 --> Final output sent to browser
DEBUG - 2022-03-10 04:39:19 --> Total execution time: 0.0620
ERROR - 2022-03-10 04:39:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:39:41 --> Config Class Initialized
INFO - 2022-03-10 04:39:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:39:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:39:41 --> Utf8 Class Initialized
INFO - 2022-03-10 04:39:41 --> URI Class Initialized
INFO - 2022-03-10 04:39:41 --> Router Class Initialized
INFO - 2022-03-10 04:39:41 --> Output Class Initialized
INFO - 2022-03-10 04:39:41 --> Security Class Initialized
DEBUG - 2022-03-10 04:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:39:41 --> Input Class Initialized
INFO - 2022-03-10 04:39:41 --> Language Class Initialized
INFO - 2022-03-10 04:39:41 --> Loader Class Initialized
INFO - 2022-03-10 04:39:41 --> Helper loaded: url_helper
INFO - 2022-03-10 04:39:41 --> Helper loaded: form_helper
INFO - 2022-03-10 04:39:41 --> Helper loaded: common_helper
INFO - 2022-03-10 04:39:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:39:41 --> Controller Class Initialized
INFO - 2022-03-10 04:39:41 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:39:41 --> Encrypt Class Initialized
INFO - 2022-03-10 04:39:41 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:39:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:39:41 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:39:41 --> Model "Users_model" initialized
INFO - 2022-03-10 04:39:41 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:39:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:39:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:39:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:39:41 --> Final output sent to browser
DEBUG - 2022-03-10 04:39:41 --> Total execution time: 0.0575
ERROR - 2022-03-10 04:39:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:39:43 --> Config Class Initialized
INFO - 2022-03-10 04:39:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:39:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:39:43 --> Utf8 Class Initialized
INFO - 2022-03-10 04:39:43 --> URI Class Initialized
INFO - 2022-03-10 04:39:43 --> Router Class Initialized
INFO - 2022-03-10 04:39:43 --> Output Class Initialized
INFO - 2022-03-10 04:39:43 --> Security Class Initialized
DEBUG - 2022-03-10 04:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:39:43 --> Input Class Initialized
INFO - 2022-03-10 04:39:43 --> Language Class Initialized
ERROR - 2022-03-10 04:39:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:43:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:43:57 --> Config Class Initialized
INFO - 2022-03-10 04:43:57 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:43:57 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:43:57 --> Utf8 Class Initialized
INFO - 2022-03-10 04:43:57 --> URI Class Initialized
INFO - 2022-03-10 04:43:57 --> Router Class Initialized
INFO - 2022-03-10 04:43:57 --> Output Class Initialized
INFO - 2022-03-10 04:43:57 --> Security Class Initialized
DEBUG - 2022-03-10 04:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:43:57 --> Input Class Initialized
INFO - 2022-03-10 04:43:57 --> Language Class Initialized
INFO - 2022-03-10 04:43:57 --> Loader Class Initialized
INFO - 2022-03-10 04:43:57 --> Helper loaded: url_helper
INFO - 2022-03-10 04:43:57 --> Helper loaded: form_helper
INFO - 2022-03-10 04:43:57 --> Helper loaded: common_helper
INFO - 2022-03-10 04:43:57 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:43:57 --> Controller Class Initialized
INFO - 2022-03-10 04:43:57 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:43:57 --> Encrypt Class Initialized
INFO - 2022-03-10 04:43:57 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:43:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:43:57 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:43:57 --> Model "Users_model" initialized
INFO - 2022-03-10 04:43:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:43:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:43:58 --> Config Class Initialized
INFO - 2022-03-10 04:43:58 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:43:58 --> Utf8 Class Initialized
INFO - 2022-03-10 04:43:58 --> URI Class Initialized
INFO - 2022-03-10 04:43:58 --> Router Class Initialized
INFO - 2022-03-10 04:43:58 --> Output Class Initialized
INFO - 2022-03-10 04:43:58 --> Security Class Initialized
DEBUG - 2022-03-10 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:43:58 --> Input Class Initialized
INFO - 2022-03-10 04:43:58 --> Language Class Initialized
INFO - 2022-03-10 04:43:58 --> Loader Class Initialized
INFO - 2022-03-10 04:43:58 --> Helper loaded: url_helper
INFO - 2022-03-10 04:43:58 --> Helper loaded: form_helper
INFO - 2022-03-10 04:43:58 --> Helper loaded: common_helper
INFO - 2022-03-10 04:43:58 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:43:58 --> Controller Class Initialized
INFO - 2022-03-10 04:43:58 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:43:58 --> Encrypt Class Initialized
INFO - 2022-03-10 04:43:58 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:43:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:43:58 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:43:58 --> Model "Users_model" initialized
INFO - 2022-03-10 04:43:58 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:43:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:43:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:43:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:43:58 --> Final output sent to browser
DEBUG - 2022-03-10 04:43:58 --> Total execution time: 0.0937
ERROR - 2022-03-10 04:43:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:43:58 --> Config Class Initialized
INFO - 2022-03-10 04:43:58 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:43:58 --> Utf8 Class Initialized
INFO - 2022-03-10 04:43:58 --> URI Class Initialized
INFO - 2022-03-10 04:43:58 --> Router Class Initialized
INFO - 2022-03-10 04:43:58 --> Output Class Initialized
INFO - 2022-03-10 04:43:58 --> Security Class Initialized
DEBUG - 2022-03-10 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:43:58 --> Input Class Initialized
INFO - 2022-03-10 04:43:58 --> Language Class Initialized
ERROR - 2022-03-10 04:43:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:49:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:49:31 --> Config Class Initialized
INFO - 2022-03-10 04:49:31 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:49:31 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:49:31 --> Utf8 Class Initialized
INFO - 2022-03-10 04:49:31 --> URI Class Initialized
INFO - 2022-03-10 04:49:31 --> Router Class Initialized
INFO - 2022-03-10 04:49:31 --> Output Class Initialized
INFO - 2022-03-10 04:49:31 --> Security Class Initialized
DEBUG - 2022-03-10 04:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:49:31 --> Input Class Initialized
INFO - 2022-03-10 04:49:31 --> Language Class Initialized
INFO - 2022-03-10 04:49:31 --> Loader Class Initialized
INFO - 2022-03-10 04:49:31 --> Helper loaded: url_helper
INFO - 2022-03-10 04:49:31 --> Helper loaded: form_helper
INFO - 2022-03-10 04:49:31 --> Helper loaded: common_helper
INFO - 2022-03-10 04:49:31 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:49:31 --> Controller Class Initialized
INFO - 2022-03-10 04:49:31 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:49:31 --> Encrypt Class Initialized
INFO - 2022-03-10 04:49:31 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:49:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:49:31 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:49:31 --> Model "Users_model" initialized
INFO - 2022-03-10 04:49:31 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:49:31 --> Final output sent to browser
DEBUG - 2022-03-10 04:49:31 --> Total execution time: 0.0308
ERROR - 2022-03-10 04:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:49:34 --> Config Class Initialized
INFO - 2022-03-10 04:49:34 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:49:34 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:49:34 --> Utf8 Class Initialized
INFO - 2022-03-10 04:49:34 --> URI Class Initialized
INFO - 2022-03-10 04:49:34 --> Router Class Initialized
INFO - 2022-03-10 04:49:34 --> Output Class Initialized
INFO - 2022-03-10 04:49:34 --> Security Class Initialized
DEBUG - 2022-03-10 04:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:49:34 --> Input Class Initialized
INFO - 2022-03-10 04:49:34 --> Language Class Initialized
INFO - 2022-03-10 04:49:34 --> Loader Class Initialized
INFO - 2022-03-10 04:49:34 --> Helper loaded: url_helper
INFO - 2022-03-10 04:49:34 --> Helper loaded: form_helper
INFO - 2022-03-10 04:49:34 --> Helper loaded: common_helper
INFO - 2022-03-10 04:49:34 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:49:34 --> Controller Class Initialized
INFO - 2022-03-10 04:49:34 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:49:34 --> Encrypt Class Initialized
INFO - 2022-03-10 04:49:34 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:49:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:49:34 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:49:34 --> Model "Users_model" initialized
INFO - 2022-03-10 04:49:34 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:49:34 --> Final output sent to browser
DEBUG - 2022-03-10 04:49:34 --> Total execution time: 0.0302
ERROR - 2022-03-10 04:49:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:49:38 --> Config Class Initialized
INFO - 2022-03-10 04:49:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:49:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:49:38 --> Utf8 Class Initialized
INFO - 2022-03-10 04:49:38 --> URI Class Initialized
INFO - 2022-03-10 04:49:38 --> Router Class Initialized
INFO - 2022-03-10 04:49:38 --> Output Class Initialized
INFO - 2022-03-10 04:49:38 --> Security Class Initialized
DEBUG - 2022-03-10 04:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:49:38 --> Input Class Initialized
INFO - 2022-03-10 04:49:38 --> Language Class Initialized
INFO - 2022-03-10 04:49:38 --> Loader Class Initialized
INFO - 2022-03-10 04:49:38 --> Helper loaded: url_helper
INFO - 2022-03-10 04:49:38 --> Helper loaded: form_helper
INFO - 2022-03-10 04:49:38 --> Helper loaded: common_helper
INFO - 2022-03-10 04:49:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:49:38 --> Controller Class Initialized
INFO - 2022-03-10 04:49:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:49:38 --> Encrypt Class Initialized
INFO - 2022-03-10 04:49:38 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:49:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:49:38 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:49:38 --> Model "Users_model" initialized
INFO - 2022-03-10 04:49:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:49:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:49:39 --> Config Class Initialized
INFO - 2022-03-10 04:49:39 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:49:39 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:49:39 --> Utf8 Class Initialized
INFO - 2022-03-10 04:49:39 --> URI Class Initialized
INFO - 2022-03-10 04:49:39 --> Router Class Initialized
INFO - 2022-03-10 04:49:39 --> Output Class Initialized
INFO - 2022-03-10 04:49:39 --> Security Class Initialized
DEBUG - 2022-03-10 04:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:49:39 --> Input Class Initialized
INFO - 2022-03-10 04:49:39 --> Language Class Initialized
INFO - 2022-03-10 04:49:39 --> Loader Class Initialized
INFO - 2022-03-10 04:49:39 --> Helper loaded: url_helper
INFO - 2022-03-10 04:49:39 --> Helper loaded: form_helper
INFO - 2022-03-10 04:49:39 --> Helper loaded: common_helper
INFO - 2022-03-10 04:49:39 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:49:39 --> Controller Class Initialized
INFO - 2022-03-10 04:49:39 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:49:39 --> Encrypt Class Initialized
INFO - 2022-03-10 04:49:39 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:49:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:49:39 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:49:39 --> Model "Users_model" initialized
INFO - 2022-03-10 04:49:39 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:49:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:49:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:49:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:49:39 --> Final output sent to browser
DEBUG - 2022-03-10 04:49:39 --> Total execution time: 0.0872
ERROR - 2022-03-10 04:49:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:49:40 --> Config Class Initialized
INFO - 2022-03-10 04:49:40 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:49:40 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:49:40 --> Utf8 Class Initialized
INFO - 2022-03-10 04:49:40 --> URI Class Initialized
INFO - 2022-03-10 04:49:40 --> Router Class Initialized
INFO - 2022-03-10 04:49:40 --> Output Class Initialized
INFO - 2022-03-10 04:49:40 --> Security Class Initialized
DEBUG - 2022-03-10 04:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:49:40 --> Input Class Initialized
INFO - 2022-03-10 04:49:40 --> Language Class Initialized
ERROR - 2022-03-10 04:49:40 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:49:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:49:55 --> Config Class Initialized
INFO - 2022-03-10 04:49:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:49:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:49:55 --> Utf8 Class Initialized
INFO - 2022-03-10 04:49:55 --> URI Class Initialized
INFO - 2022-03-10 04:49:55 --> Router Class Initialized
INFO - 2022-03-10 04:49:55 --> Output Class Initialized
INFO - 2022-03-10 04:49:55 --> Security Class Initialized
DEBUG - 2022-03-10 04:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:49:55 --> Input Class Initialized
INFO - 2022-03-10 04:49:55 --> Language Class Initialized
INFO - 2022-03-10 04:49:55 --> Loader Class Initialized
INFO - 2022-03-10 04:49:55 --> Helper loaded: url_helper
INFO - 2022-03-10 04:49:55 --> Helper loaded: form_helper
INFO - 2022-03-10 04:49:55 --> Helper loaded: common_helper
INFO - 2022-03-10 04:49:55 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:49:55 --> Controller Class Initialized
INFO - 2022-03-10 04:49:55 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:49:55 --> Encrypt Class Initialized
INFO - 2022-03-10 04:49:55 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:49:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:49:55 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:49:55 --> Model "Users_model" initialized
INFO - 2022-03-10 04:49:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:49:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:49:56 --> Config Class Initialized
INFO - 2022-03-10 04:49:56 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:49:56 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:49:56 --> Utf8 Class Initialized
INFO - 2022-03-10 04:49:56 --> URI Class Initialized
INFO - 2022-03-10 04:49:56 --> Router Class Initialized
INFO - 2022-03-10 04:49:56 --> Output Class Initialized
INFO - 2022-03-10 04:49:56 --> Security Class Initialized
DEBUG - 2022-03-10 04:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:49:56 --> Input Class Initialized
INFO - 2022-03-10 04:49:56 --> Language Class Initialized
INFO - 2022-03-10 04:49:56 --> Loader Class Initialized
INFO - 2022-03-10 04:49:56 --> Helper loaded: url_helper
INFO - 2022-03-10 04:49:56 --> Helper loaded: form_helper
INFO - 2022-03-10 04:49:56 --> Helper loaded: common_helper
INFO - 2022-03-10 04:49:56 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:49:56 --> Controller Class Initialized
INFO - 2022-03-10 04:49:56 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:49:56 --> Encrypt Class Initialized
INFO - 2022-03-10 04:49:56 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:49:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:49:56 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:49:56 --> Model "Users_model" initialized
INFO - 2022-03-10 04:49:56 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:49:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:49:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:49:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:49:56 --> Final output sent to browser
DEBUG - 2022-03-10 04:49:56 --> Total execution time: 0.0733
ERROR - 2022-03-10 04:49:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:49:57 --> Config Class Initialized
INFO - 2022-03-10 04:49:57 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:49:57 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:49:57 --> Utf8 Class Initialized
INFO - 2022-03-10 04:49:57 --> URI Class Initialized
INFO - 2022-03-10 04:49:57 --> Router Class Initialized
INFO - 2022-03-10 04:49:57 --> Output Class Initialized
INFO - 2022-03-10 04:49:57 --> Security Class Initialized
DEBUG - 2022-03-10 04:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:49:57 --> Input Class Initialized
INFO - 2022-03-10 04:49:57 --> Language Class Initialized
ERROR - 2022-03-10 04:49:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:51:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:51:50 --> Config Class Initialized
INFO - 2022-03-10 04:51:50 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:51:50 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:51:50 --> Utf8 Class Initialized
INFO - 2022-03-10 04:51:50 --> URI Class Initialized
INFO - 2022-03-10 04:51:50 --> Router Class Initialized
INFO - 2022-03-10 04:51:50 --> Output Class Initialized
INFO - 2022-03-10 04:51:50 --> Security Class Initialized
DEBUG - 2022-03-10 04:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:51:50 --> Input Class Initialized
INFO - 2022-03-10 04:51:50 --> Language Class Initialized
INFO - 2022-03-10 04:51:50 --> Loader Class Initialized
INFO - 2022-03-10 04:51:50 --> Helper loaded: url_helper
INFO - 2022-03-10 04:51:50 --> Helper loaded: form_helper
INFO - 2022-03-10 04:51:50 --> Helper loaded: common_helper
INFO - 2022-03-10 04:51:50 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:51:50 --> Controller Class Initialized
INFO - 2022-03-10 04:51:50 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:51:50 --> Encrypt Class Initialized
INFO - 2022-03-10 04:51:50 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:51:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:51:50 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:51:50 --> Model "Users_model" initialized
INFO - 2022-03-10 04:51:50 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:54:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:54:55 --> Config Class Initialized
INFO - 2022-03-10 04:54:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:54:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:54:55 --> Utf8 Class Initialized
INFO - 2022-03-10 04:54:55 --> URI Class Initialized
INFO - 2022-03-10 04:54:55 --> Router Class Initialized
INFO - 2022-03-10 04:54:55 --> Output Class Initialized
INFO - 2022-03-10 04:54:55 --> Security Class Initialized
DEBUG - 2022-03-10 04:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:54:55 --> Input Class Initialized
INFO - 2022-03-10 04:54:55 --> Language Class Initialized
INFO - 2022-03-10 04:54:55 --> Loader Class Initialized
INFO - 2022-03-10 04:54:55 --> Helper loaded: url_helper
INFO - 2022-03-10 04:54:55 --> Helper loaded: form_helper
INFO - 2022-03-10 04:54:55 --> Helper loaded: common_helper
INFO - 2022-03-10 04:54:55 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:54:55 --> Controller Class Initialized
INFO - 2022-03-10 04:54:55 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:54:55 --> Encrypt Class Initialized
INFO - 2022-03-10 04:54:55 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:54:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:54:55 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:54:55 --> Model "Users_model" initialized
INFO - 2022-03-10 04:54:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 04:54:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:54:55 --> Config Class Initialized
INFO - 2022-03-10 04:54:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:54:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:54:55 --> Utf8 Class Initialized
INFO - 2022-03-10 04:54:55 --> URI Class Initialized
INFO - 2022-03-10 04:54:55 --> Router Class Initialized
INFO - 2022-03-10 04:54:55 --> Output Class Initialized
INFO - 2022-03-10 04:54:55 --> Security Class Initialized
DEBUG - 2022-03-10 04:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:54:55 --> Input Class Initialized
INFO - 2022-03-10 04:54:55 --> Language Class Initialized
INFO - 2022-03-10 04:54:55 --> Loader Class Initialized
INFO - 2022-03-10 04:54:55 --> Helper loaded: url_helper
INFO - 2022-03-10 04:54:55 --> Helper loaded: form_helper
INFO - 2022-03-10 04:54:55 --> Helper loaded: common_helper
INFO - 2022-03-10 04:54:55 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:54:55 --> Controller Class Initialized
INFO - 2022-03-10 04:54:55 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:54:55 --> Encrypt Class Initialized
INFO - 2022-03-10 04:54:55 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:54:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:54:55 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:54:55 --> Model "Users_model" initialized
INFO - 2022-03-10 04:54:55 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:54:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:54:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:54:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:54:55 --> Final output sent to browser
DEBUG - 2022-03-10 04:54:55 --> Total execution time: 0.0602
ERROR - 2022-03-10 04:57:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:57:08 --> Config Class Initialized
INFO - 2022-03-10 04:57:08 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:57:08 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:57:08 --> Utf8 Class Initialized
INFO - 2022-03-10 04:57:08 --> URI Class Initialized
INFO - 2022-03-10 04:57:08 --> Router Class Initialized
INFO - 2022-03-10 04:57:08 --> Output Class Initialized
INFO - 2022-03-10 04:57:08 --> Security Class Initialized
DEBUG - 2022-03-10 04:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:57:08 --> Input Class Initialized
INFO - 2022-03-10 04:57:08 --> Language Class Initialized
INFO - 2022-03-10 04:57:08 --> Loader Class Initialized
INFO - 2022-03-10 04:57:08 --> Helper loaded: url_helper
INFO - 2022-03-10 04:57:08 --> Helper loaded: form_helper
INFO - 2022-03-10 04:57:08 --> Helper loaded: common_helper
INFO - 2022-03-10 04:57:08 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:57:08 --> Controller Class Initialized
INFO - 2022-03-10 04:57:08 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:57:08 --> Encrypt Class Initialized
INFO - 2022-03-10 04:57:08 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:57:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:57:08 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:57:08 --> Model "Users_model" initialized
INFO - 2022-03-10 04:57:08 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:57:09 --> Final output sent to browser
DEBUG - 2022-03-10 04:57:09 --> Total execution time: 0.5361
ERROR - 2022-03-10 04:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:57:32 --> Config Class Initialized
INFO - 2022-03-10 04:57:32 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:57:32 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:57:32 --> Utf8 Class Initialized
INFO - 2022-03-10 04:57:32 --> URI Class Initialized
INFO - 2022-03-10 04:57:32 --> Router Class Initialized
INFO - 2022-03-10 04:57:32 --> Output Class Initialized
INFO - 2022-03-10 04:57:32 --> Security Class Initialized
DEBUG - 2022-03-10 04:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:57:32 --> Input Class Initialized
INFO - 2022-03-10 04:57:32 --> Language Class Initialized
INFO - 2022-03-10 04:57:32 --> Loader Class Initialized
INFO - 2022-03-10 04:57:32 --> Helper loaded: url_helper
INFO - 2022-03-10 04:57:32 --> Helper loaded: form_helper
INFO - 2022-03-10 04:57:32 --> Helper loaded: common_helper
INFO - 2022-03-10 04:57:32 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:57:32 --> Controller Class Initialized
INFO - 2022-03-10 04:57:32 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:57:32 --> Encrypt Class Initialized
INFO - 2022-03-10 04:57:32 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:57:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:57:32 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:57:32 --> Model "Users_model" initialized
INFO - 2022-03-10 04:57:32 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:57:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 04:57:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 04:57:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 04:57:32 --> Final output sent to browser
DEBUG - 2022-03-10 04:57:32 --> Total execution time: 0.0798
ERROR - 2022-03-10 04:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:57:33 --> Config Class Initialized
INFO - 2022-03-10 04:57:33 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:57:33 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:57:33 --> Utf8 Class Initialized
INFO - 2022-03-10 04:57:33 --> URI Class Initialized
INFO - 2022-03-10 04:57:33 --> Router Class Initialized
INFO - 2022-03-10 04:57:33 --> Output Class Initialized
INFO - 2022-03-10 04:57:33 --> Security Class Initialized
DEBUG - 2022-03-10 04:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:57:33 --> Input Class Initialized
INFO - 2022-03-10 04:57:33 --> Language Class Initialized
ERROR - 2022-03-10 04:57:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 04:57:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:57:45 --> Config Class Initialized
INFO - 2022-03-10 04:57:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:57:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:57:45 --> Utf8 Class Initialized
INFO - 2022-03-10 04:57:45 --> URI Class Initialized
INFO - 2022-03-10 04:57:45 --> Router Class Initialized
INFO - 2022-03-10 04:57:45 --> Output Class Initialized
INFO - 2022-03-10 04:57:45 --> Security Class Initialized
DEBUG - 2022-03-10 04:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:57:45 --> Input Class Initialized
INFO - 2022-03-10 04:57:45 --> Language Class Initialized
ERROR - 2022-03-10 04:57:45 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 04:57:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 04:57:59 --> Config Class Initialized
INFO - 2022-03-10 04:57:59 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:57:59 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:57:59 --> Utf8 Class Initialized
INFO - 2022-03-10 04:57:59 --> URI Class Initialized
INFO - 2022-03-10 04:57:59 --> Router Class Initialized
INFO - 2022-03-10 04:57:59 --> Output Class Initialized
INFO - 2022-03-10 04:57:59 --> Security Class Initialized
DEBUG - 2022-03-10 04:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:57:59 --> Input Class Initialized
INFO - 2022-03-10 04:57:59 --> Language Class Initialized
INFO - 2022-03-10 04:57:59 --> Loader Class Initialized
INFO - 2022-03-10 04:57:59 --> Helper loaded: url_helper
INFO - 2022-03-10 04:57:59 --> Helper loaded: form_helper
INFO - 2022-03-10 04:57:59 --> Helper loaded: common_helper
INFO - 2022-03-10 04:57:59 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:57:59 --> Controller Class Initialized
INFO - 2022-03-10 04:57:59 --> Form Validation Class Initialized
DEBUG - 2022-03-10 04:57:59 --> Encrypt Class Initialized
INFO - 2022-03-10 04:57:59 --> Model "Patient_model" initialized
INFO - 2022-03-10 04:57:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 04:57:59 --> Model "Prefix_master" initialized
INFO - 2022-03-10 04:57:59 --> Model "Users_model" initialized
INFO - 2022-03-10 04:57:59 --> Model "Hospital_model" initialized
INFO - 2022-03-10 04:57:59 --> Final output sent to browser
DEBUG - 2022-03-10 04:57:59 --> Total execution time: 0.4061
ERROR - 2022-03-10 05:01:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:01:10 --> Config Class Initialized
INFO - 2022-03-10 05:01:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:01:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:01:10 --> Utf8 Class Initialized
INFO - 2022-03-10 05:01:10 --> URI Class Initialized
INFO - 2022-03-10 05:01:10 --> Router Class Initialized
INFO - 2022-03-10 05:01:10 --> Output Class Initialized
INFO - 2022-03-10 05:01:10 --> Security Class Initialized
DEBUG - 2022-03-10 05:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:01:10 --> Input Class Initialized
INFO - 2022-03-10 05:01:10 --> Language Class Initialized
INFO - 2022-03-10 05:01:10 --> Loader Class Initialized
INFO - 2022-03-10 05:01:10 --> Helper loaded: url_helper
INFO - 2022-03-10 05:01:10 --> Helper loaded: form_helper
INFO - 2022-03-10 05:01:10 --> Helper loaded: common_helper
INFO - 2022-03-10 05:01:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:01:10 --> Controller Class Initialized
INFO - 2022-03-10 05:01:10 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:01:10 --> Encrypt Class Initialized
INFO - 2022-03-10 05:01:10 --> Model "Login_model" initialized
INFO - 2022-03-10 05:01:10 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 05:01:10 --> Model "Case_model" initialized
INFO - 2022-03-10 05:01:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:01:35 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 05:01:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:01:35 --> Final output sent to browser
DEBUG - 2022-03-10 05:01:35 --> Total execution time: 24.3137
ERROR - 2022-03-10 05:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:01:36 --> Config Class Initialized
INFO - 2022-03-10 05:01:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:01:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:01:36 --> Utf8 Class Initialized
INFO - 2022-03-10 05:01:36 --> URI Class Initialized
INFO - 2022-03-10 05:01:36 --> Router Class Initialized
INFO - 2022-03-10 05:01:36 --> Output Class Initialized
INFO - 2022-03-10 05:01:36 --> Security Class Initialized
DEBUG - 2022-03-10 05:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:01:36 --> Input Class Initialized
INFO - 2022-03-10 05:01:36 --> Language Class Initialized
ERROR - 2022-03-10 05:01:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 05:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:03:36 --> Config Class Initialized
INFO - 2022-03-10 05:03:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:03:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:03:36 --> Utf8 Class Initialized
INFO - 2022-03-10 05:03:36 --> URI Class Initialized
INFO - 2022-03-10 05:03:36 --> Router Class Initialized
INFO - 2022-03-10 05:03:36 --> Output Class Initialized
INFO - 2022-03-10 05:03:36 --> Security Class Initialized
DEBUG - 2022-03-10 05:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:03:36 --> Input Class Initialized
INFO - 2022-03-10 05:03:36 --> Language Class Initialized
INFO - 2022-03-10 05:03:36 --> Loader Class Initialized
INFO - 2022-03-10 05:03:36 --> Helper loaded: url_helper
INFO - 2022-03-10 05:03:36 --> Helper loaded: form_helper
INFO - 2022-03-10 05:03:36 --> Helper loaded: common_helper
INFO - 2022-03-10 05:03:36 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:03:36 --> Controller Class Initialized
INFO - 2022-03-10 05:03:36 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:03:36 --> Encrypt Class Initialized
INFO - 2022-03-10 05:03:36 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:03:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:03:36 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:03:36 --> Model "Users_model" initialized
INFO - 2022-03-10 05:03:36 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:03:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:03:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 05:03:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:03:37 --> Final output sent to browser
DEBUG - 2022-03-10 05:03:37 --> Total execution time: 0.1424
ERROR - 2022-03-10 05:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:03:38 --> Config Class Initialized
INFO - 2022-03-10 05:03:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:03:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:03:38 --> Utf8 Class Initialized
INFO - 2022-03-10 05:03:38 --> URI Class Initialized
INFO - 2022-03-10 05:03:38 --> Router Class Initialized
INFO - 2022-03-10 05:03:38 --> Output Class Initialized
INFO - 2022-03-10 05:03:38 --> Security Class Initialized
DEBUG - 2022-03-10 05:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:03:38 --> Input Class Initialized
INFO - 2022-03-10 05:03:38 --> Language Class Initialized
ERROR - 2022-03-10 05:03:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 05:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:03:48 --> Config Class Initialized
INFO - 2022-03-10 05:03:48 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:03:48 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:03:48 --> Utf8 Class Initialized
INFO - 2022-03-10 05:03:48 --> URI Class Initialized
INFO - 2022-03-10 05:03:48 --> Router Class Initialized
INFO - 2022-03-10 05:03:48 --> Output Class Initialized
INFO - 2022-03-10 05:03:48 --> Security Class Initialized
DEBUG - 2022-03-10 05:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:03:48 --> Input Class Initialized
INFO - 2022-03-10 05:03:48 --> Language Class Initialized
ERROR - 2022-03-10 05:03:48 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 05:04:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:04:35 --> Config Class Initialized
INFO - 2022-03-10 05:04:35 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:04:35 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:04:35 --> Utf8 Class Initialized
INFO - 2022-03-10 05:04:35 --> URI Class Initialized
INFO - 2022-03-10 05:04:35 --> Router Class Initialized
INFO - 2022-03-10 05:04:35 --> Output Class Initialized
INFO - 2022-03-10 05:04:35 --> Security Class Initialized
DEBUG - 2022-03-10 05:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:04:35 --> Input Class Initialized
INFO - 2022-03-10 05:04:35 --> Language Class Initialized
ERROR - 2022-03-10 05:04:35 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 05:11:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:11:14 --> Config Class Initialized
INFO - 2022-03-10 05:11:14 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:11:14 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:11:14 --> Utf8 Class Initialized
INFO - 2022-03-10 05:11:14 --> URI Class Initialized
INFO - 2022-03-10 05:11:14 --> Router Class Initialized
INFO - 2022-03-10 05:11:14 --> Output Class Initialized
INFO - 2022-03-10 05:11:14 --> Security Class Initialized
DEBUG - 2022-03-10 05:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:11:14 --> Input Class Initialized
INFO - 2022-03-10 05:11:14 --> Language Class Initialized
ERROR - 2022-03-10 05:11:14 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 05:14:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:14:45 --> Config Class Initialized
INFO - 2022-03-10 05:14:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:14:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:14:45 --> Utf8 Class Initialized
INFO - 2022-03-10 05:14:45 --> URI Class Initialized
INFO - 2022-03-10 05:14:45 --> Router Class Initialized
INFO - 2022-03-10 05:14:45 --> Output Class Initialized
INFO - 2022-03-10 05:14:45 --> Security Class Initialized
DEBUG - 2022-03-10 05:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:14:45 --> Input Class Initialized
INFO - 2022-03-10 05:14:45 --> Language Class Initialized
INFO - 2022-03-10 05:14:45 --> Loader Class Initialized
INFO - 2022-03-10 05:14:45 --> Helper loaded: url_helper
INFO - 2022-03-10 05:14:45 --> Helper loaded: form_helper
INFO - 2022-03-10 05:14:45 --> Helper loaded: common_helper
INFO - 2022-03-10 05:14:45 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:14:45 --> Controller Class Initialized
INFO - 2022-03-10 05:14:45 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:14:45 --> Encrypt Class Initialized
INFO - 2022-03-10 05:14:45 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:14:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:14:45 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:14:45 --> Model "Users_model" initialized
INFO - 2022-03-10 05:14:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 05:14:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:14:46 --> Config Class Initialized
INFO - 2022-03-10 05:14:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:14:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:14:46 --> Utf8 Class Initialized
INFO - 2022-03-10 05:14:46 --> URI Class Initialized
INFO - 2022-03-10 05:14:46 --> Router Class Initialized
INFO - 2022-03-10 05:14:46 --> Output Class Initialized
INFO - 2022-03-10 05:14:46 --> Security Class Initialized
DEBUG - 2022-03-10 05:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:14:46 --> Input Class Initialized
INFO - 2022-03-10 05:14:46 --> Language Class Initialized
INFO - 2022-03-10 05:14:46 --> Loader Class Initialized
INFO - 2022-03-10 05:14:46 --> Helper loaded: url_helper
INFO - 2022-03-10 05:14:46 --> Helper loaded: form_helper
INFO - 2022-03-10 05:14:46 --> Helper loaded: common_helper
INFO - 2022-03-10 05:14:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:14:46 --> Controller Class Initialized
INFO - 2022-03-10 05:14:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:14:46 --> Encrypt Class Initialized
INFO - 2022-03-10 05:14:46 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:14:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:14:46 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:14:46 --> Model "Users_model" initialized
INFO - 2022-03-10 05:14:46 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:14:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:14:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 05:14:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:14:46 --> Final output sent to browser
DEBUG - 2022-03-10 05:14:46 --> Total execution time: 0.0649
ERROR - 2022-03-10 05:14:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:14:47 --> Config Class Initialized
INFO - 2022-03-10 05:14:47 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:14:47 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:14:47 --> Utf8 Class Initialized
INFO - 2022-03-10 05:14:47 --> URI Class Initialized
INFO - 2022-03-10 05:14:47 --> Router Class Initialized
INFO - 2022-03-10 05:14:47 --> Output Class Initialized
INFO - 2022-03-10 05:14:47 --> Security Class Initialized
DEBUG - 2022-03-10 05:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:14:47 --> Input Class Initialized
INFO - 2022-03-10 05:14:47 --> Language Class Initialized
ERROR - 2022-03-10 05:14:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 05:19:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:19:41 --> Config Class Initialized
INFO - 2022-03-10 05:19:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:19:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:19:41 --> Utf8 Class Initialized
INFO - 2022-03-10 05:19:41 --> URI Class Initialized
INFO - 2022-03-10 05:19:41 --> Router Class Initialized
INFO - 2022-03-10 05:19:41 --> Output Class Initialized
INFO - 2022-03-10 05:19:41 --> Security Class Initialized
DEBUG - 2022-03-10 05:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:19:41 --> Input Class Initialized
INFO - 2022-03-10 05:19:41 --> Language Class Initialized
ERROR - 2022-03-10 05:19:41 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 05:24:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:24:25 --> Config Class Initialized
INFO - 2022-03-10 05:24:25 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:24:25 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:24:25 --> Utf8 Class Initialized
INFO - 2022-03-10 05:24:25 --> URI Class Initialized
INFO - 2022-03-10 05:24:25 --> Router Class Initialized
INFO - 2022-03-10 05:24:25 --> Output Class Initialized
INFO - 2022-03-10 05:24:25 --> Security Class Initialized
DEBUG - 2022-03-10 05:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:24:25 --> Input Class Initialized
INFO - 2022-03-10 05:24:25 --> Language Class Initialized
INFO - 2022-03-10 05:24:25 --> Loader Class Initialized
INFO - 2022-03-10 05:24:25 --> Helper loaded: url_helper
INFO - 2022-03-10 05:24:25 --> Helper loaded: form_helper
INFO - 2022-03-10 05:24:25 --> Helper loaded: common_helper
INFO - 2022-03-10 05:24:25 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:24:25 --> Controller Class Initialized
INFO - 2022-03-10 05:24:25 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:24:25 --> Encrypt Class Initialized
INFO - 2022-03-10 05:24:25 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:24:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:24:25 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:24:25 --> Model "Users_model" initialized
INFO - 2022-03-10 05:24:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 05:24:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:24:25 --> Config Class Initialized
INFO - 2022-03-10 05:24:25 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:24:25 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:24:25 --> Utf8 Class Initialized
INFO - 2022-03-10 05:24:25 --> URI Class Initialized
INFO - 2022-03-10 05:24:25 --> Router Class Initialized
INFO - 2022-03-10 05:24:25 --> Output Class Initialized
INFO - 2022-03-10 05:24:25 --> Security Class Initialized
DEBUG - 2022-03-10 05:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:24:25 --> Input Class Initialized
INFO - 2022-03-10 05:24:25 --> Language Class Initialized
INFO - 2022-03-10 05:24:25 --> Loader Class Initialized
INFO - 2022-03-10 05:24:25 --> Helper loaded: url_helper
INFO - 2022-03-10 05:24:25 --> Helper loaded: form_helper
INFO - 2022-03-10 05:24:25 --> Helper loaded: common_helper
INFO - 2022-03-10 05:24:25 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:24:25 --> Controller Class Initialized
INFO - 2022-03-10 05:24:25 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:24:25 --> Encrypt Class Initialized
INFO - 2022-03-10 05:24:25 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:24:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:24:25 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:24:25 --> Model "Users_model" initialized
INFO - 2022-03-10 05:24:25 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:24:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:24:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 05:24:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:24:26 --> Final output sent to browser
DEBUG - 2022-03-10 05:24:26 --> Total execution time: 0.0813
ERROR - 2022-03-10 05:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:24:26 --> Config Class Initialized
INFO - 2022-03-10 05:24:26 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:24:26 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:24:26 --> Utf8 Class Initialized
INFO - 2022-03-10 05:24:26 --> URI Class Initialized
INFO - 2022-03-10 05:24:26 --> Router Class Initialized
INFO - 2022-03-10 05:24:26 --> Output Class Initialized
INFO - 2022-03-10 05:24:26 --> Security Class Initialized
DEBUG - 2022-03-10 05:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:24:26 --> Input Class Initialized
INFO - 2022-03-10 05:24:26 --> Language Class Initialized
ERROR - 2022-03-10 05:24:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 05:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:24:37 --> Config Class Initialized
INFO - 2022-03-10 05:24:37 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:24:37 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:24:37 --> Utf8 Class Initialized
INFO - 2022-03-10 05:24:37 --> URI Class Initialized
INFO - 2022-03-10 05:24:37 --> Router Class Initialized
INFO - 2022-03-10 05:24:37 --> Output Class Initialized
INFO - 2022-03-10 05:24:37 --> Security Class Initialized
DEBUG - 2022-03-10 05:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:24:37 --> Input Class Initialized
INFO - 2022-03-10 05:24:37 --> Language Class Initialized
INFO - 2022-03-10 05:24:37 --> Loader Class Initialized
INFO - 2022-03-10 05:24:37 --> Helper loaded: url_helper
INFO - 2022-03-10 05:24:37 --> Helper loaded: form_helper
INFO - 2022-03-10 05:24:37 --> Helper loaded: common_helper
INFO - 2022-03-10 05:24:37 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:24:37 --> Controller Class Initialized
INFO - 2022-03-10 05:24:37 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:24:37 --> Encrypt Class Initialized
INFO - 2022-03-10 05:24:37 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:24:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:24:37 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:24:37 --> Model "Users_model" initialized
INFO - 2022-03-10 05:24:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 05:24:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:24:38 --> Config Class Initialized
INFO - 2022-03-10 05:24:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:24:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:24:38 --> Utf8 Class Initialized
INFO - 2022-03-10 05:24:38 --> URI Class Initialized
INFO - 2022-03-10 05:24:38 --> Router Class Initialized
INFO - 2022-03-10 05:24:38 --> Output Class Initialized
INFO - 2022-03-10 05:24:38 --> Security Class Initialized
DEBUG - 2022-03-10 05:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:24:38 --> Input Class Initialized
INFO - 2022-03-10 05:24:38 --> Language Class Initialized
INFO - 2022-03-10 05:24:38 --> Loader Class Initialized
INFO - 2022-03-10 05:24:38 --> Helper loaded: url_helper
INFO - 2022-03-10 05:24:38 --> Helper loaded: form_helper
INFO - 2022-03-10 05:24:38 --> Helper loaded: common_helper
INFO - 2022-03-10 05:24:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:24:38 --> Controller Class Initialized
INFO - 2022-03-10 05:24:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:24:38 --> Encrypt Class Initialized
INFO - 2022-03-10 05:24:38 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:24:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:24:38 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:24:38 --> Model "Users_model" initialized
INFO - 2022-03-10 05:24:38 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:24:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:24:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 05:24:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:24:38 --> Final output sent to browser
DEBUG - 2022-03-10 05:24:38 --> Total execution time: 0.0726
ERROR - 2022-03-10 05:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:24:39 --> Config Class Initialized
INFO - 2022-03-10 05:24:39 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:24:39 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:24:39 --> Utf8 Class Initialized
INFO - 2022-03-10 05:24:39 --> URI Class Initialized
INFO - 2022-03-10 05:24:39 --> Router Class Initialized
INFO - 2022-03-10 05:24:39 --> Output Class Initialized
INFO - 2022-03-10 05:24:39 --> Security Class Initialized
DEBUG - 2022-03-10 05:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:24:39 --> Input Class Initialized
INFO - 2022-03-10 05:24:39 --> Language Class Initialized
ERROR - 2022-03-10 05:24:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 05:25:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:25:05 --> Config Class Initialized
INFO - 2022-03-10 05:25:05 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:25:05 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:25:05 --> Utf8 Class Initialized
INFO - 2022-03-10 05:25:05 --> URI Class Initialized
INFO - 2022-03-10 05:25:05 --> Router Class Initialized
INFO - 2022-03-10 05:25:05 --> Output Class Initialized
INFO - 2022-03-10 05:25:05 --> Security Class Initialized
DEBUG - 2022-03-10 05:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:25:05 --> Input Class Initialized
INFO - 2022-03-10 05:25:05 --> Language Class Initialized
INFO - 2022-03-10 05:25:05 --> Loader Class Initialized
INFO - 2022-03-10 05:25:05 --> Helper loaded: url_helper
INFO - 2022-03-10 05:25:05 --> Helper loaded: form_helper
INFO - 2022-03-10 05:25:05 --> Helper loaded: common_helper
INFO - 2022-03-10 05:25:05 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:25:05 --> Controller Class Initialized
INFO - 2022-03-10 05:25:05 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:25:05 --> Encrypt Class Initialized
INFO - 2022-03-10 05:25:05 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:25:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:25:05 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:25:05 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:25:05 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:25:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:25:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 05:25:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-10 05:25:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:25:14 --> Config Class Initialized
INFO - 2022-03-10 05:25:14 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:25:14 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:25:14 --> Utf8 Class Initialized
INFO - 2022-03-10 05:25:14 --> URI Class Initialized
INFO - 2022-03-10 05:25:14 --> Router Class Initialized
INFO - 2022-03-10 05:25:14 --> Output Class Initialized
INFO - 2022-03-10 05:25:14 --> Security Class Initialized
DEBUG - 2022-03-10 05:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:25:14 --> Input Class Initialized
INFO - 2022-03-10 05:25:14 --> Language Class Initialized
ERROR - 2022-03-10 05:25:14 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-10 05:25:29 --> Final output sent to browser
DEBUG - 2022-03-10 05:25:29 --> Total execution time: 7.0788
ERROR - 2022-03-10 05:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:32:03 --> Config Class Initialized
INFO - 2022-03-10 05:32:03 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:32:03 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:32:03 --> Utf8 Class Initialized
INFO - 2022-03-10 05:32:03 --> URI Class Initialized
INFO - 2022-03-10 05:32:03 --> Router Class Initialized
INFO - 2022-03-10 05:32:03 --> Output Class Initialized
INFO - 2022-03-10 05:32:03 --> Security Class Initialized
DEBUG - 2022-03-10 05:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:32:03 --> Input Class Initialized
INFO - 2022-03-10 05:32:03 --> Language Class Initialized
ERROR - 2022-03-10 05:32:03 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 05:45:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:45:03 --> Config Class Initialized
INFO - 2022-03-10 05:45:03 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:45:03 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:45:03 --> Utf8 Class Initialized
INFO - 2022-03-10 05:45:03 --> URI Class Initialized
DEBUG - 2022-03-10 05:45:03 --> No URI present. Default controller set.
INFO - 2022-03-10 05:45:03 --> Router Class Initialized
INFO - 2022-03-10 05:45:03 --> Output Class Initialized
INFO - 2022-03-10 05:45:03 --> Security Class Initialized
DEBUG - 2022-03-10 05:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:45:03 --> Input Class Initialized
INFO - 2022-03-10 05:45:03 --> Language Class Initialized
INFO - 2022-03-10 05:45:03 --> Loader Class Initialized
INFO - 2022-03-10 05:45:03 --> Helper loaded: url_helper
INFO - 2022-03-10 05:45:03 --> Helper loaded: form_helper
INFO - 2022-03-10 05:45:03 --> Helper loaded: common_helper
INFO - 2022-03-10 05:45:03 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:45:03 --> Controller Class Initialized
INFO - 2022-03-10 05:45:03 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:45:03 --> Encrypt Class Initialized
DEBUG - 2022-03-10 05:45:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 05:45:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 05:45:03 --> Email Class Initialized
INFO - 2022-03-10 05:45:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 05:45:03 --> Calendar Class Initialized
INFO - 2022-03-10 05:45:03 --> Model "Login_model" initialized
ERROR - 2022-03-10 05:45:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:45:04 --> Config Class Initialized
INFO - 2022-03-10 05:45:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:45:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:45:04 --> Utf8 Class Initialized
INFO - 2022-03-10 05:45:04 --> URI Class Initialized
INFO - 2022-03-10 05:45:04 --> Router Class Initialized
INFO - 2022-03-10 05:45:04 --> Output Class Initialized
INFO - 2022-03-10 05:45:04 --> Security Class Initialized
DEBUG - 2022-03-10 05:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:45:04 --> Input Class Initialized
INFO - 2022-03-10 05:45:04 --> Language Class Initialized
INFO - 2022-03-10 05:45:04 --> Loader Class Initialized
INFO - 2022-03-10 05:45:04 --> Helper loaded: url_helper
INFO - 2022-03-10 05:45:04 --> Helper loaded: form_helper
INFO - 2022-03-10 05:45:04 --> Helper loaded: common_helper
INFO - 2022-03-10 05:45:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:45:04 --> Controller Class Initialized
INFO - 2022-03-10 05:45:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:45:04 --> Encrypt Class Initialized
INFO - 2022-03-10 05:45:04 --> Model "Diseases_model" initialized
INFO - 2022-03-10 05:45:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:45:04 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-10 05:45:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:45:04 --> Final output sent to browser
DEBUG - 2022-03-10 05:45:04 --> Total execution time: 0.0264
ERROR - 2022-03-10 05:45:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:45:04 --> Config Class Initialized
INFO - 2022-03-10 05:45:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:45:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:45:04 --> Utf8 Class Initialized
INFO - 2022-03-10 05:45:04 --> URI Class Initialized
DEBUG - 2022-03-10 05:45:04 --> No URI present. Default controller set.
INFO - 2022-03-10 05:45:04 --> Router Class Initialized
INFO - 2022-03-10 05:45:04 --> Output Class Initialized
INFO - 2022-03-10 05:45:04 --> Security Class Initialized
DEBUG - 2022-03-10 05:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:45:04 --> Input Class Initialized
INFO - 2022-03-10 05:45:04 --> Language Class Initialized
INFO - 2022-03-10 05:45:04 --> Loader Class Initialized
INFO - 2022-03-10 05:45:04 --> Helper loaded: url_helper
INFO - 2022-03-10 05:45:04 --> Helper loaded: form_helper
INFO - 2022-03-10 05:45:04 --> Helper loaded: common_helper
INFO - 2022-03-10 05:45:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:45:04 --> Controller Class Initialized
INFO - 2022-03-10 05:45:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:45:04 --> Encrypt Class Initialized
DEBUG - 2022-03-10 05:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 05:45:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 05:45:04 --> Email Class Initialized
INFO - 2022-03-10 05:45:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 05:45:04 --> Calendar Class Initialized
INFO - 2022-03-10 05:45:04 --> Model "Login_model" initialized
ERROR - 2022-03-10 05:45:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:45:05 --> Config Class Initialized
INFO - 2022-03-10 05:45:05 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:45:05 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:45:05 --> Utf8 Class Initialized
INFO - 2022-03-10 05:45:05 --> URI Class Initialized
INFO - 2022-03-10 05:45:05 --> Router Class Initialized
INFO - 2022-03-10 05:45:05 --> Output Class Initialized
INFO - 2022-03-10 05:45:05 --> Security Class Initialized
DEBUG - 2022-03-10 05:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:45:05 --> Input Class Initialized
INFO - 2022-03-10 05:45:05 --> Language Class Initialized
INFO - 2022-03-10 05:45:05 --> Loader Class Initialized
INFO - 2022-03-10 05:45:05 --> Helper loaded: url_helper
INFO - 2022-03-10 05:45:05 --> Helper loaded: form_helper
INFO - 2022-03-10 05:45:05 --> Helper loaded: common_helper
INFO - 2022-03-10 05:45:05 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:45:05 --> Controller Class Initialized
INFO - 2022-03-10 05:45:05 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:45:05 --> Encrypt Class Initialized
INFO - 2022-03-10 05:45:05 --> Model "Diseases_model" initialized
INFO - 2022-03-10 05:45:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:45:05 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-10 05:45:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:45:05 --> Final output sent to browser
DEBUG - 2022-03-10 05:45:05 --> Total execution time: 0.0229
ERROR - 2022-03-10 05:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:45:12 --> Config Class Initialized
INFO - 2022-03-10 05:45:12 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:45:12 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:45:12 --> Utf8 Class Initialized
INFO - 2022-03-10 05:45:12 --> URI Class Initialized
INFO - 2022-03-10 05:45:12 --> Router Class Initialized
INFO - 2022-03-10 05:45:12 --> Output Class Initialized
INFO - 2022-03-10 05:45:12 --> Security Class Initialized
DEBUG - 2022-03-10 05:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:45:12 --> Input Class Initialized
INFO - 2022-03-10 05:45:12 --> Language Class Initialized
INFO - 2022-03-10 05:45:12 --> Loader Class Initialized
INFO - 2022-03-10 05:45:12 --> Helper loaded: url_helper
INFO - 2022-03-10 05:45:12 --> Helper loaded: form_helper
INFO - 2022-03-10 05:45:12 --> Helper loaded: common_helper
INFO - 2022-03-10 05:45:12 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:45:12 --> Controller Class Initialized
INFO - 2022-03-10 05:45:12 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:45:12 --> Encrypt Class Initialized
INFO - 2022-03-10 05:45:12 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:45:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:45:12 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:45:12 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:45:12 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:45:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:45:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 05:45:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:45:12 --> Final output sent to browser
DEBUG - 2022-03-10 05:45:12 --> Total execution time: 0.0347
ERROR - 2022-03-10 05:46:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:46:34 --> Config Class Initialized
INFO - 2022-03-10 05:46:34 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:46:34 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:46:34 --> Utf8 Class Initialized
INFO - 2022-03-10 05:46:34 --> URI Class Initialized
INFO - 2022-03-10 05:46:34 --> Router Class Initialized
INFO - 2022-03-10 05:46:34 --> Output Class Initialized
INFO - 2022-03-10 05:46:34 --> Security Class Initialized
DEBUG - 2022-03-10 05:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:46:34 --> Input Class Initialized
INFO - 2022-03-10 05:46:34 --> Language Class Initialized
INFO - 2022-03-10 05:46:34 --> Loader Class Initialized
INFO - 2022-03-10 05:46:34 --> Helper loaded: url_helper
INFO - 2022-03-10 05:46:34 --> Helper loaded: form_helper
INFO - 2022-03-10 05:46:34 --> Helper loaded: common_helper
INFO - 2022-03-10 05:46:34 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:46:34 --> Controller Class Initialized
INFO - 2022-03-10 05:46:34 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:46:34 --> Encrypt Class Initialized
INFO - 2022-03-10 05:46:34 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:46:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:46:34 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:46:34 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:46:34 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:46:34 --> Final output sent to browser
DEBUG - 2022-03-10 05:46:34 --> Total execution time: 0.0319
ERROR - 2022-03-10 05:50:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:50:00 --> Config Class Initialized
INFO - 2022-03-10 05:50:00 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:50:00 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:50:00 --> Utf8 Class Initialized
INFO - 2022-03-10 05:50:00 --> URI Class Initialized
INFO - 2022-03-10 05:50:00 --> Router Class Initialized
INFO - 2022-03-10 05:50:00 --> Output Class Initialized
INFO - 2022-03-10 05:50:00 --> Security Class Initialized
DEBUG - 2022-03-10 05:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:50:00 --> Input Class Initialized
INFO - 2022-03-10 05:50:00 --> Language Class Initialized
INFO - 2022-03-10 05:50:00 --> Loader Class Initialized
INFO - 2022-03-10 05:50:00 --> Helper loaded: url_helper
INFO - 2022-03-10 05:50:00 --> Helper loaded: form_helper
INFO - 2022-03-10 05:50:00 --> Helper loaded: common_helper
INFO - 2022-03-10 05:50:00 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:50:00 --> Controller Class Initialized
INFO - 2022-03-10 05:50:00 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:50:00 --> Final output sent to browser
DEBUG - 2022-03-10 05:50:00 --> Total execution time: 0.0275
ERROR - 2022-03-10 05:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:50:21 --> Config Class Initialized
INFO - 2022-03-10 05:50:21 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:50:21 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:50:21 --> Utf8 Class Initialized
INFO - 2022-03-10 05:50:21 --> URI Class Initialized
INFO - 2022-03-10 05:50:21 --> Router Class Initialized
INFO - 2022-03-10 05:50:21 --> Output Class Initialized
INFO - 2022-03-10 05:50:21 --> Security Class Initialized
DEBUG - 2022-03-10 05:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:50:21 --> Input Class Initialized
INFO - 2022-03-10 05:50:21 --> Language Class Initialized
INFO - 2022-03-10 05:50:21 --> Loader Class Initialized
INFO - 2022-03-10 05:50:21 --> Helper loaded: url_helper
INFO - 2022-03-10 05:50:21 --> Helper loaded: form_helper
INFO - 2022-03-10 05:50:21 --> Helper loaded: common_helper
INFO - 2022-03-10 05:50:21 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:50:21 --> Controller Class Initialized
INFO - 2022-03-10 05:50:21 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:50:21 --> Final output sent to browser
DEBUG - 2022-03-10 05:50:21 --> Total execution time: 0.0194
ERROR - 2022-03-10 05:51:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:51:27 --> Config Class Initialized
INFO - 2022-03-10 05:51:27 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:51:27 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:51:27 --> Utf8 Class Initialized
INFO - 2022-03-10 05:51:27 --> URI Class Initialized
INFO - 2022-03-10 05:51:27 --> Router Class Initialized
INFO - 2022-03-10 05:51:27 --> Output Class Initialized
INFO - 2022-03-10 05:51:27 --> Security Class Initialized
DEBUG - 2022-03-10 05:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:51:27 --> Input Class Initialized
INFO - 2022-03-10 05:51:27 --> Language Class Initialized
INFO - 2022-03-10 05:51:27 --> Loader Class Initialized
INFO - 2022-03-10 05:51:27 --> Helper loaded: url_helper
INFO - 2022-03-10 05:51:27 --> Helper loaded: form_helper
INFO - 2022-03-10 05:51:27 --> Helper loaded: common_helper
INFO - 2022-03-10 05:51:27 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:51:27 --> Controller Class Initialized
INFO - 2022-03-10 05:51:27 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:51:27 --> Encrypt Class Initialized
INFO - 2022-03-10 05:51:27 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:51:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:51:27 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:51:27 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:51:27 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:51:27 --> Final output sent to browser
DEBUG - 2022-03-10 05:51:27 --> Total execution time: 0.0353
ERROR - 2022-03-10 05:55:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:55:09 --> Config Class Initialized
INFO - 2022-03-10 05:55:09 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:55:09 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:55:09 --> Utf8 Class Initialized
INFO - 2022-03-10 05:55:09 --> URI Class Initialized
INFO - 2022-03-10 05:55:09 --> Router Class Initialized
INFO - 2022-03-10 05:55:09 --> Output Class Initialized
INFO - 2022-03-10 05:55:09 --> Security Class Initialized
DEBUG - 2022-03-10 05:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:55:09 --> Input Class Initialized
INFO - 2022-03-10 05:55:09 --> Language Class Initialized
INFO - 2022-03-10 05:55:09 --> Loader Class Initialized
INFO - 2022-03-10 05:55:09 --> Helper loaded: url_helper
INFO - 2022-03-10 05:55:09 --> Helper loaded: form_helper
INFO - 2022-03-10 05:55:09 --> Helper loaded: common_helper
INFO - 2022-03-10 05:55:09 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:55:09 --> Controller Class Initialized
INFO - 2022-03-10 05:55:09 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:55:09 --> Encrypt Class Initialized
INFO - 2022-03-10 05:55:09 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:55:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:55:09 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:55:09 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:55:09 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:55:09 --> Final output sent to browser
DEBUG - 2022-03-10 05:55:09 --> Total execution time: 0.0360
ERROR - 2022-03-10 05:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:55:23 --> Config Class Initialized
INFO - 2022-03-10 05:55:23 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:55:23 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:55:23 --> Utf8 Class Initialized
INFO - 2022-03-10 05:55:23 --> URI Class Initialized
INFO - 2022-03-10 05:55:23 --> Router Class Initialized
INFO - 2022-03-10 05:55:23 --> Output Class Initialized
INFO - 2022-03-10 05:55:23 --> Security Class Initialized
DEBUG - 2022-03-10 05:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:55:23 --> Input Class Initialized
INFO - 2022-03-10 05:55:23 --> Language Class Initialized
INFO - 2022-03-10 05:55:23 --> Loader Class Initialized
INFO - 2022-03-10 05:55:23 --> Helper loaded: url_helper
INFO - 2022-03-10 05:55:23 --> Helper loaded: form_helper
INFO - 2022-03-10 05:55:23 --> Helper loaded: common_helper
INFO - 2022-03-10 05:55:23 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:55:23 --> Controller Class Initialized
INFO - 2022-03-10 05:55:23 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:55:23 --> Encrypt Class Initialized
INFO - 2022-03-10 05:55:23 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:55:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:55:23 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:55:23 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:55:23 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:55:23 --> Final output sent to browser
DEBUG - 2022-03-10 05:55:23 --> Total execution time: 0.0376
ERROR - 2022-03-10 05:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:55:23 --> Config Class Initialized
INFO - 2022-03-10 05:55:23 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:55:23 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:55:23 --> Utf8 Class Initialized
INFO - 2022-03-10 05:55:23 --> URI Class Initialized
INFO - 2022-03-10 05:55:23 --> Router Class Initialized
INFO - 2022-03-10 05:55:23 --> Output Class Initialized
INFO - 2022-03-10 05:55:23 --> Security Class Initialized
DEBUG - 2022-03-10 05:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:55:23 --> Input Class Initialized
INFO - 2022-03-10 05:55:23 --> Language Class Initialized
INFO - 2022-03-10 05:55:23 --> Loader Class Initialized
INFO - 2022-03-10 05:55:23 --> Helper loaded: url_helper
INFO - 2022-03-10 05:55:23 --> Helper loaded: form_helper
INFO - 2022-03-10 05:55:23 --> Helper loaded: common_helper
INFO - 2022-03-10 05:55:24 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:55:24 --> Controller Class Initialized
INFO - 2022-03-10 05:55:24 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:55:24 --> Encrypt Class Initialized
INFO - 2022-03-10 05:55:24 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:55:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:55:24 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:55:24 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:55:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 05:55:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:55:24 --> Config Class Initialized
INFO - 2022-03-10 05:55:24 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:55:24 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:55:24 --> Utf8 Class Initialized
INFO - 2022-03-10 05:55:24 --> URI Class Initialized
INFO - 2022-03-10 05:55:24 --> Router Class Initialized
INFO - 2022-03-10 05:55:24 --> Output Class Initialized
INFO - 2022-03-10 05:55:24 --> Security Class Initialized
DEBUG - 2022-03-10 05:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:55:24 --> Input Class Initialized
INFO - 2022-03-10 05:55:24 --> Language Class Initialized
INFO - 2022-03-10 05:55:24 --> Loader Class Initialized
INFO - 2022-03-10 05:55:24 --> Helper loaded: url_helper
INFO - 2022-03-10 05:55:24 --> Helper loaded: form_helper
INFO - 2022-03-10 05:55:24 --> Helper loaded: common_helper
INFO - 2022-03-10 05:55:24 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:55:24 --> Controller Class Initialized
INFO - 2022-03-10 05:55:24 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:55:24 --> Encrypt Class Initialized
INFO - 2022-03-10 05:55:24 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:55:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:55:24 --> Model "Referredby_model" initialized
INFO - 2022-03-10 05:55:24 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:55:24 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:55:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:55:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 05:55:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:55:24 --> Final output sent to browser
DEBUG - 2022-03-10 05:55:24 --> Total execution time: 0.0715
ERROR - 2022-03-10 05:55:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 05:55:25 --> Config Class Initialized
INFO - 2022-03-10 05:55:25 --> Hooks Class Initialized
DEBUG - 2022-03-10 05:55:25 --> UTF-8 Support Enabled
INFO - 2022-03-10 05:55:25 --> Utf8 Class Initialized
INFO - 2022-03-10 05:55:25 --> URI Class Initialized
INFO - 2022-03-10 05:55:25 --> Router Class Initialized
INFO - 2022-03-10 05:55:25 --> Output Class Initialized
INFO - 2022-03-10 05:55:25 --> Security Class Initialized
DEBUG - 2022-03-10 05:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 05:55:25 --> Input Class Initialized
INFO - 2022-03-10 05:55:25 --> Language Class Initialized
INFO - 2022-03-10 05:55:25 --> Loader Class Initialized
INFO - 2022-03-10 05:55:25 --> Helper loaded: url_helper
INFO - 2022-03-10 05:55:25 --> Helper loaded: form_helper
INFO - 2022-03-10 05:55:25 --> Helper loaded: common_helper
INFO - 2022-03-10 05:55:25 --> Database Driver Class Initialized
DEBUG - 2022-03-10 05:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 05:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 05:55:25 --> Controller Class Initialized
INFO - 2022-03-10 05:55:25 --> Form Validation Class Initialized
DEBUG - 2022-03-10 05:55:25 --> Encrypt Class Initialized
INFO - 2022-03-10 05:55:25 --> Model "Patient_model" initialized
INFO - 2022-03-10 05:55:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 05:55:25 --> Model "Prefix_master" initialized
INFO - 2022-03-10 05:55:25 --> Model "Users_model" initialized
INFO - 2022-03-10 05:55:25 --> Model "Hospital_model" initialized
INFO - 2022-03-10 05:55:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 05:55:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 05:55:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 05:55:25 --> Final output sent to browser
DEBUG - 2022-03-10 05:55:25 --> Total execution time: 0.1166
ERROR - 2022-03-10 06:03:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:03:24 --> Config Class Initialized
INFO - 2022-03-10 06:03:24 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:03:24 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:03:24 --> Utf8 Class Initialized
INFO - 2022-03-10 06:03:24 --> URI Class Initialized
INFO - 2022-03-10 06:03:24 --> Router Class Initialized
INFO - 2022-03-10 06:03:24 --> Output Class Initialized
INFO - 2022-03-10 06:03:24 --> Security Class Initialized
DEBUG - 2022-03-10 06:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:03:24 --> Input Class Initialized
INFO - 2022-03-10 06:03:24 --> Language Class Initialized
INFO - 2022-03-10 06:03:24 --> Loader Class Initialized
INFO - 2022-03-10 06:03:24 --> Helper loaded: url_helper
INFO - 2022-03-10 06:03:24 --> Helper loaded: form_helper
INFO - 2022-03-10 06:03:24 --> Helper loaded: common_helper
INFO - 2022-03-10 06:03:24 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:03:24 --> Controller Class Initialized
INFO - 2022-03-10 06:03:24 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:03:24 --> Encrypt Class Initialized
INFO - 2022-03-10 06:03:24 --> Model "Patient_model" initialized
INFO - 2022-03-10 06:03:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 06:03:24 --> Model "Prefix_master" initialized
INFO - 2022-03-10 06:03:24 --> Model "Users_model" initialized
INFO - 2022-03-10 06:03:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 06:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:03:25 --> Config Class Initialized
INFO - 2022-03-10 06:03:25 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:03:25 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:03:25 --> Utf8 Class Initialized
INFO - 2022-03-10 06:03:25 --> URI Class Initialized
INFO - 2022-03-10 06:03:25 --> Router Class Initialized
INFO - 2022-03-10 06:03:25 --> Output Class Initialized
INFO - 2022-03-10 06:03:25 --> Security Class Initialized
DEBUG - 2022-03-10 06:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:03:25 --> Input Class Initialized
INFO - 2022-03-10 06:03:25 --> Language Class Initialized
INFO - 2022-03-10 06:03:25 --> Loader Class Initialized
INFO - 2022-03-10 06:03:25 --> Helper loaded: url_helper
INFO - 2022-03-10 06:03:25 --> Helper loaded: form_helper
INFO - 2022-03-10 06:03:25 --> Helper loaded: common_helper
INFO - 2022-03-10 06:03:25 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:03:25 --> Controller Class Initialized
INFO - 2022-03-10 06:03:25 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:03:25 --> Encrypt Class Initialized
INFO - 2022-03-10 06:03:25 --> Model "Patient_model" initialized
INFO - 2022-03-10 06:03:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 06:03:25 --> Model "Prefix_master" initialized
INFO - 2022-03-10 06:03:25 --> Model "Users_model" initialized
INFO - 2022-03-10 06:03:25 --> Model "Hospital_model" initialized
INFO - 2022-03-10 06:03:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 06:03:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 06:03:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 06:03:25 --> Final output sent to browser
DEBUG - 2022-03-10 06:03:25 --> Total execution time: 0.0962
ERROR - 2022-03-10 06:06:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:06:09 --> Config Class Initialized
INFO - 2022-03-10 06:06:09 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:06:09 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:06:09 --> Utf8 Class Initialized
INFO - 2022-03-10 06:06:09 --> URI Class Initialized
INFO - 2022-03-10 06:06:09 --> Router Class Initialized
INFO - 2022-03-10 06:06:09 --> Output Class Initialized
INFO - 2022-03-10 06:06:09 --> Security Class Initialized
DEBUG - 2022-03-10 06:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:06:09 --> Input Class Initialized
INFO - 2022-03-10 06:06:09 --> Language Class Initialized
INFO - 2022-03-10 06:06:09 --> Loader Class Initialized
INFO - 2022-03-10 06:06:09 --> Helper loaded: url_helper
INFO - 2022-03-10 06:06:09 --> Helper loaded: form_helper
INFO - 2022-03-10 06:06:09 --> Helper loaded: common_helper
INFO - 2022-03-10 06:06:09 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:06:09 --> Controller Class Initialized
INFO - 2022-03-10 06:06:09 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:06:09 --> Encrypt Class Initialized
INFO - 2022-03-10 06:06:09 --> Model "Patient_model" initialized
INFO - 2022-03-10 06:06:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 06:06:09 --> Model "Prefix_master" initialized
INFO - 2022-03-10 06:06:09 --> Model "Users_model" initialized
INFO - 2022-03-10 06:06:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 06:06:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:06:10 --> Config Class Initialized
INFO - 2022-03-10 06:06:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:06:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:06:10 --> Utf8 Class Initialized
INFO - 2022-03-10 06:06:10 --> URI Class Initialized
INFO - 2022-03-10 06:06:10 --> Router Class Initialized
INFO - 2022-03-10 06:06:10 --> Output Class Initialized
INFO - 2022-03-10 06:06:10 --> Security Class Initialized
DEBUG - 2022-03-10 06:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:06:10 --> Input Class Initialized
INFO - 2022-03-10 06:06:10 --> Language Class Initialized
INFO - 2022-03-10 06:06:10 --> Loader Class Initialized
INFO - 2022-03-10 06:06:10 --> Helper loaded: url_helper
INFO - 2022-03-10 06:06:10 --> Helper loaded: form_helper
INFO - 2022-03-10 06:06:10 --> Helper loaded: common_helper
INFO - 2022-03-10 06:06:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:06:10 --> Controller Class Initialized
INFO - 2022-03-10 06:06:10 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:06:10 --> Encrypt Class Initialized
INFO - 2022-03-10 06:06:10 --> Model "Patient_model" initialized
INFO - 2022-03-10 06:06:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 06:06:10 --> Model "Prefix_master" initialized
INFO - 2022-03-10 06:06:10 --> Model "Users_model" initialized
INFO - 2022-03-10 06:06:10 --> Model "Hospital_model" initialized
INFO - 2022-03-10 06:06:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 06:06:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 06:06:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 06:06:10 --> Final output sent to browser
DEBUG - 2022-03-10 06:06:10 --> Total execution time: 0.0853
ERROR - 2022-03-10 06:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:06:43 --> Config Class Initialized
INFO - 2022-03-10 06:06:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:06:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:06:43 --> Utf8 Class Initialized
INFO - 2022-03-10 06:06:43 --> URI Class Initialized
INFO - 2022-03-10 06:06:43 --> Router Class Initialized
INFO - 2022-03-10 06:06:43 --> Output Class Initialized
INFO - 2022-03-10 06:06:43 --> Security Class Initialized
DEBUG - 2022-03-10 06:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:06:43 --> Input Class Initialized
INFO - 2022-03-10 06:06:43 --> Language Class Initialized
INFO - 2022-03-10 06:06:43 --> Loader Class Initialized
INFO - 2022-03-10 06:06:43 --> Helper loaded: url_helper
INFO - 2022-03-10 06:06:43 --> Helper loaded: form_helper
INFO - 2022-03-10 06:06:43 --> Helper loaded: common_helper
INFO - 2022-03-10 06:06:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:06:43 --> Controller Class Initialized
INFO - 2022-03-10 06:06:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:06:43 --> Encrypt Class Initialized
INFO - 2022-03-10 06:06:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 06:06:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 06:06:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 06:06:43 --> Model "Users_model" initialized
INFO - 2022-03-10 06:06:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 06:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:06:43 --> Config Class Initialized
INFO - 2022-03-10 06:06:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:06:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:06:43 --> Utf8 Class Initialized
INFO - 2022-03-10 06:06:43 --> URI Class Initialized
INFO - 2022-03-10 06:06:43 --> Router Class Initialized
INFO - 2022-03-10 06:06:43 --> Output Class Initialized
INFO - 2022-03-10 06:06:43 --> Security Class Initialized
DEBUG - 2022-03-10 06:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:06:43 --> Input Class Initialized
INFO - 2022-03-10 06:06:43 --> Language Class Initialized
INFO - 2022-03-10 06:06:43 --> Loader Class Initialized
INFO - 2022-03-10 06:06:43 --> Helper loaded: url_helper
INFO - 2022-03-10 06:06:43 --> Helper loaded: form_helper
INFO - 2022-03-10 06:06:43 --> Helper loaded: common_helper
INFO - 2022-03-10 06:06:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:06:43 --> Controller Class Initialized
INFO - 2022-03-10 06:06:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:06:43 --> Encrypt Class Initialized
INFO - 2022-03-10 06:06:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 06:06:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 06:06:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 06:06:43 --> Model "Users_model" initialized
INFO - 2022-03-10 06:06:43 --> Model "Hospital_model" initialized
INFO - 2022-03-10 06:06:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 06:06:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 06:06:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 06:06:44 --> Final output sent to browser
DEBUG - 2022-03-10 06:06:44 --> Total execution time: 0.0874
ERROR - 2022-03-10 06:11:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:11:43 --> Config Class Initialized
INFO - 2022-03-10 06:11:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:11:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:11:43 --> Utf8 Class Initialized
INFO - 2022-03-10 06:11:43 --> URI Class Initialized
INFO - 2022-03-10 06:11:43 --> Router Class Initialized
INFO - 2022-03-10 06:11:43 --> Output Class Initialized
INFO - 2022-03-10 06:11:43 --> Security Class Initialized
DEBUG - 2022-03-10 06:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:11:43 --> Input Class Initialized
INFO - 2022-03-10 06:11:43 --> Language Class Initialized
INFO - 2022-03-10 06:11:43 --> Loader Class Initialized
INFO - 2022-03-10 06:11:43 --> Helper loaded: url_helper
INFO - 2022-03-10 06:11:43 --> Helper loaded: form_helper
INFO - 2022-03-10 06:11:43 --> Helper loaded: common_helper
INFO - 2022-03-10 06:11:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:11:43 --> Controller Class Initialized
INFO - 2022-03-10 06:11:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:11:43 --> Encrypt Class Initialized
DEBUG - 2022-03-10 06:11:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 06:11:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 06:11:43 --> Email Class Initialized
INFO - 2022-03-10 06:11:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 06:11:43 --> Calendar Class Initialized
INFO - 2022-03-10 06:11:43 --> Model "Login_model" initialized
ERROR - 2022-03-10 06:11:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:11:43 --> Config Class Initialized
INFO - 2022-03-10 06:11:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:11:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:11:43 --> Utf8 Class Initialized
INFO - 2022-03-10 06:11:43 --> URI Class Initialized
INFO - 2022-03-10 06:11:43 --> Router Class Initialized
INFO - 2022-03-10 06:11:43 --> Output Class Initialized
INFO - 2022-03-10 06:11:43 --> Security Class Initialized
DEBUG - 2022-03-10 06:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:11:43 --> Input Class Initialized
INFO - 2022-03-10 06:11:43 --> Language Class Initialized
INFO - 2022-03-10 06:11:43 --> Loader Class Initialized
INFO - 2022-03-10 06:11:43 --> Helper loaded: url_helper
INFO - 2022-03-10 06:11:43 --> Helper loaded: form_helper
INFO - 2022-03-10 06:11:43 --> Helper loaded: common_helper
INFO - 2022-03-10 06:11:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:11:43 --> Controller Class Initialized
INFO - 2022-03-10 06:11:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:11:43 --> Encrypt Class Initialized
DEBUG - 2022-03-10 06:11:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 06:11:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 06:11:43 --> Email Class Initialized
INFO - 2022-03-10 06:11:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 06:11:43 --> Calendar Class Initialized
INFO - 2022-03-10 06:11:43 --> Model "Login_model" initialized
INFO - 2022-03-10 06:11:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 06:11:43 --> Final output sent to browser
DEBUG - 2022-03-10 06:11:43 --> Total execution time: 0.0254
ERROR - 2022-03-10 06:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:11:45 --> Config Class Initialized
INFO - 2022-03-10 06:11:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:11:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:11:45 --> Utf8 Class Initialized
INFO - 2022-03-10 06:11:45 --> URI Class Initialized
INFO - 2022-03-10 06:11:45 --> Router Class Initialized
INFO - 2022-03-10 06:11:45 --> Output Class Initialized
INFO - 2022-03-10 06:11:45 --> Security Class Initialized
DEBUG - 2022-03-10 06:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:11:45 --> Input Class Initialized
INFO - 2022-03-10 06:11:45 --> Language Class Initialized
INFO - 2022-03-10 06:11:45 --> Loader Class Initialized
INFO - 2022-03-10 06:11:46 --> Helper loaded: url_helper
INFO - 2022-03-10 06:11:46 --> Helper loaded: form_helper
INFO - 2022-03-10 06:11:46 --> Helper loaded: common_helper
INFO - 2022-03-10 06:11:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:11:46 --> Controller Class Initialized
INFO - 2022-03-10 06:11:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:11:46 --> Encrypt Class Initialized
DEBUG - 2022-03-10 06:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 06:11:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 06:11:46 --> Email Class Initialized
INFO - 2022-03-10 06:11:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 06:11:46 --> Calendar Class Initialized
INFO - 2022-03-10 06:11:46 --> Model "Login_model" initialized
ERROR - 2022-03-10 06:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:11:46 --> Config Class Initialized
INFO - 2022-03-10 06:11:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:11:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:11:46 --> Utf8 Class Initialized
INFO - 2022-03-10 06:11:46 --> URI Class Initialized
INFO - 2022-03-10 06:11:46 --> Router Class Initialized
INFO - 2022-03-10 06:11:46 --> Output Class Initialized
INFO - 2022-03-10 06:11:46 --> Security Class Initialized
DEBUG - 2022-03-10 06:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:11:46 --> Input Class Initialized
INFO - 2022-03-10 06:11:46 --> Language Class Initialized
INFO - 2022-03-10 06:11:46 --> Loader Class Initialized
INFO - 2022-03-10 06:11:46 --> Helper loaded: url_helper
INFO - 2022-03-10 06:11:46 --> Helper loaded: form_helper
INFO - 2022-03-10 06:11:46 --> Helper loaded: common_helper
INFO - 2022-03-10 06:11:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:11:46 --> Controller Class Initialized
INFO - 2022-03-10 06:11:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:11:46 --> Encrypt Class Initialized
DEBUG - 2022-03-10 06:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 06:11:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 06:11:46 --> Email Class Initialized
INFO - 2022-03-10 06:11:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 06:11:46 --> Calendar Class Initialized
INFO - 2022-03-10 06:11:46 --> Model "Login_model" initialized
INFO - 2022-03-10 06:11:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 06:11:46 --> Final output sent to browser
DEBUG - 2022-03-10 06:11:46 --> Total execution time: 0.0308
ERROR - 2022-03-10 06:24:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:24:31 --> Config Class Initialized
INFO - 2022-03-10 06:24:31 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:24:31 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:24:31 --> Utf8 Class Initialized
INFO - 2022-03-10 06:24:31 --> URI Class Initialized
INFO - 2022-03-10 06:24:31 --> Router Class Initialized
INFO - 2022-03-10 06:24:31 --> Output Class Initialized
INFO - 2022-03-10 06:24:31 --> Security Class Initialized
DEBUG - 2022-03-10 06:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:24:31 --> Input Class Initialized
INFO - 2022-03-10 06:24:31 --> Language Class Initialized
INFO - 2022-03-10 06:24:31 --> Loader Class Initialized
INFO - 2022-03-10 06:24:31 --> Helper loaded: url_helper
INFO - 2022-03-10 06:24:31 --> Helper loaded: form_helper
INFO - 2022-03-10 06:24:31 --> Helper loaded: common_helper
INFO - 2022-03-10 06:24:31 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:24:31 --> Controller Class Initialized
INFO - 2022-03-10 06:24:31 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:24:31 --> Encrypt Class Initialized
INFO - 2022-03-10 06:24:31 --> Model "Patient_model" initialized
INFO - 2022-03-10 06:24:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 06:24:31 --> Model "Prefix_master" initialized
INFO - 2022-03-10 06:24:31 --> Model "Users_model" initialized
INFO - 2022-03-10 06:24:31 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 06:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:24:32 --> Config Class Initialized
INFO - 2022-03-10 06:24:32 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:24:32 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:24:32 --> Utf8 Class Initialized
INFO - 2022-03-10 06:24:32 --> URI Class Initialized
INFO - 2022-03-10 06:24:32 --> Router Class Initialized
INFO - 2022-03-10 06:24:32 --> Output Class Initialized
INFO - 2022-03-10 06:24:32 --> Security Class Initialized
DEBUG - 2022-03-10 06:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:24:32 --> Input Class Initialized
INFO - 2022-03-10 06:24:32 --> Language Class Initialized
INFO - 2022-03-10 06:24:32 --> Loader Class Initialized
INFO - 2022-03-10 06:24:32 --> Helper loaded: url_helper
INFO - 2022-03-10 06:24:32 --> Helper loaded: form_helper
INFO - 2022-03-10 06:24:32 --> Helper loaded: common_helper
INFO - 2022-03-10 06:24:32 --> Database Driver Class Initialized
DEBUG - 2022-03-10 06:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 06:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 06:24:32 --> Controller Class Initialized
INFO - 2022-03-10 06:24:32 --> Form Validation Class Initialized
DEBUG - 2022-03-10 06:24:32 --> Encrypt Class Initialized
INFO - 2022-03-10 06:24:32 --> Model "Patient_model" initialized
INFO - 2022-03-10 06:24:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 06:24:32 --> Model "Prefix_master" initialized
INFO - 2022-03-10 06:24:32 --> Model "Users_model" initialized
INFO - 2022-03-10 06:24:32 --> Model "Hospital_model" initialized
INFO - 2022-03-10 06:24:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 06:24:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 06:24:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 06:24:32 --> Final output sent to browser
DEBUG - 2022-03-10 06:24:32 --> Total execution time: 0.0833
ERROR - 2022-03-10 06:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:27:58 --> Config Class Initialized
INFO - 2022-03-10 06:27:58 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:27:58 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:27:58 --> Utf8 Class Initialized
INFO - 2022-03-10 06:27:58 --> URI Class Initialized
INFO - 2022-03-10 06:27:58 --> Router Class Initialized
INFO - 2022-03-10 06:27:58 --> Output Class Initialized
INFO - 2022-03-10 06:27:58 --> Security Class Initialized
DEBUG - 2022-03-10 06:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:27:58 --> Input Class Initialized
INFO - 2022-03-10 06:27:58 --> Language Class Initialized
ERROR - 2022-03-10 06:27:58 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 06:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:49:52 --> Config Class Initialized
INFO - 2022-03-10 06:49:52 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:49:52 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:49:52 --> Utf8 Class Initialized
INFO - 2022-03-10 06:49:52 --> URI Class Initialized
INFO - 2022-03-10 06:49:52 --> Router Class Initialized
INFO - 2022-03-10 06:49:52 --> Output Class Initialized
INFO - 2022-03-10 06:49:52 --> Security Class Initialized
DEBUG - 2022-03-10 06:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:49:52 --> Input Class Initialized
INFO - 2022-03-10 06:49:52 --> Language Class Initialized
ERROR - 2022-03-10 06:49:52 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 06:54:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 06:54:50 --> Config Class Initialized
INFO - 2022-03-10 06:54:50 --> Hooks Class Initialized
DEBUG - 2022-03-10 06:54:50 --> UTF-8 Support Enabled
INFO - 2022-03-10 06:54:50 --> Utf8 Class Initialized
INFO - 2022-03-10 06:54:50 --> URI Class Initialized
INFO - 2022-03-10 06:54:50 --> Router Class Initialized
INFO - 2022-03-10 06:54:50 --> Output Class Initialized
INFO - 2022-03-10 06:54:50 --> Security Class Initialized
DEBUG - 2022-03-10 06:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 06:54:50 --> Input Class Initialized
INFO - 2022-03-10 06:54:50 --> Language Class Initialized
ERROR - 2022-03-10 06:54:50 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 08:29:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 08:29:54 --> Config Class Initialized
INFO - 2022-03-10 08:29:54 --> Hooks Class Initialized
DEBUG - 2022-03-10 08:29:54 --> UTF-8 Support Enabled
INFO - 2022-03-10 08:29:54 --> Utf8 Class Initialized
INFO - 2022-03-10 08:29:54 --> URI Class Initialized
INFO - 2022-03-10 08:29:54 --> Router Class Initialized
INFO - 2022-03-10 08:29:54 --> Output Class Initialized
INFO - 2022-03-10 08:29:54 --> Security Class Initialized
DEBUG - 2022-03-10 08:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 08:29:54 --> Input Class Initialized
INFO - 2022-03-10 08:29:54 --> Language Class Initialized
ERROR - 2022-03-10 08:29:54 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 08:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 08:45:19 --> Config Class Initialized
INFO - 2022-03-10 08:45:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 08:45:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 08:45:19 --> Utf8 Class Initialized
INFO - 2022-03-10 08:45:19 --> URI Class Initialized
INFO - 2022-03-10 08:45:19 --> Router Class Initialized
INFO - 2022-03-10 08:45:19 --> Output Class Initialized
INFO - 2022-03-10 08:45:19 --> Security Class Initialized
DEBUG - 2022-03-10 08:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 08:45:19 --> Input Class Initialized
INFO - 2022-03-10 08:45:19 --> Language Class Initialized
ERROR - 2022-03-10 08:45:19 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 10:09:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:09:18 --> Config Class Initialized
INFO - 2022-03-10 10:09:18 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:09:18 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:09:18 --> Utf8 Class Initialized
INFO - 2022-03-10 10:09:18 --> URI Class Initialized
INFO - 2022-03-10 10:09:18 --> Router Class Initialized
INFO - 2022-03-10 10:09:18 --> Output Class Initialized
INFO - 2022-03-10 10:09:18 --> Security Class Initialized
DEBUG - 2022-03-10 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:09:18 --> Input Class Initialized
INFO - 2022-03-10 10:09:18 --> Language Class Initialized
ERROR - 2022-03-10 10:09:18 --> 404 Page Not Found: Wp-admin/includes
ERROR - 2022-03-10 10:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:09:24 --> Config Class Initialized
INFO - 2022-03-10 10:09:24 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:09:24 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:09:24 --> Utf8 Class Initialized
INFO - 2022-03-10 10:09:24 --> URI Class Initialized
INFO - 2022-03-10 10:09:24 --> Router Class Initialized
INFO - 2022-03-10 10:09:24 --> Output Class Initialized
INFO - 2022-03-10 10:09:24 --> Security Class Initialized
DEBUG - 2022-03-10 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:09:24 --> Input Class Initialized
INFO - 2022-03-10 10:09:24 --> Language Class Initialized
ERROR - 2022-03-10 10:09:24 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2022-03-10 10:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:09:36 --> Config Class Initialized
INFO - 2022-03-10 10:09:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:09:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:09:36 --> Utf8 Class Initialized
INFO - 2022-03-10 10:09:36 --> URI Class Initialized
INFO - 2022-03-10 10:09:36 --> Router Class Initialized
INFO - 2022-03-10 10:09:36 --> Output Class Initialized
INFO - 2022-03-10 10:09:36 --> Security Class Initialized
DEBUG - 2022-03-10 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:09:36 --> Input Class Initialized
INFO - 2022-03-10 10:09:36 --> Language Class Initialized
ERROR - 2022-03-10 10:09:36 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2022-03-10 10:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:09:44 --> Config Class Initialized
INFO - 2022-03-10 10:09:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:09:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:09:44 --> Utf8 Class Initialized
INFO - 2022-03-10 10:09:44 --> URI Class Initialized
INFO - 2022-03-10 10:09:44 --> Router Class Initialized
INFO - 2022-03-10 10:09:44 --> Output Class Initialized
INFO - 2022-03-10 10:09:44 --> Security Class Initialized
DEBUG - 2022-03-10 10:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:09:44 --> Input Class Initialized
INFO - 2022-03-10 10:09:44 --> Language Class Initialized
ERROR - 2022-03-10 10:09:44 --> 404 Page Not Found: Site/wp-admin
ERROR - 2022-03-10 10:09:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:09:51 --> Config Class Initialized
INFO - 2022-03-10 10:09:51 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:09:51 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:09:51 --> Utf8 Class Initialized
INFO - 2022-03-10 10:09:51 --> URI Class Initialized
INFO - 2022-03-10 10:09:51 --> Router Class Initialized
INFO - 2022-03-10 10:09:51 --> Output Class Initialized
INFO - 2022-03-10 10:09:51 --> Security Class Initialized
DEBUG - 2022-03-10 10:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:09:51 --> Input Class Initialized
INFO - 2022-03-10 10:09:51 --> Language Class Initialized
ERROR - 2022-03-10 10:09:51 --> 404 Page Not Found: Blog/wp-admin
ERROR - 2022-03-10 10:33:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:33:44 --> Config Class Initialized
INFO - 2022-03-10 10:33:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:33:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:33:44 --> Utf8 Class Initialized
INFO - 2022-03-10 10:33:44 --> URI Class Initialized
DEBUG - 2022-03-10 10:33:44 --> No URI present. Default controller set.
INFO - 2022-03-10 10:33:44 --> Router Class Initialized
INFO - 2022-03-10 10:33:44 --> Output Class Initialized
INFO - 2022-03-10 10:33:44 --> Security Class Initialized
DEBUG - 2022-03-10 10:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:33:44 --> Input Class Initialized
INFO - 2022-03-10 10:33:44 --> Language Class Initialized
INFO - 2022-03-10 10:33:44 --> Loader Class Initialized
INFO - 2022-03-10 10:33:44 --> Helper loaded: url_helper
INFO - 2022-03-10 10:33:44 --> Helper loaded: form_helper
INFO - 2022-03-10 10:33:44 --> Helper loaded: common_helper
INFO - 2022-03-10 10:33:44 --> Database Driver Class Initialized
DEBUG - 2022-03-10 10:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 10:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 10:33:44 --> Controller Class Initialized
INFO - 2022-03-10 10:33:44 --> Form Validation Class Initialized
DEBUG - 2022-03-10 10:33:44 --> Encrypt Class Initialized
DEBUG - 2022-03-10 10:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 10:33:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 10:33:44 --> Email Class Initialized
INFO - 2022-03-10 10:33:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 10:33:44 --> Calendar Class Initialized
INFO - 2022-03-10 10:33:44 --> Model "Login_model" initialized
INFO - 2022-03-10 10:33:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 10:33:44 --> Final output sent to browser
DEBUG - 2022-03-10 10:33:44 --> Total execution time: 0.0374
ERROR - 2022-03-10 10:33:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:33:50 --> Config Class Initialized
INFO - 2022-03-10 10:33:50 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:33:50 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:33:50 --> Utf8 Class Initialized
INFO - 2022-03-10 10:33:50 --> URI Class Initialized
DEBUG - 2022-03-10 10:33:50 --> No URI present. Default controller set.
INFO - 2022-03-10 10:33:50 --> Router Class Initialized
INFO - 2022-03-10 10:33:50 --> Output Class Initialized
INFO - 2022-03-10 10:33:50 --> Security Class Initialized
DEBUG - 2022-03-10 10:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:33:50 --> Input Class Initialized
INFO - 2022-03-10 10:33:50 --> Language Class Initialized
INFO - 2022-03-10 10:33:50 --> Loader Class Initialized
INFO - 2022-03-10 10:33:50 --> Helper loaded: url_helper
INFO - 2022-03-10 10:33:50 --> Helper loaded: form_helper
INFO - 2022-03-10 10:33:50 --> Helper loaded: common_helper
INFO - 2022-03-10 10:33:50 --> Database Driver Class Initialized
DEBUG - 2022-03-10 10:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 10:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 10:33:50 --> Controller Class Initialized
INFO - 2022-03-10 10:33:50 --> Form Validation Class Initialized
DEBUG - 2022-03-10 10:33:50 --> Encrypt Class Initialized
DEBUG - 2022-03-10 10:33:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 10:33:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 10:33:50 --> Email Class Initialized
INFO - 2022-03-10 10:33:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 10:33:50 --> Calendar Class Initialized
INFO - 2022-03-10 10:33:50 --> Model "Login_model" initialized
INFO - 2022-03-10 10:33:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 10:33:50 --> Final output sent to browser
DEBUG - 2022-03-10 10:33:50 --> Total execution time: 0.0271
ERROR - 2022-03-10 10:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:35:49 --> Config Class Initialized
INFO - 2022-03-10 10:35:49 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:35:49 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:35:49 --> Utf8 Class Initialized
INFO - 2022-03-10 10:35:49 --> URI Class Initialized
DEBUG - 2022-03-10 10:35:49 --> No URI present. Default controller set.
INFO - 2022-03-10 10:35:49 --> Router Class Initialized
INFO - 2022-03-10 10:35:49 --> Output Class Initialized
INFO - 2022-03-10 10:35:49 --> Security Class Initialized
DEBUG - 2022-03-10 10:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:35:49 --> Input Class Initialized
INFO - 2022-03-10 10:35:49 --> Language Class Initialized
INFO - 2022-03-10 10:35:49 --> Loader Class Initialized
INFO - 2022-03-10 10:35:49 --> Helper loaded: url_helper
INFO - 2022-03-10 10:35:49 --> Helper loaded: form_helper
INFO - 2022-03-10 10:35:49 --> Helper loaded: common_helper
INFO - 2022-03-10 10:35:49 --> Database Driver Class Initialized
DEBUG - 2022-03-10 10:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 10:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 10:35:49 --> Controller Class Initialized
INFO - 2022-03-10 10:35:49 --> Form Validation Class Initialized
DEBUG - 2022-03-10 10:35:49 --> Encrypt Class Initialized
DEBUG - 2022-03-10 10:35:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 10:35:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 10:35:49 --> Email Class Initialized
INFO - 2022-03-10 10:35:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 10:35:49 --> Calendar Class Initialized
INFO - 2022-03-10 10:35:49 --> Model "Login_model" initialized
INFO - 2022-03-10 10:35:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 10:35:49 --> Final output sent to browser
DEBUG - 2022-03-10 10:35:49 --> Total execution time: 0.0251
ERROR - 2022-03-10 10:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:49:47 --> Config Class Initialized
INFO - 2022-03-10 10:49:47 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:49:47 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:49:47 --> Utf8 Class Initialized
INFO - 2022-03-10 10:49:47 --> URI Class Initialized
DEBUG - 2022-03-10 10:49:47 --> No URI present. Default controller set.
INFO - 2022-03-10 10:49:47 --> Router Class Initialized
INFO - 2022-03-10 10:49:47 --> Output Class Initialized
INFO - 2022-03-10 10:49:47 --> Security Class Initialized
DEBUG - 2022-03-10 10:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:49:47 --> Input Class Initialized
INFO - 2022-03-10 10:49:47 --> Language Class Initialized
INFO - 2022-03-10 10:49:47 --> Loader Class Initialized
INFO - 2022-03-10 10:49:47 --> Helper loaded: url_helper
INFO - 2022-03-10 10:49:47 --> Helper loaded: form_helper
INFO - 2022-03-10 10:49:47 --> Helper loaded: common_helper
INFO - 2022-03-10 10:49:47 --> Database Driver Class Initialized
DEBUG - 2022-03-10 10:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 10:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 10:49:47 --> Controller Class Initialized
INFO - 2022-03-10 10:49:47 --> Form Validation Class Initialized
DEBUG - 2022-03-10 10:49:47 --> Encrypt Class Initialized
DEBUG - 2022-03-10 10:49:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 10:49:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 10:49:47 --> Email Class Initialized
INFO - 2022-03-10 10:49:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 10:49:47 --> Calendar Class Initialized
INFO - 2022-03-10 10:49:47 --> Model "Login_model" initialized
INFO - 2022-03-10 10:49:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 10:49:47 --> Final output sent to browser
DEBUG - 2022-03-10 10:49:47 --> Total execution time: 0.0347
ERROR - 2022-03-10 10:54:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 10:54:37 --> Config Class Initialized
INFO - 2022-03-10 10:54:37 --> Hooks Class Initialized
DEBUG - 2022-03-10 10:54:37 --> UTF-8 Support Enabled
INFO - 2022-03-10 10:54:37 --> Utf8 Class Initialized
INFO - 2022-03-10 10:54:37 --> URI Class Initialized
DEBUG - 2022-03-10 10:54:37 --> No URI present. Default controller set.
INFO - 2022-03-10 10:54:37 --> Router Class Initialized
INFO - 2022-03-10 10:54:37 --> Output Class Initialized
INFO - 2022-03-10 10:54:37 --> Security Class Initialized
DEBUG - 2022-03-10 10:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 10:54:37 --> Input Class Initialized
INFO - 2022-03-10 10:54:37 --> Language Class Initialized
INFO - 2022-03-10 10:54:37 --> Loader Class Initialized
INFO - 2022-03-10 10:54:37 --> Helper loaded: url_helper
INFO - 2022-03-10 10:54:37 --> Helper loaded: form_helper
INFO - 2022-03-10 10:54:37 --> Helper loaded: common_helper
INFO - 2022-03-10 10:54:37 --> Database Driver Class Initialized
DEBUG - 2022-03-10 10:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 10:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 10:54:37 --> Controller Class Initialized
INFO - 2022-03-10 10:54:37 --> Form Validation Class Initialized
DEBUG - 2022-03-10 10:54:37 --> Encrypt Class Initialized
DEBUG - 2022-03-10 10:54:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 10:54:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 10:54:37 --> Email Class Initialized
INFO - 2022-03-10 10:54:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 10:54:37 --> Calendar Class Initialized
INFO - 2022-03-10 10:54:37 --> Model "Login_model" initialized
INFO - 2022-03-10 10:54:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 10:54:37 --> Final output sent to browser
DEBUG - 2022-03-10 10:54:37 --> Total execution time: 0.0287
ERROR - 2022-03-10 13:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 13:26:10 --> Config Class Initialized
INFO - 2022-03-10 13:26:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 13:26:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 13:26:10 --> Utf8 Class Initialized
INFO - 2022-03-10 13:26:10 --> URI Class Initialized
DEBUG - 2022-03-10 13:26:10 --> No URI present. Default controller set.
INFO - 2022-03-10 13:26:10 --> Router Class Initialized
INFO - 2022-03-10 13:26:10 --> Output Class Initialized
INFO - 2022-03-10 13:26:10 --> Security Class Initialized
DEBUG - 2022-03-10 13:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 13:26:10 --> Input Class Initialized
INFO - 2022-03-10 13:26:10 --> Language Class Initialized
INFO - 2022-03-10 13:26:10 --> Loader Class Initialized
INFO - 2022-03-10 13:26:10 --> Helper loaded: url_helper
INFO - 2022-03-10 13:26:10 --> Helper loaded: form_helper
INFO - 2022-03-10 13:26:10 --> Helper loaded: common_helper
INFO - 2022-03-10 13:26:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 13:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 13:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 13:26:10 --> Controller Class Initialized
INFO - 2022-03-10 13:26:10 --> Form Validation Class Initialized
DEBUG - 2022-03-10 13:26:10 --> Encrypt Class Initialized
DEBUG - 2022-03-10 13:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:26:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 13:26:10 --> Email Class Initialized
INFO - 2022-03-10 13:26:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 13:26:10 --> Calendar Class Initialized
INFO - 2022-03-10 13:26:10 --> Model "Login_model" initialized
INFO - 2022-03-10 13:26:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 13:26:10 --> Final output sent to browser
DEBUG - 2022-03-10 13:26:10 --> Total execution time: 0.0998
ERROR - 2022-03-10 14:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 14:17:57 --> Config Class Initialized
INFO - 2022-03-10 14:17:57 --> Hooks Class Initialized
DEBUG - 2022-03-10 14:17:57 --> UTF-8 Support Enabled
INFO - 2022-03-10 14:17:57 --> Utf8 Class Initialized
INFO - 2022-03-10 14:17:57 --> URI Class Initialized
DEBUG - 2022-03-10 14:17:57 --> No URI present. Default controller set.
INFO - 2022-03-10 14:17:57 --> Router Class Initialized
INFO - 2022-03-10 14:17:57 --> Output Class Initialized
INFO - 2022-03-10 14:17:57 --> Security Class Initialized
DEBUG - 2022-03-10 14:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 14:17:57 --> Input Class Initialized
INFO - 2022-03-10 14:17:57 --> Language Class Initialized
INFO - 2022-03-10 14:17:57 --> Loader Class Initialized
INFO - 2022-03-10 14:17:57 --> Helper loaded: url_helper
INFO - 2022-03-10 14:17:57 --> Helper loaded: form_helper
INFO - 2022-03-10 14:17:57 --> Helper loaded: common_helper
INFO - 2022-03-10 14:17:57 --> Database Driver Class Initialized
DEBUG - 2022-03-10 14:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 14:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 14:17:57 --> Controller Class Initialized
INFO - 2022-03-10 14:17:57 --> Form Validation Class Initialized
DEBUG - 2022-03-10 14:17:57 --> Encrypt Class Initialized
DEBUG - 2022-03-10 14:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:17:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 14:17:57 --> Email Class Initialized
INFO - 2022-03-10 14:17:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 14:17:57 --> Calendar Class Initialized
INFO - 2022-03-10 14:17:57 --> Model "Login_model" initialized
INFO - 2022-03-10 14:17:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 14:17:57 --> Final output sent to browser
DEBUG - 2022-03-10 14:17:57 --> Total execution time: 0.0263
ERROR - 2022-03-10 14:21:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 14:21:32 --> Config Class Initialized
INFO - 2022-03-10 14:21:32 --> Hooks Class Initialized
DEBUG - 2022-03-10 14:21:32 --> UTF-8 Support Enabled
INFO - 2022-03-10 14:21:32 --> Utf8 Class Initialized
INFO - 2022-03-10 14:21:32 --> URI Class Initialized
DEBUG - 2022-03-10 14:21:32 --> No URI present. Default controller set.
INFO - 2022-03-10 14:21:32 --> Router Class Initialized
INFO - 2022-03-10 14:21:32 --> Output Class Initialized
INFO - 2022-03-10 14:21:32 --> Security Class Initialized
DEBUG - 2022-03-10 14:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 14:21:32 --> Input Class Initialized
INFO - 2022-03-10 14:21:32 --> Language Class Initialized
INFO - 2022-03-10 14:21:32 --> Loader Class Initialized
INFO - 2022-03-10 14:21:32 --> Helper loaded: url_helper
INFO - 2022-03-10 14:21:32 --> Helper loaded: form_helper
INFO - 2022-03-10 14:21:32 --> Helper loaded: common_helper
INFO - 2022-03-10 14:21:32 --> Database Driver Class Initialized
DEBUG - 2022-03-10 14:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 14:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 14:21:32 --> Controller Class Initialized
INFO - 2022-03-10 14:21:32 --> Form Validation Class Initialized
DEBUG - 2022-03-10 14:21:32 --> Encrypt Class Initialized
DEBUG - 2022-03-10 14:21:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:21:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 14:21:32 --> Email Class Initialized
INFO - 2022-03-10 14:21:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 14:21:32 --> Calendar Class Initialized
INFO - 2022-03-10 14:21:32 --> Model "Login_model" initialized
INFO - 2022-03-10 14:21:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 14:21:32 --> Final output sent to browser
DEBUG - 2022-03-10 14:21:32 --> Total execution time: 0.0256
ERROR - 2022-03-10 14:21:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 14:21:34 --> Config Class Initialized
INFO - 2022-03-10 14:21:34 --> Hooks Class Initialized
DEBUG - 2022-03-10 14:21:34 --> UTF-8 Support Enabled
INFO - 2022-03-10 14:21:34 --> Utf8 Class Initialized
INFO - 2022-03-10 14:21:34 --> URI Class Initialized
INFO - 2022-03-10 14:21:34 --> Router Class Initialized
INFO - 2022-03-10 14:21:34 --> Output Class Initialized
INFO - 2022-03-10 14:21:34 --> Security Class Initialized
DEBUG - 2022-03-10 14:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 14:21:34 --> Input Class Initialized
INFO - 2022-03-10 14:21:34 --> Language Class Initialized
ERROR - 2022-03-10 14:21:34 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-10 14:22:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 14:22:05 --> Config Class Initialized
INFO - 2022-03-10 14:22:05 --> Hooks Class Initialized
DEBUG - 2022-03-10 14:22:05 --> UTF-8 Support Enabled
INFO - 2022-03-10 14:22:05 --> Utf8 Class Initialized
INFO - 2022-03-10 14:22:05 --> URI Class Initialized
INFO - 2022-03-10 14:22:05 --> Router Class Initialized
INFO - 2022-03-10 14:22:05 --> Output Class Initialized
INFO - 2022-03-10 14:22:05 --> Security Class Initialized
DEBUG - 2022-03-10 14:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 14:22:05 --> Input Class Initialized
INFO - 2022-03-10 14:22:05 --> Language Class Initialized
INFO - 2022-03-10 14:22:05 --> Loader Class Initialized
INFO - 2022-03-10 14:22:05 --> Helper loaded: url_helper
INFO - 2022-03-10 14:22:05 --> Helper loaded: form_helper
INFO - 2022-03-10 14:22:05 --> Helper loaded: common_helper
INFO - 2022-03-10 14:22:05 --> Database Driver Class Initialized
DEBUG - 2022-03-10 14:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 14:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 14:22:05 --> Controller Class Initialized
INFO - 2022-03-10 14:22:05 --> Form Validation Class Initialized
DEBUG - 2022-03-10 14:22:05 --> Encrypt Class Initialized
DEBUG - 2022-03-10 14:22:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:22:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 14:22:05 --> Email Class Initialized
INFO - 2022-03-10 14:22:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 14:22:05 --> Calendar Class Initialized
INFO - 2022-03-10 14:22:05 --> Model "Login_model" initialized
INFO - 2022-03-10 14:22:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 14:22:05 --> Final output sent to browser
DEBUG - 2022-03-10 14:22:05 --> Total execution time: 0.0318
ERROR - 2022-03-10 14:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 14:22:06 --> Config Class Initialized
INFO - 2022-03-10 14:22:06 --> Hooks Class Initialized
DEBUG - 2022-03-10 14:22:06 --> UTF-8 Support Enabled
INFO - 2022-03-10 14:22:06 --> Utf8 Class Initialized
INFO - 2022-03-10 14:22:06 --> URI Class Initialized
DEBUG - 2022-03-10 14:22:06 --> No URI present. Default controller set.
INFO - 2022-03-10 14:22:06 --> Router Class Initialized
INFO - 2022-03-10 14:22:06 --> Output Class Initialized
INFO - 2022-03-10 14:22:06 --> Security Class Initialized
DEBUG - 2022-03-10 14:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 14:22:06 --> Input Class Initialized
INFO - 2022-03-10 14:22:06 --> Language Class Initialized
INFO - 2022-03-10 14:22:06 --> Loader Class Initialized
INFO - 2022-03-10 14:22:06 --> Helper loaded: url_helper
INFO - 2022-03-10 14:22:06 --> Helper loaded: form_helper
INFO - 2022-03-10 14:22:06 --> Helper loaded: common_helper
INFO - 2022-03-10 14:22:06 --> Database Driver Class Initialized
DEBUG - 2022-03-10 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 14:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 14:22:06 --> Controller Class Initialized
INFO - 2022-03-10 14:22:06 --> Form Validation Class Initialized
DEBUG - 2022-03-10 14:22:06 --> Encrypt Class Initialized
DEBUG - 2022-03-10 14:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:22:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 14:22:06 --> Email Class Initialized
INFO - 2022-03-10 14:22:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 14:22:06 --> Calendar Class Initialized
INFO - 2022-03-10 14:22:06 --> Model "Login_model" initialized
INFO - 2022-03-10 14:22:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 14:22:06 --> Final output sent to browser
DEBUG - 2022-03-10 14:22:06 --> Total execution time: 0.0229
ERROR - 2022-03-10 14:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 14:22:07 --> Config Class Initialized
INFO - 2022-03-10 14:22:07 --> Hooks Class Initialized
DEBUG - 2022-03-10 14:22:07 --> UTF-8 Support Enabled
INFO - 2022-03-10 14:22:07 --> Utf8 Class Initialized
INFO - 2022-03-10 14:22:07 --> URI Class Initialized
INFO - 2022-03-10 14:22:07 --> Router Class Initialized
INFO - 2022-03-10 14:22:07 --> Output Class Initialized
INFO - 2022-03-10 14:22:07 --> Security Class Initialized
DEBUG - 2022-03-10 14:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 14:22:07 --> Input Class Initialized
INFO - 2022-03-10 14:22:07 --> Language Class Initialized
INFO - 2022-03-10 14:22:07 --> Loader Class Initialized
INFO - 2022-03-10 14:22:07 --> Helper loaded: url_helper
INFO - 2022-03-10 14:22:07 --> Helper loaded: form_helper
INFO - 2022-03-10 14:22:07 --> Helper loaded: common_helper
INFO - 2022-03-10 14:22:07 --> Database Driver Class Initialized
DEBUG - 2022-03-10 14:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 14:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 14:22:07 --> Controller Class Initialized
INFO - 2022-03-10 14:22:07 --> Form Validation Class Initialized
DEBUG - 2022-03-10 14:22:07 --> Encrypt Class Initialized
DEBUG - 2022-03-10 14:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:22:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 14:22:07 --> Email Class Initialized
INFO - 2022-03-10 14:22:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 14:22:07 --> Calendar Class Initialized
INFO - 2022-03-10 14:22:07 --> Model "Login_model" initialized
ERROR - 2022-03-10 14:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 14:22:07 --> Config Class Initialized
INFO - 2022-03-10 14:22:07 --> Hooks Class Initialized
DEBUG - 2022-03-10 14:22:07 --> UTF-8 Support Enabled
INFO - 2022-03-10 14:22:07 --> Utf8 Class Initialized
INFO - 2022-03-10 14:22:07 --> URI Class Initialized
INFO - 2022-03-10 14:22:07 --> Router Class Initialized
INFO - 2022-03-10 14:22:07 --> Output Class Initialized
INFO - 2022-03-10 14:22:07 --> Security Class Initialized
DEBUG - 2022-03-10 14:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 14:22:07 --> Input Class Initialized
INFO - 2022-03-10 14:22:07 --> Language Class Initialized
INFO - 2022-03-10 14:22:07 --> Loader Class Initialized
INFO - 2022-03-10 14:22:07 --> Helper loaded: url_helper
INFO - 2022-03-10 14:22:07 --> Helper loaded: form_helper
INFO - 2022-03-10 14:22:07 --> Helper loaded: common_helper
INFO - 2022-03-10 14:22:07 --> Database Driver Class Initialized
DEBUG - 2022-03-10 14:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 14:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 14:22:07 --> Controller Class Initialized
INFO - 2022-03-10 14:22:07 --> Form Validation Class Initialized
DEBUG - 2022-03-10 14:22:07 --> Encrypt Class Initialized
DEBUG - 2022-03-10 14:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:22:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 14:22:07 --> Email Class Initialized
INFO - 2022-03-10 14:22:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 14:22:07 --> Calendar Class Initialized
INFO - 2022-03-10 14:22:07 --> Model "Login_model" initialized
ERROR - 2022-03-10 15:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 15:31:28 --> Config Class Initialized
INFO - 2022-03-10 15:31:28 --> Hooks Class Initialized
DEBUG - 2022-03-10 15:31:28 --> UTF-8 Support Enabled
INFO - 2022-03-10 15:31:28 --> Utf8 Class Initialized
INFO - 2022-03-10 15:31:28 --> URI Class Initialized
DEBUG - 2022-03-10 15:31:28 --> No URI present. Default controller set.
INFO - 2022-03-10 15:31:28 --> Router Class Initialized
INFO - 2022-03-10 15:31:28 --> Output Class Initialized
INFO - 2022-03-10 15:31:28 --> Security Class Initialized
DEBUG - 2022-03-10 15:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 15:31:28 --> Input Class Initialized
INFO - 2022-03-10 15:31:28 --> Language Class Initialized
INFO - 2022-03-10 15:31:28 --> Loader Class Initialized
INFO - 2022-03-10 15:31:28 --> Helper loaded: url_helper
INFO - 2022-03-10 15:31:28 --> Helper loaded: form_helper
INFO - 2022-03-10 15:31:28 --> Helper loaded: common_helper
INFO - 2022-03-10 15:31:28 --> Database Driver Class Initialized
DEBUG - 2022-03-10 15:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 15:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 15:31:28 --> Controller Class Initialized
INFO - 2022-03-10 15:31:28 --> Form Validation Class Initialized
DEBUG - 2022-03-10 15:31:28 --> Encrypt Class Initialized
DEBUG - 2022-03-10 15:31:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 15:31:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 15:31:28 --> Email Class Initialized
INFO - 2022-03-10 15:31:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 15:31:28 --> Calendar Class Initialized
INFO - 2022-03-10 15:31:28 --> Model "Login_model" initialized
INFO - 2022-03-10 15:31:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 15:31:28 --> Final output sent to browser
DEBUG - 2022-03-10 15:31:28 --> Total execution time: 0.0357
ERROR - 2022-03-10 16:16:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 16:16:13 --> Config Class Initialized
INFO - 2022-03-10 16:16:13 --> Hooks Class Initialized
DEBUG - 2022-03-10 16:16:13 --> UTF-8 Support Enabled
INFO - 2022-03-10 16:16:13 --> Utf8 Class Initialized
INFO - 2022-03-10 16:16:13 --> URI Class Initialized
DEBUG - 2022-03-10 16:16:13 --> No URI present. Default controller set.
INFO - 2022-03-10 16:16:13 --> Router Class Initialized
INFO - 2022-03-10 16:16:13 --> Output Class Initialized
INFO - 2022-03-10 16:16:13 --> Security Class Initialized
DEBUG - 2022-03-10 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 16:16:13 --> Input Class Initialized
INFO - 2022-03-10 16:16:13 --> Language Class Initialized
INFO - 2022-03-10 16:16:13 --> Loader Class Initialized
INFO - 2022-03-10 16:16:13 --> Helper loaded: url_helper
INFO - 2022-03-10 16:16:13 --> Helper loaded: form_helper
INFO - 2022-03-10 16:16:13 --> Helper loaded: common_helper
INFO - 2022-03-10 16:16:13 --> Database Driver Class Initialized
DEBUG - 2022-03-10 16:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 16:16:13 --> Controller Class Initialized
INFO - 2022-03-10 16:16:13 --> Form Validation Class Initialized
DEBUG - 2022-03-10 16:16:13 --> Encrypt Class Initialized
DEBUG - 2022-03-10 16:16:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 16:16:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 16:16:13 --> Email Class Initialized
INFO - 2022-03-10 16:16:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 16:16:13 --> Calendar Class Initialized
INFO - 2022-03-10 16:16:13 --> Model "Login_model" initialized
INFO - 2022-03-10 16:16:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 16:16:13 --> Final output sent to browser
DEBUG - 2022-03-10 16:16:13 --> Total execution time: 0.0335
ERROR - 2022-03-10 19:53:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 19:53:22 --> Config Class Initialized
INFO - 2022-03-10 19:53:22 --> Hooks Class Initialized
DEBUG - 2022-03-10 19:53:22 --> UTF-8 Support Enabled
INFO - 2022-03-10 19:53:22 --> Utf8 Class Initialized
INFO - 2022-03-10 19:53:22 --> URI Class Initialized
DEBUG - 2022-03-10 19:53:22 --> No URI present. Default controller set.
INFO - 2022-03-10 19:53:22 --> Router Class Initialized
INFO - 2022-03-10 19:53:22 --> Output Class Initialized
INFO - 2022-03-10 19:53:22 --> Security Class Initialized
DEBUG - 2022-03-10 19:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 19:53:22 --> Input Class Initialized
INFO - 2022-03-10 19:53:22 --> Language Class Initialized
INFO - 2022-03-10 19:53:22 --> Loader Class Initialized
INFO - 2022-03-10 19:53:22 --> Helper loaded: url_helper
INFO - 2022-03-10 19:53:22 --> Helper loaded: form_helper
INFO - 2022-03-10 19:53:22 --> Helper loaded: common_helper
INFO - 2022-03-10 19:53:22 --> Database Driver Class Initialized
DEBUG - 2022-03-10 19:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 19:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 19:53:22 --> Controller Class Initialized
INFO - 2022-03-10 19:53:22 --> Form Validation Class Initialized
DEBUG - 2022-03-10 19:53:22 --> Encrypt Class Initialized
DEBUG - 2022-03-10 19:53:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 19:53:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 19:53:22 --> Email Class Initialized
INFO - 2022-03-10 19:53:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 19:53:22 --> Calendar Class Initialized
INFO - 2022-03-10 19:53:22 --> Model "Login_model" initialized
INFO - 2022-03-10 19:53:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 19:53:22 --> Final output sent to browser
DEBUG - 2022-03-10 19:53:22 --> Total execution time: 0.0366
ERROR - 2022-03-10 20:27:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:38 --> Config Class Initialized
INFO - 2022-03-10 20:27:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:38 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:38 --> URI Class Initialized
DEBUG - 2022-03-10 20:27:38 --> No URI present. Default controller set.
INFO - 2022-03-10 20:27:38 --> Router Class Initialized
INFO - 2022-03-10 20:27:38 --> Output Class Initialized
INFO - 2022-03-10 20:27:38 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:38 --> Input Class Initialized
INFO - 2022-03-10 20:27:38 --> Language Class Initialized
INFO - 2022-03-10 20:27:38 --> Loader Class Initialized
INFO - 2022-03-10 20:27:38 --> Helper loaded: url_helper
INFO - 2022-03-10 20:27:38 --> Helper loaded: form_helper
INFO - 2022-03-10 20:27:38 --> Helper loaded: common_helper
INFO - 2022-03-10 20:27:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 20:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 20:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 20:27:38 --> Controller Class Initialized
INFO - 2022-03-10 20:27:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 20:27:38 --> Encrypt Class Initialized
DEBUG - 2022-03-10 20:27:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 20:27:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 20:27:38 --> Email Class Initialized
INFO - 2022-03-10 20:27:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 20:27:38 --> Calendar Class Initialized
INFO - 2022-03-10 20:27:38 --> Model "Login_model" initialized
INFO - 2022-03-10 20:27:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 20:27:38 --> Final output sent to browser
DEBUG - 2022-03-10 20:27:38 --> Total execution time: 0.0382
ERROR - 2022-03-10 20:27:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:38 --> Config Class Initialized
INFO - 2022-03-10 20:27:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:38 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:38 --> URI Class Initialized
DEBUG - 2022-03-10 20:27:38 --> No URI present. Default controller set.
INFO - 2022-03-10 20:27:38 --> Router Class Initialized
INFO - 2022-03-10 20:27:38 --> Output Class Initialized
INFO - 2022-03-10 20:27:38 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:38 --> Input Class Initialized
INFO - 2022-03-10 20:27:38 --> Language Class Initialized
INFO - 2022-03-10 20:27:38 --> Loader Class Initialized
INFO - 2022-03-10 20:27:38 --> Helper loaded: url_helper
INFO - 2022-03-10 20:27:38 --> Helper loaded: form_helper
INFO - 2022-03-10 20:27:38 --> Helper loaded: common_helper
INFO - 2022-03-10 20:27:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 20:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 20:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 20:27:38 --> Controller Class Initialized
INFO - 2022-03-10 20:27:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 20:27:38 --> Encrypt Class Initialized
DEBUG - 2022-03-10 20:27:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 20:27:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 20:27:38 --> Email Class Initialized
INFO - 2022-03-10 20:27:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 20:27:38 --> Calendar Class Initialized
INFO - 2022-03-10 20:27:38 --> Model "Login_model" initialized
INFO - 2022-03-10 20:27:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 20:27:38 --> Final output sent to browser
DEBUG - 2022-03-10 20:27:38 --> Total execution time: 0.0318
ERROR - 2022-03-10 20:27:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:39 --> Config Class Initialized
INFO - 2022-03-10 20:27:39 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:39 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:39 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:39 --> URI Class Initialized
INFO - 2022-03-10 20:27:39 --> Router Class Initialized
INFO - 2022-03-10 20:27:39 --> Output Class Initialized
INFO - 2022-03-10 20:27:39 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:39 --> Input Class Initialized
INFO - 2022-03-10 20:27:39 --> Language Class Initialized
ERROR - 2022-03-10 20:27:39 --> 404 Page Not Found: Feed/index
ERROR - 2022-03-10 20:27:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:39 --> Config Class Initialized
INFO - 2022-03-10 20:27:39 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:39 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:39 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:39 --> URI Class Initialized
INFO - 2022-03-10 20:27:39 --> Router Class Initialized
INFO - 2022-03-10 20:27:39 --> Output Class Initialized
INFO - 2022-03-10 20:27:39 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:39 --> Input Class Initialized
INFO - 2022-03-10 20:27:39 --> Language Class Initialized
ERROR - 2022-03-10 20:27:39 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-10 20:27:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:40 --> Config Class Initialized
INFO - 2022-03-10 20:27:40 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:40 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:40 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:40 --> URI Class Initialized
INFO - 2022-03-10 20:27:40 --> Router Class Initialized
INFO - 2022-03-10 20:27:40 --> Output Class Initialized
INFO - 2022-03-10 20:27:40 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:40 --> Input Class Initialized
INFO - 2022-03-10 20:27:40 --> Language Class Initialized
ERROR - 2022-03-10 20:27:40 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-10 20:27:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:40 --> Config Class Initialized
INFO - 2022-03-10 20:27:40 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:40 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:40 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:40 --> URI Class Initialized
INFO - 2022-03-10 20:27:40 --> Router Class Initialized
INFO - 2022-03-10 20:27:40 --> Output Class Initialized
INFO - 2022-03-10 20:27:40 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:40 --> Input Class Initialized
INFO - 2022-03-10 20:27:40 --> Language Class Initialized
ERROR - 2022-03-10 20:27:40 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-10 20:27:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:40 --> Config Class Initialized
INFO - 2022-03-10 20:27:40 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:40 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:40 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:40 --> URI Class Initialized
INFO - 2022-03-10 20:27:40 --> Router Class Initialized
INFO - 2022-03-10 20:27:40 --> Output Class Initialized
INFO - 2022-03-10 20:27:40 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:40 --> Input Class Initialized
INFO - 2022-03-10 20:27:40 --> Language Class Initialized
ERROR - 2022-03-10 20:27:40 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-10 20:27:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:41 --> Config Class Initialized
INFO - 2022-03-10 20:27:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:41 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:41 --> URI Class Initialized
INFO - 2022-03-10 20:27:41 --> Router Class Initialized
INFO - 2022-03-10 20:27:41 --> Output Class Initialized
INFO - 2022-03-10 20:27:41 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:41 --> Input Class Initialized
INFO - 2022-03-10 20:27:41 --> Language Class Initialized
ERROR - 2022-03-10 20:27:41 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-10 20:27:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:41 --> Config Class Initialized
INFO - 2022-03-10 20:27:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:41 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:41 --> URI Class Initialized
INFO - 2022-03-10 20:27:41 --> Router Class Initialized
INFO - 2022-03-10 20:27:41 --> Output Class Initialized
INFO - 2022-03-10 20:27:41 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:41 --> Input Class Initialized
INFO - 2022-03-10 20:27:41 --> Language Class Initialized
ERROR - 2022-03-10 20:27:41 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-10 20:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:42 --> Config Class Initialized
INFO - 2022-03-10 20:27:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:42 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:42 --> URI Class Initialized
INFO - 2022-03-10 20:27:42 --> Router Class Initialized
INFO - 2022-03-10 20:27:42 --> Output Class Initialized
INFO - 2022-03-10 20:27:42 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:42 --> Input Class Initialized
INFO - 2022-03-10 20:27:42 --> Language Class Initialized
ERROR - 2022-03-10 20:27:42 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2022-03-10 20:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:42 --> Config Class Initialized
INFO - 2022-03-10 20:27:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:42 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:42 --> URI Class Initialized
INFO - 2022-03-10 20:27:42 --> Router Class Initialized
INFO - 2022-03-10 20:27:42 --> Output Class Initialized
INFO - 2022-03-10 20:27:42 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:42 --> Input Class Initialized
INFO - 2022-03-10 20:27:42 --> Language Class Initialized
ERROR - 2022-03-10 20:27:42 --> 404 Page Not Found: 2021/wp-includes
ERROR - 2022-03-10 20:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:42 --> Config Class Initialized
INFO - 2022-03-10 20:27:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:42 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:42 --> URI Class Initialized
INFO - 2022-03-10 20:27:42 --> Router Class Initialized
INFO - 2022-03-10 20:27:42 --> Output Class Initialized
INFO - 2022-03-10 20:27:42 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:42 --> Input Class Initialized
INFO - 2022-03-10 20:27:42 --> Language Class Initialized
ERROR - 2022-03-10 20:27:42 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-10 20:27:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:43 --> Config Class Initialized
INFO - 2022-03-10 20:27:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:43 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:43 --> URI Class Initialized
INFO - 2022-03-10 20:27:43 --> Router Class Initialized
INFO - 2022-03-10 20:27:43 --> Output Class Initialized
INFO - 2022-03-10 20:27:43 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:43 --> Input Class Initialized
INFO - 2022-03-10 20:27:43 --> Language Class Initialized
ERROR - 2022-03-10 20:27:43 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-10 20:27:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:43 --> Config Class Initialized
INFO - 2022-03-10 20:27:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:43 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:43 --> URI Class Initialized
INFO - 2022-03-10 20:27:43 --> Router Class Initialized
INFO - 2022-03-10 20:27:43 --> Output Class Initialized
INFO - 2022-03-10 20:27:43 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:43 --> Input Class Initialized
INFO - 2022-03-10 20:27:43 --> Language Class Initialized
ERROR - 2022-03-10 20:27:43 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-10 20:27:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:44 --> Config Class Initialized
INFO - 2022-03-10 20:27:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:44 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:44 --> URI Class Initialized
INFO - 2022-03-10 20:27:44 --> Router Class Initialized
INFO - 2022-03-10 20:27:44 --> Output Class Initialized
INFO - 2022-03-10 20:27:44 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:44 --> Input Class Initialized
INFO - 2022-03-10 20:27:44 --> Language Class Initialized
ERROR - 2022-03-10 20:27:44 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-10 20:27:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:44 --> Config Class Initialized
INFO - 2022-03-10 20:27:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:44 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:44 --> URI Class Initialized
INFO - 2022-03-10 20:27:44 --> Router Class Initialized
INFO - 2022-03-10 20:27:44 --> Output Class Initialized
INFO - 2022-03-10 20:27:44 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:44 --> Input Class Initialized
INFO - 2022-03-10 20:27:44 --> Language Class Initialized
ERROR - 2022-03-10 20:27:44 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-10 20:27:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:44 --> Config Class Initialized
INFO - 2022-03-10 20:27:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:44 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:44 --> URI Class Initialized
INFO - 2022-03-10 20:27:44 --> Router Class Initialized
INFO - 2022-03-10 20:27:44 --> Output Class Initialized
INFO - 2022-03-10 20:27:44 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:44 --> Input Class Initialized
INFO - 2022-03-10 20:27:44 --> Language Class Initialized
ERROR - 2022-03-10 20:27:44 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-10 20:27:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 20:27:45 --> Config Class Initialized
INFO - 2022-03-10 20:27:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 20:27:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 20:27:45 --> Utf8 Class Initialized
INFO - 2022-03-10 20:27:45 --> URI Class Initialized
INFO - 2022-03-10 20:27:45 --> Router Class Initialized
INFO - 2022-03-10 20:27:45 --> Output Class Initialized
INFO - 2022-03-10 20:27:45 --> Security Class Initialized
DEBUG - 2022-03-10 20:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 20:27:45 --> Input Class Initialized
INFO - 2022-03-10 20:27:45 --> Language Class Initialized
ERROR - 2022-03-10 20:27:45 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-03-10 21:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 21:39:06 --> Config Class Initialized
INFO - 2022-03-10 21:39:06 --> Hooks Class Initialized
DEBUG - 2022-03-10 21:39:06 --> UTF-8 Support Enabled
INFO - 2022-03-10 21:39:06 --> Utf8 Class Initialized
INFO - 2022-03-10 21:39:06 --> URI Class Initialized
DEBUG - 2022-03-10 21:39:06 --> No URI present. Default controller set.
INFO - 2022-03-10 21:39:06 --> Router Class Initialized
INFO - 2022-03-10 21:39:06 --> Output Class Initialized
INFO - 2022-03-10 21:39:06 --> Security Class Initialized
DEBUG - 2022-03-10 21:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 21:39:06 --> Input Class Initialized
INFO - 2022-03-10 21:39:06 --> Language Class Initialized
INFO - 2022-03-10 21:39:06 --> Loader Class Initialized
INFO - 2022-03-10 21:39:06 --> Helper loaded: url_helper
INFO - 2022-03-10 21:39:06 --> Helper loaded: form_helper
INFO - 2022-03-10 21:39:06 --> Helper loaded: common_helper
INFO - 2022-03-10 21:39:06 --> Database Driver Class Initialized
DEBUG - 2022-03-10 21:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 21:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 21:39:06 --> Controller Class Initialized
INFO - 2022-03-10 21:39:06 --> Form Validation Class Initialized
DEBUG - 2022-03-10 21:39:06 --> Encrypt Class Initialized
DEBUG - 2022-03-10 21:39:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 21:39:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 21:39:06 --> Email Class Initialized
INFO - 2022-03-10 21:39:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 21:39:06 --> Calendar Class Initialized
INFO - 2022-03-10 21:39:06 --> Model "Login_model" initialized
INFO - 2022-03-10 21:39:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 21:39:06 --> Final output sent to browser
DEBUG - 2022-03-10 21:39:06 --> Total execution time: 0.0362
ERROR - 2022-03-10 21:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 21:39:11 --> Config Class Initialized
INFO - 2022-03-10 21:39:11 --> Hooks Class Initialized
DEBUG - 2022-03-10 21:39:11 --> UTF-8 Support Enabled
INFO - 2022-03-10 21:39:11 --> Utf8 Class Initialized
INFO - 2022-03-10 21:39:11 --> URI Class Initialized
INFO - 2022-03-10 21:39:11 --> Router Class Initialized
INFO - 2022-03-10 21:39:11 --> Output Class Initialized
INFO - 2022-03-10 21:39:11 --> Security Class Initialized
DEBUG - 2022-03-10 21:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 21:39:11 --> Input Class Initialized
INFO - 2022-03-10 21:39:11 --> Language Class Initialized
ERROR - 2022-03-10 21:39:11 --> 404 Page Not Found: Wordpress/index
ERROR - 2022-03-10 23:04:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:04:43 --> Config Class Initialized
INFO - 2022-03-10 23:04:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:04:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:04:43 --> Utf8 Class Initialized
INFO - 2022-03-10 23:04:43 --> URI Class Initialized
INFO - 2022-03-10 23:04:43 --> Router Class Initialized
INFO - 2022-03-10 23:04:43 --> Output Class Initialized
INFO - 2022-03-10 23:04:43 --> Security Class Initialized
DEBUG - 2022-03-10 23:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:04:43 --> Input Class Initialized
INFO - 2022-03-10 23:04:43 --> Language Class Initialized
INFO - 2022-03-10 23:04:43 --> Loader Class Initialized
INFO - 2022-03-10 23:04:43 --> Helper loaded: url_helper
INFO - 2022-03-10 23:04:43 --> Helper loaded: form_helper
INFO - 2022-03-10 23:04:43 --> Helper loaded: common_helper
INFO - 2022-03-10 23:04:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:04:43 --> Controller Class Initialized
ERROR - 2022-03-10 23:04:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:04:44 --> Config Class Initialized
INFO - 2022-03-10 23:04:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:04:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:04:44 --> Utf8 Class Initialized
INFO - 2022-03-10 23:04:44 --> URI Class Initialized
INFO - 2022-03-10 23:04:44 --> Router Class Initialized
INFO - 2022-03-10 23:04:44 --> Output Class Initialized
INFO - 2022-03-10 23:04:44 --> Security Class Initialized
DEBUG - 2022-03-10 23:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:04:44 --> Input Class Initialized
INFO - 2022-03-10 23:04:44 --> Language Class Initialized
INFO - 2022-03-10 23:04:44 --> Loader Class Initialized
INFO - 2022-03-10 23:04:44 --> Helper loaded: url_helper
INFO - 2022-03-10 23:04:44 --> Helper loaded: form_helper
INFO - 2022-03-10 23:04:44 --> Helper loaded: common_helper
INFO - 2022-03-10 23:04:44 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:04:44 --> Controller Class Initialized
INFO - 2022-03-10 23:04:44 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:04:44 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:04:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:04:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:04:44 --> Email Class Initialized
INFO - 2022-03-10 23:04:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:04:44 --> Calendar Class Initialized
INFO - 2022-03-10 23:04:44 --> Model "Login_model" initialized
INFO - 2022-03-10 23:04:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 23:04:44 --> Final output sent to browser
DEBUG - 2022-03-10 23:04:44 --> Total execution time: 0.0229
ERROR - 2022-03-10 23:05:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:05:08 --> Config Class Initialized
INFO - 2022-03-10 23:05:08 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:05:08 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:05:08 --> Utf8 Class Initialized
INFO - 2022-03-10 23:05:08 --> URI Class Initialized
INFO - 2022-03-10 23:05:08 --> Router Class Initialized
INFO - 2022-03-10 23:05:08 --> Output Class Initialized
INFO - 2022-03-10 23:05:08 --> Security Class Initialized
DEBUG - 2022-03-10 23:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:05:08 --> Input Class Initialized
INFO - 2022-03-10 23:05:08 --> Language Class Initialized
INFO - 2022-03-10 23:05:08 --> Loader Class Initialized
INFO - 2022-03-10 23:05:08 --> Helper loaded: url_helper
INFO - 2022-03-10 23:05:08 --> Helper loaded: form_helper
INFO - 2022-03-10 23:05:08 --> Helper loaded: common_helper
INFO - 2022-03-10 23:05:08 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:05:08 --> Controller Class Initialized
INFO - 2022-03-10 23:05:08 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:05:08 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:05:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:05:08 --> Email Class Initialized
INFO - 2022-03-10 23:05:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:05:08 --> Calendar Class Initialized
INFO - 2022-03-10 23:05:08 --> Model "Login_model" initialized
INFO - 2022-03-10 23:05:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 23:05:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:05:10 --> Config Class Initialized
INFO - 2022-03-10 23:05:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:05:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:05:10 --> Utf8 Class Initialized
INFO - 2022-03-10 23:05:10 --> URI Class Initialized
INFO - 2022-03-10 23:05:10 --> Router Class Initialized
INFO - 2022-03-10 23:05:10 --> Output Class Initialized
INFO - 2022-03-10 23:05:10 --> Security Class Initialized
DEBUG - 2022-03-10 23:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:05:10 --> Input Class Initialized
INFO - 2022-03-10 23:05:10 --> Language Class Initialized
INFO - 2022-03-10 23:05:10 --> Loader Class Initialized
INFO - 2022-03-10 23:05:10 --> Helper loaded: url_helper
INFO - 2022-03-10 23:05:10 --> Helper loaded: form_helper
INFO - 2022-03-10 23:05:10 --> Helper loaded: common_helper
INFO - 2022-03-10 23:05:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:05:10 --> Controller Class Initialized
INFO - 2022-03-10 23:05:10 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:05:10 --> Encrypt Class Initialized
INFO - 2022-03-10 23:05:10 --> Model "Login_model" initialized
INFO - 2022-03-10 23:05:10 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 23:05:10 --> Model "Case_model" initialized
INFO - 2022-03-10 23:05:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:05:31 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 23:05:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:05:31 --> Final output sent to browser
DEBUG - 2022-03-10 23:05:31 --> Total execution time: 21.7575
ERROR - 2022-03-10 23:05:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:05:33 --> Config Class Initialized
INFO - 2022-03-10 23:05:33 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:05:33 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:05:33 --> Utf8 Class Initialized
INFO - 2022-03-10 23:05:33 --> URI Class Initialized
INFO - 2022-03-10 23:05:33 --> Router Class Initialized
INFO - 2022-03-10 23:05:33 --> Output Class Initialized
INFO - 2022-03-10 23:05:33 --> Security Class Initialized
DEBUG - 2022-03-10 23:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:05:33 --> Input Class Initialized
INFO - 2022-03-10 23:05:33 --> Language Class Initialized
ERROR - 2022-03-10 23:05:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 23:06:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:06:53 --> Config Class Initialized
INFO - 2022-03-10 23:06:53 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:06:53 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:06:53 --> Utf8 Class Initialized
INFO - 2022-03-10 23:06:53 --> URI Class Initialized
DEBUG - 2022-03-10 23:06:53 --> No URI present. Default controller set.
INFO - 2022-03-10 23:06:53 --> Router Class Initialized
INFO - 2022-03-10 23:06:53 --> Output Class Initialized
INFO - 2022-03-10 23:06:53 --> Security Class Initialized
DEBUG - 2022-03-10 23:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:06:53 --> Input Class Initialized
INFO - 2022-03-10 23:06:53 --> Language Class Initialized
INFO - 2022-03-10 23:06:53 --> Loader Class Initialized
INFO - 2022-03-10 23:06:53 --> Helper loaded: url_helper
INFO - 2022-03-10 23:06:53 --> Helper loaded: form_helper
INFO - 2022-03-10 23:06:53 --> Helper loaded: common_helper
INFO - 2022-03-10 23:06:53 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:06:53 --> Controller Class Initialized
INFO - 2022-03-10 23:06:53 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:06:53 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:06:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:06:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:06:53 --> Email Class Initialized
INFO - 2022-03-10 23:06:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:06:53 --> Calendar Class Initialized
INFO - 2022-03-10 23:06:53 --> Model "Login_model" initialized
INFO - 2022-03-10 23:06:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 23:06:53 --> Final output sent to browser
DEBUG - 2022-03-10 23:06:53 --> Total execution time: 0.0227
ERROR - 2022-03-10 23:06:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:06:54 --> Config Class Initialized
INFO - 2022-03-10 23:06:54 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:06:54 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:06:54 --> Utf8 Class Initialized
INFO - 2022-03-10 23:06:54 --> URI Class Initialized
DEBUG - 2022-03-10 23:06:54 --> No URI present. Default controller set.
INFO - 2022-03-10 23:06:54 --> Router Class Initialized
INFO - 2022-03-10 23:06:54 --> Output Class Initialized
INFO - 2022-03-10 23:06:54 --> Security Class Initialized
DEBUG - 2022-03-10 23:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:06:54 --> Input Class Initialized
INFO - 2022-03-10 23:06:54 --> Language Class Initialized
INFO - 2022-03-10 23:06:54 --> Loader Class Initialized
INFO - 2022-03-10 23:06:54 --> Helper loaded: url_helper
INFO - 2022-03-10 23:06:54 --> Helper loaded: form_helper
INFO - 2022-03-10 23:06:54 --> Helper loaded: common_helper
INFO - 2022-03-10 23:06:54 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:06:54 --> Controller Class Initialized
INFO - 2022-03-10 23:06:54 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:06:54 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:06:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:06:54 --> Email Class Initialized
INFO - 2022-03-10 23:06:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:06:54 --> Calendar Class Initialized
INFO - 2022-03-10 23:06:54 --> Model "Login_model" initialized
INFO - 2022-03-10 23:06:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 23:06:54 --> Final output sent to browser
DEBUG - 2022-03-10 23:06:54 --> Total execution time: 0.0331
ERROR - 2022-03-10 23:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:07:00 --> Config Class Initialized
INFO - 2022-03-10 23:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:07:00 --> Utf8 Class Initialized
INFO - 2022-03-10 23:07:00 --> URI Class Initialized
INFO - 2022-03-10 23:07:00 --> Router Class Initialized
INFO - 2022-03-10 23:07:00 --> Output Class Initialized
INFO - 2022-03-10 23:07:00 --> Security Class Initialized
DEBUG - 2022-03-10 23:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:07:00 --> Input Class Initialized
INFO - 2022-03-10 23:07:00 --> Language Class Initialized
INFO - 2022-03-10 23:07:00 --> Loader Class Initialized
INFO - 2022-03-10 23:07:00 --> Helper loaded: url_helper
INFO - 2022-03-10 23:07:00 --> Helper loaded: form_helper
INFO - 2022-03-10 23:07:00 --> Helper loaded: common_helper
INFO - 2022-03-10 23:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:07:00 --> Controller Class Initialized
INFO - 2022-03-10 23:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:07:00 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:07:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:07:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:07:00 --> Email Class Initialized
INFO - 2022-03-10 23:07:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:07:00 --> Calendar Class Initialized
INFO - 2022-03-10 23:07:00 --> Model "Login_model" initialized
INFO - 2022-03-10 23:07:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 23:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:07:00 --> Config Class Initialized
INFO - 2022-03-10 23:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:07:00 --> Utf8 Class Initialized
INFO - 2022-03-10 23:07:00 --> URI Class Initialized
INFO - 2022-03-10 23:07:00 --> Router Class Initialized
INFO - 2022-03-10 23:07:00 --> Output Class Initialized
INFO - 2022-03-10 23:07:00 --> Security Class Initialized
DEBUG - 2022-03-10 23:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:07:00 --> Input Class Initialized
INFO - 2022-03-10 23:07:00 --> Language Class Initialized
INFO - 2022-03-10 23:07:00 --> Loader Class Initialized
INFO - 2022-03-10 23:07:00 --> Helper loaded: url_helper
INFO - 2022-03-10 23:07:00 --> Helper loaded: form_helper
INFO - 2022-03-10 23:07:00 --> Helper loaded: common_helper
INFO - 2022-03-10 23:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:07:00 --> Controller Class Initialized
INFO - 2022-03-10 23:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:07:00 --> Encrypt Class Initialized
INFO - 2022-03-10 23:07:00 --> Model "Login_model" initialized
INFO - 2022-03-10 23:07:00 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 23:07:00 --> Model "Case_model" initialized
INFO - 2022-03-10 23:07:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:07:20 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 23:07:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:07:20 --> Final output sent to browser
DEBUG - 2022-03-10 23:07:20 --> Total execution time: 19.8988
ERROR - 2022-03-10 23:12:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:12:35 --> Config Class Initialized
INFO - 2022-03-10 23:12:35 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:12:35 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:12:35 --> Utf8 Class Initialized
INFO - 2022-03-10 23:12:35 --> URI Class Initialized
INFO - 2022-03-10 23:12:35 --> Router Class Initialized
INFO - 2022-03-10 23:12:35 --> Output Class Initialized
INFO - 2022-03-10 23:12:35 --> Security Class Initialized
DEBUG - 2022-03-10 23:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:12:35 --> Input Class Initialized
INFO - 2022-03-10 23:12:35 --> Language Class Initialized
INFO - 2022-03-10 23:12:35 --> Loader Class Initialized
INFO - 2022-03-10 23:12:35 --> Helper loaded: url_helper
INFO - 2022-03-10 23:12:35 --> Helper loaded: form_helper
INFO - 2022-03-10 23:12:35 --> Helper loaded: common_helper
INFO - 2022-03-10 23:12:35 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:12:35 --> Controller Class Initialized
INFO - 2022-03-10 23:12:35 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:12:35 --> Encrypt Class Initialized
INFO - 2022-03-10 23:12:35 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:12:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:12:35 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:12:35 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:12:35 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:12:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-10 23:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:12:38 --> Config Class Initialized
INFO - 2022-03-10 23:12:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:12:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:12:38 --> Utf8 Class Initialized
INFO - 2022-03-10 23:12:38 --> URI Class Initialized
INFO - 2022-03-10 23:12:38 --> Router Class Initialized
INFO - 2022-03-10 23:12:38 --> Output Class Initialized
INFO - 2022-03-10 23:12:38 --> Security Class Initialized
DEBUG - 2022-03-10 23:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:12:38 --> Input Class Initialized
INFO - 2022-03-10 23:12:38 --> Language Class Initialized
INFO - 2022-03-10 23:12:38 --> Loader Class Initialized
INFO - 2022-03-10 23:12:38 --> Helper loaded: url_helper
INFO - 2022-03-10 23:12:38 --> Helper loaded: form_helper
INFO - 2022-03-10 23:12:38 --> Helper loaded: common_helper
INFO - 2022-03-10 23:12:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:12:38 --> Controller Class Initialized
INFO - 2022-03-10 23:12:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:12:38 --> Encrypt Class Initialized
INFO - 2022-03-10 23:12:38 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:12:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:12:38 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:12:38 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:12:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:12:38 --> Config Class Initialized
INFO - 2022-03-10 23:12:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:12:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:12:38 --> Utf8 Class Initialized
INFO - 2022-03-10 23:12:38 --> URI Class Initialized
INFO - 2022-03-10 23:12:38 --> Router Class Initialized
INFO - 2022-03-10 23:12:38 --> Output Class Initialized
INFO - 2022-03-10 23:12:38 --> Security Class Initialized
DEBUG - 2022-03-10 23:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:12:38 --> Input Class Initialized
INFO - 2022-03-10 23:12:38 --> Language Class Initialized
INFO - 2022-03-10 23:12:38 --> Loader Class Initialized
INFO - 2022-03-10 23:12:38 --> Helper loaded: url_helper
INFO - 2022-03-10 23:12:38 --> Helper loaded: form_helper
INFO - 2022-03-10 23:12:38 --> Helper loaded: common_helper
INFO - 2022-03-10 23:12:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:12:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:12:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:12:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:12:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:12:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:12:45 --> Controller Class Initialized
INFO - 2022-03-10 23:12:45 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:12:45 --> Encrypt Class Initialized
INFO - 2022-03-10 23:12:45 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:12:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:12:45 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:12:45 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:12:45 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:12:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:12:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:12:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:12:52 --> Final output sent to browser
DEBUG - 2022-03-10 23:12:52 --> Total execution time: 12.3007
ERROR - 2022-03-10 23:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:20:40 --> Config Class Initialized
INFO - 2022-03-10 23:20:40 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:20:40 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:20:40 --> Utf8 Class Initialized
INFO - 2022-03-10 23:20:40 --> URI Class Initialized
INFO - 2022-03-10 23:20:40 --> Router Class Initialized
INFO - 2022-03-10 23:20:40 --> Output Class Initialized
INFO - 2022-03-10 23:20:40 --> Security Class Initialized
DEBUG - 2022-03-10 23:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:20:40 --> Input Class Initialized
INFO - 2022-03-10 23:20:40 --> Language Class Initialized
INFO - 2022-03-10 23:20:40 --> Loader Class Initialized
INFO - 2022-03-10 23:20:40 --> Helper loaded: url_helper
INFO - 2022-03-10 23:20:40 --> Helper loaded: form_helper
INFO - 2022-03-10 23:20:40 --> Helper loaded: common_helper
INFO - 2022-03-10 23:20:40 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:20:40 --> Controller Class Initialized
INFO - 2022-03-10 23:20:40 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:20:40 --> Encrypt Class Initialized
INFO - 2022-03-10 23:20:40 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:20:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:20:40 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:20:40 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:20:40 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:20:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:20:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:20:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:20:40 --> Final output sent to browser
DEBUG - 2022-03-10 23:20:40 --> Total execution time: 0.2112
ERROR - 2022-03-10 23:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:24:56 --> Config Class Initialized
INFO - 2022-03-10 23:24:56 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:24:56 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:24:56 --> Utf8 Class Initialized
INFO - 2022-03-10 23:24:56 --> URI Class Initialized
INFO - 2022-03-10 23:24:56 --> Router Class Initialized
INFO - 2022-03-10 23:24:56 --> Output Class Initialized
INFO - 2022-03-10 23:24:56 --> Security Class Initialized
DEBUG - 2022-03-10 23:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:24:56 --> Input Class Initialized
INFO - 2022-03-10 23:24:56 --> Language Class Initialized
INFO - 2022-03-10 23:24:56 --> Loader Class Initialized
INFO - 2022-03-10 23:24:56 --> Helper loaded: url_helper
INFO - 2022-03-10 23:24:56 --> Helper loaded: form_helper
INFO - 2022-03-10 23:24:56 --> Helper loaded: common_helper
INFO - 2022-03-10 23:24:56 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:24:56 --> Controller Class Initialized
INFO - 2022-03-10 23:24:56 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:24:56 --> Final output sent to browser
DEBUG - 2022-03-10 23:24:56 --> Total execution time: 0.0209
ERROR - 2022-03-10 23:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:27:18 --> Config Class Initialized
INFO - 2022-03-10 23:27:18 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:27:18 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:27:18 --> Utf8 Class Initialized
INFO - 2022-03-10 23:27:18 --> URI Class Initialized
INFO - 2022-03-10 23:27:18 --> Router Class Initialized
INFO - 2022-03-10 23:27:18 --> Output Class Initialized
INFO - 2022-03-10 23:27:18 --> Security Class Initialized
DEBUG - 2022-03-10 23:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:27:18 --> Input Class Initialized
INFO - 2022-03-10 23:27:18 --> Language Class Initialized
INFO - 2022-03-10 23:27:18 --> Loader Class Initialized
INFO - 2022-03-10 23:27:18 --> Helper loaded: url_helper
INFO - 2022-03-10 23:27:18 --> Helper loaded: form_helper
INFO - 2022-03-10 23:27:18 --> Helper loaded: common_helper
INFO - 2022-03-10 23:27:18 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:27:18 --> Controller Class Initialized
INFO - 2022-03-10 23:27:18 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:27:18 --> Encrypt Class Initialized
INFO - 2022-03-10 23:27:18 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:27:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:27:18 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:27:18 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:27:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:27:18 --> Config Class Initialized
INFO - 2022-03-10 23:27:18 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:27:18 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:27:18 --> Utf8 Class Initialized
INFO - 2022-03-10 23:27:18 --> URI Class Initialized
INFO - 2022-03-10 23:27:18 --> Router Class Initialized
INFO - 2022-03-10 23:27:18 --> Output Class Initialized
INFO - 2022-03-10 23:27:18 --> Security Class Initialized
DEBUG - 2022-03-10 23:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:27:18 --> Input Class Initialized
INFO - 2022-03-10 23:27:18 --> Language Class Initialized
INFO - 2022-03-10 23:27:18 --> Loader Class Initialized
INFO - 2022-03-10 23:27:18 --> Helper loaded: url_helper
INFO - 2022-03-10 23:27:18 --> Helper loaded: form_helper
INFO - 2022-03-10 23:27:18 --> Helper loaded: common_helper
INFO - 2022-03-10 23:27:18 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:27:18 --> Controller Class Initialized
INFO - 2022-03-10 23:27:18 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:27:18 --> Encrypt Class Initialized
INFO - 2022-03-10 23:27:18 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:27:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:27:18 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:27:18 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:27:18 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:27:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:27:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:27:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:27:18 --> Final output sent to browser
DEBUG - 2022-03-10 23:27:18 --> Total execution time: 0.0589
ERROR - 2022-03-10 23:27:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:27:19 --> Config Class Initialized
INFO - 2022-03-10 23:27:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:27:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:27:19 --> Utf8 Class Initialized
INFO - 2022-03-10 23:27:19 --> URI Class Initialized
INFO - 2022-03-10 23:27:19 --> Router Class Initialized
INFO - 2022-03-10 23:27:19 --> Output Class Initialized
INFO - 2022-03-10 23:27:19 --> Security Class Initialized
DEBUG - 2022-03-10 23:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:27:19 --> Input Class Initialized
INFO - 2022-03-10 23:27:19 --> Language Class Initialized
INFO - 2022-03-10 23:27:19 --> Loader Class Initialized
INFO - 2022-03-10 23:27:19 --> Helper loaded: url_helper
INFO - 2022-03-10 23:27:19 --> Helper loaded: form_helper
INFO - 2022-03-10 23:27:19 --> Helper loaded: common_helper
INFO - 2022-03-10 23:27:19 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:27:19 --> Controller Class Initialized
INFO - 2022-03-10 23:27:19 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:27:19 --> Encrypt Class Initialized
INFO - 2022-03-10 23:27:19 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:27:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:27:19 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:27:19 --> Model "Users_model" initialized
INFO - 2022-03-10 23:27:19 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:27:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:27:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:27:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:27:20 --> Final output sent to browser
DEBUG - 2022-03-10 23:27:20 --> Total execution time: 0.2387
ERROR - 2022-03-10 23:27:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:27:29 --> Config Class Initialized
INFO - 2022-03-10 23:27:29 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:27:29 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:27:29 --> Utf8 Class Initialized
INFO - 2022-03-10 23:27:29 --> URI Class Initialized
INFO - 2022-03-10 23:27:29 --> Router Class Initialized
INFO - 2022-03-10 23:27:29 --> Output Class Initialized
INFO - 2022-03-10 23:27:29 --> Security Class Initialized
DEBUG - 2022-03-10 23:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:27:29 --> Input Class Initialized
INFO - 2022-03-10 23:27:29 --> Language Class Initialized
INFO - 2022-03-10 23:27:29 --> Loader Class Initialized
INFO - 2022-03-10 23:27:29 --> Helper loaded: url_helper
INFO - 2022-03-10 23:27:29 --> Helper loaded: form_helper
INFO - 2022-03-10 23:27:29 --> Helper loaded: common_helper
INFO - 2022-03-10 23:27:29 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:27:29 --> Controller Class Initialized
INFO - 2022-03-10 23:27:29 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:27:29 --> Encrypt Class Initialized
INFO - 2022-03-10 23:27:29 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:27:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:27:29 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:27:29 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:27:29 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:27:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:27:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:27:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:27:29 --> Final output sent to browser
DEBUG - 2022-03-10 23:27:29 --> Total execution time: 0.1381
ERROR - 2022-03-10 23:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:28:02 --> Config Class Initialized
INFO - 2022-03-10 23:28:02 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:28:02 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:28:02 --> Utf8 Class Initialized
INFO - 2022-03-10 23:28:02 --> URI Class Initialized
INFO - 2022-03-10 23:28:02 --> Router Class Initialized
INFO - 2022-03-10 23:28:02 --> Output Class Initialized
INFO - 2022-03-10 23:28:02 --> Security Class Initialized
DEBUG - 2022-03-10 23:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:28:02 --> Input Class Initialized
INFO - 2022-03-10 23:28:02 --> Language Class Initialized
INFO - 2022-03-10 23:28:02 --> Loader Class Initialized
INFO - 2022-03-10 23:28:02 --> Helper loaded: url_helper
INFO - 2022-03-10 23:28:02 --> Helper loaded: form_helper
INFO - 2022-03-10 23:28:02 --> Helper loaded: common_helper
INFO - 2022-03-10 23:28:02 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:28:02 --> Controller Class Initialized
INFO - 2022-03-10 23:28:02 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:28:02 --> Encrypt Class Initialized
INFO - 2022-03-10 23:28:02 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:28:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:28:02 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:28:02 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:28:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:28:03 --> Config Class Initialized
INFO - 2022-03-10 23:28:03 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:28:03 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:28:03 --> Utf8 Class Initialized
INFO - 2022-03-10 23:28:03 --> URI Class Initialized
INFO - 2022-03-10 23:28:03 --> Router Class Initialized
INFO - 2022-03-10 23:28:03 --> Output Class Initialized
INFO - 2022-03-10 23:28:03 --> Security Class Initialized
DEBUG - 2022-03-10 23:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:28:03 --> Input Class Initialized
INFO - 2022-03-10 23:28:03 --> Language Class Initialized
INFO - 2022-03-10 23:28:03 --> Loader Class Initialized
INFO - 2022-03-10 23:28:03 --> Helper loaded: url_helper
INFO - 2022-03-10 23:28:03 --> Helper loaded: form_helper
INFO - 2022-03-10 23:28:03 --> Helper loaded: common_helper
INFO - 2022-03-10 23:28:03 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:28:03 --> Controller Class Initialized
INFO - 2022-03-10 23:28:03 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:28:03 --> Encrypt Class Initialized
INFO - 2022-03-10 23:28:03 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:28:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:28:03 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:28:03 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:28:03 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:28:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:28:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:28:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:28:03 --> Final output sent to browser
DEBUG - 2022-03-10 23:28:03 --> Total execution time: 0.0611
ERROR - 2022-03-10 23:28:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:28:04 --> Config Class Initialized
INFO - 2022-03-10 23:28:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:28:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:28:04 --> Utf8 Class Initialized
INFO - 2022-03-10 23:28:04 --> URI Class Initialized
INFO - 2022-03-10 23:28:04 --> Router Class Initialized
INFO - 2022-03-10 23:28:04 --> Output Class Initialized
INFO - 2022-03-10 23:28:04 --> Security Class Initialized
DEBUG - 2022-03-10 23:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:28:04 --> Input Class Initialized
INFO - 2022-03-10 23:28:04 --> Language Class Initialized
INFO - 2022-03-10 23:28:04 --> Loader Class Initialized
INFO - 2022-03-10 23:28:04 --> Helper loaded: url_helper
INFO - 2022-03-10 23:28:04 --> Helper loaded: form_helper
INFO - 2022-03-10 23:28:04 --> Helper loaded: common_helper
INFO - 2022-03-10 23:28:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:28:04 --> Controller Class Initialized
INFO - 2022-03-10 23:28:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:28:04 --> Encrypt Class Initialized
INFO - 2022-03-10 23:28:04 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:28:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:28:04 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:28:04 --> Model "Users_model" initialized
INFO - 2022-03-10 23:28:04 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:28:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:28:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:28:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:28:04 --> Final output sent to browser
DEBUG - 2022-03-10 23:28:04 --> Total execution time: 0.0655
ERROR - 2022-03-10 23:29:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:29:54 --> Config Class Initialized
INFO - 2022-03-10 23:29:54 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:29:54 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:29:54 --> Utf8 Class Initialized
INFO - 2022-03-10 23:29:54 --> URI Class Initialized
INFO - 2022-03-10 23:29:54 --> Router Class Initialized
INFO - 2022-03-10 23:29:54 --> Output Class Initialized
INFO - 2022-03-10 23:29:54 --> Security Class Initialized
DEBUG - 2022-03-10 23:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:29:54 --> Input Class Initialized
INFO - 2022-03-10 23:29:54 --> Language Class Initialized
INFO - 2022-03-10 23:29:54 --> Loader Class Initialized
INFO - 2022-03-10 23:29:54 --> Helper loaded: url_helper
INFO - 2022-03-10 23:29:54 --> Helper loaded: form_helper
INFO - 2022-03-10 23:29:54 --> Helper loaded: common_helper
INFO - 2022-03-10 23:29:54 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:29:54 --> Controller Class Initialized
INFO - 2022-03-10 23:29:54 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:29:54 --> Encrypt Class Initialized
INFO - 2022-03-10 23:29:54 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:29:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:29:54 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:29:54 --> Model "Users_model" initialized
INFO - 2022-03-10 23:29:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:29:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:29:55 --> Config Class Initialized
INFO - 2022-03-10 23:29:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:29:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:29:55 --> Utf8 Class Initialized
INFO - 2022-03-10 23:29:55 --> URI Class Initialized
INFO - 2022-03-10 23:29:55 --> Router Class Initialized
INFO - 2022-03-10 23:29:55 --> Output Class Initialized
INFO - 2022-03-10 23:29:55 --> Security Class Initialized
DEBUG - 2022-03-10 23:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:29:55 --> Input Class Initialized
INFO - 2022-03-10 23:29:55 --> Language Class Initialized
INFO - 2022-03-10 23:29:55 --> Loader Class Initialized
INFO - 2022-03-10 23:29:55 --> Helper loaded: url_helper
INFO - 2022-03-10 23:29:55 --> Helper loaded: form_helper
INFO - 2022-03-10 23:29:55 --> Helper loaded: common_helper
INFO - 2022-03-10 23:29:55 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:29:55 --> Controller Class Initialized
INFO - 2022-03-10 23:29:55 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:29:55 --> Encrypt Class Initialized
INFO - 2022-03-10 23:29:55 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:29:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:29:55 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:29:55 --> Model "Users_model" initialized
INFO - 2022-03-10 23:29:55 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:29:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:29:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:29:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:29:55 --> Final output sent to browser
DEBUG - 2022-03-10 23:29:55 --> Total execution time: 0.0588
ERROR - 2022-03-10 23:30:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:30:27 --> Config Class Initialized
INFO - 2022-03-10 23:30:27 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:30:27 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:30:27 --> Utf8 Class Initialized
INFO - 2022-03-10 23:30:27 --> URI Class Initialized
INFO - 2022-03-10 23:30:27 --> Router Class Initialized
INFO - 2022-03-10 23:30:27 --> Output Class Initialized
INFO - 2022-03-10 23:30:27 --> Security Class Initialized
DEBUG - 2022-03-10 23:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:30:27 --> Input Class Initialized
INFO - 2022-03-10 23:30:27 --> Language Class Initialized
INFO - 2022-03-10 23:30:27 --> Loader Class Initialized
INFO - 2022-03-10 23:30:27 --> Helper loaded: url_helper
INFO - 2022-03-10 23:30:27 --> Helper loaded: form_helper
INFO - 2022-03-10 23:30:27 --> Helper loaded: common_helper
INFO - 2022-03-10 23:30:27 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:30:27 --> Controller Class Initialized
INFO - 2022-03-10 23:30:27 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:30:27 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:30:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:30:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:30:27 --> Email Class Initialized
INFO - 2022-03-10 23:30:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:30:27 --> Calendar Class Initialized
INFO - 2022-03-10 23:30:27 --> Model "Login_model" initialized
INFO - 2022-03-10 23:30:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 23:30:27 --> Final output sent to browser
DEBUG - 2022-03-10 23:30:27 --> Total execution time: 0.0290
ERROR - 2022-03-10 23:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:31:01 --> Config Class Initialized
INFO - 2022-03-10 23:31:01 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:31:01 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:31:01 --> Utf8 Class Initialized
INFO - 2022-03-10 23:31:01 --> URI Class Initialized
INFO - 2022-03-10 23:31:01 --> Router Class Initialized
INFO - 2022-03-10 23:31:01 --> Output Class Initialized
INFO - 2022-03-10 23:31:01 --> Security Class Initialized
DEBUG - 2022-03-10 23:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:31:01 --> Input Class Initialized
INFO - 2022-03-10 23:31:01 --> Language Class Initialized
INFO - 2022-03-10 23:31:01 --> Loader Class Initialized
INFO - 2022-03-10 23:31:01 --> Helper loaded: url_helper
INFO - 2022-03-10 23:31:01 --> Helper loaded: form_helper
INFO - 2022-03-10 23:31:01 --> Helper loaded: common_helper
INFO - 2022-03-10 23:31:01 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:31:01 --> Controller Class Initialized
INFO - 2022-03-10 23:31:01 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:31:01 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:31:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:31:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:31:01 --> Email Class Initialized
INFO - 2022-03-10 23:31:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:31:01 --> Calendar Class Initialized
INFO - 2022-03-10 23:31:01 --> Model "Login_model" initialized
INFO - 2022-03-10 23:31:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 23:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:31:02 --> Config Class Initialized
INFO - 2022-03-10 23:31:02 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:31:02 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:31:02 --> Utf8 Class Initialized
INFO - 2022-03-10 23:31:02 --> URI Class Initialized
INFO - 2022-03-10 23:31:02 --> Router Class Initialized
INFO - 2022-03-10 23:31:02 --> Output Class Initialized
INFO - 2022-03-10 23:31:02 --> Security Class Initialized
DEBUG - 2022-03-10 23:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:31:02 --> Input Class Initialized
INFO - 2022-03-10 23:31:02 --> Language Class Initialized
INFO - 2022-03-10 23:31:02 --> Loader Class Initialized
INFO - 2022-03-10 23:31:02 --> Helper loaded: url_helper
INFO - 2022-03-10 23:31:02 --> Helper loaded: form_helper
INFO - 2022-03-10 23:31:02 --> Helper loaded: common_helper
INFO - 2022-03-10 23:31:02 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:31:02 --> Controller Class Initialized
INFO - 2022-03-10 23:31:02 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:31:02 --> Encrypt Class Initialized
INFO - 2022-03-10 23:31:02 --> Model "Login_model" initialized
INFO - 2022-03-10 23:31:02 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 23:31:02 --> Model "Case_model" initialized
INFO - 2022-03-10 23:31:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:31:02 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 23:31:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:31:02 --> Final output sent to browser
DEBUG - 2022-03-10 23:31:02 --> Total execution time: 0.1563
ERROR - 2022-03-10 23:31:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:31:23 --> Config Class Initialized
INFO - 2022-03-10 23:31:23 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:31:23 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:31:23 --> Utf8 Class Initialized
INFO - 2022-03-10 23:31:23 --> URI Class Initialized
INFO - 2022-03-10 23:31:23 --> Router Class Initialized
INFO - 2022-03-10 23:31:23 --> Output Class Initialized
INFO - 2022-03-10 23:31:23 --> Security Class Initialized
DEBUG - 2022-03-10 23:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:31:23 --> Input Class Initialized
INFO - 2022-03-10 23:31:23 --> Language Class Initialized
INFO - 2022-03-10 23:31:23 --> Loader Class Initialized
INFO - 2022-03-10 23:31:23 --> Helper loaded: url_helper
INFO - 2022-03-10 23:31:23 --> Helper loaded: form_helper
INFO - 2022-03-10 23:31:23 --> Helper loaded: common_helper
INFO - 2022-03-10 23:31:23 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:31:23 --> Controller Class Initialized
INFO - 2022-03-10 23:31:23 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:31:23 --> Encrypt Class Initialized
INFO - 2022-03-10 23:31:23 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:31:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:31:23 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:31:23 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:31:23 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:31:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:31:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:31:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:31:23 --> Final output sent to browser
DEBUG - 2022-03-10 23:31:23 --> Total execution time: 0.0595
ERROR - 2022-03-10 23:31:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:31:33 --> Config Class Initialized
INFO - 2022-03-10 23:31:33 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:31:33 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:31:33 --> Utf8 Class Initialized
INFO - 2022-03-10 23:31:33 --> URI Class Initialized
INFO - 2022-03-10 23:31:33 --> Router Class Initialized
INFO - 2022-03-10 23:31:33 --> Output Class Initialized
INFO - 2022-03-10 23:31:33 --> Security Class Initialized
DEBUG - 2022-03-10 23:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:31:33 --> Input Class Initialized
INFO - 2022-03-10 23:31:33 --> Language Class Initialized
INFO - 2022-03-10 23:31:33 --> Loader Class Initialized
INFO - 2022-03-10 23:31:33 --> Helper loaded: url_helper
INFO - 2022-03-10 23:31:33 --> Helper loaded: form_helper
INFO - 2022-03-10 23:31:33 --> Helper loaded: common_helper
INFO - 2022-03-10 23:31:33 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:31:33 --> Controller Class Initialized
INFO - 2022-03-10 23:31:33 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:31:33 --> Encrypt Class Initialized
INFO - 2022-03-10 23:31:33 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:31:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:31:33 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:31:33 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:31:33 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:31:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:31:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:31:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:31:33 --> Final output sent to browser
DEBUG - 2022-03-10 23:31:33 --> Total execution time: 0.0463
ERROR - 2022-03-10 23:31:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:31:46 --> Config Class Initialized
INFO - 2022-03-10 23:31:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:31:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:31:46 --> Utf8 Class Initialized
INFO - 2022-03-10 23:31:46 --> URI Class Initialized
INFO - 2022-03-10 23:31:46 --> Router Class Initialized
INFO - 2022-03-10 23:31:46 --> Output Class Initialized
INFO - 2022-03-10 23:31:46 --> Security Class Initialized
DEBUG - 2022-03-10 23:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:31:46 --> Input Class Initialized
INFO - 2022-03-10 23:31:46 --> Language Class Initialized
INFO - 2022-03-10 23:31:46 --> Loader Class Initialized
INFO - 2022-03-10 23:31:46 --> Helper loaded: url_helper
INFO - 2022-03-10 23:31:46 --> Helper loaded: form_helper
INFO - 2022-03-10 23:31:46 --> Helper loaded: common_helper
INFO - 2022-03-10 23:31:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:31:46 --> Controller Class Initialized
INFO - 2022-03-10 23:31:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:31:46 --> Encrypt Class Initialized
INFO - 2022-03-10 23:31:46 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:31:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:31:46 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:31:46 --> Model "Users_model" initialized
INFO - 2022-03-10 23:31:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:31:47 --> Config Class Initialized
INFO - 2022-03-10 23:31:47 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:31:47 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:31:47 --> Utf8 Class Initialized
INFO - 2022-03-10 23:31:47 --> URI Class Initialized
INFO - 2022-03-10 23:31:47 --> Router Class Initialized
INFO - 2022-03-10 23:31:47 --> Output Class Initialized
INFO - 2022-03-10 23:31:47 --> Security Class Initialized
DEBUG - 2022-03-10 23:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:31:47 --> Input Class Initialized
INFO - 2022-03-10 23:31:47 --> Language Class Initialized
INFO - 2022-03-10 23:31:47 --> Loader Class Initialized
INFO - 2022-03-10 23:31:47 --> Helper loaded: url_helper
INFO - 2022-03-10 23:31:47 --> Helper loaded: form_helper
INFO - 2022-03-10 23:31:47 --> Helper loaded: common_helper
INFO - 2022-03-10 23:31:47 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:31:47 --> Controller Class Initialized
INFO - 2022-03-10 23:31:47 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:31:47 --> Encrypt Class Initialized
INFO - 2022-03-10 23:31:47 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:31:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:31:47 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:31:47 --> Model "Users_model" initialized
INFO - 2022-03-10 23:31:47 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:31:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:31:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:31:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:31:47 --> Final output sent to browser
DEBUG - 2022-03-10 23:31:47 --> Total execution time: 0.0705
ERROR - 2022-03-10 23:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:31:53 --> Config Class Initialized
INFO - 2022-03-10 23:31:53 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:31:53 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:31:53 --> Utf8 Class Initialized
INFO - 2022-03-10 23:31:53 --> URI Class Initialized
INFO - 2022-03-10 23:31:53 --> Router Class Initialized
INFO - 2022-03-10 23:31:53 --> Output Class Initialized
INFO - 2022-03-10 23:31:53 --> Security Class Initialized
DEBUG - 2022-03-10 23:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:31:53 --> Input Class Initialized
INFO - 2022-03-10 23:31:53 --> Language Class Initialized
INFO - 2022-03-10 23:31:53 --> Loader Class Initialized
INFO - 2022-03-10 23:31:53 --> Helper loaded: url_helper
INFO - 2022-03-10 23:31:53 --> Helper loaded: form_helper
INFO - 2022-03-10 23:31:53 --> Helper loaded: common_helper
INFO - 2022-03-10 23:31:53 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:31:53 --> Controller Class Initialized
INFO - 2022-03-10 23:31:53 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:31:53 --> Encrypt Class Initialized
INFO - 2022-03-10 23:31:53 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:31:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:31:53 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:31:53 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:31:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:31:54 --> Config Class Initialized
INFO - 2022-03-10 23:31:54 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:31:54 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:31:54 --> Utf8 Class Initialized
INFO - 2022-03-10 23:31:54 --> URI Class Initialized
INFO - 2022-03-10 23:31:54 --> Router Class Initialized
INFO - 2022-03-10 23:31:54 --> Output Class Initialized
INFO - 2022-03-10 23:31:54 --> Security Class Initialized
DEBUG - 2022-03-10 23:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:31:54 --> Input Class Initialized
INFO - 2022-03-10 23:31:54 --> Language Class Initialized
INFO - 2022-03-10 23:31:54 --> Loader Class Initialized
INFO - 2022-03-10 23:31:54 --> Helper loaded: url_helper
INFO - 2022-03-10 23:31:54 --> Helper loaded: form_helper
INFO - 2022-03-10 23:31:54 --> Helper loaded: common_helper
INFO - 2022-03-10 23:31:54 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:31:54 --> Controller Class Initialized
INFO - 2022-03-10 23:31:54 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:31:54 --> Encrypt Class Initialized
INFO - 2022-03-10 23:31:54 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:31:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:31:54 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:31:54 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:31:54 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:31:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:31:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:31:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:31:54 --> Final output sent to browser
DEBUG - 2022-03-10 23:31:54 --> Total execution time: 0.0406
ERROR - 2022-03-10 23:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:31:55 --> Config Class Initialized
INFO - 2022-03-10 23:31:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:31:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:31:55 --> Utf8 Class Initialized
INFO - 2022-03-10 23:31:55 --> URI Class Initialized
INFO - 2022-03-10 23:31:55 --> Router Class Initialized
INFO - 2022-03-10 23:31:55 --> Output Class Initialized
INFO - 2022-03-10 23:31:55 --> Security Class Initialized
DEBUG - 2022-03-10 23:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:31:55 --> Input Class Initialized
INFO - 2022-03-10 23:31:55 --> Language Class Initialized
INFO - 2022-03-10 23:31:55 --> Loader Class Initialized
INFO - 2022-03-10 23:31:55 --> Helper loaded: url_helper
INFO - 2022-03-10 23:31:55 --> Helper loaded: form_helper
INFO - 2022-03-10 23:31:55 --> Helper loaded: common_helper
INFO - 2022-03-10 23:31:55 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:31:55 --> Controller Class Initialized
INFO - 2022-03-10 23:31:55 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:31:55 --> Encrypt Class Initialized
INFO - 2022-03-10 23:31:55 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:31:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:31:55 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:31:55 --> Model "Users_model" initialized
INFO - 2022-03-10 23:31:55 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:31:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:31:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:31:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:31:55 --> Final output sent to browser
DEBUG - 2022-03-10 23:31:55 --> Total execution time: 0.0578
ERROR - 2022-03-10 23:34:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:34:17 --> Config Class Initialized
INFO - 2022-03-10 23:34:17 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:34:17 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:34:17 --> Utf8 Class Initialized
INFO - 2022-03-10 23:34:17 --> URI Class Initialized
INFO - 2022-03-10 23:34:17 --> Router Class Initialized
INFO - 2022-03-10 23:34:17 --> Output Class Initialized
INFO - 2022-03-10 23:34:17 --> Security Class Initialized
DEBUG - 2022-03-10 23:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:34:17 --> Input Class Initialized
INFO - 2022-03-10 23:34:17 --> Language Class Initialized
INFO - 2022-03-10 23:34:17 --> Loader Class Initialized
INFO - 2022-03-10 23:34:17 --> Helper loaded: url_helper
INFO - 2022-03-10 23:34:17 --> Helper loaded: form_helper
INFO - 2022-03-10 23:34:17 --> Helper loaded: common_helper
INFO - 2022-03-10 23:34:17 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:34:17 --> Controller Class Initialized
INFO - 2022-03-10 23:34:17 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:34:17 --> Encrypt Class Initialized
INFO - 2022-03-10 23:34:17 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:34:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:34:17 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:34:17 --> Model "Users_model" initialized
INFO - 2022-03-10 23:34:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:34:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:34:18 --> Config Class Initialized
INFO - 2022-03-10 23:34:18 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:34:18 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:34:18 --> Utf8 Class Initialized
INFO - 2022-03-10 23:34:18 --> URI Class Initialized
INFO - 2022-03-10 23:34:18 --> Router Class Initialized
INFO - 2022-03-10 23:34:18 --> Output Class Initialized
INFO - 2022-03-10 23:34:18 --> Security Class Initialized
DEBUG - 2022-03-10 23:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:34:18 --> Input Class Initialized
INFO - 2022-03-10 23:34:18 --> Language Class Initialized
INFO - 2022-03-10 23:34:18 --> Loader Class Initialized
INFO - 2022-03-10 23:34:18 --> Helper loaded: url_helper
INFO - 2022-03-10 23:34:18 --> Helper loaded: form_helper
INFO - 2022-03-10 23:34:18 --> Helper loaded: common_helper
INFO - 2022-03-10 23:34:18 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:34:18 --> Controller Class Initialized
INFO - 2022-03-10 23:34:18 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:34:18 --> Encrypt Class Initialized
INFO - 2022-03-10 23:34:18 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:34:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:34:18 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:34:18 --> Model "Users_model" initialized
INFO - 2022-03-10 23:34:18 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:34:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:34:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:34:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:34:18 --> Final output sent to browser
DEBUG - 2022-03-10 23:34:18 --> Total execution time: 0.0756
ERROR - 2022-03-10 23:34:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:34:18 --> Config Class Initialized
INFO - 2022-03-10 23:34:18 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:34:18 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:34:18 --> Utf8 Class Initialized
INFO - 2022-03-10 23:34:18 --> URI Class Initialized
INFO - 2022-03-10 23:34:18 --> Router Class Initialized
INFO - 2022-03-10 23:34:18 --> Output Class Initialized
INFO - 2022-03-10 23:34:18 --> Security Class Initialized
DEBUG - 2022-03-10 23:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:34:18 --> Input Class Initialized
INFO - 2022-03-10 23:34:18 --> Language Class Initialized
INFO - 2022-03-10 23:34:18 --> Loader Class Initialized
INFO - 2022-03-10 23:34:18 --> Helper loaded: url_helper
INFO - 2022-03-10 23:34:18 --> Helper loaded: form_helper
INFO - 2022-03-10 23:34:18 --> Helper loaded: common_helper
INFO - 2022-03-10 23:34:18 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:34:18 --> Controller Class Initialized
INFO - 2022-03-10 23:34:18 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:34:18 --> Encrypt Class Initialized
INFO - 2022-03-10 23:34:18 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:34:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:34:18 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:34:18 --> Model "Users_model" initialized
INFO - 2022-03-10 23:34:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:34:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:34:19 --> Config Class Initialized
INFO - 2022-03-10 23:34:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:34:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:34:19 --> Utf8 Class Initialized
INFO - 2022-03-10 23:34:19 --> URI Class Initialized
INFO - 2022-03-10 23:34:19 --> Router Class Initialized
INFO - 2022-03-10 23:34:19 --> Output Class Initialized
INFO - 2022-03-10 23:34:19 --> Security Class Initialized
DEBUG - 2022-03-10 23:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:34:19 --> Input Class Initialized
INFO - 2022-03-10 23:34:19 --> Language Class Initialized
INFO - 2022-03-10 23:34:19 --> Loader Class Initialized
INFO - 2022-03-10 23:34:19 --> Helper loaded: url_helper
INFO - 2022-03-10 23:34:19 --> Helper loaded: form_helper
INFO - 2022-03-10 23:34:19 --> Helper loaded: common_helper
INFO - 2022-03-10 23:34:19 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:34:19 --> Controller Class Initialized
INFO - 2022-03-10 23:34:19 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:34:19 --> Encrypt Class Initialized
INFO - 2022-03-10 23:34:19 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:34:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:34:19 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:34:19 --> Model "Users_model" initialized
INFO - 2022-03-10 23:34:19 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:34:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:34:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:34:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:34:19 --> Final output sent to browser
DEBUG - 2022-03-10 23:34:19 --> Total execution time: 0.0986
ERROR - 2022-03-10 23:36:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:36:36 --> Config Class Initialized
INFO - 2022-03-10 23:36:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:36:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:36:36 --> Utf8 Class Initialized
INFO - 2022-03-10 23:36:36 --> URI Class Initialized
INFO - 2022-03-10 23:36:36 --> Router Class Initialized
INFO - 2022-03-10 23:36:36 --> Output Class Initialized
INFO - 2022-03-10 23:36:36 --> Security Class Initialized
DEBUG - 2022-03-10 23:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:36:36 --> Input Class Initialized
INFO - 2022-03-10 23:36:36 --> Language Class Initialized
INFO - 2022-03-10 23:36:36 --> Loader Class Initialized
INFO - 2022-03-10 23:36:36 --> Helper loaded: url_helper
INFO - 2022-03-10 23:36:36 --> Helper loaded: form_helper
INFO - 2022-03-10 23:36:36 --> Helper loaded: common_helper
INFO - 2022-03-10 23:36:36 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:36:36 --> Controller Class Initialized
INFO - 2022-03-10 23:36:36 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:36:36 --> Encrypt Class Initialized
INFO - 2022-03-10 23:36:36 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:36:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:36:36 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:36:36 --> Model "Users_model" initialized
INFO - 2022-03-10 23:36:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:36:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:36:36 --> Config Class Initialized
INFO - 2022-03-10 23:36:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:36:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:36:36 --> Utf8 Class Initialized
INFO - 2022-03-10 23:36:36 --> URI Class Initialized
INFO - 2022-03-10 23:36:36 --> Router Class Initialized
INFO - 2022-03-10 23:36:36 --> Output Class Initialized
INFO - 2022-03-10 23:36:36 --> Security Class Initialized
DEBUG - 2022-03-10 23:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:36:36 --> Input Class Initialized
INFO - 2022-03-10 23:36:36 --> Language Class Initialized
INFO - 2022-03-10 23:36:36 --> Loader Class Initialized
INFO - 2022-03-10 23:36:36 --> Helper loaded: url_helper
INFO - 2022-03-10 23:36:36 --> Helper loaded: form_helper
INFO - 2022-03-10 23:36:36 --> Helper loaded: common_helper
INFO - 2022-03-10 23:36:36 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:36:36 --> Controller Class Initialized
INFO - 2022-03-10 23:36:36 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:36:36 --> Encrypt Class Initialized
INFO - 2022-03-10 23:36:36 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:36:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:36:36 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:36:36 --> Model "Users_model" initialized
INFO - 2022-03-10 23:36:36 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:36:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:36:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:36:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:36:37 --> Final output sent to browser
DEBUG - 2022-03-10 23:36:37 --> Total execution time: 0.0653
ERROR - 2022-03-10 23:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:37:05 --> Config Class Initialized
INFO - 2022-03-10 23:37:05 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:37:05 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:37:05 --> Utf8 Class Initialized
INFO - 2022-03-10 23:37:05 --> URI Class Initialized
INFO - 2022-03-10 23:37:05 --> Router Class Initialized
INFO - 2022-03-10 23:37:05 --> Output Class Initialized
INFO - 2022-03-10 23:37:05 --> Security Class Initialized
DEBUG - 2022-03-10 23:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:37:05 --> Input Class Initialized
INFO - 2022-03-10 23:37:05 --> Language Class Initialized
INFO - 2022-03-10 23:37:05 --> Loader Class Initialized
INFO - 2022-03-10 23:37:05 --> Helper loaded: url_helper
INFO - 2022-03-10 23:37:05 --> Helper loaded: form_helper
INFO - 2022-03-10 23:37:05 --> Helper loaded: common_helper
INFO - 2022-03-10 23:37:05 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:37:05 --> Controller Class Initialized
INFO - 2022-03-10 23:37:05 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:37:05 --> Encrypt Class Initialized
INFO - 2022-03-10 23:37:05 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:37:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:37:05 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:37:05 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:37:05 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:37:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:37:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:37:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-10 23:37:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:37:13 --> Config Class Initialized
INFO - 2022-03-10 23:37:13 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:37:13 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:37:13 --> Utf8 Class Initialized
INFO - 2022-03-10 23:37:13 --> URI Class Initialized
INFO - 2022-03-10 23:37:13 --> Router Class Initialized
INFO - 2022-03-10 23:37:13 --> Output Class Initialized
INFO - 2022-03-10 23:37:13 --> Security Class Initialized
DEBUG - 2022-03-10 23:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:37:13 --> Input Class Initialized
INFO - 2022-03-10 23:37:13 --> Language Class Initialized
ERROR - 2022-03-10 23:37:13 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-10 23:37:16 --> Final output sent to browser
DEBUG - 2022-03-10 23:37:16 --> Total execution time: 6.9870
ERROR - 2022-03-10 23:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:37:37 --> Config Class Initialized
INFO - 2022-03-10 23:37:37 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:37:37 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:37:37 --> Utf8 Class Initialized
INFO - 2022-03-10 23:37:37 --> URI Class Initialized
INFO - 2022-03-10 23:37:37 --> Router Class Initialized
INFO - 2022-03-10 23:37:37 --> Output Class Initialized
INFO - 2022-03-10 23:37:37 --> Security Class Initialized
DEBUG - 2022-03-10 23:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:37:37 --> Input Class Initialized
INFO - 2022-03-10 23:37:37 --> Language Class Initialized
INFO - 2022-03-10 23:37:37 --> Loader Class Initialized
INFO - 2022-03-10 23:37:37 --> Helper loaded: url_helper
INFO - 2022-03-10 23:37:37 --> Helper loaded: form_helper
INFO - 2022-03-10 23:37:37 --> Helper loaded: common_helper
INFO - 2022-03-10 23:37:37 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:37:37 --> Controller Class Initialized
INFO - 2022-03-10 23:37:37 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:37:37 --> Encrypt Class Initialized
INFO - 2022-03-10 23:37:37 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:37:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:37:37 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:37:37 --> Model "Users_model" initialized
INFO - 2022-03-10 23:37:37 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:37:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:37:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:37:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:37:37 --> Final output sent to browser
DEBUG - 2022-03-10 23:37:37 --> Total execution time: 0.0590
ERROR - 2022-03-10 23:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:37:38 --> Config Class Initialized
INFO - 2022-03-10 23:37:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:37:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:37:38 --> Utf8 Class Initialized
INFO - 2022-03-10 23:37:38 --> URI Class Initialized
INFO - 2022-03-10 23:37:38 --> Router Class Initialized
INFO - 2022-03-10 23:37:38 --> Output Class Initialized
INFO - 2022-03-10 23:37:38 --> Security Class Initialized
DEBUG - 2022-03-10 23:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:37:38 --> Input Class Initialized
INFO - 2022-03-10 23:37:38 --> Language Class Initialized
ERROR - 2022-03-10 23:37:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 23:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:37:45 --> Config Class Initialized
INFO - 2022-03-10 23:37:45 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:37:45 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:37:45 --> Utf8 Class Initialized
INFO - 2022-03-10 23:37:45 --> URI Class Initialized
INFO - 2022-03-10 23:37:45 --> Router Class Initialized
INFO - 2022-03-10 23:37:45 --> Output Class Initialized
INFO - 2022-03-10 23:37:45 --> Security Class Initialized
DEBUG - 2022-03-10 23:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:37:45 --> Input Class Initialized
INFO - 2022-03-10 23:37:45 --> Language Class Initialized
ERROR - 2022-03-10 23:37:45 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 23:37:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:37:53 --> Config Class Initialized
INFO - 2022-03-10 23:37:53 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:37:53 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:37:53 --> Utf8 Class Initialized
INFO - 2022-03-10 23:37:53 --> URI Class Initialized
INFO - 2022-03-10 23:37:53 --> Router Class Initialized
INFO - 2022-03-10 23:37:53 --> Output Class Initialized
INFO - 2022-03-10 23:37:53 --> Security Class Initialized
DEBUG - 2022-03-10 23:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:37:53 --> Input Class Initialized
INFO - 2022-03-10 23:37:53 --> Language Class Initialized
ERROR - 2022-03-10 23:37:53 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 23:38:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:38:28 --> Config Class Initialized
INFO - 2022-03-10 23:38:28 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:38:28 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:38:28 --> Utf8 Class Initialized
INFO - 2022-03-10 23:38:28 --> URI Class Initialized
INFO - 2022-03-10 23:38:28 --> Router Class Initialized
INFO - 2022-03-10 23:38:28 --> Output Class Initialized
INFO - 2022-03-10 23:38:28 --> Security Class Initialized
DEBUG - 2022-03-10 23:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:38:28 --> Input Class Initialized
INFO - 2022-03-10 23:38:28 --> Language Class Initialized
INFO - 2022-03-10 23:38:28 --> Loader Class Initialized
INFO - 2022-03-10 23:38:28 --> Helper loaded: url_helper
INFO - 2022-03-10 23:38:28 --> Helper loaded: form_helper
INFO - 2022-03-10 23:38:28 --> Helper loaded: common_helper
INFO - 2022-03-10 23:38:28 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:38:28 --> Controller Class Initialized
INFO - 2022-03-10 23:38:28 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:38:28 --> Encrypt Class Initialized
INFO - 2022-03-10 23:38:28 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:38:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:38:28 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:38:28 --> Model "Users_model" initialized
INFO - 2022-03-10 23:38:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:38:29 --> Config Class Initialized
INFO - 2022-03-10 23:38:29 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:38:29 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:38:29 --> Utf8 Class Initialized
INFO - 2022-03-10 23:38:29 --> URI Class Initialized
INFO - 2022-03-10 23:38:29 --> Router Class Initialized
INFO - 2022-03-10 23:38:29 --> Output Class Initialized
INFO - 2022-03-10 23:38:29 --> Security Class Initialized
DEBUG - 2022-03-10 23:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:38:29 --> Input Class Initialized
INFO - 2022-03-10 23:38:29 --> Language Class Initialized
INFO - 2022-03-10 23:38:29 --> Loader Class Initialized
INFO - 2022-03-10 23:38:29 --> Helper loaded: url_helper
INFO - 2022-03-10 23:38:29 --> Helper loaded: form_helper
INFO - 2022-03-10 23:38:29 --> Helper loaded: common_helper
INFO - 2022-03-10 23:38:29 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:38:29 --> Controller Class Initialized
INFO - 2022-03-10 23:38:29 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:38:29 --> Encrypt Class Initialized
INFO - 2022-03-10 23:38:29 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:38:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:38:29 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:38:29 --> Model "Users_model" initialized
INFO - 2022-03-10 23:38:29 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:38:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:38:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:38:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:38:29 --> Final output sent to browser
DEBUG - 2022-03-10 23:38:29 --> Total execution time: 0.0625
ERROR - 2022-03-10 23:39:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:39:04 --> Config Class Initialized
INFO - 2022-03-10 23:39:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:39:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:39:04 --> Utf8 Class Initialized
INFO - 2022-03-10 23:39:04 --> URI Class Initialized
INFO - 2022-03-10 23:39:04 --> Router Class Initialized
INFO - 2022-03-10 23:39:04 --> Output Class Initialized
INFO - 2022-03-10 23:39:04 --> Security Class Initialized
DEBUG - 2022-03-10 23:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:39:04 --> Input Class Initialized
INFO - 2022-03-10 23:39:04 --> Language Class Initialized
INFO - 2022-03-10 23:39:04 --> Loader Class Initialized
INFO - 2022-03-10 23:39:04 --> Helper loaded: url_helper
INFO - 2022-03-10 23:39:04 --> Helper loaded: form_helper
INFO - 2022-03-10 23:39:04 --> Helper loaded: common_helper
INFO - 2022-03-10 23:39:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:39:04 --> Controller Class Initialized
INFO - 2022-03-10 23:39:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:39:04 --> Encrypt Class Initialized
INFO - 2022-03-10 23:39:04 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:39:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:39:04 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:39:04 --> Model "Users_model" initialized
INFO - 2022-03-10 23:39:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:39:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:39:04 --> Config Class Initialized
INFO - 2022-03-10 23:39:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:39:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:39:04 --> Utf8 Class Initialized
INFO - 2022-03-10 23:39:04 --> URI Class Initialized
INFO - 2022-03-10 23:39:04 --> Router Class Initialized
INFO - 2022-03-10 23:39:04 --> Output Class Initialized
INFO - 2022-03-10 23:39:04 --> Security Class Initialized
DEBUG - 2022-03-10 23:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:39:04 --> Input Class Initialized
INFO - 2022-03-10 23:39:04 --> Language Class Initialized
INFO - 2022-03-10 23:39:04 --> Loader Class Initialized
INFO - 2022-03-10 23:39:04 --> Helper loaded: url_helper
INFO - 2022-03-10 23:39:04 --> Helper loaded: form_helper
INFO - 2022-03-10 23:39:04 --> Helper loaded: common_helper
INFO - 2022-03-10 23:39:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:39:04 --> Controller Class Initialized
INFO - 2022-03-10 23:39:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:39:04 --> Encrypt Class Initialized
INFO - 2022-03-10 23:39:04 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:39:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:39:04 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:39:04 --> Model "Users_model" initialized
INFO - 2022-03-10 23:39:04 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:39:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:39:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:39:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:39:05 --> Final output sent to browser
DEBUG - 2022-03-10 23:39:05 --> Total execution time: 0.0872
ERROR - 2022-03-10 23:39:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:39:36 --> Config Class Initialized
INFO - 2022-03-10 23:39:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:39:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:39:36 --> Utf8 Class Initialized
INFO - 2022-03-10 23:39:36 --> URI Class Initialized
INFO - 2022-03-10 23:39:36 --> Router Class Initialized
INFO - 2022-03-10 23:39:36 --> Output Class Initialized
INFO - 2022-03-10 23:39:36 --> Security Class Initialized
DEBUG - 2022-03-10 23:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:39:36 --> Input Class Initialized
INFO - 2022-03-10 23:39:36 --> Language Class Initialized
INFO - 2022-03-10 23:39:36 --> Loader Class Initialized
INFO - 2022-03-10 23:39:36 --> Helper loaded: url_helper
INFO - 2022-03-10 23:39:36 --> Helper loaded: form_helper
INFO - 2022-03-10 23:39:36 --> Helper loaded: common_helper
INFO - 2022-03-10 23:39:36 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:39:36 --> Controller Class Initialized
INFO - 2022-03-10 23:39:36 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:39:36 --> Encrypt Class Initialized
INFO - 2022-03-10 23:39:36 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:39:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:39:36 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:39:36 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:39:36 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:39:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:39:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:39:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:39:36 --> Final output sent to browser
DEBUG - 2022-03-10 23:39:36 --> Total execution time: 0.0601
ERROR - 2022-03-10 23:39:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:39:44 --> Config Class Initialized
INFO - 2022-03-10 23:39:44 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:39:44 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:39:44 --> Utf8 Class Initialized
INFO - 2022-03-10 23:39:44 --> URI Class Initialized
INFO - 2022-03-10 23:39:44 --> Router Class Initialized
INFO - 2022-03-10 23:39:44 --> Output Class Initialized
INFO - 2022-03-10 23:39:44 --> Security Class Initialized
DEBUG - 2022-03-10 23:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:39:44 --> Input Class Initialized
INFO - 2022-03-10 23:39:44 --> Language Class Initialized
INFO - 2022-03-10 23:39:44 --> Loader Class Initialized
INFO - 2022-03-10 23:39:44 --> Helper loaded: url_helper
INFO - 2022-03-10 23:39:44 --> Helper loaded: form_helper
INFO - 2022-03-10 23:39:44 --> Helper loaded: common_helper
INFO - 2022-03-10 23:39:44 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:39:44 --> Controller Class Initialized
INFO - 2022-03-10 23:39:44 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:39:44 --> Encrypt Class Initialized
INFO - 2022-03-10 23:39:44 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:39:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:39:44 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:39:44 --> Model "Users_model" initialized
INFO - 2022-03-10 23:39:44 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:39:44 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-10 23:39:45 --> Final output sent to browser
DEBUG - 2022-03-10 23:39:45 --> Total execution time: 0.9701
ERROR - 2022-03-10 23:39:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:39:55 --> Config Class Initialized
INFO - 2022-03-10 23:39:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:39:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:39:55 --> Utf8 Class Initialized
INFO - 2022-03-10 23:39:55 --> URI Class Initialized
INFO - 2022-03-10 23:39:55 --> Router Class Initialized
INFO - 2022-03-10 23:39:55 --> Output Class Initialized
INFO - 2022-03-10 23:39:55 --> Security Class Initialized
DEBUG - 2022-03-10 23:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:39:55 --> Input Class Initialized
INFO - 2022-03-10 23:39:55 --> Language Class Initialized
INFO - 2022-03-10 23:39:55 --> Loader Class Initialized
INFO - 2022-03-10 23:39:55 --> Helper loaded: url_helper
INFO - 2022-03-10 23:39:55 --> Helper loaded: form_helper
INFO - 2022-03-10 23:39:55 --> Helper loaded: common_helper
INFO - 2022-03-10 23:39:55 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:39:55 --> Controller Class Initialized
INFO - 2022-03-10 23:39:55 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:39:55 --> Encrypt Class Initialized
INFO - 2022-03-10 23:39:55 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:39:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:39:55 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:39:55 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:39:55 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:39:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:39:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:39:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:39:55 --> Final output sent to browser
DEBUG - 2022-03-10 23:39:55 --> Total execution time: 0.0637
ERROR - 2022-03-10 23:40:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:09 --> Config Class Initialized
INFO - 2022-03-10 23:40:09 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:09 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:09 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:09 --> URI Class Initialized
INFO - 2022-03-10 23:40:09 --> Router Class Initialized
INFO - 2022-03-10 23:40:09 --> Output Class Initialized
INFO - 2022-03-10 23:40:09 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:09 --> Input Class Initialized
INFO - 2022-03-10 23:40:09 --> Language Class Initialized
INFO - 2022-03-10 23:40:09 --> Loader Class Initialized
INFO - 2022-03-10 23:40:09 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:09 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:09 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:09 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:09 --> Controller Class Initialized
INFO - 2022-03-10 23:40:09 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:09 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:09 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:09 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:40:09 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:09 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:40:09 --> Upload Class Initialized
INFO - 2022-03-10 23:40:09 --> Final output sent to browser
DEBUG - 2022-03-10 23:40:09 --> Total execution time: 0.0241
ERROR - 2022-03-10 23:40:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:10 --> Config Class Initialized
INFO - 2022-03-10 23:40:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:10 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:10 --> URI Class Initialized
INFO - 2022-03-10 23:40:10 --> Router Class Initialized
INFO - 2022-03-10 23:40:10 --> Output Class Initialized
INFO - 2022-03-10 23:40:10 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:10 --> Input Class Initialized
INFO - 2022-03-10 23:40:10 --> Language Class Initialized
INFO - 2022-03-10 23:40:10 --> Loader Class Initialized
INFO - 2022-03-10 23:40:10 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:10 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:10 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:10 --> Controller Class Initialized
INFO - 2022-03-10 23:40:10 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:10 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:10 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:10 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:40:10 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:10 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:40:10 --> Upload Class Initialized
INFO - 2022-03-10 23:40:10 --> Final output sent to browser
DEBUG - 2022-03-10 23:40:10 --> Total execution time: 0.0233
ERROR - 2022-03-10 23:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:16 --> Config Class Initialized
INFO - 2022-03-10 23:40:16 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:16 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:16 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:16 --> URI Class Initialized
INFO - 2022-03-10 23:40:16 --> Router Class Initialized
INFO - 2022-03-10 23:40:16 --> Output Class Initialized
INFO - 2022-03-10 23:40:16 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:16 --> Input Class Initialized
INFO - 2022-03-10 23:40:16 --> Language Class Initialized
INFO - 2022-03-10 23:40:16 --> Loader Class Initialized
INFO - 2022-03-10 23:40:16 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:16 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:16 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:16 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:16 --> Controller Class Initialized
INFO - 2022-03-10 23:40:16 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:16 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:16 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:16 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:40:16 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:16 --> Config Class Initialized
INFO - 2022-03-10 23:40:16 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:16 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:16 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:16 --> URI Class Initialized
INFO - 2022-03-10 23:40:16 --> Router Class Initialized
INFO - 2022-03-10 23:40:16 --> Output Class Initialized
INFO - 2022-03-10 23:40:16 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:16 --> Input Class Initialized
INFO - 2022-03-10 23:40:16 --> Language Class Initialized
INFO - 2022-03-10 23:40:16 --> Loader Class Initialized
INFO - 2022-03-10 23:40:16 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:16 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:16 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:16 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:16 --> Controller Class Initialized
INFO - 2022-03-10 23:40:16 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:16 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:16 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:16 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:40:16 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:16 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:40:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:40:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:40:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:40:16 --> Final output sent to browser
DEBUG - 2022-03-10 23:40:16 --> Total execution time: 0.0532
ERROR - 2022-03-10 23:40:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:18 --> Config Class Initialized
INFO - 2022-03-10 23:40:18 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:18 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:18 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:18 --> URI Class Initialized
INFO - 2022-03-10 23:40:18 --> Router Class Initialized
INFO - 2022-03-10 23:40:18 --> Output Class Initialized
INFO - 2022-03-10 23:40:18 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:18 --> Input Class Initialized
INFO - 2022-03-10 23:40:18 --> Language Class Initialized
INFO - 2022-03-10 23:40:18 --> Loader Class Initialized
INFO - 2022-03-10 23:40:18 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:18 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:18 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:18 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:18 --> Controller Class Initialized
INFO - 2022-03-10 23:40:18 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:18 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:18 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:18 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:40:18 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:40:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:19 --> Config Class Initialized
INFO - 2022-03-10 23:40:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:19 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:19 --> URI Class Initialized
INFO - 2022-03-10 23:40:19 --> Router Class Initialized
INFO - 2022-03-10 23:40:19 --> Output Class Initialized
INFO - 2022-03-10 23:40:19 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:19 --> Input Class Initialized
INFO - 2022-03-10 23:40:19 --> Language Class Initialized
INFO - 2022-03-10 23:40:19 --> Loader Class Initialized
INFO - 2022-03-10 23:40:19 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:19 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:19 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:19 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:19 --> Controller Class Initialized
INFO - 2022-03-10 23:40:19 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:19 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:19 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:19 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:40:19 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:19 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:40:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:40:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:40:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:40:19 --> Final output sent to browser
DEBUG - 2022-03-10 23:40:19 --> Total execution time: 0.0426
ERROR - 2022-03-10 23:40:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:20 --> Config Class Initialized
INFO - 2022-03-10 23:40:20 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:20 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:20 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:20 --> URI Class Initialized
INFO - 2022-03-10 23:40:20 --> Router Class Initialized
INFO - 2022-03-10 23:40:20 --> Output Class Initialized
INFO - 2022-03-10 23:40:20 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:20 --> Input Class Initialized
INFO - 2022-03-10 23:40:20 --> Language Class Initialized
INFO - 2022-03-10 23:40:20 --> Loader Class Initialized
INFO - 2022-03-10 23:40:20 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:20 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:20 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:20 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:20 --> Controller Class Initialized
INFO - 2022-03-10 23:40:20 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:20 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:20 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:20 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:20 --> Model "Users_model" initialized
INFO - 2022-03-10 23:40:20 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:40:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:40:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:40:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:40:20 --> Final output sent to browser
DEBUG - 2022-03-10 23:40:20 --> Total execution time: 0.0552
ERROR - 2022-03-10 23:40:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:27 --> Config Class Initialized
INFO - 2022-03-10 23:40:27 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:27 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:27 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:27 --> URI Class Initialized
INFO - 2022-03-10 23:40:27 --> Router Class Initialized
INFO - 2022-03-10 23:40:27 --> Output Class Initialized
INFO - 2022-03-10 23:40:27 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:27 --> Input Class Initialized
INFO - 2022-03-10 23:40:27 --> Language Class Initialized
INFO - 2022-03-10 23:40:27 --> Loader Class Initialized
INFO - 2022-03-10 23:40:27 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:27 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:27 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:28 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:28 --> Controller Class Initialized
INFO - 2022-03-10 23:40:28 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:28 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:28 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:28 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:40:28 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:28 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:40:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:40:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:40:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:40:28 --> Final output sent to browser
DEBUG - 2022-03-10 23:40:28 --> Total execution time: 0.0706
ERROR - 2022-03-10 23:40:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:28 --> Config Class Initialized
INFO - 2022-03-10 23:40:28 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:28 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:28 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:28 --> URI Class Initialized
INFO - 2022-03-10 23:40:28 --> Router Class Initialized
INFO - 2022-03-10 23:40:28 --> Output Class Initialized
INFO - 2022-03-10 23:40:28 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:28 --> Input Class Initialized
INFO - 2022-03-10 23:40:28 --> Language Class Initialized
INFO - 2022-03-10 23:40:28 --> Loader Class Initialized
INFO - 2022-03-10 23:40:28 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:28 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:28 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:28 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:28 --> Controller Class Initialized
INFO - 2022-03-10 23:40:28 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:28 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:28 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:28 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:40:28 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:28 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:40:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:40:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:40:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:40:28 --> Final output sent to browser
DEBUG - 2022-03-10 23:40:28 --> Total execution time: 0.0461
ERROR - 2022-03-10 23:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:29 --> Config Class Initialized
INFO - 2022-03-10 23:40:29 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:29 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:29 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:29 --> URI Class Initialized
INFO - 2022-03-10 23:40:29 --> Router Class Initialized
INFO - 2022-03-10 23:40:29 --> Output Class Initialized
INFO - 2022-03-10 23:40:29 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:29 --> Input Class Initialized
INFO - 2022-03-10 23:40:29 --> Language Class Initialized
INFO - 2022-03-10 23:40:29 --> Loader Class Initialized
INFO - 2022-03-10 23:40:29 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:29 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:29 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:29 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:29 --> Controller Class Initialized
INFO - 2022-03-10 23:40:29 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:29 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:29 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:29 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:40:29 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:29 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:40:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:40:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:40:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:40:29 --> Final output sent to browser
DEBUG - 2022-03-10 23:40:29 --> Total execution time: 0.0590
ERROR - 2022-03-10 23:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:40:35 --> Config Class Initialized
INFO - 2022-03-10 23:40:35 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:40:35 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:40:35 --> Utf8 Class Initialized
INFO - 2022-03-10 23:40:35 --> URI Class Initialized
INFO - 2022-03-10 23:40:35 --> Router Class Initialized
INFO - 2022-03-10 23:40:35 --> Output Class Initialized
INFO - 2022-03-10 23:40:35 --> Security Class Initialized
DEBUG - 2022-03-10 23:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:40:35 --> Input Class Initialized
INFO - 2022-03-10 23:40:35 --> Language Class Initialized
INFO - 2022-03-10 23:40:35 --> Loader Class Initialized
INFO - 2022-03-10 23:40:35 --> Helper loaded: url_helper
INFO - 2022-03-10 23:40:35 --> Helper loaded: form_helper
INFO - 2022-03-10 23:40:35 --> Helper loaded: common_helper
INFO - 2022-03-10 23:40:35 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:40:35 --> Controller Class Initialized
INFO - 2022-03-10 23:40:35 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:40:35 --> Encrypt Class Initialized
INFO - 2022-03-10 23:40:35 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:40:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:40:35 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:40:35 --> Model "Users_model" initialized
INFO - 2022-03-10 23:40:35 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:40:35 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-10 23:40:36 --> Final output sent to browser
DEBUG - 2022-03-10 23:40:36 --> Total execution time: 1.0708
ERROR - 2022-03-10 23:41:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:41:38 --> Config Class Initialized
INFO - 2022-03-10 23:41:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:41:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:41:38 --> Utf8 Class Initialized
INFO - 2022-03-10 23:41:38 --> URI Class Initialized
DEBUG - 2022-03-10 23:41:38 --> No URI present. Default controller set.
INFO - 2022-03-10 23:41:38 --> Router Class Initialized
INFO - 2022-03-10 23:41:38 --> Output Class Initialized
INFO - 2022-03-10 23:41:38 --> Security Class Initialized
DEBUG - 2022-03-10 23:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:41:38 --> Input Class Initialized
INFO - 2022-03-10 23:41:38 --> Language Class Initialized
INFO - 2022-03-10 23:41:38 --> Loader Class Initialized
INFO - 2022-03-10 23:41:38 --> Helper loaded: url_helper
INFO - 2022-03-10 23:41:38 --> Helper loaded: form_helper
INFO - 2022-03-10 23:41:38 --> Helper loaded: common_helper
INFO - 2022-03-10 23:41:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:41:38 --> Controller Class Initialized
INFO - 2022-03-10 23:41:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:41:38 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:41:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:41:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:41:38 --> Email Class Initialized
INFO - 2022-03-10 23:41:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:41:38 --> Calendar Class Initialized
INFO - 2022-03-10 23:41:38 --> Model "Login_model" initialized
ERROR - 2022-03-10 23:41:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:41:39 --> Config Class Initialized
INFO - 2022-03-10 23:41:39 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:41:39 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:41:39 --> Utf8 Class Initialized
INFO - 2022-03-10 23:41:39 --> URI Class Initialized
INFO - 2022-03-10 23:41:39 --> Router Class Initialized
INFO - 2022-03-10 23:41:39 --> Output Class Initialized
INFO - 2022-03-10 23:41:39 --> Security Class Initialized
DEBUG - 2022-03-10 23:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:41:39 --> Input Class Initialized
INFO - 2022-03-10 23:41:39 --> Language Class Initialized
INFO - 2022-03-10 23:41:39 --> Loader Class Initialized
INFO - 2022-03-10 23:41:39 --> Helper loaded: url_helper
INFO - 2022-03-10 23:41:39 --> Helper loaded: form_helper
INFO - 2022-03-10 23:41:39 --> Helper loaded: common_helper
INFO - 2022-03-10 23:41:39 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:41:39 --> Controller Class Initialized
INFO - 2022-03-10 23:41:39 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:41:39 --> Encrypt Class Initialized
INFO - 2022-03-10 23:41:39 --> Model "Diseases_model" initialized
INFO - 2022-03-10 23:41:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:41:39 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-10 23:41:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:41:39 --> Final output sent to browser
DEBUG - 2022-03-10 23:41:39 --> Total execution time: 0.0263
ERROR - 2022-03-10 23:41:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:41:40 --> Config Class Initialized
INFO - 2022-03-10 23:41:40 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:41:40 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:41:40 --> Utf8 Class Initialized
INFO - 2022-03-10 23:41:40 --> URI Class Initialized
DEBUG - 2022-03-10 23:41:40 --> No URI present. Default controller set.
INFO - 2022-03-10 23:41:40 --> Router Class Initialized
INFO - 2022-03-10 23:41:40 --> Output Class Initialized
INFO - 2022-03-10 23:41:40 --> Security Class Initialized
DEBUG - 2022-03-10 23:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:41:40 --> Input Class Initialized
INFO - 2022-03-10 23:41:40 --> Language Class Initialized
INFO - 2022-03-10 23:41:40 --> Loader Class Initialized
INFO - 2022-03-10 23:41:40 --> Helper loaded: url_helper
INFO - 2022-03-10 23:41:40 --> Helper loaded: form_helper
INFO - 2022-03-10 23:41:40 --> Helper loaded: common_helper
INFO - 2022-03-10 23:41:40 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:41:40 --> Controller Class Initialized
INFO - 2022-03-10 23:41:40 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:41:40 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:41:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:41:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:41:40 --> Email Class Initialized
INFO - 2022-03-10 23:41:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:41:40 --> Calendar Class Initialized
INFO - 2022-03-10 23:41:40 --> Model "Login_model" initialized
ERROR - 2022-03-10 23:41:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:41:41 --> Config Class Initialized
INFO - 2022-03-10 23:41:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:41:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:41:41 --> Utf8 Class Initialized
INFO - 2022-03-10 23:41:41 --> URI Class Initialized
INFO - 2022-03-10 23:41:41 --> Router Class Initialized
INFO - 2022-03-10 23:41:41 --> Output Class Initialized
INFO - 2022-03-10 23:41:41 --> Security Class Initialized
DEBUG - 2022-03-10 23:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:41:41 --> Input Class Initialized
INFO - 2022-03-10 23:41:41 --> Language Class Initialized
INFO - 2022-03-10 23:41:41 --> Loader Class Initialized
INFO - 2022-03-10 23:41:41 --> Helper loaded: url_helper
INFO - 2022-03-10 23:41:41 --> Helper loaded: form_helper
INFO - 2022-03-10 23:41:41 --> Helper loaded: common_helper
INFO - 2022-03-10 23:41:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:41:41 --> Controller Class Initialized
INFO - 2022-03-10 23:41:41 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:41:41 --> Encrypt Class Initialized
INFO - 2022-03-10 23:41:41 --> Model "Diseases_model" initialized
INFO - 2022-03-10 23:41:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:41:41 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-10 23:41:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:41:41 --> Final output sent to browser
DEBUG - 2022-03-10 23:41:41 --> Total execution time: 0.0318
ERROR - 2022-03-10 23:41:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:41:51 --> Config Class Initialized
INFO - 2022-03-10 23:41:51 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:41:51 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:41:51 --> Utf8 Class Initialized
INFO - 2022-03-10 23:41:51 --> URI Class Initialized
INFO - 2022-03-10 23:41:51 --> Router Class Initialized
INFO - 2022-03-10 23:41:51 --> Output Class Initialized
INFO - 2022-03-10 23:41:51 --> Security Class Initialized
DEBUG - 2022-03-10 23:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:41:51 --> Input Class Initialized
INFO - 2022-03-10 23:41:51 --> Language Class Initialized
INFO - 2022-03-10 23:41:51 --> Loader Class Initialized
INFO - 2022-03-10 23:41:51 --> Helper loaded: url_helper
INFO - 2022-03-10 23:41:51 --> Helper loaded: form_helper
INFO - 2022-03-10 23:41:51 --> Helper loaded: common_helper
INFO - 2022-03-10 23:41:51 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:41:51 --> Controller Class Initialized
INFO - 2022-03-10 23:41:51 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:41:51 --> Encrypt Class Initialized
INFO - 2022-03-10 23:41:51 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:41:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:41:51 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:41:51 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:41:51 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:41:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:41:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:41:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:42:00 --> Final output sent to browser
DEBUG - 2022-03-10 23:42:00 --> Total execution time: 7.1845
ERROR - 2022-03-10 23:42:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:42:32 --> Config Class Initialized
INFO - 2022-03-10 23:42:32 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:42:32 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:42:32 --> Utf8 Class Initialized
INFO - 2022-03-10 23:42:32 --> URI Class Initialized
INFO - 2022-03-10 23:42:32 --> Router Class Initialized
INFO - 2022-03-10 23:42:32 --> Output Class Initialized
INFO - 2022-03-10 23:42:32 --> Security Class Initialized
DEBUG - 2022-03-10 23:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:42:32 --> Input Class Initialized
INFO - 2022-03-10 23:42:32 --> Language Class Initialized
INFO - 2022-03-10 23:42:32 --> Loader Class Initialized
INFO - 2022-03-10 23:42:32 --> Helper loaded: url_helper
INFO - 2022-03-10 23:42:32 --> Helper loaded: form_helper
INFO - 2022-03-10 23:42:32 --> Helper loaded: common_helper
INFO - 2022-03-10 23:42:32 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:42:32 --> Controller Class Initialized
INFO - 2022-03-10 23:42:32 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:42:32 --> Encrypt Class Initialized
INFO - 2022-03-10 23:42:32 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:42:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:42:32 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:42:32 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:42:32 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:42:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:42:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:42:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:42:32 --> Final output sent to browser
DEBUG - 2022-03-10 23:42:32 --> Total execution time: 0.0565
ERROR - 2022-03-10 23:43:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:43:13 --> Config Class Initialized
INFO - 2022-03-10 23:43:13 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:43:13 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:43:13 --> Utf8 Class Initialized
INFO - 2022-03-10 23:43:13 --> URI Class Initialized
INFO - 2022-03-10 23:43:13 --> Router Class Initialized
INFO - 2022-03-10 23:43:13 --> Output Class Initialized
INFO - 2022-03-10 23:43:13 --> Security Class Initialized
DEBUG - 2022-03-10 23:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:43:13 --> Input Class Initialized
INFO - 2022-03-10 23:43:13 --> Language Class Initialized
INFO - 2022-03-10 23:43:13 --> Loader Class Initialized
INFO - 2022-03-10 23:43:13 --> Helper loaded: url_helper
INFO - 2022-03-10 23:43:13 --> Helper loaded: form_helper
INFO - 2022-03-10 23:43:13 --> Helper loaded: common_helper
INFO - 2022-03-10 23:43:13 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:43:13 --> Controller Class Initialized
INFO - 2022-03-10 23:43:13 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:43:13 --> Encrypt Class Initialized
INFO - 2022-03-10 23:43:13 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:43:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:43:13 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:43:13 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:43:13 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:43:13 --> Upload Class Initialized
INFO - 2022-03-10 23:43:13 --> Final output sent to browser
DEBUG - 2022-03-10 23:43:13 --> Total execution time: 0.0364
ERROR - 2022-03-10 23:43:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:43:24 --> Config Class Initialized
INFO - 2022-03-10 23:43:24 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:43:24 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:43:24 --> Utf8 Class Initialized
INFO - 2022-03-10 23:43:24 --> URI Class Initialized
INFO - 2022-03-10 23:43:24 --> Router Class Initialized
INFO - 2022-03-10 23:43:24 --> Output Class Initialized
INFO - 2022-03-10 23:43:24 --> Security Class Initialized
DEBUG - 2022-03-10 23:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:43:24 --> Input Class Initialized
INFO - 2022-03-10 23:43:24 --> Language Class Initialized
INFO - 2022-03-10 23:43:24 --> Loader Class Initialized
INFO - 2022-03-10 23:43:24 --> Helper loaded: url_helper
INFO - 2022-03-10 23:43:24 --> Helper loaded: form_helper
INFO - 2022-03-10 23:43:24 --> Helper loaded: common_helper
INFO - 2022-03-10 23:43:24 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:43:24 --> Controller Class Initialized
INFO - 2022-03-10 23:43:24 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:43:24 --> Encrypt Class Initialized
INFO - 2022-03-10 23:43:24 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:43:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:43:24 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:43:24 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:43:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:43:25 --> Config Class Initialized
INFO - 2022-03-10 23:43:25 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:43:25 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:43:25 --> Utf8 Class Initialized
INFO - 2022-03-10 23:43:25 --> URI Class Initialized
INFO - 2022-03-10 23:43:25 --> Router Class Initialized
INFO - 2022-03-10 23:43:25 --> Output Class Initialized
INFO - 2022-03-10 23:43:25 --> Security Class Initialized
DEBUG - 2022-03-10 23:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:43:25 --> Input Class Initialized
INFO - 2022-03-10 23:43:25 --> Language Class Initialized
INFO - 2022-03-10 23:43:25 --> Loader Class Initialized
INFO - 2022-03-10 23:43:25 --> Helper loaded: url_helper
INFO - 2022-03-10 23:43:25 --> Helper loaded: form_helper
INFO - 2022-03-10 23:43:25 --> Helper loaded: common_helper
INFO - 2022-03-10 23:43:25 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:43:25 --> Controller Class Initialized
INFO - 2022-03-10 23:43:25 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:43:25 --> Encrypt Class Initialized
INFO - 2022-03-10 23:43:25 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:43:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:43:25 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:43:25 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:43:25 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:43:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:43:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:43:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:43:25 --> Final output sent to browser
DEBUG - 2022-03-10 23:43:25 --> Total execution time: 0.0644
ERROR - 2022-03-10 23:43:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:43:26 --> Config Class Initialized
INFO - 2022-03-10 23:43:26 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:43:26 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:43:26 --> Utf8 Class Initialized
INFO - 2022-03-10 23:43:26 --> URI Class Initialized
INFO - 2022-03-10 23:43:26 --> Router Class Initialized
INFO - 2022-03-10 23:43:26 --> Output Class Initialized
INFO - 2022-03-10 23:43:26 --> Security Class Initialized
DEBUG - 2022-03-10 23:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:43:26 --> Input Class Initialized
INFO - 2022-03-10 23:43:26 --> Language Class Initialized
INFO - 2022-03-10 23:43:26 --> Loader Class Initialized
INFO - 2022-03-10 23:43:26 --> Helper loaded: url_helper
INFO - 2022-03-10 23:43:26 --> Helper loaded: form_helper
INFO - 2022-03-10 23:43:26 --> Helper loaded: common_helper
INFO - 2022-03-10 23:43:26 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:43:26 --> Controller Class Initialized
INFO - 2022-03-10 23:43:26 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:43:26 --> Encrypt Class Initialized
INFO - 2022-03-10 23:43:26 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:43:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:43:26 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:43:26 --> Model "Users_model" initialized
INFO - 2022-03-10 23:43:26 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:43:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:43:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:43:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:43:26 --> Final output sent to browser
DEBUG - 2022-03-10 23:43:26 --> Total execution time: 0.0748
ERROR - 2022-03-10 23:44:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:44:14 --> Config Class Initialized
INFO - 2022-03-10 23:44:14 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:44:14 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:44:14 --> Utf8 Class Initialized
INFO - 2022-03-10 23:44:14 --> URI Class Initialized
INFO - 2022-03-10 23:44:14 --> Router Class Initialized
INFO - 2022-03-10 23:44:14 --> Output Class Initialized
INFO - 2022-03-10 23:44:14 --> Security Class Initialized
DEBUG - 2022-03-10 23:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:44:14 --> Input Class Initialized
INFO - 2022-03-10 23:44:14 --> Language Class Initialized
INFO - 2022-03-10 23:44:14 --> Loader Class Initialized
INFO - 2022-03-10 23:44:14 --> Helper loaded: url_helper
INFO - 2022-03-10 23:44:14 --> Helper loaded: form_helper
INFO - 2022-03-10 23:44:14 --> Helper loaded: common_helper
INFO - 2022-03-10 23:44:14 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:44:14 --> Controller Class Initialized
INFO - 2022-03-10 23:44:14 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:44:14 --> Encrypt Class Initialized
INFO - 2022-03-10 23:44:14 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:44:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:44:14 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:44:14 --> Model "Users_model" initialized
INFO - 2022-03-10 23:44:14 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:44:14 --> Upload Class Initialized
INFO - 2022-03-10 23:44:14 --> Final output sent to browser
DEBUG - 2022-03-10 23:44:14 --> Total execution time: 0.0487
ERROR - 2022-03-10 23:44:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:44:19 --> Config Class Initialized
INFO - 2022-03-10 23:44:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:44:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:44:19 --> Utf8 Class Initialized
INFO - 2022-03-10 23:44:19 --> URI Class Initialized
INFO - 2022-03-10 23:44:19 --> Router Class Initialized
INFO - 2022-03-10 23:44:19 --> Output Class Initialized
INFO - 2022-03-10 23:44:19 --> Security Class Initialized
DEBUG - 2022-03-10 23:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:44:19 --> Input Class Initialized
INFO - 2022-03-10 23:44:19 --> Language Class Initialized
INFO - 2022-03-10 23:44:19 --> Loader Class Initialized
INFO - 2022-03-10 23:44:19 --> Helper loaded: url_helper
INFO - 2022-03-10 23:44:19 --> Helper loaded: form_helper
INFO - 2022-03-10 23:44:19 --> Helper loaded: common_helper
INFO - 2022-03-10 23:44:19 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:44:19 --> Controller Class Initialized
INFO - 2022-03-10 23:44:19 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:44:19 --> Encrypt Class Initialized
INFO - 2022-03-10 23:44:19 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:44:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:44:19 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:44:19 --> Model "Users_model" initialized
INFO - 2022-03-10 23:44:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:44:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:44:19 --> Config Class Initialized
INFO - 2022-03-10 23:44:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:44:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:44:19 --> Utf8 Class Initialized
INFO - 2022-03-10 23:44:19 --> URI Class Initialized
INFO - 2022-03-10 23:44:19 --> Router Class Initialized
INFO - 2022-03-10 23:44:19 --> Output Class Initialized
INFO - 2022-03-10 23:44:19 --> Security Class Initialized
DEBUG - 2022-03-10 23:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:44:19 --> Input Class Initialized
INFO - 2022-03-10 23:44:19 --> Language Class Initialized
INFO - 2022-03-10 23:44:19 --> Loader Class Initialized
INFO - 2022-03-10 23:44:19 --> Helper loaded: url_helper
INFO - 2022-03-10 23:44:19 --> Helper loaded: form_helper
INFO - 2022-03-10 23:44:19 --> Helper loaded: common_helper
INFO - 2022-03-10 23:44:19 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:44:19 --> Controller Class Initialized
INFO - 2022-03-10 23:44:19 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:44:19 --> Encrypt Class Initialized
INFO - 2022-03-10 23:44:19 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:44:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:44:19 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:44:19 --> Model "Users_model" initialized
INFO - 2022-03-10 23:44:19 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:44:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:44:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:44:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:44:19 --> Final output sent to browser
DEBUG - 2022-03-10 23:44:19 --> Total execution time: 0.0600
ERROR - 2022-03-10 23:44:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:44:39 --> Config Class Initialized
INFO - 2022-03-10 23:44:39 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:44:39 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:44:39 --> Utf8 Class Initialized
INFO - 2022-03-10 23:44:39 --> URI Class Initialized
INFO - 2022-03-10 23:44:39 --> Router Class Initialized
INFO - 2022-03-10 23:44:39 --> Output Class Initialized
INFO - 2022-03-10 23:44:39 --> Security Class Initialized
DEBUG - 2022-03-10 23:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:44:39 --> Input Class Initialized
INFO - 2022-03-10 23:44:39 --> Language Class Initialized
INFO - 2022-03-10 23:44:39 --> Loader Class Initialized
INFO - 2022-03-10 23:44:39 --> Helper loaded: url_helper
INFO - 2022-03-10 23:44:39 --> Helper loaded: form_helper
INFO - 2022-03-10 23:44:39 --> Helper loaded: common_helper
INFO - 2022-03-10 23:44:39 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:44:39 --> Controller Class Initialized
INFO - 2022-03-10 23:44:39 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:44:39 --> Encrypt Class Initialized
INFO - 2022-03-10 23:44:39 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:44:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:44:39 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:44:39 --> Model "Users_model" initialized
INFO - 2022-03-10 23:44:39 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:44:39 --> Upload Class Initialized
INFO - 2022-03-10 23:44:39 --> Final output sent to browser
DEBUG - 2022-03-10 23:44:39 --> Total execution time: 0.0474
ERROR - 2022-03-10 23:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:44:42 --> Config Class Initialized
INFO - 2022-03-10 23:44:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:44:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:44:42 --> Utf8 Class Initialized
INFO - 2022-03-10 23:44:42 --> URI Class Initialized
INFO - 2022-03-10 23:44:42 --> Router Class Initialized
INFO - 2022-03-10 23:44:42 --> Output Class Initialized
INFO - 2022-03-10 23:44:42 --> Security Class Initialized
DEBUG - 2022-03-10 23:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:44:42 --> Input Class Initialized
INFO - 2022-03-10 23:44:42 --> Language Class Initialized
INFO - 2022-03-10 23:44:42 --> Loader Class Initialized
INFO - 2022-03-10 23:44:42 --> Helper loaded: url_helper
INFO - 2022-03-10 23:44:42 --> Helper loaded: form_helper
INFO - 2022-03-10 23:44:42 --> Helper loaded: common_helper
INFO - 2022-03-10 23:44:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:44:42 --> Controller Class Initialized
INFO - 2022-03-10 23:44:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:44:42 --> Encrypt Class Initialized
INFO - 2022-03-10 23:44:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:44:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:44:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:44:42 --> Model "Users_model" initialized
INFO - 2022-03-10 23:44:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:44:43 --> Config Class Initialized
INFO - 2022-03-10 23:44:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:44:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:44:43 --> Utf8 Class Initialized
INFO - 2022-03-10 23:44:43 --> URI Class Initialized
INFO - 2022-03-10 23:44:43 --> Router Class Initialized
INFO - 2022-03-10 23:44:43 --> Output Class Initialized
INFO - 2022-03-10 23:44:43 --> Security Class Initialized
DEBUG - 2022-03-10 23:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:44:43 --> Input Class Initialized
INFO - 2022-03-10 23:44:43 --> Language Class Initialized
INFO - 2022-03-10 23:44:43 --> Loader Class Initialized
INFO - 2022-03-10 23:44:43 --> Helper loaded: url_helper
INFO - 2022-03-10 23:44:43 --> Helper loaded: form_helper
INFO - 2022-03-10 23:44:43 --> Helper loaded: common_helper
INFO - 2022-03-10 23:44:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:44:43 --> Controller Class Initialized
INFO - 2022-03-10 23:44:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:44:43 --> Encrypt Class Initialized
INFO - 2022-03-10 23:44:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:44:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:44:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:44:43 --> Model "Users_model" initialized
INFO - 2022-03-10 23:44:43 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:44:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:44:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:44:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:44:43 --> Final output sent to browser
DEBUG - 2022-03-10 23:44:43 --> Total execution time: 0.0604
ERROR - 2022-03-10 23:47:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:47:31 --> Config Class Initialized
INFO - 2022-03-10 23:47:31 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:47:31 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:47:31 --> Utf8 Class Initialized
INFO - 2022-03-10 23:47:31 --> URI Class Initialized
INFO - 2022-03-10 23:47:31 --> Router Class Initialized
INFO - 2022-03-10 23:47:31 --> Output Class Initialized
INFO - 2022-03-10 23:47:31 --> Security Class Initialized
DEBUG - 2022-03-10 23:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:47:31 --> Input Class Initialized
INFO - 2022-03-10 23:47:31 --> Language Class Initialized
INFO - 2022-03-10 23:47:31 --> Loader Class Initialized
INFO - 2022-03-10 23:47:31 --> Helper loaded: url_helper
INFO - 2022-03-10 23:47:31 --> Helper loaded: form_helper
INFO - 2022-03-10 23:47:31 --> Helper loaded: common_helper
INFO - 2022-03-10 23:47:31 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:47:31 --> Controller Class Initialized
INFO - 2022-03-10 23:47:31 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:47:31 --> Encrypt Class Initialized
INFO - 2022-03-10 23:47:31 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:47:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:47:31 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:47:31 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:47:31 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:47:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:47:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:47:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:47:31 --> Final output sent to browser
DEBUG - 2022-03-10 23:47:31 --> Total execution time: 0.0481
ERROR - 2022-03-10 23:47:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:47:42 --> Config Class Initialized
INFO - 2022-03-10 23:47:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:47:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:47:42 --> Utf8 Class Initialized
INFO - 2022-03-10 23:47:42 --> URI Class Initialized
INFO - 2022-03-10 23:47:42 --> Router Class Initialized
INFO - 2022-03-10 23:47:42 --> Output Class Initialized
INFO - 2022-03-10 23:47:42 --> Security Class Initialized
DEBUG - 2022-03-10 23:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:47:42 --> Input Class Initialized
INFO - 2022-03-10 23:47:42 --> Language Class Initialized
INFO - 2022-03-10 23:47:42 --> Loader Class Initialized
INFO - 2022-03-10 23:47:42 --> Helper loaded: url_helper
INFO - 2022-03-10 23:47:42 --> Helper loaded: form_helper
INFO - 2022-03-10 23:47:42 --> Helper loaded: common_helper
INFO - 2022-03-10 23:47:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:47:42 --> Controller Class Initialized
INFO - 2022-03-10 23:47:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:47:42 --> Encrypt Class Initialized
INFO - 2022-03-10 23:47:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:47:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:47:42 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:47:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:47:42 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:47:42 --> Upload Class Initialized
INFO - 2022-03-10 23:47:42 --> Final output sent to browser
DEBUG - 2022-03-10 23:47:42 --> Total execution time: 0.0242
ERROR - 2022-03-10 23:47:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:47:51 --> Config Class Initialized
INFO - 2022-03-10 23:47:51 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:47:51 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:47:51 --> Utf8 Class Initialized
INFO - 2022-03-10 23:47:51 --> URI Class Initialized
INFO - 2022-03-10 23:47:51 --> Router Class Initialized
INFO - 2022-03-10 23:47:51 --> Output Class Initialized
INFO - 2022-03-10 23:47:51 --> Security Class Initialized
DEBUG - 2022-03-10 23:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:47:51 --> Input Class Initialized
INFO - 2022-03-10 23:47:51 --> Language Class Initialized
INFO - 2022-03-10 23:47:51 --> Loader Class Initialized
INFO - 2022-03-10 23:47:51 --> Helper loaded: url_helper
INFO - 2022-03-10 23:47:51 --> Helper loaded: form_helper
INFO - 2022-03-10 23:47:51 --> Helper loaded: common_helper
INFO - 2022-03-10 23:47:51 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:47:51 --> Controller Class Initialized
INFO - 2022-03-10 23:47:51 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:47:51 --> Encrypt Class Initialized
INFO - 2022-03-10 23:47:51 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:47:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:47:51 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:47:51 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:47:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:47:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:47:52 --> Config Class Initialized
INFO - 2022-03-10 23:47:52 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:47:52 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:47:52 --> Utf8 Class Initialized
INFO - 2022-03-10 23:47:52 --> URI Class Initialized
INFO - 2022-03-10 23:47:52 --> Router Class Initialized
INFO - 2022-03-10 23:47:52 --> Output Class Initialized
INFO - 2022-03-10 23:47:52 --> Security Class Initialized
DEBUG - 2022-03-10 23:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:47:52 --> Input Class Initialized
INFO - 2022-03-10 23:47:52 --> Language Class Initialized
INFO - 2022-03-10 23:47:52 --> Loader Class Initialized
INFO - 2022-03-10 23:47:52 --> Helper loaded: url_helper
INFO - 2022-03-10 23:47:52 --> Helper loaded: form_helper
INFO - 2022-03-10 23:47:52 --> Helper loaded: common_helper
INFO - 2022-03-10 23:47:52 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:47:52 --> Controller Class Initialized
INFO - 2022-03-10 23:47:52 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:47:52 --> Encrypt Class Initialized
INFO - 2022-03-10 23:47:52 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:47:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:47:52 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:47:52 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:47:52 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:47:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:47:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:47:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:47:52 --> Final output sent to browser
DEBUG - 2022-03-10 23:47:52 --> Total execution time: 0.0409
ERROR - 2022-03-10 23:47:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:47:53 --> Config Class Initialized
INFO - 2022-03-10 23:47:53 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:47:53 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:47:53 --> Utf8 Class Initialized
INFO - 2022-03-10 23:47:53 --> URI Class Initialized
INFO - 2022-03-10 23:47:53 --> Router Class Initialized
INFO - 2022-03-10 23:47:53 --> Output Class Initialized
INFO - 2022-03-10 23:47:53 --> Security Class Initialized
DEBUG - 2022-03-10 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:47:53 --> Input Class Initialized
INFO - 2022-03-10 23:47:53 --> Language Class Initialized
INFO - 2022-03-10 23:47:53 --> Loader Class Initialized
INFO - 2022-03-10 23:47:53 --> Helper loaded: url_helper
INFO - 2022-03-10 23:47:53 --> Helper loaded: form_helper
INFO - 2022-03-10 23:47:53 --> Helper loaded: common_helper
INFO - 2022-03-10 23:47:53 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:47:53 --> Controller Class Initialized
INFO - 2022-03-10 23:47:53 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:47:53 --> Encrypt Class Initialized
INFO - 2022-03-10 23:47:53 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:47:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:47:53 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:47:53 --> Model "Users_model" initialized
INFO - 2022-03-10 23:47:53 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:47:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:47:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:47:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:47:53 --> Final output sent to browser
DEBUG - 2022-03-10 23:47:53 --> Total execution time: 0.0697
ERROR - 2022-03-10 23:47:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:47:57 --> Config Class Initialized
INFO - 2022-03-10 23:47:57 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:47:57 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:47:57 --> Utf8 Class Initialized
INFO - 2022-03-10 23:47:57 --> URI Class Initialized
INFO - 2022-03-10 23:47:57 --> Router Class Initialized
INFO - 2022-03-10 23:47:57 --> Output Class Initialized
INFO - 2022-03-10 23:47:57 --> Security Class Initialized
DEBUG - 2022-03-10 23:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:47:57 --> Input Class Initialized
INFO - 2022-03-10 23:47:57 --> Language Class Initialized
INFO - 2022-03-10 23:47:57 --> Loader Class Initialized
INFO - 2022-03-10 23:47:57 --> Helper loaded: url_helper
INFO - 2022-03-10 23:47:57 --> Helper loaded: form_helper
INFO - 2022-03-10 23:47:57 --> Helper loaded: common_helper
INFO - 2022-03-10 23:47:57 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:47:57 --> Controller Class Initialized
INFO - 2022-03-10 23:47:57 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:47:57 --> Encrypt Class Initialized
INFO - 2022-03-10 23:47:57 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:47:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:47:57 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:47:57 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:47:57 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:47:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:47:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:47:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:47:57 --> Final output sent to browser
DEBUG - 2022-03-10 23:47:57 --> Total execution time: 0.0589
ERROR - 2022-03-10 23:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:48:04 --> Config Class Initialized
INFO - 2022-03-10 23:48:04 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:48:04 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:48:04 --> Utf8 Class Initialized
INFO - 2022-03-10 23:48:04 --> URI Class Initialized
INFO - 2022-03-10 23:48:04 --> Router Class Initialized
INFO - 2022-03-10 23:48:04 --> Output Class Initialized
INFO - 2022-03-10 23:48:04 --> Security Class Initialized
DEBUG - 2022-03-10 23:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:48:04 --> Input Class Initialized
INFO - 2022-03-10 23:48:04 --> Language Class Initialized
INFO - 2022-03-10 23:48:04 --> Loader Class Initialized
INFO - 2022-03-10 23:48:04 --> Helper loaded: url_helper
INFO - 2022-03-10 23:48:04 --> Helper loaded: form_helper
INFO - 2022-03-10 23:48:04 --> Helper loaded: common_helper
INFO - 2022-03-10 23:48:04 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:48:04 --> Controller Class Initialized
INFO - 2022-03-10 23:48:04 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:48:04 --> Encrypt Class Initialized
INFO - 2022-03-10 23:48:04 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:48:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:48:04 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:48:04 --> Model "Users_model" initialized
INFO - 2022-03-10 23:48:04 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:48:04 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-10 23:48:06 --> Final output sent to browser
DEBUG - 2022-03-10 23:48:06 --> Total execution time: 1.9292
ERROR - 2022-03-10 23:48:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:48:26 --> Config Class Initialized
INFO - 2022-03-10 23:48:26 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:48:26 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:48:26 --> Utf8 Class Initialized
INFO - 2022-03-10 23:48:26 --> URI Class Initialized
INFO - 2022-03-10 23:48:26 --> Router Class Initialized
INFO - 2022-03-10 23:48:26 --> Output Class Initialized
INFO - 2022-03-10 23:48:26 --> Security Class Initialized
DEBUG - 2022-03-10 23:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:48:26 --> Input Class Initialized
INFO - 2022-03-10 23:48:26 --> Language Class Initialized
INFO - 2022-03-10 23:48:26 --> Loader Class Initialized
INFO - 2022-03-10 23:48:26 --> Helper loaded: url_helper
INFO - 2022-03-10 23:48:26 --> Helper loaded: form_helper
INFO - 2022-03-10 23:48:26 --> Helper loaded: common_helper
INFO - 2022-03-10 23:48:26 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:48:26 --> Controller Class Initialized
INFO - 2022-03-10 23:48:26 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:48:26 --> Encrypt Class Initialized
INFO - 2022-03-10 23:48:26 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:48:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:48:26 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:48:26 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:48:26 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:48:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:48:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:48:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:48:26 --> Final output sent to browser
DEBUG - 2022-03-10 23:48:26 --> Total execution time: 0.0712
ERROR - 2022-03-10 23:48:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:48:34 --> Config Class Initialized
INFO - 2022-03-10 23:48:34 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:48:34 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:48:34 --> Utf8 Class Initialized
INFO - 2022-03-10 23:48:34 --> URI Class Initialized
INFO - 2022-03-10 23:48:34 --> Router Class Initialized
INFO - 2022-03-10 23:48:34 --> Output Class Initialized
INFO - 2022-03-10 23:48:34 --> Security Class Initialized
DEBUG - 2022-03-10 23:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:48:34 --> Input Class Initialized
INFO - 2022-03-10 23:48:34 --> Language Class Initialized
INFO - 2022-03-10 23:48:34 --> Loader Class Initialized
INFO - 2022-03-10 23:48:34 --> Helper loaded: url_helper
INFO - 2022-03-10 23:48:34 --> Helper loaded: form_helper
INFO - 2022-03-10 23:48:34 --> Helper loaded: common_helper
INFO - 2022-03-10 23:48:34 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:48:34 --> Controller Class Initialized
INFO - 2022-03-10 23:48:34 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:48:34 --> Encrypt Class Initialized
INFO - 2022-03-10 23:48:34 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:48:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:48:34 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:48:34 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:48:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:48:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:48:35 --> Config Class Initialized
INFO - 2022-03-10 23:48:35 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:48:35 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:48:35 --> Utf8 Class Initialized
INFO - 2022-03-10 23:48:35 --> URI Class Initialized
INFO - 2022-03-10 23:48:35 --> Router Class Initialized
INFO - 2022-03-10 23:48:35 --> Output Class Initialized
INFO - 2022-03-10 23:48:35 --> Security Class Initialized
DEBUG - 2022-03-10 23:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:48:35 --> Input Class Initialized
INFO - 2022-03-10 23:48:35 --> Language Class Initialized
INFO - 2022-03-10 23:48:35 --> Loader Class Initialized
INFO - 2022-03-10 23:48:35 --> Helper loaded: url_helper
INFO - 2022-03-10 23:48:35 --> Helper loaded: form_helper
INFO - 2022-03-10 23:48:35 --> Helper loaded: common_helper
INFO - 2022-03-10 23:48:35 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:48:35 --> Controller Class Initialized
INFO - 2022-03-10 23:48:35 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:48:35 --> Encrypt Class Initialized
INFO - 2022-03-10 23:48:35 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:48:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:48:35 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:48:35 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:48:35 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:48:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:48:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:48:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:48:35 --> Final output sent to browser
DEBUG - 2022-03-10 23:48:35 --> Total execution time: 0.0451
ERROR - 2022-03-10 23:48:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:48:36 --> Config Class Initialized
INFO - 2022-03-10 23:48:36 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:48:36 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:48:36 --> Utf8 Class Initialized
INFO - 2022-03-10 23:48:36 --> URI Class Initialized
INFO - 2022-03-10 23:48:36 --> Router Class Initialized
INFO - 2022-03-10 23:48:36 --> Output Class Initialized
INFO - 2022-03-10 23:48:36 --> Security Class Initialized
DEBUG - 2022-03-10 23:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:48:36 --> Input Class Initialized
INFO - 2022-03-10 23:48:36 --> Language Class Initialized
INFO - 2022-03-10 23:48:36 --> Loader Class Initialized
INFO - 2022-03-10 23:48:36 --> Helper loaded: url_helper
INFO - 2022-03-10 23:48:36 --> Helper loaded: form_helper
INFO - 2022-03-10 23:48:36 --> Helper loaded: common_helper
INFO - 2022-03-10 23:48:36 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:48:36 --> Controller Class Initialized
INFO - 2022-03-10 23:48:36 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:48:36 --> Encrypt Class Initialized
INFO - 2022-03-10 23:48:36 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:48:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:48:36 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:48:36 --> Model "Users_model" initialized
INFO - 2022-03-10 23:48:36 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:48:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:48:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:48:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:48:36 --> Final output sent to browser
DEBUG - 2022-03-10 23:48:36 --> Total execution time: 0.0606
ERROR - 2022-03-10 23:49:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:49:56 --> Config Class Initialized
INFO - 2022-03-10 23:49:56 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:49:56 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:49:56 --> Utf8 Class Initialized
INFO - 2022-03-10 23:49:56 --> URI Class Initialized
INFO - 2022-03-10 23:49:56 --> Router Class Initialized
INFO - 2022-03-10 23:49:56 --> Output Class Initialized
INFO - 2022-03-10 23:49:56 --> Security Class Initialized
DEBUG - 2022-03-10 23:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:49:56 --> Input Class Initialized
INFO - 2022-03-10 23:49:56 --> Language Class Initialized
INFO - 2022-03-10 23:49:56 --> Loader Class Initialized
INFO - 2022-03-10 23:49:56 --> Helper loaded: url_helper
INFO - 2022-03-10 23:49:56 --> Helper loaded: form_helper
INFO - 2022-03-10 23:49:56 --> Helper loaded: common_helper
INFO - 2022-03-10 23:49:56 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:49:56 --> Controller Class Initialized
INFO - 2022-03-10 23:49:56 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:49:56 --> Encrypt Class Initialized
INFO - 2022-03-10 23:49:56 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:49:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:49:56 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:49:56 --> Model "Users_model" initialized
INFO - 2022-03-10 23:49:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:49:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:49:58 --> Config Class Initialized
INFO - 2022-03-10 23:49:58 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:49:58 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:49:58 --> Utf8 Class Initialized
INFO - 2022-03-10 23:49:58 --> URI Class Initialized
INFO - 2022-03-10 23:49:58 --> Router Class Initialized
INFO - 2022-03-10 23:49:58 --> Output Class Initialized
INFO - 2022-03-10 23:49:58 --> Security Class Initialized
DEBUG - 2022-03-10 23:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:49:58 --> Input Class Initialized
INFO - 2022-03-10 23:49:58 --> Language Class Initialized
INFO - 2022-03-10 23:49:58 --> Loader Class Initialized
INFO - 2022-03-10 23:49:58 --> Helper loaded: url_helper
INFO - 2022-03-10 23:49:58 --> Helper loaded: form_helper
INFO - 2022-03-10 23:49:58 --> Helper loaded: common_helper
INFO - 2022-03-10 23:49:58 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:49:58 --> Controller Class Initialized
INFO - 2022-03-10 23:49:58 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:49:58 --> Encrypt Class Initialized
INFO - 2022-03-10 23:49:58 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:49:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:49:58 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:49:58 --> Model "Users_model" initialized
INFO - 2022-03-10 23:49:58 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:49:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:49:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:49:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:49:58 --> Final output sent to browser
DEBUG - 2022-03-10 23:49:58 --> Total execution time: 0.0549
ERROR - 2022-03-10 23:50:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:50:33 --> Config Class Initialized
INFO - 2022-03-10 23:50:33 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:50:33 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:50:33 --> Utf8 Class Initialized
INFO - 2022-03-10 23:50:33 --> URI Class Initialized
INFO - 2022-03-10 23:50:33 --> Router Class Initialized
INFO - 2022-03-10 23:50:33 --> Output Class Initialized
INFO - 2022-03-10 23:50:33 --> Security Class Initialized
DEBUG - 2022-03-10 23:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:50:33 --> Input Class Initialized
INFO - 2022-03-10 23:50:33 --> Language Class Initialized
INFO - 2022-03-10 23:50:33 --> Loader Class Initialized
INFO - 2022-03-10 23:50:33 --> Helper loaded: url_helper
INFO - 2022-03-10 23:50:33 --> Helper loaded: form_helper
INFO - 2022-03-10 23:50:33 --> Helper loaded: common_helper
INFO - 2022-03-10 23:50:33 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:50:33 --> Controller Class Initialized
INFO - 2022-03-10 23:50:33 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:50:33 --> Encrypt Class Initialized
INFO - 2022-03-10 23:50:33 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:50:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:50:33 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:50:33 --> Model "Users_model" initialized
INFO - 2022-03-10 23:50:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:50:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:50:33 --> Config Class Initialized
INFO - 2022-03-10 23:50:33 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:50:33 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:50:33 --> Utf8 Class Initialized
INFO - 2022-03-10 23:50:33 --> URI Class Initialized
INFO - 2022-03-10 23:50:33 --> Router Class Initialized
INFO - 2022-03-10 23:50:33 --> Output Class Initialized
INFO - 2022-03-10 23:50:33 --> Security Class Initialized
DEBUG - 2022-03-10 23:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:50:33 --> Input Class Initialized
INFO - 2022-03-10 23:50:33 --> Language Class Initialized
INFO - 2022-03-10 23:50:33 --> Loader Class Initialized
INFO - 2022-03-10 23:50:33 --> Helper loaded: url_helper
INFO - 2022-03-10 23:50:33 --> Helper loaded: form_helper
INFO - 2022-03-10 23:50:33 --> Helper loaded: common_helper
INFO - 2022-03-10 23:50:33 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:50:33 --> Controller Class Initialized
INFO - 2022-03-10 23:50:33 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:50:33 --> Encrypt Class Initialized
INFO - 2022-03-10 23:50:33 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:50:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:50:33 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:50:33 --> Model "Users_model" initialized
INFO - 2022-03-10 23:50:33 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:50:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:50:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:50:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:50:33 --> Final output sent to browser
DEBUG - 2022-03-10 23:50:33 --> Total execution time: 0.0643
ERROR - 2022-03-10 23:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:50:38 --> Config Class Initialized
INFO - 2022-03-10 23:50:38 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:50:38 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:50:38 --> Utf8 Class Initialized
INFO - 2022-03-10 23:50:38 --> URI Class Initialized
INFO - 2022-03-10 23:50:38 --> Router Class Initialized
INFO - 2022-03-10 23:50:38 --> Output Class Initialized
INFO - 2022-03-10 23:50:38 --> Security Class Initialized
DEBUG - 2022-03-10 23:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:50:38 --> Input Class Initialized
INFO - 2022-03-10 23:50:38 --> Language Class Initialized
INFO - 2022-03-10 23:50:38 --> Loader Class Initialized
INFO - 2022-03-10 23:50:38 --> Helper loaded: url_helper
INFO - 2022-03-10 23:50:38 --> Helper loaded: form_helper
INFO - 2022-03-10 23:50:38 --> Helper loaded: common_helper
INFO - 2022-03-10 23:50:38 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:50:38 --> Controller Class Initialized
INFO - 2022-03-10 23:50:38 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:50:38 --> Encrypt Class Initialized
INFO - 2022-03-10 23:50:38 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:50:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:50:38 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:50:38 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:50:38 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:50:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:50:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:50:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:50:38 --> Final output sent to browser
DEBUG - 2022-03-10 23:50:38 --> Total execution time: 0.0587
ERROR - 2022-03-10 23:50:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:50:42 --> Config Class Initialized
INFO - 2022-03-10 23:50:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:50:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:50:42 --> Utf8 Class Initialized
INFO - 2022-03-10 23:50:42 --> URI Class Initialized
INFO - 2022-03-10 23:50:42 --> Router Class Initialized
INFO - 2022-03-10 23:50:42 --> Output Class Initialized
INFO - 2022-03-10 23:50:42 --> Security Class Initialized
DEBUG - 2022-03-10 23:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:50:42 --> Input Class Initialized
INFO - 2022-03-10 23:50:42 --> Language Class Initialized
INFO - 2022-03-10 23:50:42 --> Loader Class Initialized
INFO - 2022-03-10 23:50:42 --> Helper loaded: url_helper
INFO - 2022-03-10 23:50:42 --> Helper loaded: form_helper
INFO - 2022-03-10 23:50:42 --> Helper loaded: common_helper
INFO - 2022-03-10 23:50:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:50:43 --> Controller Class Initialized
INFO - 2022-03-10 23:50:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:50:43 --> Encrypt Class Initialized
INFO - 2022-03-10 23:50:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:50:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:50:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:50:43 --> Model "Users_model" initialized
INFO - 2022-03-10 23:50:43 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:50:43 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-10 23:50:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:50:43 --> Config Class Initialized
INFO - 2022-03-10 23:50:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:50:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:50:43 --> Utf8 Class Initialized
INFO - 2022-03-10 23:50:43 --> URI Class Initialized
INFO - 2022-03-10 23:50:43 --> Router Class Initialized
INFO - 2022-03-10 23:50:43 --> Output Class Initialized
INFO - 2022-03-10 23:50:43 --> Security Class Initialized
DEBUG - 2022-03-10 23:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:50:43 --> Input Class Initialized
INFO - 2022-03-10 23:50:43 --> Language Class Initialized
INFO - 2022-03-10 23:50:43 --> Loader Class Initialized
INFO - 2022-03-10 23:50:43 --> Helper loaded: url_helper
INFO - 2022-03-10 23:50:43 --> Helper loaded: form_helper
INFO - 2022-03-10 23:50:43 --> Helper loaded: common_helper
INFO - 2022-03-10 23:50:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:50:43 --> Controller Class Initialized
INFO - 2022-03-10 23:50:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:50:43 --> Encrypt Class Initialized
INFO - 2022-03-10 23:50:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:50:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:50:43 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:50:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:50:43 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:50:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:50:44 --> Final output sent to browser
DEBUG - 2022-03-10 23:50:44 --> Total execution time: 1.6336
INFO - 2022-03-10 23:50:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:50:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:50:51 --> Final output sent to browser
DEBUG - 2022-03-10 23:50:51 --> Total execution time: 6.1525
ERROR - 2022-03-10 23:52:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:10 --> Config Class Initialized
INFO - 2022-03-10 23:52:10 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:10 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:10 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:10 --> URI Class Initialized
INFO - 2022-03-10 23:52:10 --> Router Class Initialized
INFO - 2022-03-10 23:52:10 --> Output Class Initialized
INFO - 2022-03-10 23:52:10 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:10 --> Input Class Initialized
INFO - 2022-03-10 23:52:10 --> Language Class Initialized
INFO - 2022-03-10 23:52:10 --> Loader Class Initialized
INFO - 2022-03-10 23:52:10 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:10 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:10 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:10 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:10 --> Controller Class Initialized
ERROR - 2022-03-10 23:52:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:11 --> Config Class Initialized
INFO - 2022-03-10 23:52:11 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:11 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:11 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:11 --> URI Class Initialized
INFO - 2022-03-10 23:52:11 --> Router Class Initialized
INFO - 2022-03-10 23:52:11 --> Output Class Initialized
INFO - 2022-03-10 23:52:11 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:11 --> Input Class Initialized
INFO - 2022-03-10 23:52:11 --> Language Class Initialized
INFO - 2022-03-10 23:52:11 --> Loader Class Initialized
INFO - 2022-03-10 23:52:11 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:11 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:11 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:11 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:11 --> Controller Class Initialized
INFO - 2022-03-10 23:52:11 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:52:11 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:52:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:52:11 --> Email Class Initialized
INFO - 2022-03-10 23:52:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:52:11 --> Calendar Class Initialized
INFO - 2022-03-10 23:52:11 --> Model "Login_model" initialized
INFO - 2022-03-10 23:52:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 23:52:11 --> Final output sent to browser
DEBUG - 2022-03-10 23:52:11 --> Total execution time: 0.0299
ERROR - 2022-03-10 23:52:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:19 --> Config Class Initialized
INFO - 2022-03-10 23:52:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:19 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:19 --> URI Class Initialized
INFO - 2022-03-10 23:52:19 --> Router Class Initialized
INFO - 2022-03-10 23:52:19 --> Output Class Initialized
INFO - 2022-03-10 23:52:19 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:19 --> Input Class Initialized
INFO - 2022-03-10 23:52:19 --> Language Class Initialized
INFO - 2022-03-10 23:52:19 --> Loader Class Initialized
INFO - 2022-03-10 23:52:19 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:19 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:19 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:19 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:19 --> Controller Class Initialized
ERROR - 2022-03-10 23:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:20 --> Config Class Initialized
INFO - 2022-03-10 23:52:20 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:20 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:20 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:20 --> URI Class Initialized
INFO - 2022-03-10 23:52:20 --> Router Class Initialized
INFO - 2022-03-10 23:52:20 --> Output Class Initialized
INFO - 2022-03-10 23:52:20 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:20 --> Input Class Initialized
INFO - 2022-03-10 23:52:20 --> Language Class Initialized
INFO - 2022-03-10 23:52:20 --> Loader Class Initialized
INFO - 2022-03-10 23:52:20 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:20 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:20 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:20 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:20 --> Controller Class Initialized
INFO - 2022-03-10 23:52:20 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:52:20 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:52:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:52:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:52:20 --> Email Class Initialized
INFO - 2022-03-10 23:52:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:52:20 --> Calendar Class Initialized
INFO - 2022-03-10 23:52:20 --> Model "Login_model" initialized
INFO - 2022-03-10 23:52:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 23:52:20 --> Final output sent to browser
DEBUG - 2022-03-10 23:52:20 --> Total execution time: 0.0268
ERROR - 2022-03-10 23:52:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:26 --> Config Class Initialized
INFO - 2022-03-10 23:52:26 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:26 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:26 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:26 --> URI Class Initialized
INFO - 2022-03-10 23:52:26 --> Router Class Initialized
INFO - 2022-03-10 23:52:26 --> Output Class Initialized
INFO - 2022-03-10 23:52:26 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:26 --> Input Class Initialized
INFO - 2022-03-10 23:52:26 --> Language Class Initialized
INFO - 2022-03-10 23:52:26 --> Loader Class Initialized
INFO - 2022-03-10 23:52:26 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:26 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:26 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:26 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:26 --> Controller Class Initialized
INFO - 2022-03-10 23:52:26 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:52:26 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:52:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:52:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:52:26 --> Email Class Initialized
INFO - 2022-03-10 23:52:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:52:26 --> Calendar Class Initialized
INFO - 2022-03-10 23:52:26 --> Model "Login_model" initialized
INFO - 2022-03-10 23:52:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-10 23:52:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:27 --> Config Class Initialized
INFO - 2022-03-10 23:52:27 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:27 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:27 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:27 --> URI Class Initialized
INFO - 2022-03-10 23:52:27 --> Router Class Initialized
INFO - 2022-03-10 23:52:27 --> Output Class Initialized
INFO - 2022-03-10 23:52:27 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:27 --> Input Class Initialized
INFO - 2022-03-10 23:52:27 --> Language Class Initialized
INFO - 2022-03-10 23:52:27 --> Loader Class Initialized
INFO - 2022-03-10 23:52:27 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:27 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:27 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:27 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:27 --> Controller Class Initialized
INFO - 2022-03-10 23:52:27 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:52:27 --> Encrypt Class Initialized
INFO - 2022-03-10 23:52:27 --> Model "Login_model" initialized
INFO - 2022-03-10 23:52:27 --> Model "Dashboard_model" initialized
INFO - 2022-03-10 23:52:27 --> Model "Case_model" initialized
INFO - 2022-03-10 23:52:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:52:45 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-10 23:52:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:52:45 --> Final output sent to browser
DEBUG - 2022-03-10 23:52:45 --> Total execution time: 18.2029
ERROR - 2022-03-10 23:52:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:46 --> Config Class Initialized
INFO - 2022-03-10 23:52:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:46 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:46 --> URI Class Initialized
INFO - 2022-03-10 23:52:46 --> Router Class Initialized
INFO - 2022-03-10 23:52:46 --> Output Class Initialized
INFO - 2022-03-10 23:52:46 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:46 --> Input Class Initialized
INFO - 2022-03-10 23:52:46 --> Language Class Initialized
ERROR - 2022-03-10 23:52:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 23:52:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:49 --> Config Class Initialized
INFO - 2022-03-10 23:52:49 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:49 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:49 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:49 --> URI Class Initialized
INFO - 2022-03-10 23:52:49 --> Router Class Initialized
INFO - 2022-03-10 23:52:49 --> Output Class Initialized
INFO - 2022-03-10 23:52:49 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:49 --> Input Class Initialized
INFO - 2022-03-10 23:52:49 --> Language Class Initialized
INFO - 2022-03-10 23:52:49 --> Loader Class Initialized
INFO - 2022-03-10 23:52:49 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:49 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:49 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:49 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:49 --> Controller Class Initialized
INFO - 2022-03-10 23:52:49 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:52:49 --> Encrypt Class Initialized
INFO - 2022-03-10 23:52:49 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:52:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:52:49 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:52:49 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:52:49 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:52:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:52:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:52:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:52:49 --> Final output sent to browser
DEBUG - 2022-03-10 23:52:49 --> Total execution time: 0.0521
ERROR - 2022-03-10 23:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:55 --> Config Class Initialized
INFO - 2022-03-10 23:52:55 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:55 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:55 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:55 --> URI Class Initialized
INFO - 2022-03-10 23:52:55 --> Router Class Initialized
INFO - 2022-03-10 23:52:55 --> Output Class Initialized
INFO - 2022-03-10 23:52:55 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:55 --> Input Class Initialized
INFO - 2022-03-10 23:52:55 --> Language Class Initialized
INFO - 2022-03-10 23:52:55 --> Loader Class Initialized
INFO - 2022-03-10 23:52:55 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:55 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:55 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:55 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:55 --> Controller Class Initialized
INFO - 2022-03-10 23:52:55 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:52:55 --> Encrypt Class Initialized
INFO - 2022-03-10 23:52:55 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:52:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:52:55 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:52:55 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:52:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:52:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:56 --> Config Class Initialized
INFO - 2022-03-10 23:52:56 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:56 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:56 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:56 --> URI Class Initialized
INFO - 2022-03-10 23:52:56 --> Router Class Initialized
INFO - 2022-03-10 23:52:56 --> Output Class Initialized
INFO - 2022-03-10 23:52:56 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:56 --> Input Class Initialized
INFO - 2022-03-10 23:52:56 --> Language Class Initialized
INFO - 2022-03-10 23:52:56 --> Loader Class Initialized
INFO - 2022-03-10 23:52:56 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:56 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:56 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:56 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:56 --> Controller Class Initialized
INFO - 2022-03-10 23:52:56 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:52:56 --> Encrypt Class Initialized
INFO - 2022-03-10 23:52:56 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:52:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:52:56 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:52:56 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:52:56 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:52:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:52:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-10 23:52:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:52:56 --> Final output sent to browser
DEBUG - 2022-03-10 23:52:56 --> Total execution time: 0.0733
ERROR - 2022-03-10 23:52:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:52:57 --> Config Class Initialized
INFO - 2022-03-10 23:52:57 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:52:57 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:52:57 --> Utf8 Class Initialized
INFO - 2022-03-10 23:52:57 --> URI Class Initialized
INFO - 2022-03-10 23:52:57 --> Router Class Initialized
INFO - 2022-03-10 23:52:57 --> Output Class Initialized
INFO - 2022-03-10 23:52:57 --> Security Class Initialized
DEBUG - 2022-03-10 23:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:52:57 --> Input Class Initialized
INFO - 2022-03-10 23:52:57 --> Language Class Initialized
INFO - 2022-03-10 23:52:57 --> Loader Class Initialized
INFO - 2022-03-10 23:52:57 --> Helper loaded: url_helper
INFO - 2022-03-10 23:52:57 --> Helper loaded: form_helper
INFO - 2022-03-10 23:52:57 --> Helper loaded: common_helper
INFO - 2022-03-10 23:52:57 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:52:57 --> Controller Class Initialized
INFO - 2022-03-10 23:52:57 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:52:57 --> Encrypt Class Initialized
INFO - 2022-03-10 23:52:57 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:52:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:52:57 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:52:57 --> Model "Users_model" initialized
INFO - 2022-03-10 23:52:57 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:52:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:52:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:52:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:52:57 --> Final output sent to browser
DEBUG - 2022-03-10 23:52:57 --> Total execution time: 0.0629
ERROR - 2022-03-10 23:53:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:53:05 --> Config Class Initialized
INFO - 2022-03-10 23:53:05 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:53:05 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:53:05 --> Utf8 Class Initialized
INFO - 2022-03-10 23:53:05 --> URI Class Initialized
INFO - 2022-03-10 23:53:05 --> Router Class Initialized
INFO - 2022-03-10 23:53:05 --> Output Class Initialized
INFO - 2022-03-10 23:53:05 --> Security Class Initialized
DEBUG - 2022-03-10 23:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:53:05 --> Input Class Initialized
INFO - 2022-03-10 23:53:05 --> Language Class Initialized
ERROR - 2022-03-10 23:53:05 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 23:53:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:53:23 --> Config Class Initialized
INFO - 2022-03-10 23:53:23 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:53:23 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:53:23 --> Utf8 Class Initialized
INFO - 2022-03-10 23:53:23 --> URI Class Initialized
DEBUG - 2022-03-10 23:53:23 --> No URI present. Default controller set.
INFO - 2022-03-10 23:53:23 --> Router Class Initialized
INFO - 2022-03-10 23:53:23 --> Output Class Initialized
INFO - 2022-03-10 23:53:23 --> Security Class Initialized
DEBUG - 2022-03-10 23:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:53:23 --> Input Class Initialized
INFO - 2022-03-10 23:53:23 --> Language Class Initialized
INFO - 2022-03-10 23:53:23 --> Loader Class Initialized
INFO - 2022-03-10 23:53:23 --> Helper loaded: url_helper
INFO - 2022-03-10 23:53:23 --> Helper loaded: form_helper
INFO - 2022-03-10 23:53:23 --> Helper loaded: common_helper
INFO - 2022-03-10 23:53:23 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:53:23 --> Controller Class Initialized
INFO - 2022-03-10 23:53:23 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:53:23 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:53:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:53:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:53:23 --> Email Class Initialized
INFO - 2022-03-10 23:53:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:53:23 --> Calendar Class Initialized
INFO - 2022-03-10 23:53:23 --> Model "Login_model" initialized
INFO - 2022-03-10 23:53:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 23:53:23 --> Final output sent to browser
DEBUG - 2022-03-10 23:53:23 --> Total execution time: 0.0222
ERROR - 2022-03-10 23:53:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:53:23 --> Config Class Initialized
INFO - 2022-03-10 23:53:23 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:53:23 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:53:23 --> Utf8 Class Initialized
INFO - 2022-03-10 23:53:23 --> URI Class Initialized
INFO - 2022-03-10 23:53:23 --> Router Class Initialized
INFO - 2022-03-10 23:53:23 --> Output Class Initialized
INFO - 2022-03-10 23:53:23 --> Security Class Initialized
DEBUG - 2022-03-10 23:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:53:23 --> Input Class Initialized
INFO - 2022-03-10 23:53:23 --> Language Class Initialized
ERROR - 2022-03-10 23:53:23 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 23:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:54:46 --> Config Class Initialized
INFO - 2022-03-10 23:54:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:54:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:54:46 --> Utf8 Class Initialized
INFO - 2022-03-10 23:54:46 --> URI Class Initialized
INFO - 2022-03-10 23:54:46 --> Router Class Initialized
INFO - 2022-03-10 23:54:46 --> Output Class Initialized
INFO - 2022-03-10 23:54:46 --> Security Class Initialized
DEBUG - 2022-03-10 23:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:54:46 --> Input Class Initialized
INFO - 2022-03-10 23:54:46 --> Language Class Initialized
INFO - 2022-03-10 23:54:46 --> Loader Class Initialized
INFO - 2022-03-10 23:54:46 --> Helper loaded: url_helper
INFO - 2022-03-10 23:54:46 --> Helper loaded: form_helper
INFO - 2022-03-10 23:54:46 --> Helper loaded: common_helper
INFO - 2022-03-10 23:54:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:54:46 --> Controller Class Initialized
INFO - 2022-03-10 23:54:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:54:46 --> Encrypt Class Initialized
INFO - 2022-03-10 23:54:46 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:54:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:54:46 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:54:46 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:54:46 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:54:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:54:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:54:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:54:54 --> Final output sent to browser
DEBUG - 2022-03-10 23:54:54 --> Total execution time: 6.6549
ERROR - 2022-03-10 23:55:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:55:41 --> Config Class Initialized
INFO - 2022-03-10 23:55:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:55:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:55:41 --> Utf8 Class Initialized
INFO - 2022-03-10 23:55:41 --> URI Class Initialized
INFO - 2022-03-10 23:55:41 --> Router Class Initialized
INFO - 2022-03-10 23:55:41 --> Output Class Initialized
INFO - 2022-03-10 23:55:41 --> Security Class Initialized
DEBUG - 2022-03-10 23:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:55:41 --> Input Class Initialized
INFO - 2022-03-10 23:55:41 --> Language Class Initialized
INFO - 2022-03-10 23:55:41 --> Loader Class Initialized
INFO - 2022-03-10 23:55:41 --> Helper loaded: url_helper
INFO - 2022-03-10 23:55:41 --> Helper loaded: form_helper
INFO - 2022-03-10 23:55:41 --> Helper loaded: common_helper
INFO - 2022-03-10 23:55:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:55:41 --> Controller Class Initialized
INFO - 2022-03-10 23:55:41 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:55:41 --> Encrypt Class Initialized
INFO - 2022-03-10 23:55:41 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:55:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:55:41 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:55:41 --> Model "Users_model" initialized
INFO - 2022-03-10 23:55:41 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:55:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:55:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:55:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:55:41 --> Final output sent to browser
DEBUG - 2022-03-10 23:55:41 --> Total execution time: 0.0937
ERROR - 2022-03-10 23:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:55:49 --> Config Class Initialized
INFO - 2022-03-10 23:55:49 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:55:49 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:55:49 --> Utf8 Class Initialized
INFO - 2022-03-10 23:55:49 --> URI Class Initialized
INFO - 2022-03-10 23:55:49 --> Router Class Initialized
INFO - 2022-03-10 23:55:49 --> Output Class Initialized
INFO - 2022-03-10 23:55:49 --> Security Class Initialized
DEBUG - 2022-03-10 23:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:55:50 --> Input Class Initialized
INFO - 2022-03-10 23:55:50 --> Language Class Initialized
ERROR - 2022-03-10 23:55:50 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-10 23:55:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:55:58 --> Config Class Initialized
INFO - 2022-03-10 23:55:58 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:55:58 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:55:58 --> Utf8 Class Initialized
INFO - 2022-03-10 23:55:58 --> URI Class Initialized
INFO - 2022-03-10 23:55:58 --> Router Class Initialized
INFO - 2022-03-10 23:55:58 --> Output Class Initialized
INFO - 2022-03-10 23:55:58 --> Security Class Initialized
DEBUG - 2022-03-10 23:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:55:58 --> Input Class Initialized
INFO - 2022-03-10 23:55:58 --> Language Class Initialized
INFO - 2022-03-10 23:55:58 --> Loader Class Initialized
INFO - 2022-03-10 23:55:58 --> Helper loaded: url_helper
INFO - 2022-03-10 23:55:58 --> Helper loaded: form_helper
INFO - 2022-03-10 23:55:58 --> Helper loaded: common_helper
INFO - 2022-03-10 23:55:58 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:55:58 --> Controller Class Initialized
INFO - 2022-03-10 23:55:58 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:55:58 --> Encrypt Class Initialized
INFO - 2022-03-10 23:55:58 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:55:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:55:58 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:55:58 --> Model "Users_model" initialized
INFO - 2022-03-10 23:55:58 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:55:58 --> Final output sent to browser
DEBUG - 2022-03-10 23:55:58 --> Total execution time: 0.0395
ERROR - 2022-03-10 23:56:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:56:05 --> Config Class Initialized
INFO - 2022-03-10 23:56:05 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:56:05 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:56:05 --> Utf8 Class Initialized
INFO - 2022-03-10 23:56:05 --> URI Class Initialized
INFO - 2022-03-10 23:56:05 --> Router Class Initialized
INFO - 2022-03-10 23:56:05 --> Output Class Initialized
INFO - 2022-03-10 23:56:05 --> Security Class Initialized
DEBUG - 2022-03-10 23:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:56:05 --> Input Class Initialized
INFO - 2022-03-10 23:56:05 --> Language Class Initialized
INFO - 2022-03-10 23:56:05 --> Loader Class Initialized
INFO - 2022-03-10 23:56:05 --> Helper loaded: url_helper
INFO - 2022-03-10 23:56:05 --> Helper loaded: form_helper
INFO - 2022-03-10 23:56:05 --> Helper loaded: common_helper
INFO - 2022-03-10 23:56:05 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:56:05 --> Controller Class Initialized
INFO - 2022-03-10 23:56:05 --> Form Validation Class Initialized
INFO - 2022-03-10 23:56:05 --> Model "Case_model" initialized
INFO - 2022-03-10 23:56:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:56:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:56:07 --> Model "Case_model" initialized
INFO - 2022-03-10 23:56:11 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2022-03-10 23:56:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:56:12 --> Final output sent to browser
DEBUG - 2022-03-10 23:56:12 --> Total execution time: 6.6891
ERROR - 2022-03-10 23:56:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:56:12 --> Config Class Initialized
INFO - 2022-03-10 23:56:12 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:56:12 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:56:12 --> Utf8 Class Initialized
INFO - 2022-03-10 23:56:12 --> URI Class Initialized
INFO - 2022-03-10 23:56:12 --> Router Class Initialized
INFO - 2022-03-10 23:56:12 --> Output Class Initialized
INFO - 2022-03-10 23:56:12 --> Security Class Initialized
DEBUG - 2022-03-10 23:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:56:12 --> Input Class Initialized
INFO - 2022-03-10 23:56:12 --> Language Class Initialized
ERROR - 2022-03-10 23:56:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 23:56:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:56:18 --> Config Class Initialized
INFO - 2022-03-10 23:56:18 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:56:18 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:56:18 --> Utf8 Class Initialized
INFO - 2022-03-10 23:56:18 --> URI Class Initialized
INFO - 2022-03-10 23:56:18 --> Router Class Initialized
INFO - 2022-03-10 23:56:18 --> Output Class Initialized
INFO - 2022-03-10 23:56:18 --> Security Class Initialized
DEBUG - 2022-03-10 23:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:56:18 --> Input Class Initialized
INFO - 2022-03-10 23:56:18 --> Language Class Initialized
INFO - 2022-03-10 23:56:18 --> Loader Class Initialized
INFO - 2022-03-10 23:56:18 --> Helper loaded: url_helper
INFO - 2022-03-10 23:56:18 --> Helper loaded: form_helper
INFO - 2022-03-10 23:56:18 --> Helper loaded: common_helper
INFO - 2022-03-10 23:56:18 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:56:18 --> Controller Class Initialized
INFO - 2022-03-10 23:56:18 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:56:18 --> Encrypt Class Initialized
INFO - 2022-03-10 23:56:18 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:56:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:56:18 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:56:18 --> Model "Users_model" initialized
INFO - 2022-03-10 23:56:18 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:56:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:56:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:56:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:56:18 --> Final output sent to browser
DEBUG - 2022-03-10 23:56:18 --> Total execution time: 0.0547
ERROR - 2022-03-10 23:56:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:56:19 --> Config Class Initialized
INFO - 2022-03-10 23:56:19 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:56:19 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:56:19 --> Utf8 Class Initialized
INFO - 2022-03-10 23:56:19 --> URI Class Initialized
INFO - 2022-03-10 23:56:19 --> Router Class Initialized
INFO - 2022-03-10 23:56:19 --> Output Class Initialized
INFO - 2022-03-10 23:56:19 --> Security Class Initialized
DEBUG - 2022-03-10 23:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:56:19 --> Input Class Initialized
INFO - 2022-03-10 23:56:19 --> Language Class Initialized
ERROR - 2022-03-10 23:56:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-10 23:57:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:57:17 --> Config Class Initialized
INFO - 2022-03-10 23:57:17 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:57:17 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:57:17 --> Utf8 Class Initialized
INFO - 2022-03-10 23:57:17 --> URI Class Initialized
INFO - 2022-03-10 23:57:17 --> Router Class Initialized
INFO - 2022-03-10 23:57:17 --> Output Class Initialized
INFO - 2022-03-10 23:57:17 --> Security Class Initialized
DEBUG - 2022-03-10 23:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:57:17 --> Input Class Initialized
INFO - 2022-03-10 23:57:17 --> Language Class Initialized
INFO - 2022-03-10 23:57:17 --> Loader Class Initialized
INFO - 2022-03-10 23:57:17 --> Helper loaded: url_helper
INFO - 2022-03-10 23:57:17 --> Helper loaded: form_helper
INFO - 2022-03-10 23:57:17 --> Helper loaded: common_helper
INFO - 2022-03-10 23:57:17 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:57:17 --> Controller Class Initialized
INFO - 2022-03-10 23:57:17 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:57:17 --> Encrypt Class Initialized
INFO - 2022-03-10 23:57:17 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:57:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:57:17 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:57:17 --> Model "Users_model" initialized
INFO - 2022-03-10 23:57:17 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:57:17 --> Upload Class Initialized
INFO - 2022-03-10 23:57:17 --> Final output sent to browser
DEBUG - 2022-03-10 23:57:17 --> Total execution time: 0.0493
ERROR - 2022-03-10 23:57:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:57:21 --> Config Class Initialized
INFO - 2022-03-10 23:57:21 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:57:21 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:57:21 --> Utf8 Class Initialized
INFO - 2022-03-10 23:57:21 --> URI Class Initialized
INFO - 2022-03-10 23:57:21 --> Router Class Initialized
INFO - 2022-03-10 23:57:21 --> Output Class Initialized
INFO - 2022-03-10 23:57:21 --> Security Class Initialized
DEBUG - 2022-03-10 23:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:57:21 --> Input Class Initialized
INFO - 2022-03-10 23:57:21 --> Language Class Initialized
INFO - 2022-03-10 23:57:21 --> Loader Class Initialized
INFO - 2022-03-10 23:57:21 --> Helper loaded: url_helper
INFO - 2022-03-10 23:57:21 --> Helper loaded: form_helper
INFO - 2022-03-10 23:57:21 --> Helper loaded: common_helper
INFO - 2022-03-10 23:57:21 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:57:21 --> Controller Class Initialized
INFO - 2022-03-10 23:57:21 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:57:21 --> Encrypt Class Initialized
INFO - 2022-03-10 23:57:21 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:57:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:57:21 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:57:21 --> Model "Users_model" initialized
INFO - 2022-03-10 23:57:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:57:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:57:22 --> Config Class Initialized
INFO - 2022-03-10 23:57:22 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:57:22 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:57:22 --> Utf8 Class Initialized
INFO - 2022-03-10 23:57:22 --> URI Class Initialized
INFO - 2022-03-10 23:57:22 --> Router Class Initialized
INFO - 2022-03-10 23:57:22 --> Output Class Initialized
INFO - 2022-03-10 23:57:22 --> Security Class Initialized
DEBUG - 2022-03-10 23:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:57:22 --> Input Class Initialized
INFO - 2022-03-10 23:57:22 --> Language Class Initialized
INFO - 2022-03-10 23:57:22 --> Loader Class Initialized
INFO - 2022-03-10 23:57:22 --> Helper loaded: url_helper
INFO - 2022-03-10 23:57:22 --> Helper loaded: form_helper
INFO - 2022-03-10 23:57:22 --> Helper loaded: common_helper
INFO - 2022-03-10 23:57:22 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:57:22 --> Controller Class Initialized
INFO - 2022-03-10 23:57:22 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:57:22 --> Encrypt Class Initialized
INFO - 2022-03-10 23:57:22 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:57:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:57:22 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:57:22 --> Model "Users_model" initialized
INFO - 2022-03-10 23:57:22 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:57:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:57:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:57:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:57:22 --> Final output sent to browser
DEBUG - 2022-03-10 23:57:22 --> Total execution time: 0.0989
ERROR - 2022-03-10 23:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:57:42 --> Config Class Initialized
INFO - 2022-03-10 23:57:42 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:57:42 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:57:42 --> Utf8 Class Initialized
INFO - 2022-03-10 23:57:42 --> URI Class Initialized
INFO - 2022-03-10 23:57:42 --> Router Class Initialized
INFO - 2022-03-10 23:57:42 --> Output Class Initialized
INFO - 2022-03-10 23:57:42 --> Security Class Initialized
DEBUG - 2022-03-10 23:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:57:42 --> Input Class Initialized
INFO - 2022-03-10 23:57:42 --> Language Class Initialized
INFO - 2022-03-10 23:57:42 --> Loader Class Initialized
INFO - 2022-03-10 23:57:42 --> Helper loaded: url_helper
INFO - 2022-03-10 23:57:42 --> Helper loaded: form_helper
INFO - 2022-03-10 23:57:42 --> Helper loaded: common_helper
INFO - 2022-03-10 23:57:42 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:57:42 --> Controller Class Initialized
INFO - 2022-03-10 23:57:42 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:57:42 --> Encrypt Class Initialized
INFO - 2022-03-10 23:57:42 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:57:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:57:42 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:57:42 --> Model "Users_model" initialized
INFO - 2022-03-10 23:57:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-10 23:57:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:57:43 --> Config Class Initialized
INFO - 2022-03-10 23:57:43 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:57:43 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:57:43 --> Utf8 Class Initialized
INFO - 2022-03-10 23:57:43 --> URI Class Initialized
INFO - 2022-03-10 23:57:43 --> Router Class Initialized
INFO - 2022-03-10 23:57:43 --> Output Class Initialized
INFO - 2022-03-10 23:57:43 --> Security Class Initialized
DEBUG - 2022-03-10 23:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:57:43 --> Input Class Initialized
INFO - 2022-03-10 23:57:43 --> Language Class Initialized
INFO - 2022-03-10 23:57:43 --> Loader Class Initialized
INFO - 2022-03-10 23:57:43 --> Helper loaded: url_helper
INFO - 2022-03-10 23:57:43 --> Helper loaded: form_helper
INFO - 2022-03-10 23:57:43 --> Helper loaded: common_helper
INFO - 2022-03-10 23:57:43 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:57:43 --> Controller Class Initialized
INFO - 2022-03-10 23:57:43 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:57:43 --> Encrypt Class Initialized
INFO - 2022-03-10 23:57:43 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:57:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:57:43 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:57:43 --> Model "Users_model" initialized
INFO - 2022-03-10 23:57:43 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:57:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:57:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:57:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:57:43 --> Final output sent to browser
DEBUG - 2022-03-10 23:57:43 --> Total execution time: 0.0652
ERROR - 2022-03-10 23:57:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:57:52 --> Config Class Initialized
INFO - 2022-03-10 23:57:52 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:57:52 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:57:52 --> Utf8 Class Initialized
INFO - 2022-03-10 23:57:52 --> URI Class Initialized
INFO - 2022-03-10 23:57:52 --> Router Class Initialized
INFO - 2022-03-10 23:57:52 --> Output Class Initialized
INFO - 2022-03-10 23:57:52 --> Security Class Initialized
DEBUG - 2022-03-10 23:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:57:52 --> Input Class Initialized
INFO - 2022-03-10 23:57:52 --> Language Class Initialized
INFO - 2022-03-10 23:57:52 --> Loader Class Initialized
INFO - 2022-03-10 23:57:52 --> Helper loaded: url_helper
INFO - 2022-03-10 23:57:52 --> Helper loaded: form_helper
INFO - 2022-03-10 23:57:52 --> Helper loaded: common_helper
INFO - 2022-03-10 23:57:52 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:57:52 --> Controller Class Initialized
INFO - 2022-03-10 23:57:52 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:57:52 --> Encrypt Class Initialized
INFO - 2022-03-10 23:57:52 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:57:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:57:52 --> Model "Referredby_model" initialized
INFO - 2022-03-10 23:57:52 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:57:52 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:57:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:57:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-10 23:57:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:58:00 --> Final output sent to browser
DEBUG - 2022-03-10 23:58:00 --> Total execution time: 6.2040
ERROR - 2022-03-10 23:58:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:58:34 --> Config Class Initialized
INFO - 2022-03-10 23:58:34 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:58:34 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:58:34 --> Utf8 Class Initialized
INFO - 2022-03-10 23:58:34 --> URI Class Initialized
INFO - 2022-03-10 23:58:34 --> Router Class Initialized
INFO - 2022-03-10 23:58:34 --> Output Class Initialized
INFO - 2022-03-10 23:58:34 --> Security Class Initialized
DEBUG - 2022-03-10 23:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:58:34 --> Input Class Initialized
INFO - 2022-03-10 23:58:34 --> Language Class Initialized
INFO - 2022-03-10 23:58:34 --> Loader Class Initialized
INFO - 2022-03-10 23:58:34 --> Helper loaded: url_helper
INFO - 2022-03-10 23:58:34 --> Helper loaded: form_helper
INFO - 2022-03-10 23:58:34 --> Helper loaded: common_helper
INFO - 2022-03-10 23:58:34 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:58:34 --> Controller Class Initialized
INFO - 2022-03-10 23:58:34 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:58:34 --> Encrypt Class Initialized
INFO - 2022-03-10 23:58:34 --> Model "Patient_model" initialized
INFO - 2022-03-10 23:58:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-10 23:58:34 --> Model "Prefix_master" initialized
INFO - 2022-03-10 23:58:34 --> Model "Users_model" initialized
INFO - 2022-03-10 23:58:34 --> Model "Hospital_model" initialized
INFO - 2022-03-10 23:58:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-10 23:58:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-10 23:58:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-10 23:58:34 --> Final output sent to browser
DEBUG - 2022-03-10 23:58:34 --> Total execution time: 0.0960
ERROR - 2022-03-10 23:58:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:58:46 --> Config Class Initialized
INFO - 2022-03-10 23:58:46 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:58:46 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:58:46 --> Utf8 Class Initialized
INFO - 2022-03-10 23:58:46 --> URI Class Initialized
DEBUG - 2022-03-10 23:58:46 --> No URI present. Default controller set.
INFO - 2022-03-10 23:58:46 --> Router Class Initialized
INFO - 2022-03-10 23:58:46 --> Output Class Initialized
INFO - 2022-03-10 23:58:46 --> Security Class Initialized
DEBUG - 2022-03-10 23:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:58:46 --> Input Class Initialized
INFO - 2022-03-10 23:58:46 --> Language Class Initialized
INFO - 2022-03-10 23:58:46 --> Loader Class Initialized
INFO - 2022-03-10 23:58:46 --> Helper loaded: url_helper
INFO - 2022-03-10 23:58:46 --> Helper loaded: form_helper
INFO - 2022-03-10 23:58:46 --> Helper loaded: common_helper
INFO - 2022-03-10 23:58:46 --> Database Driver Class Initialized
DEBUG - 2022-03-10 23:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 23:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 23:58:46 --> Controller Class Initialized
INFO - 2022-03-10 23:58:46 --> Form Validation Class Initialized
DEBUG - 2022-03-10 23:58:46 --> Encrypt Class Initialized
DEBUG - 2022-03-10 23:58:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 23:58:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-10 23:58:46 --> Email Class Initialized
INFO - 2022-03-10 23:58:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-10 23:58:46 --> Calendar Class Initialized
INFO - 2022-03-10 23:58:46 --> Model "Login_model" initialized
INFO - 2022-03-10 23:58:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-10 23:58:46 --> Final output sent to browser
DEBUG - 2022-03-10 23:58:46 --> Total execution time: 0.0207
ERROR - 2022-03-10 23:58:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-10 23:58:47 --> Config Class Initialized
INFO - 2022-03-10 23:58:47 --> Hooks Class Initialized
DEBUG - 2022-03-10 23:58:47 --> UTF-8 Support Enabled
INFO - 2022-03-10 23:58:47 --> Utf8 Class Initialized
INFO - 2022-03-10 23:58:47 --> URI Class Initialized
INFO - 2022-03-10 23:58:47 --> Router Class Initialized
INFO - 2022-03-10 23:58:47 --> Output Class Initialized
INFO - 2022-03-10 23:58:47 --> Security Class Initialized
DEBUG - 2022-03-10 23:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 23:58:47 --> Input Class Initialized
INFO - 2022-03-10 23:58:47 --> Language Class Initialized
ERROR - 2022-03-10 23:58:47 --> 404 Page Not Found: Karoclient/file_uploads
