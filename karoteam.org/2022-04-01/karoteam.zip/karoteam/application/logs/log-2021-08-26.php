<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-26 23:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:19 --> Config Class Initialized
INFO - 2021-08-26 23:49:19 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:19 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:19 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:19 --> URI Class Initialized
DEBUG - 2021-08-26 23:49:19 --> No URI present. Default controller set.
INFO - 2021-08-26 23:49:19 --> Router Class Initialized
INFO - 2021-08-26 23:49:19 --> Output Class Initialized
INFO - 2021-08-26 23:49:19 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:19 --> Input Class Initialized
INFO - 2021-08-26 23:49:19 --> Language Class Initialized
INFO - 2021-08-26 23:49:19 --> Loader Class Initialized
INFO - 2021-08-26 23:49:19 --> Helper loaded: url_helper
INFO - 2021-08-26 23:49:19 --> Helper loaded: form_helper
INFO - 2021-08-26 23:49:19 --> Helper loaded: common_helper
INFO - 2021-08-26 23:49:19 --> Database Driver Class Initialized
DEBUG - 2021-08-26 23:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 23:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 23:49:19 --> Controller Class Initialized
INFO - 2021-08-26 23:49:19 --> Form Validation Class Initialized
DEBUG - 2021-08-26 23:49:19 --> Encrypt Class Initialized
DEBUG - 2021-08-26 23:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-26 23:49:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-26 23:49:19 --> Email Class Initialized
INFO - 2021-08-26 23:49:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-26 23:49:19 --> Calendar Class Initialized
INFO - 2021-08-26 23:49:19 --> Model "Login_model" initialized
INFO - 2021-08-26 23:49:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-26 23:49:19 --> Final output sent to browser
DEBUG - 2021-08-26 23:49:19 --> Total execution time: 0.0388
ERROR - 2021-08-26 23:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:20 --> Config Class Initialized
INFO - 2021-08-26 23:49:20 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:20 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:20 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:20 --> URI Class Initialized
INFO - 2021-08-26 23:49:20 --> Router Class Initialized
INFO - 2021-08-26 23:49:20 --> Output Class Initialized
INFO - 2021-08-26 23:49:20 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:20 --> Input Class Initialized
INFO - 2021-08-26 23:49:20 --> Language Class Initialized
ERROR - 2021-08-26 23:49:20 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-08-26 23:49:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:21 --> Config Class Initialized
INFO - 2021-08-26 23:49:21 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:21 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:21 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:21 --> URI Class Initialized
INFO - 2021-08-26 23:49:21 --> Router Class Initialized
INFO - 2021-08-26 23:49:21 --> Output Class Initialized
INFO - 2021-08-26 23:49:21 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:21 --> Input Class Initialized
INFO - 2021-08-26 23:49:21 --> Language Class Initialized
ERROR - 2021-08-26 23:49:21 --> 404 Page Not Found: Issmall/index
ERROR - 2021-08-26 23:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:23 --> Config Class Initialized
INFO - 2021-08-26 23:49:23 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:23 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:23 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:23 --> URI Class Initialized
INFO - 2021-08-26 23:49:23 --> Router Class Initialized
INFO - 2021-08-26 23:49:23 --> Output Class Initialized
INFO - 2021-08-26 23:49:23 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:23 --> Input Class Initialized
INFO - 2021-08-26 23:49:23 --> Language Class Initialized
ERROR - 2021-08-26 23:49:23 --> 404 Page Not Found: New_gb/help
ERROR - 2021-08-26 23:49:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:24 --> Config Class Initialized
INFO - 2021-08-26 23:49:24 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:24 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:24 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:24 --> URI Class Initialized
INFO - 2021-08-26 23:49:24 --> Router Class Initialized
INFO - 2021-08-26 23:49:24 --> Output Class Initialized
INFO - 2021-08-26 23:49:24 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:24 --> Input Class Initialized
INFO - 2021-08-26 23:49:24 --> Language Class Initialized
ERROR - 2021-08-26 23:49:24 --> 404 Page Not Found: Web2/login_template
ERROR - 2021-08-26 23:49:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:25 --> Config Class Initialized
INFO - 2021-08-26 23:49:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:25 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:25 --> URI Class Initialized
INFO - 2021-08-26 23:49:25 --> Router Class Initialized
INFO - 2021-08-26 23:49:25 --> Output Class Initialized
INFO - 2021-08-26 23:49:25 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:25 --> Input Class Initialized
INFO - 2021-08-26 23:49:25 --> Language Class Initialized
ERROR - 2021-08-26 23:49:25 --> 404 Page Not Found: Docs/index
ERROR - 2021-08-26 23:49:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:25 --> Config Class Initialized
INFO - 2021-08-26 23:49:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:25 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:25 --> URI Class Initialized
DEBUG - 2021-08-26 23:49:25 --> No URI present. Default controller set.
INFO - 2021-08-26 23:49:25 --> Router Class Initialized
INFO - 2021-08-26 23:49:25 --> Output Class Initialized
INFO - 2021-08-26 23:49:25 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:25 --> Input Class Initialized
INFO - 2021-08-26 23:49:25 --> Language Class Initialized
INFO - 2021-08-26 23:49:25 --> Loader Class Initialized
INFO - 2021-08-26 23:49:25 --> Helper loaded: url_helper
INFO - 2021-08-26 23:49:25 --> Helper loaded: form_helper
INFO - 2021-08-26 23:49:25 --> Helper loaded: common_helper
INFO - 2021-08-26 23:49:25 --> Database Driver Class Initialized
DEBUG - 2021-08-26 23:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 23:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 23:49:25 --> Controller Class Initialized
INFO - 2021-08-26 23:49:25 --> Form Validation Class Initialized
DEBUG - 2021-08-26 23:49:25 --> Encrypt Class Initialized
DEBUG - 2021-08-26 23:49:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-26 23:49:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-26 23:49:25 --> Email Class Initialized
INFO - 2021-08-26 23:49:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-26 23:49:25 --> Calendar Class Initialized
INFO - 2021-08-26 23:49:25 --> Model "Login_model" initialized
INFO - 2021-08-26 23:49:25 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-26 23:49:25 --> Final output sent to browser
DEBUG - 2021-08-26 23:49:25 --> Total execution time: 0.0193
ERROR - 2021-08-26 23:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:26 --> Config Class Initialized
INFO - 2021-08-26 23:49:26 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:26 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:26 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:26 --> URI Class Initialized
INFO - 2021-08-26 23:49:26 --> Router Class Initialized
INFO - 2021-08-26 23:49:26 --> Output Class Initialized
INFO - 2021-08-26 23:49:26 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:26 --> Input Class Initialized
INFO - 2021-08-26 23:49:26 --> Language Class Initialized
ERROR - 2021-08-26 23:49:26 --> 404 Page Not Found: Tpl/user
ERROR - 2021-08-26 23:49:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:27 --> Config Class Initialized
INFO - 2021-08-26 23:49:27 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:27 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:27 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:27 --> URI Class Initialized
INFO - 2021-08-26 23:49:27 --> Router Class Initialized
INFO - 2021-08-26 23:49:27 --> Output Class Initialized
INFO - 2021-08-26 23:49:27 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:27 --> Input Class Initialized
INFO - 2021-08-26 23:49:27 --> Language Class Initialized
ERROR - 2021-08-26 23:49:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-26 23:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:28 --> Config Class Initialized
INFO - 2021-08-26 23:49:28 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:28 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:28 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:28 --> URI Class Initialized
INFO - 2021-08-26 23:49:28 --> Router Class Initialized
INFO - 2021-08-26 23:49:28 --> Output Class Initialized
INFO - 2021-08-26 23:49:28 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:28 --> Input Class Initialized
INFO - 2021-08-26 23:49:28 --> Language Class Initialized
ERROR - 2021-08-26 23:49:28 --> 404 Page Not Found: Images/login
ERROR - 2021-08-26 23:49:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:29 --> Config Class Initialized
INFO - 2021-08-26 23:49:29 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:29 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:29 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:29 --> URI Class Initialized
INFO - 2021-08-26 23:49:29 --> Router Class Initialized
INFO - 2021-08-26 23:49:29 --> Output Class Initialized
INFO - 2021-08-26 23:49:29 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:29 --> Input Class Initialized
INFO - 2021-08-26 23:49:29 --> Language Class Initialized
ERROR - 2021-08-26 23:49:29 --> 404 Page Not Found: Images/login
ERROR - 2021-08-26 23:49:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:30 --> Config Class Initialized
INFO - 2021-08-26 23:49:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:30 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:30 --> URI Class Initialized
INFO - 2021-08-26 23:49:30 --> Router Class Initialized
INFO - 2021-08-26 23:49:30 --> Output Class Initialized
INFO - 2021-08-26 23:49:30 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:30 --> Input Class Initialized
INFO - 2021-08-26 23:49:30 --> Language Class Initialized
ERROR - 2021-08-26 23:49:30 --> 404 Page Not Found: Tpl/login
ERROR - 2021-08-26 23:49:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:30 --> Config Class Initialized
INFO - 2021-08-26 23:49:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:30 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:30 --> URI Class Initialized
INFO - 2021-08-26 23:49:30 --> Router Class Initialized
INFO - 2021-08-26 23:49:30 --> Output Class Initialized
INFO - 2021-08-26 23:49:30 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:30 --> Input Class Initialized
INFO - 2021-08-26 23:49:30 --> Language Class Initialized
ERROR - 2021-08-26 23:49:30 --> 404 Page Not Found: Images/login
ERROR - 2021-08-26 23:49:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:31 --> Config Class Initialized
INFO - 2021-08-26 23:49:31 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:31 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:31 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:31 --> URI Class Initialized
INFO - 2021-08-26 23:49:31 --> Router Class Initialized
INFO - 2021-08-26 23:49:31 --> Output Class Initialized
INFO - 2021-08-26 23:49:31 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:31 --> Input Class Initialized
INFO - 2021-08-26 23:49:31 --> Language Class Initialized
ERROR - 2021-08-26 23:49:31 --> 404 Page Not Found: Docscss/index
ERROR - 2021-08-26 23:49:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:32 --> Config Class Initialized
INFO - 2021-08-26 23:49:32 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:32 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:32 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:32 --> URI Class Initialized
INFO - 2021-08-26 23:49:32 --> Router Class Initialized
INFO - 2021-08-26 23:49:32 --> Output Class Initialized
INFO - 2021-08-26 23:49:32 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:32 --> Input Class Initialized
INFO - 2021-08-26 23:49:32 --> Language Class Initialized
ERROR - 2021-08-26 23:49:32 --> 404 Page Not Found: Phpmyadmin/themes
ERROR - 2021-08-26 23:49:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:32 --> Config Class Initialized
INFO - 2021-08-26 23:49:32 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:32 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:32 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:32 --> URI Class Initialized
INFO - 2021-08-26 23:49:32 --> Router Class Initialized
INFO - 2021-08-26 23:49:32 --> Output Class Initialized
INFO - 2021-08-26 23:49:32 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:32 --> Input Class Initialized
INFO - 2021-08-26 23:49:32 --> Language Class Initialized
ERROR - 2021-08-26 23:49:32 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-08-26 23:49:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:33 --> Config Class Initialized
INFO - 2021-08-26 23:49:33 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:33 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:33 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:33 --> URI Class Initialized
INFO - 2021-08-26 23:49:33 --> Router Class Initialized
INFO - 2021-08-26 23:49:33 --> Output Class Initialized
INFO - 2021-08-26 23:49:33 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:33 --> Input Class Initialized
INFO - 2021-08-26 23:49:33 --> Language Class Initialized
ERROR - 2021-08-26 23:49:33 --> 404 Page Not Found: Phpmyadmin/docs.css
ERROR - 2021-08-26 23:49:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:33 --> Config Class Initialized
INFO - 2021-08-26 23:49:33 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:33 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:33 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:33 --> URI Class Initialized
INFO - 2021-08-26 23:49:33 --> Router Class Initialized
INFO - 2021-08-26 23:49:33 --> Output Class Initialized
INFO - 2021-08-26 23:49:33 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:33 --> Input Class Initialized
INFO - 2021-08-26 23:49:33 --> Language Class Initialized
ERROR - 2021-08-26 23:49:33 --> 404 Page Not Found: Fckeditor/fckconfig.js
ERROR - 2021-08-26 23:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:34 --> Config Class Initialized
INFO - 2021-08-26 23:49:34 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:34 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:34 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:34 --> URI Class Initialized
INFO - 2021-08-26 23:49:34 --> Router Class Initialized
INFO - 2021-08-26 23:49:34 --> Output Class Initialized
INFO - 2021-08-26 23:49:34 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:34 --> Input Class Initialized
INFO - 2021-08-26 23:49:34 --> Language Class Initialized
ERROR - 2021-08-26 23:49:34 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-08-26 23:49:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:35 --> Config Class Initialized
INFO - 2021-08-26 23:49:35 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:35 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:35 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:35 --> URI Class Initialized
INFO - 2021-08-26 23:49:35 --> Router Class Initialized
INFO - 2021-08-26 23:49:35 --> Output Class Initialized
INFO - 2021-08-26 23:49:35 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:35 --> Input Class Initialized
INFO - 2021-08-26 23:49:35 --> Language Class Initialized
ERROR - 2021-08-26 23:49:35 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-08-26 23:49:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:35 --> Config Class Initialized
INFO - 2021-08-26 23:49:35 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:35 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:35 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:35 --> URI Class Initialized
INFO - 2021-08-26 23:49:35 --> Router Class Initialized
INFO - 2021-08-26 23:49:35 --> Output Class Initialized
INFO - 2021-08-26 23:49:35 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:35 --> Input Class Initialized
INFO - 2021-08-26 23:49:35 --> Language Class Initialized
ERROR - 2021-08-26 23:49:35 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-08-26 23:49:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:36 --> Config Class Initialized
INFO - 2021-08-26 23:49:36 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:36 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:36 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:36 --> URI Class Initialized
INFO - 2021-08-26 23:49:36 --> Router Class Initialized
INFO - 2021-08-26 23:49:36 --> Output Class Initialized
INFO - 2021-08-26 23:49:36 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:36 --> Input Class Initialized
INFO - 2021-08-26 23:49:36 --> Language Class Initialized
ERROR - 2021-08-26 23:49:36 --> 404 Page Not Found: Fckeditor/fckeditor.js
ERROR - 2021-08-26 23:49:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:36 --> Config Class Initialized
INFO - 2021-08-26 23:49:36 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:36 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:36 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:36 --> URI Class Initialized
INFO - 2021-08-26 23:49:36 --> Router Class Initialized
INFO - 2021-08-26 23:49:36 --> Output Class Initialized
INFO - 2021-08-26 23:49:36 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:36 --> Input Class Initialized
INFO - 2021-08-26 23:49:36 --> Language Class Initialized
ERROR - 2021-08-26 23:49:36 --> 404 Page Not Found: FCK/editor
ERROR - 2021-08-26 23:49:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:37 --> Config Class Initialized
INFO - 2021-08-26 23:49:37 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:37 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:37 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:37 --> URI Class Initialized
INFO - 2021-08-26 23:49:37 --> Router Class Initialized
INFO - 2021-08-26 23:49:37 --> Output Class Initialized
INFO - 2021-08-26 23:49:37 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:37 --> Input Class Initialized
INFO - 2021-08-26 23:49:37 --> Language Class Initialized
ERROR - 2021-08-26 23:49:37 --> 404 Page Not Found: FCK/fckeditor.js
ERROR - 2021-08-26 23:49:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:38 --> Config Class Initialized
INFO - 2021-08-26 23:49:38 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:38 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:38 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:38 --> URI Class Initialized
INFO - 2021-08-26 23:49:38 --> Router Class Initialized
INFO - 2021-08-26 23:49:38 --> Output Class Initialized
INFO - 2021-08-26 23:49:38 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:38 --> Input Class Initialized
INFO - 2021-08-26 23:49:38 --> Language Class Initialized
ERROR - 2021-08-26 23:49:38 --> 404 Page Not Found: Fckeditorjs/index
ERROR - 2021-08-26 23:49:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:38 --> Config Class Initialized
INFO - 2021-08-26 23:49:38 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:38 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:38 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:38 --> URI Class Initialized
INFO - 2021-08-26 23:49:38 --> Router Class Initialized
INFO - 2021-08-26 23:49:38 --> Output Class Initialized
INFO - 2021-08-26 23:49:38 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:38 --> Input Class Initialized
INFO - 2021-08-26 23:49:38 --> Language Class Initialized
ERROR - 2021-08-26 23:49:38 --> 404 Page Not Found: Editor/fckeditor.js
ERROR - 2021-08-26 23:49:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:39 --> Config Class Initialized
INFO - 2021-08-26 23:49:39 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:39 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:39 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:39 --> URI Class Initialized
INFO - 2021-08-26 23:49:39 --> Router Class Initialized
INFO - 2021-08-26 23:49:39 --> Output Class Initialized
INFO - 2021-08-26 23:49:39 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:39 --> Input Class Initialized
INFO - 2021-08-26 23:49:39 --> Language Class Initialized
ERROR - 2021-08-26 23:49:39 --> 404 Page Not Found: Editor/js
ERROR - 2021-08-26 23:49:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:40 --> Config Class Initialized
INFO - 2021-08-26 23:49:40 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:40 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:40 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:40 --> URI Class Initialized
INFO - 2021-08-26 23:49:40 --> Router Class Initialized
INFO - 2021-08-26 23:49:40 --> Output Class Initialized
INFO - 2021-08-26 23:49:40 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:40 --> Input Class Initialized
INFO - 2021-08-26 23:49:40 --> Language Class Initialized
ERROR - 2021-08-26 23:49:40 --> 404 Page Not Found: Ckeditor/ckeditor.js
ERROR - 2021-08-26 23:49:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:40 --> Config Class Initialized
INFO - 2021-08-26 23:49:40 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:40 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:40 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:40 --> URI Class Initialized
INFO - 2021-08-26 23:49:40 --> Router Class Initialized
INFO - 2021-08-26 23:49:40 --> Output Class Initialized
INFO - 2021-08-26 23:49:40 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:40 --> Input Class Initialized
INFO - 2021-08-26 23:49:40 --> Language Class Initialized
ERROR - 2021-08-26 23:49:40 --> 404 Page Not Found: Auth/login
ERROR - 2021-08-26 23:49:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:41 --> Config Class Initialized
INFO - 2021-08-26 23:49:41 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:41 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:41 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:41 --> URI Class Initialized
INFO - 2021-08-26 23:49:41 --> Router Class Initialized
INFO - 2021-08-26 23:49:41 --> Output Class Initialized
INFO - 2021-08-26 23:49:41 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:41 --> Input Class Initialized
INFO - 2021-08-26 23:49:41 --> Language Class Initialized
ERROR - 2021-08-26 23:49:41 --> 404 Page Not Found: Admin/index
ERROR - 2021-08-26 23:49:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:42 --> Config Class Initialized
INFO - 2021-08-26 23:49:42 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:42 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:42 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:42 --> URI Class Initialized
INFO - 2021-08-26 23:49:42 --> Router Class Initialized
INFO - 2021-08-26 23:49:42 --> Output Class Initialized
INFO - 2021-08-26 23:49:42 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:42 --> Input Class Initialized
INFO - 2021-08-26 23:49:42 --> Language Class Initialized
ERROR - 2021-08-26 23:49:42 --> 404 Page Not Found: Listphp/index
ERROR - 2021-08-26 23:49:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:42 --> Config Class Initialized
INFO - 2021-08-26 23:49:42 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:42 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:42 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:42 --> URI Class Initialized
INFO - 2021-08-26 23:49:42 --> Router Class Initialized
INFO - 2021-08-26 23:49:42 --> Output Class Initialized
INFO - 2021-08-26 23:49:42 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:42 --> Input Class Initialized
INFO - 2021-08-26 23:49:42 --> Language Class Initialized
ERROR - 2021-08-26 23:49:42 --> 404 Page Not Found: Admin/template
ERROR - 2021-08-26 23:49:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:43 --> Config Class Initialized
INFO - 2021-08-26 23:49:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:43 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:43 --> URI Class Initialized
INFO - 2021-08-26 23:49:43 --> Router Class Initialized
INFO - 2021-08-26 23:49:43 --> Output Class Initialized
INFO - 2021-08-26 23:49:43 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:43 --> Input Class Initialized
INFO - 2021-08-26 23:49:43 --> Language Class Initialized
ERROR - 2021-08-26 23:49:43 --> 404 Page Not Found: E/master
ERROR - 2021-08-26 23:49:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:43 --> Config Class Initialized
INFO - 2021-08-26 23:49:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:43 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:43 --> URI Class Initialized
INFO - 2021-08-26 23:49:43 --> Router Class Initialized
INFO - 2021-08-26 23:49:43 --> Output Class Initialized
INFO - 2021-08-26 23:49:43 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:43 --> Input Class Initialized
INFO - 2021-08-26 23:49:43 --> Language Class Initialized
ERROR - 2021-08-26 23:49:43 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-08-26 23:49:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:44 --> Config Class Initialized
INFO - 2021-08-26 23:49:44 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:44 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:44 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:44 --> URI Class Initialized
INFO - 2021-08-26 23:49:44 --> Router Class Initialized
INFO - 2021-08-26 23:49:44 --> Output Class Initialized
INFO - 2021-08-26 23:49:44 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:44 --> Input Class Initialized
INFO - 2021-08-26 23:49:44 --> Language Class Initialized
ERROR - 2021-08-26 23:49:44 --> 404 Page Not Found: Images/login
ERROR - 2021-08-26 23:49:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:44 --> Config Class Initialized
INFO - 2021-08-26 23:49:44 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:44 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:44 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:44 --> URI Class Initialized
INFO - 2021-08-26 23:49:44 --> Router Class Initialized
INFO - 2021-08-26 23:49:44 --> Output Class Initialized
INFO - 2021-08-26 23:49:44 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:44 --> Input Class Initialized
INFO - 2021-08-26 23:49:44 --> Language Class Initialized
ERROR - 2021-08-26 23:49:44 --> 404 Page Not Found: Images/login
ERROR - 2021-08-26 23:49:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:45 --> Config Class Initialized
INFO - 2021-08-26 23:49:45 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:45 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:45 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:45 --> URI Class Initialized
INFO - 2021-08-26 23:49:45 --> Router Class Initialized
INFO - 2021-08-26 23:49:45 --> Output Class Initialized
INFO - 2021-08-26 23:49:45 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:45 --> Input Class Initialized
INFO - 2021-08-26 23:49:45 --> Language Class Initialized
ERROR - 2021-08-26 23:49:45 --> 404 Page Not Found: Images/login
ERROR - 2021-08-26 23:49:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:46 --> Config Class Initialized
INFO - 2021-08-26 23:49:46 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:46 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:46 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:46 --> URI Class Initialized
INFO - 2021-08-26 23:49:46 --> Router Class Initialized
INFO - 2021-08-26 23:49:46 --> Output Class Initialized
INFO - 2021-08-26 23:49:46 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:46 --> Input Class Initialized
INFO - 2021-08-26 23:49:46 --> Language Class Initialized
ERROR - 2021-08-26 23:49:46 --> 404 Page Not Found: Next/img
ERROR - 2021-08-26 23:49:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:46 --> Config Class Initialized
INFO - 2021-08-26 23:49:46 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:46 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:46 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:46 --> URI Class Initialized
INFO - 2021-08-26 23:49:46 --> Router Class Initialized
INFO - 2021-08-26 23:49:46 --> Output Class Initialized
INFO - 2021-08-26 23:49:46 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:46 --> Input Class Initialized
INFO - 2021-08-26 23:49:46 --> Language Class Initialized
ERROR - 2021-08-26 23:49:46 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-08-26 23:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:47 --> Config Class Initialized
INFO - 2021-08-26 23:49:47 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:47 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:47 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:47 --> URI Class Initialized
INFO - 2021-08-26 23:49:47 --> Router Class Initialized
INFO - 2021-08-26 23:49:47 --> Output Class Initialized
INFO - 2021-08-26 23:49:47 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:47 --> Input Class Initialized
INFO - 2021-08-26 23:49:47 --> Language Class Initialized
ERROR - 2021-08-26 23:49:47 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-26 23:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:48 --> Config Class Initialized
INFO - 2021-08-26 23:49:48 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:48 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:48 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:48 --> URI Class Initialized
INFO - 2021-08-26 23:49:48 --> Router Class Initialized
INFO - 2021-08-26 23:49:48 --> Output Class Initialized
INFO - 2021-08-26 23:49:48 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:48 --> Input Class Initialized
INFO - 2021-08-26 23:49:48 --> Language Class Initialized
ERROR - 2021-08-26 23:49:48 --> 404 Page Not Found: Common/help
ERROR - 2021-08-26 23:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:48 --> Config Class Initialized
INFO - 2021-08-26 23:49:48 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:48 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:48 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:48 --> URI Class Initialized
INFO - 2021-08-26 23:49:48 --> Router Class Initialized
INFO - 2021-08-26 23:49:48 --> Output Class Initialized
INFO - 2021-08-26 23:49:48 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:48 --> Input Class Initialized
INFO - 2021-08-26 23:49:48 --> Language Class Initialized
ERROR - 2021-08-26 23:49:48 --> 404 Page Not Found: Common/help
ERROR - 2021-08-26 23:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:49 --> Config Class Initialized
INFO - 2021-08-26 23:49:49 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:49 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:49 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:49 --> URI Class Initialized
INFO - 2021-08-26 23:49:49 --> Router Class Initialized
INFO - 2021-08-26 23:49:49 --> Output Class Initialized
INFO - 2021-08-26 23:49:49 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:49 --> Input Class Initialized
INFO - 2021-08-26 23:49:49 --> Language Class Initialized
ERROR - 2021-08-26 23:49:49 --> 404 Page Not Found: Coremail/common
ERROR - 2021-08-26 23:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:49 --> Config Class Initialized
INFO - 2021-08-26 23:49:49 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:49 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:49 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:49 --> URI Class Initialized
INFO - 2021-08-26 23:49:49 --> Router Class Initialized
INFO - 2021-08-26 23:49:49 --> Output Class Initialized
INFO - 2021-08-26 23:49:49 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:49 --> Input Class Initialized
INFO - 2021-08-26 23:49:49 --> Language Class Initialized
ERROR - 2021-08-26 23:49:49 --> 404 Page Not Found: Coremail/common
ERROR - 2021-08-26 23:49:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:50 --> Config Class Initialized
INFO - 2021-08-26 23:49:50 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:50 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:50 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:50 --> URI Class Initialized
INFO - 2021-08-26 23:49:50 --> Router Class Initialized
INFO - 2021-08-26 23:49:50 --> Output Class Initialized
INFO - 2021-08-26 23:49:50 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:50 --> Input Class Initialized
INFO - 2021-08-26 23:49:50 --> Language Class Initialized
ERROR - 2021-08-26 23:49:50 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-08-26 23:49:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:50 --> Config Class Initialized
INFO - 2021-08-26 23:49:50 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:50 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:50 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:50 --> URI Class Initialized
INFO - 2021-08-26 23:49:50 --> Router Class Initialized
INFO - 2021-08-26 23:49:50 --> Output Class Initialized
INFO - 2021-08-26 23:49:50 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:50 --> Input Class Initialized
INFO - 2021-08-26 23:49:50 --> Language Class Initialized
ERROR - 2021-08-26 23:49:50 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-08-26 23:49:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:51 --> Config Class Initialized
INFO - 2021-08-26 23:49:51 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:51 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:51 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:51 --> URI Class Initialized
INFO - 2021-08-26 23:49:51 --> Router Class Initialized
INFO - 2021-08-26 23:49:51 --> Output Class Initialized
INFO - 2021-08-26 23:49:51 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:51 --> Input Class Initialized
INFO - 2021-08-26 23:49:51 --> Language Class Initialized
ERROR - 2021-08-26 23:49:51 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-26 23:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:52 --> Config Class Initialized
INFO - 2021-08-26 23:49:52 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:52 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:52 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:52 --> URI Class Initialized
INFO - 2021-08-26 23:49:52 --> Router Class Initialized
INFO - 2021-08-26 23:49:52 --> Output Class Initialized
INFO - 2021-08-26 23:49:52 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:52 --> Input Class Initialized
INFO - 2021-08-26 23:49:52 --> Language Class Initialized
ERROR - 2021-08-26 23:49:52 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-26 23:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:52 --> Config Class Initialized
INFO - 2021-08-26 23:49:52 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:52 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:52 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:52 --> URI Class Initialized
INFO - 2021-08-26 23:49:52 --> Router Class Initialized
INFO - 2021-08-26 23:49:52 --> Output Class Initialized
INFO - 2021-08-26 23:49:52 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:52 --> Input Class Initialized
INFO - 2021-08-26 23:49:52 --> Language Class Initialized
ERROR - 2021-08-26 23:49:52 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-26 23:49:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:53 --> Config Class Initialized
INFO - 2021-08-26 23:49:53 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:53 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:53 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:53 --> URI Class Initialized
INFO - 2021-08-26 23:49:53 --> Router Class Initialized
INFO - 2021-08-26 23:49:53 --> Output Class Initialized
INFO - 2021-08-26 23:49:53 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:53 --> Input Class Initialized
INFO - 2021-08-26 23:49:53 --> Language Class Initialized
ERROR - 2021-08-26 23:49:53 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-26 23:49:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:53 --> Config Class Initialized
INFO - 2021-08-26 23:49:53 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:53 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:53 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:53 --> URI Class Initialized
INFO - 2021-08-26 23:49:53 --> Router Class Initialized
INFO - 2021-08-26 23:49:53 --> Output Class Initialized
INFO - 2021-08-26 23:49:53 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:53 --> Input Class Initialized
INFO - 2021-08-26 23:49:53 --> Language Class Initialized
ERROR - 2021-08-26 23:49:53 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-26 23:49:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:54 --> Config Class Initialized
INFO - 2021-08-26 23:49:54 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:54 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:54 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:54 --> URI Class Initialized
INFO - 2021-08-26 23:49:54 --> Router Class Initialized
INFO - 2021-08-26 23:49:54 --> Output Class Initialized
INFO - 2021-08-26 23:49:54 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:54 --> Input Class Initialized
INFO - 2021-08-26 23:49:54 --> Language Class Initialized
ERROR - 2021-08-26 23:49:54 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-26 23:49:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:55 --> Config Class Initialized
INFO - 2021-08-26 23:49:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:55 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:55 --> URI Class Initialized
INFO - 2021-08-26 23:49:55 --> Router Class Initialized
INFO - 2021-08-26 23:49:55 --> Output Class Initialized
INFO - 2021-08-26 23:49:55 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:55 --> Input Class Initialized
INFO - 2021-08-26 23:49:55 --> Language Class Initialized
ERROR - 2021-08-26 23:49:55 --> 404 Page Not Found: Admin/js
ERROR - 2021-08-26 23:49:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:55 --> Config Class Initialized
INFO - 2021-08-26 23:49:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:55 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:55 --> URI Class Initialized
INFO - 2021-08-26 23:49:55 --> Router Class Initialized
INFO - 2021-08-26 23:49:55 --> Output Class Initialized
INFO - 2021-08-26 23:49:55 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:55 --> Input Class Initialized
INFO - 2021-08-26 23:49:55 --> Language Class Initialized
ERROR - 2021-08-26 23:49:55 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-26 23:49:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:57 --> Config Class Initialized
INFO - 2021-08-26 23:49:57 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:57 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:57 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:57 --> URI Class Initialized
INFO - 2021-08-26 23:49:57 --> Router Class Initialized
INFO - 2021-08-26 23:49:57 --> Output Class Initialized
INFO - 2021-08-26 23:49:57 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:57 --> Input Class Initialized
INFO - 2021-08-26 23:49:57 --> Language Class Initialized
ERROR - 2021-08-26 23:49:57 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-26 23:49:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:57 --> Config Class Initialized
INFO - 2021-08-26 23:49:57 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:57 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:57 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:57 --> URI Class Initialized
INFO - 2021-08-26 23:49:57 --> Router Class Initialized
INFO - 2021-08-26 23:49:57 --> Output Class Initialized
INFO - 2021-08-26 23:49:57 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:57 --> Input Class Initialized
INFO - 2021-08-26 23:49:57 --> Language Class Initialized
ERROR - 2021-08-26 23:49:57 --> 404 Page Not Found: Dialog/dialog.js
ERROR - 2021-08-26 23:49:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:58 --> Config Class Initialized
INFO - 2021-08-26 23:49:58 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:58 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:58 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:58 --> URI Class Initialized
INFO - 2021-08-26 23:49:58 --> Router Class Initialized
INFO - 2021-08-26 23:49:58 --> Output Class Initialized
INFO - 2021-08-26 23:49:58 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:58 --> Input Class Initialized
INFO - 2021-08-26 23:49:58 --> Language Class Initialized
ERROR - 2021-08-26 23:49:58 --> 404 Page Not Found: Editorjs/index
ERROR - 2021-08-26 23:49:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:59 --> Config Class Initialized
INFO - 2021-08-26 23:49:59 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:59 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:59 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:59 --> URI Class Initialized
INFO - 2021-08-26 23:49:59 --> Router Class Initialized
INFO - 2021-08-26 23:49:59 --> Output Class Initialized
INFO - 2021-08-26 23:49:59 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:59 --> Input Class Initialized
INFO - 2021-08-26 23:49:59 --> Language Class Initialized
ERROR - 2021-08-26 23:49:59 --> 404 Page Not Found: Images/2_11.gif
ERROR - 2021-08-26 23:49:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:49:59 --> Config Class Initialized
INFO - 2021-08-26 23:49:59 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:49:59 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:49:59 --> Utf8 Class Initialized
INFO - 2021-08-26 23:49:59 --> URI Class Initialized
INFO - 2021-08-26 23:49:59 --> Router Class Initialized
INFO - 2021-08-26 23:49:59 --> Output Class Initialized
INFO - 2021-08-26 23:49:59 --> Security Class Initialized
DEBUG - 2021-08-26 23:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:49:59 --> Input Class Initialized
INFO - 2021-08-26 23:49:59 --> Language Class Initialized
ERROR - 2021-08-26 23:49:59 --> 404 Page Not Found: Js/buttons.js
ERROR - 2021-08-26 23:50:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:00 --> Config Class Initialized
INFO - 2021-08-26 23:50:00 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:00 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:00 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:00 --> URI Class Initialized
INFO - 2021-08-26 23:50:00 --> Router Class Initialized
INFO - 2021-08-26 23:50:00 --> Output Class Initialized
INFO - 2021-08-26 23:50:00 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:00 --> Input Class Initialized
INFO - 2021-08-26 23:50:00 --> Language Class Initialized
ERROR - 2021-08-26 23:50:00 --> 404 Page Not Found: Admin/inc
ERROR - 2021-08-26 23:50:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:00 --> Config Class Initialized
INFO - 2021-08-26 23:50:00 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:00 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:00 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:00 --> URI Class Initialized
INFO - 2021-08-26 23:50:01 --> Router Class Initialized
INFO - 2021-08-26 23:50:01 --> Output Class Initialized
INFO - 2021-08-26 23:50:01 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:01 --> Input Class Initialized
INFO - 2021-08-26 23:50:01 --> Language Class Initialized
ERROR - 2021-08-26 23:50:01 --> 404 Page Not Found: Help/ch_gb
ERROR - 2021-08-26 23:50:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:01 --> Config Class Initialized
INFO - 2021-08-26 23:50:01 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:01 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:01 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:01 --> URI Class Initialized
INFO - 2021-08-26 23:50:01 --> Router Class Initialized
INFO - 2021-08-26 23:50:01 --> Output Class Initialized
INFO - 2021-08-26 23:50:01 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:01 --> Input Class Initialized
INFO - 2021-08-26 23:50:01 --> Language Class Initialized
ERROR - 2021-08-26 23:50:01 --> 404 Page Not Found: Admin/index.php
ERROR - 2021-08-26 23:50:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:02 --> Config Class Initialized
INFO - 2021-08-26 23:50:02 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:02 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:02 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:02 --> URI Class Initialized
INFO - 2021-08-26 23:50:02 --> Router Class Initialized
INFO - 2021-08-26 23:50:02 --> Output Class Initialized
INFO - 2021-08-26 23:50:02 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:02 --> Input Class Initialized
INFO - 2021-08-26 23:50:02 --> Language Class Initialized
ERROR - 2021-08-26 23:50:02 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-08-26 23:50:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:02 --> Config Class Initialized
INFO - 2021-08-26 23:50:02 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:02 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:02 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:02 --> URI Class Initialized
INFO - 2021-08-26 23:50:02 --> Router Class Initialized
INFO - 2021-08-26 23:50:02 --> Output Class Initialized
INFO - 2021-08-26 23:50:02 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:02 --> Input Class Initialized
INFO - 2021-08-26 23:50:02 --> Language Class Initialized
ERROR - 2021-08-26 23:50:02 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-08-26 23:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:03 --> Config Class Initialized
INFO - 2021-08-26 23:50:03 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:03 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:03 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:03 --> URI Class Initialized
INFO - 2021-08-26 23:50:03 --> Router Class Initialized
INFO - 2021-08-26 23:50:03 --> Output Class Initialized
INFO - 2021-08-26 23:50:03 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:03 --> Input Class Initialized
INFO - 2021-08-26 23:50:03 --> Language Class Initialized
ERROR - 2021-08-26 23:50:03 --> 404 Page Not Found: UserCenter/css
ERROR - 2021-08-26 23:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:03 --> Config Class Initialized
INFO - 2021-08-26 23:50:03 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:03 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:03 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:03 --> URI Class Initialized
DEBUG - 2021-08-26 23:50:03 --> No URI present. Default controller set.
INFO - 2021-08-26 23:50:03 --> Router Class Initialized
INFO - 2021-08-26 23:50:03 --> Output Class Initialized
INFO - 2021-08-26 23:50:03 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:03 --> Input Class Initialized
INFO - 2021-08-26 23:50:03 --> Language Class Initialized
INFO - 2021-08-26 23:50:03 --> Loader Class Initialized
INFO - 2021-08-26 23:50:03 --> Helper loaded: url_helper
INFO - 2021-08-26 23:50:03 --> Helper loaded: form_helper
INFO - 2021-08-26 23:50:03 --> Helper loaded: common_helper
INFO - 2021-08-26 23:50:03 --> Database Driver Class Initialized
DEBUG - 2021-08-26 23:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 23:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 23:50:03 --> Controller Class Initialized
INFO - 2021-08-26 23:50:03 --> Form Validation Class Initialized
DEBUG - 2021-08-26 23:50:03 --> Encrypt Class Initialized
DEBUG - 2021-08-26 23:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-26 23:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-26 23:50:03 --> Email Class Initialized
INFO - 2021-08-26 23:50:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-26 23:50:03 --> Calendar Class Initialized
INFO - 2021-08-26 23:50:03 --> Model "Login_model" initialized
INFO - 2021-08-26 23:50:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-26 23:50:03 --> Final output sent to browser
DEBUG - 2021-08-26 23:50:03 --> Total execution time: 0.0198
ERROR - 2021-08-26 23:50:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:04 --> Config Class Initialized
INFO - 2021-08-26 23:50:04 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:04 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:04 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:04 --> URI Class Initialized
DEBUG - 2021-08-26 23:50:04 --> No URI present. Default controller set.
INFO - 2021-08-26 23:50:04 --> Router Class Initialized
INFO - 2021-08-26 23:50:04 --> Output Class Initialized
INFO - 2021-08-26 23:50:04 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:04 --> Input Class Initialized
INFO - 2021-08-26 23:50:04 --> Language Class Initialized
INFO - 2021-08-26 23:50:04 --> Loader Class Initialized
INFO - 2021-08-26 23:50:04 --> Helper loaded: url_helper
INFO - 2021-08-26 23:50:04 --> Helper loaded: form_helper
INFO - 2021-08-26 23:50:04 --> Helper loaded: common_helper
INFO - 2021-08-26 23:50:04 --> Database Driver Class Initialized
DEBUG - 2021-08-26 23:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 23:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 23:50:04 --> Controller Class Initialized
INFO - 2021-08-26 23:50:04 --> Form Validation Class Initialized
DEBUG - 2021-08-26 23:50:04 --> Encrypt Class Initialized
DEBUG - 2021-08-26 23:50:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-26 23:50:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-26 23:50:04 --> Email Class Initialized
INFO - 2021-08-26 23:50:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-26 23:50:04 --> Calendar Class Initialized
INFO - 2021-08-26 23:50:04 --> Model "Login_model" initialized
INFO - 2021-08-26 23:50:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-26 23:50:04 --> Final output sent to browser
DEBUG - 2021-08-26 23:50:04 --> Total execution time: 0.0185
ERROR - 2021-08-26 23:50:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:05 --> Config Class Initialized
INFO - 2021-08-26 23:50:05 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:05 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:05 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:05 --> URI Class Initialized
DEBUG - 2021-08-26 23:50:05 --> No URI present. Default controller set.
INFO - 2021-08-26 23:50:05 --> Router Class Initialized
INFO - 2021-08-26 23:50:05 --> Output Class Initialized
INFO - 2021-08-26 23:50:05 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:05 --> Input Class Initialized
INFO - 2021-08-26 23:50:05 --> Language Class Initialized
INFO - 2021-08-26 23:50:05 --> Loader Class Initialized
INFO - 2021-08-26 23:50:05 --> Helper loaded: url_helper
INFO - 2021-08-26 23:50:05 --> Helper loaded: form_helper
INFO - 2021-08-26 23:50:05 --> Helper loaded: common_helper
INFO - 2021-08-26 23:50:05 --> Database Driver Class Initialized
DEBUG - 2021-08-26 23:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 23:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 23:50:05 --> Controller Class Initialized
INFO - 2021-08-26 23:50:05 --> Form Validation Class Initialized
DEBUG - 2021-08-26 23:50:05 --> Encrypt Class Initialized
DEBUG - 2021-08-26 23:50:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-26 23:50:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-26 23:50:05 --> Email Class Initialized
INFO - 2021-08-26 23:50:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-26 23:50:05 --> Calendar Class Initialized
INFO - 2021-08-26 23:50:05 --> Model "Login_model" initialized
INFO - 2021-08-26 23:50:05 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-26 23:50:05 --> Final output sent to browser
DEBUG - 2021-08-26 23:50:05 --> Total execution time: 0.0255
ERROR - 2021-08-26 23:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:06 --> Config Class Initialized
INFO - 2021-08-26 23:50:06 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:06 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:06 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:06 --> URI Class Initialized
DEBUG - 2021-08-26 23:50:06 --> No URI present. Default controller set.
INFO - 2021-08-26 23:50:06 --> Router Class Initialized
INFO - 2021-08-26 23:50:06 --> Output Class Initialized
INFO - 2021-08-26 23:50:06 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:06 --> Input Class Initialized
INFO - 2021-08-26 23:50:06 --> Language Class Initialized
INFO - 2021-08-26 23:50:06 --> Loader Class Initialized
INFO - 2021-08-26 23:50:06 --> Helper loaded: url_helper
INFO - 2021-08-26 23:50:06 --> Helper loaded: form_helper
INFO - 2021-08-26 23:50:06 --> Helper loaded: common_helper
INFO - 2021-08-26 23:50:06 --> Database Driver Class Initialized
DEBUG - 2021-08-26 23:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 23:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 23:50:06 --> Controller Class Initialized
INFO - 2021-08-26 23:50:06 --> Form Validation Class Initialized
DEBUG - 2021-08-26 23:50:06 --> Encrypt Class Initialized
DEBUG - 2021-08-26 23:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-26 23:50:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-26 23:50:06 --> Email Class Initialized
INFO - 2021-08-26 23:50:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-26 23:50:06 --> Calendar Class Initialized
INFO - 2021-08-26 23:50:06 --> Model "Login_model" initialized
INFO - 2021-08-26 23:50:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-26 23:50:06 --> Final output sent to browser
DEBUG - 2021-08-26 23:50:06 --> Total execution time: 0.0196
ERROR - 2021-08-26 23:50:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:07 --> Config Class Initialized
INFO - 2021-08-26 23:50:07 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:07 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:07 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:07 --> URI Class Initialized
INFO - 2021-08-26 23:50:07 --> Router Class Initialized
INFO - 2021-08-26 23:50:07 --> Output Class Initialized
INFO - 2021-08-26 23:50:07 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:07 --> Input Class Initialized
INFO - 2021-08-26 23:50:07 --> Language Class Initialized
ERROR - 2021-08-26 23:50:07 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-08-26 23:50:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:07 --> Config Class Initialized
INFO - 2021-08-26 23:50:07 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:07 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:07 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:07 --> URI Class Initialized
INFO - 2021-08-26 23:50:07 --> Router Class Initialized
INFO - 2021-08-26 23:50:07 --> Output Class Initialized
INFO - 2021-08-26 23:50:07 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:07 --> Input Class Initialized
INFO - 2021-08-26 23:50:07 --> Language Class Initialized
ERROR - 2021-08-26 23:50:07 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-08-26 23:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:08 --> Config Class Initialized
INFO - 2021-08-26 23:50:08 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:08 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:08 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:08 --> URI Class Initialized
INFO - 2021-08-26 23:50:08 --> Router Class Initialized
INFO - 2021-08-26 23:50:08 --> Output Class Initialized
INFO - 2021-08-26 23:50:08 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:08 --> Input Class Initialized
INFO - 2021-08-26 23:50:08 --> Language Class Initialized
ERROR - 2021-08-26 23:50:08 --> 404 Page Not Found: Default/images
ERROR - 2021-08-26 23:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:09 --> Config Class Initialized
INFO - 2021-08-26 23:50:09 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:09 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:09 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:09 --> URI Class Initialized
INFO - 2021-08-26 23:50:09 --> Router Class Initialized
INFO - 2021-08-26 23:50:09 --> Output Class Initialized
INFO - 2021-08-26 23:50:09 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:09 --> Input Class Initialized
INFO - 2021-08-26 23:50:09 --> Language Class Initialized
ERROR - 2021-08-26 23:50:09 --> 404 Page Not Found: Extman/default
ERROR - 2021-08-26 23:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:09 --> Config Class Initialized
INFO - 2021-08-26 23:50:09 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:09 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:09 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:09 --> URI Class Initialized
INFO - 2021-08-26 23:50:09 --> Router Class Initialized
INFO - 2021-08-26 23:50:09 --> Output Class Initialized
INFO - 2021-08-26 23:50:09 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:09 --> Input Class Initialized
INFO - 2021-08-26 23:50:09 --> Language Class Initialized
ERROR - 2021-08-26 23:50:09 --> 404 Page Not Found: Images/hwem.css
ERROR - 2021-08-26 23:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:10 --> Config Class Initialized
INFO - 2021-08-26 23:50:10 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:10 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:10 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:10 --> URI Class Initialized
INFO - 2021-08-26 23:50:10 --> Router Class Initialized
INFO - 2021-08-26 23:50:10 --> Output Class Initialized
INFO - 2021-08-26 23:50:10 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:10 --> Input Class Initialized
INFO - 2021-08-26 23:50:10 --> Language Class Initialized
ERROR - 2021-08-26 23:50:10 --> 404 Page Not Found: Bencandyphp/index
ERROR - 2021-08-26 23:50:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:11 --> Config Class Initialized
INFO - 2021-08-26 23:50:11 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:11 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:11 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:11 --> URI Class Initialized
INFO - 2021-08-26 23:50:11 --> Router Class Initialized
INFO - 2021-08-26 23:50:11 --> Output Class Initialized
INFO - 2021-08-26 23:50:11 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:11 --> Input Class Initialized
INFO - 2021-08-26 23:50:11 --> Language Class Initialized
ERROR - 2021-08-26 23:50:11 --> 404 Page Not Found: Images/default
ERROR - 2021-08-26 23:50:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:11 --> Config Class Initialized
INFO - 2021-08-26 23:50:11 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:11 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:11 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:11 --> URI Class Initialized
INFO - 2021-08-26 23:50:11 --> Router Class Initialized
INFO - 2021-08-26 23:50:11 --> Output Class Initialized
INFO - 2021-08-26 23:50:11 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:11 --> Input Class Initialized
INFO - 2021-08-26 23:50:11 --> Language Class Initialized
ERROR - 2021-08-26 23:50:11 --> 404 Page Not Found: Images/login9
ERROR - 2021-08-26 23:50:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:12 --> Config Class Initialized
INFO - 2021-08-26 23:50:12 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:12 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:12 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:12 --> URI Class Initialized
INFO - 2021-08-26 23:50:12 --> Router Class Initialized
INFO - 2021-08-26 23:50:12 --> Output Class Initialized
INFO - 2021-08-26 23:50:12 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:12 --> Input Class Initialized
INFO - 2021-08-26 23:50:12 --> Language Class Initialized
ERROR - 2021-08-26 23:50:12 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-08-26 23:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:13 --> Config Class Initialized
INFO - 2021-08-26 23:50:13 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:13 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:13 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:13 --> URI Class Initialized
INFO - 2021-08-26 23:50:13 --> Router Class Initialized
INFO - 2021-08-26 23:50:13 --> Output Class Initialized
INFO - 2021-08-26 23:50:13 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:13 --> Input Class Initialized
INFO - 2021-08-26 23:50:13 --> Language Class Initialized
ERROR - 2021-08-26 23:50:13 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-08-26 23:50:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:16 --> Config Class Initialized
INFO - 2021-08-26 23:50:16 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:16 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:16 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:16 --> URI Class Initialized
INFO - 2021-08-26 23:50:16 --> Router Class Initialized
INFO - 2021-08-26 23:50:16 --> Output Class Initialized
INFO - 2021-08-26 23:50:16 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:16 --> Input Class Initialized
INFO - 2021-08-26 23:50:16 --> Language Class Initialized
ERROR - 2021-08-26 23:50:16 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-08-26 23:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:17 --> Config Class Initialized
INFO - 2021-08-26 23:50:17 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:17 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:17 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:17 --> URI Class Initialized
INFO - 2021-08-26 23:50:17 --> Router Class Initialized
INFO - 2021-08-26 23:50:17 --> Output Class Initialized
INFO - 2021-08-26 23:50:17 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:17 --> Input Class Initialized
INFO - 2021-08-26 23:50:17 --> Language Class Initialized
ERROR - 2021-08-26 23:50:17 --> 404 Page Not Found: Default/css
ERROR - 2021-08-26 23:50:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:18 --> Config Class Initialized
INFO - 2021-08-26 23:50:18 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:18 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:18 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:18 --> URI Class Initialized
INFO - 2021-08-26 23:50:18 --> Router Class Initialized
INFO - 2021-08-26 23:50:18 --> Output Class Initialized
INFO - 2021-08-26 23:50:18 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:18 --> Input Class Initialized
INFO - 2021-08-26 23:50:18 --> Language Class Initialized
ERROR - 2021-08-26 23:50:18 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-08-26 23:50:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:18 --> Config Class Initialized
INFO - 2021-08-26 23:50:18 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:18 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:18 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:18 --> URI Class Initialized
INFO - 2021-08-26 23:50:18 --> Router Class Initialized
INFO - 2021-08-26 23:50:18 --> Output Class Initialized
INFO - 2021-08-26 23:50:18 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:18 --> Input Class Initialized
INFO - 2021-08-26 23:50:18 --> Language Class Initialized
ERROR - 2021-08-26 23:50:18 --> 404 Page Not Found: App/js
ERROR - 2021-08-26 23:50:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:19 --> Config Class Initialized
INFO - 2021-08-26 23:50:19 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:19 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:19 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:19 --> URI Class Initialized
INFO - 2021-08-26 23:50:19 --> Router Class Initialized
INFO - 2021-08-26 23:50:19 --> Output Class Initialized
INFO - 2021-08-26 23:50:19 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:19 --> Input Class Initialized
INFO - 2021-08-26 23:50:19 --> Language Class Initialized
ERROR - 2021-08-26 23:50:19 --> 404 Page Not Found: Console/js
ERROR - 2021-08-26 23:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:21 --> Config Class Initialized
INFO - 2021-08-26 23:50:21 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:21 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:21 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:21 --> URI Class Initialized
INFO - 2021-08-26 23:50:21 --> Router Class Initialized
INFO - 2021-08-26 23:50:21 --> Output Class Initialized
INFO - 2021-08-26 23:50:21 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:21 --> Input Class Initialized
INFO - 2021-08-26 23:50:21 --> Language Class Initialized
ERROR - 2021-08-26 23:50:21 --> 404 Page Not Found: Console/include
ERROR - 2021-08-26 23:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:21 --> Config Class Initialized
INFO - 2021-08-26 23:50:21 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:21 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:21 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:21 --> URI Class Initialized
INFO - 2021-08-26 23:50:21 --> Router Class Initialized
INFO - 2021-08-26 23:50:21 --> Output Class Initialized
INFO - 2021-08-26 23:50:21 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:21 --> Input Class Initialized
INFO - 2021-08-26 23:50:21 --> Language Class Initialized
ERROR - 2021-08-26 23:50:21 --> 404 Page Not Found: Console/auth
ERROR - 2021-08-26 23:50:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:22 --> Config Class Initialized
INFO - 2021-08-26 23:50:22 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:22 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:22 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:22 --> URI Class Initialized
INFO - 2021-08-26 23:50:22 --> Router Class Initialized
INFO - 2021-08-26 23:50:22 --> Output Class Initialized
INFO - 2021-08-26 23:50:22 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:22 --> Input Class Initialized
INFO - 2021-08-26 23:50:22 --> Language Class Initialized
ERROR - 2021-08-26 23:50:22 --> 404 Page Not Found: Console/js
ERROR - 2021-08-26 23:50:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:22 --> Config Class Initialized
INFO - 2021-08-26 23:50:22 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:22 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:22 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:22 --> URI Class Initialized
INFO - 2021-08-26 23:50:22 --> Router Class Initialized
INFO - 2021-08-26 23:50:22 --> Output Class Initialized
INFO - 2021-08-26 23:50:22 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:22 --> Input Class Initialized
INFO - 2021-08-26 23:50:22 --> Language Class Initialized
ERROR - 2021-08-26 23:50:22 --> 404 Page Not Found: App/images
ERROR - 2021-08-26 23:50:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:23 --> Config Class Initialized
INFO - 2021-08-26 23:50:23 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:23 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:23 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:23 --> URI Class Initialized
INFO - 2021-08-26 23:50:23 --> Router Class Initialized
INFO - 2021-08-26 23:50:23 --> Output Class Initialized
INFO - 2021-08-26 23:50:23 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:23 --> Input Class Initialized
INFO - 2021-08-26 23:50:23 --> Language Class Initialized
ERROR - 2021-08-26 23:50:23 --> 404 Page Not Found: App/images
ERROR - 2021-08-26 23:50:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:23 --> Config Class Initialized
INFO - 2021-08-26 23:50:23 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:23 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:23 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:23 --> URI Class Initialized
INFO - 2021-08-26 23:50:23 --> Router Class Initialized
INFO - 2021-08-26 23:50:23 --> Output Class Initialized
INFO - 2021-08-26 23:50:23 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:23 --> Input Class Initialized
INFO - 2021-08-26 23:50:23 --> Language Class Initialized
ERROR - 2021-08-26 23:50:23 --> 404 Page Not Found: App/home
ERROR - 2021-08-26 23:50:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:24 --> Config Class Initialized
INFO - 2021-08-26 23:50:24 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:24 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:24 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:24 --> URI Class Initialized
INFO - 2021-08-26 23:50:24 --> Router Class Initialized
INFO - 2021-08-26 23:50:24 --> Output Class Initialized
INFO - 2021-08-26 23:50:24 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:24 --> Input Class Initialized
INFO - 2021-08-26 23:50:24 --> Language Class Initialized
ERROR - 2021-08-26 23:50:24 --> 404 Page Not Found: Addons/theme
ERROR - 2021-08-26 23:50:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:25 --> Config Class Initialized
INFO - 2021-08-26 23:50:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:25 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:25 --> URI Class Initialized
INFO - 2021-08-26 23:50:25 --> Router Class Initialized
INFO - 2021-08-26 23:50:25 --> Output Class Initialized
INFO - 2021-08-26 23:50:25 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:25 --> Input Class Initialized
INFO - 2021-08-26 23:50:25 --> Language Class Initialized
ERROR - 2021-08-26 23:50:25 --> 404 Page Not Found: Apps/admin
ERROR - 2021-08-26 23:50:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:25 --> Config Class Initialized
INFO - 2021-08-26 23:50:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:25 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:25 --> URI Class Initialized
INFO - 2021-08-26 23:50:25 --> Router Class Initialized
INFO - 2021-08-26 23:50:25 --> Output Class Initialized
INFO - 2021-08-26 23:50:25 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:25 --> Input Class Initialized
INFO - 2021-08-26 23:50:25 --> Language Class Initialized
ERROR - 2021-08-26 23:50:25 --> 404 Page Not Found: Addons/theme
ERROR - 2021-08-26 23:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:26 --> Config Class Initialized
INFO - 2021-08-26 23:50:26 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:26 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:26 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:26 --> URI Class Initialized
INFO - 2021-08-26 23:50:26 --> Router Class Initialized
INFO - 2021-08-26 23:50:26 --> Output Class Initialized
INFO - 2021-08-26 23:50:26 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:26 --> Input Class Initialized
INFO - 2021-08-26 23:50:26 --> Language Class Initialized
ERROR - 2021-08-26 23:50:26 --> 404 Page Not Found: Addons/theme
ERROR - 2021-08-26 23:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:26 --> Config Class Initialized
INFO - 2021-08-26 23:50:26 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:26 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:26 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:26 --> URI Class Initialized
INFO - 2021-08-26 23:50:26 --> Router Class Initialized
INFO - 2021-08-26 23:50:26 --> Output Class Initialized
INFO - 2021-08-26 23:50:26 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:26 --> Input Class Initialized
INFO - 2021-08-26 23:50:26 --> Language Class Initialized
ERROR - 2021-08-26 23:50:26 --> 404 Page Not Found: Skin/frontend
ERROR - 2021-08-26 23:50:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:27 --> Config Class Initialized
INFO - 2021-08-26 23:50:27 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:27 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:27 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:27 --> URI Class Initialized
INFO - 2021-08-26 23:50:27 --> Router Class Initialized
INFO - 2021-08-26 23:50:27 --> Output Class Initialized
INFO - 2021-08-26 23:50:27 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:27 --> Input Class Initialized
INFO - 2021-08-26 23:50:27 --> Language Class Initialized
ERROR - 2021-08-26 23:50:27 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-08-26 23:50:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:27 --> Config Class Initialized
INFO - 2021-08-26 23:50:27 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:27 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:27 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:27 --> URI Class Initialized
INFO - 2021-08-26 23:50:27 --> Router Class Initialized
INFO - 2021-08-26 23:50:27 --> Output Class Initialized
INFO - 2021-08-26 23:50:27 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:27 --> Input Class Initialized
INFO - 2021-08-26 23:50:27 --> Language Class Initialized
ERROR - 2021-08-26 23:50:27 --> 404 Page Not Found: Pub/guiedit
ERROR - 2021-08-26 23:50:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:28 --> Config Class Initialized
INFO - 2021-08-26 23:50:28 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:28 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:28 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:28 --> URI Class Initialized
INFO - 2021-08-26 23:50:28 --> Router Class Initialized
INFO - 2021-08-26 23:50:28 --> Output Class Initialized
INFO - 2021-08-26 23:50:28 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:28 --> Input Class Initialized
INFO - 2021-08-26 23:50:28 --> Language Class Initialized
ERROR - 2021-08-26 23:50:28 --> 404 Page Not Found: Pub/skins
ERROR - 2021-08-26 23:50:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:28 --> Config Class Initialized
INFO - 2021-08-26 23:50:28 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:28 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:28 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:28 --> URI Class Initialized
INFO - 2021-08-26 23:50:28 --> Router Class Initialized
INFO - 2021-08-26 23:50:28 --> Output Class Initialized
INFO - 2021-08-26 23:50:28 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:28 --> Input Class Initialized
INFO - 2021-08-26 23:50:28 --> Language Class Initialized
ERROR - 2021-08-26 23:50:28 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-08-26 23:50:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:29 --> Config Class Initialized
INFO - 2021-08-26 23:50:29 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:29 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:29 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:29 --> URI Class Initialized
INFO - 2021-08-26 23:50:29 --> Router Class Initialized
INFO - 2021-08-26 23:50:29 --> Output Class Initialized
INFO - 2021-08-26 23:50:29 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:29 --> Input Class Initialized
INFO - 2021-08-26 23:50:29 --> Language Class Initialized
ERROR - 2021-08-26 23:50:29 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-08-26 23:50:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:29 --> Config Class Initialized
INFO - 2021-08-26 23:50:29 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:29 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:29 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:29 --> URI Class Initialized
INFO - 2021-08-26 23:50:29 --> Router Class Initialized
INFO - 2021-08-26 23:50:29 --> Output Class Initialized
INFO - 2021-08-26 23:50:29 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:29 --> Input Class Initialized
INFO - 2021-08-26 23:50:29 --> Language Class Initialized
ERROR - 2021-08-26 23:50:29 --> 404 Page Not Found: Ymail/images
ERROR - 2021-08-26 23:50:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:30 --> Config Class Initialized
INFO - 2021-08-26 23:50:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:30 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:30 --> URI Class Initialized
INFO - 2021-08-26 23:50:30 --> Router Class Initialized
INFO - 2021-08-26 23:50:30 --> Output Class Initialized
INFO - 2021-08-26 23:50:30 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:30 --> Input Class Initialized
INFO - 2021-08-26 23:50:30 --> Language Class Initialized
ERROR - 2021-08-26 23:50:30 --> 404 Page Not Found: Advfile/ad12.js
ERROR - 2021-08-26 23:50:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:30 --> Config Class Initialized
INFO - 2021-08-26 23:50:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:30 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:30 --> URI Class Initialized
INFO - 2021-08-26 23:50:30 --> Router Class Initialized
INFO - 2021-08-26 23:50:30 --> Output Class Initialized
INFO - 2021-08-26 23:50:30 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:30 --> Input Class Initialized
INFO - 2021-08-26 23:50:30 --> Language Class Initialized
ERROR - 2021-08-26 23:50:30 --> 404 Page Not Found: Install/index
ERROR - 2021-08-26 23:50:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:31 --> Config Class Initialized
INFO - 2021-08-26 23:50:31 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:31 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:31 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:31 --> URI Class Initialized
INFO - 2021-08-26 23:50:31 --> Router Class Initialized
INFO - 2021-08-26 23:50:31 --> Output Class Initialized
INFO - 2021-08-26 23:50:31 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:31 --> Input Class Initialized
INFO - 2021-08-26 23:50:31 --> Language Class Initialized
ERROR - 2021-08-26 23:50:31 --> 404 Page Not Found: Template/1
ERROR - 2021-08-26 23:50:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:31 --> Config Class Initialized
INFO - 2021-08-26 23:50:31 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:31 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:31 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:31 --> URI Class Initialized
INFO - 2021-08-26 23:50:31 --> Router Class Initialized
INFO - 2021-08-26 23:50:31 --> Output Class Initialized
INFO - 2021-08-26 23:50:31 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:31 --> Input Class Initialized
INFO - 2021-08-26 23:50:31 --> Language Class Initialized
ERROR - 2021-08-26 23:50:31 --> 404 Page Not Found: Back/scripts
ERROR - 2021-08-26 23:50:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:32 --> Config Class Initialized
INFO - 2021-08-26 23:50:32 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:32 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:32 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:32 --> URI Class Initialized
INFO - 2021-08-26 23:50:32 --> Router Class Initialized
INFO - 2021-08-26 23:50:32 --> Output Class Initialized
INFO - 2021-08-26 23:50:32 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:32 --> Input Class Initialized
INFO - 2021-08-26 23:50:32 --> Language Class Initialized
ERROR - 2021-08-26 23:50:32 --> 404 Page Not Found: Pluginphp/index
ERROR - 2021-08-26 23:50:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:33 --> Config Class Initialized
INFO - 2021-08-26 23:50:33 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:33 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:33 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:33 --> URI Class Initialized
INFO - 2021-08-26 23:50:33 --> Router Class Initialized
INFO - 2021-08-26 23:50:33 --> Output Class Initialized
INFO - 2021-08-26 23:50:33 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:33 --> Input Class Initialized
INFO - 2021-08-26 23:50:33 --> Language Class Initialized
ERROR - 2021-08-26 23:50:33 --> 404 Page Not Found: Admin/login.aspx
ERROR - 2021-08-26 23:50:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:34 --> Config Class Initialized
INFO - 2021-08-26 23:50:34 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:34 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:34 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:34 --> URI Class Initialized
INFO - 2021-08-26 23:50:34 --> Router Class Initialized
INFO - 2021-08-26 23:50:34 --> Output Class Initialized
INFO - 2021-08-26 23:50:34 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:34 --> Input Class Initialized
INFO - 2021-08-26 23:50:34 --> Language Class Initialized
ERROR - 2021-08-26 23:50:34 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-08-26 23:50:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:34 --> Config Class Initialized
INFO - 2021-08-26 23:50:34 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:34 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:34 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:34 --> URI Class Initialized
INFO - 2021-08-26 23:50:34 --> Router Class Initialized
INFO - 2021-08-26 23:50:34 --> Output Class Initialized
INFO - 2021-08-26 23:50:34 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:34 --> Input Class Initialized
INFO - 2021-08-26 23:50:34 --> Language Class Initialized
ERROR - 2021-08-26 23:50:34 --> 404 Page Not Found: Wq_StranJFjs/index
ERROR - 2021-08-26 23:50:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:35 --> Config Class Initialized
INFO - 2021-08-26 23:50:35 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:35 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:35 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:35 --> URI Class Initialized
INFO - 2021-08-26 23:50:35 --> Router Class Initialized
INFO - 2021-08-26 23:50:35 --> Output Class Initialized
INFO - 2021-08-26 23:50:35 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:35 --> Input Class Initialized
INFO - 2021-08-26 23:50:35 --> Language Class Initialized
ERROR - 2021-08-26 23:50:35 --> 404 Page Not Found: Admin/login.asp
ERROR - 2021-08-26 23:50:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:35 --> Config Class Initialized
INFO - 2021-08-26 23:50:35 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:35 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:35 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:35 --> URI Class Initialized
INFO - 2021-08-26 23:50:35 --> Router Class Initialized
INFO - 2021-08-26 23:50:35 --> Output Class Initialized
INFO - 2021-08-26 23:50:35 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:35 --> Input Class Initialized
INFO - 2021-08-26 23:50:35 --> Language Class Initialized
ERROR - 2021-08-26 23:50:35 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-08-26 23:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:36 --> Config Class Initialized
INFO - 2021-08-26 23:50:36 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:36 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:36 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:36 --> URI Class Initialized
INFO - 2021-08-26 23:50:36 --> Router Class Initialized
INFO - 2021-08-26 23:50:36 --> Output Class Initialized
INFO - 2021-08-26 23:50:36 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:36 --> Input Class Initialized
INFO - 2021-08-26 23:50:36 --> Language Class Initialized
ERROR - 2021-08-26 23:50:36 --> 404 Page Not Found: Kindeditor-minjs/index
ERROR - 2021-08-26 23:50:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:37 --> Config Class Initialized
INFO - 2021-08-26 23:50:37 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:37 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:37 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:37 --> URI Class Initialized
INFO - 2021-08-26 23:50:37 --> Router Class Initialized
INFO - 2021-08-26 23:50:37 --> Output Class Initialized
INFO - 2021-08-26 23:50:37 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:37 --> Input Class Initialized
INFO - 2021-08-26 23:50:37 --> Language Class Initialized
ERROR - 2021-08-26 23:50:37 --> 404 Page Not Found: Kindeditorjs/index
ERROR - 2021-08-26 23:50:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:37 --> Config Class Initialized
INFO - 2021-08-26 23:50:37 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:37 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:37 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:37 --> URI Class Initialized
INFO - 2021-08-26 23:50:37 --> Router Class Initialized
INFO - 2021-08-26 23:50:37 --> Output Class Initialized
INFO - 2021-08-26 23:50:37 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:37 --> Input Class Initialized
INFO - 2021-08-26 23:50:37 --> Language Class Initialized
ERROR - 2021-08-26 23:50:37 --> 404 Page Not Found: Lang/en.js
ERROR - 2021-08-26 23:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:38 --> Config Class Initialized
INFO - 2021-08-26 23:50:38 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:38 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:38 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:38 --> URI Class Initialized
INFO - 2021-08-26 23:50:38 --> Router Class Initialized
INFO - 2021-08-26 23:50:38 --> Output Class Initialized
INFO - 2021-08-26 23:50:38 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:38 --> Input Class Initialized
INFO - 2021-08-26 23:50:38 --> Language Class Initialized
ERROR - 2021-08-26 23:50:38 --> 404 Page Not Found: Themes/default
ERROR - 2021-08-26 23:50:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:39 --> Config Class Initialized
INFO - 2021-08-26 23:50:39 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:39 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:39 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:39 --> URI Class Initialized
INFO - 2021-08-26 23:50:39 --> Router Class Initialized
INFO - 2021-08-26 23:50:39 --> Output Class Initialized
INFO - 2021-08-26 23:50:39 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:39 --> Input Class Initialized
INFO - 2021-08-26 23:50:39 --> Language Class Initialized
ERROR - 2021-08-26 23:50:39 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-08-26 23:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:40 --> Config Class Initialized
INFO - 2021-08-26 23:50:40 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:40 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:40 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:40 --> URI Class Initialized
INFO - 2021-08-26 23:50:40 --> Router Class Initialized
INFO - 2021-08-26 23:50:40 --> Output Class Initialized
INFO - 2021-08-26 23:50:40 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:40 --> Input Class Initialized
INFO - 2021-08-26 23:50:40 --> Language Class Initialized
ERROR - 2021-08-26 23:50:40 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-08-26 23:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:40 --> Config Class Initialized
INFO - 2021-08-26 23:50:40 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:40 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:40 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:40 --> URI Class Initialized
INFO - 2021-08-26 23:50:40 --> Router Class Initialized
INFO - 2021-08-26 23:50:40 --> Output Class Initialized
INFO - 2021-08-26 23:50:40 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:40 --> Input Class Initialized
INFO - 2021-08-26 23:50:40 --> Language Class Initialized
ERROR - 2021-08-26 23:50:40 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-08-26 23:50:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:41 --> Config Class Initialized
INFO - 2021-08-26 23:50:41 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:41 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:41 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:41 --> URI Class Initialized
INFO - 2021-08-26 23:50:41 --> Router Class Initialized
INFO - 2021-08-26 23:50:41 --> Output Class Initialized
INFO - 2021-08-26 23:50:41 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:41 --> Input Class Initialized
INFO - 2021-08-26 23:50:41 --> Language Class Initialized
ERROR - 2021-08-26 23:50:41 --> 404 Page Not Found: Plugins/anchor
ERROR - 2021-08-26 23:50:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:41 --> Config Class Initialized
INFO - 2021-08-26 23:50:41 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:41 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:41 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:41 --> URI Class Initialized
INFO - 2021-08-26 23:50:41 --> Router Class Initialized
INFO - 2021-08-26 23:50:41 --> Output Class Initialized
INFO - 2021-08-26 23:50:41 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:41 --> Input Class Initialized
INFO - 2021-08-26 23:50:41 --> Language Class Initialized
ERROR - 2021-08-26 23:50:41 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-08-26 23:50:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:42 --> Config Class Initialized
INFO - 2021-08-26 23:50:42 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:42 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:42 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:42 --> URI Class Initialized
INFO - 2021-08-26 23:50:42 --> Router Class Initialized
INFO - 2021-08-26 23:50:42 --> Output Class Initialized
INFO - 2021-08-26 23:50:42 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:42 --> Input Class Initialized
INFO - 2021-08-26 23:50:42 --> Language Class Initialized
ERROR - 2021-08-26 23:50:42 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-08-26 23:50:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:42 --> Config Class Initialized
INFO - 2021-08-26 23:50:42 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:42 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:42 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:42 --> URI Class Initialized
INFO - 2021-08-26 23:50:42 --> Router Class Initialized
INFO - 2021-08-26 23:50:42 --> Output Class Initialized
INFO - 2021-08-26 23:50:42 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:42 --> Input Class Initialized
INFO - 2021-08-26 23:50:42 --> Language Class Initialized
ERROR - 2021-08-26 23:50:42 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-08-26 23:50:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:43 --> Config Class Initialized
INFO - 2021-08-26 23:50:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:43 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:43 --> URI Class Initialized
INFO - 2021-08-26 23:50:43 --> Router Class Initialized
INFO - 2021-08-26 23:50:43 --> Output Class Initialized
INFO - 2021-08-26 23:50:43 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:43 --> Input Class Initialized
INFO - 2021-08-26 23:50:43 --> Language Class Initialized
ERROR - 2021-08-26 23:50:43 --> 404 Page Not Found: API/DW
ERROR - 2021-08-26 23:50:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:44 --> Config Class Initialized
INFO - 2021-08-26 23:50:44 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:44 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:44 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:44 --> URI Class Initialized
INFO - 2021-08-26 23:50:44 --> Router Class Initialized
INFO - 2021-08-26 23:50:44 --> Output Class Initialized
INFO - 2021-08-26 23:50:44 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:44 --> Input Class Initialized
INFO - 2021-08-26 23:50:44 --> Language Class Initialized
ERROR - 2021-08-26 23:50:44 --> 404 Page Not Found: API/DW
ERROR - 2021-08-26 23:50:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:44 --> Config Class Initialized
INFO - 2021-08-26 23:50:44 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:44 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:44 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:44 --> URI Class Initialized
INFO - 2021-08-26 23:50:44 --> Router Class Initialized
INFO - 2021-08-26 23:50:44 --> Output Class Initialized
INFO - 2021-08-26 23:50:44 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:44 --> Input Class Initialized
INFO - 2021-08-26 23:50:44 --> Language Class Initialized
ERROR - 2021-08-26 23:50:44 --> 404 Page Not Found: API/DW
ERROR - 2021-08-26 23:50:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:45 --> Config Class Initialized
INFO - 2021-08-26 23:50:45 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:45 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:45 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:45 --> URI Class Initialized
INFO - 2021-08-26 23:50:45 --> Router Class Initialized
INFO - 2021-08-26 23:50:45 --> Output Class Initialized
INFO - 2021-08-26 23:50:45 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:45 --> Input Class Initialized
INFO - 2021-08-26 23:50:45 --> Language Class Initialized
ERROR - 2021-08-26 23:50:45 --> 404 Page Not Found: Admin/Common
ERROR - 2021-08-26 23:50:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:46 --> Config Class Initialized
INFO - 2021-08-26 23:50:46 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:46 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:46 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:46 --> URI Class Initialized
INFO - 2021-08-26 23:50:46 --> Router Class Initialized
INFO - 2021-08-26 23:50:46 --> Output Class Initialized
INFO - 2021-08-26 23:50:46 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:46 --> Input Class Initialized
INFO - 2021-08-26 23:50:46 --> Language Class Initialized
ERROR - 2021-08-26 23:50:46 --> 404 Page Not Found: API/DW
ERROR - 2021-08-26 23:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:47 --> Config Class Initialized
INFO - 2021-08-26 23:50:47 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:47 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:47 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:47 --> URI Class Initialized
INFO - 2021-08-26 23:50:47 --> Router Class Initialized
INFO - 2021-08-26 23:50:47 --> Output Class Initialized
INFO - 2021-08-26 23:50:47 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:47 --> Input Class Initialized
INFO - 2021-08-26 23:50:47 --> Language Class Initialized
ERROR - 2021-08-26 23:50:47 --> 404 Page Not Found: API/DW
ERROR - 2021-08-26 23:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:47 --> Config Class Initialized
INFO - 2021-08-26 23:50:47 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:47 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:47 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:47 --> URI Class Initialized
INFO - 2021-08-26 23:50:47 --> Router Class Initialized
INFO - 2021-08-26 23:50:47 --> Output Class Initialized
INFO - 2021-08-26 23:50:47 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:47 --> Input Class Initialized
INFO - 2021-08-26 23:50:47 --> Language Class Initialized
ERROR - 2021-08-26 23:50:47 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-08-26 23:50:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:48 --> Config Class Initialized
INFO - 2021-08-26 23:50:48 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:48 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:48 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:48 --> URI Class Initialized
INFO - 2021-08-26 23:50:48 --> Router Class Initialized
INFO - 2021-08-26 23:50:48 --> Output Class Initialized
INFO - 2021-08-26 23:50:48 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:48 --> Input Class Initialized
INFO - 2021-08-26 23:50:48 --> Language Class Initialized
ERROR - 2021-08-26 23:50:48 --> 404 Page Not Found: Admin/Images
ERROR - 2021-08-26 23:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:49 --> Config Class Initialized
INFO - 2021-08-26 23:50:49 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:49 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:49 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:49 --> URI Class Initialized
INFO - 2021-08-26 23:50:49 --> Router Class Initialized
INFO - 2021-08-26 23:50:49 --> Output Class Initialized
INFO - 2021-08-26 23:50:49 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:49 --> Input Class Initialized
INFO - 2021-08-26 23:50:49 --> Language Class Initialized
ERROR - 2021-08-26 23:50:49 --> 404 Page Not Found: Template/Default
ERROR - 2021-08-26 23:50:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:50 --> Config Class Initialized
INFO - 2021-08-26 23:50:50 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:50 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:50 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:50 --> URI Class Initialized
INFO - 2021-08-26 23:50:50 --> Router Class Initialized
INFO - 2021-08-26 23:50:50 --> Output Class Initialized
INFO - 2021-08-26 23:50:50 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:50 --> Input Class Initialized
INFO - 2021-08-26 23:50:50 --> Language Class Initialized
ERROR - 2021-08-26 23:50:50 --> 404 Page Not Found: Prompt/images
ERROR - 2021-08-26 23:50:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:50 --> Config Class Initialized
INFO - 2021-08-26 23:50:50 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:50 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:50 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:50 --> URI Class Initialized
INFO - 2021-08-26 23:50:50 --> Router Class Initialized
INFO - 2021-08-26 23:50:50 --> Output Class Initialized
INFO - 2021-08-26 23:50:50 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:50 --> Input Class Initialized
INFO - 2021-08-26 23:50:50 --> Language Class Initialized
ERROR - 2021-08-26 23:50:50 --> 404 Page Not Found: Admin/Images
ERROR - 2021-08-26 23:50:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:51 --> Config Class Initialized
INFO - 2021-08-26 23:50:51 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:51 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:51 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:51 --> URI Class Initialized
INFO - 2021-08-26 23:50:51 --> Router Class Initialized
INFO - 2021-08-26 23:50:51 --> Output Class Initialized
INFO - 2021-08-26 23:50:51 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:51 --> Input Class Initialized
INFO - 2021-08-26 23:50:51 --> Language Class Initialized
ERROR - 2021-08-26 23:50:51 --> 404 Page Not Found: Dokuphp/index
ERROR - 2021-08-26 23:50:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:52 --> Config Class Initialized
INFO - 2021-08-26 23:50:52 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:52 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:52 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:52 --> URI Class Initialized
INFO - 2021-08-26 23:50:52 --> Router Class Initialized
INFO - 2021-08-26 23:50:52 --> Output Class Initialized
INFO - 2021-08-26 23:50:52 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:52 --> Input Class Initialized
INFO - 2021-08-26 23:50:52 --> Language Class Initialized
ERROR - 2021-08-26 23:50:52 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-08-26 23:50:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:52 --> Config Class Initialized
INFO - 2021-08-26 23:50:52 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:52 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:52 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:52 --> URI Class Initialized
INFO - 2021-08-26 23:50:52 --> Router Class Initialized
INFO - 2021-08-26 23:50:52 --> Output Class Initialized
INFO - 2021-08-26 23:50:52 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:52 --> Input Class Initialized
INFO - 2021-08-26 23:50:52 --> Language Class Initialized
ERROR - 2021-08-26 23:50:52 --> 404 Page Not Found: Admin/start
ERROR - 2021-08-26 23:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:53 --> Config Class Initialized
INFO - 2021-08-26 23:50:53 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:53 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:53 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:53 --> URI Class Initialized
INFO - 2021-08-26 23:50:53 --> Router Class Initialized
INFO - 2021-08-26 23:50:53 --> Output Class Initialized
INFO - 2021-08-26 23:50:53 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:53 --> Input Class Initialized
INFO - 2021-08-26 23:50:53 --> Language Class Initialized
ERROR - 2021-08-26 23:50:53 --> 404 Page Not Found: Style/default
ERROR - 2021-08-26 23:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:54 --> Config Class Initialized
INFO - 2021-08-26 23:50:54 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:54 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:54 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:54 --> URI Class Initialized
INFO - 2021-08-26 23:50:54 --> Router Class Initialized
INFO - 2021-08-26 23:50:54 --> Output Class Initialized
INFO - 2021-08-26 23:50:54 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:54 --> Input Class Initialized
INFO - 2021-08-26 23:50:54 --> Language Class Initialized
ERROR - 2021-08-26 23:50:54 --> 404 Page Not Found: Help/user
ERROR - 2021-08-26 23:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:55 --> Config Class Initialized
INFO - 2021-08-26 23:50:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:55 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:55 --> URI Class Initialized
INFO - 2021-08-26 23:50:55 --> Router Class Initialized
INFO - 2021-08-26 23:50:55 --> Output Class Initialized
INFO - 2021-08-26 23:50:55 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:55 --> Input Class Initialized
INFO - 2021-08-26 23:50:55 --> Language Class Initialized
ERROR - 2021-08-26 23:50:55 --> 404 Page Not Found: Script/valid_formdata.js
ERROR - 2021-08-26 23:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:55 --> Config Class Initialized
INFO - 2021-08-26 23:50:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:55 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:55 --> URI Class Initialized
INFO - 2021-08-26 23:50:55 --> Router Class Initialized
INFO - 2021-08-26 23:50:55 --> Output Class Initialized
INFO - 2021-08-26 23:50:55 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:55 --> Input Class Initialized
INFO - 2021-08-26 23:50:55 --> Language Class Initialized
ERROR - 2021-08-26 23:50:55 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-08-26 23:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:56 --> Config Class Initialized
INFO - 2021-08-26 23:50:56 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:56 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:56 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:56 --> URI Class Initialized
INFO - 2021-08-26 23:50:56 --> Router Class Initialized
INFO - 2021-08-26 23:50:56 --> Output Class Initialized
INFO - 2021-08-26 23:50:56 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:56 --> Input Class Initialized
INFO - 2021-08-26 23:50:56 --> Language Class Initialized
ERROR - 2021-08-26 23:50:56 --> 404 Page Not Found: Public/js
ERROR - 2021-08-26 23:50:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:57 --> Config Class Initialized
INFO - 2021-08-26 23:50:57 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:57 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:57 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:57 --> URI Class Initialized
INFO - 2021-08-26 23:50:57 --> Router Class Initialized
INFO - 2021-08-26 23:50:57 --> Output Class Initialized
INFO - 2021-08-26 23:50:57 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:57 --> Input Class Initialized
INFO - 2021-08-26 23:50:57 --> Language Class Initialized
ERROR - 2021-08-26 23:50:57 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-08-26 23:50:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:57 --> Config Class Initialized
INFO - 2021-08-26 23:50:57 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:57 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:57 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:57 --> URI Class Initialized
INFO - 2021-08-26 23:50:57 --> Router Class Initialized
INFO - 2021-08-26 23:50:57 --> Output Class Initialized
INFO - 2021-08-26 23:50:57 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:57 --> Input Class Initialized
INFO - 2021-08-26 23:50:57 --> Language Class Initialized
ERROR - 2021-08-26 23:50:57 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-08-26 23:50:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:58 --> Config Class Initialized
INFO - 2021-08-26 23:50:58 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:58 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:58 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:58 --> URI Class Initialized
INFO - 2021-08-26 23:50:58 --> Router Class Initialized
INFO - 2021-08-26 23:50:58 --> Output Class Initialized
INFO - 2021-08-26 23:50:58 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:58 --> Input Class Initialized
INFO - 2021-08-26 23:50:58 --> Language Class Initialized
ERROR - 2021-08-26 23:50:58 --> 404 Page Not Found: Themes/graphics
ERROR - 2021-08-26 23:50:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:50:59 --> Config Class Initialized
INFO - 2021-08-26 23:50:59 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:50:59 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:50:59 --> Utf8 Class Initialized
INFO - 2021-08-26 23:50:59 --> URI Class Initialized
INFO - 2021-08-26 23:50:59 --> Router Class Initialized
INFO - 2021-08-26 23:50:59 --> Output Class Initialized
INFO - 2021-08-26 23:50:59 --> Security Class Initialized
DEBUG - 2021-08-26 23:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:50:59 --> Input Class Initialized
INFO - 2021-08-26 23:50:59 --> Language Class Initialized
ERROR - 2021-08-26 23:50:59 --> 404 Page Not Found: Themes/default
ERROR - 2021-08-26 23:51:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:00 --> Config Class Initialized
INFO - 2021-08-26 23:51:00 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:00 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:00 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:00 --> URI Class Initialized
INFO - 2021-08-26 23:51:00 --> Router Class Initialized
INFO - 2021-08-26 23:51:00 --> Output Class Initialized
INFO - 2021-08-26 23:51:00 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:00 --> Input Class Initialized
INFO - 2021-08-26 23:51:00 --> Language Class Initialized
ERROR - 2021-08-26 23:51:00 --> 404 Page Not Found: Themes/default
ERROR - 2021-08-26 23:51:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:00 --> Config Class Initialized
INFO - 2021-08-26 23:51:00 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:00 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:00 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:00 --> URI Class Initialized
INFO - 2021-08-26 23:51:00 --> Router Class Initialized
INFO - 2021-08-26 23:51:00 --> Output Class Initialized
INFO - 2021-08-26 23:51:00 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:00 --> Input Class Initialized
INFO - 2021-08-26 23:51:00 --> Language Class Initialized
ERROR - 2021-08-26 23:51:00 --> 404 Page Not Found: Scripts/jquery
ERROR - 2021-08-26 23:51:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:01 --> Config Class Initialized
INFO - 2021-08-26 23:51:01 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:01 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:01 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:01 --> URI Class Initialized
INFO - 2021-08-26 23:51:01 --> Router Class Initialized
INFO - 2021-08-26 23:51:01 --> Output Class Initialized
INFO - 2021-08-26 23:51:01 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:01 --> Input Class Initialized
INFO - 2021-08-26 23:51:01 --> Language Class Initialized
ERROR - 2021-08-26 23:51:01 --> 404 Page Not Found: Media/com_hikashop
ERROR - 2021-08-26 23:51:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:02 --> Config Class Initialized
INFO - 2021-08-26 23:51:02 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:02 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:02 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:02 --> URI Class Initialized
INFO - 2021-08-26 23:51:02 --> Router Class Initialized
INFO - 2021-08-26 23:51:02 --> Output Class Initialized
INFO - 2021-08-26 23:51:02 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:02 --> Input Class Initialized
INFO - 2021-08-26 23:51:02 --> Language Class Initialized
ERROR - 2021-08-26 23:51:02 --> 404 Page Not Found: Templates/jsn_glass_pro
ERROR - 2021-08-26 23:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:03 --> Config Class Initialized
INFO - 2021-08-26 23:51:03 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:03 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:03 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:03 --> URI Class Initialized
INFO - 2021-08-26 23:51:03 --> Router Class Initialized
INFO - 2021-08-26 23:51:03 --> Output Class Initialized
INFO - 2021-08-26 23:51:03 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:03 --> Input Class Initialized
INFO - 2021-08-26 23:51:03 --> Language Class Initialized
ERROR - 2021-08-26 23:51:03 --> 404 Page Not Found: App/Tpl
ERROR - 2021-08-26 23:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:03 --> Config Class Initialized
INFO - 2021-08-26 23:51:03 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:03 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:03 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:03 --> URI Class Initialized
INFO - 2021-08-26 23:51:03 --> Router Class Initialized
INFO - 2021-08-26 23:51:03 --> Output Class Initialized
INFO - 2021-08-26 23:51:03 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:03 --> Input Class Initialized
INFO - 2021-08-26 23:51:03 --> Language Class Initialized
ERROR - 2021-08-26 23:51:03 --> 404 Page Not Found: Stylesheetcss/index
ERROR - 2021-08-26 23:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:04 --> Config Class Initialized
INFO - 2021-08-26 23:51:04 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:04 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:04 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:04 --> URI Class Initialized
INFO - 2021-08-26 23:51:04 --> Router Class Initialized
INFO - 2021-08-26 23:51:04 --> Output Class Initialized
INFO - 2021-08-26 23:51:04 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:04 --> Input Class Initialized
INFO - 2021-08-26 23:51:04 --> Language Class Initialized
ERROR - 2021-08-26 23:51:04 --> 404 Page Not Found: Includes/general.js
ERROR - 2021-08-26 23:51:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:05 --> Config Class Initialized
INFO - 2021-08-26 23:51:05 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:05 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:05 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:05 --> URI Class Initialized
INFO - 2021-08-26 23:51:05 --> Router Class Initialized
INFO - 2021-08-26 23:51:05 --> Output Class Initialized
INFO - 2021-08-26 23:51:05 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:05 --> Input Class Initialized
INFO - 2021-08-26 23:51:05 --> Language Class Initialized
ERROR - 2021-08-26 23:51:05 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-26 23:51:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:05 --> Config Class Initialized
INFO - 2021-08-26 23:51:05 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:05 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:05 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:05 --> URI Class Initialized
INFO - 2021-08-26 23:51:05 --> Router Class Initialized
INFO - 2021-08-26 23:51:05 --> Output Class Initialized
INFO - 2021-08-26 23:51:05 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:05 --> Input Class Initialized
INFO - 2021-08-26 23:51:05 --> Language Class Initialized
ERROR - 2021-08-26 23:51:05 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-08-26 23:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:07 --> Config Class Initialized
INFO - 2021-08-26 23:51:07 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:07 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:07 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:07 --> URI Class Initialized
INFO - 2021-08-26 23:51:07 --> Router Class Initialized
INFO - 2021-08-26 23:51:07 --> Output Class Initialized
INFO - 2021-08-26 23:51:07 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:07 --> Input Class Initialized
INFO - 2021-08-26 23:51:07 --> Language Class Initialized
ERROR - 2021-08-26 23:51:07 --> 404 Page Not Found: Rssphp/index
ERROR - 2021-08-26 23:51:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:08 --> Config Class Initialized
INFO - 2021-08-26 23:51:08 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:08 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:08 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:08 --> URI Class Initialized
INFO - 2021-08-26 23:51:08 --> Router Class Initialized
INFO - 2021-08-26 23:51:08 --> Output Class Initialized
INFO - 2021-08-26 23:51:08 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:08 --> Input Class Initialized
INFO - 2021-08-26 23:51:08 --> Language Class Initialized
ERROR - 2021-08-26 23:51:08 --> 404 Page Not Found: Inc/rsd.php
ERROR - 2021-08-26 23:51:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:08 --> Config Class Initialized
INFO - 2021-08-26 23:51:08 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:08 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:08 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:08 --> URI Class Initialized
INFO - 2021-08-26 23:51:08 --> Router Class Initialized
INFO - 2021-08-26 23:51:08 --> Output Class Initialized
INFO - 2021-08-26 23:51:08 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:08 --> Input Class Initialized
INFO - 2021-08-26 23:51:08 --> Language Class Initialized
ERROR - 2021-08-26 23:51:08 --> 404 Page Not Found: Archive/archive.css
ERROR - 2021-08-26 23:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:09 --> Config Class Initialized
INFO - 2021-08-26 23:51:09 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:09 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:09 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:09 --> URI Class Initialized
INFO - 2021-08-26 23:51:09 --> Router Class Initialized
INFO - 2021-08-26 23:51:09 --> Output Class Initialized
INFO - 2021-08-26 23:51:09 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:09 --> Input Class Initialized
INFO - 2021-08-26 23:51:09 --> Language Class Initialized
ERROR - 2021-08-26 23:51:09 --> 404 Page Not Found: Clientscript/vbulletin_ajax_htmlloader.js
ERROR - 2021-08-26 23:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:09 --> Config Class Initialized
INFO - 2021-08-26 23:51:09 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:09 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:09 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:09 --> URI Class Initialized
INFO - 2021-08-26 23:51:09 --> Router Class Initialized
INFO - 2021-08-26 23:51:09 --> Output Class Initialized
INFO - 2021-08-26 23:51:09 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:09 --> Input Class Initialized
INFO - 2021-08-26 23:51:09 --> Language Class Initialized
ERROR - 2021-08-26 23:51:09 --> 404 Page Not Found: Adminsoft/templates
ERROR - 2021-08-26 23:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:10 --> Config Class Initialized
INFO - 2021-08-26 23:51:10 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:10 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:10 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:10 --> URI Class Initialized
INFO - 2021-08-26 23:51:10 --> Router Class Initialized
INFO - 2021-08-26 23:51:10 --> Output Class Initialized
INFO - 2021-08-26 23:51:10 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:10 --> Input Class Initialized
INFO - 2021-08-26 23:51:10 --> Language Class Initialized
ERROR - 2021-08-26 23:51:10 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-08-26 23:51:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:11 --> Config Class Initialized
INFO - 2021-08-26 23:51:11 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:11 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:11 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:11 --> URI Class Initialized
INFO - 2021-08-26 23:51:11 --> Router Class Initialized
INFO - 2021-08-26 23:51:11 --> Output Class Initialized
INFO - 2021-08-26 23:51:11 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:11 --> Input Class Initialized
INFO - 2021-08-26 23:51:11 --> Language Class Initialized
ERROR - 2021-08-26 23:51:11 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-08-26 23:51:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:11 --> Config Class Initialized
INFO - 2021-08-26 23:51:11 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:11 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:11 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:11 --> URI Class Initialized
INFO - 2021-08-26 23:51:11 --> Router Class Initialized
INFO - 2021-08-26 23:51:11 --> Output Class Initialized
INFO - 2021-08-26 23:51:11 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:11 --> Input Class Initialized
INFO - 2021-08-26 23:51:11 --> Language Class Initialized
ERROR - 2021-08-26 23:51:11 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-08-26 23:51:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:12 --> Config Class Initialized
INFO - 2021-08-26 23:51:12 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:12 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:12 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:12 --> URI Class Initialized
INFO - 2021-08-26 23:51:12 --> Router Class Initialized
INFO - 2021-08-26 23:51:12 --> Output Class Initialized
INFO - 2021-08-26 23:51:12 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:12 --> Input Class Initialized
INFO - 2021-08-26 23:51:13 --> Language Class Initialized
ERROR - 2021-08-26 23:51:13 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-08-26 23:51:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:13 --> Config Class Initialized
INFO - 2021-08-26 23:51:13 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:13 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:13 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:13 --> URI Class Initialized
INFO - 2021-08-26 23:51:13 --> Router Class Initialized
INFO - 2021-08-26 23:51:13 --> Output Class Initialized
INFO - 2021-08-26 23:51:13 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:13 --> Input Class Initialized
INFO - 2021-08-26 23:51:13 --> Language Class Initialized
ERROR - 2021-08-26 23:51:13 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-08-26 23:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:14 --> Config Class Initialized
INFO - 2021-08-26 23:51:14 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:14 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:14 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:14 --> URI Class Initialized
INFO - 2021-08-26 23:51:14 --> Router Class Initialized
INFO - 2021-08-26 23:51:14 --> Output Class Initialized
INFO - 2021-08-26 23:51:14 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:14 --> Input Class Initialized
INFO - 2021-08-26 23:51:14 --> Language Class Initialized
ERROR - 2021-08-26 23:51:14 --> 404 Page Not Found: Externphp/index
ERROR - 2021-08-26 23:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:14 --> Config Class Initialized
INFO - 2021-08-26 23:51:14 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:14 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:14 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:14 --> URI Class Initialized
INFO - 2021-08-26 23:51:14 --> Router Class Initialized
INFO - 2021-08-26 23:51:14 --> Output Class Initialized
INFO - 2021-08-26 23:51:14 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:14 --> Input Class Initialized
INFO - 2021-08-26 23:51:14 --> Language Class Initialized
ERROR - 2021-08-26 23:51:14 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-08-26 23:51:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:15 --> Config Class Initialized
INFO - 2021-08-26 23:51:15 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:15 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:15 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:15 --> URI Class Initialized
INFO - 2021-08-26 23:51:15 --> Router Class Initialized
INFO - 2021-08-26 23:51:15 --> Output Class Initialized
INFO - 2021-08-26 23:51:15 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:15 --> Input Class Initialized
INFO - 2021-08-26 23:51:15 --> Language Class Initialized
ERROR - 2021-08-26 23:51:15 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-08-26 23:51:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:15 --> Config Class Initialized
INFO - 2021-08-26 23:51:15 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:15 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:15 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:15 --> URI Class Initialized
INFO - 2021-08-26 23:51:15 --> Router Class Initialized
INFO - 2021-08-26 23:51:15 --> Output Class Initialized
INFO - 2021-08-26 23:51:15 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:15 --> Input Class Initialized
INFO - 2021-08-26 23:51:15 --> Language Class Initialized
ERROR - 2021-08-26 23:51:15 --> 404 Page Not Found: Common/common.js
ERROR - 2021-08-26 23:51:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:16 --> Config Class Initialized
INFO - 2021-08-26 23:51:16 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:16 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:16 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:16 --> URI Class Initialized
INFO - 2021-08-26 23:51:16 --> Router Class Initialized
INFO - 2021-08-26 23:51:16 --> Output Class Initialized
INFO - 2021-08-26 23:51:16 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:16 --> Input Class Initialized
INFO - 2021-08-26 23:51:16 --> Language Class Initialized
ERROR - 2021-08-26 23:51:16 --> 404 Page Not Found: 404jpg/index
ERROR - 2021-08-26 23:51:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:16 --> Config Class Initialized
INFO - 2021-08-26 23:51:16 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:16 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:16 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:16 --> URI Class Initialized
INFO - 2021-08-26 23:51:16 --> Router Class Initialized
INFO - 2021-08-26 23:51:16 --> Output Class Initialized
INFO - 2021-08-26 23:51:16 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:16 --> Input Class Initialized
INFO - 2021-08-26 23:51:16 --> Language Class Initialized
ERROR - 2021-08-26 23:51:16 --> 404 Page Not Found: Ks_inc/ajax.js
ERROR - 2021-08-26 23:51:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:17 --> Config Class Initialized
INFO - 2021-08-26 23:51:17 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:17 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:17 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:17 --> URI Class Initialized
INFO - 2021-08-26 23:51:17 --> Router Class Initialized
INFO - 2021-08-26 23:51:17 --> Output Class Initialized
INFO - 2021-08-26 23:51:17 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:17 --> Input Class Initialized
INFO - 2021-08-26 23:51:17 --> Language Class Initialized
ERROR - 2021-08-26 23:51:17 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-08-26 23:51:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:17 --> Config Class Initialized
INFO - 2021-08-26 23:51:17 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:17 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:17 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:17 --> URI Class Initialized
INFO - 2021-08-26 23:51:17 --> Router Class Initialized
INFO - 2021-08-26 23:51:17 --> Output Class Initialized
INFO - 2021-08-26 23:51:17 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:17 --> Input Class Initialized
INFO - 2021-08-26 23:51:17 --> Language Class Initialized
ERROR - 2021-08-26 23:51:17 --> 404 Page Not Found: Static/hgicon.png
ERROR - 2021-08-26 23:51:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:18 --> Config Class Initialized
INFO - 2021-08-26 23:51:18 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:18 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:18 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:18 --> URI Class Initialized
INFO - 2021-08-26 23:51:18 --> Router Class Initialized
INFO - 2021-08-26 23:51:18 --> Output Class Initialized
INFO - 2021-08-26 23:51:18 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:18 --> Input Class Initialized
INFO - 2021-08-26 23:51:18 --> Language Class Initialized
ERROR - 2021-08-26 23:51:18 --> 404 Page Not Found: Base/login
ERROR - 2021-08-26 23:51:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:18 --> Config Class Initialized
INFO - 2021-08-26 23:51:18 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:18 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:18 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:18 --> URI Class Initialized
INFO - 2021-08-26 23:51:18 --> Router Class Initialized
INFO - 2021-08-26 23:51:18 --> Output Class Initialized
INFO - 2021-08-26 23:51:18 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:18 --> Input Class Initialized
INFO - 2021-08-26 23:51:18 --> Language Class Initialized
ERROR - 2021-08-26 23:51:18 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-08-26 23:51:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:19 --> Config Class Initialized
INFO - 2021-08-26 23:51:19 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:19 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:19 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:19 --> URI Class Initialized
INFO - 2021-08-26 23:51:19 --> Router Class Initialized
INFO - 2021-08-26 23:51:19 --> Output Class Initialized
INFO - 2021-08-26 23:51:19 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:19 --> Input Class Initialized
INFO - 2021-08-26 23:51:19 --> Language Class Initialized
ERROR - 2021-08-26 23:51:19 --> 404 Page Not Found: Js/ajax_x.js
ERROR - 2021-08-26 23:51:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:20 --> Config Class Initialized
INFO - 2021-08-26 23:51:20 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:20 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:20 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:20 --> URI Class Initialized
INFO - 2021-08-26 23:51:20 --> Router Class Initialized
INFO - 2021-08-26 23:51:20 --> Output Class Initialized
INFO - 2021-08-26 23:51:20 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:20 --> Input Class Initialized
INFO - 2021-08-26 23:51:20 --> Language Class Initialized
ERROR - 2021-08-26 23:51:20 --> 404 Page Not Found: Adminphp/index
ERROR - 2021-08-26 23:51:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:20 --> Config Class Initialized
INFO - 2021-08-26 23:51:20 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:20 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:20 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:20 --> URI Class Initialized
INFO - 2021-08-26 23:51:20 --> Router Class Initialized
INFO - 2021-08-26 23:51:20 --> Output Class Initialized
INFO - 2021-08-26 23:51:20 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:20 --> Input Class Initialized
INFO - 2021-08-26 23:51:20 --> Language Class Initialized
ERROR - 2021-08-26 23:51:20 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-08-26 23:51:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:21 --> Config Class Initialized
INFO - 2021-08-26 23:51:21 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:21 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:21 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:21 --> URI Class Initialized
INFO - 2021-08-26 23:51:21 --> Router Class Initialized
INFO - 2021-08-26 23:51:21 --> Output Class Initialized
INFO - 2021-08-26 23:51:21 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:21 --> Input Class Initialized
INFO - 2021-08-26 23:51:21 --> Language Class Initialized
ERROR - 2021-08-26 23:51:21 --> 404 Page Not Found: Max-templates/classic
ERROR - 2021-08-26 23:51:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:21 --> Config Class Initialized
INFO - 2021-08-26 23:51:21 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:21 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:21 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:21 --> URI Class Initialized
INFO - 2021-08-26 23:51:21 --> Router Class Initialized
INFO - 2021-08-26 23:51:21 --> Output Class Initialized
INFO - 2021-08-26 23:51:21 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:21 --> Input Class Initialized
INFO - 2021-08-26 23:51:21 --> Language Class Initialized
ERROR - 2021-08-26 23:51:21 --> 404 Page Not Found: Admin/login.php
ERROR - 2021-08-26 23:51:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:22 --> Config Class Initialized
INFO - 2021-08-26 23:51:22 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:22 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:22 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:22 --> URI Class Initialized
INFO - 2021-08-26 23:51:22 --> Router Class Initialized
INFO - 2021-08-26 23:51:22 --> Output Class Initialized
INFO - 2021-08-26 23:51:22 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:22 --> Input Class Initialized
INFO - 2021-08-26 23:51:22 --> Language Class Initialized
ERROR - 2021-08-26 23:51:22 --> 404 Page Not Found: Images/logo_88x31.gif
ERROR - 2021-08-26 23:51:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:22 --> Config Class Initialized
INFO - 2021-08-26 23:51:22 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:22 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:22 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:22 --> URI Class Initialized
INFO - 2021-08-26 23:51:22 --> Router Class Initialized
INFO - 2021-08-26 23:51:22 --> Output Class Initialized
INFO - 2021-08-26 23:51:22 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:22 --> Input Class Initialized
INFO - 2021-08-26 23:51:22 --> Language Class Initialized
ERROR - 2021-08-26 23:51:22 --> 404 Page Not Found: Admin/index
ERROR - 2021-08-26 23:51:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:23 --> Config Class Initialized
INFO - 2021-08-26 23:51:23 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:23 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:23 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:23 --> URI Class Initialized
INFO - 2021-08-26 23:51:23 --> Router Class Initialized
INFO - 2021-08-26 23:51:23 --> Output Class Initialized
INFO - 2021-08-26 23:51:23 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:23 --> Input Class Initialized
INFO - 2021-08-26 23:51:23 --> Language Class Initialized
ERROR - 2021-08-26 23:51:23 --> 404 Page Not Found: Plug/publish
ERROR - 2021-08-26 23:51:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:23 --> Config Class Initialized
INFO - 2021-08-26 23:51:23 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:23 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:23 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:23 --> URI Class Initialized
INFO - 2021-08-26 23:51:23 --> Router Class Initialized
INFO - 2021-08-26 23:51:23 --> Output Class Initialized
INFO - 2021-08-26 23:51:23 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:23 --> Input Class Initialized
INFO - 2021-08-26 23:51:23 --> Language Class Initialized
ERROR - 2021-08-26 23:51:23 --> 404 Page Not Found: Images/logo_product-cml.png
ERROR - 2021-08-26 23:51:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:24 --> Config Class Initialized
INFO - 2021-08-26 23:51:24 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:24 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:24 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:24 --> URI Class Initialized
DEBUG - 2021-08-26 23:51:24 --> No URI present. Default controller set.
INFO - 2021-08-26 23:51:24 --> Router Class Initialized
INFO - 2021-08-26 23:51:24 --> Output Class Initialized
INFO - 2021-08-26 23:51:24 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:24 --> Input Class Initialized
INFO - 2021-08-26 23:51:24 --> Language Class Initialized
INFO - 2021-08-26 23:51:24 --> Loader Class Initialized
INFO - 2021-08-26 23:51:24 --> Helper loaded: url_helper
INFO - 2021-08-26 23:51:24 --> Helper loaded: form_helper
INFO - 2021-08-26 23:51:24 --> Helper loaded: common_helper
INFO - 2021-08-26 23:51:24 --> Database Driver Class Initialized
DEBUG - 2021-08-26 23:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-26 23:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-26 23:51:24 --> Controller Class Initialized
INFO - 2021-08-26 23:51:24 --> Form Validation Class Initialized
DEBUG - 2021-08-26 23:51:24 --> Encrypt Class Initialized
DEBUG - 2021-08-26 23:51:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-26 23:51:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-26 23:51:24 --> Email Class Initialized
INFO - 2021-08-26 23:51:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-26 23:51:24 --> Calendar Class Initialized
INFO - 2021-08-26 23:51:24 --> Model "Login_model" initialized
INFO - 2021-08-26 23:51:24 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-26 23:51:24 --> Final output sent to browser
DEBUG - 2021-08-26 23:51:24 --> Total execution time: 0.0189
ERROR - 2021-08-26 23:51:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:24 --> Config Class Initialized
INFO - 2021-08-26 23:51:24 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:24 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:24 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:24 --> URI Class Initialized
INFO - 2021-08-26 23:51:24 --> Router Class Initialized
INFO - 2021-08-26 23:51:24 --> Output Class Initialized
INFO - 2021-08-26 23:51:24 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:24 --> Input Class Initialized
INFO - 2021-08-26 23:51:24 --> Language Class Initialized
ERROR - 2021-08-26 23:51:24 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-08-26 23:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:25 --> Config Class Initialized
INFO - 2021-08-26 23:51:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:25 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:25 --> URI Class Initialized
INFO - 2021-08-26 23:51:25 --> Router Class Initialized
INFO - 2021-08-26 23:51:25 --> Output Class Initialized
INFO - 2021-08-26 23:51:25 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:25 --> Input Class Initialized
INFO - 2021-08-26 23:51:25 --> Language Class Initialized
ERROR - 2021-08-26 23:51:25 --> 404 Page Not Found: Imagesschool/style1
ERROR - 2021-08-26 23:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:25 --> Config Class Initialized
INFO - 2021-08-26 23:51:25 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:25 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:25 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:25 --> URI Class Initialized
INFO - 2021-08-26 23:51:25 --> Router Class Initialized
INFO - 2021-08-26 23:51:25 --> Output Class Initialized
INFO - 2021-08-26 23:51:25 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:25 --> Input Class Initialized
INFO - 2021-08-26 23:51:25 --> Language Class Initialized
ERROR - 2021-08-26 23:51:25 --> 404 Page Not Found: Public/about.html
ERROR - 2021-08-26 23:51:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:26 --> Config Class Initialized
INFO - 2021-08-26 23:51:26 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:26 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:26 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:26 --> URI Class Initialized
INFO - 2021-08-26 23:51:26 --> Router Class Initialized
INFO - 2021-08-26 23:51:26 --> Output Class Initialized
INFO - 2021-08-26 23:51:26 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:26 --> Input Class Initialized
INFO - 2021-08-26 23:51:26 --> Language Class Initialized
ERROR - 2021-08-26 23:51:26 --> 404 Page Not Found: Help/en
ERROR - 2021-08-26 23:51:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:26 --> Config Class Initialized
INFO - 2021-08-26 23:51:26 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:26 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:26 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:26 --> URI Class Initialized
INFO - 2021-08-26 23:51:26 --> Router Class Initialized
INFO - 2021-08-26 23:51:26 --> Output Class Initialized
INFO - 2021-08-26 23:51:26 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:26 --> Input Class Initialized
INFO - 2021-08-26 23:51:26 --> Language Class Initialized
ERROR - 2021-08-26 23:51:26 --> 404 Page Not Found: Public/Admin
ERROR - 2021-08-26 23:51:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:27 --> Config Class Initialized
INFO - 2021-08-26 23:51:27 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:27 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:27 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:27 --> URI Class Initialized
INFO - 2021-08-26 23:51:27 --> Router Class Initialized
INFO - 2021-08-26 23:51:27 --> Output Class Initialized
INFO - 2021-08-26 23:51:27 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:27 --> Input Class Initialized
INFO - 2021-08-26 23:51:27 --> Language Class Initialized
ERROR - 2021-08-26 23:51:27 --> 404 Page Not Found: Script/login.js
ERROR - 2021-08-26 23:51:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:27 --> Config Class Initialized
INFO - 2021-08-26 23:51:27 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:27 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:27 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:27 --> URI Class Initialized
INFO - 2021-08-26 23:51:27 --> Router Class Initialized
INFO - 2021-08-26 23:51:27 --> Output Class Initialized
INFO - 2021-08-26 23:51:27 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:27 --> Input Class Initialized
INFO - 2021-08-26 23:51:27 --> Language Class Initialized
ERROR - 2021-08-26 23:51:27 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-08-26 23:51:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:28 --> Config Class Initialized
INFO - 2021-08-26 23:51:28 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:28 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:28 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:28 --> URI Class Initialized
INFO - 2021-08-26 23:51:28 --> Router Class Initialized
INFO - 2021-08-26 23:51:28 --> Output Class Initialized
INFO - 2021-08-26 23:51:28 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:28 --> Input Class Initialized
INFO - 2021-08-26 23:51:28 --> Language Class Initialized
ERROR - 2021-08-26 23:51:28 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-08-26 23:51:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:28 --> Config Class Initialized
INFO - 2021-08-26 23:51:28 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:28 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:28 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:28 --> URI Class Initialized
INFO - 2021-08-26 23:51:28 --> Router Class Initialized
INFO - 2021-08-26 23:51:28 --> Output Class Initialized
INFO - 2021-08-26 23:51:28 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:28 --> Input Class Initialized
INFO - 2021-08-26 23:51:28 --> Language Class Initialized
ERROR - 2021-08-26 23:51:28 --> 404 Page Not Found: Images/logo-white.png
ERROR - 2021-08-26 23:51:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:29 --> Config Class Initialized
INFO - 2021-08-26 23:51:29 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:29 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:29 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:29 --> URI Class Initialized
INFO - 2021-08-26 23:51:29 --> Router Class Initialized
INFO - 2021-08-26 23:51:29 --> Output Class Initialized
INFO - 2021-08-26 23:51:29 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:29 --> Input Class Initialized
INFO - 2021-08-26 23:51:29 --> Language Class Initialized
ERROR - 2021-08-26 23:51:29 --> 404 Page Not Found: Customdir/images
ERROR - 2021-08-26 23:51:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:29 --> Config Class Initialized
INFO - 2021-08-26 23:51:29 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:29 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:29 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:29 --> URI Class Initialized
INFO - 2021-08-26 23:51:29 --> Router Class Initialized
INFO - 2021-08-26 23:51:29 --> Output Class Initialized
INFO - 2021-08-26 23:51:29 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:29 --> Input Class Initialized
INFO - 2021-08-26 23:51:29 --> Language Class Initialized
ERROR - 2021-08-26 23:51:29 --> 404 Page Not Found: Include/dedeajax2.js
ERROR - 2021-08-26 23:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:30 --> Config Class Initialized
INFO - 2021-08-26 23:51:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:30 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:30 --> URI Class Initialized
INFO - 2021-08-26 23:51:30 --> Router Class Initialized
INFO - 2021-08-26 23:51:30 --> Output Class Initialized
INFO - 2021-08-26 23:51:30 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:30 --> Input Class Initialized
INFO - 2021-08-26 23:51:30 --> Language Class Initialized
ERROR - 2021-08-26 23:51:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-26 23:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:30 --> Config Class Initialized
INFO - 2021-08-26 23:51:30 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:30 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:30 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:30 --> URI Class Initialized
INFO - 2021-08-26 23:51:30 --> Router Class Initialized
INFO - 2021-08-26 23:51:30 --> Output Class Initialized
INFO - 2021-08-26 23:51:30 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:30 --> Input Class Initialized
INFO - 2021-08-26 23:51:30 --> Language Class Initialized
ERROR - 2021-08-26 23:51:30 --> 404 Page Not Found: Include/dialog
ERROR - 2021-08-26 23:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:31 --> Config Class Initialized
INFO - 2021-08-26 23:51:31 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:31 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:31 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:31 --> URI Class Initialized
INFO - 2021-08-26 23:51:31 --> Router Class Initialized
INFO - 2021-08-26 23:51:31 --> Output Class Initialized
INFO - 2021-08-26 23:51:31 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:31 --> Input Class Initialized
INFO - 2021-08-26 23:51:31 --> Language Class Initialized
ERROR - 2021-08-26 23:51:31 --> 404 Page Not Found: Plus/download.php
ERROR - 2021-08-26 23:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:31 --> Config Class Initialized
INFO - 2021-08-26 23:51:31 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:31 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:31 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:31 --> URI Class Initialized
INFO - 2021-08-26 23:51:31 --> Router Class Initialized
INFO - 2021-08-26 23:51:31 --> Output Class Initialized
INFO - 2021-08-26 23:51:31 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:31 --> Input Class Initialized
INFO - 2021-08-26 23:51:31 --> Language Class Initialized
ERROR - 2021-08-26 23:51:31 --> 404 Page Not Found: Diggphp/index
ERROR - 2021-08-26 23:51:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:32 --> Config Class Initialized
INFO - 2021-08-26 23:51:32 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:32 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:32 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:32 --> URI Class Initialized
INFO - 2021-08-26 23:51:32 --> Router Class Initialized
INFO - 2021-08-26 23:51:32 --> Output Class Initialized
INFO - 2021-08-26 23:51:32 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:32 --> Input Class Initialized
INFO - 2021-08-26 23:51:32 --> Language Class Initialized
ERROR - 2021-08-26 23:51:32 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-08-26 23:51:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:32 --> Config Class Initialized
INFO - 2021-08-26 23:51:32 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:32 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:32 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:32 --> URI Class Initialized
INFO - 2021-08-26 23:51:32 --> Router Class Initialized
INFO - 2021-08-26 23:51:32 --> Output Class Initialized
INFO - 2021-08-26 23:51:32 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:32 --> Input Class Initialized
INFO - 2021-08-26 23:51:32 --> Language Class Initialized
ERROR - 2021-08-26 23:51:32 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-08-26 23:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:33 --> Config Class Initialized
INFO - 2021-08-26 23:51:33 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:33 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:33 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:33 --> URI Class Initialized
INFO - 2021-08-26 23:51:33 --> Router Class Initialized
INFO - 2021-08-26 23:51:33 --> Output Class Initialized
INFO - 2021-08-26 23:51:33 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:33 --> Input Class Initialized
INFO - 2021-08-26 23:51:33 --> Language Class Initialized
ERROR - 2021-08-26 23:51:33 --> 404 Page Not Found: Plus/heightsearch.php
ERROR - 2021-08-26 23:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:33 --> Config Class Initialized
INFO - 2021-08-26 23:51:33 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:33 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:33 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:33 --> URI Class Initialized
INFO - 2021-08-26 23:51:33 --> Router Class Initialized
INFO - 2021-08-26 23:51:33 --> Output Class Initialized
INFO - 2021-08-26 23:51:33 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:33 --> Input Class Initialized
INFO - 2021-08-26 23:51:33 --> Language Class Initialized
ERROR - 2021-08-26 23:51:33 --> 404 Page Not Found: Member/space
ERROR - 2021-08-26 23:51:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:34 --> Config Class Initialized
INFO - 2021-08-26 23:51:34 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:34 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:34 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:34 --> URI Class Initialized
INFO - 2021-08-26 23:51:34 --> Router Class Initialized
INFO - 2021-08-26 23:51:34 --> Output Class Initialized
INFO - 2021-08-26 23:51:34 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:34 --> Input Class Initialized
INFO - 2021-08-26 23:51:34 --> Language Class Initialized
ERROR - 2021-08-26 23:51:34 --> 404 Page Not Found: Help/index
ERROR - 2021-08-26 23:51:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:34 --> Config Class Initialized
INFO - 2021-08-26 23:51:34 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:34 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:34 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:34 --> URI Class Initialized
INFO - 2021-08-26 23:51:34 --> Router Class Initialized
INFO - 2021-08-26 23:51:34 --> Output Class Initialized
INFO - 2021-08-26 23:51:34 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:34 --> Input Class Initialized
INFO - 2021-08-26 23:51:34 --> Language Class Initialized
ERROR - 2021-08-26 23:51:34 --> 404 Page Not Found: Images/branding
ERROR - 2021-08-26 23:51:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:35 --> Config Class Initialized
INFO - 2021-08-26 23:51:35 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:35 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:35 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:35 --> URI Class Initialized
INFO - 2021-08-26 23:51:35 --> Router Class Initialized
INFO - 2021-08-26 23:51:35 --> Output Class Initialized
INFO - 2021-08-26 23:51:35 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:35 --> Input Class Initialized
INFO - 2021-08-26 23:51:35 --> Language Class Initialized
ERROR - 2021-08-26 23:51:35 --> 404 Page Not Found: Install/logo.gif
ERROR - 2021-08-26 23:51:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:35 --> Config Class Initialized
INFO - 2021-08-26 23:51:35 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:35 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:35 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:35 --> URI Class Initialized
INFO - 2021-08-26 23:51:35 --> Router Class Initialized
INFO - 2021-08-26 23:51:35 --> Output Class Initialized
INFO - 2021-08-26 23:51:35 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:35 --> Input Class Initialized
INFO - 2021-08-26 23:51:35 --> Language Class Initialized
ERROR - 2021-08-26 23:51:35 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-08-26 23:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:36 --> Config Class Initialized
INFO - 2021-08-26 23:51:36 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:36 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:36 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:36 --> URI Class Initialized
INFO - 2021-08-26 23:51:36 --> Router Class Initialized
INFO - 2021-08-26 23:51:36 --> Output Class Initialized
INFO - 2021-08-26 23:51:36 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:36 --> Input Class Initialized
INFO - 2021-08-26 23:51:36 --> Language Class Initialized
ERROR - 2021-08-26 23:51:36 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-08-26 23:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:36 --> Config Class Initialized
INFO - 2021-08-26 23:51:36 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:36 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:36 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:36 --> URI Class Initialized
INFO - 2021-08-26 23:51:36 --> Router Class Initialized
INFO - 2021-08-26 23:51:36 --> Output Class Initialized
INFO - 2021-08-26 23:51:36 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:36 --> Input Class Initialized
INFO - 2021-08-26 23:51:36 --> Language Class Initialized
ERROR - 2021-08-26 23:51:36 --> 404 Page Not Found: Adminphp/index
ERROR - 2021-08-26 23:51:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:37 --> Config Class Initialized
INFO - 2021-08-26 23:51:37 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:37 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:37 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:37 --> URI Class Initialized
INFO - 2021-08-26 23:51:37 --> Router Class Initialized
INFO - 2021-08-26 23:51:37 --> Output Class Initialized
INFO - 2021-08-26 23:51:37 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:37 --> Input Class Initialized
INFO - 2021-08-26 23:51:37 --> Language Class Initialized
ERROR - 2021-08-26 23:51:37 --> 404 Page Not Found: M/index
ERROR - 2021-08-26 23:51:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:37 --> Config Class Initialized
INFO - 2021-08-26 23:51:37 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:37 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:37 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:37 --> URI Class Initialized
INFO - 2021-08-26 23:51:37 --> Router Class Initialized
INFO - 2021-08-26 23:51:37 --> Output Class Initialized
INFO - 2021-08-26 23:51:37 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:37 --> Input Class Initialized
INFO - 2021-08-26 23:51:37 --> Language Class Initialized
ERROR - 2021-08-26 23:51:37 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-08-26 23:51:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:38 --> Config Class Initialized
INFO - 2021-08-26 23:51:38 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:38 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:38 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:38 --> URI Class Initialized
INFO - 2021-08-26 23:51:38 --> Router Class Initialized
INFO - 2021-08-26 23:51:38 --> Output Class Initialized
INFO - 2021-08-26 23:51:38 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:38 --> Input Class Initialized
INFO - 2021-08-26 23:51:38 --> Language Class Initialized
ERROR - 2021-08-26 23:51:38 --> 404 Page Not Found: Images/login_Name.jpg
ERROR - 2021-08-26 23:51:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:38 --> Config Class Initialized
INFO - 2021-08-26 23:51:38 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:38 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:38 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:38 --> URI Class Initialized
INFO - 2021-08-26 23:51:38 --> Router Class Initialized
INFO - 2021-08-26 23:51:38 --> Output Class Initialized
INFO - 2021-08-26 23:51:38 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:38 --> Input Class Initialized
INFO - 2021-08-26 23:51:38 --> Language Class Initialized
ERROR - 2021-08-26 23:51:38 --> 404 Page Not Found: Webbuilder/script
ERROR - 2021-08-26 23:51:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:39 --> Config Class Initialized
INFO - 2021-08-26 23:51:39 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:39 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:39 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:39 --> URI Class Initialized
INFO - 2021-08-26 23:51:39 --> Router Class Initialized
INFO - 2021-08-26 23:51:39 --> Output Class Initialized
INFO - 2021-08-26 23:51:39 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:39 --> Input Class Initialized
INFO - 2021-08-26 23:51:39 --> Language Class Initialized
ERROR - 2021-08-26 23:51:39 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-08-26 23:51:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:39 --> Config Class Initialized
INFO - 2021-08-26 23:51:39 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:39 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:39 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:39 --> URI Class Initialized
INFO - 2021-08-26 23:51:39 --> Router Class Initialized
INFO - 2021-08-26 23:51:39 --> Output Class Initialized
INFO - 2021-08-26 23:51:39 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:39 --> Input Class Initialized
INFO - 2021-08-26 23:51:39 --> Language Class Initialized
ERROR - 2021-08-26 23:51:39 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-08-26 23:51:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:40 --> Config Class Initialized
INFO - 2021-08-26 23:51:40 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:40 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:40 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:40 --> URI Class Initialized
INFO - 2021-08-26 23:51:40 --> Router Class Initialized
INFO - 2021-08-26 23:51:40 --> Output Class Initialized
INFO - 2021-08-26 23:51:40 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:40 --> Input Class Initialized
INFO - 2021-08-26 23:51:40 --> Language Class Initialized
ERROR - 2021-08-26 23:51:40 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-08-26 23:51:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:40 --> Config Class Initialized
INFO - 2021-08-26 23:51:40 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:40 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:40 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:40 --> URI Class Initialized
INFO - 2021-08-26 23:51:40 --> Router Class Initialized
INFO - 2021-08-26 23:51:40 --> Output Class Initialized
INFO - 2021-08-26 23:51:40 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:40 --> Input Class Initialized
INFO - 2021-08-26 23:51:40 --> Language Class Initialized
ERROR - 2021-08-26 23:51:40 --> 404 Page Not Found: Site/Pages
ERROR - 2021-08-26 23:51:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:41 --> Config Class Initialized
INFO - 2021-08-26 23:51:41 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:41 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:41 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:41 --> URI Class Initialized
INFO - 2021-08-26 23:51:41 --> Router Class Initialized
INFO - 2021-08-26 23:51:41 --> Output Class Initialized
INFO - 2021-08-26 23:51:41 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:41 --> Input Class Initialized
INFO - 2021-08-26 23:51:41 --> Language Class Initialized
ERROR - 2021-08-26 23:51:41 --> 404 Page Not Found: Site/SystemThemes
ERROR - 2021-08-26 23:51:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:42 --> Config Class Initialized
INFO - 2021-08-26 23:51:42 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:42 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:42 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:42 --> URI Class Initialized
INFO - 2021-08-26 23:51:42 --> Router Class Initialized
INFO - 2021-08-26 23:51:42 --> Output Class Initialized
INFO - 2021-08-26 23:51:42 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:42 --> Input Class Initialized
INFO - 2021-08-26 23:51:42 --> Language Class Initialized
ERROR - 2021-08-26 23:51:42 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-08-26 23:51:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:42 --> Config Class Initialized
INFO - 2021-08-26 23:51:42 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:42 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:42 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:42 --> URI Class Initialized
INFO - 2021-08-26 23:51:42 --> Router Class Initialized
INFO - 2021-08-26 23:51:42 --> Output Class Initialized
INFO - 2021-08-26 23:51:42 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:42 --> Input Class Initialized
INFO - 2021-08-26 23:51:42 --> Language Class Initialized
ERROR - 2021-08-26 23:51:42 --> 404 Page Not Found: Forumphp/index
ERROR - 2021-08-26 23:51:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:43 --> Config Class Initialized
INFO - 2021-08-26 23:51:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:43 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:43 --> URI Class Initialized
INFO - 2021-08-26 23:51:43 --> Router Class Initialized
INFO - 2021-08-26 23:51:43 --> Output Class Initialized
INFO - 2021-08-26 23:51:43 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:43 --> Input Class Initialized
INFO - 2021-08-26 23:51:43 --> Language Class Initialized
ERROR - 2021-08-26 23:51:43 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-26 23:51:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:43 --> Config Class Initialized
INFO - 2021-08-26 23:51:43 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:43 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:43 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:43 --> URI Class Initialized
INFO - 2021-08-26 23:51:43 --> Router Class Initialized
INFO - 2021-08-26 23:51:43 --> Output Class Initialized
INFO - 2021-08-26 23:51:43 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:43 --> Input Class Initialized
INFO - 2021-08-26 23:51:43 --> Language Class Initialized
ERROR - 2021-08-26 23:51:43 --> 404 Page Not Found: Uc_server/control
ERROR - 2021-08-26 23:51:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:44 --> Config Class Initialized
INFO - 2021-08-26 23:51:44 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:44 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:44 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:44 --> URI Class Initialized
INFO - 2021-08-26 23:51:44 --> Router Class Initialized
INFO - 2021-08-26 23:51:44 --> Output Class Initialized
INFO - 2021-08-26 23:51:44 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:44 --> Input Class Initialized
INFO - 2021-08-26 23:51:44 --> Language Class Initialized
ERROR - 2021-08-26 23:51:44 --> 404 Page Not Found: Img/pic
ERROR - 2021-08-26 23:51:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:44 --> Config Class Initialized
INFO - 2021-08-26 23:51:44 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:44 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:44 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:44 --> URI Class Initialized
INFO - 2021-08-26 23:51:44 --> Router Class Initialized
INFO - 2021-08-26 23:51:44 --> Output Class Initialized
INFO - 2021-08-26 23:51:44 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:44 --> Input Class Initialized
INFO - 2021-08-26 23:51:44 --> Language Class Initialized
ERROR - 2021-08-26 23:51:44 --> 404 Page Not Found: Include/EcsServerApi.js
ERROR - 2021-08-26 23:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:45 --> Config Class Initialized
INFO - 2021-08-26 23:51:45 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:45 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:45 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:45 --> URI Class Initialized
INFO - 2021-08-26 23:51:45 --> Router Class Initialized
INFO - 2021-08-26 23:51:45 --> Output Class Initialized
INFO - 2021-08-26 23:51:45 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:45 --> Input Class Initialized
INFO - 2021-08-26 23:51:45 --> Language Class Initialized
ERROR - 2021-08-26 23:51:45 --> 404 Page Not Found: Business/images
ERROR - 2021-08-26 23:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:45 --> Config Class Initialized
INFO - 2021-08-26 23:51:45 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:45 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:45 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:45 --> URI Class Initialized
INFO - 2021-08-26 23:51:45 --> Router Class Initialized
INFO - 2021-08-26 23:51:45 --> Output Class Initialized
INFO - 2021-08-26 23:51:45 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:45 --> Input Class Initialized
INFO - 2021-08-26 23:51:45 --> Language Class Initialized
ERROR - 2021-08-26 23:51:45 --> 404 Page Not Found: Images/Default_bg_002.gif
ERROR - 2021-08-26 23:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:46 --> Config Class Initialized
INFO - 2021-08-26 23:51:46 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:46 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:46 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:46 --> URI Class Initialized
INFO - 2021-08-26 23:51:46 --> Router Class Initialized
INFO - 2021-08-26 23:51:46 --> Output Class Initialized
INFO - 2021-08-26 23:51:46 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:46 --> Input Class Initialized
INFO - 2021-08-26 23:51:46 --> Language Class Initialized
ERROR - 2021-08-26 23:51:46 --> 404 Page Not Found: Eams/static
ERROR - 2021-08-26 23:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:47 --> Config Class Initialized
INFO - 2021-08-26 23:51:47 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:47 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:47 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:47 --> URI Class Initialized
INFO - 2021-08-26 23:51:47 --> Router Class Initialized
INFO - 2021-08-26 23:51:47 --> Output Class Initialized
INFO - 2021-08-26 23:51:47 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:47 --> Input Class Initialized
INFO - 2021-08-26 23:51:47 --> Language Class Initialized
ERROR - 2021-08-26 23:51:47 --> 404 Page Not Found: Custom/SkinTemplate
ERROR - 2021-08-26 23:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:47 --> Config Class Initialized
INFO - 2021-08-26 23:51:47 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:47 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:47 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:47 --> URI Class Initialized
INFO - 2021-08-26 23:51:47 --> Router Class Initialized
INFO - 2021-08-26 23:51:47 --> Output Class Initialized
INFO - 2021-08-26 23:51:47 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:47 --> Input Class Initialized
INFO - 2021-08-26 23:51:47 --> Language Class Initialized
ERROR - 2021-08-26 23:51:47 --> 404 Page Not Found: Admin/admin_login.php
ERROR - 2021-08-26 23:51:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:48 --> Config Class Initialized
INFO - 2021-08-26 23:51:48 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:48 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:48 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:48 --> URI Class Initialized
INFO - 2021-08-26 23:51:48 --> Router Class Initialized
INFO - 2021-08-26 23:51:48 --> Output Class Initialized
INFO - 2021-08-26 23:51:48 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:48 --> Input Class Initialized
INFO - 2021-08-26 23:51:48 --> Language Class Initialized
ERROR - 2021-08-26 23:51:48 --> 404 Page Not Found: Data/images
ERROR - 2021-08-26 23:51:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:48 --> Config Class Initialized
INFO - 2021-08-26 23:51:48 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:48 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:48 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:48 --> URI Class Initialized
INFO - 2021-08-26 23:51:48 --> Router Class Initialized
INFO - 2021-08-26 23:51:48 --> Output Class Initialized
INFO - 2021-08-26 23:51:48 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:48 --> Input Class Initialized
INFO - 2021-08-26 23:51:48 --> Language Class Initialized
ERROR - 2021-08-26 23:51:48 --> 404 Page Not Found: Static/images
ERROR - 2021-08-26 23:51:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:49 --> Config Class Initialized
INFO - 2021-08-26 23:51:49 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:49 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:49 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:49 --> URI Class Initialized
INFO - 2021-08-26 23:51:49 --> Router Class Initialized
INFO - 2021-08-26 23:51:49 --> Output Class Initialized
INFO - 2021-08-26 23:51:49 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:49 --> Input Class Initialized
INFO - 2021-08-26 23:51:49 --> Language Class Initialized
ERROR - 2021-08-26 23:51:49 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2021-08-26 23:51:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:49 --> Config Class Initialized
INFO - 2021-08-26 23:51:49 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:49 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:49 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:49 --> URI Class Initialized
INFO - 2021-08-26 23:51:49 --> Router Class Initialized
INFO - 2021-08-26 23:51:49 --> Output Class Initialized
INFO - 2021-08-26 23:51:49 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:49 --> Input Class Initialized
INFO - 2021-08-26 23:51:49 --> Language Class Initialized
ERROR - 2021-08-26 23:51:49 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-08-26 23:51:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:51 --> Config Class Initialized
INFO - 2021-08-26 23:51:51 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:51 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:51 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:51 --> URI Class Initialized
INFO - 2021-08-26 23:51:51 --> Router Class Initialized
INFO - 2021-08-26 23:51:51 --> Output Class Initialized
INFO - 2021-08-26 23:51:51 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:51 --> Input Class Initialized
INFO - 2021-08-26 23:51:51 --> Language Class Initialized
ERROR - 2021-08-26 23:51:51 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-26 23:51:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:51 --> Config Class Initialized
INFO - 2021-08-26 23:51:51 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:51 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:51 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:51 --> URI Class Initialized
INFO - 2021-08-26 23:51:51 --> Router Class Initialized
INFO - 2021-08-26 23:51:51 --> Output Class Initialized
INFO - 2021-08-26 23:51:51 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:51 --> Input Class Initialized
INFO - 2021-08-26 23:51:51 --> Language Class Initialized
ERROR - 2021-08-26 23:51:51 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-08-26 23:51:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:52 --> Config Class Initialized
INFO - 2021-08-26 23:51:52 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:52 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:52 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:52 --> URI Class Initialized
INFO - 2021-08-26 23:51:52 --> Router Class Initialized
INFO - 2021-08-26 23:51:52 --> Output Class Initialized
INFO - 2021-08-26 23:51:52 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:52 --> Input Class Initialized
INFO - 2021-08-26 23:51:52 --> Language Class Initialized
ERROR - 2021-08-26 23:51:52 --> 404 Page Not Found: Logo/logo_jw.png
ERROR - 2021-08-26 23:51:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:52 --> Config Class Initialized
INFO - 2021-08-26 23:51:52 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:52 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:52 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:52 --> URI Class Initialized
INFO - 2021-08-26 23:51:52 --> Router Class Initialized
INFO - 2021-08-26 23:51:52 --> Output Class Initialized
INFO - 2021-08-26 23:51:52 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:52 --> Input Class Initialized
INFO - 2021-08-26 23:51:52 --> Language Class Initialized
ERROR - 2021-08-26 23:51:52 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-08-26 23:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:53 --> Config Class Initialized
INFO - 2021-08-26 23:51:53 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:53 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:53 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:53 --> URI Class Initialized
INFO - 2021-08-26 23:51:53 --> Router Class Initialized
INFO - 2021-08-26 23:51:53 --> Output Class Initialized
INFO - 2021-08-26 23:51:53 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:53 --> Input Class Initialized
INFO - 2021-08-26 23:51:53 --> Language Class Initialized
ERROR - 2021-08-26 23:51:53 --> 404 Page Not Found: Was5/web
ERROR - 2021-08-26 23:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:53 --> Config Class Initialized
INFO - 2021-08-26 23:51:53 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:53 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:53 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:53 --> URI Class Initialized
INFO - 2021-08-26 23:51:53 --> Router Class Initialized
INFO - 2021-08-26 23:51:53 --> Output Class Initialized
INFO - 2021-08-26 23:51:53 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:53 --> Input Class Initialized
INFO - 2021-08-26 23:51:53 --> Language Class Initialized
ERROR - 2021-08-26 23:51:53 --> 404 Page Not Found: Was/main.html
ERROR - 2021-08-26 23:51:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:54 --> Config Class Initialized
INFO - 2021-08-26 23:51:54 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:54 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:54 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:54 --> URI Class Initialized
INFO - 2021-08-26 23:51:54 --> Router Class Initialized
INFO - 2021-08-26 23:51:54 --> Output Class Initialized
INFO - 2021-08-26 23:51:54 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:54 --> Input Class Initialized
INFO - 2021-08-26 23:51:54 --> Language Class Initialized
ERROR - 2021-08-26 23:51:54 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-26 23:51:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:54 --> Config Class Initialized
INFO - 2021-08-26 23:51:54 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:54 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:54 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:54 --> URI Class Initialized
INFO - 2021-08-26 23:51:54 --> Router Class Initialized
INFO - 2021-08-26 23:51:54 --> Output Class Initialized
INFO - 2021-08-26 23:51:54 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:54 --> Input Class Initialized
INFO - 2021-08-26 23:51:54 --> Language Class Initialized
ERROR - 2021-08-26 23:51:54 --> 404 Page Not Found: Weblog/index
ERROR - 2021-08-26 23:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:55 --> Config Class Initialized
INFO - 2021-08-26 23:51:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:55 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:55 --> URI Class Initialized
INFO - 2021-08-26 23:51:55 --> Router Class Initialized
INFO - 2021-08-26 23:51:55 --> Output Class Initialized
INFO - 2021-08-26 23:51:55 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:55 --> Input Class Initialized
INFO - 2021-08-26 23:51:55 --> Language Class Initialized
ERROR - 2021-08-26 23:51:55 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-26 23:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:55 --> Config Class Initialized
INFO - 2021-08-26 23:51:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:55 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:55 --> URI Class Initialized
INFO - 2021-08-26 23:51:55 --> Router Class Initialized
INFO - 2021-08-26 23:51:55 --> Output Class Initialized
INFO - 2021-08-26 23:51:55 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:55 --> Input Class Initialized
INFO - 2021-08-26 23:51:55 --> Language Class Initialized
ERROR - 2021-08-26 23:51:55 --> 404 Page Not Found: Forum/index
ERROR - 2021-08-26 23:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:55 --> Config Class Initialized
INFO - 2021-08-26 23:51:55 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:55 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:55 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:55 --> URI Class Initialized
INFO - 2021-08-26 23:51:55 --> Router Class Initialized
INFO - 2021-08-26 23:51:55 --> Output Class Initialized
INFO - 2021-08-26 23:51:55 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:55 --> Input Class Initialized
INFO - 2021-08-26 23:51:55 --> Language Class Initialized
ERROR - 2021-08-26 23:51:55 --> 404 Page Not Found: Bbs/index
ERROR - 2021-08-26 23:51:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:56 --> Config Class Initialized
INFO - 2021-08-26 23:51:56 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:56 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:56 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:56 --> URI Class Initialized
INFO - 2021-08-26 23:51:56 --> Router Class Initialized
INFO - 2021-08-26 23:51:56 --> Output Class Initialized
INFO - 2021-08-26 23:51:56 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:56 --> Input Class Initialized
INFO - 2021-08-26 23:51:56 --> Language Class Initialized
ERROR - 2021-08-26 23:51:56 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-26 23:51:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-26 23:51:56 --> Config Class Initialized
INFO - 2021-08-26 23:51:56 --> Hooks Class Initialized
DEBUG - 2021-08-26 23:51:56 --> UTF-8 Support Enabled
INFO - 2021-08-26 23:51:56 --> Utf8 Class Initialized
INFO - 2021-08-26 23:51:56 --> URI Class Initialized
INFO - 2021-08-26 23:51:56 --> Router Class Initialized
INFO - 2021-08-26 23:51:56 --> Output Class Initialized
INFO - 2021-08-26 23:51:56 --> Security Class Initialized
DEBUG - 2021-08-26 23:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-26 23:51:56 --> Input Class Initialized
INFO - 2021-08-26 23:51:56 --> Language Class Initialized
ERROR - 2021-08-26 23:51:56 --> 404 Page Not Found: Admin/editor
