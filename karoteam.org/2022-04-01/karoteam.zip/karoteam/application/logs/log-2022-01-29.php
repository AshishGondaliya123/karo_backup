<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-29 10:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 10:08:46 --> Config Class Initialized
INFO - 2022-01-29 10:08:46 --> Hooks Class Initialized
DEBUG - 2022-01-29 10:08:46 --> UTF-8 Support Enabled
INFO - 2022-01-29 10:08:46 --> Utf8 Class Initialized
INFO - 2022-01-29 10:08:46 --> URI Class Initialized
DEBUG - 2022-01-29 10:08:46 --> No URI present. Default controller set.
INFO - 2022-01-29 10:08:46 --> Router Class Initialized
INFO - 2022-01-29 10:08:46 --> Output Class Initialized
INFO - 2022-01-29 10:08:46 --> Security Class Initialized
DEBUG - 2022-01-29 10:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 10:08:46 --> Input Class Initialized
INFO - 2022-01-29 10:08:46 --> Language Class Initialized
INFO - 2022-01-29 10:08:46 --> Loader Class Initialized
INFO - 2022-01-29 10:08:46 --> Helper loaded: url_helper
INFO - 2022-01-29 10:08:46 --> Helper loaded: form_helper
INFO - 2022-01-29 10:08:46 --> Helper loaded: common_helper
INFO - 2022-01-29 10:08:46 --> Database Driver Class Initialized
DEBUG - 2022-01-29 10:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 10:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 10:08:46 --> Controller Class Initialized
INFO - 2022-01-29 10:08:46 --> Form Validation Class Initialized
DEBUG - 2022-01-29 10:08:46 --> Encrypt Class Initialized
DEBUG - 2022-01-29 10:08:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 10:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 10:08:46 --> Email Class Initialized
INFO - 2022-01-29 10:08:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 10:08:46 --> Calendar Class Initialized
INFO - 2022-01-29 10:08:46 --> Model "Login_model" initialized
INFO - 2022-01-29 10:08:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 10:08:46 --> Final output sent to browser
DEBUG - 2022-01-29 10:08:46 --> Total execution time: 0.0234
ERROR - 2022-01-29 11:43:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 11:43:12 --> Config Class Initialized
INFO - 2022-01-29 11:43:12 --> Hooks Class Initialized
DEBUG - 2022-01-29 11:43:12 --> UTF-8 Support Enabled
INFO - 2022-01-29 11:43:12 --> Utf8 Class Initialized
INFO - 2022-01-29 11:43:12 --> URI Class Initialized
DEBUG - 2022-01-29 11:43:12 --> No URI present. Default controller set.
INFO - 2022-01-29 11:43:12 --> Router Class Initialized
INFO - 2022-01-29 11:43:12 --> Output Class Initialized
INFO - 2022-01-29 11:43:12 --> Security Class Initialized
DEBUG - 2022-01-29 11:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 11:43:12 --> Input Class Initialized
INFO - 2022-01-29 11:43:12 --> Language Class Initialized
INFO - 2022-01-29 11:43:12 --> Loader Class Initialized
INFO - 2022-01-29 11:43:12 --> Helper loaded: url_helper
INFO - 2022-01-29 11:43:12 --> Helper loaded: form_helper
INFO - 2022-01-29 11:43:12 --> Helper loaded: common_helper
INFO - 2022-01-29 11:43:13 --> Database Driver Class Initialized
DEBUG - 2022-01-29 11:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 11:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 11:43:13 --> Controller Class Initialized
INFO - 2022-01-29 11:43:13 --> Form Validation Class Initialized
DEBUG - 2022-01-29 11:43:13 --> Encrypt Class Initialized
DEBUG - 2022-01-29 11:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 11:43:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 11:43:13 --> Email Class Initialized
INFO - 2022-01-29 11:43:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 11:43:13 --> Calendar Class Initialized
INFO - 2022-01-29 11:43:13 --> Model "Login_model" initialized
INFO - 2022-01-29 11:43:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 11:43:13 --> Final output sent to browser
DEBUG - 2022-01-29 11:43:13 --> Total execution time: 0.0290
ERROR - 2022-01-29 11:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 11:48:08 --> Config Class Initialized
INFO - 2022-01-29 11:48:08 --> Hooks Class Initialized
DEBUG - 2022-01-29 11:48:08 --> UTF-8 Support Enabled
INFO - 2022-01-29 11:48:08 --> Utf8 Class Initialized
INFO - 2022-01-29 11:48:08 --> URI Class Initialized
DEBUG - 2022-01-29 11:48:08 --> No URI present. Default controller set.
INFO - 2022-01-29 11:48:08 --> Router Class Initialized
INFO - 2022-01-29 11:48:08 --> Output Class Initialized
INFO - 2022-01-29 11:48:08 --> Security Class Initialized
DEBUG - 2022-01-29 11:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 11:48:08 --> Input Class Initialized
INFO - 2022-01-29 11:48:08 --> Language Class Initialized
INFO - 2022-01-29 11:48:08 --> Loader Class Initialized
INFO - 2022-01-29 11:48:08 --> Helper loaded: url_helper
INFO - 2022-01-29 11:48:08 --> Helper loaded: form_helper
INFO - 2022-01-29 11:48:08 --> Helper loaded: common_helper
INFO - 2022-01-29 11:48:08 --> Database Driver Class Initialized
DEBUG - 2022-01-29 11:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 11:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 11:48:08 --> Controller Class Initialized
INFO - 2022-01-29 11:48:08 --> Form Validation Class Initialized
DEBUG - 2022-01-29 11:48:08 --> Encrypt Class Initialized
DEBUG - 2022-01-29 11:48:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 11:48:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 11:48:08 --> Email Class Initialized
INFO - 2022-01-29 11:48:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 11:48:08 --> Calendar Class Initialized
INFO - 2022-01-29 11:48:08 --> Model "Login_model" initialized
INFO - 2022-01-29 11:48:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 11:48:08 --> Final output sent to browser
DEBUG - 2022-01-29 11:48:08 --> Total execution time: 0.0222
ERROR - 2022-01-29 14:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 14:20:30 --> Config Class Initialized
INFO - 2022-01-29 14:20:30 --> Hooks Class Initialized
DEBUG - 2022-01-29 14:20:30 --> UTF-8 Support Enabled
INFO - 2022-01-29 14:20:30 --> Utf8 Class Initialized
INFO - 2022-01-29 14:20:30 --> URI Class Initialized
DEBUG - 2022-01-29 14:20:30 --> No URI present. Default controller set.
INFO - 2022-01-29 14:20:30 --> Router Class Initialized
INFO - 2022-01-29 14:20:30 --> Output Class Initialized
INFO - 2022-01-29 14:20:30 --> Security Class Initialized
DEBUG - 2022-01-29 14:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 14:20:30 --> Input Class Initialized
INFO - 2022-01-29 14:20:30 --> Language Class Initialized
INFO - 2022-01-29 14:20:30 --> Loader Class Initialized
INFO - 2022-01-29 14:20:30 --> Helper loaded: url_helper
INFO - 2022-01-29 14:20:30 --> Helper loaded: form_helper
INFO - 2022-01-29 14:20:30 --> Helper loaded: common_helper
INFO - 2022-01-29 14:20:30 --> Database Driver Class Initialized
DEBUG - 2022-01-29 14:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 14:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 14:20:30 --> Controller Class Initialized
INFO - 2022-01-29 14:20:30 --> Form Validation Class Initialized
DEBUG - 2022-01-29 14:20:30 --> Encrypt Class Initialized
DEBUG - 2022-01-29 14:20:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 14:20:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 14:20:30 --> Email Class Initialized
INFO - 2022-01-29 14:20:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 14:20:30 --> Calendar Class Initialized
INFO - 2022-01-29 14:20:30 --> Model "Login_model" initialized
INFO - 2022-01-29 14:20:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 14:20:30 --> Final output sent to browser
DEBUG - 2022-01-29 14:20:30 --> Total execution time: 0.0259
ERROR - 2022-01-29 14:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 14:20:30 --> Config Class Initialized
INFO - 2022-01-29 14:20:30 --> Hooks Class Initialized
DEBUG - 2022-01-29 14:20:30 --> UTF-8 Support Enabled
INFO - 2022-01-29 14:20:30 --> Utf8 Class Initialized
INFO - 2022-01-29 14:20:30 --> URI Class Initialized
INFO - 2022-01-29 14:20:30 --> Router Class Initialized
INFO - 2022-01-29 14:20:30 --> Output Class Initialized
INFO - 2022-01-29 14:20:30 --> Security Class Initialized
DEBUG - 2022-01-29 14:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 14:20:30 --> Input Class Initialized
INFO - 2022-01-29 14:20:30 --> Language Class Initialized
ERROR - 2022-01-29 14:20:30 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-29 14:20:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 14:20:39 --> Config Class Initialized
INFO - 2022-01-29 14:20:39 --> Hooks Class Initialized
DEBUG - 2022-01-29 14:20:39 --> UTF-8 Support Enabled
INFO - 2022-01-29 14:20:39 --> Utf8 Class Initialized
INFO - 2022-01-29 14:20:39 --> URI Class Initialized
INFO - 2022-01-29 14:20:39 --> Router Class Initialized
INFO - 2022-01-29 14:20:39 --> Output Class Initialized
INFO - 2022-01-29 14:20:39 --> Security Class Initialized
DEBUG - 2022-01-29 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 14:20:39 --> Input Class Initialized
INFO - 2022-01-29 14:20:39 --> Language Class Initialized
INFO - 2022-01-29 14:20:39 --> Loader Class Initialized
INFO - 2022-01-29 14:20:39 --> Helper loaded: url_helper
INFO - 2022-01-29 14:20:39 --> Helper loaded: form_helper
INFO - 2022-01-29 14:20:39 --> Helper loaded: common_helper
INFO - 2022-01-29 14:20:39 --> Database Driver Class Initialized
DEBUG - 2022-01-29 14:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 14:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 14:20:39 --> Controller Class Initialized
INFO - 2022-01-29 14:20:39 --> Form Validation Class Initialized
DEBUG - 2022-01-29 14:20:39 --> Encrypt Class Initialized
DEBUG - 2022-01-29 14:20:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 14:20:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 14:20:39 --> Email Class Initialized
INFO - 2022-01-29 14:20:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 14:20:39 --> Calendar Class Initialized
INFO - 2022-01-29 14:20:39 --> Model "Login_model" initialized
ERROR - 2022-01-29 14:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 14:20:40 --> Config Class Initialized
INFO - 2022-01-29 14:20:40 --> Hooks Class Initialized
DEBUG - 2022-01-29 14:20:40 --> UTF-8 Support Enabled
INFO - 2022-01-29 14:20:40 --> Utf8 Class Initialized
INFO - 2022-01-29 14:20:40 --> URI Class Initialized
INFO - 2022-01-29 14:20:40 --> Router Class Initialized
INFO - 2022-01-29 14:20:40 --> Output Class Initialized
INFO - 2022-01-29 14:20:40 --> Security Class Initialized
DEBUG - 2022-01-29 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 14:20:40 --> Input Class Initialized
INFO - 2022-01-29 14:20:40 --> Language Class Initialized
INFO - 2022-01-29 14:20:40 --> Loader Class Initialized
INFO - 2022-01-29 14:20:40 --> Helper loaded: url_helper
INFO - 2022-01-29 14:20:40 --> Helper loaded: form_helper
INFO - 2022-01-29 14:20:40 --> Helper loaded: common_helper
INFO - 2022-01-29 14:20:40 --> Database Driver Class Initialized
DEBUG - 2022-01-29 14:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 14:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 14:20:40 --> Controller Class Initialized
INFO - 2022-01-29 14:20:40 --> Form Validation Class Initialized
DEBUG - 2022-01-29 14:20:40 --> Encrypt Class Initialized
DEBUG - 2022-01-29 14:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 14:20:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 14:20:40 --> Email Class Initialized
INFO - 2022-01-29 14:20:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 14:20:40 --> Calendar Class Initialized
INFO - 2022-01-29 14:20:40 --> Model "Login_model" initialized
ERROR - 2022-01-29 14:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 14:20:41 --> Config Class Initialized
INFO - 2022-01-29 14:20:41 --> Hooks Class Initialized
DEBUG - 2022-01-29 14:20:41 --> UTF-8 Support Enabled
INFO - 2022-01-29 14:20:41 --> Utf8 Class Initialized
INFO - 2022-01-29 14:20:41 --> URI Class Initialized
INFO - 2022-01-29 14:20:41 --> Router Class Initialized
INFO - 2022-01-29 14:20:41 --> Output Class Initialized
INFO - 2022-01-29 14:20:41 --> Security Class Initialized
DEBUG - 2022-01-29 14:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 14:20:41 --> Input Class Initialized
INFO - 2022-01-29 14:20:41 --> Language Class Initialized
INFO - 2022-01-29 14:20:41 --> Loader Class Initialized
INFO - 2022-01-29 14:20:41 --> Helper loaded: url_helper
INFO - 2022-01-29 14:20:41 --> Helper loaded: form_helper
INFO - 2022-01-29 14:20:41 --> Helper loaded: common_helper
INFO - 2022-01-29 14:20:41 --> Database Driver Class Initialized
DEBUG - 2022-01-29 14:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 14:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 14:20:41 --> Controller Class Initialized
INFO - 2022-01-29 14:20:41 --> Form Validation Class Initialized
DEBUG - 2022-01-29 14:20:41 --> Encrypt Class Initialized
DEBUG - 2022-01-29 14:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 14:20:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 14:20:41 --> Email Class Initialized
INFO - 2022-01-29 14:20:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 14:20:41 --> Calendar Class Initialized
INFO - 2022-01-29 14:20:41 --> Model "Login_model" initialized
INFO - 2022-01-29 14:20:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 14:20:41 --> Final output sent to browser
DEBUG - 2022-01-29 14:20:41 --> Total execution time: 0.0327
ERROR - 2022-01-29 14:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 14:20:42 --> Config Class Initialized
INFO - 2022-01-29 14:20:42 --> Hooks Class Initialized
DEBUG - 2022-01-29 14:20:42 --> UTF-8 Support Enabled
INFO - 2022-01-29 14:20:42 --> Utf8 Class Initialized
INFO - 2022-01-29 14:20:42 --> URI Class Initialized
DEBUG - 2022-01-29 14:20:42 --> No URI present. Default controller set.
INFO - 2022-01-29 14:20:42 --> Router Class Initialized
INFO - 2022-01-29 14:20:42 --> Output Class Initialized
INFO - 2022-01-29 14:20:42 --> Security Class Initialized
DEBUG - 2022-01-29 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 14:20:42 --> Input Class Initialized
INFO - 2022-01-29 14:20:42 --> Language Class Initialized
INFO - 2022-01-29 14:20:42 --> Loader Class Initialized
INFO - 2022-01-29 14:20:42 --> Helper loaded: url_helper
INFO - 2022-01-29 14:20:42 --> Helper loaded: form_helper
INFO - 2022-01-29 14:20:42 --> Helper loaded: common_helper
INFO - 2022-01-29 14:20:42 --> Database Driver Class Initialized
DEBUG - 2022-01-29 14:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 14:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 14:20:42 --> Controller Class Initialized
INFO - 2022-01-29 14:20:42 --> Form Validation Class Initialized
DEBUG - 2022-01-29 14:20:42 --> Encrypt Class Initialized
DEBUG - 2022-01-29 14:20:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 14:20:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 14:20:42 --> Email Class Initialized
INFO - 2022-01-29 14:20:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 14:20:42 --> Calendar Class Initialized
INFO - 2022-01-29 14:20:42 --> Model "Login_model" initialized
INFO - 2022-01-29 14:20:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 14:20:42 --> Final output sent to browser
DEBUG - 2022-01-29 14:20:42 --> Total execution time: 0.0255
ERROR - 2022-01-29 19:30:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 19:30:08 --> Config Class Initialized
INFO - 2022-01-29 19:30:08 --> Hooks Class Initialized
DEBUG - 2022-01-29 19:30:08 --> UTF-8 Support Enabled
INFO - 2022-01-29 19:30:08 --> Utf8 Class Initialized
INFO - 2022-01-29 19:30:08 --> URI Class Initialized
INFO - 2022-01-29 19:30:08 --> Router Class Initialized
INFO - 2022-01-29 19:30:08 --> Output Class Initialized
INFO - 2022-01-29 19:30:08 --> Security Class Initialized
DEBUG - 2022-01-29 19:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 19:30:08 --> Input Class Initialized
INFO - 2022-01-29 19:30:08 --> Language Class Initialized
ERROR - 2022-01-29 19:30:08 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-01-29 19:30:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 19:30:08 --> Config Class Initialized
INFO - 2022-01-29 19:30:08 --> Hooks Class Initialized
DEBUG - 2022-01-29 19:30:08 --> UTF-8 Support Enabled
INFO - 2022-01-29 19:30:09 --> Utf8 Class Initialized
INFO - 2022-01-29 19:30:09 --> URI Class Initialized
INFO - 2022-01-29 19:30:09 --> Router Class Initialized
INFO - 2022-01-29 19:30:09 --> Output Class Initialized
INFO - 2022-01-29 19:30:09 --> Security Class Initialized
DEBUG - 2022-01-29 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 19:30:09 --> Input Class Initialized
INFO - 2022-01-29 19:30:09 --> Language Class Initialized
ERROR - 2022-01-29 19:30:09 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-01-29 19:30:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 19:30:09 --> Config Class Initialized
INFO - 2022-01-29 19:30:09 --> Hooks Class Initialized
DEBUG - 2022-01-29 19:30:09 --> UTF-8 Support Enabled
INFO - 2022-01-29 19:30:09 --> Utf8 Class Initialized
INFO - 2022-01-29 19:30:09 --> URI Class Initialized
DEBUG - 2022-01-29 19:30:09 --> No URI present. Default controller set.
INFO - 2022-01-29 19:30:09 --> Router Class Initialized
INFO - 2022-01-29 19:30:09 --> Output Class Initialized
INFO - 2022-01-29 19:30:09 --> Security Class Initialized
DEBUG - 2022-01-29 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 19:30:09 --> Input Class Initialized
INFO - 2022-01-29 19:30:09 --> Language Class Initialized
INFO - 2022-01-29 19:30:09 --> Loader Class Initialized
INFO - 2022-01-29 19:30:09 --> Helper loaded: url_helper
INFO - 2022-01-29 19:30:09 --> Helper loaded: form_helper
INFO - 2022-01-29 19:30:09 --> Helper loaded: common_helper
INFO - 2022-01-29 19:30:09 --> Database Driver Class Initialized
DEBUG - 2022-01-29 19:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 19:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 19:30:10 --> Controller Class Initialized
INFO - 2022-01-29 19:30:10 --> Form Validation Class Initialized
DEBUG - 2022-01-29 19:30:10 --> Encrypt Class Initialized
DEBUG - 2022-01-29 19:30:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 19:30:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 19:30:10 --> Email Class Initialized
INFO - 2022-01-29 19:30:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 19:30:10 --> Calendar Class Initialized
INFO - 2022-01-29 19:30:10 --> Model "Login_model" initialized
INFO - 2022-01-29 19:30:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 19:30:10 --> Final output sent to browser
DEBUG - 2022-01-29 19:30:10 --> Total execution time: 0.0258
ERROR - 2022-01-29 19:33:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 19:33:07 --> Config Class Initialized
INFO - 2022-01-29 19:33:07 --> Hooks Class Initialized
DEBUG - 2022-01-29 19:33:07 --> UTF-8 Support Enabled
INFO - 2022-01-29 19:33:07 --> Utf8 Class Initialized
INFO - 2022-01-29 19:33:07 --> URI Class Initialized
DEBUG - 2022-01-29 19:33:07 --> No URI present. Default controller set.
INFO - 2022-01-29 19:33:07 --> Router Class Initialized
INFO - 2022-01-29 19:33:07 --> Output Class Initialized
INFO - 2022-01-29 19:33:07 --> Security Class Initialized
DEBUG - 2022-01-29 19:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 19:33:07 --> Input Class Initialized
INFO - 2022-01-29 19:33:07 --> Language Class Initialized
INFO - 2022-01-29 19:33:07 --> Loader Class Initialized
INFO - 2022-01-29 19:33:07 --> Helper loaded: url_helper
INFO - 2022-01-29 19:33:07 --> Helper loaded: form_helper
INFO - 2022-01-29 19:33:07 --> Helper loaded: common_helper
INFO - 2022-01-29 19:33:07 --> Database Driver Class Initialized
DEBUG - 2022-01-29 19:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 19:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 19:33:07 --> Controller Class Initialized
INFO - 2022-01-29 19:33:07 --> Form Validation Class Initialized
DEBUG - 2022-01-29 19:33:07 --> Encrypt Class Initialized
DEBUG - 2022-01-29 19:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 19:33:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 19:33:07 --> Email Class Initialized
INFO - 2022-01-29 19:33:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 19:33:07 --> Calendar Class Initialized
INFO - 2022-01-29 19:33:07 --> Model "Login_model" initialized
INFO - 2022-01-29 19:33:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 19:33:07 --> Final output sent to browser
DEBUG - 2022-01-29 19:33:07 --> Total execution time: 0.0203
ERROR - 2022-01-29 19:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 19:38:27 --> Config Class Initialized
INFO - 2022-01-29 19:38:27 --> Hooks Class Initialized
DEBUG - 2022-01-29 19:38:27 --> UTF-8 Support Enabled
INFO - 2022-01-29 19:38:27 --> Utf8 Class Initialized
INFO - 2022-01-29 19:38:27 --> URI Class Initialized
DEBUG - 2022-01-29 19:38:27 --> No URI present. Default controller set.
INFO - 2022-01-29 19:38:27 --> Router Class Initialized
INFO - 2022-01-29 19:38:27 --> Output Class Initialized
INFO - 2022-01-29 19:38:27 --> Security Class Initialized
DEBUG - 2022-01-29 19:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 19:38:27 --> Input Class Initialized
INFO - 2022-01-29 19:38:27 --> Language Class Initialized
INFO - 2022-01-29 19:38:27 --> Loader Class Initialized
INFO - 2022-01-29 19:38:27 --> Helper loaded: url_helper
INFO - 2022-01-29 19:38:27 --> Helper loaded: form_helper
INFO - 2022-01-29 19:38:27 --> Helper loaded: common_helper
INFO - 2022-01-29 19:38:27 --> Database Driver Class Initialized
DEBUG - 2022-01-29 19:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 19:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 19:38:27 --> Controller Class Initialized
INFO - 2022-01-29 19:38:27 --> Form Validation Class Initialized
DEBUG - 2022-01-29 19:38:27 --> Encrypt Class Initialized
DEBUG - 2022-01-29 19:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 19:38:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 19:38:27 --> Email Class Initialized
INFO - 2022-01-29 19:38:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 19:38:27 --> Calendar Class Initialized
INFO - 2022-01-29 19:38:27 --> Model "Login_model" initialized
INFO - 2022-01-29 19:38:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 19:38:27 --> Final output sent to browser
DEBUG - 2022-01-29 19:38:27 --> Total execution time: 0.0245
ERROR - 2022-01-29 21:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 21:42:53 --> Config Class Initialized
INFO - 2022-01-29 21:42:53 --> Hooks Class Initialized
DEBUG - 2022-01-29 21:42:53 --> UTF-8 Support Enabled
INFO - 2022-01-29 21:42:53 --> Utf8 Class Initialized
INFO - 2022-01-29 21:42:53 --> URI Class Initialized
DEBUG - 2022-01-29 21:42:53 --> No URI present. Default controller set.
INFO - 2022-01-29 21:42:53 --> Router Class Initialized
INFO - 2022-01-29 21:42:53 --> Output Class Initialized
INFO - 2022-01-29 21:42:53 --> Security Class Initialized
DEBUG - 2022-01-29 21:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 21:42:53 --> Input Class Initialized
INFO - 2022-01-29 21:42:53 --> Language Class Initialized
INFO - 2022-01-29 21:42:53 --> Loader Class Initialized
INFO - 2022-01-29 21:42:53 --> Helper loaded: url_helper
INFO - 2022-01-29 21:42:53 --> Helper loaded: form_helper
INFO - 2022-01-29 21:42:53 --> Helper loaded: common_helper
INFO - 2022-01-29 21:42:53 --> Database Driver Class Initialized
DEBUG - 2022-01-29 21:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 21:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 21:42:53 --> Controller Class Initialized
INFO - 2022-01-29 21:42:53 --> Form Validation Class Initialized
DEBUG - 2022-01-29 21:42:53 --> Encrypt Class Initialized
DEBUG - 2022-01-29 21:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 21:42:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 21:42:53 --> Email Class Initialized
INFO - 2022-01-29 21:42:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 21:42:53 --> Calendar Class Initialized
INFO - 2022-01-29 21:42:53 --> Model "Login_model" initialized
INFO - 2022-01-29 21:42:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 21:42:53 --> Final output sent to browser
DEBUG - 2022-01-29 21:42:53 --> Total execution time: 0.1451
ERROR - 2022-01-29 21:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-29 21:42:53 --> Config Class Initialized
INFO - 2022-01-29 21:42:53 --> Hooks Class Initialized
DEBUG - 2022-01-29 21:42:53 --> UTF-8 Support Enabled
INFO - 2022-01-29 21:42:53 --> Utf8 Class Initialized
INFO - 2022-01-29 21:42:53 --> URI Class Initialized
DEBUG - 2022-01-29 21:42:53 --> No URI present. Default controller set.
INFO - 2022-01-29 21:42:53 --> Router Class Initialized
INFO - 2022-01-29 21:42:53 --> Output Class Initialized
INFO - 2022-01-29 21:42:53 --> Security Class Initialized
DEBUG - 2022-01-29 21:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-29 21:42:53 --> Input Class Initialized
INFO - 2022-01-29 21:42:53 --> Language Class Initialized
INFO - 2022-01-29 21:42:53 --> Loader Class Initialized
INFO - 2022-01-29 21:42:53 --> Helper loaded: url_helper
INFO - 2022-01-29 21:42:53 --> Helper loaded: form_helper
INFO - 2022-01-29 21:42:53 --> Helper loaded: common_helper
INFO - 2022-01-29 21:42:53 --> Database Driver Class Initialized
DEBUG - 2022-01-29 21:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-29 21:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-29 21:42:54 --> Controller Class Initialized
INFO - 2022-01-29 21:42:54 --> Form Validation Class Initialized
DEBUG - 2022-01-29 21:42:54 --> Encrypt Class Initialized
DEBUG - 2022-01-29 21:42:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-29 21:42:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-29 21:42:54 --> Email Class Initialized
INFO - 2022-01-29 21:42:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-29 21:42:54 --> Calendar Class Initialized
INFO - 2022-01-29 21:42:54 --> Model "Login_model" initialized
INFO - 2022-01-29 21:42:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-29 21:42:54 --> Final output sent to browser
DEBUG - 2022-01-29 21:42:54 --> Total execution time: 0.7324
