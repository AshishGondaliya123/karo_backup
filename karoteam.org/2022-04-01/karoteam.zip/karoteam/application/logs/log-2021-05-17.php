<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-17 16:34:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:34:02 --> Config Class Initialized
INFO - 2021-05-17 16:34:02 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:34:02 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:34:02 --> Utf8 Class Initialized
INFO - 2021-05-17 16:34:02 --> URI Class Initialized
DEBUG - 2021-05-17 16:34:02 --> No URI present. Default controller set.
INFO - 2021-05-17 16:34:02 --> Router Class Initialized
INFO - 2021-05-17 16:34:02 --> Output Class Initialized
INFO - 2021-05-17 16:34:02 --> Security Class Initialized
DEBUG - 2021-05-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:34:02 --> Input Class Initialized
INFO - 2021-05-17 16:34:02 --> Language Class Initialized
INFO - 2021-05-17 16:34:02 --> Loader Class Initialized
INFO - 2021-05-17 16:34:02 --> Helper loaded: url_helper
INFO - 2021-05-17 16:34:02 --> Helper loaded: form_helper
INFO - 2021-05-17 16:34:02 --> Helper loaded: common_helper
INFO - 2021-05-17 16:34:02 --> Database Driver Class Initialized
DEBUG - 2021-05-17 16:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 16:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 16:34:02 --> Controller Class Initialized
INFO - 2021-05-17 16:34:02 --> Form Validation Class Initialized
DEBUG - 2021-05-17 16:34:02 --> Encrypt Class Initialized
DEBUG - 2021-05-17 16:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-17 16:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-17 16:34:02 --> Email Class Initialized
INFO - 2021-05-17 16:34:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-17 16:34:02 --> Calendar Class Initialized
INFO - 2021-05-17 16:34:02 --> Model "Login_model" initialized
INFO - 2021-05-17 16:34:02 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-17 16:34:02 --> Final output sent to browser
DEBUG - 2021-05-17 16:34:02 --> Total execution time: 0.0968
ERROR - 2021-05-17 16:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:34:03 --> Config Class Initialized
INFO - 2021-05-17 16:34:03 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:34:03 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:34:03 --> Utf8 Class Initialized
INFO - 2021-05-17 16:34:03 --> URI Class Initialized
INFO - 2021-05-17 16:34:03 --> Router Class Initialized
INFO - 2021-05-17 16:34:03 --> Output Class Initialized
INFO - 2021-05-17 16:34:03 --> Security Class Initialized
DEBUG - 2021-05-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:34:03 --> Input Class Initialized
INFO - 2021-05-17 16:34:03 --> Language Class Initialized
ERROR - 2021-05-17 16:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-17 16:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:34:03 --> Config Class Initialized
INFO - 2021-05-17 16:34:03 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:34:03 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:34:03 --> Utf8 Class Initialized
INFO - 2021-05-17 16:34:03 --> URI Class Initialized
INFO - 2021-05-17 16:34:03 --> Router Class Initialized
INFO - 2021-05-17 16:34:03 --> Output Class Initialized
INFO - 2021-05-17 16:34:03 --> Security Class Initialized
DEBUG - 2021-05-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:34:03 --> Input Class Initialized
INFO - 2021-05-17 16:34:03 --> Language Class Initialized
ERROR - 2021-05-17 16:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-17 16:34:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:34:04 --> Config Class Initialized
INFO - 2021-05-17 16:34:04 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:34:04 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:34:04 --> Utf8 Class Initialized
INFO - 2021-05-17 16:34:04 --> URI Class Initialized
INFO - 2021-05-17 16:34:04 --> Router Class Initialized
INFO - 2021-05-17 16:34:04 --> Output Class Initialized
INFO - 2021-05-17 16:34:04 --> Security Class Initialized
DEBUG - 2021-05-17 16:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:34:04 --> Input Class Initialized
INFO - 2021-05-17 16:34:04 --> Language Class Initialized
ERROR - 2021-05-17 16:34:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-17 16:34:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:34:31 --> Config Class Initialized
INFO - 2021-05-17 16:34:31 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:34:31 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:34:31 --> Utf8 Class Initialized
INFO - 2021-05-17 16:34:31 --> URI Class Initialized
INFO - 2021-05-17 16:34:31 --> Router Class Initialized
INFO - 2021-05-17 16:34:31 --> Output Class Initialized
INFO - 2021-05-17 16:34:31 --> Security Class Initialized
DEBUG - 2021-05-17 16:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:34:31 --> Input Class Initialized
INFO - 2021-05-17 16:34:31 --> Language Class Initialized
INFO - 2021-05-17 16:34:31 --> Loader Class Initialized
INFO - 2021-05-17 16:34:31 --> Helper loaded: url_helper
INFO - 2021-05-17 16:34:31 --> Helper loaded: form_helper
INFO - 2021-05-17 16:34:31 --> Helper loaded: common_helper
INFO - 2021-05-17 16:34:31 --> Database Driver Class Initialized
DEBUG - 2021-05-17 16:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 16:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 16:34:31 --> Controller Class Initialized
INFO - 2021-05-17 16:34:31 --> Form Validation Class Initialized
DEBUG - 2021-05-17 16:34:31 --> Encrypt Class Initialized
DEBUG - 2021-05-17 16:34:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-17 16:34:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-17 16:34:31 --> Email Class Initialized
INFO - 2021-05-17 16:34:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-17 16:34:31 --> Calendar Class Initialized
INFO - 2021-05-17 16:34:31 --> Model "Login_model" initialized
INFO - 2021-05-17 16:34:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-05-17 16:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:34:32 --> Config Class Initialized
INFO - 2021-05-17 16:34:32 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:34:32 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:34:32 --> Utf8 Class Initialized
INFO - 2021-05-17 16:34:32 --> URI Class Initialized
INFO - 2021-05-17 16:34:32 --> Router Class Initialized
INFO - 2021-05-17 16:34:32 --> Output Class Initialized
INFO - 2021-05-17 16:34:32 --> Security Class Initialized
DEBUG - 2021-05-17 16:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:34:32 --> Input Class Initialized
INFO - 2021-05-17 16:34:32 --> Language Class Initialized
INFO - 2021-05-17 16:34:32 --> Loader Class Initialized
INFO - 2021-05-17 16:34:32 --> Helper loaded: url_helper
INFO - 2021-05-17 16:34:32 --> Helper loaded: form_helper
INFO - 2021-05-17 16:34:32 --> Helper loaded: common_helper
INFO - 2021-05-17 16:34:32 --> Database Driver Class Initialized
DEBUG - 2021-05-17 16:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 16:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 16:34:32 --> Controller Class Initialized
INFO - 2021-05-17 16:34:32 --> Form Validation Class Initialized
DEBUG - 2021-05-17 16:34:32 --> Encrypt Class Initialized
INFO - 2021-05-17 16:34:32 --> Model "Login_model" initialized
INFO - 2021-05-17 16:34:32 --> Model "Dashboard_model" initialized
INFO - 2021-05-17 16:34:32 --> Model "Case_model" initialized
INFO - 2021-05-17 16:34:35 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-17 16:34:41 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-05-17 16:34:41 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-17 16:34:41 --> Final output sent to browser
DEBUG - 2021-05-17 16:34:41 --> Total execution time: 9.1193
ERROR - 2021-05-17 16:34:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:34:42 --> Config Class Initialized
INFO - 2021-05-17 16:34:42 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:34:42 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:34:42 --> Utf8 Class Initialized
INFO - 2021-05-17 16:34:42 --> URI Class Initialized
INFO - 2021-05-17 16:34:42 --> Router Class Initialized
INFO - 2021-05-17 16:34:42 --> Output Class Initialized
INFO - 2021-05-17 16:34:42 --> Security Class Initialized
DEBUG - 2021-05-17 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:34:42 --> Input Class Initialized
INFO - 2021-05-17 16:34:42 --> Language Class Initialized
ERROR - 2021-05-17 16:34:42 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-17 16:34:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:34:57 --> Config Class Initialized
INFO - 2021-05-17 16:34:57 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:34:57 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:34:57 --> Utf8 Class Initialized
INFO - 2021-05-17 16:34:57 --> URI Class Initialized
INFO - 2021-05-17 16:34:57 --> Router Class Initialized
INFO - 2021-05-17 16:34:57 --> Output Class Initialized
INFO - 2021-05-17 16:34:57 --> Security Class Initialized
DEBUG - 2021-05-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:34:57 --> Input Class Initialized
INFO - 2021-05-17 16:34:57 --> Language Class Initialized
INFO - 2021-05-17 16:34:57 --> Loader Class Initialized
INFO - 2021-05-17 16:34:57 --> Helper loaded: url_helper
INFO - 2021-05-17 16:34:57 --> Helper loaded: form_helper
INFO - 2021-05-17 16:34:57 --> Helper loaded: common_helper
INFO - 2021-05-17 16:34:57 --> Database Driver Class Initialized
DEBUG - 2021-05-17 16:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 16:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 16:34:57 --> Controller Class Initialized
INFO - 2021-05-17 16:34:57 --> Form Validation Class Initialized
DEBUG - 2021-05-17 16:34:57 --> Encrypt Class Initialized
INFO - 2021-05-17 16:34:57 --> Model "Login_model" initialized
INFO - 2021-05-17 16:34:57 --> Model "Dashboard_model" initialized
INFO - 2021-05-17 16:34:57 --> Model "Case_model" initialized
INFO - 2021-05-17 16:34:58 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-17 16:34:58 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/dashboard/birthday.php
INFO - 2021-05-17 16:34:58 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-17 16:34:58 --> Final output sent to browser
DEBUG - 2021-05-17 16:34:58 --> Total execution time: 0.0223
ERROR - 2021-05-17 16:34:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:34:59 --> Config Class Initialized
INFO - 2021-05-17 16:34:59 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:34:59 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:34:59 --> Utf8 Class Initialized
INFO - 2021-05-17 16:34:59 --> URI Class Initialized
INFO - 2021-05-17 16:34:59 --> Router Class Initialized
INFO - 2021-05-17 16:34:59 --> Output Class Initialized
INFO - 2021-05-17 16:34:59 --> Security Class Initialized
DEBUG - 2021-05-17 16:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:34:59 --> Input Class Initialized
INFO - 2021-05-17 16:34:59 --> Language Class Initialized
ERROR - 2021-05-17 16:34:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-17 16:35:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:35:42 --> Config Class Initialized
INFO - 2021-05-17 16:35:42 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:35:42 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:35:42 --> Utf8 Class Initialized
INFO - 2021-05-17 16:35:42 --> URI Class Initialized
INFO - 2021-05-17 16:35:42 --> Router Class Initialized
INFO - 2021-05-17 16:35:42 --> Output Class Initialized
INFO - 2021-05-17 16:35:42 --> Security Class Initialized
DEBUG - 2021-05-17 16:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:35:42 --> Input Class Initialized
INFO - 2021-05-17 16:35:42 --> Language Class Initialized
INFO - 2021-05-17 16:35:42 --> Loader Class Initialized
INFO - 2021-05-17 16:35:42 --> Helper loaded: url_helper
INFO - 2021-05-17 16:35:42 --> Helper loaded: form_helper
INFO - 2021-05-17 16:35:42 --> Helper loaded: common_helper
INFO - 2021-05-17 16:35:42 --> Database Driver Class Initialized
DEBUG - 2021-05-17 16:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 16:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 16:35:42 --> Controller Class Initialized
INFO - 2021-05-17 16:35:42 --> Form Validation Class Initialized
DEBUG - 2021-05-17 16:35:42 --> Encrypt Class Initialized
INFO - 2021-05-17 16:35:42 --> Model "Login_model" initialized
INFO - 2021-05-17 16:35:42 --> Model "Dashboard_model" initialized
INFO - 2021-05-17 16:35:42 --> Model "Case_model" initialized
INFO - 2021-05-17 16:35:42 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-17 16:35:42 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/dashboard/birthday.php
INFO - 2021-05-17 16:35:42 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-17 16:35:42 --> Final output sent to browser
DEBUG - 2021-05-17 16:35:42 --> Total execution time: 0.0271
ERROR - 2021-05-17 16:35:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:35:43 --> Config Class Initialized
INFO - 2021-05-17 16:35:43 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:35:43 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:35:43 --> Utf8 Class Initialized
INFO - 2021-05-17 16:35:43 --> URI Class Initialized
INFO - 2021-05-17 16:35:43 --> Router Class Initialized
INFO - 2021-05-17 16:35:43 --> Output Class Initialized
INFO - 2021-05-17 16:35:43 --> Security Class Initialized
DEBUG - 2021-05-17 16:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:35:43 --> Input Class Initialized
INFO - 2021-05-17 16:35:43 --> Language Class Initialized
ERROR - 2021-05-17 16:35:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-17 16:37:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:37:11 --> Config Class Initialized
INFO - 2021-05-17 16:37:11 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:37:11 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:37:11 --> Utf8 Class Initialized
INFO - 2021-05-17 16:37:11 --> URI Class Initialized
INFO - 2021-05-17 16:37:11 --> Router Class Initialized
INFO - 2021-05-17 16:37:11 --> Output Class Initialized
INFO - 2021-05-17 16:37:11 --> Security Class Initialized
DEBUG - 2021-05-17 16:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:37:11 --> Input Class Initialized
INFO - 2021-05-17 16:37:11 --> Language Class Initialized
INFO - 2021-05-17 16:37:11 --> Loader Class Initialized
INFO - 2021-05-17 16:37:11 --> Helper loaded: url_helper
INFO - 2021-05-17 16:37:11 --> Helper loaded: form_helper
INFO - 2021-05-17 16:37:11 --> Helper loaded: common_helper
INFO - 2021-05-17 16:37:11 --> Database Driver Class Initialized
DEBUG - 2021-05-17 16:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 16:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 16:37:11 --> Controller Class Initialized
INFO - 2021-05-17 16:37:11 --> Form Validation Class Initialized
DEBUG - 2021-05-17 16:37:11 --> Encrypt Class Initialized
INFO - 2021-05-17 16:37:11 --> Model "Login_model" initialized
INFO - 2021-05-17 16:37:11 --> Model "Dashboard_model" initialized
INFO - 2021-05-17 16:37:11 --> Model "Case_model" initialized
INFO - 2021-05-17 16:37:14 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-17 16:37:21 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-05-17 16:37:21 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-17 16:37:21 --> Final output sent to browser
DEBUG - 2021-05-17 16:37:21 --> Total execution time: 9.5304
ERROR - 2021-05-17 16:37:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 16:37:22 --> Config Class Initialized
INFO - 2021-05-17 16:37:22 --> Hooks Class Initialized
DEBUG - 2021-05-17 16:37:22 --> UTF-8 Support Enabled
INFO - 2021-05-17 16:37:22 --> Utf8 Class Initialized
INFO - 2021-05-17 16:37:22 --> URI Class Initialized
INFO - 2021-05-17 16:37:22 --> Router Class Initialized
INFO - 2021-05-17 16:37:22 --> Output Class Initialized
INFO - 2021-05-17 16:37:22 --> Security Class Initialized
DEBUG - 2021-05-17 16:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 16:37:22 --> Input Class Initialized
INFO - 2021-05-17 16:37:22 --> Language Class Initialized
ERROR - 2021-05-17 16:37:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-17 22:48:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-17 22:48:26 --> Config Class Initialized
INFO - 2021-05-17 22:48:26 --> Hooks Class Initialized
DEBUG - 2021-05-17 22:48:26 --> UTF-8 Support Enabled
INFO - 2021-05-17 22:48:26 --> Utf8 Class Initialized
INFO - 2021-05-17 22:48:26 --> URI Class Initialized
INFO - 2021-05-17 22:48:26 --> Router Class Initialized
INFO - 2021-05-17 22:48:26 --> Output Class Initialized
INFO - 2021-05-17 22:48:26 --> Security Class Initialized
DEBUG - 2021-05-17 22:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-17 22:48:26 --> Input Class Initialized
INFO - 2021-05-17 22:48:26 --> Language Class Initialized
INFO - 2021-05-17 22:48:26 --> Loader Class Initialized
INFO - 2021-05-17 22:48:27 --> Helper loaded: url_helper
INFO - 2021-05-17 22:48:27 --> Helper loaded: form_helper
INFO - 2021-05-17 22:48:27 --> Helper loaded: common_helper
INFO - 2021-05-17 22:48:27 --> Database Driver Class Initialized
DEBUG - 2021-05-17 22:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-17 22:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-17 22:48:27 --> Controller Class Initialized
INFO - 2021-05-17 22:48:27 --> Form Validation Class Initialized
DEBUG - 2021-05-17 22:48:27 --> Encrypt Class Initialized
DEBUG - 2021-05-17 22:48:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-17 22:48:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-17 22:48:27 --> Email Class Initialized
INFO - 2021-05-17 22:48:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-17 22:48:27 --> Calendar Class Initialized
INFO - 2021-05-17 22:48:27 --> Model "Login_model" initialized
INFO - 2021-05-17 22:48:27 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-17 22:48:27 --> Final output sent to browser
DEBUG - 2021-05-17 22:48:27 --> Total execution time: 0.0961
