<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-17 01:02:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:02:29 --> Config Class Initialized
INFO - 2022-03-17 01:02:29 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:02:29 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:02:29 --> Utf8 Class Initialized
INFO - 2022-03-17 01:02:29 --> URI Class Initialized
INFO - 2022-03-17 01:02:29 --> Router Class Initialized
INFO - 2022-03-17 01:02:29 --> Output Class Initialized
INFO - 2022-03-17 01:02:29 --> Security Class Initialized
DEBUG - 2022-03-17 01:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:02:29 --> Input Class Initialized
INFO - 2022-03-17 01:02:29 --> Language Class Initialized
INFO - 2022-03-17 01:02:29 --> Loader Class Initialized
INFO - 2022-03-17 01:02:29 --> Helper loaded: url_helper
INFO - 2022-03-17 01:02:29 --> Helper loaded: form_helper
INFO - 2022-03-17 01:02:29 --> Helper loaded: common_helper
INFO - 2022-03-17 01:02:29 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:02:29 --> Controller Class Initialized
INFO - 2022-03-17 01:02:29 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:02:29 --> Encrypt Class Initialized
DEBUG - 2022-03-17 01:02:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 01:02:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 01:02:29 --> Email Class Initialized
INFO - 2022-03-17 01:02:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 01:02:29 --> Calendar Class Initialized
INFO - 2022-03-17 01:02:29 --> Model "Login_model" initialized
INFO - 2022-03-17 01:02:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 01:02:29 --> Final output sent to browser
DEBUG - 2022-03-17 01:02:29 --> Total execution time: 0.0275
ERROR - 2022-03-17 01:02:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:02:45 --> Config Class Initialized
INFO - 2022-03-17 01:02:45 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:02:45 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:02:45 --> Utf8 Class Initialized
INFO - 2022-03-17 01:02:45 --> URI Class Initialized
INFO - 2022-03-17 01:02:45 --> Router Class Initialized
INFO - 2022-03-17 01:02:45 --> Output Class Initialized
INFO - 2022-03-17 01:02:45 --> Security Class Initialized
DEBUG - 2022-03-17 01:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:02:45 --> Input Class Initialized
INFO - 2022-03-17 01:02:45 --> Language Class Initialized
INFO - 2022-03-17 01:02:45 --> Loader Class Initialized
INFO - 2022-03-17 01:02:45 --> Helper loaded: url_helper
INFO - 2022-03-17 01:02:45 --> Helper loaded: form_helper
INFO - 2022-03-17 01:02:45 --> Helper loaded: common_helper
INFO - 2022-03-17 01:02:45 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:02:45 --> Controller Class Initialized
INFO - 2022-03-17 01:02:45 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:02:45 --> Encrypt Class Initialized
DEBUG - 2022-03-17 01:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 01:02:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 01:02:45 --> Email Class Initialized
INFO - 2022-03-17 01:02:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 01:02:45 --> Calendar Class Initialized
INFO - 2022-03-17 01:02:45 --> Model "Login_model" initialized
INFO - 2022-03-17 01:02:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-17 01:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:02:46 --> Config Class Initialized
INFO - 2022-03-17 01:02:46 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:02:46 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:02:46 --> Utf8 Class Initialized
INFO - 2022-03-17 01:02:46 --> URI Class Initialized
INFO - 2022-03-17 01:02:46 --> Router Class Initialized
INFO - 2022-03-17 01:02:46 --> Output Class Initialized
INFO - 2022-03-17 01:02:46 --> Security Class Initialized
DEBUG - 2022-03-17 01:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:02:46 --> Input Class Initialized
INFO - 2022-03-17 01:02:46 --> Language Class Initialized
INFO - 2022-03-17 01:02:46 --> Loader Class Initialized
INFO - 2022-03-17 01:02:46 --> Helper loaded: url_helper
INFO - 2022-03-17 01:02:46 --> Helper loaded: form_helper
INFO - 2022-03-17 01:02:46 --> Helper loaded: common_helper
INFO - 2022-03-17 01:02:46 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:02:46 --> Controller Class Initialized
INFO - 2022-03-17 01:02:46 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:02:46 --> Encrypt Class Initialized
INFO - 2022-03-17 01:02:46 --> Model "Login_model" initialized
INFO - 2022-03-17 01:02:46 --> Model "Dashboard_model" initialized
INFO - 2022-03-17 01:02:46 --> Model "Case_model" initialized
INFO - 2022-03-17 01:02:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:02:48 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-17 01:02:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:02:48 --> Final output sent to browser
DEBUG - 2022-03-17 01:02:48 --> Total execution time: 2.3866
ERROR - 2022-03-17 01:02:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:02:49 --> Config Class Initialized
INFO - 2022-03-17 01:02:49 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:02:49 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:02:49 --> Utf8 Class Initialized
INFO - 2022-03-17 01:02:49 --> URI Class Initialized
INFO - 2022-03-17 01:02:49 --> Router Class Initialized
INFO - 2022-03-17 01:02:49 --> Output Class Initialized
INFO - 2022-03-17 01:02:49 --> Security Class Initialized
DEBUG - 2022-03-17 01:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:02:49 --> Input Class Initialized
INFO - 2022-03-17 01:02:49 --> Language Class Initialized
INFO - 2022-03-17 01:02:49 --> Loader Class Initialized
INFO - 2022-03-17 01:02:49 --> Helper loaded: url_helper
INFO - 2022-03-17 01:02:49 --> Helper loaded: form_helper
INFO - 2022-03-17 01:02:49 --> Helper loaded: common_helper
INFO - 2022-03-17 01:02:49 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:02:49 --> Controller Class Initialized
INFO - 2022-03-17 01:02:49 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:02:49 --> Encrypt Class Initialized
DEBUG - 2022-03-17 01:02:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 01:02:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 01:02:49 --> Email Class Initialized
INFO - 2022-03-17 01:02:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 01:02:49 --> Calendar Class Initialized
INFO - 2022-03-17 01:02:49 --> Model "Login_model" initialized
INFO - 2022-03-17 01:02:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-17 01:02:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:02:51 --> Config Class Initialized
INFO - 2022-03-17 01:02:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:02:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:02:51 --> Utf8 Class Initialized
INFO - 2022-03-17 01:02:51 --> URI Class Initialized
INFO - 2022-03-17 01:02:51 --> Router Class Initialized
INFO - 2022-03-17 01:02:51 --> Output Class Initialized
INFO - 2022-03-17 01:02:51 --> Security Class Initialized
DEBUG - 2022-03-17 01:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:02:51 --> Input Class Initialized
INFO - 2022-03-17 01:02:51 --> Language Class Initialized
INFO - 2022-03-17 01:02:51 --> Loader Class Initialized
INFO - 2022-03-17 01:02:51 --> Helper loaded: url_helper
INFO - 2022-03-17 01:02:51 --> Helper loaded: form_helper
INFO - 2022-03-17 01:02:51 --> Helper loaded: common_helper
INFO - 2022-03-17 01:02:51 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:02:51 --> Controller Class Initialized
INFO - 2022-03-17 01:02:51 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:02:51 --> Encrypt Class Initialized
INFO - 2022-03-17 01:02:51 --> Model "Login_model" initialized
INFO - 2022-03-17 01:02:51 --> Model "Dashboard_model" initialized
INFO - 2022-03-17 01:02:51 --> Model "Case_model" initialized
INFO - 2022-03-17 01:02:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:02:52 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-17 01:02:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:02:52 --> Final output sent to browser
DEBUG - 2022-03-17 01:02:52 --> Total execution time: 0.2960
ERROR - 2022-03-17 01:03:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:03:31 --> Config Class Initialized
INFO - 2022-03-17 01:03:31 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:03:31 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:03:31 --> Utf8 Class Initialized
INFO - 2022-03-17 01:03:31 --> URI Class Initialized
INFO - 2022-03-17 01:03:31 --> Router Class Initialized
INFO - 2022-03-17 01:03:31 --> Output Class Initialized
INFO - 2022-03-17 01:03:31 --> Security Class Initialized
DEBUG - 2022-03-17 01:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:03:31 --> Input Class Initialized
INFO - 2022-03-17 01:03:31 --> Language Class Initialized
INFO - 2022-03-17 01:03:31 --> Loader Class Initialized
INFO - 2022-03-17 01:03:31 --> Helper loaded: url_helper
INFO - 2022-03-17 01:03:31 --> Helper loaded: form_helper
INFO - 2022-03-17 01:03:31 --> Helper loaded: common_helper
INFO - 2022-03-17 01:03:31 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:03:31 --> Controller Class Initialized
INFO - 2022-03-17 01:03:31 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:03:31 --> Encrypt Class Initialized
INFO - 2022-03-17 01:03:31 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:03:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:03:32 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:03:32 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:03:32 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:03:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:03:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 01:03:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:03:32 --> Final output sent to browser
DEBUG - 2022-03-17 01:03:32 --> Total execution time: 0.6982
ERROR - 2022-03-17 01:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:03:36 --> Config Class Initialized
INFO - 2022-03-17 01:03:36 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:03:36 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:03:36 --> Utf8 Class Initialized
INFO - 2022-03-17 01:03:36 --> URI Class Initialized
INFO - 2022-03-17 01:03:36 --> Router Class Initialized
INFO - 2022-03-17 01:03:36 --> Output Class Initialized
INFO - 2022-03-17 01:03:36 --> Security Class Initialized
DEBUG - 2022-03-17 01:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:03:36 --> Input Class Initialized
INFO - 2022-03-17 01:03:36 --> Language Class Initialized
INFO - 2022-03-17 01:03:36 --> Loader Class Initialized
INFO - 2022-03-17 01:03:36 --> Helper loaded: url_helper
INFO - 2022-03-17 01:03:36 --> Helper loaded: form_helper
INFO - 2022-03-17 01:03:36 --> Helper loaded: common_helper
INFO - 2022-03-17 01:03:36 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:03:36 --> Controller Class Initialized
INFO - 2022-03-17 01:03:36 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:03:36 --> Encrypt Class Initialized
INFO - 2022-03-17 01:03:36 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:03:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:03:36 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:03:36 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:03:36 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:03:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:03:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 01:03:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:03:36 --> Final output sent to browser
DEBUG - 2022-03-17 01:03:36 --> Total execution time: 0.0949
ERROR - 2022-03-17 01:03:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:03:46 --> Config Class Initialized
INFO - 2022-03-17 01:03:46 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:03:46 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:03:46 --> Utf8 Class Initialized
INFO - 2022-03-17 01:03:46 --> URI Class Initialized
INFO - 2022-03-17 01:03:46 --> Router Class Initialized
INFO - 2022-03-17 01:03:46 --> Output Class Initialized
INFO - 2022-03-17 01:03:46 --> Security Class Initialized
DEBUG - 2022-03-17 01:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:03:46 --> Input Class Initialized
INFO - 2022-03-17 01:03:46 --> Language Class Initialized
INFO - 2022-03-17 01:03:46 --> Loader Class Initialized
INFO - 2022-03-17 01:03:46 --> Helper loaded: url_helper
INFO - 2022-03-17 01:03:46 --> Helper loaded: form_helper
INFO - 2022-03-17 01:03:46 --> Helper loaded: common_helper
INFO - 2022-03-17 01:03:46 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:03:46 --> Controller Class Initialized
INFO - 2022-03-17 01:03:46 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:03:46 --> Encrypt Class Initialized
INFO - 2022-03-17 01:03:46 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:03:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:03:46 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:03:46 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:03:46 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:03:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:03:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 01:03:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:03:46 --> Final output sent to browser
DEBUG - 2022-03-17 01:03:46 --> Total execution time: 0.1567
ERROR - 2022-03-17 01:07:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:07:08 --> Config Class Initialized
INFO - 2022-03-17 01:07:08 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:07:08 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:07:08 --> Utf8 Class Initialized
INFO - 2022-03-17 01:07:08 --> URI Class Initialized
INFO - 2022-03-17 01:07:08 --> Router Class Initialized
INFO - 2022-03-17 01:07:08 --> Output Class Initialized
INFO - 2022-03-17 01:07:08 --> Security Class Initialized
DEBUG - 2022-03-17 01:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:07:08 --> Input Class Initialized
INFO - 2022-03-17 01:07:08 --> Language Class Initialized
INFO - 2022-03-17 01:07:08 --> Loader Class Initialized
INFO - 2022-03-17 01:07:08 --> Helper loaded: url_helper
INFO - 2022-03-17 01:07:08 --> Helper loaded: form_helper
INFO - 2022-03-17 01:07:08 --> Helper loaded: common_helper
INFO - 2022-03-17 01:07:08 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:07:08 --> Controller Class Initialized
INFO - 2022-03-17 01:07:08 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:07:08 --> Encrypt Class Initialized
INFO - 2022-03-17 01:07:08 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:07:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:07:08 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:07:08 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:07:08 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:07:08 --> Final output sent to browser
DEBUG - 2022-03-17 01:07:08 --> Total execution time: 0.0295
ERROR - 2022-03-17 01:13:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:13:48 --> Config Class Initialized
INFO - 2022-03-17 01:13:48 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:13:48 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:13:48 --> Utf8 Class Initialized
INFO - 2022-03-17 01:13:48 --> URI Class Initialized
INFO - 2022-03-17 01:13:48 --> Router Class Initialized
INFO - 2022-03-17 01:13:48 --> Output Class Initialized
INFO - 2022-03-17 01:13:48 --> Security Class Initialized
DEBUG - 2022-03-17 01:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:13:48 --> Input Class Initialized
INFO - 2022-03-17 01:13:48 --> Language Class Initialized
INFO - 2022-03-17 01:13:48 --> Loader Class Initialized
INFO - 2022-03-17 01:13:48 --> Helper loaded: url_helper
INFO - 2022-03-17 01:13:48 --> Helper loaded: form_helper
INFO - 2022-03-17 01:13:48 --> Helper loaded: common_helper
INFO - 2022-03-17 01:13:48 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:13:48 --> Controller Class Initialized
INFO - 2022-03-17 01:13:48 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:13:48 --> Encrypt Class Initialized
INFO - 2022-03-17 01:13:48 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:13:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:13:48 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:13:48 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:13:48 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:13:48 --> Final output sent to browser
DEBUG - 2022-03-17 01:13:48 --> Total execution time: 0.0417
ERROR - 2022-03-17 01:13:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:13:53 --> Config Class Initialized
INFO - 2022-03-17 01:13:53 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:13:53 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:13:53 --> Utf8 Class Initialized
INFO - 2022-03-17 01:13:53 --> URI Class Initialized
INFO - 2022-03-17 01:13:53 --> Router Class Initialized
INFO - 2022-03-17 01:13:53 --> Output Class Initialized
INFO - 2022-03-17 01:13:53 --> Security Class Initialized
DEBUG - 2022-03-17 01:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:13:53 --> Input Class Initialized
INFO - 2022-03-17 01:13:53 --> Language Class Initialized
INFO - 2022-03-17 01:13:53 --> Loader Class Initialized
INFO - 2022-03-17 01:13:53 --> Helper loaded: url_helper
INFO - 2022-03-17 01:13:53 --> Helper loaded: form_helper
INFO - 2022-03-17 01:13:53 --> Helper loaded: common_helper
INFO - 2022-03-17 01:13:53 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:13:53 --> Controller Class Initialized
INFO - 2022-03-17 01:13:53 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:13:53 --> Encrypt Class Initialized
INFO - 2022-03-17 01:13:53 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:13:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:13:53 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:13:53 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:13:53 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:13:53 --> Final output sent to browser
DEBUG - 2022-03-17 01:13:53 --> Total execution time: 0.0258
ERROR - 2022-03-17 01:13:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:13:55 --> Config Class Initialized
INFO - 2022-03-17 01:13:55 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:13:55 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:13:55 --> Utf8 Class Initialized
INFO - 2022-03-17 01:13:55 --> URI Class Initialized
INFO - 2022-03-17 01:13:55 --> Router Class Initialized
INFO - 2022-03-17 01:13:55 --> Output Class Initialized
INFO - 2022-03-17 01:13:55 --> Security Class Initialized
DEBUG - 2022-03-17 01:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:13:55 --> Input Class Initialized
INFO - 2022-03-17 01:13:55 --> Language Class Initialized
INFO - 2022-03-17 01:13:55 --> Loader Class Initialized
INFO - 2022-03-17 01:13:55 --> Helper loaded: url_helper
INFO - 2022-03-17 01:13:55 --> Helper loaded: form_helper
INFO - 2022-03-17 01:13:55 --> Helper loaded: common_helper
INFO - 2022-03-17 01:13:55 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:13:55 --> Controller Class Initialized
INFO - 2022-03-17 01:13:55 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:13:55 --> Encrypt Class Initialized
INFO - 2022-03-17 01:13:55 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:13:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:13:55 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:13:55 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:13:55 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:13:55 --> Final output sent to browser
DEBUG - 2022-03-17 01:13:55 --> Total execution time: 0.0276
ERROR - 2022-03-17 01:14:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:14:03 --> Config Class Initialized
INFO - 2022-03-17 01:14:03 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:14:03 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:14:03 --> Utf8 Class Initialized
INFO - 2022-03-17 01:14:03 --> URI Class Initialized
INFO - 2022-03-17 01:14:03 --> Router Class Initialized
INFO - 2022-03-17 01:14:03 --> Output Class Initialized
INFO - 2022-03-17 01:14:03 --> Security Class Initialized
DEBUG - 2022-03-17 01:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:14:03 --> Input Class Initialized
INFO - 2022-03-17 01:14:03 --> Language Class Initialized
INFO - 2022-03-17 01:14:03 --> Loader Class Initialized
INFO - 2022-03-17 01:14:03 --> Helper loaded: url_helper
INFO - 2022-03-17 01:14:03 --> Helper loaded: form_helper
INFO - 2022-03-17 01:14:03 --> Helper loaded: common_helper
INFO - 2022-03-17 01:14:03 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:14:03 --> Controller Class Initialized
INFO - 2022-03-17 01:14:03 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:14:03 --> Encrypt Class Initialized
INFO - 2022-03-17 01:14:03 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:14:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:14:03 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:14:03 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:14:03 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:14:03 --> Final output sent to browser
DEBUG - 2022-03-17 01:14:03 --> Total execution time: 0.0423
ERROR - 2022-03-17 01:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:19:06 --> Config Class Initialized
INFO - 2022-03-17 01:19:06 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:19:06 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:19:06 --> Utf8 Class Initialized
INFO - 2022-03-17 01:19:06 --> URI Class Initialized
INFO - 2022-03-17 01:19:06 --> Router Class Initialized
INFO - 2022-03-17 01:19:06 --> Output Class Initialized
INFO - 2022-03-17 01:19:06 --> Security Class Initialized
DEBUG - 2022-03-17 01:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:19:06 --> Input Class Initialized
INFO - 2022-03-17 01:19:06 --> Language Class Initialized
INFO - 2022-03-17 01:19:06 --> Loader Class Initialized
INFO - 2022-03-17 01:19:06 --> Helper loaded: url_helper
INFO - 2022-03-17 01:19:06 --> Helper loaded: form_helper
INFO - 2022-03-17 01:19:06 --> Helper loaded: common_helper
INFO - 2022-03-17 01:19:06 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:19:06 --> Controller Class Initialized
INFO - 2022-03-17 01:19:06 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:19:06 --> Encrypt Class Initialized
INFO - 2022-03-17 01:19:06 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:19:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:19:06 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:19:06 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:19:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 01:19:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:19:07 --> Config Class Initialized
INFO - 2022-03-17 01:19:07 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:19:07 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:19:07 --> Utf8 Class Initialized
INFO - 2022-03-17 01:19:07 --> URI Class Initialized
INFO - 2022-03-17 01:19:07 --> Router Class Initialized
INFO - 2022-03-17 01:19:07 --> Output Class Initialized
INFO - 2022-03-17 01:19:07 --> Security Class Initialized
DEBUG - 2022-03-17 01:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:19:07 --> Input Class Initialized
INFO - 2022-03-17 01:19:07 --> Language Class Initialized
INFO - 2022-03-17 01:19:07 --> Loader Class Initialized
INFO - 2022-03-17 01:19:07 --> Helper loaded: url_helper
INFO - 2022-03-17 01:19:07 --> Helper loaded: form_helper
INFO - 2022-03-17 01:19:07 --> Helper loaded: common_helper
INFO - 2022-03-17 01:19:07 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:19:07 --> Controller Class Initialized
INFO - 2022-03-17 01:19:07 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:19:07 --> Encrypt Class Initialized
INFO - 2022-03-17 01:19:07 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:19:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:19:07 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:19:07 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:19:07 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:19:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:19:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 01:19:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:19:07 --> Final output sent to browser
DEBUG - 2022-03-17 01:19:07 --> Total execution time: 0.0595
ERROR - 2022-03-17 01:19:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:19:08 --> Config Class Initialized
INFO - 2022-03-17 01:19:08 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:19:08 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:19:08 --> Utf8 Class Initialized
INFO - 2022-03-17 01:19:08 --> URI Class Initialized
INFO - 2022-03-17 01:19:08 --> Router Class Initialized
INFO - 2022-03-17 01:19:08 --> Output Class Initialized
INFO - 2022-03-17 01:19:08 --> Security Class Initialized
DEBUG - 2022-03-17 01:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:19:08 --> Input Class Initialized
INFO - 2022-03-17 01:19:08 --> Language Class Initialized
INFO - 2022-03-17 01:19:08 --> Loader Class Initialized
INFO - 2022-03-17 01:19:08 --> Helper loaded: url_helper
INFO - 2022-03-17 01:19:08 --> Helper loaded: form_helper
INFO - 2022-03-17 01:19:08 --> Helper loaded: common_helper
INFO - 2022-03-17 01:19:08 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:19:08 --> Controller Class Initialized
INFO - 2022-03-17 01:19:08 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:19:08 --> Encrypt Class Initialized
INFO - 2022-03-17 01:19:08 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:19:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:19:08 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:19:08 --> Model "Users_model" initialized
INFO - 2022-03-17 01:19:08 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:19:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:19:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 01:19:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:19:08 --> Final output sent to browser
DEBUG - 2022-03-17 01:19:08 --> Total execution time: 0.0762
ERROR - 2022-03-17 01:30:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:30:51 --> Config Class Initialized
INFO - 2022-03-17 01:30:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:30:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:30:51 --> Utf8 Class Initialized
INFO - 2022-03-17 01:30:51 --> URI Class Initialized
INFO - 2022-03-17 01:30:51 --> Router Class Initialized
INFO - 2022-03-17 01:30:51 --> Output Class Initialized
INFO - 2022-03-17 01:30:51 --> Security Class Initialized
DEBUG - 2022-03-17 01:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:30:51 --> Input Class Initialized
INFO - 2022-03-17 01:30:51 --> Language Class Initialized
INFO - 2022-03-17 01:30:51 --> Loader Class Initialized
INFO - 2022-03-17 01:30:51 --> Helper loaded: url_helper
INFO - 2022-03-17 01:30:51 --> Helper loaded: form_helper
INFO - 2022-03-17 01:30:51 --> Helper loaded: common_helper
INFO - 2022-03-17 01:30:51 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:30:51 --> Controller Class Initialized
INFO - 2022-03-17 01:30:51 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:30:51 --> Encrypt Class Initialized
INFO - 2022-03-17 01:30:51 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:30:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:30:51 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:30:51 --> Model "Users_model" initialized
INFO - 2022-03-17 01:30:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 01:30:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:30:51 --> Config Class Initialized
INFO - 2022-03-17 01:30:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:30:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:30:51 --> Utf8 Class Initialized
INFO - 2022-03-17 01:30:51 --> URI Class Initialized
INFO - 2022-03-17 01:30:51 --> Router Class Initialized
INFO - 2022-03-17 01:30:51 --> Output Class Initialized
INFO - 2022-03-17 01:30:51 --> Security Class Initialized
DEBUG - 2022-03-17 01:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:30:51 --> Input Class Initialized
INFO - 2022-03-17 01:30:51 --> Language Class Initialized
INFO - 2022-03-17 01:30:51 --> Loader Class Initialized
INFO - 2022-03-17 01:30:51 --> Helper loaded: url_helper
INFO - 2022-03-17 01:30:51 --> Helper loaded: form_helper
INFO - 2022-03-17 01:30:51 --> Helper loaded: common_helper
INFO - 2022-03-17 01:30:51 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:30:51 --> Controller Class Initialized
INFO - 2022-03-17 01:30:51 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:30:51 --> Encrypt Class Initialized
INFO - 2022-03-17 01:30:51 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:30:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:30:51 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:30:51 --> Model "Users_model" initialized
INFO - 2022-03-17 01:30:51 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:30:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:30:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 01:30:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:30:51 --> Final output sent to browser
DEBUG - 2022-03-17 01:30:51 --> Total execution time: 0.0853
ERROR - 2022-03-17 01:30:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:30:56 --> Config Class Initialized
INFO - 2022-03-17 01:30:56 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:30:56 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:30:56 --> Utf8 Class Initialized
INFO - 2022-03-17 01:30:56 --> URI Class Initialized
INFO - 2022-03-17 01:30:56 --> Router Class Initialized
INFO - 2022-03-17 01:30:56 --> Output Class Initialized
INFO - 2022-03-17 01:30:56 --> Security Class Initialized
DEBUG - 2022-03-17 01:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:30:56 --> Input Class Initialized
INFO - 2022-03-17 01:30:56 --> Language Class Initialized
INFO - 2022-03-17 01:30:56 --> Loader Class Initialized
INFO - 2022-03-17 01:30:56 --> Helper loaded: url_helper
INFO - 2022-03-17 01:30:56 --> Helper loaded: form_helper
INFO - 2022-03-17 01:30:56 --> Helper loaded: common_helper
INFO - 2022-03-17 01:30:56 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:30:56 --> Controller Class Initialized
INFO - 2022-03-17 01:30:56 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:30:56 --> Encrypt Class Initialized
INFO - 2022-03-17 01:30:56 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:30:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:30:56 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:30:56 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:30:56 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:30:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:30:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 01:30:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:30:56 --> Final output sent to browser
DEBUG - 2022-03-17 01:30:56 --> Total execution time: 0.0797
ERROR - 2022-03-17 01:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:31:13 --> Config Class Initialized
INFO - 2022-03-17 01:31:13 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:31:13 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:31:13 --> Utf8 Class Initialized
INFO - 2022-03-17 01:31:13 --> URI Class Initialized
INFO - 2022-03-17 01:31:13 --> Router Class Initialized
INFO - 2022-03-17 01:31:13 --> Output Class Initialized
INFO - 2022-03-17 01:31:13 --> Security Class Initialized
DEBUG - 2022-03-17 01:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:31:13 --> Input Class Initialized
INFO - 2022-03-17 01:31:13 --> Language Class Initialized
INFO - 2022-03-17 01:31:13 --> Loader Class Initialized
INFO - 2022-03-17 01:31:13 --> Helper loaded: url_helper
INFO - 2022-03-17 01:31:13 --> Helper loaded: form_helper
INFO - 2022-03-17 01:31:13 --> Helper loaded: common_helper
INFO - 2022-03-17 01:31:13 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:31:13 --> Controller Class Initialized
INFO - 2022-03-17 01:31:13 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:31:13 --> Encrypt Class Initialized
INFO - 2022-03-17 01:31:13 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:31:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:31:13 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:31:13 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:31:13 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:31:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:31:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 01:31:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:31:13 --> Final output sent to browser
DEBUG - 2022-03-17 01:31:13 --> Total execution time: 0.0532
ERROR - 2022-03-17 01:32:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:32:13 --> Config Class Initialized
INFO - 2022-03-17 01:32:13 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:32:13 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:32:13 --> Utf8 Class Initialized
INFO - 2022-03-17 01:32:13 --> URI Class Initialized
INFO - 2022-03-17 01:32:13 --> Router Class Initialized
INFO - 2022-03-17 01:32:13 --> Output Class Initialized
INFO - 2022-03-17 01:32:13 --> Security Class Initialized
DEBUG - 2022-03-17 01:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:32:13 --> Input Class Initialized
INFO - 2022-03-17 01:32:13 --> Language Class Initialized
INFO - 2022-03-17 01:32:13 --> Loader Class Initialized
INFO - 2022-03-17 01:32:13 --> Helper loaded: url_helper
INFO - 2022-03-17 01:32:13 --> Helper loaded: form_helper
INFO - 2022-03-17 01:32:13 --> Helper loaded: common_helper
INFO - 2022-03-17 01:32:13 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:32:13 --> Controller Class Initialized
INFO - 2022-03-17 01:32:13 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:32:13 --> Final output sent to browser
DEBUG - 2022-03-17 01:32:13 --> Total execution time: 0.0377
ERROR - 2022-03-17 01:32:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:32:18 --> Config Class Initialized
INFO - 2022-03-17 01:32:18 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:32:18 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:32:18 --> Utf8 Class Initialized
INFO - 2022-03-17 01:32:18 --> URI Class Initialized
INFO - 2022-03-17 01:32:18 --> Router Class Initialized
INFO - 2022-03-17 01:32:18 --> Output Class Initialized
INFO - 2022-03-17 01:32:18 --> Security Class Initialized
DEBUG - 2022-03-17 01:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:32:18 --> Input Class Initialized
INFO - 2022-03-17 01:32:18 --> Language Class Initialized
INFO - 2022-03-17 01:32:18 --> Loader Class Initialized
INFO - 2022-03-17 01:32:18 --> Helper loaded: url_helper
INFO - 2022-03-17 01:32:18 --> Helper loaded: form_helper
INFO - 2022-03-17 01:32:18 --> Helper loaded: common_helper
INFO - 2022-03-17 01:32:18 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:32:18 --> Controller Class Initialized
INFO - 2022-03-17 01:32:18 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:32:18 --> Final output sent to browser
DEBUG - 2022-03-17 01:32:18 --> Total execution time: 0.0252
ERROR - 2022-03-17 01:32:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:32:42 --> Config Class Initialized
INFO - 2022-03-17 01:32:42 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:32:42 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:32:42 --> Utf8 Class Initialized
INFO - 2022-03-17 01:32:42 --> URI Class Initialized
INFO - 2022-03-17 01:32:42 --> Router Class Initialized
INFO - 2022-03-17 01:32:42 --> Output Class Initialized
INFO - 2022-03-17 01:32:42 --> Security Class Initialized
DEBUG - 2022-03-17 01:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:32:42 --> Input Class Initialized
INFO - 2022-03-17 01:32:42 --> Language Class Initialized
INFO - 2022-03-17 01:32:42 --> Loader Class Initialized
INFO - 2022-03-17 01:32:42 --> Helper loaded: url_helper
INFO - 2022-03-17 01:32:42 --> Helper loaded: form_helper
INFO - 2022-03-17 01:32:42 --> Helper loaded: common_helper
INFO - 2022-03-17 01:32:42 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:32:42 --> Controller Class Initialized
INFO - 2022-03-17 01:32:42 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:32:42 --> Final output sent to browser
DEBUG - 2022-03-17 01:32:42 --> Total execution time: 0.0262
ERROR - 2022-03-17 01:32:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:32:42 --> Config Class Initialized
INFO - 2022-03-17 01:32:42 --> Hooks Class Initialized
ERROR - 2022-03-17 01:32:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:32:42 --> Config Class Initialized
INFO - 2022-03-17 01:32:42 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:32:42 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:32:42 --> Utf8 Class Initialized
INFO - 2022-03-17 01:32:42 --> URI Class Initialized
DEBUG - 2022-03-17 01:32:42 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:32:42 --> Utf8 Class Initialized
INFO - 2022-03-17 01:32:42 --> Router Class Initialized
INFO - 2022-03-17 01:32:42 --> URI Class Initialized
INFO - 2022-03-17 01:32:42 --> Output Class Initialized
INFO - 2022-03-17 01:32:42 --> Router Class Initialized
INFO - 2022-03-17 01:32:42 --> Security Class Initialized
INFO - 2022-03-17 01:32:42 --> Output Class Initialized
DEBUG - 2022-03-17 01:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:32:42 --> Input Class Initialized
INFO - 2022-03-17 01:32:42 --> Language Class Initialized
INFO - 2022-03-17 01:32:42 --> Security Class Initialized
DEBUG - 2022-03-17 01:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:32:42 --> Loader Class Initialized
INFO - 2022-03-17 01:32:42 --> Input Class Initialized
INFO - 2022-03-17 01:32:42 --> Language Class Initialized
INFO - 2022-03-17 01:32:42 --> Helper loaded: url_helper
INFO - 2022-03-17 01:32:42 --> Helper loaded: form_helper
INFO - 2022-03-17 01:32:42 --> Helper loaded: common_helper
INFO - 2022-03-17 01:32:42 --> Loader Class Initialized
INFO - 2022-03-17 01:32:42 --> Helper loaded: url_helper
INFO - 2022-03-17 01:32:42 --> Helper loaded: form_helper
INFO - 2022-03-17 01:32:42 --> Helper loaded: common_helper
INFO - 2022-03-17 01:32:42 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:32:42 --> Controller Class Initialized
INFO - 2022-03-17 01:32:42 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:32:42 --> Database Driver Class Initialized
INFO - 2022-03-17 01:32:42 --> Final output sent to browser
DEBUG - 2022-03-17 01:32:42 --> Total execution time: 0.0201
DEBUG - 2022-03-17 01:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:32:43 --> Controller Class Initialized
INFO - 2022-03-17 01:32:43 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:32:43 --> Final output sent to browser
DEBUG - 2022-03-17 01:32:43 --> Total execution time: 0.0293
ERROR - 2022-03-17 01:32:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:32:43 --> Config Class Initialized
INFO - 2022-03-17 01:32:43 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:32:43 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:32:43 --> Utf8 Class Initialized
INFO - 2022-03-17 01:32:43 --> URI Class Initialized
INFO - 2022-03-17 01:32:43 --> Router Class Initialized
INFO - 2022-03-17 01:32:43 --> Output Class Initialized
INFO - 2022-03-17 01:32:43 --> Security Class Initialized
DEBUG - 2022-03-17 01:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:32:43 --> Input Class Initialized
INFO - 2022-03-17 01:32:43 --> Language Class Initialized
INFO - 2022-03-17 01:32:43 --> Loader Class Initialized
INFO - 2022-03-17 01:32:43 --> Helper loaded: url_helper
INFO - 2022-03-17 01:32:43 --> Helper loaded: form_helper
INFO - 2022-03-17 01:32:43 --> Helper loaded: common_helper
INFO - 2022-03-17 01:32:43 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:32:43 --> Controller Class Initialized
INFO - 2022-03-17 01:32:43 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:32:43 --> Final output sent to browser
DEBUG - 2022-03-17 01:32:43 --> Total execution time: 0.0276
ERROR - 2022-03-17 01:35:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:35:54 --> Config Class Initialized
INFO - 2022-03-17 01:35:54 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:35:54 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:35:54 --> Utf8 Class Initialized
INFO - 2022-03-17 01:35:54 --> URI Class Initialized
INFO - 2022-03-17 01:35:54 --> Router Class Initialized
INFO - 2022-03-17 01:35:54 --> Output Class Initialized
INFO - 2022-03-17 01:35:54 --> Security Class Initialized
DEBUG - 2022-03-17 01:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:35:54 --> Input Class Initialized
INFO - 2022-03-17 01:35:54 --> Language Class Initialized
INFO - 2022-03-17 01:35:54 --> Loader Class Initialized
INFO - 2022-03-17 01:35:54 --> Helper loaded: url_helper
INFO - 2022-03-17 01:35:54 --> Helper loaded: form_helper
INFO - 2022-03-17 01:35:54 --> Helper loaded: common_helper
INFO - 2022-03-17 01:35:54 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:35:54 --> Controller Class Initialized
INFO - 2022-03-17 01:35:54 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:35:54 --> Encrypt Class Initialized
INFO - 2022-03-17 01:35:54 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:35:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:35:54 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:35:54 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:35:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 01:35:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:35:55 --> Config Class Initialized
INFO - 2022-03-17 01:35:55 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:35:55 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:35:55 --> Utf8 Class Initialized
INFO - 2022-03-17 01:35:55 --> URI Class Initialized
INFO - 2022-03-17 01:35:55 --> Router Class Initialized
INFO - 2022-03-17 01:35:55 --> Output Class Initialized
INFO - 2022-03-17 01:35:55 --> Security Class Initialized
DEBUG - 2022-03-17 01:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:35:55 --> Input Class Initialized
INFO - 2022-03-17 01:35:55 --> Language Class Initialized
INFO - 2022-03-17 01:35:55 --> Loader Class Initialized
INFO - 2022-03-17 01:35:55 --> Helper loaded: url_helper
INFO - 2022-03-17 01:35:55 --> Helper loaded: form_helper
INFO - 2022-03-17 01:35:55 --> Helper loaded: common_helper
INFO - 2022-03-17 01:35:55 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:35:55 --> Controller Class Initialized
INFO - 2022-03-17 01:35:55 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:35:55 --> Encrypt Class Initialized
INFO - 2022-03-17 01:35:55 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:35:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:35:55 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:35:55 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:35:55 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:35:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:35:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 01:35:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:35:55 --> Final output sent to browser
DEBUG - 2022-03-17 01:35:55 --> Total execution time: 0.0670
ERROR - 2022-03-17 01:35:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:35:56 --> Config Class Initialized
INFO - 2022-03-17 01:35:56 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:35:56 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:35:56 --> Utf8 Class Initialized
INFO - 2022-03-17 01:35:56 --> URI Class Initialized
INFO - 2022-03-17 01:35:56 --> Router Class Initialized
INFO - 2022-03-17 01:35:56 --> Output Class Initialized
INFO - 2022-03-17 01:35:56 --> Security Class Initialized
DEBUG - 2022-03-17 01:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:35:56 --> Input Class Initialized
INFO - 2022-03-17 01:35:56 --> Language Class Initialized
INFO - 2022-03-17 01:35:56 --> Loader Class Initialized
INFO - 2022-03-17 01:35:56 --> Helper loaded: url_helper
INFO - 2022-03-17 01:35:56 --> Helper loaded: form_helper
INFO - 2022-03-17 01:35:56 --> Helper loaded: common_helper
INFO - 2022-03-17 01:35:56 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:35:56 --> Controller Class Initialized
INFO - 2022-03-17 01:35:56 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:35:56 --> Encrypt Class Initialized
INFO - 2022-03-17 01:35:56 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:35:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:35:56 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:35:56 --> Model "Users_model" initialized
INFO - 2022-03-17 01:35:56 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:35:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:35:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 01:35:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:35:56 --> Final output sent to browser
DEBUG - 2022-03-17 01:35:56 --> Total execution time: 0.1326
ERROR - 2022-03-17 01:37:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:37:51 --> Config Class Initialized
INFO - 2022-03-17 01:37:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:37:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:37:51 --> Utf8 Class Initialized
INFO - 2022-03-17 01:37:51 --> URI Class Initialized
INFO - 2022-03-17 01:37:51 --> Router Class Initialized
INFO - 2022-03-17 01:37:51 --> Output Class Initialized
INFO - 2022-03-17 01:37:51 --> Security Class Initialized
DEBUG - 2022-03-17 01:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:37:51 --> Input Class Initialized
INFO - 2022-03-17 01:37:51 --> Language Class Initialized
INFO - 2022-03-17 01:37:51 --> Loader Class Initialized
INFO - 2022-03-17 01:37:51 --> Helper loaded: url_helper
INFO - 2022-03-17 01:37:51 --> Helper loaded: form_helper
INFO - 2022-03-17 01:37:51 --> Helper loaded: common_helper
INFO - 2022-03-17 01:37:51 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:37:51 --> Controller Class Initialized
INFO - 2022-03-17 01:37:51 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:37:51 --> Encrypt Class Initialized
INFO - 2022-03-17 01:37:51 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:37:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:37:51 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:37:51 --> Model "Users_model" initialized
INFO - 2022-03-17 01:37:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 01:37:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:37:52 --> Config Class Initialized
INFO - 2022-03-17 01:37:52 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:37:52 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:37:52 --> Utf8 Class Initialized
INFO - 2022-03-17 01:37:52 --> URI Class Initialized
INFO - 2022-03-17 01:37:52 --> Router Class Initialized
INFO - 2022-03-17 01:37:52 --> Output Class Initialized
INFO - 2022-03-17 01:37:52 --> Security Class Initialized
DEBUG - 2022-03-17 01:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:37:52 --> Input Class Initialized
INFO - 2022-03-17 01:37:52 --> Language Class Initialized
INFO - 2022-03-17 01:37:52 --> Loader Class Initialized
INFO - 2022-03-17 01:37:52 --> Helper loaded: url_helper
INFO - 2022-03-17 01:37:52 --> Helper loaded: form_helper
INFO - 2022-03-17 01:37:52 --> Helper loaded: common_helper
INFO - 2022-03-17 01:37:52 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:37:52 --> Controller Class Initialized
INFO - 2022-03-17 01:37:52 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:37:52 --> Encrypt Class Initialized
INFO - 2022-03-17 01:37:52 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:37:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:37:52 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:37:52 --> Model "Users_model" initialized
INFO - 2022-03-17 01:37:52 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:37:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:37:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 01:37:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:37:52 --> Final output sent to browser
DEBUG - 2022-03-17 01:37:52 --> Total execution time: 0.0698
ERROR - 2022-03-17 01:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:39:21 --> Config Class Initialized
INFO - 2022-03-17 01:39:21 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:39:21 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:39:21 --> Utf8 Class Initialized
INFO - 2022-03-17 01:39:21 --> URI Class Initialized
INFO - 2022-03-17 01:39:21 --> Router Class Initialized
INFO - 2022-03-17 01:39:21 --> Output Class Initialized
INFO - 2022-03-17 01:39:21 --> Security Class Initialized
DEBUG - 2022-03-17 01:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:39:21 --> Input Class Initialized
INFO - 2022-03-17 01:39:21 --> Language Class Initialized
INFO - 2022-03-17 01:39:21 --> Loader Class Initialized
INFO - 2022-03-17 01:39:21 --> Helper loaded: url_helper
INFO - 2022-03-17 01:39:21 --> Helper loaded: form_helper
INFO - 2022-03-17 01:39:21 --> Helper loaded: common_helper
INFO - 2022-03-17 01:39:21 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:39:21 --> Controller Class Initialized
INFO - 2022-03-17 01:39:21 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:39:21 --> Encrypt Class Initialized
INFO - 2022-03-17 01:39:21 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:39:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:39:21 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:39:21 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:39:21 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:39:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:39:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 01:39:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:39:21 --> Final output sent to browser
DEBUG - 2022-03-17 01:39:21 --> Total execution time: 0.0894
ERROR - 2022-03-17 01:39:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:39:28 --> Config Class Initialized
INFO - 2022-03-17 01:39:28 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:39:28 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:39:28 --> Utf8 Class Initialized
INFO - 2022-03-17 01:39:28 --> URI Class Initialized
INFO - 2022-03-17 01:39:28 --> Router Class Initialized
INFO - 2022-03-17 01:39:28 --> Output Class Initialized
INFO - 2022-03-17 01:39:28 --> Security Class Initialized
DEBUG - 2022-03-17 01:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:39:28 --> Input Class Initialized
INFO - 2022-03-17 01:39:28 --> Language Class Initialized
INFO - 2022-03-17 01:39:28 --> Loader Class Initialized
INFO - 2022-03-17 01:39:28 --> Helper loaded: url_helper
INFO - 2022-03-17 01:39:28 --> Helper loaded: form_helper
INFO - 2022-03-17 01:39:28 --> Helper loaded: common_helper
INFO - 2022-03-17 01:39:28 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:39:28 --> Controller Class Initialized
INFO - 2022-03-17 01:39:28 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:39:28 --> Encrypt Class Initialized
INFO - 2022-03-17 01:39:28 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:39:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:39:28 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:39:28 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:39:28 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:39:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:39:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 01:39:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:39:28 --> Final output sent to browser
DEBUG - 2022-03-17 01:39:28 --> Total execution time: 0.0497
ERROR - 2022-03-17 01:39:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:39:35 --> Config Class Initialized
INFO - 2022-03-17 01:39:35 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:39:35 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:39:35 --> Utf8 Class Initialized
INFO - 2022-03-17 01:39:35 --> URI Class Initialized
INFO - 2022-03-17 01:39:35 --> Router Class Initialized
INFO - 2022-03-17 01:39:35 --> Output Class Initialized
INFO - 2022-03-17 01:39:35 --> Security Class Initialized
DEBUG - 2022-03-17 01:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:39:35 --> Input Class Initialized
INFO - 2022-03-17 01:39:35 --> Language Class Initialized
INFO - 2022-03-17 01:39:35 --> Loader Class Initialized
INFO - 2022-03-17 01:39:35 --> Helper loaded: url_helper
INFO - 2022-03-17 01:39:35 --> Helper loaded: form_helper
INFO - 2022-03-17 01:39:35 --> Helper loaded: common_helper
INFO - 2022-03-17 01:39:35 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:39:35 --> Controller Class Initialized
INFO - 2022-03-17 01:39:35 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:39:35 --> Encrypt Class Initialized
INFO - 2022-03-17 01:39:35 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:39:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:39:35 --> Model "Referredby_model" initialized
INFO - 2022-03-17 01:39:35 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:39:35 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:39:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 01:39:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 01:39:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 01:39:35 --> Final output sent to browser
DEBUG - 2022-03-17 01:39:35 --> Total execution time: 0.0679
ERROR - 2022-03-17 01:39:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:39:53 --> Config Class Initialized
INFO - 2022-03-17 01:39:53 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:39:53 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:39:53 --> Utf8 Class Initialized
INFO - 2022-03-17 01:39:53 --> URI Class Initialized
INFO - 2022-03-17 01:39:53 --> Router Class Initialized
INFO - 2022-03-17 01:39:53 --> Output Class Initialized
INFO - 2022-03-17 01:39:53 --> Security Class Initialized
DEBUG - 2022-03-17 01:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:39:53 --> Input Class Initialized
INFO - 2022-03-17 01:39:53 --> Language Class Initialized
INFO - 2022-03-17 01:39:53 --> Loader Class Initialized
INFO - 2022-03-17 01:39:53 --> Helper loaded: url_helper
INFO - 2022-03-17 01:39:53 --> Helper loaded: form_helper
INFO - 2022-03-17 01:39:53 --> Helper loaded: common_helper
INFO - 2022-03-17 01:39:53 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:39:53 --> Controller Class Initialized
INFO - 2022-03-17 01:39:53 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:39:53 --> Encrypt Class Initialized
INFO - 2022-03-17 01:39:53 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:39:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:39:53 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:39:53 --> Model "Users_model" initialized
INFO - 2022-03-17 01:39:53 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:39:53 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 01:39:54 --> Final output sent to browser
DEBUG - 2022-03-17 01:39:54 --> Total execution time: 1.8536
ERROR - 2022-03-17 01:49:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:49:16 --> Config Class Initialized
INFO - 2022-03-17 01:49:16 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:49:16 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:49:16 --> Utf8 Class Initialized
INFO - 2022-03-17 01:49:16 --> URI Class Initialized
INFO - 2022-03-17 01:49:16 --> Router Class Initialized
INFO - 2022-03-17 01:49:16 --> Output Class Initialized
INFO - 2022-03-17 01:49:16 --> Security Class Initialized
DEBUG - 2022-03-17 01:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:49:16 --> Input Class Initialized
INFO - 2022-03-17 01:49:16 --> Language Class Initialized
INFO - 2022-03-17 01:49:16 --> Loader Class Initialized
INFO - 2022-03-17 01:49:16 --> Helper loaded: url_helper
INFO - 2022-03-17 01:49:16 --> Helper loaded: form_helper
INFO - 2022-03-17 01:49:16 --> Helper loaded: common_helper
INFO - 2022-03-17 01:49:16 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:49:16 --> Controller Class Initialized
INFO - 2022-03-17 01:49:16 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:49:16 --> Encrypt Class Initialized
INFO - 2022-03-17 01:49:16 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:49:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:49:16 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:49:16 --> Model "Users_model" initialized
INFO - 2022-03-17 01:49:16 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:49:17 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 01:49:17 --> Final output sent to browser
DEBUG - 2022-03-17 01:49:17 --> Total execution time: 0.9928
ERROR - 2022-03-17 01:57:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 01:57:22 --> Config Class Initialized
INFO - 2022-03-17 01:57:22 --> Hooks Class Initialized
DEBUG - 2022-03-17 01:57:22 --> UTF-8 Support Enabled
INFO - 2022-03-17 01:57:22 --> Utf8 Class Initialized
INFO - 2022-03-17 01:57:22 --> URI Class Initialized
INFO - 2022-03-17 01:57:22 --> Router Class Initialized
INFO - 2022-03-17 01:57:22 --> Output Class Initialized
INFO - 2022-03-17 01:57:22 --> Security Class Initialized
DEBUG - 2022-03-17 01:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 01:57:22 --> Input Class Initialized
INFO - 2022-03-17 01:57:22 --> Language Class Initialized
INFO - 2022-03-17 01:57:22 --> Loader Class Initialized
INFO - 2022-03-17 01:57:22 --> Helper loaded: url_helper
INFO - 2022-03-17 01:57:22 --> Helper loaded: form_helper
INFO - 2022-03-17 01:57:22 --> Helper loaded: common_helper
INFO - 2022-03-17 01:57:22 --> Database Driver Class Initialized
DEBUG - 2022-03-17 01:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 01:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 01:57:22 --> Controller Class Initialized
INFO - 2022-03-17 01:57:22 --> Form Validation Class Initialized
DEBUG - 2022-03-17 01:57:22 --> Encrypt Class Initialized
INFO - 2022-03-17 01:57:22 --> Model "Patient_model" initialized
INFO - 2022-03-17 01:57:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 01:57:22 --> Model "Prefix_master" initialized
INFO - 2022-03-17 01:57:22 --> Model "Users_model" initialized
INFO - 2022-03-17 01:57:22 --> Model "Hospital_model" initialized
INFO - 2022-03-17 01:57:22 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 01:57:23 --> Final output sent to browser
DEBUG - 2022-03-17 01:57:23 --> Total execution time: 0.7900
ERROR - 2022-03-17 02:09:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:09:25 --> Config Class Initialized
INFO - 2022-03-17 02:09:25 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:09:25 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:09:25 --> Utf8 Class Initialized
INFO - 2022-03-17 02:09:25 --> URI Class Initialized
INFO - 2022-03-17 02:09:25 --> Router Class Initialized
INFO - 2022-03-17 02:09:25 --> Output Class Initialized
INFO - 2022-03-17 02:09:25 --> Security Class Initialized
DEBUG - 2022-03-17 02:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:09:25 --> Input Class Initialized
INFO - 2022-03-17 02:09:25 --> Language Class Initialized
INFO - 2022-03-17 02:09:25 --> Loader Class Initialized
INFO - 2022-03-17 02:09:25 --> Helper loaded: url_helper
INFO - 2022-03-17 02:09:25 --> Helper loaded: form_helper
INFO - 2022-03-17 02:09:25 --> Helper loaded: common_helper
INFO - 2022-03-17 02:09:25 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:09:25 --> Controller Class Initialized
INFO - 2022-03-17 02:09:25 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:09:25 --> Encrypt Class Initialized
INFO - 2022-03-17 02:09:25 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:09:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:09:25 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:09:25 --> Model "Users_model" initialized
INFO - 2022-03-17 02:09:25 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:09:25 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 02:09:26 --> Final output sent to browser
DEBUG - 2022-03-17 02:09:26 --> Total execution time: 0.9284
ERROR - 2022-03-17 02:10:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:10:25 --> Config Class Initialized
INFO - 2022-03-17 02:10:25 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:10:25 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:10:25 --> Utf8 Class Initialized
INFO - 2022-03-17 02:10:25 --> URI Class Initialized
INFO - 2022-03-17 02:10:25 --> Router Class Initialized
INFO - 2022-03-17 02:10:25 --> Output Class Initialized
INFO - 2022-03-17 02:10:25 --> Security Class Initialized
DEBUG - 2022-03-17 02:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:10:25 --> Input Class Initialized
INFO - 2022-03-17 02:10:25 --> Language Class Initialized
INFO - 2022-03-17 02:10:25 --> Loader Class Initialized
INFO - 2022-03-17 02:10:25 --> Helper loaded: url_helper
INFO - 2022-03-17 02:10:25 --> Helper loaded: form_helper
INFO - 2022-03-17 02:10:25 --> Helper loaded: common_helper
INFO - 2022-03-17 02:10:25 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:10:25 --> Controller Class Initialized
INFO - 2022-03-17 02:10:25 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:10:25 --> Encrypt Class Initialized
INFO - 2022-03-17 02:10:25 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:10:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:10:25 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:10:25 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:10:25 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:10:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:10:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 02:10:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:10:25 --> Final output sent to browser
DEBUG - 2022-03-17 02:10:25 --> Total execution time: 0.0706
ERROR - 2022-03-17 02:10:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:10:35 --> Config Class Initialized
INFO - 2022-03-17 02:10:35 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:10:35 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:10:35 --> Utf8 Class Initialized
INFO - 2022-03-17 02:10:35 --> URI Class Initialized
INFO - 2022-03-17 02:10:35 --> Router Class Initialized
INFO - 2022-03-17 02:10:35 --> Output Class Initialized
INFO - 2022-03-17 02:10:35 --> Security Class Initialized
DEBUG - 2022-03-17 02:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:10:35 --> Input Class Initialized
INFO - 2022-03-17 02:10:35 --> Language Class Initialized
INFO - 2022-03-17 02:10:35 --> Loader Class Initialized
INFO - 2022-03-17 02:10:35 --> Helper loaded: url_helper
INFO - 2022-03-17 02:10:35 --> Helper loaded: form_helper
INFO - 2022-03-17 02:10:35 --> Helper loaded: common_helper
INFO - 2022-03-17 02:10:35 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:10:35 --> Controller Class Initialized
INFO - 2022-03-17 02:10:35 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:10:35 --> Final output sent to browser
DEBUG - 2022-03-17 02:10:35 --> Total execution time: 0.0243
ERROR - 2022-03-17 02:10:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:10:39 --> Config Class Initialized
INFO - 2022-03-17 02:10:39 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:10:39 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:10:39 --> Utf8 Class Initialized
INFO - 2022-03-17 02:10:39 --> URI Class Initialized
INFO - 2022-03-17 02:10:39 --> Router Class Initialized
INFO - 2022-03-17 02:10:39 --> Output Class Initialized
INFO - 2022-03-17 02:10:39 --> Security Class Initialized
DEBUG - 2022-03-17 02:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:10:39 --> Input Class Initialized
INFO - 2022-03-17 02:10:39 --> Language Class Initialized
INFO - 2022-03-17 02:10:39 --> Loader Class Initialized
INFO - 2022-03-17 02:10:39 --> Helper loaded: url_helper
INFO - 2022-03-17 02:10:39 --> Helper loaded: form_helper
INFO - 2022-03-17 02:10:39 --> Helper loaded: common_helper
INFO - 2022-03-17 02:10:39 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:10:39 --> Controller Class Initialized
INFO - 2022-03-17 02:10:39 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:10:39 --> Encrypt Class Initialized
INFO - 2022-03-17 02:10:39 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:10:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:10:39 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:10:39 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:10:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 02:10:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:10:39 --> Config Class Initialized
INFO - 2022-03-17 02:10:39 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:10:39 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:10:39 --> Utf8 Class Initialized
INFO - 2022-03-17 02:10:39 --> URI Class Initialized
INFO - 2022-03-17 02:10:39 --> Router Class Initialized
INFO - 2022-03-17 02:10:39 --> Output Class Initialized
INFO - 2022-03-17 02:10:39 --> Security Class Initialized
DEBUG - 2022-03-17 02:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:10:39 --> Input Class Initialized
INFO - 2022-03-17 02:10:39 --> Language Class Initialized
INFO - 2022-03-17 02:10:39 --> Loader Class Initialized
INFO - 2022-03-17 02:10:39 --> Helper loaded: url_helper
INFO - 2022-03-17 02:10:39 --> Helper loaded: form_helper
INFO - 2022-03-17 02:10:39 --> Helper loaded: common_helper
INFO - 2022-03-17 02:10:39 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:10:39 --> Controller Class Initialized
INFO - 2022-03-17 02:10:39 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:10:39 --> Encrypt Class Initialized
INFO - 2022-03-17 02:10:39 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:10:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:10:39 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:10:39 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:10:39 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:10:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:10:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 02:10:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:10:39 --> Final output sent to browser
DEBUG - 2022-03-17 02:10:39 --> Total execution time: 0.0661
ERROR - 2022-03-17 02:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:10:40 --> Config Class Initialized
INFO - 2022-03-17 02:10:40 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:10:40 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:10:40 --> Utf8 Class Initialized
INFO - 2022-03-17 02:10:40 --> URI Class Initialized
INFO - 2022-03-17 02:10:40 --> Router Class Initialized
INFO - 2022-03-17 02:10:40 --> Output Class Initialized
INFO - 2022-03-17 02:10:40 --> Security Class Initialized
DEBUG - 2022-03-17 02:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:10:40 --> Input Class Initialized
INFO - 2022-03-17 02:10:40 --> Language Class Initialized
INFO - 2022-03-17 02:10:40 --> Loader Class Initialized
INFO - 2022-03-17 02:10:40 --> Helper loaded: url_helper
INFO - 2022-03-17 02:10:40 --> Helper loaded: form_helper
INFO - 2022-03-17 02:10:40 --> Helper loaded: common_helper
INFO - 2022-03-17 02:10:40 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:10:40 --> Controller Class Initialized
INFO - 2022-03-17 02:10:40 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:10:40 --> Encrypt Class Initialized
INFO - 2022-03-17 02:10:40 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:10:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:10:40 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:10:40 --> Model "Users_model" initialized
INFO - 2022-03-17 02:10:40 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:10:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:10:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 02:10:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:10:41 --> Final output sent to browser
DEBUG - 2022-03-17 02:10:41 --> Total execution time: 0.1365
ERROR - 2022-03-17 02:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:11:03 --> Config Class Initialized
INFO - 2022-03-17 02:11:03 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:11:03 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:11:03 --> Utf8 Class Initialized
INFO - 2022-03-17 02:11:03 --> URI Class Initialized
INFO - 2022-03-17 02:11:03 --> Router Class Initialized
INFO - 2022-03-17 02:11:03 --> Output Class Initialized
INFO - 2022-03-17 02:11:03 --> Security Class Initialized
DEBUG - 2022-03-17 02:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:11:03 --> Input Class Initialized
INFO - 2022-03-17 02:11:03 --> Language Class Initialized
INFO - 2022-03-17 02:11:03 --> Loader Class Initialized
INFO - 2022-03-17 02:11:03 --> Helper loaded: url_helper
INFO - 2022-03-17 02:11:03 --> Helper loaded: form_helper
INFO - 2022-03-17 02:11:03 --> Helper loaded: common_helper
INFO - 2022-03-17 02:11:03 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:11:03 --> Controller Class Initialized
INFO - 2022-03-17 02:11:03 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:11:03 --> Encrypt Class Initialized
INFO - 2022-03-17 02:11:03 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:11:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:11:03 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:11:03 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:11:03 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:11:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:11:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 02:11:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:11:03 --> Final output sent to browser
DEBUG - 2022-03-17 02:11:03 --> Total execution time: 0.0662
ERROR - 2022-03-17 02:11:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:11:13 --> Config Class Initialized
INFO - 2022-03-17 02:11:13 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:11:13 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:11:13 --> Utf8 Class Initialized
INFO - 2022-03-17 02:11:13 --> URI Class Initialized
INFO - 2022-03-17 02:11:13 --> Router Class Initialized
INFO - 2022-03-17 02:11:13 --> Output Class Initialized
INFO - 2022-03-17 02:11:13 --> Security Class Initialized
DEBUG - 2022-03-17 02:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:11:13 --> Input Class Initialized
INFO - 2022-03-17 02:11:13 --> Language Class Initialized
INFO - 2022-03-17 02:11:13 --> Loader Class Initialized
INFO - 2022-03-17 02:11:13 --> Helper loaded: url_helper
INFO - 2022-03-17 02:11:13 --> Helper loaded: form_helper
INFO - 2022-03-17 02:11:13 --> Helper loaded: common_helper
INFO - 2022-03-17 02:11:13 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:11:13 --> Controller Class Initialized
INFO - 2022-03-17 02:11:13 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:11:13 --> Encrypt Class Initialized
INFO - 2022-03-17 02:11:13 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:11:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:11:13 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:11:13 --> Model "Users_model" initialized
INFO - 2022-03-17 02:11:13 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:11:13 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 02:11:13 --> Final output sent to browser
DEBUG - 2022-03-17 02:11:13 --> Total execution time: 0.7936
ERROR - 2022-03-17 02:19:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:19:10 --> Config Class Initialized
INFO - 2022-03-17 02:19:10 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:19:10 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:19:10 --> Utf8 Class Initialized
INFO - 2022-03-17 02:19:10 --> URI Class Initialized
INFO - 2022-03-17 02:19:10 --> Router Class Initialized
INFO - 2022-03-17 02:19:10 --> Output Class Initialized
INFO - 2022-03-17 02:19:10 --> Security Class Initialized
DEBUG - 2022-03-17 02:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:19:10 --> Input Class Initialized
INFO - 2022-03-17 02:19:10 --> Language Class Initialized
INFO - 2022-03-17 02:19:10 --> Loader Class Initialized
INFO - 2022-03-17 02:19:10 --> Helper loaded: url_helper
INFO - 2022-03-17 02:19:10 --> Helper loaded: form_helper
INFO - 2022-03-17 02:19:10 --> Helper loaded: common_helper
INFO - 2022-03-17 02:19:10 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:19:10 --> Controller Class Initialized
INFO - 2022-03-17 02:19:10 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:19:10 --> Encrypt Class Initialized
INFO - 2022-03-17 02:19:10 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:19:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:19:10 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:19:10 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:19:10 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:19:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:19:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 02:19:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:19:10 --> Final output sent to browser
DEBUG - 2022-03-17 02:19:10 --> Total execution time: 0.1794
ERROR - 2022-03-17 02:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:20:26 --> Config Class Initialized
INFO - 2022-03-17 02:20:26 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:20:26 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:20:26 --> Utf8 Class Initialized
INFO - 2022-03-17 02:20:26 --> URI Class Initialized
INFO - 2022-03-17 02:20:26 --> Router Class Initialized
INFO - 2022-03-17 02:20:26 --> Output Class Initialized
INFO - 2022-03-17 02:20:26 --> Security Class Initialized
DEBUG - 2022-03-17 02:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:20:26 --> Input Class Initialized
INFO - 2022-03-17 02:20:26 --> Language Class Initialized
INFO - 2022-03-17 02:20:26 --> Loader Class Initialized
INFO - 2022-03-17 02:20:26 --> Helper loaded: url_helper
INFO - 2022-03-17 02:20:26 --> Helper loaded: form_helper
INFO - 2022-03-17 02:20:26 --> Helper loaded: common_helper
INFO - 2022-03-17 02:20:26 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:20:26 --> Controller Class Initialized
INFO - 2022-03-17 02:20:26 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:20:26 --> Encrypt Class Initialized
INFO - 2022-03-17 02:20:26 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:20:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:20:26 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:20:26 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:20:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 02:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:20:27 --> Config Class Initialized
INFO - 2022-03-17 02:20:27 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:20:27 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:20:27 --> Utf8 Class Initialized
INFO - 2022-03-17 02:20:27 --> URI Class Initialized
INFO - 2022-03-17 02:20:27 --> Router Class Initialized
INFO - 2022-03-17 02:20:27 --> Output Class Initialized
INFO - 2022-03-17 02:20:27 --> Security Class Initialized
DEBUG - 2022-03-17 02:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:20:27 --> Input Class Initialized
INFO - 2022-03-17 02:20:27 --> Language Class Initialized
INFO - 2022-03-17 02:20:27 --> Loader Class Initialized
INFO - 2022-03-17 02:20:27 --> Helper loaded: url_helper
INFO - 2022-03-17 02:20:27 --> Helper loaded: form_helper
INFO - 2022-03-17 02:20:27 --> Helper loaded: common_helper
INFO - 2022-03-17 02:20:27 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:20:27 --> Controller Class Initialized
INFO - 2022-03-17 02:20:27 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:20:27 --> Encrypt Class Initialized
INFO - 2022-03-17 02:20:27 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:20:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:20:27 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:20:27 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:20:27 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:20:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:20:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 02:20:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:20:27 --> Final output sent to browser
DEBUG - 2022-03-17 02:20:27 --> Total execution time: 0.0669
ERROR - 2022-03-17 02:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:20:28 --> Config Class Initialized
INFO - 2022-03-17 02:20:28 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:20:28 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:20:28 --> Utf8 Class Initialized
INFO - 2022-03-17 02:20:28 --> URI Class Initialized
INFO - 2022-03-17 02:20:28 --> Router Class Initialized
INFO - 2022-03-17 02:20:28 --> Output Class Initialized
INFO - 2022-03-17 02:20:28 --> Security Class Initialized
DEBUG - 2022-03-17 02:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:20:28 --> Input Class Initialized
INFO - 2022-03-17 02:20:28 --> Language Class Initialized
INFO - 2022-03-17 02:20:28 --> Loader Class Initialized
INFO - 2022-03-17 02:20:28 --> Helper loaded: url_helper
INFO - 2022-03-17 02:20:28 --> Helper loaded: form_helper
INFO - 2022-03-17 02:20:28 --> Helper loaded: common_helper
INFO - 2022-03-17 02:20:28 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:20:28 --> Controller Class Initialized
INFO - 2022-03-17 02:20:28 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:20:28 --> Encrypt Class Initialized
INFO - 2022-03-17 02:20:28 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:20:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:20:28 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:20:28 --> Model "Users_model" initialized
INFO - 2022-03-17 02:20:28 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:20:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:20:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 02:20:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:20:28 --> Final output sent to browser
DEBUG - 2022-03-17 02:20:28 --> Total execution time: 0.2686
ERROR - 2022-03-17 02:22:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:22:43 --> Config Class Initialized
INFO - 2022-03-17 02:22:43 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:22:43 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:22:43 --> Utf8 Class Initialized
INFO - 2022-03-17 02:22:43 --> URI Class Initialized
INFO - 2022-03-17 02:22:43 --> Router Class Initialized
INFO - 2022-03-17 02:22:43 --> Output Class Initialized
INFO - 2022-03-17 02:22:43 --> Security Class Initialized
DEBUG - 2022-03-17 02:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:22:43 --> Input Class Initialized
INFO - 2022-03-17 02:22:43 --> Language Class Initialized
INFO - 2022-03-17 02:22:43 --> Loader Class Initialized
INFO - 2022-03-17 02:22:43 --> Helper loaded: url_helper
INFO - 2022-03-17 02:22:43 --> Helper loaded: form_helper
INFO - 2022-03-17 02:22:43 --> Helper loaded: common_helper
INFO - 2022-03-17 02:22:43 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:22:43 --> Controller Class Initialized
INFO - 2022-03-17 02:22:43 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:22:43 --> Encrypt Class Initialized
INFO - 2022-03-17 02:22:43 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:22:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:22:43 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:22:43 --> Model "Users_model" initialized
INFO - 2022-03-17 02:22:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 02:22:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:22:44 --> Config Class Initialized
INFO - 2022-03-17 02:22:44 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:22:44 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:22:44 --> Utf8 Class Initialized
INFO - 2022-03-17 02:22:44 --> URI Class Initialized
INFO - 2022-03-17 02:22:44 --> Router Class Initialized
INFO - 2022-03-17 02:22:44 --> Output Class Initialized
INFO - 2022-03-17 02:22:44 --> Security Class Initialized
DEBUG - 2022-03-17 02:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:22:44 --> Input Class Initialized
INFO - 2022-03-17 02:22:44 --> Language Class Initialized
INFO - 2022-03-17 02:22:44 --> Loader Class Initialized
INFO - 2022-03-17 02:22:44 --> Helper loaded: url_helper
INFO - 2022-03-17 02:22:44 --> Helper loaded: form_helper
INFO - 2022-03-17 02:22:44 --> Helper loaded: common_helper
INFO - 2022-03-17 02:22:44 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:22:44 --> Controller Class Initialized
INFO - 2022-03-17 02:22:44 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:22:44 --> Encrypt Class Initialized
INFO - 2022-03-17 02:22:44 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:22:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:22:44 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:22:44 --> Model "Users_model" initialized
INFO - 2022-03-17 02:22:44 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:22:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:22:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 02:22:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:22:44 --> Final output sent to browser
DEBUG - 2022-03-17 02:22:44 --> Total execution time: 0.0717
ERROR - 2022-03-17 02:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:23:36 --> Config Class Initialized
INFO - 2022-03-17 02:23:36 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:23:36 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:23:36 --> Utf8 Class Initialized
INFO - 2022-03-17 02:23:36 --> URI Class Initialized
INFO - 2022-03-17 02:23:36 --> Router Class Initialized
INFO - 2022-03-17 02:23:36 --> Output Class Initialized
INFO - 2022-03-17 02:23:36 --> Security Class Initialized
DEBUG - 2022-03-17 02:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:23:36 --> Input Class Initialized
INFO - 2022-03-17 02:23:36 --> Language Class Initialized
INFO - 2022-03-17 02:23:36 --> Loader Class Initialized
INFO - 2022-03-17 02:23:36 --> Helper loaded: url_helper
INFO - 2022-03-17 02:23:36 --> Helper loaded: form_helper
INFO - 2022-03-17 02:23:36 --> Helper loaded: common_helper
INFO - 2022-03-17 02:23:36 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:23:36 --> Controller Class Initialized
INFO - 2022-03-17 02:23:36 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:23:36 --> Encrypt Class Initialized
INFO - 2022-03-17 02:23:36 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:23:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:23:36 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:23:36 --> Model "Users_model" initialized
INFO - 2022-03-17 02:23:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 02:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:23:37 --> Config Class Initialized
INFO - 2022-03-17 02:23:37 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:23:37 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:23:37 --> Utf8 Class Initialized
INFO - 2022-03-17 02:23:37 --> URI Class Initialized
INFO - 2022-03-17 02:23:37 --> Router Class Initialized
INFO - 2022-03-17 02:23:37 --> Output Class Initialized
INFO - 2022-03-17 02:23:37 --> Security Class Initialized
DEBUG - 2022-03-17 02:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:23:37 --> Input Class Initialized
INFO - 2022-03-17 02:23:37 --> Language Class Initialized
INFO - 2022-03-17 02:23:37 --> Loader Class Initialized
INFO - 2022-03-17 02:23:37 --> Helper loaded: url_helper
INFO - 2022-03-17 02:23:37 --> Helper loaded: form_helper
INFO - 2022-03-17 02:23:37 --> Helper loaded: common_helper
INFO - 2022-03-17 02:23:37 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:23:37 --> Controller Class Initialized
INFO - 2022-03-17 02:23:37 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:23:37 --> Encrypt Class Initialized
INFO - 2022-03-17 02:23:37 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:23:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:23:37 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:23:37 --> Model "Users_model" initialized
INFO - 2022-03-17 02:23:37 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:23:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:23:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 02:23:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:23:37 --> Final output sent to browser
DEBUG - 2022-03-17 02:23:37 --> Total execution time: 0.0585
ERROR - 2022-03-17 02:24:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:24:07 --> Config Class Initialized
INFO - 2022-03-17 02:24:07 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:24:07 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:24:07 --> Utf8 Class Initialized
INFO - 2022-03-17 02:24:07 --> URI Class Initialized
INFO - 2022-03-17 02:24:07 --> Router Class Initialized
INFO - 2022-03-17 02:24:07 --> Output Class Initialized
INFO - 2022-03-17 02:24:07 --> Security Class Initialized
DEBUG - 2022-03-17 02:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:24:07 --> Input Class Initialized
INFO - 2022-03-17 02:24:07 --> Language Class Initialized
INFO - 2022-03-17 02:24:07 --> Loader Class Initialized
INFO - 2022-03-17 02:24:07 --> Helper loaded: url_helper
INFO - 2022-03-17 02:24:07 --> Helper loaded: form_helper
INFO - 2022-03-17 02:24:07 --> Helper loaded: common_helper
INFO - 2022-03-17 02:24:07 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:24:07 --> Controller Class Initialized
INFO - 2022-03-17 02:24:07 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:24:07 --> Encrypt Class Initialized
INFO - 2022-03-17 02:24:07 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:24:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:24:07 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:24:07 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:24:07 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:24:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:24:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 02:24:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:24:07 --> Final output sent to browser
DEBUG - 2022-03-17 02:24:07 --> Total execution time: 0.0748
ERROR - 2022-03-17 02:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:24:23 --> Config Class Initialized
INFO - 2022-03-17 02:24:23 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:24:23 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:24:23 --> Utf8 Class Initialized
INFO - 2022-03-17 02:24:23 --> URI Class Initialized
INFO - 2022-03-17 02:24:23 --> Router Class Initialized
INFO - 2022-03-17 02:24:23 --> Output Class Initialized
INFO - 2022-03-17 02:24:23 --> Security Class Initialized
DEBUG - 2022-03-17 02:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:24:23 --> Input Class Initialized
INFO - 2022-03-17 02:24:23 --> Language Class Initialized
INFO - 2022-03-17 02:24:23 --> Loader Class Initialized
INFO - 2022-03-17 02:24:23 --> Helper loaded: url_helper
INFO - 2022-03-17 02:24:23 --> Helper loaded: form_helper
INFO - 2022-03-17 02:24:23 --> Helper loaded: common_helper
INFO - 2022-03-17 02:24:23 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:24:23 --> Controller Class Initialized
INFO - 2022-03-17 02:24:23 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:24:23 --> Encrypt Class Initialized
INFO - 2022-03-17 02:24:23 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:24:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:24:23 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:24:23 --> Model "Users_model" initialized
INFO - 2022-03-17 02:24:23 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:24:23 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 02:24:24 --> Final output sent to browser
DEBUG - 2022-03-17 02:24:24 --> Total execution time: 1.2189
ERROR - 2022-03-17 02:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:27:35 --> Config Class Initialized
INFO - 2022-03-17 02:27:35 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:27:35 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:27:35 --> Utf8 Class Initialized
INFO - 2022-03-17 02:27:35 --> URI Class Initialized
INFO - 2022-03-17 02:27:35 --> Router Class Initialized
INFO - 2022-03-17 02:27:35 --> Output Class Initialized
INFO - 2022-03-17 02:27:35 --> Security Class Initialized
DEBUG - 2022-03-17 02:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:27:35 --> Input Class Initialized
INFO - 2022-03-17 02:27:35 --> Language Class Initialized
INFO - 2022-03-17 02:27:35 --> Loader Class Initialized
INFO - 2022-03-17 02:27:35 --> Helper loaded: url_helper
INFO - 2022-03-17 02:27:35 --> Helper loaded: form_helper
INFO - 2022-03-17 02:27:35 --> Helper loaded: common_helper
INFO - 2022-03-17 02:27:35 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:27:35 --> Controller Class Initialized
INFO - 2022-03-17 02:27:35 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:27:35 --> Encrypt Class Initialized
INFO - 2022-03-17 02:27:35 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:27:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:27:35 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:27:35 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:27:35 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:27:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:27:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 02:27:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:27:35 --> Final output sent to browser
DEBUG - 2022-03-17 02:27:35 --> Total execution time: 0.0829
ERROR - 2022-03-17 02:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:27:42 --> Config Class Initialized
INFO - 2022-03-17 02:27:42 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:27:42 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:27:42 --> Utf8 Class Initialized
INFO - 2022-03-17 02:27:42 --> URI Class Initialized
INFO - 2022-03-17 02:27:42 --> Router Class Initialized
INFO - 2022-03-17 02:27:42 --> Output Class Initialized
INFO - 2022-03-17 02:27:42 --> Security Class Initialized
DEBUG - 2022-03-17 02:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:27:42 --> Input Class Initialized
INFO - 2022-03-17 02:27:42 --> Language Class Initialized
INFO - 2022-03-17 02:27:42 --> Loader Class Initialized
INFO - 2022-03-17 02:27:42 --> Helper loaded: url_helper
INFO - 2022-03-17 02:27:42 --> Helper loaded: form_helper
INFO - 2022-03-17 02:27:42 --> Helper loaded: common_helper
INFO - 2022-03-17 02:27:42 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:27:42 --> Controller Class Initialized
INFO - 2022-03-17 02:27:42 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:27:42 --> Encrypt Class Initialized
INFO - 2022-03-17 02:27:42 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:27:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:27:42 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:27:42 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:27:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 02:27:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:27:43 --> Config Class Initialized
INFO - 2022-03-17 02:27:43 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:27:43 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:27:43 --> Utf8 Class Initialized
INFO - 2022-03-17 02:27:43 --> URI Class Initialized
INFO - 2022-03-17 02:27:43 --> Router Class Initialized
INFO - 2022-03-17 02:27:43 --> Output Class Initialized
INFO - 2022-03-17 02:27:43 --> Security Class Initialized
DEBUG - 2022-03-17 02:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:27:43 --> Input Class Initialized
INFO - 2022-03-17 02:27:43 --> Language Class Initialized
INFO - 2022-03-17 02:27:43 --> Loader Class Initialized
INFO - 2022-03-17 02:27:43 --> Helper loaded: url_helper
INFO - 2022-03-17 02:27:43 --> Helper loaded: form_helper
INFO - 2022-03-17 02:27:43 --> Helper loaded: common_helper
INFO - 2022-03-17 02:27:43 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:27:43 --> Controller Class Initialized
INFO - 2022-03-17 02:27:43 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:27:43 --> Encrypt Class Initialized
INFO - 2022-03-17 02:27:43 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:27:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:27:43 --> Model "Referredby_model" initialized
INFO - 2022-03-17 02:27:43 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:27:43 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:27:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:27:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 02:27:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:27:43 --> Final output sent to browser
DEBUG - 2022-03-17 02:27:43 --> Total execution time: 0.0592
ERROR - 2022-03-17 02:27:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:27:44 --> Config Class Initialized
INFO - 2022-03-17 02:27:44 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:27:44 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:27:44 --> Utf8 Class Initialized
INFO - 2022-03-17 02:27:44 --> URI Class Initialized
INFO - 2022-03-17 02:27:44 --> Router Class Initialized
INFO - 2022-03-17 02:27:44 --> Output Class Initialized
INFO - 2022-03-17 02:27:44 --> Security Class Initialized
DEBUG - 2022-03-17 02:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:27:44 --> Input Class Initialized
INFO - 2022-03-17 02:27:44 --> Language Class Initialized
INFO - 2022-03-17 02:27:44 --> Loader Class Initialized
INFO - 2022-03-17 02:27:44 --> Helper loaded: url_helper
INFO - 2022-03-17 02:27:44 --> Helper loaded: form_helper
INFO - 2022-03-17 02:27:44 --> Helper loaded: common_helper
INFO - 2022-03-17 02:27:44 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:27:44 --> Controller Class Initialized
INFO - 2022-03-17 02:27:44 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:27:44 --> Encrypt Class Initialized
INFO - 2022-03-17 02:27:44 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:27:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:27:44 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:27:44 --> Model "Users_model" initialized
INFO - 2022-03-17 02:27:44 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:27:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:27:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 02:27:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:27:44 --> Final output sent to browser
DEBUG - 2022-03-17 02:27:44 --> Total execution time: 0.1407
ERROR - 2022-03-17 02:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:30:18 --> Config Class Initialized
INFO - 2022-03-17 02:30:18 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:30:18 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:30:18 --> Utf8 Class Initialized
INFO - 2022-03-17 02:30:18 --> URI Class Initialized
INFO - 2022-03-17 02:30:18 --> Router Class Initialized
INFO - 2022-03-17 02:30:18 --> Output Class Initialized
INFO - 2022-03-17 02:30:18 --> Security Class Initialized
DEBUG - 2022-03-17 02:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:30:18 --> Input Class Initialized
INFO - 2022-03-17 02:30:18 --> Language Class Initialized
INFO - 2022-03-17 02:30:18 --> Loader Class Initialized
INFO - 2022-03-17 02:30:18 --> Helper loaded: url_helper
INFO - 2022-03-17 02:30:18 --> Helper loaded: form_helper
INFO - 2022-03-17 02:30:18 --> Helper loaded: common_helper
INFO - 2022-03-17 02:30:18 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:30:18 --> Controller Class Initialized
INFO - 2022-03-17 02:30:18 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:30:18 --> Encrypt Class Initialized
INFO - 2022-03-17 02:30:18 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:30:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:30:18 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:30:18 --> Model "Users_model" initialized
INFO - 2022-03-17 02:30:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 02:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:30:19 --> Config Class Initialized
INFO - 2022-03-17 02:30:19 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:30:19 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:30:19 --> Utf8 Class Initialized
INFO - 2022-03-17 02:30:19 --> URI Class Initialized
INFO - 2022-03-17 02:30:19 --> Router Class Initialized
INFO - 2022-03-17 02:30:19 --> Output Class Initialized
INFO - 2022-03-17 02:30:19 --> Security Class Initialized
DEBUG - 2022-03-17 02:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:30:19 --> Input Class Initialized
INFO - 2022-03-17 02:30:19 --> Language Class Initialized
INFO - 2022-03-17 02:30:19 --> Loader Class Initialized
INFO - 2022-03-17 02:30:19 --> Helper loaded: url_helper
INFO - 2022-03-17 02:30:19 --> Helper loaded: form_helper
INFO - 2022-03-17 02:30:19 --> Helper loaded: common_helper
INFO - 2022-03-17 02:30:19 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:30:19 --> Controller Class Initialized
INFO - 2022-03-17 02:30:19 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:30:19 --> Encrypt Class Initialized
INFO - 2022-03-17 02:30:19 --> Model "Patient_model" initialized
INFO - 2022-03-17 02:30:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 02:30:19 --> Model "Prefix_master" initialized
INFO - 2022-03-17 02:30:19 --> Model "Users_model" initialized
INFO - 2022-03-17 02:30:19 --> Model "Hospital_model" initialized
INFO - 2022-03-17 02:30:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 02:30:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 02:30:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 02:30:19 --> Final output sent to browser
DEBUG - 2022-03-17 02:30:19 --> Total execution time: 0.0563
ERROR - 2022-03-17 02:36:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 02:36:13 --> Config Class Initialized
INFO - 2022-03-17 02:36:13 --> Hooks Class Initialized
DEBUG - 2022-03-17 02:36:13 --> UTF-8 Support Enabled
INFO - 2022-03-17 02:36:13 --> Utf8 Class Initialized
INFO - 2022-03-17 02:36:13 --> URI Class Initialized
DEBUG - 2022-03-17 02:36:13 --> No URI present. Default controller set.
INFO - 2022-03-17 02:36:13 --> Router Class Initialized
INFO - 2022-03-17 02:36:13 --> Output Class Initialized
INFO - 2022-03-17 02:36:13 --> Security Class Initialized
DEBUG - 2022-03-17 02:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 02:36:13 --> Input Class Initialized
INFO - 2022-03-17 02:36:13 --> Language Class Initialized
INFO - 2022-03-17 02:36:13 --> Loader Class Initialized
INFO - 2022-03-17 02:36:13 --> Helper loaded: url_helper
INFO - 2022-03-17 02:36:13 --> Helper loaded: form_helper
INFO - 2022-03-17 02:36:13 --> Helper loaded: common_helper
INFO - 2022-03-17 02:36:13 --> Database Driver Class Initialized
DEBUG - 2022-03-17 02:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 02:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 02:36:13 --> Controller Class Initialized
INFO - 2022-03-17 02:36:13 --> Form Validation Class Initialized
DEBUG - 2022-03-17 02:36:13 --> Encrypt Class Initialized
DEBUG - 2022-03-17 02:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 02:36:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 02:36:13 --> Email Class Initialized
INFO - 2022-03-17 02:36:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 02:36:13 --> Calendar Class Initialized
INFO - 2022-03-17 02:36:13 --> Model "Login_model" initialized
INFO - 2022-03-17 02:36:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 02:36:13 --> Final output sent to browser
DEBUG - 2022-03-17 02:36:13 --> Total execution time: 0.0309
ERROR - 2022-03-17 03:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:55:23 --> Config Class Initialized
INFO - 2022-03-17 03:55:23 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:55:23 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:55:23 --> Utf8 Class Initialized
INFO - 2022-03-17 03:55:23 --> URI Class Initialized
INFO - 2022-03-17 03:55:23 --> Router Class Initialized
INFO - 2022-03-17 03:55:23 --> Output Class Initialized
INFO - 2022-03-17 03:55:23 --> Security Class Initialized
DEBUG - 2022-03-17 03:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:55:23 --> Input Class Initialized
INFO - 2022-03-17 03:55:23 --> Language Class Initialized
INFO - 2022-03-17 03:55:23 --> Loader Class Initialized
INFO - 2022-03-17 03:55:23 --> Helper loaded: url_helper
INFO - 2022-03-17 03:55:23 --> Helper loaded: form_helper
INFO - 2022-03-17 03:55:23 --> Helper loaded: common_helper
INFO - 2022-03-17 03:55:23 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:55:23 --> Controller Class Initialized
INFO - 2022-03-17 03:55:23 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:55:23 --> Encrypt Class Initialized
DEBUG - 2022-03-17 03:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 03:55:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 03:55:23 --> Email Class Initialized
INFO - 2022-03-17 03:55:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 03:55:23 --> Calendar Class Initialized
INFO - 2022-03-17 03:55:23 --> Model "Login_model" initialized
INFO - 2022-03-17 03:55:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-17 03:55:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:55:24 --> Config Class Initialized
INFO - 2022-03-17 03:55:24 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:55:24 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:55:24 --> Utf8 Class Initialized
INFO - 2022-03-17 03:55:24 --> URI Class Initialized
INFO - 2022-03-17 03:55:24 --> Router Class Initialized
INFO - 2022-03-17 03:55:24 --> Output Class Initialized
INFO - 2022-03-17 03:55:24 --> Security Class Initialized
DEBUG - 2022-03-17 03:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:55:24 --> Input Class Initialized
INFO - 2022-03-17 03:55:24 --> Language Class Initialized
INFO - 2022-03-17 03:55:24 --> Loader Class Initialized
INFO - 2022-03-17 03:55:24 --> Helper loaded: url_helper
INFO - 2022-03-17 03:55:24 --> Helper loaded: form_helper
INFO - 2022-03-17 03:55:24 --> Helper loaded: common_helper
INFO - 2022-03-17 03:55:24 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:55:24 --> Controller Class Initialized
INFO - 2022-03-17 03:55:24 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:55:24 --> Encrypt Class Initialized
DEBUG - 2022-03-17 03:55:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 03:55:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 03:55:24 --> Email Class Initialized
INFO - 2022-03-17 03:55:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 03:55:24 --> Calendar Class Initialized
INFO - 2022-03-17 03:55:24 --> Model "Login_model" initialized
INFO - 2022-03-17 03:55:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 03:55:24 --> Final output sent to browser
DEBUG - 2022-03-17 03:55:24 --> Total execution time: 0.0261
ERROR - 2022-03-17 03:57:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:57:23 --> Config Class Initialized
INFO - 2022-03-17 03:57:23 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:57:23 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:57:23 --> Utf8 Class Initialized
INFO - 2022-03-17 03:57:23 --> URI Class Initialized
INFO - 2022-03-17 03:57:23 --> Router Class Initialized
INFO - 2022-03-17 03:57:23 --> Output Class Initialized
INFO - 2022-03-17 03:57:23 --> Security Class Initialized
DEBUG - 2022-03-17 03:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:57:23 --> Input Class Initialized
INFO - 2022-03-17 03:57:23 --> Language Class Initialized
INFO - 2022-03-17 03:57:23 --> Loader Class Initialized
INFO - 2022-03-17 03:57:23 --> Helper loaded: url_helper
INFO - 2022-03-17 03:57:23 --> Helper loaded: form_helper
INFO - 2022-03-17 03:57:23 --> Helper loaded: common_helper
INFO - 2022-03-17 03:57:23 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:57:23 --> Controller Class Initialized
INFO - 2022-03-17 03:57:23 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:57:23 --> Encrypt Class Initialized
DEBUG - 2022-03-17 03:57:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 03:57:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 03:57:23 --> Email Class Initialized
INFO - 2022-03-17 03:57:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 03:57:23 --> Calendar Class Initialized
INFO - 2022-03-17 03:57:23 --> Model "Login_model" initialized
INFO - 2022-03-17 03:57:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-17 03:57:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:57:24 --> Config Class Initialized
INFO - 2022-03-17 03:57:24 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:57:24 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:57:24 --> Utf8 Class Initialized
INFO - 2022-03-17 03:57:24 --> URI Class Initialized
INFO - 2022-03-17 03:57:24 --> Router Class Initialized
INFO - 2022-03-17 03:57:24 --> Output Class Initialized
INFO - 2022-03-17 03:57:24 --> Security Class Initialized
DEBUG - 2022-03-17 03:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:57:24 --> Input Class Initialized
INFO - 2022-03-17 03:57:24 --> Language Class Initialized
INFO - 2022-03-17 03:57:24 --> Loader Class Initialized
INFO - 2022-03-17 03:57:24 --> Helper loaded: url_helper
INFO - 2022-03-17 03:57:24 --> Helper loaded: form_helper
INFO - 2022-03-17 03:57:24 --> Helper loaded: common_helper
INFO - 2022-03-17 03:57:24 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:57:24 --> Controller Class Initialized
INFO - 2022-03-17 03:57:24 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:57:24 --> Encrypt Class Initialized
INFO - 2022-03-17 03:57:24 --> Model "Login_model" initialized
INFO - 2022-03-17 03:57:24 --> Model "Dashboard_model" initialized
INFO - 2022-03-17 03:57:24 --> Model "Case_model" initialized
INFO - 2022-03-17 03:57:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 03:57:49 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-17 03:57:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 03:57:49 --> Final output sent to browser
DEBUG - 2022-03-17 03:57:49 --> Total execution time: 24.9468
ERROR - 2022-03-17 03:57:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:57:51 --> Config Class Initialized
INFO - 2022-03-17 03:57:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:57:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:57:51 --> Utf8 Class Initialized
INFO - 2022-03-17 03:57:51 --> URI Class Initialized
DEBUG - 2022-03-17 03:57:51 --> No URI present. Default controller set.
INFO - 2022-03-17 03:57:51 --> Router Class Initialized
INFO - 2022-03-17 03:57:51 --> Output Class Initialized
INFO - 2022-03-17 03:57:51 --> Security Class Initialized
DEBUG - 2022-03-17 03:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:57:51 --> Input Class Initialized
INFO - 2022-03-17 03:57:51 --> Language Class Initialized
INFO - 2022-03-17 03:57:51 --> Loader Class Initialized
INFO - 2022-03-17 03:57:51 --> Helper loaded: url_helper
INFO - 2022-03-17 03:57:51 --> Helper loaded: form_helper
INFO - 2022-03-17 03:57:51 --> Helper loaded: common_helper
INFO - 2022-03-17 03:57:51 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:57:51 --> Controller Class Initialized
INFO - 2022-03-17 03:57:51 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:57:51 --> Encrypt Class Initialized
DEBUG - 2022-03-17 03:57:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 03:57:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 03:57:51 --> Email Class Initialized
INFO - 2022-03-17 03:57:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 03:57:51 --> Calendar Class Initialized
INFO - 2022-03-17 03:57:51 --> Model "Login_model" initialized
ERROR - 2022-03-17 03:57:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:57:52 --> Config Class Initialized
INFO - 2022-03-17 03:57:52 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:57:52 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:57:52 --> Utf8 Class Initialized
INFO - 2022-03-17 03:57:52 --> URI Class Initialized
INFO - 2022-03-17 03:57:52 --> Router Class Initialized
INFO - 2022-03-17 03:57:52 --> Output Class Initialized
INFO - 2022-03-17 03:57:52 --> Security Class Initialized
DEBUG - 2022-03-17 03:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:57:52 --> Input Class Initialized
INFO - 2022-03-17 03:57:52 --> Language Class Initialized
INFO - 2022-03-17 03:57:52 --> Loader Class Initialized
INFO - 2022-03-17 03:57:52 --> Helper loaded: url_helper
INFO - 2022-03-17 03:57:52 --> Helper loaded: form_helper
INFO - 2022-03-17 03:57:52 --> Helper loaded: common_helper
INFO - 2022-03-17 03:57:52 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:57:52 --> Controller Class Initialized
INFO - 2022-03-17 03:57:52 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:57:52 --> Encrypt Class Initialized
INFO - 2022-03-17 03:57:52 --> Model "Diseases_model" initialized
INFO - 2022-03-17 03:57:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 03:57:52 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-17 03:57:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 03:57:52 --> Final output sent to browser
DEBUG - 2022-03-17 03:57:52 --> Total execution time: 0.0585
ERROR - 2022-03-17 03:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:57:54 --> Config Class Initialized
INFO - 2022-03-17 03:57:54 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:57:54 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:57:54 --> Utf8 Class Initialized
INFO - 2022-03-17 03:57:54 --> URI Class Initialized
INFO - 2022-03-17 03:57:54 --> Router Class Initialized
INFO - 2022-03-17 03:57:54 --> Output Class Initialized
INFO - 2022-03-17 03:57:54 --> Security Class Initialized
DEBUG - 2022-03-17 03:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:57:54 --> Input Class Initialized
INFO - 2022-03-17 03:57:54 --> Language Class Initialized
ERROR - 2022-03-17 03:57:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 03:58:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:58:07 --> Config Class Initialized
INFO - 2022-03-17 03:58:07 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:58:07 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:58:07 --> Utf8 Class Initialized
INFO - 2022-03-17 03:58:07 --> URI Class Initialized
INFO - 2022-03-17 03:58:07 --> Router Class Initialized
INFO - 2022-03-17 03:58:07 --> Output Class Initialized
INFO - 2022-03-17 03:58:07 --> Security Class Initialized
DEBUG - 2022-03-17 03:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:58:07 --> Input Class Initialized
INFO - 2022-03-17 03:58:07 --> Language Class Initialized
INFO - 2022-03-17 03:58:07 --> Loader Class Initialized
INFO - 2022-03-17 03:58:07 --> Helper loaded: url_helper
INFO - 2022-03-17 03:58:07 --> Helper loaded: form_helper
INFO - 2022-03-17 03:58:07 --> Helper loaded: common_helper
INFO - 2022-03-17 03:58:07 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:58:07 --> Controller Class Initialized
INFO - 2022-03-17 03:58:07 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:58:07 --> Encrypt Class Initialized
INFO - 2022-03-17 03:58:07 --> Model "Patient_model" initialized
INFO - 2022-03-17 03:58:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 03:58:07 --> Model "Referredby_model" initialized
INFO - 2022-03-17 03:58:07 --> Model "Prefix_master" initialized
INFO - 2022-03-17 03:58:07 --> Model "Hospital_model" initialized
INFO - 2022-03-17 03:58:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-17 03:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:58:15 --> Config Class Initialized
INFO - 2022-03-17 03:58:15 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:58:15 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:58:15 --> Utf8 Class Initialized
INFO - 2022-03-17 03:58:15 --> URI Class Initialized
INFO - 2022-03-17 03:58:15 --> Router Class Initialized
INFO - 2022-03-17 03:58:15 --> Output Class Initialized
INFO - 2022-03-17 03:58:15 --> Security Class Initialized
DEBUG - 2022-03-17 03:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:58:15 --> Input Class Initialized
INFO - 2022-03-17 03:58:15 --> Language Class Initialized
INFO - 2022-03-17 03:58:15 --> Loader Class Initialized
INFO - 2022-03-17 03:58:15 --> Helper loaded: url_helper
INFO - 2022-03-17 03:58:15 --> Helper loaded: form_helper
INFO - 2022-03-17 03:58:15 --> Helper loaded: common_helper
INFO - 2022-03-17 03:58:15 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:58:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 03:58:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 03:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:58:17 --> Controller Class Initialized
INFO - 2022-03-17 03:58:17 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:58:17 --> Encrypt Class Initialized
INFO - 2022-03-17 03:58:17 --> Model "Patient_model" initialized
INFO - 2022-03-17 03:58:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 03:58:17 --> Model "Referredby_model" initialized
INFO - 2022-03-17 03:58:17 --> Model "Prefix_master" initialized
INFO - 2022-03-17 03:58:17 --> Model "Hospital_model" initialized
INFO - 2022-03-17 03:58:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 03:58:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 03:58:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-17 03:58:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:58:28 --> Config Class Initialized
INFO - 2022-03-17 03:58:28 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:58:28 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:58:28 --> Utf8 Class Initialized
INFO - 2022-03-17 03:58:28 --> URI Class Initialized
INFO - 2022-03-17 03:58:28 --> Router Class Initialized
INFO - 2022-03-17 03:58:28 --> Output Class Initialized
INFO - 2022-03-17 03:58:28 --> Security Class Initialized
DEBUG - 2022-03-17 03:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:58:28 --> Input Class Initialized
INFO - 2022-03-17 03:58:28 --> Language Class Initialized
ERROR - 2022-03-17 03:58:28 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-17 03:58:29 --> Final output sent to browser
DEBUG - 2022-03-17 03:58:29 --> Total execution time: 12.1239
ERROR - 2022-03-17 03:58:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:58:42 --> Config Class Initialized
INFO - 2022-03-17 03:58:42 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:58:42 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:58:42 --> Utf8 Class Initialized
INFO - 2022-03-17 03:58:42 --> URI Class Initialized
INFO - 2022-03-17 03:58:42 --> Router Class Initialized
INFO - 2022-03-17 03:58:42 --> Output Class Initialized
INFO - 2022-03-17 03:58:42 --> Security Class Initialized
DEBUG - 2022-03-17 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:58:42 --> Input Class Initialized
INFO - 2022-03-17 03:58:42 --> Language Class Initialized
INFO - 2022-03-17 03:58:42 --> Loader Class Initialized
INFO - 2022-03-17 03:58:42 --> Helper loaded: url_helper
INFO - 2022-03-17 03:58:42 --> Helper loaded: form_helper
INFO - 2022-03-17 03:58:42 --> Helper loaded: common_helper
INFO - 2022-03-17 03:58:42 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:58:42 --> Controller Class Initialized
INFO - 2022-03-17 03:58:42 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:58:42 --> Encrypt Class Initialized
INFO - 2022-03-17 03:58:42 --> Model "Patient_model" initialized
INFO - 2022-03-17 03:58:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 03:58:42 --> Model "Referredby_model" initialized
INFO - 2022-03-17 03:58:42 --> Model "Prefix_master" initialized
INFO - 2022-03-17 03:58:42 --> Model "Hospital_model" initialized
INFO - 2022-03-17 03:58:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 03:58:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 03:58:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-17 03:58:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:58:53 --> Config Class Initialized
INFO - 2022-03-17 03:58:53 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:58:53 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:58:53 --> Utf8 Class Initialized
INFO - 2022-03-17 03:58:53 --> URI Class Initialized
INFO - 2022-03-17 03:58:53 --> Router Class Initialized
INFO - 2022-03-17 03:58:53 --> Output Class Initialized
INFO - 2022-03-17 03:58:53 --> Security Class Initialized
DEBUG - 2022-03-17 03:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:58:53 --> Input Class Initialized
INFO - 2022-03-17 03:58:53 --> Language Class Initialized
ERROR - 2022-03-17 03:58:53 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-17 03:58:53 --> Final output sent to browser
DEBUG - 2022-03-17 03:58:53 --> Total execution time: 9.3005
ERROR - 2022-03-17 03:59:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:59:32 --> Config Class Initialized
INFO - 2022-03-17 03:59:32 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:59:32 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:59:32 --> Utf8 Class Initialized
INFO - 2022-03-17 03:59:32 --> URI Class Initialized
INFO - 2022-03-17 03:59:32 --> Router Class Initialized
INFO - 2022-03-17 03:59:32 --> Output Class Initialized
INFO - 2022-03-17 03:59:32 --> Security Class Initialized
DEBUG - 2022-03-17 03:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:59:32 --> Input Class Initialized
INFO - 2022-03-17 03:59:32 --> Language Class Initialized
INFO - 2022-03-17 03:59:32 --> Loader Class Initialized
INFO - 2022-03-17 03:59:32 --> Helper loaded: url_helper
INFO - 2022-03-17 03:59:32 --> Helper loaded: form_helper
INFO - 2022-03-17 03:59:32 --> Helper loaded: common_helper
INFO - 2022-03-17 03:59:32 --> Database Driver Class Initialized
DEBUG - 2022-03-17 03:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 03:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 03:59:32 --> Controller Class Initialized
INFO - 2022-03-17 03:59:32 --> Form Validation Class Initialized
DEBUG - 2022-03-17 03:59:32 --> Encrypt Class Initialized
INFO - 2022-03-17 03:59:32 --> Model "Patient_model" initialized
INFO - 2022-03-17 03:59:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 03:59:32 --> Model "Referredby_model" initialized
INFO - 2022-03-17 03:59:32 --> Model "Prefix_master" initialized
INFO - 2022-03-17 03:59:32 --> Model "Hospital_model" initialized
INFO - 2022-03-17 03:59:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 03:59:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 03:59:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 03:59:32 --> Final output sent to browser
DEBUG - 2022-03-17 03:59:32 --> Total execution time: 0.0709
ERROR - 2022-03-17 03:59:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 03:59:33 --> Config Class Initialized
INFO - 2022-03-17 03:59:33 --> Hooks Class Initialized
DEBUG - 2022-03-17 03:59:33 --> UTF-8 Support Enabled
INFO - 2022-03-17 03:59:33 --> Utf8 Class Initialized
INFO - 2022-03-17 03:59:33 --> URI Class Initialized
INFO - 2022-03-17 03:59:33 --> Router Class Initialized
INFO - 2022-03-17 03:59:33 --> Output Class Initialized
INFO - 2022-03-17 03:59:33 --> Security Class Initialized
DEBUG - 2022-03-17 03:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 03:59:33 --> Input Class Initialized
INFO - 2022-03-17 03:59:33 --> Language Class Initialized
ERROR - 2022-03-17 03:59:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:05:59 --> Config Class Initialized
INFO - 2022-03-17 05:05:59 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:05:59 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:05:59 --> Utf8 Class Initialized
INFO - 2022-03-17 05:05:59 --> URI Class Initialized
DEBUG - 2022-03-17 05:05:59 --> No URI present. Default controller set.
INFO - 2022-03-17 05:05:59 --> Router Class Initialized
INFO - 2022-03-17 05:05:59 --> Output Class Initialized
INFO - 2022-03-17 05:05:59 --> Security Class Initialized
DEBUG - 2022-03-17 05:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:05:59 --> Input Class Initialized
INFO - 2022-03-17 05:05:59 --> Language Class Initialized
INFO - 2022-03-17 05:05:59 --> Loader Class Initialized
INFO - 2022-03-17 05:05:59 --> Helper loaded: url_helper
INFO - 2022-03-17 05:05:59 --> Helper loaded: form_helper
INFO - 2022-03-17 05:05:59 --> Helper loaded: common_helper
INFO - 2022-03-17 05:05:59 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:05:59 --> Controller Class Initialized
INFO - 2022-03-17 05:05:59 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:05:59 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:05:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:05:59 --> Email Class Initialized
INFO - 2022-03-17 05:05:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:05:59 --> Calendar Class Initialized
INFO - 2022-03-17 05:05:59 --> Model "Login_model" initialized
INFO - 2022-03-17 05:05:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 05:05:59 --> Final output sent to browser
DEBUG - 2022-03-17 05:05:59 --> Total execution time: 0.0306
ERROR - 2022-03-17 05:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:06:02 --> Config Class Initialized
INFO - 2022-03-17 05:06:02 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:06:02 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:06:02 --> Utf8 Class Initialized
INFO - 2022-03-17 05:06:02 --> URI Class Initialized
DEBUG - 2022-03-17 05:06:02 --> No URI present. Default controller set.
INFO - 2022-03-17 05:06:02 --> Router Class Initialized
INFO - 2022-03-17 05:06:02 --> Output Class Initialized
INFO - 2022-03-17 05:06:02 --> Security Class Initialized
DEBUG - 2022-03-17 05:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:06:02 --> Input Class Initialized
INFO - 2022-03-17 05:06:02 --> Language Class Initialized
INFO - 2022-03-17 05:06:02 --> Loader Class Initialized
INFO - 2022-03-17 05:06:02 --> Helper loaded: url_helper
INFO - 2022-03-17 05:06:02 --> Helper loaded: form_helper
INFO - 2022-03-17 05:06:02 --> Helper loaded: common_helper
INFO - 2022-03-17 05:06:02 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:06:02 --> Controller Class Initialized
INFO - 2022-03-17 05:06:02 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:06:02 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:06:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:06:02 --> Email Class Initialized
INFO - 2022-03-17 05:06:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:06:02 --> Calendar Class Initialized
INFO - 2022-03-17 05:06:02 --> Model "Login_model" initialized
INFO - 2022-03-17 05:06:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 05:06:02 --> Final output sent to browser
DEBUG - 2022-03-17 05:06:02 --> Total execution time: 0.0253
ERROR - 2022-03-17 05:06:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:06:08 --> Config Class Initialized
INFO - 2022-03-17 05:06:08 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:06:08 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:06:08 --> Utf8 Class Initialized
INFO - 2022-03-17 05:06:08 --> URI Class Initialized
INFO - 2022-03-17 05:06:08 --> Router Class Initialized
INFO - 2022-03-17 05:06:08 --> Output Class Initialized
INFO - 2022-03-17 05:06:08 --> Security Class Initialized
DEBUG - 2022-03-17 05:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:06:08 --> Input Class Initialized
INFO - 2022-03-17 05:06:08 --> Language Class Initialized
INFO - 2022-03-17 05:06:08 --> Loader Class Initialized
INFO - 2022-03-17 05:06:08 --> Helper loaded: url_helper
INFO - 2022-03-17 05:06:08 --> Helper loaded: form_helper
INFO - 2022-03-17 05:06:08 --> Helper loaded: common_helper
INFO - 2022-03-17 05:06:08 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:06:08 --> Controller Class Initialized
INFO - 2022-03-17 05:06:08 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:06:08 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:06:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:06:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:06:08 --> Email Class Initialized
INFO - 2022-03-17 05:06:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:06:08 --> Calendar Class Initialized
INFO - 2022-03-17 05:06:08 --> Model "Login_model" initialized
INFO - 2022-03-17 05:06:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-17 05:06:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 05:06:08 --> Final output sent to browser
DEBUG - 2022-03-17 05:06:08 --> Total execution time: 0.0336
ERROR - 2022-03-17 05:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:06:19 --> Config Class Initialized
INFO - 2022-03-17 05:06:19 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:06:19 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:06:19 --> Utf8 Class Initialized
INFO - 2022-03-17 05:06:19 --> URI Class Initialized
INFO - 2022-03-17 05:06:19 --> Router Class Initialized
INFO - 2022-03-17 05:06:19 --> Output Class Initialized
INFO - 2022-03-17 05:06:19 --> Security Class Initialized
DEBUG - 2022-03-17 05:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:06:19 --> Input Class Initialized
INFO - 2022-03-17 05:06:19 --> Language Class Initialized
INFO - 2022-03-17 05:06:19 --> Loader Class Initialized
INFO - 2022-03-17 05:06:19 --> Helper loaded: url_helper
INFO - 2022-03-17 05:06:19 --> Helper loaded: form_helper
INFO - 2022-03-17 05:06:19 --> Helper loaded: common_helper
INFO - 2022-03-17 05:06:19 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:06:19 --> Controller Class Initialized
INFO - 2022-03-17 05:06:19 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:06:19 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:06:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:06:19 --> Email Class Initialized
INFO - 2022-03-17 05:06:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:06:19 --> Calendar Class Initialized
INFO - 2022-03-17 05:06:19 --> Model "Login_model" initialized
INFO - 2022-03-17 05:06:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-17 05:06:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:06:20 --> Config Class Initialized
INFO - 2022-03-17 05:06:20 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:06:20 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:06:20 --> Utf8 Class Initialized
INFO - 2022-03-17 05:06:20 --> URI Class Initialized
INFO - 2022-03-17 05:06:20 --> Router Class Initialized
INFO - 2022-03-17 05:06:20 --> Output Class Initialized
INFO - 2022-03-17 05:06:20 --> Security Class Initialized
DEBUG - 2022-03-17 05:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:06:20 --> Input Class Initialized
INFO - 2022-03-17 05:06:20 --> Language Class Initialized
INFO - 2022-03-17 05:06:20 --> Loader Class Initialized
INFO - 2022-03-17 05:06:20 --> Helper loaded: url_helper
INFO - 2022-03-17 05:06:20 --> Helper loaded: form_helper
INFO - 2022-03-17 05:06:20 --> Helper loaded: common_helper
INFO - 2022-03-17 05:06:20 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:06:20 --> Controller Class Initialized
INFO - 2022-03-17 05:06:20 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:06:20 --> Encrypt Class Initialized
INFO - 2022-03-17 05:06:20 --> Model "Login_model" initialized
INFO - 2022-03-17 05:06:20 --> Model "Dashboard_model" initialized
INFO - 2022-03-17 05:06:20 --> Model "Case_model" initialized
INFO - 2022-03-17 05:06:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:06:20 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-17 05:06:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:06:20 --> Final output sent to browser
DEBUG - 2022-03-17 05:06:20 --> Total execution time: 0.6073
ERROR - 2022-03-17 05:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:06:29 --> Config Class Initialized
INFO - 2022-03-17 05:06:29 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:06:29 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:06:29 --> Utf8 Class Initialized
INFO - 2022-03-17 05:06:29 --> URI Class Initialized
INFO - 2022-03-17 05:06:29 --> Router Class Initialized
INFO - 2022-03-17 05:06:29 --> Output Class Initialized
INFO - 2022-03-17 05:06:29 --> Security Class Initialized
DEBUG - 2022-03-17 05:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:06:29 --> Input Class Initialized
INFO - 2022-03-17 05:06:29 --> Language Class Initialized
INFO - 2022-03-17 05:06:29 --> Loader Class Initialized
INFO - 2022-03-17 05:06:29 --> Helper loaded: url_helper
INFO - 2022-03-17 05:06:29 --> Helper loaded: form_helper
INFO - 2022-03-17 05:06:29 --> Helper loaded: common_helper
INFO - 2022-03-17 05:06:29 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:06:29 --> Controller Class Initialized
INFO - 2022-03-17 05:06:29 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:06:29 --> Encrypt Class Initialized
INFO - 2022-03-17 05:06:29 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:06:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:06:29 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:06:29 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:06:29 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:06:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:06:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:06:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:06:29 --> Final output sent to browser
DEBUG - 2022-03-17 05:06:29 --> Total execution time: 0.0974
ERROR - 2022-03-17 05:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:06:40 --> Config Class Initialized
INFO - 2022-03-17 05:06:40 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:06:40 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:06:40 --> Utf8 Class Initialized
INFO - 2022-03-17 05:06:40 --> URI Class Initialized
INFO - 2022-03-17 05:06:40 --> Router Class Initialized
INFO - 2022-03-17 05:06:40 --> Output Class Initialized
INFO - 2022-03-17 05:06:40 --> Security Class Initialized
DEBUG - 2022-03-17 05:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:06:40 --> Input Class Initialized
INFO - 2022-03-17 05:06:40 --> Language Class Initialized
INFO - 2022-03-17 05:06:40 --> Loader Class Initialized
INFO - 2022-03-17 05:06:40 --> Helper loaded: url_helper
INFO - 2022-03-17 05:06:40 --> Helper loaded: form_helper
INFO - 2022-03-17 05:06:40 --> Helper loaded: common_helper
INFO - 2022-03-17 05:06:40 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:06:40 --> Controller Class Initialized
INFO - 2022-03-17 05:06:40 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:06:40 --> Encrypt Class Initialized
INFO - 2022-03-17 05:06:40 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:06:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:06:40 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:06:40 --> Model "Users_model" initialized
INFO - 2022-03-17 05:06:40 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:06:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:06:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:06:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:06:40 --> Final output sent to browser
DEBUG - 2022-03-17 05:06:40 --> Total execution time: 0.5308
ERROR - 2022-03-17 05:06:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:06:53 --> Config Class Initialized
INFO - 2022-03-17 05:06:53 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:06:53 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:06:53 --> Utf8 Class Initialized
INFO - 2022-03-17 05:06:53 --> URI Class Initialized
INFO - 2022-03-17 05:06:53 --> Router Class Initialized
INFO - 2022-03-17 05:06:53 --> Output Class Initialized
INFO - 2022-03-17 05:06:53 --> Security Class Initialized
DEBUG - 2022-03-17 05:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:06:53 --> Input Class Initialized
INFO - 2022-03-17 05:06:53 --> Language Class Initialized
INFO - 2022-03-17 05:06:53 --> Loader Class Initialized
INFO - 2022-03-17 05:06:53 --> Helper loaded: url_helper
INFO - 2022-03-17 05:06:53 --> Helper loaded: form_helper
INFO - 2022-03-17 05:06:53 --> Helper loaded: common_helper
INFO - 2022-03-17 05:06:53 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:06:53 --> Controller Class Initialized
INFO - 2022-03-17 05:06:53 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:06:53 --> Encrypt Class Initialized
INFO - 2022-03-17 05:06:53 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:06:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:06:53 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:06:53 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:06:53 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:06:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:06:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:06:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:06:53 --> Final output sent to browser
DEBUG - 2022-03-17 05:06:53 --> Total execution time: 0.1118
ERROR - 2022-03-17 05:07:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:07:47 --> Config Class Initialized
INFO - 2022-03-17 05:07:47 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:07:47 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:07:47 --> Utf8 Class Initialized
INFO - 2022-03-17 05:07:47 --> URI Class Initialized
INFO - 2022-03-17 05:07:47 --> Router Class Initialized
INFO - 2022-03-17 05:07:47 --> Output Class Initialized
INFO - 2022-03-17 05:07:47 --> Security Class Initialized
DEBUG - 2022-03-17 05:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:07:47 --> Input Class Initialized
INFO - 2022-03-17 05:07:47 --> Language Class Initialized
INFO - 2022-03-17 05:07:47 --> Loader Class Initialized
INFO - 2022-03-17 05:07:47 --> Helper loaded: url_helper
INFO - 2022-03-17 05:07:47 --> Helper loaded: form_helper
INFO - 2022-03-17 05:07:47 --> Helper loaded: common_helper
INFO - 2022-03-17 05:07:47 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:07:47 --> Controller Class Initialized
INFO - 2022-03-17 05:07:47 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:07:47 --> Encrypt Class Initialized
INFO - 2022-03-17 05:07:47 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:07:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:07:47 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:07:48 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:07:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 05:07:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:07:48 --> Config Class Initialized
INFO - 2022-03-17 05:07:48 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:07:48 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:07:48 --> Utf8 Class Initialized
INFO - 2022-03-17 05:07:48 --> URI Class Initialized
INFO - 2022-03-17 05:07:48 --> Router Class Initialized
INFO - 2022-03-17 05:07:48 --> Output Class Initialized
INFO - 2022-03-17 05:07:48 --> Security Class Initialized
DEBUG - 2022-03-17 05:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:07:48 --> Input Class Initialized
INFO - 2022-03-17 05:07:48 --> Language Class Initialized
INFO - 2022-03-17 05:07:48 --> Loader Class Initialized
INFO - 2022-03-17 05:07:48 --> Helper loaded: url_helper
INFO - 2022-03-17 05:07:48 --> Helper loaded: form_helper
INFO - 2022-03-17 05:07:48 --> Helper loaded: common_helper
INFO - 2022-03-17 05:07:48 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:07:48 --> Controller Class Initialized
INFO - 2022-03-17 05:07:48 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:07:48 --> Encrypt Class Initialized
INFO - 2022-03-17 05:07:48 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:07:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:07:48 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:07:48 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:07:48 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:07:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:07:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:07:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:07:48 --> Final output sent to browser
DEBUG - 2022-03-17 05:07:48 --> Total execution time: 0.0846
ERROR - 2022-03-17 05:07:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:07:49 --> Config Class Initialized
INFO - 2022-03-17 05:07:49 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:07:49 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:07:49 --> Utf8 Class Initialized
INFO - 2022-03-17 05:07:49 --> URI Class Initialized
INFO - 2022-03-17 05:07:49 --> Router Class Initialized
INFO - 2022-03-17 05:07:49 --> Output Class Initialized
INFO - 2022-03-17 05:07:49 --> Security Class Initialized
DEBUG - 2022-03-17 05:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:07:49 --> Input Class Initialized
INFO - 2022-03-17 05:07:49 --> Language Class Initialized
INFO - 2022-03-17 05:07:49 --> Loader Class Initialized
INFO - 2022-03-17 05:07:49 --> Helper loaded: url_helper
INFO - 2022-03-17 05:07:49 --> Helper loaded: form_helper
INFO - 2022-03-17 05:07:49 --> Helper loaded: common_helper
INFO - 2022-03-17 05:07:49 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:07:49 --> Controller Class Initialized
INFO - 2022-03-17 05:07:49 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:07:49 --> Encrypt Class Initialized
INFO - 2022-03-17 05:07:49 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:07:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:07:49 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:07:49 --> Model "Users_model" initialized
INFO - 2022-03-17 05:07:49 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:07:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:07:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:07:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:07:49 --> Final output sent to browser
DEBUG - 2022-03-17 05:07:49 --> Total execution time: 0.0625
ERROR - 2022-03-17 05:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:08:08 --> Config Class Initialized
INFO - 2022-03-17 05:08:08 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:08:08 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:08:08 --> Utf8 Class Initialized
INFO - 2022-03-17 05:08:08 --> URI Class Initialized
INFO - 2022-03-17 05:08:08 --> Router Class Initialized
INFO - 2022-03-17 05:08:08 --> Output Class Initialized
INFO - 2022-03-17 05:08:08 --> Security Class Initialized
DEBUG - 2022-03-17 05:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:08:08 --> Input Class Initialized
INFO - 2022-03-17 05:08:08 --> Language Class Initialized
INFO - 2022-03-17 05:08:08 --> Loader Class Initialized
INFO - 2022-03-17 05:08:08 --> Helper loaded: url_helper
INFO - 2022-03-17 05:08:08 --> Helper loaded: form_helper
INFO - 2022-03-17 05:08:08 --> Helper loaded: common_helper
INFO - 2022-03-17 05:08:08 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:08:08 --> Controller Class Initialized
INFO - 2022-03-17 05:08:08 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:08:08 --> Encrypt Class Initialized
INFO - 2022-03-17 05:08:08 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:08:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:08:08 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:08:08 --> Model "Users_model" initialized
INFO - 2022-03-17 05:08:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 05:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:08:08 --> Config Class Initialized
INFO - 2022-03-17 05:08:08 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:08:08 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:08:08 --> Utf8 Class Initialized
INFO - 2022-03-17 05:08:08 --> URI Class Initialized
INFO - 2022-03-17 05:08:08 --> Router Class Initialized
INFO - 2022-03-17 05:08:08 --> Output Class Initialized
INFO - 2022-03-17 05:08:08 --> Security Class Initialized
DEBUG - 2022-03-17 05:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:08:08 --> Input Class Initialized
INFO - 2022-03-17 05:08:08 --> Language Class Initialized
INFO - 2022-03-17 05:08:08 --> Loader Class Initialized
INFO - 2022-03-17 05:08:08 --> Helper loaded: url_helper
INFO - 2022-03-17 05:08:08 --> Helper loaded: form_helper
INFO - 2022-03-17 05:08:08 --> Helper loaded: common_helper
INFO - 2022-03-17 05:08:08 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:08:08 --> Controller Class Initialized
INFO - 2022-03-17 05:08:08 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:08:08 --> Encrypt Class Initialized
INFO - 2022-03-17 05:08:08 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:08:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:08:08 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:08:08 --> Model "Users_model" initialized
INFO - 2022-03-17 05:08:08 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:08:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:08:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:08:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:08:08 --> Final output sent to browser
DEBUG - 2022-03-17 05:08:08 --> Total execution time: 0.0998
ERROR - 2022-03-17 05:08:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:08:49 --> Config Class Initialized
INFO - 2022-03-17 05:08:49 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:08:49 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:08:49 --> Utf8 Class Initialized
INFO - 2022-03-17 05:08:49 --> URI Class Initialized
INFO - 2022-03-17 05:08:49 --> Router Class Initialized
INFO - 2022-03-17 05:08:49 --> Output Class Initialized
INFO - 2022-03-17 05:08:49 --> Security Class Initialized
DEBUG - 2022-03-17 05:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:08:49 --> Input Class Initialized
INFO - 2022-03-17 05:08:49 --> Language Class Initialized
INFO - 2022-03-17 05:08:49 --> Loader Class Initialized
INFO - 2022-03-17 05:08:49 --> Helper loaded: url_helper
INFO - 2022-03-17 05:08:49 --> Helper loaded: form_helper
INFO - 2022-03-17 05:08:49 --> Helper loaded: common_helper
INFO - 2022-03-17 05:08:49 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:08:49 --> Controller Class Initialized
INFO - 2022-03-17 05:08:49 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:08:49 --> Encrypt Class Initialized
INFO - 2022-03-17 05:08:49 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:08:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:08:49 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:08:49 --> Model "Users_model" initialized
INFO - 2022-03-17 05:08:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 05:08:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:08:49 --> Config Class Initialized
INFO - 2022-03-17 05:08:49 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:08:49 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:08:49 --> Utf8 Class Initialized
INFO - 2022-03-17 05:08:49 --> URI Class Initialized
INFO - 2022-03-17 05:08:49 --> Router Class Initialized
INFO - 2022-03-17 05:08:50 --> Output Class Initialized
INFO - 2022-03-17 05:08:50 --> Security Class Initialized
DEBUG - 2022-03-17 05:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:08:50 --> Input Class Initialized
INFO - 2022-03-17 05:08:50 --> Language Class Initialized
INFO - 2022-03-17 05:08:50 --> Loader Class Initialized
INFO - 2022-03-17 05:08:50 --> Helper loaded: url_helper
INFO - 2022-03-17 05:08:50 --> Helper loaded: form_helper
INFO - 2022-03-17 05:08:50 --> Helper loaded: common_helper
INFO - 2022-03-17 05:08:50 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:08:50 --> Controller Class Initialized
INFO - 2022-03-17 05:08:50 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:08:50 --> Encrypt Class Initialized
INFO - 2022-03-17 05:08:50 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:08:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:08:50 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:08:50 --> Model "Users_model" initialized
INFO - 2022-03-17 05:08:50 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:08:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:08:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:08:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:08:50 --> Final output sent to browser
DEBUG - 2022-03-17 05:08:50 --> Total execution time: 0.0778
ERROR - 2022-03-17 05:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:09:16 --> Config Class Initialized
INFO - 2022-03-17 05:09:16 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:09:16 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:09:16 --> Utf8 Class Initialized
INFO - 2022-03-17 05:09:16 --> URI Class Initialized
INFO - 2022-03-17 05:09:16 --> Router Class Initialized
INFO - 2022-03-17 05:09:16 --> Output Class Initialized
INFO - 2022-03-17 05:09:16 --> Security Class Initialized
DEBUG - 2022-03-17 05:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:09:16 --> Input Class Initialized
INFO - 2022-03-17 05:09:16 --> Language Class Initialized
INFO - 2022-03-17 05:09:16 --> Loader Class Initialized
INFO - 2022-03-17 05:09:16 --> Helper loaded: url_helper
INFO - 2022-03-17 05:09:16 --> Helper loaded: form_helper
INFO - 2022-03-17 05:09:16 --> Helper loaded: common_helper
INFO - 2022-03-17 05:09:16 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:09:16 --> Controller Class Initialized
INFO - 2022-03-17 05:09:16 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:09:16 --> Encrypt Class Initialized
INFO - 2022-03-17 05:09:16 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:09:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:09:16 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:09:16 --> Model "Users_model" initialized
INFO - 2022-03-17 05:09:16 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:09:16 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 05:09:18 --> Final output sent to browser
DEBUG - 2022-03-17 05:09:18 --> Total execution time: 2.1750
ERROR - 2022-03-17 05:12:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:12:58 --> Config Class Initialized
INFO - 2022-03-17 05:12:58 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:12:58 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:12:58 --> Utf8 Class Initialized
INFO - 2022-03-17 05:12:58 --> URI Class Initialized
INFO - 2022-03-17 05:12:58 --> Router Class Initialized
INFO - 2022-03-17 05:12:58 --> Output Class Initialized
INFO - 2022-03-17 05:12:58 --> Security Class Initialized
DEBUG - 2022-03-17 05:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:12:58 --> Input Class Initialized
INFO - 2022-03-17 05:12:58 --> Language Class Initialized
INFO - 2022-03-17 05:12:58 --> Loader Class Initialized
INFO - 2022-03-17 05:12:58 --> Helper loaded: url_helper
INFO - 2022-03-17 05:12:58 --> Helper loaded: form_helper
INFO - 2022-03-17 05:12:58 --> Helper loaded: common_helper
INFO - 2022-03-17 05:12:58 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:12:58 --> Controller Class Initialized
INFO - 2022-03-17 05:12:58 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:12:58 --> Encrypt Class Initialized
INFO - 2022-03-17 05:12:58 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:12:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:12:58 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:12:58 --> Model "Users_model" initialized
INFO - 2022-03-17 05:12:58 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:12:58 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 05:12:59 --> Final output sent to browser
DEBUG - 2022-03-17 05:12:59 --> Total execution time: 0.8918
ERROR - 2022-03-17 05:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:14:33 --> Config Class Initialized
INFO - 2022-03-17 05:14:33 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:14:33 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:14:33 --> Utf8 Class Initialized
INFO - 2022-03-17 05:14:33 --> URI Class Initialized
INFO - 2022-03-17 05:14:33 --> Router Class Initialized
INFO - 2022-03-17 05:14:33 --> Output Class Initialized
INFO - 2022-03-17 05:14:33 --> Security Class Initialized
DEBUG - 2022-03-17 05:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:14:33 --> Input Class Initialized
INFO - 2022-03-17 05:14:33 --> Language Class Initialized
INFO - 2022-03-17 05:14:33 --> Loader Class Initialized
INFO - 2022-03-17 05:14:33 --> Helper loaded: url_helper
INFO - 2022-03-17 05:14:33 --> Helper loaded: form_helper
INFO - 2022-03-17 05:14:33 --> Helper loaded: common_helper
INFO - 2022-03-17 05:14:33 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:14:33 --> Controller Class Initialized
INFO - 2022-03-17 05:14:33 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:14:33 --> Encrypt Class Initialized
INFO - 2022-03-17 05:14:33 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:14:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:14:33 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:14:33 --> Model "Users_model" initialized
INFO - 2022-03-17 05:14:33 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:14:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:14:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:14:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:14:33 --> Final output sent to browser
DEBUG - 2022-03-17 05:14:33 --> Total execution time: 0.0957
ERROR - 2022-03-17 05:14:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:14:40 --> Config Class Initialized
INFO - 2022-03-17 05:14:40 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:14:40 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:14:40 --> Utf8 Class Initialized
INFO - 2022-03-17 05:14:40 --> URI Class Initialized
INFO - 2022-03-17 05:14:40 --> Router Class Initialized
INFO - 2022-03-17 05:14:40 --> Output Class Initialized
INFO - 2022-03-17 05:14:40 --> Security Class Initialized
DEBUG - 2022-03-17 05:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:14:40 --> Input Class Initialized
INFO - 2022-03-17 05:14:40 --> Language Class Initialized
INFO - 2022-03-17 05:14:40 --> Loader Class Initialized
INFO - 2022-03-17 05:14:40 --> Helper loaded: url_helper
INFO - 2022-03-17 05:14:40 --> Helper loaded: form_helper
INFO - 2022-03-17 05:14:40 --> Helper loaded: common_helper
INFO - 2022-03-17 05:14:40 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:14:40 --> Controller Class Initialized
INFO - 2022-03-17 05:14:40 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:14:40 --> Encrypt Class Initialized
INFO - 2022-03-17 05:14:40 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:14:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:14:40 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:14:40 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:14:40 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:14:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:14:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:14:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:14:40 --> Final output sent to browser
DEBUG - 2022-03-17 05:14:40 --> Total execution time: 0.0651
ERROR - 2022-03-17 05:15:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:15:55 --> Config Class Initialized
INFO - 2022-03-17 05:15:55 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:15:55 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:15:55 --> Utf8 Class Initialized
INFO - 2022-03-17 05:15:55 --> URI Class Initialized
INFO - 2022-03-17 05:15:55 --> Router Class Initialized
INFO - 2022-03-17 05:15:55 --> Output Class Initialized
INFO - 2022-03-17 05:15:55 --> Security Class Initialized
DEBUG - 2022-03-17 05:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:15:55 --> Input Class Initialized
INFO - 2022-03-17 05:15:55 --> Language Class Initialized
INFO - 2022-03-17 05:15:55 --> Loader Class Initialized
INFO - 2022-03-17 05:15:55 --> Helper loaded: url_helper
INFO - 2022-03-17 05:15:55 --> Helper loaded: form_helper
INFO - 2022-03-17 05:15:55 --> Helper loaded: common_helper
INFO - 2022-03-17 05:15:55 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:15:55 --> Controller Class Initialized
INFO - 2022-03-17 05:15:55 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:15:55 --> Encrypt Class Initialized
INFO - 2022-03-17 05:15:55 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:15:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:15:55 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:15:55 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:15:55 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:15:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:15:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:15:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:15:55 --> Final output sent to browser
DEBUG - 2022-03-17 05:15:55 --> Total execution time: 0.0523
ERROR - 2022-03-17 05:15:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:15:59 --> Config Class Initialized
INFO - 2022-03-17 05:15:59 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:15:59 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:15:59 --> Utf8 Class Initialized
INFO - 2022-03-17 05:15:59 --> URI Class Initialized
INFO - 2022-03-17 05:15:59 --> Router Class Initialized
INFO - 2022-03-17 05:15:59 --> Output Class Initialized
INFO - 2022-03-17 05:15:59 --> Security Class Initialized
DEBUG - 2022-03-17 05:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:15:59 --> Input Class Initialized
INFO - 2022-03-17 05:15:59 --> Language Class Initialized
INFO - 2022-03-17 05:15:59 --> Loader Class Initialized
INFO - 2022-03-17 05:15:59 --> Helper loaded: url_helper
INFO - 2022-03-17 05:15:59 --> Helper loaded: form_helper
INFO - 2022-03-17 05:15:59 --> Helper loaded: common_helper
INFO - 2022-03-17 05:15:59 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:15:59 --> Controller Class Initialized
ERROR - 2022-03-17 05:16:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:16:00 --> Config Class Initialized
INFO - 2022-03-17 05:16:00 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:16:00 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:16:00 --> Utf8 Class Initialized
INFO - 2022-03-17 05:16:00 --> URI Class Initialized
INFO - 2022-03-17 05:16:00 --> Router Class Initialized
INFO - 2022-03-17 05:16:00 --> Output Class Initialized
INFO - 2022-03-17 05:16:00 --> Security Class Initialized
DEBUG - 2022-03-17 05:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:16:00 --> Input Class Initialized
INFO - 2022-03-17 05:16:00 --> Language Class Initialized
INFO - 2022-03-17 05:16:00 --> Loader Class Initialized
INFO - 2022-03-17 05:16:00 --> Helper loaded: url_helper
INFO - 2022-03-17 05:16:00 --> Helper loaded: form_helper
INFO - 2022-03-17 05:16:00 --> Helper loaded: common_helper
INFO - 2022-03-17 05:16:00 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:16:00 --> Controller Class Initialized
INFO - 2022-03-17 05:16:00 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:16:00 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:16:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:16:00 --> Email Class Initialized
INFO - 2022-03-17 05:16:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:16:00 --> Calendar Class Initialized
INFO - 2022-03-17 05:16:00 --> Model "Login_model" initialized
INFO - 2022-03-17 05:16:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 05:16:00 --> Final output sent to browser
DEBUG - 2022-03-17 05:16:00 --> Total execution time: 0.0412
ERROR - 2022-03-17 05:16:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:16:09 --> Config Class Initialized
INFO - 2022-03-17 05:16:09 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:16:09 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:16:09 --> Utf8 Class Initialized
INFO - 2022-03-17 05:16:09 --> URI Class Initialized
DEBUG - 2022-03-17 05:16:09 --> No URI present. Default controller set.
INFO - 2022-03-17 05:16:09 --> Router Class Initialized
INFO - 2022-03-17 05:16:09 --> Output Class Initialized
INFO - 2022-03-17 05:16:09 --> Security Class Initialized
DEBUG - 2022-03-17 05:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:16:09 --> Input Class Initialized
INFO - 2022-03-17 05:16:09 --> Language Class Initialized
INFO - 2022-03-17 05:16:09 --> Loader Class Initialized
INFO - 2022-03-17 05:16:09 --> Helper loaded: url_helper
INFO - 2022-03-17 05:16:09 --> Helper loaded: form_helper
INFO - 2022-03-17 05:16:09 --> Helper loaded: common_helper
INFO - 2022-03-17 05:16:09 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:16:09 --> Controller Class Initialized
INFO - 2022-03-17 05:16:09 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:16:09 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:16:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:16:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:16:09 --> Email Class Initialized
INFO - 2022-03-17 05:16:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:16:09 --> Calendar Class Initialized
INFO - 2022-03-17 05:16:09 --> Model "Login_model" initialized
ERROR - 2022-03-17 05:16:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:16:09 --> Config Class Initialized
INFO - 2022-03-17 05:16:09 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:16:09 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:16:09 --> Utf8 Class Initialized
INFO - 2022-03-17 05:16:09 --> URI Class Initialized
INFO - 2022-03-17 05:16:09 --> Router Class Initialized
INFO - 2022-03-17 05:16:09 --> Output Class Initialized
INFO - 2022-03-17 05:16:09 --> Security Class Initialized
DEBUG - 2022-03-17 05:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:16:09 --> Input Class Initialized
INFO - 2022-03-17 05:16:09 --> Language Class Initialized
INFO - 2022-03-17 05:16:09 --> Loader Class Initialized
INFO - 2022-03-17 05:16:09 --> Helper loaded: url_helper
INFO - 2022-03-17 05:16:09 --> Helper loaded: form_helper
INFO - 2022-03-17 05:16:09 --> Helper loaded: common_helper
INFO - 2022-03-17 05:16:09 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:16:09 --> Controller Class Initialized
INFO - 2022-03-17 05:16:09 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:16:09 --> Encrypt Class Initialized
INFO - 2022-03-17 05:16:09 --> Model "Diseases_model" initialized
INFO - 2022-03-17 05:16:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:16:09 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-17 05:16:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:16:09 --> Final output sent to browser
DEBUG - 2022-03-17 05:16:09 --> Total execution time: 0.0309
ERROR - 2022-03-17 05:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:16:11 --> Config Class Initialized
INFO - 2022-03-17 05:16:11 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:16:11 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:16:11 --> Utf8 Class Initialized
INFO - 2022-03-17 05:16:11 --> URI Class Initialized
DEBUG - 2022-03-17 05:16:11 --> No URI present. Default controller set.
INFO - 2022-03-17 05:16:11 --> Router Class Initialized
INFO - 2022-03-17 05:16:11 --> Output Class Initialized
INFO - 2022-03-17 05:16:11 --> Security Class Initialized
DEBUG - 2022-03-17 05:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:16:11 --> Input Class Initialized
INFO - 2022-03-17 05:16:11 --> Language Class Initialized
INFO - 2022-03-17 05:16:11 --> Loader Class Initialized
INFO - 2022-03-17 05:16:11 --> Helper loaded: url_helper
INFO - 2022-03-17 05:16:11 --> Helper loaded: form_helper
INFO - 2022-03-17 05:16:11 --> Helper loaded: common_helper
INFO - 2022-03-17 05:16:11 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:16:11 --> Controller Class Initialized
INFO - 2022-03-17 05:16:11 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:16:11 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:16:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:16:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:16:11 --> Email Class Initialized
INFO - 2022-03-17 05:16:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:16:11 --> Calendar Class Initialized
INFO - 2022-03-17 05:16:11 --> Model "Login_model" initialized
ERROR - 2022-03-17 05:16:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:16:12 --> Config Class Initialized
INFO - 2022-03-17 05:16:12 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:16:12 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:16:12 --> Utf8 Class Initialized
INFO - 2022-03-17 05:16:12 --> URI Class Initialized
INFO - 2022-03-17 05:16:12 --> Router Class Initialized
INFO - 2022-03-17 05:16:12 --> Output Class Initialized
INFO - 2022-03-17 05:16:12 --> Security Class Initialized
DEBUG - 2022-03-17 05:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:16:12 --> Input Class Initialized
INFO - 2022-03-17 05:16:12 --> Language Class Initialized
INFO - 2022-03-17 05:16:12 --> Loader Class Initialized
INFO - 2022-03-17 05:16:12 --> Helper loaded: url_helper
INFO - 2022-03-17 05:16:12 --> Helper loaded: form_helper
INFO - 2022-03-17 05:16:12 --> Helper loaded: common_helper
INFO - 2022-03-17 05:16:12 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:16:12 --> Controller Class Initialized
INFO - 2022-03-17 05:16:12 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:16:12 --> Encrypt Class Initialized
INFO - 2022-03-17 05:16:12 --> Model "Diseases_model" initialized
INFO - 2022-03-17 05:16:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:16:12 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-17 05:16:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:16:12 --> Final output sent to browser
DEBUG - 2022-03-17 05:16:12 --> Total execution time: 0.0312
ERROR - 2022-03-17 05:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:16:17 --> Config Class Initialized
INFO - 2022-03-17 05:16:17 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:16:17 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:16:17 --> Utf8 Class Initialized
INFO - 2022-03-17 05:16:17 --> URI Class Initialized
INFO - 2022-03-17 05:16:17 --> Router Class Initialized
INFO - 2022-03-17 05:16:17 --> Output Class Initialized
INFO - 2022-03-17 05:16:17 --> Security Class Initialized
DEBUG - 2022-03-17 05:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:16:17 --> Input Class Initialized
INFO - 2022-03-17 05:16:17 --> Language Class Initialized
INFO - 2022-03-17 05:16:17 --> Loader Class Initialized
INFO - 2022-03-17 05:16:17 --> Helper loaded: url_helper
INFO - 2022-03-17 05:16:17 --> Helper loaded: form_helper
INFO - 2022-03-17 05:16:17 --> Helper loaded: common_helper
INFO - 2022-03-17 05:16:17 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:16:17 --> Controller Class Initialized
INFO - 2022-03-17 05:16:17 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:16:17 --> Encrypt Class Initialized
INFO - 2022-03-17 05:16:17 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:16:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:16:17 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:16:17 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:16:17 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:16:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:16:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:16:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:16:17 --> Final output sent to browser
DEBUG - 2022-03-17 05:16:17 --> Total execution time: 0.0689
ERROR - 2022-03-17 05:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:16:25 --> Config Class Initialized
INFO - 2022-03-17 05:16:25 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:16:25 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:16:25 --> Utf8 Class Initialized
INFO - 2022-03-17 05:16:25 --> URI Class Initialized
INFO - 2022-03-17 05:16:25 --> Router Class Initialized
INFO - 2022-03-17 05:16:25 --> Output Class Initialized
INFO - 2022-03-17 05:16:25 --> Security Class Initialized
DEBUG - 2022-03-17 05:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:16:25 --> Input Class Initialized
INFO - 2022-03-17 05:16:25 --> Language Class Initialized
INFO - 2022-03-17 05:16:25 --> Loader Class Initialized
INFO - 2022-03-17 05:16:25 --> Helper loaded: url_helper
INFO - 2022-03-17 05:16:25 --> Helper loaded: form_helper
INFO - 2022-03-17 05:16:25 --> Helper loaded: common_helper
INFO - 2022-03-17 05:16:25 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:16:25 --> Controller Class Initialized
INFO - 2022-03-17 05:16:25 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:16:25 --> Encrypt Class Initialized
INFO - 2022-03-17 05:16:25 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:16:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:16:25 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:16:25 --> Model "Users_model" initialized
INFO - 2022-03-17 05:16:25 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:16:26 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 05:16:27 --> Final output sent to browser
DEBUG - 2022-03-17 05:16:27 --> Total execution time: 1.1098
ERROR - 2022-03-17 05:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:16:31 --> Config Class Initialized
INFO - 2022-03-17 05:16:31 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:16:31 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:16:31 --> Utf8 Class Initialized
INFO - 2022-03-17 05:16:31 --> URI Class Initialized
INFO - 2022-03-17 05:16:31 --> Router Class Initialized
INFO - 2022-03-17 05:16:31 --> Output Class Initialized
INFO - 2022-03-17 05:16:31 --> Security Class Initialized
DEBUG - 2022-03-17 05:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:16:31 --> Input Class Initialized
INFO - 2022-03-17 05:16:31 --> Language Class Initialized
INFO - 2022-03-17 05:16:31 --> Loader Class Initialized
INFO - 2022-03-17 05:16:31 --> Helper loaded: url_helper
INFO - 2022-03-17 05:16:31 --> Helper loaded: form_helper
INFO - 2022-03-17 05:16:31 --> Helper loaded: common_helper
INFO - 2022-03-17 05:16:31 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:16:31 --> Controller Class Initialized
INFO - 2022-03-17 05:16:31 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:16:31 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:16:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:16:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:16:31 --> Email Class Initialized
INFO - 2022-03-17 05:16:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:16:31 --> Calendar Class Initialized
INFO - 2022-03-17 05:16:31 --> Model "Login_model" initialized
INFO - 2022-03-17 05:16:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-17 05:16:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:16:32 --> Config Class Initialized
INFO - 2022-03-17 05:16:32 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:16:32 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:16:32 --> Utf8 Class Initialized
INFO - 2022-03-17 05:16:32 --> URI Class Initialized
INFO - 2022-03-17 05:16:32 --> Router Class Initialized
INFO - 2022-03-17 05:16:32 --> Output Class Initialized
INFO - 2022-03-17 05:16:32 --> Security Class Initialized
DEBUG - 2022-03-17 05:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:16:32 --> Input Class Initialized
INFO - 2022-03-17 05:16:32 --> Language Class Initialized
INFO - 2022-03-17 05:16:32 --> Loader Class Initialized
INFO - 2022-03-17 05:16:32 --> Helper loaded: url_helper
INFO - 2022-03-17 05:16:32 --> Helper loaded: form_helper
INFO - 2022-03-17 05:16:32 --> Helper loaded: common_helper
INFO - 2022-03-17 05:16:32 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:16:32 --> Controller Class Initialized
INFO - 2022-03-17 05:16:32 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:16:32 --> Encrypt Class Initialized
INFO - 2022-03-17 05:16:32 --> Model "Login_model" initialized
INFO - 2022-03-17 05:16:32 --> Model "Dashboard_model" initialized
INFO - 2022-03-17 05:16:32 --> Model "Case_model" initialized
INFO - 2022-03-17 05:16:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:16:32 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-17 05:16:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:16:32 --> Final output sent to browser
DEBUG - 2022-03-17 05:16:32 --> Total execution time: 0.1917
ERROR - 2022-03-17 05:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:18:31 --> Config Class Initialized
INFO - 2022-03-17 05:18:31 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:18:31 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:18:31 --> Utf8 Class Initialized
INFO - 2022-03-17 05:18:31 --> URI Class Initialized
DEBUG - 2022-03-17 05:18:31 --> No URI present. Default controller set.
INFO - 2022-03-17 05:18:31 --> Router Class Initialized
INFO - 2022-03-17 05:18:31 --> Output Class Initialized
INFO - 2022-03-17 05:18:31 --> Security Class Initialized
DEBUG - 2022-03-17 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:18:31 --> Input Class Initialized
INFO - 2022-03-17 05:18:31 --> Language Class Initialized
INFO - 2022-03-17 05:18:31 --> Loader Class Initialized
INFO - 2022-03-17 05:18:31 --> Helper loaded: url_helper
INFO - 2022-03-17 05:18:31 --> Helper loaded: form_helper
INFO - 2022-03-17 05:18:31 --> Helper loaded: common_helper
INFO - 2022-03-17 05:18:31 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:18:31 --> Controller Class Initialized
INFO - 2022-03-17 05:18:31 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:18:31 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:18:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:18:31 --> Email Class Initialized
INFO - 2022-03-17 05:18:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:18:31 --> Calendar Class Initialized
INFO - 2022-03-17 05:18:31 --> Model "Login_model" initialized
ERROR - 2022-03-17 05:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:18:31 --> Config Class Initialized
INFO - 2022-03-17 05:18:31 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:18:31 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:18:31 --> Utf8 Class Initialized
INFO - 2022-03-17 05:18:31 --> URI Class Initialized
INFO - 2022-03-17 05:18:31 --> Router Class Initialized
INFO - 2022-03-17 05:18:31 --> Output Class Initialized
INFO - 2022-03-17 05:18:31 --> Security Class Initialized
DEBUG - 2022-03-17 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:18:31 --> Input Class Initialized
INFO - 2022-03-17 05:18:31 --> Language Class Initialized
INFO - 2022-03-17 05:18:31 --> Loader Class Initialized
INFO - 2022-03-17 05:18:31 --> Helper loaded: url_helper
INFO - 2022-03-17 05:18:31 --> Helper loaded: form_helper
INFO - 2022-03-17 05:18:31 --> Helper loaded: common_helper
INFO - 2022-03-17 05:18:31 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:18:31 --> Controller Class Initialized
INFO - 2022-03-17 05:18:31 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:18:31 --> Encrypt Class Initialized
INFO - 2022-03-17 05:18:31 --> Model "Diseases_model" initialized
INFO - 2022-03-17 05:18:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:18:31 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-17 05:18:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:18:31 --> Final output sent to browser
DEBUG - 2022-03-17 05:18:31 --> Total execution time: 0.0255
ERROR - 2022-03-17 05:18:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:18:33 --> Config Class Initialized
INFO - 2022-03-17 05:18:33 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:18:33 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:18:33 --> Utf8 Class Initialized
INFO - 2022-03-17 05:18:33 --> URI Class Initialized
DEBUG - 2022-03-17 05:18:33 --> No URI present. Default controller set.
INFO - 2022-03-17 05:18:33 --> Router Class Initialized
INFO - 2022-03-17 05:18:33 --> Output Class Initialized
INFO - 2022-03-17 05:18:33 --> Security Class Initialized
DEBUG - 2022-03-17 05:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:18:33 --> Input Class Initialized
INFO - 2022-03-17 05:18:33 --> Language Class Initialized
INFO - 2022-03-17 05:18:33 --> Loader Class Initialized
INFO - 2022-03-17 05:18:33 --> Helper loaded: url_helper
INFO - 2022-03-17 05:18:33 --> Helper loaded: form_helper
INFO - 2022-03-17 05:18:33 --> Helper loaded: common_helper
INFO - 2022-03-17 05:18:33 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:18:33 --> Controller Class Initialized
INFO - 2022-03-17 05:18:33 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:18:33 --> Encrypt Class Initialized
DEBUG - 2022-03-17 05:18:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 05:18:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 05:18:33 --> Email Class Initialized
INFO - 2022-03-17 05:18:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 05:18:33 --> Calendar Class Initialized
INFO - 2022-03-17 05:18:33 --> Model "Login_model" initialized
ERROR - 2022-03-17 05:18:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:18:34 --> Config Class Initialized
INFO - 2022-03-17 05:18:34 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:18:34 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:18:34 --> Utf8 Class Initialized
INFO - 2022-03-17 05:18:34 --> URI Class Initialized
INFO - 2022-03-17 05:18:34 --> Router Class Initialized
INFO - 2022-03-17 05:18:34 --> Output Class Initialized
INFO - 2022-03-17 05:18:34 --> Security Class Initialized
DEBUG - 2022-03-17 05:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:18:34 --> Input Class Initialized
INFO - 2022-03-17 05:18:34 --> Language Class Initialized
INFO - 2022-03-17 05:18:34 --> Loader Class Initialized
INFO - 2022-03-17 05:18:34 --> Helper loaded: url_helper
INFO - 2022-03-17 05:18:34 --> Helper loaded: form_helper
INFO - 2022-03-17 05:18:34 --> Helper loaded: common_helper
INFO - 2022-03-17 05:18:34 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:18:34 --> Controller Class Initialized
INFO - 2022-03-17 05:18:34 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:18:34 --> Encrypt Class Initialized
INFO - 2022-03-17 05:18:34 --> Model "Diseases_model" initialized
INFO - 2022-03-17 05:18:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:18:34 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-17 05:18:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:18:34 --> Final output sent to browser
DEBUG - 2022-03-17 05:18:34 --> Total execution time: 0.0303
ERROR - 2022-03-17 05:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:18:41 --> Config Class Initialized
INFO - 2022-03-17 05:18:41 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:18:41 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:18:41 --> Utf8 Class Initialized
INFO - 2022-03-17 05:18:41 --> URI Class Initialized
INFO - 2022-03-17 05:18:41 --> Router Class Initialized
INFO - 2022-03-17 05:18:41 --> Output Class Initialized
INFO - 2022-03-17 05:18:41 --> Security Class Initialized
DEBUG - 2022-03-17 05:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:18:41 --> Input Class Initialized
INFO - 2022-03-17 05:18:41 --> Language Class Initialized
INFO - 2022-03-17 05:18:41 --> Loader Class Initialized
INFO - 2022-03-17 05:18:41 --> Helper loaded: url_helper
INFO - 2022-03-17 05:18:41 --> Helper loaded: form_helper
INFO - 2022-03-17 05:18:41 --> Helper loaded: common_helper
INFO - 2022-03-17 05:18:41 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:18:41 --> Controller Class Initialized
INFO - 2022-03-17 05:18:41 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:18:41 --> Encrypt Class Initialized
INFO - 2022-03-17 05:18:41 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:18:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:18:41 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:18:41 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:18:41 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:18:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:18:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:18:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:18:41 --> Final output sent to browser
DEBUG - 2022-03-17 05:18:41 --> Total execution time: 0.0607
ERROR - 2022-03-17 05:18:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:18:51 --> Config Class Initialized
INFO - 2022-03-17 05:18:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:18:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:18:51 --> Utf8 Class Initialized
INFO - 2022-03-17 05:18:51 --> URI Class Initialized
INFO - 2022-03-17 05:18:51 --> Router Class Initialized
INFO - 2022-03-17 05:18:51 --> Output Class Initialized
INFO - 2022-03-17 05:18:51 --> Security Class Initialized
DEBUG - 2022-03-17 05:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:18:51 --> Input Class Initialized
INFO - 2022-03-17 05:18:51 --> Language Class Initialized
INFO - 2022-03-17 05:18:51 --> Loader Class Initialized
INFO - 2022-03-17 05:18:51 --> Helper loaded: url_helper
INFO - 2022-03-17 05:18:51 --> Helper loaded: form_helper
INFO - 2022-03-17 05:18:51 --> Helper loaded: common_helper
INFO - 2022-03-17 05:18:51 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:18:51 --> Controller Class Initialized
INFO - 2022-03-17 05:18:51 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:18:51 --> Encrypt Class Initialized
INFO - 2022-03-17 05:18:51 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:18:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:18:51 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:18:51 --> Model "Users_model" initialized
INFO - 2022-03-17 05:18:51 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:18:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:18:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:18:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:18:51 --> Final output sent to browser
DEBUG - 2022-03-17 05:18:51 --> Total execution time: 0.0945
ERROR - 2022-03-17 05:18:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:18:56 --> Config Class Initialized
INFO - 2022-03-17 05:18:56 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:18:56 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:18:56 --> Utf8 Class Initialized
INFO - 2022-03-17 05:18:56 --> URI Class Initialized
INFO - 2022-03-17 05:18:56 --> Router Class Initialized
INFO - 2022-03-17 05:18:56 --> Output Class Initialized
INFO - 2022-03-17 05:18:56 --> Security Class Initialized
DEBUG - 2022-03-17 05:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:18:56 --> Input Class Initialized
INFO - 2022-03-17 05:18:56 --> Language Class Initialized
INFO - 2022-03-17 05:18:56 --> Loader Class Initialized
INFO - 2022-03-17 05:18:56 --> Helper loaded: url_helper
INFO - 2022-03-17 05:18:56 --> Helper loaded: form_helper
INFO - 2022-03-17 05:18:56 --> Helper loaded: common_helper
INFO - 2022-03-17 05:18:56 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:18:56 --> Controller Class Initialized
INFO - 2022-03-17 05:18:56 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:18:56 --> Encrypt Class Initialized
INFO - 2022-03-17 05:18:56 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:18:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:18:56 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:18:56 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:18:56 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:18:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:18:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:18:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:18:57 --> Final output sent to browser
DEBUG - 2022-03-17 05:18:57 --> Total execution time: 0.0717
ERROR - 2022-03-17 05:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:19:28 --> Config Class Initialized
INFO - 2022-03-17 05:19:28 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:19:28 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:19:28 --> Utf8 Class Initialized
INFO - 2022-03-17 05:19:28 --> URI Class Initialized
INFO - 2022-03-17 05:19:28 --> Router Class Initialized
INFO - 2022-03-17 05:19:28 --> Output Class Initialized
INFO - 2022-03-17 05:19:28 --> Security Class Initialized
DEBUG - 2022-03-17 05:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:19:28 --> Input Class Initialized
INFO - 2022-03-17 05:19:28 --> Language Class Initialized
INFO - 2022-03-17 05:19:28 --> Loader Class Initialized
INFO - 2022-03-17 05:19:28 --> Helper loaded: url_helper
INFO - 2022-03-17 05:19:28 --> Helper loaded: form_helper
INFO - 2022-03-17 05:19:28 --> Helper loaded: common_helper
INFO - 2022-03-17 05:19:28 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:19:28 --> Controller Class Initialized
INFO - 2022-03-17 05:19:28 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:19:28 --> Encrypt Class Initialized
INFO - 2022-03-17 05:19:28 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:19:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:19:28 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:19:28 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:19:28 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:19:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:19:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:19:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:19:28 --> Final output sent to browser
DEBUG - 2022-03-17 05:19:28 --> Total execution time: 0.0762
ERROR - 2022-03-17 05:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:19:59 --> Config Class Initialized
INFO - 2022-03-17 05:19:59 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:19:59 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:19:59 --> Utf8 Class Initialized
INFO - 2022-03-17 05:19:59 --> URI Class Initialized
INFO - 2022-03-17 05:19:59 --> Router Class Initialized
INFO - 2022-03-17 05:19:59 --> Output Class Initialized
INFO - 2022-03-17 05:19:59 --> Security Class Initialized
DEBUG - 2022-03-17 05:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:19:59 --> Input Class Initialized
INFO - 2022-03-17 05:19:59 --> Language Class Initialized
INFO - 2022-03-17 05:19:59 --> Loader Class Initialized
INFO - 2022-03-17 05:19:59 --> Helper loaded: url_helper
INFO - 2022-03-17 05:19:59 --> Helper loaded: form_helper
INFO - 2022-03-17 05:19:59 --> Helper loaded: common_helper
INFO - 2022-03-17 05:19:59 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:20:00 --> Controller Class Initialized
INFO - 2022-03-17 05:20:00 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:20:00 --> Encrypt Class Initialized
INFO - 2022-03-17 05:20:00 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:20:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:20:00 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:20:00 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:20:00 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:20:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:20:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:20:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:20:00 --> Final output sent to browser
DEBUG - 2022-03-17 05:20:00 --> Total execution time: 0.0614
ERROR - 2022-03-17 05:20:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:20:09 --> Config Class Initialized
INFO - 2022-03-17 05:20:09 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:20:09 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:20:09 --> Utf8 Class Initialized
INFO - 2022-03-17 05:20:09 --> URI Class Initialized
INFO - 2022-03-17 05:20:09 --> Router Class Initialized
INFO - 2022-03-17 05:20:09 --> Output Class Initialized
INFO - 2022-03-17 05:20:09 --> Security Class Initialized
DEBUG - 2022-03-17 05:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:20:09 --> Input Class Initialized
INFO - 2022-03-17 05:20:09 --> Language Class Initialized
INFO - 2022-03-17 05:20:09 --> Loader Class Initialized
INFO - 2022-03-17 05:20:09 --> Helper loaded: url_helper
INFO - 2022-03-17 05:20:09 --> Helper loaded: form_helper
INFO - 2022-03-17 05:20:09 --> Helper loaded: common_helper
INFO - 2022-03-17 05:20:09 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:20:09 --> Controller Class Initialized
INFO - 2022-03-17 05:20:09 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:20:09 --> Encrypt Class Initialized
INFO - 2022-03-17 05:20:09 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:20:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:20:09 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:20:09 --> Model "Users_model" initialized
INFO - 2022-03-17 05:20:09 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:20:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:20:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:20:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:20:09 --> Final output sent to browser
DEBUG - 2022-03-17 05:20:09 --> Total execution time: 0.0688
ERROR - 2022-03-17 05:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:20:12 --> Config Class Initialized
INFO - 2022-03-17 05:20:12 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:20:12 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:20:12 --> Utf8 Class Initialized
INFO - 2022-03-17 05:20:12 --> URI Class Initialized
INFO - 2022-03-17 05:20:12 --> Router Class Initialized
INFO - 2022-03-17 05:20:12 --> Output Class Initialized
INFO - 2022-03-17 05:20:12 --> Security Class Initialized
DEBUG - 2022-03-17 05:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:20:12 --> Input Class Initialized
INFO - 2022-03-17 05:20:12 --> Language Class Initialized
INFO - 2022-03-17 05:20:12 --> Loader Class Initialized
INFO - 2022-03-17 05:20:12 --> Helper loaded: url_helper
INFO - 2022-03-17 05:20:12 --> Helper loaded: form_helper
INFO - 2022-03-17 05:20:12 --> Helper loaded: common_helper
INFO - 2022-03-17 05:20:12 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:20:12 --> Controller Class Initialized
INFO - 2022-03-17 05:20:12 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:20:12 --> Encrypt Class Initialized
INFO - 2022-03-17 05:20:12 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:20:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:20:12 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:20:12 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:20:12 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:20:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:20:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:20:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:20:12 --> Final output sent to browser
DEBUG - 2022-03-17 05:20:12 --> Total execution time: 0.0601
ERROR - 2022-03-17 05:20:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:20:33 --> Config Class Initialized
INFO - 2022-03-17 05:20:33 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:20:33 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:20:33 --> Utf8 Class Initialized
INFO - 2022-03-17 05:20:33 --> URI Class Initialized
INFO - 2022-03-17 05:20:33 --> Router Class Initialized
INFO - 2022-03-17 05:20:33 --> Output Class Initialized
INFO - 2022-03-17 05:20:33 --> Security Class Initialized
DEBUG - 2022-03-17 05:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:20:33 --> Input Class Initialized
INFO - 2022-03-17 05:20:33 --> Language Class Initialized
INFO - 2022-03-17 05:20:33 --> Loader Class Initialized
INFO - 2022-03-17 05:20:33 --> Helper loaded: url_helper
INFO - 2022-03-17 05:20:33 --> Helper loaded: form_helper
INFO - 2022-03-17 05:20:33 --> Helper loaded: common_helper
INFO - 2022-03-17 05:20:33 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:20:33 --> Controller Class Initialized
INFO - 2022-03-17 05:20:33 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:20:33 --> Encrypt Class Initialized
INFO - 2022-03-17 05:20:33 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:20:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:20:33 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:20:33 --> Model "Users_model" initialized
INFO - 2022-03-17 05:20:33 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:20:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:20:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:20:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:20:33 --> Final output sent to browser
DEBUG - 2022-03-17 05:20:33 --> Total execution time: 0.0680
ERROR - 2022-03-17 05:20:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:20:48 --> Config Class Initialized
INFO - 2022-03-17 05:20:48 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:20:48 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:20:48 --> Utf8 Class Initialized
INFO - 2022-03-17 05:20:48 --> URI Class Initialized
INFO - 2022-03-17 05:20:48 --> Router Class Initialized
INFO - 2022-03-17 05:20:48 --> Output Class Initialized
INFO - 2022-03-17 05:20:48 --> Security Class Initialized
DEBUG - 2022-03-17 05:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:20:48 --> Input Class Initialized
INFO - 2022-03-17 05:20:48 --> Language Class Initialized
INFO - 2022-03-17 05:20:48 --> Loader Class Initialized
INFO - 2022-03-17 05:20:48 --> Helper loaded: url_helper
INFO - 2022-03-17 05:20:48 --> Helper loaded: form_helper
INFO - 2022-03-17 05:20:48 --> Helper loaded: common_helper
INFO - 2022-03-17 05:20:48 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:20:48 --> Controller Class Initialized
INFO - 2022-03-17 05:20:48 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:20:48 --> Encrypt Class Initialized
INFO - 2022-03-17 05:20:48 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:20:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:20:48 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:20:48 --> Model "Users_model" initialized
INFO - 2022-03-17 05:20:48 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:20:49 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 05:20:49 --> Final output sent to browser
DEBUG - 2022-03-17 05:20:49 --> Total execution time: 0.9063
ERROR - 2022-03-17 05:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:21:48 --> Config Class Initialized
INFO - 2022-03-17 05:21:48 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:21:48 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:21:48 --> Utf8 Class Initialized
INFO - 2022-03-17 05:21:48 --> URI Class Initialized
INFO - 2022-03-17 05:21:48 --> Router Class Initialized
INFO - 2022-03-17 05:21:48 --> Output Class Initialized
INFO - 2022-03-17 05:21:48 --> Security Class Initialized
DEBUG - 2022-03-17 05:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:21:48 --> Input Class Initialized
INFO - 2022-03-17 05:21:48 --> Language Class Initialized
INFO - 2022-03-17 05:21:48 --> Loader Class Initialized
INFO - 2022-03-17 05:21:48 --> Helper loaded: url_helper
INFO - 2022-03-17 05:21:48 --> Helper loaded: form_helper
INFO - 2022-03-17 05:21:48 --> Helper loaded: common_helper
INFO - 2022-03-17 05:21:48 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:21:48 --> Controller Class Initialized
INFO - 2022-03-17 05:21:48 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:21:48 --> Encrypt Class Initialized
INFO - 2022-03-17 05:21:48 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:21:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:21:48 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:21:48 --> Model "Users_model" initialized
INFO - 2022-03-17 05:21:48 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:21:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:21:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:21:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:21:48 --> Final output sent to browser
DEBUG - 2022-03-17 05:21:48 --> Total execution time: 0.0685
ERROR - 2022-03-17 05:21:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:21:51 --> Config Class Initialized
INFO - 2022-03-17 05:21:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:21:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:21:51 --> Utf8 Class Initialized
INFO - 2022-03-17 05:21:51 --> URI Class Initialized
INFO - 2022-03-17 05:21:51 --> Router Class Initialized
INFO - 2022-03-17 05:21:51 --> Output Class Initialized
INFO - 2022-03-17 05:21:51 --> Security Class Initialized
DEBUG - 2022-03-17 05:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:21:51 --> Input Class Initialized
INFO - 2022-03-17 05:21:51 --> Language Class Initialized
INFO - 2022-03-17 05:21:51 --> Loader Class Initialized
INFO - 2022-03-17 05:21:51 --> Helper loaded: url_helper
INFO - 2022-03-17 05:21:51 --> Helper loaded: form_helper
INFO - 2022-03-17 05:21:51 --> Helper loaded: common_helper
INFO - 2022-03-17 05:21:51 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:21:51 --> Controller Class Initialized
INFO - 2022-03-17 05:21:51 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:21:51 --> Encrypt Class Initialized
INFO - 2022-03-17 05:21:51 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:21:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:21:51 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:21:51 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:21:51 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:21:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:21:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:21:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:21:51 --> Final output sent to browser
DEBUG - 2022-03-17 05:21:51 --> Total execution time: 0.0625
ERROR - 2022-03-17 05:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:22:12 --> Config Class Initialized
INFO - 2022-03-17 05:22:12 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:22:12 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:22:12 --> Utf8 Class Initialized
INFO - 2022-03-17 05:22:12 --> URI Class Initialized
INFO - 2022-03-17 05:22:12 --> Router Class Initialized
INFO - 2022-03-17 05:22:12 --> Output Class Initialized
INFO - 2022-03-17 05:22:12 --> Security Class Initialized
DEBUG - 2022-03-17 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:22:12 --> Input Class Initialized
INFO - 2022-03-17 05:22:12 --> Language Class Initialized
INFO - 2022-03-17 05:22:12 --> Loader Class Initialized
INFO - 2022-03-17 05:22:12 --> Helper loaded: url_helper
INFO - 2022-03-17 05:22:12 --> Helper loaded: form_helper
INFO - 2022-03-17 05:22:12 --> Helper loaded: common_helper
INFO - 2022-03-17 05:22:12 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:22:12 --> Controller Class Initialized
INFO - 2022-03-17 05:22:12 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:22:12 --> Encrypt Class Initialized
INFO - 2022-03-17 05:22:12 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:22:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:22:12 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:22:12 --> Model "Users_model" initialized
INFO - 2022-03-17 05:22:12 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:22:12 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 05:22:13 --> Final output sent to browser
DEBUG - 2022-03-17 05:22:13 --> Total execution time: 1.2512
ERROR - 2022-03-17 05:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:26:46 --> Config Class Initialized
INFO - 2022-03-17 05:26:46 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:26:46 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:26:46 --> Utf8 Class Initialized
INFO - 2022-03-17 05:26:46 --> URI Class Initialized
INFO - 2022-03-17 05:26:46 --> Router Class Initialized
INFO - 2022-03-17 05:26:46 --> Output Class Initialized
INFO - 2022-03-17 05:26:46 --> Security Class Initialized
DEBUG - 2022-03-17 05:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:26:46 --> Input Class Initialized
INFO - 2022-03-17 05:26:46 --> Language Class Initialized
INFO - 2022-03-17 05:26:46 --> Loader Class Initialized
INFO - 2022-03-17 05:26:46 --> Helper loaded: url_helper
INFO - 2022-03-17 05:26:46 --> Helper loaded: form_helper
INFO - 2022-03-17 05:26:46 --> Helper loaded: common_helper
INFO - 2022-03-17 05:26:46 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:26:46 --> Controller Class Initialized
INFO - 2022-03-17 05:26:46 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:26:46 --> Encrypt Class Initialized
INFO - 2022-03-17 05:26:46 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:26:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:26:46 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:26:46 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:26:46 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:26:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:26:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:26:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:26:58 --> Final output sent to browser
DEBUG - 2022-03-17 05:26:58 --> Total execution time: 10.0624
ERROR - 2022-03-17 05:27:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:27:01 --> Config Class Initialized
INFO - 2022-03-17 05:27:01 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:27:01 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:27:01 --> Utf8 Class Initialized
INFO - 2022-03-17 05:27:01 --> URI Class Initialized
INFO - 2022-03-17 05:27:01 --> Router Class Initialized
INFO - 2022-03-17 05:27:01 --> Output Class Initialized
INFO - 2022-03-17 05:27:01 --> Security Class Initialized
DEBUG - 2022-03-17 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:27:01 --> Input Class Initialized
INFO - 2022-03-17 05:27:01 --> Language Class Initialized
ERROR - 2022-03-17 05:27:01 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:35:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:35:21 --> Config Class Initialized
INFO - 2022-03-17 05:35:21 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:35:21 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:35:21 --> Utf8 Class Initialized
INFO - 2022-03-17 05:35:21 --> URI Class Initialized
INFO - 2022-03-17 05:35:21 --> Router Class Initialized
INFO - 2022-03-17 05:35:21 --> Output Class Initialized
INFO - 2022-03-17 05:35:21 --> Security Class Initialized
DEBUG - 2022-03-17 05:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:35:21 --> Input Class Initialized
INFO - 2022-03-17 05:35:21 --> Language Class Initialized
INFO - 2022-03-17 05:35:21 --> Loader Class Initialized
INFO - 2022-03-17 05:35:21 --> Helper loaded: url_helper
INFO - 2022-03-17 05:35:21 --> Helper loaded: form_helper
INFO - 2022-03-17 05:35:21 --> Helper loaded: common_helper
INFO - 2022-03-17 05:35:21 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:35:21 --> Controller Class Initialized
INFO - 2022-03-17 05:35:21 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:35:21 --> Encrypt Class Initialized
INFO - 2022-03-17 05:35:21 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:35:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:35:21 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:35:21 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:35:21 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:35:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:35:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:35:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:35:21 --> Final output sent to browser
DEBUG - 2022-03-17 05:35:21 --> Total execution time: 0.0824
ERROR - 2022-03-17 05:35:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:35:23 --> Config Class Initialized
INFO - 2022-03-17 05:35:23 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:35:23 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:35:23 --> Utf8 Class Initialized
INFO - 2022-03-17 05:35:23 --> URI Class Initialized
INFO - 2022-03-17 05:35:23 --> Router Class Initialized
INFO - 2022-03-17 05:35:23 --> Output Class Initialized
INFO - 2022-03-17 05:35:23 --> Security Class Initialized
DEBUG - 2022-03-17 05:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:35:23 --> Input Class Initialized
INFO - 2022-03-17 05:35:23 --> Language Class Initialized
ERROR - 2022-03-17 05:35:23 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 05:35:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:35:23 --> Config Class Initialized
INFO - 2022-03-17 05:35:23 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:35:23 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:35:23 --> Utf8 Class Initialized
INFO - 2022-03-17 05:35:23 --> URI Class Initialized
INFO - 2022-03-17 05:35:23 --> Router Class Initialized
INFO - 2022-03-17 05:35:23 --> Output Class Initialized
INFO - 2022-03-17 05:35:23 --> Security Class Initialized
DEBUG - 2022-03-17 05:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:35:23 --> Input Class Initialized
INFO - 2022-03-17 05:35:23 --> Language Class Initialized
ERROR - 2022-03-17 05:35:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:36:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:36:17 --> Config Class Initialized
INFO - 2022-03-17 05:36:17 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:36:17 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:36:17 --> Utf8 Class Initialized
INFO - 2022-03-17 05:36:17 --> URI Class Initialized
INFO - 2022-03-17 05:36:17 --> Router Class Initialized
INFO - 2022-03-17 05:36:17 --> Output Class Initialized
INFO - 2022-03-17 05:36:17 --> Security Class Initialized
DEBUG - 2022-03-17 05:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:36:17 --> Input Class Initialized
INFO - 2022-03-17 05:36:17 --> Language Class Initialized
INFO - 2022-03-17 05:36:17 --> Loader Class Initialized
INFO - 2022-03-17 05:36:17 --> Helper loaded: url_helper
INFO - 2022-03-17 05:36:17 --> Helper loaded: form_helper
INFO - 2022-03-17 05:36:17 --> Helper loaded: common_helper
INFO - 2022-03-17 05:36:17 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:36:17 --> Controller Class Initialized
INFO - 2022-03-17 05:36:17 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:36:17 --> Encrypt Class Initialized
INFO - 2022-03-17 05:36:17 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:36:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:36:17 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:36:17 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:36:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 05:36:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:36:18 --> Config Class Initialized
INFO - 2022-03-17 05:36:18 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:36:18 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:36:18 --> Utf8 Class Initialized
INFO - 2022-03-17 05:36:18 --> URI Class Initialized
INFO - 2022-03-17 05:36:18 --> Router Class Initialized
INFO - 2022-03-17 05:36:18 --> Output Class Initialized
INFO - 2022-03-17 05:36:18 --> Security Class Initialized
DEBUG - 2022-03-17 05:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:36:18 --> Input Class Initialized
INFO - 2022-03-17 05:36:18 --> Language Class Initialized
INFO - 2022-03-17 05:36:18 --> Loader Class Initialized
INFO - 2022-03-17 05:36:18 --> Helper loaded: url_helper
INFO - 2022-03-17 05:36:18 --> Helper loaded: form_helper
INFO - 2022-03-17 05:36:18 --> Helper loaded: common_helper
INFO - 2022-03-17 05:36:18 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:36:18 --> Controller Class Initialized
INFO - 2022-03-17 05:36:18 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:36:18 --> Encrypt Class Initialized
INFO - 2022-03-17 05:36:18 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:36:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:36:18 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:36:18 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:36:18 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:36:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:36:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:36:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:36:18 --> Final output sent to browser
DEBUG - 2022-03-17 05:36:18 --> Total execution time: 0.0785
ERROR - 2022-03-17 05:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:36:19 --> Config Class Initialized
INFO - 2022-03-17 05:36:19 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:36:19 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:36:19 --> Utf8 Class Initialized
INFO - 2022-03-17 05:36:19 --> URI Class Initialized
ERROR - 2022-03-17 05:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:36:19 --> Router Class Initialized
INFO - 2022-03-17 05:36:19 --> Config Class Initialized
INFO - 2022-03-17 05:36:19 --> Hooks Class Initialized
INFO - 2022-03-17 05:36:19 --> Output Class Initialized
DEBUG - 2022-03-17 05:36:19 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:36:19 --> Utf8 Class Initialized
INFO - 2022-03-17 05:36:19 --> Security Class Initialized
INFO - 2022-03-17 05:36:19 --> URI Class Initialized
INFO - 2022-03-17 05:36:19 --> Router Class Initialized
DEBUG - 2022-03-17 05:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:36:19 --> Input Class Initialized
INFO - 2022-03-17 05:36:19 --> Language Class Initialized
ERROR - 2022-03-17 05:36:19 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-17 05:36:19 --> Output Class Initialized
INFO - 2022-03-17 05:36:19 --> Security Class Initialized
DEBUG - 2022-03-17 05:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:36:19 --> Input Class Initialized
INFO - 2022-03-17 05:36:19 --> Language Class Initialized
ERROR - 2022-03-17 05:36:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:36:20 --> Config Class Initialized
INFO - 2022-03-17 05:36:20 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:36:20 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:36:20 --> Utf8 Class Initialized
INFO - 2022-03-17 05:36:20 --> URI Class Initialized
INFO - 2022-03-17 05:36:20 --> Router Class Initialized
INFO - 2022-03-17 05:36:20 --> Output Class Initialized
INFO - 2022-03-17 05:36:20 --> Security Class Initialized
DEBUG - 2022-03-17 05:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:36:20 --> Input Class Initialized
INFO - 2022-03-17 05:36:20 --> Language Class Initialized
INFO - 2022-03-17 05:36:20 --> Loader Class Initialized
INFO - 2022-03-17 05:36:20 --> Helper loaded: url_helper
INFO - 2022-03-17 05:36:20 --> Helper loaded: form_helper
INFO - 2022-03-17 05:36:20 --> Helper loaded: common_helper
INFO - 2022-03-17 05:36:20 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:36:20 --> Controller Class Initialized
INFO - 2022-03-17 05:36:20 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:36:20 --> Encrypt Class Initialized
INFO - 2022-03-17 05:36:20 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:36:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:36:20 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:36:20 --> Model "Users_model" initialized
INFO - 2022-03-17 05:36:20 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:36:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:36:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:36:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:36:20 --> Final output sent to browser
DEBUG - 2022-03-17 05:36:20 --> Total execution time: 0.0787
ERROR - 2022-03-17 05:36:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:36:21 --> Config Class Initialized
INFO - 2022-03-17 05:36:21 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:36:21 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:36:21 --> Utf8 Class Initialized
INFO - 2022-03-17 05:36:21 --> URI Class Initialized
INFO - 2022-03-17 05:36:21 --> Router Class Initialized
INFO - 2022-03-17 05:36:21 --> Output Class Initialized
INFO - 2022-03-17 05:36:21 --> Security Class Initialized
DEBUG - 2022-03-17 05:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:36:21 --> Input Class Initialized
INFO - 2022-03-17 05:36:21 --> Language Class Initialized
ERROR - 2022-03-17 05:36:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:36:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:36:35 --> Config Class Initialized
INFO - 2022-03-17 05:36:35 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:36:35 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:36:35 --> Utf8 Class Initialized
INFO - 2022-03-17 05:36:35 --> URI Class Initialized
INFO - 2022-03-17 05:36:35 --> Router Class Initialized
INFO - 2022-03-17 05:36:35 --> Output Class Initialized
INFO - 2022-03-17 05:36:35 --> Security Class Initialized
DEBUG - 2022-03-17 05:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:36:35 --> Input Class Initialized
INFO - 2022-03-17 05:36:35 --> Language Class Initialized
INFO - 2022-03-17 05:36:35 --> Loader Class Initialized
INFO - 2022-03-17 05:36:35 --> Helper loaded: url_helper
INFO - 2022-03-17 05:36:35 --> Helper loaded: form_helper
INFO - 2022-03-17 05:36:35 --> Helper loaded: common_helper
INFO - 2022-03-17 05:36:35 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:36:35 --> Controller Class Initialized
INFO - 2022-03-17 05:36:35 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:36:35 --> Encrypt Class Initialized
INFO - 2022-03-17 05:36:35 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:36:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:36:35 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:36:35 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:36:35 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:36:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:36:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:36:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:36:35 --> Final output sent to browser
DEBUG - 2022-03-17 05:36:35 --> Total execution time: 0.0600
ERROR - 2022-03-17 05:36:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:36:37 --> Config Class Initialized
INFO - 2022-03-17 05:36:37 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:36:37 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:36:37 --> Utf8 Class Initialized
INFO - 2022-03-17 05:36:37 --> URI Class Initialized
INFO - 2022-03-17 05:36:37 --> Router Class Initialized
INFO - 2022-03-17 05:36:37 --> Output Class Initialized
INFO - 2022-03-17 05:36:37 --> Security Class Initialized
DEBUG - 2022-03-17 05:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:36:37 --> Input Class Initialized
INFO - 2022-03-17 05:36:37 --> Language Class Initialized
ERROR - 2022-03-17 05:36:37 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:36:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:36:37 --> Config Class Initialized
INFO - 2022-03-17 05:36:37 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:36:37 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:36:37 --> Utf8 Class Initialized
INFO - 2022-03-17 05:36:37 --> URI Class Initialized
INFO - 2022-03-17 05:36:37 --> Router Class Initialized
INFO - 2022-03-17 05:36:37 --> Output Class Initialized
INFO - 2022-03-17 05:36:37 --> Security Class Initialized
DEBUG - 2022-03-17 05:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:36:37 --> Input Class Initialized
INFO - 2022-03-17 05:36:37 --> Language Class Initialized
ERROR - 2022-03-17 05:36:37 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 05:37:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:37:14 --> Config Class Initialized
INFO - 2022-03-17 05:37:14 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:37:14 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:37:14 --> Utf8 Class Initialized
INFO - 2022-03-17 05:37:14 --> URI Class Initialized
INFO - 2022-03-17 05:37:14 --> Router Class Initialized
INFO - 2022-03-17 05:37:14 --> Output Class Initialized
INFO - 2022-03-17 05:37:14 --> Security Class Initialized
DEBUG - 2022-03-17 05:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:37:14 --> Input Class Initialized
INFO - 2022-03-17 05:37:14 --> Language Class Initialized
INFO - 2022-03-17 05:37:14 --> Loader Class Initialized
INFO - 2022-03-17 05:37:14 --> Helper loaded: url_helper
INFO - 2022-03-17 05:37:14 --> Helper loaded: form_helper
INFO - 2022-03-17 05:37:14 --> Helper loaded: common_helper
INFO - 2022-03-17 05:37:14 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:37:14 --> Controller Class Initialized
INFO - 2022-03-17 05:37:14 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:37:14 --> Encrypt Class Initialized
INFO - 2022-03-17 05:37:14 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:37:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:37:14 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:37:14 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:37:14 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:37:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:37:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:37:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-17 05:37:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:37:21 --> Config Class Initialized
INFO - 2022-03-17 05:37:21 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:37:21 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:37:21 --> Utf8 Class Initialized
INFO - 2022-03-17 05:37:21 --> URI Class Initialized
INFO - 2022-03-17 05:37:21 --> Router Class Initialized
INFO - 2022-03-17 05:37:21 --> Output Class Initialized
INFO - 2022-03-17 05:37:21 --> Security Class Initialized
DEBUG - 2022-03-17 05:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:37:22 --> Input Class Initialized
INFO - 2022-03-17 05:37:22 --> Language Class Initialized
ERROR - 2022-03-17 05:37:22 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-17 05:37:22 --> Final output sent to browser
DEBUG - 2022-03-17 05:37:22 --> Total execution time: 6.3326
ERROR - 2022-03-17 05:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:37:50 --> Config Class Initialized
INFO - 2022-03-17 05:37:50 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:37:50 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:37:50 --> Utf8 Class Initialized
INFO - 2022-03-17 05:37:50 --> URI Class Initialized
INFO - 2022-03-17 05:37:50 --> Router Class Initialized
INFO - 2022-03-17 05:37:50 --> Output Class Initialized
INFO - 2022-03-17 05:37:50 --> Security Class Initialized
DEBUG - 2022-03-17 05:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:37:50 --> Input Class Initialized
INFO - 2022-03-17 05:37:50 --> Language Class Initialized
INFO - 2022-03-17 05:37:50 --> Loader Class Initialized
INFO - 2022-03-17 05:37:50 --> Helper loaded: url_helper
INFO - 2022-03-17 05:37:50 --> Helper loaded: form_helper
INFO - 2022-03-17 05:37:50 --> Helper loaded: common_helper
INFO - 2022-03-17 05:37:50 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:37:50 --> Controller Class Initialized
INFO - 2022-03-17 05:37:50 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:37:50 --> Encrypt Class Initialized
INFO - 2022-03-17 05:37:50 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:37:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:37:50 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:37:50 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:37:50 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:37:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:37:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:37:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:37:50 --> Final output sent to browser
DEBUG - 2022-03-17 05:37:50 --> Total execution time: 0.0470
ERROR - 2022-03-17 05:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:37:50 --> Config Class Initialized
INFO - 2022-03-17 05:37:50 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:37:50 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:37:50 --> Utf8 Class Initialized
INFO - 2022-03-17 05:37:50 --> URI Class Initialized
INFO - 2022-03-17 05:37:50 --> Router Class Initialized
INFO - 2022-03-17 05:37:50 --> Output Class Initialized
INFO - 2022-03-17 05:37:50 --> Security Class Initialized
DEBUG - 2022-03-17 05:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:37:50 --> Input Class Initialized
INFO - 2022-03-17 05:37:50 --> Language Class Initialized
ERROR - 2022-03-17 05:37:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:37:50 --> Config Class Initialized
INFO - 2022-03-17 05:37:50 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:37:50 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:37:50 --> Utf8 Class Initialized
INFO - 2022-03-17 05:37:50 --> URI Class Initialized
INFO - 2022-03-17 05:37:50 --> Router Class Initialized
INFO - 2022-03-17 05:37:50 --> Output Class Initialized
INFO - 2022-03-17 05:37:50 --> Security Class Initialized
DEBUG - 2022-03-17 05:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:37:50 --> Input Class Initialized
INFO - 2022-03-17 05:37:50 --> Language Class Initialized
ERROR - 2022-03-17 05:37:50 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 05:37:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:37:58 --> Config Class Initialized
INFO - 2022-03-17 05:37:58 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:37:58 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:37:58 --> Utf8 Class Initialized
INFO - 2022-03-17 05:37:58 --> URI Class Initialized
INFO - 2022-03-17 05:37:58 --> Router Class Initialized
INFO - 2022-03-17 05:37:58 --> Output Class Initialized
INFO - 2022-03-17 05:37:58 --> Security Class Initialized
DEBUG - 2022-03-17 05:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:37:58 --> Input Class Initialized
INFO - 2022-03-17 05:37:58 --> Language Class Initialized
INFO - 2022-03-17 05:37:58 --> Loader Class Initialized
INFO - 2022-03-17 05:37:58 --> Helper loaded: url_helper
INFO - 2022-03-17 05:37:58 --> Helper loaded: form_helper
INFO - 2022-03-17 05:37:58 --> Helper loaded: common_helper
INFO - 2022-03-17 05:37:58 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:37:58 --> Controller Class Initialized
INFO - 2022-03-17 05:37:58 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:37:58 --> Encrypt Class Initialized
INFO - 2022-03-17 05:37:58 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:37:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:37:58 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:37:58 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:37:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 05:37:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:37:59 --> Config Class Initialized
INFO - 2022-03-17 05:37:59 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:37:59 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:37:59 --> Utf8 Class Initialized
INFO - 2022-03-17 05:37:59 --> URI Class Initialized
INFO - 2022-03-17 05:37:59 --> Router Class Initialized
INFO - 2022-03-17 05:37:59 --> Output Class Initialized
INFO - 2022-03-17 05:37:59 --> Security Class Initialized
DEBUG - 2022-03-17 05:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:37:59 --> Input Class Initialized
INFO - 2022-03-17 05:37:59 --> Language Class Initialized
INFO - 2022-03-17 05:37:59 --> Loader Class Initialized
INFO - 2022-03-17 05:37:59 --> Helper loaded: url_helper
INFO - 2022-03-17 05:37:59 --> Helper loaded: form_helper
INFO - 2022-03-17 05:37:59 --> Helper loaded: common_helper
INFO - 2022-03-17 05:37:59 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:37:59 --> Controller Class Initialized
INFO - 2022-03-17 05:37:59 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:37:59 --> Encrypt Class Initialized
INFO - 2022-03-17 05:37:59 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:37:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:37:59 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:37:59 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:37:59 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:37:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:38:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:38:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-17 05:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:38:06 --> Config Class Initialized
INFO - 2022-03-17 05:38:06 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:38:06 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:38:06 --> Utf8 Class Initialized
INFO - 2022-03-17 05:38:06 --> URI Class Initialized
INFO - 2022-03-17 05:38:06 --> Router Class Initialized
INFO - 2022-03-17 05:38:06 --> Output Class Initialized
INFO - 2022-03-17 05:38:06 --> Security Class Initialized
DEBUG - 2022-03-17 05:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:38:06 --> Input Class Initialized
INFO - 2022-03-17 05:38:06 --> Language Class Initialized
ERROR - 2022-03-17 05:38:06 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-17 05:38:06 --> Final output sent to browser
DEBUG - 2022-03-17 05:38:06 --> Total execution time: 5.7715
ERROR - 2022-03-17 05:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:38:29 --> Config Class Initialized
INFO - 2022-03-17 05:38:29 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:38:29 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:38:29 --> Utf8 Class Initialized
INFO - 2022-03-17 05:38:29 --> URI Class Initialized
INFO - 2022-03-17 05:38:29 --> Router Class Initialized
INFO - 2022-03-17 05:38:29 --> Output Class Initialized
INFO - 2022-03-17 05:38:29 --> Security Class Initialized
DEBUG - 2022-03-17 05:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:38:29 --> Input Class Initialized
INFO - 2022-03-17 05:38:29 --> Language Class Initialized
INFO - 2022-03-17 05:38:29 --> Loader Class Initialized
INFO - 2022-03-17 05:38:29 --> Helper loaded: url_helper
INFO - 2022-03-17 05:38:29 --> Helper loaded: form_helper
INFO - 2022-03-17 05:38:29 --> Helper loaded: common_helper
INFO - 2022-03-17 05:38:29 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:38:29 --> Controller Class Initialized
INFO - 2022-03-17 05:38:29 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:38:29 --> Encrypt Class Initialized
INFO - 2022-03-17 05:38:29 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:38:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:38:29 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:38:29 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:38:29 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:38:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:38:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:38:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:38:29 --> Final output sent to browser
DEBUG - 2022-03-17 05:38:29 --> Total execution time: 0.0623
ERROR - 2022-03-17 05:38:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:38:29 --> Config Class Initialized
INFO - 2022-03-17 05:38:29 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:38:29 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:38:29 --> Utf8 Class Initialized
INFO - 2022-03-17 05:38:29 --> URI Class Initialized
INFO - 2022-03-17 05:38:29 --> Router Class Initialized
INFO - 2022-03-17 05:38:29 --> Output Class Initialized
INFO - 2022-03-17 05:38:29 --> Security Class Initialized
DEBUG - 2022-03-17 05:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:38:29 --> Input Class Initialized
INFO - 2022-03-17 05:38:29 --> Language Class Initialized
ERROR - 2022-03-17 05:38:29 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 05:38:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:38:30 --> Config Class Initialized
INFO - 2022-03-17 05:38:30 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:38:30 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:38:30 --> Utf8 Class Initialized
INFO - 2022-03-17 05:38:30 --> URI Class Initialized
INFO - 2022-03-17 05:38:30 --> Router Class Initialized
INFO - 2022-03-17 05:38:30 --> Output Class Initialized
INFO - 2022-03-17 05:38:30 --> Security Class Initialized
DEBUG - 2022-03-17 05:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:38:30 --> Input Class Initialized
INFO - 2022-03-17 05:38:30 --> Language Class Initialized
ERROR - 2022-03-17 05:38:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:38:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:38:37 --> Config Class Initialized
INFO - 2022-03-17 05:38:37 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:38:37 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:38:37 --> Utf8 Class Initialized
INFO - 2022-03-17 05:38:37 --> URI Class Initialized
INFO - 2022-03-17 05:38:37 --> Router Class Initialized
INFO - 2022-03-17 05:38:37 --> Output Class Initialized
INFO - 2022-03-17 05:38:37 --> Security Class Initialized
DEBUG - 2022-03-17 05:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:38:37 --> Input Class Initialized
INFO - 2022-03-17 05:38:37 --> Language Class Initialized
INFO - 2022-03-17 05:38:37 --> Loader Class Initialized
INFO - 2022-03-17 05:38:37 --> Helper loaded: url_helper
INFO - 2022-03-17 05:38:37 --> Helper loaded: form_helper
INFO - 2022-03-17 05:38:37 --> Helper loaded: common_helper
INFO - 2022-03-17 05:38:37 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:38:37 --> Controller Class Initialized
INFO - 2022-03-17 05:38:37 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:38:37 --> Encrypt Class Initialized
INFO - 2022-03-17 05:38:37 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:38:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:38:37 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:38:37 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:38:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 05:38:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:38:37 --> Config Class Initialized
INFO - 2022-03-17 05:38:37 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:38:37 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:38:37 --> Utf8 Class Initialized
INFO - 2022-03-17 05:38:37 --> URI Class Initialized
INFO - 2022-03-17 05:38:37 --> Router Class Initialized
INFO - 2022-03-17 05:38:37 --> Output Class Initialized
INFO - 2022-03-17 05:38:37 --> Security Class Initialized
DEBUG - 2022-03-17 05:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:38:37 --> Input Class Initialized
INFO - 2022-03-17 05:38:37 --> Language Class Initialized
INFO - 2022-03-17 05:38:37 --> Loader Class Initialized
INFO - 2022-03-17 05:38:37 --> Helper loaded: url_helper
INFO - 2022-03-17 05:38:37 --> Helper loaded: form_helper
INFO - 2022-03-17 05:38:37 --> Helper loaded: common_helper
INFO - 2022-03-17 05:38:37 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:38:37 --> Controller Class Initialized
INFO - 2022-03-17 05:38:37 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:38:37 --> Encrypt Class Initialized
INFO - 2022-03-17 05:38:37 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:38:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:38:37 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:38:37 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:38:37 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:38:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:38:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:38:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-17 05:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:38:44 --> Config Class Initialized
INFO - 2022-03-17 05:38:44 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:38:44 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:38:44 --> Utf8 Class Initialized
INFO - 2022-03-17 05:38:44 --> URI Class Initialized
INFO - 2022-03-17 05:38:44 --> Router Class Initialized
INFO - 2022-03-17 05:38:44 --> Output Class Initialized
INFO - 2022-03-17 05:38:44 --> Security Class Initialized
DEBUG - 2022-03-17 05:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:38:44 --> Input Class Initialized
INFO - 2022-03-17 05:38:44 --> Language Class Initialized
ERROR - 2022-03-17 05:38:44 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-17 05:38:45 --> Final output sent to browser
DEBUG - 2022-03-17 05:38:45 --> Total execution time: 5.8542
ERROR - 2022-03-17 05:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:39:06 --> Config Class Initialized
INFO - 2022-03-17 05:39:06 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:39:06 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:39:06 --> Utf8 Class Initialized
INFO - 2022-03-17 05:39:06 --> URI Class Initialized
INFO - 2022-03-17 05:39:06 --> Router Class Initialized
INFO - 2022-03-17 05:39:06 --> Output Class Initialized
INFO - 2022-03-17 05:39:06 --> Security Class Initialized
DEBUG - 2022-03-17 05:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:39:06 --> Input Class Initialized
INFO - 2022-03-17 05:39:06 --> Language Class Initialized
INFO - 2022-03-17 05:39:06 --> Loader Class Initialized
INFO - 2022-03-17 05:39:06 --> Helper loaded: url_helper
INFO - 2022-03-17 05:39:06 --> Helper loaded: form_helper
INFO - 2022-03-17 05:39:06 --> Helper loaded: common_helper
INFO - 2022-03-17 05:39:06 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:39:06 --> Controller Class Initialized
INFO - 2022-03-17 05:39:06 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:39:06 --> Encrypt Class Initialized
INFO - 2022-03-17 05:39:06 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:39:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:39:06 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:39:06 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:39:06 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:39:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:39:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:39:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:39:06 --> Final output sent to browser
DEBUG - 2022-03-17 05:39:06 --> Total execution time: 0.0614
ERROR - 2022-03-17 05:39:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:39:07 --> Config Class Initialized
INFO - 2022-03-17 05:39:07 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:39:07 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:39:07 --> Utf8 Class Initialized
INFO - 2022-03-17 05:39:07 --> URI Class Initialized
INFO - 2022-03-17 05:39:07 --> Router Class Initialized
INFO - 2022-03-17 05:39:07 --> Output Class Initialized
INFO - 2022-03-17 05:39:07 --> Security Class Initialized
DEBUG - 2022-03-17 05:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:39:07 --> Input Class Initialized
INFO - 2022-03-17 05:39:07 --> Language Class Initialized
ERROR - 2022-03-17 05:39:07 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 05:39:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:39:07 --> Config Class Initialized
INFO - 2022-03-17 05:39:07 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:39:07 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:39:07 --> Utf8 Class Initialized
INFO - 2022-03-17 05:39:07 --> URI Class Initialized
INFO - 2022-03-17 05:39:07 --> Router Class Initialized
INFO - 2022-03-17 05:39:07 --> Output Class Initialized
INFO - 2022-03-17 05:39:07 --> Security Class Initialized
DEBUG - 2022-03-17 05:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:39:07 --> Input Class Initialized
INFO - 2022-03-17 05:39:07 --> Language Class Initialized
ERROR - 2022-03-17 05:39:07 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:39:22 --> Config Class Initialized
INFO - 2022-03-17 05:39:22 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:39:22 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:39:22 --> Utf8 Class Initialized
INFO - 2022-03-17 05:39:22 --> URI Class Initialized
INFO - 2022-03-17 05:39:22 --> Router Class Initialized
INFO - 2022-03-17 05:39:22 --> Output Class Initialized
INFO - 2022-03-17 05:39:22 --> Security Class Initialized
DEBUG - 2022-03-17 05:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:39:22 --> Input Class Initialized
INFO - 2022-03-17 05:39:22 --> Language Class Initialized
INFO - 2022-03-17 05:39:22 --> Loader Class Initialized
INFO - 2022-03-17 05:39:22 --> Helper loaded: url_helper
INFO - 2022-03-17 05:39:22 --> Helper loaded: form_helper
INFO - 2022-03-17 05:39:22 --> Helper loaded: common_helper
INFO - 2022-03-17 05:39:22 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:39:22 --> Controller Class Initialized
INFO - 2022-03-17 05:39:22 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:39:22 --> Encrypt Class Initialized
INFO - 2022-03-17 05:39:22 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:39:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:39:22 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:39:22 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:39:22 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:39:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:39:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:39:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-17 05:39:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:39:32 --> Config Class Initialized
INFO - 2022-03-17 05:39:32 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:39:32 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:39:32 --> Utf8 Class Initialized
INFO - 2022-03-17 05:39:32 --> URI Class Initialized
INFO - 2022-03-17 05:39:32 --> Router Class Initialized
INFO - 2022-03-17 05:39:32 --> Output Class Initialized
INFO - 2022-03-17 05:39:32 --> Security Class Initialized
DEBUG - 2022-03-17 05:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:39:32 --> Input Class Initialized
INFO - 2022-03-17 05:39:32 --> Language Class Initialized
ERROR - 2022-03-17 05:39:32 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-17 05:39:32 --> Final output sent to browser
DEBUG - 2022-03-17 05:39:32 --> Total execution time: 8.6787
ERROR - 2022-03-17 05:40:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:40:14 --> Config Class Initialized
INFO - 2022-03-17 05:40:14 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:40:14 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:40:14 --> Utf8 Class Initialized
INFO - 2022-03-17 05:40:14 --> URI Class Initialized
INFO - 2022-03-17 05:40:14 --> Router Class Initialized
INFO - 2022-03-17 05:40:14 --> Output Class Initialized
INFO - 2022-03-17 05:40:14 --> Security Class Initialized
DEBUG - 2022-03-17 05:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:40:14 --> Input Class Initialized
INFO - 2022-03-17 05:40:14 --> Language Class Initialized
INFO - 2022-03-17 05:40:14 --> Loader Class Initialized
INFO - 2022-03-17 05:40:14 --> Helper loaded: url_helper
INFO - 2022-03-17 05:40:14 --> Helper loaded: form_helper
INFO - 2022-03-17 05:40:14 --> Helper loaded: common_helper
INFO - 2022-03-17 05:40:14 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:40:14 --> Controller Class Initialized
INFO - 2022-03-17 05:40:14 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:40:14 --> Encrypt Class Initialized
INFO - 2022-03-17 05:40:14 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:40:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:40:14 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:40:14 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:40:14 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:40:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:40:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:40:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-17 05:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:40:23 --> Config Class Initialized
INFO - 2022-03-17 05:40:23 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:40:23 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:40:23 --> Utf8 Class Initialized
INFO - 2022-03-17 05:40:23 --> URI Class Initialized
INFO - 2022-03-17 05:40:23 --> Router Class Initialized
INFO - 2022-03-17 05:40:23 --> Output Class Initialized
INFO - 2022-03-17 05:40:23 --> Security Class Initialized
DEBUG - 2022-03-17 05:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:40:23 --> Input Class Initialized
INFO - 2022-03-17 05:40:23 --> Language Class Initialized
ERROR - 2022-03-17 05:40:23 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-17 05:40:23 --> Final output sent to browser
DEBUG - 2022-03-17 05:40:23 --> Total execution time: 7.4398
ERROR - 2022-03-17 05:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:40:43 --> Config Class Initialized
INFO - 2022-03-17 05:40:43 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:40:43 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:40:43 --> Utf8 Class Initialized
INFO - 2022-03-17 05:40:43 --> URI Class Initialized
INFO - 2022-03-17 05:40:43 --> Router Class Initialized
INFO - 2022-03-17 05:40:43 --> Output Class Initialized
INFO - 2022-03-17 05:40:43 --> Security Class Initialized
DEBUG - 2022-03-17 05:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:40:43 --> Input Class Initialized
INFO - 2022-03-17 05:40:43 --> Language Class Initialized
INFO - 2022-03-17 05:40:43 --> Loader Class Initialized
INFO - 2022-03-17 05:40:43 --> Helper loaded: url_helper
INFO - 2022-03-17 05:40:43 --> Helper loaded: form_helper
INFO - 2022-03-17 05:40:43 --> Helper loaded: common_helper
INFO - 2022-03-17 05:40:43 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:40:43 --> Controller Class Initialized
INFO - 2022-03-17 05:40:43 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:40:43 --> Encrypt Class Initialized
INFO - 2022-03-17 05:40:43 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:40:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:40:43 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:40:43 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:40:43 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:40:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:40:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:40:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:40:43 --> Final output sent to browser
DEBUG - 2022-03-17 05:40:43 --> Total execution time: 0.0816
ERROR - 2022-03-17 05:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:40:44 --> Config Class Initialized
INFO - 2022-03-17 05:40:44 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:40:44 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:40:44 --> Utf8 Class Initialized
INFO - 2022-03-17 05:40:44 --> URI Class Initialized
INFO - 2022-03-17 05:40:44 --> Router Class Initialized
INFO - 2022-03-17 05:40:44 --> Output Class Initialized
INFO - 2022-03-17 05:40:44 --> Security Class Initialized
DEBUG - 2022-03-17 05:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:40:44 --> Input Class Initialized
INFO - 2022-03-17 05:40:44 --> Language Class Initialized
ERROR - 2022-03-17 05:40:44 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 05:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:40:44 --> Config Class Initialized
INFO - 2022-03-17 05:40:44 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:40:44 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:40:44 --> Utf8 Class Initialized
INFO - 2022-03-17 05:40:44 --> URI Class Initialized
INFO - 2022-03-17 05:40:44 --> Router Class Initialized
INFO - 2022-03-17 05:40:44 --> Output Class Initialized
INFO - 2022-03-17 05:40:44 --> Security Class Initialized
DEBUG - 2022-03-17 05:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:40:44 --> Input Class Initialized
INFO - 2022-03-17 05:40:44 --> Language Class Initialized
ERROR - 2022-03-17 05:40:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:41:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:41:27 --> Config Class Initialized
INFO - 2022-03-17 05:41:27 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:41:27 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:41:27 --> Utf8 Class Initialized
INFO - 2022-03-17 05:41:27 --> URI Class Initialized
INFO - 2022-03-17 05:41:27 --> Router Class Initialized
INFO - 2022-03-17 05:41:27 --> Output Class Initialized
INFO - 2022-03-17 05:41:27 --> Security Class Initialized
DEBUG - 2022-03-17 05:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:41:27 --> Input Class Initialized
INFO - 2022-03-17 05:41:27 --> Language Class Initialized
INFO - 2022-03-17 05:41:27 --> Loader Class Initialized
INFO - 2022-03-17 05:41:27 --> Helper loaded: url_helper
INFO - 2022-03-17 05:41:27 --> Helper loaded: form_helper
INFO - 2022-03-17 05:41:27 --> Helper loaded: common_helper
INFO - 2022-03-17 05:41:27 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:41:27 --> Controller Class Initialized
INFO - 2022-03-17 05:41:27 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:41:27 --> Encrypt Class Initialized
INFO - 2022-03-17 05:41:27 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:41:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:41:27 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:41:27 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:41:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 05:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:41:28 --> Config Class Initialized
INFO - 2022-03-17 05:41:28 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:41:28 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:41:28 --> Utf8 Class Initialized
INFO - 2022-03-17 05:41:28 --> URI Class Initialized
INFO - 2022-03-17 05:41:28 --> Router Class Initialized
INFO - 2022-03-17 05:41:28 --> Output Class Initialized
INFO - 2022-03-17 05:41:28 --> Security Class Initialized
DEBUG - 2022-03-17 05:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:41:28 --> Input Class Initialized
INFO - 2022-03-17 05:41:28 --> Language Class Initialized
INFO - 2022-03-17 05:41:28 --> Loader Class Initialized
INFO - 2022-03-17 05:41:28 --> Helper loaded: url_helper
INFO - 2022-03-17 05:41:28 --> Helper loaded: form_helper
INFO - 2022-03-17 05:41:28 --> Helper loaded: common_helper
INFO - 2022-03-17 05:41:28 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:41:28 --> Controller Class Initialized
INFO - 2022-03-17 05:41:28 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:41:28 --> Encrypt Class Initialized
INFO - 2022-03-17 05:41:28 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:41:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:41:28 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:41:28 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:41:28 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:41:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:41:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:41:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:41:28 --> Final output sent to browser
DEBUG - 2022-03-17 05:41:28 --> Total execution time: 0.0791
ERROR - 2022-03-17 05:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:41:29 --> Config Class Initialized
INFO - 2022-03-17 05:41:29 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:41:29 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:41:29 --> Utf8 Class Initialized
INFO - 2022-03-17 05:41:29 --> URI Class Initialized
INFO - 2022-03-17 05:41:29 --> Router Class Initialized
INFO - 2022-03-17 05:41:29 --> Output Class Initialized
INFO - 2022-03-17 05:41:29 --> Security Class Initialized
DEBUG - 2022-03-17 05:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:41:29 --> Input Class Initialized
INFO - 2022-03-17 05:41:29 --> Language Class Initialized
ERROR - 2022-03-17 05:41:29 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 05:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:41:29 --> Config Class Initialized
INFO - 2022-03-17 05:41:29 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:41:29 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:41:29 --> Utf8 Class Initialized
INFO - 2022-03-17 05:41:29 --> URI Class Initialized
INFO - 2022-03-17 05:41:29 --> Router Class Initialized
INFO - 2022-03-17 05:41:29 --> Output Class Initialized
INFO - 2022-03-17 05:41:29 --> Security Class Initialized
DEBUG - 2022-03-17 05:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:41:29 --> Input Class Initialized
INFO - 2022-03-17 05:41:29 --> Language Class Initialized
ERROR - 2022-03-17 05:41:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:41:29 --> Config Class Initialized
INFO - 2022-03-17 05:41:29 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:41:29 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:41:29 --> Utf8 Class Initialized
INFO - 2022-03-17 05:41:29 --> URI Class Initialized
INFO - 2022-03-17 05:41:29 --> Router Class Initialized
INFO - 2022-03-17 05:41:29 --> Output Class Initialized
INFO - 2022-03-17 05:41:29 --> Security Class Initialized
DEBUG - 2022-03-17 05:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:41:29 --> Input Class Initialized
INFO - 2022-03-17 05:41:29 --> Language Class Initialized
INFO - 2022-03-17 05:41:29 --> Loader Class Initialized
INFO - 2022-03-17 05:41:29 --> Helper loaded: url_helper
INFO - 2022-03-17 05:41:29 --> Helper loaded: form_helper
INFO - 2022-03-17 05:41:29 --> Helper loaded: common_helper
INFO - 2022-03-17 05:41:29 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:41:29 --> Controller Class Initialized
INFO - 2022-03-17 05:41:29 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:41:29 --> Encrypt Class Initialized
INFO - 2022-03-17 05:41:29 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:41:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:41:29 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:41:29 --> Model "Users_model" initialized
INFO - 2022-03-17 05:41:29 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:41:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:41:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:41:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:41:29 --> Final output sent to browser
DEBUG - 2022-03-17 05:41:29 --> Total execution time: 0.1405
ERROR - 2022-03-17 05:41:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:41:30 --> Config Class Initialized
INFO - 2022-03-17 05:41:30 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:41:30 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:41:30 --> Utf8 Class Initialized
INFO - 2022-03-17 05:41:30 --> URI Class Initialized
INFO - 2022-03-17 05:41:30 --> Router Class Initialized
INFO - 2022-03-17 05:41:30 --> Output Class Initialized
INFO - 2022-03-17 05:41:30 --> Security Class Initialized
DEBUG - 2022-03-17 05:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:41:30 --> Input Class Initialized
INFO - 2022-03-17 05:41:30 --> Language Class Initialized
ERROR - 2022-03-17 05:41:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 05:42:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:42:35 --> Config Class Initialized
INFO - 2022-03-17 05:42:35 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:42:35 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:42:35 --> Utf8 Class Initialized
INFO - 2022-03-17 05:42:35 --> URI Class Initialized
INFO - 2022-03-17 05:42:35 --> Router Class Initialized
INFO - 2022-03-17 05:42:35 --> Output Class Initialized
INFO - 2022-03-17 05:42:35 --> Security Class Initialized
DEBUG - 2022-03-17 05:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:42:35 --> Input Class Initialized
INFO - 2022-03-17 05:42:35 --> Language Class Initialized
INFO - 2022-03-17 05:42:35 --> Loader Class Initialized
INFO - 2022-03-17 05:42:35 --> Helper loaded: url_helper
INFO - 2022-03-17 05:42:35 --> Helper loaded: form_helper
INFO - 2022-03-17 05:42:35 --> Helper loaded: common_helper
INFO - 2022-03-17 05:42:35 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:42:35 --> Controller Class Initialized
INFO - 2022-03-17 05:42:35 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:42:35 --> Encrypt Class Initialized
INFO - 2022-03-17 05:42:35 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:42:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:42:35 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:42:35 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:42:35 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:42:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:42:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:42:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-17 05:42:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:42:45 --> Config Class Initialized
INFO - 2022-03-17 05:42:45 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:42:45 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:42:45 --> Utf8 Class Initialized
INFO - 2022-03-17 05:42:45 --> URI Class Initialized
INFO - 2022-03-17 05:42:45 --> Router Class Initialized
INFO - 2022-03-17 05:42:45 --> Output Class Initialized
INFO - 2022-03-17 05:42:45 --> Security Class Initialized
DEBUG - 2022-03-17 05:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:42:45 --> Input Class Initialized
INFO - 2022-03-17 05:42:45 --> Language Class Initialized
ERROR - 2022-03-17 05:42:45 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-17 05:42:46 --> Final output sent to browser
DEBUG - 2022-03-17 05:42:46 --> Total execution time: 8.3154
ERROR - 2022-03-17 05:46:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:46:31 --> Config Class Initialized
INFO - 2022-03-17 05:46:31 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:46:31 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:46:31 --> Utf8 Class Initialized
INFO - 2022-03-17 05:46:31 --> URI Class Initialized
INFO - 2022-03-17 05:46:31 --> Router Class Initialized
INFO - 2022-03-17 05:46:31 --> Output Class Initialized
INFO - 2022-03-17 05:46:31 --> Security Class Initialized
DEBUG - 2022-03-17 05:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:46:31 --> Input Class Initialized
INFO - 2022-03-17 05:46:31 --> Language Class Initialized
INFO - 2022-03-17 05:46:31 --> Loader Class Initialized
INFO - 2022-03-17 05:46:31 --> Helper loaded: url_helper
INFO - 2022-03-17 05:46:31 --> Helper loaded: form_helper
INFO - 2022-03-17 05:46:31 --> Helper loaded: common_helper
INFO - 2022-03-17 05:46:31 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:46:31 --> Controller Class Initialized
INFO - 2022-03-17 05:46:31 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:46:31 --> Encrypt Class Initialized
INFO - 2022-03-17 05:46:31 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:46:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:46:31 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:46:31 --> Model "Users_model" initialized
INFO - 2022-03-17 05:46:31 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:46:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:46:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 05:46:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:46:31 --> Final output sent to browser
DEBUG - 2022-03-17 05:46:31 --> Total execution time: 0.1026
ERROR - 2022-03-17 05:46:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:46:34 --> Config Class Initialized
INFO - 2022-03-17 05:46:34 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:46:34 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:46:34 --> Utf8 Class Initialized
INFO - 2022-03-17 05:46:34 --> URI Class Initialized
INFO - 2022-03-17 05:46:34 --> Router Class Initialized
INFO - 2022-03-17 05:46:34 --> Output Class Initialized
INFO - 2022-03-17 05:46:34 --> Security Class Initialized
DEBUG - 2022-03-17 05:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:46:34 --> Input Class Initialized
INFO - 2022-03-17 05:46:34 --> Language Class Initialized
INFO - 2022-03-17 05:46:34 --> Loader Class Initialized
INFO - 2022-03-17 05:46:34 --> Helper loaded: url_helper
INFO - 2022-03-17 05:46:34 --> Helper loaded: form_helper
INFO - 2022-03-17 05:46:34 --> Helper loaded: common_helper
INFO - 2022-03-17 05:46:34 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:46:34 --> Controller Class Initialized
INFO - 2022-03-17 05:46:34 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:46:34 --> Encrypt Class Initialized
INFO - 2022-03-17 05:46:34 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:46:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:46:34 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:46:34 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:46:34 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:46:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:46:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:46:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:46:34 --> Final output sent to browser
DEBUG - 2022-03-17 05:46:34 --> Total execution time: 0.0538
ERROR - 2022-03-17 05:46:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:46:53 --> Config Class Initialized
INFO - 2022-03-17 05:46:53 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:46:53 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:46:53 --> Utf8 Class Initialized
INFO - 2022-03-17 05:46:53 --> URI Class Initialized
INFO - 2022-03-17 05:46:53 --> Router Class Initialized
INFO - 2022-03-17 05:46:53 --> Output Class Initialized
INFO - 2022-03-17 05:46:53 --> Security Class Initialized
DEBUG - 2022-03-17 05:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:46:53 --> Input Class Initialized
INFO - 2022-03-17 05:46:53 --> Language Class Initialized
INFO - 2022-03-17 05:46:53 --> Loader Class Initialized
INFO - 2022-03-17 05:46:53 --> Helper loaded: url_helper
INFO - 2022-03-17 05:46:53 --> Helper loaded: form_helper
INFO - 2022-03-17 05:46:53 --> Helper loaded: common_helper
INFO - 2022-03-17 05:46:53 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:46:53 --> Controller Class Initialized
INFO - 2022-03-17 05:46:53 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:46:53 --> Encrypt Class Initialized
INFO - 2022-03-17 05:46:53 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:46:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:46:53 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:46:53 --> Model "Users_model" initialized
INFO - 2022-03-17 05:46:53 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:46:53 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 05:46:54 --> Final output sent to browser
DEBUG - 2022-03-17 05:46:54 --> Total execution time: 1.3893
ERROR - 2022-03-17 05:48:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:48:10 --> Config Class Initialized
INFO - 2022-03-17 05:48:10 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:48:10 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:48:10 --> Utf8 Class Initialized
INFO - 2022-03-17 05:48:10 --> URI Class Initialized
INFO - 2022-03-17 05:48:10 --> Router Class Initialized
INFO - 2022-03-17 05:48:10 --> Output Class Initialized
INFO - 2022-03-17 05:48:10 --> Security Class Initialized
DEBUG - 2022-03-17 05:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:48:10 --> Input Class Initialized
INFO - 2022-03-17 05:48:10 --> Language Class Initialized
INFO - 2022-03-17 05:48:10 --> Loader Class Initialized
INFO - 2022-03-17 05:48:10 --> Helper loaded: url_helper
INFO - 2022-03-17 05:48:10 --> Helper loaded: form_helper
INFO - 2022-03-17 05:48:10 --> Helper loaded: common_helper
INFO - 2022-03-17 05:48:10 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:48:10 --> Controller Class Initialized
INFO - 2022-03-17 05:48:10 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:48:10 --> Encrypt Class Initialized
INFO - 2022-03-17 05:48:10 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:48:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:48:10 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:48:10 --> Model "Users_model" initialized
INFO - 2022-03-17 05:48:10 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:48:10 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 05:48:11 --> Final output sent to browser
DEBUG - 2022-03-17 05:48:11 --> Total execution time: 1.1773
ERROR - 2022-03-17 05:48:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:48:45 --> Config Class Initialized
INFO - 2022-03-17 05:48:45 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:48:45 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:48:45 --> Utf8 Class Initialized
INFO - 2022-03-17 05:48:45 --> URI Class Initialized
INFO - 2022-03-17 05:48:45 --> Router Class Initialized
INFO - 2022-03-17 05:48:45 --> Output Class Initialized
INFO - 2022-03-17 05:48:45 --> Security Class Initialized
DEBUG - 2022-03-17 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:48:45 --> Input Class Initialized
INFO - 2022-03-17 05:48:45 --> Language Class Initialized
INFO - 2022-03-17 05:48:45 --> Loader Class Initialized
INFO - 2022-03-17 05:48:45 --> Helper loaded: url_helper
INFO - 2022-03-17 05:48:45 --> Helper loaded: form_helper
INFO - 2022-03-17 05:48:45 --> Helper loaded: common_helper
INFO - 2022-03-17 05:48:45 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:48:45 --> Controller Class Initialized
INFO - 2022-03-17 05:48:45 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:48:45 --> Encrypt Class Initialized
INFO - 2022-03-17 05:48:45 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:48:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:48:45 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:48:45 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:48:45 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:48:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:48:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:48:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:48:45 --> Final output sent to browser
DEBUG - 2022-03-17 05:48:45 --> Total execution time: 0.0608
ERROR - 2022-03-17 05:49:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:49:27 --> Config Class Initialized
INFO - 2022-03-17 05:49:27 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:49:27 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:49:27 --> Utf8 Class Initialized
INFO - 2022-03-17 05:49:27 --> URI Class Initialized
INFO - 2022-03-17 05:49:27 --> Router Class Initialized
INFO - 2022-03-17 05:49:27 --> Output Class Initialized
INFO - 2022-03-17 05:49:27 --> Security Class Initialized
DEBUG - 2022-03-17 05:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:49:27 --> Input Class Initialized
INFO - 2022-03-17 05:49:27 --> Language Class Initialized
INFO - 2022-03-17 05:49:27 --> Loader Class Initialized
INFO - 2022-03-17 05:49:27 --> Helper loaded: url_helper
INFO - 2022-03-17 05:49:27 --> Helper loaded: form_helper
INFO - 2022-03-17 05:49:27 --> Helper loaded: common_helper
INFO - 2022-03-17 05:49:27 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:49:27 --> Controller Class Initialized
INFO - 2022-03-17 05:49:27 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:49:27 --> Encrypt Class Initialized
INFO - 2022-03-17 05:49:27 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:49:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:49:27 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:49:27 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:49:27 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:49:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:49:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:49:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:49:27 --> Final output sent to browser
DEBUG - 2022-03-17 05:49:27 --> Total execution time: 0.0492
ERROR - 2022-03-17 05:49:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:49:43 --> Config Class Initialized
INFO - 2022-03-17 05:49:43 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:49:43 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:49:43 --> Utf8 Class Initialized
INFO - 2022-03-17 05:49:43 --> URI Class Initialized
INFO - 2022-03-17 05:49:43 --> Router Class Initialized
INFO - 2022-03-17 05:49:43 --> Output Class Initialized
INFO - 2022-03-17 05:49:43 --> Security Class Initialized
DEBUG - 2022-03-17 05:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:49:43 --> Input Class Initialized
INFO - 2022-03-17 05:49:43 --> Language Class Initialized
INFO - 2022-03-17 05:49:43 --> Loader Class Initialized
INFO - 2022-03-17 05:49:43 --> Helper loaded: url_helper
INFO - 2022-03-17 05:49:43 --> Helper loaded: form_helper
INFO - 2022-03-17 05:49:43 --> Helper loaded: common_helper
INFO - 2022-03-17 05:49:43 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:49:43 --> Controller Class Initialized
INFO - 2022-03-17 05:49:43 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:49:43 --> Encrypt Class Initialized
INFO - 2022-03-17 05:49:43 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:49:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:49:43 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:49:43 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:49:43 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:49:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:49:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:49:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:49:43 --> Final output sent to browser
DEBUG - 2022-03-17 05:49:43 --> Total execution time: 0.0597
ERROR - 2022-03-17 05:49:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:49:45 --> Config Class Initialized
INFO - 2022-03-17 05:49:45 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:49:45 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:49:45 --> Utf8 Class Initialized
INFO - 2022-03-17 05:49:45 --> URI Class Initialized
INFO - 2022-03-17 05:49:45 --> Router Class Initialized
INFO - 2022-03-17 05:49:45 --> Output Class Initialized
INFO - 2022-03-17 05:49:45 --> Security Class Initialized
DEBUG - 2022-03-17 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:49:45 --> Input Class Initialized
INFO - 2022-03-17 05:49:45 --> Language Class Initialized
INFO - 2022-03-17 05:49:45 --> Loader Class Initialized
INFO - 2022-03-17 05:49:45 --> Helper loaded: url_helper
INFO - 2022-03-17 05:49:45 --> Helper loaded: form_helper
INFO - 2022-03-17 05:49:45 --> Helper loaded: common_helper
INFO - 2022-03-17 05:49:45 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:49:45 --> Controller Class Initialized
INFO - 2022-03-17 05:49:45 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:49:45 --> Encrypt Class Initialized
INFO - 2022-03-17 05:49:45 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:49:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:49:45 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:49:45 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:49:45 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:49:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:49:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:49:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:49:45 --> Final output sent to browser
DEBUG - 2022-03-17 05:49:45 --> Total execution time: 0.1000
ERROR - 2022-03-17 05:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:49:47 --> Config Class Initialized
INFO - 2022-03-17 05:49:47 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:49:47 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:49:47 --> Utf8 Class Initialized
INFO - 2022-03-17 05:49:47 --> URI Class Initialized
INFO - 2022-03-17 05:49:47 --> Router Class Initialized
INFO - 2022-03-17 05:49:47 --> Output Class Initialized
INFO - 2022-03-17 05:49:47 --> Security Class Initialized
DEBUG - 2022-03-17 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:49:47 --> Input Class Initialized
INFO - 2022-03-17 05:49:47 --> Language Class Initialized
INFO - 2022-03-17 05:49:47 --> Loader Class Initialized
INFO - 2022-03-17 05:49:47 --> Helper loaded: url_helper
INFO - 2022-03-17 05:49:47 --> Helper loaded: form_helper
INFO - 2022-03-17 05:49:47 --> Helper loaded: common_helper
INFO - 2022-03-17 05:49:47 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:49:47 --> Controller Class Initialized
INFO - 2022-03-17 05:49:47 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:49:47 --> Encrypt Class Initialized
INFO - 2022-03-17 05:49:47 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:49:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:49:47 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:49:47 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:49:47 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:49:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:49:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:49:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:49:47 --> Final output sent to browser
DEBUG - 2022-03-17 05:49:47 --> Total execution time: 0.0689
ERROR - 2022-03-17 05:49:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:49:57 --> Config Class Initialized
INFO - 2022-03-17 05:49:57 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:49:57 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:49:57 --> Utf8 Class Initialized
INFO - 2022-03-17 05:49:57 --> URI Class Initialized
INFO - 2022-03-17 05:49:57 --> Router Class Initialized
INFO - 2022-03-17 05:49:57 --> Output Class Initialized
INFO - 2022-03-17 05:49:57 --> Security Class Initialized
DEBUG - 2022-03-17 05:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:49:57 --> Input Class Initialized
INFO - 2022-03-17 05:49:57 --> Language Class Initialized
INFO - 2022-03-17 05:49:57 --> Loader Class Initialized
INFO - 2022-03-17 05:49:57 --> Helper loaded: url_helper
INFO - 2022-03-17 05:49:57 --> Helper loaded: form_helper
INFO - 2022-03-17 05:49:57 --> Helper loaded: common_helper
INFO - 2022-03-17 05:49:57 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:49:57 --> Controller Class Initialized
INFO - 2022-03-17 05:49:57 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:49:57 --> Encrypt Class Initialized
INFO - 2022-03-17 05:49:57 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:49:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:49:57 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:49:57 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:49:57 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:49:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:49:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:49:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:49:57 --> Final output sent to browser
DEBUG - 2022-03-17 05:49:57 --> Total execution time: 0.0885
ERROR - 2022-03-17 05:50:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:50:04 --> Config Class Initialized
INFO - 2022-03-17 05:50:04 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:50:04 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:50:04 --> Utf8 Class Initialized
INFO - 2022-03-17 05:50:04 --> URI Class Initialized
INFO - 2022-03-17 05:50:04 --> Router Class Initialized
INFO - 2022-03-17 05:50:04 --> Output Class Initialized
INFO - 2022-03-17 05:50:04 --> Security Class Initialized
DEBUG - 2022-03-17 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:50:04 --> Input Class Initialized
INFO - 2022-03-17 05:50:04 --> Language Class Initialized
INFO - 2022-03-17 05:50:04 --> Loader Class Initialized
INFO - 2022-03-17 05:50:04 --> Helper loaded: url_helper
INFO - 2022-03-17 05:50:04 --> Helper loaded: form_helper
INFO - 2022-03-17 05:50:04 --> Helper loaded: common_helper
INFO - 2022-03-17 05:50:04 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:50:04 --> Controller Class Initialized
INFO - 2022-03-17 05:50:04 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:50:04 --> Encrypt Class Initialized
INFO - 2022-03-17 05:50:04 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:50:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:50:04 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:50:04 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:50:04 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:50:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:50:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:50:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:50:04 --> Final output sent to browser
DEBUG - 2022-03-17 05:50:04 --> Total execution time: 0.0818
ERROR - 2022-03-17 05:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:50:06 --> Config Class Initialized
INFO - 2022-03-17 05:50:06 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:50:06 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:50:06 --> Utf8 Class Initialized
INFO - 2022-03-17 05:50:06 --> URI Class Initialized
INFO - 2022-03-17 05:50:06 --> Router Class Initialized
INFO - 2022-03-17 05:50:06 --> Output Class Initialized
INFO - 2022-03-17 05:50:06 --> Security Class Initialized
DEBUG - 2022-03-17 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:50:06 --> Input Class Initialized
INFO - 2022-03-17 05:50:06 --> Language Class Initialized
INFO - 2022-03-17 05:50:06 --> Loader Class Initialized
INFO - 2022-03-17 05:50:06 --> Helper loaded: url_helper
INFO - 2022-03-17 05:50:06 --> Helper loaded: form_helper
INFO - 2022-03-17 05:50:06 --> Helper loaded: common_helper
INFO - 2022-03-17 05:50:06 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:50:06 --> Controller Class Initialized
INFO - 2022-03-17 05:50:06 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:50:06 --> Encrypt Class Initialized
INFO - 2022-03-17 05:50:06 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:50:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:50:06 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:50:06 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:50:06 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:50:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:50:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 05:50:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:50:06 --> Final output sent to browser
DEBUG - 2022-03-17 05:50:06 --> Total execution time: 0.0716
ERROR - 2022-03-17 05:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:50:13 --> Config Class Initialized
INFO - 2022-03-17 05:50:13 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:50:13 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:50:13 --> Utf8 Class Initialized
INFO - 2022-03-17 05:50:13 --> URI Class Initialized
INFO - 2022-03-17 05:50:13 --> Router Class Initialized
INFO - 2022-03-17 05:50:13 --> Output Class Initialized
INFO - 2022-03-17 05:50:13 --> Security Class Initialized
DEBUG - 2022-03-17 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:50:13 --> Input Class Initialized
INFO - 2022-03-17 05:50:13 --> Language Class Initialized
INFO - 2022-03-17 05:50:13 --> Loader Class Initialized
INFO - 2022-03-17 05:50:13 --> Helper loaded: url_helper
INFO - 2022-03-17 05:50:13 --> Helper loaded: form_helper
INFO - 2022-03-17 05:50:13 --> Helper loaded: common_helper
INFO - 2022-03-17 05:50:13 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:50:13 --> Controller Class Initialized
INFO - 2022-03-17 05:50:13 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:50:13 --> Encrypt Class Initialized
INFO - 2022-03-17 05:50:13 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:50:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:50:13 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:50:13 --> Model "Users_model" initialized
INFO - 2022-03-17 05:50:13 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:50:13 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 05:50:14 --> Final output sent to browser
DEBUG - 2022-03-17 05:50:14 --> Total execution time: 1.0364
ERROR - 2022-03-17 05:50:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:50:20 --> Config Class Initialized
INFO - 2022-03-17 05:50:20 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:50:20 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:50:20 --> Utf8 Class Initialized
INFO - 2022-03-17 05:50:20 --> URI Class Initialized
INFO - 2022-03-17 05:50:20 --> Router Class Initialized
INFO - 2022-03-17 05:50:20 --> Output Class Initialized
INFO - 2022-03-17 05:50:20 --> Security Class Initialized
DEBUG - 2022-03-17 05:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:50:20 --> Input Class Initialized
INFO - 2022-03-17 05:50:20 --> Language Class Initialized
INFO - 2022-03-17 05:50:20 --> Loader Class Initialized
INFO - 2022-03-17 05:50:20 --> Helper loaded: url_helper
INFO - 2022-03-17 05:50:20 --> Helper loaded: form_helper
INFO - 2022-03-17 05:50:20 --> Helper loaded: common_helper
INFO - 2022-03-17 05:50:20 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:50:20 --> Controller Class Initialized
INFO - 2022-03-17 05:50:20 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:50:20 --> Encrypt Class Initialized
INFO - 2022-03-17 05:50:20 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:50:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:50:20 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:50:20 --> Model "Users_model" initialized
INFO - 2022-03-17 05:50:20 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:50:20 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 05:50:21 --> Final output sent to browser
DEBUG - 2022-03-17 05:50:21 --> Total execution time: 0.9303
ERROR - 2022-03-17 05:59:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:59:53 --> Config Class Initialized
INFO - 2022-03-17 05:59:53 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:59:53 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:59:53 --> Utf8 Class Initialized
INFO - 2022-03-17 05:59:53 --> URI Class Initialized
INFO - 2022-03-17 05:59:53 --> Router Class Initialized
INFO - 2022-03-17 05:59:53 --> Output Class Initialized
INFO - 2022-03-17 05:59:53 --> Security Class Initialized
DEBUG - 2022-03-17 05:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:59:53 --> Input Class Initialized
INFO - 2022-03-17 05:59:53 --> Language Class Initialized
INFO - 2022-03-17 05:59:53 --> Loader Class Initialized
INFO - 2022-03-17 05:59:53 --> Helper loaded: url_helper
INFO - 2022-03-17 05:59:53 --> Helper loaded: form_helper
INFO - 2022-03-17 05:59:53 --> Helper loaded: common_helper
INFO - 2022-03-17 05:59:53 --> Database Driver Class Initialized
DEBUG - 2022-03-17 05:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 05:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 05:59:53 --> Controller Class Initialized
INFO - 2022-03-17 05:59:53 --> Form Validation Class Initialized
DEBUG - 2022-03-17 05:59:53 --> Encrypt Class Initialized
INFO - 2022-03-17 05:59:53 --> Model "Patient_model" initialized
INFO - 2022-03-17 05:59:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 05:59:53 --> Model "Referredby_model" initialized
INFO - 2022-03-17 05:59:53 --> Model "Prefix_master" initialized
INFO - 2022-03-17 05:59:53 --> Model "Hospital_model" initialized
INFO - 2022-03-17 05:59:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 05:59:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 05:59:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 05:59:53 --> Final output sent to browser
DEBUG - 2022-03-17 05:59:53 --> Total execution time: 0.1133
ERROR - 2022-03-17 05:59:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 05:59:53 --> Config Class Initialized
INFO - 2022-03-17 05:59:53 --> Hooks Class Initialized
DEBUG - 2022-03-17 05:59:53 --> UTF-8 Support Enabled
INFO - 2022-03-17 05:59:53 --> Utf8 Class Initialized
INFO - 2022-03-17 05:59:53 --> URI Class Initialized
INFO - 2022-03-17 05:59:53 --> Router Class Initialized
INFO - 2022-03-17 05:59:53 --> Output Class Initialized
INFO - 2022-03-17 05:59:53 --> Security Class Initialized
DEBUG - 2022-03-17 05:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 05:59:53 --> Input Class Initialized
INFO - 2022-03-17 05:59:53 --> Language Class Initialized
ERROR - 2022-03-17 05:59:53 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 06:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:04:11 --> Config Class Initialized
INFO - 2022-03-17 06:04:11 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:04:11 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:04:11 --> Utf8 Class Initialized
INFO - 2022-03-17 06:04:11 --> URI Class Initialized
INFO - 2022-03-17 06:04:11 --> Router Class Initialized
INFO - 2022-03-17 06:04:11 --> Output Class Initialized
INFO - 2022-03-17 06:04:11 --> Security Class Initialized
DEBUG - 2022-03-17 06:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:04:11 --> Input Class Initialized
INFO - 2022-03-17 06:04:11 --> Language Class Initialized
INFO - 2022-03-17 06:04:11 --> Loader Class Initialized
INFO - 2022-03-17 06:04:11 --> Helper loaded: url_helper
INFO - 2022-03-17 06:04:11 --> Helper loaded: form_helper
INFO - 2022-03-17 06:04:11 --> Helper loaded: common_helper
INFO - 2022-03-17 06:04:11 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:04:11 --> Controller Class Initialized
INFO - 2022-03-17 06:04:11 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:04:11 --> Encrypt Class Initialized
INFO - 2022-03-17 06:04:11 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:04:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:04:11 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:04:11 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:04:11 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:04:11 --> Upload Class Initialized
INFO - 2022-03-17 06:04:11 --> Final output sent to browser
DEBUG - 2022-03-17 06:04:11 --> Total execution time: 0.0333
ERROR - 2022-03-17 06:04:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:04:49 --> Config Class Initialized
INFO - 2022-03-17 06:04:49 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:04:49 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:04:49 --> Utf8 Class Initialized
INFO - 2022-03-17 06:04:49 --> URI Class Initialized
INFO - 2022-03-17 06:04:49 --> Router Class Initialized
INFO - 2022-03-17 06:04:49 --> Output Class Initialized
INFO - 2022-03-17 06:04:49 --> Security Class Initialized
DEBUG - 2022-03-17 06:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:04:49 --> Input Class Initialized
INFO - 2022-03-17 06:04:49 --> Language Class Initialized
INFO - 2022-03-17 06:04:49 --> Loader Class Initialized
INFO - 2022-03-17 06:04:49 --> Helper loaded: url_helper
INFO - 2022-03-17 06:04:49 --> Helper loaded: form_helper
INFO - 2022-03-17 06:04:49 --> Helper loaded: common_helper
INFO - 2022-03-17 06:04:49 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:04:49 --> Controller Class Initialized
INFO - 2022-03-17 06:04:49 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:04:49 --> Encrypt Class Initialized
INFO - 2022-03-17 06:04:49 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:04:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:04:49 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:04:49 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:04:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:04:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:04:51 --> Config Class Initialized
INFO - 2022-03-17 06:04:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:04:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:04:51 --> Utf8 Class Initialized
INFO - 2022-03-17 06:04:51 --> URI Class Initialized
INFO - 2022-03-17 06:04:51 --> Router Class Initialized
INFO - 2022-03-17 06:04:51 --> Output Class Initialized
INFO - 2022-03-17 06:04:51 --> Security Class Initialized
DEBUG - 2022-03-17 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:04:51 --> Input Class Initialized
INFO - 2022-03-17 06:04:51 --> Language Class Initialized
INFO - 2022-03-17 06:04:51 --> Loader Class Initialized
INFO - 2022-03-17 06:04:51 --> Helper loaded: url_helper
INFO - 2022-03-17 06:04:51 --> Helper loaded: form_helper
INFO - 2022-03-17 06:04:51 --> Helper loaded: common_helper
INFO - 2022-03-17 06:04:51 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:04:51 --> Controller Class Initialized
INFO - 2022-03-17 06:04:51 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:04:51 --> Encrypt Class Initialized
INFO - 2022-03-17 06:04:51 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:04:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:04:51 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:04:51 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:04:51 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:04:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:04:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:04:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:04:51 --> Final output sent to browser
DEBUG - 2022-03-17 06:04:51 --> Total execution time: 0.1872
ERROR - 2022-03-17 06:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:04:52 --> Config Class Initialized
INFO - 2022-03-17 06:04:52 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:04:52 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:04:52 --> Utf8 Class Initialized
INFO - 2022-03-17 06:04:52 --> URI Class Initialized
INFO - 2022-03-17 06:04:52 --> Router Class Initialized
INFO - 2022-03-17 06:04:52 --> Output Class Initialized
INFO - 2022-03-17 06:04:52 --> Security Class Initialized
DEBUG - 2022-03-17 06:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:04:52 --> Input Class Initialized
INFO - 2022-03-17 06:04:52 --> Language Class Initialized
INFO - 2022-03-17 06:04:52 --> Loader Class Initialized
INFO - 2022-03-17 06:04:52 --> Helper loaded: url_helper
INFO - 2022-03-17 06:04:52 --> Helper loaded: form_helper
INFO - 2022-03-17 06:04:52 --> Helper loaded: common_helper
INFO - 2022-03-17 06:04:52 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:04:52 --> Controller Class Initialized
INFO - 2022-03-17 06:04:52 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:04:52 --> Encrypt Class Initialized
INFO - 2022-03-17 06:04:52 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:04:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:04:52 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:04:52 --> Model "Users_model" initialized
INFO - 2022-03-17 06:04:52 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:04:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:04:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:04:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:04:52 --> Final output sent to browser
DEBUG - 2022-03-17 06:04:52 --> Total execution time: 0.0891
ERROR - 2022-03-17 06:07:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:07:32 --> Config Class Initialized
INFO - 2022-03-17 06:07:32 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:07:32 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:07:32 --> Utf8 Class Initialized
INFO - 2022-03-17 06:07:32 --> URI Class Initialized
INFO - 2022-03-17 06:07:32 --> Router Class Initialized
INFO - 2022-03-17 06:07:32 --> Output Class Initialized
INFO - 2022-03-17 06:07:32 --> Security Class Initialized
DEBUG - 2022-03-17 06:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:07:32 --> Input Class Initialized
INFO - 2022-03-17 06:07:32 --> Language Class Initialized
INFO - 2022-03-17 06:07:32 --> Loader Class Initialized
INFO - 2022-03-17 06:07:32 --> Helper loaded: url_helper
INFO - 2022-03-17 06:07:32 --> Helper loaded: form_helper
INFO - 2022-03-17 06:07:32 --> Helper loaded: common_helper
INFO - 2022-03-17 06:07:32 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:07:32 --> Controller Class Initialized
INFO - 2022-03-17 06:07:32 --> Form Validation Class Initialized
INFO - 2022-03-17 06:07:32 --> Model "Case_model" initialized
INFO - 2022-03-17 06:07:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:07:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:07:32 --> File loaded: /home3/karoteam/public_html/application/views/cases/rehelp.php
INFO - 2022-03-17 06:07:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:07:32 --> Final output sent to browser
DEBUG - 2022-03-17 06:07:32 --> Total execution time: 0.0646
ERROR - 2022-03-17 06:09:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:09:55 --> Config Class Initialized
INFO - 2022-03-17 06:09:55 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:09:55 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:09:55 --> Utf8 Class Initialized
INFO - 2022-03-17 06:09:55 --> URI Class Initialized
INFO - 2022-03-17 06:09:55 --> Router Class Initialized
INFO - 2022-03-17 06:09:55 --> Output Class Initialized
INFO - 2022-03-17 06:09:55 --> Security Class Initialized
DEBUG - 2022-03-17 06:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:09:55 --> Input Class Initialized
INFO - 2022-03-17 06:09:55 --> Language Class Initialized
INFO - 2022-03-17 06:09:55 --> Loader Class Initialized
INFO - 2022-03-17 06:09:55 --> Helper loaded: url_helper
INFO - 2022-03-17 06:09:55 --> Helper loaded: form_helper
INFO - 2022-03-17 06:09:55 --> Helper loaded: common_helper
INFO - 2022-03-17 06:09:55 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:09:55 --> Controller Class Initialized
INFO - 2022-03-17 06:09:55 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:09:55 --> Encrypt Class Initialized
INFO - 2022-03-17 06:09:55 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:09:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:09:55 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:09:55 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:09:55 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:09:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:09:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 06:09:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:09:55 --> Final output sent to browser
DEBUG - 2022-03-17 06:09:55 --> Total execution time: 0.1112
ERROR - 2022-03-17 06:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:10:02 --> Config Class Initialized
INFO - 2022-03-17 06:10:02 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:10:02 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:10:02 --> Utf8 Class Initialized
INFO - 2022-03-17 06:10:02 --> URI Class Initialized
INFO - 2022-03-17 06:10:02 --> Router Class Initialized
INFO - 2022-03-17 06:10:02 --> Output Class Initialized
INFO - 2022-03-17 06:10:02 --> Security Class Initialized
DEBUG - 2022-03-17 06:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:10:02 --> Input Class Initialized
INFO - 2022-03-17 06:10:02 --> Language Class Initialized
INFO - 2022-03-17 06:10:02 --> Loader Class Initialized
INFO - 2022-03-17 06:10:02 --> Helper loaded: url_helper
INFO - 2022-03-17 06:10:02 --> Helper loaded: form_helper
INFO - 2022-03-17 06:10:02 --> Helper loaded: common_helper
INFO - 2022-03-17 06:10:02 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:10:02 --> Controller Class Initialized
INFO - 2022-03-17 06:10:02 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:10:02 --> Encrypt Class Initialized
INFO - 2022-03-17 06:10:02 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:10:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:10:02 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:10:02 --> Model "Users_model" initialized
INFO - 2022-03-17 06:10:02 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:10:02 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 06:10:03 --> Final output sent to browser
DEBUG - 2022-03-17 06:10:03 --> Total execution time: 0.9868
ERROR - 2022-03-17 06:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:10:18 --> Config Class Initialized
INFO - 2022-03-17 06:10:18 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:10:18 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:10:18 --> Utf8 Class Initialized
INFO - 2022-03-17 06:10:18 --> URI Class Initialized
INFO - 2022-03-17 06:10:18 --> Router Class Initialized
INFO - 2022-03-17 06:10:18 --> Output Class Initialized
INFO - 2022-03-17 06:10:18 --> Security Class Initialized
DEBUG - 2022-03-17 06:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:10:18 --> Input Class Initialized
INFO - 2022-03-17 06:10:18 --> Language Class Initialized
INFO - 2022-03-17 06:10:18 --> Loader Class Initialized
INFO - 2022-03-17 06:10:18 --> Helper loaded: url_helper
INFO - 2022-03-17 06:10:18 --> Helper loaded: form_helper
INFO - 2022-03-17 06:10:18 --> Helper loaded: common_helper
INFO - 2022-03-17 06:10:18 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:10:18 --> Controller Class Initialized
INFO - 2022-03-17 06:10:18 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:10:18 --> Encrypt Class Initialized
INFO - 2022-03-17 06:10:18 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:10:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:10:18 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:10:18 --> Model "Users_model" initialized
INFO - 2022-03-17 06:10:18 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:10:18 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-17 06:10:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:10:19 --> Config Class Initialized
INFO - 2022-03-17 06:10:19 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:10:19 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:10:19 --> Utf8 Class Initialized
INFO - 2022-03-17 06:10:19 --> URI Class Initialized
INFO - 2022-03-17 06:10:19 --> Router Class Initialized
INFO - 2022-03-17 06:10:19 --> Output Class Initialized
INFO - 2022-03-17 06:10:19 --> Security Class Initialized
DEBUG - 2022-03-17 06:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:10:19 --> Input Class Initialized
INFO - 2022-03-17 06:10:19 --> Language Class Initialized
ERROR - 2022-03-17 06:10:19 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 06:10:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:10:19 --> Config Class Initialized
INFO - 2022-03-17 06:10:19 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:10:19 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:10:19 --> Utf8 Class Initialized
INFO - 2022-03-17 06:10:19 --> URI Class Initialized
INFO - 2022-03-17 06:10:19 --> Router Class Initialized
INFO - 2022-03-17 06:10:19 --> Output Class Initialized
INFO - 2022-03-17 06:10:19 --> Security Class Initialized
DEBUG - 2022-03-17 06:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:10:19 --> Input Class Initialized
INFO - 2022-03-17 06:10:19 --> Language Class Initialized
ERROR - 2022-03-17 06:10:19 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-17 06:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:10:20 --> Config Class Initialized
INFO - 2022-03-17 06:10:20 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:10:20 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:10:20 --> Utf8 Class Initialized
INFO - 2022-03-17 06:10:20 --> URI Class Initialized
INFO - 2022-03-17 06:10:20 --> Router Class Initialized
INFO - 2022-03-17 06:10:20 --> Output Class Initialized
INFO - 2022-03-17 06:10:20 --> Security Class Initialized
DEBUG - 2022-03-17 06:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:10:20 --> Input Class Initialized
INFO - 2022-03-17 06:10:20 --> Language Class Initialized
ERROR - 2022-03-17 06:10:20 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-17 06:10:21 --> Final output sent to browser
DEBUG - 2022-03-17 06:10:21 --> Total execution time: 2.7813
ERROR - 2022-03-17 06:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:10:32 --> Config Class Initialized
INFO - 2022-03-17 06:10:32 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:10:32 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:10:32 --> Utf8 Class Initialized
INFO - 2022-03-17 06:10:32 --> URI Class Initialized
INFO - 2022-03-17 06:10:32 --> Router Class Initialized
INFO - 2022-03-17 06:10:32 --> Output Class Initialized
INFO - 2022-03-17 06:10:32 --> Security Class Initialized
DEBUG - 2022-03-17 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:10:32 --> Input Class Initialized
INFO - 2022-03-17 06:10:32 --> Language Class Initialized
INFO - 2022-03-17 06:10:32 --> Loader Class Initialized
INFO - 2022-03-17 06:10:32 --> Helper loaded: url_helper
INFO - 2022-03-17 06:10:32 --> Helper loaded: form_helper
INFO - 2022-03-17 06:10:32 --> Helper loaded: common_helper
INFO - 2022-03-17 06:10:32 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:10:32 --> Controller Class Initialized
INFO - 2022-03-17 06:10:32 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:10:32 --> Encrypt Class Initialized
INFO - 2022-03-17 06:10:32 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:10:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:10:32 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:10:32 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:10:32 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:10:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:10:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:10:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:10:32 --> Final output sent to browser
DEBUG - 2022-03-17 06:10:32 --> Total execution time: 0.0885
ERROR - 2022-03-17 06:11:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:11:14 --> Config Class Initialized
INFO - 2022-03-17 06:11:14 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:11:14 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:11:14 --> Utf8 Class Initialized
INFO - 2022-03-17 06:11:14 --> URI Class Initialized
INFO - 2022-03-17 06:11:14 --> Router Class Initialized
INFO - 2022-03-17 06:11:14 --> Output Class Initialized
INFO - 2022-03-17 06:11:14 --> Security Class Initialized
DEBUG - 2022-03-17 06:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:11:14 --> Input Class Initialized
INFO - 2022-03-17 06:11:14 --> Language Class Initialized
INFO - 2022-03-17 06:11:14 --> Loader Class Initialized
INFO - 2022-03-17 06:11:14 --> Helper loaded: url_helper
INFO - 2022-03-17 06:11:14 --> Helper loaded: form_helper
INFO - 2022-03-17 06:11:14 --> Helper loaded: common_helper
INFO - 2022-03-17 06:11:14 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:11:14 --> Controller Class Initialized
INFO - 2022-03-17 06:11:14 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:11:14 --> Encrypt Class Initialized
INFO - 2022-03-17 06:11:14 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:11:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:11:14 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:11:14 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:11:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:11:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:11:14 --> Config Class Initialized
INFO - 2022-03-17 06:11:14 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:11:14 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:11:14 --> Utf8 Class Initialized
INFO - 2022-03-17 06:11:14 --> URI Class Initialized
INFO - 2022-03-17 06:11:14 --> Router Class Initialized
INFO - 2022-03-17 06:11:14 --> Output Class Initialized
INFO - 2022-03-17 06:11:14 --> Security Class Initialized
DEBUG - 2022-03-17 06:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:11:14 --> Input Class Initialized
INFO - 2022-03-17 06:11:14 --> Language Class Initialized
INFO - 2022-03-17 06:11:14 --> Loader Class Initialized
INFO - 2022-03-17 06:11:14 --> Helper loaded: url_helper
INFO - 2022-03-17 06:11:14 --> Helper loaded: form_helper
INFO - 2022-03-17 06:11:14 --> Helper loaded: common_helper
INFO - 2022-03-17 06:11:14 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:11:14 --> Controller Class Initialized
INFO - 2022-03-17 06:11:14 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:11:14 --> Encrypt Class Initialized
INFO - 2022-03-17 06:11:14 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:11:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:11:14 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:11:14 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:11:14 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:11:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:11:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:11:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:11:14 --> Final output sent to browser
DEBUG - 2022-03-17 06:11:14 --> Total execution time: 0.1045
ERROR - 2022-03-17 06:11:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:11:15 --> Config Class Initialized
INFO - 2022-03-17 06:11:15 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:11:15 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:11:15 --> Utf8 Class Initialized
INFO - 2022-03-17 06:11:15 --> URI Class Initialized
INFO - 2022-03-17 06:11:15 --> Router Class Initialized
INFO - 2022-03-17 06:11:15 --> Output Class Initialized
INFO - 2022-03-17 06:11:15 --> Security Class Initialized
DEBUG - 2022-03-17 06:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:11:15 --> Input Class Initialized
INFO - 2022-03-17 06:11:15 --> Language Class Initialized
INFO - 2022-03-17 06:11:15 --> Loader Class Initialized
INFO - 2022-03-17 06:11:15 --> Helper loaded: url_helper
INFO - 2022-03-17 06:11:15 --> Helper loaded: form_helper
INFO - 2022-03-17 06:11:15 --> Helper loaded: common_helper
INFO - 2022-03-17 06:11:15 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:11:15 --> Controller Class Initialized
INFO - 2022-03-17 06:11:15 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:11:15 --> Encrypt Class Initialized
INFO - 2022-03-17 06:11:15 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:11:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:11:15 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:11:15 --> Model "Users_model" initialized
INFO - 2022-03-17 06:11:15 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:11:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:11:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:11:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:11:16 --> Final output sent to browser
DEBUG - 2022-03-17 06:11:16 --> Total execution time: 0.1462
ERROR - 2022-03-17 06:11:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:11:19 --> Config Class Initialized
INFO - 2022-03-17 06:11:19 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:11:19 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:11:19 --> Utf8 Class Initialized
INFO - 2022-03-17 06:11:19 --> URI Class Initialized
INFO - 2022-03-17 06:11:19 --> Router Class Initialized
INFO - 2022-03-17 06:11:19 --> Output Class Initialized
INFO - 2022-03-17 06:11:19 --> Security Class Initialized
DEBUG - 2022-03-17 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:11:19 --> Input Class Initialized
INFO - 2022-03-17 06:11:19 --> Language Class Initialized
INFO - 2022-03-17 06:11:19 --> Loader Class Initialized
INFO - 2022-03-17 06:11:19 --> Helper loaded: url_helper
INFO - 2022-03-17 06:11:19 --> Helper loaded: form_helper
INFO - 2022-03-17 06:11:19 --> Helper loaded: common_helper
INFO - 2022-03-17 06:11:20 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:11:20 --> Controller Class Initialized
INFO - 2022-03-17 06:11:20 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:11:20 --> Encrypt Class Initialized
INFO - 2022-03-17 06:11:20 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:11:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:11:20 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:11:20 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:11:20 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:11:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:11:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 06:11:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:11:20 --> Final output sent to browser
DEBUG - 2022-03-17 06:11:20 --> Total execution time: 0.1108
ERROR - 2022-03-17 06:11:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:11:49 --> Config Class Initialized
INFO - 2022-03-17 06:11:49 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:11:49 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:11:49 --> Utf8 Class Initialized
INFO - 2022-03-17 06:11:49 --> URI Class Initialized
INFO - 2022-03-17 06:11:49 --> Router Class Initialized
INFO - 2022-03-17 06:11:49 --> Output Class Initialized
INFO - 2022-03-17 06:11:49 --> Security Class Initialized
DEBUG - 2022-03-17 06:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:11:49 --> Input Class Initialized
INFO - 2022-03-17 06:11:49 --> Language Class Initialized
INFO - 2022-03-17 06:11:49 --> Loader Class Initialized
INFO - 2022-03-17 06:11:49 --> Helper loaded: url_helper
INFO - 2022-03-17 06:11:49 --> Helper loaded: form_helper
INFO - 2022-03-17 06:11:49 --> Helper loaded: common_helper
INFO - 2022-03-17 06:11:49 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:11:49 --> Controller Class Initialized
INFO - 2022-03-17 06:11:49 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:11:49 --> Encrypt Class Initialized
INFO - 2022-03-17 06:11:49 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:11:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:11:49 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:11:49 --> Model "Users_model" initialized
INFO - 2022-03-17 06:11:49 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:11:49 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 06:11:50 --> Final output sent to browser
DEBUG - 2022-03-17 06:11:50 --> Total execution time: 1.1201
ERROR - 2022-03-17 06:12:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:12:21 --> Config Class Initialized
INFO - 2022-03-17 06:12:21 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:12:21 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:12:21 --> Utf8 Class Initialized
INFO - 2022-03-17 06:12:21 --> URI Class Initialized
INFO - 2022-03-17 06:12:21 --> Router Class Initialized
INFO - 2022-03-17 06:12:21 --> Output Class Initialized
INFO - 2022-03-17 06:12:21 --> Security Class Initialized
DEBUG - 2022-03-17 06:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:12:21 --> Input Class Initialized
INFO - 2022-03-17 06:12:21 --> Language Class Initialized
INFO - 2022-03-17 06:12:21 --> Loader Class Initialized
INFO - 2022-03-17 06:12:21 --> Helper loaded: url_helper
INFO - 2022-03-17 06:12:21 --> Helper loaded: form_helper
INFO - 2022-03-17 06:12:21 --> Helper loaded: common_helper
INFO - 2022-03-17 06:12:21 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:12:21 --> Controller Class Initialized
INFO - 2022-03-17 06:12:21 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:12:21 --> Encrypt Class Initialized
INFO - 2022-03-17 06:12:21 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:12:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:12:21 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:12:21 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:12:21 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:12:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:12:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:12:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:12:21 --> Final output sent to browser
DEBUG - 2022-03-17 06:12:21 --> Total execution time: 0.0488
ERROR - 2022-03-17 06:12:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:12:35 --> Config Class Initialized
INFO - 2022-03-17 06:12:35 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:12:35 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:12:35 --> Utf8 Class Initialized
INFO - 2022-03-17 06:12:35 --> URI Class Initialized
INFO - 2022-03-17 06:12:35 --> Router Class Initialized
INFO - 2022-03-17 06:12:35 --> Output Class Initialized
INFO - 2022-03-17 06:12:35 --> Security Class Initialized
DEBUG - 2022-03-17 06:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:12:35 --> Input Class Initialized
INFO - 2022-03-17 06:12:35 --> Language Class Initialized
INFO - 2022-03-17 06:12:35 --> Loader Class Initialized
INFO - 2022-03-17 06:12:35 --> Helper loaded: url_helper
INFO - 2022-03-17 06:12:35 --> Helper loaded: form_helper
INFO - 2022-03-17 06:12:35 --> Helper loaded: common_helper
INFO - 2022-03-17 06:12:35 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:12:35 --> Controller Class Initialized
INFO - 2022-03-17 06:12:35 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:12:35 --> Encrypt Class Initialized
INFO - 2022-03-17 06:12:35 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:12:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:12:35 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:12:35 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:12:35 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:12:35 --> Upload Class Initialized
INFO - 2022-03-17 06:12:35 --> Final output sent to browser
DEBUG - 2022-03-17 06:12:35 --> Total execution time: 0.0409
ERROR - 2022-03-17 06:12:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:12:40 --> Config Class Initialized
INFO - 2022-03-17 06:12:40 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:12:40 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:12:40 --> Utf8 Class Initialized
INFO - 2022-03-17 06:12:40 --> URI Class Initialized
INFO - 2022-03-17 06:12:40 --> Router Class Initialized
INFO - 2022-03-17 06:12:40 --> Output Class Initialized
INFO - 2022-03-17 06:12:40 --> Security Class Initialized
DEBUG - 2022-03-17 06:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:12:40 --> Input Class Initialized
INFO - 2022-03-17 06:12:40 --> Language Class Initialized
INFO - 2022-03-17 06:12:40 --> Loader Class Initialized
INFO - 2022-03-17 06:12:40 --> Helper loaded: url_helper
INFO - 2022-03-17 06:12:40 --> Helper loaded: form_helper
INFO - 2022-03-17 06:12:40 --> Helper loaded: common_helper
INFO - 2022-03-17 06:12:40 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:12:40 --> Controller Class Initialized
INFO - 2022-03-17 06:12:40 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:12:40 --> Encrypt Class Initialized
INFO - 2022-03-17 06:12:40 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:12:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:12:40 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:12:40 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:12:40 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:12:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:12:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:12:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:12:40 --> Final output sent to browser
DEBUG - 2022-03-17 06:12:40 --> Total execution time: 0.1326
ERROR - 2022-03-17 06:12:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:12:41 --> Config Class Initialized
INFO - 2022-03-17 06:12:41 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:12:41 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:12:41 --> Utf8 Class Initialized
INFO - 2022-03-17 06:12:41 --> URI Class Initialized
INFO - 2022-03-17 06:12:41 --> Router Class Initialized
INFO - 2022-03-17 06:12:41 --> Output Class Initialized
INFO - 2022-03-17 06:12:41 --> Security Class Initialized
DEBUG - 2022-03-17 06:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:12:41 --> Input Class Initialized
INFO - 2022-03-17 06:12:41 --> Language Class Initialized
ERROR - 2022-03-17 06:12:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:15:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:15:06 --> Config Class Initialized
INFO - 2022-03-17 06:15:06 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:15:06 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:15:06 --> Utf8 Class Initialized
INFO - 2022-03-17 06:15:06 --> URI Class Initialized
INFO - 2022-03-17 06:15:06 --> Router Class Initialized
INFO - 2022-03-17 06:15:06 --> Output Class Initialized
INFO - 2022-03-17 06:15:06 --> Security Class Initialized
DEBUG - 2022-03-17 06:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:15:06 --> Input Class Initialized
INFO - 2022-03-17 06:15:06 --> Language Class Initialized
INFO - 2022-03-17 06:15:06 --> Loader Class Initialized
INFO - 2022-03-17 06:15:06 --> Helper loaded: url_helper
INFO - 2022-03-17 06:15:06 --> Helper loaded: form_helper
INFO - 2022-03-17 06:15:06 --> Helper loaded: common_helper
INFO - 2022-03-17 06:15:06 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:15:06 --> Controller Class Initialized
INFO - 2022-03-17 06:15:06 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:15:06 --> Encrypt Class Initialized
INFO - 2022-03-17 06:15:06 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:15:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:15:06 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:15:06 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:15:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:15:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:15:07 --> Config Class Initialized
INFO - 2022-03-17 06:15:07 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:15:07 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:15:07 --> Utf8 Class Initialized
INFO - 2022-03-17 06:15:07 --> URI Class Initialized
INFO - 2022-03-17 06:15:07 --> Router Class Initialized
INFO - 2022-03-17 06:15:07 --> Output Class Initialized
INFO - 2022-03-17 06:15:07 --> Security Class Initialized
DEBUG - 2022-03-17 06:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:15:07 --> Input Class Initialized
INFO - 2022-03-17 06:15:07 --> Language Class Initialized
INFO - 2022-03-17 06:15:07 --> Loader Class Initialized
INFO - 2022-03-17 06:15:07 --> Helper loaded: url_helper
INFO - 2022-03-17 06:15:07 --> Helper loaded: form_helper
INFO - 2022-03-17 06:15:07 --> Helper loaded: common_helper
INFO - 2022-03-17 06:15:07 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:15:07 --> Controller Class Initialized
INFO - 2022-03-17 06:15:07 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:15:07 --> Encrypt Class Initialized
INFO - 2022-03-17 06:15:07 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:15:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:15:07 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:15:07 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:15:07 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:15:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:15:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:15:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:15:07 --> Final output sent to browser
DEBUG - 2022-03-17 06:15:07 --> Total execution time: 0.0742
ERROR - 2022-03-17 06:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:15:08 --> Config Class Initialized
INFO - 2022-03-17 06:15:08 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:15:08 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:15:08 --> Utf8 Class Initialized
INFO - 2022-03-17 06:15:08 --> URI Class Initialized
INFO - 2022-03-17 06:15:08 --> Router Class Initialized
INFO - 2022-03-17 06:15:08 --> Output Class Initialized
INFO - 2022-03-17 06:15:08 --> Security Class Initialized
DEBUG - 2022-03-17 06:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:15:08 --> Input Class Initialized
INFO - 2022-03-17 06:15:08 --> Language Class Initialized
ERROR - 2022-03-17 06:15:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:15:08 --> Config Class Initialized
INFO - 2022-03-17 06:15:08 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:15:08 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:15:08 --> Utf8 Class Initialized
INFO - 2022-03-17 06:15:08 --> URI Class Initialized
INFO - 2022-03-17 06:15:08 --> Router Class Initialized
INFO - 2022-03-17 06:15:08 --> Output Class Initialized
INFO - 2022-03-17 06:15:08 --> Security Class Initialized
DEBUG - 2022-03-17 06:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:15:08 --> Input Class Initialized
INFO - 2022-03-17 06:15:08 --> Language Class Initialized
INFO - 2022-03-17 06:15:08 --> Loader Class Initialized
INFO - 2022-03-17 06:15:08 --> Helper loaded: url_helper
INFO - 2022-03-17 06:15:08 --> Helper loaded: form_helper
INFO - 2022-03-17 06:15:08 --> Helper loaded: common_helper
INFO - 2022-03-17 06:15:08 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:15:08 --> Controller Class Initialized
INFO - 2022-03-17 06:15:08 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:15:08 --> Encrypt Class Initialized
INFO - 2022-03-17 06:15:08 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:15:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:15:08 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:15:08 --> Model "Users_model" initialized
INFO - 2022-03-17 06:15:08 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:15:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:15:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:15:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:15:08 --> Final output sent to browser
DEBUG - 2022-03-17 06:15:08 --> Total execution time: 0.0962
ERROR - 2022-03-17 06:15:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:15:09 --> Config Class Initialized
INFO - 2022-03-17 06:15:09 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:15:09 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:15:09 --> Utf8 Class Initialized
INFO - 2022-03-17 06:15:09 --> URI Class Initialized
INFO - 2022-03-17 06:15:09 --> Router Class Initialized
INFO - 2022-03-17 06:15:09 --> Output Class Initialized
INFO - 2022-03-17 06:15:09 --> Security Class Initialized
DEBUG - 2022-03-17 06:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:15:09 --> Input Class Initialized
INFO - 2022-03-17 06:15:09 --> Language Class Initialized
ERROR - 2022-03-17 06:15:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:18:27 --> Config Class Initialized
INFO - 2022-03-17 06:18:27 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:18:27 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:18:27 --> Utf8 Class Initialized
INFO - 2022-03-17 06:18:27 --> URI Class Initialized
INFO - 2022-03-17 06:18:27 --> Router Class Initialized
INFO - 2022-03-17 06:18:27 --> Output Class Initialized
INFO - 2022-03-17 06:18:27 --> Security Class Initialized
DEBUG - 2022-03-17 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:18:27 --> Input Class Initialized
INFO - 2022-03-17 06:18:27 --> Language Class Initialized
INFO - 2022-03-17 06:18:27 --> Loader Class Initialized
INFO - 2022-03-17 06:18:27 --> Helper loaded: url_helper
INFO - 2022-03-17 06:18:27 --> Helper loaded: form_helper
INFO - 2022-03-17 06:18:27 --> Helper loaded: common_helper
INFO - 2022-03-17 06:18:27 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:18:27 --> Controller Class Initialized
INFO - 2022-03-17 06:18:27 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:18:27 --> Encrypt Class Initialized
INFO - 2022-03-17 06:18:27 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:18:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:18:27 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:18:27 --> Model "Users_model" initialized
INFO - 2022-03-17 06:18:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:18:28 --> Config Class Initialized
INFO - 2022-03-17 06:18:28 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:18:28 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:18:28 --> Utf8 Class Initialized
INFO - 2022-03-17 06:18:28 --> URI Class Initialized
INFO - 2022-03-17 06:18:28 --> Router Class Initialized
INFO - 2022-03-17 06:18:28 --> Output Class Initialized
INFO - 2022-03-17 06:18:28 --> Security Class Initialized
DEBUG - 2022-03-17 06:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:18:28 --> Input Class Initialized
INFO - 2022-03-17 06:18:28 --> Language Class Initialized
INFO - 2022-03-17 06:18:28 --> Loader Class Initialized
INFO - 2022-03-17 06:18:28 --> Helper loaded: url_helper
INFO - 2022-03-17 06:18:28 --> Helper loaded: form_helper
INFO - 2022-03-17 06:18:28 --> Helper loaded: common_helper
INFO - 2022-03-17 06:18:28 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:18:28 --> Controller Class Initialized
INFO - 2022-03-17 06:18:28 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:18:28 --> Encrypt Class Initialized
INFO - 2022-03-17 06:18:28 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:18:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:18:28 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:18:28 --> Model "Users_model" initialized
INFO - 2022-03-17 06:18:28 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:18:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:18:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:18:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:18:28 --> Final output sent to browser
DEBUG - 2022-03-17 06:18:28 --> Total execution time: 0.0776
ERROR - 2022-03-17 06:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:18:29 --> Config Class Initialized
INFO - 2022-03-17 06:18:29 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:18:29 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:18:29 --> Utf8 Class Initialized
INFO - 2022-03-17 06:18:29 --> URI Class Initialized
INFO - 2022-03-17 06:18:29 --> Router Class Initialized
INFO - 2022-03-17 06:18:29 --> Output Class Initialized
INFO - 2022-03-17 06:18:29 --> Security Class Initialized
DEBUG - 2022-03-17 06:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:18:29 --> Input Class Initialized
INFO - 2022-03-17 06:18:29 --> Language Class Initialized
ERROR - 2022-03-17 06:18:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:19:28 --> Config Class Initialized
INFO - 2022-03-17 06:19:28 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:19:28 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:19:28 --> Utf8 Class Initialized
INFO - 2022-03-17 06:19:28 --> URI Class Initialized
INFO - 2022-03-17 06:19:28 --> Router Class Initialized
INFO - 2022-03-17 06:19:28 --> Output Class Initialized
INFO - 2022-03-17 06:19:28 --> Security Class Initialized
DEBUG - 2022-03-17 06:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:19:28 --> Input Class Initialized
INFO - 2022-03-17 06:19:28 --> Language Class Initialized
INFO - 2022-03-17 06:19:28 --> Loader Class Initialized
INFO - 2022-03-17 06:19:28 --> Helper loaded: url_helper
INFO - 2022-03-17 06:19:28 --> Helper loaded: form_helper
INFO - 2022-03-17 06:19:28 --> Helper loaded: common_helper
INFO - 2022-03-17 06:19:28 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:19:28 --> Controller Class Initialized
INFO - 2022-03-17 06:19:28 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:19:28 --> Encrypt Class Initialized
INFO - 2022-03-17 06:19:28 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:19:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:19:28 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:19:28 --> Model "Users_model" initialized
INFO - 2022-03-17 06:19:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:19:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:19:29 --> Config Class Initialized
INFO - 2022-03-17 06:19:29 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:19:29 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:19:29 --> Utf8 Class Initialized
INFO - 2022-03-17 06:19:29 --> URI Class Initialized
INFO - 2022-03-17 06:19:29 --> Router Class Initialized
INFO - 2022-03-17 06:19:29 --> Output Class Initialized
INFO - 2022-03-17 06:19:29 --> Security Class Initialized
DEBUG - 2022-03-17 06:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:19:29 --> Input Class Initialized
INFO - 2022-03-17 06:19:29 --> Language Class Initialized
INFO - 2022-03-17 06:19:29 --> Loader Class Initialized
INFO - 2022-03-17 06:19:29 --> Helper loaded: url_helper
INFO - 2022-03-17 06:19:29 --> Helper loaded: form_helper
INFO - 2022-03-17 06:19:29 --> Helper loaded: common_helper
INFO - 2022-03-17 06:19:29 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:19:29 --> Controller Class Initialized
INFO - 2022-03-17 06:19:29 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:19:29 --> Encrypt Class Initialized
INFO - 2022-03-17 06:19:29 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:19:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:19:29 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:19:29 --> Model "Users_model" initialized
INFO - 2022-03-17 06:19:29 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:19:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:19:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:19:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:19:29 --> Final output sent to browser
DEBUG - 2022-03-17 06:19:29 --> Total execution time: 0.1705
ERROR - 2022-03-17 06:19:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:19:30 --> Config Class Initialized
INFO - 2022-03-17 06:19:30 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:19:30 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:19:30 --> Utf8 Class Initialized
INFO - 2022-03-17 06:19:30 --> URI Class Initialized
INFO - 2022-03-17 06:19:30 --> Router Class Initialized
INFO - 2022-03-17 06:19:30 --> Output Class Initialized
INFO - 2022-03-17 06:19:30 --> Security Class Initialized
DEBUG - 2022-03-17 06:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:19:30 --> Input Class Initialized
INFO - 2022-03-17 06:19:30 --> Language Class Initialized
ERROR - 2022-03-17 06:19:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:19:45 --> Config Class Initialized
INFO - 2022-03-17 06:19:45 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:19:45 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:19:45 --> Utf8 Class Initialized
INFO - 2022-03-17 06:19:45 --> URI Class Initialized
INFO - 2022-03-17 06:19:45 --> Router Class Initialized
INFO - 2022-03-17 06:19:45 --> Output Class Initialized
INFO - 2022-03-17 06:19:45 --> Security Class Initialized
DEBUG - 2022-03-17 06:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:19:45 --> Input Class Initialized
INFO - 2022-03-17 06:19:45 --> Language Class Initialized
INFO - 2022-03-17 06:19:45 --> Loader Class Initialized
INFO - 2022-03-17 06:19:45 --> Helper loaded: url_helper
INFO - 2022-03-17 06:19:45 --> Helper loaded: form_helper
INFO - 2022-03-17 06:19:45 --> Helper loaded: common_helper
INFO - 2022-03-17 06:19:45 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:19:45 --> Controller Class Initialized
INFO - 2022-03-17 06:19:45 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:19:45 --> Encrypt Class Initialized
INFO - 2022-03-17 06:19:45 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:19:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:19:45 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:19:45 --> Model "Users_model" initialized
INFO - 2022-03-17 06:19:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:19:46 --> Config Class Initialized
INFO - 2022-03-17 06:19:46 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:19:46 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:19:46 --> Utf8 Class Initialized
INFO - 2022-03-17 06:19:46 --> URI Class Initialized
INFO - 2022-03-17 06:19:46 --> Router Class Initialized
INFO - 2022-03-17 06:19:46 --> Output Class Initialized
INFO - 2022-03-17 06:19:46 --> Security Class Initialized
DEBUG - 2022-03-17 06:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:19:46 --> Input Class Initialized
INFO - 2022-03-17 06:19:46 --> Language Class Initialized
INFO - 2022-03-17 06:19:46 --> Loader Class Initialized
INFO - 2022-03-17 06:19:46 --> Helper loaded: url_helper
INFO - 2022-03-17 06:19:46 --> Helper loaded: form_helper
INFO - 2022-03-17 06:19:46 --> Helper loaded: common_helper
INFO - 2022-03-17 06:19:46 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:19:46 --> Controller Class Initialized
INFO - 2022-03-17 06:19:46 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:19:46 --> Encrypt Class Initialized
INFO - 2022-03-17 06:19:46 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:19:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:19:46 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:19:46 --> Model "Users_model" initialized
INFO - 2022-03-17 06:19:46 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:19:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:19:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:19:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:19:46 --> Final output sent to browser
DEBUG - 2022-03-17 06:19:46 --> Total execution time: 0.0938
ERROR - 2022-03-17 06:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:19:47 --> Config Class Initialized
INFO - 2022-03-17 06:19:47 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:19:47 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:19:47 --> Utf8 Class Initialized
INFO - 2022-03-17 06:19:47 --> URI Class Initialized
INFO - 2022-03-17 06:19:47 --> Router Class Initialized
INFO - 2022-03-17 06:19:47 --> Output Class Initialized
INFO - 2022-03-17 06:19:47 --> Security Class Initialized
DEBUG - 2022-03-17 06:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:19:47 --> Input Class Initialized
INFO - 2022-03-17 06:19:47 --> Language Class Initialized
ERROR - 2022-03-17 06:19:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:22:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:22:51 --> Config Class Initialized
INFO - 2022-03-17 06:22:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:22:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:22:51 --> Utf8 Class Initialized
INFO - 2022-03-17 06:22:51 --> URI Class Initialized
INFO - 2022-03-17 06:22:51 --> Router Class Initialized
INFO - 2022-03-17 06:22:51 --> Output Class Initialized
INFO - 2022-03-17 06:22:51 --> Security Class Initialized
DEBUG - 2022-03-17 06:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:22:51 --> Input Class Initialized
INFO - 2022-03-17 06:22:51 --> Language Class Initialized
INFO - 2022-03-17 06:22:51 --> Loader Class Initialized
INFO - 2022-03-17 06:22:51 --> Helper loaded: url_helper
INFO - 2022-03-17 06:22:51 --> Helper loaded: form_helper
INFO - 2022-03-17 06:22:51 --> Helper loaded: common_helper
INFO - 2022-03-17 06:22:51 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:22:51 --> Controller Class Initialized
INFO - 2022-03-17 06:22:51 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:22:51 --> Encrypt Class Initialized
INFO - 2022-03-17 06:22:51 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:22:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:22:51 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:22:51 --> Model "Users_model" initialized
INFO - 2022-03-17 06:22:51 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:22:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:22:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:22:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:22:51 --> Final output sent to browser
DEBUG - 2022-03-17 06:22:51 --> Total execution time: 0.1118
ERROR - 2022-03-17 06:33:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:33:15 --> Config Class Initialized
INFO - 2022-03-17 06:33:15 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:33:15 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:33:15 --> Utf8 Class Initialized
INFO - 2022-03-17 06:33:15 --> URI Class Initialized
INFO - 2022-03-17 06:33:15 --> Router Class Initialized
INFO - 2022-03-17 06:33:15 --> Output Class Initialized
INFO - 2022-03-17 06:33:15 --> Security Class Initialized
DEBUG - 2022-03-17 06:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:33:15 --> Input Class Initialized
INFO - 2022-03-17 06:33:15 --> Language Class Initialized
INFO - 2022-03-17 06:33:15 --> Loader Class Initialized
INFO - 2022-03-17 06:33:15 --> Helper loaded: url_helper
INFO - 2022-03-17 06:33:15 --> Helper loaded: form_helper
INFO - 2022-03-17 06:33:15 --> Helper loaded: common_helper
INFO - 2022-03-17 06:33:15 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:33:15 --> Controller Class Initialized
INFO - 2022-03-17 06:33:15 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:33:15 --> Encrypt Class Initialized
INFO - 2022-03-17 06:33:15 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:33:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:33:15 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:33:15 --> Model "Users_model" initialized
INFO - 2022-03-17 06:33:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:33:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:33:16 --> Config Class Initialized
INFO - 2022-03-17 06:33:16 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:33:16 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:33:16 --> Utf8 Class Initialized
INFO - 2022-03-17 06:33:16 --> URI Class Initialized
INFO - 2022-03-17 06:33:16 --> Router Class Initialized
INFO - 2022-03-17 06:33:16 --> Output Class Initialized
INFO - 2022-03-17 06:33:16 --> Security Class Initialized
DEBUG - 2022-03-17 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:33:16 --> Input Class Initialized
INFO - 2022-03-17 06:33:16 --> Language Class Initialized
INFO - 2022-03-17 06:33:16 --> Loader Class Initialized
INFO - 2022-03-17 06:33:16 --> Helper loaded: url_helper
INFO - 2022-03-17 06:33:16 --> Helper loaded: form_helper
INFO - 2022-03-17 06:33:16 --> Helper loaded: common_helper
INFO - 2022-03-17 06:33:16 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:33:16 --> Controller Class Initialized
INFO - 2022-03-17 06:33:16 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:33:16 --> Encrypt Class Initialized
INFO - 2022-03-17 06:33:16 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:33:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:33:16 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:33:16 --> Model "Users_model" initialized
INFO - 2022-03-17 06:33:16 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:33:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:33:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:33:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:33:16 --> Final output sent to browser
DEBUG - 2022-03-17 06:33:16 --> Total execution time: 0.1086
ERROR - 2022-03-17 06:33:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:33:17 --> Config Class Initialized
INFO - 2022-03-17 06:33:17 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:33:17 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:33:17 --> Utf8 Class Initialized
INFO - 2022-03-17 06:33:17 --> URI Class Initialized
INFO - 2022-03-17 06:33:17 --> Router Class Initialized
INFO - 2022-03-17 06:33:17 --> Output Class Initialized
INFO - 2022-03-17 06:33:17 --> Security Class Initialized
DEBUG - 2022-03-17 06:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:33:17 --> Input Class Initialized
INFO - 2022-03-17 06:33:17 --> Language Class Initialized
ERROR - 2022-03-17 06:33:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:33:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:33:37 --> Config Class Initialized
INFO - 2022-03-17 06:33:37 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:33:37 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:33:37 --> Utf8 Class Initialized
INFO - 2022-03-17 06:33:37 --> URI Class Initialized
INFO - 2022-03-17 06:33:37 --> Router Class Initialized
INFO - 2022-03-17 06:33:37 --> Output Class Initialized
INFO - 2022-03-17 06:33:37 --> Security Class Initialized
DEBUG - 2022-03-17 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:33:37 --> Input Class Initialized
INFO - 2022-03-17 06:33:37 --> Language Class Initialized
INFO - 2022-03-17 06:33:37 --> Loader Class Initialized
INFO - 2022-03-17 06:33:37 --> Helper loaded: url_helper
INFO - 2022-03-17 06:33:37 --> Helper loaded: form_helper
INFO - 2022-03-17 06:33:37 --> Helper loaded: common_helper
INFO - 2022-03-17 06:33:37 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:33:37 --> Controller Class Initialized
INFO - 2022-03-17 06:33:37 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:33:37 --> Encrypt Class Initialized
INFO - 2022-03-17 06:33:37 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:33:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:33:37 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:33:37 --> Model "Users_model" initialized
INFO - 2022-03-17 06:33:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:33:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:33:37 --> Config Class Initialized
INFO - 2022-03-17 06:33:37 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:33:37 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:33:37 --> Utf8 Class Initialized
INFO - 2022-03-17 06:33:37 --> URI Class Initialized
INFO - 2022-03-17 06:33:37 --> Router Class Initialized
INFO - 2022-03-17 06:33:37 --> Output Class Initialized
INFO - 2022-03-17 06:33:37 --> Security Class Initialized
DEBUG - 2022-03-17 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:33:37 --> Input Class Initialized
INFO - 2022-03-17 06:33:37 --> Language Class Initialized
INFO - 2022-03-17 06:33:37 --> Loader Class Initialized
INFO - 2022-03-17 06:33:37 --> Helper loaded: url_helper
INFO - 2022-03-17 06:33:37 --> Helper loaded: form_helper
INFO - 2022-03-17 06:33:37 --> Helper loaded: common_helper
INFO - 2022-03-17 06:33:37 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:33:37 --> Controller Class Initialized
INFO - 2022-03-17 06:33:37 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:33:37 --> Encrypt Class Initialized
INFO - 2022-03-17 06:33:37 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:33:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:33:37 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:33:37 --> Model "Users_model" initialized
INFO - 2022-03-17 06:33:37 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:33:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:33:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:33:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:33:38 --> Final output sent to browser
DEBUG - 2022-03-17 06:33:38 --> Total execution time: 0.0848
ERROR - 2022-03-17 06:33:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:33:38 --> Config Class Initialized
INFO - 2022-03-17 06:33:38 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:33:38 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:33:38 --> Utf8 Class Initialized
INFO - 2022-03-17 06:33:38 --> URI Class Initialized
INFO - 2022-03-17 06:33:38 --> Router Class Initialized
INFO - 2022-03-17 06:33:38 --> Output Class Initialized
INFO - 2022-03-17 06:33:38 --> Security Class Initialized
DEBUG - 2022-03-17 06:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:33:38 --> Input Class Initialized
INFO - 2022-03-17 06:33:38 --> Language Class Initialized
ERROR - 2022-03-17 06:33:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:34:26 --> Config Class Initialized
INFO - 2022-03-17 06:34:26 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:34:26 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:34:26 --> Utf8 Class Initialized
INFO - 2022-03-17 06:34:26 --> URI Class Initialized
INFO - 2022-03-17 06:34:26 --> Router Class Initialized
INFO - 2022-03-17 06:34:26 --> Output Class Initialized
INFO - 2022-03-17 06:34:26 --> Security Class Initialized
DEBUG - 2022-03-17 06:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:34:26 --> Input Class Initialized
INFO - 2022-03-17 06:34:26 --> Language Class Initialized
INFO - 2022-03-17 06:34:26 --> Loader Class Initialized
INFO - 2022-03-17 06:34:26 --> Helper loaded: url_helper
INFO - 2022-03-17 06:34:26 --> Helper loaded: form_helper
INFO - 2022-03-17 06:34:26 --> Helper loaded: common_helper
INFO - 2022-03-17 06:34:26 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:34:26 --> Controller Class Initialized
INFO - 2022-03-17 06:34:26 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:34:26 --> Encrypt Class Initialized
INFO - 2022-03-17 06:34:26 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:34:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:34:26 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:34:26 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:34:26 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:34:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:34:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 06:34:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:34:26 --> Final output sent to browser
DEBUG - 2022-03-17 06:34:26 --> Total execution time: 0.0999
ERROR - 2022-03-17 06:34:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:34:42 --> Config Class Initialized
INFO - 2022-03-17 06:34:42 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:34:42 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:34:42 --> Utf8 Class Initialized
INFO - 2022-03-17 06:34:42 --> URI Class Initialized
INFO - 2022-03-17 06:34:42 --> Router Class Initialized
INFO - 2022-03-17 06:34:42 --> Output Class Initialized
INFO - 2022-03-17 06:34:42 --> Security Class Initialized
DEBUG - 2022-03-17 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:34:42 --> Input Class Initialized
INFO - 2022-03-17 06:34:42 --> Language Class Initialized
INFO - 2022-03-17 06:34:42 --> Loader Class Initialized
INFO - 2022-03-17 06:34:42 --> Helper loaded: url_helper
INFO - 2022-03-17 06:34:42 --> Helper loaded: form_helper
INFO - 2022-03-17 06:34:42 --> Helper loaded: common_helper
INFO - 2022-03-17 06:34:42 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:34:42 --> Controller Class Initialized
INFO - 2022-03-17 06:34:42 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:34:42 --> Encrypt Class Initialized
INFO - 2022-03-17 06:34:42 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:34:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:34:42 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:34:42 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:34:42 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:34:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:34:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:34:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:34:42 --> Final output sent to browser
DEBUG - 2022-03-17 06:34:42 --> Total execution time: 0.0645
ERROR - 2022-03-17 06:35:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:35:04 --> Config Class Initialized
INFO - 2022-03-17 06:35:04 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:35:04 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:35:04 --> Utf8 Class Initialized
INFO - 2022-03-17 06:35:04 --> URI Class Initialized
INFO - 2022-03-17 06:35:04 --> Router Class Initialized
INFO - 2022-03-17 06:35:04 --> Output Class Initialized
INFO - 2022-03-17 06:35:04 --> Security Class Initialized
DEBUG - 2022-03-17 06:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:35:04 --> Input Class Initialized
INFO - 2022-03-17 06:35:04 --> Language Class Initialized
INFO - 2022-03-17 06:35:04 --> Loader Class Initialized
INFO - 2022-03-17 06:35:04 --> Helper loaded: url_helper
INFO - 2022-03-17 06:35:04 --> Helper loaded: form_helper
INFO - 2022-03-17 06:35:04 --> Helper loaded: common_helper
INFO - 2022-03-17 06:35:04 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:35:04 --> Controller Class Initialized
INFO - 2022-03-17 06:35:04 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:35:04 --> Encrypt Class Initialized
INFO - 2022-03-17 06:35:04 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:35:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:35:04 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:35:04 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:35:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:35:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:35:05 --> Config Class Initialized
INFO - 2022-03-17 06:35:05 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:35:05 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:35:05 --> Utf8 Class Initialized
INFO - 2022-03-17 06:35:05 --> URI Class Initialized
INFO - 2022-03-17 06:35:05 --> Router Class Initialized
INFO - 2022-03-17 06:35:05 --> Output Class Initialized
INFO - 2022-03-17 06:35:05 --> Security Class Initialized
DEBUG - 2022-03-17 06:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:35:05 --> Input Class Initialized
INFO - 2022-03-17 06:35:05 --> Language Class Initialized
INFO - 2022-03-17 06:35:05 --> Loader Class Initialized
INFO - 2022-03-17 06:35:05 --> Helper loaded: url_helper
INFO - 2022-03-17 06:35:05 --> Helper loaded: form_helper
INFO - 2022-03-17 06:35:05 --> Helper loaded: common_helper
INFO - 2022-03-17 06:35:05 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:35:05 --> Controller Class Initialized
INFO - 2022-03-17 06:35:05 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:35:05 --> Encrypt Class Initialized
INFO - 2022-03-17 06:35:05 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:35:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:35:05 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:35:05 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:35:05 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:35:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:35:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:35:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:35:05 --> Final output sent to browser
DEBUG - 2022-03-17 06:35:05 --> Total execution time: 0.0706
ERROR - 2022-03-17 06:35:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:35:06 --> Config Class Initialized
INFO - 2022-03-17 06:35:06 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:35:06 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:35:06 --> Utf8 Class Initialized
INFO - 2022-03-17 06:35:06 --> URI Class Initialized
INFO - 2022-03-17 06:35:06 --> Router Class Initialized
INFO - 2022-03-17 06:35:06 --> Output Class Initialized
INFO - 2022-03-17 06:35:06 --> Security Class Initialized
DEBUG - 2022-03-17 06:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:35:06 --> Input Class Initialized
INFO - 2022-03-17 06:35:06 --> Language Class Initialized
INFO - 2022-03-17 06:35:06 --> Loader Class Initialized
INFO - 2022-03-17 06:35:06 --> Helper loaded: url_helper
INFO - 2022-03-17 06:35:06 --> Helper loaded: form_helper
INFO - 2022-03-17 06:35:06 --> Helper loaded: common_helper
INFO - 2022-03-17 06:35:06 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:35:06 --> Controller Class Initialized
INFO - 2022-03-17 06:35:06 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:35:06 --> Encrypt Class Initialized
INFO - 2022-03-17 06:35:06 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:35:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:35:06 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:35:06 --> Model "Users_model" initialized
INFO - 2022-03-17 06:35:06 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:35:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:35:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:35:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:35:06 --> Final output sent to browser
DEBUG - 2022-03-17 06:35:06 --> Total execution time: 0.1010
ERROR - 2022-03-17 06:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:36:00 --> Config Class Initialized
INFO - 2022-03-17 06:36:00 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:36:00 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:36:00 --> Utf8 Class Initialized
INFO - 2022-03-17 06:36:00 --> URI Class Initialized
INFO - 2022-03-17 06:36:00 --> Router Class Initialized
INFO - 2022-03-17 06:36:00 --> Output Class Initialized
INFO - 2022-03-17 06:36:00 --> Security Class Initialized
DEBUG - 2022-03-17 06:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:36:00 --> Input Class Initialized
INFO - 2022-03-17 06:36:00 --> Language Class Initialized
INFO - 2022-03-17 06:36:00 --> Loader Class Initialized
INFO - 2022-03-17 06:36:00 --> Helper loaded: url_helper
INFO - 2022-03-17 06:36:00 --> Helper loaded: form_helper
INFO - 2022-03-17 06:36:00 --> Helper loaded: common_helper
INFO - 2022-03-17 06:36:00 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:36:00 --> Controller Class Initialized
INFO - 2022-03-17 06:36:00 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:36:00 --> Encrypt Class Initialized
INFO - 2022-03-17 06:36:00 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:36:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:36:00 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:36:00 --> Model "Users_model" initialized
INFO - 2022-03-17 06:36:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:36:00 --> Config Class Initialized
INFO - 2022-03-17 06:36:00 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:36:00 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:36:00 --> Utf8 Class Initialized
INFO - 2022-03-17 06:36:00 --> URI Class Initialized
INFO - 2022-03-17 06:36:00 --> Router Class Initialized
INFO - 2022-03-17 06:36:00 --> Output Class Initialized
INFO - 2022-03-17 06:36:00 --> Security Class Initialized
DEBUG - 2022-03-17 06:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:36:00 --> Input Class Initialized
INFO - 2022-03-17 06:36:00 --> Language Class Initialized
INFO - 2022-03-17 06:36:00 --> Loader Class Initialized
INFO - 2022-03-17 06:36:00 --> Helper loaded: url_helper
INFO - 2022-03-17 06:36:00 --> Helper loaded: form_helper
INFO - 2022-03-17 06:36:00 --> Helper loaded: common_helper
INFO - 2022-03-17 06:36:00 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:36:00 --> Controller Class Initialized
INFO - 2022-03-17 06:36:00 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:36:00 --> Encrypt Class Initialized
INFO - 2022-03-17 06:36:00 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:36:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:36:00 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:36:00 --> Model "Users_model" initialized
INFO - 2022-03-17 06:36:00 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:36:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:36:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:36:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:36:01 --> Final output sent to browser
DEBUG - 2022-03-17 06:36:01 --> Total execution time: 0.0696
ERROR - 2022-03-17 06:36:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:36:27 --> Config Class Initialized
INFO - 2022-03-17 06:36:27 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:36:27 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:36:27 --> Utf8 Class Initialized
INFO - 2022-03-17 06:36:27 --> URI Class Initialized
INFO - 2022-03-17 06:36:27 --> Router Class Initialized
INFO - 2022-03-17 06:36:27 --> Output Class Initialized
INFO - 2022-03-17 06:36:27 --> Security Class Initialized
DEBUG - 2022-03-17 06:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:36:27 --> Input Class Initialized
INFO - 2022-03-17 06:36:27 --> Language Class Initialized
INFO - 2022-03-17 06:36:27 --> Loader Class Initialized
INFO - 2022-03-17 06:36:27 --> Helper loaded: url_helper
INFO - 2022-03-17 06:36:27 --> Helper loaded: form_helper
INFO - 2022-03-17 06:36:27 --> Helper loaded: common_helper
INFO - 2022-03-17 06:36:27 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:36:27 --> Controller Class Initialized
INFO - 2022-03-17 06:36:27 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:36:27 --> Encrypt Class Initialized
INFO - 2022-03-17 06:36:27 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:36:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:36:27 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:36:27 --> Model "Users_model" initialized
INFO - 2022-03-17 06:36:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:36:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:36:27 --> Config Class Initialized
INFO - 2022-03-17 06:36:27 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:36:27 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:36:27 --> Utf8 Class Initialized
INFO - 2022-03-17 06:36:27 --> URI Class Initialized
INFO - 2022-03-17 06:36:27 --> Router Class Initialized
INFO - 2022-03-17 06:36:27 --> Output Class Initialized
INFO - 2022-03-17 06:36:27 --> Security Class Initialized
DEBUG - 2022-03-17 06:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:36:27 --> Input Class Initialized
INFO - 2022-03-17 06:36:27 --> Language Class Initialized
INFO - 2022-03-17 06:36:27 --> Loader Class Initialized
INFO - 2022-03-17 06:36:27 --> Helper loaded: url_helper
INFO - 2022-03-17 06:36:27 --> Helper loaded: form_helper
INFO - 2022-03-17 06:36:27 --> Helper loaded: common_helper
INFO - 2022-03-17 06:36:27 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:36:27 --> Controller Class Initialized
INFO - 2022-03-17 06:36:27 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:36:27 --> Encrypt Class Initialized
INFO - 2022-03-17 06:36:27 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:36:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:36:27 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:36:27 --> Model "Users_model" initialized
INFO - 2022-03-17 06:36:27 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:36:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:36:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:36:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:36:28 --> Final output sent to browser
DEBUG - 2022-03-17 06:36:28 --> Total execution time: 0.0877
ERROR - 2022-03-17 06:38:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:38:05 --> Config Class Initialized
INFO - 2022-03-17 06:38:05 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:38:05 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:38:05 --> Utf8 Class Initialized
INFO - 2022-03-17 06:38:05 --> URI Class Initialized
INFO - 2022-03-17 06:38:05 --> Router Class Initialized
INFO - 2022-03-17 06:38:05 --> Output Class Initialized
INFO - 2022-03-17 06:38:05 --> Security Class Initialized
DEBUG - 2022-03-17 06:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:38:05 --> Input Class Initialized
INFO - 2022-03-17 06:38:05 --> Language Class Initialized
INFO - 2022-03-17 06:38:05 --> Loader Class Initialized
INFO - 2022-03-17 06:38:05 --> Helper loaded: url_helper
INFO - 2022-03-17 06:38:05 --> Helper loaded: form_helper
INFO - 2022-03-17 06:38:05 --> Helper loaded: common_helper
INFO - 2022-03-17 06:38:05 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:38:05 --> Controller Class Initialized
INFO - 2022-03-17 06:38:05 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:38:05 --> Encrypt Class Initialized
INFO - 2022-03-17 06:38:05 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:38:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:38:05 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:38:05 --> Model "Users_model" initialized
INFO - 2022-03-17 06:38:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:38:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:38:05 --> Config Class Initialized
INFO - 2022-03-17 06:38:05 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:38:05 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:38:05 --> Utf8 Class Initialized
INFO - 2022-03-17 06:38:05 --> URI Class Initialized
INFO - 2022-03-17 06:38:05 --> Router Class Initialized
INFO - 2022-03-17 06:38:05 --> Output Class Initialized
INFO - 2022-03-17 06:38:05 --> Security Class Initialized
DEBUG - 2022-03-17 06:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:38:05 --> Input Class Initialized
INFO - 2022-03-17 06:38:05 --> Language Class Initialized
INFO - 2022-03-17 06:38:05 --> Loader Class Initialized
INFO - 2022-03-17 06:38:05 --> Helper loaded: url_helper
INFO - 2022-03-17 06:38:05 --> Helper loaded: form_helper
INFO - 2022-03-17 06:38:05 --> Helper loaded: common_helper
INFO - 2022-03-17 06:38:05 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:38:05 --> Controller Class Initialized
INFO - 2022-03-17 06:38:05 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:38:05 --> Encrypt Class Initialized
INFO - 2022-03-17 06:38:05 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:38:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:38:05 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:38:05 --> Model "Users_model" initialized
INFO - 2022-03-17 06:38:05 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:38:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:38:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:38:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:38:06 --> Final output sent to browser
DEBUG - 2022-03-17 06:38:06 --> Total execution time: 0.1146
ERROR - 2022-03-17 06:38:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:38:11 --> Config Class Initialized
INFO - 2022-03-17 06:38:11 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:38:11 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:38:11 --> Utf8 Class Initialized
INFO - 2022-03-17 06:38:11 --> URI Class Initialized
INFO - 2022-03-17 06:38:11 --> Router Class Initialized
INFO - 2022-03-17 06:38:11 --> Output Class Initialized
INFO - 2022-03-17 06:38:11 --> Security Class Initialized
DEBUG - 2022-03-17 06:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:38:11 --> Input Class Initialized
INFO - 2022-03-17 06:38:11 --> Language Class Initialized
INFO - 2022-03-17 06:38:11 --> Loader Class Initialized
INFO - 2022-03-17 06:38:11 --> Helper loaded: url_helper
INFO - 2022-03-17 06:38:11 --> Helper loaded: form_helper
INFO - 2022-03-17 06:38:11 --> Helper loaded: common_helper
INFO - 2022-03-17 06:38:11 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:38:11 --> Controller Class Initialized
INFO - 2022-03-17 06:38:11 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:38:11 --> Encrypt Class Initialized
INFO - 2022-03-17 06:38:11 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:38:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:38:11 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:38:11 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:38:11 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:38:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:38:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 06:38:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:38:11 --> Final output sent to browser
DEBUG - 2022-03-17 06:38:11 --> Total execution time: 0.0836
ERROR - 2022-03-17 06:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:38:18 --> Config Class Initialized
INFO - 2022-03-17 06:38:18 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:38:18 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:38:18 --> Utf8 Class Initialized
INFO - 2022-03-17 06:38:18 --> URI Class Initialized
INFO - 2022-03-17 06:38:18 --> Router Class Initialized
INFO - 2022-03-17 06:38:18 --> Output Class Initialized
INFO - 2022-03-17 06:38:18 --> Security Class Initialized
DEBUG - 2022-03-17 06:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:38:18 --> Input Class Initialized
INFO - 2022-03-17 06:38:18 --> Language Class Initialized
INFO - 2022-03-17 06:38:18 --> Loader Class Initialized
INFO - 2022-03-17 06:38:18 --> Helper loaded: url_helper
INFO - 2022-03-17 06:38:18 --> Helper loaded: form_helper
INFO - 2022-03-17 06:38:18 --> Helper loaded: common_helper
INFO - 2022-03-17 06:38:18 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:38:18 --> Controller Class Initialized
INFO - 2022-03-17 06:38:18 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:38:18 --> Encrypt Class Initialized
INFO - 2022-03-17 06:38:18 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:38:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:38:18 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:38:18 --> Model "Users_model" initialized
INFO - 2022-03-17 06:38:18 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:38:18 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-17 06:38:19 --> Final output sent to browser
DEBUG - 2022-03-17 06:38:19 --> Total execution time: 1.4705
ERROR - 2022-03-17 06:53:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:53:34 --> Config Class Initialized
INFO - 2022-03-17 06:53:34 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:53:34 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:53:34 --> Utf8 Class Initialized
INFO - 2022-03-17 06:53:34 --> URI Class Initialized
INFO - 2022-03-17 06:53:34 --> Router Class Initialized
INFO - 2022-03-17 06:53:34 --> Output Class Initialized
INFO - 2022-03-17 06:53:34 --> Security Class Initialized
DEBUG - 2022-03-17 06:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:53:34 --> Input Class Initialized
INFO - 2022-03-17 06:53:34 --> Language Class Initialized
INFO - 2022-03-17 06:53:34 --> Loader Class Initialized
INFO - 2022-03-17 06:53:34 --> Helper loaded: url_helper
INFO - 2022-03-17 06:53:34 --> Helper loaded: form_helper
INFO - 2022-03-17 06:53:34 --> Helper loaded: common_helper
INFO - 2022-03-17 06:53:34 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:53:34 --> Controller Class Initialized
INFO - 2022-03-17 06:53:34 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:53:34 --> Encrypt Class Initialized
INFO - 2022-03-17 06:53:34 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:53:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:53:34 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:53:34 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:53:34 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:53:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-17 06:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:53:41 --> Config Class Initialized
INFO - 2022-03-17 06:53:41 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:53:41 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:53:41 --> Utf8 Class Initialized
INFO - 2022-03-17 06:53:41 --> URI Class Initialized
INFO - 2022-03-17 06:53:41 --> Router Class Initialized
INFO - 2022-03-17 06:53:41 --> Output Class Initialized
INFO - 2022-03-17 06:53:41 --> Security Class Initialized
DEBUG - 2022-03-17 06:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:53:41 --> Input Class Initialized
INFO - 2022-03-17 06:53:41 --> Language Class Initialized
INFO - 2022-03-17 06:53:41 --> Loader Class Initialized
INFO - 2022-03-17 06:53:41 --> Helper loaded: url_helper
INFO - 2022-03-17 06:53:41 --> Helper loaded: form_helper
INFO - 2022-03-17 06:53:41 --> Helper loaded: common_helper
INFO - 2022-03-17 06:53:41 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:53:41 --> Controller Class Initialized
INFO - 2022-03-17 06:53:41 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:53:41 --> Encrypt Class Initialized
INFO - 2022-03-17 06:53:41 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:53:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:53:41 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:53:41 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:53:41 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:53:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:53:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 06:53:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:53:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-17 06:53:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-17 06:53:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:53:51 --> Config Class Initialized
INFO - 2022-03-17 06:53:51 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:53:51 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:53:51 --> Utf8 Class Initialized
INFO - 2022-03-17 06:53:51 --> URI Class Initialized
INFO - 2022-03-17 06:53:51 --> Router Class Initialized
INFO - 2022-03-17 06:53:51 --> Output Class Initialized
INFO - 2022-03-17 06:53:51 --> Security Class Initialized
DEBUG - 2022-03-17 06:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:53:51 --> Input Class Initialized
INFO - 2022-03-17 06:53:51 --> Language Class Initialized
ERROR - 2022-03-17 06:53:51 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-17 06:53:51 --> Final output sent to browser
DEBUG - 2022-03-17 06:53:51 --> Total execution time: 8.1707
ERROR - 2022-03-17 06:55:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:55:05 --> Config Class Initialized
INFO - 2022-03-17 06:55:05 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:55:05 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:55:05 --> Utf8 Class Initialized
INFO - 2022-03-17 06:55:05 --> URI Class Initialized
INFO - 2022-03-17 06:55:05 --> Router Class Initialized
INFO - 2022-03-17 06:55:05 --> Output Class Initialized
INFO - 2022-03-17 06:55:05 --> Security Class Initialized
DEBUG - 2022-03-17 06:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:55:05 --> Input Class Initialized
INFO - 2022-03-17 06:55:05 --> Language Class Initialized
INFO - 2022-03-17 06:55:05 --> Loader Class Initialized
INFO - 2022-03-17 06:55:05 --> Helper loaded: url_helper
INFO - 2022-03-17 06:55:05 --> Helper loaded: form_helper
INFO - 2022-03-17 06:55:05 --> Helper loaded: common_helper
INFO - 2022-03-17 06:55:05 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:55:05 --> Controller Class Initialized
INFO - 2022-03-17 06:55:05 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:55:05 --> Encrypt Class Initialized
INFO - 2022-03-17 06:55:05 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:55:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:55:05 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:55:05 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:55:05 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:55:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:55:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:55:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:55:05 --> Final output sent to browser
DEBUG - 2022-03-17 06:55:05 --> Total execution time: 0.0680
ERROR - 2022-03-17 06:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:55:07 --> Config Class Initialized
INFO - 2022-03-17 06:55:07 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:55:07 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:55:07 --> Utf8 Class Initialized
INFO - 2022-03-17 06:55:07 --> URI Class Initialized
INFO - 2022-03-17 06:55:07 --> Router Class Initialized
INFO - 2022-03-17 06:55:07 --> Output Class Initialized
INFO - 2022-03-17 06:55:07 --> Security Class Initialized
DEBUG - 2022-03-17 06:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:55:07 --> Input Class Initialized
INFO - 2022-03-17 06:55:07 --> Language Class Initialized
ERROR - 2022-03-17 06:55:07 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:58:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:58:09 --> Config Class Initialized
INFO - 2022-03-17 06:58:09 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:58:09 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:58:09 --> Utf8 Class Initialized
INFO - 2022-03-17 06:58:09 --> URI Class Initialized
INFO - 2022-03-17 06:58:09 --> Router Class Initialized
INFO - 2022-03-17 06:58:09 --> Output Class Initialized
INFO - 2022-03-17 06:58:09 --> Security Class Initialized
DEBUG - 2022-03-17 06:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:58:09 --> Input Class Initialized
INFO - 2022-03-17 06:58:09 --> Language Class Initialized
INFO - 2022-03-17 06:58:09 --> Loader Class Initialized
INFO - 2022-03-17 06:58:09 --> Helper loaded: url_helper
INFO - 2022-03-17 06:58:09 --> Helper loaded: form_helper
INFO - 2022-03-17 06:58:09 --> Helper loaded: common_helper
INFO - 2022-03-17 06:58:09 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:58:09 --> Controller Class Initialized
INFO - 2022-03-17 06:58:09 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:58:09 --> Encrypt Class Initialized
INFO - 2022-03-17 06:58:09 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:58:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:58:09 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:58:09 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:58:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 06:58:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:58:10 --> Config Class Initialized
INFO - 2022-03-17 06:58:10 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:58:10 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:58:10 --> Utf8 Class Initialized
INFO - 2022-03-17 06:58:10 --> URI Class Initialized
INFO - 2022-03-17 06:58:10 --> Router Class Initialized
INFO - 2022-03-17 06:58:10 --> Output Class Initialized
INFO - 2022-03-17 06:58:10 --> Security Class Initialized
DEBUG - 2022-03-17 06:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:58:10 --> Input Class Initialized
INFO - 2022-03-17 06:58:10 --> Language Class Initialized
INFO - 2022-03-17 06:58:10 --> Loader Class Initialized
INFO - 2022-03-17 06:58:10 --> Helper loaded: url_helper
INFO - 2022-03-17 06:58:10 --> Helper loaded: form_helper
INFO - 2022-03-17 06:58:10 --> Helper loaded: common_helper
INFO - 2022-03-17 06:58:10 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:58:10 --> Controller Class Initialized
INFO - 2022-03-17 06:58:10 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:58:10 --> Encrypt Class Initialized
INFO - 2022-03-17 06:58:10 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:58:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:58:10 --> Model "Referredby_model" initialized
INFO - 2022-03-17 06:58:10 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:58:10 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:58:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:58:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 06:58:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:58:10 --> Final output sent to browser
DEBUG - 2022-03-17 06:58:10 --> Total execution time: 0.0567
ERROR - 2022-03-17 06:58:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:58:11 --> Config Class Initialized
INFO - 2022-03-17 06:58:11 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:58:11 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:58:11 --> Utf8 Class Initialized
INFO - 2022-03-17 06:58:11 --> URI Class Initialized
INFO - 2022-03-17 06:58:11 --> Router Class Initialized
INFO - 2022-03-17 06:58:11 --> Output Class Initialized
INFO - 2022-03-17 06:58:11 --> Security Class Initialized
DEBUG - 2022-03-17 06:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:58:11 --> Input Class Initialized
INFO - 2022-03-17 06:58:11 --> Language Class Initialized
ERROR - 2022-03-17 06:58:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 06:58:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:58:11 --> Config Class Initialized
INFO - 2022-03-17 06:58:11 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:58:11 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:58:11 --> Utf8 Class Initialized
INFO - 2022-03-17 06:58:11 --> URI Class Initialized
INFO - 2022-03-17 06:58:11 --> Router Class Initialized
INFO - 2022-03-17 06:58:11 --> Output Class Initialized
INFO - 2022-03-17 06:58:11 --> Security Class Initialized
DEBUG - 2022-03-17 06:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:58:11 --> Input Class Initialized
INFO - 2022-03-17 06:58:11 --> Language Class Initialized
INFO - 2022-03-17 06:58:11 --> Loader Class Initialized
INFO - 2022-03-17 06:58:11 --> Helper loaded: url_helper
INFO - 2022-03-17 06:58:11 --> Helper loaded: form_helper
INFO - 2022-03-17 06:58:11 --> Helper loaded: common_helper
INFO - 2022-03-17 06:58:11 --> Database Driver Class Initialized
DEBUG - 2022-03-17 06:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 06:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 06:58:11 --> Controller Class Initialized
INFO - 2022-03-17 06:58:11 --> Form Validation Class Initialized
DEBUG - 2022-03-17 06:58:11 --> Encrypt Class Initialized
INFO - 2022-03-17 06:58:11 --> Model "Patient_model" initialized
INFO - 2022-03-17 06:58:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 06:58:11 --> Model "Prefix_master" initialized
INFO - 2022-03-17 06:58:11 --> Model "Users_model" initialized
INFO - 2022-03-17 06:58:11 --> Model "Hospital_model" initialized
INFO - 2022-03-17 06:58:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 06:58:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 06:58:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 06:58:11 --> Final output sent to browser
DEBUG - 2022-03-17 06:58:11 --> Total execution time: 0.0882
ERROR - 2022-03-17 06:58:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 06:58:12 --> Config Class Initialized
INFO - 2022-03-17 06:58:12 --> Hooks Class Initialized
DEBUG - 2022-03-17 06:58:12 --> UTF-8 Support Enabled
INFO - 2022-03-17 06:58:12 --> Utf8 Class Initialized
INFO - 2022-03-17 06:58:12 --> URI Class Initialized
INFO - 2022-03-17 06:58:12 --> Router Class Initialized
INFO - 2022-03-17 06:58:12 --> Output Class Initialized
INFO - 2022-03-17 06:58:12 --> Security Class Initialized
DEBUG - 2022-03-17 06:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 06:58:12 --> Input Class Initialized
INFO - 2022-03-17 06:58:12 --> Language Class Initialized
ERROR - 2022-03-17 06:58:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 07:16:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:16:58 --> Config Class Initialized
INFO - 2022-03-17 07:16:58 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:16:58 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:16:58 --> Utf8 Class Initialized
INFO - 2022-03-17 07:16:58 --> URI Class Initialized
INFO - 2022-03-17 07:16:58 --> Router Class Initialized
INFO - 2022-03-17 07:16:58 --> Output Class Initialized
INFO - 2022-03-17 07:16:58 --> Security Class Initialized
DEBUG - 2022-03-17 07:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:16:58 --> Input Class Initialized
INFO - 2022-03-17 07:16:58 --> Language Class Initialized
INFO - 2022-03-17 07:16:58 --> Loader Class Initialized
INFO - 2022-03-17 07:16:58 --> Helper loaded: url_helper
INFO - 2022-03-17 07:16:58 --> Helper loaded: form_helper
INFO - 2022-03-17 07:16:58 --> Helper loaded: common_helper
INFO - 2022-03-17 07:16:58 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:16:58 --> Controller Class Initialized
INFO - 2022-03-17 07:16:58 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:16:58 --> Encrypt Class Initialized
INFO - 2022-03-17 07:16:58 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:16:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:16:58 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:16:58 --> Model "Users_model" initialized
INFO - 2022-03-17 07:16:58 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:16:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:16:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:16:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:16:58 --> Final output sent to browser
DEBUG - 2022-03-17 07:16:58 --> Total execution time: 0.0781
ERROR - 2022-03-17 07:17:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:17:04 --> Config Class Initialized
INFO - 2022-03-17 07:17:04 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:17:04 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:17:04 --> Utf8 Class Initialized
INFO - 2022-03-17 07:17:04 --> URI Class Initialized
INFO - 2022-03-17 07:17:04 --> Router Class Initialized
INFO - 2022-03-17 07:17:04 --> Output Class Initialized
INFO - 2022-03-17 07:17:04 --> Security Class Initialized
DEBUG - 2022-03-17 07:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:17:04 --> Input Class Initialized
INFO - 2022-03-17 07:17:04 --> Language Class Initialized
INFO - 2022-03-17 07:17:04 --> Loader Class Initialized
INFO - 2022-03-17 07:17:04 --> Helper loaded: url_helper
INFO - 2022-03-17 07:17:04 --> Helper loaded: form_helper
INFO - 2022-03-17 07:17:04 --> Helper loaded: common_helper
INFO - 2022-03-17 07:17:04 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:17:04 --> Controller Class Initialized
INFO - 2022-03-17 07:17:04 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:17:04 --> Encrypt Class Initialized
INFO - 2022-03-17 07:17:04 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:17:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:17:04 --> Model "Referredby_model" initialized
INFO - 2022-03-17 07:17:04 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:17:04 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:17:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:17:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 07:17:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:17:04 --> Final output sent to browser
DEBUG - 2022-03-17 07:17:04 --> Total execution time: 0.0703
ERROR - 2022-03-17 07:18:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:18:36 --> Config Class Initialized
INFO - 2022-03-17 07:18:36 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:18:36 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:18:36 --> Utf8 Class Initialized
INFO - 2022-03-17 07:18:36 --> URI Class Initialized
INFO - 2022-03-17 07:18:36 --> Router Class Initialized
INFO - 2022-03-17 07:18:36 --> Output Class Initialized
INFO - 2022-03-17 07:18:36 --> Security Class Initialized
DEBUG - 2022-03-17 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:18:36 --> Input Class Initialized
INFO - 2022-03-17 07:18:36 --> Language Class Initialized
INFO - 2022-03-17 07:18:36 --> Loader Class Initialized
INFO - 2022-03-17 07:18:36 --> Helper loaded: url_helper
INFO - 2022-03-17 07:18:36 --> Helper loaded: form_helper
INFO - 2022-03-17 07:18:36 --> Helper loaded: common_helper
INFO - 2022-03-17 07:18:36 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:18:36 --> Controller Class Initialized
INFO - 2022-03-17 07:18:36 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:18:36 --> Encrypt Class Initialized
INFO - 2022-03-17 07:18:36 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:18:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:18:36 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:18:36 --> Model "Users_model" initialized
INFO - 2022-03-17 07:18:36 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:18:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:18:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:18:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:18:36 --> Final output sent to browser
DEBUG - 2022-03-17 07:18:36 --> Total execution time: 0.0655
ERROR - 2022-03-17 07:18:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:18:38 --> Config Class Initialized
INFO - 2022-03-17 07:18:38 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:18:38 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:18:38 --> Utf8 Class Initialized
INFO - 2022-03-17 07:18:38 --> URI Class Initialized
INFO - 2022-03-17 07:18:38 --> Router Class Initialized
INFO - 2022-03-17 07:18:38 --> Output Class Initialized
INFO - 2022-03-17 07:18:38 --> Security Class Initialized
DEBUG - 2022-03-17 07:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:18:38 --> Input Class Initialized
INFO - 2022-03-17 07:18:38 --> Language Class Initialized
INFO - 2022-03-17 07:18:38 --> Loader Class Initialized
INFO - 2022-03-17 07:18:38 --> Helper loaded: url_helper
INFO - 2022-03-17 07:18:38 --> Helper loaded: form_helper
INFO - 2022-03-17 07:18:38 --> Helper loaded: common_helper
INFO - 2022-03-17 07:18:38 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:18:38 --> Controller Class Initialized
INFO - 2022-03-17 07:18:38 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:18:38 --> Encrypt Class Initialized
INFO - 2022-03-17 07:18:38 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:18:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:18:38 --> Model "Referredby_model" initialized
INFO - 2022-03-17 07:18:38 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:18:38 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:18:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:18:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 07:18:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:18:38 --> Final output sent to browser
DEBUG - 2022-03-17 07:18:38 --> Total execution time: 0.0729
ERROR - 2022-03-17 07:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:19:38 --> Config Class Initialized
INFO - 2022-03-17 07:19:38 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:19:38 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:19:38 --> Utf8 Class Initialized
INFO - 2022-03-17 07:19:38 --> URI Class Initialized
INFO - 2022-03-17 07:19:38 --> Router Class Initialized
INFO - 2022-03-17 07:19:38 --> Output Class Initialized
INFO - 2022-03-17 07:19:38 --> Security Class Initialized
DEBUG - 2022-03-17 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:19:38 --> Input Class Initialized
INFO - 2022-03-17 07:19:38 --> Language Class Initialized
INFO - 2022-03-17 07:19:38 --> Loader Class Initialized
INFO - 2022-03-17 07:19:38 --> Helper loaded: url_helper
INFO - 2022-03-17 07:19:38 --> Helper loaded: form_helper
INFO - 2022-03-17 07:19:38 --> Helper loaded: common_helper
INFO - 2022-03-17 07:19:38 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:19:38 --> Controller Class Initialized
INFO - 2022-03-17 07:19:38 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:19:38 --> Encrypt Class Initialized
INFO - 2022-03-17 07:19:38 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:19:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:19:38 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:19:38 --> Model "Users_model" initialized
INFO - 2022-03-17 07:19:38 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:19:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:19:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:19:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:19:38 --> Final output sent to browser
DEBUG - 2022-03-17 07:19:38 --> Total execution time: 0.0988
ERROR - 2022-03-17 07:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:19:45 --> Config Class Initialized
INFO - 2022-03-17 07:19:45 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:19:45 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:19:45 --> Utf8 Class Initialized
INFO - 2022-03-17 07:19:45 --> URI Class Initialized
INFO - 2022-03-17 07:19:45 --> Router Class Initialized
INFO - 2022-03-17 07:19:45 --> Output Class Initialized
INFO - 2022-03-17 07:19:46 --> Security Class Initialized
DEBUG - 2022-03-17 07:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:19:46 --> Input Class Initialized
INFO - 2022-03-17 07:19:46 --> Language Class Initialized
INFO - 2022-03-17 07:19:46 --> Loader Class Initialized
INFO - 2022-03-17 07:19:46 --> Helper loaded: url_helper
INFO - 2022-03-17 07:19:46 --> Helper loaded: form_helper
INFO - 2022-03-17 07:19:46 --> Helper loaded: common_helper
INFO - 2022-03-17 07:19:46 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:19:46 --> Controller Class Initialized
INFO - 2022-03-17 07:19:46 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:19:46 --> Encrypt Class Initialized
INFO - 2022-03-17 07:19:46 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:19:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:19:46 --> Model "Referredby_model" initialized
INFO - 2022-03-17 07:19:46 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:19:46 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:19:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:19:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 07:19:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:19:46 --> Final output sent to browser
DEBUG - 2022-03-17 07:19:46 --> Total execution time: 0.0653
ERROR - 2022-03-17 07:21:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:21:23 --> Config Class Initialized
INFO - 2022-03-17 07:21:23 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:21:23 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:21:23 --> Utf8 Class Initialized
INFO - 2022-03-17 07:21:23 --> URI Class Initialized
INFO - 2022-03-17 07:21:23 --> Router Class Initialized
INFO - 2022-03-17 07:21:23 --> Output Class Initialized
INFO - 2022-03-17 07:21:23 --> Security Class Initialized
DEBUG - 2022-03-17 07:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:21:23 --> Input Class Initialized
INFO - 2022-03-17 07:21:23 --> Language Class Initialized
INFO - 2022-03-17 07:21:23 --> Loader Class Initialized
INFO - 2022-03-17 07:21:23 --> Helper loaded: url_helper
INFO - 2022-03-17 07:21:23 --> Helper loaded: form_helper
INFO - 2022-03-17 07:21:23 --> Helper loaded: common_helper
INFO - 2022-03-17 07:21:23 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:21:23 --> Controller Class Initialized
INFO - 2022-03-17 07:21:23 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:21:23 --> Encrypt Class Initialized
INFO - 2022-03-17 07:21:23 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:21:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:21:23 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:21:23 --> Model "Users_model" initialized
INFO - 2022-03-17 07:21:23 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:21:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:21:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:21:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:21:23 --> Final output sent to browser
DEBUG - 2022-03-17 07:21:23 --> Total execution time: 0.1047
ERROR - 2022-03-17 07:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:21:26 --> Config Class Initialized
INFO - 2022-03-17 07:21:26 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:21:26 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:21:26 --> Utf8 Class Initialized
INFO - 2022-03-17 07:21:26 --> URI Class Initialized
INFO - 2022-03-17 07:21:26 --> Router Class Initialized
INFO - 2022-03-17 07:21:26 --> Output Class Initialized
INFO - 2022-03-17 07:21:26 --> Security Class Initialized
DEBUG - 2022-03-17 07:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:21:26 --> Input Class Initialized
INFO - 2022-03-17 07:21:26 --> Language Class Initialized
INFO - 2022-03-17 07:21:26 --> Loader Class Initialized
INFO - 2022-03-17 07:21:26 --> Helper loaded: url_helper
INFO - 2022-03-17 07:21:26 --> Helper loaded: form_helper
INFO - 2022-03-17 07:21:26 --> Helper loaded: common_helper
INFO - 2022-03-17 07:21:26 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:21:26 --> Controller Class Initialized
INFO - 2022-03-17 07:21:26 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:21:26 --> Encrypt Class Initialized
INFO - 2022-03-17 07:21:26 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:21:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:21:26 --> Model "Referredby_model" initialized
INFO - 2022-03-17 07:21:26 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:21:26 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:21:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:21:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 07:21:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:21:26 --> Final output sent to browser
DEBUG - 2022-03-17 07:21:26 --> Total execution time: 0.0961
ERROR - 2022-03-17 07:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:22:38 --> Config Class Initialized
INFO - 2022-03-17 07:22:38 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:22:38 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:22:38 --> Utf8 Class Initialized
INFO - 2022-03-17 07:22:38 --> URI Class Initialized
INFO - 2022-03-17 07:22:38 --> Router Class Initialized
INFO - 2022-03-17 07:22:38 --> Output Class Initialized
INFO - 2022-03-17 07:22:38 --> Security Class Initialized
DEBUG - 2022-03-17 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:22:38 --> Input Class Initialized
INFO - 2022-03-17 07:22:38 --> Language Class Initialized
INFO - 2022-03-17 07:22:38 --> Loader Class Initialized
INFO - 2022-03-17 07:22:38 --> Helper loaded: url_helper
INFO - 2022-03-17 07:22:38 --> Helper loaded: form_helper
INFO - 2022-03-17 07:22:38 --> Helper loaded: common_helper
INFO - 2022-03-17 07:22:38 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:22:38 --> Controller Class Initialized
INFO - 2022-03-17 07:22:38 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:22:38 --> Encrypt Class Initialized
INFO - 2022-03-17 07:22:38 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:22:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:22:38 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:22:38 --> Model "Users_model" initialized
INFO - 2022-03-17 07:22:38 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:22:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:22:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:22:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:22:38 --> Final output sent to browser
DEBUG - 2022-03-17 07:22:38 --> Total execution time: 0.1331
ERROR - 2022-03-17 07:22:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:22:45 --> Config Class Initialized
INFO - 2022-03-17 07:22:45 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:22:45 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:22:45 --> Utf8 Class Initialized
INFO - 2022-03-17 07:22:45 --> URI Class Initialized
INFO - 2022-03-17 07:22:45 --> Router Class Initialized
INFO - 2022-03-17 07:22:45 --> Output Class Initialized
INFO - 2022-03-17 07:22:45 --> Security Class Initialized
DEBUG - 2022-03-17 07:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:22:45 --> Input Class Initialized
INFO - 2022-03-17 07:22:45 --> Language Class Initialized
INFO - 2022-03-17 07:22:45 --> Loader Class Initialized
INFO - 2022-03-17 07:22:45 --> Helper loaded: url_helper
INFO - 2022-03-17 07:22:45 --> Helper loaded: form_helper
INFO - 2022-03-17 07:22:45 --> Helper loaded: common_helper
INFO - 2022-03-17 07:22:45 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:22:45 --> Controller Class Initialized
INFO - 2022-03-17 07:22:45 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:22:45 --> Encrypt Class Initialized
INFO - 2022-03-17 07:22:45 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:22:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:22:45 --> Model "Referredby_model" initialized
INFO - 2022-03-17 07:22:45 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:22:45 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:22:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:22:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 07:22:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:22:45 --> Final output sent to browser
DEBUG - 2022-03-17 07:22:45 --> Total execution time: 0.0639
ERROR - 2022-03-17 07:23:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:23:56 --> Config Class Initialized
INFO - 2022-03-17 07:23:56 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:23:56 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:23:56 --> Utf8 Class Initialized
INFO - 2022-03-17 07:23:56 --> URI Class Initialized
DEBUG - 2022-03-17 07:23:56 --> No URI present. Default controller set.
INFO - 2022-03-17 07:23:56 --> Router Class Initialized
INFO - 2022-03-17 07:23:56 --> Output Class Initialized
INFO - 2022-03-17 07:23:56 --> Security Class Initialized
DEBUG - 2022-03-17 07:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:23:56 --> Input Class Initialized
INFO - 2022-03-17 07:23:56 --> Language Class Initialized
INFO - 2022-03-17 07:23:56 --> Loader Class Initialized
INFO - 2022-03-17 07:23:56 --> Helper loaded: url_helper
INFO - 2022-03-17 07:23:56 --> Helper loaded: form_helper
INFO - 2022-03-17 07:23:56 --> Helper loaded: common_helper
INFO - 2022-03-17 07:23:56 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:23:56 --> Controller Class Initialized
INFO - 2022-03-17 07:23:56 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:23:56 --> Encrypt Class Initialized
DEBUG - 2022-03-17 07:23:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 07:23:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 07:23:56 --> Email Class Initialized
INFO - 2022-03-17 07:23:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 07:23:56 --> Calendar Class Initialized
INFO - 2022-03-17 07:23:56 --> Model "Login_model" initialized
ERROR - 2022-03-17 07:23:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:23:57 --> Config Class Initialized
INFO - 2022-03-17 07:23:57 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:23:57 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:23:57 --> Utf8 Class Initialized
INFO - 2022-03-17 07:23:57 --> URI Class Initialized
INFO - 2022-03-17 07:23:57 --> Router Class Initialized
INFO - 2022-03-17 07:23:57 --> Output Class Initialized
INFO - 2022-03-17 07:23:57 --> Security Class Initialized
DEBUG - 2022-03-17 07:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:23:57 --> Input Class Initialized
INFO - 2022-03-17 07:23:57 --> Language Class Initialized
INFO - 2022-03-17 07:23:57 --> Loader Class Initialized
INFO - 2022-03-17 07:23:57 --> Helper loaded: url_helper
INFO - 2022-03-17 07:23:57 --> Helper loaded: form_helper
INFO - 2022-03-17 07:23:57 --> Helper loaded: common_helper
INFO - 2022-03-17 07:23:57 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:23:57 --> Controller Class Initialized
INFO - 2022-03-17 07:23:57 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:23:57 --> Encrypt Class Initialized
INFO - 2022-03-17 07:23:57 --> Model "Diseases_model" initialized
INFO - 2022-03-17 07:23:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:23:57 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-17 07:23:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:23:57 --> Final output sent to browser
DEBUG - 2022-03-17 07:23:57 --> Total execution time: 0.0238
ERROR - 2022-03-17 07:23:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:23:59 --> Config Class Initialized
INFO - 2022-03-17 07:23:59 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:23:59 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:23:59 --> Utf8 Class Initialized
INFO - 2022-03-17 07:23:59 --> URI Class Initialized
INFO - 2022-03-17 07:23:59 --> Router Class Initialized
INFO - 2022-03-17 07:23:59 --> Output Class Initialized
INFO - 2022-03-17 07:23:59 --> Security Class Initialized
DEBUG - 2022-03-17 07:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:23:59 --> Input Class Initialized
INFO - 2022-03-17 07:23:59 --> Language Class Initialized
ERROR - 2022-03-17 07:23:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 07:25:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:25:13 --> Config Class Initialized
INFO - 2022-03-17 07:25:13 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:25:13 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:25:13 --> Utf8 Class Initialized
INFO - 2022-03-17 07:25:13 --> URI Class Initialized
INFO - 2022-03-17 07:25:13 --> Router Class Initialized
INFO - 2022-03-17 07:25:13 --> Output Class Initialized
INFO - 2022-03-17 07:25:13 --> Security Class Initialized
DEBUG - 2022-03-17 07:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:25:13 --> Input Class Initialized
INFO - 2022-03-17 07:25:13 --> Language Class Initialized
INFO - 2022-03-17 07:25:13 --> Loader Class Initialized
INFO - 2022-03-17 07:25:13 --> Helper loaded: url_helper
INFO - 2022-03-17 07:25:13 --> Helper loaded: form_helper
INFO - 2022-03-17 07:25:13 --> Helper loaded: common_helper
INFO - 2022-03-17 07:25:13 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:25:13 --> Controller Class Initialized
INFO - 2022-03-17 07:25:13 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:25:13 --> Encrypt Class Initialized
INFO - 2022-03-17 07:25:13 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:25:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:25:13 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:25:13 --> Model "Users_model" initialized
INFO - 2022-03-17 07:25:13 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:25:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:25:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:25:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:25:13 --> Final output sent to browser
DEBUG - 2022-03-17 07:25:13 --> Total execution time: 0.0983
ERROR - 2022-03-17 07:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:25:16 --> Config Class Initialized
INFO - 2022-03-17 07:25:16 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:25:16 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:25:16 --> Utf8 Class Initialized
INFO - 2022-03-17 07:25:16 --> URI Class Initialized
INFO - 2022-03-17 07:25:16 --> Router Class Initialized
INFO - 2022-03-17 07:25:16 --> Output Class Initialized
INFO - 2022-03-17 07:25:16 --> Security Class Initialized
DEBUG - 2022-03-17 07:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:25:16 --> Input Class Initialized
INFO - 2022-03-17 07:25:16 --> Language Class Initialized
INFO - 2022-03-17 07:25:16 --> Loader Class Initialized
INFO - 2022-03-17 07:25:16 --> Helper loaded: url_helper
INFO - 2022-03-17 07:25:16 --> Helper loaded: form_helper
INFO - 2022-03-17 07:25:16 --> Helper loaded: common_helper
INFO - 2022-03-17 07:25:16 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:25:16 --> Controller Class Initialized
INFO - 2022-03-17 07:25:16 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:25:16 --> Encrypt Class Initialized
INFO - 2022-03-17 07:25:16 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:25:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:25:16 --> Model "Referredby_model" initialized
INFO - 2022-03-17 07:25:16 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:25:16 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:25:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:25:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 07:25:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:25:16 --> Final output sent to browser
DEBUG - 2022-03-17 07:25:16 --> Total execution time: 0.0580
ERROR - 2022-03-17 07:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:26:03 --> Config Class Initialized
INFO - 2022-03-17 07:26:03 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:26:03 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:26:03 --> Utf8 Class Initialized
INFO - 2022-03-17 07:26:03 --> URI Class Initialized
INFO - 2022-03-17 07:26:03 --> Router Class Initialized
INFO - 2022-03-17 07:26:03 --> Output Class Initialized
INFO - 2022-03-17 07:26:03 --> Security Class Initialized
DEBUG - 2022-03-17 07:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:26:03 --> Input Class Initialized
INFO - 2022-03-17 07:26:03 --> Language Class Initialized
INFO - 2022-03-17 07:26:03 --> Loader Class Initialized
INFO - 2022-03-17 07:26:03 --> Helper loaded: url_helper
INFO - 2022-03-17 07:26:03 --> Helper loaded: form_helper
INFO - 2022-03-17 07:26:03 --> Helper loaded: common_helper
INFO - 2022-03-17 07:26:03 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:26:03 --> Controller Class Initialized
INFO - 2022-03-17 07:26:03 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:26:03 --> Encrypt Class Initialized
INFO - 2022-03-17 07:26:03 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:26:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:26:03 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:26:03 --> Model "Users_model" initialized
INFO - 2022-03-17 07:26:03 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:26:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:26:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:26:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:26:03 --> Final output sent to browser
DEBUG - 2022-03-17 07:26:03 --> Total execution time: 0.0627
ERROR - 2022-03-17 07:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:26:05 --> Config Class Initialized
INFO - 2022-03-17 07:26:05 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:26:05 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:26:05 --> Utf8 Class Initialized
INFO - 2022-03-17 07:26:05 --> URI Class Initialized
INFO - 2022-03-17 07:26:05 --> Router Class Initialized
INFO - 2022-03-17 07:26:05 --> Output Class Initialized
INFO - 2022-03-17 07:26:05 --> Security Class Initialized
DEBUG - 2022-03-17 07:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:26:05 --> Input Class Initialized
INFO - 2022-03-17 07:26:05 --> Language Class Initialized
INFO - 2022-03-17 07:26:05 --> Loader Class Initialized
INFO - 2022-03-17 07:26:05 --> Helper loaded: url_helper
INFO - 2022-03-17 07:26:05 --> Helper loaded: form_helper
INFO - 2022-03-17 07:26:05 --> Helper loaded: common_helper
INFO - 2022-03-17 07:26:05 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:26:05 --> Controller Class Initialized
INFO - 2022-03-17 07:26:05 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:26:05 --> Encrypt Class Initialized
INFO - 2022-03-17 07:26:05 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:26:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:26:05 --> Model "Referredby_model" initialized
INFO - 2022-03-17 07:26:05 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:26:05 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:26:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:26:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 07:26:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:26:05 --> Final output sent to browser
DEBUG - 2022-03-17 07:26:05 --> Total execution time: 0.0704
ERROR - 2022-03-17 07:26:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:26:41 --> Config Class Initialized
INFO - 2022-03-17 07:26:41 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:26:41 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:26:41 --> Utf8 Class Initialized
INFO - 2022-03-17 07:26:41 --> URI Class Initialized
INFO - 2022-03-17 07:26:41 --> Router Class Initialized
INFO - 2022-03-17 07:26:41 --> Output Class Initialized
INFO - 2022-03-17 07:26:41 --> Security Class Initialized
DEBUG - 2022-03-17 07:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:26:41 --> Input Class Initialized
INFO - 2022-03-17 07:26:41 --> Language Class Initialized
INFO - 2022-03-17 07:26:41 --> Loader Class Initialized
INFO - 2022-03-17 07:26:41 --> Helper loaded: url_helper
INFO - 2022-03-17 07:26:41 --> Helper loaded: form_helper
INFO - 2022-03-17 07:26:41 --> Helper loaded: common_helper
INFO - 2022-03-17 07:26:41 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:26:41 --> Controller Class Initialized
INFO - 2022-03-17 07:26:41 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:26:41 --> Encrypt Class Initialized
INFO - 2022-03-17 07:26:41 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:26:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:26:41 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:26:41 --> Model "Users_model" initialized
INFO - 2022-03-17 07:26:41 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:26:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:26:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:26:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:26:41 --> Final output sent to browser
DEBUG - 2022-03-17 07:26:41 --> Total execution time: 0.0571
ERROR - 2022-03-17 07:26:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:26:43 --> Config Class Initialized
INFO - 2022-03-17 07:26:43 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:26:43 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:26:43 --> Utf8 Class Initialized
INFO - 2022-03-17 07:26:43 --> URI Class Initialized
INFO - 2022-03-17 07:26:43 --> Router Class Initialized
INFO - 2022-03-17 07:26:43 --> Output Class Initialized
INFO - 2022-03-17 07:26:43 --> Security Class Initialized
DEBUG - 2022-03-17 07:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:26:43 --> Input Class Initialized
INFO - 2022-03-17 07:26:43 --> Language Class Initialized
INFO - 2022-03-17 07:26:43 --> Loader Class Initialized
INFO - 2022-03-17 07:26:43 --> Helper loaded: url_helper
INFO - 2022-03-17 07:26:43 --> Helper loaded: form_helper
INFO - 2022-03-17 07:26:43 --> Helper loaded: common_helper
INFO - 2022-03-17 07:26:43 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:26:43 --> Controller Class Initialized
INFO - 2022-03-17 07:26:43 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:26:43 --> Encrypt Class Initialized
INFO - 2022-03-17 07:26:43 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:26:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:26:43 --> Model "Referredby_model" initialized
INFO - 2022-03-17 07:26:43 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:26:43 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:26:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:26:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-17 07:26:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:26:43 --> Final output sent to browser
DEBUG - 2022-03-17 07:26:43 --> Total execution time: 0.0464
ERROR - 2022-03-17 07:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:28:56 --> Config Class Initialized
INFO - 2022-03-17 07:28:56 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:28:56 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:28:56 --> Utf8 Class Initialized
INFO - 2022-03-17 07:28:56 --> URI Class Initialized
INFO - 2022-03-17 07:28:56 --> Router Class Initialized
INFO - 2022-03-17 07:28:56 --> Output Class Initialized
INFO - 2022-03-17 07:28:56 --> Security Class Initialized
DEBUG - 2022-03-17 07:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:28:56 --> Input Class Initialized
INFO - 2022-03-17 07:28:56 --> Language Class Initialized
INFO - 2022-03-17 07:28:56 --> Loader Class Initialized
INFO - 2022-03-17 07:28:56 --> Helper loaded: url_helper
INFO - 2022-03-17 07:28:56 --> Helper loaded: form_helper
INFO - 2022-03-17 07:28:56 --> Helper loaded: common_helper
INFO - 2022-03-17 07:28:56 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:28:56 --> Controller Class Initialized
INFO - 2022-03-17 07:28:56 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:28:56 --> Encrypt Class Initialized
INFO - 2022-03-17 07:28:56 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:28:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:28:56 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:28:56 --> Model "Users_model" initialized
INFO - 2022-03-17 07:28:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 07:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:28:56 --> Config Class Initialized
INFO - 2022-03-17 07:28:56 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:28:56 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:28:56 --> Utf8 Class Initialized
INFO - 2022-03-17 07:28:56 --> URI Class Initialized
INFO - 2022-03-17 07:28:56 --> Router Class Initialized
INFO - 2022-03-17 07:28:56 --> Output Class Initialized
INFO - 2022-03-17 07:28:56 --> Security Class Initialized
DEBUG - 2022-03-17 07:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:28:56 --> Input Class Initialized
INFO - 2022-03-17 07:28:56 --> Language Class Initialized
INFO - 2022-03-17 07:28:56 --> Loader Class Initialized
INFO - 2022-03-17 07:28:56 --> Helper loaded: url_helper
INFO - 2022-03-17 07:28:56 --> Helper loaded: form_helper
INFO - 2022-03-17 07:28:56 --> Helper loaded: common_helper
INFO - 2022-03-17 07:28:56 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:28:56 --> Controller Class Initialized
INFO - 2022-03-17 07:28:56 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:28:56 --> Encrypt Class Initialized
INFO - 2022-03-17 07:28:56 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:28:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:28:56 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:28:56 --> Model "Users_model" initialized
INFO - 2022-03-17 07:28:56 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:28:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:28:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:28:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:28:57 --> Final output sent to browser
DEBUG - 2022-03-17 07:28:57 --> Total execution time: 0.1099
ERROR - 2022-03-17 07:28:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:28:57 --> Config Class Initialized
INFO - 2022-03-17 07:28:57 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:28:57 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:28:57 --> Utf8 Class Initialized
INFO - 2022-03-17 07:28:57 --> URI Class Initialized
INFO - 2022-03-17 07:28:57 --> Router Class Initialized
INFO - 2022-03-17 07:28:57 --> Output Class Initialized
INFO - 2022-03-17 07:28:57 --> Security Class Initialized
DEBUG - 2022-03-17 07:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:28:57 --> Input Class Initialized
INFO - 2022-03-17 07:28:57 --> Language Class Initialized
ERROR - 2022-03-17 07:28:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 07:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:29:08 --> Config Class Initialized
INFO - 2022-03-17 07:29:08 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:29:08 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:29:08 --> Utf8 Class Initialized
INFO - 2022-03-17 07:29:08 --> URI Class Initialized
INFO - 2022-03-17 07:29:08 --> Router Class Initialized
INFO - 2022-03-17 07:29:08 --> Output Class Initialized
INFO - 2022-03-17 07:29:08 --> Security Class Initialized
DEBUG - 2022-03-17 07:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:29:08 --> Input Class Initialized
INFO - 2022-03-17 07:29:08 --> Language Class Initialized
INFO - 2022-03-17 07:29:08 --> Loader Class Initialized
INFO - 2022-03-17 07:29:08 --> Helper loaded: url_helper
INFO - 2022-03-17 07:29:08 --> Helper loaded: form_helper
INFO - 2022-03-17 07:29:08 --> Helper loaded: common_helper
INFO - 2022-03-17 07:29:08 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:29:08 --> Controller Class Initialized
INFO - 2022-03-17 07:29:08 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:29:08 --> Encrypt Class Initialized
INFO - 2022-03-17 07:29:08 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:29:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:29:08 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:29:08 --> Model "Users_model" initialized
INFO - 2022-03-17 07:29:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-17 07:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:29:08 --> Config Class Initialized
INFO - 2022-03-17 07:29:08 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:29:08 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:29:08 --> Utf8 Class Initialized
INFO - 2022-03-17 07:29:08 --> URI Class Initialized
INFO - 2022-03-17 07:29:08 --> Router Class Initialized
INFO - 2022-03-17 07:29:08 --> Output Class Initialized
INFO - 2022-03-17 07:29:08 --> Security Class Initialized
DEBUG - 2022-03-17 07:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:29:08 --> Input Class Initialized
INFO - 2022-03-17 07:29:08 --> Language Class Initialized
INFO - 2022-03-17 07:29:08 --> Loader Class Initialized
INFO - 2022-03-17 07:29:08 --> Helper loaded: url_helper
INFO - 2022-03-17 07:29:08 --> Helper loaded: form_helper
INFO - 2022-03-17 07:29:08 --> Helper loaded: common_helper
INFO - 2022-03-17 07:29:08 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:29:08 --> Controller Class Initialized
INFO - 2022-03-17 07:29:08 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:29:08 --> Encrypt Class Initialized
INFO - 2022-03-17 07:29:08 --> Model "Patient_model" initialized
INFO - 2022-03-17 07:29:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-17 07:29:08 --> Model "Prefix_master" initialized
INFO - 2022-03-17 07:29:08 --> Model "Users_model" initialized
INFO - 2022-03-17 07:29:08 --> Model "Hospital_model" initialized
INFO - 2022-03-17 07:29:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-17 07:29:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-17 07:29:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-17 07:29:08 --> Final output sent to browser
DEBUG - 2022-03-17 07:29:08 --> Total execution time: 0.0645
ERROR - 2022-03-17 07:29:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:29:09 --> Config Class Initialized
INFO - 2022-03-17 07:29:09 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:29:09 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:29:09 --> Utf8 Class Initialized
INFO - 2022-03-17 07:29:09 --> URI Class Initialized
INFO - 2022-03-17 07:29:09 --> Router Class Initialized
INFO - 2022-03-17 07:29:09 --> Output Class Initialized
INFO - 2022-03-17 07:29:09 --> Security Class Initialized
DEBUG - 2022-03-17 07:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:29:09 --> Input Class Initialized
INFO - 2022-03-17 07:29:09 --> Language Class Initialized
ERROR - 2022-03-17 07:29:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-17 07:29:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:29:30 --> Config Class Initialized
INFO - 2022-03-17 07:29:30 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:29:30 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:29:30 --> Utf8 Class Initialized
INFO - 2022-03-17 07:29:30 --> URI Class Initialized
INFO - 2022-03-17 07:29:30 --> Router Class Initialized
INFO - 2022-03-17 07:29:30 --> Output Class Initialized
INFO - 2022-03-17 07:29:30 --> Security Class Initialized
DEBUG - 2022-03-17 07:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:29:30 --> Input Class Initialized
INFO - 2022-03-17 07:29:30 --> Language Class Initialized
INFO - 2022-03-17 07:29:30 --> Loader Class Initialized
INFO - 2022-03-17 07:29:30 --> Helper loaded: url_helper
INFO - 2022-03-17 07:29:30 --> Helper loaded: form_helper
INFO - 2022-03-17 07:29:30 --> Helper loaded: common_helper
INFO - 2022-03-17 07:29:30 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:29:30 --> Controller Class Initialized
INFO - 2022-03-17 07:29:30 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:29:30 --> Encrypt Class Initialized
DEBUG - 2022-03-17 07:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 07:29:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 07:29:30 --> Email Class Initialized
INFO - 2022-03-17 07:29:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 07:29:30 --> Calendar Class Initialized
INFO - 2022-03-17 07:29:30 --> Model "Login_model" initialized
ERROR - 2022-03-17 07:29:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:29:31 --> Config Class Initialized
INFO - 2022-03-17 07:29:31 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:29:31 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:29:31 --> Utf8 Class Initialized
INFO - 2022-03-17 07:29:31 --> URI Class Initialized
INFO - 2022-03-17 07:29:31 --> Router Class Initialized
INFO - 2022-03-17 07:29:31 --> Output Class Initialized
INFO - 2022-03-17 07:29:31 --> Security Class Initialized
DEBUG - 2022-03-17 07:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:29:31 --> Input Class Initialized
INFO - 2022-03-17 07:29:31 --> Language Class Initialized
INFO - 2022-03-17 07:29:31 --> Loader Class Initialized
INFO - 2022-03-17 07:29:31 --> Helper loaded: url_helper
INFO - 2022-03-17 07:29:31 --> Helper loaded: form_helper
INFO - 2022-03-17 07:29:31 --> Helper loaded: common_helper
INFO - 2022-03-17 07:29:31 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:29:31 --> Controller Class Initialized
INFO - 2022-03-17 07:29:31 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:29:31 --> Encrypt Class Initialized
DEBUG - 2022-03-17 07:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 07:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 07:29:31 --> Email Class Initialized
INFO - 2022-03-17 07:29:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 07:29:31 --> Calendar Class Initialized
INFO - 2022-03-17 07:29:31 --> Model "Login_model" initialized
INFO - 2022-03-17 07:29:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 07:29:31 --> Final output sent to browser
DEBUG - 2022-03-17 07:29:31 --> Total execution time: 0.0349
ERROR - 2022-03-17 07:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:31:43 --> Config Class Initialized
INFO - 2022-03-17 07:31:43 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:31:43 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:31:43 --> Utf8 Class Initialized
INFO - 2022-03-17 07:31:43 --> URI Class Initialized
INFO - 2022-03-17 07:31:43 --> Router Class Initialized
INFO - 2022-03-17 07:31:43 --> Output Class Initialized
INFO - 2022-03-17 07:31:43 --> Security Class Initialized
DEBUG - 2022-03-17 07:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:31:43 --> Input Class Initialized
INFO - 2022-03-17 07:31:43 --> Language Class Initialized
INFO - 2022-03-17 07:31:43 --> Loader Class Initialized
INFO - 2022-03-17 07:31:43 --> Helper loaded: url_helper
INFO - 2022-03-17 07:31:43 --> Helper loaded: form_helper
INFO - 2022-03-17 07:31:43 --> Helper loaded: common_helper
INFO - 2022-03-17 07:31:43 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:31:43 --> Controller Class Initialized
INFO - 2022-03-17 07:31:43 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:31:43 --> Encrypt Class Initialized
DEBUG - 2022-03-17 07:31:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 07:31:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 07:31:43 --> Email Class Initialized
INFO - 2022-03-17 07:31:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 07:31:43 --> Calendar Class Initialized
INFO - 2022-03-17 07:31:43 --> Model "Login_model" initialized
ERROR - 2022-03-17 07:31:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 07:31:44 --> Config Class Initialized
INFO - 2022-03-17 07:31:44 --> Hooks Class Initialized
DEBUG - 2022-03-17 07:31:44 --> UTF-8 Support Enabled
INFO - 2022-03-17 07:31:44 --> Utf8 Class Initialized
INFO - 2022-03-17 07:31:44 --> URI Class Initialized
INFO - 2022-03-17 07:31:44 --> Router Class Initialized
INFO - 2022-03-17 07:31:44 --> Output Class Initialized
INFO - 2022-03-17 07:31:44 --> Security Class Initialized
DEBUG - 2022-03-17 07:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 07:31:44 --> Input Class Initialized
INFO - 2022-03-17 07:31:44 --> Language Class Initialized
INFO - 2022-03-17 07:31:44 --> Loader Class Initialized
INFO - 2022-03-17 07:31:44 --> Helper loaded: url_helper
INFO - 2022-03-17 07:31:44 --> Helper loaded: form_helper
INFO - 2022-03-17 07:31:44 --> Helper loaded: common_helper
INFO - 2022-03-17 07:31:44 --> Database Driver Class Initialized
DEBUG - 2022-03-17 07:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 07:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 07:31:44 --> Controller Class Initialized
INFO - 2022-03-17 07:31:44 --> Form Validation Class Initialized
DEBUG - 2022-03-17 07:31:44 --> Encrypt Class Initialized
DEBUG - 2022-03-17 07:31:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 07:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 07:31:44 --> Email Class Initialized
INFO - 2022-03-17 07:31:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 07:31:44 --> Calendar Class Initialized
INFO - 2022-03-17 07:31:44 --> Model "Login_model" initialized
INFO - 2022-03-17 07:31:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 07:31:44 --> Final output sent to browser
DEBUG - 2022-03-17 07:31:44 --> Total execution time: 0.0663
ERROR - 2022-03-17 13:46:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 13:46:10 --> Config Class Initialized
INFO - 2022-03-17 13:46:10 --> Hooks Class Initialized
DEBUG - 2022-03-17 13:46:10 --> UTF-8 Support Enabled
INFO - 2022-03-17 13:46:10 --> Utf8 Class Initialized
INFO - 2022-03-17 13:46:10 --> URI Class Initialized
DEBUG - 2022-03-17 13:46:10 --> No URI present. Default controller set.
INFO - 2022-03-17 13:46:10 --> Router Class Initialized
INFO - 2022-03-17 13:46:10 --> Output Class Initialized
INFO - 2022-03-17 13:46:10 --> Security Class Initialized
DEBUG - 2022-03-17 13:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 13:46:10 --> Input Class Initialized
INFO - 2022-03-17 13:46:10 --> Language Class Initialized
INFO - 2022-03-17 13:46:10 --> Loader Class Initialized
INFO - 2022-03-17 13:46:10 --> Helper loaded: url_helper
INFO - 2022-03-17 13:46:10 --> Helper loaded: form_helper
INFO - 2022-03-17 13:46:10 --> Helper loaded: common_helper
INFO - 2022-03-17 13:46:10 --> Database Driver Class Initialized
DEBUG - 2022-03-17 13:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 13:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 13:46:11 --> Controller Class Initialized
INFO - 2022-03-17 13:46:11 --> Form Validation Class Initialized
DEBUG - 2022-03-17 13:46:11 --> Encrypt Class Initialized
DEBUG - 2022-03-17 13:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:46:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 13:46:11 --> Email Class Initialized
INFO - 2022-03-17 13:46:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 13:46:11 --> Calendar Class Initialized
INFO - 2022-03-17 13:46:11 --> Model "Login_model" initialized
INFO - 2022-03-17 13:46:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 13:46:11 --> Final output sent to browser
DEBUG - 2022-03-17 13:46:11 --> Total execution time: 1.0640
ERROR - 2022-03-17 14:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 14:22:55 --> Config Class Initialized
INFO - 2022-03-17 14:22:55 --> Hooks Class Initialized
DEBUG - 2022-03-17 14:22:55 --> UTF-8 Support Enabled
INFO - 2022-03-17 14:22:55 --> Utf8 Class Initialized
INFO - 2022-03-17 14:22:55 --> URI Class Initialized
DEBUG - 2022-03-17 14:22:55 --> No URI present. Default controller set.
INFO - 2022-03-17 14:22:55 --> Router Class Initialized
INFO - 2022-03-17 14:22:55 --> Output Class Initialized
INFO - 2022-03-17 14:22:55 --> Security Class Initialized
DEBUG - 2022-03-17 14:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 14:22:55 --> Input Class Initialized
INFO - 2022-03-17 14:22:55 --> Language Class Initialized
INFO - 2022-03-17 14:22:55 --> Loader Class Initialized
INFO - 2022-03-17 14:22:55 --> Helper loaded: url_helper
INFO - 2022-03-17 14:22:55 --> Helper loaded: form_helper
INFO - 2022-03-17 14:22:55 --> Helper loaded: common_helper
INFO - 2022-03-17 14:22:55 --> Database Driver Class Initialized
DEBUG - 2022-03-17 14:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 14:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 14:22:55 --> Controller Class Initialized
INFO - 2022-03-17 14:22:55 --> Form Validation Class Initialized
DEBUG - 2022-03-17 14:22:55 --> Encrypt Class Initialized
DEBUG - 2022-03-17 14:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:22:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 14:22:55 --> Email Class Initialized
INFO - 2022-03-17 14:22:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 14:22:55 --> Calendar Class Initialized
INFO - 2022-03-17 14:22:55 --> Model "Login_model" initialized
INFO - 2022-03-17 14:22:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 14:22:55 --> Final output sent to browser
DEBUG - 2022-03-17 14:22:55 --> Total execution time: 0.0623
ERROR - 2022-03-17 14:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 14:22:56 --> Config Class Initialized
INFO - 2022-03-17 14:22:56 --> Hooks Class Initialized
DEBUG - 2022-03-17 14:22:56 --> UTF-8 Support Enabled
INFO - 2022-03-17 14:22:56 --> Utf8 Class Initialized
INFO - 2022-03-17 14:22:56 --> URI Class Initialized
INFO - 2022-03-17 14:22:56 --> Router Class Initialized
INFO - 2022-03-17 14:22:56 --> Output Class Initialized
INFO - 2022-03-17 14:22:56 --> Security Class Initialized
DEBUG - 2022-03-17 14:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 14:22:56 --> Input Class Initialized
INFO - 2022-03-17 14:22:56 --> Language Class Initialized
ERROR - 2022-03-17 14:22:56 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-17 14:23:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 14:23:22 --> Config Class Initialized
INFO - 2022-03-17 14:23:22 --> Hooks Class Initialized
DEBUG - 2022-03-17 14:23:22 --> UTF-8 Support Enabled
INFO - 2022-03-17 14:23:22 --> Utf8 Class Initialized
INFO - 2022-03-17 14:23:22 --> URI Class Initialized
INFO - 2022-03-17 14:23:22 --> Router Class Initialized
INFO - 2022-03-17 14:23:22 --> Output Class Initialized
INFO - 2022-03-17 14:23:22 --> Security Class Initialized
DEBUG - 2022-03-17 14:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 14:23:22 --> Input Class Initialized
INFO - 2022-03-17 14:23:22 --> Language Class Initialized
INFO - 2022-03-17 14:23:22 --> Loader Class Initialized
INFO - 2022-03-17 14:23:22 --> Helper loaded: url_helper
INFO - 2022-03-17 14:23:22 --> Helper loaded: form_helper
INFO - 2022-03-17 14:23:22 --> Helper loaded: common_helper
INFO - 2022-03-17 14:23:22 --> Database Driver Class Initialized
DEBUG - 2022-03-17 14:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 14:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 14:23:22 --> Controller Class Initialized
INFO - 2022-03-17 14:23:22 --> Form Validation Class Initialized
DEBUG - 2022-03-17 14:23:22 --> Encrypt Class Initialized
DEBUG - 2022-03-17 14:23:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:23:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 14:23:22 --> Email Class Initialized
INFO - 2022-03-17 14:23:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 14:23:22 --> Calendar Class Initialized
INFO - 2022-03-17 14:23:22 --> Model "Login_model" initialized
ERROR - 2022-03-17 14:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 14:23:23 --> Config Class Initialized
INFO - 2022-03-17 14:23:23 --> Hooks Class Initialized
DEBUG - 2022-03-17 14:23:23 --> UTF-8 Support Enabled
INFO - 2022-03-17 14:23:23 --> Utf8 Class Initialized
INFO - 2022-03-17 14:23:23 --> URI Class Initialized
INFO - 2022-03-17 14:23:23 --> Router Class Initialized
INFO - 2022-03-17 14:23:23 --> Output Class Initialized
INFO - 2022-03-17 14:23:23 --> Security Class Initialized
DEBUG - 2022-03-17 14:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 14:23:23 --> Input Class Initialized
INFO - 2022-03-17 14:23:23 --> Language Class Initialized
INFO - 2022-03-17 14:23:23 --> Loader Class Initialized
INFO - 2022-03-17 14:23:23 --> Helper loaded: url_helper
INFO - 2022-03-17 14:23:23 --> Helper loaded: form_helper
INFO - 2022-03-17 14:23:23 --> Helper loaded: common_helper
INFO - 2022-03-17 14:23:23 --> Database Driver Class Initialized
DEBUG - 2022-03-17 14:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 14:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 14:23:23 --> Controller Class Initialized
INFO - 2022-03-17 14:23:23 --> Form Validation Class Initialized
DEBUG - 2022-03-17 14:23:23 --> Encrypt Class Initialized
DEBUG - 2022-03-17 14:23:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:23:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 14:23:23 --> Email Class Initialized
INFO - 2022-03-17 14:23:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 14:23:23 --> Calendar Class Initialized
INFO - 2022-03-17 14:23:23 --> Model "Login_model" initialized
ERROR - 2022-03-17 14:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 14:23:23 --> Config Class Initialized
INFO - 2022-03-17 14:23:23 --> Hooks Class Initialized
DEBUG - 2022-03-17 14:23:23 --> UTF-8 Support Enabled
INFO - 2022-03-17 14:23:23 --> Utf8 Class Initialized
INFO - 2022-03-17 14:23:23 --> URI Class Initialized
INFO - 2022-03-17 14:23:23 --> Router Class Initialized
INFO - 2022-03-17 14:23:23 --> Output Class Initialized
INFO - 2022-03-17 14:23:23 --> Security Class Initialized
DEBUG - 2022-03-17 14:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 14:23:23 --> Input Class Initialized
INFO - 2022-03-17 14:23:23 --> Language Class Initialized
INFO - 2022-03-17 14:23:23 --> Loader Class Initialized
INFO - 2022-03-17 14:23:23 --> Helper loaded: url_helper
INFO - 2022-03-17 14:23:23 --> Helper loaded: form_helper
INFO - 2022-03-17 14:23:23 --> Helper loaded: common_helper
INFO - 2022-03-17 14:23:23 --> Database Driver Class Initialized
DEBUG - 2022-03-17 14:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 14:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 14:23:23 --> Controller Class Initialized
INFO - 2022-03-17 14:23:23 --> Form Validation Class Initialized
DEBUG - 2022-03-17 14:23:23 --> Encrypt Class Initialized
DEBUG - 2022-03-17 14:23:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:23:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 14:23:23 --> Email Class Initialized
INFO - 2022-03-17 14:23:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 14:23:23 --> Calendar Class Initialized
INFO - 2022-03-17 14:23:23 --> Model "Login_model" initialized
INFO - 2022-03-17 14:23:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 14:23:23 --> Final output sent to browser
DEBUG - 2022-03-17 14:23:23 --> Total execution time: 0.0404
ERROR - 2022-03-17 14:23:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 14:23:24 --> Config Class Initialized
INFO - 2022-03-17 14:23:24 --> Hooks Class Initialized
DEBUG - 2022-03-17 14:23:24 --> UTF-8 Support Enabled
INFO - 2022-03-17 14:23:24 --> Utf8 Class Initialized
INFO - 2022-03-17 14:23:24 --> URI Class Initialized
DEBUG - 2022-03-17 14:23:24 --> No URI present. Default controller set.
INFO - 2022-03-17 14:23:24 --> Router Class Initialized
INFO - 2022-03-17 14:23:24 --> Output Class Initialized
INFO - 2022-03-17 14:23:24 --> Security Class Initialized
DEBUG - 2022-03-17 14:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 14:23:24 --> Input Class Initialized
INFO - 2022-03-17 14:23:24 --> Language Class Initialized
INFO - 2022-03-17 14:23:24 --> Loader Class Initialized
INFO - 2022-03-17 14:23:24 --> Helper loaded: url_helper
INFO - 2022-03-17 14:23:24 --> Helper loaded: form_helper
INFO - 2022-03-17 14:23:24 --> Helper loaded: common_helper
INFO - 2022-03-17 14:23:24 --> Database Driver Class Initialized
DEBUG - 2022-03-17 14:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 14:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 14:23:24 --> Controller Class Initialized
INFO - 2022-03-17 14:23:24 --> Form Validation Class Initialized
DEBUG - 2022-03-17 14:23:24 --> Encrypt Class Initialized
DEBUG - 2022-03-17 14:23:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:23:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 14:23:24 --> Email Class Initialized
INFO - 2022-03-17 14:23:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 14:23:24 --> Calendar Class Initialized
INFO - 2022-03-17 14:23:24 --> Model "Login_model" initialized
INFO - 2022-03-17 14:23:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 14:23:24 --> Final output sent to browser
DEBUG - 2022-03-17 14:23:24 --> Total execution time: 0.0403
ERROR - 2022-03-17 16:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 16:15:35 --> Config Class Initialized
INFO - 2022-03-17 16:15:35 --> Hooks Class Initialized
DEBUG - 2022-03-17 16:15:35 --> UTF-8 Support Enabled
INFO - 2022-03-17 16:15:35 --> Utf8 Class Initialized
INFO - 2022-03-17 16:15:35 --> URI Class Initialized
DEBUG - 2022-03-17 16:15:35 --> No URI present. Default controller set.
INFO - 2022-03-17 16:15:35 --> Router Class Initialized
INFO - 2022-03-17 16:15:35 --> Output Class Initialized
INFO - 2022-03-17 16:15:35 --> Security Class Initialized
DEBUG - 2022-03-17 16:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 16:15:35 --> Input Class Initialized
INFO - 2022-03-17 16:15:35 --> Language Class Initialized
INFO - 2022-03-17 16:15:35 --> Loader Class Initialized
INFO - 2022-03-17 16:15:35 --> Helper loaded: url_helper
INFO - 2022-03-17 16:15:35 --> Helper loaded: form_helper
INFO - 2022-03-17 16:15:35 --> Helper loaded: common_helper
INFO - 2022-03-17 16:15:35 --> Database Driver Class Initialized
DEBUG - 2022-03-17 16:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 16:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 16:15:35 --> Controller Class Initialized
INFO - 2022-03-17 16:15:35 --> Form Validation Class Initialized
DEBUG - 2022-03-17 16:15:35 --> Encrypt Class Initialized
DEBUG - 2022-03-17 16:15:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 16:15:35 --> Email Class Initialized
INFO - 2022-03-17 16:15:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 16:15:35 --> Calendar Class Initialized
INFO - 2022-03-17 16:15:35 --> Model "Login_model" initialized
INFO - 2022-03-17 16:15:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 16:15:35 --> Final output sent to browser
DEBUG - 2022-03-17 16:15:35 --> Total execution time: 0.0279
ERROR - 2022-03-17 16:59:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 16:59:14 --> Config Class Initialized
INFO - 2022-03-17 16:59:14 --> Hooks Class Initialized
DEBUG - 2022-03-17 16:59:14 --> UTF-8 Support Enabled
INFO - 2022-03-17 16:59:14 --> Utf8 Class Initialized
INFO - 2022-03-17 16:59:14 --> URI Class Initialized
DEBUG - 2022-03-17 16:59:14 --> No URI present. Default controller set.
INFO - 2022-03-17 16:59:14 --> Router Class Initialized
INFO - 2022-03-17 16:59:14 --> Output Class Initialized
INFO - 2022-03-17 16:59:14 --> Security Class Initialized
DEBUG - 2022-03-17 16:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 16:59:14 --> Input Class Initialized
INFO - 2022-03-17 16:59:14 --> Language Class Initialized
INFO - 2022-03-17 16:59:14 --> Loader Class Initialized
INFO - 2022-03-17 16:59:14 --> Helper loaded: url_helper
INFO - 2022-03-17 16:59:14 --> Helper loaded: form_helper
INFO - 2022-03-17 16:59:14 --> Helper loaded: common_helper
INFO - 2022-03-17 16:59:14 --> Database Driver Class Initialized
DEBUG - 2022-03-17 16:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-17 16:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-17 16:59:14 --> Controller Class Initialized
INFO - 2022-03-17 16:59:14 --> Form Validation Class Initialized
DEBUG - 2022-03-17 16:59:14 --> Encrypt Class Initialized
DEBUG - 2022-03-17 16:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:59:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-17 16:59:14 --> Email Class Initialized
INFO - 2022-03-17 16:59:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-17 16:59:14 --> Calendar Class Initialized
INFO - 2022-03-17 16:59:14 --> Model "Login_model" initialized
INFO - 2022-03-17 16:59:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-17 16:59:14 --> Final output sent to browser
DEBUG - 2022-03-17 16:59:14 --> Total execution time: 0.0309
ERROR - 2022-03-17 20:18:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-17 20:18:20 --> Config Class Initialized
INFO - 2022-03-17 20:18:20 --> Hooks Class Initialized
DEBUG - 2022-03-17 20:18:20 --> UTF-8 Support Enabled
INFO - 2022-03-17 20:18:20 --> Utf8 Class Initialized
INFO - 2022-03-17 20:18:20 --> URI Class Initialized
INFO - 2022-03-17 20:18:20 --> Router Class Initialized
INFO - 2022-03-17 20:18:20 --> Output Class Initialized
INFO - 2022-03-17 20:18:20 --> Security Class Initialized
DEBUG - 2022-03-17 20:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-17 20:18:20 --> Input Class Initialized
INFO - 2022-03-17 20:18:20 --> Language Class Initialized
ERROR - 2022-03-17 20:18:20 --> 404 Page Not Found: Wp-content/index
