<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-21 17:36:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-21 17:36:24 --> Config Class Initialized
INFO - 2021-10-21 17:36:24 --> Hooks Class Initialized
DEBUG - 2021-10-21 17:36:24 --> UTF-8 Support Enabled
INFO - 2021-10-21 17:36:24 --> Utf8 Class Initialized
INFO - 2021-10-21 17:36:24 --> URI Class Initialized
DEBUG - 2021-10-21 17:36:24 --> No URI present. Default controller set.
INFO - 2021-10-21 17:36:24 --> Router Class Initialized
INFO - 2021-10-21 17:36:24 --> Output Class Initialized
INFO - 2021-10-21 17:36:24 --> Security Class Initialized
DEBUG - 2021-10-21 17:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-21 17:36:24 --> Input Class Initialized
INFO - 2021-10-21 17:36:24 --> Language Class Initialized
INFO - 2021-10-21 17:36:24 --> Loader Class Initialized
INFO - 2021-10-21 17:36:24 --> Helper loaded: url_helper
INFO - 2021-10-21 17:36:24 --> Helper loaded: form_helper
INFO - 2021-10-21 17:36:24 --> Helper loaded: common_helper
INFO - 2021-10-21 17:36:24 --> Database Driver Class Initialized
DEBUG - 2021-10-21 17:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-21 17:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-21 17:36:24 --> Controller Class Initialized
INFO - 2021-10-21 17:36:24 --> Form Validation Class Initialized
DEBUG - 2021-10-21 17:36:24 --> Encrypt Class Initialized
DEBUG - 2021-10-21 17:36:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-21 17:36:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-21 17:36:24 --> Email Class Initialized
INFO - 2021-10-21 17:36:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-21 17:36:24 --> Calendar Class Initialized
INFO - 2021-10-21 17:36:24 --> Model "Login_model" initialized
INFO - 2021-10-21 17:36:24 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-21 17:36:24 --> Final output sent to browser
DEBUG - 2021-10-21 17:36:24 --> Total execution time: 0.0639
ERROR - 2021-10-21 17:36:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-21 17:36:25 --> Config Class Initialized
INFO - 2021-10-21 17:36:25 --> Hooks Class Initialized
DEBUG - 2021-10-21 17:36:25 --> UTF-8 Support Enabled
INFO - 2021-10-21 17:36:25 --> Utf8 Class Initialized
INFO - 2021-10-21 17:36:25 --> URI Class Initialized
DEBUG - 2021-10-21 17:36:25 --> No URI present. Default controller set.
INFO - 2021-10-21 17:36:25 --> Router Class Initialized
INFO - 2021-10-21 17:36:25 --> Output Class Initialized
INFO - 2021-10-21 17:36:25 --> Security Class Initialized
DEBUG - 2021-10-21 17:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-21 17:36:25 --> Input Class Initialized
INFO - 2021-10-21 17:36:25 --> Language Class Initialized
INFO - 2021-10-21 17:36:25 --> Loader Class Initialized
INFO - 2021-10-21 17:36:25 --> Helper loaded: url_helper
INFO - 2021-10-21 17:36:25 --> Helper loaded: form_helper
INFO - 2021-10-21 17:36:25 --> Helper loaded: common_helper
INFO - 2021-10-21 17:36:25 --> Database Driver Class Initialized
DEBUG - 2021-10-21 17:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-21 17:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-21 17:36:25 --> Controller Class Initialized
INFO - 2021-10-21 17:36:25 --> Form Validation Class Initialized
DEBUG - 2021-10-21 17:36:25 --> Encrypt Class Initialized
DEBUG - 2021-10-21 17:36:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-21 17:36:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-21 17:36:25 --> Email Class Initialized
INFO - 2021-10-21 17:36:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-21 17:36:25 --> Calendar Class Initialized
INFO - 2021-10-21 17:36:25 --> Model "Login_model" initialized
INFO - 2021-10-21 17:36:25 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-21 17:36:25 --> Final output sent to browser
DEBUG - 2021-10-21 17:36:25 --> Total execution time: 0.0296
