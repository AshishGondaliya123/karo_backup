<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-03 00:27:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 00:27:43 --> Config Class Initialized
INFO - 2021-12-03 00:27:43 --> Hooks Class Initialized
DEBUG - 2021-12-03 00:27:43 --> UTF-8 Support Enabled
INFO - 2021-12-03 00:27:43 --> Utf8 Class Initialized
INFO - 2021-12-03 00:27:43 --> URI Class Initialized
DEBUG - 2021-12-03 00:27:43 --> No URI present. Default controller set.
INFO - 2021-12-03 00:27:43 --> Router Class Initialized
INFO - 2021-12-03 00:27:43 --> Output Class Initialized
INFO - 2021-12-03 00:27:43 --> Security Class Initialized
DEBUG - 2021-12-03 00:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 00:27:43 --> Input Class Initialized
INFO - 2021-12-03 00:27:43 --> Language Class Initialized
INFO - 2021-12-03 00:27:43 --> Loader Class Initialized
INFO - 2021-12-03 00:27:43 --> Helper loaded: url_helper
INFO - 2021-12-03 00:27:43 --> Helper loaded: form_helper
INFO - 2021-12-03 00:27:43 --> Helper loaded: common_helper
INFO - 2021-12-03 00:27:43 --> Database Driver Class Initialized
DEBUG - 2021-12-03 00:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 00:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 00:27:43 --> Controller Class Initialized
INFO - 2021-12-03 00:27:43 --> Form Validation Class Initialized
DEBUG - 2021-12-03 00:27:43 --> Encrypt Class Initialized
DEBUG - 2021-12-03 00:27:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 00:27:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 00:27:43 --> Email Class Initialized
INFO - 2021-12-03 00:27:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 00:27:43 --> Calendar Class Initialized
INFO - 2021-12-03 00:27:43 --> Model "Login_model" initialized
INFO - 2021-12-03 00:27:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 00:27:43 --> Final output sent to browser
DEBUG - 2021-12-03 00:27:43 --> Total execution time: 0.0252
ERROR - 2021-12-03 03:01:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 03:01:41 --> Config Class Initialized
INFO - 2021-12-03 03:01:41 --> Hooks Class Initialized
DEBUG - 2021-12-03 03:01:41 --> UTF-8 Support Enabled
INFO - 2021-12-03 03:01:41 --> Utf8 Class Initialized
INFO - 2021-12-03 03:01:41 --> URI Class Initialized
DEBUG - 2021-12-03 03:01:41 --> No URI present. Default controller set.
INFO - 2021-12-03 03:01:41 --> Router Class Initialized
INFO - 2021-12-03 03:01:41 --> Output Class Initialized
INFO - 2021-12-03 03:01:41 --> Security Class Initialized
DEBUG - 2021-12-03 03:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 03:01:41 --> Input Class Initialized
INFO - 2021-12-03 03:01:41 --> Language Class Initialized
INFO - 2021-12-03 03:01:41 --> Loader Class Initialized
INFO - 2021-12-03 03:01:41 --> Helper loaded: url_helper
INFO - 2021-12-03 03:01:41 --> Helper loaded: form_helper
INFO - 2021-12-03 03:01:41 --> Helper loaded: common_helper
INFO - 2021-12-03 03:01:41 --> Database Driver Class Initialized
DEBUG - 2021-12-03 03:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 03:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 03:01:41 --> Controller Class Initialized
INFO - 2021-12-03 03:01:41 --> Form Validation Class Initialized
DEBUG - 2021-12-03 03:01:41 --> Encrypt Class Initialized
DEBUG - 2021-12-03 03:01:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 03:01:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 03:01:41 --> Email Class Initialized
INFO - 2021-12-03 03:01:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 03:01:41 --> Calendar Class Initialized
INFO - 2021-12-03 03:01:41 --> Model "Login_model" initialized
INFO - 2021-12-03 03:01:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 03:01:41 --> Final output sent to browser
DEBUG - 2021-12-03 03:01:41 --> Total execution time: 0.0257
ERROR - 2021-12-03 03:23:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 03:23:14 --> Config Class Initialized
INFO - 2021-12-03 03:23:14 --> Hooks Class Initialized
DEBUG - 2021-12-03 03:23:14 --> UTF-8 Support Enabled
INFO - 2021-12-03 03:23:14 --> Utf8 Class Initialized
INFO - 2021-12-03 03:23:14 --> URI Class Initialized
DEBUG - 2021-12-03 03:23:14 --> No URI present. Default controller set.
INFO - 2021-12-03 03:23:14 --> Router Class Initialized
INFO - 2021-12-03 03:23:14 --> Output Class Initialized
INFO - 2021-12-03 03:23:14 --> Security Class Initialized
DEBUG - 2021-12-03 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 03:23:14 --> Input Class Initialized
INFO - 2021-12-03 03:23:14 --> Language Class Initialized
INFO - 2021-12-03 03:23:14 --> Loader Class Initialized
INFO - 2021-12-03 03:23:14 --> Helper loaded: url_helper
INFO - 2021-12-03 03:23:14 --> Helper loaded: form_helper
INFO - 2021-12-03 03:23:14 --> Helper loaded: common_helper
INFO - 2021-12-03 03:23:14 --> Database Driver Class Initialized
DEBUG - 2021-12-03 03:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 03:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 03:23:14 --> Controller Class Initialized
INFO - 2021-12-03 03:23:14 --> Form Validation Class Initialized
DEBUG - 2021-12-03 03:23:14 --> Encrypt Class Initialized
DEBUG - 2021-12-03 03:23:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 03:23:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 03:23:14 --> Email Class Initialized
INFO - 2021-12-03 03:23:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 03:23:14 --> Calendar Class Initialized
INFO - 2021-12-03 03:23:14 --> Model "Login_model" initialized
INFO - 2021-12-03 03:23:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 03:23:14 --> Final output sent to browser
DEBUG - 2021-12-03 03:23:14 --> Total execution time: 0.0227
ERROR - 2021-12-03 07:56:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 07:56:42 --> Config Class Initialized
INFO - 2021-12-03 07:56:42 --> Hooks Class Initialized
DEBUG - 2021-12-03 07:56:42 --> UTF-8 Support Enabled
INFO - 2021-12-03 07:56:42 --> Utf8 Class Initialized
INFO - 2021-12-03 07:56:42 --> URI Class Initialized
DEBUG - 2021-12-03 07:56:42 --> No URI present. Default controller set.
INFO - 2021-12-03 07:56:42 --> Router Class Initialized
INFO - 2021-12-03 07:56:42 --> Output Class Initialized
INFO - 2021-12-03 07:56:42 --> Security Class Initialized
DEBUG - 2021-12-03 07:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 07:56:42 --> Input Class Initialized
INFO - 2021-12-03 07:56:42 --> Language Class Initialized
INFO - 2021-12-03 07:56:42 --> Loader Class Initialized
INFO - 2021-12-03 07:56:42 --> Helper loaded: url_helper
INFO - 2021-12-03 07:56:42 --> Helper loaded: form_helper
INFO - 2021-12-03 07:56:42 --> Helper loaded: common_helper
INFO - 2021-12-03 07:56:42 --> Database Driver Class Initialized
DEBUG - 2021-12-03 07:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 07:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 07:56:42 --> Controller Class Initialized
INFO - 2021-12-03 07:56:42 --> Form Validation Class Initialized
DEBUG - 2021-12-03 07:56:42 --> Encrypt Class Initialized
DEBUG - 2021-12-03 07:56:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 07:56:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 07:56:42 --> Email Class Initialized
INFO - 2021-12-03 07:56:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 07:56:42 --> Calendar Class Initialized
INFO - 2021-12-03 07:56:42 --> Model "Login_model" initialized
INFO - 2021-12-03 07:56:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 07:56:42 --> Final output sent to browser
DEBUG - 2021-12-03 07:56:42 --> Total execution time: 0.0275
ERROR - 2021-12-03 09:23:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 09:23:12 --> Config Class Initialized
INFO - 2021-12-03 09:23:12 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:23:12 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:23:12 --> Utf8 Class Initialized
INFO - 2021-12-03 09:23:12 --> URI Class Initialized
DEBUG - 2021-12-03 09:23:12 --> No URI present. Default controller set.
INFO - 2021-12-03 09:23:12 --> Router Class Initialized
INFO - 2021-12-03 09:23:12 --> Output Class Initialized
INFO - 2021-12-03 09:23:12 --> Security Class Initialized
DEBUG - 2021-12-03 09:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:23:12 --> Input Class Initialized
INFO - 2021-12-03 09:23:12 --> Language Class Initialized
INFO - 2021-12-03 09:23:12 --> Loader Class Initialized
INFO - 2021-12-03 09:23:12 --> Helper loaded: url_helper
INFO - 2021-12-03 09:23:12 --> Helper loaded: form_helper
INFO - 2021-12-03 09:23:12 --> Helper loaded: common_helper
INFO - 2021-12-03 09:23:12 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:23:12 --> Controller Class Initialized
INFO - 2021-12-03 09:23:12 --> Form Validation Class Initialized
DEBUG - 2021-12-03 09:23:12 --> Encrypt Class Initialized
DEBUG - 2021-12-03 09:23:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 09:23:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 09:23:12 --> Email Class Initialized
INFO - 2021-12-03 09:23:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 09:23:12 --> Calendar Class Initialized
INFO - 2021-12-03 09:23:12 --> Model "Login_model" initialized
INFO - 2021-12-03 09:23:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 09:23:12 --> Final output sent to browser
DEBUG - 2021-12-03 09:23:12 --> Total execution time: 0.0280
ERROR - 2021-12-03 09:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 09:31:08 --> Config Class Initialized
INFO - 2021-12-03 09:31:08 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:31:08 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:31:08 --> Utf8 Class Initialized
INFO - 2021-12-03 09:31:08 --> URI Class Initialized
DEBUG - 2021-12-03 09:31:08 --> No URI present. Default controller set.
INFO - 2021-12-03 09:31:08 --> Router Class Initialized
INFO - 2021-12-03 09:31:08 --> Output Class Initialized
INFO - 2021-12-03 09:31:08 --> Security Class Initialized
DEBUG - 2021-12-03 09:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:31:08 --> Input Class Initialized
INFO - 2021-12-03 09:31:08 --> Language Class Initialized
INFO - 2021-12-03 09:31:08 --> Loader Class Initialized
INFO - 2021-12-03 09:31:08 --> Helper loaded: url_helper
INFO - 2021-12-03 09:31:08 --> Helper loaded: form_helper
INFO - 2021-12-03 09:31:08 --> Helper loaded: common_helper
INFO - 2021-12-03 09:31:08 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:31:08 --> Controller Class Initialized
INFO - 2021-12-03 09:31:08 --> Form Validation Class Initialized
DEBUG - 2021-12-03 09:31:08 --> Encrypt Class Initialized
DEBUG - 2021-12-03 09:31:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 09:31:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 09:31:08 --> Email Class Initialized
INFO - 2021-12-03 09:31:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 09:31:08 --> Calendar Class Initialized
INFO - 2021-12-03 09:31:08 --> Model "Login_model" initialized
INFO - 2021-12-03 09:31:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 09:31:08 --> Final output sent to browser
DEBUG - 2021-12-03 09:31:08 --> Total execution time: 0.0364
ERROR - 2021-12-03 09:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 09:40:41 --> Config Class Initialized
INFO - 2021-12-03 09:40:41 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:40:41 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:40:41 --> Utf8 Class Initialized
INFO - 2021-12-03 09:40:41 --> URI Class Initialized
DEBUG - 2021-12-03 09:40:41 --> No URI present. Default controller set.
INFO - 2021-12-03 09:40:41 --> Router Class Initialized
INFO - 2021-12-03 09:40:41 --> Output Class Initialized
INFO - 2021-12-03 09:40:41 --> Security Class Initialized
DEBUG - 2021-12-03 09:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:40:41 --> Input Class Initialized
INFO - 2021-12-03 09:40:41 --> Language Class Initialized
INFO - 2021-12-03 09:40:41 --> Loader Class Initialized
INFO - 2021-12-03 09:40:41 --> Helper loaded: url_helper
INFO - 2021-12-03 09:40:41 --> Helper loaded: form_helper
INFO - 2021-12-03 09:40:41 --> Helper loaded: common_helper
INFO - 2021-12-03 09:40:41 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:40:41 --> Controller Class Initialized
INFO - 2021-12-03 09:40:41 --> Form Validation Class Initialized
DEBUG - 2021-12-03 09:40:41 --> Encrypt Class Initialized
DEBUG - 2021-12-03 09:40:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 09:40:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 09:40:41 --> Email Class Initialized
INFO - 2021-12-03 09:40:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 09:40:41 --> Calendar Class Initialized
INFO - 2021-12-03 09:40:41 --> Model "Login_model" initialized
INFO - 2021-12-03 09:40:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 09:40:41 --> Final output sent to browser
DEBUG - 2021-12-03 09:40:41 --> Total execution time: 0.0370
ERROR - 2021-12-03 09:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 09:40:44 --> Config Class Initialized
INFO - 2021-12-03 09:40:44 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:40:44 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:40:44 --> Utf8 Class Initialized
INFO - 2021-12-03 09:40:44 --> URI Class Initialized
DEBUG - 2021-12-03 09:40:44 --> No URI present. Default controller set.
INFO - 2021-12-03 09:40:44 --> Router Class Initialized
INFO - 2021-12-03 09:40:44 --> Output Class Initialized
INFO - 2021-12-03 09:40:44 --> Security Class Initialized
DEBUG - 2021-12-03 09:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:40:44 --> Input Class Initialized
INFO - 2021-12-03 09:40:44 --> Language Class Initialized
INFO - 2021-12-03 09:40:44 --> Loader Class Initialized
INFO - 2021-12-03 09:40:44 --> Helper loaded: url_helper
INFO - 2021-12-03 09:40:44 --> Helper loaded: form_helper
INFO - 2021-12-03 09:40:44 --> Helper loaded: common_helper
INFO - 2021-12-03 09:40:44 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:40:44 --> Controller Class Initialized
INFO - 2021-12-03 09:40:44 --> Form Validation Class Initialized
DEBUG - 2021-12-03 09:40:44 --> Encrypt Class Initialized
DEBUG - 2021-12-03 09:40:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 09:40:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 09:40:44 --> Email Class Initialized
INFO - 2021-12-03 09:40:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 09:40:44 --> Calendar Class Initialized
INFO - 2021-12-03 09:40:44 --> Model "Login_model" initialized
INFO - 2021-12-03 09:40:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 09:40:44 --> Final output sent to browser
DEBUG - 2021-12-03 09:40:44 --> Total execution time: 0.0259
ERROR - 2021-12-03 10:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 10:12:38 --> Config Class Initialized
INFO - 2021-12-03 10:12:38 --> Hooks Class Initialized
DEBUG - 2021-12-03 10:12:38 --> UTF-8 Support Enabled
INFO - 2021-12-03 10:12:38 --> Utf8 Class Initialized
INFO - 2021-12-03 10:12:38 --> URI Class Initialized
DEBUG - 2021-12-03 10:12:38 --> No URI present. Default controller set.
INFO - 2021-12-03 10:12:38 --> Router Class Initialized
INFO - 2021-12-03 10:12:38 --> Output Class Initialized
INFO - 2021-12-03 10:12:38 --> Security Class Initialized
DEBUG - 2021-12-03 10:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 10:12:38 --> Input Class Initialized
INFO - 2021-12-03 10:12:38 --> Language Class Initialized
INFO - 2021-12-03 10:12:38 --> Loader Class Initialized
INFO - 2021-12-03 10:12:38 --> Helper loaded: url_helper
INFO - 2021-12-03 10:12:38 --> Helper loaded: form_helper
INFO - 2021-12-03 10:12:38 --> Helper loaded: common_helper
INFO - 2021-12-03 10:12:38 --> Database Driver Class Initialized
DEBUG - 2021-12-03 10:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 10:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 10:12:38 --> Controller Class Initialized
INFO - 2021-12-03 10:12:38 --> Form Validation Class Initialized
DEBUG - 2021-12-03 10:12:38 --> Encrypt Class Initialized
DEBUG - 2021-12-03 10:12:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 10:12:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 10:12:38 --> Email Class Initialized
INFO - 2021-12-03 10:12:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 10:12:38 --> Calendar Class Initialized
INFO - 2021-12-03 10:12:38 --> Model "Login_model" initialized
INFO - 2021-12-03 10:12:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 10:12:38 --> Final output sent to browser
DEBUG - 2021-12-03 10:12:38 --> Total execution time: 0.0238
ERROR - 2021-12-03 10:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 10:13:46 --> Config Class Initialized
INFO - 2021-12-03 10:13:46 --> Hooks Class Initialized
DEBUG - 2021-12-03 10:13:46 --> UTF-8 Support Enabled
INFO - 2021-12-03 10:13:46 --> Utf8 Class Initialized
INFO - 2021-12-03 10:13:46 --> URI Class Initialized
DEBUG - 2021-12-03 10:13:46 --> No URI present. Default controller set.
INFO - 2021-12-03 10:13:46 --> Router Class Initialized
INFO - 2021-12-03 10:13:46 --> Output Class Initialized
INFO - 2021-12-03 10:13:46 --> Security Class Initialized
DEBUG - 2021-12-03 10:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 10:13:46 --> Input Class Initialized
INFO - 2021-12-03 10:13:46 --> Language Class Initialized
INFO - 2021-12-03 10:13:46 --> Loader Class Initialized
INFO - 2021-12-03 10:13:46 --> Helper loaded: url_helper
INFO - 2021-12-03 10:13:46 --> Helper loaded: form_helper
INFO - 2021-12-03 10:13:46 --> Helper loaded: common_helper
INFO - 2021-12-03 10:13:46 --> Database Driver Class Initialized
DEBUG - 2021-12-03 10:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 10:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 10:13:46 --> Controller Class Initialized
INFO - 2021-12-03 10:13:46 --> Form Validation Class Initialized
DEBUG - 2021-12-03 10:13:46 --> Encrypt Class Initialized
DEBUG - 2021-12-03 10:13:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 10:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 10:13:46 --> Email Class Initialized
INFO - 2021-12-03 10:13:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 10:13:46 --> Calendar Class Initialized
INFO - 2021-12-03 10:13:46 --> Model "Login_model" initialized
INFO - 2021-12-03 10:13:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 10:13:46 --> Final output sent to browser
DEBUG - 2021-12-03 10:13:46 --> Total execution time: 0.0222
ERROR - 2021-12-03 11:22:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 11:22:59 --> Config Class Initialized
INFO - 2021-12-03 11:22:59 --> Hooks Class Initialized
DEBUG - 2021-12-03 11:22:59 --> UTF-8 Support Enabled
INFO - 2021-12-03 11:22:59 --> Utf8 Class Initialized
INFO - 2021-12-03 11:22:59 --> URI Class Initialized
DEBUG - 2021-12-03 11:22:59 --> No URI present. Default controller set.
INFO - 2021-12-03 11:22:59 --> Router Class Initialized
INFO - 2021-12-03 11:22:59 --> Output Class Initialized
INFO - 2021-12-03 11:22:59 --> Security Class Initialized
DEBUG - 2021-12-03 11:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 11:22:59 --> Input Class Initialized
INFO - 2021-12-03 11:22:59 --> Language Class Initialized
INFO - 2021-12-03 11:22:59 --> Loader Class Initialized
INFO - 2021-12-03 11:22:59 --> Helper loaded: url_helper
INFO - 2021-12-03 11:22:59 --> Helper loaded: form_helper
INFO - 2021-12-03 11:22:59 --> Helper loaded: common_helper
INFO - 2021-12-03 11:22:59 --> Database Driver Class Initialized
DEBUG - 2021-12-03 11:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 11:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 11:22:59 --> Controller Class Initialized
INFO - 2021-12-03 11:22:59 --> Form Validation Class Initialized
DEBUG - 2021-12-03 11:22:59 --> Encrypt Class Initialized
DEBUG - 2021-12-03 11:22:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 11:22:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 11:22:59 --> Email Class Initialized
INFO - 2021-12-03 11:22:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 11:22:59 --> Calendar Class Initialized
INFO - 2021-12-03 11:22:59 --> Model "Login_model" initialized
INFO - 2021-12-03 11:22:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 11:22:59 --> Final output sent to browser
DEBUG - 2021-12-03 11:22:59 --> Total execution time: 0.0345
ERROR - 2021-12-03 11:23:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 11:23:03 --> Config Class Initialized
INFO - 2021-12-03 11:23:03 --> Hooks Class Initialized
DEBUG - 2021-12-03 11:23:03 --> UTF-8 Support Enabled
INFO - 2021-12-03 11:23:03 --> Utf8 Class Initialized
INFO - 2021-12-03 11:23:03 --> URI Class Initialized
DEBUG - 2021-12-03 11:23:03 --> No URI present. Default controller set.
INFO - 2021-12-03 11:23:03 --> Router Class Initialized
INFO - 2021-12-03 11:23:03 --> Output Class Initialized
INFO - 2021-12-03 11:23:03 --> Security Class Initialized
DEBUG - 2021-12-03 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 11:23:03 --> Input Class Initialized
INFO - 2021-12-03 11:23:03 --> Language Class Initialized
INFO - 2021-12-03 11:23:03 --> Loader Class Initialized
INFO - 2021-12-03 11:23:03 --> Helper loaded: url_helper
INFO - 2021-12-03 11:23:03 --> Helper loaded: form_helper
INFO - 2021-12-03 11:23:03 --> Helper loaded: common_helper
INFO - 2021-12-03 11:23:03 --> Database Driver Class Initialized
DEBUG - 2021-12-03 11:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 11:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 11:23:03 --> Controller Class Initialized
INFO - 2021-12-03 11:23:03 --> Form Validation Class Initialized
DEBUG - 2021-12-03 11:23:03 --> Encrypt Class Initialized
DEBUG - 2021-12-03 11:23:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 11:23:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 11:23:03 --> Email Class Initialized
INFO - 2021-12-03 11:23:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 11:23:03 --> Calendar Class Initialized
INFO - 2021-12-03 11:23:03 --> Model "Login_model" initialized
INFO - 2021-12-03 11:23:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 11:23:03 --> Final output sent to browser
DEBUG - 2021-12-03 11:23:03 --> Total execution time: 0.0244
ERROR - 2021-12-03 12:13:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:41 --> Config Class Initialized
INFO - 2021-12-03 12:13:41 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:41 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:41 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:41 --> URI Class Initialized
DEBUG - 2021-12-03 12:13:41 --> No URI present. Default controller set.
INFO - 2021-12-03 12:13:41 --> Router Class Initialized
INFO - 2021-12-03 12:13:41 --> Output Class Initialized
INFO - 2021-12-03 12:13:41 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:41 --> Input Class Initialized
INFO - 2021-12-03 12:13:41 --> Language Class Initialized
INFO - 2021-12-03 12:13:41 --> Loader Class Initialized
INFO - 2021-12-03 12:13:41 --> Helper loaded: url_helper
INFO - 2021-12-03 12:13:41 --> Helper loaded: form_helper
INFO - 2021-12-03 12:13:41 --> Helper loaded: common_helper
INFO - 2021-12-03 12:13:41 --> Database Driver Class Initialized
DEBUG - 2021-12-03 12:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 12:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 12:13:41 --> Controller Class Initialized
INFO - 2021-12-03 12:13:41 --> Form Validation Class Initialized
DEBUG - 2021-12-03 12:13:41 --> Encrypt Class Initialized
DEBUG - 2021-12-03 12:13:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 12:13:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 12:13:41 --> Email Class Initialized
INFO - 2021-12-03 12:13:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 12:13:41 --> Calendar Class Initialized
INFO - 2021-12-03 12:13:41 --> Model "Login_model" initialized
INFO - 2021-12-03 12:13:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 12:13:41 --> Final output sent to browser
DEBUG - 2021-12-03 12:13:41 --> Total execution time: 0.0235
ERROR - 2021-12-03 12:13:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:42 --> Config Class Initialized
INFO - 2021-12-03 12:13:42 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:42 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:42 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:42 --> URI Class Initialized
DEBUG - 2021-12-03 12:13:42 --> No URI present. Default controller set.
INFO - 2021-12-03 12:13:42 --> Router Class Initialized
INFO - 2021-12-03 12:13:42 --> Output Class Initialized
INFO - 2021-12-03 12:13:42 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:42 --> Input Class Initialized
INFO - 2021-12-03 12:13:42 --> Language Class Initialized
INFO - 2021-12-03 12:13:42 --> Loader Class Initialized
INFO - 2021-12-03 12:13:42 --> Helper loaded: url_helper
INFO - 2021-12-03 12:13:42 --> Helper loaded: form_helper
INFO - 2021-12-03 12:13:42 --> Helper loaded: common_helper
INFO - 2021-12-03 12:13:42 --> Database Driver Class Initialized
DEBUG - 2021-12-03 12:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 12:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 12:13:42 --> Controller Class Initialized
INFO - 2021-12-03 12:13:42 --> Form Validation Class Initialized
DEBUG - 2021-12-03 12:13:42 --> Encrypt Class Initialized
DEBUG - 2021-12-03 12:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 12:13:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 12:13:42 --> Email Class Initialized
INFO - 2021-12-03 12:13:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 12:13:42 --> Calendar Class Initialized
INFO - 2021-12-03 12:13:42 --> Model "Login_model" initialized
INFO - 2021-12-03 12:13:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 12:13:42 --> Final output sent to browser
DEBUG - 2021-12-03 12:13:42 --> Total execution time: 0.0221
ERROR - 2021-12-03 12:13:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:42 --> Config Class Initialized
INFO - 2021-12-03 12:13:42 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:42 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:42 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:42 --> URI Class Initialized
INFO - 2021-12-03 12:13:42 --> Router Class Initialized
INFO - 2021-12-03 12:13:42 --> Output Class Initialized
INFO - 2021-12-03 12:13:42 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:42 --> Input Class Initialized
INFO - 2021-12-03 12:13:42 --> Language Class Initialized
ERROR - 2021-12-03 12:13:42 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-03 12:13:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:43 --> Config Class Initialized
INFO - 2021-12-03 12:13:43 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:43 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:43 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:43 --> URI Class Initialized
DEBUG - 2021-12-03 12:13:43 --> No URI present. Default controller set.
INFO - 2021-12-03 12:13:43 --> Router Class Initialized
INFO - 2021-12-03 12:13:43 --> Output Class Initialized
INFO - 2021-12-03 12:13:43 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:43 --> Input Class Initialized
INFO - 2021-12-03 12:13:43 --> Language Class Initialized
INFO - 2021-12-03 12:13:43 --> Loader Class Initialized
INFO - 2021-12-03 12:13:43 --> Helper loaded: url_helper
INFO - 2021-12-03 12:13:43 --> Helper loaded: form_helper
INFO - 2021-12-03 12:13:43 --> Helper loaded: common_helper
INFO - 2021-12-03 12:13:43 --> Database Driver Class Initialized
DEBUG - 2021-12-03 12:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 12:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 12:13:43 --> Controller Class Initialized
INFO - 2021-12-03 12:13:43 --> Form Validation Class Initialized
DEBUG - 2021-12-03 12:13:43 --> Encrypt Class Initialized
DEBUG - 2021-12-03 12:13:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 12:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 12:13:43 --> Email Class Initialized
INFO - 2021-12-03 12:13:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 12:13:43 --> Calendar Class Initialized
INFO - 2021-12-03 12:13:43 --> Model "Login_model" initialized
INFO - 2021-12-03 12:13:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 12:13:43 --> Final output sent to browser
DEBUG - 2021-12-03 12:13:43 --> Total execution time: 0.0224
ERROR - 2021-12-03 12:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:44 --> Config Class Initialized
INFO - 2021-12-03 12:13:44 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:44 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:44 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:44 --> URI Class Initialized
INFO - 2021-12-03 12:13:44 --> Router Class Initialized
INFO - 2021-12-03 12:13:44 --> Output Class Initialized
INFO - 2021-12-03 12:13:44 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:44 --> Input Class Initialized
INFO - 2021-12-03 12:13:44 --> Language Class Initialized
ERROR - 2021-12-03 12:13:44 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-03 12:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:44 --> Config Class Initialized
INFO - 2021-12-03 12:13:44 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:44 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:44 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:44 --> URI Class Initialized
INFO - 2021-12-03 12:13:44 --> Router Class Initialized
INFO - 2021-12-03 12:13:44 --> Output Class Initialized
INFO - 2021-12-03 12:13:44 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:44 --> Input Class Initialized
INFO - 2021-12-03 12:13:44 --> Language Class Initialized
ERROR - 2021-12-03 12:13:44 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-03 12:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:44 --> Config Class Initialized
INFO - 2021-12-03 12:13:44 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:44 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:44 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:44 --> URI Class Initialized
INFO - 2021-12-03 12:13:44 --> Router Class Initialized
INFO - 2021-12-03 12:13:44 --> Output Class Initialized
INFO - 2021-12-03 12:13:44 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:44 --> Input Class Initialized
INFO - 2021-12-03 12:13:44 --> Language Class Initialized
ERROR - 2021-12-03 12:13:44 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-03 12:13:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:45 --> Config Class Initialized
INFO - 2021-12-03 12:13:45 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:45 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:45 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:45 --> URI Class Initialized
INFO - 2021-12-03 12:13:45 --> Router Class Initialized
INFO - 2021-12-03 12:13:45 --> Output Class Initialized
INFO - 2021-12-03 12:13:45 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:45 --> Input Class Initialized
INFO - 2021-12-03 12:13:45 --> Language Class Initialized
ERROR - 2021-12-03 12:13:45 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-03 12:13:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:45 --> Config Class Initialized
INFO - 2021-12-03 12:13:45 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:45 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:45 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:45 --> URI Class Initialized
INFO - 2021-12-03 12:13:45 --> Router Class Initialized
INFO - 2021-12-03 12:13:45 --> Output Class Initialized
INFO - 2021-12-03 12:13:45 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:45 --> Input Class Initialized
INFO - 2021-12-03 12:13:45 --> Language Class Initialized
ERROR - 2021-12-03 12:13:45 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-03 12:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:46 --> Config Class Initialized
INFO - 2021-12-03 12:13:46 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:46 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:46 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:46 --> URI Class Initialized
INFO - 2021-12-03 12:13:46 --> Router Class Initialized
INFO - 2021-12-03 12:13:46 --> Output Class Initialized
INFO - 2021-12-03 12:13:46 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:46 --> Input Class Initialized
INFO - 2021-12-03 12:13:46 --> Language Class Initialized
ERROR - 2021-12-03 12:13:46 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-03 12:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:46 --> Config Class Initialized
INFO - 2021-12-03 12:13:46 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:46 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:46 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:46 --> URI Class Initialized
INFO - 2021-12-03 12:13:46 --> Router Class Initialized
INFO - 2021-12-03 12:13:46 --> Output Class Initialized
INFO - 2021-12-03 12:13:46 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:46 --> Input Class Initialized
INFO - 2021-12-03 12:13:46 --> Language Class Initialized
ERROR - 2021-12-03 12:13:46 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-12-03 12:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:46 --> Config Class Initialized
INFO - 2021-12-03 12:13:46 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:46 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:46 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:46 --> URI Class Initialized
INFO - 2021-12-03 12:13:46 --> Router Class Initialized
INFO - 2021-12-03 12:13:46 --> Output Class Initialized
INFO - 2021-12-03 12:13:46 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:46 --> Input Class Initialized
INFO - 2021-12-03 12:13:46 --> Language Class Initialized
ERROR - 2021-12-03 12:13:46 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-03 12:13:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:47 --> Config Class Initialized
INFO - 2021-12-03 12:13:47 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:47 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:47 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:47 --> URI Class Initialized
INFO - 2021-12-03 12:13:47 --> Router Class Initialized
INFO - 2021-12-03 12:13:47 --> Output Class Initialized
INFO - 2021-12-03 12:13:47 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:47 --> Input Class Initialized
INFO - 2021-12-03 12:13:47 --> Language Class Initialized
ERROR - 2021-12-03 12:13:47 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-03 12:13:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:47 --> Config Class Initialized
INFO - 2021-12-03 12:13:47 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:47 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:47 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:47 --> URI Class Initialized
INFO - 2021-12-03 12:13:47 --> Router Class Initialized
INFO - 2021-12-03 12:13:47 --> Output Class Initialized
INFO - 2021-12-03 12:13:47 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:47 --> Input Class Initialized
INFO - 2021-12-03 12:13:47 --> Language Class Initialized
ERROR - 2021-12-03 12:13:47 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-03 12:13:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:48 --> Config Class Initialized
INFO - 2021-12-03 12:13:48 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:48 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:48 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:48 --> URI Class Initialized
INFO - 2021-12-03 12:13:48 --> Router Class Initialized
INFO - 2021-12-03 12:13:48 --> Output Class Initialized
INFO - 2021-12-03 12:13:48 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:48 --> Input Class Initialized
INFO - 2021-12-03 12:13:48 --> Language Class Initialized
ERROR - 2021-12-03 12:13:48 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-03 12:13:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:48 --> Config Class Initialized
INFO - 2021-12-03 12:13:48 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:48 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:48 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:48 --> URI Class Initialized
INFO - 2021-12-03 12:13:48 --> Router Class Initialized
INFO - 2021-12-03 12:13:48 --> Output Class Initialized
INFO - 2021-12-03 12:13:48 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:48 --> Input Class Initialized
INFO - 2021-12-03 12:13:48 --> Language Class Initialized
ERROR - 2021-12-03 12:13:48 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-12-03 12:13:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:49 --> Config Class Initialized
INFO - 2021-12-03 12:13:49 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:49 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:49 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:49 --> URI Class Initialized
INFO - 2021-12-03 12:13:49 --> Router Class Initialized
INFO - 2021-12-03 12:13:49 --> Output Class Initialized
INFO - 2021-12-03 12:13:49 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:49 --> Input Class Initialized
INFO - 2021-12-03 12:13:49 --> Language Class Initialized
ERROR - 2021-12-03 12:13:49 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-03 12:13:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:49 --> Config Class Initialized
INFO - 2021-12-03 12:13:49 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:49 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:49 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:49 --> URI Class Initialized
INFO - 2021-12-03 12:13:49 --> Router Class Initialized
INFO - 2021-12-03 12:13:49 --> Output Class Initialized
INFO - 2021-12-03 12:13:49 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:49 --> Input Class Initialized
INFO - 2021-12-03 12:13:49 --> Language Class Initialized
ERROR - 2021-12-03 12:13:49 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-03 12:13:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:50 --> Config Class Initialized
INFO - 2021-12-03 12:13:50 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:50 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:50 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:50 --> URI Class Initialized
INFO - 2021-12-03 12:13:50 --> Router Class Initialized
INFO - 2021-12-03 12:13:50 --> Output Class Initialized
INFO - 2021-12-03 12:13:50 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:50 --> Input Class Initialized
INFO - 2021-12-03 12:13:50 --> Language Class Initialized
ERROR - 2021-12-03 12:13:50 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-03 12:13:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:13:50 --> Config Class Initialized
INFO - 2021-12-03 12:13:50 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:13:50 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:13:50 --> Utf8 Class Initialized
INFO - 2021-12-03 12:13:50 --> URI Class Initialized
INFO - 2021-12-03 12:13:50 --> Router Class Initialized
INFO - 2021-12-03 12:13:50 --> Output Class Initialized
INFO - 2021-12-03 12:13:50 --> Security Class Initialized
DEBUG - 2021-12-03 12:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:13:50 --> Input Class Initialized
INFO - 2021-12-03 12:13:50 --> Language Class Initialized
ERROR - 2021-12-03 12:13:50 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-03 12:16:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:04 --> Config Class Initialized
INFO - 2021-12-03 12:16:04 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:04 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:04 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:04 --> URI Class Initialized
DEBUG - 2021-12-03 12:16:04 --> No URI present. Default controller set.
INFO - 2021-12-03 12:16:04 --> Router Class Initialized
INFO - 2021-12-03 12:16:04 --> Output Class Initialized
INFO - 2021-12-03 12:16:04 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:04 --> Input Class Initialized
INFO - 2021-12-03 12:16:04 --> Language Class Initialized
INFO - 2021-12-03 12:16:04 --> Loader Class Initialized
INFO - 2021-12-03 12:16:04 --> Helper loaded: url_helper
INFO - 2021-12-03 12:16:04 --> Helper loaded: form_helper
INFO - 2021-12-03 12:16:04 --> Helper loaded: common_helper
INFO - 2021-12-03 12:16:04 --> Database Driver Class Initialized
DEBUG - 2021-12-03 12:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 12:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 12:16:04 --> Controller Class Initialized
INFO - 2021-12-03 12:16:04 --> Form Validation Class Initialized
DEBUG - 2021-12-03 12:16:04 --> Encrypt Class Initialized
DEBUG - 2021-12-03 12:16:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 12:16:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 12:16:04 --> Email Class Initialized
INFO - 2021-12-03 12:16:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 12:16:04 --> Calendar Class Initialized
INFO - 2021-12-03 12:16:04 --> Model "Login_model" initialized
INFO - 2021-12-03 12:16:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 12:16:04 --> Final output sent to browser
DEBUG - 2021-12-03 12:16:04 --> Total execution time: 0.0242
ERROR - 2021-12-03 12:16:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:04 --> Config Class Initialized
INFO - 2021-12-03 12:16:04 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:04 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:04 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:04 --> URI Class Initialized
DEBUG - 2021-12-03 12:16:04 --> No URI present. Default controller set.
INFO - 2021-12-03 12:16:04 --> Router Class Initialized
INFO - 2021-12-03 12:16:04 --> Output Class Initialized
INFO - 2021-12-03 12:16:04 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:04 --> Input Class Initialized
INFO - 2021-12-03 12:16:04 --> Language Class Initialized
INFO - 2021-12-03 12:16:04 --> Loader Class Initialized
INFO - 2021-12-03 12:16:04 --> Helper loaded: url_helper
INFO - 2021-12-03 12:16:04 --> Helper loaded: form_helper
INFO - 2021-12-03 12:16:04 --> Helper loaded: common_helper
INFO - 2021-12-03 12:16:04 --> Database Driver Class Initialized
DEBUG - 2021-12-03 12:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 12:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 12:16:04 --> Controller Class Initialized
INFO - 2021-12-03 12:16:04 --> Form Validation Class Initialized
DEBUG - 2021-12-03 12:16:04 --> Encrypt Class Initialized
DEBUG - 2021-12-03 12:16:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 12:16:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 12:16:04 --> Email Class Initialized
INFO - 2021-12-03 12:16:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 12:16:04 --> Calendar Class Initialized
INFO - 2021-12-03 12:16:04 --> Model "Login_model" initialized
INFO - 2021-12-03 12:16:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 12:16:04 --> Final output sent to browser
DEBUG - 2021-12-03 12:16:04 --> Total execution time: 0.0256
ERROR - 2021-12-03 12:16:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:05 --> Config Class Initialized
INFO - 2021-12-03 12:16:05 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:05 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:05 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:05 --> URI Class Initialized
INFO - 2021-12-03 12:16:05 --> Router Class Initialized
INFO - 2021-12-03 12:16:05 --> Output Class Initialized
INFO - 2021-12-03 12:16:05 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:05 --> Input Class Initialized
INFO - 2021-12-03 12:16:05 --> Language Class Initialized
ERROR - 2021-12-03 12:16:05 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-03 12:16:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:06 --> Config Class Initialized
INFO - 2021-12-03 12:16:06 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:06 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:06 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:06 --> URI Class Initialized
DEBUG - 2021-12-03 12:16:06 --> No URI present. Default controller set.
INFO - 2021-12-03 12:16:06 --> Router Class Initialized
INFO - 2021-12-03 12:16:06 --> Output Class Initialized
INFO - 2021-12-03 12:16:06 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:06 --> Input Class Initialized
INFO - 2021-12-03 12:16:06 --> Language Class Initialized
INFO - 2021-12-03 12:16:06 --> Loader Class Initialized
INFO - 2021-12-03 12:16:06 --> Helper loaded: url_helper
INFO - 2021-12-03 12:16:06 --> Helper loaded: form_helper
INFO - 2021-12-03 12:16:06 --> Helper loaded: common_helper
INFO - 2021-12-03 12:16:06 --> Database Driver Class Initialized
DEBUG - 2021-12-03 12:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 12:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 12:16:06 --> Controller Class Initialized
INFO - 2021-12-03 12:16:06 --> Form Validation Class Initialized
DEBUG - 2021-12-03 12:16:06 --> Encrypt Class Initialized
DEBUG - 2021-12-03 12:16:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 12:16:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 12:16:06 --> Email Class Initialized
INFO - 2021-12-03 12:16:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 12:16:06 --> Calendar Class Initialized
INFO - 2021-12-03 12:16:06 --> Model "Login_model" initialized
INFO - 2021-12-03 12:16:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 12:16:06 --> Final output sent to browser
DEBUG - 2021-12-03 12:16:06 --> Total execution time: 0.0303
ERROR - 2021-12-03 12:16:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:06 --> Config Class Initialized
INFO - 2021-12-03 12:16:06 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:06 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:06 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:06 --> URI Class Initialized
INFO - 2021-12-03 12:16:06 --> Router Class Initialized
INFO - 2021-12-03 12:16:06 --> Output Class Initialized
INFO - 2021-12-03 12:16:06 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:06 --> Input Class Initialized
INFO - 2021-12-03 12:16:06 --> Language Class Initialized
ERROR - 2021-12-03 12:16:06 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-03 12:16:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:07 --> Config Class Initialized
INFO - 2021-12-03 12:16:07 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:07 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:07 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:07 --> URI Class Initialized
INFO - 2021-12-03 12:16:07 --> Router Class Initialized
INFO - 2021-12-03 12:16:07 --> Output Class Initialized
INFO - 2021-12-03 12:16:07 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:07 --> Input Class Initialized
INFO - 2021-12-03 12:16:07 --> Language Class Initialized
ERROR - 2021-12-03 12:16:07 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-03 12:16:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:08 --> Config Class Initialized
INFO - 2021-12-03 12:16:08 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:08 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:08 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:08 --> URI Class Initialized
INFO - 2021-12-03 12:16:08 --> Router Class Initialized
INFO - 2021-12-03 12:16:08 --> Output Class Initialized
INFO - 2021-12-03 12:16:08 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:08 --> Input Class Initialized
INFO - 2021-12-03 12:16:08 --> Language Class Initialized
ERROR - 2021-12-03 12:16:08 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-03 12:16:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:08 --> Config Class Initialized
INFO - 2021-12-03 12:16:08 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:08 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:08 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:08 --> URI Class Initialized
INFO - 2021-12-03 12:16:08 --> Router Class Initialized
INFO - 2021-12-03 12:16:08 --> Output Class Initialized
INFO - 2021-12-03 12:16:08 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:08 --> Input Class Initialized
INFO - 2021-12-03 12:16:08 --> Language Class Initialized
ERROR - 2021-12-03 12:16:08 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-03 12:16:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:09 --> Config Class Initialized
INFO - 2021-12-03 12:16:09 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:09 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:09 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:09 --> URI Class Initialized
INFO - 2021-12-03 12:16:09 --> Router Class Initialized
INFO - 2021-12-03 12:16:09 --> Output Class Initialized
INFO - 2021-12-03 12:16:09 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:09 --> Input Class Initialized
INFO - 2021-12-03 12:16:09 --> Language Class Initialized
ERROR - 2021-12-03 12:16:09 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-03 12:16:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:09 --> Config Class Initialized
INFO - 2021-12-03 12:16:09 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:09 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:09 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:09 --> URI Class Initialized
INFO - 2021-12-03 12:16:09 --> Router Class Initialized
INFO - 2021-12-03 12:16:09 --> Output Class Initialized
INFO - 2021-12-03 12:16:09 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:09 --> Input Class Initialized
INFO - 2021-12-03 12:16:09 --> Language Class Initialized
ERROR - 2021-12-03 12:16:09 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-03 12:16:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:10 --> Config Class Initialized
INFO - 2021-12-03 12:16:10 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:10 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:10 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:10 --> URI Class Initialized
INFO - 2021-12-03 12:16:10 --> Router Class Initialized
INFO - 2021-12-03 12:16:10 --> Output Class Initialized
INFO - 2021-12-03 12:16:10 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:10 --> Input Class Initialized
INFO - 2021-12-03 12:16:10 --> Language Class Initialized
ERROR - 2021-12-03 12:16:10 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-12-03 12:16:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:10 --> Config Class Initialized
INFO - 2021-12-03 12:16:10 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:10 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:10 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:10 --> URI Class Initialized
INFO - 2021-12-03 12:16:10 --> Router Class Initialized
INFO - 2021-12-03 12:16:10 --> Output Class Initialized
INFO - 2021-12-03 12:16:10 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:10 --> Input Class Initialized
INFO - 2021-12-03 12:16:10 --> Language Class Initialized
ERROR - 2021-12-03 12:16:10 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-03 12:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:11 --> Config Class Initialized
INFO - 2021-12-03 12:16:11 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:11 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:11 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:11 --> URI Class Initialized
INFO - 2021-12-03 12:16:11 --> Router Class Initialized
INFO - 2021-12-03 12:16:11 --> Output Class Initialized
INFO - 2021-12-03 12:16:11 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:11 --> Input Class Initialized
INFO - 2021-12-03 12:16:11 --> Language Class Initialized
ERROR - 2021-12-03 12:16:11 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-03 12:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:11 --> Config Class Initialized
INFO - 2021-12-03 12:16:11 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:11 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:11 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:11 --> URI Class Initialized
INFO - 2021-12-03 12:16:11 --> Router Class Initialized
INFO - 2021-12-03 12:16:11 --> Output Class Initialized
INFO - 2021-12-03 12:16:11 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:11 --> Input Class Initialized
INFO - 2021-12-03 12:16:11 --> Language Class Initialized
ERROR - 2021-12-03 12:16:11 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-03 12:16:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:12 --> Config Class Initialized
INFO - 2021-12-03 12:16:12 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:12 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:12 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:12 --> URI Class Initialized
INFO - 2021-12-03 12:16:12 --> Router Class Initialized
INFO - 2021-12-03 12:16:12 --> Output Class Initialized
INFO - 2021-12-03 12:16:12 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:12 --> Input Class Initialized
INFO - 2021-12-03 12:16:12 --> Language Class Initialized
ERROR - 2021-12-03 12:16:12 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-03 12:16:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:12 --> Config Class Initialized
INFO - 2021-12-03 12:16:12 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:12 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:12 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:12 --> URI Class Initialized
INFO - 2021-12-03 12:16:12 --> Router Class Initialized
INFO - 2021-12-03 12:16:12 --> Output Class Initialized
INFO - 2021-12-03 12:16:12 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:12 --> Input Class Initialized
INFO - 2021-12-03 12:16:12 --> Language Class Initialized
ERROR - 2021-12-03 12:16:12 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-12-03 12:16:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:13 --> Config Class Initialized
INFO - 2021-12-03 12:16:13 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:13 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:13 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:13 --> URI Class Initialized
INFO - 2021-12-03 12:16:13 --> Router Class Initialized
INFO - 2021-12-03 12:16:13 --> Output Class Initialized
INFO - 2021-12-03 12:16:13 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:13 --> Input Class Initialized
INFO - 2021-12-03 12:16:13 --> Language Class Initialized
ERROR - 2021-12-03 12:16:13 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-03 12:16:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:13 --> Config Class Initialized
INFO - 2021-12-03 12:16:13 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:13 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:13 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:13 --> URI Class Initialized
INFO - 2021-12-03 12:16:13 --> Router Class Initialized
INFO - 2021-12-03 12:16:13 --> Output Class Initialized
INFO - 2021-12-03 12:16:13 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:13 --> Input Class Initialized
INFO - 2021-12-03 12:16:13 --> Language Class Initialized
ERROR - 2021-12-03 12:16:13 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-03 12:16:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:14 --> Config Class Initialized
INFO - 2021-12-03 12:16:14 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:14 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:14 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:14 --> URI Class Initialized
INFO - 2021-12-03 12:16:14 --> Router Class Initialized
INFO - 2021-12-03 12:16:14 --> Output Class Initialized
INFO - 2021-12-03 12:16:14 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:14 --> Input Class Initialized
INFO - 2021-12-03 12:16:14 --> Language Class Initialized
ERROR - 2021-12-03 12:16:14 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-03 12:16:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:16:14 --> Config Class Initialized
INFO - 2021-12-03 12:16:14 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:16:14 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:16:14 --> Utf8 Class Initialized
INFO - 2021-12-03 12:16:14 --> URI Class Initialized
INFO - 2021-12-03 12:16:14 --> Router Class Initialized
INFO - 2021-12-03 12:16:14 --> Output Class Initialized
INFO - 2021-12-03 12:16:14 --> Security Class Initialized
DEBUG - 2021-12-03 12:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:16:14 --> Input Class Initialized
INFO - 2021-12-03 12:16:14 --> Language Class Initialized
ERROR - 2021-12-03 12:16:14 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-03 12:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 12:31:31 --> Config Class Initialized
INFO - 2021-12-03 12:31:31 --> Hooks Class Initialized
DEBUG - 2021-12-03 12:31:31 --> UTF-8 Support Enabled
INFO - 2021-12-03 12:31:31 --> Utf8 Class Initialized
INFO - 2021-12-03 12:31:31 --> URI Class Initialized
DEBUG - 2021-12-03 12:31:31 --> No URI present. Default controller set.
INFO - 2021-12-03 12:31:31 --> Router Class Initialized
INFO - 2021-12-03 12:31:31 --> Output Class Initialized
INFO - 2021-12-03 12:31:31 --> Security Class Initialized
DEBUG - 2021-12-03 12:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 12:31:31 --> Input Class Initialized
INFO - 2021-12-03 12:31:31 --> Language Class Initialized
INFO - 2021-12-03 12:31:31 --> Loader Class Initialized
INFO - 2021-12-03 12:31:31 --> Helper loaded: url_helper
INFO - 2021-12-03 12:31:31 --> Helper loaded: form_helper
INFO - 2021-12-03 12:31:31 --> Helper loaded: common_helper
INFO - 2021-12-03 12:31:31 --> Database Driver Class Initialized
DEBUG - 2021-12-03 12:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 12:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 12:31:31 --> Controller Class Initialized
INFO - 2021-12-03 12:31:31 --> Form Validation Class Initialized
DEBUG - 2021-12-03 12:31:31 --> Encrypt Class Initialized
DEBUG - 2021-12-03 12:31:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 12:31:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 12:31:31 --> Email Class Initialized
INFO - 2021-12-03 12:31:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 12:31:31 --> Calendar Class Initialized
INFO - 2021-12-03 12:31:31 --> Model "Login_model" initialized
INFO - 2021-12-03 12:31:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 12:31:31 --> Final output sent to browser
DEBUG - 2021-12-03 12:31:31 --> Total execution time: 0.0345
ERROR - 2021-12-03 13:01:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:01:32 --> Config Class Initialized
INFO - 2021-12-03 13:01:32 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:01:32 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:01:32 --> Utf8 Class Initialized
INFO - 2021-12-03 13:01:32 --> URI Class Initialized
INFO - 2021-12-03 13:01:32 --> Router Class Initialized
INFO - 2021-12-03 13:01:32 --> Output Class Initialized
INFO - 2021-12-03 13:01:32 --> Security Class Initialized
DEBUG - 2021-12-03 13:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:01:32 --> Input Class Initialized
INFO - 2021-12-03 13:01:32 --> Language Class Initialized
ERROR - 2021-12-03 13:01:32 --> 404 Page Not Found: Dup-installer/main.installer.php
ERROR - 2021-12-03 13:01:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:01:32 --> Config Class Initialized
INFO - 2021-12-03 13:01:32 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:01:32 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:01:32 --> Utf8 Class Initialized
INFO - 2021-12-03 13:01:32 --> URI Class Initialized
INFO - 2021-12-03 13:01:32 --> Router Class Initialized
INFO - 2021-12-03 13:01:32 --> Output Class Initialized
INFO - 2021-12-03 13:01:32 --> Security Class Initialized
DEBUG - 2021-12-03 13:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:01:32 --> Input Class Initialized
INFO - 2021-12-03 13:01:32 --> Language Class Initialized
ERROR - 2021-12-03 13:01:32 --> 404 Page Not Found: Dup-installer/main.installer.php
ERROR - 2021-12-03 13:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:31 --> Config Class Initialized
INFO - 2021-12-03 13:10:31 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:31 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:31 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:31 --> URI Class Initialized
DEBUG - 2021-12-03 13:10:31 --> No URI present. Default controller set.
INFO - 2021-12-03 13:10:31 --> Router Class Initialized
INFO - 2021-12-03 13:10:31 --> Output Class Initialized
INFO - 2021-12-03 13:10:31 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:31 --> Input Class Initialized
INFO - 2021-12-03 13:10:31 --> Language Class Initialized
INFO - 2021-12-03 13:10:31 --> Loader Class Initialized
INFO - 2021-12-03 13:10:31 --> Helper loaded: url_helper
INFO - 2021-12-03 13:10:31 --> Helper loaded: form_helper
INFO - 2021-12-03 13:10:31 --> Helper loaded: common_helper
INFO - 2021-12-03 13:10:31 --> Database Driver Class Initialized
DEBUG - 2021-12-03 13:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 13:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 13:10:31 --> Controller Class Initialized
INFO - 2021-12-03 13:10:31 --> Form Validation Class Initialized
DEBUG - 2021-12-03 13:10:31 --> Encrypt Class Initialized
DEBUG - 2021-12-03 13:10:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 13:10:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 13:10:31 --> Email Class Initialized
INFO - 2021-12-03 13:10:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 13:10:31 --> Calendar Class Initialized
INFO - 2021-12-03 13:10:31 --> Model "Login_model" initialized
INFO - 2021-12-03 13:10:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 13:10:31 --> Final output sent to browser
DEBUG - 2021-12-03 13:10:31 --> Total execution time: 0.0236
ERROR - 2021-12-03 13:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:31 --> Config Class Initialized
INFO - 2021-12-03 13:10:31 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:31 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:31 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:31 --> URI Class Initialized
DEBUG - 2021-12-03 13:10:31 --> No URI present. Default controller set.
INFO - 2021-12-03 13:10:31 --> Router Class Initialized
INFO - 2021-12-03 13:10:31 --> Output Class Initialized
INFO - 2021-12-03 13:10:31 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:31 --> Input Class Initialized
INFO - 2021-12-03 13:10:31 --> Language Class Initialized
INFO - 2021-12-03 13:10:31 --> Loader Class Initialized
INFO - 2021-12-03 13:10:31 --> Helper loaded: url_helper
INFO - 2021-12-03 13:10:31 --> Helper loaded: form_helper
INFO - 2021-12-03 13:10:31 --> Helper loaded: common_helper
INFO - 2021-12-03 13:10:31 --> Database Driver Class Initialized
DEBUG - 2021-12-03 13:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 13:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 13:10:31 --> Controller Class Initialized
INFO - 2021-12-03 13:10:31 --> Form Validation Class Initialized
DEBUG - 2021-12-03 13:10:31 --> Encrypt Class Initialized
DEBUG - 2021-12-03 13:10:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 13:10:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 13:10:31 --> Email Class Initialized
INFO - 2021-12-03 13:10:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 13:10:31 --> Calendar Class Initialized
INFO - 2021-12-03 13:10:31 --> Model "Login_model" initialized
INFO - 2021-12-03 13:10:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 13:10:31 --> Final output sent to browser
DEBUG - 2021-12-03 13:10:31 --> Total execution time: 0.0224
ERROR - 2021-12-03 13:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:32 --> Config Class Initialized
INFO - 2021-12-03 13:10:32 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:32 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:32 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:32 --> URI Class Initialized
INFO - 2021-12-03 13:10:32 --> Router Class Initialized
INFO - 2021-12-03 13:10:32 --> Output Class Initialized
INFO - 2021-12-03 13:10:32 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:32 --> Input Class Initialized
INFO - 2021-12-03 13:10:32 --> Language Class Initialized
ERROR - 2021-12-03 13:10:32 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-03 13:10:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:33 --> Config Class Initialized
INFO - 2021-12-03 13:10:33 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:33 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:33 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:33 --> URI Class Initialized
DEBUG - 2021-12-03 13:10:33 --> No URI present. Default controller set.
INFO - 2021-12-03 13:10:33 --> Router Class Initialized
INFO - 2021-12-03 13:10:33 --> Output Class Initialized
INFO - 2021-12-03 13:10:33 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:33 --> Input Class Initialized
INFO - 2021-12-03 13:10:33 --> Language Class Initialized
INFO - 2021-12-03 13:10:33 --> Loader Class Initialized
INFO - 2021-12-03 13:10:33 --> Helper loaded: url_helper
INFO - 2021-12-03 13:10:33 --> Helper loaded: form_helper
INFO - 2021-12-03 13:10:33 --> Helper loaded: common_helper
INFO - 2021-12-03 13:10:33 --> Database Driver Class Initialized
DEBUG - 2021-12-03 13:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 13:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 13:10:33 --> Controller Class Initialized
INFO - 2021-12-03 13:10:33 --> Form Validation Class Initialized
DEBUG - 2021-12-03 13:10:33 --> Encrypt Class Initialized
DEBUG - 2021-12-03 13:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 13:10:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 13:10:33 --> Email Class Initialized
INFO - 2021-12-03 13:10:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 13:10:33 --> Calendar Class Initialized
INFO - 2021-12-03 13:10:33 --> Model "Login_model" initialized
INFO - 2021-12-03 13:10:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 13:10:33 --> Final output sent to browser
DEBUG - 2021-12-03 13:10:33 --> Total execution time: 0.0215
ERROR - 2021-12-03 13:10:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:33 --> Config Class Initialized
INFO - 2021-12-03 13:10:33 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:33 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:33 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:33 --> URI Class Initialized
INFO - 2021-12-03 13:10:33 --> Router Class Initialized
INFO - 2021-12-03 13:10:33 --> Output Class Initialized
INFO - 2021-12-03 13:10:33 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:33 --> Input Class Initialized
INFO - 2021-12-03 13:10:33 --> Language Class Initialized
ERROR - 2021-12-03 13:10:33 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-03 13:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:34 --> Config Class Initialized
INFO - 2021-12-03 13:10:34 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:34 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:34 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:34 --> URI Class Initialized
INFO - 2021-12-03 13:10:34 --> Router Class Initialized
INFO - 2021-12-03 13:10:34 --> Output Class Initialized
INFO - 2021-12-03 13:10:34 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:34 --> Input Class Initialized
INFO - 2021-12-03 13:10:34 --> Language Class Initialized
ERROR - 2021-12-03 13:10:34 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-03 13:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:34 --> Config Class Initialized
INFO - 2021-12-03 13:10:34 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:34 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:34 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:34 --> URI Class Initialized
INFO - 2021-12-03 13:10:34 --> Router Class Initialized
INFO - 2021-12-03 13:10:34 --> Output Class Initialized
INFO - 2021-12-03 13:10:34 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:34 --> Input Class Initialized
INFO - 2021-12-03 13:10:34 --> Language Class Initialized
ERROR - 2021-12-03 13:10:34 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-03 13:10:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:35 --> Config Class Initialized
INFO - 2021-12-03 13:10:35 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:35 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:35 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:35 --> URI Class Initialized
INFO - 2021-12-03 13:10:35 --> Router Class Initialized
INFO - 2021-12-03 13:10:35 --> Output Class Initialized
INFO - 2021-12-03 13:10:35 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:35 --> Input Class Initialized
INFO - 2021-12-03 13:10:35 --> Language Class Initialized
ERROR - 2021-12-03 13:10:35 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-03 13:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:36 --> Config Class Initialized
INFO - 2021-12-03 13:10:36 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:36 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:36 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:36 --> URI Class Initialized
INFO - 2021-12-03 13:10:36 --> Router Class Initialized
INFO - 2021-12-03 13:10:36 --> Output Class Initialized
INFO - 2021-12-03 13:10:36 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:36 --> Input Class Initialized
INFO - 2021-12-03 13:10:36 --> Language Class Initialized
ERROR - 2021-12-03 13:10:36 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-03 13:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:36 --> Config Class Initialized
INFO - 2021-12-03 13:10:36 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:36 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:36 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:36 --> URI Class Initialized
INFO - 2021-12-03 13:10:36 --> Router Class Initialized
INFO - 2021-12-03 13:10:36 --> Output Class Initialized
INFO - 2021-12-03 13:10:36 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:36 --> Input Class Initialized
INFO - 2021-12-03 13:10:36 --> Language Class Initialized
ERROR - 2021-12-03 13:10:36 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-03 13:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:37 --> Config Class Initialized
INFO - 2021-12-03 13:10:37 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:37 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:37 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:37 --> URI Class Initialized
INFO - 2021-12-03 13:10:37 --> Router Class Initialized
INFO - 2021-12-03 13:10:37 --> Output Class Initialized
INFO - 2021-12-03 13:10:37 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:37 --> Input Class Initialized
INFO - 2021-12-03 13:10:37 --> Language Class Initialized
ERROR - 2021-12-03 13:10:37 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-12-03 13:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:37 --> Config Class Initialized
INFO - 2021-12-03 13:10:37 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:37 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:37 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:37 --> URI Class Initialized
INFO - 2021-12-03 13:10:37 --> Router Class Initialized
INFO - 2021-12-03 13:10:37 --> Output Class Initialized
INFO - 2021-12-03 13:10:37 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:37 --> Input Class Initialized
INFO - 2021-12-03 13:10:37 --> Language Class Initialized
ERROR - 2021-12-03 13:10:37 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-03 13:10:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:38 --> Config Class Initialized
INFO - 2021-12-03 13:10:38 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:38 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:38 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:38 --> URI Class Initialized
INFO - 2021-12-03 13:10:38 --> Router Class Initialized
INFO - 2021-12-03 13:10:38 --> Output Class Initialized
INFO - 2021-12-03 13:10:38 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:38 --> Input Class Initialized
INFO - 2021-12-03 13:10:38 --> Language Class Initialized
ERROR - 2021-12-03 13:10:38 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-03 13:10:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:38 --> Config Class Initialized
INFO - 2021-12-03 13:10:38 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:38 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:38 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:38 --> URI Class Initialized
INFO - 2021-12-03 13:10:38 --> Router Class Initialized
INFO - 2021-12-03 13:10:38 --> Output Class Initialized
INFO - 2021-12-03 13:10:38 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:38 --> Input Class Initialized
INFO - 2021-12-03 13:10:38 --> Language Class Initialized
ERROR - 2021-12-03 13:10:38 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-03 13:10:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:39 --> Config Class Initialized
INFO - 2021-12-03 13:10:39 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:39 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:39 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:39 --> URI Class Initialized
INFO - 2021-12-03 13:10:39 --> Router Class Initialized
INFO - 2021-12-03 13:10:39 --> Output Class Initialized
INFO - 2021-12-03 13:10:39 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:39 --> Input Class Initialized
INFO - 2021-12-03 13:10:39 --> Language Class Initialized
ERROR - 2021-12-03 13:10:39 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-03 13:10:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:39 --> Config Class Initialized
INFO - 2021-12-03 13:10:39 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:39 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:39 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:39 --> URI Class Initialized
INFO - 2021-12-03 13:10:39 --> Router Class Initialized
INFO - 2021-12-03 13:10:39 --> Output Class Initialized
INFO - 2021-12-03 13:10:39 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:39 --> Input Class Initialized
INFO - 2021-12-03 13:10:39 --> Language Class Initialized
ERROR - 2021-12-03 13:10:39 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-03 13:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:40 --> Config Class Initialized
INFO - 2021-12-03 13:10:40 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:40 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:40 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:40 --> URI Class Initialized
INFO - 2021-12-03 13:10:40 --> Router Class Initialized
INFO - 2021-12-03 13:10:40 --> Output Class Initialized
INFO - 2021-12-03 13:10:40 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:40 --> Input Class Initialized
INFO - 2021-12-03 13:10:40 --> Language Class Initialized
ERROR - 2021-12-03 13:10:40 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-03 13:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:40 --> Config Class Initialized
INFO - 2021-12-03 13:10:40 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:40 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:40 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:40 --> URI Class Initialized
INFO - 2021-12-03 13:10:40 --> Router Class Initialized
INFO - 2021-12-03 13:10:40 --> Output Class Initialized
INFO - 2021-12-03 13:10:40 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:40 --> Input Class Initialized
INFO - 2021-12-03 13:10:40 --> Language Class Initialized
ERROR - 2021-12-03 13:10:40 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-03 13:10:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 13:10:41 --> Config Class Initialized
INFO - 2021-12-03 13:10:41 --> Hooks Class Initialized
DEBUG - 2021-12-03 13:10:41 --> UTF-8 Support Enabled
INFO - 2021-12-03 13:10:41 --> Utf8 Class Initialized
INFO - 2021-12-03 13:10:41 --> URI Class Initialized
INFO - 2021-12-03 13:10:41 --> Router Class Initialized
INFO - 2021-12-03 13:10:41 --> Output Class Initialized
INFO - 2021-12-03 13:10:41 --> Security Class Initialized
DEBUG - 2021-12-03 13:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 13:10:41 --> Input Class Initialized
INFO - 2021-12-03 13:10:41 --> Language Class Initialized
ERROR - 2021-12-03 13:10:41 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-03 14:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 14:18:06 --> Config Class Initialized
INFO - 2021-12-03 14:18:06 --> Hooks Class Initialized
DEBUG - 2021-12-03 14:18:06 --> UTF-8 Support Enabled
INFO - 2021-12-03 14:18:06 --> Utf8 Class Initialized
INFO - 2021-12-03 14:18:06 --> URI Class Initialized
DEBUG - 2021-12-03 14:18:06 --> No URI present. Default controller set.
INFO - 2021-12-03 14:18:06 --> Router Class Initialized
INFO - 2021-12-03 14:18:06 --> Output Class Initialized
INFO - 2021-12-03 14:18:06 --> Security Class Initialized
DEBUG - 2021-12-03 14:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 14:18:06 --> Input Class Initialized
INFO - 2021-12-03 14:18:06 --> Language Class Initialized
INFO - 2021-12-03 14:18:06 --> Loader Class Initialized
INFO - 2021-12-03 14:18:06 --> Helper loaded: url_helper
INFO - 2021-12-03 14:18:06 --> Helper loaded: form_helper
INFO - 2021-12-03 14:18:06 --> Helper loaded: common_helper
INFO - 2021-12-03 14:18:06 --> Database Driver Class Initialized
DEBUG - 2021-12-03 14:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 14:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 14:18:06 --> Controller Class Initialized
INFO - 2021-12-03 14:18:06 --> Form Validation Class Initialized
DEBUG - 2021-12-03 14:18:06 --> Encrypt Class Initialized
DEBUG - 2021-12-03 14:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 14:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 14:18:06 --> Email Class Initialized
INFO - 2021-12-03 14:18:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 14:18:06 --> Calendar Class Initialized
INFO - 2021-12-03 14:18:06 --> Model "Login_model" initialized
INFO - 2021-12-03 14:18:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 14:18:06 --> Final output sent to browser
DEBUG - 2021-12-03 14:18:06 --> Total execution time: 0.0273
ERROR - 2021-12-03 14:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 14:18:07 --> Config Class Initialized
INFO - 2021-12-03 14:18:07 --> Hooks Class Initialized
DEBUG - 2021-12-03 14:18:07 --> UTF-8 Support Enabled
INFO - 2021-12-03 14:18:07 --> Utf8 Class Initialized
INFO - 2021-12-03 14:18:07 --> URI Class Initialized
INFO - 2021-12-03 14:18:07 --> Router Class Initialized
INFO - 2021-12-03 14:18:07 --> Output Class Initialized
INFO - 2021-12-03 14:18:07 --> Security Class Initialized
DEBUG - 2021-12-03 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 14:18:07 --> Input Class Initialized
INFO - 2021-12-03 14:18:07 --> Language Class Initialized
ERROR - 2021-12-03 14:18:07 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-03 14:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 14:18:27 --> Config Class Initialized
INFO - 2021-12-03 14:18:27 --> Hooks Class Initialized
DEBUG - 2021-12-03 14:18:27 --> UTF-8 Support Enabled
INFO - 2021-12-03 14:18:27 --> Utf8 Class Initialized
INFO - 2021-12-03 14:18:27 --> URI Class Initialized
DEBUG - 2021-12-03 14:18:27 --> No URI present. Default controller set.
INFO - 2021-12-03 14:18:27 --> Router Class Initialized
INFO - 2021-12-03 14:18:27 --> Output Class Initialized
INFO - 2021-12-03 14:18:27 --> Security Class Initialized
DEBUG - 2021-12-03 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 14:18:27 --> Input Class Initialized
INFO - 2021-12-03 14:18:27 --> Language Class Initialized
INFO - 2021-12-03 14:18:27 --> Loader Class Initialized
INFO - 2021-12-03 14:18:27 --> Helper loaded: url_helper
INFO - 2021-12-03 14:18:27 --> Helper loaded: form_helper
INFO - 2021-12-03 14:18:27 --> Helper loaded: common_helper
INFO - 2021-12-03 14:18:27 --> Database Driver Class Initialized
DEBUG - 2021-12-03 14:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 14:18:27 --> Controller Class Initialized
INFO - 2021-12-03 14:18:27 --> Form Validation Class Initialized
DEBUG - 2021-12-03 14:18:27 --> Encrypt Class Initialized
DEBUG - 2021-12-03 14:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 14:18:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 14:18:27 --> Email Class Initialized
INFO - 2021-12-03 14:18:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 14:18:27 --> Calendar Class Initialized
INFO - 2021-12-03 14:18:27 --> Model "Login_model" initialized
INFO - 2021-12-03 14:18:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 14:18:27 --> Final output sent to browser
DEBUG - 2021-12-03 14:18:27 --> Total execution time: 0.0204
ERROR - 2021-12-03 14:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 14:18:27 --> Config Class Initialized
INFO - 2021-12-03 14:18:27 --> Hooks Class Initialized
DEBUG - 2021-12-03 14:18:27 --> UTF-8 Support Enabled
INFO - 2021-12-03 14:18:27 --> Utf8 Class Initialized
INFO - 2021-12-03 14:18:27 --> URI Class Initialized
INFO - 2021-12-03 14:18:27 --> Router Class Initialized
INFO - 2021-12-03 14:18:27 --> Output Class Initialized
INFO - 2021-12-03 14:18:27 --> Security Class Initialized
DEBUG - 2021-12-03 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 14:18:27 --> Input Class Initialized
INFO - 2021-12-03 14:18:27 --> Language Class Initialized
INFO - 2021-12-03 14:18:27 --> Loader Class Initialized
INFO - 2021-12-03 14:18:27 --> Helper loaded: url_helper
INFO - 2021-12-03 14:18:27 --> Helper loaded: form_helper
INFO - 2021-12-03 14:18:27 --> Helper loaded: common_helper
INFO - 2021-12-03 14:18:27 --> Database Driver Class Initialized
DEBUG - 2021-12-03 14:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 14:18:27 --> Controller Class Initialized
INFO - 2021-12-03 14:18:27 --> Form Validation Class Initialized
DEBUG - 2021-12-03 14:18:27 --> Encrypt Class Initialized
DEBUG - 2021-12-03 14:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 14:18:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 14:18:27 --> Email Class Initialized
INFO - 2021-12-03 14:18:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 14:18:27 --> Calendar Class Initialized
INFO - 2021-12-03 14:18:27 --> Model "Login_model" initialized
INFO - 2021-12-03 14:18:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 14:18:27 --> Final output sent to browser
DEBUG - 2021-12-03 14:18:27 --> Total execution time: 0.0222
ERROR - 2021-12-03 14:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 14:18:28 --> Config Class Initialized
INFO - 2021-12-03 14:18:28 --> Hooks Class Initialized
DEBUG - 2021-12-03 14:18:28 --> UTF-8 Support Enabled
INFO - 2021-12-03 14:18:28 --> Utf8 Class Initialized
INFO - 2021-12-03 14:18:28 --> URI Class Initialized
INFO - 2021-12-03 14:18:28 --> Router Class Initialized
INFO - 2021-12-03 14:18:28 --> Output Class Initialized
INFO - 2021-12-03 14:18:28 --> Security Class Initialized
DEBUG - 2021-12-03 14:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 14:18:28 --> Input Class Initialized
INFO - 2021-12-03 14:18:28 --> Language Class Initialized
INFO - 2021-12-03 14:18:28 --> Loader Class Initialized
INFO - 2021-12-03 14:18:28 --> Helper loaded: url_helper
INFO - 2021-12-03 14:18:28 --> Helper loaded: form_helper
INFO - 2021-12-03 14:18:28 --> Helper loaded: common_helper
INFO - 2021-12-03 14:18:28 --> Database Driver Class Initialized
DEBUG - 2021-12-03 14:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 14:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 14:18:28 --> Controller Class Initialized
INFO - 2021-12-03 14:18:28 --> Form Validation Class Initialized
DEBUG - 2021-12-03 14:18:28 --> Encrypt Class Initialized
DEBUG - 2021-12-03 14:18:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 14:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 14:18:28 --> Email Class Initialized
INFO - 2021-12-03 14:18:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 14:18:28 --> Calendar Class Initialized
INFO - 2021-12-03 14:18:28 --> Model "Login_model" initialized
ERROR - 2021-12-03 14:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 14:18:28 --> Config Class Initialized
INFO - 2021-12-03 14:18:28 --> Hooks Class Initialized
DEBUG - 2021-12-03 14:18:28 --> UTF-8 Support Enabled
INFO - 2021-12-03 14:18:28 --> Utf8 Class Initialized
INFO - 2021-12-03 14:18:28 --> URI Class Initialized
INFO - 2021-12-03 14:18:28 --> Router Class Initialized
INFO - 2021-12-03 14:18:28 --> Output Class Initialized
INFO - 2021-12-03 14:18:28 --> Security Class Initialized
DEBUG - 2021-12-03 14:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 14:18:28 --> Input Class Initialized
INFO - 2021-12-03 14:18:28 --> Language Class Initialized
INFO - 2021-12-03 14:18:28 --> Loader Class Initialized
INFO - 2021-12-03 14:18:28 --> Helper loaded: url_helper
INFO - 2021-12-03 14:18:28 --> Helper loaded: form_helper
INFO - 2021-12-03 14:18:28 --> Helper loaded: common_helper
INFO - 2021-12-03 14:18:28 --> Database Driver Class Initialized
DEBUG - 2021-12-03 14:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 14:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 14:18:28 --> Controller Class Initialized
INFO - 2021-12-03 14:18:28 --> Form Validation Class Initialized
DEBUG - 2021-12-03 14:18:28 --> Encrypt Class Initialized
DEBUG - 2021-12-03 14:18:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 14:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 14:18:28 --> Email Class Initialized
INFO - 2021-12-03 14:18:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 14:18:28 --> Calendar Class Initialized
INFO - 2021-12-03 14:18:28 --> Model "Login_model" initialized
ERROR - 2021-12-03 19:32:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 19:32:15 --> Config Class Initialized
INFO - 2021-12-03 19:32:15 --> Hooks Class Initialized
DEBUG - 2021-12-03 19:32:15 --> UTF-8 Support Enabled
INFO - 2021-12-03 19:32:15 --> Utf8 Class Initialized
INFO - 2021-12-03 19:32:15 --> URI Class Initialized
DEBUG - 2021-12-03 19:32:15 --> No URI present. Default controller set.
INFO - 2021-12-03 19:32:15 --> Router Class Initialized
INFO - 2021-12-03 19:32:15 --> Output Class Initialized
INFO - 2021-12-03 19:32:15 --> Security Class Initialized
DEBUG - 2021-12-03 19:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 19:32:15 --> Input Class Initialized
INFO - 2021-12-03 19:32:15 --> Language Class Initialized
INFO - 2021-12-03 19:32:15 --> Loader Class Initialized
INFO - 2021-12-03 19:32:15 --> Helper loaded: url_helper
INFO - 2021-12-03 19:32:15 --> Helper loaded: form_helper
INFO - 2021-12-03 19:32:15 --> Helper loaded: common_helper
INFO - 2021-12-03 19:32:15 --> Database Driver Class Initialized
DEBUG - 2021-12-03 19:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 19:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 19:32:15 --> Controller Class Initialized
INFO - 2021-12-03 19:32:15 --> Form Validation Class Initialized
DEBUG - 2021-12-03 19:32:15 --> Encrypt Class Initialized
DEBUG - 2021-12-03 19:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 19:32:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 19:32:15 --> Email Class Initialized
INFO - 2021-12-03 19:32:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 19:32:15 --> Calendar Class Initialized
INFO - 2021-12-03 19:32:15 --> Model "Login_model" initialized
INFO - 2021-12-03 19:32:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 19:32:15 --> Final output sent to browser
DEBUG - 2021-12-03 19:32:15 --> Total execution time: 0.7602
ERROR - 2021-12-03 19:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 19:54:45 --> Config Class Initialized
INFO - 2021-12-03 19:54:45 --> Hooks Class Initialized
DEBUG - 2021-12-03 19:54:45 --> UTF-8 Support Enabled
INFO - 2021-12-03 19:54:45 --> Utf8 Class Initialized
INFO - 2021-12-03 19:54:45 --> URI Class Initialized
DEBUG - 2021-12-03 19:54:45 --> No URI present. Default controller set.
INFO - 2021-12-03 19:54:45 --> Router Class Initialized
INFO - 2021-12-03 19:54:45 --> Output Class Initialized
INFO - 2021-12-03 19:54:45 --> Security Class Initialized
DEBUG - 2021-12-03 19:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 19:54:45 --> Input Class Initialized
INFO - 2021-12-03 19:54:45 --> Language Class Initialized
INFO - 2021-12-03 19:54:45 --> Loader Class Initialized
INFO - 2021-12-03 19:54:45 --> Helper loaded: url_helper
INFO - 2021-12-03 19:54:45 --> Helper loaded: form_helper
INFO - 2021-12-03 19:54:45 --> Helper loaded: common_helper
INFO - 2021-12-03 19:54:45 --> Database Driver Class Initialized
DEBUG - 2021-12-03 19:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 19:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 19:54:45 --> Controller Class Initialized
INFO - 2021-12-03 19:54:45 --> Form Validation Class Initialized
DEBUG - 2021-12-03 19:54:45 --> Encrypt Class Initialized
DEBUG - 2021-12-03 19:54:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 19:54:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 19:54:45 --> Email Class Initialized
INFO - 2021-12-03 19:54:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 19:54:45 --> Calendar Class Initialized
INFO - 2021-12-03 19:54:45 --> Model "Login_model" initialized
INFO - 2021-12-03 19:54:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 19:54:45 --> Final output sent to browser
DEBUG - 2021-12-03 19:54:45 --> Total execution time: 0.0250
ERROR - 2021-12-03 20:12:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:41 --> Config Class Initialized
INFO - 2021-12-03 20:12:41 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:41 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:41 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:41 --> URI Class Initialized
DEBUG - 2021-12-03 20:12:41 --> No URI present. Default controller set.
INFO - 2021-12-03 20:12:41 --> Router Class Initialized
INFO - 2021-12-03 20:12:41 --> Output Class Initialized
INFO - 2021-12-03 20:12:41 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:41 --> Input Class Initialized
INFO - 2021-12-03 20:12:41 --> Language Class Initialized
INFO - 2021-12-03 20:12:41 --> Loader Class Initialized
INFO - 2021-12-03 20:12:41 --> Helper loaded: url_helper
INFO - 2021-12-03 20:12:41 --> Helper loaded: form_helper
INFO - 2021-12-03 20:12:41 --> Helper loaded: common_helper
INFO - 2021-12-03 20:12:41 --> Database Driver Class Initialized
DEBUG - 2021-12-03 20:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 20:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 20:12:41 --> Controller Class Initialized
INFO - 2021-12-03 20:12:41 --> Form Validation Class Initialized
DEBUG - 2021-12-03 20:12:41 --> Encrypt Class Initialized
DEBUG - 2021-12-03 20:12:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 20:12:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 20:12:41 --> Email Class Initialized
INFO - 2021-12-03 20:12:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 20:12:41 --> Calendar Class Initialized
INFO - 2021-12-03 20:12:41 --> Model "Login_model" initialized
INFO - 2021-12-03 20:12:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 20:12:41 --> Final output sent to browser
DEBUG - 2021-12-03 20:12:41 --> Total execution time: 0.0225
ERROR - 2021-12-03 20:12:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:42 --> Config Class Initialized
INFO - 2021-12-03 20:12:42 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:42 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:42 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:42 --> URI Class Initialized
DEBUG - 2021-12-03 20:12:42 --> No URI present. Default controller set.
INFO - 2021-12-03 20:12:42 --> Router Class Initialized
INFO - 2021-12-03 20:12:42 --> Output Class Initialized
INFO - 2021-12-03 20:12:42 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:42 --> Input Class Initialized
INFO - 2021-12-03 20:12:42 --> Language Class Initialized
INFO - 2021-12-03 20:12:42 --> Loader Class Initialized
INFO - 2021-12-03 20:12:42 --> Helper loaded: url_helper
INFO - 2021-12-03 20:12:42 --> Helper loaded: form_helper
INFO - 2021-12-03 20:12:42 --> Helper loaded: common_helper
INFO - 2021-12-03 20:12:42 --> Database Driver Class Initialized
DEBUG - 2021-12-03 20:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 20:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 20:12:42 --> Controller Class Initialized
INFO - 2021-12-03 20:12:42 --> Form Validation Class Initialized
DEBUG - 2021-12-03 20:12:42 --> Encrypt Class Initialized
DEBUG - 2021-12-03 20:12:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 20:12:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 20:12:42 --> Email Class Initialized
INFO - 2021-12-03 20:12:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 20:12:42 --> Calendar Class Initialized
INFO - 2021-12-03 20:12:42 --> Model "Login_model" initialized
INFO - 2021-12-03 20:12:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 20:12:42 --> Final output sent to browser
DEBUG - 2021-12-03 20:12:42 --> Total execution time: 0.0230
ERROR - 2021-12-03 20:12:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:42 --> Config Class Initialized
INFO - 2021-12-03 20:12:42 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:42 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:42 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:42 --> URI Class Initialized
INFO - 2021-12-03 20:12:42 --> Router Class Initialized
INFO - 2021-12-03 20:12:42 --> Output Class Initialized
INFO - 2021-12-03 20:12:42 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:42 --> Input Class Initialized
INFO - 2021-12-03 20:12:42 --> Language Class Initialized
ERROR - 2021-12-03 20:12:42 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-03 20:12:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:43 --> Config Class Initialized
INFO - 2021-12-03 20:12:43 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:43 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:43 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:43 --> URI Class Initialized
INFO - 2021-12-03 20:12:43 --> Router Class Initialized
INFO - 2021-12-03 20:12:43 --> Output Class Initialized
INFO - 2021-12-03 20:12:43 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:43 --> Input Class Initialized
INFO - 2021-12-03 20:12:43 --> Language Class Initialized
ERROR - 2021-12-03 20:12:43 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-03 20:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:44 --> Config Class Initialized
INFO - 2021-12-03 20:12:44 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:44 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:44 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:44 --> URI Class Initialized
INFO - 2021-12-03 20:12:44 --> Router Class Initialized
INFO - 2021-12-03 20:12:44 --> Output Class Initialized
INFO - 2021-12-03 20:12:44 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:44 --> Input Class Initialized
INFO - 2021-12-03 20:12:44 --> Language Class Initialized
ERROR - 2021-12-03 20:12:44 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-03 20:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:44 --> Config Class Initialized
INFO - 2021-12-03 20:12:44 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:44 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:44 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:44 --> URI Class Initialized
INFO - 2021-12-03 20:12:44 --> Router Class Initialized
INFO - 2021-12-03 20:12:44 --> Output Class Initialized
INFO - 2021-12-03 20:12:44 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:44 --> Input Class Initialized
INFO - 2021-12-03 20:12:44 --> Language Class Initialized
ERROR - 2021-12-03 20:12:44 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-03 20:12:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:45 --> Config Class Initialized
INFO - 2021-12-03 20:12:45 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:45 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:45 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:45 --> URI Class Initialized
INFO - 2021-12-03 20:12:45 --> Router Class Initialized
INFO - 2021-12-03 20:12:45 --> Output Class Initialized
INFO - 2021-12-03 20:12:45 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:45 --> Input Class Initialized
INFO - 2021-12-03 20:12:45 --> Language Class Initialized
ERROR - 2021-12-03 20:12:45 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-03 20:12:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:45 --> Config Class Initialized
INFO - 2021-12-03 20:12:45 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:45 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:45 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:45 --> URI Class Initialized
INFO - 2021-12-03 20:12:45 --> Router Class Initialized
INFO - 2021-12-03 20:12:45 --> Output Class Initialized
INFO - 2021-12-03 20:12:45 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:45 --> Input Class Initialized
INFO - 2021-12-03 20:12:45 --> Language Class Initialized
ERROR - 2021-12-03 20:12:45 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-03 20:12:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:46 --> Config Class Initialized
INFO - 2021-12-03 20:12:46 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:46 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:46 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:46 --> URI Class Initialized
INFO - 2021-12-03 20:12:46 --> Router Class Initialized
INFO - 2021-12-03 20:12:46 --> Output Class Initialized
INFO - 2021-12-03 20:12:46 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:46 --> Input Class Initialized
INFO - 2021-12-03 20:12:46 --> Language Class Initialized
ERROR - 2021-12-03 20:12:46 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-03 20:12:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:46 --> Config Class Initialized
INFO - 2021-12-03 20:12:46 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:46 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:46 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:46 --> URI Class Initialized
INFO - 2021-12-03 20:12:46 --> Router Class Initialized
INFO - 2021-12-03 20:12:46 --> Output Class Initialized
INFO - 2021-12-03 20:12:46 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:46 --> Input Class Initialized
INFO - 2021-12-03 20:12:46 --> Language Class Initialized
ERROR - 2021-12-03 20:12:46 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-12-03 20:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:47 --> Config Class Initialized
INFO - 2021-12-03 20:12:47 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:47 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:47 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:47 --> URI Class Initialized
INFO - 2021-12-03 20:12:47 --> Router Class Initialized
INFO - 2021-12-03 20:12:47 --> Output Class Initialized
INFO - 2021-12-03 20:12:47 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:47 --> Input Class Initialized
INFO - 2021-12-03 20:12:47 --> Language Class Initialized
ERROR - 2021-12-03 20:12:47 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-03 20:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:47 --> Config Class Initialized
INFO - 2021-12-03 20:12:47 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:47 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:47 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:47 --> URI Class Initialized
INFO - 2021-12-03 20:12:47 --> Router Class Initialized
INFO - 2021-12-03 20:12:47 --> Output Class Initialized
INFO - 2021-12-03 20:12:47 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:47 --> Input Class Initialized
INFO - 2021-12-03 20:12:47 --> Language Class Initialized
ERROR - 2021-12-03 20:12:47 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-03 20:12:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:48 --> Config Class Initialized
INFO - 2021-12-03 20:12:48 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:48 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:48 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:48 --> URI Class Initialized
INFO - 2021-12-03 20:12:48 --> Router Class Initialized
INFO - 2021-12-03 20:12:48 --> Output Class Initialized
INFO - 2021-12-03 20:12:48 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:48 --> Input Class Initialized
INFO - 2021-12-03 20:12:48 --> Language Class Initialized
ERROR - 2021-12-03 20:12:48 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-03 20:12:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:48 --> Config Class Initialized
INFO - 2021-12-03 20:12:48 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:48 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:48 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:48 --> URI Class Initialized
INFO - 2021-12-03 20:12:48 --> Router Class Initialized
INFO - 2021-12-03 20:12:48 --> Output Class Initialized
INFO - 2021-12-03 20:12:48 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:48 --> Input Class Initialized
INFO - 2021-12-03 20:12:48 --> Language Class Initialized
ERROR - 2021-12-03 20:12:48 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-03 20:12:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:49 --> Config Class Initialized
INFO - 2021-12-03 20:12:49 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:49 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:49 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:49 --> URI Class Initialized
INFO - 2021-12-03 20:12:49 --> Router Class Initialized
INFO - 2021-12-03 20:12:49 --> Output Class Initialized
INFO - 2021-12-03 20:12:49 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:49 --> Input Class Initialized
INFO - 2021-12-03 20:12:49 --> Language Class Initialized
ERROR - 2021-12-03 20:12:49 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-03 20:12:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:49 --> Config Class Initialized
INFO - 2021-12-03 20:12:49 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:49 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:49 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:49 --> URI Class Initialized
INFO - 2021-12-03 20:12:49 --> Router Class Initialized
INFO - 2021-12-03 20:12:49 --> Output Class Initialized
INFO - 2021-12-03 20:12:49 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:49 --> Input Class Initialized
INFO - 2021-12-03 20:12:49 --> Language Class Initialized
ERROR - 2021-12-03 20:12:49 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-03 20:12:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:50 --> Config Class Initialized
INFO - 2021-12-03 20:12:50 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:50 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:50 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:50 --> URI Class Initialized
INFO - 2021-12-03 20:12:50 --> Router Class Initialized
INFO - 2021-12-03 20:12:50 --> Output Class Initialized
INFO - 2021-12-03 20:12:50 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:50 --> Input Class Initialized
INFO - 2021-12-03 20:12:50 --> Language Class Initialized
ERROR - 2021-12-03 20:12:50 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-03 20:12:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 20:12:50 --> Config Class Initialized
INFO - 2021-12-03 20:12:50 --> Hooks Class Initialized
DEBUG - 2021-12-03 20:12:50 --> UTF-8 Support Enabled
INFO - 2021-12-03 20:12:50 --> Utf8 Class Initialized
INFO - 2021-12-03 20:12:50 --> URI Class Initialized
INFO - 2021-12-03 20:12:50 --> Router Class Initialized
INFO - 2021-12-03 20:12:50 --> Output Class Initialized
INFO - 2021-12-03 20:12:50 --> Security Class Initialized
DEBUG - 2021-12-03 20:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 20:12:50 --> Input Class Initialized
INFO - 2021-12-03 20:12:50 --> Language Class Initialized
ERROR - 2021-12-03 20:12:50 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-03 21:45:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 21:45:43 --> Config Class Initialized
INFO - 2021-12-03 21:45:43 --> Hooks Class Initialized
DEBUG - 2021-12-03 21:45:43 --> UTF-8 Support Enabled
INFO - 2021-12-03 21:45:43 --> Utf8 Class Initialized
INFO - 2021-12-03 21:45:43 --> URI Class Initialized
DEBUG - 2021-12-03 21:45:43 --> No URI present. Default controller set.
INFO - 2021-12-03 21:45:43 --> Router Class Initialized
INFO - 2021-12-03 21:45:43 --> Output Class Initialized
INFO - 2021-12-03 21:45:43 --> Security Class Initialized
DEBUG - 2021-12-03 21:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 21:45:43 --> Input Class Initialized
INFO - 2021-12-03 21:45:43 --> Language Class Initialized
INFO - 2021-12-03 21:45:43 --> Loader Class Initialized
INFO - 2021-12-03 21:45:43 --> Helper loaded: url_helper
INFO - 2021-12-03 21:45:43 --> Helper loaded: form_helper
INFO - 2021-12-03 21:45:43 --> Helper loaded: common_helper
INFO - 2021-12-03 21:45:43 --> Database Driver Class Initialized
DEBUG - 2021-12-03 21:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 21:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 21:45:43 --> Controller Class Initialized
INFO - 2021-12-03 21:45:43 --> Form Validation Class Initialized
DEBUG - 2021-12-03 21:45:43 --> Encrypt Class Initialized
DEBUG - 2021-12-03 21:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 21:45:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 21:45:43 --> Email Class Initialized
INFO - 2021-12-03 21:45:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 21:45:43 --> Calendar Class Initialized
INFO - 2021-12-03 21:45:43 --> Model "Login_model" initialized
INFO - 2021-12-03 21:45:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 21:45:43 --> Final output sent to browser
DEBUG - 2021-12-03 21:45:43 --> Total execution time: 0.0239
ERROR - 2021-12-03 21:48:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 21:48:29 --> Config Class Initialized
INFO - 2021-12-03 21:48:29 --> Hooks Class Initialized
DEBUG - 2021-12-03 21:48:29 --> UTF-8 Support Enabled
INFO - 2021-12-03 21:48:29 --> Utf8 Class Initialized
INFO - 2021-12-03 21:48:29 --> URI Class Initialized
DEBUG - 2021-12-03 21:48:29 --> No URI present. Default controller set.
INFO - 2021-12-03 21:48:29 --> Router Class Initialized
INFO - 2021-12-03 21:48:29 --> Output Class Initialized
INFO - 2021-12-03 21:48:29 --> Security Class Initialized
DEBUG - 2021-12-03 21:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 21:48:29 --> Input Class Initialized
INFO - 2021-12-03 21:48:29 --> Language Class Initialized
INFO - 2021-12-03 21:48:29 --> Loader Class Initialized
INFO - 2021-12-03 21:48:29 --> Helper loaded: url_helper
INFO - 2021-12-03 21:48:29 --> Helper loaded: form_helper
INFO - 2021-12-03 21:48:29 --> Helper loaded: common_helper
INFO - 2021-12-03 21:48:29 --> Database Driver Class Initialized
DEBUG - 2021-12-03 21:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 21:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 21:48:29 --> Controller Class Initialized
INFO - 2021-12-03 21:48:29 --> Form Validation Class Initialized
DEBUG - 2021-12-03 21:48:29 --> Encrypt Class Initialized
DEBUG - 2021-12-03 21:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 21:48:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 21:48:29 --> Email Class Initialized
INFO - 2021-12-03 21:48:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 21:48:29 --> Calendar Class Initialized
INFO - 2021-12-03 21:48:29 --> Model "Login_model" initialized
INFO - 2021-12-03 21:48:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 21:48:29 --> Final output sent to browser
DEBUG - 2021-12-03 21:48:29 --> Total execution time: 0.0230
ERROR - 2021-12-03 21:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-03 21:50:54 --> Config Class Initialized
INFO - 2021-12-03 21:50:54 --> Hooks Class Initialized
DEBUG - 2021-12-03 21:50:54 --> UTF-8 Support Enabled
INFO - 2021-12-03 21:50:54 --> Utf8 Class Initialized
INFO - 2021-12-03 21:50:54 --> URI Class Initialized
DEBUG - 2021-12-03 21:50:54 --> No URI present. Default controller set.
INFO - 2021-12-03 21:50:54 --> Router Class Initialized
INFO - 2021-12-03 21:50:54 --> Output Class Initialized
INFO - 2021-12-03 21:50:54 --> Security Class Initialized
DEBUG - 2021-12-03 21:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 21:50:54 --> Input Class Initialized
INFO - 2021-12-03 21:50:54 --> Language Class Initialized
INFO - 2021-12-03 21:50:54 --> Loader Class Initialized
INFO - 2021-12-03 21:50:54 --> Helper loaded: url_helper
INFO - 2021-12-03 21:50:54 --> Helper loaded: form_helper
INFO - 2021-12-03 21:50:54 --> Helper loaded: common_helper
INFO - 2021-12-03 21:50:54 --> Database Driver Class Initialized
DEBUG - 2021-12-03 21:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 21:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 21:50:54 --> Controller Class Initialized
INFO - 2021-12-03 21:50:54 --> Form Validation Class Initialized
DEBUG - 2021-12-03 21:50:54 --> Encrypt Class Initialized
DEBUG - 2021-12-03 21:50:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-03 21:50:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-03 21:50:54 --> Email Class Initialized
INFO - 2021-12-03 21:50:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-03 21:50:54 --> Calendar Class Initialized
INFO - 2021-12-03 21:50:54 --> Model "Login_model" initialized
INFO - 2021-12-03 21:50:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-03 21:50:54 --> Final output sent to browser
DEBUG - 2021-12-03 21:50:54 --> Total execution time: 0.0250
