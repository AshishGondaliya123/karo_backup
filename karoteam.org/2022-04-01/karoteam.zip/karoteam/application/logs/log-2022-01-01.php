<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-01 05:47:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 05:47:29 --> Config Class Initialized
INFO - 2022-01-01 05:47:29 --> Hooks Class Initialized
DEBUG - 2022-01-01 05:47:29 --> UTF-8 Support Enabled
INFO - 2022-01-01 05:47:29 --> Utf8 Class Initialized
INFO - 2022-01-01 05:47:29 --> URI Class Initialized
DEBUG - 2022-01-01 05:47:29 --> No URI present. Default controller set.
INFO - 2022-01-01 05:47:29 --> Router Class Initialized
INFO - 2022-01-01 05:47:29 --> Output Class Initialized
INFO - 2022-01-01 05:47:29 --> Security Class Initialized
DEBUG - 2022-01-01 05:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 05:47:29 --> Input Class Initialized
INFO - 2022-01-01 05:47:29 --> Language Class Initialized
INFO - 2022-01-01 05:47:29 --> Loader Class Initialized
INFO - 2022-01-01 05:47:29 --> Helper loaded: url_helper
INFO - 2022-01-01 05:47:29 --> Helper loaded: form_helper
INFO - 2022-01-01 05:47:29 --> Helper loaded: common_helper
INFO - 2022-01-01 05:47:29 --> Database Driver Class Initialized
DEBUG - 2022-01-01 05:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 05:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 05:47:29 --> Controller Class Initialized
INFO - 2022-01-01 05:47:29 --> Form Validation Class Initialized
DEBUG - 2022-01-01 05:47:29 --> Encrypt Class Initialized
DEBUG - 2022-01-01 05:47:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 05:47:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 05:47:29 --> Email Class Initialized
INFO - 2022-01-01 05:47:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 05:47:29 --> Calendar Class Initialized
INFO - 2022-01-01 05:47:29 --> Model "Login_model" initialized
INFO - 2022-01-01 05:47:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-01 05:47:29 --> Final output sent to browser
DEBUG - 2022-01-01 05:47:29 --> Total execution time: 0.0254
ERROR - 2022-01-01 07:38:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 07:38:05 --> Config Class Initialized
INFO - 2022-01-01 07:38:05 --> Hooks Class Initialized
DEBUG - 2022-01-01 07:38:05 --> UTF-8 Support Enabled
INFO - 2022-01-01 07:38:05 --> Utf8 Class Initialized
INFO - 2022-01-01 07:38:05 --> URI Class Initialized
DEBUG - 2022-01-01 07:38:05 --> No URI present. Default controller set.
INFO - 2022-01-01 07:38:05 --> Router Class Initialized
INFO - 2022-01-01 07:38:05 --> Output Class Initialized
INFO - 2022-01-01 07:38:05 --> Security Class Initialized
DEBUG - 2022-01-01 07:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 07:38:05 --> Input Class Initialized
INFO - 2022-01-01 07:38:05 --> Language Class Initialized
INFO - 2022-01-01 07:38:05 --> Loader Class Initialized
INFO - 2022-01-01 07:38:05 --> Helper loaded: url_helper
INFO - 2022-01-01 07:38:05 --> Helper loaded: form_helper
INFO - 2022-01-01 07:38:05 --> Helper loaded: common_helper
INFO - 2022-01-01 07:38:05 --> Database Driver Class Initialized
DEBUG - 2022-01-01 07:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 07:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 07:38:05 --> Controller Class Initialized
INFO - 2022-01-01 07:38:05 --> Form Validation Class Initialized
DEBUG - 2022-01-01 07:38:05 --> Encrypt Class Initialized
DEBUG - 2022-01-01 07:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 07:38:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 07:38:05 --> Email Class Initialized
INFO - 2022-01-01 07:38:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 07:38:05 --> Calendar Class Initialized
INFO - 2022-01-01 07:38:05 --> Model "Login_model" initialized
INFO - 2022-01-01 07:38:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-01 07:38:05 --> Final output sent to browser
DEBUG - 2022-01-01 07:38:05 --> Total execution time: 0.0226
ERROR - 2022-01-01 11:28:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 11:28:29 --> Config Class Initialized
INFO - 2022-01-01 11:28:29 --> Hooks Class Initialized
DEBUG - 2022-01-01 11:28:29 --> UTF-8 Support Enabled
INFO - 2022-01-01 11:28:29 --> Utf8 Class Initialized
INFO - 2022-01-01 11:28:29 --> URI Class Initialized
DEBUG - 2022-01-01 11:28:29 --> No URI present. Default controller set.
INFO - 2022-01-01 11:28:29 --> Router Class Initialized
INFO - 2022-01-01 11:28:29 --> Output Class Initialized
INFO - 2022-01-01 11:28:29 --> Security Class Initialized
DEBUG - 2022-01-01 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 11:28:29 --> Input Class Initialized
INFO - 2022-01-01 11:28:29 --> Language Class Initialized
INFO - 2022-01-01 11:28:29 --> Loader Class Initialized
INFO - 2022-01-01 11:28:29 --> Helper loaded: url_helper
INFO - 2022-01-01 11:28:29 --> Helper loaded: form_helper
INFO - 2022-01-01 11:28:29 --> Helper loaded: common_helper
INFO - 2022-01-01 11:28:29 --> Database Driver Class Initialized
DEBUG - 2022-01-01 11:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 11:28:29 --> Controller Class Initialized
INFO - 2022-01-01 11:28:29 --> Form Validation Class Initialized
DEBUG - 2022-01-01 11:28:29 --> Encrypt Class Initialized
DEBUG - 2022-01-01 11:28:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 11:28:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 11:28:29 --> Email Class Initialized
INFO - 2022-01-01 11:28:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 11:28:29 --> Calendar Class Initialized
INFO - 2022-01-01 11:28:29 --> Model "Login_model" initialized
INFO - 2022-01-01 11:28:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-01 11:28:29 --> Final output sent to browser
DEBUG - 2022-01-01 11:28:29 --> Total execution time: 0.0244
ERROR - 2022-01-01 13:19:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:35 --> Config Class Initialized
INFO - 2022-01-01 13:19:35 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:35 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:35 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:35 --> URI Class Initialized
DEBUG - 2022-01-01 13:19:35 --> No URI present. Default controller set.
INFO - 2022-01-01 13:19:35 --> Router Class Initialized
INFO - 2022-01-01 13:19:35 --> Output Class Initialized
INFO - 2022-01-01 13:19:35 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:35 --> Input Class Initialized
INFO - 2022-01-01 13:19:35 --> Language Class Initialized
INFO - 2022-01-01 13:19:35 --> Loader Class Initialized
INFO - 2022-01-01 13:19:35 --> Helper loaded: url_helper
INFO - 2022-01-01 13:19:35 --> Helper loaded: form_helper
INFO - 2022-01-01 13:19:35 --> Helper loaded: common_helper
INFO - 2022-01-01 13:19:35 --> Database Driver Class Initialized
DEBUG - 2022-01-01 13:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 13:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 13:19:35 --> Controller Class Initialized
INFO - 2022-01-01 13:19:35 --> Form Validation Class Initialized
DEBUG - 2022-01-01 13:19:35 --> Encrypt Class Initialized
DEBUG - 2022-01-01 13:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 13:19:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 13:19:35 --> Email Class Initialized
INFO - 2022-01-01 13:19:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 13:19:35 --> Calendar Class Initialized
INFO - 2022-01-01 13:19:35 --> Model "Login_model" initialized
INFO - 2022-01-01 13:19:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-01 13:19:35 --> Final output sent to browser
DEBUG - 2022-01-01 13:19:35 --> Total execution time: 0.0335
ERROR - 2022-01-01 13:19:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:35 --> Config Class Initialized
INFO - 2022-01-01 13:19:35 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:35 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:35 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:35 --> URI Class Initialized
DEBUG - 2022-01-01 13:19:35 --> No URI present. Default controller set.
INFO - 2022-01-01 13:19:35 --> Router Class Initialized
INFO - 2022-01-01 13:19:35 --> Output Class Initialized
INFO - 2022-01-01 13:19:35 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:35 --> Input Class Initialized
INFO - 2022-01-01 13:19:35 --> Language Class Initialized
INFO - 2022-01-01 13:19:35 --> Loader Class Initialized
INFO - 2022-01-01 13:19:35 --> Helper loaded: url_helper
INFO - 2022-01-01 13:19:35 --> Helper loaded: form_helper
INFO - 2022-01-01 13:19:35 --> Helper loaded: common_helper
INFO - 2022-01-01 13:19:35 --> Database Driver Class Initialized
DEBUG - 2022-01-01 13:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 13:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 13:19:35 --> Controller Class Initialized
INFO - 2022-01-01 13:19:35 --> Form Validation Class Initialized
DEBUG - 2022-01-01 13:19:35 --> Encrypt Class Initialized
DEBUG - 2022-01-01 13:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 13:19:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 13:19:35 --> Email Class Initialized
INFO - 2022-01-01 13:19:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 13:19:35 --> Calendar Class Initialized
INFO - 2022-01-01 13:19:35 --> Model "Login_model" initialized
INFO - 2022-01-01 13:19:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-01 13:19:35 --> Final output sent to browser
DEBUG - 2022-01-01 13:19:35 --> Total execution time: 0.0249
ERROR - 2022-01-01 13:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:36 --> Config Class Initialized
INFO - 2022-01-01 13:19:36 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:36 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:36 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:36 --> URI Class Initialized
INFO - 2022-01-01 13:19:36 --> Router Class Initialized
INFO - 2022-01-01 13:19:36 --> Output Class Initialized
INFO - 2022-01-01 13:19:36 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:36 --> Input Class Initialized
INFO - 2022-01-01 13:19:36 --> Language Class Initialized
ERROR - 2022-01-01 13:19:36 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-01 13:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:36 --> Config Class Initialized
INFO - 2022-01-01 13:19:36 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:36 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:36 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:36 --> URI Class Initialized
INFO - 2022-01-01 13:19:36 --> Router Class Initialized
INFO - 2022-01-01 13:19:36 --> Output Class Initialized
INFO - 2022-01-01 13:19:36 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:36 --> Input Class Initialized
INFO - 2022-01-01 13:19:36 --> Language Class Initialized
ERROR - 2022-01-01 13:19:36 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-01 13:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:37 --> Config Class Initialized
INFO - 2022-01-01 13:19:37 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:37 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:37 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:37 --> URI Class Initialized
INFO - 2022-01-01 13:19:37 --> Router Class Initialized
INFO - 2022-01-01 13:19:37 --> Output Class Initialized
INFO - 2022-01-01 13:19:37 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:37 --> Input Class Initialized
INFO - 2022-01-01 13:19:37 --> Language Class Initialized
ERROR - 2022-01-01 13:19:37 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-01 13:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:37 --> Config Class Initialized
INFO - 2022-01-01 13:19:37 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:37 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:37 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:37 --> URI Class Initialized
INFO - 2022-01-01 13:19:37 --> Router Class Initialized
INFO - 2022-01-01 13:19:37 --> Output Class Initialized
INFO - 2022-01-01 13:19:37 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:37 --> Input Class Initialized
INFO - 2022-01-01 13:19:37 --> Language Class Initialized
ERROR - 2022-01-01 13:19:37 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-01 13:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:37 --> Config Class Initialized
INFO - 2022-01-01 13:19:37 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:37 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:37 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:37 --> URI Class Initialized
INFO - 2022-01-01 13:19:37 --> Router Class Initialized
INFO - 2022-01-01 13:19:37 --> Output Class Initialized
INFO - 2022-01-01 13:19:37 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:37 --> Input Class Initialized
INFO - 2022-01-01 13:19:37 --> Language Class Initialized
ERROR - 2022-01-01 13:19:37 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-01 13:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:38 --> Config Class Initialized
INFO - 2022-01-01 13:19:38 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:38 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:38 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:38 --> URI Class Initialized
INFO - 2022-01-01 13:19:38 --> Router Class Initialized
INFO - 2022-01-01 13:19:38 --> Output Class Initialized
INFO - 2022-01-01 13:19:38 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:38 --> Input Class Initialized
INFO - 2022-01-01 13:19:38 --> Language Class Initialized
ERROR - 2022-01-01 13:19:38 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-01 13:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:38 --> Config Class Initialized
INFO - 2022-01-01 13:19:38 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:38 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:38 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:38 --> URI Class Initialized
INFO - 2022-01-01 13:19:38 --> Router Class Initialized
INFO - 2022-01-01 13:19:38 --> Output Class Initialized
INFO - 2022-01-01 13:19:38 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:38 --> Input Class Initialized
INFO - 2022-01-01 13:19:38 --> Language Class Initialized
ERROR - 2022-01-01 13:19:38 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-01 13:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:38 --> Config Class Initialized
INFO - 2022-01-01 13:19:38 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:38 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:38 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:38 --> URI Class Initialized
INFO - 2022-01-01 13:19:38 --> Router Class Initialized
INFO - 2022-01-01 13:19:38 --> Output Class Initialized
INFO - 2022-01-01 13:19:38 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:38 --> Input Class Initialized
INFO - 2022-01-01 13:19:38 --> Language Class Initialized
ERROR - 2022-01-01 13:19:38 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-01 13:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:39 --> Config Class Initialized
INFO - 2022-01-01 13:19:39 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:39 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:39 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:39 --> URI Class Initialized
INFO - 2022-01-01 13:19:39 --> Router Class Initialized
INFO - 2022-01-01 13:19:39 --> Output Class Initialized
INFO - 2022-01-01 13:19:39 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:39 --> Input Class Initialized
INFO - 2022-01-01 13:19:39 --> Language Class Initialized
ERROR - 2022-01-01 13:19:39 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-01 13:19:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:41 --> Config Class Initialized
INFO - 2022-01-01 13:19:41 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:41 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:41 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:41 --> URI Class Initialized
INFO - 2022-01-01 13:19:41 --> Router Class Initialized
INFO - 2022-01-01 13:19:41 --> Output Class Initialized
INFO - 2022-01-01 13:19:41 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:41 --> Input Class Initialized
INFO - 2022-01-01 13:19:41 --> Language Class Initialized
ERROR - 2022-01-01 13:19:41 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-01 13:19:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:41 --> Config Class Initialized
INFO - 2022-01-01 13:19:41 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:41 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:41 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:41 --> URI Class Initialized
INFO - 2022-01-01 13:19:41 --> Router Class Initialized
INFO - 2022-01-01 13:19:41 --> Output Class Initialized
INFO - 2022-01-01 13:19:41 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:41 --> Input Class Initialized
INFO - 2022-01-01 13:19:41 --> Language Class Initialized
ERROR - 2022-01-01 13:19:41 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-01 13:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:42 --> Config Class Initialized
INFO - 2022-01-01 13:19:42 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:42 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:42 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:42 --> URI Class Initialized
INFO - 2022-01-01 13:19:42 --> Router Class Initialized
INFO - 2022-01-01 13:19:42 --> Output Class Initialized
INFO - 2022-01-01 13:19:42 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:42 --> Input Class Initialized
INFO - 2022-01-01 13:19:42 --> Language Class Initialized
ERROR - 2022-01-01 13:19:42 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-01 13:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:42 --> Config Class Initialized
INFO - 2022-01-01 13:19:42 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:42 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:42 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:42 --> URI Class Initialized
INFO - 2022-01-01 13:19:42 --> Router Class Initialized
INFO - 2022-01-01 13:19:42 --> Output Class Initialized
INFO - 2022-01-01 13:19:42 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:42 --> Input Class Initialized
INFO - 2022-01-01 13:19:42 --> Language Class Initialized
ERROR - 2022-01-01 13:19:42 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-01 13:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:43 --> Config Class Initialized
INFO - 2022-01-01 13:19:43 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:43 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:43 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:43 --> URI Class Initialized
INFO - 2022-01-01 13:19:43 --> Router Class Initialized
INFO - 2022-01-01 13:19:43 --> Output Class Initialized
INFO - 2022-01-01 13:19:43 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:43 --> Input Class Initialized
INFO - 2022-01-01 13:19:43 --> Language Class Initialized
ERROR - 2022-01-01 13:19:43 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-01 13:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:43 --> Config Class Initialized
INFO - 2022-01-01 13:19:43 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:43 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:43 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:43 --> URI Class Initialized
INFO - 2022-01-01 13:19:43 --> Router Class Initialized
INFO - 2022-01-01 13:19:43 --> Output Class Initialized
INFO - 2022-01-01 13:19:43 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:43 --> Input Class Initialized
INFO - 2022-01-01 13:19:43 --> Language Class Initialized
ERROR - 2022-01-01 13:19:43 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-01 13:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:43 --> Config Class Initialized
INFO - 2022-01-01 13:19:43 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:43 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:43 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:43 --> URI Class Initialized
INFO - 2022-01-01 13:19:43 --> Router Class Initialized
INFO - 2022-01-01 13:19:43 --> Output Class Initialized
INFO - 2022-01-01 13:19:43 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:43 --> Input Class Initialized
INFO - 2022-01-01 13:19:43 --> Language Class Initialized
ERROR - 2022-01-01 13:19:43 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-01 13:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 13:19:44 --> Config Class Initialized
INFO - 2022-01-01 13:19:44 --> Hooks Class Initialized
DEBUG - 2022-01-01 13:19:44 --> UTF-8 Support Enabled
INFO - 2022-01-01 13:19:44 --> Utf8 Class Initialized
INFO - 2022-01-01 13:19:44 --> URI Class Initialized
INFO - 2022-01-01 13:19:44 --> Router Class Initialized
INFO - 2022-01-01 13:19:44 --> Output Class Initialized
INFO - 2022-01-01 13:19:44 --> Security Class Initialized
DEBUG - 2022-01-01 13:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 13:19:44 --> Input Class Initialized
INFO - 2022-01-01 13:19:44 --> Language Class Initialized
ERROR - 2022-01-01 13:19:44 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-01 14:23:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 14:23:48 --> Config Class Initialized
INFO - 2022-01-01 14:23:48 --> Hooks Class Initialized
DEBUG - 2022-01-01 14:23:48 --> UTF-8 Support Enabled
INFO - 2022-01-01 14:23:48 --> Utf8 Class Initialized
INFO - 2022-01-01 14:23:48 --> URI Class Initialized
DEBUG - 2022-01-01 14:23:48 --> No URI present. Default controller set.
INFO - 2022-01-01 14:23:48 --> Router Class Initialized
INFO - 2022-01-01 14:23:48 --> Output Class Initialized
INFO - 2022-01-01 14:23:48 --> Security Class Initialized
DEBUG - 2022-01-01 14:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 14:23:48 --> Input Class Initialized
INFO - 2022-01-01 14:23:48 --> Language Class Initialized
INFO - 2022-01-01 14:23:48 --> Loader Class Initialized
INFO - 2022-01-01 14:23:48 --> Helper loaded: url_helper
INFO - 2022-01-01 14:23:48 --> Helper loaded: form_helper
INFO - 2022-01-01 14:23:48 --> Helper loaded: common_helper
INFO - 2022-01-01 14:23:48 --> Database Driver Class Initialized
DEBUG - 2022-01-01 14:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 14:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 14:23:48 --> Controller Class Initialized
INFO - 2022-01-01 14:23:48 --> Form Validation Class Initialized
DEBUG - 2022-01-01 14:23:48 --> Encrypt Class Initialized
DEBUG - 2022-01-01 14:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 14:23:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 14:23:48 --> Email Class Initialized
INFO - 2022-01-01 14:23:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 14:23:48 --> Calendar Class Initialized
INFO - 2022-01-01 14:23:48 --> Model "Login_model" initialized
INFO - 2022-01-01 14:23:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-01 14:23:48 --> Final output sent to browser
DEBUG - 2022-01-01 14:23:48 --> Total execution time: 0.0246
ERROR - 2022-01-01 14:23:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 14:23:49 --> Config Class Initialized
INFO - 2022-01-01 14:23:49 --> Hooks Class Initialized
DEBUG - 2022-01-01 14:23:49 --> UTF-8 Support Enabled
INFO - 2022-01-01 14:23:49 --> Utf8 Class Initialized
INFO - 2022-01-01 14:23:49 --> URI Class Initialized
INFO - 2022-01-01 14:23:49 --> Router Class Initialized
INFO - 2022-01-01 14:23:49 --> Output Class Initialized
INFO - 2022-01-01 14:23:49 --> Security Class Initialized
DEBUG - 2022-01-01 14:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 14:23:49 --> Input Class Initialized
INFO - 2022-01-01 14:23:49 --> Language Class Initialized
ERROR - 2022-01-01 14:23:49 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-01 14:24:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 14:24:01 --> Config Class Initialized
INFO - 2022-01-01 14:24:01 --> Hooks Class Initialized
DEBUG - 2022-01-01 14:24:01 --> UTF-8 Support Enabled
INFO - 2022-01-01 14:24:01 --> Utf8 Class Initialized
INFO - 2022-01-01 14:24:01 --> URI Class Initialized
DEBUG - 2022-01-01 14:24:01 --> No URI present. Default controller set.
INFO - 2022-01-01 14:24:01 --> Router Class Initialized
INFO - 2022-01-01 14:24:01 --> Output Class Initialized
INFO - 2022-01-01 14:24:01 --> Security Class Initialized
DEBUG - 2022-01-01 14:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 14:24:01 --> Input Class Initialized
INFO - 2022-01-01 14:24:01 --> Language Class Initialized
INFO - 2022-01-01 14:24:01 --> Loader Class Initialized
INFO - 2022-01-01 14:24:01 --> Helper loaded: url_helper
INFO - 2022-01-01 14:24:01 --> Helper loaded: form_helper
INFO - 2022-01-01 14:24:01 --> Helper loaded: common_helper
INFO - 2022-01-01 14:24:01 --> Database Driver Class Initialized
DEBUG - 2022-01-01 14:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 14:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 14:24:01 --> Controller Class Initialized
INFO - 2022-01-01 14:24:01 --> Form Validation Class Initialized
DEBUG - 2022-01-01 14:24:01 --> Encrypt Class Initialized
DEBUG - 2022-01-01 14:24:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 14:24:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 14:24:01 --> Email Class Initialized
INFO - 2022-01-01 14:24:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 14:24:01 --> Calendar Class Initialized
INFO - 2022-01-01 14:24:01 --> Model "Login_model" initialized
INFO - 2022-01-01 14:24:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-01 14:24:01 --> Final output sent to browser
DEBUG - 2022-01-01 14:24:01 --> Total execution time: 0.0570
ERROR - 2022-01-01 14:24:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 14:24:02 --> Config Class Initialized
INFO - 2022-01-01 14:24:02 --> Hooks Class Initialized
DEBUG - 2022-01-01 14:24:02 --> UTF-8 Support Enabled
INFO - 2022-01-01 14:24:02 --> Utf8 Class Initialized
INFO - 2022-01-01 14:24:02 --> URI Class Initialized
INFO - 2022-01-01 14:24:02 --> Router Class Initialized
INFO - 2022-01-01 14:24:02 --> Output Class Initialized
INFO - 2022-01-01 14:24:02 --> Security Class Initialized
DEBUG - 2022-01-01 14:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 14:24:02 --> Input Class Initialized
INFO - 2022-01-01 14:24:02 --> Language Class Initialized
INFO - 2022-01-01 14:24:02 --> Loader Class Initialized
INFO - 2022-01-01 14:24:02 --> Helper loaded: url_helper
INFO - 2022-01-01 14:24:02 --> Helper loaded: form_helper
INFO - 2022-01-01 14:24:02 --> Helper loaded: common_helper
INFO - 2022-01-01 14:24:02 --> Database Driver Class Initialized
DEBUG - 2022-01-01 14:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 14:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 14:24:02 --> Controller Class Initialized
INFO - 2022-01-01 14:24:02 --> Form Validation Class Initialized
DEBUG - 2022-01-01 14:24:02 --> Encrypt Class Initialized
DEBUG - 2022-01-01 14:24:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 14:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 14:24:02 --> Email Class Initialized
INFO - 2022-01-01 14:24:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 14:24:02 --> Calendar Class Initialized
INFO - 2022-01-01 14:24:02 --> Model "Login_model" initialized
ERROR - 2022-01-01 14:24:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 14:24:03 --> Config Class Initialized
INFO - 2022-01-01 14:24:03 --> Hooks Class Initialized
DEBUG - 2022-01-01 14:24:03 --> UTF-8 Support Enabled
INFO - 2022-01-01 14:24:03 --> Utf8 Class Initialized
INFO - 2022-01-01 14:24:03 --> URI Class Initialized
INFO - 2022-01-01 14:24:03 --> Router Class Initialized
INFO - 2022-01-01 14:24:03 --> Output Class Initialized
INFO - 2022-01-01 14:24:03 --> Security Class Initialized
DEBUG - 2022-01-01 14:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 14:24:03 --> Input Class Initialized
INFO - 2022-01-01 14:24:03 --> Language Class Initialized
INFO - 2022-01-01 14:24:03 --> Loader Class Initialized
INFO - 2022-01-01 14:24:03 --> Helper loaded: url_helper
INFO - 2022-01-01 14:24:03 --> Helper loaded: form_helper
INFO - 2022-01-01 14:24:03 --> Helper loaded: common_helper
INFO - 2022-01-01 14:24:03 --> Database Driver Class Initialized
DEBUG - 2022-01-01 14:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 14:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 14:24:03 --> Controller Class Initialized
INFO - 2022-01-01 14:24:03 --> Form Validation Class Initialized
DEBUG - 2022-01-01 14:24:03 --> Encrypt Class Initialized
DEBUG - 2022-01-01 14:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 14:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 14:24:03 --> Email Class Initialized
INFO - 2022-01-01 14:24:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 14:24:03 --> Calendar Class Initialized
INFO - 2022-01-01 14:24:03 --> Model "Login_model" initialized
ERROR - 2022-01-01 14:24:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 14:24:03 --> Config Class Initialized
INFO - 2022-01-01 14:24:03 --> Hooks Class Initialized
DEBUG - 2022-01-01 14:24:03 --> UTF-8 Support Enabled
INFO - 2022-01-01 14:24:03 --> Utf8 Class Initialized
INFO - 2022-01-01 14:24:03 --> URI Class Initialized
INFO - 2022-01-01 14:24:03 --> Router Class Initialized
INFO - 2022-01-01 14:24:03 --> Output Class Initialized
INFO - 2022-01-01 14:24:03 --> Security Class Initialized
DEBUG - 2022-01-01 14:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 14:24:03 --> Input Class Initialized
INFO - 2022-01-01 14:24:03 --> Language Class Initialized
INFO - 2022-01-01 14:24:03 --> Loader Class Initialized
INFO - 2022-01-01 14:24:03 --> Helper loaded: url_helper
INFO - 2022-01-01 14:24:03 --> Helper loaded: form_helper
INFO - 2022-01-01 14:24:03 --> Helper loaded: common_helper
INFO - 2022-01-01 14:24:03 --> Database Driver Class Initialized
DEBUG - 2022-01-01 14:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 14:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 14:24:03 --> Controller Class Initialized
INFO - 2022-01-01 14:24:03 --> Form Validation Class Initialized
DEBUG - 2022-01-01 14:24:03 --> Encrypt Class Initialized
DEBUG - 2022-01-01 14:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 14:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 14:24:03 --> Email Class Initialized
INFO - 2022-01-01 14:24:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 14:24:03 --> Calendar Class Initialized
INFO - 2022-01-01 14:24:03 --> Model "Login_model" initialized
INFO - 2022-01-01 14:24:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-01 14:24:03 --> Final output sent to browser
DEBUG - 2022-01-01 14:24:03 --> Total execution time: 0.0346
ERROR - 2022-01-01 19:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-01 19:28:40 --> Config Class Initialized
INFO - 2022-01-01 19:28:40 --> Hooks Class Initialized
DEBUG - 2022-01-01 19:28:40 --> UTF-8 Support Enabled
INFO - 2022-01-01 19:28:40 --> Utf8 Class Initialized
INFO - 2022-01-01 19:28:40 --> URI Class Initialized
DEBUG - 2022-01-01 19:28:40 --> No URI present. Default controller set.
INFO - 2022-01-01 19:28:40 --> Router Class Initialized
INFO - 2022-01-01 19:28:40 --> Output Class Initialized
INFO - 2022-01-01 19:28:40 --> Security Class Initialized
DEBUG - 2022-01-01 19:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-01 19:28:40 --> Input Class Initialized
INFO - 2022-01-01 19:28:40 --> Language Class Initialized
INFO - 2022-01-01 19:28:40 --> Loader Class Initialized
INFO - 2022-01-01 19:28:40 --> Helper loaded: url_helper
INFO - 2022-01-01 19:28:40 --> Helper loaded: form_helper
INFO - 2022-01-01 19:28:40 --> Helper loaded: common_helper
INFO - 2022-01-01 19:28:40 --> Database Driver Class Initialized
DEBUG - 2022-01-01 19:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-01 19:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-01 19:28:40 --> Controller Class Initialized
INFO - 2022-01-01 19:28:40 --> Form Validation Class Initialized
DEBUG - 2022-01-01 19:28:40 --> Encrypt Class Initialized
DEBUG - 2022-01-01 19:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 19:28:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-01 19:28:40 --> Email Class Initialized
INFO - 2022-01-01 19:28:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-01 19:28:40 --> Calendar Class Initialized
INFO - 2022-01-01 19:28:40 --> Model "Login_model" initialized
INFO - 2022-01-01 19:28:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-01 19:28:40 --> Final output sent to browser
DEBUG - 2022-01-01 19:28:40 --> Total execution time: 0.0247
