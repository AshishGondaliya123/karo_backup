<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-21 02:11:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-21 02:11:15 --> Config Class Initialized
INFO - 2021-05-21 02:11:15 --> Hooks Class Initialized
DEBUG - 2021-05-21 02:11:15 --> UTF-8 Support Enabled
INFO - 2021-05-21 02:11:15 --> Utf8 Class Initialized
INFO - 2021-05-21 02:11:15 --> URI Class Initialized
DEBUG - 2021-05-21 02:11:15 --> No URI present. Default controller set.
INFO - 2021-05-21 02:11:15 --> Router Class Initialized
INFO - 2021-05-21 02:11:15 --> Output Class Initialized
INFO - 2021-05-21 02:11:15 --> Security Class Initialized
DEBUG - 2021-05-21 02:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 02:11:15 --> Input Class Initialized
INFO - 2021-05-21 02:11:15 --> Language Class Initialized
INFO - 2021-05-21 02:11:15 --> Loader Class Initialized
INFO - 2021-05-21 02:11:15 --> Helper loaded: url_helper
INFO - 2021-05-21 02:11:15 --> Helper loaded: form_helper
INFO - 2021-05-21 02:11:15 --> Helper loaded: common_helper
INFO - 2021-05-21 02:11:15 --> Database Driver Class Initialized
DEBUG - 2021-05-21 02:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-21 02:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-21 02:11:15 --> Controller Class Initialized
INFO - 2021-05-21 02:11:15 --> Form Validation Class Initialized
DEBUG - 2021-05-21 02:11:15 --> Encrypt Class Initialized
DEBUG - 2021-05-21 02:11:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-21 02:11:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-21 02:11:15 --> Email Class Initialized
INFO - 2021-05-21 02:11:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-21 02:11:15 --> Calendar Class Initialized
INFO - 2021-05-21 02:11:15 --> Model "Login_model" initialized
INFO - 2021-05-21 02:11:15 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-21 02:11:15 --> Final output sent to browser
DEBUG - 2021-05-21 02:11:15 --> Total execution time: 0.1437
ERROR - 2021-05-21 10:09:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-21 10:09:03 --> Config Class Initialized
INFO - 2021-05-21 10:09:03 --> Hooks Class Initialized
DEBUG - 2021-05-21 10:09:03 --> UTF-8 Support Enabled
INFO - 2021-05-21 10:09:03 --> Utf8 Class Initialized
INFO - 2021-05-21 10:09:03 --> URI Class Initialized
DEBUG - 2021-05-21 10:09:03 --> No URI present. Default controller set.
INFO - 2021-05-21 10:09:03 --> Router Class Initialized
INFO - 2021-05-21 10:09:03 --> Output Class Initialized
INFO - 2021-05-21 10:09:03 --> Security Class Initialized
DEBUG - 2021-05-21 10:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 10:09:03 --> Input Class Initialized
INFO - 2021-05-21 10:09:03 --> Language Class Initialized
INFO - 2021-05-21 10:09:03 --> Loader Class Initialized
INFO - 2021-05-21 10:09:03 --> Helper loaded: url_helper
INFO - 2021-05-21 10:09:03 --> Helper loaded: form_helper
INFO - 2021-05-21 10:09:03 --> Helper loaded: common_helper
INFO - 2021-05-21 10:09:03 --> Database Driver Class Initialized
DEBUG - 2021-05-21 10:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-21 10:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-21 10:09:03 --> Controller Class Initialized
INFO - 2021-05-21 10:09:03 --> Form Validation Class Initialized
DEBUG - 2021-05-21 10:09:03 --> Encrypt Class Initialized
DEBUG - 2021-05-21 10:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-21 10:09:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-21 10:09:03 --> Email Class Initialized
INFO - 2021-05-21 10:09:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-21 10:09:03 --> Calendar Class Initialized
INFO - 2021-05-21 10:09:03 --> Model "Login_model" initialized
INFO - 2021-05-21 10:09:03 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-21 10:09:03 --> Final output sent to browser
DEBUG - 2021-05-21 10:09:03 --> Total execution time: 0.1193
ERROR - 2021-05-21 10:09:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-21 10:09:04 --> Config Class Initialized
INFO - 2021-05-21 10:09:04 --> Hooks Class Initialized
DEBUG - 2021-05-21 10:09:04 --> UTF-8 Support Enabled
INFO - 2021-05-21 10:09:04 --> Utf8 Class Initialized
INFO - 2021-05-21 10:09:04 --> URI Class Initialized
INFO - 2021-05-21 10:09:04 --> Router Class Initialized
INFO - 2021-05-21 10:09:04 --> Output Class Initialized
INFO - 2021-05-21 10:09:04 --> Security Class Initialized
DEBUG - 2021-05-21 10:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 10:09:04 --> Input Class Initialized
INFO - 2021-05-21 10:09:04 --> Language Class Initialized
ERROR - 2021-05-21 10:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-21 17:41:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-21 17:41:35 --> Config Class Initialized
INFO - 2021-05-21 17:41:35 --> Hooks Class Initialized
DEBUG - 2021-05-21 17:41:35 --> UTF-8 Support Enabled
INFO - 2021-05-21 17:41:35 --> Utf8 Class Initialized
INFO - 2021-05-21 17:41:35 --> URI Class Initialized
DEBUG - 2021-05-21 17:41:35 --> No URI present. Default controller set.
INFO - 2021-05-21 17:41:35 --> Router Class Initialized
INFO - 2021-05-21 17:41:35 --> Output Class Initialized
INFO - 2021-05-21 17:41:35 --> Security Class Initialized
DEBUG - 2021-05-21 17:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-21 17:41:35 --> Input Class Initialized
INFO - 2021-05-21 17:41:35 --> Language Class Initialized
INFO - 2021-05-21 17:41:35 --> Loader Class Initialized
INFO - 2021-05-21 17:41:35 --> Helper loaded: url_helper
INFO - 2021-05-21 17:41:35 --> Helper loaded: form_helper
INFO - 2021-05-21 17:41:35 --> Helper loaded: common_helper
INFO - 2021-05-21 17:41:35 --> Database Driver Class Initialized
DEBUG - 2021-05-21 17:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-21 17:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-21 17:41:35 --> Controller Class Initialized
INFO - 2021-05-21 17:41:35 --> Form Validation Class Initialized
DEBUG - 2021-05-21 17:41:35 --> Encrypt Class Initialized
DEBUG - 2021-05-21 17:41:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-21 17:41:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-21 17:41:35 --> Email Class Initialized
INFO - 2021-05-21 17:41:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-21 17:41:35 --> Calendar Class Initialized
INFO - 2021-05-21 17:41:35 --> Model "Login_model" initialized
INFO - 2021-05-21 17:41:35 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-21 17:41:35 --> Final output sent to browser
DEBUG - 2021-05-21 17:41:35 --> Total execution time: 0.1700
