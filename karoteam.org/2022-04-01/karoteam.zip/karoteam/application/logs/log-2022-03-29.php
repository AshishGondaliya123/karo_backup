<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-29 00:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:07:18 --> Config Class Initialized
INFO - 2022-03-29 00:07:18 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:07:18 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:07:18 --> Utf8 Class Initialized
INFO - 2022-03-29 00:07:18 --> URI Class Initialized
INFO - 2022-03-29 00:07:18 --> Router Class Initialized
INFO - 2022-03-29 00:07:18 --> Output Class Initialized
INFO - 2022-03-29 00:07:18 --> Security Class Initialized
DEBUG - 2022-03-29 00:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:07:18 --> Input Class Initialized
INFO - 2022-03-29 00:07:18 --> Language Class Initialized
INFO - 2022-03-29 00:07:18 --> Loader Class Initialized
INFO - 2022-03-29 00:07:18 --> Helper loaded: url_helper
INFO - 2022-03-29 00:07:18 --> Helper loaded: form_helper
INFO - 2022-03-29 00:07:18 --> Helper loaded: common_helper
INFO - 2022-03-29 00:07:18 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:07:18 --> Controller Class Initialized
INFO - 2022-03-29 00:07:18 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:07:18 --> Encrypt Class Initialized
INFO - 2022-03-29 00:07:18 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:07:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:07:18 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:07:18 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:07:18 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:07:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:07:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:07:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:07:18 --> Final output sent to browser
DEBUG - 2022-03-29 00:07:18 --> Total execution time: 0.0887
ERROR - 2022-03-29 00:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:07:24 --> Config Class Initialized
INFO - 2022-03-29 00:07:24 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:07:24 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:07:24 --> Utf8 Class Initialized
INFO - 2022-03-29 00:07:24 --> URI Class Initialized
INFO - 2022-03-29 00:07:24 --> Router Class Initialized
INFO - 2022-03-29 00:07:24 --> Output Class Initialized
INFO - 2022-03-29 00:07:24 --> Security Class Initialized
DEBUG - 2022-03-29 00:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:07:24 --> Input Class Initialized
INFO - 2022-03-29 00:07:24 --> Language Class Initialized
INFO - 2022-03-29 00:07:24 --> Loader Class Initialized
INFO - 2022-03-29 00:07:24 --> Helper loaded: url_helper
INFO - 2022-03-29 00:07:24 --> Helper loaded: form_helper
INFO - 2022-03-29 00:07:24 --> Helper loaded: common_helper
INFO - 2022-03-29 00:07:24 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:07:24 --> Controller Class Initialized
INFO - 2022-03-29 00:07:24 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:07:24 --> Encrypt Class Initialized
INFO - 2022-03-29 00:07:24 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:07:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:07:24 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:07:24 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:07:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:07:24 --> Config Class Initialized
INFO - 2022-03-29 00:07:24 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:07:24 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:07:24 --> Utf8 Class Initialized
INFO - 2022-03-29 00:07:24 --> URI Class Initialized
INFO - 2022-03-29 00:07:24 --> Router Class Initialized
INFO - 2022-03-29 00:07:24 --> Output Class Initialized
INFO - 2022-03-29 00:07:24 --> Security Class Initialized
DEBUG - 2022-03-29 00:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:07:24 --> Input Class Initialized
INFO - 2022-03-29 00:07:24 --> Language Class Initialized
INFO - 2022-03-29 00:07:24 --> Loader Class Initialized
INFO - 2022-03-29 00:07:24 --> Helper loaded: url_helper
INFO - 2022-03-29 00:07:24 --> Helper loaded: form_helper
INFO - 2022-03-29 00:07:24 --> Helper loaded: common_helper
INFO - 2022-03-29 00:07:24 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:07:24 --> Controller Class Initialized
INFO - 2022-03-29 00:07:24 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:07:24 --> Encrypt Class Initialized
INFO - 2022-03-29 00:07:24 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:07:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:07:24 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:07:24 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:07:24 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:07:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:07:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:07:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:07:24 --> Final output sent to browser
DEBUG - 2022-03-29 00:07:24 --> Total execution time: 0.0257
ERROR - 2022-03-29 00:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:07:25 --> Config Class Initialized
INFO - 2022-03-29 00:07:25 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:07:25 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:07:25 --> Utf8 Class Initialized
INFO - 2022-03-29 00:07:25 --> URI Class Initialized
INFO - 2022-03-29 00:07:25 --> Router Class Initialized
INFO - 2022-03-29 00:07:25 --> Output Class Initialized
INFO - 2022-03-29 00:07:25 --> Security Class Initialized
DEBUG - 2022-03-29 00:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:07:25 --> Input Class Initialized
INFO - 2022-03-29 00:07:25 --> Language Class Initialized
INFO - 2022-03-29 00:07:25 --> Loader Class Initialized
INFO - 2022-03-29 00:07:25 --> Helper loaded: url_helper
INFO - 2022-03-29 00:07:25 --> Helper loaded: form_helper
INFO - 2022-03-29 00:07:25 --> Helper loaded: common_helper
INFO - 2022-03-29 00:07:25 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:07:25 --> Controller Class Initialized
INFO - 2022-03-29 00:07:25 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:07:25 --> Encrypt Class Initialized
INFO - 2022-03-29 00:07:25 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:07:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:07:25 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:07:25 --> Model "Users_model" initialized
INFO - 2022-03-29 00:07:25 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:07:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:07:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:07:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:07:25 --> Final output sent to browser
DEBUG - 2022-03-29 00:07:25 --> Total execution time: 0.0486
ERROR - 2022-03-29 00:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:08:08 --> Config Class Initialized
INFO - 2022-03-29 00:08:08 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:08:08 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:08:08 --> Utf8 Class Initialized
INFO - 2022-03-29 00:08:08 --> URI Class Initialized
INFO - 2022-03-29 00:08:08 --> Router Class Initialized
INFO - 2022-03-29 00:08:08 --> Output Class Initialized
INFO - 2022-03-29 00:08:08 --> Security Class Initialized
DEBUG - 2022-03-29 00:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:08:08 --> Input Class Initialized
INFO - 2022-03-29 00:08:08 --> Language Class Initialized
INFO - 2022-03-29 00:08:08 --> Loader Class Initialized
INFO - 2022-03-29 00:08:08 --> Helper loaded: url_helper
INFO - 2022-03-29 00:08:08 --> Helper loaded: form_helper
INFO - 2022-03-29 00:08:08 --> Helper loaded: common_helper
INFO - 2022-03-29 00:08:08 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:08:08 --> Controller Class Initialized
INFO - 2022-03-29 00:08:08 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:08:08 --> Encrypt Class Initialized
INFO - 2022-03-29 00:08:08 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:08:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:08:08 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:08:08 --> Model "Users_model" initialized
INFO - 2022-03-29 00:08:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:08:08 --> Config Class Initialized
INFO - 2022-03-29 00:08:08 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:08:08 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:08:08 --> Utf8 Class Initialized
INFO - 2022-03-29 00:08:08 --> URI Class Initialized
INFO - 2022-03-29 00:08:08 --> Router Class Initialized
INFO - 2022-03-29 00:08:08 --> Output Class Initialized
INFO - 2022-03-29 00:08:08 --> Security Class Initialized
DEBUG - 2022-03-29 00:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:08:08 --> Input Class Initialized
INFO - 2022-03-29 00:08:08 --> Language Class Initialized
INFO - 2022-03-29 00:08:08 --> Loader Class Initialized
INFO - 2022-03-29 00:08:08 --> Helper loaded: url_helper
INFO - 2022-03-29 00:08:08 --> Helper loaded: form_helper
INFO - 2022-03-29 00:08:08 --> Helper loaded: common_helper
INFO - 2022-03-29 00:08:08 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:08:08 --> Controller Class Initialized
INFO - 2022-03-29 00:08:08 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:08:08 --> Encrypt Class Initialized
INFO - 2022-03-29 00:08:08 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:08:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:08:08 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:08:08 --> Model "Users_model" initialized
INFO - 2022-03-29 00:08:08 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:08:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:08:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:08:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:08:08 --> Final output sent to browser
DEBUG - 2022-03-29 00:08:08 --> Total execution time: 0.0371
ERROR - 2022-03-29 00:08:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:08:12 --> Config Class Initialized
INFO - 2022-03-29 00:08:12 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:08:12 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:08:12 --> Utf8 Class Initialized
INFO - 2022-03-29 00:08:12 --> URI Class Initialized
INFO - 2022-03-29 00:08:12 --> Router Class Initialized
INFO - 2022-03-29 00:08:12 --> Output Class Initialized
INFO - 2022-03-29 00:08:12 --> Security Class Initialized
DEBUG - 2022-03-29 00:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:08:12 --> Input Class Initialized
INFO - 2022-03-29 00:08:12 --> Language Class Initialized
INFO - 2022-03-29 00:08:12 --> Loader Class Initialized
INFO - 2022-03-29 00:08:12 --> Helper loaded: url_helper
INFO - 2022-03-29 00:08:12 --> Helper loaded: form_helper
INFO - 2022-03-29 00:08:12 --> Helper loaded: common_helper
INFO - 2022-03-29 00:08:12 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:08:12 --> Controller Class Initialized
INFO - 2022-03-29 00:08:12 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:08:12 --> Encrypt Class Initialized
INFO - 2022-03-29 00:08:12 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:08:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:08:12 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:08:12 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:08:12 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:08:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:08:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 00:08:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:08:12 --> Final output sent to browser
DEBUG - 2022-03-29 00:08:12 --> Total execution time: 0.0582
ERROR - 2022-03-29 00:08:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:08:19 --> Config Class Initialized
INFO - 2022-03-29 00:08:19 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:08:19 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:08:19 --> Utf8 Class Initialized
INFO - 2022-03-29 00:08:19 --> URI Class Initialized
INFO - 2022-03-29 00:08:19 --> Router Class Initialized
INFO - 2022-03-29 00:08:19 --> Output Class Initialized
INFO - 2022-03-29 00:08:19 --> Security Class Initialized
DEBUG - 2022-03-29 00:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:08:19 --> Input Class Initialized
INFO - 2022-03-29 00:08:19 --> Language Class Initialized
INFO - 2022-03-29 00:08:19 --> Loader Class Initialized
INFO - 2022-03-29 00:08:19 --> Helper loaded: url_helper
INFO - 2022-03-29 00:08:19 --> Helper loaded: form_helper
INFO - 2022-03-29 00:08:19 --> Helper loaded: common_helper
INFO - 2022-03-29 00:08:19 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:08:19 --> Controller Class Initialized
INFO - 2022-03-29 00:08:19 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:08:19 --> Encrypt Class Initialized
INFO - 2022-03-29 00:08:19 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:08:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:08:19 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:08:19 --> Model "Users_model" initialized
INFO - 2022-03-29 00:08:19 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:08:19 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 00:08:20 --> Final output sent to browser
DEBUG - 2022-03-29 00:08:20 --> Total execution time: 1.0390
ERROR - 2022-03-29 00:08:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:08:43 --> Config Class Initialized
INFO - 2022-03-29 00:08:43 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:08:43 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:08:43 --> Utf8 Class Initialized
INFO - 2022-03-29 00:08:43 --> URI Class Initialized
INFO - 2022-03-29 00:08:43 --> Router Class Initialized
INFO - 2022-03-29 00:08:43 --> Output Class Initialized
INFO - 2022-03-29 00:08:43 --> Security Class Initialized
DEBUG - 2022-03-29 00:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:08:43 --> Input Class Initialized
INFO - 2022-03-29 00:08:43 --> Language Class Initialized
INFO - 2022-03-29 00:08:43 --> Loader Class Initialized
INFO - 2022-03-29 00:08:43 --> Helper loaded: url_helper
INFO - 2022-03-29 00:08:43 --> Helper loaded: form_helper
INFO - 2022-03-29 00:08:43 --> Helper loaded: common_helper
INFO - 2022-03-29 00:08:43 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:08:43 --> Controller Class Initialized
INFO - 2022-03-29 00:08:43 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:08:43 --> Encrypt Class Initialized
INFO - 2022-03-29 00:08:43 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:08:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:08:43 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:08:43 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:08:43 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:08:43 --> Upload Class Initialized
INFO - 2022-03-29 00:08:43 --> Final output sent to browser
DEBUG - 2022-03-29 00:08:43 --> Total execution time: 0.0664
ERROR - 2022-03-29 00:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:08:56 --> Config Class Initialized
INFO - 2022-03-29 00:08:56 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:08:56 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:08:56 --> Utf8 Class Initialized
INFO - 2022-03-29 00:08:56 --> URI Class Initialized
INFO - 2022-03-29 00:08:56 --> Router Class Initialized
INFO - 2022-03-29 00:08:56 --> Output Class Initialized
INFO - 2022-03-29 00:08:56 --> Security Class Initialized
DEBUG - 2022-03-29 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:08:56 --> Input Class Initialized
INFO - 2022-03-29 00:08:56 --> Language Class Initialized
INFO - 2022-03-29 00:08:56 --> Loader Class Initialized
INFO - 2022-03-29 00:08:56 --> Helper loaded: url_helper
INFO - 2022-03-29 00:08:56 --> Helper loaded: form_helper
INFO - 2022-03-29 00:08:56 --> Helper loaded: common_helper
INFO - 2022-03-29 00:08:56 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:08:56 --> Controller Class Initialized
INFO - 2022-03-29 00:08:56 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:08:56 --> Encrypt Class Initialized
INFO - 2022-03-29 00:08:56 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:08:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:08:56 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:08:56 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:08:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:08:56 --> Config Class Initialized
INFO - 2022-03-29 00:08:56 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:08:56 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:08:56 --> Utf8 Class Initialized
INFO - 2022-03-29 00:08:56 --> URI Class Initialized
INFO - 2022-03-29 00:08:56 --> Router Class Initialized
INFO - 2022-03-29 00:08:56 --> Output Class Initialized
INFO - 2022-03-29 00:08:56 --> Security Class Initialized
DEBUG - 2022-03-29 00:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:08:56 --> Input Class Initialized
INFO - 2022-03-29 00:08:56 --> Language Class Initialized
INFO - 2022-03-29 00:08:56 --> Loader Class Initialized
INFO - 2022-03-29 00:08:56 --> Helper loaded: url_helper
INFO - 2022-03-29 00:08:56 --> Helper loaded: form_helper
INFO - 2022-03-29 00:08:56 --> Helper loaded: common_helper
INFO - 2022-03-29 00:08:56 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:08:56 --> Controller Class Initialized
INFO - 2022-03-29 00:08:56 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:08:56 --> Encrypt Class Initialized
INFO - 2022-03-29 00:08:56 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:08:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:08:56 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:08:56 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:08:56 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:08:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:08:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:08:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:08:56 --> Final output sent to browser
DEBUG - 2022-03-29 00:08:56 --> Total execution time: 0.0264
ERROR - 2022-03-29 00:08:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:08:57 --> Config Class Initialized
INFO - 2022-03-29 00:08:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:08:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:08:57 --> Utf8 Class Initialized
INFO - 2022-03-29 00:08:57 --> URI Class Initialized
INFO - 2022-03-29 00:08:57 --> Router Class Initialized
INFO - 2022-03-29 00:08:57 --> Output Class Initialized
INFO - 2022-03-29 00:08:57 --> Security Class Initialized
DEBUG - 2022-03-29 00:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:08:57 --> Input Class Initialized
INFO - 2022-03-29 00:08:57 --> Language Class Initialized
INFO - 2022-03-29 00:08:57 --> Loader Class Initialized
INFO - 2022-03-29 00:08:57 --> Helper loaded: url_helper
INFO - 2022-03-29 00:08:57 --> Helper loaded: form_helper
INFO - 2022-03-29 00:08:57 --> Helper loaded: common_helper
INFO - 2022-03-29 00:08:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:08:57 --> Controller Class Initialized
INFO - 2022-03-29 00:08:57 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:08:57 --> Encrypt Class Initialized
INFO - 2022-03-29 00:08:57 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:08:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:08:57 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:08:57 --> Model "Users_model" initialized
INFO - 2022-03-29 00:08:57 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:08:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:08:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:08:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:08:57 --> Final output sent to browser
DEBUG - 2022-03-29 00:08:57 --> Total execution time: 0.0384
ERROR - 2022-03-29 00:09:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:09:42 --> Config Class Initialized
INFO - 2022-03-29 00:09:42 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:09:42 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:09:42 --> Utf8 Class Initialized
INFO - 2022-03-29 00:09:42 --> URI Class Initialized
DEBUG - 2022-03-29 00:09:42 --> No URI present. Default controller set.
INFO - 2022-03-29 00:09:42 --> Router Class Initialized
INFO - 2022-03-29 00:09:42 --> Output Class Initialized
INFO - 2022-03-29 00:09:42 --> Security Class Initialized
DEBUG - 2022-03-29 00:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:09:42 --> Input Class Initialized
INFO - 2022-03-29 00:09:42 --> Language Class Initialized
INFO - 2022-03-29 00:09:42 --> Loader Class Initialized
INFO - 2022-03-29 00:09:42 --> Helper loaded: url_helper
INFO - 2022-03-29 00:09:42 --> Helper loaded: form_helper
INFO - 2022-03-29 00:09:42 --> Helper loaded: common_helper
INFO - 2022-03-29 00:09:42 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:09:42 --> Controller Class Initialized
INFO - 2022-03-29 00:09:42 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:09:42 --> Encrypt Class Initialized
DEBUG - 2022-03-29 00:09:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 00:09:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 00:09:42 --> Email Class Initialized
INFO - 2022-03-29 00:09:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 00:09:42 --> Calendar Class Initialized
INFO - 2022-03-29 00:09:42 --> Model "Login_model" initialized
INFO - 2022-03-29 00:09:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 00:09:42 --> Final output sent to browser
DEBUG - 2022-03-29 00:09:42 --> Total execution time: 0.0188
ERROR - 2022-03-29 00:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:16:29 --> Config Class Initialized
INFO - 2022-03-29 00:16:30 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:16:30 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:16:30 --> Utf8 Class Initialized
INFO - 2022-03-29 00:16:30 --> URI Class Initialized
INFO - 2022-03-29 00:16:30 --> Router Class Initialized
INFO - 2022-03-29 00:16:30 --> Output Class Initialized
INFO - 2022-03-29 00:16:30 --> Security Class Initialized
DEBUG - 2022-03-29 00:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:16:30 --> Input Class Initialized
INFO - 2022-03-29 00:16:30 --> Language Class Initialized
INFO - 2022-03-29 00:16:30 --> Loader Class Initialized
INFO - 2022-03-29 00:16:30 --> Helper loaded: url_helper
INFO - 2022-03-29 00:16:30 --> Helper loaded: form_helper
INFO - 2022-03-29 00:16:30 --> Helper loaded: common_helper
INFO - 2022-03-29 00:16:30 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:16:30 --> Controller Class Initialized
INFO - 2022-03-29 00:16:30 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:16:30 --> Encrypt Class Initialized
INFO - 2022-03-29 00:16:30 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:16:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:16:30 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:16:30 --> Model "Users_model" initialized
INFO - 2022-03-29 00:16:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:16:30 --> Config Class Initialized
INFO - 2022-03-29 00:16:30 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:16:30 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:16:30 --> Utf8 Class Initialized
INFO - 2022-03-29 00:16:30 --> URI Class Initialized
INFO - 2022-03-29 00:16:30 --> Router Class Initialized
INFO - 2022-03-29 00:16:30 --> Output Class Initialized
INFO - 2022-03-29 00:16:30 --> Security Class Initialized
DEBUG - 2022-03-29 00:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:16:30 --> Input Class Initialized
INFO - 2022-03-29 00:16:30 --> Language Class Initialized
INFO - 2022-03-29 00:16:30 --> Loader Class Initialized
INFO - 2022-03-29 00:16:30 --> Helper loaded: url_helper
INFO - 2022-03-29 00:16:30 --> Helper loaded: form_helper
INFO - 2022-03-29 00:16:30 --> Helper loaded: common_helper
INFO - 2022-03-29 00:16:30 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:16:30 --> Controller Class Initialized
INFO - 2022-03-29 00:16:30 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:16:30 --> Encrypt Class Initialized
INFO - 2022-03-29 00:16:30 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:16:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:16:30 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:16:30 --> Model "Users_model" initialized
INFO - 2022-03-29 00:16:30 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:16:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:16:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:16:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:16:30 --> Final output sent to browser
DEBUG - 2022-03-29 00:16:30 --> Total execution time: 0.0466
ERROR - 2022-03-29 00:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:24:20 --> Config Class Initialized
INFO - 2022-03-29 00:24:20 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:24:20 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:24:20 --> Utf8 Class Initialized
INFO - 2022-03-29 00:24:20 --> URI Class Initialized
DEBUG - 2022-03-29 00:24:20 --> No URI present. Default controller set.
INFO - 2022-03-29 00:24:20 --> Router Class Initialized
INFO - 2022-03-29 00:24:20 --> Output Class Initialized
INFO - 2022-03-29 00:24:20 --> Security Class Initialized
DEBUG - 2022-03-29 00:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:24:20 --> Input Class Initialized
INFO - 2022-03-29 00:24:20 --> Language Class Initialized
INFO - 2022-03-29 00:24:20 --> Loader Class Initialized
INFO - 2022-03-29 00:24:20 --> Helper loaded: url_helper
INFO - 2022-03-29 00:24:20 --> Helper loaded: form_helper
INFO - 2022-03-29 00:24:20 --> Helper loaded: common_helper
INFO - 2022-03-29 00:24:20 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:24:20 --> Controller Class Initialized
INFO - 2022-03-29 00:24:20 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:24:20 --> Encrypt Class Initialized
DEBUG - 2022-03-29 00:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 00:24:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 00:24:20 --> Email Class Initialized
INFO - 2022-03-29 00:24:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 00:24:20 --> Calendar Class Initialized
INFO - 2022-03-29 00:24:20 --> Model "Login_model" initialized
INFO - 2022-03-29 00:24:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 00:24:20 --> Final output sent to browser
DEBUG - 2022-03-29 00:24:20 --> Total execution time: 0.0721
ERROR - 2022-03-29 00:24:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:24:24 --> Config Class Initialized
INFO - 2022-03-29 00:24:24 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:24:24 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:24:24 --> Utf8 Class Initialized
INFO - 2022-03-29 00:24:24 --> URI Class Initialized
INFO - 2022-03-29 00:24:24 --> Router Class Initialized
INFO - 2022-03-29 00:24:24 --> Output Class Initialized
INFO - 2022-03-29 00:24:24 --> Security Class Initialized
DEBUG - 2022-03-29 00:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:24:24 --> Input Class Initialized
INFO - 2022-03-29 00:24:24 --> Language Class Initialized
INFO - 2022-03-29 00:24:24 --> Loader Class Initialized
INFO - 2022-03-29 00:24:24 --> Helper loaded: url_helper
INFO - 2022-03-29 00:24:24 --> Helper loaded: form_helper
INFO - 2022-03-29 00:24:24 --> Helper loaded: common_helper
INFO - 2022-03-29 00:24:24 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:24:24 --> Controller Class Initialized
INFO - 2022-03-29 00:24:24 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:24:24 --> Encrypt Class Initialized
DEBUG - 2022-03-29 00:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 00:24:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 00:24:24 --> Email Class Initialized
INFO - 2022-03-29 00:24:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 00:24:24 --> Calendar Class Initialized
INFO - 2022-03-29 00:24:24 --> Model "Login_model" initialized
INFO - 2022-03-29 00:24:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-29 00:24:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:24:24 --> Config Class Initialized
INFO - 2022-03-29 00:24:24 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:24:24 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:24:24 --> Utf8 Class Initialized
INFO - 2022-03-29 00:24:24 --> URI Class Initialized
INFO - 2022-03-29 00:24:24 --> Router Class Initialized
INFO - 2022-03-29 00:24:24 --> Output Class Initialized
INFO - 2022-03-29 00:24:24 --> Security Class Initialized
DEBUG - 2022-03-29 00:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:24:24 --> Input Class Initialized
INFO - 2022-03-29 00:24:24 --> Language Class Initialized
INFO - 2022-03-29 00:24:24 --> Loader Class Initialized
INFO - 2022-03-29 00:24:24 --> Helper loaded: url_helper
INFO - 2022-03-29 00:24:24 --> Helper loaded: form_helper
INFO - 2022-03-29 00:24:24 --> Helper loaded: common_helper
INFO - 2022-03-29 00:24:24 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:24:24 --> Controller Class Initialized
INFO - 2022-03-29 00:24:24 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:24:24 --> Encrypt Class Initialized
INFO - 2022-03-29 00:24:24 --> Model "Login_model" initialized
INFO - 2022-03-29 00:24:24 --> Model "Dashboard_model" initialized
INFO - 2022-03-29 00:24:24 --> Model "Case_model" initialized
INFO - 2022-03-29 00:24:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:24:44 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-29 00:24:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:24:44 --> Final output sent to browser
DEBUG - 2022-03-29 00:24:44 --> Total execution time: 19.8304
ERROR - 2022-03-29 00:24:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:24:55 --> Config Class Initialized
INFO - 2022-03-29 00:24:55 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:24:55 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:24:55 --> Utf8 Class Initialized
INFO - 2022-03-29 00:24:55 --> URI Class Initialized
INFO - 2022-03-29 00:24:55 --> Router Class Initialized
INFO - 2022-03-29 00:24:55 --> Output Class Initialized
INFO - 2022-03-29 00:24:55 --> Security Class Initialized
DEBUG - 2022-03-29 00:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:24:55 --> Input Class Initialized
INFO - 2022-03-29 00:24:55 --> Language Class Initialized
INFO - 2022-03-29 00:24:55 --> Loader Class Initialized
INFO - 2022-03-29 00:24:55 --> Helper loaded: url_helper
INFO - 2022-03-29 00:24:55 --> Helper loaded: form_helper
INFO - 2022-03-29 00:24:55 --> Helper loaded: common_helper
INFO - 2022-03-29 00:24:55 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:24:55 --> Controller Class Initialized
INFO - 2022-03-29 00:24:55 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:24:55 --> Encrypt Class Initialized
INFO - 2022-03-29 00:24:55 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:24:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:24:55 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:24:55 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:24:55 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:24:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:24:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:24:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:24:55 --> Final output sent to browser
DEBUG - 2022-03-29 00:24:55 --> Total execution time: 0.0202
ERROR - 2022-03-29 00:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:25:23 --> Config Class Initialized
INFO - 2022-03-29 00:25:23 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:25:23 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:25:23 --> Utf8 Class Initialized
INFO - 2022-03-29 00:25:23 --> URI Class Initialized
INFO - 2022-03-29 00:25:23 --> Router Class Initialized
INFO - 2022-03-29 00:25:23 --> Output Class Initialized
INFO - 2022-03-29 00:25:23 --> Security Class Initialized
DEBUG - 2022-03-29 00:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:25:23 --> Input Class Initialized
INFO - 2022-03-29 00:25:23 --> Language Class Initialized
INFO - 2022-03-29 00:25:23 --> Loader Class Initialized
INFO - 2022-03-29 00:25:23 --> Helper loaded: url_helper
INFO - 2022-03-29 00:25:23 --> Helper loaded: form_helper
INFO - 2022-03-29 00:25:23 --> Helper loaded: common_helper
INFO - 2022-03-29 00:25:23 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:25:23 --> Controller Class Initialized
INFO - 2022-03-29 00:25:23 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:25:23 --> Encrypt Class Initialized
INFO - 2022-03-29 00:25:23 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:25:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:25:23 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:25:23 --> Model "Users_model" initialized
INFO - 2022-03-29 00:25:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:25:23 --> Config Class Initialized
INFO - 2022-03-29 00:25:23 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:25:23 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:25:23 --> Utf8 Class Initialized
INFO - 2022-03-29 00:25:23 --> URI Class Initialized
INFO - 2022-03-29 00:25:23 --> Router Class Initialized
INFO - 2022-03-29 00:25:23 --> Output Class Initialized
INFO - 2022-03-29 00:25:23 --> Security Class Initialized
DEBUG - 2022-03-29 00:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:25:23 --> Input Class Initialized
INFO - 2022-03-29 00:25:23 --> Language Class Initialized
INFO - 2022-03-29 00:25:23 --> Loader Class Initialized
INFO - 2022-03-29 00:25:23 --> Helper loaded: url_helper
INFO - 2022-03-29 00:25:23 --> Helper loaded: form_helper
INFO - 2022-03-29 00:25:23 --> Helper loaded: common_helper
INFO - 2022-03-29 00:25:23 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:25:23 --> Controller Class Initialized
INFO - 2022-03-29 00:25:23 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:25:23 --> Encrypt Class Initialized
INFO - 2022-03-29 00:25:23 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:25:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:25:23 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:25:23 --> Model "Users_model" initialized
INFO - 2022-03-29 00:25:23 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:25:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:25:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:25:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:25:23 --> Final output sent to browser
DEBUG - 2022-03-29 00:25:23 --> Total execution time: 0.0807
ERROR - 2022-03-29 00:30:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:30:09 --> Config Class Initialized
INFO - 2022-03-29 00:30:09 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:30:09 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:30:09 --> Utf8 Class Initialized
INFO - 2022-03-29 00:30:09 --> URI Class Initialized
INFO - 2022-03-29 00:30:09 --> Router Class Initialized
INFO - 2022-03-29 00:30:09 --> Output Class Initialized
INFO - 2022-03-29 00:30:09 --> Security Class Initialized
DEBUG - 2022-03-29 00:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:30:09 --> Input Class Initialized
INFO - 2022-03-29 00:30:09 --> Language Class Initialized
INFO - 2022-03-29 00:30:09 --> Loader Class Initialized
INFO - 2022-03-29 00:30:09 --> Helper loaded: url_helper
INFO - 2022-03-29 00:30:09 --> Helper loaded: form_helper
INFO - 2022-03-29 00:30:09 --> Helper loaded: common_helper
INFO - 2022-03-29 00:30:09 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:30:09 --> Controller Class Initialized
INFO - 2022-03-29 00:30:09 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:30:09 --> Final output sent to browser
DEBUG - 2022-03-29 00:30:09 --> Total execution time: 0.0546
ERROR - 2022-03-29 00:30:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:30:48 --> Config Class Initialized
INFO - 2022-03-29 00:30:48 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:30:48 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:30:48 --> Utf8 Class Initialized
INFO - 2022-03-29 00:30:48 --> URI Class Initialized
INFO - 2022-03-29 00:30:48 --> Router Class Initialized
INFO - 2022-03-29 00:30:48 --> Output Class Initialized
INFO - 2022-03-29 00:30:48 --> Security Class Initialized
DEBUG - 2022-03-29 00:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:30:48 --> Input Class Initialized
INFO - 2022-03-29 00:30:48 --> Language Class Initialized
INFO - 2022-03-29 00:30:48 --> Loader Class Initialized
INFO - 2022-03-29 00:30:48 --> Helper loaded: url_helper
INFO - 2022-03-29 00:30:48 --> Helper loaded: form_helper
INFO - 2022-03-29 00:30:48 --> Helper loaded: common_helper
INFO - 2022-03-29 00:30:48 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:30:48 --> Controller Class Initialized
INFO - 2022-03-29 00:30:48 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:30:48 --> Encrypt Class Initialized
INFO - 2022-03-29 00:30:48 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:30:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:30:48 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:30:48 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:30:48 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:30:48 --> Final output sent to browser
DEBUG - 2022-03-29 00:30:48 --> Total execution time: 0.0260
ERROR - 2022-03-29 00:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:31:01 --> Config Class Initialized
INFO - 2022-03-29 00:31:01 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:31:01 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:31:01 --> Utf8 Class Initialized
INFO - 2022-03-29 00:31:01 --> URI Class Initialized
INFO - 2022-03-29 00:31:01 --> Router Class Initialized
INFO - 2022-03-29 00:31:01 --> Output Class Initialized
INFO - 2022-03-29 00:31:01 --> Security Class Initialized
DEBUG - 2022-03-29 00:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:31:01 --> Input Class Initialized
INFO - 2022-03-29 00:31:01 --> Language Class Initialized
INFO - 2022-03-29 00:31:01 --> Loader Class Initialized
INFO - 2022-03-29 00:31:01 --> Helper loaded: url_helper
INFO - 2022-03-29 00:31:01 --> Helper loaded: form_helper
INFO - 2022-03-29 00:31:01 --> Helper loaded: common_helper
INFO - 2022-03-29 00:31:01 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:31:01 --> Controller Class Initialized
INFO - 2022-03-29 00:31:01 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:31:01 --> Encrypt Class Initialized
INFO - 2022-03-29 00:31:01 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:31:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:31:01 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:31:01 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:31:01 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:31:01 --> Final output sent to browser
DEBUG - 2022-03-29 00:31:01 --> Total execution time: 0.0125
ERROR - 2022-03-29 00:31:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:31:50 --> Config Class Initialized
INFO - 2022-03-29 00:31:50 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:31:50 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:31:50 --> Utf8 Class Initialized
INFO - 2022-03-29 00:31:50 --> URI Class Initialized
INFO - 2022-03-29 00:31:50 --> Router Class Initialized
INFO - 2022-03-29 00:31:50 --> Output Class Initialized
INFO - 2022-03-29 00:31:50 --> Security Class Initialized
DEBUG - 2022-03-29 00:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:31:50 --> Input Class Initialized
INFO - 2022-03-29 00:31:50 --> Language Class Initialized
INFO - 2022-03-29 00:31:50 --> Loader Class Initialized
INFO - 2022-03-29 00:31:50 --> Helper loaded: url_helper
INFO - 2022-03-29 00:31:50 --> Helper loaded: form_helper
INFO - 2022-03-29 00:31:50 --> Helper loaded: common_helper
INFO - 2022-03-29 00:31:50 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:31:50 --> Controller Class Initialized
INFO - 2022-03-29 00:31:50 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:31:50 --> Encrypt Class Initialized
INFO - 2022-03-29 00:31:50 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:31:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:31:50 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:31:50 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:31:50 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:31:50 --> Final output sent to browser
DEBUG - 2022-03-29 00:31:50 --> Total execution time: 0.0100
ERROR - 2022-03-29 00:32:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:32:46 --> Config Class Initialized
INFO - 2022-03-29 00:32:46 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:32:46 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:32:46 --> Utf8 Class Initialized
INFO - 2022-03-29 00:32:46 --> URI Class Initialized
INFO - 2022-03-29 00:32:46 --> Router Class Initialized
INFO - 2022-03-29 00:32:46 --> Output Class Initialized
INFO - 2022-03-29 00:32:46 --> Security Class Initialized
DEBUG - 2022-03-29 00:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:32:46 --> Input Class Initialized
INFO - 2022-03-29 00:32:46 --> Language Class Initialized
INFO - 2022-03-29 00:32:46 --> Loader Class Initialized
INFO - 2022-03-29 00:32:46 --> Helper loaded: url_helper
INFO - 2022-03-29 00:32:46 --> Helper loaded: form_helper
INFO - 2022-03-29 00:32:46 --> Helper loaded: common_helper
INFO - 2022-03-29 00:32:46 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:32:46 --> Controller Class Initialized
INFO - 2022-03-29 00:32:46 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:32:46 --> Encrypt Class Initialized
INFO - 2022-03-29 00:32:46 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:32:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:32:46 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:32:46 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:32:46 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:32:46 --> Final output sent to browser
DEBUG - 2022-03-29 00:32:46 --> Total execution time: 0.0117
ERROR - 2022-03-29 00:33:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:33:54 --> Config Class Initialized
INFO - 2022-03-29 00:33:54 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:33:54 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:33:54 --> Utf8 Class Initialized
INFO - 2022-03-29 00:33:54 --> URI Class Initialized
INFO - 2022-03-29 00:33:54 --> Router Class Initialized
INFO - 2022-03-29 00:33:54 --> Output Class Initialized
INFO - 2022-03-29 00:33:54 --> Security Class Initialized
DEBUG - 2022-03-29 00:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:33:54 --> Input Class Initialized
INFO - 2022-03-29 00:33:54 --> Language Class Initialized
INFO - 2022-03-29 00:33:54 --> Loader Class Initialized
INFO - 2022-03-29 00:33:54 --> Helper loaded: url_helper
INFO - 2022-03-29 00:33:54 --> Helper loaded: form_helper
INFO - 2022-03-29 00:33:54 --> Helper loaded: common_helper
INFO - 2022-03-29 00:33:54 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:33:54 --> Controller Class Initialized
INFO - 2022-03-29 00:33:54 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:33:54 --> Encrypt Class Initialized
INFO - 2022-03-29 00:33:54 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:33:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:33:54 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:33:54 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:33:54 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:33:54 --> Final output sent to browser
DEBUG - 2022-03-29 00:33:54 --> Total execution time: 0.0126
ERROR - 2022-03-29 00:33:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:33:57 --> Config Class Initialized
INFO - 2022-03-29 00:33:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:33:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:33:57 --> Utf8 Class Initialized
INFO - 2022-03-29 00:33:57 --> URI Class Initialized
INFO - 2022-03-29 00:33:57 --> Router Class Initialized
INFO - 2022-03-29 00:33:57 --> Output Class Initialized
INFO - 2022-03-29 00:33:57 --> Security Class Initialized
DEBUG - 2022-03-29 00:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:33:57 --> Input Class Initialized
INFO - 2022-03-29 00:33:57 --> Language Class Initialized
INFO - 2022-03-29 00:33:57 --> Loader Class Initialized
INFO - 2022-03-29 00:33:57 --> Helper loaded: url_helper
INFO - 2022-03-29 00:33:57 --> Helper loaded: form_helper
INFO - 2022-03-29 00:33:57 --> Helper loaded: common_helper
INFO - 2022-03-29 00:33:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:33:57 --> Controller Class Initialized
INFO - 2022-03-29 00:33:57 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:33:57 --> Final output sent to browser
DEBUG - 2022-03-29 00:33:57 --> Total execution time: 0.0100
ERROR - 2022-03-29 00:34:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:34:01 --> Config Class Initialized
INFO - 2022-03-29 00:34:01 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:34:01 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:34:01 --> Utf8 Class Initialized
INFO - 2022-03-29 00:34:01 --> URI Class Initialized
INFO - 2022-03-29 00:34:01 --> Router Class Initialized
INFO - 2022-03-29 00:34:01 --> Output Class Initialized
INFO - 2022-03-29 00:34:01 --> Security Class Initialized
DEBUG - 2022-03-29 00:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:34:01 --> Input Class Initialized
INFO - 2022-03-29 00:34:01 --> Language Class Initialized
INFO - 2022-03-29 00:34:01 --> Loader Class Initialized
INFO - 2022-03-29 00:34:01 --> Helper loaded: url_helper
INFO - 2022-03-29 00:34:01 --> Helper loaded: form_helper
INFO - 2022-03-29 00:34:01 --> Helper loaded: common_helper
INFO - 2022-03-29 00:34:01 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:34:01 --> Controller Class Initialized
INFO - 2022-03-29 00:34:01 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:34:01 --> Encrypt Class Initialized
INFO - 2022-03-29 00:34:01 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:34:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:34:01 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:34:01 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:34:01 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:34:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:34:02 --> Config Class Initialized
INFO - 2022-03-29 00:34:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:34:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:34:02 --> Utf8 Class Initialized
INFO - 2022-03-29 00:34:02 --> URI Class Initialized
INFO - 2022-03-29 00:34:02 --> Router Class Initialized
INFO - 2022-03-29 00:34:02 --> Output Class Initialized
INFO - 2022-03-29 00:34:02 --> Security Class Initialized
DEBUG - 2022-03-29 00:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:34:02 --> Input Class Initialized
INFO - 2022-03-29 00:34:02 --> Language Class Initialized
INFO - 2022-03-29 00:34:02 --> Loader Class Initialized
INFO - 2022-03-29 00:34:02 --> Helper loaded: url_helper
INFO - 2022-03-29 00:34:02 --> Helper loaded: form_helper
INFO - 2022-03-29 00:34:02 --> Helper loaded: common_helper
INFO - 2022-03-29 00:34:02 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:34:02 --> Controller Class Initialized
INFO - 2022-03-29 00:34:02 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:34:02 --> Encrypt Class Initialized
INFO - 2022-03-29 00:34:02 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:34:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:34:02 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:34:02 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:34:02 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:34:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:34:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:34:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:34:02 --> Final output sent to browser
DEBUG - 2022-03-29 00:34:02 --> Total execution time: 0.0377
ERROR - 2022-03-29 00:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:34:03 --> Config Class Initialized
INFO - 2022-03-29 00:34:03 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:34:03 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:34:03 --> Utf8 Class Initialized
INFO - 2022-03-29 00:34:03 --> URI Class Initialized
INFO - 2022-03-29 00:34:03 --> Router Class Initialized
INFO - 2022-03-29 00:34:03 --> Output Class Initialized
INFO - 2022-03-29 00:34:03 --> Security Class Initialized
DEBUG - 2022-03-29 00:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:34:03 --> Input Class Initialized
INFO - 2022-03-29 00:34:03 --> Language Class Initialized
INFO - 2022-03-29 00:34:03 --> Loader Class Initialized
INFO - 2022-03-29 00:34:03 --> Helper loaded: url_helper
INFO - 2022-03-29 00:34:03 --> Helper loaded: form_helper
INFO - 2022-03-29 00:34:03 --> Helper loaded: common_helper
INFO - 2022-03-29 00:34:03 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:34:03 --> Controller Class Initialized
INFO - 2022-03-29 00:34:03 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:34:03 --> Encrypt Class Initialized
INFO - 2022-03-29 00:34:03 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:34:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:34:03 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:34:03 --> Model "Users_model" initialized
INFO - 2022-03-29 00:34:03 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:34:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:34:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:34:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:34:03 --> Final output sent to browser
DEBUG - 2022-03-29 00:34:03 --> Total execution time: 0.0548
ERROR - 2022-03-29 00:36:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:36:12 --> Config Class Initialized
INFO - 2022-03-29 00:36:12 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:36:12 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:36:12 --> Utf8 Class Initialized
INFO - 2022-03-29 00:36:12 --> URI Class Initialized
INFO - 2022-03-29 00:36:12 --> Router Class Initialized
INFO - 2022-03-29 00:36:12 --> Output Class Initialized
INFO - 2022-03-29 00:36:12 --> Security Class Initialized
DEBUG - 2022-03-29 00:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:36:12 --> Input Class Initialized
INFO - 2022-03-29 00:36:12 --> Language Class Initialized
INFO - 2022-03-29 00:36:12 --> Loader Class Initialized
INFO - 2022-03-29 00:36:12 --> Helper loaded: url_helper
INFO - 2022-03-29 00:36:12 --> Helper loaded: form_helper
INFO - 2022-03-29 00:36:12 --> Helper loaded: common_helper
INFO - 2022-03-29 00:36:12 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:36:12 --> Controller Class Initialized
INFO - 2022-03-29 00:36:12 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:36:12 --> Encrypt Class Initialized
INFO - 2022-03-29 00:36:12 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:36:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:36:12 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:36:12 --> Model "Users_model" initialized
INFO - 2022-03-29 00:36:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:36:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:36:12 --> Config Class Initialized
INFO - 2022-03-29 00:36:12 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:36:12 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:36:12 --> Utf8 Class Initialized
INFO - 2022-03-29 00:36:12 --> URI Class Initialized
INFO - 2022-03-29 00:36:12 --> Router Class Initialized
INFO - 2022-03-29 00:36:12 --> Output Class Initialized
INFO - 2022-03-29 00:36:12 --> Security Class Initialized
DEBUG - 2022-03-29 00:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:36:12 --> Input Class Initialized
INFO - 2022-03-29 00:36:12 --> Language Class Initialized
INFO - 2022-03-29 00:36:12 --> Loader Class Initialized
INFO - 2022-03-29 00:36:12 --> Helper loaded: url_helper
INFO - 2022-03-29 00:36:12 --> Helper loaded: form_helper
INFO - 2022-03-29 00:36:12 --> Helper loaded: common_helper
INFO - 2022-03-29 00:36:12 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:36:13 --> Controller Class Initialized
INFO - 2022-03-29 00:36:13 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:36:13 --> Encrypt Class Initialized
INFO - 2022-03-29 00:36:13 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:36:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:36:13 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:36:13 --> Model "Users_model" initialized
INFO - 2022-03-29 00:36:13 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:36:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:36:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:36:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:36:13 --> Final output sent to browser
DEBUG - 2022-03-29 00:36:13 --> Total execution time: 0.0515
ERROR - 2022-03-29 00:36:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:36:59 --> Config Class Initialized
INFO - 2022-03-29 00:36:59 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:36:59 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:36:59 --> Utf8 Class Initialized
INFO - 2022-03-29 00:36:59 --> URI Class Initialized
INFO - 2022-03-29 00:36:59 --> Router Class Initialized
INFO - 2022-03-29 00:36:59 --> Output Class Initialized
INFO - 2022-03-29 00:36:59 --> Security Class Initialized
DEBUG - 2022-03-29 00:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:36:59 --> Input Class Initialized
INFO - 2022-03-29 00:36:59 --> Language Class Initialized
INFO - 2022-03-29 00:36:59 --> Loader Class Initialized
INFO - 2022-03-29 00:36:59 --> Helper loaded: url_helper
INFO - 2022-03-29 00:36:59 --> Helper loaded: form_helper
INFO - 2022-03-29 00:36:59 --> Helper loaded: common_helper
INFO - 2022-03-29 00:36:59 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:36:59 --> Controller Class Initialized
INFO - 2022-03-29 00:36:59 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:36:59 --> Encrypt Class Initialized
INFO - 2022-03-29 00:36:59 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:36:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:36:59 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:36:59 --> Model "Users_model" initialized
INFO - 2022-03-29 00:36:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:36:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:36:59 --> Config Class Initialized
INFO - 2022-03-29 00:36:59 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:36:59 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:36:59 --> Utf8 Class Initialized
INFO - 2022-03-29 00:36:59 --> URI Class Initialized
INFO - 2022-03-29 00:36:59 --> Router Class Initialized
INFO - 2022-03-29 00:36:59 --> Output Class Initialized
INFO - 2022-03-29 00:36:59 --> Security Class Initialized
DEBUG - 2022-03-29 00:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:36:59 --> Input Class Initialized
INFO - 2022-03-29 00:36:59 --> Language Class Initialized
INFO - 2022-03-29 00:36:59 --> Loader Class Initialized
INFO - 2022-03-29 00:36:59 --> Helper loaded: url_helper
INFO - 2022-03-29 00:36:59 --> Helper loaded: form_helper
INFO - 2022-03-29 00:36:59 --> Helper loaded: common_helper
INFO - 2022-03-29 00:36:59 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:36:59 --> Controller Class Initialized
INFO - 2022-03-29 00:36:59 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:36:59 --> Encrypt Class Initialized
INFO - 2022-03-29 00:36:59 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:36:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:36:59 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:36:59 --> Model "Users_model" initialized
INFO - 2022-03-29 00:36:59 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:37:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:37:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:37:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:37:00 --> Final output sent to browser
DEBUG - 2022-03-29 00:37:00 --> Total execution time: 0.0414
ERROR - 2022-03-29 00:37:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:37:57 --> Config Class Initialized
INFO - 2022-03-29 00:37:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:37:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:37:57 --> Utf8 Class Initialized
INFO - 2022-03-29 00:37:57 --> URI Class Initialized
INFO - 2022-03-29 00:37:57 --> Router Class Initialized
INFO - 2022-03-29 00:37:57 --> Output Class Initialized
INFO - 2022-03-29 00:37:57 --> Security Class Initialized
DEBUG - 2022-03-29 00:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:37:57 --> Input Class Initialized
INFO - 2022-03-29 00:37:57 --> Language Class Initialized
INFO - 2022-03-29 00:37:57 --> Loader Class Initialized
INFO - 2022-03-29 00:37:57 --> Helper loaded: url_helper
INFO - 2022-03-29 00:37:57 --> Helper loaded: form_helper
INFO - 2022-03-29 00:37:57 --> Helper loaded: common_helper
INFO - 2022-03-29 00:37:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:37:57 --> Controller Class Initialized
INFO - 2022-03-29 00:37:57 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:37:57 --> Encrypt Class Initialized
INFO - 2022-03-29 00:37:57 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:37:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:37:57 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:37:57 --> Model "Users_model" initialized
INFO - 2022-03-29 00:37:57 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:37:57 --> Upload Class Initialized
INFO - 2022-03-29 00:37:57 --> Final output sent to browser
DEBUG - 2022-03-29 00:37:57 --> Total execution time: 0.0669
ERROR - 2022-03-29 00:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:38:00 --> Config Class Initialized
INFO - 2022-03-29 00:38:00 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:38:00 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:38:00 --> Utf8 Class Initialized
INFO - 2022-03-29 00:38:00 --> URI Class Initialized
INFO - 2022-03-29 00:38:00 --> Router Class Initialized
INFO - 2022-03-29 00:38:00 --> Output Class Initialized
INFO - 2022-03-29 00:38:00 --> Security Class Initialized
DEBUG - 2022-03-29 00:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:38:00 --> Input Class Initialized
INFO - 2022-03-29 00:38:00 --> Language Class Initialized
INFO - 2022-03-29 00:38:00 --> Loader Class Initialized
INFO - 2022-03-29 00:38:00 --> Helper loaded: url_helper
INFO - 2022-03-29 00:38:00 --> Helper loaded: form_helper
INFO - 2022-03-29 00:38:00 --> Helper loaded: common_helper
INFO - 2022-03-29 00:38:00 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:38:00 --> Controller Class Initialized
INFO - 2022-03-29 00:38:00 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:38:00 --> Encrypt Class Initialized
INFO - 2022-03-29 00:38:00 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:38:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:38:00 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:38:00 --> Model "Users_model" initialized
INFO - 2022-03-29 00:38:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:38:00 --> Config Class Initialized
INFO - 2022-03-29 00:38:00 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:38:00 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:38:00 --> Utf8 Class Initialized
INFO - 2022-03-29 00:38:00 --> URI Class Initialized
INFO - 2022-03-29 00:38:00 --> Router Class Initialized
INFO - 2022-03-29 00:38:00 --> Output Class Initialized
INFO - 2022-03-29 00:38:00 --> Security Class Initialized
DEBUG - 2022-03-29 00:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:38:00 --> Input Class Initialized
INFO - 2022-03-29 00:38:00 --> Language Class Initialized
INFO - 2022-03-29 00:38:00 --> Loader Class Initialized
INFO - 2022-03-29 00:38:00 --> Helper loaded: url_helper
INFO - 2022-03-29 00:38:00 --> Helper loaded: form_helper
INFO - 2022-03-29 00:38:00 --> Helper loaded: common_helper
INFO - 2022-03-29 00:38:00 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:38:00 --> Controller Class Initialized
INFO - 2022-03-29 00:38:00 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:38:00 --> Encrypt Class Initialized
INFO - 2022-03-29 00:38:00 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:38:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:38:00 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:38:00 --> Model "Users_model" initialized
INFO - 2022-03-29 00:38:00 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:38:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:38:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:38:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:38:00 --> Final output sent to browser
DEBUG - 2022-03-29 00:38:00 --> Total execution time: 0.0757
ERROR - 2022-03-29 00:38:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:38:20 --> Config Class Initialized
INFO - 2022-03-29 00:38:20 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:38:20 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:38:20 --> Utf8 Class Initialized
INFO - 2022-03-29 00:38:20 --> URI Class Initialized
INFO - 2022-03-29 00:38:20 --> Router Class Initialized
INFO - 2022-03-29 00:38:20 --> Output Class Initialized
INFO - 2022-03-29 00:38:20 --> Security Class Initialized
DEBUG - 2022-03-29 00:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:38:20 --> Input Class Initialized
INFO - 2022-03-29 00:38:20 --> Language Class Initialized
INFO - 2022-03-29 00:38:20 --> Loader Class Initialized
INFO - 2022-03-29 00:38:20 --> Helper loaded: url_helper
INFO - 2022-03-29 00:38:20 --> Helper loaded: form_helper
INFO - 2022-03-29 00:38:20 --> Helper loaded: common_helper
INFO - 2022-03-29 00:38:20 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:38:20 --> Controller Class Initialized
INFO - 2022-03-29 00:38:20 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:38:20 --> Encrypt Class Initialized
INFO - 2022-03-29 00:38:20 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:38:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:38:20 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:38:20 --> Model "Users_model" initialized
INFO - 2022-03-29 00:38:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:38:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:38:20 --> Config Class Initialized
INFO - 2022-03-29 00:38:20 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:38:20 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:38:20 --> Utf8 Class Initialized
INFO - 2022-03-29 00:38:20 --> URI Class Initialized
INFO - 2022-03-29 00:38:20 --> Router Class Initialized
INFO - 2022-03-29 00:38:20 --> Output Class Initialized
INFO - 2022-03-29 00:38:20 --> Security Class Initialized
DEBUG - 2022-03-29 00:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:38:20 --> Input Class Initialized
INFO - 2022-03-29 00:38:20 --> Language Class Initialized
INFO - 2022-03-29 00:38:20 --> Loader Class Initialized
INFO - 2022-03-29 00:38:20 --> Helper loaded: url_helper
INFO - 2022-03-29 00:38:20 --> Helper loaded: form_helper
INFO - 2022-03-29 00:38:20 --> Helper loaded: common_helper
INFO - 2022-03-29 00:38:20 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:38:20 --> Controller Class Initialized
INFO - 2022-03-29 00:38:20 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:38:20 --> Encrypt Class Initialized
INFO - 2022-03-29 00:38:20 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:38:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:38:20 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:38:20 --> Model "Users_model" initialized
INFO - 2022-03-29 00:38:20 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:38:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:38:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:38:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:38:20 --> Final output sent to browser
DEBUG - 2022-03-29 00:38:20 --> Total execution time: 0.3991
ERROR - 2022-03-29 00:39:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:39:01 --> Config Class Initialized
INFO - 2022-03-29 00:39:01 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:39:01 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:39:01 --> Utf8 Class Initialized
INFO - 2022-03-29 00:39:01 --> URI Class Initialized
INFO - 2022-03-29 00:39:01 --> Router Class Initialized
INFO - 2022-03-29 00:39:01 --> Output Class Initialized
INFO - 2022-03-29 00:39:01 --> Security Class Initialized
DEBUG - 2022-03-29 00:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:39:01 --> Input Class Initialized
INFO - 2022-03-29 00:39:01 --> Language Class Initialized
INFO - 2022-03-29 00:39:01 --> Loader Class Initialized
INFO - 2022-03-29 00:39:01 --> Helper loaded: url_helper
INFO - 2022-03-29 00:39:01 --> Helper loaded: form_helper
INFO - 2022-03-29 00:39:01 --> Helper loaded: common_helper
INFO - 2022-03-29 00:39:01 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:39:01 --> Controller Class Initialized
INFO - 2022-03-29 00:39:01 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:39:01 --> Encrypt Class Initialized
INFO - 2022-03-29 00:39:01 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:39:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:39:01 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:39:01 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:39:01 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:39:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:39:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 00:39:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:39:13 --> Final output sent to browser
DEBUG - 2022-03-29 00:39:13 --> Total execution time: 10.0761
ERROR - 2022-03-29 00:39:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:39:46 --> Config Class Initialized
INFO - 2022-03-29 00:39:46 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:39:46 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:39:46 --> Utf8 Class Initialized
INFO - 2022-03-29 00:39:46 --> URI Class Initialized
INFO - 2022-03-29 00:39:46 --> Router Class Initialized
INFO - 2022-03-29 00:39:46 --> Output Class Initialized
INFO - 2022-03-29 00:39:46 --> Security Class Initialized
DEBUG - 2022-03-29 00:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:39:46 --> Input Class Initialized
INFO - 2022-03-29 00:39:46 --> Language Class Initialized
INFO - 2022-03-29 00:39:46 --> Loader Class Initialized
INFO - 2022-03-29 00:39:46 --> Helper loaded: url_helper
INFO - 2022-03-29 00:39:46 --> Helper loaded: form_helper
INFO - 2022-03-29 00:39:46 --> Helper loaded: common_helper
INFO - 2022-03-29 00:39:46 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:39:46 --> Controller Class Initialized
INFO - 2022-03-29 00:39:46 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:39:46 --> Encrypt Class Initialized
INFO - 2022-03-29 00:39:46 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:39:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:39:46 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:39:46 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:39:46 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:39:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:39:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:39:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:39:46 --> Final output sent to browser
DEBUG - 2022-03-29 00:39:46 --> Total execution time: 0.0315
ERROR - 2022-03-29 00:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:44:21 --> Config Class Initialized
INFO - 2022-03-29 00:44:21 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:44:21 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:44:21 --> Utf8 Class Initialized
INFO - 2022-03-29 00:44:21 --> URI Class Initialized
DEBUG - 2022-03-29 00:44:21 --> No URI present. Default controller set.
INFO - 2022-03-29 00:44:21 --> Router Class Initialized
INFO - 2022-03-29 00:44:21 --> Output Class Initialized
INFO - 2022-03-29 00:44:21 --> Security Class Initialized
DEBUG - 2022-03-29 00:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:44:21 --> Input Class Initialized
INFO - 2022-03-29 00:44:21 --> Language Class Initialized
INFO - 2022-03-29 00:44:21 --> Loader Class Initialized
INFO - 2022-03-29 00:44:21 --> Helper loaded: url_helper
INFO - 2022-03-29 00:44:21 --> Helper loaded: form_helper
INFO - 2022-03-29 00:44:21 --> Helper loaded: common_helper
INFO - 2022-03-29 00:44:21 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:44:21 --> Controller Class Initialized
INFO - 2022-03-29 00:44:21 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:44:21 --> Encrypt Class Initialized
DEBUG - 2022-03-29 00:44:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 00:44:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 00:44:21 --> Email Class Initialized
INFO - 2022-03-29 00:44:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 00:44:21 --> Calendar Class Initialized
INFO - 2022-03-29 00:44:21 --> Model "Login_model" initialized
ERROR - 2022-03-29 00:44:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:44:21 --> Config Class Initialized
INFO - 2022-03-29 00:44:21 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:44:21 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:44:21 --> Utf8 Class Initialized
INFO - 2022-03-29 00:44:21 --> URI Class Initialized
INFO - 2022-03-29 00:44:21 --> Router Class Initialized
INFO - 2022-03-29 00:44:21 --> Output Class Initialized
INFO - 2022-03-29 00:44:21 --> Security Class Initialized
DEBUG - 2022-03-29 00:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:44:21 --> Input Class Initialized
INFO - 2022-03-29 00:44:21 --> Language Class Initialized
INFO - 2022-03-29 00:44:21 --> Loader Class Initialized
INFO - 2022-03-29 00:44:21 --> Helper loaded: url_helper
INFO - 2022-03-29 00:44:21 --> Helper loaded: form_helper
INFO - 2022-03-29 00:44:21 --> Helper loaded: common_helper
INFO - 2022-03-29 00:44:21 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:44:21 --> Controller Class Initialized
INFO - 2022-03-29 00:44:21 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:44:21 --> Encrypt Class Initialized
INFO - 2022-03-29 00:44:21 --> Model "Diseases_model" initialized
INFO - 2022-03-29 00:44:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:44:21 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-29 00:44:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:44:21 --> Final output sent to browser
DEBUG - 2022-03-29 00:44:21 --> Total execution time: 0.0139
ERROR - 2022-03-29 00:44:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:44:35 --> Config Class Initialized
INFO - 2022-03-29 00:44:35 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:44:35 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:44:35 --> Utf8 Class Initialized
INFO - 2022-03-29 00:44:35 --> URI Class Initialized
INFO - 2022-03-29 00:44:35 --> Router Class Initialized
INFO - 2022-03-29 00:44:35 --> Output Class Initialized
INFO - 2022-03-29 00:44:35 --> Security Class Initialized
DEBUG - 2022-03-29 00:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:44:35 --> Input Class Initialized
INFO - 2022-03-29 00:44:35 --> Language Class Initialized
INFO - 2022-03-29 00:44:35 --> Loader Class Initialized
INFO - 2022-03-29 00:44:35 --> Helper loaded: url_helper
INFO - 2022-03-29 00:44:35 --> Helper loaded: form_helper
INFO - 2022-03-29 00:44:35 --> Helper loaded: common_helper
INFO - 2022-03-29 00:44:35 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:44:35 --> Controller Class Initialized
INFO - 2022-03-29 00:44:35 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:44:35 --> Encrypt Class Initialized
INFO - 2022-03-29 00:44:35 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:44:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:44:35 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:44:35 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:44:35 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:44:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:44:35 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 00:44:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:44:35 --> Final output sent to browser
DEBUG - 2022-03-29 00:44:35 --> Total execution time: 0.0717
ERROR - 2022-03-29 00:44:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:44:37 --> Config Class Initialized
INFO - 2022-03-29 00:44:37 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:44:37 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:44:37 --> Utf8 Class Initialized
INFO - 2022-03-29 00:44:37 --> URI Class Initialized
INFO - 2022-03-29 00:44:37 --> Router Class Initialized
INFO - 2022-03-29 00:44:37 --> Output Class Initialized
INFO - 2022-03-29 00:44:37 --> Security Class Initialized
DEBUG - 2022-03-29 00:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:44:37 --> Input Class Initialized
INFO - 2022-03-29 00:44:37 --> Language Class Initialized
INFO - 2022-03-29 00:44:37 --> Loader Class Initialized
INFO - 2022-03-29 00:44:37 --> Helper loaded: url_helper
INFO - 2022-03-29 00:44:37 --> Helper loaded: form_helper
INFO - 2022-03-29 00:44:37 --> Helper loaded: common_helper
INFO - 2022-03-29 00:44:37 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:44:37 --> Controller Class Initialized
INFO - 2022-03-29 00:44:37 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:44:37 --> Encrypt Class Initialized
INFO - 2022-03-29 00:44:37 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:44:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:44:37 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:44:37 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:44:37 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:44:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:44:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:44:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:44:37 --> Final output sent to browser
DEBUG - 2022-03-29 00:44:37 --> Total execution time: 0.0152
ERROR - 2022-03-29 00:48:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:48:39 --> Config Class Initialized
INFO - 2022-03-29 00:48:39 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:48:39 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:48:39 --> Utf8 Class Initialized
INFO - 2022-03-29 00:48:39 --> URI Class Initialized
INFO - 2022-03-29 00:48:39 --> Router Class Initialized
INFO - 2022-03-29 00:48:39 --> Output Class Initialized
INFO - 2022-03-29 00:48:39 --> Security Class Initialized
DEBUG - 2022-03-29 00:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:48:39 --> Input Class Initialized
INFO - 2022-03-29 00:48:39 --> Language Class Initialized
INFO - 2022-03-29 00:48:39 --> Loader Class Initialized
INFO - 2022-03-29 00:48:39 --> Helper loaded: url_helper
INFO - 2022-03-29 00:48:39 --> Helper loaded: form_helper
INFO - 2022-03-29 00:48:39 --> Helper loaded: common_helper
INFO - 2022-03-29 00:48:39 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:48:39 --> Controller Class Initialized
INFO - 2022-03-29 00:48:39 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:48:39 --> Encrypt Class Initialized
INFO - 2022-03-29 00:48:39 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:48:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:48:39 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:48:39 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:48:39 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:48:39 --> Upload Class Initialized
INFO - 2022-03-29 00:48:39 --> Final output sent to browser
DEBUG - 2022-03-29 00:48:39 --> Total execution time: 0.2158
ERROR - 2022-03-29 00:51:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:51:48 --> Config Class Initialized
INFO - 2022-03-29 00:51:48 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:51:48 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:51:48 --> Utf8 Class Initialized
INFO - 2022-03-29 00:51:48 --> URI Class Initialized
INFO - 2022-03-29 00:51:48 --> Router Class Initialized
INFO - 2022-03-29 00:51:48 --> Output Class Initialized
INFO - 2022-03-29 00:51:48 --> Security Class Initialized
DEBUG - 2022-03-29 00:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:51:48 --> Input Class Initialized
INFO - 2022-03-29 00:51:48 --> Language Class Initialized
INFO - 2022-03-29 00:51:48 --> Loader Class Initialized
INFO - 2022-03-29 00:51:48 --> Helper loaded: url_helper
INFO - 2022-03-29 00:51:48 --> Helper loaded: form_helper
INFO - 2022-03-29 00:51:48 --> Helper loaded: common_helper
INFO - 2022-03-29 00:51:48 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:51:48 --> Controller Class Initialized
INFO - 2022-03-29 00:51:48 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:51:48 --> Final output sent to browser
DEBUG - 2022-03-29 00:51:48 --> Total execution time: 0.0599
ERROR - 2022-03-29 00:52:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:52:13 --> Config Class Initialized
INFO - 2022-03-29 00:52:13 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:52:13 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:52:13 --> Utf8 Class Initialized
INFO - 2022-03-29 00:52:13 --> URI Class Initialized
INFO - 2022-03-29 00:52:13 --> Router Class Initialized
INFO - 2022-03-29 00:52:13 --> Output Class Initialized
INFO - 2022-03-29 00:52:13 --> Security Class Initialized
DEBUG - 2022-03-29 00:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:52:13 --> Input Class Initialized
INFO - 2022-03-29 00:52:13 --> Language Class Initialized
INFO - 2022-03-29 00:52:13 --> Loader Class Initialized
INFO - 2022-03-29 00:52:13 --> Helper loaded: url_helper
INFO - 2022-03-29 00:52:13 --> Helper loaded: form_helper
INFO - 2022-03-29 00:52:13 --> Helper loaded: common_helper
INFO - 2022-03-29 00:52:13 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:52:13 --> Controller Class Initialized
INFO - 2022-03-29 00:52:13 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:52:13 --> Encrypt Class Initialized
INFO - 2022-03-29 00:52:13 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:52:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:52:13 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:52:13 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:52:13 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:52:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:52:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:52:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:52:13 --> Final output sent to browser
DEBUG - 2022-03-29 00:52:13 --> Total execution time: 0.0251
ERROR - 2022-03-29 00:53:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:53:02 --> Config Class Initialized
INFO - 2022-03-29 00:53:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:53:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:53:02 --> Utf8 Class Initialized
INFO - 2022-03-29 00:53:02 --> URI Class Initialized
INFO - 2022-03-29 00:53:02 --> Router Class Initialized
INFO - 2022-03-29 00:53:02 --> Output Class Initialized
INFO - 2022-03-29 00:53:02 --> Security Class Initialized
DEBUG - 2022-03-29 00:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:53:02 --> Input Class Initialized
INFO - 2022-03-29 00:53:02 --> Language Class Initialized
INFO - 2022-03-29 00:53:02 --> Loader Class Initialized
INFO - 2022-03-29 00:53:02 --> Helper loaded: url_helper
INFO - 2022-03-29 00:53:02 --> Helper loaded: form_helper
INFO - 2022-03-29 00:53:02 --> Helper loaded: common_helper
INFO - 2022-03-29 00:53:02 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:53:02 --> Controller Class Initialized
INFO - 2022-03-29 00:53:02 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:53:02 --> Encrypt Class Initialized
INFO - 2022-03-29 00:53:02 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:53:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:53:02 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:53:02 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:53:02 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:53:02 --> Final output sent to browser
DEBUG - 2022-03-29 00:53:02 --> Total execution time: 0.0101
ERROR - 2022-03-29 00:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:53:57 --> Config Class Initialized
INFO - 2022-03-29 00:53:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:53:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:53:57 --> Utf8 Class Initialized
INFO - 2022-03-29 00:53:57 --> URI Class Initialized
INFO - 2022-03-29 00:53:57 --> Router Class Initialized
INFO - 2022-03-29 00:53:57 --> Output Class Initialized
INFO - 2022-03-29 00:53:57 --> Security Class Initialized
DEBUG - 2022-03-29 00:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:53:57 --> Input Class Initialized
INFO - 2022-03-29 00:53:57 --> Language Class Initialized
INFO - 2022-03-29 00:53:57 --> Loader Class Initialized
INFO - 2022-03-29 00:53:57 --> Helper loaded: url_helper
INFO - 2022-03-29 00:53:57 --> Helper loaded: form_helper
INFO - 2022-03-29 00:53:57 --> Helper loaded: common_helper
INFO - 2022-03-29 00:53:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:53:57 --> Controller Class Initialized
INFO - 2022-03-29 00:53:57 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:53:57 --> Final output sent to browser
DEBUG - 2022-03-29 00:53:57 --> Total execution time: 0.0090
ERROR - 2022-03-29 00:54:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:54:04 --> Config Class Initialized
INFO - 2022-03-29 00:54:04 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:54:04 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:54:04 --> Utf8 Class Initialized
INFO - 2022-03-29 00:54:04 --> URI Class Initialized
INFO - 2022-03-29 00:54:04 --> Router Class Initialized
INFO - 2022-03-29 00:54:04 --> Output Class Initialized
INFO - 2022-03-29 00:54:04 --> Security Class Initialized
DEBUG - 2022-03-29 00:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:54:04 --> Input Class Initialized
INFO - 2022-03-29 00:54:04 --> Language Class Initialized
INFO - 2022-03-29 00:54:04 --> Loader Class Initialized
INFO - 2022-03-29 00:54:04 --> Helper loaded: url_helper
INFO - 2022-03-29 00:54:04 --> Helper loaded: form_helper
INFO - 2022-03-29 00:54:04 --> Helper loaded: common_helper
INFO - 2022-03-29 00:54:04 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:54:04 --> Controller Class Initialized
INFO - 2022-03-29 00:54:04 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:54:04 --> Final output sent to browser
DEBUG - 2022-03-29 00:54:04 --> Total execution time: 0.0074
ERROR - 2022-03-29 00:54:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:54:25 --> Config Class Initialized
INFO - 2022-03-29 00:54:25 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:54:25 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:54:25 --> Utf8 Class Initialized
INFO - 2022-03-29 00:54:25 --> URI Class Initialized
INFO - 2022-03-29 00:54:25 --> Router Class Initialized
INFO - 2022-03-29 00:54:25 --> Output Class Initialized
INFO - 2022-03-29 00:54:25 --> Security Class Initialized
DEBUG - 2022-03-29 00:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:54:25 --> Input Class Initialized
INFO - 2022-03-29 00:54:25 --> Language Class Initialized
INFO - 2022-03-29 00:54:25 --> Loader Class Initialized
INFO - 2022-03-29 00:54:25 --> Helper loaded: url_helper
INFO - 2022-03-29 00:54:25 --> Helper loaded: form_helper
INFO - 2022-03-29 00:54:25 --> Helper loaded: common_helper
INFO - 2022-03-29 00:54:25 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:54:25 --> Controller Class Initialized
INFO - 2022-03-29 00:54:25 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:54:25 --> Encrypt Class Initialized
INFO - 2022-03-29 00:54:25 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:54:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:54:25 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:54:25 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:54:25 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:54:25 --> Final output sent to browser
DEBUG - 2022-03-29 00:54:25 --> Total execution time: 0.0092
ERROR - 2022-03-29 00:55:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:55:03 --> Config Class Initialized
INFO - 2022-03-29 00:55:03 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:55:03 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:55:03 --> Utf8 Class Initialized
INFO - 2022-03-29 00:55:03 --> URI Class Initialized
INFO - 2022-03-29 00:55:03 --> Router Class Initialized
INFO - 2022-03-29 00:55:03 --> Output Class Initialized
INFO - 2022-03-29 00:55:03 --> Security Class Initialized
DEBUG - 2022-03-29 00:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:55:03 --> Input Class Initialized
INFO - 2022-03-29 00:55:03 --> Language Class Initialized
INFO - 2022-03-29 00:55:03 --> Loader Class Initialized
INFO - 2022-03-29 00:55:03 --> Helper loaded: url_helper
INFO - 2022-03-29 00:55:03 --> Helper loaded: form_helper
INFO - 2022-03-29 00:55:03 --> Helper loaded: common_helper
INFO - 2022-03-29 00:55:03 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:55:03 --> Controller Class Initialized
INFO - 2022-03-29 00:55:03 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:55:03 --> Encrypt Class Initialized
INFO - 2022-03-29 00:55:03 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:55:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:55:03 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:55:03 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:55:03 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:55:03 --> Final output sent to browser
DEBUG - 2022-03-29 00:55:03 --> Total execution time: 0.0113
ERROR - 2022-03-29 00:55:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:55:25 --> Config Class Initialized
INFO - 2022-03-29 00:55:25 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:55:25 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:55:25 --> Utf8 Class Initialized
INFO - 2022-03-29 00:55:25 --> URI Class Initialized
INFO - 2022-03-29 00:55:25 --> Router Class Initialized
INFO - 2022-03-29 00:55:25 --> Output Class Initialized
INFO - 2022-03-29 00:55:25 --> Security Class Initialized
DEBUG - 2022-03-29 00:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:55:25 --> Input Class Initialized
INFO - 2022-03-29 00:55:25 --> Language Class Initialized
INFO - 2022-03-29 00:55:25 --> Loader Class Initialized
INFO - 2022-03-29 00:55:25 --> Helper loaded: url_helper
INFO - 2022-03-29 00:55:25 --> Helper loaded: form_helper
INFO - 2022-03-29 00:55:25 --> Helper loaded: common_helper
INFO - 2022-03-29 00:55:25 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:55:25 --> Controller Class Initialized
INFO - 2022-03-29 00:55:25 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:55:25 --> Encrypt Class Initialized
INFO - 2022-03-29 00:55:25 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:55:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:55:25 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:55:25 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:55:25 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:55:25 --> Final output sent to browser
DEBUG - 2022-03-29 00:55:25 --> Total execution time: 0.0145
ERROR - 2022-03-29 00:56:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:56:24 --> Config Class Initialized
INFO - 2022-03-29 00:56:24 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:56:24 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:56:24 --> Utf8 Class Initialized
INFO - 2022-03-29 00:56:24 --> URI Class Initialized
INFO - 2022-03-29 00:56:24 --> Router Class Initialized
INFO - 2022-03-29 00:56:24 --> Output Class Initialized
INFO - 2022-03-29 00:56:24 --> Security Class Initialized
DEBUG - 2022-03-29 00:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:56:24 --> Input Class Initialized
INFO - 2022-03-29 00:56:24 --> Language Class Initialized
INFO - 2022-03-29 00:56:24 --> Loader Class Initialized
INFO - 2022-03-29 00:56:24 --> Helper loaded: url_helper
INFO - 2022-03-29 00:56:24 --> Helper loaded: form_helper
INFO - 2022-03-29 00:56:24 --> Helper loaded: common_helper
INFO - 2022-03-29 00:56:24 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:56:24 --> Controller Class Initialized
INFO - 2022-03-29 00:56:24 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:56:24 --> Encrypt Class Initialized
INFO - 2022-03-29 00:56:24 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:56:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:56:24 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:56:24 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:56:24 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:56:24 --> Final output sent to browser
DEBUG - 2022-03-29 00:56:24 --> Total execution time: 0.0089
ERROR - 2022-03-29 00:56:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:56:45 --> Config Class Initialized
INFO - 2022-03-29 00:56:45 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:56:45 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:56:45 --> Utf8 Class Initialized
INFO - 2022-03-29 00:56:45 --> URI Class Initialized
INFO - 2022-03-29 00:56:45 --> Router Class Initialized
INFO - 2022-03-29 00:56:45 --> Output Class Initialized
INFO - 2022-03-29 00:56:45 --> Security Class Initialized
DEBUG - 2022-03-29 00:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:56:45 --> Input Class Initialized
INFO - 2022-03-29 00:56:45 --> Language Class Initialized
INFO - 2022-03-29 00:56:45 --> Loader Class Initialized
INFO - 2022-03-29 00:56:45 --> Helper loaded: url_helper
INFO - 2022-03-29 00:56:45 --> Helper loaded: form_helper
INFO - 2022-03-29 00:56:45 --> Helper loaded: common_helper
INFO - 2022-03-29 00:56:45 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:56:45 --> Controller Class Initialized
INFO - 2022-03-29 00:56:45 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:56:45 --> Encrypt Class Initialized
INFO - 2022-03-29 00:56:45 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:56:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:56:45 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:56:45 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:56:45 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:56:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:56:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 00:56:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:56:45 --> Final output sent to browser
DEBUG - 2022-03-29 00:56:45 --> Total execution time: 0.0519
ERROR - 2022-03-29 00:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:57:54 --> Config Class Initialized
INFO - 2022-03-29 00:57:54 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:57:54 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:57:54 --> Utf8 Class Initialized
INFO - 2022-03-29 00:57:54 --> URI Class Initialized
DEBUG - 2022-03-29 00:57:54 --> No URI present. Default controller set.
INFO - 2022-03-29 00:57:54 --> Router Class Initialized
INFO - 2022-03-29 00:57:54 --> Output Class Initialized
INFO - 2022-03-29 00:57:54 --> Security Class Initialized
DEBUG - 2022-03-29 00:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:57:54 --> Input Class Initialized
INFO - 2022-03-29 00:57:54 --> Language Class Initialized
INFO - 2022-03-29 00:57:54 --> Loader Class Initialized
INFO - 2022-03-29 00:57:54 --> Helper loaded: url_helper
INFO - 2022-03-29 00:57:54 --> Helper loaded: form_helper
INFO - 2022-03-29 00:57:54 --> Helper loaded: common_helper
INFO - 2022-03-29 00:57:54 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:57:54 --> Controller Class Initialized
INFO - 2022-03-29 00:57:54 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:57:54 --> Encrypt Class Initialized
DEBUG - 2022-03-29 00:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 00:57:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 00:57:54 --> Email Class Initialized
INFO - 2022-03-29 00:57:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 00:57:54 --> Calendar Class Initialized
INFO - 2022-03-29 00:57:54 --> Model "Login_model" initialized
ERROR - 2022-03-29 00:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:57:54 --> Config Class Initialized
INFO - 2022-03-29 00:57:54 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:57:54 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:57:54 --> Utf8 Class Initialized
INFO - 2022-03-29 00:57:54 --> URI Class Initialized
INFO - 2022-03-29 00:57:54 --> Router Class Initialized
INFO - 2022-03-29 00:57:54 --> Output Class Initialized
INFO - 2022-03-29 00:57:54 --> Security Class Initialized
DEBUG - 2022-03-29 00:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:57:54 --> Input Class Initialized
INFO - 2022-03-29 00:57:54 --> Language Class Initialized
INFO - 2022-03-29 00:57:54 --> Loader Class Initialized
INFO - 2022-03-29 00:57:54 --> Helper loaded: url_helper
INFO - 2022-03-29 00:57:54 --> Helper loaded: form_helper
INFO - 2022-03-29 00:57:54 --> Helper loaded: common_helper
INFO - 2022-03-29 00:57:54 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:57:54 --> Controller Class Initialized
INFO - 2022-03-29 00:57:54 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:57:54 --> Encrypt Class Initialized
INFO - 2022-03-29 00:57:54 --> Model "Diseases_model" initialized
INFO - 2022-03-29 00:57:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:57:54 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-29 00:57:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:57:54 --> Final output sent to browser
DEBUG - 2022-03-29 00:57:54 --> Total execution time: 0.0083
ERROR - 2022-03-29 00:57:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:57:56 --> Config Class Initialized
INFO - 2022-03-29 00:57:56 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:57:56 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:57:56 --> Utf8 Class Initialized
INFO - 2022-03-29 00:57:56 --> URI Class Initialized
DEBUG - 2022-03-29 00:57:56 --> No URI present. Default controller set.
INFO - 2022-03-29 00:57:56 --> Router Class Initialized
INFO - 2022-03-29 00:57:56 --> Output Class Initialized
INFO - 2022-03-29 00:57:56 --> Security Class Initialized
DEBUG - 2022-03-29 00:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:57:56 --> Input Class Initialized
INFO - 2022-03-29 00:57:56 --> Language Class Initialized
INFO - 2022-03-29 00:57:56 --> Loader Class Initialized
INFO - 2022-03-29 00:57:56 --> Helper loaded: url_helper
INFO - 2022-03-29 00:57:56 --> Helper loaded: form_helper
INFO - 2022-03-29 00:57:56 --> Helper loaded: common_helper
INFO - 2022-03-29 00:57:56 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:57:56 --> Controller Class Initialized
INFO - 2022-03-29 00:57:56 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:57:56 --> Encrypt Class Initialized
DEBUG - 2022-03-29 00:57:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 00:57:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 00:57:56 --> Email Class Initialized
INFO - 2022-03-29 00:57:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 00:57:56 --> Calendar Class Initialized
INFO - 2022-03-29 00:57:56 --> Model "Login_model" initialized
ERROR - 2022-03-29 00:57:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:57:57 --> Config Class Initialized
INFO - 2022-03-29 00:57:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:57:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:57:57 --> Utf8 Class Initialized
INFO - 2022-03-29 00:57:57 --> URI Class Initialized
INFO - 2022-03-29 00:57:57 --> Router Class Initialized
INFO - 2022-03-29 00:57:57 --> Output Class Initialized
INFO - 2022-03-29 00:57:57 --> Security Class Initialized
DEBUG - 2022-03-29 00:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:57:57 --> Input Class Initialized
INFO - 2022-03-29 00:57:57 --> Language Class Initialized
INFO - 2022-03-29 00:57:57 --> Loader Class Initialized
INFO - 2022-03-29 00:57:57 --> Helper loaded: url_helper
INFO - 2022-03-29 00:57:57 --> Helper loaded: form_helper
INFO - 2022-03-29 00:57:57 --> Helper loaded: common_helper
INFO - 2022-03-29 00:57:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:57:57 --> Controller Class Initialized
INFO - 2022-03-29 00:57:57 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:57:57 --> Encrypt Class Initialized
INFO - 2022-03-29 00:57:57 --> Model "Diseases_model" initialized
INFO - 2022-03-29 00:57:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:57:57 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-29 00:57:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:57:57 --> Final output sent to browser
DEBUG - 2022-03-29 00:57:57 --> Total execution time: 0.0076
ERROR - 2022-03-29 00:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:58:00 --> Config Class Initialized
INFO - 2022-03-29 00:58:00 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:58:00 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:58:00 --> Utf8 Class Initialized
INFO - 2022-03-29 00:58:00 --> URI Class Initialized
INFO - 2022-03-29 00:58:00 --> Router Class Initialized
INFO - 2022-03-29 00:58:00 --> Output Class Initialized
INFO - 2022-03-29 00:58:00 --> Security Class Initialized
DEBUG - 2022-03-29 00:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:58:00 --> Input Class Initialized
INFO - 2022-03-29 00:58:00 --> Language Class Initialized
INFO - 2022-03-29 00:58:00 --> Loader Class Initialized
INFO - 2022-03-29 00:58:00 --> Helper loaded: url_helper
INFO - 2022-03-29 00:58:00 --> Helper loaded: form_helper
INFO - 2022-03-29 00:58:00 --> Helper loaded: common_helper
INFO - 2022-03-29 00:58:00 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:58:00 --> Controller Class Initialized
INFO - 2022-03-29 00:58:00 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:58:00 --> Encrypt Class Initialized
INFO - 2022-03-29 00:58:00 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:58:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:58:00 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:58:00 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:58:00 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:58:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:58:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 00:58:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:58:00 --> Final output sent to browser
DEBUG - 2022-03-29 00:58:00 --> Total execution time: 0.0683
ERROR - 2022-03-29 00:58:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:58:11 --> Config Class Initialized
INFO - 2022-03-29 00:58:11 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:58:11 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:58:11 --> Utf8 Class Initialized
INFO - 2022-03-29 00:58:11 --> URI Class Initialized
INFO - 2022-03-29 00:58:11 --> Router Class Initialized
INFO - 2022-03-29 00:58:11 --> Output Class Initialized
INFO - 2022-03-29 00:58:11 --> Security Class Initialized
DEBUG - 2022-03-29 00:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:58:11 --> Input Class Initialized
INFO - 2022-03-29 00:58:11 --> Language Class Initialized
INFO - 2022-03-29 00:58:11 --> Loader Class Initialized
INFO - 2022-03-29 00:58:11 --> Helper loaded: url_helper
INFO - 2022-03-29 00:58:11 --> Helper loaded: form_helper
INFO - 2022-03-29 00:58:11 --> Helper loaded: common_helper
INFO - 2022-03-29 00:58:11 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:58:11 --> Controller Class Initialized
INFO - 2022-03-29 00:58:11 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:58:11 --> Encrypt Class Initialized
INFO - 2022-03-29 00:58:11 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:58:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:58:11 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:58:11 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:58:11 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:58:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:58:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:58:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:58:11 --> Final output sent to browser
DEBUG - 2022-03-29 00:58:11 --> Total execution time: 0.0107
ERROR - 2022-03-29 00:58:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:58:43 --> Config Class Initialized
INFO - 2022-03-29 00:58:43 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:58:43 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:58:43 --> Utf8 Class Initialized
INFO - 2022-03-29 00:58:43 --> URI Class Initialized
INFO - 2022-03-29 00:58:43 --> Router Class Initialized
INFO - 2022-03-29 00:58:43 --> Output Class Initialized
INFO - 2022-03-29 00:58:43 --> Security Class Initialized
DEBUG - 2022-03-29 00:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:58:43 --> Input Class Initialized
INFO - 2022-03-29 00:58:43 --> Language Class Initialized
INFO - 2022-03-29 00:58:43 --> Loader Class Initialized
INFO - 2022-03-29 00:58:43 --> Helper loaded: url_helper
INFO - 2022-03-29 00:58:43 --> Helper loaded: form_helper
INFO - 2022-03-29 00:58:43 --> Helper loaded: common_helper
INFO - 2022-03-29 00:58:43 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:58:43 --> Controller Class Initialized
INFO - 2022-03-29 00:58:43 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:58:43 --> Final output sent to browser
DEBUG - 2022-03-29 00:58:43 --> Total execution time: 0.0068
ERROR - 2022-03-29 00:58:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:58:48 --> Config Class Initialized
INFO - 2022-03-29 00:58:48 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:58:48 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:58:48 --> Utf8 Class Initialized
INFO - 2022-03-29 00:58:48 --> URI Class Initialized
INFO - 2022-03-29 00:58:48 --> Router Class Initialized
INFO - 2022-03-29 00:58:48 --> Output Class Initialized
INFO - 2022-03-29 00:58:48 --> Security Class Initialized
DEBUG - 2022-03-29 00:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:58:48 --> Input Class Initialized
INFO - 2022-03-29 00:58:48 --> Language Class Initialized
INFO - 2022-03-29 00:58:48 --> Loader Class Initialized
INFO - 2022-03-29 00:58:48 --> Helper loaded: url_helper
INFO - 2022-03-29 00:58:48 --> Helper loaded: form_helper
INFO - 2022-03-29 00:58:48 --> Helper loaded: common_helper
INFO - 2022-03-29 00:58:48 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:58:48 --> Controller Class Initialized
INFO - 2022-03-29 00:58:48 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:58:48 --> Encrypt Class Initialized
INFO - 2022-03-29 00:58:48 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:58:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:58:48 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:58:48 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:58:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 00:58:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:58:48 --> Config Class Initialized
INFO - 2022-03-29 00:58:48 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:58:48 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:58:48 --> Utf8 Class Initialized
INFO - 2022-03-29 00:58:48 --> URI Class Initialized
INFO - 2022-03-29 00:58:48 --> Router Class Initialized
INFO - 2022-03-29 00:58:48 --> Output Class Initialized
INFO - 2022-03-29 00:58:48 --> Security Class Initialized
DEBUG - 2022-03-29 00:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:58:48 --> Input Class Initialized
INFO - 2022-03-29 00:58:48 --> Language Class Initialized
INFO - 2022-03-29 00:58:48 --> Loader Class Initialized
INFO - 2022-03-29 00:58:48 --> Helper loaded: url_helper
INFO - 2022-03-29 00:58:48 --> Helper loaded: form_helper
INFO - 2022-03-29 00:58:48 --> Helper loaded: common_helper
INFO - 2022-03-29 00:58:48 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:58:48 --> Controller Class Initialized
INFO - 2022-03-29 00:58:48 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:58:48 --> Encrypt Class Initialized
INFO - 2022-03-29 00:58:48 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:58:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:58:48 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:58:48 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:58:48 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:58:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:58:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 00:58:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:58:48 --> Final output sent to browser
DEBUG - 2022-03-29 00:58:48 --> Total execution time: 0.0424
ERROR - 2022-03-29 00:58:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:58:49 --> Config Class Initialized
INFO - 2022-03-29 00:58:49 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:58:49 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:58:49 --> Utf8 Class Initialized
INFO - 2022-03-29 00:58:49 --> URI Class Initialized
INFO - 2022-03-29 00:58:49 --> Router Class Initialized
INFO - 2022-03-29 00:58:49 --> Output Class Initialized
INFO - 2022-03-29 00:58:49 --> Security Class Initialized
DEBUG - 2022-03-29 00:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:58:49 --> Input Class Initialized
INFO - 2022-03-29 00:58:49 --> Language Class Initialized
INFO - 2022-03-29 00:58:49 --> Loader Class Initialized
INFO - 2022-03-29 00:58:49 --> Helper loaded: url_helper
INFO - 2022-03-29 00:58:49 --> Helper loaded: form_helper
INFO - 2022-03-29 00:58:49 --> Helper loaded: common_helper
INFO - 2022-03-29 00:58:49 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:58:49 --> Controller Class Initialized
INFO - 2022-03-29 00:58:49 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:58:49 --> Encrypt Class Initialized
INFO - 2022-03-29 00:58:49 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:58:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:58:49 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:58:49 --> Model "Users_model" initialized
INFO - 2022-03-29 00:58:49 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:58:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:58:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 00:58:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:58:49 --> Final output sent to browser
DEBUG - 2022-03-29 00:58:49 --> Total execution time: 0.0582
ERROR - 2022-03-29 00:59:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 00:59:02 --> Config Class Initialized
INFO - 2022-03-29 00:59:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 00:59:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 00:59:02 --> Utf8 Class Initialized
INFO - 2022-03-29 00:59:02 --> URI Class Initialized
INFO - 2022-03-29 00:59:02 --> Router Class Initialized
INFO - 2022-03-29 00:59:02 --> Output Class Initialized
INFO - 2022-03-29 00:59:02 --> Security Class Initialized
DEBUG - 2022-03-29 00:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 00:59:02 --> Input Class Initialized
INFO - 2022-03-29 00:59:02 --> Language Class Initialized
INFO - 2022-03-29 00:59:02 --> Loader Class Initialized
INFO - 2022-03-29 00:59:02 --> Helper loaded: url_helper
INFO - 2022-03-29 00:59:02 --> Helper loaded: form_helper
INFO - 2022-03-29 00:59:02 --> Helper loaded: common_helper
INFO - 2022-03-29 00:59:02 --> Database Driver Class Initialized
DEBUG - 2022-03-29 00:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 00:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 00:59:02 --> Controller Class Initialized
INFO - 2022-03-29 00:59:02 --> Form Validation Class Initialized
DEBUG - 2022-03-29 00:59:02 --> Encrypt Class Initialized
INFO - 2022-03-29 00:59:02 --> Model "Patient_model" initialized
INFO - 2022-03-29 00:59:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 00:59:02 --> Model "Referredby_model" initialized
INFO - 2022-03-29 00:59:02 --> Model "Prefix_master" initialized
INFO - 2022-03-29 00:59:02 --> Model "Hospital_model" initialized
INFO - 2022-03-29 00:59:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 00:59:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 00:59:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 00:59:02 --> Final output sent to browser
DEBUG - 2022-03-29 00:59:02 --> Total execution time: 0.0827
ERROR - 2022-03-29 01:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:01:17 --> Config Class Initialized
INFO - 2022-03-29 01:01:17 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:01:17 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:01:17 --> Utf8 Class Initialized
INFO - 2022-03-29 01:01:17 --> URI Class Initialized
INFO - 2022-03-29 01:01:17 --> Router Class Initialized
INFO - 2022-03-29 01:01:17 --> Output Class Initialized
INFO - 2022-03-29 01:01:17 --> Security Class Initialized
DEBUG - 2022-03-29 01:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:01:17 --> Input Class Initialized
INFO - 2022-03-29 01:01:17 --> Language Class Initialized
INFO - 2022-03-29 01:01:17 --> Loader Class Initialized
INFO - 2022-03-29 01:01:17 --> Helper loaded: url_helper
INFO - 2022-03-29 01:01:17 --> Helper loaded: form_helper
INFO - 2022-03-29 01:01:17 --> Helper loaded: common_helper
INFO - 2022-03-29 01:01:17 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:01:17 --> Controller Class Initialized
INFO - 2022-03-29 01:01:17 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:01:17 --> Encrypt Class Initialized
INFO - 2022-03-29 01:01:17 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:01:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:01:17 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:01:17 --> Model "Users_model" initialized
INFO - 2022-03-29 01:01:17 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:01:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:01:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:01:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:01:17 --> Final output sent to browser
DEBUG - 2022-03-29 01:01:17 --> Total execution time: 0.0945
ERROR - 2022-03-29 01:02:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:02:14 --> Config Class Initialized
INFO - 2022-03-29 01:02:14 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:02:14 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:02:14 --> Utf8 Class Initialized
INFO - 2022-03-29 01:02:14 --> URI Class Initialized
INFO - 2022-03-29 01:02:14 --> Router Class Initialized
INFO - 2022-03-29 01:02:14 --> Output Class Initialized
INFO - 2022-03-29 01:02:14 --> Security Class Initialized
DEBUG - 2022-03-29 01:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:02:14 --> Input Class Initialized
INFO - 2022-03-29 01:02:14 --> Language Class Initialized
INFO - 2022-03-29 01:02:14 --> Loader Class Initialized
INFO - 2022-03-29 01:02:14 --> Helper loaded: url_helper
INFO - 2022-03-29 01:02:14 --> Helper loaded: form_helper
INFO - 2022-03-29 01:02:14 --> Helper loaded: common_helper
INFO - 2022-03-29 01:02:14 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:02:14 --> Controller Class Initialized
INFO - 2022-03-29 01:02:14 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:02:14 --> Encrypt Class Initialized
INFO - 2022-03-29 01:02:14 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:02:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:02:14 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:02:14 --> Model "Users_model" initialized
INFO - 2022-03-29 01:02:14 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:02:14 --> Upload Class Initialized
INFO - 2022-03-29 01:02:14 --> Final output sent to browser
DEBUG - 2022-03-29 01:02:14 --> Total execution time: 0.0274
ERROR - 2022-03-29 01:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:02:43 --> Config Class Initialized
INFO - 2022-03-29 01:02:43 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:02:43 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:02:43 --> Utf8 Class Initialized
INFO - 2022-03-29 01:02:43 --> URI Class Initialized
INFO - 2022-03-29 01:02:43 --> Router Class Initialized
INFO - 2022-03-29 01:02:43 --> Output Class Initialized
INFO - 2022-03-29 01:02:43 --> Security Class Initialized
DEBUG - 2022-03-29 01:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:02:43 --> Input Class Initialized
INFO - 2022-03-29 01:02:43 --> Language Class Initialized
INFO - 2022-03-29 01:02:43 --> Loader Class Initialized
INFO - 2022-03-29 01:02:43 --> Helper loaded: url_helper
INFO - 2022-03-29 01:02:43 --> Helper loaded: form_helper
INFO - 2022-03-29 01:02:43 --> Helper loaded: common_helper
INFO - 2022-03-29 01:02:43 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:02:43 --> Controller Class Initialized
INFO - 2022-03-29 01:02:43 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:02:43 --> Encrypt Class Initialized
INFO - 2022-03-29 01:02:43 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:02:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:02:43 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:02:43 --> Model "Users_model" initialized
INFO - 2022-03-29 01:02:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:02:43 --> Config Class Initialized
INFO - 2022-03-29 01:02:43 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:02:43 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:02:43 --> Utf8 Class Initialized
INFO - 2022-03-29 01:02:43 --> URI Class Initialized
INFO - 2022-03-29 01:02:43 --> Router Class Initialized
INFO - 2022-03-29 01:02:43 --> Output Class Initialized
INFO - 2022-03-29 01:02:43 --> Security Class Initialized
DEBUG - 2022-03-29 01:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:02:43 --> Input Class Initialized
INFO - 2022-03-29 01:02:43 --> Language Class Initialized
INFO - 2022-03-29 01:02:43 --> Loader Class Initialized
INFO - 2022-03-29 01:02:43 --> Helper loaded: url_helper
INFO - 2022-03-29 01:02:43 --> Helper loaded: form_helper
INFO - 2022-03-29 01:02:43 --> Helper loaded: common_helper
INFO - 2022-03-29 01:02:43 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:02:43 --> Controller Class Initialized
INFO - 2022-03-29 01:02:43 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:02:43 --> Encrypt Class Initialized
INFO - 2022-03-29 01:02:43 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:02:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:02:43 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:02:43 --> Model "Users_model" initialized
INFO - 2022-03-29 01:02:43 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:02:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:02:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:02:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:02:43 --> Final output sent to browser
DEBUG - 2022-03-29 01:02:43 --> Total execution time: 0.0364
ERROR - 2022-03-29 01:03:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:03:13 --> Config Class Initialized
INFO - 2022-03-29 01:03:13 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:03:13 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:03:13 --> Utf8 Class Initialized
INFO - 2022-03-29 01:03:13 --> URI Class Initialized
INFO - 2022-03-29 01:03:13 --> Router Class Initialized
INFO - 2022-03-29 01:03:13 --> Output Class Initialized
INFO - 2022-03-29 01:03:13 --> Security Class Initialized
DEBUG - 2022-03-29 01:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:03:13 --> Input Class Initialized
INFO - 2022-03-29 01:03:13 --> Language Class Initialized
INFO - 2022-03-29 01:03:13 --> Loader Class Initialized
INFO - 2022-03-29 01:03:13 --> Helper loaded: url_helper
INFO - 2022-03-29 01:03:13 --> Helper loaded: form_helper
INFO - 2022-03-29 01:03:13 --> Helper loaded: common_helper
INFO - 2022-03-29 01:03:13 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:03:13 --> Controller Class Initialized
INFO - 2022-03-29 01:03:13 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:03:13 --> Encrypt Class Initialized
INFO - 2022-03-29 01:03:13 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:03:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:03:13 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:03:13 --> Model "Users_model" initialized
INFO - 2022-03-29 01:03:13 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:03:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:03:13 --> Config Class Initialized
INFO - 2022-03-29 01:03:13 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:03:13 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:03:13 --> Utf8 Class Initialized
INFO - 2022-03-29 01:03:13 --> URI Class Initialized
INFO - 2022-03-29 01:03:13 --> Router Class Initialized
INFO - 2022-03-29 01:03:13 --> Output Class Initialized
INFO - 2022-03-29 01:03:13 --> Security Class Initialized
DEBUG - 2022-03-29 01:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:03:13 --> Input Class Initialized
INFO - 2022-03-29 01:03:13 --> Language Class Initialized
INFO - 2022-03-29 01:03:13 --> Loader Class Initialized
INFO - 2022-03-29 01:03:13 --> Helper loaded: url_helper
INFO - 2022-03-29 01:03:13 --> Helper loaded: form_helper
INFO - 2022-03-29 01:03:13 --> Helper loaded: common_helper
INFO - 2022-03-29 01:03:13 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:03:13 --> Controller Class Initialized
INFO - 2022-03-29 01:03:13 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:03:13 --> Encrypt Class Initialized
INFO - 2022-03-29 01:03:13 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:03:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:03:13 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:03:13 --> Model "Users_model" initialized
INFO - 2022-03-29 01:03:13 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:03:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:03:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:03:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:03:13 --> Final output sent to browser
DEBUG - 2022-03-29 01:03:13 --> Total execution time: 0.0444
ERROR - 2022-03-29 01:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:10:37 --> Config Class Initialized
INFO - 2022-03-29 01:10:37 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:10:37 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:10:37 --> Utf8 Class Initialized
INFO - 2022-03-29 01:10:37 --> URI Class Initialized
INFO - 2022-03-29 01:10:37 --> Router Class Initialized
INFO - 2022-03-29 01:10:37 --> Output Class Initialized
INFO - 2022-03-29 01:10:37 --> Security Class Initialized
DEBUG - 2022-03-29 01:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:10:37 --> Input Class Initialized
INFO - 2022-03-29 01:10:37 --> Language Class Initialized
INFO - 2022-03-29 01:10:37 --> Loader Class Initialized
INFO - 2022-03-29 01:10:37 --> Helper loaded: url_helper
INFO - 2022-03-29 01:10:37 --> Helper loaded: form_helper
INFO - 2022-03-29 01:10:37 --> Helper loaded: common_helper
INFO - 2022-03-29 01:10:37 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:10:37 --> Controller Class Initialized
INFO - 2022-03-29 01:10:37 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:10:37 --> Encrypt Class Initialized
INFO - 2022-03-29 01:10:37 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:10:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:10:37 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:10:37 --> Model "Users_model" initialized
INFO - 2022-03-29 01:10:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:10:37 --> Config Class Initialized
INFO - 2022-03-29 01:10:37 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:10:37 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:10:37 --> Utf8 Class Initialized
INFO - 2022-03-29 01:10:37 --> URI Class Initialized
INFO - 2022-03-29 01:10:37 --> Router Class Initialized
INFO - 2022-03-29 01:10:37 --> Output Class Initialized
INFO - 2022-03-29 01:10:37 --> Security Class Initialized
DEBUG - 2022-03-29 01:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:10:37 --> Input Class Initialized
INFO - 2022-03-29 01:10:37 --> Language Class Initialized
INFO - 2022-03-29 01:10:37 --> Loader Class Initialized
INFO - 2022-03-29 01:10:37 --> Helper loaded: url_helper
INFO - 2022-03-29 01:10:37 --> Helper loaded: form_helper
INFO - 2022-03-29 01:10:37 --> Helper loaded: common_helper
INFO - 2022-03-29 01:10:37 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:10:37 --> Controller Class Initialized
INFO - 2022-03-29 01:10:37 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:10:37 --> Encrypt Class Initialized
INFO - 2022-03-29 01:10:37 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:10:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:10:37 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:10:37 --> Model "Users_model" initialized
INFO - 2022-03-29 01:10:37 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:10:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:10:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:10:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:10:37 --> Final output sent to browser
DEBUG - 2022-03-29 01:10:37 --> Total execution time: 0.1085
ERROR - 2022-03-29 01:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:13:44 --> Config Class Initialized
INFO - 2022-03-29 01:13:44 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:13:44 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:13:44 --> Utf8 Class Initialized
INFO - 2022-03-29 01:13:44 --> URI Class Initialized
INFO - 2022-03-29 01:13:44 --> Router Class Initialized
INFO - 2022-03-29 01:13:44 --> Output Class Initialized
INFO - 2022-03-29 01:13:44 --> Security Class Initialized
DEBUG - 2022-03-29 01:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:13:44 --> Input Class Initialized
INFO - 2022-03-29 01:13:44 --> Language Class Initialized
INFO - 2022-03-29 01:13:44 --> Loader Class Initialized
INFO - 2022-03-29 01:13:44 --> Helper loaded: url_helper
INFO - 2022-03-29 01:13:44 --> Helper loaded: form_helper
INFO - 2022-03-29 01:13:44 --> Helper loaded: common_helper
INFO - 2022-03-29 01:13:44 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:13:44 --> Controller Class Initialized
INFO - 2022-03-29 01:13:44 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:13:44 --> Encrypt Class Initialized
INFO - 2022-03-29 01:13:44 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:13:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:13:44 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:13:44 --> Model "Users_model" initialized
INFO - 2022-03-29 01:13:44 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:13:44 --> Upload Class Initialized
INFO - 2022-03-29 01:13:44 --> Final output sent to browser
DEBUG - 2022-03-29 01:13:44 --> Total execution time: 0.0728
ERROR - 2022-03-29 01:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:13:54 --> Config Class Initialized
INFO - 2022-03-29 01:13:54 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:13:54 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:13:54 --> Utf8 Class Initialized
INFO - 2022-03-29 01:13:54 --> URI Class Initialized
INFO - 2022-03-29 01:13:54 --> Router Class Initialized
INFO - 2022-03-29 01:13:54 --> Output Class Initialized
INFO - 2022-03-29 01:13:54 --> Security Class Initialized
DEBUG - 2022-03-29 01:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:13:54 --> Input Class Initialized
INFO - 2022-03-29 01:13:54 --> Language Class Initialized
INFO - 2022-03-29 01:13:54 --> Loader Class Initialized
INFO - 2022-03-29 01:13:54 --> Helper loaded: url_helper
INFO - 2022-03-29 01:13:54 --> Helper loaded: form_helper
INFO - 2022-03-29 01:13:54 --> Helper loaded: common_helper
INFO - 2022-03-29 01:13:54 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:13:54 --> Controller Class Initialized
INFO - 2022-03-29 01:13:54 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:13:54 --> Encrypt Class Initialized
INFO - 2022-03-29 01:13:54 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:13:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:13:54 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:13:54 --> Model "Users_model" initialized
INFO - 2022-03-29 01:13:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:13:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:13:55 --> Config Class Initialized
INFO - 2022-03-29 01:13:55 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:13:55 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:13:55 --> Utf8 Class Initialized
INFO - 2022-03-29 01:13:55 --> URI Class Initialized
INFO - 2022-03-29 01:13:55 --> Router Class Initialized
INFO - 2022-03-29 01:13:55 --> Output Class Initialized
INFO - 2022-03-29 01:13:55 --> Security Class Initialized
DEBUG - 2022-03-29 01:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:13:55 --> Input Class Initialized
INFO - 2022-03-29 01:13:55 --> Language Class Initialized
INFO - 2022-03-29 01:13:55 --> Loader Class Initialized
INFO - 2022-03-29 01:13:55 --> Helper loaded: url_helper
INFO - 2022-03-29 01:13:55 --> Helper loaded: form_helper
INFO - 2022-03-29 01:13:55 --> Helper loaded: common_helper
INFO - 2022-03-29 01:13:55 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:13:55 --> Controller Class Initialized
INFO - 2022-03-29 01:13:55 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:13:55 --> Encrypt Class Initialized
INFO - 2022-03-29 01:13:55 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:13:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:13:55 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:13:55 --> Model "Users_model" initialized
INFO - 2022-03-29 01:13:55 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:13:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:13:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:13:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:13:55 --> Final output sent to browser
DEBUG - 2022-03-29 01:13:55 --> Total execution time: 0.0684
ERROR - 2022-03-29 01:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:35:45 --> Config Class Initialized
INFO - 2022-03-29 01:35:45 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:35:45 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:35:45 --> Utf8 Class Initialized
INFO - 2022-03-29 01:35:45 --> URI Class Initialized
INFO - 2022-03-29 01:35:45 --> Router Class Initialized
INFO - 2022-03-29 01:35:45 --> Output Class Initialized
INFO - 2022-03-29 01:35:45 --> Security Class Initialized
DEBUG - 2022-03-29 01:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:35:45 --> Input Class Initialized
INFO - 2022-03-29 01:35:45 --> Language Class Initialized
INFO - 2022-03-29 01:35:45 --> Loader Class Initialized
INFO - 2022-03-29 01:35:45 --> Helper loaded: url_helper
INFO - 2022-03-29 01:35:45 --> Helper loaded: form_helper
INFO - 2022-03-29 01:35:45 --> Helper loaded: common_helper
INFO - 2022-03-29 01:35:45 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:35:45 --> Controller Class Initialized
INFO - 2022-03-29 01:35:45 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:35:45 --> Encrypt Class Initialized
INFO - 2022-03-29 01:35:45 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:35:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:35:45 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:35:45 --> Model "Users_model" initialized
INFO - 2022-03-29 01:35:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:35:45 --> Config Class Initialized
INFO - 2022-03-29 01:35:45 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:35:45 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:35:45 --> Utf8 Class Initialized
INFO - 2022-03-29 01:35:45 --> URI Class Initialized
INFO - 2022-03-29 01:35:45 --> Router Class Initialized
INFO - 2022-03-29 01:35:45 --> Output Class Initialized
INFO - 2022-03-29 01:35:45 --> Security Class Initialized
DEBUG - 2022-03-29 01:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:35:45 --> Input Class Initialized
INFO - 2022-03-29 01:35:45 --> Language Class Initialized
INFO - 2022-03-29 01:35:45 --> Loader Class Initialized
INFO - 2022-03-29 01:35:45 --> Helper loaded: url_helper
INFO - 2022-03-29 01:35:45 --> Helper loaded: form_helper
INFO - 2022-03-29 01:35:45 --> Helper loaded: common_helper
INFO - 2022-03-29 01:35:45 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:35:45 --> Controller Class Initialized
INFO - 2022-03-29 01:35:45 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:35:45 --> Encrypt Class Initialized
INFO - 2022-03-29 01:35:45 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:35:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:35:45 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:35:45 --> Model "Users_model" initialized
INFO - 2022-03-29 01:35:45 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:35:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:35:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:35:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:35:46 --> Final output sent to browser
DEBUG - 2022-03-29 01:35:46 --> Total execution time: 0.0571
ERROR - 2022-03-29 01:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:35:50 --> Config Class Initialized
INFO - 2022-03-29 01:35:50 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:35:50 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:35:50 --> Utf8 Class Initialized
INFO - 2022-03-29 01:35:50 --> URI Class Initialized
INFO - 2022-03-29 01:35:50 --> Router Class Initialized
INFO - 2022-03-29 01:35:50 --> Output Class Initialized
INFO - 2022-03-29 01:35:50 --> Security Class Initialized
DEBUG - 2022-03-29 01:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:35:50 --> Input Class Initialized
INFO - 2022-03-29 01:35:50 --> Language Class Initialized
INFO - 2022-03-29 01:35:50 --> Loader Class Initialized
INFO - 2022-03-29 01:35:50 --> Helper loaded: url_helper
INFO - 2022-03-29 01:35:50 --> Helper loaded: form_helper
INFO - 2022-03-29 01:35:50 --> Helper loaded: common_helper
INFO - 2022-03-29 01:35:50 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:35:50 --> Controller Class Initialized
INFO - 2022-03-29 01:35:51 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:35:51 --> Encrypt Class Initialized
INFO - 2022-03-29 01:35:51 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:35:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:35:51 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:35:51 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:35:51 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:35:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:35:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 01:35:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:35:51 --> Final output sent to browser
DEBUG - 2022-03-29 01:35:51 --> Total execution time: 0.0284
ERROR - 2022-03-29 01:36:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:36:04 --> Config Class Initialized
INFO - 2022-03-29 01:36:04 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:36:04 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:36:04 --> Utf8 Class Initialized
INFO - 2022-03-29 01:36:04 --> URI Class Initialized
INFO - 2022-03-29 01:36:04 --> Router Class Initialized
INFO - 2022-03-29 01:36:04 --> Output Class Initialized
INFO - 2022-03-29 01:36:04 --> Security Class Initialized
DEBUG - 2022-03-29 01:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:36:04 --> Input Class Initialized
INFO - 2022-03-29 01:36:04 --> Language Class Initialized
INFO - 2022-03-29 01:36:04 --> Loader Class Initialized
INFO - 2022-03-29 01:36:04 --> Helper loaded: url_helper
INFO - 2022-03-29 01:36:04 --> Helper loaded: form_helper
INFO - 2022-03-29 01:36:04 --> Helper loaded: common_helper
INFO - 2022-03-29 01:36:04 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:36:04 --> Controller Class Initialized
INFO - 2022-03-29 01:36:04 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:36:04 --> Encrypt Class Initialized
INFO - 2022-03-29 01:36:04 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:36:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:36:04 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:36:04 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:36:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:36:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:36:04 --> Config Class Initialized
INFO - 2022-03-29 01:36:04 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:36:04 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:36:04 --> Utf8 Class Initialized
INFO - 2022-03-29 01:36:04 --> URI Class Initialized
INFO - 2022-03-29 01:36:04 --> Router Class Initialized
INFO - 2022-03-29 01:36:04 --> Output Class Initialized
INFO - 2022-03-29 01:36:04 --> Security Class Initialized
DEBUG - 2022-03-29 01:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:36:04 --> Input Class Initialized
INFO - 2022-03-29 01:36:04 --> Language Class Initialized
INFO - 2022-03-29 01:36:04 --> Loader Class Initialized
INFO - 2022-03-29 01:36:04 --> Helper loaded: url_helper
INFO - 2022-03-29 01:36:04 --> Helper loaded: form_helper
INFO - 2022-03-29 01:36:04 --> Helper loaded: common_helper
INFO - 2022-03-29 01:36:04 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:36:04 --> Controller Class Initialized
INFO - 2022-03-29 01:36:04 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:36:04 --> Encrypt Class Initialized
INFO - 2022-03-29 01:36:04 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:36:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:36:04 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:36:04 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:36:04 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:36:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:36:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 01:36:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:36:04 --> Final output sent to browser
DEBUG - 2022-03-29 01:36:04 --> Total execution time: 0.0246
ERROR - 2022-03-29 01:36:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:36:05 --> Config Class Initialized
INFO - 2022-03-29 01:36:05 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:36:05 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:36:05 --> Utf8 Class Initialized
INFO - 2022-03-29 01:36:05 --> URI Class Initialized
INFO - 2022-03-29 01:36:05 --> Router Class Initialized
INFO - 2022-03-29 01:36:05 --> Output Class Initialized
INFO - 2022-03-29 01:36:05 --> Security Class Initialized
DEBUG - 2022-03-29 01:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:36:05 --> Input Class Initialized
INFO - 2022-03-29 01:36:05 --> Language Class Initialized
INFO - 2022-03-29 01:36:05 --> Loader Class Initialized
INFO - 2022-03-29 01:36:05 --> Helper loaded: url_helper
INFO - 2022-03-29 01:36:05 --> Helper loaded: form_helper
INFO - 2022-03-29 01:36:05 --> Helper loaded: common_helper
INFO - 2022-03-29 01:36:05 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:36:05 --> Controller Class Initialized
INFO - 2022-03-29 01:36:05 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:36:05 --> Encrypt Class Initialized
INFO - 2022-03-29 01:36:05 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:36:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:36:05 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:36:05 --> Model "Users_model" initialized
INFO - 2022-03-29 01:36:05 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:36:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:36:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:36:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:36:05 --> Final output sent to browser
DEBUG - 2022-03-29 01:36:05 --> Total execution time: 0.0367
ERROR - 2022-03-29 01:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:36:20 --> Config Class Initialized
INFO - 2022-03-29 01:36:20 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:36:20 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:36:20 --> Utf8 Class Initialized
INFO - 2022-03-29 01:36:20 --> URI Class Initialized
INFO - 2022-03-29 01:36:20 --> Router Class Initialized
INFO - 2022-03-29 01:36:20 --> Output Class Initialized
INFO - 2022-03-29 01:36:20 --> Security Class Initialized
DEBUG - 2022-03-29 01:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:36:20 --> Input Class Initialized
INFO - 2022-03-29 01:36:20 --> Language Class Initialized
INFO - 2022-03-29 01:36:20 --> Loader Class Initialized
INFO - 2022-03-29 01:36:20 --> Helper loaded: url_helper
INFO - 2022-03-29 01:36:20 --> Helper loaded: form_helper
INFO - 2022-03-29 01:36:20 --> Helper loaded: common_helper
INFO - 2022-03-29 01:36:20 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:36:20 --> Controller Class Initialized
INFO - 2022-03-29 01:36:20 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:36:20 --> Encrypt Class Initialized
INFO - 2022-03-29 01:36:20 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:36:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:36:20 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:36:20 --> Model "Users_model" initialized
INFO - 2022-03-29 01:36:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:36:20 --> Config Class Initialized
INFO - 2022-03-29 01:36:20 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:36:20 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:36:20 --> Utf8 Class Initialized
INFO - 2022-03-29 01:36:20 --> URI Class Initialized
INFO - 2022-03-29 01:36:20 --> Router Class Initialized
INFO - 2022-03-29 01:36:20 --> Output Class Initialized
INFO - 2022-03-29 01:36:20 --> Security Class Initialized
DEBUG - 2022-03-29 01:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:36:20 --> Input Class Initialized
INFO - 2022-03-29 01:36:20 --> Language Class Initialized
INFO - 2022-03-29 01:36:20 --> Loader Class Initialized
INFO - 2022-03-29 01:36:20 --> Helper loaded: url_helper
INFO - 2022-03-29 01:36:20 --> Helper loaded: form_helper
INFO - 2022-03-29 01:36:20 --> Helper loaded: common_helper
INFO - 2022-03-29 01:36:20 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:36:20 --> Controller Class Initialized
INFO - 2022-03-29 01:36:20 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:36:20 --> Encrypt Class Initialized
INFO - 2022-03-29 01:36:20 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:36:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:36:20 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:36:20 --> Model "Users_model" initialized
INFO - 2022-03-29 01:36:20 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:36:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:36:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:36:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:36:21 --> Final output sent to browser
DEBUG - 2022-03-29 01:36:21 --> Total execution time: 0.0442
ERROR - 2022-03-29 01:36:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:36:53 --> Config Class Initialized
INFO - 2022-03-29 01:36:53 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:36:53 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:36:53 --> Utf8 Class Initialized
INFO - 2022-03-29 01:36:53 --> URI Class Initialized
INFO - 2022-03-29 01:36:53 --> Router Class Initialized
INFO - 2022-03-29 01:36:53 --> Output Class Initialized
INFO - 2022-03-29 01:36:53 --> Security Class Initialized
DEBUG - 2022-03-29 01:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:36:53 --> Input Class Initialized
INFO - 2022-03-29 01:36:53 --> Language Class Initialized
INFO - 2022-03-29 01:36:53 --> Loader Class Initialized
INFO - 2022-03-29 01:36:53 --> Helper loaded: url_helper
INFO - 2022-03-29 01:36:53 --> Helper loaded: form_helper
INFO - 2022-03-29 01:36:53 --> Helper loaded: common_helper
INFO - 2022-03-29 01:36:53 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:36:53 --> Controller Class Initialized
INFO - 2022-03-29 01:36:53 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:36:53 --> Encrypt Class Initialized
INFO - 2022-03-29 01:36:53 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:36:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:36:53 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:36:53 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:36:53 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:36:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:36:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 01:36:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:36:53 --> Final output sent to browser
DEBUG - 2022-03-29 01:36:53 --> Total execution time: 0.3441
ERROR - 2022-03-29 01:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:38:43 --> Config Class Initialized
INFO - 2022-03-29 01:38:43 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:38:43 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:38:43 --> Utf8 Class Initialized
INFO - 2022-03-29 01:38:43 --> URI Class Initialized
INFO - 2022-03-29 01:38:43 --> Router Class Initialized
INFO - 2022-03-29 01:38:43 --> Output Class Initialized
INFO - 2022-03-29 01:38:43 --> Security Class Initialized
DEBUG - 2022-03-29 01:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:38:43 --> Input Class Initialized
INFO - 2022-03-29 01:38:43 --> Language Class Initialized
INFO - 2022-03-29 01:38:43 --> Loader Class Initialized
INFO - 2022-03-29 01:38:43 --> Helper loaded: url_helper
INFO - 2022-03-29 01:38:43 --> Helper loaded: form_helper
INFO - 2022-03-29 01:38:43 --> Helper loaded: common_helper
INFO - 2022-03-29 01:38:43 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:38:43 --> Controller Class Initialized
INFO - 2022-03-29 01:38:43 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:38:43 --> Encrypt Class Initialized
INFO - 2022-03-29 01:38:43 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:38:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:38:43 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:38:43 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:38:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:38:43 --> Config Class Initialized
INFO - 2022-03-29 01:38:43 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:38:43 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:38:43 --> Utf8 Class Initialized
INFO - 2022-03-29 01:38:43 --> URI Class Initialized
INFO - 2022-03-29 01:38:43 --> Router Class Initialized
INFO - 2022-03-29 01:38:43 --> Output Class Initialized
INFO - 2022-03-29 01:38:43 --> Security Class Initialized
DEBUG - 2022-03-29 01:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:38:43 --> Input Class Initialized
INFO - 2022-03-29 01:38:43 --> Language Class Initialized
INFO - 2022-03-29 01:38:43 --> Loader Class Initialized
INFO - 2022-03-29 01:38:43 --> Helper loaded: url_helper
INFO - 2022-03-29 01:38:43 --> Helper loaded: form_helper
INFO - 2022-03-29 01:38:43 --> Helper loaded: common_helper
INFO - 2022-03-29 01:38:43 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:38:43 --> Controller Class Initialized
INFO - 2022-03-29 01:38:43 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:38:43 --> Encrypt Class Initialized
INFO - 2022-03-29 01:38:43 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:38:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:38:43 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:38:43 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:38:43 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:38:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:38:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 01:38:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:38:43 --> Final output sent to browser
DEBUG - 2022-03-29 01:38:43 --> Total execution time: 0.0246
ERROR - 2022-03-29 01:38:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:38:44 --> Config Class Initialized
INFO - 2022-03-29 01:38:44 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:38:44 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:38:44 --> Utf8 Class Initialized
INFO - 2022-03-29 01:38:44 --> URI Class Initialized
INFO - 2022-03-29 01:38:44 --> Router Class Initialized
INFO - 2022-03-29 01:38:44 --> Output Class Initialized
INFO - 2022-03-29 01:38:44 --> Security Class Initialized
DEBUG - 2022-03-29 01:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:38:44 --> Input Class Initialized
INFO - 2022-03-29 01:38:44 --> Language Class Initialized
INFO - 2022-03-29 01:38:44 --> Loader Class Initialized
INFO - 2022-03-29 01:38:44 --> Helper loaded: url_helper
INFO - 2022-03-29 01:38:44 --> Helper loaded: form_helper
INFO - 2022-03-29 01:38:44 --> Helper loaded: common_helper
INFO - 2022-03-29 01:38:44 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:38:44 --> Controller Class Initialized
INFO - 2022-03-29 01:38:44 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:38:44 --> Encrypt Class Initialized
INFO - 2022-03-29 01:38:44 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:38:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:38:44 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:38:44 --> Model "Users_model" initialized
INFO - 2022-03-29 01:38:44 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:38:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:38:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:38:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:38:44 --> Final output sent to browser
DEBUG - 2022-03-29 01:38:44 --> Total execution time: 0.0384
ERROR - 2022-03-29 01:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:38:57 --> Config Class Initialized
INFO - 2022-03-29 01:38:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:38:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:38:57 --> Utf8 Class Initialized
INFO - 2022-03-29 01:38:57 --> URI Class Initialized
INFO - 2022-03-29 01:38:57 --> Router Class Initialized
INFO - 2022-03-29 01:38:57 --> Output Class Initialized
INFO - 2022-03-29 01:38:57 --> Security Class Initialized
DEBUG - 2022-03-29 01:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:38:57 --> Input Class Initialized
INFO - 2022-03-29 01:38:57 --> Language Class Initialized
INFO - 2022-03-29 01:38:57 --> Loader Class Initialized
INFO - 2022-03-29 01:38:57 --> Helper loaded: url_helper
INFO - 2022-03-29 01:38:57 --> Helper loaded: form_helper
INFO - 2022-03-29 01:38:57 --> Helper loaded: common_helper
INFO - 2022-03-29 01:38:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:38:57 --> Controller Class Initialized
INFO - 2022-03-29 01:38:57 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:38:57 --> Encrypt Class Initialized
INFO - 2022-03-29 01:38:57 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:38:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:38:57 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:38:57 --> Model "Users_model" initialized
INFO - 2022-03-29 01:38:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:38:57 --> Config Class Initialized
INFO - 2022-03-29 01:38:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:38:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:38:57 --> Utf8 Class Initialized
INFO - 2022-03-29 01:38:57 --> URI Class Initialized
INFO - 2022-03-29 01:38:57 --> Router Class Initialized
INFO - 2022-03-29 01:38:57 --> Output Class Initialized
INFO - 2022-03-29 01:38:57 --> Security Class Initialized
DEBUG - 2022-03-29 01:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:38:57 --> Input Class Initialized
INFO - 2022-03-29 01:38:57 --> Language Class Initialized
INFO - 2022-03-29 01:38:57 --> Loader Class Initialized
INFO - 2022-03-29 01:38:57 --> Helper loaded: url_helper
INFO - 2022-03-29 01:38:57 --> Helper loaded: form_helper
INFO - 2022-03-29 01:38:57 --> Helper loaded: common_helper
INFO - 2022-03-29 01:38:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:38:57 --> Controller Class Initialized
INFO - 2022-03-29 01:38:57 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:38:57 --> Encrypt Class Initialized
INFO - 2022-03-29 01:38:57 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:38:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:38:57 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:38:57 --> Model "Users_model" initialized
INFO - 2022-03-29 01:38:57 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:38:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:38:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:38:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:38:57 --> Final output sent to browser
DEBUG - 2022-03-29 01:38:57 --> Total execution time: 0.0369
ERROR - 2022-03-29 01:42:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:42:43 --> Config Class Initialized
INFO - 2022-03-29 01:42:43 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:42:43 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:42:43 --> Utf8 Class Initialized
INFO - 2022-03-29 01:42:43 --> URI Class Initialized
INFO - 2022-03-29 01:42:43 --> Router Class Initialized
INFO - 2022-03-29 01:42:43 --> Output Class Initialized
INFO - 2022-03-29 01:42:43 --> Security Class Initialized
DEBUG - 2022-03-29 01:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:42:43 --> Input Class Initialized
INFO - 2022-03-29 01:42:43 --> Language Class Initialized
INFO - 2022-03-29 01:42:43 --> Loader Class Initialized
INFO - 2022-03-29 01:42:43 --> Helper loaded: url_helper
INFO - 2022-03-29 01:42:43 --> Helper loaded: form_helper
INFO - 2022-03-29 01:42:43 --> Helper loaded: common_helper
INFO - 2022-03-29 01:42:43 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:42:43 --> Controller Class Initialized
INFO - 2022-03-29 01:42:43 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:42:43 --> Encrypt Class Initialized
INFO - 2022-03-29 01:42:43 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:42:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:42:43 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:42:43 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:42:43 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:42:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:42:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 01:42:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:42:43 --> Final output sent to browser
DEBUG - 2022-03-29 01:42:43 --> Total execution time: 0.1278
ERROR - 2022-03-29 01:42:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:42:51 --> Config Class Initialized
INFO - 2022-03-29 01:42:51 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:42:51 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:42:51 --> Utf8 Class Initialized
INFO - 2022-03-29 01:42:51 --> URI Class Initialized
INFO - 2022-03-29 01:42:51 --> Router Class Initialized
INFO - 2022-03-29 01:42:51 --> Output Class Initialized
INFO - 2022-03-29 01:42:51 --> Security Class Initialized
DEBUG - 2022-03-29 01:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:42:51 --> Input Class Initialized
INFO - 2022-03-29 01:42:51 --> Language Class Initialized
INFO - 2022-03-29 01:42:51 --> Loader Class Initialized
INFO - 2022-03-29 01:42:51 --> Helper loaded: url_helper
INFO - 2022-03-29 01:42:51 --> Helper loaded: form_helper
INFO - 2022-03-29 01:42:51 --> Helper loaded: common_helper
INFO - 2022-03-29 01:42:51 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:42:51 --> Controller Class Initialized
INFO - 2022-03-29 01:42:51 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:42:51 --> Encrypt Class Initialized
INFO - 2022-03-29 01:42:51 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:42:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:42:51 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:42:51 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:42:51 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:42:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:42:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 01:42:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:42:51 --> Final output sent to browser
DEBUG - 2022-03-29 01:42:51 --> Total execution time: 0.0630
ERROR - 2022-03-29 01:43:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:43:02 --> Config Class Initialized
INFO - 2022-03-29 01:43:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:43:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:43:02 --> Utf8 Class Initialized
INFO - 2022-03-29 01:43:02 --> URI Class Initialized
INFO - 2022-03-29 01:43:02 --> Router Class Initialized
INFO - 2022-03-29 01:43:02 --> Output Class Initialized
INFO - 2022-03-29 01:43:02 --> Security Class Initialized
DEBUG - 2022-03-29 01:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:43:02 --> Input Class Initialized
INFO - 2022-03-29 01:43:02 --> Language Class Initialized
INFO - 2022-03-29 01:43:02 --> Loader Class Initialized
INFO - 2022-03-29 01:43:02 --> Helper loaded: url_helper
INFO - 2022-03-29 01:43:02 --> Helper loaded: form_helper
INFO - 2022-03-29 01:43:02 --> Helper loaded: common_helper
INFO - 2022-03-29 01:43:02 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:43:02 --> Controller Class Initialized
INFO - 2022-03-29 01:43:02 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:43:02 --> Encrypt Class Initialized
INFO - 2022-03-29 01:43:02 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:43:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:43:02 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:43:02 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:43:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:43:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:43:03 --> Config Class Initialized
INFO - 2022-03-29 01:43:03 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:43:03 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:43:03 --> Utf8 Class Initialized
INFO - 2022-03-29 01:43:03 --> URI Class Initialized
INFO - 2022-03-29 01:43:03 --> Router Class Initialized
INFO - 2022-03-29 01:43:03 --> Output Class Initialized
INFO - 2022-03-29 01:43:03 --> Security Class Initialized
DEBUG - 2022-03-29 01:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:43:03 --> Input Class Initialized
INFO - 2022-03-29 01:43:03 --> Language Class Initialized
INFO - 2022-03-29 01:43:03 --> Loader Class Initialized
INFO - 2022-03-29 01:43:03 --> Helper loaded: url_helper
INFO - 2022-03-29 01:43:03 --> Helper loaded: form_helper
INFO - 2022-03-29 01:43:03 --> Helper loaded: common_helper
INFO - 2022-03-29 01:43:03 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:43:03 --> Controller Class Initialized
INFO - 2022-03-29 01:43:03 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:43:03 --> Encrypt Class Initialized
INFO - 2022-03-29 01:43:03 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:43:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:43:03 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:43:03 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:43:03 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:43:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:43:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 01:43:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:43:03 --> Final output sent to browser
DEBUG - 2022-03-29 01:43:03 --> Total execution time: 0.0253
ERROR - 2022-03-29 01:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:43:04 --> Config Class Initialized
INFO - 2022-03-29 01:43:04 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:43:04 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:43:04 --> Utf8 Class Initialized
INFO - 2022-03-29 01:43:04 --> URI Class Initialized
INFO - 2022-03-29 01:43:04 --> Router Class Initialized
INFO - 2022-03-29 01:43:04 --> Output Class Initialized
INFO - 2022-03-29 01:43:04 --> Security Class Initialized
DEBUG - 2022-03-29 01:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:43:04 --> Input Class Initialized
INFO - 2022-03-29 01:43:04 --> Language Class Initialized
INFO - 2022-03-29 01:43:04 --> Loader Class Initialized
INFO - 2022-03-29 01:43:04 --> Helper loaded: url_helper
INFO - 2022-03-29 01:43:04 --> Helper loaded: form_helper
INFO - 2022-03-29 01:43:04 --> Helper loaded: common_helper
INFO - 2022-03-29 01:43:04 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:43:04 --> Controller Class Initialized
INFO - 2022-03-29 01:43:04 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:43:04 --> Encrypt Class Initialized
INFO - 2022-03-29 01:43:04 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:43:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:43:04 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:43:04 --> Model "Users_model" initialized
INFO - 2022-03-29 01:43:04 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:43:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:43:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:43:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:43:04 --> Final output sent to browser
DEBUG - 2022-03-29 01:43:04 --> Total execution time: 0.0455
ERROR - 2022-03-29 01:45:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:45:10 --> Config Class Initialized
INFO - 2022-03-29 01:45:10 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:45:10 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:45:10 --> Utf8 Class Initialized
INFO - 2022-03-29 01:45:10 --> URI Class Initialized
INFO - 2022-03-29 01:45:10 --> Router Class Initialized
INFO - 2022-03-29 01:45:10 --> Output Class Initialized
INFO - 2022-03-29 01:45:10 --> Security Class Initialized
DEBUG - 2022-03-29 01:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:45:10 --> Input Class Initialized
INFO - 2022-03-29 01:45:10 --> Language Class Initialized
INFO - 2022-03-29 01:45:10 --> Loader Class Initialized
INFO - 2022-03-29 01:45:10 --> Helper loaded: url_helper
INFO - 2022-03-29 01:45:10 --> Helper loaded: form_helper
INFO - 2022-03-29 01:45:10 --> Helper loaded: common_helper
INFO - 2022-03-29 01:45:10 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:45:10 --> Controller Class Initialized
INFO - 2022-03-29 01:45:10 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:45:10 --> Encrypt Class Initialized
INFO - 2022-03-29 01:45:10 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:45:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:45:10 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:45:10 --> Model "Users_model" initialized
INFO - 2022-03-29 01:45:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:45:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:45:11 --> Config Class Initialized
INFO - 2022-03-29 01:45:11 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:45:11 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:45:11 --> Utf8 Class Initialized
INFO - 2022-03-29 01:45:11 --> URI Class Initialized
INFO - 2022-03-29 01:45:11 --> Router Class Initialized
INFO - 2022-03-29 01:45:11 --> Output Class Initialized
INFO - 2022-03-29 01:45:11 --> Security Class Initialized
DEBUG - 2022-03-29 01:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:45:11 --> Input Class Initialized
INFO - 2022-03-29 01:45:11 --> Language Class Initialized
INFO - 2022-03-29 01:45:11 --> Loader Class Initialized
INFO - 2022-03-29 01:45:11 --> Helper loaded: url_helper
INFO - 2022-03-29 01:45:11 --> Helper loaded: form_helper
INFO - 2022-03-29 01:45:11 --> Helper loaded: common_helper
INFO - 2022-03-29 01:45:11 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:45:11 --> Controller Class Initialized
INFO - 2022-03-29 01:45:11 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:45:11 --> Encrypt Class Initialized
INFO - 2022-03-29 01:45:11 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:45:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:45:11 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:45:11 --> Model "Users_model" initialized
INFO - 2022-03-29 01:45:11 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:45:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:45:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:45:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:45:11 --> Final output sent to browser
DEBUG - 2022-03-29 01:45:11 --> Total execution time: 0.1959
ERROR - 2022-03-29 01:45:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:45:37 --> Config Class Initialized
INFO - 2022-03-29 01:45:37 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:45:37 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:45:37 --> Utf8 Class Initialized
INFO - 2022-03-29 01:45:37 --> URI Class Initialized
INFO - 2022-03-29 01:45:37 --> Router Class Initialized
INFO - 2022-03-29 01:45:37 --> Output Class Initialized
INFO - 2022-03-29 01:45:37 --> Security Class Initialized
DEBUG - 2022-03-29 01:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:45:37 --> Input Class Initialized
INFO - 2022-03-29 01:45:37 --> Language Class Initialized
INFO - 2022-03-29 01:45:37 --> Loader Class Initialized
INFO - 2022-03-29 01:45:37 --> Helper loaded: url_helper
INFO - 2022-03-29 01:45:37 --> Helper loaded: form_helper
INFO - 2022-03-29 01:45:37 --> Helper loaded: common_helper
INFO - 2022-03-29 01:45:37 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:45:37 --> Controller Class Initialized
INFO - 2022-03-29 01:45:37 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:45:37 --> Encrypt Class Initialized
INFO - 2022-03-29 01:45:37 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:45:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:45:37 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:45:37 --> Model "Users_model" initialized
INFO - 2022-03-29 01:45:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:45:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:45:37 --> Config Class Initialized
INFO - 2022-03-29 01:45:37 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:45:37 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:45:37 --> Utf8 Class Initialized
INFO - 2022-03-29 01:45:37 --> URI Class Initialized
INFO - 2022-03-29 01:45:37 --> Router Class Initialized
INFO - 2022-03-29 01:45:37 --> Output Class Initialized
INFO - 2022-03-29 01:45:37 --> Security Class Initialized
DEBUG - 2022-03-29 01:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:45:37 --> Input Class Initialized
INFO - 2022-03-29 01:45:37 --> Language Class Initialized
INFO - 2022-03-29 01:45:37 --> Loader Class Initialized
INFO - 2022-03-29 01:45:37 --> Helper loaded: url_helper
INFO - 2022-03-29 01:45:37 --> Helper loaded: form_helper
INFO - 2022-03-29 01:45:37 --> Helper loaded: common_helper
INFO - 2022-03-29 01:45:37 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:45:37 --> Controller Class Initialized
INFO - 2022-03-29 01:45:37 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:45:37 --> Encrypt Class Initialized
INFO - 2022-03-29 01:45:37 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:45:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:45:37 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:45:37 --> Model "Users_model" initialized
INFO - 2022-03-29 01:45:37 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:45:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:45:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:45:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:45:37 --> Final output sent to browser
DEBUG - 2022-03-29 01:45:37 --> Total execution time: 0.0485
ERROR - 2022-03-29 01:46:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:46:06 --> Config Class Initialized
INFO - 2022-03-29 01:46:06 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:46:06 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:46:06 --> Utf8 Class Initialized
INFO - 2022-03-29 01:46:06 --> URI Class Initialized
INFO - 2022-03-29 01:46:06 --> Router Class Initialized
INFO - 2022-03-29 01:46:06 --> Output Class Initialized
INFO - 2022-03-29 01:46:06 --> Security Class Initialized
DEBUG - 2022-03-29 01:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:46:06 --> Input Class Initialized
INFO - 2022-03-29 01:46:06 --> Language Class Initialized
INFO - 2022-03-29 01:46:06 --> Loader Class Initialized
INFO - 2022-03-29 01:46:06 --> Helper loaded: url_helper
INFO - 2022-03-29 01:46:06 --> Helper loaded: form_helper
INFO - 2022-03-29 01:46:06 --> Helper loaded: common_helper
INFO - 2022-03-29 01:46:06 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:46:06 --> Controller Class Initialized
INFO - 2022-03-29 01:46:06 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:46:06 --> Encrypt Class Initialized
INFO - 2022-03-29 01:46:06 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:46:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:46:06 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:46:06 --> Model "Users_model" initialized
INFO - 2022-03-29 01:46:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:46:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:46:07 --> Config Class Initialized
INFO - 2022-03-29 01:46:07 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:46:07 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:46:07 --> Utf8 Class Initialized
INFO - 2022-03-29 01:46:07 --> URI Class Initialized
INFO - 2022-03-29 01:46:07 --> Router Class Initialized
INFO - 2022-03-29 01:46:07 --> Output Class Initialized
INFO - 2022-03-29 01:46:07 --> Security Class Initialized
DEBUG - 2022-03-29 01:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:46:07 --> Input Class Initialized
INFO - 2022-03-29 01:46:07 --> Language Class Initialized
INFO - 2022-03-29 01:46:07 --> Loader Class Initialized
INFO - 2022-03-29 01:46:07 --> Helper loaded: url_helper
INFO - 2022-03-29 01:46:07 --> Helper loaded: form_helper
INFO - 2022-03-29 01:46:07 --> Helper loaded: common_helper
INFO - 2022-03-29 01:46:07 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:46:07 --> Controller Class Initialized
INFO - 2022-03-29 01:46:07 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:46:07 --> Encrypt Class Initialized
INFO - 2022-03-29 01:46:07 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:46:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:46:07 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:46:07 --> Model "Users_model" initialized
INFO - 2022-03-29 01:46:07 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:46:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:46:07 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:46:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:46:07 --> Final output sent to browser
DEBUG - 2022-03-29 01:46:07 --> Total execution time: 0.0480
ERROR - 2022-03-29 01:46:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:46:14 --> Config Class Initialized
INFO - 2022-03-29 01:46:14 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:46:14 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:46:14 --> Utf8 Class Initialized
INFO - 2022-03-29 01:46:14 --> URI Class Initialized
INFO - 2022-03-29 01:46:14 --> Router Class Initialized
INFO - 2022-03-29 01:46:14 --> Output Class Initialized
INFO - 2022-03-29 01:46:14 --> Security Class Initialized
DEBUG - 2022-03-29 01:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:46:14 --> Input Class Initialized
INFO - 2022-03-29 01:46:14 --> Language Class Initialized
INFO - 2022-03-29 01:46:14 --> Loader Class Initialized
INFO - 2022-03-29 01:46:14 --> Helper loaded: url_helper
INFO - 2022-03-29 01:46:14 --> Helper loaded: form_helper
INFO - 2022-03-29 01:46:14 --> Helper loaded: common_helper
INFO - 2022-03-29 01:46:14 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:46:14 --> Controller Class Initialized
INFO - 2022-03-29 01:46:14 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:46:14 --> Encrypt Class Initialized
INFO - 2022-03-29 01:46:14 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:46:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:46:14 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:46:14 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:46:14 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:46:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:46:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 01:46:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:46:14 --> Final output sent to browser
DEBUG - 2022-03-29 01:46:14 --> Total execution time: 0.0560
ERROR - 2022-03-29 01:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:46:28 --> Config Class Initialized
INFO - 2022-03-29 01:46:28 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:46:28 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:46:28 --> Utf8 Class Initialized
INFO - 2022-03-29 01:46:28 --> URI Class Initialized
INFO - 2022-03-29 01:46:28 --> Router Class Initialized
INFO - 2022-03-29 01:46:28 --> Output Class Initialized
INFO - 2022-03-29 01:46:28 --> Security Class Initialized
DEBUG - 2022-03-29 01:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:46:28 --> Input Class Initialized
INFO - 2022-03-29 01:46:28 --> Language Class Initialized
INFO - 2022-03-29 01:46:28 --> Loader Class Initialized
INFO - 2022-03-29 01:46:28 --> Helper loaded: url_helper
INFO - 2022-03-29 01:46:28 --> Helper loaded: form_helper
INFO - 2022-03-29 01:46:28 --> Helper loaded: common_helper
INFO - 2022-03-29 01:46:28 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:46:28 --> Controller Class Initialized
INFO - 2022-03-29 01:46:28 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:46:28 --> Encrypt Class Initialized
INFO - 2022-03-29 01:46:28 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:46:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:46:28 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:46:28 --> Model "Users_model" initialized
INFO - 2022-03-29 01:46:28 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:46:28 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 01:46:29 --> Final output sent to browser
DEBUG - 2022-03-29 01:46:29 --> Total execution time: 1.2759
ERROR - 2022-03-29 01:57:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:57:29 --> Config Class Initialized
INFO - 2022-03-29 01:57:29 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:57:29 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:57:29 --> Utf8 Class Initialized
INFO - 2022-03-29 01:57:29 --> URI Class Initialized
INFO - 2022-03-29 01:57:29 --> Router Class Initialized
INFO - 2022-03-29 01:57:29 --> Output Class Initialized
INFO - 2022-03-29 01:57:29 --> Security Class Initialized
DEBUG - 2022-03-29 01:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:57:29 --> Input Class Initialized
INFO - 2022-03-29 01:57:29 --> Language Class Initialized
INFO - 2022-03-29 01:57:29 --> Loader Class Initialized
INFO - 2022-03-29 01:57:29 --> Helper loaded: url_helper
INFO - 2022-03-29 01:57:29 --> Helper loaded: form_helper
INFO - 2022-03-29 01:57:29 --> Helper loaded: common_helper
INFO - 2022-03-29 01:57:29 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:57:29 --> Controller Class Initialized
INFO - 2022-03-29 01:57:29 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:57:29 --> Encrypt Class Initialized
INFO - 2022-03-29 01:57:29 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:57:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:57:29 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:57:29 --> Model "Users_model" initialized
INFO - 2022-03-29 01:57:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:57:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:57:29 --> Config Class Initialized
INFO - 2022-03-29 01:57:29 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:57:29 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:57:29 --> Utf8 Class Initialized
INFO - 2022-03-29 01:57:29 --> URI Class Initialized
INFO - 2022-03-29 01:57:29 --> Router Class Initialized
INFO - 2022-03-29 01:57:29 --> Output Class Initialized
INFO - 2022-03-29 01:57:29 --> Security Class Initialized
DEBUG - 2022-03-29 01:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:57:29 --> Input Class Initialized
INFO - 2022-03-29 01:57:29 --> Language Class Initialized
INFO - 2022-03-29 01:57:29 --> Loader Class Initialized
INFO - 2022-03-29 01:57:29 --> Helper loaded: url_helper
INFO - 2022-03-29 01:57:29 --> Helper loaded: form_helper
INFO - 2022-03-29 01:57:29 --> Helper loaded: common_helper
INFO - 2022-03-29 01:57:29 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:57:29 --> Controller Class Initialized
INFO - 2022-03-29 01:57:29 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:57:29 --> Encrypt Class Initialized
INFO - 2022-03-29 01:57:29 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:57:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:57:29 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:57:29 --> Model "Users_model" initialized
INFO - 2022-03-29 01:57:29 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:57:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:57:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:57:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:57:29 --> Final output sent to browser
DEBUG - 2022-03-29 01:57:29 --> Total execution time: 0.0471
ERROR - 2022-03-29 01:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:57:47 --> Config Class Initialized
INFO - 2022-03-29 01:57:47 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:57:47 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:57:47 --> Utf8 Class Initialized
INFO - 2022-03-29 01:57:47 --> URI Class Initialized
INFO - 2022-03-29 01:57:47 --> Router Class Initialized
INFO - 2022-03-29 01:57:47 --> Output Class Initialized
INFO - 2022-03-29 01:57:47 --> Security Class Initialized
DEBUG - 2022-03-29 01:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:57:47 --> Input Class Initialized
INFO - 2022-03-29 01:57:47 --> Language Class Initialized
INFO - 2022-03-29 01:57:47 --> Loader Class Initialized
INFO - 2022-03-29 01:57:47 --> Helper loaded: url_helper
INFO - 2022-03-29 01:57:47 --> Helper loaded: form_helper
INFO - 2022-03-29 01:57:47 --> Helper loaded: common_helper
INFO - 2022-03-29 01:57:47 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:57:47 --> Controller Class Initialized
INFO - 2022-03-29 01:57:47 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:57:47 --> Encrypt Class Initialized
INFO - 2022-03-29 01:57:47 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:57:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:57:47 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:57:47 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:57:47 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:57:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:57:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 01:57:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:57:47 --> Final output sent to browser
DEBUG - 2022-03-29 01:57:47 --> Total execution time: 0.0456
ERROR - 2022-03-29 01:58:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:58:29 --> Config Class Initialized
INFO - 2022-03-29 01:58:29 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:58:29 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:58:29 --> Utf8 Class Initialized
INFO - 2022-03-29 01:58:29 --> URI Class Initialized
INFO - 2022-03-29 01:58:29 --> Router Class Initialized
INFO - 2022-03-29 01:58:29 --> Output Class Initialized
INFO - 2022-03-29 01:58:29 --> Security Class Initialized
DEBUG - 2022-03-29 01:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:58:29 --> Input Class Initialized
INFO - 2022-03-29 01:58:29 --> Language Class Initialized
INFO - 2022-03-29 01:58:29 --> Loader Class Initialized
INFO - 2022-03-29 01:58:29 --> Helper loaded: url_helper
INFO - 2022-03-29 01:58:29 --> Helper loaded: form_helper
INFO - 2022-03-29 01:58:29 --> Helper loaded: common_helper
INFO - 2022-03-29 01:58:29 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:58:29 --> Controller Class Initialized
INFO - 2022-03-29 01:58:29 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:58:29 --> Encrypt Class Initialized
INFO - 2022-03-29 01:58:29 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:58:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:58:29 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:58:29 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:58:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:58:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:58:30 --> Config Class Initialized
INFO - 2022-03-29 01:58:30 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:58:30 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:58:30 --> Utf8 Class Initialized
INFO - 2022-03-29 01:58:30 --> URI Class Initialized
INFO - 2022-03-29 01:58:30 --> Router Class Initialized
INFO - 2022-03-29 01:58:30 --> Output Class Initialized
INFO - 2022-03-29 01:58:30 --> Security Class Initialized
DEBUG - 2022-03-29 01:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:58:30 --> Input Class Initialized
INFO - 2022-03-29 01:58:30 --> Language Class Initialized
INFO - 2022-03-29 01:58:30 --> Loader Class Initialized
INFO - 2022-03-29 01:58:30 --> Helper loaded: url_helper
INFO - 2022-03-29 01:58:30 --> Helper loaded: form_helper
INFO - 2022-03-29 01:58:30 --> Helper loaded: common_helper
INFO - 2022-03-29 01:58:30 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:58:30 --> Controller Class Initialized
INFO - 2022-03-29 01:58:30 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:58:30 --> Encrypt Class Initialized
INFO - 2022-03-29 01:58:30 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:58:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:58:30 --> Model "Referredby_model" initialized
INFO - 2022-03-29 01:58:30 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:58:30 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:58:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:58:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 01:58:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:58:30 --> Final output sent to browser
DEBUG - 2022-03-29 01:58:30 --> Total execution time: 0.0246
ERROR - 2022-03-29 01:58:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:58:30 --> Config Class Initialized
INFO - 2022-03-29 01:58:30 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:58:30 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:58:30 --> Utf8 Class Initialized
INFO - 2022-03-29 01:58:30 --> URI Class Initialized
INFO - 2022-03-29 01:58:30 --> Router Class Initialized
INFO - 2022-03-29 01:58:30 --> Output Class Initialized
INFO - 2022-03-29 01:58:30 --> Security Class Initialized
DEBUG - 2022-03-29 01:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:58:30 --> Input Class Initialized
INFO - 2022-03-29 01:58:30 --> Language Class Initialized
INFO - 2022-03-29 01:58:30 --> Loader Class Initialized
INFO - 2022-03-29 01:58:30 --> Helper loaded: url_helper
INFO - 2022-03-29 01:58:30 --> Helper loaded: form_helper
INFO - 2022-03-29 01:58:30 --> Helper loaded: common_helper
INFO - 2022-03-29 01:58:30 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:58:30 --> Controller Class Initialized
INFO - 2022-03-29 01:58:30 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:58:30 --> Encrypt Class Initialized
INFO - 2022-03-29 01:58:30 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:58:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:58:30 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:58:30 --> Model "Users_model" initialized
INFO - 2022-03-29 01:58:30 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:58:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:58:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:58:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:58:30 --> Final output sent to browser
DEBUG - 2022-03-29 01:58:30 --> Total execution time: 0.0373
ERROR - 2022-03-29 01:58:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:58:44 --> Config Class Initialized
INFO - 2022-03-29 01:58:44 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:58:44 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:58:44 --> Utf8 Class Initialized
INFO - 2022-03-29 01:58:44 --> URI Class Initialized
INFO - 2022-03-29 01:58:44 --> Router Class Initialized
INFO - 2022-03-29 01:58:44 --> Output Class Initialized
INFO - 2022-03-29 01:58:44 --> Security Class Initialized
DEBUG - 2022-03-29 01:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:58:44 --> Input Class Initialized
INFO - 2022-03-29 01:58:44 --> Language Class Initialized
INFO - 2022-03-29 01:58:44 --> Loader Class Initialized
INFO - 2022-03-29 01:58:44 --> Helper loaded: url_helper
INFO - 2022-03-29 01:58:44 --> Helper loaded: form_helper
INFO - 2022-03-29 01:58:44 --> Helper loaded: common_helper
INFO - 2022-03-29 01:58:44 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:58:44 --> Controller Class Initialized
INFO - 2022-03-29 01:58:44 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:58:44 --> Encrypt Class Initialized
INFO - 2022-03-29 01:58:44 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:58:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:58:44 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:58:44 --> Model "Users_model" initialized
INFO - 2022-03-29 01:58:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:58:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:58:45 --> Config Class Initialized
INFO - 2022-03-29 01:58:45 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:58:45 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:58:45 --> Utf8 Class Initialized
INFO - 2022-03-29 01:58:45 --> URI Class Initialized
INFO - 2022-03-29 01:58:45 --> Router Class Initialized
INFO - 2022-03-29 01:58:45 --> Output Class Initialized
INFO - 2022-03-29 01:58:45 --> Security Class Initialized
DEBUG - 2022-03-29 01:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:58:45 --> Input Class Initialized
INFO - 2022-03-29 01:58:45 --> Language Class Initialized
INFO - 2022-03-29 01:58:45 --> Loader Class Initialized
INFO - 2022-03-29 01:58:45 --> Helper loaded: url_helper
INFO - 2022-03-29 01:58:45 --> Helper loaded: form_helper
INFO - 2022-03-29 01:58:45 --> Helper loaded: common_helper
INFO - 2022-03-29 01:58:45 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:58:45 --> Controller Class Initialized
INFO - 2022-03-29 01:58:45 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:58:45 --> Encrypt Class Initialized
INFO - 2022-03-29 01:58:45 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:58:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:58:45 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:58:45 --> Model "Users_model" initialized
INFO - 2022-03-29 01:58:45 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:58:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:58:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:58:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:58:45 --> Final output sent to browser
DEBUG - 2022-03-29 01:58:45 --> Total execution time: 0.0510
ERROR - 2022-03-29 01:59:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:59:41 --> Config Class Initialized
INFO - 2022-03-29 01:59:41 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:59:41 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:59:41 --> Utf8 Class Initialized
INFO - 2022-03-29 01:59:41 --> URI Class Initialized
INFO - 2022-03-29 01:59:41 --> Router Class Initialized
INFO - 2022-03-29 01:59:41 --> Output Class Initialized
INFO - 2022-03-29 01:59:41 --> Security Class Initialized
DEBUG - 2022-03-29 01:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:59:41 --> Input Class Initialized
INFO - 2022-03-29 01:59:41 --> Language Class Initialized
INFO - 2022-03-29 01:59:41 --> Loader Class Initialized
INFO - 2022-03-29 01:59:41 --> Helper loaded: url_helper
INFO - 2022-03-29 01:59:41 --> Helper loaded: form_helper
INFO - 2022-03-29 01:59:41 --> Helper loaded: common_helper
INFO - 2022-03-29 01:59:41 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:59:41 --> Controller Class Initialized
INFO - 2022-03-29 01:59:41 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:59:41 --> Encrypt Class Initialized
INFO - 2022-03-29 01:59:41 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:59:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:59:41 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:59:41 --> Model "Users_model" initialized
INFO - 2022-03-29 01:59:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 01:59:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 01:59:41 --> Config Class Initialized
INFO - 2022-03-29 01:59:41 --> Hooks Class Initialized
DEBUG - 2022-03-29 01:59:41 --> UTF-8 Support Enabled
INFO - 2022-03-29 01:59:41 --> Utf8 Class Initialized
INFO - 2022-03-29 01:59:41 --> URI Class Initialized
INFO - 2022-03-29 01:59:41 --> Router Class Initialized
INFO - 2022-03-29 01:59:41 --> Output Class Initialized
INFO - 2022-03-29 01:59:41 --> Security Class Initialized
DEBUG - 2022-03-29 01:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 01:59:41 --> Input Class Initialized
INFO - 2022-03-29 01:59:41 --> Language Class Initialized
INFO - 2022-03-29 01:59:41 --> Loader Class Initialized
INFO - 2022-03-29 01:59:41 --> Helper loaded: url_helper
INFO - 2022-03-29 01:59:41 --> Helper loaded: form_helper
INFO - 2022-03-29 01:59:41 --> Helper loaded: common_helper
INFO - 2022-03-29 01:59:41 --> Database Driver Class Initialized
DEBUG - 2022-03-29 01:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 01:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 01:59:41 --> Controller Class Initialized
INFO - 2022-03-29 01:59:41 --> Form Validation Class Initialized
DEBUG - 2022-03-29 01:59:41 --> Encrypt Class Initialized
INFO - 2022-03-29 01:59:41 --> Model "Patient_model" initialized
INFO - 2022-03-29 01:59:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 01:59:41 --> Model "Prefix_master" initialized
INFO - 2022-03-29 01:59:41 --> Model "Users_model" initialized
INFO - 2022-03-29 01:59:41 --> Model "Hospital_model" initialized
INFO - 2022-03-29 01:59:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 01:59:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 01:59:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 01:59:41 --> Final output sent to browser
DEBUG - 2022-03-29 01:59:41 --> Total execution time: 0.0392
ERROR - 2022-03-29 02:00:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 02:00:04 --> Config Class Initialized
INFO - 2022-03-29 02:00:04 --> Hooks Class Initialized
DEBUG - 2022-03-29 02:00:04 --> UTF-8 Support Enabled
INFO - 2022-03-29 02:00:04 --> Utf8 Class Initialized
INFO - 2022-03-29 02:00:04 --> URI Class Initialized
INFO - 2022-03-29 02:00:04 --> Router Class Initialized
INFO - 2022-03-29 02:00:04 --> Output Class Initialized
INFO - 2022-03-29 02:00:04 --> Security Class Initialized
DEBUG - 2022-03-29 02:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 02:00:04 --> Input Class Initialized
INFO - 2022-03-29 02:00:04 --> Language Class Initialized
INFO - 2022-03-29 02:00:04 --> Loader Class Initialized
INFO - 2022-03-29 02:00:04 --> Helper loaded: url_helper
INFO - 2022-03-29 02:00:04 --> Helper loaded: form_helper
INFO - 2022-03-29 02:00:04 --> Helper loaded: common_helper
INFO - 2022-03-29 02:00:04 --> Database Driver Class Initialized
DEBUG - 2022-03-29 02:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 02:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 02:00:04 --> Controller Class Initialized
INFO - 2022-03-29 02:00:04 --> Form Validation Class Initialized
DEBUG - 2022-03-29 02:00:04 --> Encrypt Class Initialized
INFO - 2022-03-29 02:00:04 --> Model "Patient_model" initialized
INFO - 2022-03-29 02:00:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 02:00:04 --> Model "Prefix_master" initialized
INFO - 2022-03-29 02:00:04 --> Model "Users_model" initialized
INFO - 2022-03-29 02:00:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 02:00:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 02:00:04 --> Config Class Initialized
INFO - 2022-03-29 02:00:04 --> Hooks Class Initialized
DEBUG - 2022-03-29 02:00:04 --> UTF-8 Support Enabled
INFO - 2022-03-29 02:00:04 --> Utf8 Class Initialized
INFO - 2022-03-29 02:00:04 --> URI Class Initialized
INFO - 2022-03-29 02:00:04 --> Router Class Initialized
INFO - 2022-03-29 02:00:04 --> Output Class Initialized
INFO - 2022-03-29 02:00:04 --> Security Class Initialized
DEBUG - 2022-03-29 02:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 02:00:04 --> Input Class Initialized
INFO - 2022-03-29 02:00:04 --> Language Class Initialized
INFO - 2022-03-29 02:00:04 --> Loader Class Initialized
INFO - 2022-03-29 02:00:04 --> Helper loaded: url_helper
INFO - 2022-03-29 02:00:04 --> Helper loaded: form_helper
INFO - 2022-03-29 02:00:04 --> Helper loaded: common_helper
INFO - 2022-03-29 02:00:04 --> Database Driver Class Initialized
DEBUG - 2022-03-29 02:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 02:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 02:00:04 --> Controller Class Initialized
INFO - 2022-03-29 02:00:04 --> Form Validation Class Initialized
DEBUG - 2022-03-29 02:00:04 --> Encrypt Class Initialized
INFO - 2022-03-29 02:00:04 --> Model "Patient_model" initialized
INFO - 2022-03-29 02:00:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 02:00:04 --> Model "Prefix_master" initialized
INFO - 2022-03-29 02:00:04 --> Model "Users_model" initialized
INFO - 2022-03-29 02:00:04 --> Model "Hospital_model" initialized
INFO - 2022-03-29 02:00:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 02:00:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 02:00:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 02:00:04 --> Final output sent to browser
DEBUG - 2022-03-29 02:00:04 --> Total execution time: 0.0467
ERROR - 2022-03-29 02:00:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 02:00:35 --> Config Class Initialized
INFO - 2022-03-29 02:00:35 --> Hooks Class Initialized
DEBUG - 2022-03-29 02:00:35 --> UTF-8 Support Enabled
INFO - 2022-03-29 02:00:35 --> Utf8 Class Initialized
INFO - 2022-03-29 02:00:35 --> URI Class Initialized
INFO - 2022-03-29 02:00:35 --> Router Class Initialized
INFO - 2022-03-29 02:00:35 --> Output Class Initialized
INFO - 2022-03-29 02:00:35 --> Security Class Initialized
DEBUG - 2022-03-29 02:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 02:00:35 --> Input Class Initialized
INFO - 2022-03-29 02:00:35 --> Language Class Initialized
INFO - 2022-03-29 02:00:35 --> Loader Class Initialized
INFO - 2022-03-29 02:00:35 --> Helper loaded: url_helper
INFO - 2022-03-29 02:00:35 --> Helper loaded: form_helper
INFO - 2022-03-29 02:00:35 --> Helper loaded: common_helper
INFO - 2022-03-29 02:00:35 --> Database Driver Class Initialized
DEBUG - 2022-03-29 02:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 02:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 02:00:35 --> Controller Class Initialized
INFO - 2022-03-29 02:00:35 --> Form Validation Class Initialized
DEBUG - 2022-03-29 02:00:35 --> Encrypt Class Initialized
INFO - 2022-03-29 02:00:35 --> Model "Patient_model" initialized
INFO - 2022-03-29 02:00:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 02:00:35 --> Model "Prefix_master" initialized
INFO - 2022-03-29 02:00:35 --> Model "Users_model" initialized
INFO - 2022-03-29 02:00:35 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 02:00:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 02:00:35 --> Config Class Initialized
INFO - 2022-03-29 02:00:35 --> Hooks Class Initialized
DEBUG - 2022-03-29 02:00:35 --> UTF-8 Support Enabled
INFO - 2022-03-29 02:00:35 --> Utf8 Class Initialized
INFO - 2022-03-29 02:00:35 --> URI Class Initialized
INFO - 2022-03-29 02:00:35 --> Router Class Initialized
INFO - 2022-03-29 02:00:35 --> Output Class Initialized
INFO - 2022-03-29 02:00:35 --> Security Class Initialized
DEBUG - 2022-03-29 02:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 02:00:35 --> Input Class Initialized
INFO - 2022-03-29 02:00:35 --> Language Class Initialized
INFO - 2022-03-29 02:00:35 --> Loader Class Initialized
INFO - 2022-03-29 02:00:35 --> Helper loaded: url_helper
INFO - 2022-03-29 02:00:35 --> Helper loaded: form_helper
INFO - 2022-03-29 02:00:35 --> Helper loaded: common_helper
INFO - 2022-03-29 02:00:35 --> Database Driver Class Initialized
DEBUG - 2022-03-29 02:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 02:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 02:00:35 --> Controller Class Initialized
INFO - 2022-03-29 02:00:35 --> Form Validation Class Initialized
DEBUG - 2022-03-29 02:00:35 --> Encrypt Class Initialized
INFO - 2022-03-29 02:00:35 --> Model "Patient_model" initialized
INFO - 2022-03-29 02:00:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 02:00:35 --> Model "Prefix_master" initialized
INFO - 2022-03-29 02:00:35 --> Model "Users_model" initialized
INFO - 2022-03-29 02:00:35 --> Model "Hospital_model" initialized
INFO - 2022-03-29 02:00:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 02:00:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 02:00:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 02:00:35 --> Final output sent to browser
DEBUG - 2022-03-29 02:00:35 --> Total execution time: 0.0512
ERROR - 2022-03-29 02:04:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 02:04:50 --> Config Class Initialized
INFO - 2022-03-29 02:04:50 --> Hooks Class Initialized
DEBUG - 2022-03-29 02:04:50 --> UTF-8 Support Enabled
INFO - 2022-03-29 02:04:50 --> Utf8 Class Initialized
INFO - 2022-03-29 02:04:50 --> URI Class Initialized
INFO - 2022-03-29 02:04:50 --> Router Class Initialized
INFO - 2022-03-29 02:04:50 --> Output Class Initialized
INFO - 2022-03-29 02:04:50 --> Security Class Initialized
DEBUG - 2022-03-29 02:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 02:04:50 --> Input Class Initialized
INFO - 2022-03-29 02:04:50 --> Language Class Initialized
INFO - 2022-03-29 02:04:50 --> Loader Class Initialized
INFO - 2022-03-29 02:04:50 --> Helper loaded: url_helper
INFO - 2022-03-29 02:04:50 --> Helper loaded: form_helper
INFO - 2022-03-29 02:04:50 --> Helper loaded: common_helper
INFO - 2022-03-29 02:04:50 --> Database Driver Class Initialized
DEBUG - 2022-03-29 02:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 02:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 02:04:51 --> Controller Class Initialized
INFO - 2022-03-29 02:04:51 --> Form Validation Class Initialized
DEBUG - 2022-03-29 02:04:51 --> Encrypt Class Initialized
INFO - 2022-03-29 02:04:51 --> Model "Patient_model" initialized
INFO - 2022-03-29 02:04:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 02:04:51 --> Model "Prefix_master" initialized
INFO - 2022-03-29 02:04:51 --> Model "Users_model" initialized
INFO - 2022-03-29 02:04:51 --> Model "Hospital_model" initialized
INFO - 2022-03-29 02:04:51 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 02:04:52 --> Final output sent to browser
DEBUG - 2022-03-29 02:04:52 --> Total execution time: 1.1503
ERROR - 2022-03-29 02:08:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 02:08:20 --> Config Class Initialized
INFO - 2022-03-29 02:08:20 --> Hooks Class Initialized
DEBUG - 2022-03-29 02:08:20 --> UTF-8 Support Enabled
INFO - 2022-03-29 02:08:20 --> Utf8 Class Initialized
INFO - 2022-03-29 02:08:20 --> URI Class Initialized
INFO - 2022-03-29 02:08:20 --> Router Class Initialized
INFO - 2022-03-29 02:08:20 --> Output Class Initialized
INFO - 2022-03-29 02:08:20 --> Security Class Initialized
DEBUG - 2022-03-29 02:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 02:08:20 --> Input Class Initialized
INFO - 2022-03-29 02:08:20 --> Language Class Initialized
INFO - 2022-03-29 02:08:20 --> Loader Class Initialized
INFO - 2022-03-29 02:08:20 --> Helper loaded: url_helper
INFO - 2022-03-29 02:08:20 --> Helper loaded: form_helper
INFO - 2022-03-29 02:08:20 --> Helper loaded: common_helper
INFO - 2022-03-29 02:08:20 --> Database Driver Class Initialized
DEBUG - 2022-03-29 02:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 02:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 02:08:20 --> Controller Class Initialized
INFO - 2022-03-29 02:08:20 --> Form Validation Class Initialized
DEBUG - 2022-03-29 02:08:20 --> Encrypt Class Initialized
INFO - 2022-03-29 02:08:20 --> Model "Patient_model" initialized
INFO - 2022-03-29 02:08:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 02:08:20 --> Model "Prefix_master" initialized
INFO - 2022-03-29 02:08:20 --> Model "Users_model" initialized
INFO - 2022-03-29 02:08:20 --> Model "Hospital_model" initialized
INFO - 2022-03-29 02:08:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 02:08:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 02:08:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 02:08:20 --> Final output sent to browser
DEBUG - 2022-03-29 02:08:20 --> Total execution time: 0.1161
ERROR - 2022-03-29 02:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 02:09:26 --> Config Class Initialized
INFO - 2022-03-29 02:09:26 --> Hooks Class Initialized
DEBUG - 2022-03-29 02:09:26 --> UTF-8 Support Enabled
INFO - 2022-03-29 02:09:26 --> Utf8 Class Initialized
INFO - 2022-03-29 02:09:26 --> URI Class Initialized
INFO - 2022-03-29 02:09:26 --> Router Class Initialized
INFO - 2022-03-29 02:09:26 --> Output Class Initialized
INFO - 2022-03-29 02:09:26 --> Security Class Initialized
DEBUG - 2022-03-29 02:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 02:09:26 --> Input Class Initialized
INFO - 2022-03-29 02:09:26 --> Language Class Initialized
INFO - 2022-03-29 02:09:26 --> Loader Class Initialized
INFO - 2022-03-29 02:09:26 --> Helper loaded: url_helper
INFO - 2022-03-29 02:09:26 --> Helper loaded: form_helper
INFO - 2022-03-29 02:09:26 --> Helper loaded: common_helper
INFO - 2022-03-29 02:09:26 --> Database Driver Class Initialized
DEBUG - 2022-03-29 02:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 02:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 02:09:26 --> Controller Class Initialized
INFO - 2022-03-29 02:09:26 --> Form Validation Class Initialized
DEBUG - 2022-03-29 02:09:26 --> Encrypt Class Initialized
INFO - 2022-03-29 02:09:26 --> Model "Patient_model" initialized
INFO - 2022-03-29 02:09:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 02:09:26 --> Model "Prefix_master" initialized
INFO - 2022-03-29 02:09:26 --> Model "Users_model" initialized
INFO - 2022-03-29 02:09:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 02:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 02:09:27 --> Config Class Initialized
INFO - 2022-03-29 02:09:27 --> Hooks Class Initialized
DEBUG - 2022-03-29 02:09:27 --> UTF-8 Support Enabled
INFO - 2022-03-29 02:09:27 --> Utf8 Class Initialized
INFO - 2022-03-29 02:09:27 --> URI Class Initialized
INFO - 2022-03-29 02:09:27 --> Router Class Initialized
INFO - 2022-03-29 02:09:27 --> Output Class Initialized
INFO - 2022-03-29 02:09:27 --> Security Class Initialized
DEBUG - 2022-03-29 02:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 02:09:27 --> Input Class Initialized
INFO - 2022-03-29 02:09:27 --> Language Class Initialized
INFO - 2022-03-29 02:09:27 --> Loader Class Initialized
INFO - 2022-03-29 02:09:27 --> Helper loaded: url_helper
INFO - 2022-03-29 02:09:27 --> Helper loaded: form_helper
INFO - 2022-03-29 02:09:27 --> Helper loaded: common_helper
INFO - 2022-03-29 02:09:27 --> Database Driver Class Initialized
DEBUG - 2022-03-29 02:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 02:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 02:09:27 --> Controller Class Initialized
INFO - 2022-03-29 02:09:27 --> Form Validation Class Initialized
DEBUG - 2022-03-29 02:09:27 --> Encrypt Class Initialized
INFO - 2022-03-29 02:09:27 --> Model "Patient_model" initialized
INFO - 2022-03-29 02:09:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 02:09:27 --> Model "Prefix_master" initialized
INFO - 2022-03-29 02:09:27 --> Model "Users_model" initialized
INFO - 2022-03-29 02:09:27 --> Model "Hospital_model" initialized
INFO - 2022-03-29 02:09:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 02:09:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 02:09:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 02:09:27 --> Final output sent to browser
DEBUG - 2022-03-29 02:09:27 --> Total execution time: 0.0384
ERROR - 2022-03-29 03:06:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:06:55 --> Config Class Initialized
INFO - 2022-03-29 03:06:55 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:06:55 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:06:55 --> Utf8 Class Initialized
INFO - 2022-03-29 03:06:55 --> URI Class Initialized
INFO - 2022-03-29 03:06:55 --> Router Class Initialized
INFO - 2022-03-29 03:06:55 --> Output Class Initialized
INFO - 2022-03-29 03:06:55 --> Security Class Initialized
DEBUG - 2022-03-29 03:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:06:55 --> Input Class Initialized
INFO - 2022-03-29 03:06:55 --> Language Class Initialized
INFO - 2022-03-29 03:06:55 --> Loader Class Initialized
INFO - 2022-03-29 03:06:55 --> Helper loaded: url_helper
INFO - 2022-03-29 03:06:55 --> Helper loaded: form_helper
INFO - 2022-03-29 03:06:55 --> Helper loaded: common_helper
INFO - 2022-03-29 03:06:55 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:06:55 --> Controller Class Initialized
ERROR - 2022-03-29 03:06:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:06:55 --> Config Class Initialized
INFO - 2022-03-29 03:06:55 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:06:55 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:06:55 --> Utf8 Class Initialized
INFO - 2022-03-29 03:06:55 --> URI Class Initialized
INFO - 2022-03-29 03:06:55 --> Router Class Initialized
INFO - 2022-03-29 03:06:55 --> Output Class Initialized
INFO - 2022-03-29 03:06:55 --> Security Class Initialized
DEBUG - 2022-03-29 03:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:06:55 --> Input Class Initialized
INFO - 2022-03-29 03:06:55 --> Language Class Initialized
INFO - 2022-03-29 03:06:55 --> Loader Class Initialized
INFO - 2022-03-29 03:06:55 --> Helper loaded: url_helper
INFO - 2022-03-29 03:06:55 --> Helper loaded: form_helper
INFO - 2022-03-29 03:06:55 --> Helper loaded: common_helper
INFO - 2022-03-29 03:06:55 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:06:55 --> Controller Class Initialized
INFO - 2022-03-29 03:06:55 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:06:55 --> Encrypt Class Initialized
DEBUG - 2022-03-29 03:06:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 03:06:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 03:06:55 --> Email Class Initialized
INFO - 2022-03-29 03:06:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 03:06:55 --> Calendar Class Initialized
INFO - 2022-03-29 03:06:55 --> Model "Login_model" initialized
INFO - 2022-03-29 03:06:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 03:06:55 --> Final output sent to browser
DEBUG - 2022-03-29 03:06:55 --> Total execution time: 0.0337
ERROR - 2022-03-29 03:06:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:06:59 --> Config Class Initialized
INFO - 2022-03-29 03:06:59 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:06:59 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:06:59 --> Utf8 Class Initialized
INFO - 2022-03-29 03:06:59 --> URI Class Initialized
INFO - 2022-03-29 03:06:59 --> Router Class Initialized
INFO - 2022-03-29 03:06:59 --> Output Class Initialized
INFO - 2022-03-29 03:06:59 --> Security Class Initialized
DEBUG - 2022-03-29 03:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:06:59 --> Input Class Initialized
INFO - 2022-03-29 03:06:59 --> Language Class Initialized
INFO - 2022-03-29 03:06:59 --> Loader Class Initialized
INFO - 2022-03-29 03:06:59 --> Helper loaded: url_helper
INFO - 2022-03-29 03:06:59 --> Helper loaded: form_helper
INFO - 2022-03-29 03:06:59 --> Helper loaded: common_helper
INFO - 2022-03-29 03:06:59 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:06:59 --> Controller Class Initialized
INFO - 2022-03-29 03:06:59 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:06:59 --> Encrypt Class Initialized
DEBUG - 2022-03-29 03:06:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 03:06:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 03:06:59 --> Email Class Initialized
INFO - 2022-03-29 03:06:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 03:06:59 --> Calendar Class Initialized
INFO - 2022-03-29 03:06:59 --> Model "Login_model" initialized
INFO - 2022-03-29 03:06:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-29 03:06:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:06:59 --> Config Class Initialized
INFO - 2022-03-29 03:06:59 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:06:59 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:06:59 --> Utf8 Class Initialized
INFO - 2022-03-29 03:06:59 --> URI Class Initialized
INFO - 2022-03-29 03:06:59 --> Router Class Initialized
INFO - 2022-03-29 03:06:59 --> Output Class Initialized
INFO - 2022-03-29 03:06:59 --> Security Class Initialized
DEBUG - 2022-03-29 03:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:06:59 --> Input Class Initialized
INFO - 2022-03-29 03:06:59 --> Language Class Initialized
INFO - 2022-03-29 03:06:59 --> Loader Class Initialized
INFO - 2022-03-29 03:06:59 --> Helper loaded: url_helper
INFO - 2022-03-29 03:06:59 --> Helper loaded: form_helper
INFO - 2022-03-29 03:06:59 --> Helper loaded: common_helper
INFO - 2022-03-29 03:06:59 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:06:59 --> Controller Class Initialized
INFO - 2022-03-29 03:06:59 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:06:59 --> Encrypt Class Initialized
INFO - 2022-03-29 03:06:59 --> Model "Login_model" initialized
INFO - 2022-03-29 03:06:59 --> Model "Dashboard_model" initialized
INFO - 2022-03-29 03:06:59 --> Model "Case_model" initialized
INFO - 2022-03-29 03:07:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 03:07:20 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-29 03:07:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 03:07:20 --> Final output sent to browser
DEBUG - 2022-03-29 03:07:20 --> Total execution time: 20.7735
ERROR - 2022-03-29 03:08:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:08:17 --> Config Class Initialized
INFO - 2022-03-29 03:08:17 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:08:17 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:08:17 --> Utf8 Class Initialized
INFO - 2022-03-29 03:08:17 --> URI Class Initialized
DEBUG - 2022-03-29 03:08:17 --> No URI present. Default controller set.
INFO - 2022-03-29 03:08:17 --> Router Class Initialized
INFO - 2022-03-29 03:08:17 --> Output Class Initialized
INFO - 2022-03-29 03:08:17 --> Security Class Initialized
DEBUG - 2022-03-29 03:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:08:17 --> Input Class Initialized
INFO - 2022-03-29 03:08:17 --> Language Class Initialized
INFO - 2022-03-29 03:08:17 --> Loader Class Initialized
INFO - 2022-03-29 03:08:17 --> Helper loaded: url_helper
INFO - 2022-03-29 03:08:17 --> Helper loaded: form_helper
INFO - 2022-03-29 03:08:17 --> Helper loaded: common_helper
INFO - 2022-03-29 03:08:17 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:08:17 --> Controller Class Initialized
INFO - 2022-03-29 03:08:17 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:08:17 --> Encrypt Class Initialized
DEBUG - 2022-03-29 03:08:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 03:08:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 03:08:17 --> Email Class Initialized
INFO - 2022-03-29 03:08:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 03:08:17 --> Calendar Class Initialized
INFO - 2022-03-29 03:08:17 --> Model "Login_model" initialized
INFO - 2022-03-29 03:08:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 03:08:17 --> Final output sent to browser
DEBUG - 2022-03-29 03:08:17 --> Total execution time: 0.0065
ERROR - 2022-03-29 03:17:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:17:13 --> Config Class Initialized
INFO - 2022-03-29 03:17:13 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:17:13 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:17:13 --> Utf8 Class Initialized
INFO - 2022-03-29 03:17:13 --> URI Class Initialized
INFO - 2022-03-29 03:17:13 --> Router Class Initialized
INFO - 2022-03-29 03:17:13 --> Output Class Initialized
INFO - 2022-03-29 03:17:13 --> Security Class Initialized
DEBUG - 2022-03-29 03:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:17:13 --> Input Class Initialized
INFO - 2022-03-29 03:17:13 --> Language Class Initialized
INFO - 2022-03-29 03:17:13 --> Loader Class Initialized
INFO - 2022-03-29 03:17:13 --> Helper loaded: url_helper
INFO - 2022-03-29 03:17:13 --> Helper loaded: form_helper
INFO - 2022-03-29 03:17:13 --> Helper loaded: common_helper
INFO - 2022-03-29 03:17:13 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:17:13 --> Controller Class Initialized
INFO - 2022-03-29 03:17:13 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:17:13 --> Encrypt Class Initialized
DEBUG - 2022-03-29 03:17:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 03:17:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 03:17:13 --> Email Class Initialized
INFO - 2022-03-29 03:17:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 03:17:13 --> Calendar Class Initialized
INFO - 2022-03-29 03:17:13 --> Model "Login_model" initialized
ERROR - 2022-03-29 03:17:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:17:13 --> Config Class Initialized
INFO - 2022-03-29 03:17:13 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:17:13 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:17:13 --> Utf8 Class Initialized
INFO - 2022-03-29 03:17:13 --> URI Class Initialized
INFO - 2022-03-29 03:17:13 --> Router Class Initialized
INFO - 2022-03-29 03:17:13 --> Output Class Initialized
INFO - 2022-03-29 03:17:13 --> Security Class Initialized
DEBUG - 2022-03-29 03:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:17:13 --> Input Class Initialized
INFO - 2022-03-29 03:17:13 --> Language Class Initialized
INFO - 2022-03-29 03:17:14 --> Loader Class Initialized
INFO - 2022-03-29 03:17:14 --> Helper loaded: url_helper
INFO - 2022-03-29 03:17:14 --> Helper loaded: form_helper
INFO - 2022-03-29 03:17:14 --> Helper loaded: common_helper
INFO - 2022-03-29 03:17:14 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:17:14 --> Controller Class Initialized
INFO - 2022-03-29 03:17:14 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:17:14 --> Encrypt Class Initialized
INFO - 2022-03-29 03:17:14 --> Model "Diseases_model" initialized
INFO - 2022-03-29 03:17:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 03:17:14 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-29 03:17:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 03:17:14 --> Final output sent to browser
DEBUG - 2022-03-29 03:17:14 --> Total execution time: 0.1201
ERROR - 2022-03-29 03:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:17:51 --> Config Class Initialized
INFO - 2022-03-29 03:17:51 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:17:51 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:17:51 --> Utf8 Class Initialized
INFO - 2022-03-29 03:17:51 --> URI Class Initialized
INFO - 2022-03-29 03:17:51 --> Router Class Initialized
INFO - 2022-03-29 03:17:51 --> Output Class Initialized
INFO - 2022-03-29 03:17:51 --> Security Class Initialized
DEBUG - 2022-03-29 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:17:51 --> Input Class Initialized
INFO - 2022-03-29 03:17:51 --> Language Class Initialized
INFO - 2022-03-29 03:17:51 --> Loader Class Initialized
INFO - 2022-03-29 03:17:51 --> Helper loaded: url_helper
INFO - 2022-03-29 03:17:51 --> Helper loaded: form_helper
INFO - 2022-03-29 03:17:51 --> Helper loaded: common_helper
INFO - 2022-03-29 03:17:51 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:17:51 --> Controller Class Initialized
INFO - 2022-03-29 03:17:51 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:17:51 --> Encrypt Class Initialized
INFO - 2022-03-29 03:17:51 --> Model "Patient_model" initialized
INFO - 2022-03-29 03:17:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 03:17:51 --> Model "Referredby_model" initialized
INFO - 2022-03-29 03:17:51 --> Model "Prefix_master" initialized
INFO - 2022-03-29 03:17:51 --> Model "Hospital_model" initialized
INFO - 2022-03-29 03:17:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 03:17:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 03:17:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 03:17:51 --> Final output sent to browser
DEBUG - 2022-03-29 03:17:51 --> Total execution time: 0.1659
ERROR - 2022-03-29 03:17:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:17:52 --> Config Class Initialized
INFO - 2022-03-29 03:17:52 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:17:52 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:17:52 --> Utf8 Class Initialized
INFO - 2022-03-29 03:17:52 --> URI Class Initialized
INFO - 2022-03-29 03:17:52 --> Router Class Initialized
INFO - 2022-03-29 03:17:52 --> Output Class Initialized
INFO - 2022-03-29 03:17:52 --> Security Class Initialized
DEBUG - 2022-03-29 03:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:17:52 --> Input Class Initialized
INFO - 2022-03-29 03:17:52 --> Language Class Initialized
INFO - 2022-03-29 03:17:52 --> Loader Class Initialized
INFO - 2022-03-29 03:17:52 --> Helper loaded: url_helper
INFO - 2022-03-29 03:17:52 --> Helper loaded: form_helper
INFO - 2022-03-29 03:17:52 --> Helper loaded: common_helper
INFO - 2022-03-29 03:17:52 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:17:52 --> Controller Class Initialized
INFO - 2022-03-29 03:17:52 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:17:52 --> Encrypt Class Initialized
INFO - 2022-03-29 03:17:52 --> Model "Patient_model" initialized
INFO - 2022-03-29 03:17:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 03:17:52 --> Model "Referredby_model" initialized
INFO - 2022-03-29 03:17:52 --> Model "Prefix_master" initialized
INFO - 2022-03-29 03:17:52 --> Model "Hospital_model" initialized
INFO - 2022-03-29 03:17:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 03:17:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 03:17:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 03:17:53 --> Final output sent to browser
DEBUG - 2022-03-29 03:17:53 --> Total execution time: 0.0699
ERROR - 2022-03-29 03:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:18:07 --> Config Class Initialized
INFO - 2022-03-29 03:18:07 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:18:07 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:18:07 --> Utf8 Class Initialized
INFO - 2022-03-29 03:18:07 --> URI Class Initialized
INFO - 2022-03-29 03:18:07 --> Router Class Initialized
INFO - 2022-03-29 03:18:07 --> Output Class Initialized
INFO - 2022-03-29 03:18:07 --> Security Class Initialized
DEBUG - 2022-03-29 03:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:18:07 --> Input Class Initialized
INFO - 2022-03-29 03:18:07 --> Language Class Initialized
INFO - 2022-03-29 03:18:07 --> Loader Class Initialized
INFO - 2022-03-29 03:18:07 --> Helper loaded: url_helper
INFO - 2022-03-29 03:18:07 --> Helper loaded: form_helper
INFO - 2022-03-29 03:18:07 --> Helper loaded: common_helper
INFO - 2022-03-29 03:18:07 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:18:07 --> Controller Class Initialized
INFO - 2022-03-29 03:18:07 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:18:07 --> Encrypt Class Initialized
INFO - 2022-03-29 03:18:07 --> Model "Patient_model" initialized
INFO - 2022-03-29 03:18:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 03:18:07 --> Model "Prefix_master" initialized
INFO - 2022-03-29 03:18:07 --> Model "Users_model" initialized
INFO - 2022-03-29 03:18:07 --> Model "Hospital_model" initialized
INFO - 2022-03-29 03:18:07 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 03:18:08 --> Final output sent to browser
DEBUG - 2022-03-29 03:18:08 --> Total execution time: 1.8740
ERROR - 2022-03-29 03:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:20:27 --> Config Class Initialized
INFO - 2022-03-29 03:20:27 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:20:27 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:20:27 --> Utf8 Class Initialized
INFO - 2022-03-29 03:20:27 --> URI Class Initialized
INFO - 2022-03-29 03:20:27 --> Router Class Initialized
INFO - 2022-03-29 03:20:27 --> Output Class Initialized
INFO - 2022-03-29 03:20:27 --> Security Class Initialized
DEBUG - 2022-03-29 03:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:20:27 --> Input Class Initialized
INFO - 2022-03-29 03:20:27 --> Language Class Initialized
INFO - 2022-03-29 03:20:27 --> Loader Class Initialized
INFO - 2022-03-29 03:20:27 --> Helper loaded: url_helper
INFO - 2022-03-29 03:20:27 --> Helper loaded: form_helper
INFO - 2022-03-29 03:20:27 --> Helper loaded: common_helper
INFO - 2022-03-29 03:20:27 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:20:27 --> Controller Class Initialized
INFO - 2022-03-29 03:20:27 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:20:27 --> Encrypt Class Initialized
INFO - 2022-03-29 03:20:27 --> Model "Patient_model" initialized
INFO - 2022-03-29 03:20:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 03:20:27 --> Model "Prefix_master" initialized
INFO - 2022-03-29 03:20:27 --> Model "Users_model" initialized
INFO - 2022-03-29 03:20:27 --> Model "Hospital_model" initialized
INFO - 2022-03-29 03:20:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 03:20:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 03:20:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 03:20:27 --> Final output sent to browser
DEBUG - 2022-03-29 03:20:27 --> Total execution time: 0.1705
ERROR - 2022-03-29 03:34:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:34:12 --> Config Class Initialized
INFO - 2022-03-29 03:34:12 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:34:12 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:34:12 --> Utf8 Class Initialized
INFO - 2022-03-29 03:34:12 --> URI Class Initialized
INFO - 2022-03-29 03:34:12 --> Router Class Initialized
INFO - 2022-03-29 03:34:12 --> Output Class Initialized
INFO - 2022-03-29 03:34:12 --> Security Class Initialized
DEBUG - 2022-03-29 03:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:34:12 --> Input Class Initialized
INFO - 2022-03-29 03:34:12 --> Language Class Initialized
INFO - 2022-03-29 03:34:12 --> Loader Class Initialized
INFO - 2022-03-29 03:34:12 --> Helper loaded: url_helper
INFO - 2022-03-29 03:34:12 --> Helper loaded: form_helper
INFO - 2022-03-29 03:34:12 --> Helper loaded: common_helper
INFO - 2022-03-29 03:34:12 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:34:12 --> Controller Class Initialized
INFO - 2022-03-29 03:34:12 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:34:12 --> Encrypt Class Initialized
INFO - 2022-03-29 03:34:12 --> Model "Patient_model" initialized
INFO - 2022-03-29 03:34:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 03:34:12 --> Model "Referredby_model" initialized
INFO - 2022-03-29 03:34:12 --> Model "Prefix_master" initialized
INFO - 2022-03-29 03:34:12 --> Model "Hospital_model" initialized
INFO - 2022-03-29 03:34:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 03:34:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 03:34:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 03:34:12 --> Final output sent to browser
DEBUG - 2022-03-29 03:34:12 --> Total execution time: 0.2424
ERROR - 2022-03-29 03:36:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:36:57 --> Config Class Initialized
INFO - 2022-03-29 03:36:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:36:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:36:57 --> Utf8 Class Initialized
INFO - 2022-03-29 03:36:57 --> URI Class Initialized
INFO - 2022-03-29 03:36:57 --> Router Class Initialized
INFO - 2022-03-29 03:36:57 --> Output Class Initialized
INFO - 2022-03-29 03:36:57 --> Security Class Initialized
DEBUG - 2022-03-29 03:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:36:57 --> Input Class Initialized
INFO - 2022-03-29 03:36:57 --> Language Class Initialized
ERROR - 2022-03-29 03:36:57 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-03-29 03:58:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:58:07 --> Config Class Initialized
INFO - 2022-03-29 03:58:07 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:58:07 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:58:07 --> Utf8 Class Initialized
INFO - 2022-03-29 03:58:07 --> URI Class Initialized
INFO - 2022-03-29 03:58:07 --> Router Class Initialized
INFO - 2022-03-29 03:58:07 --> Output Class Initialized
INFO - 2022-03-29 03:58:07 --> Security Class Initialized
DEBUG - 2022-03-29 03:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:58:07 --> Input Class Initialized
INFO - 2022-03-29 03:58:07 --> Language Class Initialized
INFO - 2022-03-29 03:58:07 --> Loader Class Initialized
INFO - 2022-03-29 03:58:07 --> Helper loaded: url_helper
INFO - 2022-03-29 03:58:07 --> Helper loaded: form_helper
INFO - 2022-03-29 03:58:07 --> Helper loaded: common_helper
INFO - 2022-03-29 03:58:07 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:58:07 --> Controller Class Initialized
INFO - 2022-03-29 03:58:07 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:58:07 --> Encrypt Class Initialized
INFO - 2022-03-29 03:58:07 --> Model "Patient_model" initialized
INFO - 2022-03-29 03:58:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 03:58:07 --> Model "Referredby_model" initialized
INFO - 2022-03-29 03:58:07 --> Model "Prefix_master" initialized
INFO - 2022-03-29 03:58:07 --> Model "Hospital_model" initialized
INFO - 2022-03-29 03:58:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 03:58:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 03:58:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 03:58:07 --> Final output sent to browser
DEBUG - 2022-03-29 03:58:07 --> Total execution time: 0.1092
ERROR - 2022-03-29 03:58:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 03:58:17 --> Config Class Initialized
INFO - 2022-03-29 03:58:17 --> Hooks Class Initialized
DEBUG - 2022-03-29 03:58:17 --> UTF-8 Support Enabled
INFO - 2022-03-29 03:58:17 --> Utf8 Class Initialized
INFO - 2022-03-29 03:58:17 --> URI Class Initialized
INFO - 2022-03-29 03:58:17 --> Router Class Initialized
INFO - 2022-03-29 03:58:17 --> Output Class Initialized
INFO - 2022-03-29 03:58:17 --> Security Class Initialized
DEBUG - 2022-03-29 03:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 03:58:17 --> Input Class Initialized
INFO - 2022-03-29 03:58:17 --> Language Class Initialized
INFO - 2022-03-29 03:58:17 --> Loader Class Initialized
INFO - 2022-03-29 03:58:17 --> Helper loaded: url_helper
INFO - 2022-03-29 03:58:17 --> Helper loaded: form_helper
INFO - 2022-03-29 03:58:17 --> Helper loaded: common_helper
INFO - 2022-03-29 03:58:17 --> Database Driver Class Initialized
DEBUG - 2022-03-29 03:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 03:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 03:58:17 --> Controller Class Initialized
INFO - 2022-03-29 03:58:17 --> Form Validation Class Initialized
DEBUG - 2022-03-29 03:58:17 --> Encrypt Class Initialized
INFO - 2022-03-29 03:58:17 --> Model "Patient_model" initialized
INFO - 2022-03-29 03:58:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 03:58:17 --> Model "Prefix_master" initialized
INFO - 2022-03-29 03:58:17 --> Model "Users_model" initialized
INFO - 2022-03-29 03:58:17 --> Model "Hospital_model" initialized
INFO - 2022-03-29 03:58:18 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 03:58:19 --> Final output sent to browser
DEBUG - 2022-03-29 03:58:19 --> Total execution time: 1.1937
ERROR - 2022-03-29 04:00:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:00:51 --> Config Class Initialized
INFO - 2022-03-29 04:00:51 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:00:51 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:00:51 --> Utf8 Class Initialized
INFO - 2022-03-29 04:00:51 --> URI Class Initialized
INFO - 2022-03-29 04:00:51 --> Router Class Initialized
INFO - 2022-03-29 04:00:51 --> Output Class Initialized
INFO - 2022-03-29 04:00:51 --> Security Class Initialized
DEBUG - 2022-03-29 04:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:00:51 --> Input Class Initialized
INFO - 2022-03-29 04:00:51 --> Language Class Initialized
INFO - 2022-03-29 04:00:51 --> Loader Class Initialized
INFO - 2022-03-29 04:00:51 --> Helper loaded: url_helper
INFO - 2022-03-29 04:00:51 --> Helper loaded: form_helper
INFO - 2022-03-29 04:00:51 --> Helper loaded: common_helper
INFO - 2022-03-29 04:00:51 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:00:51 --> Controller Class Initialized
ERROR - 2022-03-29 04:00:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:00:51 --> Config Class Initialized
INFO - 2022-03-29 04:00:51 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:00:51 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:00:51 --> Utf8 Class Initialized
INFO - 2022-03-29 04:00:51 --> URI Class Initialized
INFO - 2022-03-29 04:00:51 --> Router Class Initialized
INFO - 2022-03-29 04:00:51 --> Output Class Initialized
INFO - 2022-03-29 04:00:51 --> Security Class Initialized
DEBUG - 2022-03-29 04:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:00:51 --> Input Class Initialized
INFO - 2022-03-29 04:00:51 --> Language Class Initialized
INFO - 2022-03-29 04:00:51 --> Loader Class Initialized
INFO - 2022-03-29 04:00:51 --> Helper loaded: url_helper
INFO - 2022-03-29 04:00:51 --> Helper loaded: form_helper
INFO - 2022-03-29 04:00:51 --> Helper loaded: common_helper
INFO - 2022-03-29 04:00:51 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:00:51 --> Controller Class Initialized
INFO - 2022-03-29 04:00:51 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:00:51 --> Encrypt Class Initialized
DEBUG - 2022-03-29 04:00:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 04:00:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 04:00:51 --> Email Class Initialized
INFO - 2022-03-29 04:00:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 04:00:51 --> Calendar Class Initialized
INFO - 2022-03-29 04:00:51 --> Model "Login_model" initialized
INFO - 2022-03-29 04:00:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 04:00:51 --> Final output sent to browser
DEBUG - 2022-03-29 04:00:51 --> Total execution time: 0.0207
ERROR - 2022-03-29 04:01:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:01:11 --> Config Class Initialized
INFO - 2022-03-29 04:01:11 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:01:11 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:01:11 --> Utf8 Class Initialized
INFO - 2022-03-29 04:01:11 --> URI Class Initialized
INFO - 2022-03-29 04:01:11 --> Router Class Initialized
INFO - 2022-03-29 04:01:11 --> Output Class Initialized
INFO - 2022-03-29 04:01:11 --> Security Class Initialized
DEBUG - 2022-03-29 04:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:01:11 --> Input Class Initialized
INFO - 2022-03-29 04:01:11 --> Language Class Initialized
INFO - 2022-03-29 04:01:11 --> Loader Class Initialized
INFO - 2022-03-29 04:01:11 --> Helper loaded: url_helper
INFO - 2022-03-29 04:01:11 --> Helper loaded: form_helper
INFO - 2022-03-29 04:01:11 --> Helper loaded: common_helper
INFO - 2022-03-29 04:01:11 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:01:11 --> Controller Class Initialized
INFO - 2022-03-29 04:01:11 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:01:11 --> Encrypt Class Initialized
DEBUG - 2022-03-29 04:01:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 04:01:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 04:01:11 --> Email Class Initialized
INFO - 2022-03-29 04:01:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 04:01:11 --> Calendar Class Initialized
INFO - 2022-03-29 04:01:11 --> Model "Login_model" initialized
INFO - 2022-03-29 04:01:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-29 04:01:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:01:11 --> Config Class Initialized
INFO - 2022-03-29 04:01:11 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:01:11 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:01:11 --> Utf8 Class Initialized
INFO - 2022-03-29 04:01:11 --> URI Class Initialized
INFO - 2022-03-29 04:01:11 --> Router Class Initialized
INFO - 2022-03-29 04:01:11 --> Output Class Initialized
INFO - 2022-03-29 04:01:11 --> Security Class Initialized
DEBUG - 2022-03-29 04:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:01:11 --> Input Class Initialized
INFO - 2022-03-29 04:01:11 --> Language Class Initialized
INFO - 2022-03-29 04:01:11 --> Loader Class Initialized
INFO - 2022-03-29 04:01:11 --> Helper loaded: url_helper
INFO - 2022-03-29 04:01:11 --> Helper loaded: form_helper
INFO - 2022-03-29 04:01:11 --> Helper loaded: common_helper
INFO - 2022-03-29 04:01:11 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:01:11 --> Controller Class Initialized
INFO - 2022-03-29 04:01:11 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:01:11 --> Encrypt Class Initialized
INFO - 2022-03-29 04:01:11 --> Model "Login_model" initialized
INFO - 2022-03-29 04:01:11 --> Model "Dashboard_model" initialized
INFO - 2022-03-29 04:01:11 --> Model "Case_model" initialized
INFO - 2022-03-29 04:01:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 04:01:31 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-29 04:01:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 04:01:31 --> Final output sent to browser
DEBUG - 2022-03-29 04:01:31 --> Total execution time: 19.9974
ERROR - 2022-03-29 04:01:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:01:39 --> Config Class Initialized
INFO - 2022-03-29 04:01:39 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:01:39 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:01:39 --> Utf8 Class Initialized
INFO - 2022-03-29 04:01:39 --> URI Class Initialized
INFO - 2022-03-29 04:01:39 --> Router Class Initialized
INFO - 2022-03-29 04:01:39 --> Output Class Initialized
INFO - 2022-03-29 04:01:39 --> Security Class Initialized
DEBUG - 2022-03-29 04:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:01:39 --> Input Class Initialized
INFO - 2022-03-29 04:01:39 --> Language Class Initialized
INFO - 2022-03-29 04:01:39 --> Loader Class Initialized
INFO - 2022-03-29 04:01:39 --> Helper loaded: url_helper
INFO - 2022-03-29 04:01:39 --> Helper loaded: form_helper
INFO - 2022-03-29 04:01:39 --> Helper loaded: common_helper
INFO - 2022-03-29 04:01:39 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:01:39 --> Controller Class Initialized
INFO - 2022-03-29 04:01:39 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:01:39 --> Encrypt Class Initialized
INFO - 2022-03-29 04:01:39 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:01:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:01:39 --> Model "Referredby_model" initialized
INFO - 2022-03-29 04:01:39 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:01:39 --> Model "Hospital_model" initialized
INFO - 2022-03-29 04:01:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 04:01:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 04:01:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 04:01:48 --> Final output sent to browser
DEBUG - 2022-03-29 04:01:48 --> Total execution time: 7.1818
ERROR - 2022-03-29 04:02:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:02:15 --> Config Class Initialized
INFO - 2022-03-29 04:02:15 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:02:15 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:02:15 --> Utf8 Class Initialized
INFO - 2022-03-29 04:02:15 --> URI Class Initialized
INFO - 2022-03-29 04:02:15 --> Router Class Initialized
INFO - 2022-03-29 04:02:15 --> Output Class Initialized
INFO - 2022-03-29 04:02:15 --> Security Class Initialized
DEBUG - 2022-03-29 04:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:02:15 --> Input Class Initialized
INFO - 2022-03-29 04:02:15 --> Language Class Initialized
INFO - 2022-03-29 04:02:15 --> Loader Class Initialized
INFO - 2022-03-29 04:02:15 --> Helper loaded: url_helper
INFO - 2022-03-29 04:02:15 --> Helper loaded: form_helper
INFO - 2022-03-29 04:02:15 --> Helper loaded: common_helper
INFO - 2022-03-29 04:02:15 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:02:16 --> Controller Class Initialized
INFO - 2022-03-29 04:02:16 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:02:16 --> Encrypt Class Initialized
INFO - 2022-03-29 04:02:16 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:02:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:02:16 --> Model "Referredby_model" initialized
INFO - 2022-03-29 04:02:16 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:02:16 --> Model "Hospital_model" initialized
INFO - 2022-03-29 04:02:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 04:02:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 04:02:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 04:02:16 --> Final output sent to browser
DEBUG - 2022-03-29 04:02:16 --> Total execution time: 0.0382
ERROR - 2022-03-29 04:24:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:24:40 --> Config Class Initialized
INFO - 2022-03-29 04:24:40 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:24:40 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:24:40 --> Utf8 Class Initialized
INFO - 2022-03-29 04:24:40 --> URI Class Initialized
INFO - 2022-03-29 04:24:40 --> Router Class Initialized
INFO - 2022-03-29 04:24:40 --> Output Class Initialized
INFO - 2022-03-29 04:24:40 --> Security Class Initialized
DEBUG - 2022-03-29 04:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:24:40 --> Input Class Initialized
INFO - 2022-03-29 04:24:40 --> Language Class Initialized
INFO - 2022-03-29 04:24:40 --> Loader Class Initialized
INFO - 2022-03-29 04:24:40 --> Helper loaded: url_helper
INFO - 2022-03-29 04:24:40 --> Helper loaded: form_helper
INFO - 2022-03-29 04:24:40 --> Helper loaded: common_helper
INFO - 2022-03-29 04:24:40 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:24:40 --> Controller Class Initialized
INFO - 2022-03-29 04:24:40 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:24:40 --> Encrypt Class Initialized
INFO - 2022-03-29 04:24:40 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:24:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:24:40 --> Model "Referredby_model" initialized
INFO - 2022-03-29 04:24:40 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:24:40 --> Model "Hospital_model" initialized
INFO - 2022-03-29 04:24:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 04:24:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 04:24:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 04:24:40 --> Final output sent to browser
DEBUG - 2022-03-29 04:24:40 --> Total execution time: 0.0818
ERROR - 2022-03-29 04:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:30:52 --> Config Class Initialized
INFO - 2022-03-29 04:30:52 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:30:52 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:30:52 --> Utf8 Class Initialized
INFO - 2022-03-29 04:30:52 --> URI Class Initialized
INFO - 2022-03-29 04:30:52 --> Router Class Initialized
INFO - 2022-03-29 04:30:52 --> Output Class Initialized
INFO - 2022-03-29 04:30:52 --> Security Class Initialized
DEBUG - 2022-03-29 04:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:30:52 --> Input Class Initialized
INFO - 2022-03-29 04:30:52 --> Language Class Initialized
INFO - 2022-03-29 04:30:52 --> Loader Class Initialized
INFO - 2022-03-29 04:30:52 --> Helper loaded: url_helper
INFO - 2022-03-29 04:30:52 --> Helper loaded: form_helper
INFO - 2022-03-29 04:30:52 --> Helper loaded: common_helper
INFO - 2022-03-29 04:30:52 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:30:52 --> Controller Class Initialized
INFO - 2022-03-29 04:30:52 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:30:52 --> Encrypt Class Initialized
INFO - 2022-03-29 04:30:52 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:30:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:30:52 --> Model "Referredby_model" initialized
INFO - 2022-03-29 04:30:52 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:30:52 --> Model "Hospital_model" initialized
INFO - 2022-03-29 04:30:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 04:30:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 04:30:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 04:30:52 --> Final output sent to browser
DEBUG - 2022-03-29 04:30:52 --> Total execution time: 0.0776
ERROR - 2022-03-29 04:44:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:44:55 --> Config Class Initialized
INFO - 2022-03-29 04:44:55 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:44:55 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:44:55 --> Utf8 Class Initialized
INFO - 2022-03-29 04:44:55 --> URI Class Initialized
INFO - 2022-03-29 04:44:55 --> Router Class Initialized
INFO - 2022-03-29 04:44:55 --> Output Class Initialized
INFO - 2022-03-29 04:44:55 --> Security Class Initialized
DEBUG - 2022-03-29 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:44:55 --> Input Class Initialized
INFO - 2022-03-29 04:44:55 --> Language Class Initialized
INFO - 2022-03-29 04:44:55 --> Loader Class Initialized
INFO - 2022-03-29 04:44:55 --> Helper loaded: url_helper
INFO - 2022-03-29 04:44:55 --> Helper loaded: form_helper
INFO - 2022-03-29 04:44:55 --> Helper loaded: common_helper
INFO - 2022-03-29 04:44:55 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:44:55 --> Controller Class Initialized
INFO - 2022-03-29 04:44:55 --> Model "Referredby_model" initialized
INFO - 2022-03-29 04:44:55 --> Final output sent to browser
DEBUG - 2022-03-29 04:44:55 --> Total execution time: 0.0801
ERROR - 2022-03-29 04:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:45:28 --> Config Class Initialized
INFO - 2022-03-29 04:45:28 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:45:28 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:45:28 --> Utf8 Class Initialized
INFO - 2022-03-29 04:45:28 --> URI Class Initialized
INFO - 2022-03-29 04:45:28 --> Router Class Initialized
INFO - 2022-03-29 04:45:28 --> Output Class Initialized
INFO - 2022-03-29 04:45:28 --> Security Class Initialized
DEBUG - 2022-03-29 04:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:45:28 --> Input Class Initialized
INFO - 2022-03-29 04:45:28 --> Language Class Initialized
INFO - 2022-03-29 04:45:28 --> Loader Class Initialized
INFO - 2022-03-29 04:45:28 --> Helper loaded: url_helper
INFO - 2022-03-29 04:45:28 --> Helper loaded: form_helper
INFO - 2022-03-29 04:45:28 --> Helper loaded: common_helper
INFO - 2022-03-29 04:45:28 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:45:28 --> Controller Class Initialized
INFO - 2022-03-29 04:45:28 --> Model "Referredby_model" initialized
INFO - 2022-03-29 04:45:28 --> Final output sent to browser
DEBUG - 2022-03-29 04:45:28 --> Total execution time: 0.0086
ERROR - 2022-03-29 04:45:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:45:40 --> Config Class Initialized
INFO - 2022-03-29 04:45:40 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:45:40 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:45:40 --> Utf8 Class Initialized
INFO - 2022-03-29 04:45:40 --> URI Class Initialized
INFO - 2022-03-29 04:45:40 --> Router Class Initialized
INFO - 2022-03-29 04:45:40 --> Output Class Initialized
INFO - 2022-03-29 04:45:40 --> Security Class Initialized
DEBUG - 2022-03-29 04:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:45:40 --> Input Class Initialized
INFO - 2022-03-29 04:45:40 --> Language Class Initialized
INFO - 2022-03-29 04:45:40 --> Loader Class Initialized
INFO - 2022-03-29 04:45:40 --> Helper loaded: url_helper
INFO - 2022-03-29 04:45:40 --> Helper loaded: form_helper
INFO - 2022-03-29 04:45:40 --> Helper loaded: common_helper
INFO - 2022-03-29 04:45:40 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:45:40 --> Controller Class Initialized
INFO - 2022-03-29 04:45:40 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:45:40 --> Encrypt Class Initialized
INFO - 2022-03-29 04:45:40 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:45:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:45:40 --> Model "Referredby_model" initialized
INFO - 2022-03-29 04:45:40 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:45:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 04:45:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:45:40 --> Config Class Initialized
INFO - 2022-03-29 04:45:40 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:45:40 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:45:40 --> Utf8 Class Initialized
INFO - 2022-03-29 04:45:40 --> URI Class Initialized
INFO - 2022-03-29 04:45:40 --> Router Class Initialized
INFO - 2022-03-29 04:45:40 --> Output Class Initialized
INFO - 2022-03-29 04:45:40 --> Security Class Initialized
DEBUG - 2022-03-29 04:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:45:40 --> Input Class Initialized
INFO - 2022-03-29 04:45:40 --> Language Class Initialized
INFO - 2022-03-29 04:45:40 --> Loader Class Initialized
INFO - 2022-03-29 04:45:40 --> Helper loaded: url_helper
INFO - 2022-03-29 04:45:40 --> Helper loaded: form_helper
INFO - 2022-03-29 04:45:40 --> Helper loaded: common_helper
INFO - 2022-03-29 04:45:40 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:45:40 --> Controller Class Initialized
INFO - 2022-03-29 04:45:40 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:45:40 --> Encrypt Class Initialized
INFO - 2022-03-29 04:45:40 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:45:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:45:40 --> Model "Referredby_model" initialized
INFO - 2022-03-29 04:45:40 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:45:40 --> Model "Hospital_model" initialized
INFO - 2022-03-29 04:45:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 04:45:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 04:45:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 04:45:40 --> Final output sent to browser
DEBUG - 2022-03-29 04:45:40 --> Total execution time: 0.0332
ERROR - 2022-03-29 04:45:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:45:41 --> Config Class Initialized
INFO - 2022-03-29 04:45:41 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:45:41 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:45:41 --> Utf8 Class Initialized
INFO - 2022-03-29 04:45:41 --> URI Class Initialized
INFO - 2022-03-29 04:45:41 --> Router Class Initialized
INFO - 2022-03-29 04:45:41 --> Output Class Initialized
INFO - 2022-03-29 04:45:41 --> Security Class Initialized
DEBUG - 2022-03-29 04:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:45:41 --> Input Class Initialized
INFO - 2022-03-29 04:45:41 --> Language Class Initialized
INFO - 2022-03-29 04:45:41 --> Loader Class Initialized
INFO - 2022-03-29 04:45:41 --> Helper loaded: url_helper
INFO - 2022-03-29 04:45:41 --> Helper loaded: form_helper
INFO - 2022-03-29 04:45:41 --> Helper loaded: common_helper
INFO - 2022-03-29 04:45:41 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:45:41 --> Controller Class Initialized
INFO - 2022-03-29 04:45:41 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:45:41 --> Encrypt Class Initialized
INFO - 2022-03-29 04:45:41 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:45:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:45:41 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:45:41 --> Model "Users_model" initialized
INFO - 2022-03-29 04:45:41 --> Model "Hospital_model" initialized
INFO - 2022-03-29 04:45:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 04:45:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 04:45:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 04:45:41 --> Final output sent to browser
DEBUG - 2022-03-29 04:45:41 --> Total execution time: 0.0900
ERROR - 2022-03-29 04:47:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:47:55 --> Config Class Initialized
INFO - 2022-03-29 04:47:55 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:47:55 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:47:55 --> Utf8 Class Initialized
INFO - 2022-03-29 04:47:55 --> URI Class Initialized
INFO - 2022-03-29 04:47:55 --> Router Class Initialized
INFO - 2022-03-29 04:47:55 --> Output Class Initialized
INFO - 2022-03-29 04:47:55 --> Security Class Initialized
DEBUG - 2022-03-29 04:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:47:55 --> Input Class Initialized
INFO - 2022-03-29 04:47:55 --> Language Class Initialized
INFO - 2022-03-29 04:47:55 --> Loader Class Initialized
INFO - 2022-03-29 04:47:55 --> Helper loaded: url_helper
INFO - 2022-03-29 04:47:55 --> Helper loaded: form_helper
INFO - 2022-03-29 04:47:55 --> Helper loaded: common_helper
INFO - 2022-03-29 04:47:55 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:47:55 --> Controller Class Initialized
INFO - 2022-03-29 04:47:55 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:47:55 --> Encrypt Class Initialized
INFO - 2022-03-29 04:47:55 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:47:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:47:55 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:47:55 --> Model "Users_model" initialized
INFO - 2022-03-29 04:47:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 04:47:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:47:56 --> Config Class Initialized
INFO - 2022-03-29 04:47:56 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:47:56 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:47:56 --> Utf8 Class Initialized
INFO - 2022-03-29 04:47:56 --> URI Class Initialized
INFO - 2022-03-29 04:47:56 --> Router Class Initialized
INFO - 2022-03-29 04:47:56 --> Output Class Initialized
INFO - 2022-03-29 04:47:56 --> Security Class Initialized
DEBUG - 2022-03-29 04:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:47:56 --> Input Class Initialized
INFO - 2022-03-29 04:47:56 --> Language Class Initialized
INFO - 2022-03-29 04:47:56 --> Loader Class Initialized
INFO - 2022-03-29 04:47:56 --> Helper loaded: url_helper
INFO - 2022-03-29 04:47:56 --> Helper loaded: form_helper
INFO - 2022-03-29 04:47:56 --> Helper loaded: common_helper
INFO - 2022-03-29 04:47:56 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:47:56 --> Controller Class Initialized
INFO - 2022-03-29 04:47:56 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:47:56 --> Encrypt Class Initialized
INFO - 2022-03-29 04:47:56 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:47:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:47:56 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:47:56 --> Model "Users_model" initialized
INFO - 2022-03-29 04:47:56 --> Model "Hospital_model" initialized
INFO - 2022-03-29 04:47:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 04:47:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 04:47:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 04:47:56 --> Final output sent to browser
DEBUG - 2022-03-29 04:47:56 --> Total execution time: 0.0537
ERROR - 2022-03-29 04:51:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:51:35 --> Config Class Initialized
INFO - 2022-03-29 04:51:35 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:51:35 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:51:35 --> Utf8 Class Initialized
INFO - 2022-03-29 04:51:35 --> URI Class Initialized
INFO - 2022-03-29 04:51:35 --> Router Class Initialized
INFO - 2022-03-29 04:51:35 --> Output Class Initialized
INFO - 2022-03-29 04:51:35 --> Security Class Initialized
DEBUG - 2022-03-29 04:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:51:35 --> Input Class Initialized
INFO - 2022-03-29 04:51:35 --> Language Class Initialized
INFO - 2022-03-29 04:51:35 --> Loader Class Initialized
INFO - 2022-03-29 04:51:35 --> Helper loaded: url_helper
INFO - 2022-03-29 04:51:35 --> Helper loaded: form_helper
INFO - 2022-03-29 04:51:35 --> Helper loaded: common_helper
INFO - 2022-03-29 04:51:35 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:51:35 --> Controller Class Initialized
INFO - 2022-03-29 04:51:35 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:51:35 --> Encrypt Class Initialized
INFO - 2022-03-29 04:51:35 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:51:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:51:35 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:51:35 --> Model "Users_model" initialized
INFO - 2022-03-29 04:51:35 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 04:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 04:51:36 --> Config Class Initialized
INFO - 2022-03-29 04:51:36 --> Hooks Class Initialized
DEBUG - 2022-03-29 04:51:36 --> UTF-8 Support Enabled
INFO - 2022-03-29 04:51:36 --> Utf8 Class Initialized
INFO - 2022-03-29 04:51:36 --> URI Class Initialized
INFO - 2022-03-29 04:51:36 --> Router Class Initialized
INFO - 2022-03-29 04:51:36 --> Output Class Initialized
INFO - 2022-03-29 04:51:36 --> Security Class Initialized
DEBUG - 2022-03-29 04:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 04:51:36 --> Input Class Initialized
INFO - 2022-03-29 04:51:36 --> Language Class Initialized
INFO - 2022-03-29 04:51:36 --> Loader Class Initialized
INFO - 2022-03-29 04:51:36 --> Helper loaded: url_helper
INFO - 2022-03-29 04:51:36 --> Helper loaded: form_helper
INFO - 2022-03-29 04:51:36 --> Helper loaded: common_helper
INFO - 2022-03-29 04:51:36 --> Database Driver Class Initialized
DEBUG - 2022-03-29 04:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 04:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 04:51:36 --> Controller Class Initialized
INFO - 2022-03-29 04:51:36 --> Form Validation Class Initialized
DEBUG - 2022-03-29 04:51:36 --> Encrypt Class Initialized
INFO - 2022-03-29 04:51:36 --> Model "Patient_model" initialized
INFO - 2022-03-29 04:51:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 04:51:36 --> Model "Prefix_master" initialized
INFO - 2022-03-29 04:51:36 --> Model "Users_model" initialized
INFO - 2022-03-29 04:51:36 --> Model "Hospital_model" initialized
INFO - 2022-03-29 04:51:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 04:51:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 04:51:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 04:51:36 --> Final output sent to browser
DEBUG - 2022-03-29 04:51:36 --> Total execution time: 0.0411
ERROR - 2022-03-29 05:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:03:49 --> Config Class Initialized
INFO - 2022-03-29 05:03:49 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:03:49 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:03:49 --> Utf8 Class Initialized
INFO - 2022-03-29 05:03:49 --> URI Class Initialized
INFO - 2022-03-29 05:03:49 --> Router Class Initialized
INFO - 2022-03-29 05:03:49 --> Output Class Initialized
INFO - 2022-03-29 05:03:49 --> Security Class Initialized
DEBUG - 2022-03-29 05:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:03:49 --> Input Class Initialized
INFO - 2022-03-29 05:03:49 --> Language Class Initialized
INFO - 2022-03-29 05:03:49 --> Loader Class Initialized
INFO - 2022-03-29 05:03:49 --> Helper loaded: url_helper
INFO - 2022-03-29 05:03:49 --> Helper loaded: form_helper
INFO - 2022-03-29 05:03:49 --> Helper loaded: common_helper
INFO - 2022-03-29 05:03:49 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:03:49 --> Controller Class Initialized
INFO - 2022-03-29 05:03:49 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:03:49 --> Encrypt Class Initialized
INFO - 2022-03-29 05:03:49 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:03:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:03:49 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:03:49 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:03:49 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:03:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:03:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 05:03:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-29 05:03:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:03:56 --> Config Class Initialized
INFO - 2022-03-29 05:03:56 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:03:56 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:03:56 --> Utf8 Class Initialized
INFO - 2022-03-29 05:03:56 --> URI Class Initialized
INFO - 2022-03-29 05:03:56 --> Router Class Initialized
INFO - 2022-03-29 05:03:56 --> Output Class Initialized
INFO - 2022-03-29 05:03:56 --> Security Class Initialized
DEBUG - 2022-03-29 05:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:03:56 --> Input Class Initialized
INFO - 2022-03-29 05:03:56 --> Language Class Initialized
INFO - 2022-03-29 05:03:56 --> Loader Class Initialized
INFO - 2022-03-29 05:03:56 --> Helper loaded: url_helper
INFO - 2022-03-29 05:03:56 --> Helper loaded: form_helper
INFO - 2022-03-29 05:03:56 --> Helper loaded: common_helper
INFO - 2022-03-29 05:03:56 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:03:56 --> Controller Class Initialized
INFO - 2022-03-29 05:03:56 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:03:56 --> Encrypt Class Initialized
INFO - 2022-03-29 05:03:56 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:03:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:03:56 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:03:56 --> Model "Users_model" initialized
INFO - 2022-03-29 05:03:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 05:03:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:03:57 --> Config Class Initialized
INFO - 2022-03-29 05:03:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:03:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:03:57 --> Utf8 Class Initialized
INFO - 2022-03-29 05:03:57 --> URI Class Initialized
INFO - 2022-03-29 05:03:57 --> Router Class Initialized
INFO - 2022-03-29 05:03:57 --> Output Class Initialized
INFO - 2022-03-29 05:03:57 --> Security Class Initialized
DEBUG - 2022-03-29 05:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:03:57 --> Input Class Initialized
INFO - 2022-03-29 05:03:57 --> Language Class Initialized
INFO - 2022-03-29 05:03:57 --> Loader Class Initialized
INFO - 2022-03-29 05:03:57 --> Helper loaded: url_helper
INFO - 2022-03-29 05:03:57 --> Helper loaded: form_helper
INFO - 2022-03-29 05:03:57 --> Helper loaded: common_helper
INFO - 2022-03-29 05:03:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:03:57 --> Controller Class Initialized
INFO - 2022-03-29 05:03:57 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:03:57 --> Encrypt Class Initialized
INFO - 2022-03-29 05:03:57 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:03:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:03:57 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:03:57 --> Model "Users_model" initialized
INFO - 2022-03-29 05:03:57 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:03:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:03:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 05:03:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:03:57 --> Final output sent to browser
DEBUG - 2022-03-29 05:03:57 --> Total execution time: 0.0564
INFO - 2022-03-29 05:03:57 --> Final output sent to browser
DEBUG - 2022-03-29 05:03:57 --> Total execution time: 6.6818
ERROR - 2022-03-29 05:04:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:04:07 --> Config Class Initialized
INFO - 2022-03-29 05:04:07 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:04:07 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:04:07 --> Utf8 Class Initialized
INFO - 2022-03-29 05:04:07 --> URI Class Initialized
INFO - 2022-03-29 05:04:07 --> Router Class Initialized
INFO - 2022-03-29 05:04:07 --> Output Class Initialized
INFO - 2022-03-29 05:04:07 --> Security Class Initialized
DEBUG - 2022-03-29 05:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:04:07 --> Input Class Initialized
INFO - 2022-03-29 05:04:07 --> Language Class Initialized
INFO - 2022-03-29 05:04:07 --> Loader Class Initialized
INFO - 2022-03-29 05:04:07 --> Helper loaded: url_helper
INFO - 2022-03-29 05:04:07 --> Helper loaded: form_helper
INFO - 2022-03-29 05:04:07 --> Helper loaded: common_helper
INFO - 2022-03-29 05:04:07 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:04:07 --> Controller Class Initialized
INFO - 2022-03-29 05:04:07 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:04:07 --> Encrypt Class Initialized
INFO - 2022-03-29 05:04:07 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:04:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:04:07 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:04:07 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:04:07 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:04:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:04:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 05:04:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:04:17 --> Final output sent to browser
DEBUG - 2022-03-29 05:04:17 --> Total execution time: 8.7723
ERROR - 2022-03-29 05:06:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:06:10 --> Config Class Initialized
INFO - 2022-03-29 05:06:10 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:06:10 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:06:10 --> Utf8 Class Initialized
INFO - 2022-03-29 05:06:10 --> URI Class Initialized
INFO - 2022-03-29 05:06:10 --> Router Class Initialized
INFO - 2022-03-29 05:06:10 --> Output Class Initialized
INFO - 2022-03-29 05:06:10 --> Security Class Initialized
DEBUG - 2022-03-29 05:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:06:10 --> Input Class Initialized
INFO - 2022-03-29 05:06:10 --> Language Class Initialized
INFO - 2022-03-29 05:06:10 --> Loader Class Initialized
INFO - 2022-03-29 05:06:10 --> Helper loaded: url_helper
INFO - 2022-03-29 05:06:10 --> Helper loaded: form_helper
INFO - 2022-03-29 05:06:10 --> Helper loaded: common_helper
INFO - 2022-03-29 05:06:10 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:06:10 --> Controller Class Initialized
INFO - 2022-03-29 05:06:10 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:06:10 --> Encrypt Class Initialized
INFO - 2022-03-29 05:06:10 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:06:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:06:10 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:06:10 --> Model "Users_model" initialized
INFO - 2022-03-29 05:06:10 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:06:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:06:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 05:06:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:06:10 --> Final output sent to browser
DEBUG - 2022-03-29 05:06:10 --> Total execution time: 0.0512
ERROR - 2022-03-29 05:06:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:06:12 --> Config Class Initialized
INFO - 2022-03-29 05:06:12 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:06:12 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:06:12 --> Utf8 Class Initialized
INFO - 2022-03-29 05:06:12 --> URI Class Initialized
INFO - 2022-03-29 05:06:12 --> Router Class Initialized
INFO - 2022-03-29 05:06:12 --> Output Class Initialized
INFO - 2022-03-29 05:06:12 --> Security Class Initialized
DEBUG - 2022-03-29 05:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:06:12 --> Input Class Initialized
INFO - 2022-03-29 05:06:12 --> Language Class Initialized
INFO - 2022-03-29 05:06:12 --> Loader Class Initialized
INFO - 2022-03-29 05:06:12 --> Helper loaded: url_helper
INFO - 2022-03-29 05:06:12 --> Helper loaded: form_helper
INFO - 2022-03-29 05:06:12 --> Helper loaded: common_helper
INFO - 2022-03-29 05:06:12 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:06:12 --> Controller Class Initialized
INFO - 2022-03-29 05:06:12 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:06:12 --> Encrypt Class Initialized
INFO - 2022-03-29 05:06:12 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:06:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:06:12 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:06:12 --> Model "Users_model" initialized
INFO - 2022-03-29 05:06:12 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:06:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:06:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 05:06:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:06:12 --> Final output sent to browser
DEBUG - 2022-03-29 05:06:12 --> Total execution time: 0.0357
ERROR - 2022-03-29 05:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:06:22 --> Config Class Initialized
INFO - 2022-03-29 05:06:22 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:06:22 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:06:22 --> Utf8 Class Initialized
INFO - 2022-03-29 05:06:22 --> URI Class Initialized
INFO - 2022-03-29 05:06:22 --> Router Class Initialized
INFO - 2022-03-29 05:06:22 --> Output Class Initialized
INFO - 2022-03-29 05:06:22 --> Security Class Initialized
DEBUG - 2022-03-29 05:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:06:22 --> Input Class Initialized
INFO - 2022-03-29 05:06:22 --> Language Class Initialized
INFO - 2022-03-29 05:06:22 --> Loader Class Initialized
INFO - 2022-03-29 05:06:22 --> Helper loaded: url_helper
INFO - 2022-03-29 05:06:22 --> Helper loaded: form_helper
INFO - 2022-03-29 05:06:22 --> Helper loaded: common_helper
INFO - 2022-03-29 05:06:22 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:06:22 --> Controller Class Initialized
INFO - 2022-03-29 05:06:22 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:06:22 --> Encrypt Class Initialized
INFO - 2022-03-29 05:06:22 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:06:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:06:22 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:06:22 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:06:22 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:06:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:06:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 05:06:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:06:22 --> Final output sent to browser
DEBUG - 2022-03-29 05:06:22 --> Total execution time: 0.0551
ERROR - 2022-03-29 05:07:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:07:57 --> Config Class Initialized
INFO - 2022-03-29 05:07:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:07:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:07:57 --> Utf8 Class Initialized
INFO - 2022-03-29 05:07:57 --> URI Class Initialized
INFO - 2022-03-29 05:07:57 --> Router Class Initialized
INFO - 2022-03-29 05:07:57 --> Output Class Initialized
INFO - 2022-03-29 05:07:57 --> Security Class Initialized
DEBUG - 2022-03-29 05:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:07:57 --> Input Class Initialized
INFO - 2022-03-29 05:07:57 --> Language Class Initialized
INFO - 2022-03-29 05:07:57 --> Loader Class Initialized
INFO - 2022-03-29 05:07:57 --> Helper loaded: url_helper
INFO - 2022-03-29 05:07:57 --> Helper loaded: form_helper
INFO - 2022-03-29 05:07:57 --> Helper loaded: common_helper
INFO - 2022-03-29 05:07:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:07:57 --> Controller Class Initialized
INFO - 2022-03-29 05:07:57 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:07:57 --> Encrypt Class Initialized
INFO - 2022-03-29 05:07:57 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:07:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:07:57 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:07:57 --> Model "Users_model" initialized
INFO - 2022-03-29 05:07:57 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:07:57 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 05:07:58 --> Final output sent to browser
DEBUG - 2022-03-29 05:07:58 --> Total execution time: 1.1196
ERROR - 2022-03-29 05:09:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:09:43 --> Config Class Initialized
INFO - 2022-03-29 05:09:43 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:09:43 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:09:43 --> Utf8 Class Initialized
INFO - 2022-03-29 05:09:43 --> URI Class Initialized
DEBUG - 2022-03-29 05:09:43 --> No URI present. Default controller set.
INFO - 2022-03-29 05:09:43 --> Router Class Initialized
INFO - 2022-03-29 05:09:43 --> Output Class Initialized
INFO - 2022-03-29 05:09:43 --> Security Class Initialized
DEBUG - 2022-03-29 05:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:09:43 --> Input Class Initialized
INFO - 2022-03-29 05:09:43 --> Language Class Initialized
INFO - 2022-03-29 05:09:43 --> Loader Class Initialized
INFO - 2022-03-29 05:09:43 --> Helper loaded: url_helper
INFO - 2022-03-29 05:09:43 --> Helper loaded: form_helper
INFO - 2022-03-29 05:09:43 --> Helper loaded: common_helper
INFO - 2022-03-29 05:09:43 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:09:43 --> Controller Class Initialized
INFO - 2022-03-29 05:09:43 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:09:43 --> Encrypt Class Initialized
DEBUG - 2022-03-29 05:09:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 05:09:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 05:09:43 --> Email Class Initialized
INFO - 2022-03-29 05:09:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 05:09:43 --> Calendar Class Initialized
INFO - 2022-03-29 05:09:43 --> Model "Login_model" initialized
ERROR - 2022-03-29 05:09:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:09:43 --> Config Class Initialized
INFO - 2022-03-29 05:09:43 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:09:43 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:09:43 --> Utf8 Class Initialized
INFO - 2022-03-29 05:09:43 --> URI Class Initialized
INFO - 2022-03-29 05:09:43 --> Router Class Initialized
INFO - 2022-03-29 05:09:43 --> Output Class Initialized
INFO - 2022-03-29 05:09:43 --> Security Class Initialized
DEBUG - 2022-03-29 05:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:09:43 --> Input Class Initialized
INFO - 2022-03-29 05:09:43 --> Language Class Initialized
INFO - 2022-03-29 05:09:43 --> Loader Class Initialized
INFO - 2022-03-29 05:09:43 --> Helper loaded: url_helper
INFO - 2022-03-29 05:09:43 --> Helper loaded: form_helper
INFO - 2022-03-29 05:09:43 --> Helper loaded: common_helper
INFO - 2022-03-29 05:09:43 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:09:43 --> Controller Class Initialized
INFO - 2022-03-29 05:09:43 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:09:43 --> Encrypt Class Initialized
INFO - 2022-03-29 05:09:43 --> Model "Diseases_model" initialized
INFO - 2022-03-29 05:09:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:09:43 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-29 05:09:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:09:43 --> Final output sent to browser
DEBUG - 2022-03-29 05:09:43 --> Total execution time: 0.0096
ERROR - 2022-03-29 05:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:09:45 --> Config Class Initialized
INFO - 2022-03-29 05:09:45 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:09:45 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:09:45 --> Utf8 Class Initialized
INFO - 2022-03-29 05:09:45 --> URI Class Initialized
DEBUG - 2022-03-29 05:09:45 --> No URI present. Default controller set.
INFO - 2022-03-29 05:09:45 --> Router Class Initialized
INFO - 2022-03-29 05:09:45 --> Output Class Initialized
INFO - 2022-03-29 05:09:45 --> Security Class Initialized
DEBUG - 2022-03-29 05:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:09:45 --> Input Class Initialized
INFO - 2022-03-29 05:09:45 --> Language Class Initialized
INFO - 2022-03-29 05:09:45 --> Loader Class Initialized
INFO - 2022-03-29 05:09:45 --> Helper loaded: url_helper
INFO - 2022-03-29 05:09:45 --> Helper loaded: form_helper
INFO - 2022-03-29 05:09:45 --> Helper loaded: common_helper
INFO - 2022-03-29 05:09:45 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:09:45 --> Controller Class Initialized
INFO - 2022-03-29 05:09:45 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:09:45 --> Encrypt Class Initialized
DEBUG - 2022-03-29 05:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 05:09:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 05:09:45 --> Email Class Initialized
INFO - 2022-03-29 05:09:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 05:09:45 --> Calendar Class Initialized
INFO - 2022-03-29 05:09:45 --> Model "Login_model" initialized
ERROR - 2022-03-29 05:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:09:46 --> Config Class Initialized
INFO - 2022-03-29 05:09:46 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:09:46 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:09:46 --> Utf8 Class Initialized
INFO - 2022-03-29 05:09:46 --> URI Class Initialized
INFO - 2022-03-29 05:09:46 --> Router Class Initialized
INFO - 2022-03-29 05:09:46 --> Output Class Initialized
INFO - 2022-03-29 05:09:46 --> Security Class Initialized
DEBUG - 2022-03-29 05:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:09:46 --> Input Class Initialized
INFO - 2022-03-29 05:09:46 --> Language Class Initialized
INFO - 2022-03-29 05:09:46 --> Loader Class Initialized
INFO - 2022-03-29 05:09:46 --> Helper loaded: url_helper
INFO - 2022-03-29 05:09:46 --> Helper loaded: form_helper
INFO - 2022-03-29 05:09:46 --> Helper loaded: common_helper
INFO - 2022-03-29 05:09:46 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:09:46 --> Controller Class Initialized
INFO - 2022-03-29 05:09:46 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:09:46 --> Encrypt Class Initialized
INFO - 2022-03-29 05:09:46 --> Model "Diseases_model" initialized
INFO - 2022-03-29 05:09:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:09:46 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-29 05:09:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:09:46 --> Final output sent to browser
DEBUG - 2022-03-29 05:09:46 --> Total execution time: 0.0062
ERROR - 2022-03-29 05:09:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:09:51 --> Config Class Initialized
INFO - 2022-03-29 05:09:51 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:09:51 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:09:51 --> Utf8 Class Initialized
INFO - 2022-03-29 05:09:51 --> URI Class Initialized
INFO - 2022-03-29 05:09:51 --> Router Class Initialized
INFO - 2022-03-29 05:09:51 --> Output Class Initialized
INFO - 2022-03-29 05:09:51 --> Security Class Initialized
DEBUG - 2022-03-29 05:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:09:51 --> Input Class Initialized
INFO - 2022-03-29 05:09:51 --> Language Class Initialized
INFO - 2022-03-29 05:09:51 --> Loader Class Initialized
INFO - 2022-03-29 05:09:51 --> Helper loaded: url_helper
INFO - 2022-03-29 05:09:51 --> Helper loaded: form_helper
INFO - 2022-03-29 05:09:51 --> Helper loaded: common_helper
INFO - 2022-03-29 05:09:51 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:09:51 --> Controller Class Initialized
INFO - 2022-03-29 05:09:51 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:09:51 --> Encrypt Class Initialized
INFO - 2022-03-29 05:09:51 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:09:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:09:51 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:09:51 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:09:51 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:09:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:09:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 05:09:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:09:51 --> Final output sent to browser
DEBUG - 2022-03-29 05:09:51 --> Total execution time: 0.0155
ERROR - 2022-03-29 05:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:10:02 --> Config Class Initialized
INFO - 2022-03-29 05:10:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:10:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:10:02 --> Utf8 Class Initialized
INFO - 2022-03-29 05:10:02 --> URI Class Initialized
INFO - 2022-03-29 05:10:02 --> Router Class Initialized
INFO - 2022-03-29 05:10:02 --> Output Class Initialized
INFO - 2022-03-29 05:10:02 --> Security Class Initialized
DEBUG - 2022-03-29 05:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:10:02 --> Input Class Initialized
INFO - 2022-03-29 05:10:02 --> Language Class Initialized
INFO - 2022-03-29 05:10:02 --> Loader Class Initialized
INFO - 2022-03-29 05:10:02 --> Helper loaded: url_helper
INFO - 2022-03-29 05:10:02 --> Helper loaded: form_helper
INFO - 2022-03-29 05:10:02 --> Helper loaded: common_helper
INFO - 2022-03-29 05:10:02 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:10:02 --> Controller Class Initialized
INFO - 2022-03-29 05:10:02 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:10:02 --> Encrypt Class Initialized
INFO - 2022-03-29 05:10:02 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:10:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:10:02 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:10:02 --> Model "Users_model" initialized
INFO - 2022-03-29 05:10:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 05:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:10:02 --> Config Class Initialized
INFO - 2022-03-29 05:10:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:10:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:10:02 --> Utf8 Class Initialized
INFO - 2022-03-29 05:10:02 --> URI Class Initialized
INFO - 2022-03-29 05:10:02 --> Router Class Initialized
INFO - 2022-03-29 05:10:02 --> Output Class Initialized
INFO - 2022-03-29 05:10:02 --> Security Class Initialized
DEBUG - 2022-03-29 05:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:10:02 --> Input Class Initialized
INFO - 2022-03-29 05:10:02 --> Language Class Initialized
INFO - 2022-03-29 05:10:02 --> Loader Class Initialized
INFO - 2022-03-29 05:10:02 --> Helper loaded: url_helper
INFO - 2022-03-29 05:10:02 --> Helper loaded: form_helper
INFO - 2022-03-29 05:10:02 --> Helper loaded: common_helper
INFO - 2022-03-29 05:10:02 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:10:02 --> Controller Class Initialized
INFO - 2022-03-29 05:10:02 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:10:02 --> Encrypt Class Initialized
INFO - 2022-03-29 05:10:02 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:10:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:10:02 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:10:02 --> Model "Users_model" initialized
INFO - 2022-03-29 05:10:02 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:10:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:10:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 05:10:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:10:02 --> Final output sent to browser
DEBUG - 2022-03-29 05:10:02 --> Total execution time: 0.0655
ERROR - 2022-03-29 05:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:10:36 --> Config Class Initialized
INFO - 2022-03-29 05:10:36 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:10:36 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:10:36 --> Utf8 Class Initialized
INFO - 2022-03-29 05:10:36 --> URI Class Initialized
INFO - 2022-03-29 05:10:36 --> Router Class Initialized
INFO - 2022-03-29 05:10:36 --> Output Class Initialized
INFO - 2022-03-29 05:10:36 --> Security Class Initialized
DEBUG - 2022-03-29 05:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:10:36 --> Input Class Initialized
INFO - 2022-03-29 05:10:36 --> Language Class Initialized
INFO - 2022-03-29 05:10:36 --> Loader Class Initialized
INFO - 2022-03-29 05:10:36 --> Helper loaded: url_helper
INFO - 2022-03-29 05:10:36 --> Helper loaded: form_helper
INFO - 2022-03-29 05:10:36 --> Helper loaded: common_helper
INFO - 2022-03-29 05:10:36 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:10:36 --> Controller Class Initialized
INFO - 2022-03-29 05:10:36 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:10:36 --> Encrypt Class Initialized
INFO - 2022-03-29 05:10:36 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:10:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:10:36 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:10:36 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:10:36 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:10:36 --> Upload Class Initialized
INFO - 2022-03-29 05:10:36 --> Final output sent to browser
DEBUG - 2022-03-29 05:10:36 --> Total execution time: 0.0147
ERROR - 2022-03-29 05:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:17:21 --> Config Class Initialized
INFO - 2022-03-29 05:17:21 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:17:21 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:17:21 --> Utf8 Class Initialized
INFO - 2022-03-29 05:17:21 --> URI Class Initialized
INFO - 2022-03-29 05:17:21 --> Router Class Initialized
INFO - 2022-03-29 05:17:21 --> Output Class Initialized
INFO - 2022-03-29 05:17:21 --> Security Class Initialized
DEBUG - 2022-03-29 05:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:17:21 --> Input Class Initialized
INFO - 2022-03-29 05:17:21 --> Language Class Initialized
INFO - 2022-03-29 05:17:21 --> Loader Class Initialized
INFO - 2022-03-29 05:17:21 --> Helper loaded: url_helper
INFO - 2022-03-29 05:17:21 --> Helper loaded: form_helper
INFO - 2022-03-29 05:17:21 --> Helper loaded: common_helper
INFO - 2022-03-29 05:17:21 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:17:21 --> Controller Class Initialized
INFO - 2022-03-29 05:17:21 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:17:21 --> Encrypt Class Initialized
INFO - 2022-03-29 05:17:21 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:17:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:17:21 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:17:21 --> Model "Users_model" initialized
INFO - 2022-03-29 05:17:21 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:17:21 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 05:17:22 --> Final output sent to browser
DEBUG - 2022-03-29 05:17:22 --> Total execution time: 1.2078
ERROR - 2022-03-29 05:19:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:19:00 --> Config Class Initialized
INFO - 2022-03-29 05:19:00 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:19:00 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:19:00 --> Utf8 Class Initialized
INFO - 2022-03-29 05:19:00 --> URI Class Initialized
DEBUG - 2022-03-29 05:19:00 --> No URI present. Default controller set.
INFO - 2022-03-29 05:19:00 --> Router Class Initialized
INFO - 2022-03-29 05:19:00 --> Output Class Initialized
INFO - 2022-03-29 05:19:00 --> Security Class Initialized
DEBUG - 2022-03-29 05:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:19:00 --> Input Class Initialized
INFO - 2022-03-29 05:19:00 --> Language Class Initialized
INFO - 2022-03-29 05:19:00 --> Loader Class Initialized
INFO - 2022-03-29 05:19:00 --> Helper loaded: url_helper
INFO - 2022-03-29 05:19:00 --> Helper loaded: form_helper
INFO - 2022-03-29 05:19:00 --> Helper loaded: common_helper
INFO - 2022-03-29 05:19:00 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:19:00 --> Controller Class Initialized
INFO - 2022-03-29 05:19:00 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:19:00 --> Encrypt Class Initialized
DEBUG - 2022-03-29 05:19:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 05:19:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 05:19:00 --> Email Class Initialized
INFO - 2022-03-29 05:19:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 05:19:00 --> Calendar Class Initialized
INFO - 2022-03-29 05:19:00 --> Model "Login_model" initialized
INFO - 2022-03-29 05:19:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 05:19:00 --> Final output sent to browser
DEBUG - 2022-03-29 05:19:00 --> Total execution time: 0.0215
ERROR - 2022-03-29 05:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:20:30 --> Config Class Initialized
INFO - 2022-03-29 05:20:30 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:20:30 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:20:30 --> Utf8 Class Initialized
INFO - 2022-03-29 05:20:30 --> URI Class Initialized
INFO - 2022-03-29 05:20:30 --> Router Class Initialized
INFO - 2022-03-29 05:20:30 --> Output Class Initialized
INFO - 2022-03-29 05:20:30 --> Security Class Initialized
DEBUG - 2022-03-29 05:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:20:30 --> Input Class Initialized
INFO - 2022-03-29 05:20:30 --> Language Class Initialized
INFO - 2022-03-29 05:20:30 --> Loader Class Initialized
INFO - 2022-03-29 05:20:30 --> Helper loaded: url_helper
INFO - 2022-03-29 05:20:30 --> Helper loaded: form_helper
INFO - 2022-03-29 05:20:30 --> Helper loaded: common_helper
INFO - 2022-03-29 05:20:30 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:20:30 --> Controller Class Initialized
INFO - 2022-03-29 05:20:30 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:20:30 --> Final output sent to browser
DEBUG - 2022-03-29 05:20:30 --> Total execution time: 0.0116
ERROR - 2022-03-29 05:25:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:25:59 --> Config Class Initialized
INFO - 2022-03-29 05:25:59 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:25:59 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:25:59 --> Utf8 Class Initialized
INFO - 2022-03-29 05:25:59 --> URI Class Initialized
INFO - 2022-03-29 05:25:59 --> Router Class Initialized
INFO - 2022-03-29 05:25:59 --> Output Class Initialized
INFO - 2022-03-29 05:25:59 --> Security Class Initialized
DEBUG - 2022-03-29 05:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:25:59 --> Input Class Initialized
INFO - 2022-03-29 05:25:59 --> Language Class Initialized
INFO - 2022-03-29 05:25:59 --> Loader Class Initialized
INFO - 2022-03-29 05:25:59 --> Helper loaded: url_helper
INFO - 2022-03-29 05:25:59 --> Helper loaded: form_helper
INFO - 2022-03-29 05:25:59 --> Helper loaded: common_helper
INFO - 2022-03-29 05:25:59 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:25:59 --> Controller Class Initialized
INFO - 2022-03-29 05:25:59 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:25:59 --> Encrypt Class Initialized
INFO - 2022-03-29 05:25:59 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:25:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:25:59 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:25:59 --> Model "Users_model" initialized
INFO - 2022-03-29 05:25:59 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:25:59 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 05:26:00 --> Final output sent to browser
DEBUG - 2022-03-29 05:26:00 --> Total execution time: 1.3497
ERROR - 2022-03-29 05:26:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:26:55 --> Config Class Initialized
INFO - 2022-03-29 05:26:55 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:26:55 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:26:55 --> Utf8 Class Initialized
INFO - 2022-03-29 05:26:55 --> URI Class Initialized
INFO - 2022-03-29 05:26:55 --> Router Class Initialized
INFO - 2022-03-29 05:26:55 --> Output Class Initialized
INFO - 2022-03-29 05:26:55 --> Security Class Initialized
DEBUG - 2022-03-29 05:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:26:55 --> Input Class Initialized
INFO - 2022-03-29 05:26:55 --> Language Class Initialized
INFO - 2022-03-29 05:26:55 --> Loader Class Initialized
INFO - 2022-03-29 05:26:55 --> Helper loaded: url_helper
INFO - 2022-03-29 05:26:55 --> Helper loaded: form_helper
INFO - 2022-03-29 05:26:55 --> Helper loaded: common_helper
INFO - 2022-03-29 05:26:55 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:26:56 --> Controller Class Initialized
INFO - 2022-03-29 05:26:56 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:26:56 --> Final output sent to browser
DEBUG - 2022-03-29 05:26:56 --> Total execution time: 0.4925
ERROR - 2022-03-29 05:27:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:27:57 --> Config Class Initialized
INFO - 2022-03-29 05:27:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:27:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:27:57 --> Utf8 Class Initialized
INFO - 2022-03-29 05:27:57 --> URI Class Initialized
INFO - 2022-03-29 05:27:57 --> Router Class Initialized
INFO - 2022-03-29 05:27:57 --> Output Class Initialized
INFO - 2022-03-29 05:27:57 --> Security Class Initialized
DEBUG - 2022-03-29 05:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:27:57 --> Input Class Initialized
INFO - 2022-03-29 05:27:57 --> Language Class Initialized
INFO - 2022-03-29 05:27:57 --> Loader Class Initialized
INFO - 2022-03-29 05:27:57 --> Helper loaded: url_helper
INFO - 2022-03-29 05:27:57 --> Helper loaded: form_helper
INFO - 2022-03-29 05:27:57 --> Helper loaded: common_helper
INFO - 2022-03-29 05:27:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:27:57 --> Controller Class Initialized
INFO - 2022-03-29 05:27:57 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:27:57 --> Encrypt Class Initialized
INFO - 2022-03-29 05:27:57 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:27:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:27:57 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:27:57 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:27:57 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:27:57 --> Final output sent to browser
DEBUG - 2022-03-29 05:27:57 --> Total execution time: 0.0122
ERROR - 2022-03-29 05:33:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:33:58 --> Config Class Initialized
INFO - 2022-03-29 05:33:58 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:33:58 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:33:58 --> Utf8 Class Initialized
INFO - 2022-03-29 05:33:58 --> URI Class Initialized
INFO - 2022-03-29 05:33:58 --> Router Class Initialized
INFO - 2022-03-29 05:33:58 --> Output Class Initialized
INFO - 2022-03-29 05:33:58 --> Security Class Initialized
DEBUG - 2022-03-29 05:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:33:58 --> Input Class Initialized
INFO - 2022-03-29 05:33:58 --> Language Class Initialized
INFO - 2022-03-29 05:33:58 --> Loader Class Initialized
INFO - 2022-03-29 05:33:58 --> Helper loaded: url_helper
INFO - 2022-03-29 05:33:58 --> Helper loaded: form_helper
INFO - 2022-03-29 05:33:58 --> Helper loaded: common_helper
INFO - 2022-03-29 05:33:58 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:33:58 --> Controller Class Initialized
INFO - 2022-03-29 05:33:58 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:33:58 --> Encrypt Class Initialized
INFO - 2022-03-29 05:33:58 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:33:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:33:58 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:33:58 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:33:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 05:33:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:33:58 --> Config Class Initialized
INFO - 2022-03-29 05:33:58 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:33:58 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:33:58 --> Utf8 Class Initialized
INFO - 2022-03-29 05:33:58 --> URI Class Initialized
INFO - 2022-03-29 05:33:58 --> Router Class Initialized
INFO - 2022-03-29 05:33:58 --> Output Class Initialized
INFO - 2022-03-29 05:33:58 --> Security Class Initialized
DEBUG - 2022-03-29 05:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:33:58 --> Input Class Initialized
INFO - 2022-03-29 05:33:58 --> Language Class Initialized
INFO - 2022-03-29 05:33:58 --> Loader Class Initialized
INFO - 2022-03-29 05:33:58 --> Helper loaded: url_helper
INFO - 2022-03-29 05:33:58 --> Helper loaded: form_helper
INFO - 2022-03-29 05:33:58 --> Helper loaded: common_helper
INFO - 2022-03-29 05:33:58 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:33:58 --> Controller Class Initialized
INFO - 2022-03-29 05:33:58 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:33:58 --> Encrypt Class Initialized
INFO - 2022-03-29 05:33:58 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:33:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:33:58 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:33:58 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:33:58 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:33:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:33:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 05:33:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:33:58 --> Final output sent to browser
DEBUG - 2022-03-29 05:33:58 --> Total execution time: 0.0295
ERROR - 2022-03-29 05:33:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:33:59 --> Config Class Initialized
INFO - 2022-03-29 05:33:59 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:33:59 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:33:59 --> Utf8 Class Initialized
INFO - 2022-03-29 05:33:59 --> URI Class Initialized
INFO - 2022-03-29 05:33:59 --> Router Class Initialized
INFO - 2022-03-29 05:33:59 --> Output Class Initialized
INFO - 2022-03-29 05:33:59 --> Security Class Initialized
DEBUG - 2022-03-29 05:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:33:59 --> Input Class Initialized
INFO - 2022-03-29 05:33:59 --> Language Class Initialized
INFO - 2022-03-29 05:33:59 --> Loader Class Initialized
INFO - 2022-03-29 05:33:59 --> Helper loaded: url_helper
INFO - 2022-03-29 05:33:59 --> Helper loaded: form_helper
INFO - 2022-03-29 05:33:59 --> Helper loaded: common_helper
INFO - 2022-03-29 05:33:59 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:33:59 --> Controller Class Initialized
INFO - 2022-03-29 05:33:59 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:33:59 --> Encrypt Class Initialized
INFO - 2022-03-29 05:33:59 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:33:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:33:59 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:33:59 --> Model "Users_model" initialized
INFO - 2022-03-29 05:33:59 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:33:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:33:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 05:33:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:33:59 --> Final output sent to browser
DEBUG - 2022-03-29 05:33:59 --> Total execution time: 0.0655
ERROR - 2022-03-29 05:36:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:36:47 --> Config Class Initialized
INFO - 2022-03-29 05:36:47 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:36:47 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:36:47 --> Utf8 Class Initialized
INFO - 2022-03-29 05:36:47 --> URI Class Initialized
INFO - 2022-03-29 05:36:47 --> Router Class Initialized
INFO - 2022-03-29 05:36:47 --> Output Class Initialized
INFO - 2022-03-29 05:36:47 --> Security Class Initialized
DEBUG - 2022-03-29 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:36:47 --> Input Class Initialized
INFO - 2022-03-29 05:36:47 --> Language Class Initialized
INFO - 2022-03-29 05:36:47 --> Loader Class Initialized
INFO - 2022-03-29 05:36:47 --> Helper loaded: url_helper
INFO - 2022-03-29 05:36:47 --> Helper loaded: form_helper
INFO - 2022-03-29 05:36:47 --> Helper loaded: common_helper
INFO - 2022-03-29 05:36:47 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:36:47 --> Controller Class Initialized
INFO - 2022-03-29 05:36:47 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:36:47 --> Encrypt Class Initialized
INFO - 2022-03-29 05:36:47 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:36:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:36:47 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:36:47 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:36:47 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:36:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:36:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 05:36:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:36:47 --> Final output sent to browser
DEBUG - 2022-03-29 05:36:47 --> Total execution time: 0.1104
ERROR - 2022-03-29 05:36:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:36:50 --> Config Class Initialized
INFO - 2022-03-29 05:36:50 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:36:50 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:36:50 --> Utf8 Class Initialized
INFO - 2022-03-29 05:36:50 --> URI Class Initialized
INFO - 2022-03-29 05:36:50 --> Router Class Initialized
INFO - 2022-03-29 05:36:50 --> Output Class Initialized
INFO - 2022-03-29 05:36:50 --> Security Class Initialized
DEBUG - 2022-03-29 05:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:36:50 --> Input Class Initialized
INFO - 2022-03-29 05:36:50 --> Language Class Initialized
INFO - 2022-03-29 05:36:50 --> Loader Class Initialized
INFO - 2022-03-29 05:36:50 --> Helper loaded: url_helper
INFO - 2022-03-29 05:36:50 --> Helper loaded: form_helper
INFO - 2022-03-29 05:36:50 --> Helper loaded: common_helper
INFO - 2022-03-29 05:36:50 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:36:50 --> Controller Class Initialized
INFO - 2022-03-29 05:36:50 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:36:50 --> Encrypt Class Initialized
INFO - 2022-03-29 05:36:50 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:36:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:36:50 --> Model "Referredby_model" initialized
INFO - 2022-03-29 05:36:50 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:36:50 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:36:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:36:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 05:36:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:36:50 --> Final output sent to browser
DEBUG - 2022-03-29 05:36:50 --> Total execution time: 0.0597
ERROR - 2022-03-29 05:56:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:56:17 --> Config Class Initialized
INFO - 2022-03-29 05:56:17 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:56:17 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:56:17 --> Utf8 Class Initialized
INFO - 2022-03-29 05:56:17 --> URI Class Initialized
INFO - 2022-03-29 05:56:17 --> Router Class Initialized
INFO - 2022-03-29 05:56:17 --> Output Class Initialized
INFO - 2022-03-29 05:56:17 --> Security Class Initialized
DEBUG - 2022-03-29 05:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:56:17 --> Input Class Initialized
INFO - 2022-03-29 05:56:17 --> Language Class Initialized
INFO - 2022-03-29 05:56:17 --> Loader Class Initialized
INFO - 2022-03-29 05:56:17 --> Helper loaded: url_helper
INFO - 2022-03-29 05:56:17 --> Helper loaded: form_helper
INFO - 2022-03-29 05:56:17 --> Helper loaded: common_helper
INFO - 2022-03-29 05:56:17 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:56:17 --> Controller Class Initialized
INFO - 2022-03-29 05:56:17 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:56:17 --> Encrypt Class Initialized
INFO - 2022-03-29 05:56:17 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:56:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:56:17 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:56:17 --> Model "Users_model" initialized
INFO - 2022-03-29 05:56:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 05:56:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 05:56:18 --> Config Class Initialized
INFO - 2022-03-29 05:56:18 --> Hooks Class Initialized
DEBUG - 2022-03-29 05:56:18 --> UTF-8 Support Enabled
INFO - 2022-03-29 05:56:18 --> Utf8 Class Initialized
INFO - 2022-03-29 05:56:18 --> URI Class Initialized
INFO - 2022-03-29 05:56:18 --> Router Class Initialized
INFO - 2022-03-29 05:56:18 --> Output Class Initialized
INFO - 2022-03-29 05:56:18 --> Security Class Initialized
DEBUG - 2022-03-29 05:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 05:56:18 --> Input Class Initialized
INFO - 2022-03-29 05:56:18 --> Language Class Initialized
INFO - 2022-03-29 05:56:18 --> Loader Class Initialized
INFO - 2022-03-29 05:56:18 --> Helper loaded: url_helper
INFO - 2022-03-29 05:56:18 --> Helper loaded: form_helper
INFO - 2022-03-29 05:56:18 --> Helper loaded: common_helper
INFO - 2022-03-29 05:56:18 --> Database Driver Class Initialized
DEBUG - 2022-03-29 05:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 05:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 05:56:18 --> Controller Class Initialized
INFO - 2022-03-29 05:56:18 --> Form Validation Class Initialized
DEBUG - 2022-03-29 05:56:18 --> Encrypt Class Initialized
INFO - 2022-03-29 05:56:18 --> Model "Patient_model" initialized
INFO - 2022-03-29 05:56:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 05:56:18 --> Model "Prefix_master" initialized
INFO - 2022-03-29 05:56:18 --> Model "Users_model" initialized
INFO - 2022-03-29 05:56:18 --> Model "Hospital_model" initialized
INFO - 2022-03-29 05:56:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 05:56:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 05:56:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 05:56:18 --> Final output sent to browser
DEBUG - 2022-03-29 05:56:18 --> Total execution time: 0.0529
ERROR - 2022-03-29 06:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:18:21 --> Config Class Initialized
INFO - 2022-03-29 06:18:21 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:18:21 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:18:21 --> Utf8 Class Initialized
INFO - 2022-03-29 06:18:21 --> URI Class Initialized
INFO - 2022-03-29 06:18:21 --> Router Class Initialized
INFO - 2022-03-29 06:18:21 --> Output Class Initialized
INFO - 2022-03-29 06:18:21 --> Security Class Initialized
DEBUG - 2022-03-29 06:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:18:21 --> Input Class Initialized
INFO - 2022-03-29 06:18:21 --> Language Class Initialized
INFO - 2022-03-29 06:18:21 --> Loader Class Initialized
INFO - 2022-03-29 06:18:21 --> Helper loaded: url_helper
INFO - 2022-03-29 06:18:21 --> Helper loaded: form_helper
INFO - 2022-03-29 06:18:21 --> Helper loaded: common_helper
INFO - 2022-03-29 06:18:21 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:18:21 --> Controller Class Initialized
INFO - 2022-03-29 06:18:21 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:18:21 --> Encrypt Class Initialized
INFO - 2022-03-29 06:18:21 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:18:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:18:21 --> Model "Referredby_model" initialized
INFO - 2022-03-29 06:18:21 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:18:21 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:18:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 06:18:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 06:18:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 06:18:31 --> Final output sent to browser
DEBUG - 2022-03-29 06:18:31 --> Total execution time: 7.4213
ERROR - 2022-03-29 06:26:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:26:34 --> Config Class Initialized
INFO - 2022-03-29 06:26:34 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:26:34 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:26:34 --> Utf8 Class Initialized
INFO - 2022-03-29 06:26:34 --> URI Class Initialized
INFO - 2022-03-29 06:26:34 --> Router Class Initialized
INFO - 2022-03-29 06:26:34 --> Output Class Initialized
INFO - 2022-03-29 06:26:34 --> Security Class Initialized
DEBUG - 2022-03-29 06:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:26:34 --> Input Class Initialized
INFO - 2022-03-29 06:26:34 --> Language Class Initialized
INFO - 2022-03-29 06:26:34 --> Loader Class Initialized
INFO - 2022-03-29 06:26:34 --> Helper loaded: url_helper
INFO - 2022-03-29 06:26:34 --> Helper loaded: form_helper
INFO - 2022-03-29 06:26:34 --> Helper loaded: common_helper
INFO - 2022-03-29 06:26:34 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:26:34 --> Controller Class Initialized
INFO - 2022-03-29 06:26:34 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:26:34 --> Encrypt Class Initialized
INFO - 2022-03-29 06:26:34 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:26:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:26:34 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:26:34 --> Model "Users_model" initialized
INFO - 2022-03-29 06:26:34 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:26:34 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 06:26:35 --> Final output sent to browser
DEBUG - 2022-03-29 06:26:35 --> Total execution time: 1.1600
ERROR - 2022-03-29 06:26:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:26:41 --> Config Class Initialized
INFO - 2022-03-29 06:26:41 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:26:41 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:26:41 --> Utf8 Class Initialized
INFO - 2022-03-29 06:26:41 --> URI Class Initialized
INFO - 2022-03-29 06:26:41 --> Router Class Initialized
INFO - 2022-03-29 06:26:41 --> Output Class Initialized
INFO - 2022-03-29 06:26:41 --> Security Class Initialized
DEBUG - 2022-03-29 06:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:26:41 --> Input Class Initialized
INFO - 2022-03-29 06:26:41 --> Language Class Initialized
INFO - 2022-03-29 06:26:41 --> Loader Class Initialized
INFO - 2022-03-29 06:26:41 --> Helper loaded: url_helper
INFO - 2022-03-29 06:26:41 --> Helper loaded: form_helper
INFO - 2022-03-29 06:26:41 --> Helper loaded: common_helper
INFO - 2022-03-29 06:26:41 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:26:41 --> Controller Class Initialized
INFO - 2022-03-29 06:26:41 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:26:41 --> Encrypt Class Initialized
INFO - 2022-03-29 06:26:41 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:26:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:26:41 --> Model "Referredby_model" initialized
INFO - 2022-03-29 06:26:41 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:26:41 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:26:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 06:26:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 06:26:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 06:26:41 --> Final output sent to browser
DEBUG - 2022-03-29 06:26:41 --> Total execution time: 0.0382
ERROR - 2022-03-29 06:30:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:30:12 --> Config Class Initialized
INFO - 2022-03-29 06:30:12 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:30:12 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:30:12 --> Utf8 Class Initialized
INFO - 2022-03-29 06:30:12 --> URI Class Initialized
INFO - 2022-03-29 06:30:12 --> Router Class Initialized
INFO - 2022-03-29 06:30:12 --> Output Class Initialized
INFO - 2022-03-29 06:30:12 --> Security Class Initialized
DEBUG - 2022-03-29 06:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:30:12 --> Input Class Initialized
INFO - 2022-03-29 06:30:12 --> Language Class Initialized
INFO - 2022-03-29 06:30:12 --> Loader Class Initialized
INFO - 2022-03-29 06:30:13 --> Helper loaded: url_helper
INFO - 2022-03-29 06:30:13 --> Helper loaded: form_helper
INFO - 2022-03-29 06:30:13 --> Helper loaded: common_helper
INFO - 2022-03-29 06:30:13 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:30:13 --> Controller Class Initialized
INFO - 2022-03-29 06:30:13 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:30:13 --> Encrypt Class Initialized
INFO - 2022-03-29 06:30:13 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:30:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:30:13 --> Model "Referredby_model" initialized
INFO - 2022-03-29 06:30:13 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:30:13 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:30:13 --> Upload Class Initialized
INFO - 2022-03-29 06:30:13 --> Final output sent to browser
DEBUG - 2022-03-29 06:30:13 --> Total execution time: 0.0706
ERROR - 2022-03-29 06:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:30:22 --> Config Class Initialized
INFO - 2022-03-29 06:30:22 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:30:22 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:30:22 --> Utf8 Class Initialized
INFO - 2022-03-29 06:30:22 --> URI Class Initialized
INFO - 2022-03-29 06:30:22 --> Router Class Initialized
INFO - 2022-03-29 06:30:22 --> Output Class Initialized
INFO - 2022-03-29 06:30:22 --> Security Class Initialized
DEBUG - 2022-03-29 06:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:30:22 --> Input Class Initialized
INFO - 2022-03-29 06:30:22 --> Language Class Initialized
INFO - 2022-03-29 06:30:22 --> Loader Class Initialized
INFO - 2022-03-29 06:30:22 --> Helper loaded: url_helper
INFO - 2022-03-29 06:30:22 --> Helper loaded: form_helper
INFO - 2022-03-29 06:30:22 --> Helper loaded: common_helper
INFO - 2022-03-29 06:30:22 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:30:22 --> Controller Class Initialized
INFO - 2022-03-29 06:30:22 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:30:22 --> Encrypt Class Initialized
INFO - 2022-03-29 06:30:22 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:30:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:30:22 --> Model "Referredby_model" initialized
INFO - 2022-03-29 06:30:22 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:30:22 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 06:30:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:30:22 --> Config Class Initialized
INFO - 2022-03-29 06:30:22 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:30:22 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:30:22 --> Utf8 Class Initialized
INFO - 2022-03-29 06:30:22 --> URI Class Initialized
INFO - 2022-03-29 06:30:22 --> Router Class Initialized
INFO - 2022-03-29 06:30:22 --> Output Class Initialized
INFO - 2022-03-29 06:30:22 --> Security Class Initialized
DEBUG - 2022-03-29 06:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:30:22 --> Input Class Initialized
INFO - 2022-03-29 06:30:22 --> Language Class Initialized
INFO - 2022-03-29 06:30:22 --> Loader Class Initialized
INFO - 2022-03-29 06:30:22 --> Helper loaded: url_helper
INFO - 2022-03-29 06:30:22 --> Helper loaded: form_helper
INFO - 2022-03-29 06:30:22 --> Helper loaded: common_helper
INFO - 2022-03-29 06:30:22 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:30:22 --> Controller Class Initialized
INFO - 2022-03-29 06:30:22 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:30:22 --> Encrypt Class Initialized
INFO - 2022-03-29 06:30:22 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:30:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:30:22 --> Model "Referredby_model" initialized
INFO - 2022-03-29 06:30:22 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:30:22 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:30:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 06:30:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 06:30:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 06:30:22 --> Final output sent to browser
DEBUG - 2022-03-29 06:30:22 --> Total execution time: 0.0350
ERROR - 2022-03-29 06:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:30:23 --> Config Class Initialized
INFO - 2022-03-29 06:30:23 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:30:23 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:30:23 --> Utf8 Class Initialized
INFO - 2022-03-29 06:30:23 --> URI Class Initialized
INFO - 2022-03-29 06:30:23 --> Router Class Initialized
INFO - 2022-03-29 06:30:23 --> Output Class Initialized
INFO - 2022-03-29 06:30:23 --> Security Class Initialized
DEBUG - 2022-03-29 06:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:30:23 --> Input Class Initialized
INFO - 2022-03-29 06:30:23 --> Language Class Initialized
INFO - 2022-03-29 06:30:23 --> Loader Class Initialized
INFO - 2022-03-29 06:30:23 --> Helper loaded: url_helper
INFO - 2022-03-29 06:30:23 --> Helper loaded: form_helper
INFO - 2022-03-29 06:30:23 --> Helper loaded: common_helper
INFO - 2022-03-29 06:30:23 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:30:23 --> Controller Class Initialized
INFO - 2022-03-29 06:30:23 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:30:23 --> Encrypt Class Initialized
INFO - 2022-03-29 06:30:23 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:30:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:30:23 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:30:23 --> Model "Users_model" initialized
INFO - 2022-03-29 06:30:23 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:30:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 06:30:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 06:30:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 06:30:23 --> Final output sent to browser
DEBUG - 2022-03-29 06:30:23 --> Total execution time: 0.0578
ERROR - 2022-03-29 06:30:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:30:40 --> Config Class Initialized
INFO - 2022-03-29 06:30:40 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:30:40 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:30:40 --> Utf8 Class Initialized
INFO - 2022-03-29 06:30:40 --> URI Class Initialized
INFO - 2022-03-29 06:30:40 --> Router Class Initialized
INFO - 2022-03-29 06:30:40 --> Output Class Initialized
INFO - 2022-03-29 06:30:40 --> Security Class Initialized
DEBUG - 2022-03-29 06:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:30:40 --> Input Class Initialized
INFO - 2022-03-29 06:30:40 --> Language Class Initialized
INFO - 2022-03-29 06:30:40 --> Loader Class Initialized
INFO - 2022-03-29 06:30:40 --> Helper loaded: url_helper
INFO - 2022-03-29 06:30:40 --> Helper loaded: form_helper
INFO - 2022-03-29 06:30:40 --> Helper loaded: common_helper
INFO - 2022-03-29 06:30:40 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:30:40 --> Controller Class Initialized
INFO - 2022-03-29 06:30:40 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:30:40 --> Encrypt Class Initialized
INFO - 2022-03-29 06:30:40 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:30:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:30:40 --> Model "Referredby_model" initialized
INFO - 2022-03-29 06:30:40 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:30:40 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:30:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 06:30:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 06:30:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 06:30:49 --> Final output sent to browser
DEBUG - 2022-03-29 06:30:49 --> Total execution time: 7.2797
ERROR - 2022-03-29 06:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:30:55 --> Config Class Initialized
INFO - 2022-03-29 06:30:55 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:30:55 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:30:55 --> Utf8 Class Initialized
INFO - 2022-03-29 06:30:55 --> URI Class Initialized
INFO - 2022-03-29 06:30:55 --> Router Class Initialized
INFO - 2022-03-29 06:30:55 --> Output Class Initialized
INFO - 2022-03-29 06:30:55 --> Security Class Initialized
DEBUG - 2022-03-29 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:30:55 --> Input Class Initialized
INFO - 2022-03-29 06:30:55 --> Language Class Initialized
INFO - 2022-03-29 06:30:55 --> Loader Class Initialized
INFO - 2022-03-29 06:30:55 --> Helper loaded: url_helper
INFO - 2022-03-29 06:30:55 --> Helper loaded: form_helper
INFO - 2022-03-29 06:30:55 --> Helper loaded: common_helper
INFO - 2022-03-29 06:30:55 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:30:55 --> Controller Class Initialized
INFO - 2022-03-29 06:30:55 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:30:55 --> Encrypt Class Initialized
INFO - 2022-03-29 06:30:55 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:30:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:30:55 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:30:55 --> Model "Users_model" initialized
INFO - 2022-03-29 06:30:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 06:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:30:55 --> Config Class Initialized
INFO - 2022-03-29 06:30:55 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:30:55 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:30:55 --> Utf8 Class Initialized
INFO - 2022-03-29 06:30:55 --> URI Class Initialized
INFO - 2022-03-29 06:30:55 --> Router Class Initialized
INFO - 2022-03-29 06:30:55 --> Output Class Initialized
INFO - 2022-03-29 06:30:55 --> Security Class Initialized
DEBUG - 2022-03-29 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:30:55 --> Input Class Initialized
INFO - 2022-03-29 06:30:55 --> Language Class Initialized
INFO - 2022-03-29 06:30:55 --> Loader Class Initialized
INFO - 2022-03-29 06:30:55 --> Helper loaded: url_helper
INFO - 2022-03-29 06:30:55 --> Helper loaded: form_helper
INFO - 2022-03-29 06:30:55 --> Helper loaded: common_helper
INFO - 2022-03-29 06:30:55 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:30:55 --> Controller Class Initialized
INFO - 2022-03-29 06:30:55 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:30:55 --> Encrypt Class Initialized
INFO - 2022-03-29 06:30:55 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:30:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:30:55 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:30:55 --> Model "Users_model" initialized
INFO - 2022-03-29 06:30:55 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:30:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 06:30:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 06:30:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 06:30:55 --> Final output sent to browser
DEBUG - 2022-03-29 06:30:55 --> Total execution time: 0.0364
ERROR - 2022-03-29 06:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:31:16 --> Config Class Initialized
INFO - 2022-03-29 06:31:16 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:31:16 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:31:16 --> Utf8 Class Initialized
INFO - 2022-03-29 06:31:16 --> URI Class Initialized
INFO - 2022-03-29 06:31:16 --> Router Class Initialized
INFO - 2022-03-29 06:31:16 --> Output Class Initialized
INFO - 2022-03-29 06:31:16 --> Security Class Initialized
DEBUG - 2022-03-29 06:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:31:16 --> Input Class Initialized
INFO - 2022-03-29 06:31:16 --> Language Class Initialized
INFO - 2022-03-29 06:31:16 --> Loader Class Initialized
INFO - 2022-03-29 06:31:16 --> Helper loaded: url_helper
INFO - 2022-03-29 06:31:16 --> Helper loaded: form_helper
INFO - 2022-03-29 06:31:16 --> Helper loaded: common_helper
INFO - 2022-03-29 06:31:16 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:31:16 --> Controller Class Initialized
INFO - 2022-03-29 06:31:16 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:31:16 --> Encrypt Class Initialized
INFO - 2022-03-29 06:31:16 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:31:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:31:16 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:31:16 --> Model "Users_model" initialized
INFO - 2022-03-29 06:31:16 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:31:16 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 06:31:17 --> Final output sent to browser
DEBUG - 2022-03-29 06:31:17 --> Total execution time: 0.9663
ERROR - 2022-03-29 06:32:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:32:40 --> Config Class Initialized
INFO - 2022-03-29 06:32:40 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:32:40 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:32:40 --> Utf8 Class Initialized
INFO - 2022-03-29 06:32:40 --> URI Class Initialized
INFO - 2022-03-29 06:32:40 --> Router Class Initialized
INFO - 2022-03-29 06:32:40 --> Output Class Initialized
INFO - 2022-03-29 06:32:40 --> Security Class Initialized
DEBUG - 2022-03-29 06:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:32:40 --> Input Class Initialized
INFO - 2022-03-29 06:32:40 --> Language Class Initialized
INFO - 2022-03-29 06:32:40 --> Loader Class Initialized
INFO - 2022-03-29 06:32:40 --> Helper loaded: url_helper
INFO - 2022-03-29 06:32:40 --> Helper loaded: form_helper
INFO - 2022-03-29 06:32:40 --> Helper loaded: common_helper
INFO - 2022-03-29 06:32:40 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:32:40 --> Controller Class Initialized
INFO - 2022-03-29 06:32:40 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:32:40 --> Encrypt Class Initialized
INFO - 2022-03-29 06:32:40 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:32:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:32:40 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:32:40 --> Model "Users_model" initialized
INFO - 2022-03-29 06:32:40 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:32:40 --> Upload Class Initialized
INFO - 2022-03-29 06:32:40 --> Final output sent to browser
DEBUG - 2022-03-29 06:32:40 --> Total execution time: 0.0330
ERROR - 2022-03-29 06:33:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:33:56 --> Config Class Initialized
INFO - 2022-03-29 06:33:56 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:33:56 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:33:56 --> Utf8 Class Initialized
INFO - 2022-03-29 06:33:56 --> URI Class Initialized
INFO - 2022-03-29 06:33:56 --> Router Class Initialized
INFO - 2022-03-29 06:33:56 --> Output Class Initialized
INFO - 2022-03-29 06:33:56 --> Security Class Initialized
DEBUG - 2022-03-29 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:33:56 --> Input Class Initialized
INFO - 2022-03-29 06:33:56 --> Language Class Initialized
INFO - 2022-03-29 06:33:56 --> Loader Class Initialized
INFO - 2022-03-29 06:33:56 --> Helper loaded: url_helper
INFO - 2022-03-29 06:33:56 --> Helper loaded: form_helper
INFO - 2022-03-29 06:33:56 --> Helper loaded: common_helper
INFO - 2022-03-29 06:33:56 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:33:56 --> Controller Class Initialized
INFO - 2022-03-29 06:33:56 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:33:56 --> Encrypt Class Initialized
INFO - 2022-03-29 06:33:56 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:33:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:33:56 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:33:56 --> Model "Users_model" initialized
INFO - 2022-03-29 06:33:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 06:33:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:33:56 --> Config Class Initialized
INFO - 2022-03-29 06:33:56 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:33:56 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:33:56 --> Utf8 Class Initialized
INFO - 2022-03-29 06:33:56 --> URI Class Initialized
INFO - 2022-03-29 06:33:56 --> Router Class Initialized
INFO - 2022-03-29 06:33:56 --> Output Class Initialized
INFO - 2022-03-29 06:33:56 --> Security Class Initialized
DEBUG - 2022-03-29 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:33:56 --> Input Class Initialized
INFO - 2022-03-29 06:33:56 --> Language Class Initialized
INFO - 2022-03-29 06:33:56 --> Loader Class Initialized
INFO - 2022-03-29 06:33:56 --> Helper loaded: url_helper
INFO - 2022-03-29 06:33:56 --> Helper loaded: form_helper
INFO - 2022-03-29 06:33:56 --> Helper loaded: common_helper
INFO - 2022-03-29 06:33:56 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:33:56 --> Controller Class Initialized
INFO - 2022-03-29 06:33:56 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:33:56 --> Encrypt Class Initialized
INFO - 2022-03-29 06:33:56 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:33:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:33:56 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:33:56 --> Model "Users_model" initialized
INFO - 2022-03-29 06:33:56 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:33:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 06:33:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 06:33:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 06:33:56 --> Final output sent to browser
DEBUG - 2022-03-29 06:33:56 --> Total execution time: 0.0399
ERROR - 2022-03-29 06:45:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:45:02 --> Config Class Initialized
INFO - 2022-03-29 06:45:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:45:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:45:02 --> Utf8 Class Initialized
INFO - 2022-03-29 06:45:02 --> URI Class Initialized
DEBUG - 2022-03-29 06:45:02 --> No URI present. Default controller set.
INFO - 2022-03-29 06:45:02 --> Router Class Initialized
INFO - 2022-03-29 06:45:02 --> Output Class Initialized
INFO - 2022-03-29 06:45:02 --> Security Class Initialized
DEBUG - 2022-03-29 06:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:45:02 --> Input Class Initialized
INFO - 2022-03-29 06:45:02 --> Language Class Initialized
INFO - 2022-03-29 06:45:02 --> Loader Class Initialized
INFO - 2022-03-29 06:45:02 --> Helper loaded: url_helper
INFO - 2022-03-29 06:45:02 --> Helper loaded: form_helper
INFO - 2022-03-29 06:45:02 --> Helper loaded: common_helper
INFO - 2022-03-29 06:45:02 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:45:02 --> Controller Class Initialized
INFO - 2022-03-29 06:45:02 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:45:02 --> Encrypt Class Initialized
DEBUG - 2022-03-29 06:45:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 06:45:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 06:45:02 --> Email Class Initialized
INFO - 2022-03-29 06:45:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 06:45:02 --> Calendar Class Initialized
INFO - 2022-03-29 06:45:02 --> Model "Login_model" initialized
INFO - 2022-03-29 06:45:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 06:45:02 --> Final output sent to browser
DEBUG - 2022-03-29 06:45:02 --> Total execution time: 0.0992
ERROR - 2022-03-29 06:53:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:53:19 --> Config Class Initialized
INFO - 2022-03-29 06:53:19 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:53:19 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:53:19 --> Utf8 Class Initialized
INFO - 2022-03-29 06:53:19 --> URI Class Initialized
INFO - 2022-03-29 06:53:19 --> Router Class Initialized
INFO - 2022-03-29 06:53:19 --> Output Class Initialized
INFO - 2022-03-29 06:53:19 --> Security Class Initialized
DEBUG - 2022-03-29 06:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:53:19 --> Input Class Initialized
INFO - 2022-03-29 06:53:19 --> Language Class Initialized
INFO - 2022-03-29 06:53:19 --> Loader Class Initialized
INFO - 2022-03-29 06:53:19 --> Helper loaded: url_helper
INFO - 2022-03-29 06:53:19 --> Helper loaded: form_helper
INFO - 2022-03-29 06:53:19 --> Helper loaded: common_helper
INFO - 2022-03-29 06:53:19 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:53:19 --> Controller Class Initialized
INFO - 2022-03-29 06:53:19 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:53:19 --> Encrypt Class Initialized
INFO - 2022-03-29 06:53:19 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:53:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:53:19 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:53:19 --> Model "Users_model" initialized
INFO - 2022-03-29 06:53:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 06:53:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 06:53:19 --> Config Class Initialized
INFO - 2022-03-29 06:53:19 --> Hooks Class Initialized
DEBUG - 2022-03-29 06:53:19 --> UTF-8 Support Enabled
INFO - 2022-03-29 06:53:19 --> Utf8 Class Initialized
INFO - 2022-03-29 06:53:19 --> URI Class Initialized
INFO - 2022-03-29 06:53:19 --> Router Class Initialized
INFO - 2022-03-29 06:53:19 --> Output Class Initialized
INFO - 2022-03-29 06:53:19 --> Security Class Initialized
DEBUG - 2022-03-29 06:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 06:53:19 --> Input Class Initialized
INFO - 2022-03-29 06:53:19 --> Language Class Initialized
INFO - 2022-03-29 06:53:19 --> Loader Class Initialized
INFO - 2022-03-29 06:53:19 --> Helper loaded: url_helper
INFO - 2022-03-29 06:53:19 --> Helper loaded: form_helper
INFO - 2022-03-29 06:53:19 --> Helper loaded: common_helper
INFO - 2022-03-29 06:53:19 --> Database Driver Class Initialized
DEBUG - 2022-03-29 06:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 06:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 06:53:19 --> Controller Class Initialized
INFO - 2022-03-29 06:53:19 --> Form Validation Class Initialized
DEBUG - 2022-03-29 06:53:19 --> Encrypt Class Initialized
INFO - 2022-03-29 06:53:19 --> Model "Patient_model" initialized
INFO - 2022-03-29 06:53:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 06:53:19 --> Model "Prefix_master" initialized
INFO - 2022-03-29 06:53:19 --> Model "Users_model" initialized
INFO - 2022-03-29 06:53:19 --> Model "Hospital_model" initialized
INFO - 2022-03-29 06:53:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 06:53:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 06:53:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 06:53:20 --> Final output sent to browser
DEBUG - 2022-03-29 06:53:20 --> Total execution time: 0.0470
ERROR - 2022-03-29 07:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:09:45 --> Config Class Initialized
INFO - 2022-03-29 07:09:45 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:09:45 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:09:45 --> Utf8 Class Initialized
INFO - 2022-03-29 07:09:45 --> URI Class Initialized
DEBUG - 2022-03-29 07:09:45 --> No URI present. Default controller set.
INFO - 2022-03-29 07:09:45 --> Router Class Initialized
INFO - 2022-03-29 07:09:46 --> Output Class Initialized
INFO - 2022-03-29 07:09:46 --> Security Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:09:46 --> Input Class Initialized
INFO - 2022-03-29 07:09:46 --> Language Class Initialized
INFO - 2022-03-29 07:09:46 --> Loader Class Initialized
INFO - 2022-03-29 07:09:46 --> Helper loaded: url_helper
INFO - 2022-03-29 07:09:46 --> Helper loaded: form_helper
INFO - 2022-03-29 07:09:46 --> Helper loaded: common_helper
INFO - 2022-03-29 07:09:46 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:09:46 --> Controller Class Initialized
INFO - 2022-03-29 07:09:46 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Encrypt Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 07:09:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 07:09:46 --> Email Class Initialized
INFO - 2022-03-29 07:09:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 07:09:46 --> Calendar Class Initialized
INFO - 2022-03-29 07:09:46 --> Model "Login_model" initialized
ERROR - 2022-03-29 07:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:09:46 --> Config Class Initialized
INFO - 2022-03-29 07:09:46 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:09:46 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:09:46 --> Utf8 Class Initialized
INFO - 2022-03-29 07:09:46 --> URI Class Initialized
INFO - 2022-03-29 07:09:46 --> Router Class Initialized
INFO - 2022-03-29 07:09:46 --> Output Class Initialized
INFO - 2022-03-29 07:09:46 --> Security Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:09:46 --> Input Class Initialized
INFO - 2022-03-29 07:09:46 --> Language Class Initialized
INFO - 2022-03-29 07:09:46 --> Loader Class Initialized
INFO - 2022-03-29 07:09:46 --> Helper loaded: url_helper
INFO - 2022-03-29 07:09:46 --> Helper loaded: form_helper
INFO - 2022-03-29 07:09:46 --> Helper loaded: common_helper
INFO - 2022-03-29 07:09:46 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:09:46 --> Controller Class Initialized
INFO - 2022-03-29 07:09:46 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Encrypt Class Initialized
INFO - 2022-03-29 07:09:46 --> Model "Diseases_model" initialized
INFO - 2022-03-29 07:09:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 07:09:46 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-29 07:09:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 07:09:46 --> Final output sent to browser
DEBUG - 2022-03-29 07:09:46 --> Total execution time: 0.0146
ERROR - 2022-03-29 07:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:09:46 --> Config Class Initialized
INFO - 2022-03-29 07:09:46 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:09:46 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:09:46 --> Utf8 Class Initialized
INFO - 2022-03-29 07:09:46 --> URI Class Initialized
DEBUG - 2022-03-29 07:09:46 --> No URI present. Default controller set.
INFO - 2022-03-29 07:09:46 --> Router Class Initialized
INFO - 2022-03-29 07:09:46 --> Output Class Initialized
INFO - 2022-03-29 07:09:46 --> Security Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:09:46 --> Input Class Initialized
INFO - 2022-03-29 07:09:46 --> Language Class Initialized
INFO - 2022-03-29 07:09:46 --> Loader Class Initialized
INFO - 2022-03-29 07:09:46 --> Helper loaded: url_helper
INFO - 2022-03-29 07:09:46 --> Helper loaded: form_helper
INFO - 2022-03-29 07:09:46 --> Helper loaded: common_helper
INFO - 2022-03-29 07:09:46 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:09:46 --> Controller Class Initialized
INFO - 2022-03-29 07:09:46 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Encrypt Class Initialized
DEBUG - 2022-03-29 07:09:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 07:09:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 07:09:46 --> Email Class Initialized
INFO - 2022-03-29 07:09:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 07:09:46 --> Calendar Class Initialized
INFO - 2022-03-29 07:09:46 --> Model "Login_model" initialized
ERROR - 2022-03-29 07:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:09:47 --> Config Class Initialized
INFO - 2022-03-29 07:09:47 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:09:47 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:09:47 --> Utf8 Class Initialized
INFO - 2022-03-29 07:09:47 --> URI Class Initialized
INFO - 2022-03-29 07:09:47 --> Router Class Initialized
INFO - 2022-03-29 07:09:47 --> Output Class Initialized
INFO - 2022-03-29 07:09:47 --> Security Class Initialized
DEBUG - 2022-03-29 07:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:09:47 --> Input Class Initialized
INFO - 2022-03-29 07:09:47 --> Language Class Initialized
INFO - 2022-03-29 07:09:47 --> Loader Class Initialized
INFO - 2022-03-29 07:09:47 --> Helper loaded: url_helper
INFO - 2022-03-29 07:09:47 --> Helper loaded: form_helper
INFO - 2022-03-29 07:09:47 --> Helper loaded: common_helper
INFO - 2022-03-29 07:09:47 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:09:47 --> Controller Class Initialized
INFO - 2022-03-29 07:09:47 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:09:47 --> Encrypt Class Initialized
INFO - 2022-03-29 07:09:47 --> Model "Diseases_model" initialized
INFO - 2022-03-29 07:09:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 07:09:47 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-29 07:09:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 07:09:47 --> Final output sent to browser
DEBUG - 2022-03-29 07:09:47 --> Total execution time: 0.0072
ERROR - 2022-03-29 07:09:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:09:57 --> Config Class Initialized
INFO - 2022-03-29 07:09:57 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:09:57 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:09:57 --> Utf8 Class Initialized
INFO - 2022-03-29 07:09:57 --> URI Class Initialized
INFO - 2022-03-29 07:09:57 --> Router Class Initialized
INFO - 2022-03-29 07:09:57 --> Output Class Initialized
INFO - 2022-03-29 07:09:57 --> Security Class Initialized
DEBUG - 2022-03-29 07:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:09:57 --> Input Class Initialized
INFO - 2022-03-29 07:09:57 --> Language Class Initialized
INFO - 2022-03-29 07:09:57 --> Loader Class Initialized
INFO - 2022-03-29 07:09:57 --> Helper loaded: url_helper
INFO - 2022-03-29 07:09:57 --> Helper loaded: form_helper
INFO - 2022-03-29 07:09:57 --> Helper loaded: common_helper
INFO - 2022-03-29 07:09:57 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:09:57 --> Controller Class Initialized
INFO - 2022-03-29 07:09:57 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:09:57 --> Encrypt Class Initialized
INFO - 2022-03-29 07:09:57 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:09:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:09:57 --> Model "Referredby_model" initialized
INFO - 2022-03-29 07:09:57 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:09:57 --> Model "Hospital_model" initialized
INFO - 2022-03-29 07:09:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 07:09:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 07:09:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 07:09:57 --> Final output sent to browser
DEBUG - 2022-03-29 07:09:57 --> Total execution time: 0.0867
ERROR - 2022-03-29 07:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:10:22 --> Config Class Initialized
INFO - 2022-03-29 07:10:22 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:10:22 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:10:22 --> Utf8 Class Initialized
INFO - 2022-03-29 07:10:22 --> URI Class Initialized
INFO - 2022-03-29 07:10:22 --> Router Class Initialized
INFO - 2022-03-29 07:10:22 --> Output Class Initialized
INFO - 2022-03-29 07:10:22 --> Security Class Initialized
DEBUG - 2022-03-29 07:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:10:22 --> Input Class Initialized
INFO - 2022-03-29 07:10:22 --> Language Class Initialized
INFO - 2022-03-29 07:10:22 --> Loader Class Initialized
INFO - 2022-03-29 07:10:22 --> Helper loaded: url_helper
INFO - 2022-03-29 07:10:22 --> Helper loaded: form_helper
INFO - 2022-03-29 07:10:22 --> Helper loaded: common_helper
INFO - 2022-03-29 07:10:22 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:10:22 --> Controller Class Initialized
INFO - 2022-03-29 07:10:22 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:10:22 --> Encrypt Class Initialized
INFO - 2022-03-29 07:10:22 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:10:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:10:22 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:10:22 --> Model "Users_model" initialized
INFO - 2022-03-29 07:10:22 --> Model "Hospital_model" initialized
INFO - 2022-03-29 07:10:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 07:10:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 07:10:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 07:10:22 --> Final output sent to browser
DEBUG - 2022-03-29 07:10:22 --> Total execution time: 0.0538
ERROR - 2022-03-29 07:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:11:46 --> Config Class Initialized
INFO - 2022-03-29 07:11:46 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:11:46 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:11:46 --> Utf8 Class Initialized
INFO - 2022-03-29 07:11:46 --> URI Class Initialized
INFO - 2022-03-29 07:11:46 --> Router Class Initialized
INFO - 2022-03-29 07:11:46 --> Output Class Initialized
INFO - 2022-03-29 07:11:46 --> Security Class Initialized
DEBUG - 2022-03-29 07:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:11:46 --> Input Class Initialized
INFO - 2022-03-29 07:11:46 --> Language Class Initialized
INFO - 2022-03-29 07:11:46 --> Loader Class Initialized
INFO - 2022-03-29 07:11:46 --> Helper loaded: url_helper
INFO - 2022-03-29 07:11:46 --> Helper loaded: form_helper
INFO - 2022-03-29 07:11:46 --> Helper loaded: common_helper
INFO - 2022-03-29 07:11:46 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:11:46 --> Controller Class Initialized
INFO - 2022-03-29 07:11:46 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:11:46 --> Encrypt Class Initialized
INFO - 2022-03-29 07:11:46 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:11:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:11:46 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:11:46 --> Model "Users_model" initialized
INFO - 2022-03-29 07:11:46 --> Model "Hospital_model" initialized
INFO - 2022-03-29 07:11:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 07:11:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 07:11:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 07:11:46 --> Final output sent to browser
DEBUG - 2022-03-29 07:11:46 --> Total execution time: 0.0383
ERROR - 2022-03-29 07:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:11:52 --> Config Class Initialized
INFO - 2022-03-29 07:11:52 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:11:52 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:11:52 --> Utf8 Class Initialized
INFO - 2022-03-29 07:11:52 --> URI Class Initialized
INFO - 2022-03-29 07:11:52 --> Router Class Initialized
INFO - 2022-03-29 07:11:52 --> Output Class Initialized
INFO - 2022-03-29 07:11:52 --> Security Class Initialized
DEBUG - 2022-03-29 07:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:11:52 --> Input Class Initialized
INFO - 2022-03-29 07:11:52 --> Language Class Initialized
INFO - 2022-03-29 07:11:52 --> Loader Class Initialized
INFO - 2022-03-29 07:11:52 --> Helper loaded: url_helper
INFO - 2022-03-29 07:11:52 --> Helper loaded: form_helper
INFO - 2022-03-29 07:11:52 --> Helper loaded: common_helper
INFO - 2022-03-29 07:11:52 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:11:52 --> Controller Class Initialized
INFO - 2022-03-29 07:11:52 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:11:52 --> Encrypt Class Initialized
INFO - 2022-03-29 07:11:52 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:11:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:11:52 --> Model "Referredby_model" initialized
INFO - 2022-03-29 07:11:52 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:11:52 --> Model "Hospital_model" initialized
INFO - 2022-03-29 07:11:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 07:11:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 07:11:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 07:11:52 --> Final output sent to browser
DEBUG - 2022-03-29 07:11:52 --> Total execution time: 0.1021
ERROR - 2022-03-29 07:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:12:02 --> Config Class Initialized
INFO - 2022-03-29 07:12:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:12:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:12:02 --> Utf8 Class Initialized
INFO - 2022-03-29 07:12:02 --> URI Class Initialized
INFO - 2022-03-29 07:12:02 --> Router Class Initialized
INFO - 2022-03-29 07:12:02 --> Output Class Initialized
INFO - 2022-03-29 07:12:02 --> Security Class Initialized
DEBUG - 2022-03-29 07:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:12:02 --> Input Class Initialized
INFO - 2022-03-29 07:12:02 --> Language Class Initialized
INFO - 2022-03-29 07:12:02 --> Loader Class Initialized
INFO - 2022-03-29 07:12:02 --> Helper loaded: url_helper
INFO - 2022-03-29 07:12:02 --> Helper loaded: form_helper
INFO - 2022-03-29 07:12:02 --> Helper loaded: common_helper
INFO - 2022-03-29 07:12:02 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:12:02 --> Controller Class Initialized
INFO - 2022-03-29 07:12:02 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:12:02 --> Encrypt Class Initialized
INFO - 2022-03-29 07:12:02 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:12:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:12:02 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:12:02 --> Model "Users_model" initialized
INFO - 2022-03-29 07:12:02 --> Model "Hospital_model" initialized
INFO - 2022-03-29 07:12:02 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-29 07:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:12:02 --> Config Class Initialized
INFO - 2022-03-29 07:12:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:12:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:12:02 --> Utf8 Class Initialized
INFO - 2022-03-29 07:12:02 --> URI Class Initialized
INFO - 2022-03-29 07:12:02 --> Router Class Initialized
INFO - 2022-03-29 07:12:02 --> Output Class Initialized
INFO - 2022-03-29 07:12:02 --> Security Class Initialized
DEBUG - 2022-03-29 07:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:12:02 --> Input Class Initialized
INFO - 2022-03-29 07:12:02 --> Language Class Initialized
ERROR - 2022-03-29 07:12:02 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-29 07:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:12:02 --> Config Class Initialized
INFO - 2022-03-29 07:12:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:12:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:12:02 --> Utf8 Class Initialized
INFO - 2022-03-29 07:12:02 --> URI Class Initialized
INFO - 2022-03-29 07:12:02 --> Router Class Initialized
INFO - 2022-03-29 07:12:02 --> Output Class Initialized
INFO - 2022-03-29 07:12:02 --> Security Class Initialized
DEBUG - 2022-03-29 07:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:12:02 --> Input Class Initialized
INFO - 2022-03-29 07:12:02 --> Language Class Initialized
ERROR - 2022-03-29 07:12:02 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-29 07:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:12:02 --> Config Class Initialized
INFO - 2022-03-29 07:12:02 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:12:02 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:12:02 --> Utf8 Class Initialized
INFO - 2022-03-29 07:12:02 --> URI Class Initialized
INFO - 2022-03-29 07:12:02 --> Router Class Initialized
INFO - 2022-03-29 07:12:02 --> Output Class Initialized
INFO - 2022-03-29 07:12:02 --> Security Class Initialized
DEBUG - 2022-03-29 07:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:12:02 --> Input Class Initialized
INFO - 2022-03-29 07:12:02 --> Language Class Initialized
ERROR - 2022-03-29 07:12:02 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-29 07:12:03 --> Final output sent to browser
DEBUG - 2022-03-29 07:12:03 --> Total execution time: 1.2040
ERROR - 2022-03-29 07:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:18:28 --> Config Class Initialized
INFO - 2022-03-29 07:18:28 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:18:28 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:18:28 --> Utf8 Class Initialized
INFO - 2022-03-29 07:18:28 --> URI Class Initialized
INFO - 2022-03-29 07:18:28 --> Router Class Initialized
INFO - 2022-03-29 07:18:28 --> Output Class Initialized
INFO - 2022-03-29 07:18:28 --> Security Class Initialized
DEBUG - 2022-03-29 07:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:18:28 --> Input Class Initialized
INFO - 2022-03-29 07:18:28 --> Language Class Initialized
INFO - 2022-03-29 07:18:28 --> Loader Class Initialized
INFO - 2022-03-29 07:18:28 --> Helper loaded: url_helper
INFO - 2022-03-29 07:18:28 --> Helper loaded: form_helper
INFO - 2022-03-29 07:18:28 --> Helper loaded: common_helper
INFO - 2022-03-29 07:18:28 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:18:28 --> Controller Class Initialized
INFO - 2022-03-29 07:18:28 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:18:28 --> Encrypt Class Initialized
INFO - 2022-03-29 07:18:28 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:18:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:18:28 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:18:28 --> Model "Users_model" initialized
INFO - 2022-03-29 07:18:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 07:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:18:28 --> Config Class Initialized
INFO - 2022-03-29 07:18:28 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:18:28 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:18:28 --> Utf8 Class Initialized
INFO - 2022-03-29 07:18:28 --> URI Class Initialized
INFO - 2022-03-29 07:18:28 --> Router Class Initialized
INFO - 2022-03-29 07:18:28 --> Output Class Initialized
INFO - 2022-03-29 07:18:28 --> Security Class Initialized
DEBUG - 2022-03-29 07:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:18:28 --> Input Class Initialized
INFO - 2022-03-29 07:18:28 --> Language Class Initialized
INFO - 2022-03-29 07:18:28 --> Loader Class Initialized
INFO - 2022-03-29 07:18:28 --> Helper loaded: url_helper
INFO - 2022-03-29 07:18:28 --> Helper loaded: form_helper
INFO - 2022-03-29 07:18:28 --> Helper loaded: common_helper
INFO - 2022-03-29 07:18:28 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:18:28 --> Controller Class Initialized
INFO - 2022-03-29 07:18:28 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:18:28 --> Encrypt Class Initialized
INFO - 2022-03-29 07:18:28 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:18:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:18:28 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:18:28 --> Model "Users_model" initialized
INFO - 2022-03-29 07:18:28 --> Model "Hospital_model" initialized
INFO - 2022-03-29 07:18:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 07:18:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 07:18:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 07:18:28 --> Final output sent to browser
DEBUG - 2022-03-29 07:18:28 --> Total execution time: 0.0429
ERROR - 2022-03-29 07:18:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:18:39 --> Config Class Initialized
INFO - 2022-03-29 07:18:39 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:18:39 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:18:39 --> Utf8 Class Initialized
INFO - 2022-03-29 07:18:39 --> URI Class Initialized
INFO - 2022-03-29 07:18:39 --> Router Class Initialized
INFO - 2022-03-29 07:18:39 --> Output Class Initialized
INFO - 2022-03-29 07:18:39 --> Security Class Initialized
DEBUG - 2022-03-29 07:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:18:39 --> Input Class Initialized
INFO - 2022-03-29 07:18:39 --> Language Class Initialized
INFO - 2022-03-29 07:18:39 --> Loader Class Initialized
INFO - 2022-03-29 07:18:39 --> Helper loaded: url_helper
INFO - 2022-03-29 07:18:39 --> Helper loaded: form_helper
INFO - 2022-03-29 07:18:39 --> Helper loaded: common_helper
INFO - 2022-03-29 07:18:39 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:18:39 --> Controller Class Initialized
INFO - 2022-03-29 07:18:39 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:18:39 --> Encrypt Class Initialized
INFO - 2022-03-29 07:18:39 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:18:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:18:39 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:18:39 --> Model "Users_model" initialized
INFO - 2022-03-29 07:18:39 --> Model "Hospital_model" initialized
INFO - 2022-03-29 07:18:40 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 07:18:40 --> Final output sent to browser
DEBUG - 2022-03-29 07:18:40 --> Total execution time: 0.9597
ERROR - 2022-03-29 07:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:21:13 --> Config Class Initialized
INFO - 2022-03-29 07:21:13 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:21:13 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:21:13 --> Utf8 Class Initialized
INFO - 2022-03-29 07:21:13 --> URI Class Initialized
INFO - 2022-03-29 07:21:13 --> Router Class Initialized
INFO - 2022-03-29 07:21:13 --> Output Class Initialized
INFO - 2022-03-29 07:21:13 --> Security Class Initialized
DEBUG - 2022-03-29 07:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:21:13 --> Input Class Initialized
INFO - 2022-03-29 07:21:13 --> Language Class Initialized
INFO - 2022-03-29 07:21:13 --> Loader Class Initialized
INFO - 2022-03-29 07:21:13 --> Helper loaded: url_helper
INFO - 2022-03-29 07:21:13 --> Helper loaded: form_helper
INFO - 2022-03-29 07:21:13 --> Helper loaded: common_helper
INFO - 2022-03-29 07:21:13 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:21:13 --> Controller Class Initialized
INFO - 2022-03-29 07:21:13 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:21:13 --> Encrypt Class Initialized
INFO - 2022-03-29 07:21:13 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:21:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:21:13 --> Model "Referredby_model" initialized
INFO - 2022-03-29 07:21:13 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:21:13 --> Model "Hospital_model" initialized
INFO - 2022-03-29 07:21:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 07:21:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-29 07:21:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 07:21:14 --> Final output sent to browser
DEBUG - 2022-03-29 07:21:14 --> Total execution time: 0.0826
ERROR - 2022-03-29 07:22:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:22:41 --> Config Class Initialized
INFO - 2022-03-29 07:22:41 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:22:41 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:22:41 --> Utf8 Class Initialized
INFO - 2022-03-29 07:22:41 --> URI Class Initialized
INFO - 2022-03-29 07:22:41 --> Router Class Initialized
INFO - 2022-03-29 07:22:41 --> Output Class Initialized
INFO - 2022-03-29 07:22:41 --> Security Class Initialized
DEBUG - 2022-03-29 07:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:22:41 --> Input Class Initialized
INFO - 2022-03-29 07:22:41 --> Language Class Initialized
INFO - 2022-03-29 07:22:41 --> Loader Class Initialized
INFO - 2022-03-29 07:22:41 --> Helper loaded: url_helper
INFO - 2022-03-29 07:22:41 --> Helper loaded: form_helper
INFO - 2022-03-29 07:22:41 --> Helper loaded: common_helper
INFO - 2022-03-29 07:22:41 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:22:41 --> Controller Class Initialized
INFO - 2022-03-29 07:22:41 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:22:41 --> Encrypt Class Initialized
INFO - 2022-03-29 07:22:41 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:22:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:22:41 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:22:41 --> Model "Users_model" initialized
INFO - 2022-03-29 07:22:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 07:22:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:22:41 --> Config Class Initialized
INFO - 2022-03-29 07:22:41 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:22:41 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:22:41 --> Utf8 Class Initialized
INFO - 2022-03-29 07:22:41 --> URI Class Initialized
INFO - 2022-03-29 07:22:41 --> Router Class Initialized
INFO - 2022-03-29 07:22:41 --> Output Class Initialized
INFO - 2022-03-29 07:22:41 --> Security Class Initialized
DEBUG - 2022-03-29 07:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:22:41 --> Input Class Initialized
INFO - 2022-03-29 07:22:41 --> Language Class Initialized
INFO - 2022-03-29 07:22:41 --> Loader Class Initialized
INFO - 2022-03-29 07:22:41 --> Helper loaded: url_helper
INFO - 2022-03-29 07:22:41 --> Helper loaded: form_helper
INFO - 2022-03-29 07:22:41 --> Helper loaded: common_helper
INFO - 2022-03-29 07:22:41 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:22:41 --> Controller Class Initialized
INFO - 2022-03-29 07:22:41 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:22:41 --> Encrypt Class Initialized
INFO - 2022-03-29 07:22:41 --> Model "Patient_model" initialized
INFO - 2022-03-29 07:22:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 07:22:41 --> Model "Prefix_master" initialized
INFO - 2022-03-29 07:22:41 --> Model "Users_model" initialized
INFO - 2022-03-29 07:22:41 --> Model "Hospital_model" initialized
INFO - 2022-03-29 07:22:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 07:22:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 07:22:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 07:22:41 --> Final output sent to browser
DEBUG - 2022-03-29 07:22:41 --> Total execution time: 0.0589
ERROR - 2022-03-29 07:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:28:38 --> Config Class Initialized
INFO - 2022-03-29 07:28:38 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:28:38 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:28:38 --> Utf8 Class Initialized
INFO - 2022-03-29 07:28:38 --> URI Class Initialized
INFO - 2022-03-29 07:28:38 --> Router Class Initialized
INFO - 2022-03-29 07:28:38 --> Output Class Initialized
INFO - 2022-03-29 07:28:38 --> Security Class Initialized
DEBUG - 2022-03-29 07:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:28:38 --> Input Class Initialized
INFO - 2022-03-29 07:28:38 --> Language Class Initialized
INFO - 2022-03-29 07:28:38 --> Loader Class Initialized
INFO - 2022-03-29 07:28:38 --> Helper loaded: url_helper
INFO - 2022-03-29 07:28:38 --> Helper loaded: form_helper
INFO - 2022-03-29 07:28:38 --> Helper loaded: common_helper
INFO - 2022-03-29 07:28:38 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:28:38 --> Controller Class Initialized
INFO - 2022-03-29 07:28:38 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:28:38 --> Encrypt Class Initialized
DEBUG - 2022-03-29 07:28:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 07:28:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 07:28:38 --> Email Class Initialized
INFO - 2022-03-29 07:28:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 07:28:38 --> Calendar Class Initialized
INFO - 2022-03-29 07:28:38 --> Model "Login_model" initialized
ERROR - 2022-03-29 07:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 07:28:39 --> Config Class Initialized
INFO - 2022-03-29 07:28:39 --> Hooks Class Initialized
DEBUG - 2022-03-29 07:28:39 --> UTF-8 Support Enabled
INFO - 2022-03-29 07:28:39 --> Utf8 Class Initialized
INFO - 2022-03-29 07:28:39 --> URI Class Initialized
INFO - 2022-03-29 07:28:39 --> Router Class Initialized
INFO - 2022-03-29 07:28:39 --> Output Class Initialized
INFO - 2022-03-29 07:28:39 --> Security Class Initialized
DEBUG - 2022-03-29 07:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 07:28:39 --> Input Class Initialized
INFO - 2022-03-29 07:28:39 --> Language Class Initialized
INFO - 2022-03-29 07:28:39 --> Loader Class Initialized
INFO - 2022-03-29 07:28:39 --> Helper loaded: url_helper
INFO - 2022-03-29 07:28:39 --> Helper loaded: form_helper
INFO - 2022-03-29 07:28:39 --> Helper loaded: common_helper
INFO - 2022-03-29 07:28:39 --> Database Driver Class Initialized
DEBUG - 2022-03-29 07:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 07:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 07:28:39 --> Controller Class Initialized
INFO - 2022-03-29 07:28:39 --> Form Validation Class Initialized
DEBUG - 2022-03-29 07:28:39 --> Encrypt Class Initialized
DEBUG - 2022-03-29 07:28:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 07:28:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 07:28:39 --> Email Class Initialized
INFO - 2022-03-29 07:28:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 07:28:39 --> Calendar Class Initialized
INFO - 2022-03-29 07:28:39 --> Model "Login_model" initialized
INFO - 2022-03-29 07:28:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 07:28:39 --> Final output sent to browser
DEBUG - 2022-03-29 07:28:39 --> Total execution time: 0.0067
ERROR - 2022-03-29 14:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:17:46 --> Config Class Initialized
INFO - 2022-03-29 14:17:46 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:17:46 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:17:46 --> Utf8 Class Initialized
INFO - 2022-03-29 14:17:46 --> URI Class Initialized
DEBUG - 2022-03-29 14:17:46 --> No URI present. Default controller set.
INFO - 2022-03-29 14:17:46 --> Router Class Initialized
INFO - 2022-03-29 14:17:46 --> Output Class Initialized
INFO - 2022-03-29 14:17:46 --> Security Class Initialized
DEBUG - 2022-03-29 14:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:17:46 --> Input Class Initialized
INFO - 2022-03-29 14:17:46 --> Language Class Initialized
INFO - 2022-03-29 14:17:46 --> Loader Class Initialized
INFO - 2022-03-29 14:17:46 --> Helper loaded: url_helper
INFO - 2022-03-29 14:17:46 --> Helper loaded: form_helper
INFO - 2022-03-29 14:17:46 --> Helper loaded: common_helper
INFO - 2022-03-29 14:17:46 --> Database Driver Class Initialized
DEBUG - 2022-03-29 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 14:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 14:17:46 --> Controller Class Initialized
INFO - 2022-03-29 14:17:46 --> Form Validation Class Initialized
DEBUG - 2022-03-29 14:17:46 --> Encrypt Class Initialized
DEBUG - 2022-03-29 14:17:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 14:17:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 14:17:46 --> Email Class Initialized
INFO - 2022-03-29 14:17:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 14:17:46 --> Calendar Class Initialized
INFO - 2022-03-29 14:17:46 --> Model "Login_model" initialized
INFO - 2022-03-29 14:17:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 14:17:46 --> Final output sent to browser
DEBUG - 2022-03-29 14:17:46 --> Total execution time: 0.0874
ERROR - 2022-03-29 14:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:17:46 --> Config Class Initialized
INFO - 2022-03-29 14:17:46 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:17:46 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:17:46 --> Utf8 Class Initialized
INFO - 2022-03-29 14:17:46 --> URI Class Initialized
INFO - 2022-03-29 14:17:46 --> Router Class Initialized
INFO - 2022-03-29 14:17:46 --> Output Class Initialized
INFO - 2022-03-29 14:17:46 --> Security Class Initialized
DEBUG - 2022-03-29 14:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:17:46 --> Input Class Initialized
INFO - 2022-03-29 14:17:46 --> Language Class Initialized
ERROR - 2022-03-29 14:17:46 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-29 14:18:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:18:39 --> Config Class Initialized
INFO - 2022-03-29 14:18:39 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:18:39 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:18:39 --> Utf8 Class Initialized
INFO - 2022-03-29 14:18:39 --> URI Class Initialized
DEBUG - 2022-03-29 14:18:39 --> No URI present. Default controller set.
INFO - 2022-03-29 14:18:39 --> Router Class Initialized
INFO - 2022-03-29 14:18:39 --> Output Class Initialized
INFO - 2022-03-29 14:18:39 --> Security Class Initialized
DEBUG - 2022-03-29 14:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:18:39 --> Input Class Initialized
INFO - 2022-03-29 14:18:39 --> Language Class Initialized
INFO - 2022-03-29 14:18:39 --> Loader Class Initialized
INFO - 2022-03-29 14:18:39 --> Helper loaded: url_helper
INFO - 2022-03-29 14:18:39 --> Helper loaded: form_helper
INFO - 2022-03-29 14:18:39 --> Helper loaded: common_helper
INFO - 2022-03-29 14:18:39 --> Database Driver Class Initialized
DEBUG - 2022-03-29 14:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 14:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 14:18:39 --> Controller Class Initialized
INFO - 2022-03-29 14:18:39 --> Form Validation Class Initialized
DEBUG - 2022-03-29 14:18:39 --> Encrypt Class Initialized
DEBUG - 2022-03-29 14:18:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 14:18:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 14:18:39 --> Email Class Initialized
INFO - 2022-03-29 14:18:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 14:18:39 --> Calendar Class Initialized
INFO - 2022-03-29 14:18:39 --> Model "Login_model" initialized
INFO - 2022-03-29 14:18:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 14:18:39 --> Final output sent to browser
DEBUG - 2022-03-29 14:18:39 --> Total execution time: 0.0060
ERROR - 2022-03-29 14:18:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:18:40 --> Config Class Initialized
INFO - 2022-03-29 14:18:40 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:18:40 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:18:40 --> Utf8 Class Initialized
INFO - 2022-03-29 14:18:40 --> URI Class Initialized
INFO - 2022-03-29 14:18:40 --> Router Class Initialized
INFO - 2022-03-29 14:18:40 --> Output Class Initialized
INFO - 2022-03-29 14:18:40 --> Security Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:18:40 --> Input Class Initialized
INFO - 2022-03-29 14:18:40 --> Language Class Initialized
INFO - 2022-03-29 14:18:40 --> Loader Class Initialized
INFO - 2022-03-29 14:18:40 --> Helper loaded: url_helper
INFO - 2022-03-29 14:18:40 --> Helper loaded: form_helper
INFO - 2022-03-29 14:18:40 --> Helper loaded: common_helper
INFO - 2022-03-29 14:18:40 --> Database Driver Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 14:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 14:18:40 --> Controller Class Initialized
INFO - 2022-03-29 14:18:40 --> Form Validation Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Encrypt Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 14:18:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 14:18:40 --> Email Class Initialized
INFO - 2022-03-29 14:18:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 14:18:40 --> Calendar Class Initialized
INFO - 2022-03-29 14:18:40 --> Model "Login_model" initialized
INFO - 2022-03-29 14:18:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 14:18:40 --> Final output sent to browser
DEBUG - 2022-03-29 14:18:40 --> Total execution time: 0.0055
ERROR - 2022-03-29 14:18:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:18:40 --> Config Class Initialized
INFO - 2022-03-29 14:18:40 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:18:40 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:18:40 --> Utf8 Class Initialized
INFO - 2022-03-29 14:18:40 --> URI Class Initialized
INFO - 2022-03-29 14:18:40 --> Router Class Initialized
INFO - 2022-03-29 14:18:40 --> Output Class Initialized
INFO - 2022-03-29 14:18:40 --> Security Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:18:40 --> Input Class Initialized
INFO - 2022-03-29 14:18:40 --> Language Class Initialized
INFO - 2022-03-29 14:18:40 --> Loader Class Initialized
INFO - 2022-03-29 14:18:40 --> Helper loaded: url_helper
INFO - 2022-03-29 14:18:40 --> Helper loaded: form_helper
INFO - 2022-03-29 14:18:40 --> Helper loaded: common_helper
INFO - 2022-03-29 14:18:40 --> Database Driver Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 14:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 14:18:40 --> Controller Class Initialized
INFO - 2022-03-29 14:18:40 --> Form Validation Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Encrypt Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 14:18:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 14:18:40 --> Email Class Initialized
INFO - 2022-03-29 14:18:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 14:18:40 --> Calendar Class Initialized
INFO - 2022-03-29 14:18:40 --> Model "Login_model" initialized
ERROR - 2022-03-29 14:18:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:18:40 --> Config Class Initialized
INFO - 2022-03-29 14:18:40 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:18:40 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:18:40 --> Utf8 Class Initialized
INFO - 2022-03-29 14:18:40 --> URI Class Initialized
INFO - 2022-03-29 14:18:40 --> Router Class Initialized
INFO - 2022-03-29 14:18:40 --> Output Class Initialized
INFO - 2022-03-29 14:18:40 --> Security Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:18:40 --> Input Class Initialized
INFO - 2022-03-29 14:18:40 --> Language Class Initialized
INFO - 2022-03-29 14:18:40 --> Loader Class Initialized
INFO - 2022-03-29 14:18:40 --> Helper loaded: url_helper
INFO - 2022-03-29 14:18:40 --> Helper loaded: form_helper
INFO - 2022-03-29 14:18:40 --> Helper loaded: common_helper
INFO - 2022-03-29 14:18:40 --> Database Driver Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 14:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 14:18:40 --> Controller Class Initialized
INFO - 2022-03-29 14:18:40 --> Form Validation Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Encrypt Class Initialized
DEBUG - 2022-03-29 14:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 14:18:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 14:18:40 --> Email Class Initialized
INFO - 2022-03-29 14:18:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 14:18:40 --> Calendar Class Initialized
INFO - 2022-03-29 14:18:40 --> Model "Login_model" initialized
ERROR - 2022-03-29 14:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:10 --> Config Class Initialized
INFO - 2022-03-29 14:31:10 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:10 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:10 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:10 --> URI Class Initialized
DEBUG - 2022-03-29 14:31:10 --> No URI present. Default controller set.
INFO - 2022-03-29 14:31:10 --> Router Class Initialized
INFO - 2022-03-29 14:31:10 --> Output Class Initialized
INFO - 2022-03-29 14:31:10 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:10 --> Input Class Initialized
INFO - 2022-03-29 14:31:10 --> Language Class Initialized
INFO - 2022-03-29 14:31:10 --> Loader Class Initialized
INFO - 2022-03-29 14:31:10 --> Helper loaded: url_helper
INFO - 2022-03-29 14:31:10 --> Helper loaded: form_helper
INFO - 2022-03-29 14:31:10 --> Helper loaded: common_helper
INFO - 2022-03-29 14:31:10 --> Database Driver Class Initialized
DEBUG - 2022-03-29 14:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 14:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 14:31:10 --> Controller Class Initialized
INFO - 2022-03-29 14:31:10 --> Form Validation Class Initialized
DEBUG - 2022-03-29 14:31:10 --> Encrypt Class Initialized
DEBUG - 2022-03-29 14:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 14:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 14:31:10 --> Email Class Initialized
INFO - 2022-03-29 14:31:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 14:31:10 --> Calendar Class Initialized
INFO - 2022-03-29 14:31:10 --> Model "Login_model" initialized
INFO - 2022-03-29 14:31:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 14:31:10 --> Final output sent to browser
DEBUG - 2022-03-29 14:31:10 --> Total execution time: 0.0892
ERROR - 2022-03-29 14:31:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:11 --> Config Class Initialized
INFO - 2022-03-29 14:31:11 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:11 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:11 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:11 --> URI Class Initialized
DEBUG - 2022-03-29 14:31:11 --> No URI present. Default controller set.
INFO - 2022-03-29 14:31:11 --> Router Class Initialized
INFO - 2022-03-29 14:31:11 --> Output Class Initialized
INFO - 2022-03-29 14:31:11 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:11 --> Input Class Initialized
INFO - 2022-03-29 14:31:11 --> Language Class Initialized
INFO - 2022-03-29 14:31:11 --> Loader Class Initialized
INFO - 2022-03-29 14:31:11 --> Helper loaded: url_helper
INFO - 2022-03-29 14:31:11 --> Helper loaded: form_helper
INFO - 2022-03-29 14:31:11 --> Helper loaded: common_helper
INFO - 2022-03-29 14:31:11 --> Database Driver Class Initialized
DEBUG - 2022-03-29 14:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 14:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 14:31:11 --> Controller Class Initialized
INFO - 2022-03-29 14:31:11 --> Form Validation Class Initialized
DEBUG - 2022-03-29 14:31:11 --> Encrypt Class Initialized
DEBUG - 2022-03-29 14:31:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 14:31:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 14:31:11 --> Email Class Initialized
INFO - 2022-03-29 14:31:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 14:31:11 --> Calendar Class Initialized
INFO - 2022-03-29 14:31:11 --> Model "Login_model" initialized
INFO - 2022-03-29 14:31:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 14:31:11 --> Final output sent to browser
DEBUG - 2022-03-29 14:31:11 --> Total execution time: 0.0283
ERROR - 2022-03-29 14:31:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:11 --> Config Class Initialized
INFO - 2022-03-29 14:31:11 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:11 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:11 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:11 --> URI Class Initialized
INFO - 2022-03-29 14:31:11 --> Router Class Initialized
INFO - 2022-03-29 14:31:11 --> Output Class Initialized
INFO - 2022-03-29 14:31:11 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:11 --> Input Class Initialized
INFO - 2022-03-29 14:31:11 --> Language Class Initialized
ERROR - 2022-03-29 14:31:11 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-29 14:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:12 --> Config Class Initialized
INFO - 2022-03-29 14:31:12 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:12 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:12 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:12 --> URI Class Initialized
INFO - 2022-03-29 14:31:12 --> Router Class Initialized
INFO - 2022-03-29 14:31:12 --> Output Class Initialized
INFO - 2022-03-29 14:31:12 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:12 --> Input Class Initialized
INFO - 2022-03-29 14:31:12 --> Language Class Initialized
ERROR - 2022-03-29 14:31:12 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-29 14:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:12 --> Config Class Initialized
INFO - 2022-03-29 14:31:12 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:12 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:12 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:13 --> URI Class Initialized
INFO - 2022-03-29 14:31:13 --> Router Class Initialized
INFO - 2022-03-29 14:31:13 --> Output Class Initialized
INFO - 2022-03-29 14:31:13 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:13 --> Input Class Initialized
INFO - 2022-03-29 14:31:13 --> Language Class Initialized
ERROR - 2022-03-29 14:31:13 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-29 14:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:13 --> Config Class Initialized
INFO - 2022-03-29 14:31:13 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:13 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:13 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:13 --> URI Class Initialized
INFO - 2022-03-29 14:31:13 --> Router Class Initialized
INFO - 2022-03-29 14:31:13 --> Output Class Initialized
INFO - 2022-03-29 14:31:13 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:13 --> Input Class Initialized
INFO - 2022-03-29 14:31:13 --> Language Class Initialized
ERROR - 2022-03-29 14:31:13 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-29 14:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:13 --> Config Class Initialized
INFO - 2022-03-29 14:31:13 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:13 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:13 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:13 --> URI Class Initialized
INFO - 2022-03-29 14:31:13 --> Router Class Initialized
INFO - 2022-03-29 14:31:13 --> Output Class Initialized
INFO - 2022-03-29 14:31:13 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:13 --> Input Class Initialized
INFO - 2022-03-29 14:31:13 --> Language Class Initialized
ERROR - 2022-03-29 14:31:13 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-29 14:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:14 --> Config Class Initialized
INFO - 2022-03-29 14:31:14 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:14 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:14 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:14 --> URI Class Initialized
INFO - 2022-03-29 14:31:14 --> Router Class Initialized
INFO - 2022-03-29 14:31:14 --> Output Class Initialized
INFO - 2022-03-29 14:31:14 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:14 --> Input Class Initialized
INFO - 2022-03-29 14:31:14 --> Language Class Initialized
ERROR - 2022-03-29 14:31:14 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-29 14:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:14 --> Config Class Initialized
INFO - 2022-03-29 14:31:14 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:14 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:14 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:14 --> URI Class Initialized
INFO - 2022-03-29 14:31:14 --> Router Class Initialized
INFO - 2022-03-29 14:31:14 --> Output Class Initialized
INFO - 2022-03-29 14:31:14 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:14 --> Input Class Initialized
INFO - 2022-03-29 14:31:14 --> Language Class Initialized
ERROR - 2022-03-29 14:31:14 --> 404 Page Not Found: 2015/wp-includes
ERROR - 2022-03-29 14:31:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:51 --> Config Class Initialized
INFO - 2022-03-29 14:31:51 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:51 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:51 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:51 --> URI Class Initialized
INFO - 2022-03-29 14:31:51 --> Router Class Initialized
INFO - 2022-03-29 14:31:51 --> Output Class Initialized
INFO - 2022-03-29 14:31:51 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:51 --> Input Class Initialized
INFO - 2022-03-29 14:31:51 --> Language Class Initialized
ERROR - 2022-03-29 14:31:51 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-03-29 14:31:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:51 --> Config Class Initialized
INFO - 2022-03-29 14:31:51 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:51 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:51 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:51 --> URI Class Initialized
INFO - 2022-03-29 14:31:51 --> Router Class Initialized
INFO - 2022-03-29 14:31:51 --> Output Class Initialized
INFO - 2022-03-29 14:31:51 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:51 --> Input Class Initialized
INFO - 2022-03-29 14:31:51 --> Language Class Initialized
ERROR - 2022-03-29 14:31:51 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-29 14:31:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:51 --> Config Class Initialized
INFO - 2022-03-29 14:31:51 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:51 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:51 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:51 --> URI Class Initialized
INFO - 2022-03-29 14:31:51 --> Router Class Initialized
INFO - 2022-03-29 14:31:51 --> Output Class Initialized
INFO - 2022-03-29 14:31:51 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:51 --> Input Class Initialized
INFO - 2022-03-29 14:31:51 --> Language Class Initialized
ERROR - 2022-03-29 14:31:51 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-29 14:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:52 --> Config Class Initialized
INFO - 2022-03-29 14:31:52 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:52 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:52 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:52 --> URI Class Initialized
INFO - 2022-03-29 14:31:52 --> Router Class Initialized
INFO - 2022-03-29 14:31:52 --> Output Class Initialized
INFO - 2022-03-29 14:31:52 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:52 --> Input Class Initialized
INFO - 2022-03-29 14:31:52 --> Language Class Initialized
ERROR - 2022-03-29 14:31:52 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-29 14:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:52 --> Config Class Initialized
INFO - 2022-03-29 14:31:52 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:52 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:52 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:52 --> URI Class Initialized
INFO - 2022-03-29 14:31:52 --> Router Class Initialized
INFO - 2022-03-29 14:31:52 --> Output Class Initialized
INFO - 2022-03-29 14:31:52 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:52 --> Input Class Initialized
INFO - 2022-03-29 14:31:52 --> Language Class Initialized
ERROR - 2022-03-29 14:31:52 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-03-29 14:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:52 --> Config Class Initialized
INFO - 2022-03-29 14:31:52 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:52 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:52 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:52 --> URI Class Initialized
INFO - 2022-03-29 14:31:52 --> Router Class Initialized
INFO - 2022-03-29 14:31:52 --> Output Class Initialized
INFO - 2022-03-29 14:31:52 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:52 --> Input Class Initialized
INFO - 2022-03-29 14:31:52 --> Language Class Initialized
ERROR - 2022-03-29 14:31:52 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-29 14:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:52 --> Config Class Initialized
INFO - 2022-03-29 14:31:52 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:52 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:52 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:52 --> URI Class Initialized
INFO - 2022-03-29 14:31:52 --> Router Class Initialized
INFO - 2022-03-29 14:31:52 --> Output Class Initialized
INFO - 2022-03-29 14:31:52 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:52 --> Input Class Initialized
INFO - 2022-03-29 14:31:52 --> Language Class Initialized
ERROR - 2022-03-29 14:31:52 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-29 14:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:52 --> Config Class Initialized
INFO - 2022-03-29 14:31:52 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:52 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:52 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:52 --> URI Class Initialized
INFO - 2022-03-29 14:31:52 --> Router Class Initialized
INFO - 2022-03-29 14:31:52 --> Output Class Initialized
INFO - 2022-03-29 14:31:52 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:52 --> Input Class Initialized
INFO - 2022-03-29 14:31:52 --> Language Class Initialized
ERROR - 2022-03-29 14:31:52 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-29 14:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 14:31:53 --> Config Class Initialized
INFO - 2022-03-29 14:31:53 --> Hooks Class Initialized
DEBUG - 2022-03-29 14:31:53 --> UTF-8 Support Enabled
INFO - 2022-03-29 14:31:53 --> Utf8 Class Initialized
INFO - 2022-03-29 14:31:53 --> URI Class Initialized
INFO - 2022-03-29 14:31:53 --> Router Class Initialized
INFO - 2022-03-29 14:31:53 --> Output Class Initialized
INFO - 2022-03-29 14:31:53 --> Security Class Initialized
DEBUG - 2022-03-29 14:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 14:31:53 --> Input Class Initialized
INFO - 2022-03-29 14:31:53 --> Language Class Initialized
ERROR - 2022-03-29 14:31:53 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-03-29 23:28:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:28:26 --> Config Class Initialized
INFO - 2022-03-29 23:28:26 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:28:26 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:28:26 --> Utf8 Class Initialized
INFO - 2022-03-29 23:28:26 --> URI Class Initialized
DEBUG - 2022-03-29 23:28:26 --> No URI present. Default controller set.
INFO - 2022-03-29 23:28:26 --> Router Class Initialized
INFO - 2022-03-29 23:28:26 --> Output Class Initialized
INFO - 2022-03-29 23:28:26 --> Security Class Initialized
DEBUG - 2022-03-29 23:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:28:26 --> Input Class Initialized
INFO - 2022-03-29 23:28:26 --> Language Class Initialized
INFO - 2022-03-29 23:28:26 --> Loader Class Initialized
INFO - 2022-03-29 23:28:26 --> Helper loaded: url_helper
INFO - 2022-03-29 23:28:26 --> Helper loaded: form_helper
INFO - 2022-03-29 23:28:26 --> Helper loaded: common_helper
INFO - 2022-03-29 23:28:26 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:28:26 --> Controller Class Initialized
INFO - 2022-03-29 23:28:26 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:28:26 --> Encrypt Class Initialized
DEBUG - 2022-03-29 23:28:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 23:28:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 23:28:26 --> Email Class Initialized
INFO - 2022-03-29 23:28:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 23:28:26 --> Calendar Class Initialized
INFO - 2022-03-29 23:28:26 --> Model "Login_model" initialized
INFO - 2022-03-29 23:28:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 23:28:26 --> Final output sent to browser
DEBUG - 2022-03-29 23:28:26 --> Total execution time: 0.0669
ERROR - 2022-03-29 23:28:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:28:27 --> Config Class Initialized
INFO - 2022-03-29 23:28:27 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:28:27 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:28:27 --> Utf8 Class Initialized
INFO - 2022-03-29 23:28:27 --> URI Class Initialized
DEBUG - 2022-03-29 23:28:27 --> No URI present. Default controller set.
INFO - 2022-03-29 23:28:27 --> Router Class Initialized
INFO - 2022-03-29 23:28:27 --> Output Class Initialized
INFO - 2022-03-29 23:28:27 --> Security Class Initialized
DEBUG - 2022-03-29 23:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:28:27 --> Input Class Initialized
INFO - 2022-03-29 23:28:27 --> Language Class Initialized
INFO - 2022-03-29 23:28:27 --> Loader Class Initialized
INFO - 2022-03-29 23:28:27 --> Helper loaded: url_helper
INFO - 2022-03-29 23:28:27 --> Helper loaded: form_helper
INFO - 2022-03-29 23:28:27 --> Helper loaded: common_helper
INFO - 2022-03-29 23:28:27 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:28:27 --> Controller Class Initialized
INFO - 2022-03-29 23:28:27 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:28:27 --> Encrypt Class Initialized
DEBUG - 2022-03-29 23:28:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 23:28:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 23:28:27 --> Email Class Initialized
INFO - 2022-03-29 23:28:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 23:28:27 --> Calendar Class Initialized
INFO - 2022-03-29 23:28:27 --> Model "Login_model" initialized
INFO - 2022-03-29 23:28:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 23:28:27 --> Final output sent to browser
DEBUG - 2022-03-29 23:28:27 --> Total execution time: 0.0062
ERROR - 2022-03-29 23:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:28:40 --> Config Class Initialized
INFO - 2022-03-29 23:28:40 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:28:40 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:28:40 --> Utf8 Class Initialized
INFO - 2022-03-29 23:28:40 --> URI Class Initialized
INFO - 2022-03-29 23:28:40 --> Router Class Initialized
INFO - 2022-03-29 23:28:40 --> Output Class Initialized
INFO - 2022-03-29 23:28:40 --> Security Class Initialized
DEBUG - 2022-03-29 23:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:28:40 --> Input Class Initialized
INFO - 2022-03-29 23:28:40 --> Language Class Initialized
INFO - 2022-03-29 23:28:40 --> Loader Class Initialized
INFO - 2022-03-29 23:28:40 --> Helper loaded: url_helper
INFO - 2022-03-29 23:28:40 --> Helper loaded: form_helper
INFO - 2022-03-29 23:28:40 --> Helper loaded: common_helper
INFO - 2022-03-29 23:28:40 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:28:40 --> Controller Class Initialized
INFO - 2022-03-29 23:28:40 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:28:40 --> Encrypt Class Initialized
DEBUG - 2022-03-29 23:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 23:28:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 23:28:40 --> Email Class Initialized
INFO - 2022-03-29 23:28:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 23:28:40 --> Calendar Class Initialized
INFO - 2022-03-29 23:28:40 --> Model "Login_model" initialized
INFO - 2022-03-29 23:28:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-29 23:28:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:28:41 --> Config Class Initialized
INFO - 2022-03-29 23:28:41 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:28:41 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:28:41 --> Utf8 Class Initialized
INFO - 2022-03-29 23:28:41 --> URI Class Initialized
INFO - 2022-03-29 23:28:41 --> Router Class Initialized
INFO - 2022-03-29 23:28:41 --> Output Class Initialized
INFO - 2022-03-29 23:28:41 --> Security Class Initialized
DEBUG - 2022-03-29 23:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:28:41 --> Input Class Initialized
INFO - 2022-03-29 23:28:41 --> Language Class Initialized
INFO - 2022-03-29 23:28:41 --> Loader Class Initialized
INFO - 2022-03-29 23:28:41 --> Helper loaded: url_helper
INFO - 2022-03-29 23:28:41 --> Helper loaded: form_helper
INFO - 2022-03-29 23:28:41 --> Helper loaded: common_helper
INFO - 2022-03-29 23:28:41 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:28:41 --> Controller Class Initialized
INFO - 2022-03-29 23:28:41 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:28:41 --> Encrypt Class Initialized
INFO - 2022-03-29 23:28:41 --> Model "Login_model" initialized
INFO - 2022-03-29 23:28:41 --> Model "Dashboard_model" initialized
INFO - 2022-03-29 23:28:41 --> Model "Case_model" initialized
INFO - 2022-03-29 23:28:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 23:28:41 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-29 23:28:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 23:28:41 --> Final output sent to browser
DEBUG - 2022-03-29 23:28:41 --> Total execution time: 0.4888
ERROR - 2022-03-29 23:46:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:46:18 --> Config Class Initialized
INFO - 2022-03-29 23:46:18 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:46:18 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:46:18 --> Utf8 Class Initialized
INFO - 2022-03-29 23:46:18 --> URI Class Initialized
INFO - 2022-03-29 23:46:18 --> Router Class Initialized
INFO - 2022-03-29 23:46:18 --> Output Class Initialized
INFO - 2022-03-29 23:46:18 --> Security Class Initialized
DEBUG - 2022-03-29 23:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:46:18 --> Input Class Initialized
INFO - 2022-03-29 23:46:18 --> Language Class Initialized
INFO - 2022-03-29 23:46:18 --> Loader Class Initialized
INFO - 2022-03-29 23:46:18 --> Helper loaded: url_helper
INFO - 2022-03-29 23:46:18 --> Helper loaded: form_helper
INFO - 2022-03-29 23:46:18 --> Helper loaded: common_helper
INFO - 2022-03-29 23:46:18 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:46:19 --> Controller Class Initialized
INFO - 2022-03-29 23:46:19 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:46:19 --> Encrypt Class Initialized
INFO - 2022-03-29 23:46:19 --> Model "Patient_model" initialized
INFO - 2022-03-29 23:46:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 23:46:19 --> Model "Referredby_model" initialized
INFO - 2022-03-29 23:46:19 --> Model "Prefix_master" initialized
INFO - 2022-03-29 23:46:19 --> Model "Hospital_model" initialized
INFO - 2022-03-29 23:46:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 23:46:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-29 23:46:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 23:46:19 --> Final output sent to browser
DEBUG - 2022-03-29 23:46:19 --> Total execution time: 0.2026
ERROR - 2022-03-29 23:46:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:46:31 --> Config Class Initialized
INFO - 2022-03-29 23:46:31 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:46:31 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:46:31 --> Utf8 Class Initialized
INFO - 2022-03-29 23:46:31 --> URI Class Initialized
INFO - 2022-03-29 23:46:31 --> Router Class Initialized
INFO - 2022-03-29 23:46:31 --> Output Class Initialized
INFO - 2022-03-29 23:46:31 --> Security Class Initialized
DEBUG - 2022-03-29 23:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:46:31 --> Input Class Initialized
INFO - 2022-03-29 23:46:31 --> Language Class Initialized
INFO - 2022-03-29 23:46:31 --> Loader Class Initialized
INFO - 2022-03-29 23:46:31 --> Helper loaded: url_helper
INFO - 2022-03-29 23:46:31 --> Helper loaded: form_helper
INFO - 2022-03-29 23:46:31 --> Helper loaded: common_helper
INFO - 2022-03-29 23:46:31 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:46:31 --> Controller Class Initialized
INFO - 2022-03-29 23:46:31 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:46:31 --> Encrypt Class Initialized
INFO - 2022-03-29 23:46:31 --> Model "Patient_model" initialized
INFO - 2022-03-29 23:46:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 23:46:31 --> Model "Prefix_master" initialized
INFO - 2022-03-29 23:46:31 --> Model "Users_model" initialized
INFO - 2022-03-29 23:46:31 --> Model "Hospital_model" initialized
INFO - 2022-03-29 23:46:31 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-29 23:46:33 --> Final output sent to browser
DEBUG - 2022-03-29 23:46:33 --> Total execution time: 1.6549
ERROR - 2022-03-29 23:51:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:51:01 --> Config Class Initialized
INFO - 2022-03-29 23:51:01 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:51:01 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:51:01 --> Utf8 Class Initialized
INFO - 2022-03-29 23:51:01 --> URI Class Initialized
INFO - 2022-03-29 23:51:01 --> Router Class Initialized
INFO - 2022-03-29 23:51:01 --> Output Class Initialized
INFO - 2022-03-29 23:51:01 --> Security Class Initialized
DEBUG - 2022-03-29 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:51:01 --> Input Class Initialized
INFO - 2022-03-29 23:51:01 --> Language Class Initialized
INFO - 2022-03-29 23:51:01 --> Loader Class Initialized
INFO - 2022-03-29 23:51:01 --> Helper loaded: url_helper
INFO - 2022-03-29 23:51:01 --> Helper loaded: form_helper
INFO - 2022-03-29 23:51:01 --> Helper loaded: common_helper
INFO - 2022-03-29 23:51:01 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:51:01 --> Controller Class Initialized
INFO - 2022-03-29 23:51:01 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:51:01 --> Encrypt Class Initialized
INFO - 2022-03-29 23:51:01 --> Model "Patient_model" initialized
INFO - 2022-03-29 23:51:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 23:51:01 --> Model "Prefix_master" initialized
INFO - 2022-03-29 23:51:01 --> Model "Users_model" initialized
INFO - 2022-03-29 23:51:01 --> Model "Hospital_model" initialized
INFO - 2022-03-29 23:51:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 23:51:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 23:51:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 23:51:01 --> Final output sent to browser
DEBUG - 2022-03-29 23:51:01 --> Total execution time: 0.2191
ERROR - 2022-03-29 23:52:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:52:35 --> Config Class Initialized
INFO - 2022-03-29 23:52:35 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:52:35 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:52:35 --> Utf8 Class Initialized
INFO - 2022-03-29 23:52:35 --> URI Class Initialized
INFO - 2022-03-29 23:52:35 --> Router Class Initialized
INFO - 2022-03-29 23:52:35 --> Output Class Initialized
INFO - 2022-03-29 23:52:35 --> Security Class Initialized
DEBUG - 2022-03-29 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:52:35 --> Input Class Initialized
INFO - 2022-03-29 23:52:35 --> Language Class Initialized
INFO - 2022-03-29 23:52:35 --> Loader Class Initialized
INFO - 2022-03-29 23:52:35 --> Helper loaded: url_helper
INFO - 2022-03-29 23:52:35 --> Helper loaded: form_helper
INFO - 2022-03-29 23:52:35 --> Helper loaded: common_helper
INFO - 2022-03-29 23:52:35 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:52:35 --> Controller Class Initialized
INFO - 2022-03-29 23:52:35 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:52:35 --> Encrypt Class Initialized
INFO - 2022-03-29 23:52:35 --> Model "Patient_model" initialized
INFO - 2022-03-29 23:52:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 23:52:35 --> Model "Prefix_master" initialized
INFO - 2022-03-29 23:52:35 --> Model "Users_model" initialized
INFO - 2022-03-29 23:52:35 --> Model "Hospital_model" initialized
ERROR - 2022-03-29 23:52:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:52:35 --> Config Class Initialized
INFO - 2022-03-29 23:52:35 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:52:35 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:52:35 --> Utf8 Class Initialized
INFO - 2022-03-29 23:52:35 --> URI Class Initialized
INFO - 2022-03-29 23:52:35 --> Router Class Initialized
INFO - 2022-03-29 23:52:35 --> Output Class Initialized
INFO - 2022-03-29 23:52:35 --> Security Class Initialized
DEBUG - 2022-03-29 23:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:52:35 --> Input Class Initialized
INFO - 2022-03-29 23:52:35 --> Language Class Initialized
INFO - 2022-03-29 23:52:35 --> Loader Class Initialized
INFO - 2022-03-29 23:52:35 --> Helper loaded: url_helper
INFO - 2022-03-29 23:52:35 --> Helper loaded: form_helper
INFO - 2022-03-29 23:52:35 --> Helper loaded: common_helper
INFO - 2022-03-29 23:52:35 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:52:35 --> Controller Class Initialized
INFO - 2022-03-29 23:52:35 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:52:35 --> Encrypt Class Initialized
INFO - 2022-03-29 23:52:35 --> Model "Patient_model" initialized
INFO - 2022-03-29 23:52:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-29 23:52:35 --> Model "Prefix_master" initialized
INFO - 2022-03-29 23:52:35 --> Model "Users_model" initialized
INFO - 2022-03-29 23:52:35 --> Model "Hospital_model" initialized
INFO - 2022-03-29 23:52:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-29 23:52:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-29 23:52:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-29 23:52:35 --> Final output sent to browser
DEBUG - 2022-03-29 23:52:35 --> Total execution time: 0.0420
ERROR - 2022-03-29 23:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-29 23:57:33 --> Config Class Initialized
INFO - 2022-03-29 23:57:33 --> Hooks Class Initialized
DEBUG - 2022-03-29 23:57:33 --> UTF-8 Support Enabled
INFO - 2022-03-29 23:57:33 --> Utf8 Class Initialized
INFO - 2022-03-29 23:57:33 --> URI Class Initialized
DEBUG - 2022-03-29 23:57:33 --> No URI present. Default controller set.
INFO - 2022-03-29 23:57:33 --> Router Class Initialized
INFO - 2022-03-29 23:57:33 --> Output Class Initialized
INFO - 2022-03-29 23:57:33 --> Security Class Initialized
DEBUG - 2022-03-29 23:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-29 23:57:33 --> Input Class Initialized
INFO - 2022-03-29 23:57:33 --> Language Class Initialized
INFO - 2022-03-29 23:57:33 --> Loader Class Initialized
INFO - 2022-03-29 23:57:33 --> Helper loaded: url_helper
INFO - 2022-03-29 23:57:33 --> Helper loaded: form_helper
INFO - 2022-03-29 23:57:33 --> Helper loaded: common_helper
INFO - 2022-03-29 23:57:34 --> Database Driver Class Initialized
DEBUG - 2022-03-29 23:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-29 23:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-29 23:57:34 --> Controller Class Initialized
INFO - 2022-03-29 23:57:34 --> Form Validation Class Initialized
DEBUG - 2022-03-29 23:57:34 --> Encrypt Class Initialized
DEBUG - 2022-03-29 23:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-29 23:57:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-29 23:57:34 --> Email Class Initialized
INFO - 2022-03-29 23:57:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-29 23:57:34 --> Calendar Class Initialized
INFO - 2022-03-29 23:57:34 --> Model "Login_model" initialized
INFO - 2022-03-29 23:57:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-29 23:57:34 --> Final output sent to browser
DEBUG - 2022-03-29 23:57:34 --> Total execution time: 0.0660
