<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-25 00:55:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 00:55:34 --> Config Class Initialized
INFO - 2021-11-25 00:55:34 --> Hooks Class Initialized
DEBUG - 2021-11-25 00:55:34 --> UTF-8 Support Enabled
INFO - 2021-11-25 00:55:34 --> Utf8 Class Initialized
INFO - 2021-11-25 00:55:34 --> URI Class Initialized
DEBUG - 2021-11-25 00:55:34 --> No URI present. Default controller set.
INFO - 2021-11-25 00:55:34 --> Router Class Initialized
INFO - 2021-11-25 00:55:34 --> Output Class Initialized
INFO - 2021-11-25 00:55:34 --> Security Class Initialized
DEBUG - 2021-11-25 00:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 00:55:34 --> Input Class Initialized
INFO - 2021-11-25 00:55:34 --> Language Class Initialized
INFO - 2021-11-25 00:55:34 --> Loader Class Initialized
INFO - 2021-11-25 00:55:34 --> Helper loaded: url_helper
INFO - 2021-11-25 00:55:34 --> Helper loaded: form_helper
INFO - 2021-11-25 00:55:34 --> Helper loaded: common_helper
INFO - 2021-11-25 00:55:34 --> Database Driver Class Initialized
DEBUG - 2021-11-25 00:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 00:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 00:55:34 --> Controller Class Initialized
INFO - 2021-11-25 00:55:34 --> Form Validation Class Initialized
DEBUG - 2021-11-25 00:55:34 --> Encrypt Class Initialized
DEBUG - 2021-11-25 00:55:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 00:55:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 00:55:34 --> Email Class Initialized
INFO - 2021-11-25 00:55:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 00:55:34 --> Calendar Class Initialized
INFO - 2021-11-25 00:55:34 --> Model "Login_model" initialized
INFO - 2021-11-25 00:55:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 00:55:34 --> Final output sent to browser
DEBUG - 2021-11-25 00:55:34 --> Total execution time: 0.0251
ERROR - 2021-11-25 07:19:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 07:19:51 --> Config Class Initialized
INFO - 2021-11-25 07:19:51 --> Hooks Class Initialized
DEBUG - 2021-11-25 07:19:51 --> UTF-8 Support Enabled
INFO - 2021-11-25 07:19:51 --> Utf8 Class Initialized
INFO - 2021-11-25 07:19:51 --> URI Class Initialized
DEBUG - 2021-11-25 07:19:51 --> No URI present. Default controller set.
INFO - 2021-11-25 07:19:51 --> Router Class Initialized
INFO - 2021-11-25 07:19:51 --> Output Class Initialized
INFO - 2021-11-25 07:19:51 --> Security Class Initialized
DEBUG - 2021-11-25 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 07:19:51 --> Input Class Initialized
INFO - 2021-11-25 07:19:51 --> Language Class Initialized
INFO - 2021-11-25 07:19:51 --> Loader Class Initialized
INFO - 2021-11-25 07:19:51 --> Helper loaded: url_helper
INFO - 2021-11-25 07:19:51 --> Helper loaded: form_helper
INFO - 2021-11-25 07:19:51 --> Helper loaded: common_helper
INFO - 2021-11-25 07:19:51 --> Database Driver Class Initialized
DEBUG - 2021-11-25 07:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 07:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 07:19:51 --> Controller Class Initialized
INFO - 2021-11-25 07:19:51 --> Form Validation Class Initialized
DEBUG - 2021-11-25 07:19:51 --> Encrypt Class Initialized
DEBUG - 2021-11-25 07:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 07:19:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 07:19:51 --> Email Class Initialized
INFO - 2021-11-25 07:19:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 07:19:51 --> Calendar Class Initialized
INFO - 2021-11-25 07:19:51 --> Model "Login_model" initialized
INFO - 2021-11-25 07:19:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 07:19:51 --> Final output sent to browser
DEBUG - 2021-11-25 07:19:51 --> Total execution time: 0.0426
ERROR - 2021-11-25 10:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 10:17:30 --> Config Class Initialized
INFO - 2021-11-25 10:17:30 --> Hooks Class Initialized
DEBUG - 2021-11-25 10:17:30 --> UTF-8 Support Enabled
INFO - 2021-11-25 10:17:30 --> Utf8 Class Initialized
INFO - 2021-11-25 10:17:30 --> URI Class Initialized
DEBUG - 2021-11-25 10:17:30 --> No URI present. Default controller set.
INFO - 2021-11-25 10:17:30 --> Router Class Initialized
INFO - 2021-11-25 10:17:30 --> Output Class Initialized
INFO - 2021-11-25 10:17:30 --> Security Class Initialized
DEBUG - 2021-11-25 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 10:17:30 --> Input Class Initialized
INFO - 2021-11-25 10:17:30 --> Language Class Initialized
INFO - 2021-11-25 10:17:30 --> Loader Class Initialized
INFO - 2021-11-25 10:17:30 --> Helper loaded: url_helper
INFO - 2021-11-25 10:17:30 --> Helper loaded: form_helper
INFO - 2021-11-25 10:17:30 --> Helper loaded: common_helper
INFO - 2021-11-25 10:17:30 --> Database Driver Class Initialized
DEBUG - 2021-11-25 10:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 10:17:30 --> Controller Class Initialized
INFO - 2021-11-25 10:17:30 --> Form Validation Class Initialized
DEBUG - 2021-11-25 10:17:30 --> Encrypt Class Initialized
DEBUG - 2021-11-25 10:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 10:17:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 10:17:30 --> Email Class Initialized
INFO - 2021-11-25 10:17:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 10:17:30 --> Calendar Class Initialized
INFO - 2021-11-25 10:17:30 --> Model "Login_model" initialized
INFO - 2021-11-25 10:17:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 10:17:30 --> Final output sent to browser
DEBUG - 2021-11-25 10:17:30 --> Total execution time: 0.0242
ERROR - 2021-11-25 10:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 10:17:31 --> Config Class Initialized
INFO - 2021-11-25 10:17:31 --> Hooks Class Initialized
DEBUG - 2021-11-25 10:17:31 --> UTF-8 Support Enabled
INFO - 2021-11-25 10:17:31 --> Utf8 Class Initialized
INFO - 2021-11-25 10:17:31 --> URI Class Initialized
DEBUG - 2021-11-25 10:17:31 --> No URI present. Default controller set.
INFO - 2021-11-25 10:17:31 --> Router Class Initialized
INFO - 2021-11-25 10:17:31 --> Output Class Initialized
INFO - 2021-11-25 10:17:31 --> Security Class Initialized
DEBUG - 2021-11-25 10:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 10:17:31 --> Input Class Initialized
INFO - 2021-11-25 10:17:31 --> Language Class Initialized
INFO - 2021-11-25 10:17:31 --> Loader Class Initialized
INFO - 2021-11-25 10:17:31 --> Helper loaded: url_helper
INFO - 2021-11-25 10:17:31 --> Helper loaded: form_helper
INFO - 2021-11-25 10:17:31 --> Helper loaded: common_helper
INFO - 2021-11-25 10:17:31 --> Database Driver Class Initialized
DEBUG - 2021-11-25 10:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 10:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 10:17:31 --> Controller Class Initialized
INFO - 2021-11-25 10:17:31 --> Form Validation Class Initialized
DEBUG - 2021-11-25 10:17:31 --> Encrypt Class Initialized
DEBUG - 2021-11-25 10:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 10:17:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 10:17:31 --> Email Class Initialized
INFO - 2021-11-25 10:17:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 10:17:31 --> Calendar Class Initialized
INFO - 2021-11-25 10:17:31 --> Model "Login_model" initialized
INFO - 2021-11-25 10:17:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 10:17:31 --> Final output sent to browser
DEBUG - 2021-11-25 10:17:31 --> Total execution time: 0.0280
ERROR - 2021-11-25 10:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 10:17:32 --> Config Class Initialized
INFO - 2021-11-25 10:17:32 --> Hooks Class Initialized
DEBUG - 2021-11-25 10:17:32 --> UTF-8 Support Enabled
INFO - 2021-11-25 10:17:32 --> Utf8 Class Initialized
INFO - 2021-11-25 10:17:32 --> URI Class Initialized
DEBUG - 2021-11-25 10:17:32 --> No URI present. Default controller set.
INFO - 2021-11-25 10:17:32 --> Router Class Initialized
INFO - 2021-11-25 10:17:32 --> Output Class Initialized
INFO - 2021-11-25 10:17:32 --> Security Class Initialized
DEBUG - 2021-11-25 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 10:17:32 --> Input Class Initialized
INFO - 2021-11-25 10:17:32 --> Language Class Initialized
INFO - 2021-11-25 10:17:32 --> Loader Class Initialized
INFO - 2021-11-25 10:17:32 --> Helper loaded: url_helper
INFO - 2021-11-25 10:17:32 --> Helper loaded: form_helper
INFO - 2021-11-25 10:17:32 --> Helper loaded: common_helper
INFO - 2021-11-25 10:17:32 --> Database Driver Class Initialized
DEBUG - 2021-11-25 10:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 10:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 10:17:32 --> Controller Class Initialized
INFO - 2021-11-25 10:17:32 --> Form Validation Class Initialized
DEBUG - 2021-11-25 10:17:32 --> Encrypt Class Initialized
DEBUG - 2021-11-25 10:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 10:17:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 10:17:32 --> Email Class Initialized
INFO - 2021-11-25 10:17:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 10:17:32 --> Calendar Class Initialized
INFO - 2021-11-25 10:17:32 --> Model "Login_model" initialized
INFO - 2021-11-25 10:17:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 10:17:32 --> Final output sent to browser
DEBUG - 2021-11-25 10:17:32 --> Total execution time: 0.0300
ERROR - 2021-11-25 10:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 10:40:53 --> Config Class Initialized
INFO - 2021-11-25 10:40:53 --> Hooks Class Initialized
DEBUG - 2021-11-25 10:40:53 --> UTF-8 Support Enabled
INFO - 2021-11-25 10:40:53 --> Utf8 Class Initialized
INFO - 2021-11-25 10:40:53 --> URI Class Initialized
DEBUG - 2021-11-25 10:40:53 --> No URI present. Default controller set.
INFO - 2021-11-25 10:40:53 --> Router Class Initialized
INFO - 2021-11-25 10:40:53 --> Output Class Initialized
INFO - 2021-11-25 10:40:53 --> Security Class Initialized
DEBUG - 2021-11-25 10:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 10:40:53 --> Input Class Initialized
INFO - 2021-11-25 10:40:53 --> Language Class Initialized
INFO - 2021-11-25 10:40:53 --> Loader Class Initialized
INFO - 2021-11-25 10:40:53 --> Helper loaded: url_helper
INFO - 2021-11-25 10:40:53 --> Helper loaded: form_helper
INFO - 2021-11-25 10:40:53 --> Helper loaded: common_helper
INFO - 2021-11-25 10:40:53 --> Database Driver Class Initialized
DEBUG - 2021-11-25 10:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 10:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 10:40:53 --> Controller Class Initialized
INFO - 2021-11-25 10:40:53 --> Form Validation Class Initialized
DEBUG - 2021-11-25 10:40:53 --> Encrypt Class Initialized
DEBUG - 2021-11-25 10:40:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 10:40:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 10:40:53 --> Email Class Initialized
INFO - 2021-11-25 10:40:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 10:40:53 --> Calendar Class Initialized
INFO - 2021-11-25 10:40:53 --> Model "Login_model" initialized
INFO - 2021-11-25 10:40:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 10:40:53 --> Final output sent to browser
DEBUG - 2021-11-25 10:40:53 --> Total execution time: 0.0314
ERROR - 2021-11-25 10:40:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 10:40:57 --> Config Class Initialized
INFO - 2021-11-25 10:40:57 --> Hooks Class Initialized
DEBUG - 2021-11-25 10:40:57 --> UTF-8 Support Enabled
INFO - 2021-11-25 10:40:57 --> Utf8 Class Initialized
INFO - 2021-11-25 10:40:57 --> URI Class Initialized
DEBUG - 2021-11-25 10:40:57 --> No URI present. Default controller set.
INFO - 2021-11-25 10:40:57 --> Router Class Initialized
INFO - 2021-11-25 10:40:57 --> Output Class Initialized
INFO - 2021-11-25 10:40:57 --> Security Class Initialized
DEBUG - 2021-11-25 10:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 10:40:57 --> Input Class Initialized
INFO - 2021-11-25 10:40:57 --> Language Class Initialized
INFO - 2021-11-25 10:40:57 --> Loader Class Initialized
INFO - 2021-11-25 10:40:57 --> Helper loaded: url_helper
INFO - 2021-11-25 10:40:57 --> Helper loaded: form_helper
INFO - 2021-11-25 10:40:57 --> Helper loaded: common_helper
INFO - 2021-11-25 10:40:57 --> Database Driver Class Initialized
DEBUG - 2021-11-25 10:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 10:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 10:40:57 --> Controller Class Initialized
INFO - 2021-11-25 10:40:57 --> Form Validation Class Initialized
DEBUG - 2021-11-25 10:40:57 --> Encrypt Class Initialized
DEBUG - 2021-11-25 10:40:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 10:40:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 10:40:57 --> Email Class Initialized
INFO - 2021-11-25 10:40:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 10:40:57 --> Calendar Class Initialized
INFO - 2021-11-25 10:40:57 --> Model "Login_model" initialized
INFO - 2021-11-25 10:40:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 10:40:57 --> Final output sent to browser
DEBUG - 2021-11-25 10:40:57 --> Total execution time: 0.0324
ERROR - 2021-11-25 11:56:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 11:56:20 --> Config Class Initialized
INFO - 2021-11-25 11:56:20 --> Hooks Class Initialized
DEBUG - 2021-11-25 11:56:20 --> UTF-8 Support Enabled
INFO - 2021-11-25 11:56:20 --> Utf8 Class Initialized
INFO - 2021-11-25 11:56:20 --> URI Class Initialized
DEBUG - 2021-11-25 11:56:20 --> No URI present. Default controller set.
INFO - 2021-11-25 11:56:20 --> Router Class Initialized
INFO - 2021-11-25 11:56:20 --> Output Class Initialized
INFO - 2021-11-25 11:56:20 --> Security Class Initialized
DEBUG - 2021-11-25 11:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 11:56:20 --> Input Class Initialized
INFO - 2021-11-25 11:56:20 --> Language Class Initialized
INFO - 2021-11-25 11:56:20 --> Loader Class Initialized
INFO - 2021-11-25 11:56:20 --> Helper loaded: url_helper
INFO - 2021-11-25 11:56:20 --> Helper loaded: form_helper
INFO - 2021-11-25 11:56:20 --> Helper loaded: common_helper
INFO - 2021-11-25 11:56:20 --> Database Driver Class Initialized
DEBUG - 2021-11-25 11:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 11:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 11:56:20 --> Controller Class Initialized
INFO - 2021-11-25 11:56:20 --> Form Validation Class Initialized
DEBUG - 2021-11-25 11:56:20 --> Encrypt Class Initialized
DEBUG - 2021-11-25 11:56:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 11:56:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 11:56:20 --> Email Class Initialized
INFO - 2021-11-25 11:56:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 11:56:20 --> Calendar Class Initialized
INFO - 2021-11-25 11:56:20 --> Model "Login_model" initialized
INFO - 2021-11-25 11:56:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 11:56:20 --> Final output sent to browser
DEBUG - 2021-11-25 11:56:20 --> Total execution time: 0.0334
ERROR - 2021-11-25 11:59:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 11:59:27 --> Config Class Initialized
INFO - 2021-11-25 11:59:27 --> Hooks Class Initialized
DEBUG - 2021-11-25 11:59:27 --> UTF-8 Support Enabled
INFO - 2021-11-25 11:59:27 --> Utf8 Class Initialized
INFO - 2021-11-25 11:59:27 --> URI Class Initialized
DEBUG - 2021-11-25 11:59:27 --> No URI present. Default controller set.
INFO - 2021-11-25 11:59:27 --> Router Class Initialized
INFO - 2021-11-25 11:59:27 --> Output Class Initialized
INFO - 2021-11-25 11:59:27 --> Security Class Initialized
DEBUG - 2021-11-25 11:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 11:59:27 --> Input Class Initialized
INFO - 2021-11-25 11:59:27 --> Language Class Initialized
INFO - 2021-11-25 11:59:27 --> Loader Class Initialized
INFO - 2021-11-25 11:59:27 --> Helper loaded: url_helper
INFO - 2021-11-25 11:59:27 --> Helper loaded: form_helper
INFO - 2021-11-25 11:59:27 --> Helper loaded: common_helper
INFO - 2021-11-25 11:59:27 --> Database Driver Class Initialized
DEBUG - 2021-11-25 11:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 11:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 11:59:27 --> Controller Class Initialized
INFO - 2021-11-25 11:59:27 --> Form Validation Class Initialized
DEBUG - 2021-11-25 11:59:27 --> Encrypt Class Initialized
DEBUG - 2021-11-25 11:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 11:59:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 11:59:27 --> Email Class Initialized
INFO - 2021-11-25 11:59:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 11:59:27 --> Calendar Class Initialized
INFO - 2021-11-25 11:59:27 --> Model "Login_model" initialized
INFO - 2021-11-25 11:59:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 11:59:27 --> Final output sent to browser
DEBUG - 2021-11-25 11:59:27 --> Total execution time: 0.0227
ERROR - 2021-11-25 12:00:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 12:00:53 --> Config Class Initialized
INFO - 2021-11-25 12:00:53 --> Hooks Class Initialized
DEBUG - 2021-11-25 12:00:53 --> UTF-8 Support Enabled
INFO - 2021-11-25 12:00:53 --> Utf8 Class Initialized
INFO - 2021-11-25 12:00:53 --> URI Class Initialized
DEBUG - 2021-11-25 12:00:53 --> No URI present. Default controller set.
INFO - 2021-11-25 12:00:53 --> Router Class Initialized
INFO - 2021-11-25 12:00:53 --> Output Class Initialized
INFO - 2021-11-25 12:00:53 --> Security Class Initialized
DEBUG - 2021-11-25 12:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 12:00:53 --> Input Class Initialized
INFO - 2021-11-25 12:00:53 --> Language Class Initialized
INFO - 2021-11-25 12:00:53 --> Loader Class Initialized
INFO - 2021-11-25 12:00:53 --> Helper loaded: url_helper
INFO - 2021-11-25 12:00:53 --> Helper loaded: form_helper
INFO - 2021-11-25 12:00:53 --> Helper loaded: common_helper
INFO - 2021-11-25 12:00:53 --> Database Driver Class Initialized
DEBUG - 2021-11-25 12:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 12:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 12:00:53 --> Controller Class Initialized
INFO - 2021-11-25 12:00:53 --> Form Validation Class Initialized
DEBUG - 2021-11-25 12:00:53 --> Encrypt Class Initialized
DEBUG - 2021-11-25 12:00:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 12:00:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 12:00:53 --> Email Class Initialized
INFO - 2021-11-25 12:00:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 12:00:53 --> Calendar Class Initialized
INFO - 2021-11-25 12:00:53 --> Model "Login_model" initialized
INFO - 2021-11-25 12:00:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 12:00:53 --> Final output sent to browser
DEBUG - 2021-11-25 12:00:53 --> Total execution time: 0.0281
ERROR - 2021-11-25 12:04:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 12:04:47 --> Config Class Initialized
INFO - 2021-11-25 12:04:47 --> Hooks Class Initialized
DEBUG - 2021-11-25 12:04:47 --> UTF-8 Support Enabled
INFO - 2021-11-25 12:04:47 --> Utf8 Class Initialized
INFO - 2021-11-25 12:04:47 --> URI Class Initialized
DEBUG - 2021-11-25 12:04:47 --> No URI present. Default controller set.
INFO - 2021-11-25 12:04:47 --> Router Class Initialized
INFO - 2021-11-25 12:04:47 --> Output Class Initialized
INFO - 2021-11-25 12:04:47 --> Security Class Initialized
DEBUG - 2021-11-25 12:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 12:04:47 --> Input Class Initialized
INFO - 2021-11-25 12:04:47 --> Language Class Initialized
INFO - 2021-11-25 12:04:47 --> Loader Class Initialized
INFO - 2021-11-25 12:04:47 --> Helper loaded: url_helper
INFO - 2021-11-25 12:04:47 --> Helper loaded: form_helper
INFO - 2021-11-25 12:04:47 --> Helper loaded: common_helper
INFO - 2021-11-25 12:04:47 --> Database Driver Class Initialized
DEBUG - 2021-11-25 12:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 12:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 12:04:47 --> Controller Class Initialized
INFO - 2021-11-25 12:04:47 --> Form Validation Class Initialized
DEBUG - 2021-11-25 12:04:47 --> Encrypt Class Initialized
DEBUG - 2021-11-25 12:04:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 12:04:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 12:04:47 --> Email Class Initialized
INFO - 2021-11-25 12:04:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 12:04:47 --> Calendar Class Initialized
INFO - 2021-11-25 12:04:47 --> Model "Login_model" initialized
INFO - 2021-11-25 12:04:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 12:04:47 --> Final output sent to browser
DEBUG - 2021-11-25 12:04:47 --> Total execution time: 0.0359
ERROR - 2021-11-25 12:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 12:05:39 --> Config Class Initialized
INFO - 2021-11-25 12:05:39 --> Hooks Class Initialized
DEBUG - 2021-11-25 12:05:39 --> UTF-8 Support Enabled
INFO - 2021-11-25 12:05:39 --> Utf8 Class Initialized
INFO - 2021-11-25 12:05:39 --> URI Class Initialized
DEBUG - 2021-11-25 12:05:39 --> No URI present. Default controller set.
INFO - 2021-11-25 12:05:39 --> Router Class Initialized
INFO - 2021-11-25 12:05:39 --> Output Class Initialized
INFO - 2021-11-25 12:05:39 --> Security Class Initialized
DEBUG - 2021-11-25 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 12:05:39 --> Input Class Initialized
INFO - 2021-11-25 12:05:39 --> Language Class Initialized
INFO - 2021-11-25 12:05:39 --> Loader Class Initialized
INFO - 2021-11-25 12:05:39 --> Helper loaded: url_helper
INFO - 2021-11-25 12:05:39 --> Helper loaded: form_helper
INFO - 2021-11-25 12:05:39 --> Helper loaded: common_helper
INFO - 2021-11-25 12:05:39 --> Database Driver Class Initialized
DEBUG - 2021-11-25 12:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 12:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 12:05:39 --> Controller Class Initialized
INFO - 2021-11-25 12:05:39 --> Form Validation Class Initialized
DEBUG - 2021-11-25 12:05:39 --> Encrypt Class Initialized
DEBUG - 2021-11-25 12:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 12:05:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 12:05:39 --> Email Class Initialized
INFO - 2021-11-25 12:05:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 12:05:39 --> Calendar Class Initialized
INFO - 2021-11-25 12:05:39 --> Model "Login_model" initialized
INFO - 2021-11-25 12:05:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 12:05:39 --> Final output sent to browser
DEBUG - 2021-11-25 12:05:39 --> Total execution time: 0.0308
ERROR - 2021-11-25 12:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 12:05:40 --> Config Class Initialized
INFO - 2021-11-25 12:05:40 --> Hooks Class Initialized
DEBUG - 2021-11-25 12:05:40 --> UTF-8 Support Enabled
INFO - 2021-11-25 12:05:40 --> Utf8 Class Initialized
INFO - 2021-11-25 12:05:40 --> URI Class Initialized
DEBUG - 2021-11-25 12:05:40 --> No URI present. Default controller set.
INFO - 2021-11-25 12:05:40 --> Router Class Initialized
INFO - 2021-11-25 12:05:40 --> Output Class Initialized
INFO - 2021-11-25 12:05:40 --> Security Class Initialized
DEBUG - 2021-11-25 12:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 12:05:40 --> Input Class Initialized
INFO - 2021-11-25 12:05:40 --> Language Class Initialized
INFO - 2021-11-25 12:05:40 --> Loader Class Initialized
INFO - 2021-11-25 12:05:40 --> Helper loaded: url_helper
INFO - 2021-11-25 12:05:40 --> Helper loaded: form_helper
INFO - 2021-11-25 12:05:40 --> Helper loaded: common_helper
INFO - 2021-11-25 12:05:40 --> Database Driver Class Initialized
DEBUG - 2021-11-25 12:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 12:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 12:05:40 --> Controller Class Initialized
INFO - 2021-11-25 12:05:40 --> Form Validation Class Initialized
DEBUG - 2021-11-25 12:05:40 --> Encrypt Class Initialized
DEBUG - 2021-11-25 12:05:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 12:05:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 12:05:40 --> Email Class Initialized
INFO - 2021-11-25 12:05:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 12:05:40 --> Calendar Class Initialized
INFO - 2021-11-25 12:05:40 --> Model "Login_model" initialized
INFO - 2021-11-25 12:05:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 12:05:40 --> Final output sent to browser
DEBUG - 2021-11-25 12:05:40 --> Total execution time: 0.0271
ERROR - 2021-11-25 12:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 12:06:42 --> Config Class Initialized
INFO - 2021-11-25 12:06:42 --> Hooks Class Initialized
DEBUG - 2021-11-25 12:06:42 --> UTF-8 Support Enabled
INFO - 2021-11-25 12:06:42 --> Utf8 Class Initialized
INFO - 2021-11-25 12:06:42 --> URI Class Initialized
DEBUG - 2021-11-25 12:06:42 --> No URI present. Default controller set.
INFO - 2021-11-25 12:06:42 --> Router Class Initialized
INFO - 2021-11-25 12:06:42 --> Output Class Initialized
INFO - 2021-11-25 12:06:42 --> Security Class Initialized
DEBUG - 2021-11-25 12:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 12:06:42 --> Input Class Initialized
INFO - 2021-11-25 12:06:42 --> Language Class Initialized
INFO - 2021-11-25 12:06:42 --> Loader Class Initialized
INFO - 2021-11-25 12:06:42 --> Helper loaded: url_helper
INFO - 2021-11-25 12:06:42 --> Helper loaded: form_helper
INFO - 2021-11-25 12:06:42 --> Helper loaded: common_helper
INFO - 2021-11-25 12:06:42 --> Database Driver Class Initialized
DEBUG - 2021-11-25 12:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 12:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 12:06:42 --> Controller Class Initialized
INFO - 2021-11-25 12:06:42 --> Form Validation Class Initialized
DEBUG - 2021-11-25 12:06:42 --> Encrypt Class Initialized
DEBUG - 2021-11-25 12:06:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 12:06:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 12:06:42 --> Email Class Initialized
INFO - 2021-11-25 12:06:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 12:06:42 --> Calendar Class Initialized
INFO - 2021-11-25 12:06:42 --> Model "Login_model" initialized
INFO - 2021-11-25 12:06:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 12:06:42 --> Final output sent to browser
DEBUG - 2021-11-25 12:06:42 --> Total execution time: 0.0218
ERROR - 2021-11-25 12:07:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 12:07:10 --> Config Class Initialized
INFO - 2021-11-25 12:07:10 --> Hooks Class Initialized
DEBUG - 2021-11-25 12:07:10 --> UTF-8 Support Enabled
INFO - 2021-11-25 12:07:10 --> Utf8 Class Initialized
INFO - 2021-11-25 12:07:10 --> URI Class Initialized
DEBUG - 2021-11-25 12:07:10 --> No URI present. Default controller set.
INFO - 2021-11-25 12:07:10 --> Router Class Initialized
INFO - 2021-11-25 12:07:10 --> Output Class Initialized
INFO - 2021-11-25 12:07:10 --> Security Class Initialized
DEBUG - 2021-11-25 12:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 12:07:10 --> Input Class Initialized
INFO - 2021-11-25 12:07:10 --> Language Class Initialized
INFO - 2021-11-25 12:07:10 --> Loader Class Initialized
INFO - 2021-11-25 12:07:10 --> Helper loaded: url_helper
INFO - 2021-11-25 12:07:10 --> Helper loaded: form_helper
INFO - 2021-11-25 12:07:10 --> Helper loaded: common_helper
INFO - 2021-11-25 12:07:10 --> Database Driver Class Initialized
DEBUG - 2021-11-25 12:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 12:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 12:07:10 --> Controller Class Initialized
INFO - 2021-11-25 12:07:10 --> Form Validation Class Initialized
DEBUG - 2021-11-25 12:07:10 --> Encrypt Class Initialized
DEBUG - 2021-11-25 12:07:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 12:07:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 12:07:10 --> Email Class Initialized
INFO - 2021-11-25 12:07:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 12:07:10 --> Calendar Class Initialized
INFO - 2021-11-25 12:07:10 --> Model "Login_model" initialized
INFO - 2021-11-25 12:07:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 12:07:10 --> Final output sent to browser
DEBUG - 2021-11-25 12:07:10 --> Total execution time: 0.0343
ERROR - 2021-11-25 12:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 12:48:55 --> Config Class Initialized
INFO - 2021-11-25 12:48:55 --> Hooks Class Initialized
DEBUG - 2021-11-25 12:48:55 --> UTF-8 Support Enabled
INFO - 2021-11-25 12:48:55 --> Utf8 Class Initialized
INFO - 2021-11-25 12:48:55 --> URI Class Initialized
DEBUG - 2021-11-25 12:48:55 --> No URI present. Default controller set.
INFO - 2021-11-25 12:48:55 --> Router Class Initialized
INFO - 2021-11-25 12:48:55 --> Output Class Initialized
INFO - 2021-11-25 12:48:55 --> Security Class Initialized
DEBUG - 2021-11-25 12:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 12:48:55 --> Input Class Initialized
INFO - 2021-11-25 12:48:55 --> Language Class Initialized
INFO - 2021-11-25 12:48:55 --> Loader Class Initialized
INFO - 2021-11-25 12:48:55 --> Helper loaded: url_helper
INFO - 2021-11-25 12:48:55 --> Helper loaded: form_helper
INFO - 2021-11-25 12:48:55 --> Helper loaded: common_helper
INFO - 2021-11-25 12:48:55 --> Database Driver Class Initialized
DEBUG - 2021-11-25 12:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 12:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 12:48:55 --> Controller Class Initialized
INFO - 2021-11-25 12:48:55 --> Form Validation Class Initialized
DEBUG - 2021-11-25 12:48:55 --> Encrypt Class Initialized
DEBUG - 2021-11-25 12:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 12:48:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 12:48:55 --> Email Class Initialized
INFO - 2021-11-25 12:48:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 12:48:55 --> Calendar Class Initialized
INFO - 2021-11-25 12:48:55 --> Model "Login_model" initialized
INFO - 2021-11-25 12:48:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 12:48:55 --> Final output sent to browser
DEBUG - 2021-11-25 12:48:55 --> Total execution time: 0.0362
ERROR - 2021-11-25 12:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 12:50:06 --> Config Class Initialized
INFO - 2021-11-25 12:50:06 --> Hooks Class Initialized
DEBUG - 2021-11-25 12:50:06 --> UTF-8 Support Enabled
INFO - 2021-11-25 12:50:06 --> Utf8 Class Initialized
INFO - 2021-11-25 12:50:06 --> URI Class Initialized
DEBUG - 2021-11-25 12:50:06 --> No URI present. Default controller set.
INFO - 2021-11-25 12:50:06 --> Router Class Initialized
INFO - 2021-11-25 12:50:06 --> Output Class Initialized
INFO - 2021-11-25 12:50:06 --> Security Class Initialized
DEBUG - 2021-11-25 12:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 12:50:06 --> Input Class Initialized
INFO - 2021-11-25 12:50:06 --> Language Class Initialized
INFO - 2021-11-25 12:50:06 --> Loader Class Initialized
INFO - 2021-11-25 12:50:06 --> Helper loaded: url_helper
INFO - 2021-11-25 12:50:06 --> Helper loaded: form_helper
INFO - 2021-11-25 12:50:06 --> Helper loaded: common_helper
INFO - 2021-11-25 12:50:06 --> Database Driver Class Initialized
DEBUG - 2021-11-25 12:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 12:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 12:50:06 --> Controller Class Initialized
INFO - 2021-11-25 12:50:06 --> Form Validation Class Initialized
DEBUG - 2021-11-25 12:50:06 --> Encrypt Class Initialized
DEBUG - 2021-11-25 12:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 12:50:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 12:50:06 --> Email Class Initialized
INFO - 2021-11-25 12:50:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 12:50:06 --> Calendar Class Initialized
INFO - 2021-11-25 12:50:06 --> Model "Login_model" initialized
INFO - 2021-11-25 12:50:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 12:50:06 --> Final output sent to browser
DEBUG - 2021-11-25 12:50:06 --> Total execution time: 0.0318
ERROR - 2021-11-25 14:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 14:20:29 --> Config Class Initialized
INFO - 2021-11-25 14:20:29 --> Hooks Class Initialized
DEBUG - 2021-11-25 14:20:29 --> UTF-8 Support Enabled
INFO - 2021-11-25 14:20:29 --> Utf8 Class Initialized
INFO - 2021-11-25 14:20:29 --> URI Class Initialized
DEBUG - 2021-11-25 14:20:29 --> No URI present. Default controller set.
INFO - 2021-11-25 14:20:29 --> Router Class Initialized
INFO - 2021-11-25 14:20:29 --> Output Class Initialized
INFO - 2021-11-25 14:20:29 --> Security Class Initialized
DEBUG - 2021-11-25 14:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 14:20:29 --> Input Class Initialized
INFO - 2021-11-25 14:20:29 --> Language Class Initialized
INFO - 2021-11-25 14:20:29 --> Loader Class Initialized
INFO - 2021-11-25 14:20:29 --> Helper loaded: url_helper
INFO - 2021-11-25 14:20:29 --> Helper loaded: form_helper
INFO - 2021-11-25 14:20:29 --> Helper loaded: common_helper
INFO - 2021-11-25 14:20:29 --> Database Driver Class Initialized
DEBUG - 2021-11-25 14:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 14:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 14:20:29 --> Controller Class Initialized
INFO - 2021-11-25 14:20:29 --> Form Validation Class Initialized
DEBUG - 2021-11-25 14:20:29 --> Encrypt Class Initialized
DEBUG - 2021-11-25 14:20:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 14:20:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 14:20:29 --> Email Class Initialized
INFO - 2021-11-25 14:20:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 14:20:29 --> Calendar Class Initialized
INFO - 2021-11-25 14:20:29 --> Model "Login_model" initialized
INFO - 2021-11-25 14:20:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 14:20:29 --> Final output sent to browser
DEBUG - 2021-11-25 14:20:29 --> Total execution time: 0.0250
ERROR - 2021-11-25 14:32:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 14:32:35 --> Config Class Initialized
INFO - 2021-11-25 14:32:35 --> Hooks Class Initialized
DEBUG - 2021-11-25 14:32:35 --> UTF-8 Support Enabled
INFO - 2021-11-25 14:32:35 --> Utf8 Class Initialized
INFO - 2021-11-25 14:32:35 --> URI Class Initialized
DEBUG - 2021-11-25 14:32:35 --> No URI present. Default controller set.
INFO - 2021-11-25 14:32:35 --> Router Class Initialized
INFO - 2021-11-25 14:32:35 --> Output Class Initialized
INFO - 2021-11-25 14:32:35 --> Security Class Initialized
DEBUG - 2021-11-25 14:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 14:32:35 --> Input Class Initialized
INFO - 2021-11-25 14:32:35 --> Language Class Initialized
INFO - 2021-11-25 14:32:35 --> Loader Class Initialized
INFO - 2021-11-25 14:32:35 --> Helper loaded: url_helper
INFO - 2021-11-25 14:32:35 --> Helper loaded: form_helper
INFO - 2021-11-25 14:32:35 --> Helper loaded: common_helper
INFO - 2021-11-25 14:32:35 --> Database Driver Class Initialized
DEBUG - 2021-11-25 14:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 14:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 14:32:35 --> Controller Class Initialized
INFO - 2021-11-25 14:32:35 --> Form Validation Class Initialized
DEBUG - 2021-11-25 14:32:35 --> Encrypt Class Initialized
DEBUG - 2021-11-25 14:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 14:32:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 14:32:35 --> Email Class Initialized
INFO - 2021-11-25 14:32:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 14:32:35 --> Calendar Class Initialized
INFO - 2021-11-25 14:32:35 --> Model "Login_model" initialized
INFO - 2021-11-25 14:32:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 14:32:35 --> Final output sent to browser
DEBUG - 2021-11-25 14:32:35 --> Total execution time: 0.0256
ERROR - 2021-11-25 14:54:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 14:54:15 --> Config Class Initialized
INFO - 2021-11-25 14:54:15 --> Hooks Class Initialized
DEBUG - 2021-11-25 14:54:15 --> UTF-8 Support Enabled
INFO - 2021-11-25 14:54:15 --> Utf8 Class Initialized
INFO - 2021-11-25 14:54:15 --> URI Class Initialized
DEBUG - 2021-11-25 14:54:15 --> No URI present. Default controller set.
INFO - 2021-11-25 14:54:15 --> Router Class Initialized
INFO - 2021-11-25 14:54:15 --> Output Class Initialized
INFO - 2021-11-25 14:54:15 --> Security Class Initialized
DEBUG - 2021-11-25 14:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 14:54:15 --> Input Class Initialized
INFO - 2021-11-25 14:54:15 --> Language Class Initialized
INFO - 2021-11-25 14:54:15 --> Loader Class Initialized
INFO - 2021-11-25 14:54:15 --> Helper loaded: url_helper
INFO - 2021-11-25 14:54:15 --> Helper loaded: form_helper
INFO - 2021-11-25 14:54:15 --> Helper loaded: common_helper
INFO - 2021-11-25 14:54:15 --> Database Driver Class Initialized
DEBUG - 2021-11-25 14:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 14:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 14:54:15 --> Controller Class Initialized
INFO - 2021-11-25 14:54:15 --> Form Validation Class Initialized
DEBUG - 2021-11-25 14:54:15 --> Encrypt Class Initialized
DEBUG - 2021-11-25 14:54:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 14:54:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 14:54:15 --> Email Class Initialized
INFO - 2021-11-25 14:54:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 14:54:15 --> Calendar Class Initialized
INFO - 2021-11-25 14:54:15 --> Model "Login_model" initialized
INFO - 2021-11-25 14:54:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 14:54:15 --> Final output sent to browser
DEBUG - 2021-11-25 14:54:15 --> Total execution time: 0.0237
ERROR - 2021-11-25 16:30:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 16:30:25 --> Config Class Initialized
INFO - 2021-11-25 16:30:25 --> Hooks Class Initialized
DEBUG - 2021-11-25 16:30:25 --> UTF-8 Support Enabled
INFO - 2021-11-25 16:30:25 --> Utf8 Class Initialized
INFO - 2021-11-25 16:30:25 --> URI Class Initialized
DEBUG - 2021-11-25 16:30:25 --> No URI present. Default controller set.
INFO - 2021-11-25 16:30:25 --> Router Class Initialized
INFO - 2021-11-25 16:30:25 --> Output Class Initialized
INFO - 2021-11-25 16:30:25 --> Security Class Initialized
DEBUG - 2021-11-25 16:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 16:30:25 --> Input Class Initialized
INFO - 2021-11-25 16:30:25 --> Language Class Initialized
INFO - 2021-11-25 16:30:25 --> Loader Class Initialized
INFO - 2021-11-25 16:30:25 --> Helper loaded: url_helper
INFO - 2021-11-25 16:30:25 --> Helper loaded: form_helper
INFO - 2021-11-25 16:30:25 --> Helper loaded: common_helper
INFO - 2021-11-25 16:30:25 --> Database Driver Class Initialized
DEBUG - 2021-11-25 16:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 16:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 16:30:25 --> Controller Class Initialized
INFO - 2021-11-25 16:30:25 --> Form Validation Class Initialized
DEBUG - 2021-11-25 16:30:25 --> Encrypt Class Initialized
DEBUG - 2021-11-25 16:30:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 16:30:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 16:30:25 --> Email Class Initialized
INFO - 2021-11-25 16:30:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 16:30:25 --> Calendar Class Initialized
INFO - 2021-11-25 16:30:25 --> Model "Login_model" initialized
INFO - 2021-11-25 16:30:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 16:30:25 --> Final output sent to browser
DEBUG - 2021-11-25 16:30:25 --> Total execution time: 0.3184
ERROR - 2021-11-25 20:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 20:39:59 --> Config Class Initialized
INFO - 2021-11-25 20:39:59 --> Hooks Class Initialized
DEBUG - 2021-11-25 20:39:59 --> UTF-8 Support Enabled
INFO - 2021-11-25 20:39:59 --> Utf8 Class Initialized
INFO - 2021-11-25 20:39:59 --> URI Class Initialized
DEBUG - 2021-11-25 20:39:59 --> No URI present. Default controller set.
INFO - 2021-11-25 20:39:59 --> Router Class Initialized
INFO - 2021-11-25 20:39:59 --> Output Class Initialized
INFO - 2021-11-25 20:39:59 --> Security Class Initialized
DEBUG - 2021-11-25 20:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 20:39:59 --> Input Class Initialized
INFO - 2021-11-25 20:39:59 --> Language Class Initialized
INFO - 2021-11-25 20:39:59 --> Loader Class Initialized
INFO - 2021-11-25 20:39:59 --> Helper loaded: url_helper
INFO - 2021-11-25 20:39:59 --> Helper loaded: form_helper
INFO - 2021-11-25 20:39:59 --> Helper loaded: common_helper
INFO - 2021-11-25 20:39:59 --> Database Driver Class Initialized
DEBUG - 2021-11-25 20:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 20:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 20:39:59 --> Controller Class Initialized
INFO - 2021-11-25 20:39:59 --> Form Validation Class Initialized
DEBUG - 2021-11-25 20:39:59 --> Encrypt Class Initialized
DEBUG - 2021-11-25 20:39:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 20:39:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 20:39:59 --> Email Class Initialized
INFO - 2021-11-25 20:39:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 20:39:59 --> Calendar Class Initialized
INFO - 2021-11-25 20:39:59 --> Model "Login_model" initialized
INFO - 2021-11-25 20:39:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 20:39:59 --> Final output sent to browser
DEBUG - 2021-11-25 20:39:59 --> Total execution time: 0.0297
ERROR - 2021-11-25 23:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 23:18:54 --> Config Class Initialized
INFO - 2021-11-25 23:18:54 --> Hooks Class Initialized
DEBUG - 2021-11-25 23:18:54 --> UTF-8 Support Enabled
INFO - 2021-11-25 23:18:54 --> Utf8 Class Initialized
INFO - 2021-11-25 23:18:54 --> URI Class Initialized
DEBUG - 2021-11-25 23:18:54 --> No URI present. Default controller set.
INFO - 2021-11-25 23:18:54 --> Router Class Initialized
INFO - 2021-11-25 23:18:54 --> Output Class Initialized
INFO - 2021-11-25 23:18:54 --> Security Class Initialized
DEBUG - 2021-11-25 23:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 23:18:54 --> Input Class Initialized
INFO - 2021-11-25 23:18:54 --> Language Class Initialized
INFO - 2021-11-25 23:18:54 --> Loader Class Initialized
INFO - 2021-11-25 23:18:54 --> Helper loaded: url_helper
INFO - 2021-11-25 23:18:54 --> Helper loaded: form_helper
INFO - 2021-11-25 23:18:54 --> Helper loaded: common_helper
INFO - 2021-11-25 23:18:54 --> Database Driver Class Initialized
DEBUG - 2021-11-25 23:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 23:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 23:18:54 --> Controller Class Initialized
INFO - 2021-11-25 23:18:54 --> Form Validation Class Initialized
DEBUG - 2021-11-25 23:18:54 --> Encrypt Class Initialized
DEBUG - 2021-11-25 23:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 23:18:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 23:18:54 --> Email Class Initialized
INFO - 2021-11-25 23:18:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 23:18:54 --> Calendar Class Initialized
INFO - 2021-11-25 23:18:54 --> Model "Login_model" initialized
INFO - 2021-11-25 23:18:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 23:18:54 --> Final output sent to browser
DEBUG - 2021-11-25 23:18:54 --> Total execution time: 0.0304
ERROR - 2021-11-25 23:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-25 23:20:40 --> Config Class Initialized
INFO - 2021-11-25 23:20:40 --> Hooks Class Initialized
DEBUG - 2021-11-25 23:20:40 --> UTF-8 Support Enabled
INFO - 2021-11-25 23:20:40 --> Utf8 Class Initialized
INFO - 2021-11-25 23:20:40 --> URI Class Initialized
DEBUG - 2021-11-25 23:20:40 --> No URI present. Default controller set.
INFO - 2021-11-25 23:20:40 --> Router Class Initialized
INFO - 2021-11-25 23:20:40 --> Output Class Initialized
INFO - 2021-11-25 23:20:40 --> Security Class Initialized
DEBUG - 2021-11-25 23:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-25 23:20:40 --> Input Class Initialized
INFO - 2021-11-25 23:20:40 --> Language Class Initialized
INFO - 2021-11-25 23:20:40 --> Loader Class Initialized
INFO - 2021-11-25 23:20:40 --> Helper loaded: url_helper
INFO - 2021-11-25 23:20:40 --> Helper loaded: form_helper
INFO - 2021-11-25 23:20:40 --> Helper loaded: common_helper
INFO - 2021-11-25 23:20:40 --> Database Driver Class Initialized
DEBUG - 2021-11-25 23:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-25 23:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-25 23:20:40 --> Controller Class Initialized
INFO - 2021-11-25 23:20:40 --> Form Validation Class Initialized
DEBUG - 2021-11-25 23:20:40 --> Encrypt Class Initialized
DEBUG - 2021-11-25 23:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 23:20:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-25 23:20:40 --> Email Class Initialized
INFO - 2021-11-25 23:20:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-25 23:20:40 --> Calendar Class Initialized
INFO - 2021-11-25 23:20:40 --> Model "Login_model" initialized
INFO - 2021-11-25 23:20:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-25 23:20:40 --> Final output sent to browser
DEBUG - 2021-11-25 23:20:40 --> Total execution time: 0.0236
