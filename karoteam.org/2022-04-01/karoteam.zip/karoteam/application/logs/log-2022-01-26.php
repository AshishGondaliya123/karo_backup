<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-26 06:18:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 06:18:11 --> Config Class Initialized
INFO - 2022-01-26 06:18:11 --> Hooks Class Initialized
DEBUG - 2022-01-26 06:18:11 --> UTF-8 Support Enabled
INFO - 2022-01-26 06:18:11 --> Utf8 Class Initialized
INFO - 2022-01-26 06:18:11 --> URI Class Initialized
DEBUG - 2022-01-26 06:18:11 --> No URI present. Default controller set.
INFO - 2022-01-26 06:18:11 --> Router Class Initialized
INFO - 2022-01-26 06:18:11 --> Output Class Initialized
INFO - 2022-01-26 06:18:11 --> Security Class Initialized
DEBUG - 2022-01-26 06:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 06:18:11 --> Input Class Initialized
INFO - 2022-01-26 06:18:11 --> Language Class Initialized
INFO - 2022-01-26 06:18:11 --> Loader Class Initialized
INFO - 2022-01-26 06:18:11 --> Helper loaded: url_helper
INFO - 2022-01-26 06:18:11 --> Helper loaded: form_helper
INFO - 2022-01-26 06:18:11 --> Helper loaded: common_helper
INFO - 2022-01-26 06:18:11 --> Database Driver Class Initialized
DEBUG - 2022-01-26 06:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 06:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 06:18:11 --> Controller Class Initialized
INFO - 2022-01-26 06:18:11 --> Form Validation Class Initialized
DEBUG - 2022-01-26 06:18:11 --> Encrypt Class Initialized
DEBUG - 2022-01-26 06:18:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 06:18:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 06:18:11 --> Email Class Initialized
INFO - 2022-01-26 06:18:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 06:18:11 --> Calendar Class Initialized
INFO - 2022-01-26 06:18:11 --> Model "Login_model" initialized
INFO - 2022-01-26 06:18:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 06:18:11 --> Final output sent to browser
DEBUG - 2022-01-26 06:18:11 --> Total execution time: 0.0228
ERROR - 2022-01-26 09:25:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:25:58 --> Config Class Initialized
INFO - 2022-01-26 09:25:58 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:25:58 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:25:58 --> Utf8 Class Initialized
INFO - 2022-01-26 09:25:58 --> URI Class Initialized
DEBUG - 2022-01-26 09:25:58 --> No URI present. Default controller set.
INFO - 2022-01-26 09:25:58 --> Router Class Initialized
INFO - 2022-01-26 09:25:58 --> Output Class Initialized
INFO - 2022-01-26 09:25:58 --> Security Class Initialized
DEBUG - 2022-01-26 09:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:25:58 --> Input Class Initialized
INFO - 2022-01-26 09:25:58 --> Language Class Initialized
INFO - 2022-01-26 09:25:58 --> Loader Class Initialized
INFO - 2022-01-26 09:25:58 --> Helper loaded: url_helper
INFO - 2022-01-26 09:25:58 --> Helper loaded: form_helper
INFO - 2022-01-26 09:25:58 --> Helper loaded: common_helper
INFO - 2022-01-26 09:25:58 --> Database Driver Class Initialized
DEBUG - 2022-01-26 09:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 09:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 09:25:58 --> Controller Class Initialized
INFO - 2022-01-26 09:25:58 --> Form Validation Class Initialized
DEBUG - 2022-01-26 09:25:58 --> Encrypt Class Initialized
DEBUG - 2022-01-26 09:25:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 09:25:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 09:25:58 --> Email Class Initialized
INFO - 2022-01-26 09:25:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 09:25:58 --> Calendar Class Initialized
INFO - 2022-01-26 09:25:58 --> Model "Login_model" initialized
INFO - 2022-01-26 09:25:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 09:25:58 --> Final output sent to browser
DEBUG - 2022-01-26 09:25:58 --> Total execution time: 0.0392
ERROR - 2022-01-26 09:25:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:25:59 --> Config Class Initialized
INFO - 2022-01-26 09:25:59 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:25:59 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:25:59 --> Utf8 Class Initialized
INFO - 2022-01-26 09:25:59 --> URI Class Initialized
INFO - 2022-01-26 09:25:59 --> Router Class Initialized
INFO - 2022-01-26 09:25:59 --> Output Class Initialized
INFO - 2022-01-26 09:25:59 --> Security Class Initialized
DEBUG - 2022-01-26 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:25:59 --> Input Class Initialized
INFO - 2022-01-26 09:25:59 --> Language Class Initialized
ERROR - 2022-01-26 09:25:59 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2022-01-26 09:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:00 --> Config Class Initialized
INFO - 2022-01-26 09:26:00 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:00 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:00 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:00 --> URI Class Initialized
DEBUG - 2022-01-26 09:26:00 --> No URI present. Default controller set.
INFO - 2022-01-26 09:26:00 --> Router Class Initialized
INFO - 2022-01-26 09:26:00 --> Output Class Initialized
INFO - 2022-01-26 09:26:00 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:00 --> Input Class Initialized
INFO - 2022-01-26 09:26:00 --> Language Class Initialized
INFO - 2022-01-26 09:26:00 --> Loader Class Initialized
INFO - 2022-01-26 09:26:00 --> Helper loaded: url_helper
INFO - 2022-01-26 09:26:00 --> Helper loaded: form_helper
INFO - 2022-01-26 09:26:00 --> Helper loaded: common_helper
INFO - 2022-01-26 09:26:00 --> Database Driver Class Initialized
DEBUG - 2022-01-26 09:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 09:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 09:26:00 --> Controller Class Initialized
INFO - 2022-01-26 09:26:00 --> Form Validation Class Initialized
DEBUG - 2022-01-26 09:26:00 --> Encrypt Class Initialized
DEBUG - 2022-01-26 09:26:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 09:26:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 09:26:00 --> Email Class Initialized
INFO - 2022-01-26 09:26:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 09:26:00 --> Calendar Class Initialized
INFO - 2022-01-26 09:26:00 --> Model "Login_model" initialized
INFO - 2022-01-26 09:26:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 09:26:00 --> Final output sent to browser
DEBUG - 2022-01-26 09:26:00 --> Total execution time: 0.0454
ERROR - 2022-01-26 09:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:00 --> Config Class Initialized
INFO - 2022-01-26 09:26:00 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:00 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:00 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:00 --> URI Class Initialized
INFO - 2022-01-26 09:26:00 --> Router Class Initialized
INFO - 2022-01-26 09:26:00 --> Output Class Initialized
INFO - 2022-01-26 09:26:00 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:00 --> Input Class Initialized
INFO - 2022-01-26 09:26:00 --> Language Class Initialized
ERROR - 2022-01-26 09:26:00 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-01-26 09:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:01 --> Config Class Initialized
INFO - 2022-01-26 09:26:01 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:01 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:01 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:01 --> URI Class Initialized
INFO - 2022-01-26 09:26:01 --> Router Class Initialized
INFO - 2022-01-26 09:26:01 --> Output Class Initialized
INFO - 2022-01-26 09:26:01 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:01 --> Input Class Initialized
INFO - 2022-01-26 09:26:01 --> Language Class Initialized
ERROR - 2022-01-26 09:26:01 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-01-26 09:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:02 --> Config Class Initialized
INFO - 2022-01-26 09:26:02 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:02 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:02 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:02 --> URI Class Initialized
INFO - 2022-01-26 09:26:02 --> Router Class Initialized
INFO - 2022-01-26 09:26:02 --> Output Class Initialized
INFO - 2022-01-26 09:26:02 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:02 --> Input Class Initialized
INFO - 2022-01-26 09:26:02 --> Language Class Initialized
ERROR - 2022-01-26 09:26:02 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-01-26 09:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:02 --> Config Class Initialized
INFO - 2022-01-26 09:26:02 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:02 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:02 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:02 --> URI Class Initialized
INFO - 2022-01-26 09:26:02 --> Router Class Initialized
INFO - 2022-01-26 09:26:02 --> Output Class Initialized
INFO - 2022-01-26 09:26:02 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:02 --> Input Class Initialized
INFO - 2022-01-26 09:26:02 --> Language Class Initialized
ERROR - 2022-01-26 09:26:02 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-01-26 09:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:03 --> Config Class Initialized
INFO - 2022-01-26 09:26:03 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:03 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:03 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:03 --> URI Class Initialized
INFO - 2022-01-26 09:26:03 --> Router Class Initialized
INFO - 2022-01-26 09:26:03 --> Output Class Initialized
INFO - 2022-01-26 09:26:03 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:03 --> Input Class Initialized
INFO - 2022-01-26 09:26:03 --> Language Class Initialized
ERROR - 2022-01-26 09:26:03 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-01-26 09:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:03 --> Config Class Initialized
INFO - 2022-01-26 09:26:03 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:03 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:03 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:03 --> URI Class Initialized
INFO - 2022-01-26 09:26:03 --> Router Class Initialized
INFO - 2022-01-26 09:26:03 --> Output Class Initialized
INFO - 2022-01-26 09:26:03 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:03 --> Input Class Initialized
INFO - 2022-01-26 09:26:03 --> Language Class Initialized
ERROR - 2022-01-26 09:26:03 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-01-26 09:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:04 --> Config Class Initialized
INFO - 2022-01-26 09:26:04 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:04 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:04 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:04 --> URI Class Initialized
INFO - 2022-01-26 09:26:04 --> Router Class Initialized
INFO - 2022-01-26 09:26:04 --> Output Class Initialized
INFO - 2022-01-26 09:26:04 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:04 --> Input Class Initialized
INFO - 2022-01-26 09:26:04 --> Language Class Initialized
ERROR - 2022-01-26 09:26:04 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-01-26 09:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:04 --> Config Class Initialized
INFO - 2022-01-26 09:26:04 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:04 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:04 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:04 --> URI Class Initialized
INFO - 2022-01-26 09:26:04 --> Router Class Initialized
INFO - 2022-01-26 09:26:04 --> Output Class Initialized
INFO - 2022-01-26 09:26:04 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:04 --> Input Class Initialized
INFO - 2022-01-26 09:26:04 --> Language Class Initialized
ERROR - 2022-01-26 09:26:04 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-01-26 09:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:05 --> Config Class Initialized
INFO - 2022-01-26 09:26:05 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:05 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:05 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:05 --> URI Class Initialized
INFO - 2022-01-26 09:26:05 --> Router Class Initialized
INFO - 2022-01-26 09:26:05 --> Output Class Initialized
INFO - 2022-01-26 09:26:05 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:05 --> Input Class Initialized
INFO - 2022-01-26 09:26:05 --> Language Class Initialized
ERROR - 2022-01-26 09:26:05 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-01-26 09:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:05 --> Config Class Initialized
INFO - 2022-01-26 09:26:05 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:05 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:05 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:05 --> URI Class Initialized
INFO - 2022-01-26 09:26:05 --> Router Class Initialized
INFO - 2022-01-26 09:26:05 --> Output Class Initialized
INFO - 2022-01-26 09:26:05 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:05 --> Input Class Initialized
INFO - 2022-01-26 09:26:05 --> Language Class Initialized
ERROR - 2022-01-26 09:26:05 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-01-26 09:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:05 --> Config Class Initialized
INFO - 2022-01-26 09:26:05 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:05 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:05 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:05 --> URI Class Initialized
INFO - 2022-01-26 09:26:05 --> Router Class Initialized
INFO - 2022-01-26 09:26:06 --> Output Class Initialized
INFO - 2022-01-26 09:26:06 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:06 --> Input Class Initialized
INFO - 2022-01-26 09:26:06 --> Language Class Initialized
ERROR - 2022-01-26 09:26:06 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-01-26 09:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:06 --> Config Class Initialized
INFO - 2022-01-26 09:26:06 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:06 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:06 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:06 --> URI Class Initialized
INFO - 2022-01-26 09:26:06 --> Router Class Initialized
INFO - 2022-01-26 09:26:06 --> Output Class Initialized
INFO - 2022-01-26 09:26:06 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:06 --> Input Class Initialized
INFO - 2022-01-26 09:26:06 --> Language Class Initialized
ERROR - 2022-01-26 09:26:06 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-01-26 09:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:06 --> Config Class Initialized
INFO - 2022-01-26 09:26:06 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:06 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:06 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:06 --> URI Class Initialized
INFO - 2022-01-26 09:26:06 --> Router Class Initialized
INFO - 2022-01-26 09:26:06 --> Output Class Initialized
INFO - 2022-01-26 09:26:06 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:06 --> Input Class Initialized
INFO - 2022-01-26 09:26:06 --> Language Class Initialized
ERROR - 2022-01-26 09:26:06 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-01-26 09:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:07 --> Config Class Initialized
INFO - 2022-01-26 09:26:07 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:07 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:07 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:07 --> URI Class Initialized
INFO - 2022-01-26 09:26:07 --> Router Class Initialized
INFO - 2022-01-26 09:26:07 --> Output Class Initialized
INFO - 2022-01-26 09:26:07 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:07 --> Input Class Initialized
INFO - 2022-01-26 09:26:07 --> Language Class Initialized
ERROR - 2022-01-26 09:26:07 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-01-26 09:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:07 --> Config Class Initialized
INFO - 2022-01-26 09:26:07 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:07 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:07 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:07 --> URI Class Initialized
INFO - 2022-01-26 09:26:07 --> Router Class Initialized
INFO - 2022-01-26 09:26:07 --> Output Class Initialized
INFO - 2022-01-26 09:26:07 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:07 --> Input Class Initialized
INFO - 2022-01-26 09:26:07 --> Language Class Initialized
ERROR - 2022-01-26 09:26:07 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-01-26 09:26:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 09:26:08 --> Config Class Initialized
INFO - 2022-01-26 09:26:08 --> Hooks Class Initialized
DEBUG - 2022-01-26 09:26:08 --> UTF-8 Support Enabled
INFO - 2022-01-26 09:26:08 --> Utf8 Class Initialized
INFO - 2022-01-26 09:26:08 --> URI Class Initialized
INFO - 2022-01-26 09:26:08 --> Router Class Initialized
INFO - 2022-01-26 09:26:08 --> Output Class Initialized
INFO - 2022-01-26 09:26:08 --> Security Class Initialized
DEBUG - 2022-01-26 09:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 09:26:08 --> Input Class Initialized
INFO - 2022-01-26 09:26:08 --> Language Class Initialized
ERROR - 2022-01-26 09:26:08 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-01-26 10:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 10:02:46 --> Config Class Initialized
INFO - 2022-01-26 10:02:46 --> Hooks Class Initialized
DEBUG - 2022-01-26 10:02:46 --> UTF-8 Support Enabled
INFO - 2022-01-26 10:02:46 --> Utf8 Class Initialized
INFO - 2022-01-26 10:02:46 --> URI Class Initialized
DEBUG - 2022-01-26 10:02:46 --> No URI present. Default controller set.
INFO - 2022-01-26 10:02:46 --> Router Class Initialized
INFO - 2022-01-26 10:02:46 --> Output Class Initialized
INFO - 2022-01-26 10:02:46 --> Security Class Initialized
DEBUG - 2022-01-26 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 10:02:46 --> Input Class Initialized
INFO - 2022-01-26 10:02:46 --> Language Class Initialized
INFO - 2022-01-26 10:02:46 --> Loader Class Initialized
INFO - 2022-01-26 10:02:46 --> Helper loaded: url_helper
INFO - 2022-01-26 10:02:46 --> Helper loaded: form_helper
INFO - 2022-01-26 10:02:46 --> Helper loaded: common_helper
INFO - 2022-01-26 10:02:46 --> Database Driver Class Initialized
DEBUG - 2022-01-26 10:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 10:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 10:02:46 --> Controller Class Initialized
INFO - 2022-01-26 10:02:46 --> Form Validation Class Initialized
DEBUG - 2022-01-26 10:02:46 --> Encrypt Class Initialized
DEBUG - 2022-01-26 10:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:02:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 10:02:46 --> Email Class Initialized
INFO - 2022-01-26 10:02:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 10:02:46 --> Calendar Class Initialized
INFO - 2022-01-26 10:02:46 --> Model "Login_model" initialized
INFO - 2022-01-26 10:02:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 10:02:46 --> Final output sent to browser
DEBUG - 2022-01-26 10:02:46 --> Total execution time: 0.0404
ERROR - 2022-01-26 10:25:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 10:25:52 --> Config Class Initialized
INFO - 2022-01-26 10:25:52 --> Hooks Class Initialized
DEBUG - 2022-01-26 10:25:52 --> UTF-8 Support Enabled
INFO - 2022-01-26 10:25:52 --> Utf8 Class Initialized
INFO - 2022-01-26 10:25:52 --> URI Class Initialized
DEBUG - 2022-01-26 10:25:52 --> No URI present. Default controller set.
INFO - 2022-01-26 10:25:52 --> Router Class Initialized
INFO - 2022-01-26 10:25:52 --> Output Class Initialized
INFO - 2022-01-26 10:25:52 --> Security Class Initialized
DEBUG - 2022-01-26 10:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 10:25:52 --> Input Class Initialized
INFO - 2022-01-26 10:25:52 --> Language Class Initialized
INFO - 2022-01-26 10:25:52 --> Loader Class Initialized
INFO - 2022-01-26 10:25:52 --> Helper loaded: url_helper
INFO - 2022-01-26 10:25:52 --> Helper loaded: form_helper
INFO - 2022-01-26 10:25:52 --> Helper loaded: common_helper
INFO - 2022-01-26 10:25:52 --> Database Driver Class Initialized
DEBUG - 2022-01-26 10:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 10:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 10:25:52 --> Controller Class Initialized
INFO - 2022-01-26 10:25:52 --> Form Validation Class Initialized
DEBUG - 2022-01-26 10:25:52 --> Encrypt Class Initialized
DEBUG - 2022-01-26 10:25:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:25:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 10:25:52 --> Email Class Initialized
INFO - 2022-01-26 10:25:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 10:25:52 --> Calendar Class Initialized
INFO - 2022-01-26 10:25:52 --> Model "Login_model" initialized
INFO - 2022-01-26 10:25:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 10:25:52 --> Final output sent to browser
DEBUG - 2022-01-26 10:25:52 --> Total execution time: 0.0239
ERROR - 2022-01-26 11:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 11:42:19 --> Config Class Initialized
INFO - 2022-01-26 11:42:19 --> Hooks Class Initialized
DEBUG - 2022-01-26 11:42:19 --> UTF-8 Support Enabled
INFO - 2022-01-26 11:42:19 --> Utf8 Class Initialized
INFO - 2022-01-26 11:42:19 --> URI Class Initialized
DEBUG - 2022-01-26 11:42:19 --> No URI present. Default controller set.
INFO - 2022-01-26 11:42:19 --> Router Class Initialized
INFO - 2022-01-26 11:42:19 --> Output Class Initialized
INFO - 2022-01-26 11:42:19 --> Security Class Initialized
DEBUG - 2022-01-26 11:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 11:42:19 --> Input Class Initialized
INFO - 2022-01-26 11:42:19 --> Language Class Initialized
INFO - 2022-01-26 11:42:19 --> Loader Class Initialized
INFO - 2022-01-26 11:42:19 --> Helper loaded: url_helper
INFO - 2022-01-26 11:42:19 --> Helper loaded: form_helper
INFO - 2022-01-26 11:42:19 --> Helper loaded: common_helper
INFO - 2022-01-26 11:42:19 --> Database Driver Class Initialized
DEBUG - 2022-01-26 11:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 11:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 11:42:19 --> Controller Class Initialized
INFO - 2022-01-26 11:42:19 --> Form Validation Class Initialized
DEBUG - 2022-01-26 11:42:19 --> Encrypt Class Initialized
DEBUG - 2022-01-26 11:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 11:42:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 11:42:19 --> Email Class Initialized
INFO - 2022-01-26 11:42:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 11:42:19 --> Calendar Class Initialized
INFO - 2022-01-26 11:42:19 --> Model "Login_model" initialized
INFO - 2022-01-26 11:42:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 11:42:19 --> Final output sent to browser
DEBUG - 2022-01-26 11:42:19 --> Total execution time: 0.0352
ERROR - 2022-01-26 14:19:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 14:19:12 --> Config Class Initialized
INFO - 2022-01-26 14:19:12 --> Hooks Class Initialized
DEBUG - 2022-01-26 14:19:12 --> UTF-8 Support Enabled
INFO - 2022-01-26 14:19:12 --> Utf8 Class Initialized
INFO - 2022-01-26 14:19:12 --> URI Class Initialized
DEBUG - 2022-01-26 14:19:12 --> No URI present. Default controller set.
INFO - 2022-01-26 14:19:12 --> Router Class Initialized
INFO - 2022-01-26 14:19:12 --> Output Class Initialized
INFO - 2022-01-26 14:19:12 --> Security Class Initialized
DEBUG - 2022-01-26 14:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 14:19:12 --> Input Class Initialized
INFO - 2022-01-26 14:19:12 --> Language Class Initialized
INFO - 2022-01-26 14:19:12 --> Loader Class Initialized
INFO - 2022-01-26 14:19:12 --> Helper loaded: url_helper
INFO - 2022-01-26 14:19:12 --> Helper loaded: form_helper
INFO - 2022-01-26 14:19:12 --> Helper loaded: common_helper
INFO - 2022-01-26 14:19:12 --> Database Driver Class Initialized
DEBUG - 2022-01-26 14:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 14:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 14:19:12 --> Controller Class Initialized
INFO - 2022-01-26 14:19:12 --> Form Validation Class Initialized
DEBUG - 2022-01-26 14:19:12 --> Encrypt Class Initialized
DEBUG - 2022-01-26 14:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:19:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 14:19:12 --> Email Class Initialized
INFO - 2022-01-26 14:19:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 14:19:12 --> Calendar Class Initialized
INFO - 2022-01-26 14:19:12 --> Model "Login_model" initialized
INFO - 2022-01-26 14:19:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 14:19:12 --> Final output sent to browser
DEBUG - 2022-01-26 14:19:12 --> Total execution time: 0.0346
ERROR - 2022-01-26 14:19:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 14:19:13 --> Config Class Initialized
INFO - 2022-01-26 14:19:13 --> Hooks Class Initialized
DEBUG - 2022-01-26 14:19:13 --> UTF-8 Support Enabled
INFO - 2022-01-26 14:19:13 --> Utf8 Class Initialized
INFO - 2022-01-26 14:19:13 --> URI Class Initialized
INFO - 2022-01-26 14:19:13 --> Router Class Initialized
INFO - 2022-01-26 14:19:13 --> Output Class Initialized
INFO - 2022-01-26 14:19:13 --> Security Class Initialized
DEBUG - 2022-01-26 14:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 14:19:13 --> Input Class Initialized
INFO - 2022-01-26 14:19:13 --> Language Class Initialized
ERROR - 2022-01-26 14:19:13 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-26 14:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 14:19:36 --> Config Class Initialized
INFO - 2022-01-26 14:19:36 --> Hooks Class Initialized
DEBUG - 2022-01-26 14:19:36 --> UTF-8 Support Enabled
INFO - 2022-01-26 14:19:36 --> Utf8 Class Initialized
INFO - 2022-01-26 14:19:36 --> URI Class Initialized
INFO - 2022-01-26 14:19:36 --> Router Class Initialized
INFO - 2022-01-26 14:19:36 --> Output Class Initialized
INFO - 2022-01-26 14:19:36 --> Security Class Initialized
DEBUG - 2022-01-26 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 14:19:36 --> Input Class Initialized
INFO - 2022-01-26 14:19:36 --> Language Class Initialized
INFO - 2022-01-26 14:19:36 --> Loader Class Initialized
INFO - 2022-01-26 14:19:36 --> Helper loaded: url_helper
INFO - 2022-01-26 14:19:36 --> Helper loaded: form_helper
INFO - 2022-01-26 14:19:36 --> Helper loaded: common_helper
INFO - 2022-01-26 14:19:36 --> Database Driver Class Initialized
DEBUG - 2022-01-26 14:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 14:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 14:19:36 --> Controller Class Initialized
INFO - 2022-01-26 14:19:36 --> Form Validation Class Initialized
DEBUG - 2022-01-26 14:19:36 --> Encrypt Class Initialized
DEBUG - 2022-01-26 14:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 14:19:36 --> Email Class Initialized
INFO - 2022-01-26 14:19:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 14:19:36 --> Calendar Class Initialized
INFO - 2022-01-26 14:19:36 --> Model "Login_model" initialized
ERROR - 2022-01-26 14:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 14:19:36 --> Config Class Initialized
INFO - 2022-01-26 14:19:36 --> Hooks Class Initialized
DEBUG - 2022-01-26 14:19:36 --> UTF-8 Support Enabled
INFO - 2022-01-26 14:19:36 --> Utf8 Class Initialized
INFO - 2022-01-26 14:19:36 --> URI Class Initialized
INFO - 2022-01-26 14:19:36 --> Router Class Initialized
INFO - 2022-01-26 14:19:36 --> Output Class Initialized
INFO - 2022-01-26 14:19:36 --> Security Class Initialized
DEBUG - 2022-01-26 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 14:19:36 --> Input Class Initialized
INFO - 2022-01-26 14:19:36 --> Language Class Initialized
INFO - 2022-01-26 14:19:36 --> Loader Class Initialized
INFO - 2022-01-26 14:19:36 --> Helper loaded: url_helper
INFO - 2022-01-26 14:19:36 --> Helper loaded: form_helper
INFO - 2022-01-26 14:19:36 --> Helper loaded: common_helper
INFO - 2022-01-26 14:19:36 --> Database Driver Class Initialized
DEBUG - 2022-01-26 14:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 14:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 14:19:36 --> Controller Class Initialized
INFO - 2022-01-26 14:19:36 --> Form Validation Class Initialized
DEBUG - 2022-01-26 14:19:36 --> Encrypt Class Initialized
DEBUG - 2022-01-26 14:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 14:19:36 --> Email Class Initialized
INFO - 2022-01-26 14:19:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 14:19:36 --> Calendar Class Initialized
INFO - 2022-01-26 14:19:36 --> Model "Login_model" initialized
ERROR - 2022-01-26 14:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 14:19:37 --> Config Class Initialized
INFO - 2022-01-26 14:19:37 --> Hooks Class Initialized
DEBUG - 2022-01-26 14:19:37 --> UTF-8 Support Enabled
INFO - 2022-01-26 14:19:37 --> Utf8 Class Initialized
INFO - 2022-01-26 14:19:37 --> URI Class Initialized
DEBUG - 2022-01-26 14:19:37 --> No URI present. Default controller set.
INFO - 2022-01-26 14:19:37 --> Router Class Initialized
INFO - 2022-01-26 14:19:37 --> Output Class Initialized
INFO - 2022-01-26 14:19:37 --> Security Class Initialized
DEBUG - 2022-01-26 14:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 14:19:37 --> Input Class Initialized
INFO - 2022-01-26 14:19:37 --> Language Class Initialized
INFO - 2022-01-26 14:19:37 --> Loader Class Initialized
INFO - 2022-01-26 14:19:37 --> Helper loaded: url_helper
INFO - 2022-01-26 14:19:37 --> Helper loaded: form_helper
INFO - 2022-01-26 14:19:37 --> Helper loaded: common_helper
INFO - 2022-01-26 14:19:37 --> Database Driver Class Initialized
DEBUG - 2022-01-26 14:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 14:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 14:19:37 --> Controller Class Initialized
INFO - 2022-01-26 14:19:37 --> Form Validation Class Initialized
DEBUG - 2022-01-26 14:19:37 --> Encrypt Class Initialized
DEBUG - 2022-01-26 14:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 14:19:37 --> Email Class Initialized
INFO - 2022-01-26 14:19:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 14:19:37 --> Calendar Class Initialized
INFO - 2022-01-26 14:19:37 --> Model "Login_model" initialized
INFO - 2022-01-26 14:19:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 14:19:37 --> Final output sent to browser
DEBUG - 2022-01-26 14:19:37 --> Total execution time: 0.0347
ERROR - 2022-01-26 14:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 14:19:38 --> Config Class Initialized
INFO - 2022-01-26 14:19:38 --> Hooks Class Initialized
DEBUG - 2022-01-26 14:19:38 --> UTF-8 Support Enabled
INFO - 2022-01-26 14:19:38 --> Utf8 Class Initialized
INFO - 2022-01-26 14:19:38 --> URI Class Initialized
INFO - 2022-01-26 14:19:38 --> Router Class Initialized
INFO - 2022-01-26 14:19:38 --> Output Class Initialized
INFO - 2022-01-26 14:19:38 --> Security Class Initialized
DEBUG - 2022-01-26 14:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 14:19:38 --> Input Class Initialized
INFO - 2022-01-26 14:19:38 --> Language Class Initialized
INFO - 2022-01-26 14:19:38 --> Loader Class Initialized
INFO - 2022-01-26 14:19:38 --> Helper loaded: url_helper
INFO - 2022-01-26 14:19:38 --> Helper loaded: form_helper
INFO - 2022-01-26 14:19:38 --> Helper loaded: common_helper
INFO - 2022-01-26 14:19:38 --> Database Driver Class Initialized
DEBUG - 2022-01-26 14:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 14:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 14:19:38 --> Controller Class Initialized
INFO - 2022-01-26 14:19:38 --> Form Validation Class Initialized
DEBUG - 2022-01-26 14:19:38 --> Encrypt Class Initialized
DEBUG - 2022-01-26 14:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 14:19:38 --> Email Class Initialized
INFO - 2022-01-26 14:19:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 14:19:38 --> Calendar Class Initialized
INFO - 2022-01-26 14:19:38 --> Model "Login_model" initialized
INFO - 2022-01-26 14:19:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 14:19:38 --> Final output sent to browser
DEBUG - 2022-01-26 14:19:38 --> Total execution time: 0.0732
ERROR - 2022-01-26 15:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 15:08:37 --> Config Class Initialized
INFO - 2022-01-26 15:08:37 --> Hooks Class Initialized
DEBUG - 2022-01-26 15:08:37 --> UTF-8 Support Enabled
INFO - 2022-01-26 15:08:37 --> Utf8 Class Initialized
INFO - 2022-01-26 15:08:37 --> URI Class Initialized
DEBUG - 2022-01-26 15:08:37 --> No URI present. Default controller set.
INFO - 2022-01-26 15:08:37 --> Router Class Initialized
INFO - 2022-01-26 15:08:37 --> Output Class Initialized
INFO - 2022-01-26 15:08:37 --> Security Class Initialized
DEBUG - 2022-01-26 15:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 15:08:37 --> Input Class Initialized
INFO - 2022-01-26 15:08:37 --> Language Class Initialized
INFO - 2022-01-26 15:08:37 --> Loader Class Initialized
INFO - 2022-01-26 15:08:37 --> Helper loaded: url_helper
INFO - 2022-01-26 15:08:37 --> Helper loaded: form_helper
INFO - 2022-01-26 15:08:37 --> Helper loaded: common_helper
INFO - 2022-01-26 15:08:37 --> Database Driver Class Initialized
DEBUG - 2022-01-26 15:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 15:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 15:08:37 --> Controller Class Initialized
INFO - 2022-01-26 15:08:37 --> Form Validation Class Initialized
DEBUG - 2022-01-26 15:08:37 --> Encrypt Class Initialized
DEBUG - 2022-01-26 15:08:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:08:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 15:08:37 --> Email Class Initialized
INFO - 2022-01-26 15:08:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 15:08:37 --> Calendar Class Initialized
INFO - 2022-01-26 15:08:37 --> Model "Login_model" initialized
INFO - 2022-01-26 15:08:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 15:08:37 --> Final output sent to browser
DEBUG - 2022-01-26 15:08:37 --> Total execution time: 0.0222
ERROR - 2022-01-26 20:20:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 20:20:32 --> Config Class Initialized
INFO - 2022-01-26 20:20:32 --> Hooks Class Initialized
DEBUG - 2022-01-26 20:20:32 --> UTF-8 Support Enabled
INFO - 2022-01-26 20:20:32 --> Utf8 Class Initialized
INFO - 2022-01-26 20:20:32 --> URI Class Initialized
DEBUG - 2022-01-26 20:20:32 --> No URI present. Default controller set.
INFO - 2022-01-26 20:20:32 --> Router Class Initialized
INFO - 2022-01-26 20:20:32 --> Output Class Initialized
INFO - 2022-01-26 20:20:32 --> Security Class Initialized
DEBUG - 2022-01-26 20:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 20:20:32 --> Input Class Initialized
INFO - 2022-01-26 20:20:32 --> Language Class Initialized
INFO - 2022-01-26 20:20:32 --> Loader Class Initialized
INFO - 2022-01-26 20:20:32 --> Helper loaded: url_helper
INFO - 2022-01-26 20:20:32 --> Helper loaded: form_helper
INFO - 2022-01-26 20:20:32 --> Helper loaded: common_helper
INFO - 2022-01-26 20:20:32 --> Database Driver Class Initialized
DEBUG - 2022-01-26 20:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 20:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 20:20:32 --> Controller Class Initialized
INFO - 2022-01-26 20:20:32 --> Form Validation Class Initialized
DEBUG - 2022-01-26 20:20:32 --> Encrypt Class Initialized
DEBUG - 2022-01-26 20:20:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 20:20:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 20:20:32 --> Email Class Initialized
INFO - 2022-01-26 20:20:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 20:20:32 --> Calendar Class Initialized
INFO - 2022-01-26 20:20:32 --> Model "Login_model" initialized
INFO - 2022-01-26 20:20:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 20:20:32 --> Final output sent to browser
DEBUG - 2022-01-26 20:20:32 --> Total execution time: 0.0241
ERROR - 2022-01-26 20:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 20:20:37 --> Config Class Initialized
INFO - 2022-01-26 20:20:37 --> Hooks Class Initialized
DEBUG - 2022-01-26 20:20:37 --> UTF-8 Support Enabled
INFO - 2022-01-26 20:20:37 --> Utf8 Class Initialized
INFO - 2022-01-26 20:20:37 --> URI Class Initialized
INFO - 2022-01-26 20:20:37 --> Router Class Initialized
INFO - 2022-01-26 20:20:37 --> Output Class Initialized
INFO - 2022-01-26 20:20:37 --> Security Class Initialized
DEBUG - 2022-01-26 20:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 20:20:37 --> Input Class Initialized
INFO - 2022-01-26 20:20:37 --> Language Class Initialized
INFO - 2022-01-26 20:20:37 --> Loader Class Initialized
INFO - 2022-01-26 20:20:37 --> Helper loaded: url_helper
INFO - 2022-01-26 20:20:37 --> Helper loaded: form_helper
INFO - 2022-01-26 20:20:37 --> Helper loaded: common_helper
INFO - 2022-01-26 20:20:37 --> Database Driver Class Initialized
DEBUG - 2022-01-26 20:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 20:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 20:20:37 --> Controller Class Initialized
INFO - 2022-01-26 20:20:37 --> Form Validation Class Initialized
DEBUG - 2022-01-26 20:20:37 --> Encrypt Class Initialized
DEBUG - 2022-01-26 20:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 20:20:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 20:20:37 --> Email Class Initialized
INFO - 2022-01-26 20:20:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 20:20:37 --> Calendar Class Initialized
INFO - 2022-01-26 20:20:37 --> Model "Login_model" initialized
INFO - 2022-01-26 20:20:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 20:20:37 --> Final output sent to browser
DEBUG - 2022-01-26 20:20:37 --> Total execution time: 0.0223
ERROR - 2022-01-26 20:20:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 20:20:38 --> Config Class Initialized
INFO - 2022-01-26 20:20:38 --> Hooks Class Initialized
DEBUG - 2022-01-26 20:20:38 --> UTF-8 Support Enabled
INFO - 2022-01-26 20:20:38 --> Utf8 Class Initialized
INFO - 2022-01-26 20:20:38 --> URI Class Initialized
DEBUG - 2022-01-26 20:20:38 --> No URI present. Default controller set.
INFO - 2022-01-26 20:20:38 --> Router Class Initialized
INFO - 2022-01-26 20:20:38 --> Output Class Initialized
INFO - 2022-01-26 20:20:38 --> Security Class Initialized
DEBUG - 2022-01-26 20:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 20:20:38 --> Input Class Initialized
INFO - 2022-01-26 20:20:38 --> Language Class Initialized
INFO - 2022-01-26 20:20:38 --> Loader Class Initialized
INFO - 2022-01-26 20:20:38 --> Helper loaded: url_helper
INFO - 2022-01-26 20:20:38 --> Helper loaded: form_helper
INFO - 2022-01-26 20:20:38 --> Helper loaded: common_helper
INFO - 2022-01-26 20:20:38 --> Database Driver Class Initialized
DEBUG - 2022-01-26 20:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 20:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 20:20:38 --> Controller Class Initialized
INFO - 2022-01-26 20:20:38 --> Form Validation Class Initialized
DEBUG - 2022-01-26 20:20:38 --> Encrypt Class Initialized
DEBUG - 2022-01-26 20:20:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 20:20:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 20:20:38 --> Email Class Initialized
INFO - 2022-01-26 20:20:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 20:20:38 --> Calendar Class Initialized
INFO - 2022-01-26 20:20:38 --> Model "Login_model" initialized
INFO - 2022-01-26 20:20:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 20:20:38 --> Final output sent to browser
DEBUG - 2022-01-26 20:20:38 --> Total execution time: 0.0233
ERROR - 2022-01-26 20:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 20:20:41 --> Config Class Initialized
INFO - 2022-01-26 20:20:41 --> Hooks Class Initialized
DEBUG - 2022-01-26 20:20:41 --> UTF-8 Support Enabled
INFO - 2022-01-26 20:20:41 --> Utf8 Class Initialized
INFO - 2022-01-26 20:20:41 --> URI Class Initialized
INFO - 2022-01-26 20:20:41 --> Router Class Initialized
INFO - 2022-01-26 20:20:41 --> Output Class Initialized
INFO - 2022-01-26 20:20:41 --> Security Class Initialized
DEBUG - 2022-01-26 20:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 20:20:41 --> Input Class Initialized
INFO - 2022-01-26 20:20:41 --> Language Class Initialized
INFO - 2022-01-26 20:20:41 --> Loader Class Initialized
INFO - 2022-01-26 20:20:41 --> Helper loaded: url_helper
INFO - 2022-01-26 20:20:41 --> Helper loaded: form_helper
INFO - 2022-01-26 20:20:41 --> Helper loaded: common_helper
INFO - 2022-01-26 20:20:41 --> Database Driver Class Initialized
DEBUG - 2022-01-26 20:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 20:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 20:20:41 --> Controller Class Initialized
INFO - 2022-01-26 20:20:41 --> Form Validation Class Initialized
DEBUG - 2022-01-26 20:20:41 --> Encrypt Class Initialized
DEBUG - 2022-01-26 20:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 20:20:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 20:20:41 --> Email Class Initialized
INFO - 2022-01-26 20:20:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 20:20:41 --> Calendar Class Initialized
INFO - 2022-01-26 20:20:41 --> Model "Login_model" initialized
ERROR - 2022-01-26 20:20:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 20:20:44 --> Config Class Initialized
INFO - 2022-01-26 20:20:44 --> Hooks Class Initialized
DEBUG - 2022-01-26 20:20:44 --> UTF-8 Support Enabled
INFO - 2022-01-26 20:20:44 --> Utf8 Class Initialized
INFO - 2022-01-26 20:20:44 --> URI Class Initialized
INFO - 2022-01-26 20:20:44 --> Router Class Initialized
INFO - 2022-01-26 20:20:44 --> Output Class Initialized
INFO - 2022-01-26 20:20:44 --> Security Class Initialized
DEBUG - 2022-01-26 20:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 20:20:44 --> Input Class Initialized
INFO - 2022-01-26 20:20:44 --> Language Class Initialized
INFO - 2022-01-26 20:20:44 --> Loader Class Initialized
INFO - 2022-01-26 20:20:44 --> Helper loaded: url_helper
INFO - 2022-01-26 20:20:44 --> Helper loaded: form_helper
INFO - 2022-01-26 20:20:44 --> Helper loaded: common_helper
INFO - 2022-01-26 20:20:44 --> Database Driver Class Initialized
DEBUG - 2022-01-26 20:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 20:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 20:20:44 --> Controller Class Initialized
INFO - 2022-01-26 20:20:44 --> Form Validation Class Initialized
DEBUG - 2022-01-26 20:20:44 --> Encrypt Class Initialized
DEBUG - 2022-01-26 20:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 20:20:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 20:20:44 --> Email Class Initialized
INFO - 2022-01-26 20:20:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 20:20:44 --> Calendar Class Initialized
INFO - 2022-01-26 20:20:44 --> Model "Login_model" initialized
INFO - 2022-01-26 20:20:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 20:20:44 --> Final output sent to browser
DEBUG - 2022-01-26 20:20:44 --> Total execution time: 0.0239
ERROR - 2022-01-26 20:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 20:37:16 --> Config Class Initialized
INFO - 2022-01-26 20:37:16 --> Hooks Class Initialized
DEBUG - 2022-01-26 20:37:16 --> UTF-8 Support Enabled
INFO - 2022-01-26 20:37:16 --> Utf8 Class Initialized
INFO - 2022-01-26 20:37:16 --> URI Class Initialized
DEBUG - 2022-01-26 20:37:16 --> No URI present. Default controller set.
INFO - 2022-01-26 20:37:16 --> Router Class Initialized
INFO - 2022-01-26 20:37:16 --> Output Class Initialized
INFO - 2022-01-26 20:37:16 --> Security Class Initialized
DEBUG - 2022-01-26 20:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 20:37:16 --> Input Class Initialized
INFO - 2022-01-26 20:37:16 --> Language Class Initialized
INFO - 2022-01-26 20:37:16 --> Loader Class Initialized
INFO - 2022-01-26 20:37:16 --> Helper loaded: url_helper
INFO - 2022-01-26 20:37:16 --> Helper loaded: form_helper
INFO - 2022-01-26 20:37:16 --> Helper loaded: common_helper
INFO - 2022-01-26 20:37:16 --> Database Driver Class Initialized
DEBUG - 2022-01-26 20:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 20:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 20:37:16 --> Controller Class Initialized
INFO - 2022-01-26 20:37:16 --> Form Validation Class Initialized
DEBUG - 2022-01-26 20:37:16 --> Encrypt Class Initialized
DEBUG - 2022-01-26 20:37:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 20:37:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 20:37:16 --> Email Class Initialized
INFO - 2022-01-26 20:37:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 20:37:16 --> Calendar Class Initialized
INFO - 2022-01-26 20:37:16 --> Model "Login_model" initialized
INFO - 2022-01-26 20:37:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 20:37:16 --> Final output sent to browser
DEBUG - 2022-01-26 20:37:16 --> Total execution time: 0.0449
ERROR - 2022-01-26 23:56:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-26 23:56:01 --> Config Class Initialized
INFO - 2022-01-26 23:56:01 --> Hooks Class Initialized
DEBUG - 2022-01-26 23:56:01 --> UTF-8 Support Enabled
INFO - 2022-01-26 23:56:01 --> Utf8 Class Initialized
INFO - 2022-01-26 23:56:01 --> URI Class Initialized
DEBUG - 2022-01-26 23:56:01 --> No URI present. Default controller set.
INFO - 2022-01-26 23:56:01 --> Router Class Initialized
INFO - 2022-01-26 23:56:01 --> Output Class Initialized
INFO - 2022-01-26 23:56:01 --> Security Class Initialized
DEBUG - 2022-01-26 23:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-26 23:56:01 --> Input Class Initialized
INFO - 2022-01-26 23:56:01 --> Language Class Initialized
INFO - 2022-01-26 23:56:01 --> Loader Class Initialized
INFO - 2022-01-26 23:56:01 --> Helper loaded: url_helper
INFO - 2022-01-26 23:56:01 --> Helper loaded: form_helper
INFO - 2022-01-26 23:56:01 --> Helper loaded: common_helper
INFO - 2022-01-26 23:56:01 --> Database Driver Class Initialized
DEBUG - 2022-01-26 23:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-26 23:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-26 23:56:01 --> Controller Class Initialized
INFO - 2022-01-26 23:56:01 --> Form Validation Class Initialized
DEBUG - 2022-01-26 23:56:01 --> Encrypt Class Initialized
DEBUG - 2022-01-26 23:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 23:56:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-26 23:56:01 --> Email Class Initialized
INFO - 2022-01-26 23:56:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-26 23:56:01 --> Calendar Class Initialized
INFO - 2022-01-26 23:56:01 --> Model "Login_model" initialized
INFO - 2022-01-26 23:56:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-26 23:56:01 --> Final output sent to browser
DEBUG - 2022-01-26 23:56:01 --> Total execution time: 0.0284
