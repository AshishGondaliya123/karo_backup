<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-08 20:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-08 20:22:00 --> Config Class Initialized
INFO - 2021-10-08 20:22:00 --> Hooks Class Initialized
DEBUG - 2021-10-08 20:22:00 --> UTF-8 Support Enabled
INFO - 2021-10-08 20:22:00 --> Utf8 Class Initialized
INFO - 2021-10-08 20:22:00 --> URI Class Initialized
DEBUG - 2021-10-08 20:22:00 --> No URI present. Default controller set.
INFO - 2021-10-08 20:22:00 --> Router Class Initialized
INFO - 2021-10-08 20:22:00 --> Output Class Initialized
INFO - 2021-10-08 20:22:00 --> Security Class Initialized
DEBUG - 2021-10-08 20:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-08 20:22:00 --> Input Class Initialized
INFO - 2021-10-08 20:22:00 --> Language Class Initialized
INFO - 2021-10-08 20:22:00 --> Loader Class Initialized
INFO - 2021-10-08 20:22:00 --> Helper loaded: url_helper
INFO - 2021-10-08 20:22:00 --> Helper loaded: form_helper
INFO - 2021-10-08 20:22:00 --> Helper loaded: common_helper
INFO - 2021-10-08 20:22:00 --> Database Driver Class Initialized
DEBUG - 2021-10-08 20:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-08 20:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-08 20:22:00 --> Controller Class Initialized
INFO - 2021-10-08 20:22:00 --> Form Validation Class Initialized
DEBUG - 2021-10-08 20:22:00 --> Encrypt Class Initialized
DEBUG - 2021-10-08 20:22:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-08 20:22:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-08 20:22:00 --> Email Class Initialized
INFO - 2021-10-08 20:22:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-08 20:22:00 --> Calendar Class Initialized
INFO - 2021-10-08 20:22:00 --> Model "Login_model" initialized
INFO - 2021-10-08 20:22:00 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-08 20:22:00 --> Final output sent to browser
DEBUG - 2021-10-08 20:22:00 --> Total execution time: 0.0383
