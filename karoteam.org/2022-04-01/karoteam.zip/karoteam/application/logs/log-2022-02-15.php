<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-15 11:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-15 11:22:20 --> Config Class Initialized
INFO - 2022-02-15 11:22:20 --> Hooks Class Initialized
DEBUG - 2022-02-15 11:22:20 --> UTF-8 Support Enabled
INFO - 2022-02-15 11:22:20 --> Utf8 Class Initialized
INFO - 2022-02-15 11:22:20 --> URI Class Initialized
DEBUG - 2022-02-15 11:22:20 --> No URI present. Default controller set.
INFO - 2022-02-15 11:22:20 --> Router Class Initialized
INFO - 2022-02-15 11:22:20 --> Output Class Initialized
INFO - 2022-02-15 11:22:20 --> Security Class Initialized
DEBUG - 2022-02-15 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-15 11:22:20 --> Input Class Initialized
INFO - 2022-02-15 11:22:20 --> Language Class Initialized
INFO - 2022-02-15 11:22:20 --> Loader Class Initialized
INFO - 2022-02-15 11:22:20 --> Helper loaded: url_helper
INFO - 2022-02-15 11:22:20 --> Helper loaded: form_helper
INFO - 2022-02-15 11:22:20 --> Helper loaded: common_helper
INFO - 2022-02-15 11:22:20 --> Database Driver Class Initialized
DEBUG - 2022-02-15 11:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-15 11:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-15 11:22:20 --> Controller Class Initialized
INFO - 2022-02-15 11:22:20 --> Form Validation Class Initialized
DEBUG - 2022-02-15 11:22:20 --> Encrypt Class Initialized
DEBUG - 2022-02-15 11:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-15 11:22:20 --> Email Class Initialized
INFO - 2022-02-15 11:22:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-15 11:22:20 --> Calendar Class Initialized
INFO - 2022-02-15 11:22:20 --> Model "Login_model" initialized
INFO - 2022-02-15 11:22:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-15 11:22:20 --> Final output sent to browser
DEBUG - 2022-02-15 11:22:20 --> Total execution time: 0.0398
ERROR - 2022-02-15 14:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-15 14:18:06 --> Config Class Initialized
INFO - 2022-02-15 14:18:06 --> Hooks Class Initialized
DEBUG - 2022-02-15 14:18:06 --> UTF-8 Support Enabled
INFO - 2022-02-15 14:18:06 --> Utf8 Class Initialized
INFO - 2022-02-15 14:18:06 --> URI Class Initialized
DEBUG - 2022-02-15 14:18:06 --> No URI present. Default controller set.
INFO - 2022-02-15 14:18:06 --> Router Class Initialized
INFO - 2022-02-15 14:18:06 --> Output Class Initialized
INFO - 2022-02-15 14:18:06 --> Security Class Initialized
DEBUG - 2022-02-15 14:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-15 14:18:06 --> Input Class Initialized
INFO - 2022-02-15 14:18:06 --> Language Class Initialized
INFO - 2022-02-15 14:18:06 --> Loader Class Initialized
INFO - 2022-02-15 14:18:06 --> Helper loaded: url_helper
INFO - 2022-02-15 14:18:06 --> Helper loaded: form_helper
INFO - 2022-02-15 14:18:06 --> Helper loaded: common_helper
INFO - 2022-02-15 14:18:06 --> Database Driver Class Initialized
DEBUG - 2022-02-15 14:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-15 14:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-15 14:18:06 --> Controller Class Initialized
INFO - 2022-02-15 14:18:06 --> Form Validation Class Initialized
DEBUG - 2022-02-15 14:18:06 --> Encrypt Class Initialized
DEBUG - 2022-02-15 14:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-15 14:18:06 --> Email Class Initialized
INFO - 2022-02-15 14:18:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-15 14:18:06 --> Calendar Class Initialized
INFO - 2022-02-15 14:18:06 --> Model "Login_model" initialized
INFO - 2022-02-15 14:18:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-15 14:18:06 --> Final output sent to browser
DEBUG - 2022-02-15 14:18:06 --> Total execution time: 0.0240
ERROR - 2022-02-15 14:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-15 14:18:06 --> Config Class Initialized
INFO - 2022-02-15 14:18:06 --> Hooks Class Initialized
DEBUG - 2022-02-15 14:18:06 --> UTF-8 Support Enabled
INFO - 2022-02-15 14:18:06 --> Utf8 Class Initialized
INFO - 2022-02-15 14:18:06 --> URI Class Initialized
INFO - 2022-02-15 14:18:06 --> Router Class Initialized
INFO - 2022-02-15 14:18:06 --> Output Class Initialized
INFO - 2022-02-15 14:18:06 --> Security Class Initialized
DEBUG - 2022-02-15 14:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-15 14:18:06 --> Input Class Initialized
INFO - 2022-02-15 14:18:06 --> Language Class Initialized
ERROR - 2022-02-15 14:18:06 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-15 14:18:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-15 14:18:14 --> Config Class Initialized
INFO - 2022-02-15 14:18:14 --> Hooks Class Initialized
DEBUG - 2022-02-15 14:18:14 --> UTF-8 Support Enabled
INFO - 2022-02-15 14:18:14 --> Utf8 Class Initialized
INFO - 2022-02-15 14:18:14 --> URI Class Initialized
INFO - 2022-02-15 14:18:14 --> Router Class Initialized
INFO - 2022-02-15 14:18:14 --> Output Class Initialized
INFO - 2022-02-15 14:18:14 --> Security Class Initialized
DEBUG - 2022-02-15 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-15 14:18:14 --> Input Class Initialized
INFO - 2022-02-15 14:18:14 --> Language Class Initialized
INFO - 2022-02-15 14:18:14 --> Loader Class Initialized
INFO - 2022-02-15 14:18:14 --> Helper loaded: url_helper
INFO - 2022-02-15 14:18:14 --> Helper loaded: form_helper
INFO - 2022-02-15 14:18:14 --> Helper loaded: common_helper
INFO - 2022-02-15 14:18:14 --> Database Driver Class Initialized
DEBUG - 2022-02-15 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-15 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-15 14:18:14 --> Controller Class Initialized
INFO - 2022-02-15 14:18:14 --> Form Validation Class Initialized
DEBUG - 2022-02-15 14:18:14 --> Encrypt Class Initialized
DEBUG - 2022-02-15 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-15 14:18:14 --> Email Class Initialized
INFO - 2022-02-15 14:18:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-15 14:18:14 --> Calendar Class Initialized
INFO - 2022-02-15 14:18:14 --> Model "Login_model" initialized
INFO - 2022-02-15 14:18:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-15 14:18:14 --> Final output sent to browser
DEBUG - 2022-02-15 14:18:14 --> Total execution time: 0.0322
ERROR - 2022-02-15 14:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-15 14:18:15 --> Config Class Initialized
INFO - 2022-02-15 14:18:15 --> Hooks Class Initialized
DEBUG - 2022-02-15 14:18:15 --> UTF-8 Support Enabled
INFO - 2022-02-15 14:18:15 --> Utf8 Class Initialized
INFO - 2022-02-15 14:18:15 --> URI Class Initialized
DEBUG - 2022-02-15 14:18:15 --> No URI present. Default controller set.
INFO - 2022-02-15 14:18:15 --> Router Class Initialized
INFO - 2022-02-15 14:18:15 --> Output Class Initialized
INFO - 2022-02-15 14:18:15 --> Security Class Initialized
DEBUG - 2022-02-15 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-15 14:18:15 --> Input Class Initialized
INFO - 2022-02-15 14:18:15 --> Language Class Initialized
INFO - 2022-02-15 14:18:15 --> Loader Class Initialized
INFO - 2022-02-15 14:18:15 --> Helper loaded: url_helper
INFO - 2022-02-15 14:18:15 --> Helper loaded: form_helper
INFO - 2022-02-15 14:18:15 --> Helper loaded: common_helper
INFO - 2022-02-15 14:18:15 --> Database Driver Class Initialized
DEBUG - 2022-02-15 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-15 14:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-15 14:18:15 --> Controller Class Initialized
INFO - 2022-02-15 14:18:15 --> Form Validation Class Initialized
DEBUG - 2022-02-15 14:18:15 --> Encrypt Class Initialized
DEBUG - 2022-02-15 14:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-15 14:18:15 --> Email Class Initialized
INFO - 2022-02-15 14:18:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-15 14:18:15 --> Calendar Class Initialized
INFO - 2022-02-15 14:18:15 --> Model "Login_model" initialized
INFO - 2022-02-15 14:18:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-15 14:18:15 --> Final output sent to browser
DEBUG - 2022-02-15 14:18:15 --> Total execution time: 0.0288
ERROR - 2022-02-15 14:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-15 14:18:15 --> Config Class Initialized
INFO - 2022-02-15 14:18:15 --> Hooks Class Initialized
DEBUG - 2022-02-15 14:18:15 --> UTF-8 Support Enabled
INFO - 2022-02-15 14:18:15 --> Utf8 Class Initialized
INFO - 2022-02-15 14:18:15 --> URI Class Initialized
INFO - 2022-02-15 14:18:15 --> Router Class Initialized
INFO - 2022-02-15 14:18:15 --> Output Class Initialized
INFO - 2022-02-15 14:18:15 --> Security Class Initialized
DEBUG - 2022-02-15 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-15 14:18:15 --> Input Class Initialized
INFO - 2022-02-15 14:18:15 --> Language Class Initialized
INFO - 2022-02-15 14:18:15 --> Loader Class Initialized
INFO - 2022-02-15 14:18:15 --> Helper loaded: url_helper
INFO - 2022-02-15 14:18:15 --> Helper loaded: form_helper
INFO - 2022-02-15 14:18:15 --> Helper loaded: common_helper
INFO - 2022-02-15 14:18:15 --> Database Driver Class Initialized
DEBUG - 2022-02-15 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-15 14:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-15 14:18:15 --> Controller Class Initialized
INFO - 2022-02-15 14:18:15 --> Form Validation Class Initialized
DEBUG - 2022-02-15 14:18:15 --> Encrypt Class Initialized
DEBUG - 2022-02-15 14:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-15 14:18:15 --> Email Class Initialized
INFO - 2022-02-15 14:18:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-15 14:18:15 --> Calendar Class Initialized
INFO - 2022-02-15 14:18:15 --> Model "Login_model" initialized
ERROR - 2022-02-15 14:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-15 14:18:16 --> Config Class Initialized
INFO - 2022-02-15 14:18:16 --> Hooks Class Initialized
DEBUG - 2022-02-15 14:18:16 --> UTF-8 Support Enabled
INFO - 2022-02-15 14:18:16 --> Utf8 Class Initialized
INFO - 2022-02-15 14:18:16 --> URI Class Initialized
INFO - 2022-02-15 14:18:16 --> Router Class Initialized
INFO - 2022-02-15 14:18:16 --> Output Class Initialized
INFO - 2022-02-15 14:18:16 --> Security Class Initialized
DEBUG - 2022-02-15 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-15 14:18:16 --> Input Class Initialized
INFO - 2022-02-15 14:18:16 --> Language Class Initialized
INFO - 2022-02-15 14:18:16 --> Loader Class Initialized
INFO - 2022-02-15 14:18:16 --> Helper loaded: url_helper
INFO - 2022-02-15 14:18:16 --> Helper loaded: form_helper
INFO - 2022-02-15 14:18:16 --> Helper loaded: common_helper
INFO - 2022-02-15 14:18:16 --> Database Driver Class Initialized
DEBUG - 2022-02-15 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-15 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-15 14:18:16 --> Controller Class Initialized
INFO - 2022-02-15 14:18:16 --> Form Validation Class Initialized
DEBUG - 2022-02-15 14:18:16 --> Encrypt Class Initialized
DEBUG - 2022-02-15 14:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-15 14:18:16 --> Email Class Initialized
INFO - 2022-02-15 14:18:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-15 14:18:16 --> Calendar Class Initialized
INFO - 2022-02-15 14:18:16 --> Model "Login_model" initialized
ERROR - 2022-02-15 15:44:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-15 15:44:52 --> Config Class Initialized
INFO - 2022-02-15 15:44:52 --> Hooks Class Initialized
DEBUG - 2022-02-15 15:44:52 --> UTF-8 Support Enabled
INFO - 2022-02-15 15:44:52 --> Utf8 Class Initialized
INFO - 2022-02-15 15:44:52 --> URI Class Initialized
DEBUG - 2022-02-15 15:44:52 --> No URI present. Default controller set.
INFO - 2022-02-15 15:44:52 --> Router Class Initialized
INFO - 2022-02-15 15:44:52 --> Output Class Initialized
INFO - 2022-02-15 15:44:52 --> Security Class Initialized
DEBUG - 2022-02-15 15:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-15 15:44:52 --> Input Class Initialized
INFO - 2022-02-15 15:44:52 --> Language Class Initialized
INFO - 2022-02-15 15:44:52 --> Loader Class Initialized
INFO - 2022-02-15 15:44:52 --> Helper loaded: url_helper
INFO - 2022-02-15 15:44:52 --> Helper loaded: form_helper
INFO - 2022-02-15 15:44:52 --> Helper loaded: common_helper
INFO - 2022-02-15 15:44:52 --> Database Driver Class Initialized
DEBUG - 2022-02-15 15:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-15 15:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-15 15:44:52 --> Controller Class Initialized
INFO - 2022-02-15 15:44:52 --> Form Validation Class Initialized
DEBUG - 2022-02-15 15:44:52 --> Encrypt Class Initialized
DEBUG - 2022-02-15 15:44:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:44:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-15 15:44:52 --> Email Class Initialized
INFO - 2022-02-15 15:44:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-15 15:44:52 --> Calendar Class Initialized
INFO - 2022-02-15 15:44:52 --> Model "Login_model" initialized
INFO - 2022-02-15 15:44:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-15 15:44:52 --> Final output sent to browser
DEBUG - 2022-02-15 15:44:52 --> Total execution time: 0.0244
ERROR - 2022-02-15 20:15:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-15 20:15:42 --> Config Class Initialized
INFO - 2022-02-15 20:15:42 --> Hooks Class Initialized
DEBUG - 2022-02-15 20:15:42 --> UTF-8 Support Enabled
INFO - 2022-02-15 20:15:42 --> Utf8 Class Initialized
INFO - 2022-02-15 20:15:42 --> URI Class Initialized
DEBUG - 2022-02-15 20:15:42 --> No URI present. Default controller set.
INFO - 2022-02-15 20:15:42 --> Router Class Initialized
INFO - 2022-02-15 20:15:42 --> Output Class Initialized
INFO - 2022-02-15 20:15:42 --> Security Class Initialized
DEBUG - 2022-02-15 20:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-15 20:15:42 --> Input Class Initialized
INFO - 2022-02-15 20:15:42 --> Language Class Initialized
INFO - 2022-02-15 20:15:42 --> Loader Class Initialized
INFO - 2022-02-15 20:15:42 --> Helper loaded: url_helper
INFO - 2022-02-15 20:15:42 --> Helper loaded: form_helper
INFO - 2022-02-15 20:15:42 --> Helper loaded: common_helper
INFO - 2022-02-15 20:15:42 --> Database Driver Class Initialized
DEBUG - 2022-02-15 20:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-15 20:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-15 20:15:42 --> Controller Class Initialized
INFO - 2022-02-15 20:15:42 --> Form Validation Class Initialized
DEBUG - 2022-02-15 20:15:42 --> Encrypt Class Initialized
DEBUG - 2022-02-15 20:15:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 20:15:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-15 20:15:42 --> Email Class Initialized
INFO - 2022-02-15 20:15:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-15 20:15:42 --> Calendar Class Initialized
INFO - 2022-02-15 20:15:42 --> Model "Login_model" initialized
INFO - 2022-02-15 20:15:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-15 20:15:42 --> Final output sent to browser
DEBUG - 2022-02-15 20:15:42 --> Total execution time: 0.0270
