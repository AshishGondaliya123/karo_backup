<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-13 00:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 00:08:37 --> Config Class Initialized
INFO - 2021-12-13 00:08:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 00:08:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 00:08:37 --> Utf8 Class Initialized
INFO - 2021-12-13 00:08:37 --> URI Class Initialized
DEBUG - 2021-12-13 00:08:37 --> No URI present. Default controller set.
INFO - 2021-12-13 00:08:37 --> Router Class Initialized
INFO - 2021-12-13 00:08:37 --> Output Class Initialized
INFO - 2021-12-13 00:08:37 --> Security Class Initialized
DEBUG - 2021-12-13 00:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 00:08:37 --> Input Class Initialized
INFO - 2021-12-13 00:08:37 --> Language Class Initialized
INFO - 2021-12-13 00:08:37 --> Loader Class Initialized
INFO - 2021-12-13 00:08:37 --> Helper loaded: url_helper
INFO - 2021-12-13 00:08:37 --> Helper loaded: form_helper
INFO - 2021-12-13 00:08:37 --> Helper loaded: common_helper
INFO - 2021-12-13 00:08:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 00:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 00:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 00:08:37 --> Controller Class Initialized
INFO - 2021-12-13 00:08:37 --> Form Validation Class Initialized
DEBUG - 2021-12-13 00:08:37 --> Encrypt Class Initialized
DEBUG - 2021-12-13 00:08:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 00:08:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 00:08:37 --> Email Class Initialized
INFO - 2021-12-13 00:08:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 00:08:37 --> Calendar Class Initialized
INFO - 2021-12-13 00:08:37 --> Model "Login_model" initialized
INFO - 2021-12-13 00:08:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 00:08:37 --> Final output sent to browser
DEBUG - 2021-12-13 00:08:37 --> Total execution time: 0.0225
ERROR - 2021-12-13 01:15:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 01:15:09 --> Config Class Initialized
INFO - 2021-12-13 01:15:09 --> Hooks Class Initialized
DEBUG - 2021-12-13 01:15:09 --> UTF-8 Support Enabled
INFO - 2021-12-13 01:15:09 --> Utf8 Class Initialized
INFO - 2021-12-13 01:15:09 --> URI Class Initialized
DEBUG - 2021-12-13 01:15:09 --> No URI present. Default controller set.
INFO - 2021-12-13 01:15:09 --> Router Class Initialized
INFO - 2021-12-13 01:15:09 --> Output Class Initialized
INFO - 2021-12-13 01:15:09 --> Security Class Initialized
DEBUG - 2021-12-13 01:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 01:15:09 --> Input Class Initialized
INFO - 2021-12-13 01:15:09 --> Language Class Initialized
INFO - 2021-12-13 01:15:09 --> Loader Class Initialized
INFO - 2021-12-13 01:15:09 --> Helper loaded: url_helper
INFO - 2021-12-13 01:15:09 --> Helper loaded: form_helper
INFO - 2021-12-13 01:15:09 --> Helper loaded: common_helper
INFO - 2021-12-13 01:15:09 --> Database Driver Class Initialized
DEBUG - 2021-12-13 01:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 01:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 01:15:09 --> Controller Class Initialized
INFO - 2021-12-13 01:15:09 --> Form Validation Class Initialized
DEBUG - 2021-12-13 01:15:09 --> Encrypt Class Initialized
DEBUG - 2021-12-13 01:15:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 01:15:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 01:15:09 --> Email Class Initialized
INFO - 2021-12-13 01:15:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 01:15:09 --> Calendar Class Initialized
INFO - 2021-12-13 01:15:09 --> Model "Login_model" initialized
INFO - 2021-12-13 01:15:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 01:15:09 --> Final output sent to browser
DEBUG - 2021-12-13 01:15:09 --> Total execution time: 0.0225
ERROR - 2021-12-13 02:08:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 02:08:27 --> Config Class Initialized
INFO - 2021-12-13 02:08:27 --> Hooks Class Initialized
DEBUG - 2021-12-13 02:08:27 --> UTF-8 Support Enabled
INFO - 2021-12-13 02:08:27 --> Utf8 Class Initialized
INFO - 2021-12-13 02:08:27 --> URI Class Initialized
DEBUG - 2021-12-13 02:08:27 --> No URI present. Default controller set.
INFO - 2021-12-13 02:08:27 --> Router Class Initialized
INFO - 2021-12-13 02:08:27 --> Output Class Initialized
INFO - 2021-12-13 02:08:27 --> Security Class Initialized
DEBUG - 2021-12-13 02:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 02:08:27 --> Input Class Initialized
INFO - 2021-12-13 02:08:27 --> Language Class Initialized
INFO - 2021-12-13 02:08:27 --> Loader Class Initialized
INFO - 2021-12-13 02:08:27 --> Helper loaded: url_helper
INFO - 2021-12-13 02:08:27 --> Helper loaded: form_helper
INFO - 2021-12-13 02:08:27 --> Helper loaded: common_helper
INFO - 2021-12-13 02:08:27 --> Database Driver Class Initialized
DEBUG - 2021-12-13 02:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 02:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 02:08:27 --> Controller Class Initialized
INFO - 2021-12-13 02:08:27 --> Form Validation Class Initialized
DEBUG - 2021-12-13 02:08:27 --> Encrypt Class Initialized
DEBUG - 2021-12-13 02:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 02:08:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 02:08:27 --> Email Class Initialized
INFO - 2021-12-13 02:08:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 02:08:27 --> Calendar Class Initialized
INFO - 2021-12-13 02:08:27 --> Model "Login_model" initialized
INFO - 2021-12-13 02:08:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 02:08:27 --> Final output sent to browser
DEBUG - 2021-12-13 02:08:27 --> Total execution time: 0.0229
ERROR - 2021-12-13 06:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 06:21:21 --> Config Class Initialized
INFO - 2021-12-13 06:21:21 --> Hooks Class Initialized
DEBUG - 2021-12-13 06:21:21 --> UTF-8 Support Enabled
INFO - 2021-12-13 06:21:21 --> Utf8 Class Initialized
INFO - 2021-12-13 06:21:21 --> URI Class Initialized
DEBUG - 2021-12-13 06:21:21 --> No URI present. Default controller set.
INFO - 2021-12-13 06:21:21 --> Router Class Initialized
INFO - 2021-12-13 06:21:21 --> Output Class Initialized
INFO - 2021-12-13 06:21:21 --> Security Class Initialized
DEBUG - 2021-12-13 06:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 06:21:21 --> Input Class Initialized
INFO - 2021-12-13 06:21:21 --> Language Class Initialized
INFO - 2021-12-13 06:21:21 --> Loader Class Initialized
INFO - 2021-12-13 06:21:21 --> Helper loaded: url_helper
INFO - 2021-12-13 06:21:21 --> Helper loaded: form_helper
INFO - 2021-12-13 06:21:21 --> Helper loaded: common_helper
INFO - 2021-12-13 06:21:21 --> Database Driver Class Initialized
DEBUG - 2021-12-13 06:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 06:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 06:21:21 --> Controller Class Initialized
INFO - 2021-12-13 06:21:21 --> Form Validation Class Initialized
DEBUG - 2021-12-13 06:21:21 --> Encrypt Class Initialized
DEBUG - 2021-12-13 06:21:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 06:21:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 06:21:21 --> Email Class Initialized
INFO - 2021-12-13 06:21:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 06:21:21 --> Calendar Class Initialized
INFO - 2021-12-13 06:21:21 --> Model "Login_model" initialized
INFO - 2021-12-13 06:21:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 06:21:21 --> Final output sent to browser
DEBUG - 2021-12-13 06:21:21 --> Total execution time: 0.0246
ERROR - 2021-12-13 07:30:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 07:30:12 --> Config Class Initialized
INFO - 2021-12-13 07:30:12 --> Hooks Class Initialized
DEBUG - 2021-12-13 07:30:12 --> UTF-8 Support Enabled
INFO - 2021-12-13 07:30:12 --> Utf8 Class Initialized
INFO - 2021-12-13 07:30:12 --> URI Class Initialized
DEBUG - 2021-12-13 07:30:12 --> No URI present. Default controller set.
INFO - 2021-12-13 07:30:12 --> Router Class Initialized
INFO - 2021-12-13 07:30:12 --> Output Class Initialized
INFO - 2021-12-13 07:30:12 --> Security Class Initialized
DEBUG - 2021-12-13 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 07:30:12 --> Input Class Initialized
INFO - 2021-12-13 07:30:12 --> Language Class Initialized
INFO - 2021-12-13 07:30:12 --> Loader Class Initialized
INFO - 2021-12-13 07:30:12 --> Helper loaded: url_helper
INFO - 2021-12-13 07:30:12 --> Helper loaded: form_helper
INFO - 2021-12-13 07:30:12 --> Helper loaded: common_helper
INFO - 2021-12-13 07:30:12 --> Database Driver Class Initialized
DEBUG - 2021-12-13 07:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 07:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 07:30:12 --> Controller Class Initialized
INFO - 2021-12-13 07:30:12 --> Form Validation Class Initialized
DEBUG - 2021-12-13 07:30:12 --> Encrypt Class Initialized
DEBUG - 2021-12-13 07:30:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 07:30:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 07:30:12 --> Email Class Initialized
INFO - 2021-12-13 07:30:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 07:30:12 --> Calendar Class Initialized
INFO - 2021-12-13 07:30:12 --> Model "Login_model" initialized
INFO - 2021-12-13 07:30:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 07:30:12 --> Final output sent to browser
DEBUG - 2021-12-13 07:30:12 --> Total execution time: 0.0230
ERROR - 2021-12-13 08:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 08:21:55 --> Config Class Initialized
INFO - 2021-12-13 08:21:55 --> Hooks Class Initialized
DEBUG - 2021-12-13 08:21:55 --> UTF-8 Support Enabled
INFO - 2021-12-13 08:21:55 --> Utf8 Class Initialized
INFO - 2021-12-13 08:21:55 --> URI Class Initialized
DEBUG - 2021-12-13 08:21:55 --> No URI present. Default controller set.
INFO - 2021-12-13 08:21:55 --> Router Class Initialized
INFO - 2021-12-13 08:21:55 --> Output Class Initialized
INFO - 2021-12-13 08:21:55 --> Security Class Initialized
DEBUG - 2021-12-13 08:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 08:21:55 --> Input Class Initialized
INFO - 2021-12-13 08:21:55 --> Language Class Initialized
INFO - 2021-12-13 08:21:55 --> Loader Class Initialized
INFO - 2021-12-13 08:21:55 --> Helper loaded: url_helper
INFO - 2021-12-13 08:21:55 --> Helper loaded: form_helper
INFO - 2021-12-13 08:21:55 --> Helper loaded: common_helper
INFO - 2021-12-13 08:21:55 --> Database Driver Class Initialized
DEBUG - 2021-12-13 08:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 08:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 08:21:55 --> Controller Class Initialized
INFO - 2021-12-13 08:21:55 --> Form Validation Class Initialized
DEBUG - 2021-12-13 08:21:55 --> Encrypt Class Initialized
DEBUG - 2021-12-13 08:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 08:21:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 08:21:55 --> Email Class Initialized
INFO - 2021-12-13 08:21:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 08:21:55 --> Calendar Class Initialized
INFO - 2021-12-13 08:21:55 --> Model "Login_model" initialized
INFO - 2021-12-13 08:21:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 08:21:55 --> Final output sent to browser
DEBUG - 2021-12-13 08:21:55 --> Total execution time: 0.0271
ERROR - 2021-12-13 12:07:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 12:07:43 --> Config Class Initialized
INFO - 2021-12-13 12:07:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 12:07:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 12:07:43 --> Utf8 Class Initialized
INFO - 2021-12-13 12:07:43 --> URI Class Initialized
DEBUG - 2021-12-13 12:07:43 --> No URI present. Default controller set.
INFO - 2021-12-13 12:07:43 --> Router Class Initialized
INFO - 2021-12-13 12:07:43 --> Output Class Initialized
INFO - 2021-12-13 12:07:43 --> Security Class Initialized
DEBUG - 2021-12-13 12:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 12:07:43 --> Input Class Initialized
INFO - 2021-12-13 12:07:43 --> Language Class Initialized
INFO - 2021-12-13 12:07:43 --> Loader Class Initialized
INFO - 2021-12-13 12:07:43 --> Helper loaded: url_helper
INFO - 2021-12-13 12:07:43 --> Helper loaded: form_helper
INFO - 2021-12-13 12:07:43 --> Helper loaded: common_helper
INFO - 2021-12-13 12:07:43 --> Database Driver Class Initialized
DEBUG - 2021-12-13 12:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 12:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 12:07:43 --> Controller Class Initialized
INFO - 2021-12-13 12:07:43 --> Form Validation Class Initialized
DEBUG - 2021-12-13 12:07:43 --> Encrypt Class Initialized
DEBUG - 2021-12-13 12:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 12:07:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 12:07:43 --> Email Class Initialized
INFO - 2021-12-13 12:07:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 12:07:43 --> Calendar Class Initialized
INFO - 2021-12-13 12:07:43 --> Model "Login_model" initialized
INFO - 2021-12-13 12:07:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 12:07:43 --> Final output sent to browser
DEBUG - 2021-12-13 12:07:43 --> Total execution time: 0.0364
ERROR - 2021-12-13 14:17:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 14:17:18 --> Config Class Initialized
INFO - 2021-12-13 14:17:18 --> Hooks Class Initialized
DEBUG - 2021-12-13 14:17:18 --> UTF-8 Support Enabled
INFO - 2021-12-13 14:17:18 --> Utf8 Class Initialized
INFO - 2021-12-13 14:17:18 --> URI Class Initialized
DEBUG - 2021-12-13 14:17:18 --> No URI present. Default controller set.
INFO - 2021-12-13 14:17:18 --> Router Class Initialized
INFO - 2021-12-13 14:17:18 --> Output Class Initialized
INFO - 2021-12-13 14:17:18 --> Security Class Initialized
DEBUG - 2021-12-13 14:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 14:17:18 --> Input Class Initialized
INFO - 2021-12-13 14:17:18 --> Language Class Initialized
INFO - 2021-12-13 14:17:18 --> Loader Class Initialized
INFO - 2021-12-13 14:17:18 --> Helper loaded: url_helper
INFO - 2021-12-13 14:17:18 --> Helper loaded: form_helper
INFO - 2021-12-13 14:17:18 --> Helper loaded: common_helper
INFO - 2021-12-13 14:17:18 --> Database Driver Class Initialized
DEBUG - 2021-12-13 14:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 14:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 14:17:18 --> Controller Class Initialized
INFO - 2021-12-13 14:17:18 --> Form Validation Class Initialized
DEBUG - 2021-12-13 14:17:18 --> Encrypt Class Initialized
DEBUG - 2021-12-13 14:17:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 14:17:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 14:17:18 --> Email Class Initialized
INFO - 2021-12-13 14:17:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 14:17:18 --> Calendar Class Initialized
INFO - 2021-12-13 14:17:18 --> Model "Login_model" initialized
INFO - 2021-12-13 14:17:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 14:17:18 --> Final output sent to browser
DEBUG - 2021-12-13 14:17:18 --> Total execution time: 0.1156
ERROR - 2021-12-13 14:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 14:17:21 --> Config Class Initialized
INFO - 2021-12-13 14:17:21 --> Hooks Class Initialized
DEBUG - 2021-12-13 14:17:21 --> UTF-8 Support Enabled
INFO - 2021-12-13 14:17:21 --> Utf8 Class Initialized
INFO - 2021-12-13 14:17:21 --> URI Class Initialized
INFO - 2021-12-13 14:17:21 --> Router Class Initialized
INFO - 2021-12-13 14:17:21 --> Output Class Initialized
INFO - 2021-12-13 14:17:21 --> Security Class Initialized
DEBUG - 2021-12-13 14:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 14:17:21 --> Input Class Initialized
INFO - 2021-12-13 14:17:21 --> Language Class Initialized
ERROR - 2021-12-13 14:17:21 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-13 14:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 14:17:36 --> Config Class Initialized
INFO - 2021-12-13 14:17:36 --> Hooks Class Initialized
DEBUG - 2021-12-13 14:17:36 --> UTF-8 Support Enabled
INFO - 2021-12-13 14:17:36 --> Utf8 Class Initialized
INFO - 2021-12-13 14:17:36 --> URI Class Initialized
INFO - 2021-12-13 14:17:36 --> Router Class Initialized
INFO - 2021-12-13 14:17:36 --> Output Class Initialized
INFO - 2021-12-13 14:17:36 --> Security Class Initialized
DEBUG - 2021-12-13 14:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 14:17:36 --> Input Class Initialized
INFO - 2021-12-13 14:17:36 --> Language Class Initialized
INFO - 2021-12-13 14:17:36 --> Loader Class Initialized
INFO - 2021-12-13 14:17:36 --> Helper loaded: url_helper
INFO - 2021-12-13 14:17:36 --> Helper loaded: form_helper
INFO - 2021-12-13 14:17:36 --> Helper loaded: common_helper
INFO - 2021-12-13 14:17:36 --> Database Driver Class Initialized
DEBUG - 2021-12-13 14:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 14:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 14:17:36 --> Controller Class Initialized
INFO - 2021-12-13 14:17:36 --> Form Validation Class Initialized
DEBUG - 2021-12-13 14:17:36 --> Encrypt Class Initialized
DEBUG - 2021-12-13 14:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 14:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 14:17:36 --> Email Class Initialized
INFO - 2021-12-13 14:17:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 14:17:36 --> Calendar Class Initialized
INFO - 2021-12-13 14:17:36 --> Model "Login_model" initialized
ERROR - 2021-12-13 14:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 14:17:37 --> Config Class Initialized
INFO - 2021-12-13 14:17:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 14:17:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 14:17:37 --> Utf8 Class Initialized
INFO - 2021-12-13 14:17:37 --> URI Class Initialized
INFO - 2021-12-13 14:17:37 --> Router Class Initialized
INFO - 2021-12-13 14:17:37 --> Output Class Initialized
INFO - 2021-12-13 14:17:37 --> Security Class Initialized
DEBUG - 2021-12-13 14:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 14:17:37 --> Input Class Initialized
INFO - 2021-12-13 14:17:37 --> Language Class Initialized
INFO - 2021-12-13 14:17:37 --> Loader Class Initialized
INFO - 2021-12-13 14:17:37 --> Helper loaded: url_helper
INFO - 2021-12-13 14:17:37 --> Helper loaded: form_helper
INFO - 2021-12-13 14:17:37 --> Helper loaded: common_helper
INFO - 2021-12-13 14:17:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 14:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 14:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 14:17:37 --> Controller Class Initialized
INFO - 2021-12-13 14:17:37 --> Form Validation Class Initialized
DEBUG - 2021-12-13 14:17:37 --> Encrypt Class Initialized
DEBUG - 2021-12-13 14:17:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 14:17:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 14:17:37 --> Email Class Initialized
INFO - 2021-12-13 14:17:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 14:17:37 --> Calendar Class Initialized
INFO - 2021-12-13 14:17:37 --> Model "Login_model" initialized
ERROR - 2021-12-13 14:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 14:17:37 --> Config Class Initialized
INFO - 2021-12-13 14:17:37 --> Hooks Class Initialized
DEBUG - 2021-12-13 14:17:37 --> UTF-8 Support Enabled
INFO - 2021-12-13 14:17:37 --> Utf8 Class Initialized
INFO - 2021-12-13 14:17:37 --> URI Class Initialized
DEBUG - 2021-12-13 14:17:37 --> No URI present. Default controller set.
INFO - 2021-12-13 14:17:37 --> Router Class Initialized
INFO - 2021-12-13 14:17:37 --> Output Class Initialized
INFO - 2021-12-13 14:17:37 --> Security Class Initialized
DEBUG - 2021-12-13 14:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 14:17:37 --> Input Class Initialized
INFO - 2021-12-13 14:17:37 --> Language Class Initialized
INFO - 2021-12-13 14:17:37 --> Loader Class Initialized
INFO - 2021-12-13 14:17:37 --> Helper loaded: url_helper
INFO - 2021-12-13 14:17:37 --> Helper loaded: form_helper
INFO - 2021-12-13 14:17:37 --> Helper loaded: common_helper
INFO - 2021-12-13 14:17:37 --> Database Driver Class Initialized
DEBUG - 2021-12-13 14:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 14:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 14:17:37 --> Controller Class Initialized
INFO - 2021-12-13 14:17:37 --> Form Validation Class Initialized
DEBUG - 2021-12-13 14:17:37 --> Encrypt Class Initialized
DEBUG - 2021-12-13 14:17:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 14:17:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 14:17:37 --> Email Class Initialized
INFO - 2021-12-13 14:17:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 14:17:37 --> Calendar Class Initialized
INFO - 2021-12-13 14:17:37 --> Model "Login_model" initialized
INFO - 2021-12-13 14:17:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 14:17:37 --> Final output sent to browser
DEBUG - 2021-12-13 14:17:37 --> Total execution time: 0.0264
ERROR - 2021-12-13 14:17:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 14:17:38 --> Config Class Initialized
INFO - 2021-12-13 14:17:38 --> Hooks Class Initialized
DEBUG - 2021-12-13 14:17:38 --> UTF-8 Support Enabled
INFO - 2021-12-13 14:17:38 --> Utf8 Class Initialized
INFO - 2021-12-13 14:17:38 --> URI Class Initialized
INFO - 2021-12-13 14:17:38 --> Router Class Initialized
INFO - 2021-12-13 14:17:38 --> Output Class Initialized
INFO - 2021-12-13 14:17:38 --> Security Class Initialized
DEBUG - 2021-12-13 14:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 14:17:38 --> Input Class Initialized
INFO - 2021-12-13 14:17:38 --> Language Class Initialized
INFO - 2021-12-13 14:17:38 --> Loader Class Initialized
INFO - 2021-12-13 14:17:38 --> Helper loaded: url_helper
INFO - 2021-12-13 14:17:38 --> Helper loaded: form_helper
INFO - 2021-12-13 14:17:38 --> Helper loaded: common_helper
INFO - 2021-12-13 14:17:38 --> Database Driver Class Initialized
DEBUG - 2021-12-13 14:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 14:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 14:17:38 --> Controller Class Initialized
INFO - 2021-12-13 14:17:38 --> Form Validation Class Initialized
DEBUG - 2021-12-13 14:17:38 --> Encrypt Class Initialized
DEBUG - 2021-12-13 14:17:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 14:17:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 14:17:38 --> Email Class Initialized
INFO - 2021-12-13 14:17:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 14:17:38 --> Calendar Class Initialized
INFO - 2021-12-13 14:17:38 --> Model "Login_model" initialized
INFO - 2021-12-13 14:17:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 14:17:38 --> Final output sent to browser
DEBUG - 2021-12-13 14:17:38 --> Total execution time: 0.0289
ERROR - 2021-12-13 15:05:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 15:05:31 --> Config Class Initialized
INFO - 2021-12-13 15:05:31 --> Hooks Class Initialized
DEBUG - 2021-12-13 15:05:31 --> UTF-8 Support Enabled
INFO - 2021-12-13 15:05:31 --> Utf8 Class Initialized
INFO - 2021-12-13 15:05:31 --> URI Class Initialized
DEBUG - 2021-12-13 15:05:31 --> No URI present. Default controller set.
INFO - 2021-12-13 15:05:31 --> Router Class Initialized
INFO - 2021-12-13 15:05:31 --> Output Class Initialized
INFO - 2021-12-13 15:05:31 --> Security Class Initialized
DEBUG - 2021-12-13 15:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 15:05:31 --> Input Class Initialized
INFO - 2021-12-13 15:05:31 --> Language Class Initialized
INFO - 2021-12-13 15:05:31 --> Loader Class Initialized
INFO - 2021-12-13 15:05:31 --> Helper loaded: url_helper
INFO - 2021-12-13 15:05:31 --> Helper loaded: form_helper
INFO - 2021-12-13 15:05:31 --> Helper loaded: common_helper
INFO - 2021-12-13 15:05:31 --> Database Driver Class Initialized
DEBUG - 2021-12-13 15:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 15:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 15:05:31 --> Controller Class Initialized
INFO - 2021-12-13 15:05:31 --> Form Validation Class Initialized
DEBUG - 2021-12-13 15:05:31 --> Encrypt Class Initialized
DEBUG - 2021-12-13 15:05:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 15:05:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 15:05:31 --> Email Class Initialized
INFO - 2021-12-13 15:05:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 15:05:31 --> Calendar Class Initialized
INFO - 2021-12-13 15:05:31 --> Model "Login_model" initialized
INFO - 2021-12-13 15:05:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 15:05:31 --> Final output sent to browser
DEBUG - 2021-12-13 15:05:31 --> Total execution time: 0.0307
ERROR - 2021-12-13 15:32:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 15:32:04 --> Config Class Initialized
INFO - 2021-12-13 15:32:04 --> Hooks Class Initialized
DEBUG - 2021-12-13 15:32:04 --> UTF-8 Support Enabled
INFO - 2021-12-13 15:32:04 --> Utf8 Class Initialized
INFO - 2021-12-13 15:32:04 --> URI Class Initialized
DEBUG - 2021-12-13 15:32:04 --> No URI present. Default controller set.
INFO - 2021-12-13 15:32:04 --> Router Class Initialized
INFO - 2021-12-13 15:32:04 --> Output Class Initialized
INFO - 2021-12-13 15:32:04 --> Security Class Initialized
DEBUG - 2021-12-13 15:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 15:32:04 --> Input Class Initialized
INFO - 2021-12-13 15:32:04 --> Language Class Initialized
INFO - 2021-12-13 15:32:04 --> Loader Class Initialized
INFO - 2021-12-13 15:32:04 --> Helper loaded: url_helper
INFO - 2021-12-13 15:32:04 --> Helper loaded: form_helper
INFO - 2021-12-13 15:32:04 --> Helper loaded: common_helper
INFO - 2021-12-13 15:32:04 --> Database Driver Class Initialized
DEBUG - 2021-12-13 15:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 15:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 15:32:04 --> Controller Class Initialized
INFO - 2021-12-13 15:32:04 --> Form Validation Class Initialized
DEBUG - 2021-12-13 15:32:04 --> Encrypt Class Initialized
DEBUG - 2021-12-13 15:32:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 15:32:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 15:32:04 --> Email Class Initialized
INFO - 2021-12-13 15:32:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 15:32:04 --> Calendar Class Initialized
INFO - 2021-12-13 15:32:04 --> Model "Login_model" initialized
INFO - 2021-12-13 15:32:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 15:32:04 --> Final output sent to browser
DEBUG - 2021-12-13 15:32:04 --> Total execution time: 0.0425
ERROR - 2021-12-13 17:09:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 17:09:13 --> Config Class Initialized
INFO - 2021-12-13 17:09:13 --> Hooks Class Initialized
DEBUG - 2021-12-13 17:09:13 --> UTF-8 Support Enabled
INFO - 2021-12-13 17:09:13 --> Utf8 Class Initialized
INFO - 2021-12-13 17:09:13 --> URI Class Initialized
DEBUG - 2021-12-13 17:09:13 --> No URI present. Default controller set.
INFO - 2021-12-13 17:09:13 --> Router Class Initialized
INFO - 2021-12-13 17:09:13 --> Output Class Initialized
INFO - 2021-12-13 17:09:13 --> Security Class Initialized
DEBUG - 2021-12-13 17:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 17:09:13 --> Input Class Initialized
INFO - 2021-12-13 17:09:13 --> Language Class Initialized
INFO - 2021-12-13 17:09:13 --> Loader Class Initialized
INFO - 2021-12-13 17:09:13 --> Helper loaded: url_helper
INFO - 2021-12-13 17:09:13 --> Helper loaded: form_helper
INFO - 2021-12-13 17:09:13 --> Helper loaded: common_helper
INFO - 2021-12-13 17:09:13 --> Database Driver Class Initialized
DEBUG - 2021-12-13 17:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 17:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 17:09:13 --> Controller Class Initialized
INFO - 2021-12-13 17:09:13 --> Form Validation Class Initialized
DEBUG - 2021-12-13 17:09:13 --> Encrypt Class Initialized
DEBUG - 2021-12-13 17:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 17:09:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 17:09:13 --> Email Class Initialized
INFO - 2021-12-13 17:09:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 17:09:13 --> Calendar Class Initialized
INFO - 2021-12-13 17:09:13 --> Model "Login_model" initialized
INFO - 2021-12-13 17:09:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 17:09:13 --> Final output sent to browser
DEBUG - 2021-12-13 17:09:13 --> Total execution time: 0.0376
ERROR - 2021-12-13 19:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:40 --> Config Class Initialized
INFO - 2021-12-13 19:52:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:40 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:40 --> URI Class Initialized
DEBUG - 2021-12-13 19:52:40 --> No URI present. Default controller set.
INFO - 2021-12-13 19:52:40 --> Router Class Initialized
INFO - 2021-12-13 19:52:40 --> Output Class Initialized
INFO - 2021-12-13 19:52:40 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:40 --> Input Class Initialized
INFO - 2021-12-13 19:52:40 --> Language Class Initialized
INFO - 2021-12-13 19:52:40 --> Loader Class Initialized
INFO - 2021-12-13 19:52:40 --> Helper loaded: url_helper
INFO - 2021-12-13 19:52:40 --> Helper loaded: form_helper
INFO - 2021-12-13 19:52:40 --> Helper loaded: common_helper
INFO - 2021-12-13 19:52:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 19:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 19:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 19:52:40 --> Controller Class Initialized
INFO - 2021-12-13 19:52:40 --> Form Validation Class Initialized
DEBUG - 2021-12-13 19:52:40 --> Encrypt Class Initialized
DEBUG - 2021-12-13 19:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 19:52:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 19:52:40 --> Email Class Initialized
INFO - 2021-12-13 19:52:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 19:52:40 --> Calendar Class Initialized
INFO - 2021-12-13 19:52:40 --> Model "Login_model" initialized
INFO - 2021-12-13 19:52:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 19:52:40 --> Final output sent to browser
DEBUG - 2021-12-13 19:52:40 --> Total execution time: 0.0222
ERROR - 2021-12-13 19:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:40 --> Config Class Initialized
INFO - 2021-12-13 19:52:40 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:40 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:40 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:40 --> URI Class Initialized
DEBUG - 2021-12-13 19:52:40 --> No URI present. Default controller set.
INFO - 2021-12-13 19:52:40 --> Router Class Initialized
INFO - 2021-12-13 19:52:40 --> Output Class Initialized
INFO - 2021-12-13 19:52:40 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:40 --> Input Class Initialized
INFO - 2021-12-13 19:52:40 --> Language Class Initialized
INFO - 2021-12-13 19:52:40 --> Loader Class Initialized
INFO - 2021-12-13 19:52:40 --> Helper loaded: url_helper
INFO - 2021-12-13 19:52:40 --> Helper loaded: form_helper
INFO - 2021-12-13 19:52:40 --> Helper loaded: common_helper
INFO - 2021-12-13 19:52:40 --> Database Driver Class Initialized
DEBUG - 2021-12-13 19:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 19:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 19:52:40 --> Controller Class Initialized
INFO - 2021-12-13 19:52:40 --> Form Validation Class Initialized
DEBUG - 2021-12-13 19:52:40 --> Encrypt Class Initialized
DEBUG - 2021-12-13 19:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 19:52:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 19:52:40 --> Email Class Initialized
INFO - 2021-12-13 19:52:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 19:52:40 --> Calendar Class Initialized
INFO - 2021-12-13 19:52:40 --> Model "Login_model" initialized
INFO - 2021-12-13 19:52:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 19:52:40 --> Final output sent to browser
DEBUG - 2021-12-13 19:52:40 --> Total execution time: 0.0215
ERROR - 2021-12-13 19:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:41 --> Config Class Initialized
INFO - 2021-12-13 19:52:41 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:41 --> URI Class Initialized
INFO - 2021-12-13 19:52:41 --> Router Class Initialized
INFO - 2021-12-13 19:52:41 --> Output Class Initialized
INFO - 2021-12-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:41 --> Input Class Initialized
INFO - 2021-12-13 19:52:41 --> Language Class Initialized
ERROR - 2021-12-13 19:52:41 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-13 19:52:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:42 --> Config Class Initialized
INFO - 2021-12-13 19:52:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:42 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:42 --> URI Class Initialized
INFO - 2021-12-13 19:52:42 --> Router Class Initialized
INFO - 2021-12-13 19:52:42 --> Output Class Initialized
INFO - 2021-12-13 19:52:42 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:42 --> Input Class Initialized
INFO - 2021-12-13 19:52:42 --> Language Class Initialized
ERROR - 2021-12-13 19:52:42 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-13 19:52:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:42 --> Config Class Initialized
INFO - 2021-12-13 19:52:42 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:42 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:42 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:42 --> URI Class Initialized
INFO - 2021-12-13 19:52:42 --> Router Class Initialized
INFO - 2021-12-13 19:52:42 --> Output Class Initialized
INFO - 2021-12-13 19:52:42 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:42 --> Input Class Initialized
INFO - 2021-12-13 19:52:42 --> Language Class Initialized
ERROR - 2021-12-13 19:52:42 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-13 19:52:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:43 --> Config Class Initialized
INFO - 2021-12-13 19:52:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:43 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:43 --> URI Class Initialized
INFO - 2021-12-13 19:52:43 --> Router Class Initialized
INFO - 2021-12-13 19:52:43 --> Output Class Initialized
INFO - 2021-12-13 19:52:43 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:43 --> Input Class Initialized
INFO - 2021-12-13 19:52:43 --> Language Class Initialized
ERROR - 2021-12-13 19:52:43 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-13 19:52:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:43 --> Config Class Initialized
INFO - 2021-12-13 19:52:43 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:43 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:43 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:43 --> URI Class Initialized
INFO - 2021-12-13 19:52:43 --> Router Class Initialized
INFO - 2021-12-13 19:52:43 --> Output Class Initialized
INFO - 2021-12-13 19:52:43 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:43 --> Input Class Initialized
INFO - 2021-12-13 19:52:43 --> Language Class Initialized
ERROR - 2021-12-13 19:52:43 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-13 19:52:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:44 --> Config Class Initialized
INFO - 2021-12-13 19:52:44 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:44 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:44 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:44 --> URI Class Initialized
INFO - 2021-12-13 19:52:44 --> Router Class Initialized
INFO - 2021-12-13 19:52:44 --> Output Class Initialized
INFO - 2021-12-13 19:52:44 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:44 --> Input Class Initialized
INFO - 2021-12-13 19:52:44 --> Language Class Initialized
ERROR - 2021-12-13 19:52:44 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-13 19:52:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:44 --> Config Class Initialized
INFO - 2021-12-13 19:52:44 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:44 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:44 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:44 --> URI Class Initialized
INFO - 2021-12-13 19:52:44 --> Router Class Initialized
INFO - 2021-12-13 19:52:44 --> Output Class Initialized
INFO - 2021-12-13 19:52:44 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:44 --> Input Class Initialized
INFO - 2021-12-13 19:52:44 --> Language Class Initialized
ERROR - 2021-12-13 19:52:44 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-13 19:52:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:45 --> Config Class Initialized
INFO - 2021-12-13 19:52:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:45 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:45 --> URI Class Initialized
INFO - 2021-12-13 19:52:45 --> Router Class Initialized
INFO - 2021-12-13 19:52:45 --> Output Class Initialized
INFO - 2021-12-13 19:52:45 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:45 --> Input Class Initialized
INFO - 2021-12-13 19:52:45 --> Language Class Initialized
ERROR - 2021-12-13 19:52:45 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-12-13 19:52:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:45 --> Config Class Initialized
INFO - 2021-12-13 19:52:45 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:45 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:45 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:45 --> URI Class Initialized
INFO - 2021-12-13 19:52:45 --> Router Class Initialized
INFO - 2021-12-13 19:52:45 --> Output Class Initialized
INFO - 2021-12-13 19:52:45 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:45 --> Input Class Initialized
INFO - 2021-12-13 19:52:45 --> Language Class Initialized
ERROR - 2021-12-13 19:52:45 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-13 19:52:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:46 --> Config Class Initialized
INFO - 2021-12-13 19:52:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:46 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:46 --> URI Class Initialized
INFO - 2021-12-13 19:52:46 --> Router Class Initialized
INFO - 2021-12-13 19:52:46 --> Output Class Initialized
INFO - 2021-12-13 19:52:46 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:46 --> Input Class Initialized
INFO - 2021-12-13 19:52:46 --> Language Class Initialized
ERROR - 2021-12-13 19:52:46 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-13 19:52:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:46 --> Config Class Initialized
INFO - 2021-12-13 19:52:46 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:46 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:46 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:46 --> URI Class Initialized
INFO - 2021-12-13 19:52:46 --> Router Class Initialized
INFO - 2021-12-13 19:52:46 --> Output Class Initialized
INFO - 2021-12-13 19:52:46 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:46 --> Input Class Initialized
INFO - 2021-12-13 19:52:46 --> Language Class Initialized
ERROR - 2021-12-13 19:52:46 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-13 19:52:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:47 --> Config Class Initialized
INFO - 2021-12-13 19:52:47 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:47 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:47 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:47 --> URI Class Initialized
INFO - 2021-12-13 19:52:47 --> Router Class Initialized
INFO - 2021-12-13 19:52:47 --> Output Class Initialized
INFO - 2021-12-13 19:52:47 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:47 --> Input Class Initialized
INFO - 2021-12-13 19:52:47 --> Language Class Initialized
ERROR - 2021-12-13 19:52:47 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-13 19:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:48 --> Config Class Initialized
INFO - 2021-12-13 19:52:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:48 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:48 --> URI Class Initialized
INFO - 2021-12-13 19:52:48 --> Router Class Initialized
INFO - 2021-12-13 19:52:48 --> Output Class Initialized
INFO - 2021-12-13 19:52:48 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:48 --> Input Class Initialized
INFO - 2021-12-13 19:52:48 --> Language Class Initialized
ERROR - 2021-12-13 19:52:48 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-12-13 19:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:48 --> Config Class Initialized
INFO - 2021-12-13 19:52:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:48 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:48 --> URI Class Initialized
INFO - 2021-12-13 19:52:48 --> Router Class Initialized
INFO - 2021-12-13 19:52:48 --> Output Class Initialized
INFO - 2021-12-13 19:52:48 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:48 --> Input Class Initialized
INFO - 2021-12-13 19:52:48 --> Language Class Initialized
ERROR - 2021-12-13 19:52:48 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-13 19:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:48 --> Config Class Initialized
INFO - 2021-12-13 19:52:48 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:48 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:48 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:49 --> URI Class Initialized
INFO - 2021-12-13 19:52:49 --> Router Class Initialized
INFO - 2021-12-13 19:52:49 --> Output Class Initialized
INFO - 2021-12-13 19:52:49 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:49 --> Input Class Initialized
INFO - 2021-12-13 19:52:49 --> Language Class Initialized
ERROR - 2021-12-13 19:52:49 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-13 19:52:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:49 --> Config Class Initialized
INFO - 2021-12-13 19:52:49 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:49 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:49 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:49 --> URI Class Initialized
INFO - 2021-12-13 19:52:49 --> Router Class Initialized
INFO - 2021-12-13 19:52:49 --> Output Class Initialized
INFO - 2021-12-13 19:52:49 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:49 --> Input Class Initialized
INFO - 2021-12-13 19:52:49 --> Language Class Initialized
ERROR - 2021-12-13 19:52:49 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-13 19:52:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 19:52:50 --> Config Class Initialized
INFO - 2021-12-13 19:52:50 --> Hooks Class Initialized
DEBUG - 2021-12-13 19:52:50 --> UTF-8 Support Enabled
INFO - 2021-12-13 19:52:50 --> Utf8 Class Initialized
INFO - 2021-12-13 19:52:50 --> URI Class Initialized
INFO - 2021-12-13 19:52:50 --> Router Class Initialized
INFO - 2021-12-13 19:52:50 --> Output Class Initialized
INFO - 2021-12-13 19:52:50 --> Security Class Initialized
DEBUG - 2021-12-13 19:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 19:52:50 --> Input Class Initialized
INFO - 2021-12-13 19:52:50 --> Language Class Initialized
ERROR - 2021-12-13 19:52:50 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-13 22:56:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-13 22:56:06 --> Config Class Initialized
INFO - 2021-12-13 22:56:06 --> Hooks Class Initialized
DEBUG - 2021-12-13 22:56:06 --> UTF-8 Support Enabled
INFO - 2021-12-13 22:56:06 --> Utf8 Class Initialized
INFO - 2021-12-13 22:56:06 --> URI Class Initialized
DEBUG - 2021-12-13 22:56:06 --> No URI present. Default controller set.
INFO - 2021-12-13 22:56:06 --> Router Class Initialized
INFO - 2021-12-13 22:56:06 --> Output Class Initialized
INFO - 2021-12-13 22:56:06 --> Security Class Initialized
DEBUG - 2021-12-13 22:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-13 22:56:06 --> Input Class Initialized
INFO - 2021-12-13 22:56:06 --> Language Class Initialized
INFO - 2021-12-13 22:56:06 --> Loader Class Initialized
INFO - 2021-12-13 22:56:06 --> Helper loaded: url_helper
INFO - 2021-12-13 22:56:06 --> Helper loaded: form_helper
INFO - 2021-12-13 22:56:06 --> Helper loaded: common_helper
INFO - 2021-12-13 22:56:06 --> Database Driver Class Initialized
DEBUG - 2021-12-13 22:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-13 22:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-13 22:56:06 --> Controller Class Initialized
INFO - 2021-12-13 22:56:06 --> Form Validation Class Initialized
DEBUG - 2021-12-13 22:56:06 --> Encrypt Class Initialized
DEBUG - 2021-12-13 22:56:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-13 22:56:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-13 22:56:06 --> Email Class Initialized
INFO - 2021-12-13 22:56:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-13 22:56:06 --> Calendar Class Initialized
INFO - 2021-12-13 22:56:06 --> Model "Login_model" initialized
INFO - 2021-12-13 22:56:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-13 22:56:06 --> Final output sent to browser
DEBUG - 2021-12-13 22:56:06 --> Total execution time: 0.0240
