<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-09 07:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 07:50:36 --> Config Class Initialized
INFO - 2021-06-09 07:50:36 --> Hooks Class Initialized
DEBUG - 2021-06-09 07:50:36 --> UTF-8 Support Enabled
INFO - 2021-06-09 07:50:36 --> Utf8 Class Initialized
INFO - 2021-06-09 07:50:36 --> URI Class Initialized
DEBUG - 2021-06-09 07:50:36 --> No URI present. Default controller set.
INFO - 2021-06-09 07:50:36 --> Router Class Initialized
INFO - 2021-06-09 07:50:36 --> Output Class Initialized
INFO - 2021-06-09 07:50:36 --> Security Class Initialized
DEBUG - 2021-06-09 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 07:50:36 --> Input Class Initialized
INFO - 2021-06-09 07:50:36 --> Language Class Initialized
INFO - 2021-06-09 07:50:36 --> Loader Class Initialized
INFO - 2021-06-09 07:50:36 --> Helper loaded: url_helper
INFO - 2021-06-09 07:50:36 --> Helper loaded: form_helper
INFO - 2021-06-09 07:50:36 --> Helper loaded: common_helper
INFO - 2021-06-09 07:50:36 --> Database Driver Class Initialized
DEBUG - 2021-06-09 07:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-09 07:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-09 07:50:36 --> Controller Class Initialized
INFO - 2021-06-09 07:50:36 --> Form Validation Class Initialized
DEBUG - 2021-06-09 07:50:36 --> Encrypt Class Initialized
DEBUG - 2021-06-09 07:50:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-09 07:50:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-09 07:50:36 --> Email Class Initialized
INFO - 2021-06-09 07:50:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-09 07:50:36 --> Calendar Class Initialized
INFO - 2021-06-09 07:50:36 --> Model "Login_model" initialized
INFO - 2021-06-09 07:50:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-09 07:50:36 --> Final output sent to browser
DEBUG - 2021-06-09 07:50:36 --> Total execution time: 0.0354
ERROR - 2021-06-09 15:41:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:41:51 --> Config Class Initialized
INFO - 2021-06-09 15:41:51 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:41:51 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:41:51 --> Utf8 Class Initialized
INFO - 2021-06-09 15:41:51 --> URI Class Initialized
DEBUG - 2021-06-09 15:41:51 --> No URI present. Default controller set.
INFO - 2021-06-09 15:41:51 --> Router Class Initialized
INFO - 2021-06-09 15:41:51 --> Output Class Initialized
INFO - 2021-06-09 15:41:51 --> Security Class Initialized
DEBUG - 2021-06-09 15:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:41:51 --> Input Class Initialized
INFO - 2021-06-09 15:41:51 --> Language Class Initialized
INFO - 2021-06-09 15:41:51 --> Loader Class Initialized
INFO - 2021-06-09 15:41:51 --> Helper loaded: url_helper
INFO - 2021-06-09 15:41:51 --> Helper loaded: form_helper
INFO - 2021-06-09 15:41:51 --> Helper loaded: common_helper
INFO - 2021-06-09 15:41:51 --> Database Driver Class Initialized
DEBUG - 2021-06-09 15:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-09 15:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-09 15:41:51 --> Controller Class Initialized
INFO - 2021-06-09 15:41:51 --> Form Validation Class Initialized
DEBUG - 2021-06-09 15:41:51 --> Encrypt Class Initialized
DEBUG - 2021-06-09 15:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-09 15:41:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-09 15:41:51 --> Email Class Initialized
INFO - 2021-06-09 15:41:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-09 15:41:51 --> Calendar Class Initialized
INFO - 2021-06-09 15:41:51 --> Model "Login_model" initialized
INFO - 2021-06-09 15:41:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-09 15:41:51 --> Final output sent to browser
DEBUG - 2021-06-09 15:41:51 --> Total execution time: 0.0403
ERROR - 2021-06-09 15:41:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:41:52 --> Config Class Initialized
INFO - 2021-06-09 15:41:52 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:41:52 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:41:52 --> Utf8 Class Initialized
INFO - 2021-06-09 15:41:52 --> URI Class Initialized
DEBUG - 2021-06-09 15:41:52 --> No URI present. Default controller set.
INFO - 2021-06-09 15:41:52 --> Router Class Initialized
INFO - 2021-06-09 15:41:52 --> Output Class Initialized
INFO - 2021-06-09 15:41:52 --> Security Class Initialized
DEBUG - 2021-06-09 15:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:41:52 --> Input Class Initialized
INFO - 2021-06-09 15:41:52 --> Language Class Initialized
INFO - 2021-06-09 15:41:52 --> Loader Class Initialized
INFO - 2021-06-09 15:41:52 --> Helper loaded: url_helper
INFO - 2021-06-09 15:41:52 --> Helper loaded: form_helper
INFO - 2021-06-09 15:41:52 --> Helper loaded: common_helper
INFO - 2021-06-09 15:41:52 --> Database Driver Class Initialized
DEBUG - 2021-06-09 15:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-09 15:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-09 15:41:52 --> Controller Class Initialized
INFO - 2021-06-09 15:41:52 --> Form Validation Class Initialized
DEBUG - 2021-06-09 15:41:52 --> Encrypt Class Initialized
DEBUG - 2021-06-09 15:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-09 15:41:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-09 15:41:52 --> Email Class Initialized
INFO - 2021-06-09 15:41:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-09 15:41:52 --> Calendar Class Initialized
INFO - 2021-06-09 15:41:52 --> Model "Login_model" initialized
INFO - 2021-06-09 15:41:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-09 15:41:52 --> Final output sent to browser
DEBUG - 2021-06-09 15:41:52 --> Total execution time: 0.0243
ERROR - 2021-06-09 15:41:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:41:53 --> Config Class Initialized
INFO - 2021-06-09 15:41:53 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:41:53 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:41:53 --> Utf8 Class Initialized
INFO - 2021-06-09 15:41:53 --> URI Class Initialized
INFO - 2021-06-09 15:41:53 --> Router Class Initialized
INFO - 2021-06-09 15:41:53 --> Output Class Initialized
INFO - 2021-06-09 15:41:53 --> Security Class Initialized
DEBUG - 2021-06-09 15:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:41:53 --> Input Class Initialized
INFO - 2021-06-09 15:41:53 --> Language Class Initialized
ERROR - 2021-06-09 15:41:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-09 15:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:41:56 --> Config Class Initialized
INFO - 2021-06-09 15:41:56 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:41:56 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:41:56 --> Utf8 Class Initialized
INFO - 2021-06-09 15:41:56 --> URI Class Initialized
INFO - 2021-06-09 15:41:56 --> Router Class Initialized
INFO - 2021-06-09 15:41:56 --> Output Class Initialized
INFO - 2021-06-09 15:41:56 --> Security Class Initialized
DEBUG - 2021-06-09 15:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:41:56 --> Input Class Initialized
INFO - 2021-06-09 15:41:56 --> Language Class Initialized
INFO - 2021-06-09 15:41:56 --> Loader Class Initialized
INFO - 2021-06-09 15:41:56 --> Helper loaded: url_helper
INFO - 2021-06-09 15:41:56 --> Helper loaded: form_helper
INFO - 2021-06-09 15:41:56 --> Helper loaded: common_helper
INFO - 2021-06-09 15:41:56 --> Database Driver Class Initialized
DEBUG - 2021-06-09 15:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-09 15:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-09 15:41:56 --> Controller Class Initialized
INFO - 2021-06-09 15:41:56 --> Form Validation Class Initialized
DEBUG - 2021-06-09 15:41:56 --> Encrypt Class Initialized
DEBUG - 2021-06-09 15:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-09 15:41:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-09 15:41:56 --> Email Class Initialized
INFO - 2021-06-09 15:41:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-09 15:41:56 --> Calendar Class Initialized
INFO - 2021-06-09 15:41:56 --> Model "Login_model" initialized
INFO - 2021-06-09 15:41:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-09 15:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:41:56 --> Config Class Initialized
INFO - 2021-06-09 15:41:56 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:41:56 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:41:56 --> Utf8 Class Initialized
INFO - 2021-06-09 15:41:56 --> URI Class Initialized
INFO - 2021-06-09 15:41:56 --> Router Class Initialized
INFO - 2021-06-09 15:41:56 --> Output Class Initialized
INFO - 2021-06-09 15:41:56 --> Security Class Initialized
DEBUG - 2021-06-09 15:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:41:56 --> Input Class Initialized
INFO - 2021-06-09 15:41:56 --> Language Class Initialized
INFO - 2021-06-09 15:41:56 --> Loader Class Initialized
INFO - 2021-06-09 15:41:56 --> Helper loaded: url_helper
INFO - 2021-06-09 15:41:56 --> Helper loaded: form_helper
INFO - 2021-06-09 15:41:56 --> Helper loaded: common_helper
INFO - 2021-06-09 15:41:56 --> Database Driver Class Initialized
DEBUG - 2021-06-09 15:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-09 15:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-09 15:41:56 --> Controller Class Initialized
INFO - 2021-06-09 15:41:56 --> Form Validation Class Initialized
DEBUG - 2021-06-09 15:41:56 --> Encrypt Class Initialized
INFO - 2021-06-09 15:41:56 --> Model "Login_model" initialized
INFO - 2021-06-09 15:41:56 --> Model "Dashboard_model" initialized
INFO - 2021-06-09 15:41:56 --> Model "Case_model" initialized
INFO - 2021-06-09 15:41:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-09 15:42:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-09 15:42:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-09 15:42:06 --> Final output sent to browser
DEBUG - 2021-06-09 15:42:06 --> Total execution time: 9.3545
ERROR - 2021-06-09 15:42:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:42:08 --> Config Class Initialized
INFO - 2021-06-09 15:42:08 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:42:08 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:42:08 --> Utf8 Class Initialized
INFO - 2021-06-09 15:42:08 --> URI Class Initialized
INFO - 2021-06-09 15:42:08 --> Router Class Initialized
INFO - 2021-06-09 15:42:08 --> Output Class Initialized
INFO - 2021-06-09 15:42:08 --> Security Class Initialized
DEBUG - 2021-06-09 15:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:42:08 --> Input Class Initialized
INFO - 2021-06-09 15:42:08 --> Language Class Initialized
ERROR - 2021-06-09 15:42:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-09 15:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:42:19 --> Config Class Initialized
INFO - 2021-06-09 15:42:19 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:42:19 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:42:19 --> Utf8 Class Initialized
INFO - 2021-06-09 15:42:19 --> URI Class Initialized
INFO - 2021-06-09 15:42:19 --> Router Class Initialized
INFO - 2021-06-09 15:42:19 --> Output Class Initialized
INFO - 2021-06-09 15:42:19 --> Security Class Initialized
DEBUG - 2021-06-09 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:42:19 --> Input Class Initialized
INFO - 2021-06-09 15:42:19 --> Language Class Initialized
INFO - 2021-06-09 15:42:19 --> Loader Class Initialized
INFO - 2021-06-09 15:42:19 --> Helper loaded: url_helper
INFO - 2021-06-09 15:42:19 --> Helper loaded: form_helper
INFO - 2021-06-09 15:42:19 --> Helper loaded: common_helper
INFO - 2021-06-09 15:42:19 --> Database Driver Class Initialized
DEBUG - 2021-06-09 15:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-09 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-09 15:42:19 --> Controller Class Initialized
INFO - 2021-06-09 15:42:19 --> Form Validation Class Initialized
INFO - 2021-06-09 15:42:19 --> Model "Case_model" initialized
INFO - 2021-06-09 15:42:19 --> Model "Hospital_model" initialized
INFO - 2021-06-09 15:42:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-09 15:42:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-06-09 15:42:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-09 15:42:19 --> Final output sent to browser
DEBUG - 2021-06-09 15:42:19 --> Total execution time: 0.0173
ERROR - 2021-06-09 15:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:42:20 --> Config Class Initialized
INFO - 2021-06-09 15:42:20 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:42:20 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:42:20 --> Utf8 Class Initialized
INFO - 2021-06-09 15:42:20 --> URI Class Initialized
INFO - 2021-06-09 15:42:20 --> Router Class Initialized
INFO - 2021-06-09 15:42:20 --> Output Class Initialized
INFO - 2021-06-09 15:42:20 --> Security Class Initialized
DEBUG - 2021-06-09 15:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:42:20 --> Input Class Initialized
INFO - 2021-06-09 15:42:20 --> Language Class Initialized
ERROR - 2021-06-09 15:42:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-09 15:42:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:42:25 --> Config Class Initialized
INFO - 2021-06-09 15:42:25 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:42:25 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:42:25 --> Utf8 Class Initialized
INFO - 2021-06-09 15:42:25 --> URI Class Initialized
INFO - 2021-06-09 15:42:25 --> Router Class Initialized
INFO - 2021-06-09 15:42:25 --> Output Class Initialized
INFO - 2021-06-09 15:42:25 --> Security Class Initialized
DEBUG - 2021-06-09 15:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:42:25 --> Input Class Initialized
INFO - 2021-06-09 15:42:25 --> Language Class Initialized
INFO - 2021-06-09 15:42:25 --> Loader Class Initialized
INFO - 2021-06-09 15:42:25 --> Helper loaded: url_helper
INFO - 2021-06-09 15:42:25 --> Helper loaded: form_helper
INFO - 2021-06-09 15:42:25 --> Helper loaded: common_helper
INFO - 2021-06-09 15:42:25 --> Database Driver Class Initialized
DEBUG - 2021-06-09 15:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-09 15:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-09 15:42:25 --> Controller Class Initialized
INFO - 2021-06-09 15:42:25 --> Form Validation Class Initialized
DEBUG - 2021-06-09 15:42:25 --> Encrypt Class Initialized
INFO - 2021-06-09 15:42:25 --> Model "Login_model" initialized
INFO - 2021-06-09 15:42:25 --> Model "Dashboard_model" initialized
INFO - 2021-06-09 15:42:25 --> Model "Case_model" initialized
INFO - 2021-06-09 15:42:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-09 15:42:33 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-09 15:42:33 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-09 15:42:33 --> Final output sent to browser
DEBUG - 2021-06-09 15:42:33 --> Total execution time: 8.8403
ERROR - 2021-06-09 15:42:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-09 15:42:34 --> Config Class Initialized
INFO - 2021-06-09 15:42:34 --> Hooks Class Initialized
DEBUG - 2021-06-09 15:42:34 --> UTF-8 Support Enabled
INFO - 2021-06-09 15:42:34 --> Utf8 Class Initialized
INFO - 2021-06-09 15:42:34 --> URI Class Initialized
INFO - 2021-06-09 15:42:34 --> Router Class Initialized
INFO - 2021-06-09 15:42:34 --> Output Class Initialized
INFO - 2021-06-09 15:42:34 --> Security Class Initialized
DEBUG - 2021-06-09 15:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-09 15:42:34 --> Input Class Initialized
INFO - 2021-06-09 15:42:34 --> Language Class Initialized
ERROR - 2021-06-09 15:42:34 --> 404 Page Not Found: Karoclient/usersprofile
