<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-27 03:35:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-27 03:35:57 --> Config Class Initialized
INFO - 2021-09-27 03:35:57 --> Hooks Class Initialized
DEBUG - 2021-09-27 03:35:57 --> UTF-8 Support Enabled
INFO - 2021-09-27 03:35:57 --> Utf8 Class Initialized
INFO - 2021-09-27 03:35:57 --> URI Class Initialized
INFO - 2021-09-27 03:35:57 --> Router Class Initialized
INFO - 2021-09-27 03:35:57 --> Output Class Initialized
INFO - 2021-09-27 03:35:57 --> Security Class Initialized
DEBUG - 2021-09-27 03:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-27 03:35:57 --> Input Class Initialized
INFO - 2021-09-27 03:35:57 --> Language Class Initialized
ERROR - 2021-09-27 03:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:35:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-27 03:35:58 --> Config Class Initialized
INFO - 2021-09-27 03:35:58 --> Hooks Class Initialized
DEBUG - 2021-09-27 03:35:58 --> UTF-8 Support Enabled
INFO - 2021-09-27 03:35:58 --> Utf8 Class Initialized
INFO - 2021-09-27 03:35:58 --> URI Class Initialized
DEBUG - 2021-09-27 03:35:58 --> No URI present. Default controller set.
INFO - 2021-09-27 03:35:58 --> Router Class Initialized
INFO - 2021-09-27 03:35:58 --> Output Class Initialized
INFO - 2021-09-27 03:35:58 --> Security Class Initialized
DEBUG - 2021-09-27 03:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-27 03:35:58 --> Input Class Initialized
INFO - 2021-09-27 03:35:58 --> Language Class Initialized
INFO - 2021-09-27 03:35:58 --> Loader Class Initialized
INFO - 2021-09-27 03:35:58 --> Helper loaded: url_helper
INFO - 2021-09-27 03:35:58 --> Helper loaded: form_helper
INFO - 2021-09-27 03:35:58 --> Helper loaded: common_helper
INFO - 2021-09-27 03:35:58 --> Database Driver Class Initialized
DEBUG - 2021-09-27 03:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-27 03:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-27 03:35:58 --> Controller Class Initialized
INFO - 2021-09-27 03:35:58 --> Form Validation Class Initialized
DEBUG - 2021-09-27 03:35:58 --> Encrypt Class Initialized
DEBUG - 2021-09-27 03:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-27 03:35:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-27 03:35:58 --> Email Class Initialized
INFO - 2021-09-27 03:35:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-27 03:35:58 --> Calendar Class Initialized
INFO - 2021-09-27 03:35:58 --> Model "Login_model" initialized
INFO - 2021-09-27 03:35:58 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-27 03:35:58 --> Final output sent to browser
DEBUG - 2021-09-27 03:35:58 --> Total execution time: 0.0339
ERROR - 2021-09-27 03:35:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-27 03:35:58 --> Config Class Initialized
INFO - 2021-09-27 03:35:58 --> Hooks Class Initialized
DEBUG - 2021-09-27 03:35:58 --> UTF-8 Support Enabled
INFO - 2021-09-27 03:35:58 --> Utf8 Class Initialized
INFO - 2021-09-27 03:35:58 --> URI Class Initialized
INFO - 2021-09-27 03:35:58 --> Router Class Initialized
INFO - 2021-09-27 03:35:58 --> Output Class Initialized
INFO - 2021-09-27 03:35:58 --> Security Class Initialized
DEBUG - 2021-09-27 03:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-27 03:35:58 --> Input Class Initialized
INFO - 2021-09-27 03:35:58 --> Language Class Initialized
ERROR - 2021-09-27 03:35:58 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2021-09-27 03:35:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-27 03:35:58 --> Config Class Initialized
INFO - 2021-09-27 03:35:58 --> Hooks Class Initialized
DEBUG - 2021-09-27 03:35:58 --> UTF-8 Support Enabled
INFO - 2021-09-27 03:35:58 --> Utf8 Class Initialized
INFO - 2021-09-27 03:35:58 --> URI Class Initialized
INFO - 2021-09-27 03:35:58 --> Router Class Initialized
INFO - 2021-09-27 03:35:58 --> Output Class Initialized
INFO - 2021-09-27 03:35:58 --> Security Class Initialized
DEBUG - 2021-09-27 03:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-27 03:35:58 --> Input Class Initialized
INFO - 2021-09-27 03:35:58 --> Language Class Initialized
ERROR - 2021-09-27 03:35:58 --> 404 Page Not Found: Blog/index
ERROR - 2021-09-27 03:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-27 03:35:59 --> Config Class Initialized
INFO - 2021-09-27 03:35:59 --> Hooks Class Initialized
DEBUG - 2021-09-27 03:35:59 --> UTF-8 Support Enabled
INFO - 2021-09-27 03:35:59 --> Utf8 Class Initialized
INFO - 2021-09-27 03:35:59 --> URI Class Initialized
INFO - 2021-09-27 03:35:59 --> Router Class Initialized
INFO - 2021-09-27 03:35:59 --> Output Class Initialized
INFO - 2021-09-27 03:35:59 --> Security Class Initialized
DEBUG - 2021-09-27 03:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-27 03:35:59 --> Input Class Initialized
INFO - 2021-09-27 03:35:59 --> Language Class Initialized
ERROR - 2021-09-27 03:35:59 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-27 03:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-27 03:35:59 --> Config Class Initialized
INFO - 2021-09-27 03:35:59 --> Hooks Class Initialized
DEBUG - 2021-09-27 03:35:59 --> UTF-8 Support Enabled
INFO - 2021-09-27 03:35:59 --> Utf8 Class Initialized
INFO - 2021-09-27 03:35:59 --> URI Class Initialized
INFO - 2021-09-27 03:35:59 --> Router Class Initialized
INFO - 2021-09-27 03:35:59 --> Output Class Initialized
INFO - 2021-09-27 03:35:59 --> Security Class Initialized
DEBUG - 2021-09-27 03:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-27 03:35:59 --> Input Class Initialized
INFO - 2021-09-27 03:35:59 --> Language Class Initialized
ERROR - 2021-09-27 03:35:59 --> 404 Page Not Found: Wp/index
ERROR - 2021-09-27 11:35:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-27 11:35:56 --> Config Class Initialized
INFO - 2021-09-27 11:35:56 --> Hooks Class Initialized
DEBUG - 2021-09-27 11:35:56 --> UTF-8 Support Enabled
INFO - 2021-09-27 11:35:56 --> Utf8 Class Initialized
INFO - 2021-09-27 11:35:56 --> URI Class Initialized
DEBUG - 2021-09-27 11:35:56 --> No URI present. Default controller set.
INFO - 2021-09-27 11:35:56 --> Router Class Initialized
INFO - 2021-09-27 11:35:56 --> Output Class Initialized
INFO - 2021-09-27 11:35:56 --> Security Class Initialized
DEBUG - 2021-09-27 11:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-27 11:35:56 --> Input Class Initialized
INFO - 2021-09-27 11:35:56 --> Language Class Initialized
INFO - 2021-09-27 11:35:56 --> Loader Class Initialized
INFO - 2021-09-27 11:35:56 --> Helper loaded: url_helper
INFO - 2021-09-27 11:35:56 --> Helper loaded: form_helper
INFO - 2021-09-27 11:35:56 --> Helper loaded: common_helper
INFO - 2021-09-27 11:35:56 --> Database Driver Class Initialized
DEBUG - 2021-09-27 11:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-27 11:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-27 11:35:56 --> Controller Class Initialized
INFO - 2021-09-27 11:35:56 --> Form Validation Class Initialized
DEBUG - 2021-09-27 11:35:56 --> Encrypt Class Initialized
DEBUG - 2021-09-27 11:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-27 11:35:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-27 11:35:56 --> Email Class Initialized
INFO - 2021-09-27 11:35:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-27 11:35:56 --> Calendar Class Initialized
INFO - 2021-09-27 11:35:56 --> Model "Login_model" initialized
INFO - 2021-09-27 11:35:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-27 11:35:56 --> Final output sent to browser
DEBUG - 2021-09-27 11:35:56 --> Total execution time: 0.0563
ERROR - 2021-09-27 18:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-27 18:18:55 --> Config Class Initialized
INFO - 2021-09-27 18:18:55 --> Hooks Class Initialized
DEBUG - 2021-09-27 18:18:55 --> UTF-8 Support Enabled
INFO - 2021-09-27 18:18:55 --> Utf8 Class Initialized
INFO - 2021-09-27 18:18:55 --> URI Class Initialized
DEBUG - 2021-09-27 18:18:55 --> No URI present. Default controller set.
INFO - 2021-09-27 18:18:55 --> Router Class Initialized
INFO - 2021-09-27 18:18:55 --> Output Class Initialized
INFO - 2021-09-27 18:18:55 --> Security Class Initialized
DEBUG - 2021-09-27 18:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-27 18:18:55 --> Input Class Initialized
INFO - 2021-09-27 18:18:55 --> Language Class Initialized
INFO - 2021-09-27 18:18:55 --> Loader Class Initialized
INFO - 2021-09-27 18:18:55 --> Helper loaded: url_helper
INFO - 2021-09-27 18:18:55 --> Helper loaded: form_helper
INFO - 2021-09-27 18:18:55 --> Helper loaded: common_helper
INFO - 2021-09-27 18:18:55 --> Database Driver Class Initialized
DEBUG - 2021-09-27 18:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-27 18:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-27 18:18:55 --> Controller Class Initialized
INFO - 2021-09-27 18:18:55 --> Form Validation Class Initialized
DEBUG - 2021-09-27 18:18:55 --> Encrypt Class Initialized
DEBUG - 2021-09-27 18:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-27 18:18:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-27 18:18:55 --> Email Class Initialized
INFO - 2021-09-27 18:18:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-27 18:18:55 --> Calendar Class Initialized
INFO - 2021-09-27 18:18:56 --> Model "Login_model" initialized
INFO - 2021-09-27 18:18:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-27 18:18:56 --> Final output sent to browser
DEBUG - 2021-09-27 18:18:56 --> Total execution time: 0.8944
