<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-07 08:27:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 08:27:53 --> Config Class Initialized
INFO - 2022-01-07 08:27:53 --> Hooks Class Initialized
DEBUG - 2022-01-07 08:27:53 --> UTF-8 Support Enabled
INFO - 2022-01-07 08:27:53 --> Utf8 Class Initialized
INFO - 2022-01-07 08:27:53 --> URI Class Initialized
DEBUG - 2022-01-07 08:27:53 --> No URI present. Default controller set.
INFO - 2022-01-07 08:27:53 --> Router Class Initialized
INFO - 2022-01-07 08:27:53 --> Output Class Initialized
INFO - 2022-01-07 08:27:53 --> Security Class Initialized
DEBUG - 2022-01-07 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 08:27:53 --> Input Class Initialized
INFO - 2022-01-07 08:27:53 --> Language Class Initialized
INFO - 2022-01-07 08:27:53 --> Loader Class Initialized
INFO - 2022-01-07 08:27:53 --> Helper loaded: url_helper
INFO - 2022-01-07 08:27:53 --> Helper loaded: form_helper
INFO - 2022-01-07 08:27:53 --> Helper loaded: common_helper
INFO - 2022-01-07 08:27:53 --> Database Driver Class Initialized
DEBUG - 2022-01-07 08:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 08:27:53 --> Controller Class Initialized
INFO - 2022-01-07 08:27:53 --> Form Validation Class Initialized
DEBUG - 2022-01-07 08:27:53 --> Encrypt Class Initialized
DEBUG - 2022-01-07 08:27:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 08:27:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 08:27:53 --> Email Class Initialized
INFO - 2022-01-07 08:27:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 08:27:53 --> Calendar Class Initialized
INFO - 2022-01-07 08:27:53 --> Model "Login_model" initialized
INFO - 2022-01-07 08:27:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-07 08:27:53 --> Final output sent to browser
DEBUG - 2022-01-07 08:27:53 --> Total execution time: 0.0259
ERROR - 2022-01-07 11:48:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 11:48:57 --> Config Class Initialized
INFO - 2022-01-07 11:48:57 --> Hooks Class Initialized
DEBUG - 2022-01-07 11:48:57 --> UTF-8 Support Enabled
INFO - 2022-01-07 11:48:57 --> Utf8 Class Initialized
INFO - 2022-01-07 11:48:57 --> URI Class Initialized
DEBUG - 2022-01-07 11:48:57 --> No URI present. Default controller set.
INFO - 2022-01-07 11:48:57 --> Router Class Initialized
INFO - 2022-01-07 11:48:57 --> Output Class Initialized
INFO - 2022-01-07 11:48:57 --> Security Class Initialized
DEBUG - 2022-01-07 11:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 11:48:57 --> Input Class Initialized
INFO - 2022-01-07 11:48:57 --> Language Class Initialized
INFO - 2022-01-07 11:48:57 --> Loader Class Initialized
INFO - 2022-01-07 11:48:57 --> Helper loaded: url_helper
INFO - 2022-01-07 11:48:57 --> Helper loaded: form_helper
INFO - 2022-01-07 11:48:57 --> Helper loaded: common_helper
INFO - 2022-01-07 11:48:57 --> Database Driver Class Initialized
DEBUG - 2022-01-07 11:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 11:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 11:48:57 --> Controller Class Initialized
INFO - 2022-01-07 11:48:57 --> Form Validation Class Initialized
DEBUG - 2022-01-07 11:48:57 --> Encrypt Class Initialized
DEBUG - 2022-01-07 11:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 11:48:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 11:48:57 --> Email Class Initialized
INFO - 2022-01-07 11:48:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 11:48:57 --> Calendar Class Initialized
INFO - 2022-01-07 11:48:57 --> Model "Login_model" initialized
INFO - 2022-01-07 11:48:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-07 11:48:57 --> Final output sent to browser
DEBUG - 2022-01-07 11:48:57 --> Total execution time: 0.0570
ERROR - 2022-01-07 14:22:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 14:22:10 --> Config Class Initialized
INFO - 2022-01-07 14:22:10 --> Hooks Class Initialized
DEBUG - 2022-01-07 14:22:10 --> UTF-8 Support Enabled
INFO - 2022-01-07 14:22:10 --> Utf8 Class Initialized
INFO - 2022-01-07 14:22:10 --> URI Class Initialized
DEBUG - 2022-01-07 14:22:10 --> No URI present. Default controller set.
INFO - 2022-01-07 14:22:10 --> Router Class Initialized
INFO - 2022-01-07 14:22:10 --> Output Class Initialized
INFO - 2022-01-07 14:22:10 --> Security Class Initialized
DEBUG - 2022-01-07 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 14:22:10 --> Input Class Initialized
INFO - 2022-01-07 14:22:10 --> Language Class Initialized
INFO - 2022-01-07 14:22:10 --> Loader Class Initialized
INFO - 2022-01-07 14:22:10 --> Helper loaded: url_helper
INFO - 2022-01-07 14:22:10 --> Helper loaded: form_helper
INFO - 2022-01-07 14:22:10 --> Helper loaded: common_helper
INFO - 2022-01-07 14:22:10 --> Database Driver Class Initialized
DEBUG - 2022-01-07 14:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 14:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 14:22:10 --> Controller Class Initialized
INFO - 2022-01-07 14:22:10 --> Form Validation Class Initialized
DEBUG - 2022-01-07 14:22:10 --> Encrypt Class Initialized
DEBUG - 2022-01-07 14:22:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 14:22:10 --> Email Class Initialized
INFO - 2022-01-07 14:22:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 14:22:10 --> Calendar Class Initialized
INFO - 2022-01-07 14:22:10 --> Model "Login_model" initialized
INFO - 2022-01-07 14:22:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-07 14:22:10 --> Final output sent to browser
DEBUG - 2022-01-07 14:22:10 --> Total execution time: 0.0278
ERROR - 2022-01-07 14:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 14:22:11 --> Config Class Initialized
INFO - 2022-01-07 14:22:11 --> Hooks Class Initialized
DEBUG - 2022-01-07 14:22:11 --> UTF-8 Support Enabled
INFO - 2022-01-07 14:22:11 --> Utf8 Class Initialized
INFO - 2022-01-07 14:22:11 --> URI Class Initialized
INFO - 2022-01-07 14:22:11 --> Router Class Initialized
INFO - 2022-01-07 14:22:11 --> Output Class Initialized
INFO - 2022-01-07 14:22:11 --> Security Class Initialized
DEBUG - 2022-01-07 14:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 14:22:11 --> Input Class Initialized
INFO - 2022-01-07 14:22:11 --> Language Class Initialized
ERROR - 2022-01-07 14:22:11 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-07 14:22:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 14:22:19 --> Config Class Initialized
INFO - 2022-01-07 14:22:19 --> Hooks Class Initialized
DEBUG - 2022-01-07 14:22:19 --> UTF-8 Support Enabled
INFO - 2022-01-07 14:22:19 --> Utf8 Class Initialized
INFO - 2022-01-07 14:22:19 --> URI Class Initialized
DEBUG - 2022-01-07 14:22:19 --> No URI present. Default controller set.
INFO - 2022-01-07 14:22:19 --> Router Class Initialized
INFO - 2022-01-07 14:22:19 --> Output Class Initialized
INFO - 2022-01-07 14:22:19 --> Security Class Initialized
DEBUG - 2022-01-07 14:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 14:22:19 --> Input Class Initialized
INFO - 2022-01-07 14:22:19 --> Language Class Initialized
INFO - 2022-01-07 14:22:19 --> Loader Class Initialized
INFO - 2022-01-07 14:22:19 --> Helper loaded: url_helper
INFO - 2022-01-07 14:22:19 --> Helper loaded: form_helper
INFO - 2022-01-07 14:22:19 --> Helper loaded: common_helper
INFO - 2022-01-07 14:22:19 --> Database Driver Class Initialized
DEBUG - 2022-01-07 14:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 14:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 14:22:19 --> Controller Class Initialized
INFO - 2022-01-07 14:22:19 --> Form Validation Class Initialized
DEBUG - 2022-01-07 14:22:19 --> Encrypt Class Initialized
DEBUG - 2022-01-07 14:22:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:22:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 14:22:19 --> Email Class Initialized
INFO - 2022-01-07 14:22:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 14:22:19 --> Calendar Class Initialized
INFO - 2022-01-07 14:22:19 --> Model "Login_model" initialized
INFO - 2022-01-07 14:22:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-07 14:22:19 --> Final output sent to browser
DEBUG - 2022-01-07 14:22:19 --> Total execution time: 0.0251
ERROR - 2022-01-07 14:22:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 14:22:19 --> Config Class Initialized
INFO - 2022-01-07 14:22:19 --> Hooks Class Initialized
DEBUG - 2022-01-07 14:22:19 --> UTF-8 Support Enabled
INFO - 2022-01-07 14:22:19 --> Utf8 Class Initialized
INFO - 2022-01-07 14:22:19 --> URI Class Initialized
INFO - 2022-01-07 14:22:19 --> Router Class Initialized
INFO - 2022-01-07 14:22:19 --> Output Class Initialized
INFO - 2022-01-07 14:22:19 --> Security Class Initialized
DEBUG - 2022-01-07 14:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 14:22:19 --> Input Class Initialized
INFO - 2022-01-07 14:22:19 --> Language Class Initialized
INFO - 2022-01-07 14:22:19 --> Loader Class Initialized
INFO - 2022-01-07 14:22:19 --> Helper loaded: url_helper
INFO - 2022-01-07 14:22:19 --> Helper loaded: form_helper
INFO - 2022-01-07 14:22:19 --> Helper loaded: common_helper
INFO - 2022-01-07 14:22:19 --> Database Driver Class Initialized
DEBUG - 2022-01-07 14:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 14:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 14:22:19 --> Controller Class Initialized
INFO - 2022-01-07 14:22:19 --> Form Validation Class Initialized
DEBUG - 2022-01-07 14:22:19 --> Encrypt Class Initialized
DEBUG - 2022-01-07 14:22:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:22:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 14:22:19 --> Email Class Initialized
INFO - 2022-01-07 14:22:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 14:22:19 --> Calendar Class Initialized
INFO - 2022-01-07 14:22:19 --> Model "Login_model" initialized
ERROR - 2022-01-07 14:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 14:22:20 --> Config Class Initialized
INFO - 2022-01-07 14:22:20 --> Hooks Class Initialized
DEBUG - 2022-01-07 14:22:20 --> UTF-8 Support Enabled
INFO - 2022-01-07 14:22:20 --> Utf8 Class Initialized
INFO - 2022-01-07 14:22:20 --> URI Class Initialized
INFO - 2022-01-07 14:22:20 --> Router Class Initialized
INFO - 2022-01-07 14:22:20 --> Output Class Initialized
INFO - 2022-01-07 14:22:20 --> Security Class Initialized
DEBUG - 2022-01-07 14:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 14:22:20 --> Input Class Initialized
INFO - 2022-01-07 14:22:20 --> Language Class Initialized
INFO - 2022-01-07 14:22:20 --> Loader Class Initialized
INFO - 2022-01-07 14:22:20 --> Helper loaded: url_helper
INFO - 2022-01-07 14:22:20 --> Helper loaded: form_helper
INFO - 2022-01-07 14:22:20 --> Helper loaded: common_helper
INFO - 2022-01-07 14:22:20 --> Database Driver Class Initialized
DEBUG - 2022-01-07 14:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 14:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 14:22:20 --> Controller Class Initialized
INFO - 2022-01-07 14:22:20 --> Form Validation Class Initialized
DEBUG - 2022-01-07 14:22:20 --> Encrypt Class Initialized
DEBUG - 2022-01-07 14:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 14:22:20 --> Email Class Initialized
INFO - 2022-01-07 14:22:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 14:22:20 --> Calendar Class Initialized
INFO - 2022-01-07 14:22:20 --> Model "Login_model" initialized
ERROR - 2022-01-07 14:22:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 14:22:21 --> Config Class Initialized
INFO - 2022-01-07 14:22:21 --> Hooks Class Initialized
DEBUG - 2022-01-07 14:22:21 --> UTF-8 Support Enabled
INFO - 2022-01-07 14:22:21 --> Utf8 Class Initialized
INFO - 2022-01-07 14:22:21 --> URI Class Initialized
INFO - 2022-01-07 14:22:21 --> Router Class Initialized
INFO - 2022-01-07 14:22:21 --> Output Class Initialized
INFO - 2022-01-07 14:22:21 --> Security Class Initialized
DEBUG - 2022-01-07 14:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 14:22:21 --> Input Class Initialized
INFO - 2022-01-07 14:22:21 --> Language Class Initialized
INFO - 2022-01-07 14:22:21 --> Loader Class Initialized
INFO - 2022-01-07 14:22:21 --> Helper loaded: url_helper
INFO - 2022-01-07 14:22:21 --> Helper loaded: form_helper
INFO - 2022-01-07 14:22:21 --> Helper loaded: common_helper
INFO - 2022-01-07 14:22:21 --> Database Driver Class Initialized
DEBUG - 2022-01-07 14:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 14:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 14:22:21 --> Controller Class Initialized
INFO - 2022-01-07 14:22:21 --> Form Validation Class Initialized
DEBUG - 2022-01-07 14:22:21 --> Encrypt Class Initialized
DEBUG - 2022-01-07 14:22:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:22:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 14:22:21 --> Email Class Initialized
INFO - 2022-01-07 14:22:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 14:22:21 --> Calendar Class Initialized
INFO - 2022-01-07 14:22:21 --> Model "Login_model" initialized
INFO - 2022-01-07 14:22:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-07 14:22:21 --> Final output sent to browser
DEBUG - 2022-01-07 14:22:21 --> Total execution time: 0.8795
ERROR - 2022-01-07 15:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 15:15:49 --> Config Class Initialized
INFO - 2022-01-07 15:15:49 --> Hooks Class Initialized
DEBUG - 2022-01-07 15:15:49 --> UTF-8 Support Enabled
INFO - 2022-01-07 15:15:49 --> Utf8 Class Initialized
INFO - 2022-01-07 15:15:49 --> URI Class Initialized
DEBUG - 2022-01-07 15:15:49 --> No URI present. Default controller set.
INFO - 2022-01-07 15:15:49 --> Router Class Initialized
INFO - 2022-01-07 15:15:49 --> Output Class Initialized
INFO - 2022-01-07 15:15:49 --> Security Class Initialized
DEBUG - 2022-01-07 15:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 15:15:49 --> Input Class Initialized
INFO - 2022-01-07 15:15:49 --> Language Class Initialized
INFO - 2022-01-07 15:15:49 --> Loader Class Initialized
INFO - 2022-01-07 15:15:49 --> Helper loaded: url_helper
INFO - 2022-01-07 15:15:49 --> Helper loaded: form_helper
INFO - 2022-01-07 15:15:49 --> Helper loaded: common_helper
INFO - 2022-01-07 15:15:49 --> Database Driver Class Initialized
DEBUG - 2022-01-07 15:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 15:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 15:15:49 --> Controller Class Initialized
INFO - 2022-01-07 15:15:49 --> Form Validation Class Initialized
DEBUG - 2022-01-07 15:15:49 --> Encrypt Class Initialized
DEBUG - 2022-01-07 15:15:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 15:15:49 --> Email Class Initialized
INFO - 2022-01-07 15:15:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 15:15:49 --> Calendar Class Initialized
INFO - 2022-01-07 15:15:49 --> Model "Login_model" initialized
INFO - 2022-01-07 15:15:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-07 15:15:49 --> Final output sent to browser
DEBUG - 2022-01-07 15:15:49 --> Total execution time: 0.0359
ERROR - 2022-01-07 16:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 16:16:21 --> Config Class Initialized
INFO - 2022-01-07 16:16:21 --> Hooks Class Initialized
DEBUG - 2022-01-07 16:16:21 --> UTF-8 Support Enabled
INFO - 2022-01-07 16:16:21 --> Utf8 Class Initialized
INFO - 2022-01-07 16:16:21 --> URI Class Initialized
DEBUG - 2022-01-07 16:16:21 --> No URI present. Default controller set.
INFO - 2022-01-07 16:16:21 --> Router Class Initialized
INFO - 2022-01-07 16:16:21 --> Output Class Initialized
INFO - 2022-01-07 16:16:21 --> Security Class Initialized
DEBUG - 2022-01-07 16:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 16:16:21 --> Input Class Initialized
INFO - 2022-01-07 16:16:21 --> Language Class Initialized
INFO - 2022-01-07 16:16:21 --> Loader Class Initialized
INFO - 2022-01-07 16:16:21 --> Helper loaded: url_helper
INFO - 2022-01-07 16:16:21 --> Helper loaded: form_helper
INFO - 2022-01-07 16:16:21 --> Helper loaded: common_helper
INFO - 2022-01-07 16:16:21 --> Database Driver Class Initialized
DEBUG - 2022-01-07 16:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 16:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 16:16:21 --> Controller Class Initialized
INFO - 2022-01-07 16:16:21 --> Form Validation Class Initialized
DEBUG - 2022-01-07 16:16:21 --> Encrypt Class Initialized
DEBUG - 2022-01-07 16:16:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:16:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 16:16:21 --> Email Class Initialized
INFO - 2022-01-07 16:16:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 16:16:21 --> Calendar Class Initialized
INFO - 2022-01-07 16:16:21 --> Model "Login_model" initialized
INFO - 2022-01-07 16:16:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-07 16:16:21 --> Final output sent to browser
DEBUG - 2022-01-07 16:16:21 --> Total execution time: 0.0648
ERROR - 2022-01-07 17:35:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 17:35:06 --> Config Class Initialized
INFO - 2022-01-07 17:35:06 --> Hooks Class Initialized
DEBUG - 2022-01-07 17:35:06 --> UTF-8 Support Enabled
INFO - 2022-01-07 17:35:06 --> Utf8 Class Initialized
INFO - 2022-01-07 17:35:06 --> URI Class Initialized
INFO - 2022-01-07 17:35:06 --> Router Class Initialized
INFO - 2022-01-07 17:35:06 --> Output Class Initialized
INFO - 2022-01-07 17:35:06 --> Security Class Initialized
DEBUG - 2022-01-07 17:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 17:35:06 --> Input Class Initialized
INFO - 2022-01-07 17:35:06 --> Language Class Initialized
ERROR - 2022-01-07 17:35:06 --> 404 Page Not Found: Dist/app.js
ERROR - 2022-01-07 17:35:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 17:35:06 --> Config Class Initialized
INFO - 2022-01-07 17:35:06 --> Hooks Class Initialized
DEBUG - 2022-01-07 17:35:06 --> UTF-8 Support Enabled
INFO - 2022-01-07 17:35:06 --> Utf8 Class Initialized
INFO - 2022-01-07 17:35:06 --> URI Class Initialized
INFO - 2022-01-07 17:35:06 --> Router Class Initialized
INFO - 2022-01-07 17:35:06 --> Output Class Initialized
INFO - 2022-01-07 17:35:06 --> Security Class Initialized
DEBUG - 2022-01-07 17:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 17:35:06 --> Input Class Initialized
INFO - 2022-01-07 17:35:06 --> Language Class Initialized
ERROR - 2022-01-07 17:35:06 --> 404 Page Not Found: Dist/app.js
ERROR - 2022-01-07 19:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 19:39:06 --> Config Class Initialized
INFO - 2022-01-07 19:39:06 --> Hooks Class Initialized
DEBUG - 2022-01-07 19:39:06 --> UTF-8 Support Enabled
INFO - 2022-01-07 19:39:06 --> Utf8 Class Initialized
INFO - 2022-01-07 19:39:06 --> URI Class Initialized
DEBUG - 2022-01-07 19:39:06 --> No URI present. Default controller set.
INFO - 2022-01-07 19:39:06 --> Router Class Initialized
INFO - 2022-01-07 19:39:06 --> Output Class Initialized
INFO - 2022-01-07 19:39:06 --> Security Class Initialized
DEBUG - 2022-01-07 19:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 19:39:06 --> Input Class Initialized
INFO - 2022-01-07 19:39:06 --> Language Class Initialized
INFO - 2022-01-07 19:39:06 --> Loader Class Initialized
INFO - 2022-01-07 19:39:06 --> Helper loaded: url_helper
INFO - 2022-01-07 19:39:06 --> Helper loaded: form_helper
INFO - 2022-01-07 19:39:06 --> Helper loaded: common_helper
INFO - 2022-01-07 19:39:06 --> Database Driver Class Initialized
DEBUG - 2022-01-07 19:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 19:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 19:39:06 --> Controller Class Initialized
INFO - 2022-01-07 19:39:06 --> Form Validation Class Initialized
DEBUG - 2022-01-07 19:39:06 --> Encrypt Class Initialized
DEBUG - 2022-01-07 19:39:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 19:39:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 19:39:06 --> Email Class Initialized
INFO - 2022-01-07 19:39:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 19:39:06 --> Calendar Class Initialized
INFO - 2022-01-07 19:39:06 --> Model "Login_model" initialized
INFO - 2022-01-07 19:39:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-07 19:39:06 --> Final output sent to browser
DEBUG - 2022-01-07 19:39:06 --> Total execution time: 0.0273
ERROR - 2022-01-07 21:06:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-07 21:06:47 --> Config Class Initialized
INFO - 2022-01-07 21:06:47 --> Hooks Class Initialized
DEBUG - 2022-01-07 21:06:47 --> UTF-8 Support Enabled
INFO - 2022-01-07 21:06:47 --> Utf8 Class Initialized
INFO - 2022-01-07 21:06:47 --> URI Class Initialized
DEBUG - 2022-01-07 21:06:47 --> No URI present. Default controller set.
INFO - 2022-01-07 21:06:47 --> Router Class Initialized
INFO - 2022-01-07 21:06:47 --> Output Class Initialized
INFO - 2022-01-07 21:06:47 --> Security Class Initialized
DEBUG - 2022-01-07 21:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-07 21:06:47 --> Input Class Initialized
INFO - 2022-01-07 21:06:47 --> Language Class Initialized
INFO - 2022-01-07 21:06:47 --> Loader Class Initialized
INFO - 2022-01-07 21:06:47 --> Helper loaded: url_helper
INFO - 2022-01-07 21:06:47 --> Helper loaded: form_helper
INFO - 2022-01-07 21:06:47 --> Helper loaded: common_helper
INFO - 2022-01-07 21:06:47 --> Database Driver Class Initialized
DEBUG - 2022-01-07 21:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-07 21:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-07 21:06:47 --> Controller Class Initialized
INFO - 2022-01-07 21:06:47 --> Form Validation Class Initialized
DEBUG - 2022-01-07 21:06:47 --> Encrypt Class Initialized
DEBUG - 2022-01-07 21:06:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 21:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-07 21:06:47 --> Email Class Initialized
INFO - 2022-01-07 21:06:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-07 21:06:47 --> Calendar Class Initialized
INFO - 2022-01-07 21:06:47 --> Model "Login_model" initialized
INFO - 2022-01-07 21:06:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-07 21:06:47 --> Final output sent to browser
DEBUG - 2022-01-07 21:06:47 --> Total execution time: 0.0420
