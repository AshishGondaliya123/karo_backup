<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-19 08:37:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 08:37:44 --> Config Class Initialized
INFO - 2022-01-19 08:37:44 --> Hooks Class Initialized
DEBUG - 2022-01-19 08:37:44 --> UTF-8 Support Enabled
INFO - 2022-01-19 08:37:44 --> Utf8 Class Initialized
INFO - 2022-01-19 08:37:44 --> URI Class Initialized
DEBUG - 2022-01-19 08:37:44 --> No URI present. Default controller set.
INFO - 2022-01-19 08:37:44 --> Router Class Initialized
INFO - 2022-01-19 08:37:44 --> Output Class Initialized
INFO - 2022-01-19 08:37:44 --> Security Class Initialized
DEBUG - 2022-01-19 08:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 08:37:44 --> Input Class Initialized
INFO - 2022-01-19 08:37:44 --> Language Class Initialized
INFO - 2022-01-19 08:37:44 --> Loader Class Initialized
INFO - 2022-01-19 08:37:44 --> Helper loaded: url_helper
INFO - 2022-01-19 08:37:44 --> Helper loaded: form_helper
INFO - 2022-01-19 08:37:44 --> Helper loaded: common_helper
INFO - 2022-01-19 08:37:44 --> Database Driver Class Initialized
DEBUG - 2022-01-19 08:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 08:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 08:37:44 --> Controller Class Initialized
INFO - 2022-01-19 08:37:44 --> Form Validation Class Initialized
DEBUG - 2022-01-19 08:37:44 --> Encrypt Class Initialized
DEBUG - 2022-01-19 08:37:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 08:37:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 08:37:44 --> Email Class Initialized
INFO - 2022-01-19 08:37:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 08:37:44 --> Calendar Class Initialized
INFO - 2022-01-19 08:37:44 --> Model "Login_model" initialized
INFO - 2022-01-19 08:37:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-19 08:37:44 --> Final output sent to browser
DEBUG - 2022-01-19 08:37:44 --> Total execution time: 0.0279
ERROR - 2022-01-19 14:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 14:19:58 --> Config Class Initialized
INFO - 2022-01-19 14:19:58 --> Hooks Class Initialized
DEBUG - 2022-01-19 14:19:58 --> UTF-8 Support Enabled
INFO - 2022-01-19 14:19:58 --> Utf8 Class Initialized
INFO - 2022-01-19 14:19:58 --> URI Class Initialized
DEBUG - 2022-01-19 14:19:58 --> No URI present. Default controller set.
INFO - 2022-01-19 14:19:58 --> Router Class Initialized
INFO - 2022-01-19 14:19:58 --> Output Class Initialized
INFO - 2022-01-19 14:19:58 --> Security Class Initialized
DEBUG - 2022-01-19 14:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 14:19:58 --> Input Class Initialized
INFO - 2022-01-19 14:19:58 --> Language Class Initialized
INFO - 2022-01-19 14:19:58 --> Loader Class Initialized
INFO - 2022-01-19 14:19:58 --> Helper loaded: url_helper
INFO - 2022-01-19 14:19:58 --> Helper loaded: form_helper
INFO - 2022-01-19 14:19:58 --> Helper loaded: common_helper
INFO - 2022-01-19 14:19:58 --> Database Driver Class Initialized
DEBUG - 2022-01-19 14:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 14:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 14:19:58 --> Controller Class Initialized
INFO - 2022-01-19 14:19:58 --> Form Validation Class Initialized
DEBUG - 2022-01-19 14:19:58 --> Encrypt Class Initialized
DEBUG - 2022-01-19 14:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 14:19:58 --> Email Class Initialized
INFO - 2022-01-19 14:19:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 14:19:58 --> Calendar Class Initialized
INFO - 2022-01-19 14:19:58 --> Model "Login_model" initialized
INFO - 2022-01-19 14:19:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-19 14:19:58 --> Final output sent to browser
DEBUG - 2022-01-19 14:19:58 --> Total execution time: 0.0296
ERROR - 2022-01-19 14:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 14:20:00 --> Config Class Initialized
INFO - 2022-01-19 14:20:00 --> Hooks Class Initialized
DEBUG - 2022-01-19 14:20:00 --> UTF-8 Support Enabled
INFO - 2022-01-19 14:20:00 --> Utf8 Class Initialized
INFO - 2022-01-19 14:20:00 --> URI Class Initialized
INFO - 2022-01-19 14:20:00 --> Router Class Initialized
INFO - 2022-01-19 14:20:00 --> Output Class Initialized
INFO - 2022-01-19 14:20:00 --> Security Class Initialized
DEBUG - 2022-01-19 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 14:20:00 --> Input Class Initialized
INFO - 2022-01-19 14:20:00 --> Language Class Initialized
ERROR - 2022-01-19 14:20:00 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-19 14:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 14:20:06 --> Config Class Initialized
INFO - 2022-01-19 14:20:06 --> Hooks Class Initialized
DEBUG - 2022-01-19 14:20:06 --> UTF-8 Support Enabled
INFO - 2022-01-19 14:20:06 --> Utf8 Class Initialized
INFO - 2022-01-19 14:20:06 --> URI Class Initialized
INFO - 2022-01-19 14:20:06 --> Router Class Initialized
INFO - 2022-01-19 14:20:06 --> Output Class Initialized
INFO - 2022-01-19 14:20:06 --> Security Class Initialized
DEBUG - 2022-01-19 14:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 14:20:06 --> Input Class Initialized
INFO - 2022-01-19 14:20:06 --> Language Class Initialized
INFO - 2022-01-19 14:20:06 --> Loader Class Initialized
INFO - 2022-01-19 14:20:06 --> Helper loaded: url_helper
INFO - 2022-01-19 14:20:06 --> Helper loaded: form_helper
INFO - 2022-01-19 14:20:06 --> Helper loaded: common_helper
INFO - 2022-01-19 14:20:06 --> Database Driver Class Initialized
DEBUG - 2022-01-19 14:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 14:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 14:20:06 --> Controller Class Initialized
INFO - 2022-01-19 14:20:06 --> Form Validation Class Initialized
DEBUG - 2022-01-19 14:20:06 --> Encrypt Class Initialized
DEBUG - 2022-01-19 14:20:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:20:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 14:20:06 --> Email Class Initialized
INFO - 2022-01-19 14:20:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 14:20:06 --> Calendar Class Initialized
INFO - 2022-01-19 14:20:06 --> Model "Login_model" initialized
INFO - 2022-01-19 14:20:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-19 14:20:06 --> Final output sent to browser
DEBUG - 2022-01-19 14:20:06 --> Total execution time: 0.0224
ERROR - 2022-01-19 14:20:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 14:20:07 --> Config Class Initialized
INFO - 2022-01-19 14:20:07 --> Hooks Class Initialized
DEBUG - 2022-01-19 14:20:07 --> UTF-8 Support Enabled
INFO - 2022-01-19 14:20:07 --> Utf8 Class Initialized
INFO - 2022-01-19 14:20:07 --> URI Class Initialized
DEBUG - 2022-01-19 14:20:07 --> No URI present. Default controller set.
INFO - 2022-01-19 14:20:07 --> Router Class Initialized
INFO - 2022-01-19 14:20:07 --> Output Class Initialized
INFO - 2022-01-19 14:20:07 --> Security Class Initialized
DEBUG - 2022-01-19 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 14:20:07 --> Input Class Initialized
INFO - 2022-01-19 14:20:07 --> Language Class Initialized
INFO - 2022-01-19 14:20:07 --> Loader Class Initialized
INFO - 2022-01-19 14:20:07 --> Helper loaded: url_helper
INFO - 2022-01-19 14:20:07 --> Helper loaded: form_helper
INFO - 2022-01-19 14:20:07 --> Helper loaded: common_helper
INFO - 2022-01-19 14:20:07 --> Database Driver Class Initialized
DEBUG - 2022-01-19 14:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 14:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 14:20:07 --> Controller Class Initialized
INFO - 2022-01-19 14:20:07 --> Form Validation Class Initialized
DEBUG - 2022-01-19 14:20:07 --> Encrypt Class Initialized
DEBUG - 2022-01-19 14:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 14:20:07 --> Email Class Initialized
INFO - 2022-01-19 14:20:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 14:20:07 --> Calendar Class Initialized
INFO - 2022-01-19 14:20:07 --> Model "Login_model" initialized
INFO - 2022-01-19 14:20:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-19 14:20:07 --> Final output sent to browser
DEBUG - 2022-01-19 14:20:07 --> Total execution time: 0.0216
ERROR - 2022-01-19 14:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 14:20:08 --> Config Class Initialized
INFO - 2022-01-19 14:20:08 --> Hooks Class Initialized
DEBUG - 2022-01-19 14:20:08 --> UTF-8 Support Enabled
INFO - 2022-01-19 14:20:08 --> Utf8 Class Initialized
INFO - 2022-01-19 14:20:08 --> URI Class Initialized
INFO - 2022-01-19 14:20:08 --> Router Class Initialized
INFO - 2022-01-19 14:20:08 --> Output Class Initialized
INFO - 2022-01-19 14:20:08 --> Security Class Initialized
DEBUG - 2022-01-19 14:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 14:20:08 --> Input Class Initialized
INFO - 2022-01-19 14:20:08 --> Language Class Initialized
INFO - 2022-01-19 14:20:08 --> Loader Class Initialized
INFO - 2022-01-19 14:20:08 --> Helper loaded: url_helper
INFO - 2022-01-19 14:20:08 --> Helper loaded: form_helper
INFO - 2022-01-19 14:20:08 --> Helper loaded: common_helper
INFO - 2022-01-19 14:20:08 --> Database Driver Class Initialized
DEBUG - 2022-01-19 14:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 14:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 14:20:08 --> Controller Class Initialized
INFO - 2022-01-19 14:20:08 --> Form Validation Class Initialized
DEBUG - 2022-01-19 14:20:08 --> Encrypt Class Initialized
DEBUG - 2022-01-19 14:20:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:20:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 14:20:08 --> Email Class Initialized
INFO - 2022-01-19 14:20:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 14:20:08 --> Calendar Class Initialized
INFO - 2022-01-19 14:20:08 --> Model "Login_model" initialized
ERROR - 2022-01-19 14:20:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 14:20:09 --> Config Class Initialized
INFO - 2022-01-19 14:20:09 --> Hooks Class Initialized
DEBUG - 2022-01-19 14:20:09 --> UTF-8 Support Enabled
INFO - 2022-01-19 14:20:09 --> Utf8 Class Initialized
INFO - 2022-01-19 14:20:09 --> URI Class Initialized
INFO - 2022-01-19 14:20:09 --> Router Class Initialized
INFO - 2022-01-19 14:20:09 --> Output Class Initialized
INFO - 2022-01-19 14:20:09 --> Security Class Initialized
DEBUG - 2022-01-19 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 14:20:09 --> Input Class Initialized
INFO - 2022-01-19 14:20:09 --> Language Class Initialized
INFO - 2022-01-19 14:20:09 --> Loader Class Initialized
INFO - 2022-01-19 14:20:09 --> Helper loaded: url_helper
INFO - 2022-01-19 14:20:09 --> Helper loaded: form_helper
INFO - 2022-01-19 14:20:09 --> Helper loaded: common_helper
INFO - 2022-01-19 14:20:09 --> Database Driver Class Initialized
DEBUG - 2022-01-19 14:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 14:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 14:20:09 --> Controller Class Initialized
INFO - 2022-01-19 14:20:09 --> Form Validation Class Initialized
DEBUG - 2022-01-19 14:20:09 --> Encrypt Class Initialized
DEBUG - 2022-01-19 14:20:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:20:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 14:20:09 --> Email Class Initialized
INFO - 2022-01-19 14:20:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 14:20:09 --> Calendar Class Initialized
INFO - 2022-01-19 14:20:09 --> Model "Login_model" initialized
ERROR - 2022-01-19 15:15:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 15:15:42 --> Config Class Initialized
INFO - 2022-01-19 15:15:42 --> Hooks Class Initialized
DEBUG - 2022-01-19 15:15:42 --> UTF-8 Support Enabled
INFO - 2022-01-19 15:15:42 --> Utf8 Class Initialized
INFO - 2022-01-19 15:15:42 --> URI Class Initialized
DEBUG - 2022-01-19 15:15:42 --> No URI present. Default controller set.
INFO - 2022-01-19 15:15:42 --> Router Class Initialized
INFO - 2022-01-19 15:15:42 --> Output Class Initialized
INFO - 2022-01-19 15:15:42 --> Security Class Initialized
DEBUG - 2022-01-19 15:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 15:15:42 --> Input Class Initialized
INFO - 2022-01-19 15:15:42 --> Language Class Initialized
INFO - 2022-01-19 15:15:42 --> Loader Class Initialized
INFO - 2022-01-19 15:15:42 --> Helper loaded: url_helper
INFO - 2022-01-19 15:15:42 --> Helper loaded: form_helper
INFO - 2022-01-19 15:15:42 --> Helper loaded: common_helper
INFO - 2022-01-19 15:15:42 --> Database Driver Class Initialized
DEBUG - 2022-01-19 15:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 15:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 15:15:42 --> Controller Class Initialized
INFO - 2022-01-19 15:15:42 --> Form Validation Class Initialized
DEBUG - 2022-01-19 15:15:42 --> Encrypt Class Initialized
DEBUG - 2022-01-19 15:15:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:15:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 15:15:42 --> Email Class Initialized
INFO - 2022-01-19 15:15:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 15:15:42 --> Calendar Class Initialized
INFO - 2022-01-19 15:15:42 --> Model "Login_model" initialized
INFO - 2022-01-19 15:15:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-19 15:15:42 --> Final output sent to browser
DEBUG - 2022-01-19 15:15:42 --> Total execution time: 0.0244
ERROR - 2022-01-19 15:16:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 15:16:06 --> Config Class Initialized
INFO - 2022-01-19 15:16:06 --> Hooks Class Initialized
DEBUG - 2022-01-19 15:16:06 --> UTF-8 Support Enabled
INFO - 2022-01-19 15:16:06 --> Utf8 Class Initialized
INFO - 2022-01-19 15:16:06 --> URI Class Initialized
DEBUG - 2022-01-19 15:16:06 --> No URI present. Default controller set.
INFO - 2022-01-19 15:16:06 --> Router Class Initialized
INFO - 2022-01-19 15:16:06 --> Output Class Initialized
INFO - 2022-01-19 15:16:06 --> Security Class Initialized
DEBUG - 2022-01-19 15:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 15:16:06 --> Input Class Initialized
INFO - 2022-01-19 15:16:06 --> Language Class Initialized
INFO - 2022-01-19 15:16:06 --> Loader Class Initialized
INFO - 2022-01-19 15:16:06 --> Helper loaded: url_helper
INFO - 2022-01-19 15:16:06 --> Helper loaded: form_helper
INFO - 2022-01-19 15:16:06 --> Helper loaded: common_helper
INFO - 2022-01-19 15:16:06 --> Database Driver Class Initialized
DEBUG - 2022-01-19 15:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 15:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 15:16:07 --> Controller Class Initialized
INFO - 2022-01-19 15:16:07 --> Form Validation Class Initialized
DEBUG - 2022-01-19 15:16:07 --> Encrypt Class Initialized
DEBUG - 2022-01-19 15:16:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:16:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 15:16:07 --> Email Class Initialized
INFO - 2022-01-19 15:16:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 15:16:07 --> Calendar Class Initialized
INFO - 2022-01-19 15:16:07 --> Model "Login_model" initialized
INFO - 2022-01-19 15:16:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-19 15:16:07 --> Final output sent to browser
DEBUG - 2022-01-19 15:16:07 --> Total execution time: 0.3412
ERROR - 2022-01-19 17:55:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 17:55:50 --> Config Class Initialized
INFO - 2022-01-19 17:55:50 --> Hooks Class Initialized
DEBUG - 2022-01-19 17:55:50 --> UTF-8 Support Enabled
INFO - 2022-01-19 17:55:50 --> Utf8 Class Initialized
INFO - 2022-01-19 17:55:50 --> URI Class Initialized
DEBUG - 2022-01-19 17:55:50 --> No URI present. Default controller set.
INFO - 2022-01-19 17:55:50 --> Router Class Initialized
INFO - 2022-01-19 17:55:50 --> Output Class Initialized
INFO - 2022-01-19 17:55:50 --> Security Class Initialized
DEBUG - 2022-01-19 17:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 17:55:50 --> Input Class Initialized
INFO - 2022-01-19 17:55:50 --> Language Class Initialized
INFO - 2022-01-19 17:55:50 --> Loader Class Initialized
INFO - 2022-01-19 17:55:50 --> Helper loaded: url_helper
INFO - 2022-01-19 17:55:50 --> Helper loaded: form_helper
INFO - 2022-01-19 17:55:50 --> Helper loaded: common_helper
INFO - 2022-01-19 17:55:50 --> Database Driver Class Initialized
DEBUG - 2022-01-19 17:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 17:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 17:55:50 --> Controller Class Initialized
INFO - 2022-01-19 17:55:50 --> Form Validation Class Initialized
DEBUG - 2022-01-19 17:55:50 --> Encrypt Class Initialized
DEBUG - 2022-01-19 17:55:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:55:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 17:55:50 --> Email Class Initialized
INFO - 2022-01-19 17:55:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 17:55:50 --> Calendar Class Initialized
INFO - 2022-01-19 17:55:50 --> Model "Login_model" initialized
INFO - 2022-01-19 17:55:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-19 17:55:50 --> Final output sent to browser
DEBUG - 2022-01-19 17:55:50 --> Total execution time: 0.0214
ERROR - 2022-01-19 18:05:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 18:05:15 --> Config Class Initialized
INFO - 2022-01-19 18:05:15 --> Hooks Class Initialized
DEBUG - 2022-01-19 18:05:15 --> UTF-8 Support Enabled
INFO - 2022-01-19 18:05:15 --> Utf8 Class Initialized
INFO - 2022-01-19 18:05:15 --> URI Class Initialized
DEBUG - 2022-01-19 18:05:15 --> No URI present. Default controller set.
INFO - 2022-01-19 18:05:15 --> Router Class Initialized
INFO - 2022-01-19 18:05:15 --> Output Class Initialized
INFO - 2022-01-19 18:05:15 --> Security Class Initialized
DEBUG - 2022-01-19 18:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 18:05:15 --> Input Class Initialized
INFO - 2022-01-19 18:05:15 --> Language Class Initialized
INFO - 2022-01-19 18:05:15 --> Loader Class Initialized
INFO - 2022-01-19 18:05:15 --> Helper loaded: url_helper
INFO - 2022-01-19 18:05:15 --> Helper loaded: form_helper
INFO - 2022-01-19 18:05:15 --> Helper loaded: common_helper
INFO - 2022-01-19 18:05:15 --> Database Driver Class Initialized
DEBUG - 2022-01-19 18:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 18:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 18:05:15 --> Controller Class Initialized
INFO - 2022-01-19 18:05:15 --> Form Validation Class Initialized
DEBUG - 2022-01-19 18:05:15 --> Encrypt Class Initialized
DEBUG - 2022-01-19 18:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 18:05:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 18:05:15 --> Email Class Initialized
INFO - 2022-01-19 18:05:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 18:05:15 --> Calendar Class Initialized
INFO - 2022-01-19 18:05:15 --> Model "Login_model" initialized
INFO - 2022-01-19 18:05:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-19 18:05:15 --> Final output sent to browser
DEBUG - 2022-01-19 18:05:15 --> Total execution time: 0.0250
ERROR - 2022-01-19 23:06:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-19 23:06:01 --> Config Class Initialized
INFO - 2022-01-19 23:06:01 --> Hooks Class Initialized
DEBUG - 2022-01-19 23:06:01 --> UTF-8 Support Enabled
INFO - 2022-01-19 23:06:01 --> Utf8 Class Initialized
INFO - 2022-01-19 23:06:01 --> URI Class Initialized
DEBUG - 2022-01-19 23:06:01 --> No URI present. Default controller set.
INFO - 2022-01-19 23:06:01 --> Router Class Initialized
INFO - 2022-01-19 23:06:01 --> Output Class Initialized
INFO - 2022-01-19 23:06:01 --> Security Class Initialized
DEBUG - 2022-01-19 23:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-19 23:06:01 --> Input Class Initialized
INFO - 2022-01-19 23:06:01 --> Language Class Initialized
INFO - 2022-01-19 23:06:01 --> Loader Class Initialized
INFO - 2022-01-19 23:06:01 --> Helper loaded: url_helper
INFO - 2022-01-19 23:06:01 --> Helper loaded: form_helper
INFO - 2022-01-19 23:06:01 --> Helper loaded: common_helper
INFO - 2022-01-19 23:06:01 --> Database Driver Class Initialized
DEBUG - 2022-01-19 23:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-19 23:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-19 23:06:01 --> Controller Class Initialized
INFO - 2022-01-19 23:06:01 --> Form Validation Class Initialized
DEBUG - 2022-01-19 23:06:01 --> Encrypt Class Initialized
DEBUG - 2022-01-19 23:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 23:06:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-19 23:06:01 --> Email Class Initialized
INFO - 2022-01-19 23:06:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-19 23:06:01 --> Calendar Class Initialized
INFO - 2022-01-19 23:06:01 --> Model "Login_model" initialized
INFO - 2022-01-19 23:06:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-19 23:06:01 --> Final output sent to browser
DEBUG - 2022-01-19 23:06:01 --> Total execution time: 0.0364
