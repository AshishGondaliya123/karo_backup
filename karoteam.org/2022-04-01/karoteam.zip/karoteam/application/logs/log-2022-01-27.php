<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-27 03:53:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 03:53:17 --> Config Class Initialized
INFO - 2022-01-27 03:53:17 --> Hooks Class Initialized
DEBUG - 2022-01-27 03:53:17 --> UTF-8 Support Enabled
INFO - 2022-01-27 03:53:17 --> Utf8 Class Initialized
INFO - 2022-01-27 03:53:17 --> URI Class Initialized
DEBUG - 2022-01-27 03:53:17 --> No URI present. Default controller set.
INFO - 2022-01-27 03:53:17 --> Router Class Initialized
INFO - 2022-01-27 03:53:17 --> Output Class Initialized
INFO - 2022-01-27 03:53:17 --> Security Class Initialized
DEBUG - 2022-01-27 03:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 03:53:17 --> Input Class Initialized
INFO - 2022-01-27 03:53:17 --> Language Class Initialized
INFO - 2022-01-27 03:53:17 --> Loader Class Initialized
INFO - 2022-01-27 03:53:17 --> Helper loaded: url_helper
INFO - 2022-01-27 03:53:17 --> Helper loaded: form_helper
INFO - 2022-01-27 03:53:17 --> Helper loaded: common_helper
INFO - 2022-01-27 03:53:17 --> Database Driver Class Initialized
DEBUG - 2022-01-27 03:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 03:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 03:53:17 --> Controller Class Initialized
INFO - 2022-01-27 03:53:17 --> Form Validation Class Initialized
DEBUG - 2022-01-27 03:53:17 --> Encrypt Class Initialized
DEBUG - 2022-01-27 03:53:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 03:53:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 03:53:17 --> Email Class Initialized
INFO - 2022-01-27 03:53:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 03:53:17 --> Calendar Class Initialized
INFO - 2022-01-27 03:53:17 --> Model "Login_model" initialized
INFO - 2022-01-27 03:53:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 03:53:17 --> Final output sent to browser
DEBUG - 2022-01-27 03:53:17 --> Total execution time: 0.0233
ERROR - 2022-01-27 10:17:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 10:17:24 --> Config Class Initialized
INFO - 2022-01-27 10:17:24 --> Hooks Class Initialized
DEBUG - 2022-01-27 10:17:24 --> UTF-8 Support Enabled
INFO - 2022-01-27 10:17:24 --> Utf8 Class Initialized
INFO - 2022-01-27 10:17:24 --> URI Class Initialized
DEBUG - 2022-01-27 10:17:24 --> No URI present. Default controller set.
INFO - 2022-01-27 10:17:24 --> Router Class Initialized
INFO - 2022-01-27 10:17:24 --> Output Class Initialized
INFO - 2022-01-27 10:17:24 --> Security Class Initialized
DEBUG - 2022-01-27 10:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 10:17:24 --> Input Class Initialized
INFO - 2022-01-27 10:17:24 --> Language Class Initialized
INFO - 2022-01-27 10:17:24 --> Loader Class Initialized
INFO - 2022-01-27 10:17:24 --> Helper loaded: url_helper
INFO - 2022-01-27 10:17:24 --> Helper loaded: form_helper
INFO - 2022-01-27 10:17:24 --> Helper loaded: common_helper
INFO - 2022-01-27 10:17:24 --> Database Driver Class Initialized
DEBUG - 2022-01-27 10:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 10:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 10:17:24 --> Controller Class Initialized
INFO - 2022-01-27 10:17:24 --> Form Validation Class Initialized
DEBUG - 2022-01-27 10:17:24 --> Encrypt Class Initialized
DEBUG - 2022-01-27 10:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 10:17:24 --> Email Class Initialized
INFO - 2022-01-27 10:17:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 10:17:24 --> Calendar Class Initialized
INFO - 2022-01-27 10:17:24 --> Model "Login_model" initialized
INFO - 2022-01-27 10:17:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 10:17:24 --> Final output sent to browser
DEBUG - 2022-01-27 10:17:24 --> Total execution time: 0.0753
ERROR - 2022-01-27 11:30:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 11:30:27 --> Config Class Initialized
INFO - 2022-01-27 11:30:27 --> Hooks Class Initialized
DEBUG - 2022-01-27 11:30:27 --> UTF-8 Support Enabled
INFO - 2022-01-27 11:30:27 --> Utf8 Class Initialized
INFO - 2022-01-27 11:30:27 --> URI Class Initialized
DEBUG - 2022-01-27 11:30:27 --> No URI present. Default controller set.
INFO - 2022-01-27 11:30:27 --> Router Class Initialized
INFO - 2022-01-27 11:30:27 --> Output Class Initialized
INFO - 2022-01-27 11:30:27 --> Security Class Initialized
DEBUG - 2022-01-27 11:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 11:30:27 --> Input Class Initialized
INFO - 2022-01-27 11:30:27 --> Language Class Initialized
INFO - 2022-01-27 11:30:27 --> Loader Class Initialized
INFO - 2022-01-27 11:30:27 --> Helper loaded: url_helper
INFO - 2022-01-27 11:30:27 --> Helper loaded: form_helper
INFO - 2022-01-27 11:30:27 --> Helper loaded: common_helper
INFO - 2022-01-27 11:30:27 --> Database Driver Class Initialized
DEBUG - 2022-01-27 11:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 11:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 11:30:27 --> Controller Class Initialized
INFO - 2022-01-27 11:30:27 --> Form Validation Class Initialized
DEBUG - 2022-01-27 11:30:27 --> Encrypt Class Initialized
DEBUG - 2022-01-27 11:30:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:30:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 11:30:27 --> Email Class Initialized
INFO - 2022-01-27 11:30:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 11:30:27 --> Calendar Class Initialized
INFO - 2022-01-27 11:30:27 --> Model "Login_model" initialized
INFO - 2022-01-27 11:30:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 11:30:27 --> Final output sent to browser
DEBUG - 2022-01-27 11:30:27 --> Total execution time: 0.0648
ERROR - 2022-01-27 12:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 12:32:05 --> Config Class Initialized
INFO - 2022-01-27 12:32:05 --> Hooks Class Initialized
DEBUG - 2022-01-27 12:32:05 --> UTF-8 Support Enabled
INFO - 2022-01-27 12:32:05 --> Utf8 Class Initialized
INFO - 2022-01-27 12:32:05 --> URI Class Initialized
DEBUG - 2022-01-27 12:32:05 --> No URI present. Default controller set.
INFO - 2022-01-27 12:32:05 --> Router Class Initialized
INFO - 2022-01-27 12:32:05 --> Output Class Initialized
INFO - 2022-01-27 12:32:05 --> Security Class Initialized
DEBUG - 2022-01-27 12:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 12:32:05 --> Input Class Initialized
INFO - 2022-01-27 12:32:05 --> Language Class Initialized
INFO - 2022-01-27 12:32:05 --> Loader Class Initialized
INFO - 2022-01-27 12:32:05 --> Helper loaded: url_helper
INFO - 2022-01-27 12:32:05 --> Helper loaded: form_helper
INFO - 2022-01-27 12:32:05 --> Helper loaded: common_helper
INFO - 2022-01-27 12:32:05 --> Database Driver Class Initialized
DEBUG - 2022-01-27 12:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 12:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 12:32:05 --> Controller Class Initialized
INFO - 2022-01-27 12:32:05 --> Form Validation Class Initialized
DEBUG - 2022-01-27 12:32:05 --> Encrypt Class Initialized
DEBUG - 2022-01-27 12:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 12:32:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 12:32:05 --> Email Class Initialized
INFO - 2022-01-27 12:32:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 12:32:05 --> Calendar Class Initialized
INFO - 2022-01-27 12:32:05 --> Model "Login_model" initialized
INFO - 2022-01-27 12:32:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 12:32:05 --> Final output sent to browser
DEBUG - 2022-01-27 12:32:05 --> Total execution time: 0.0338
ERROR - 2022-01-27 14:18:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 14:18:26 --> Config Class Initialized
INFO - 2022-01-27 14:18:26 --> Hooks Class Initialized
DEBUG - 2022-01-27 14:18:26 --> UTF-8 Support Enabled
INFO - 2022-01-27 14:18:26 --> Utf8 Class Initialized
INFO - 2022-01-27 14:18:26 --> URI Class Initialized
DEBUG - 2022-01-27 14:18:26 --> No URI present. Default controller set.
INFO - 2022-01-27 14:18:26 --> Router Class Initialized
INFO - 2022-01-27 14:18:26 --> Output Class Initialized
INFO - 2022-01-27 14:18:26 --> Security Class Initialized
DEBUG - 2022-01-27 14:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 14:18:26 --> Input Class Initialized
INFO - 2022-01-27 14:18:26 --> Language Class Initialized
INFO - 2022-01-27 14:18:26 --> Loader Class Initialized
INFO - 2022-01-27 14:18:26 --> Helper loaded: url_helper
INFO - 2022-01-27 14:18:26 --> Helper loaded: form_helper
INFO - 2022-01-27 14:18:26 --> Helper loaded: common_helper
INFO - 2022-01-27 14:18:26 --> Database Driver Class Initialized
DEBUG - 2022-01-27 14:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 14:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 14:18:26 --> Controller Class Initialized
INFO - 2022-01-27 14:18:26 --> Form Validation Class Initialized
DEBUG - 2022-01-27 14:18:26 --> Encrypt Class Initialized
DEBUG - 2022-01-27 14:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:18:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 14:18:26 --> Email Class Initialized
INFO - 2022-01-27 14:18:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 14:18:26 --> Calendar Class Initialized
INFO - 2022-01-27 14:18:26 --> Model "Login_model" initialized
INFO - 2022-01-27 14:18:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 14:18:26 --> Final output sent to browser
DEBUG - 2022-01-27 14:18:26 --> Total execution time: 0.0236
ERROR - 2022-01-27 14:18:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 14:18:26 --> Config Class Initialized
INFO - 2022-01-27 14:18:26 --> Hooks Class Initialized
DEBUG - 2022-01-27 14:18:26 --> UTF-8 Support Enabled
INFO - 2022-01-27 14:18:26 --> Utf8 Class Initialized
INFO - 2022-01-27 14:18:26 --> URI Class Initialized
INFO - 2022-01-27 14:18:26 --> Router Class Initialized
INFO - 2022-01-27 14:18:26 --> Output Class Initialized
INFO - 2022-01-27 14:18:26 --> Security Class Initialized
DEBUG - 2022-01-27 14:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 14:18:26 --> Input Class Initialized
INFO - 2022-01-27 14:18:26 --> Language Class Initialized
ERROR - 2022-01-27 14:18:26 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-27 14:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 14:18:55 --> Config Class Initialized
INFO - 2022-01-27 14:18:55 --> Hooks Class Initialized
DEBUG - 2022-01-27 14:18:55 --> UTF-8 Support Enabled
INFO - 2022-01-27 14:18:55 --> Utf8 Class Initialized
INFO - 2022-01-27 14:18:55 --> URI Class Initialized
INFO - 2022-01-27 14:18:55 --> Router Class Initialized
INFO - 2022-01-27 14:18:55 --> Output Class Initialized
INFO - 2022-01-27 14:18:55 --> Security Class Initialized
DEBUG - 2022-01-27 14:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 14:18:55 --> Input Class Initialized
INFO - 2022-01-27 14:18:55 --> Language Class Initialized
INFO - 2022-01-27 14:18:55 --> Loader Class Initialized
INFO - 2022-01-27 14:18:55 --> Helper loaded: url_helper
INFO - 2022-01-27 14:18:55 --> Helper loaded: form_helper
INFO - 2022-01-27 14:18:55 --> Helper loaded: common_helper
INFO - 2022-01-27 14:18:55 --> Database Driver Class Initialized
DEBUG - 2022-01-27 14:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 14:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 14:18:56 --> Controller Class Initialized
INFO - 2022-01-27 14:18:56 --> Form Validation Class Initialized
DEBUG - 2022-01-27 14:18:56 --> Encrypt Class Initialized
DEBUG - 2022-01-27 14:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 14:18:56 --> Email Class Initialized
INFO - 2022-01-27 14:18:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 14:18:56 --> Calendar Class Initialized
INFO - 2022-01-27 14:18:56 --> Model "Login_model" initialized
ERROR - 2022-01-27 14:18:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 14:18:56 --> Config Class Initialized
INFO - 2022-01-27 14:18:56 --> Hooks Class Initialized
DEBUG - 2022-01-27 14:18:56 --> UTF-8 Support Enabled
INFO - 2022-01-27 14:18:56 --> Utf8 Class Initialized
INFO - 2022-01-27 14:18:56 --> URI Class Initialized
INFO - 2022-01-27 14:18:56 --> Router Class Initialized
INFO - 2022-01-27 14:18:56 --> Output Class Initialized
INFO - 2022-01-27 14:18:56 --> Security Class Initialized
DEBUG - 2022-01-27 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 14:18:56 --> Input Class Initialized
INFO - 2022-01-27 14:18:56 --> Language Class Initialized
INFO - 2022-01-27 14:18:56 --> Loader Class Initialized
INFO - 2022-01-27 14:18:56 --> Helper loaded: url_helper
INFO - 2022-01-27 14:18:56 --> Helper loaded: form_helper
INFO - 2022-01-27 14:18:56 --> Helper loaded: common_helper
INFO - 2022-01-27 14:18:56 --> Database Driver Class Initialized
DEBUG - 2022-01-27 14:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 14:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 14:18:56 --> Controller Class Initialized
INFO - 2022-01-27 14:18:56 --> Form Validation Class Initialized
DEBUG - 2022-01-27 14:18:56 --> Encrypt Class Initialized
DEBUG - 2022-01-27 14:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 14:18:56 --> Email Class Initialized
INFO - 2022-01-27 14:18:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 14:18:56 --> Calendar Class Initialized
INFO - 2022-01-27 14:18:56 --> Model "Login_model" initialized
ERROR - 2022-01-27 14:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 14:18:57 --> Config Class Initialized
INFO - 2022-01-27 14:18:57 --> Hooks Class Initialized
DEBUG - 2022-01-27 14:18:57 --> UTF-8 Support Enabled
INFO - 2022-01-27 14:18:57 --> Utf8 Class Initialized
INFO - 2022-01-27 14:18:57 --> URI Class Initialized
DEBUG - 2022-01-27 14:18:57 --> No URI present. Default controller set.
INFO - 2022-01-27 14:18:57 --> Router Class Initialized
INFO - 2022-01-27 14:18:57 --> Output Class Initialized
INFO - 2022-01-27 14:18:57 --> Security Class Initialized
DEBUG - 2022-01-27 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 14:18:57 --> Input Class Initialized
INFO - 2022-01-27 14:18:57 --> Language Class Initialized
INFO - 2022-01-27 14:18:57 --> Loader Class Initialized
INFO - 2022-01-27 14:18:57 --> Helper loaded: url_helper
INFO - 2022-01-27 14:18:57 --> Helper loaded: form_helper
INFO - 2022-01-27 14:18:57 --> Helper loaded: common_helper
INFO - 2022-01-27 14:18:57 --> Database Driver Class Initialized
DEBUG - 2022-01-27 14:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 14:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 14:18:57 --> Controller Class Initialized
INFO - 2022-01-27 14:18:57 --> Form Validation Class Initialized
DEBUG - 2022-01-27 14:18:57 --> Encrypt Class Initialized
DEBUG - 2022-01-27 14:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 14:18:57 --> Email Class Initialized
INFO - 2022-01-27 14:18:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 14:18:57 --> Calendar Class Initialized
INFO - 2022-01-27 14:18:57 --> Model "Login_model" initialized
INFO - 2022-01-27 14:18:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 14:18:57 --> Final output sent to browser
DEBUG - 2022-01-27 14:18:57 --> Total execution time: 0.0333
ERROR - 2022-01-27 14:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 14:18:58 --> Config Class Initialized
INFO - 2022-01-27 14:18:58 --> Hooks Class Initialized
DEBUG - 2022-01-27 14:18:58 --> UTF-8 Support Enabled
INFO - 2022-01-27 14:18:58 --> Utf8 Class Initialized
INFO - 2022-01-27 14:18:58 --> URI Class Initialized
INFO - 2022-01-27 14:18:58 --> Router Class Initialized
INFO - 2022-01-27 14:18:58 --> Output Class Initialized
INFO - 2022-01-27 14:18:58 --> Security Class Initialized
DEBUG - 2022-01-27 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 14:18:58 --> Input Class Initialized
INFO - 2022-01-27 14:18:58 --> Language Class Initialized
INFO - 2022-01-27 14:18:58 --> Loader Class Initialized
INFO - 2022-01-27 14:18:58 --> Helper loaded: url_helper
INFO - 2022-01-27 14:18:58 --> Helper loaded: form_helper
INFO - 2022-01-27 14:18:58 --> Helper loaded: common_helper
INFO - 2022-01-27 14:18:58 --> Database Driver Class Initialized
DEBUG - 2022-01-27 14:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 14:18:58 --> Controller Class Initialized
INFO - 2022-01-27 14:18:58 --> Form Validation Class Initialized
DEBUG - 2022-01-27 14:18:58 --> Encrypt Class Initialized
DEBUG - 2022-01-27 14:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:18:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 14:18:58 --> Email Class Initialized
INFO - 2022-01-27 14:18:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 14:18:58 --> Calendar Class Initialized
INFO - 2022-01-27 14:18:58 --> Model "Login_model" initialized
INFO - 2022-01-27 14:18:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 14:18:58 --> Final output sent to browser
DEBUG - 2022-01-27 14:18:58 --> Total execution time: 0.0298
ERROR - 2022-01-27 15:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 15:16:24 --> Config Class Initialized
INFO - 2022-01-27 15:16:24 --> Hooks Class Initialized
DEBUG - 2022-01-27 15:16:24 --> UTF-8 Support Enabled
INFO - 2022-01-27 15:16:24 --> Utf8 Class Initialized
INFO - 2022-01-27 15:16:24 --> URI Class Initialized
DEBUG - 2022-01-27 15:16:24 --> No URI present. Default controller set.
INFO - 2022-01-27 15:16:24 --> Router Class Initialized
INFO - 2022-01-27 15:16:24 --> Output Class Initialized
INFO - 2022-01-27 15:16:24 --> Security Class Initialized
DEBUG - 2022-01-27 15:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 15:16:24 --> Input Class Initialized
INFO - 2022-01-27 15:16:24 --> Language Class Initialized
INFO - 2022-01-27 15:16:24 --> Loader Class Initialized
INFO - 2022-01-27 15:16:24 --> Helper loaded: url_helper
INFO - 2022-01-27 15:16:24 --> Helper loaded: form_helper
INFO - 2022-01-27 15:16:24 --> Helper loaded: common_helper
INFO - 2022-01-27 15:16:24 --> Database Driver Class Initialized
DEBUG - 2022-01-27 15:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 15:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 15:16:24 --> Controller Class Initialized
INFO - 2022-01-27 15:16:24 --> Form Validation Class Initialized
DEBUG - 2022-01-27 15:16:24 --> Encrypt Class Initialized
DEBUG - 2022-01-27 15:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:16:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 15:16:24 --> Email Class Initialized
INFO - 2022-01-27 15:16:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 15:16:24 --> Calendar Class Initialized
INFO - 2022-01-27 15:16:24 --> Model "Login_model" initialized
INFO - 2022-01-27 15:16:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 15:16:24 --> Final output sent to browser
DEBUG - 2022-01-27 15:16:24 --> Total execution time: 0.0237
ERROR - 2022-01-27 17:47:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 17:47:37 --> Config Class Initialized
INFO - 2022-01-27 17:47:37 --> Hooks Class Initialized
DEBUG - 2022-01-27 17:47:37 --> UTF-8 Support Enabled
INFO - 2022-01-27 17:47:37 --> Utf8 Class Initialized
INFO - 2022-01-27 17:47:37 --> URI Class Initialized
DEBUG - 2022-01-27 17:47:37 --> No URI present. Default controller set.
INFO - 2022-01-27 17:47:37 --> Router Class Initialized
INFO - 2022-01-27 17:47:37 --> Output Class Initialized
INFO - 2022-01-27 17:47:37 --> Security Class Initialized
DEBUG - 2022-01-27 17:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 17:47:37 --> Input Class Initialized
INFO - 2022-01-27 17:47:37 --> Language Class Initialized
INFO - 2022-01-27 17:47:37 --> Loader Class Initialized
INFO - 2022-01-27 17:47:37 --> Helper loaded: url_helper
INFO - 2022-01-27 17:47:37 --> Helper loaded: form_helper
INFO - 2022-01-27 17:47:37 --> Helper loaded: common_helper
INFO - 2022-01-27 17:47:37 --> Database Driver Class Initialized
DEBUG - 2022-01-27 17:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 17:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 17:47:37 --> Controller Class Initialized
INFO - 2022-01-27 17:47:37 --> Form Validation Class Initialized
DEBUG - 2022-01-27 17:47:37 --> Encrypt Class Initialized
DEBUG - 2022-01-27 17:47:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 17:47:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 17:47:37 --> Email Class Initialized
INFO - 2022-01-27 17:47:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 17:47:37 --> Calendar Class Initialized
INFO - 2022-01-27 17:47:37 --> Model "Login_model" initialized
INFO - 2022-01-27 17:47:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 17:47:37 --> Final output sent to browser
DEBUG - 2022-01-27 17:47:37 --> Total execution time: 0.0571
ERROR - 2022-01-27 17:47:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 17:47:38 --> Config Class Initialized
INFO - 2022-01-27 17:47:38 --> Hooks Class Initialized
DEBUG - 2022-01-27 17:47:38 --> UTF-8 Support Enabled
INFO - 2022-01-27 17:47:38 --> Utf8 Class Initialized
INFO - 2022-01-27 17:47:38 --> URI Class Initialized
INFO - 2022-01-27 17:47:38 --> Router Class Initialized
INFO - 2022-01-27 17:47:38 --> Output Class Initialized
INFO - 2022-01-27 17:47:38 --> Security Class Initialized
DEBUG - 2022-01-27 17:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 17:47:38 --> Input Class Initialized
INFO - 2022-01-27 17:47:38 --> Language Class Initialized
ERROR - 2022-01-27 17:47:38 --> 404 Page Not Found: Register/index
ERROR - 2022-01-27 17:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 17:47:39 --> Config Class Initialized
INFO - 2022-01-27 17:47:39 --> Hooks Class Initialized
DEBUG - 2022-01-27 17:47:39 --> UTF-8 Support Enabled
INFO - 2022-01-27 17:47:39 --> Utf8 Class Initialized
INFO - 2022-01-27 17:47:39 --> URI Class Initialized
INFO - 2022-01-27 17:47:39 --> Router Class Initialized
INFO - 2022-01-27 17:47:39 --> Output Class Initialized
INFO - 2022-01-27 17:47:39 --> Security Class Initialized
DEBUG - 2022-01-27 17:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 17:47:39 --> Input Class Initialized
INFO - 2022-01-27 17:47:39 --> Language Class Initialized
INFO - 2022-01-27 17:47:39 --> Loader Class Initialized
INFO - 2022-01-27 17:47:39 --> Helper loaded: url_helper
INFO - 2022-01-27 17:47:39 --> Helper loaded: form_helper
INFO - 2022-01-27 17:47:39 --> Helper loaded: common_helper
INFO - 2022-01-27 17:47:39 --> Database Driver Class Initialized
DEBUG - 2022-01-27 17:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 17:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 17:47:39 --> Controller Class Initialized
INFO - 2022-01-27 17:47:39 --> Form Validation Class Initialized
DEBUG - 2022-01-27 17:47:39 --> Encrypt Class Initialized
DEBUG - 2022-01-27 17:47:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 17:47:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 17:47:39 --> Email Class Initialized
INFO - 2022-01-27 17:47:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 17:47:39 --> Calendar Class Initialized
INFO - 2022-01-27 17:47:39 --> Model "Login_model" initialized
INFO - 2022-01-27 17:47:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 17:47:39 --> Final output sent to browser
DEBUG - 2022-01-27 17:47:39 --> Total execution time: 0.0559
ERROR - 2022-01-27 17:47:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 17:47:40 --> Config Class Initialized
INFO - 2022-01-27 17:47:40 --> Hooks Class Initialized
DEBUG - 2022-01-27 17:47:40 --> UTF-8 Support Enabled
INFO - 2022-01-27 17:47:40 --> Utf8 Class Initialized
INFO - 2022-01-27 17:47:40 --> URI Class Initialized
DEBUG - 2022-01-27 17:47:40 --> No URI present. Default controller set.
INFO - 2022-01-27 17:47:40 --> Router Class Initialized
INFO - 2022-01-27 17:47:40 --> Output Class Initialized
INFO - 2022-01-27 17:47:40 --> Security Class Initialized
DEBUG - 2022-01-27 17:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 17:47:40 --> Input Class Initialized
INFO - 2022-01-27 17:47:40 --> Language Class Initialized
INFO - 2022-01-27 17:47:40 --> Loader Class Initialized
INFO - 2022-01-27 17:47:40 --> Helper loaded: url_helper
INFO - 2022-01-27 17:47:40 --> Helper loaded: form_helper
INFO - 2022-01-27 17:47:40 --> Helper loaded: common_helper
INFO - 2022-01-27 17:47:40 --> Database Driver Class Initialized
DEBUG - 2022-01-27 17:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 17:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 17:47:40 --> Controller Class Initialized
INFO - 2022-01-27 17:47:40 --> Form Validation Class Initialized
DEBUG - 2022-01-27 17:47:40 --> Encrypt Class Initialized
DEBUG - 2022-01-27 17:47:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 17:47:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 17:47:40 --> Email Class Initialized
INFO - 2022-01-27 17:47:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 17:47:40 --> Calendar Class Initialized
INFO - 2022-01-27 17:47:40 --> Model "Login_model" initialized
INFO - 2022-01-27 17:47:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 17:47:40 --> Final output sent to browser
DEBUG - 2022-01-27 17:47:40 --> Total execution time: 0.0329
ERROR - 2022-01-27 17:47:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 17:47:41 --> Config Class Initialized
INFO - 2022-01-27 17:47:41 --> Hooks Class Initialized
DEBUG - 2022-01-27 17:47:41 --> UTF-8 Support Enabled
INFO - 2022-01-27 17:47:41 --> Utf8 Class Initialized
INFO - 2022-01-27 17:47:41 --> URI Class Initialized
INFO - 2022-01-27 17:47:41 --> Router Class Initialized
INFO - 2022-01-27 17:47:41 --> Output Class Initialized
INFO - 2022-01-27 17:47:41 --> Security Class Initialized
DEBUG - 2022-01-27 17:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 17:47:41 --> Input Class Initialized
INFO - 2022-01-27 17:47:41 --> Language Class Initialized
INFO - 2022-01-27 17:47:41 --> Loader Class Initialized
INFO - 2022-01-27 17:47:41 --> Helper loaded: url_helper
INFO - 2022-01-27 17:47:41 --> Helper loaded: form_helper
INFO - 2022-01-27 17:47:41 --> Helper loaded: common_helper
INFO - 2022-01-27 17:47:41 --> Database Driver Class Initialized
DEBUG - 2022-01-27 17:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 17:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 17:47:41 --> Controller Class Initialized
INFO - 2022-01-27 17:47:41 --> Form Validation Class Initialized
DEBUG - 2022-01-27 17:47:41 --> Encrypt Class Initialized
DEBUG - 2022-01-27 17:47:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 17:47:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 17:47:41 --> Email Class Initialized
INFO - 2022-01-27 17:47:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 17:47:41 --> Calendar Class Initialized
INFO - 2022-01-27 17:47:41 --> Model "Login_model" initialized
ERROR - 2022-01-27 17:47:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 17:47:41 --> Config Class Initialized
INFO - 2022-01-27 17:47:41 --> Hooks Class Initialized
DEBUG - 2022-01-27 17:47:41 --> UTF-8 Support Enabled
INFO - 2022-01-27 17:47:41 --> Utf8 Class Initialized
INFO - 2022-01-27 17:47:41 --> URI Class Initialized
INFO - 2022-01-27 17:47:41 --> Router Class Initialized
INFO - 2022-01-27 17:47:41 --> Output Class Initialized
INFO - 2022-01-27 17:47:41 --> Security Class Initialized
DEBUG - 2022-01-27 17:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 17:47:41 --> Input Class Initialized
INFO - 2022-01-27 17:47:41 --> Language Class Initialized
INFO - 2022-01-27 17:47:41 --> Loader Class Initialized
INFO - 2022-01-27 17:47:41 --> Helper loaded: url_helper
INFO - 2022-01-27 17:47:41 --> Helper loaded: form_helper
INFO - 2022-01-27 17:47:41 --> Helper loaded: common_helper
INFO - 2022-01-27 17:47:41 --> Database Driver Class Initialized
DEBUG - 2022-01-27 17:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 17:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 17:47:41 --> Controller Class Initialized
INFO - 2022-01-27 17:47:41 --> Form Validation Class Initialized
DEBUG - 2022-01-27 17:47:41 --> Encrypt Class Initialized
DEBUG - 2022-01-27 17:47:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 17:47:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 17:47:41 --> Email Class Initialized
INFO - 2022-01-27 17:47:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 17:47:41 --> Calendar Class Initialized
INFO - 2022-01-27 17:47:41 --> Model "Login_model" initialized
INFO - 2022-01-27 17:47:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 17:47:41 --> Final output sent to browser
DEBUG - 2022-01-27 17:47:41 --> Total execution time: 0.0230
ERROR - 2022-01-27 20:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-27 20:37:05 --> Config Class Initialized
INFO - 2022-01-27 20:37:05 --> Hooks Class Initialized
DEBUG - 2022-01-27 20:37:05 --> UTF-8 Support Enabled
INFO - 2022-01-27 20:37:05 --> Utf8 Class Initialized
INFO - 2022-01-27 20:37:05 --> URI Class Initialized
DEBUG - 2022-01-27 20:37:05 --> No URI present. Default controller set.
INFO - 2022-01-27 20:37:05 --> Router Class Initialized
INFO - 2022-01-27 20:37:05 --> Output Class Initialized
INFO - 2022-01-27 20:37:05 --> Security Class Initialized
DEBUG - 2022-01-27 20:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-27 20:37:05 --> Input Class Initialized
INFO - 2022-01-27 20:37:05 --> Language Class Initialized
INFO - 2022-01-27 20:37:05 --> Loader Class Initialized
INFO - 2022-01-27 20:37:05 --> Helper loaded: url_helper
INFO - 2022-01-27 20:37:05 --> Helper loaded: form_helper
INFO - 2022-01-27 20:37:05 --> Helper loaded: common_helper
INFO - 2022-01-27 20:37:05 --> Database Driver Class Initialized
DEBUG - 2022-01-27 20:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-27 20:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-27 20:37:05 --> Controller Class Initialized
INFO - 2022-01-27 20:37:05 --> Form Validation Class Initialized
DEBUG - 2022-01-27 20:37:05 --> Encrypt Class Initialized
DEBUG - 2022-01-27 20:37:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 20:37:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-27 20:37:05 --> Email Class Initialized
INFO - 2022-01-27 20:37:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-27 20:37:05 --> Calendar Class Initialized
INFO - 2022-01-27 20:37:05 --> Model "Login_model" initialized
INFO - 2022-01-27 20:37:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-27 20:37:05 --> Final output sent to browser
DEBUG - 2022-01-27 20:37:05 --> Total execution time: 0.0398
