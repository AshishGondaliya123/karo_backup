<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-20 11:32:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:32:02 --> Config Class Initialized
INFO - 2021-06-20 11:32:02 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:32:02 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:32:02 --> Utf8 Class Initialized
INFO - 2021-06-20 11:32:02 --> URI Class Initialized
DEBUG - 2021-06-20 11:32:02 --> No URI present. Default controller set.
INFO - 2021-06-20 11:32:02 --> Router Class Initialized
INFO - 2021-06-20 11:32:02 --> Output Class Initialized
INFO - 2021-06-20 11:32:02 --> Security Class Initialized
DEBUG - 2021-06-20 11:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:32:02 --> Input Class Initialized
INFO - 2021-06-20 11:32:02 --> Language Class Initialized
INFO - 2021-06-20 11:32:02 --> Loader Class Initialized
INFO - 2021-06-20 11:32:02 --> Helper loaded: url_helper
INFO - 2021-06-20 11:32:02 --> Helper loaded: form_helper
INFO - 2021-06-20 11:32:02 --> Helper loaded: common_helper
INFO - 2021-06-20 11:32:02 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:32:02 --> Controller Class Initialized
INFO - 2021-06-20 11:32:02 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:32:02 --> Encrypt Class Initialized
DEBUG - 2021-06-20 11:32:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-20 11:32:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-20 11:32:02 --> Email Class Initialized
INFO - 2021-06-20 11:32:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-20 11:32:02 --> Calendar Class Initialized
INFO - 2021-06-20 11:32:02 --> Model "Login_model" initialized
INFO - 2021-06-20 11:32:02 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-20 11:32:02 --> Final output sent to browser
DEBUG - 2021-06-20 11:32:02 --> Total execution time: 0.0400
ERROR - 2021-06-20 11:32:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:32:04 --> Config Class Initialized
INFO - 2021-06-20 11:32:04 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:32:04 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:32:04 --> Utf8 Class Initialized
INFO - 2021-06-20 11:32:04 --> URI Class Initialized
INFO - 2021-06-20 11:32:04 --> Router Class Initialized
INFO - 2021-06-20 11:32:04 --> Output Class Initialized
INFO - 2021-06-20 11:32:04 --> Security Class Initialized
DEBUG - 2021-06-20 11:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:32:04 --> Input Class Initialized
INFO - 2021-06-20 11:32:04 --> Language Class Initialized
ERROR - 2021-06-20 11:32:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-20 11:32:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:32:50 --> Config Class Initialized
INFO - 2021-06-20 11:32:50 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:32:50 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:32:50 --> Utf8 Class Initialized
INFO - 2021-06-20 11:32:50 --> URI Class Initialized
INFO - 2021-06-20 11:32:50 --> Router Class Initialized
INFO - 2021-06-20 11:32:50 --> Output Class Initialized
INFO - 2021-06-20 11:32:50 --> Security Class Initialized
DEBUG - 2021-06-20 11:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:32:50 --> Input Class Initialized
INFO - 2021-06-20 11:32:50 --> Language Class Initialized
INFO - 2021-06-20 11:32:50 --> Loader Class Initialized
INFO - 2021-06-20 11:32:50 --> Helper loaded: url_helper
INFO - 2021-06-20 11:32:50 --> Helper loaded: form_helper
INFO - 2021-06-20 11:32:50 --> Helper loaded: common_helper
INFO - 2021-06-20 11:32:50 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:32:50 --> Controller Class Initialized
INFO - 2021-06-20 11:32:50 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:32:50 --> Encrypt Class Initialized
DEBUG - 2021-06-20 11:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-20 11:32:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-20 11:32:50 --> Email Class Initialized
INFO - 2021-06-20 11:32:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-20 11:32:50 --> Calendar Class Initialized
INFO - 2021-06-20 11:32:50 --> Model "Login_model" initialized
INFO - 2021-06-20 11:32:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-20 11:32:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:32:50 --> Config Class Initialized
INFO - 2021-06-20 11:32:50 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:32:50 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:32:50 --> Utf8 Class Initialized
INFO - 2021-06-20 11:32:50 --> URI Class Initialized
INFO - 2021-06-20 11:32:50 --> Router Class Initialized
INFO - 2021-06-20 11:32:50 --> Output Class Initialized
INFO - 2021-06-20 11:32:50 --> Security Class Initialized
DEBUG - 2021-06-20 11:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:32:50 --> Input Class Initialized
INFO - 2021-06-20 11:32:50 --> Language Class Initialized
INFO - 2021-06-20 11:32:50 --> Loader Class Initialized
INFO - 2021-06-20 11:32:50 --> Helper loaded: url_helper
INFO - 2021-06-20 11:32:50 --> Helper loaded: form_helper
INFO - 2021-06-20 11:32:50 --> Helper loaded: common_helper
INFO - 2021-06-20 11:32:50 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:32:50 --> Controller Class Initialized
INFO - 2021-06-20 11:32:50 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:32:50 --> Encrypt Class Initialized
INFO - 2021-06-20 11:32:50 --> Model "Login_model" initialized
INFO - 2021-06-20 11:32:50 --> Model "Dashboard_model" initialized
INFO - 2021-06-20 11:32:50 --> Model "Case_model" initialized
INFO - 2021-06-20 11:32:53 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-20 11:33:00 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-20 11:33:00 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-20 11:33:00 --> Final output sent to browser
DEBUG - 2021-06-20 11:33:00 --> Total execution time: 9.3048
ERROR - 2021-06-20 11:33:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:02 --> Config Class Initialized
INFO - 2021-06-20 11:33:02 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:02 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:02 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:02 --> URI Class Initialized
INFO - 2021-06-20 11:33:02 --> Router Class Initialized
INFO - 2021-06-20 11:33:02 --> Output Class Initialized
INFO - 2021-06-20 11:33:02 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:02 --> Input Class Initialized
INFO - 2021-06-20 11:33:02 --> Language Class Initialized
ERROR - 2021-06-20 11:33:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-20 11:33:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:06 --> Config Class Initialized
INFO - 2021-06-20 11:33:06 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:06 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:06 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:06 --> URI Class Initialized
INFO - 2021-06-20 11:33:06 --> Router Class Initialized
INFO - 2021-06-20 11:33:06 --> Output Class Initialized
INFO - 2021-06-20 11:33:06 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:06 --> Input Class Initialized
INFO - 2021-06-20 11:33:06 --> Language Class Initialized
INFO - 2021-06-20 11:33:06 --> Loader Class Initialized
INFO - 2021-06-20 11:33:06 --> Helper loaded: url_helper
INFO - 2021-06-20 11:33:06 --> Helper loaded: form_helper
INFO - 2021-06-20 11:33:06 --> Helper loaded: common_helper
INFO - 2021-06-20 11:33:06 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:33:06 --> Controller Class Initialized
INFO - 2021-06-20 11:33:06 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:33:06 --> Encrypt Class Initialized
INFO - 2021-06-20 11:33:06 --> Model "Login_model" initialized
INFO - 2021-06-20 11:33:06 --> Model "Dashboard_model" initialized
INFO - 2021-06-20 11:33:06 --> Model "Case_model" initialized
INFO - 2021-06-20 11:33:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-20 11:33:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/birthday.php
INFO - 2021-06-20 11:33:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-20 11:33:06 --> Final output sent to browser
DEBUG - 2021-06-20 11:33:06 --> Total execution time: 0.0206
ERROR - 2021-06-20 11:33:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:07 --> Config Class Initialized
INFO - 2021-06-20 11:33:07 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:07 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:07 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:07 --> URI Class Initialized
INFO - 2021-06-20 11:33:07 --> Router Class Initialized
INFO - 2021-06-20 11:33:07 --> Output Class Initialized
INFO - 2021-06-20 11:33:07 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:07 --> Input Class Initialized
INFO - 2021-06-20 11:33:07 --> Language Class Initialized
ERROR - 2021-06-20 11:33:07 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-20 11:33:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:25 --> Config Class Initialized
INFO - 2021-06-20 11:33:25 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:25 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:25 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:25 --> URI Class Initialized
INFO - 2021-06-20 11:33:25 --> Router Class Initialized
INFO - 2021-06-20 11:33:25 --> Output Class Initialized
INFO - 2021-06-20 11:33:25 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:25 --> Input Class Initialized
INFO - 2021-06-20 11:33:25 --> Language Class Initialized
INFO - 2021-06-20 11:33:25 --> Loader Class Initialized
INFO - 2021-06-20 11:33:25 --> Helper loaded: url_helper
INFO - 2021-06-20 11:33:25 --> Helper loaded: form_helper
INFO - 2021-06-20 11:33:25 --> Helper loaded: common_helper
INFO - 2021-06-20 11:33:25 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:33:25 --> Controller Class Initialized
INFO - 2021-06-20 11:33:25 --> Form Validation Class Initialized
INFO - 2021-06-20 11:33:25 --> Model "Case_model" initialized
INFO - 2021-06-20 11:33:25 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-20 11:33:25 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/donner_donation.php
INFO - 2021-06-20 11:33:25 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-20 11:33:25 --> Final output sent to browser
DEBUG - 2021-06-20 11:33:25 --> Total execution time: 0.0234
ERROR - 2021-06-20 11:33:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:25 --> Config Class Initialized
INFO - 2021-06-20 11:33:25 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:25 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:25 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:25 --> URI Class Initialized
INFO - 2021-06-20 11:33:25 --> Router Class Initialized
INFO - 2021-06-20 11:33:25 --> Output Class Initialized
INFO - 2021-06-20 11:33:25 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:25 --> Input Class Initialized
INFO - 2021-06-20 11:33:25 --> Language Class Initialized
ERROR - 2021-06-20 11:33:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-20 11:33:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:36 --> Config Class Initialized
INFO - 2021-06-20 11:33:36 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:36 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:36 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:36 --> URI Class Initialized
INFO - 2021-06-20 11:33:36 --> Router Class Initialized
INFO - 2021-06-20 11:33:36 --> Output Class Initialized
INFO - 2021-06-20 11:33:36 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:36 --> Input Class Initialized
INFO - 2021-06-20 11:33:36 --> Language Class Initialized
INFO - 2021-06-20 11:33:36 --> Loader Class Initialized
INFO - 2021-06-20 11:33:36 --> Helper loaded: url_helper
INFO - 2021-06-20 11:33:36 --> Helper loaded: form_helper
INFO - 2021-06-20 11:33:36 --> Helper loaded: common_helper
INFO - 2021-06-20 11:33:36 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:33:36 --> Controller Class Initialized
INFO - 2021-06-20 11:33:36 --> Form Validation Class Initialized
INFO - 2021-06-20 11:33:36 --> Model "Case_model" initialized
INFO - 2021-06-20 11:33:36 --> Model "Patientcase_model" initialized
INFO - 2021-06-20 11:33:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-20 11:33:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/cases/new_case.php
INFO - 2021-06-20 11:33:36 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-20 11:33:36 --> Final output sent to browser
DEBUG - 2021-06-20 11:33:36 --> Total execution time: 0.2132
ERROR - 2021-06-20 11:33:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:36 --> Config Class Initialized
INFO - 2021-06-20 11:33:36 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:36 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:36 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:36 --> URI Class Initialized
INFO - 2021-06-20 11:33:36 --> Router Class Initialized
INFO - 2021-06-20 11:33:36 --> Output Class Initialized
INFO - 2021-06-20 11:33:36 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:36 --> Input Class Initialized
INFO - 2021-06-20 11:33:36 --> Language Class Initialized
ERROR - 2021-06-20 11:33:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-20 11:33:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:38 --> Config Class Initialized
INFO - 2021-06-20 11:33:38 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:38 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:38 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:38 --> URI Class Initialized
INFO - 2021-06-20 11:33:38 --> Router Class Initialized
INFO - 2021-06-20 11:33:38 --> Output Class Initialized
INFO - 2021-06-20 11:33:38 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:38 --> Input Class Initialized
INFO - 2021-06-20 11:33:38 --> Language Class Initialized
INFO - 2021-06-20 11:33:38 --> Loader Class Initialized
INFO - 2021-06-20 11:33:38 --> Helper loaded: url_helper
INFO - 2021-06-20 11:33:38 --> Helper loaded: form_helper
INFO - 2021-06-20 11:33:38 --> Helper loaded: common_helper
INFO - 2021-06-20 11:33:38 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:33:38 --> Controller Class Initialized
INFO - 2021-06-20 11:33:38 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:33:38 --> Encrypt Class Initialized
INFO - 2021-06-20 11:33:38 --> Model "Patient_model" initialized
INFO - 2021-06-20 11:33:38 --> Model "Patientcase_model" initialized
INFO - 2021-06-20 11:33:38 --> Model "Referredby_model" initialized
INFO - 2021-06-20 11:33:38 --> Model "Prefix_master" initialized
INFO - 2021-06-20 11:33:38 --> Model "Hospital_model" initialized
INFO - 2021-06-20 11:33:38 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-20 11:33:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-20 11:33:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-20 11:33:43 --> Final output sent to browser
DEBUG - 2021-06-20 11:33:43 --> Total execution time: 4.1216
ERROR - 2021-06-20 11:33:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:45 --> Config Class Initialized
INFO - 2021-06-20 11:33:45 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:45 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:45 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:45 --> URI Class Initialized
INFO - 2021-06-20 11:33:45 --> Router Class Initialized
INFO - 2021-06-20 11:33:45 --> Output Class Initialized
INFO - 2021-06-20 11:33:45 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:45 --> Input Class Initialized
INFO - 2021-06-20 11:33:45 --> Language Class Initialized
ERROR - 2021-06-20 11:33:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-20 11:33:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:51 --> Config Class Initialized
INFO - 2021-06-20 11:33:51 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:51 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:51 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:51 --> URI Class Initialized
INFO - 2021-06-20 11:33:51 --> Router Class Initialized
INFO - 2021-06-20 11:33:51 --> Output Class Initialized
INFO - 2021-06-20 11:33:51 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:51 --> Input Class Initialized
INFO - 2021-06-20 11:33:51 --> Language Class Initialized
INFO - 2021-06-20 11:33:51 --> Loader Class Initialized
INFO - 2021-06-20 11:33:51 --> Helper loaded: url_helper
INFO - 2021-06-20 11:33:51 --> Helper loaded: form_helper
INFO - 2021-06-20 11:33:51 --> Helper loaded: common_helper
INFO - 2021-06-20 11:33:51 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:33:51 --> Controller Class Initialized
INFO - 2021-06-20 11:33:51 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:33:51 --> Encrypt Class Initialized
INFO - 2021-06-20 11:33:51 --> Model "Patient_model" initialized
INFO - 2021-06-20 11:33:51 --> Model "Patientcase_model" initialized
INFO - 2021-06-20 11:33:51 --> Model "Prefix_master" initialized
INFO - 2021-06-20 11:33:51 --> Model "Users_model" initialized
INFO - 2021-06-20 11:33:51 --> Model "Hospital_model" initialized
INFO - 2021-06-20 11:33:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
INFO - 2021-06-20 11:33:51 --> Final output sent to browser
DEBUG - 2021-06-20 11:33:51 --> Total execution time: 0.7953
ERROR - 2021-06-20 11:33:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:33:56 --> Config Class Initialized
INFO - 2021-06-20 11:33:56 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:33:56 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:33:56 --> Utf8 Class Initialized
INFO - 2021-06-20 11:33:56 --> URI Class Initialized
INFO - 2021-06-20 11:33:56 --> Router Class Initialized
INFO - 2021-06-20 11:33:56 --> Output Class Initialized
INFO - 2021-06-20 11:33:56 --> Security Class Initialized
DEBUG - 2021-06-20 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:33:56 --> Input Class Initialized
INFO - 2021-06-20 11:33:56 --> Language Class Initialized
INFO - 2021-06-20 11:33:56 --> Loader Class Initialized
INFO - 2021-06-20 11:33:56 --> Helper loaded: url_helper
INFO - 2021-06-20 11:33:56 --> Helper loaded: form_helper
INFO - 2021-06-20 11:33:56 --> Helper loaded: common_helper
INFO - 2021-06-20 11:33:56 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:33:56 --> Controller Class Initialized
INFO - 2021-06-20 11:33:56 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:33:56 --> Encrypt Class Initialized
INFO - 2021-06-20 11:33:56 --> Model "Patient_model" initialized
INFO - 2021-06-20 11:33:56 --> Model "Patientcase_model" initialized
INFO - 2021-06-20 11:33:56 --> Model "Prefix_master" initialized
INFO - 2021-06-20 11:33:56 --> Model "Users_model" initialized
INFO - 2021-06-20 11:33:56 --> Model "Hospital_model" initialized
INFO - 2021-06-20 11:33:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
INFO - 2021-06-20 11:33:56 --> Final output sent to browser
DEBUG - 2021-06-20 11:33:56 --> Total execution time: 0.4852
ERROR - 2021-06-20 11:34:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:00 --> Config Class Initialized
INFO - 2021-06-20 11:34:00 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:00 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:00 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:00 --> URI Class Initialized
INFO - 2021-06-20 11:34:00 --> Router Class Initialized
INFO - 2021-06-20 11:34:00 --> Output Class Initialized
INFO - 2021-06-20 11:34:00 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:00 --> Input Class Initialized
INFO - 2021-06-20 11:34:00 --> Language Class Initialized
ERROR - 2021-06-20 11:34:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-20 11:34:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:16 --> Config Class Initialized
INFO - 2021-06-20 11:34:16 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:16 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:16 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:16 --> URI Class Initialized
INFO - 2021-06-20 11:34:16 --> Router Class Initialized
INFO - 2021-06-20 11:34:16 --> Output Class Initialized
INFO - 2021-06-20 11:34:16 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:16 --> Input Class Initialized
INFO - 2021-06-20 11:34:16 --> Language Class Initialized
INFO - 2021-06-20 11:34:16 --> Loader Class Initialized
INFO - 2021-06-20 11:34:16 --> Helper loaded: url_helper
INFO - 2021-06-20 11:34:16 --> Helper loaded: form_helper
INFO - 2021-06-20 11:34:16 --> Helper loaded: common_helper
INFO - 2021-06-20 11:34:16 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:34:16 --> Controller Class Initialized
INFO - 2021-06-20 11:34:16 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:34:16 --> Encrypt Class Initialized
INFO - 2021-06-20 11:34:16 --> Model "Patient_model" initialized
INFO - 2021-06-20 11:34:16 --> Model "Patientcase_model" initialized
INFO - 2021-06-20 11:34:16 --> Model "Prefix_master" initialized
INFO - 2021-06-20 11:34:16 --> Model "Users_model" initialized
INFO - 2021-06-20 11:34:16 --> Model "Hospital_model" initialized
INFO - 2021-06-20 11:34:16 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-20 11:34:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:16 --> Config Class Initialized
INFO - 2021-06-20 11:34:16 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:16 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:16 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:16 --> URI Class Initialized
INFO - 2021-06-20 11:34:16 --> Router Class Initialized
INFO - 2021-06-20 11:34:16 --> Output Class Initialized
INFO - 2021-06-20 11:34:16 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:16 --> Input Class Initialized
INFO - 2021-06-20 11:34:16 --> Language Class Initialized
ERROR - 2021-06-20 11:34:16 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-20 11:34:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:16 --> Config Class Initialized
INFO - 2021-06-20 11:34:16 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:16 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:16 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:16 --> URI Class Initialized
INFO - 2021-06-20 11:34:16 --> Router Class Initialized
INFO - 2021-06-20 11:34:16 --> Output Class Initialized
INFO - 2021-06-20 11:34:16 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:16 --> Input Class Initialized
INFO - 2021-06-20 11:34:16 --> Language Class Initialized
ERROR - 2021-06-20 11:34:16 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-20 11:34:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:16 --> Config Class Initialized
INFO - 2021-06-20 11:34:16 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:16 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:16 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:16 --> URI Class Initialized
INFO - 2021-06-20 11:34:16 --> Router Class Initialized
INFO - 2021-06-20 11:34:16 --> Output Class Initialized
INFO - 2021-06-20 11:34:16 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:16 --> Input Class Initialized
INFO - 2021-06-20 11:34:16 --> Language Class Initialized
ERROR - 2021-06-20 11:34:16 --> 404 Page Not Found: Karoclient/images
INFO - 2021-06-20 11:34:17 --> Final output sent to browser
DEBUG - 2021-06-20 11:34:17 --> Total execution time: 1.0198
ERROR - 2021-06-20 11:34:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:17 --> Config Class Initialized
INFO - 2021-06-20 11:34:17 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:17 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:17 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:17 --> URI Class Initialized
INFO - 2021-06-20 11:34:17 --> Router Class Initialized
INFO - 2021-06-20 11:34:17 --> Output Class Initialized
INFO - 2021-06-20 11:34:17 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:17 --> Input Class Initialized
INFO - 2021-06-20 11:34:17 --> Language Class Initialized
INFO - 2021-06-20 11:34:17 --> Loader Class Initialized
INFO - 2021-06-20 11:34:17 --> Helper loaded: url_helper
INFO - 2021-06-20 11:34:17 --> Helper loaded: form_helper
INFO - 2021-06-20 11:34:17 --> Helper loaded: common_helper
INFO - 2021-06-20 11:34:17 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:34:17 --> Controller Class Initialized
INFO - 2021-06-20 11:34:17 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:34:17 --> Encrypt Class Initialized
INFO - 2021-06-20 11:34:17 --> Model "Patient_model" initialized
INFO - 2021-06-20 11:34:17 --> Model "Patientcase_model" initialized
INFO - 2021-06-20 11:34:17 --> Model "Prefix_master" initialized
INFO - 2021-06-20 11:34:17 --> Model "Users_model" initialized
INFO - 2021-06-20 11:34:17 --> Model "Hospital_model" initialized
INFO - 2021-06-20 11:34:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-20 11:34:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:18 --> Config Class Initialized
INFO - 2021-06-20 11:34:18 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:18 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:18 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:18 --> URI Class Initialized
INFO - 2021-06-20 11:34:18 --> Router Class Initialized
INFO - 2021-06-20 11:34:18 --> Output Class Initialized
INFO - 2021-06-20 11:34:18 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:18 --> Input Class Initialized
INFO - 2021-06-20 11:34:18 --> Language Class Initialized
ERROR - 2021-06-20 11:34:18 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-20 11:34:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:18 --> Config Class Initialized
INFO - 2021-06-20 11:34:18 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:18 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:18 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:18 --> URI Class Initialized
INFO - 2021-06-20 11:34:18 --> Router Class Initialized
INFO - 2021-06-20 11:34:18 --> Output Class Initialized
INFO - 2021-06-20 11:34:18 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:18 --> Input Class Initialized
INFO - 2021-06-20 11:34:18 --> Language Class Initialized
ERROR - 2021-06-20 11:34:18 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-20 11:34:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:18 --> Config Class Initialized
INFO - 2021-06-20 11:34:18 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:18 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:18 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:18 --> URI Class Initialized
INFO - 2021-06-20 11:34:18 --> Router Class Initialized
INFO - 2021-06-20 11:34:18 --> Output Class Initialized
INFO - 2021-06-20 11:34:18 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:18 --> Input Class Initialized
INFO - 2021-06-20 11:34:18 --> Language Class Initialized
ERROR - 2021-06-20 11:34:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-20 11:34:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:18 --> Config Class Initialized
INFO - 2021-06-20 11:34:18 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:18 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:18 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:18 --> URI Class Initialized
INFO - 2021-06-20 11:34:18 --> Router Class Initialized
INFO - 2021-06-20 11:34:18 --> Output Class Initialized
INFO - 2021-06-20 11:34:18 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:18 --> Input Class Initialized
INFO - 2021-06-20 11:34:18 --> Language Class Initialized
ERROR - 2021-06-20 11:34:18 --> 404 Page Not Found: Karoclient/images
INFO - 2021-06-20 11:34:18 --> Final output sent to browser
DEBUG - 2021-06-20 11:34:18 --> Total execution time: 1.0247
ERROR - 2021-06-20 11:34:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:25 --> Config Class Initialized
INFO - 2021-06-20 11:34:25 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:25 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:25 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:25 --> URI Class Initialized
INFO - 2021-06-20 11:34:25 --> Router Class Initialized
INFO - 2021-06-20 11:34:25 --> Output Class Initialized
INFO - 2021-06-20 11:34:25 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:25 --> Input Class Initialized
INFO - 2021-06-20 11:34:25 --> Language Class Initialized
INFO - 2021-06-20 11:34:25 --> Loader Class Initialized
INFO - 2021-06-20 11:34:25 --> Helper loaded: url_helper
INFO - 2021-06-20 11:34:25 --> Helper loaded: form_helper
INFO - 2021-06-20 11:34:25 --> Helper loaded: common_helper
INFO - 2021-06-20 11:34:25 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:34:25 --> Controller Class Initialized
INFO - 2021-06-20 11:34:25 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:34:25 --> Encrypt Class Initialized
INFO - 2021-06-20 11:34:25 --> Model "Patient_model" initialized
INFO - 2021-06-20 11:34:25 --> Model "Patientcase_model" initialized
INFO - 2021-06-20 11:34:25 --> Model "Prefix_master" initialized
INFO - 2021-06-20 11:34:25 --> Model "Users_model" initialized
INFO - 2021-06-20 11:34:25 --> Model "Hospital_model" initialized
INFO - 2021-06-20 11:34:25 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-20 11:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:26 --> Config Class Initialized
INFO - 2021-06-20 11:34:26 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:26 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:26 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:26 --> URI Class Initialized
INFO - 2021-06-20 11:34:26 --> Router Class Initialized
INFO - 2021-06-20 11:34:26 --> Output Class Initialized
INFO - 2021-06-20 11:34:26 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:26 --> Input Class Initialized
INFO - 2021-06-20 11:34:26 --> Language Class Initialized
ERROR - 2021-06-20 11:34:26 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-20 11:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:26 --> Config Class Initialized
INFO - 2021-06-20 11:34:26 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:26 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:26 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:26 --> URI Class Initialized
INFO - 2021-06-20 11:34:26 --> Router Class Initialized
INFO - 2021-06-20 11:34:26 --> Output Class Initialized
INFO - 2021-06-20 11:34:26 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:26 --> Input Class Initialized
INFO - 2021-06-20 11:34:26 --> Language Class Initialized
ERROR - 2021-06-20 11:34:26 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-20 11:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:26 --> Config Class Initialized
INFO - 2021-06-20 11:34:26 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:26 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:26 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:26 --> URI Class Initialized
INFO - 2021-06-20 11:34:26 --> Router Class Initialized
INFO - 2021-06-20 11:34:26 --> Output Class Initialized
INFO - 2021-06-20 11:34:26 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:26 --> Input Class Initialized
INFO - 2021-06-20 11:34:26 --> Language Class Initialized
ERROR - 2021-06-20 11:34:26 --> 404 Page Not Found: Karoclient/images
INFO - 2021-06-20 11:34:26 --> Final output sent to browser
DEBUG - 2021-06-20 11:34:26 --> Total execution time: 1.0285
ERROR - 2021-06-20 11:34:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:27 --> Config Class Initialized
INFO - 2021-06-20 11:34:27 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:27 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:27 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:27 --> URI Class Initialized
INFO - 2021-06-20 11:34:27 --> Router Class Initialized
INFO - 2021-06-20 11:34:27 --> Output Class Initialized
INFO - 2021-06-20 11:34:27 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:27 --> Input Class Initialized
INFO - 2021-06-20 11:34:27 --> Language Class Initialized
INFO - 2021-06-20 11:34:27 --> Loader Class Initialized
INFO - 2021-06-20 11:34:27 --> Helper loaded: url_helper
INFO - 2021-06-20 11:34:27 --> Helper loaded: form_helper
INFO - 2021-06-20 11:34:27 --> Helper loaded: common_helper
INFO - 2021-06-20 11:34:27 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:34:27 --> Controller Class Initialized
INFO - 2021-06-20 11:34:27 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:34:27 --> Encrypt Class Initialized
INFO - 2021-06-20 11:34:27 --> Model "Patient_model" initialized
INFO - 2021-06-20 11:34:27 --> Model "Patientcase_model" initialized
INFO - 2021-06-20 11:34:27 --> Model "Prefix_master" initialized
INFO - 2021-06-20 11:34:27 --> Model "Users_model" initialized
INFO - 2021-06-20 11:34:27 --> Model "Hospital_model" initialized
INFO - 2021-06-20 11:34:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-20 11:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:28 --> Config Class Initialized
INFO - 2021-06-20 11:34:28 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:28 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:28 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:28 --> URI Class Initialized
INFO - 2021-06-20 11:34:28 --> Router Class Initialized
INFO - 2021-06-20 11:34:28 --> Output Class Initialized
INFO - 2021-06-20 11:34:28 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:28 --> Input Class Initialized
INFO - 2021-06-20 11:34:28 --> Language Class Initialized
ERROR - 2021-06-20 11:34:28 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-20 11:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:28 --> Config Class Initialized
INFO - 2021-06-20 11:34:28 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:28 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:28 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:28 --> URI Class Initialized
INFO - 2021-06-20 11:34:28 --> Router Class Initialized
INFO - 2021-06-20 11:34:28 --> Output Class Initialized
INFO - 2021-06-20 11:34:28 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:28 --> Input Class Initialized
INFO - 2021-06-20 11:34:28 --> Language Class Initialized
ERROR - 2021-06-20 11:34:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-20 11:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:28 --> Config Class Initialized
INFO - 2021-06-20 11:34:28 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:28 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:28 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:28 --> URI Class Initialized
INFO - 2021-06-20 11:34:28 --> Router Class Initialized
INFO - 2021-06-20 11:34:28 --> Output Class Initialized
INFO - 2021-06-20 11:34:28 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:28 --> Input Class Initialized
INFO - 2021-06-20 11:34:28 --> Language Class Initialized
ERROR - 2021-06-20 11:34:28 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-20 11:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:28 --> Config Class Initialized
INFO - 2021-06-20 11:34:28 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:28 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:28 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:28 --> URI Class Initialized
INFO - 2021-06-20 11:34:28 --> Router Class Initialized
INFO - 2021-06-20 11:34:28 --> Output Class Initialized
INFO - 2021-06-20 11:34:28 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:28 --> Input Class Initialized
INFO - 2021-06-20 11:34:28 --> Language Class Initialized
ERROR - 2021-06-20 11:34:28 --> 404 Page Not Found: Karoclient/images
INFO - 2021-06-20 11:34:28 --> Final output sent to browser
DEBUG - 2021-06-20 11:34:28 --> Total execution time: 1.0381
ERROR - 2021-06-20 11:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:39 --> Config Class Initialized
INFO - 2021-06-20 11:34:39 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:39 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:39 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:39 --> URI Class Initialized
INFO - 2021-06-20 11:34:39 --> Router Class Initialized
INFO - 2021-06-20 11:34:39 --> Output Class Initialized
INFO - 2021-06-20 11:34:39 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:39 --> Input Class Initialized
INFO - 2021-06-20 11:34:39 --> Language Class Initialized
INFO - 2021-06-20 11:34:39 --> Loader Class Initialized
INFO - 2021-06-20 11:34:39 --> Helper loaded: url_helper
INFO - 2021-06-20 11:34:39 --> Helper loaded: form_helper
INFO - 2021-06-20 11:34:39 --> Helper loaded: common_helper
INFO - 2021-06-20 11:34:39 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:34:39 --> Controller Class Initialized
INFO - 2021-06-20 11:34:39 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:34:39 --> Encrypt Class Initialized
INFO - 2021-06-20 11:34:39 --> Model "Referredby_model" initialized
INFO - 2021-06-20 11:34:39 --> Model "Users_model" initialized
INFO - 2021-06-20 11:34:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-20 11:34:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-20 11:34:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-20 11:34:39 --> Final output sent to browser
DEBUG - 2021-06-20 11:34:39 --> Total execution time: 0.0214
ERROR - 2021-06-20 11:34:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:40 --> Config Class Initialized
INFO - 2021-06-20 11:34:40 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:40 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:40 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:40 --> URI Class Initialized
INFO - 2021-06-20 11:34:40 --> Router Class Initialized
INFO - 2021-06-20 11:34:40 --> Output Class Initialized
INFO - 2021-06-20 11:34:40 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:40 --> Input Class Initialized
INFO - 2021-06-20 11:34:40 --> Language Class Initialized
ERROR - 2021-06-20 11:34:40 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-20 11:34:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:46 --> Config Class Initialized
INFO - 2021-06-20 11:34:46 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:46 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:46 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:46 --> URI Class Initialized
INFO - 2021-06-20 11:34:46 --> Router Class Initialized
INFO - 2021-06-20 11:34:46 --> Output Class Initialized
INFO - 2021-06-20 11:34:46 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:46 --> Input Class Initialized
INFO - 2021-06-20 11:34:46 --> Language Class Initialized
INFO - 2021-06-20 11:34:46 --> Loader Class Initialized
INFO - 2021-06-20 11:34:46 --> Helper loaded: url_helper
INFO - 2021-06-20 11:34:46 --> Helper loaded: form_helper
INFO - 2021-06-20 11:34:46 --> Helper loaded: common_helper
INFO - 2021-06-20 11:34:46 --> Database Driver Class Initialized
DEBUG - 2021-06-20 11:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 11:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 11:34:46 --> Controller Class Initialized
INFO - 2021-06-20 11:34:46 --> Form Validation Class Initialized
DEBUG - 2021-06-20 11:34:46 --> Encrypt Class Initialized
INFO - 2021-06-20 11:34:46 --> Model "Referredby_model" initialized
INFO - 2021-06-20 11:34:46 --> Model "Users_model" initialized
INFO - 2021-06-20 11:34:46 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-20 11:34:46 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-20 11:34:46 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-20 11:34:46 --> Final output sent to browser
DEBUG - 2021-06-20 11:34:46 --> Total execution time: 0.0198
ERROR - 2021-06-20 11:34:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 11:34:47 --> Config Class Initialized
INFO - 2021-06-20 11:34:47 --> Hooks Class Initialized
DEBUG - 2021-06-20 11:34:47 --> UTF-8 Support Enabled
INFO - 2021-06-20 11:34:47 --> Utf8 Class Initialized
INFO - 2021-06-20 11:34:47 --> URI Class Initialized
INFO - 2021-06-20 11:34:47 --> Router Class Initialized
INFO - 2021-06-20 11:34:47 --> Output Class Initialized
INFO - 2021-06-20 11:34:47 --> Security Class Initialized
DEBUG - 2021-06-20 11:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 11:34:47 --> Input Class Initialized
INFO - 2021-06-20 11:34:47 --> Language Class Initialized
ERROR - 2021-06-20 11:34:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-20 12:11:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-20 12:11:28 --> Config Class Initialized
INFO - 2021-06-20 12:11:28 --> Hooks Class Initialized
DEBUG - 2021-06-20 12:11:28 --> UTF-8 Support Enabled
INFO - 2021-06-20 12:11:28 --> Utf8 Class Initialized
INFO - 2021-06-20 12:11:28 --> URI Class Initialized
DEBUG - 2021-06-20 12:11:28 --> No URI present. Default controller set.
INFO - 2021-06-20 12:11:28 --> Router Class Initialized
INFO - 2021-06-20 12:11:28 --> Output Class Initialized
INFO - 2021-06-20 12:11:28 --> Security Class Initialized
DEBUG - 2021-06-20 12:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-20 12:11:28 --> Input Class Initialized
INFO - 2021-06-20 12:11:28 --> Language Class Initialized
INFO - 2021-06-20 12:11:28 --> Loader Class Initialized
INFO - 2021-06-20 12:11:28 --> Helper loaded: url_helper
INFO - 2021-06-20 12:11:28 --> Helper loaded: form_helper
INFO - 2021-06-20 12:11:28 --> Helper loaded: common_helper
INFO - 2021-06-20 12:11:28 --> Database Driver Class Initialized
DEBUG - 2021-06-20 12:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-20 12:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-20 12:11:28 --> Controller Class Initialized
INFO - 2021-06-20 12:11:28 --> Form Validation Class Initialized
DEBUG - 2021-06-20 12:11:28 --> Encrypt Class Initialized
DEBUG - 2021-06-20 12:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-20 12:11:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-20 12:11:28 --> Email Class Initialized
INFO - 2021-06-20 12:11:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-20 12:11:28 --> Calendar Class Initialized
INFO - 2021-06-20 12:11:28 --> Model "Login_model" initialized
INFO - 2021-06-20 12:11:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-20 12:11:28 --> Final output sent to browser
DEBUG - 2021-06-20 12:11:28 --> Total execution time: 0.0261
