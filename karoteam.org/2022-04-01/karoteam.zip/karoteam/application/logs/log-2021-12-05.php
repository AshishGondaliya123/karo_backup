<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-05 00:32:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 00:32:23 --> Config Class Initialized
INFO - 2021-12-05 00:32:23 --> Hooks Class Initialized
DEBUG - 2021-12-05 00:32:23 --> UTF-8 Support Enabled
INFO - 2021-12-05 00:32:23 --> Utf8 Class Initialized
INFO - 2021-12-05 00:32:23 --> URI Class Initialized
DEBUG - 2021-12-05 00:32:23 --> No URI present. Default controller set.
INFO - 2021-12-05 00:32:23 --> Router Class Initialized
INFO - 2021-12-05 00:32:23 --> Output Class Initialized
INFO - 2021-12-05 00:32:23 --> Security Class Initialized
DEBUG - 2021-12-05 00:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 00:32:23 --> Input Class Initialized
INFO - 2021-12-05 00:32:23 --> Language Class Initialized
INFO - 2021-12-05 00:32:23 --> Loader Class Initialized
INFO - 2021-12-05 00:32:23 --> Helper loaded: url_helper
INFO - 2021-12-05 00:32:23 --> Helper loaded: form_helper
INFO - 2021-12-05 00:32:23 --> Helper loaded: common_helper
INFO - 2021-12-05 00:32:23 --> Database Driver Class Initialized
DEBUG - 2021-12-05 00:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 00:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 00:32:23 --> Controller Class Initialized
INFO - 2021-12-05 00:32:23 --> Form Validation Class Initialized
DEBUG - 2021-12-05 00:32:23 --> Encrypt Class Initialized
DEBUG - 2021-12-05 00:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 00:32:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 00:32:23 --> Email Class Initialized
INFO - 2021-12-05 00:32:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 00:32:23 --> Calendar Class Initialized
INFO - 2021-12-05 00:32:23 --> Model "Login_model" initialized
INFO - 2021-12-05 00:32:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 00:32:23 --> Final output sent to browser
DEBUG - 2021-12-05 00:32:23 --> Total execution time: 0.0255
ERROR - 2021-12-05 01:16:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 01:16:57 --> Config Class Initialized
INFO - 2021-12-05 01:16:57 --> Hooks Class Initialized
DEBUG - 2021-12-05 01:16:57 --> UTF-8 Support Enabled
INFO - 2021-12-05 01:16:57 --> Utf8 Class Initialized
INFO - 2021-12-05 01:16:57 --> URI Class Initialized
DEBUG - 2021-12-05 01:16:57 --> No URI present. Default controller set.
INFO - 2021-12-05 01:16:57 --> Router Class Initialized
INFO - 2021-12-05 01:16:57 --> Output Class Initialized
INFO - 2021-12-05 01:16:57 --> Security Class Initialized
DEBUG - 2021-12-05 01:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 01:16:57 --> Input Class Initialized
INFO - 2021-12-05 01:16:57 --> Language Class Initialized
INFO - 2021-12-05 01:16:57 --> Loader Class Initialized
INFO - 2021-12-05 01:16:57 --> Helper loaded: url_helper
INFO - 2021-12-05 01:16:57 --> Helper loaded: form_helper
INFO - 2021-12-05 01:16:57 --> Helper loaded: common_helper
INFO - 2021-12-05 01:16:57 --> Database Driver Class Initialized
DEBUG - 2021-12-05 01:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 01:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 01:16:57 --> Controller Class Initialized
INFO - 2021-12-05 01:16:57 --> Form Validation Class Initialized
DEBUG - 2021-12-05 01:16:57 --> Encrypt Class Initialized
DEBUG - 2021-12-05 01:16:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 01:16:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 01:16:57 --> Email Class Initialized
INFO - 2021-12-05 01:16:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 01:16:57 --> Calendar Class Initialized
INFO - 2021-12-05 01:16:57 --> Model "Login_model" initialized
INFO - 2021-12-05 01:16:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 01:16:57 --> Final output sent to browser
DEBUG - 2021-12-05 01:16:57 --> Total execution time: 0.0223
ERROR - 2021-12-05 03:03:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 03:03:34 --> Config Class Initialized
INFO - 2021-12-05 03:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-05 03:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-05 03:03:34 --> Utf8 Class Initialized
INFO - 2021-12-05 03:03:34 --> URI Class Initialized
DEBUG - 2021-12-05 03:03:34 --> No URI present. Default controller set.
INFO - 2021-12-05 03:03:34 --> Router Class Initialized
INFO - 2021-12-05 03:03:34 --> Output Class Initialized
INFO - 2021-12-05 03:03:34 --> Security Class Initialized
DEBUG - 2021-12-05 03:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 03:03:34 --> Input Class Initialized
INFO - 2021-12-05 03:03:34 --> Language Class Initialized
INFO - 2021-12-05 03:03:34 --> Loader Class Initialized
INFO - 2021-12-05 03:03:34 --> Helper loaded: url_helper
INFO - 2021-12-05 03:03:34 --> Helper loaded: form_helper
INFO - 2021-12-05 03:03:34 --> Helper loaded: common_helper
INFO - 2021-12-05 03:03:34 --> Database Driver Class Initialized
DEBUG - 2021-12-05 03:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 03:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 03:03:34 --> Controller Class Initialized
INFO - 2021-12-05 03:03:34 --> Form Validation Class Initialized
DEBUG - 2021-12-05 03:03:34 --> Encrypt Class Initialized
DEBUG - 2021-12-05 03:03:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 03:03:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 03:03:34 --> Email Class Initialized
INFO - 2021-12-05 03:03:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 03:03:34 --> Calendar Class Initialized
INFO - 2021-12-05 03:03:34 --> Model "Login_model" initialized
INFO - 2021-12-05 03:03:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 03:03:34 --> Final output sent to browser
DEBUG - 2021-12-05 03:03:34 --> Total execution time: 0.0232
ERROR - 2021-12-05 06:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 06:23:35 --> Config Class Initialized
INFO - 2021-12-05 06:23:35 --> Hooks Class Initialized
DEBUG - 2021-12-05 06:23:35 --> UTF-8 Support Enabled
INFO - 2021-12-05 06:23:35 --> Utf8 Class Initialized
INFO - 2021-12-05 06:23:35 --> URI Class Initialized
DEBUG - 2021-12-05 06:23:35 --> No URI present. Default controller set.
INFO - 2021-12-05 06:23:35 --> Router Class Initialized
INFO - 2021-12-05 06:23:35 --> Output Class Initialized
INFO - 2021-12-05 06:23:35 --> Security Class Initialized
DEBUG - 2021-12-05 06:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 06:23:35 --> Input Class Initialized
INFO - 2021-12-05 06:23:35 --> Language Class Initialized
INFO - 2021-12-05 06:23:35 --> Loader Class Initialized
INFO - 2021-12-05 06:23:35 --> Helper loaded: url_helper
INFO - 2021-12-05 06:23:35 --> Helper loaded: form_helper
INFO - 2021-12-05 06:23:35 --> Helper loaded: common_helper
INFO - 2021-12-05 06:23:35 --> Database Driver Class Initialized
DEBUG - 2021-12-05 06:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 06:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 06:23:35 --> Controller Class Initialized
INFO - 2021-12-05 06:23:35 --> Form Validation Class Initialized
DEBUG - 2021-12-05 06:23:35 --> Encrypt Class Initialized
DEBUG - 2021-12-05 06:23:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 06:23:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 06:23:35 --> Email Class Initialized
INFO - 2021-12-05 06:23:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 06:23:35 --> Calendar Class Initialized
INFO - 2021-12-05 06:23:35 --> Model "Login_model" initialized
INFO - 2021-12-05 06:23:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 06:23:35 --> Final output sent to browser
DEBUG - 2021-12-05 06:23:35 --> Total execution time: 0.0217
ERROR - 2021-12-05 09:44:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 09:44:38 --> Config Class Initialized
INFO - 2021-12-05 09:44:38 --> Hooks Class Initialized
DEBUG - 2021-12-05 09:44:38 --> UTF-8 Support Enabled
INFO - 2021-12-05 09:44:38 --> Utf8 Class Initialized
INFO - 2021-12-05 09:44:38 --> URI Class Initialized
DEBUG - 2021-12-05 09:44:38 --> No URI present. Default controller set.
INFO - 2021-12-05 09:44:38 --> Router Class Initialized
INFO - 2021-12-05 09:44:38 --> Output Class Initialized
INFO - 2021-12-05 09:44:38 --> Security Class Initialized
DEBUG - 2021-12-05 09:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 09:44:38 --> Input Class Initialized
INFO - 2021-12-05 09:44:38 --> Language Class Initialized
INFO - 2021-12-05 09:44:38 --> Loader Class Initialized
INFO - 2021-12-05 09:44:38 --> Helper loaded: url_helper
INFO - 2021-12-05 09:44:38 --> Helper loaded: form_helper
INFO - 2021-12-05 09:44:38 --> Helper loaded: common_helper
INFO - 2021-12-05 09:44:38 --> Database Driver Class Initialized
DEBUG - 2021-12-05 09:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 09:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 09:44:38 --> Controller Class Initialized
INFO - 2021-12-05 09:44:38 --> Form Validation Class Initialized
DEBUG - 2021-12-05 09:44:38 --> Encrypt Class Initialized
DEBUG - 2021-12-05 09:44:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 09:44:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 09:44:38 --> Email Class Initialized
INFO - 2021-12-05 09:44:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 09:44:38 --> Calendar Class Initialized
INFO - 2021-12-05 09:44:38 --> Model "Login_model" initialized
INFO - 2021-12-05 09:44:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 09:44:38 --> Final output sent to browser
DEBUG - 2021-12-05 09:44:38 --> Total execution time: 0.0295
ERROR - 2021-12-05 10:12:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 10:12:37 --> Config Class Initialized
INFO - 2021-12-05 10:12:37 --> Hooks Class Initialized
DEBUG - 2021-12-05 10:12:37 --> UTF-8 Support Enabled
INFO - 2021-12-05 10:12:37 --> Utf8 Class Initialized
INFO - 2021-12-05 10:12:37 --> URI Class Initialized
DEBUG - 2021-12-05 10:12:37 --> No URI present. Default controller set.
INFO - 2021-12-05 10:12:37 --> Router Class Initialized
INFO - 2021-12-05 10:12:37 --> Output Class Initialized
INFO - 2021-12-05 10:12:37 --> Security Class Initialized
DEBUG - 2021-12-05 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 10:12:37 --> Input Class Initialized
INFO - 2021-12-05 10:12:37 --> Language Class Initialized
INFO - 2021-12-05 10:12:37 --> Loader Class Initialized
INFO - 2021-12-05 10:12:37 --> Helper loaded: url_helper
INFO - 2021-12-05 10:12:37 --> Helper loaded: form_helper
INFO - 2021-12-05 10:12:37 --> Helper loaded: common_helper
INFO - 2021-12-05 10:12:37 --> Database Driver Class Initialized
DEBUG - 2021-12-05 10:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 10:12:37 --> Controller Class Initialized
INFO - 2021-12-05 10:12:37 --> Form Validation Class Initialized
DEBUG - 2021-12-05 10:12:37 --> Encrypt Class Initialized
DEBUG - 2021-12-05 10:12:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 10:12:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 10:12:37 --> Email Class Initialized
INFO - 2021-12-05 10:12:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 10:12:37 --> Calendar Class Initialized
INFO - 2021-12-05 10:12:37 --> Model "Login_model" initialized
INFO - 2021-12-05 10:12:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 10:12:37 --> Final output sent to browser
DEBUG - 2021-12-05 10:12:37 --> Total execution time: 0.0361
ERROR - 2021-12-05 10:12:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 10:12:51 --> Config Class Initialized
INFO - 2021-12-05 10:12:51 --> Hooks Class Initialized
DEBUG - 2021-12-05 10:12:51 --> UTF-8 Support Enabled
INFO - 2021-12-05 10:12:51 --> Utf8 Class Initialized
INFO - 2021-12-05 10:12:51 --> URI Class Initialized
DEBUG - 2021-12-05 10:12:51 --> No URI present. Default controller set.
INFO - 2021-12-05 10:12:51 --> Router Class Initialized
INFO - 2021-12-05 10:12:51 --> Output Class Initialized
INFO - 2021-12-05 10:12:51 --> Security Class Initialized
DEBUG - 2021-12-05 10:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 10:12:51 --> Input Class Initialized
INFO - 2021-12-05 10:12:51 --> Language Class Initialized
INFO - 2021-12-05 10:12:51 --> Loader Class Initialized
INFO - 2021-12-05 10:12:51 --> Helper loaded: url_helper
INFO - 2021-12-05 10:12:51 --> Helper loaded: form_helper
INFO - 2021-12-05 10:12:51 --> Helper loaded: common_helper
INFO - 2021-12-05 10:12:51 --> Database Driver Class Initialized
DEBUG - 2021-12-05 10:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 10:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 10:12:51 --> Controller Class Initialized
INFO - 2021-12-05 10:12:51 --> Form Validation Class Initialized
DEBUG - 2021-12-05 10:12:51 --> Encrypt Class Initialized
DEBUG - 2021-12-05 10:12:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 10:12:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 10:12:51 --> Email Class Initialized
INFO - 2021-12-05 10:12:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 10:12:51 --> Calendar Class Initialized
INFO - 2021-12-05 10:12:51 --> Model "Login_model" initialized
INFO - 2021-12-05 10:12:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 10:12:51 --> Final output sent to browser
DEBUG - 2021-12-05 10:12:51 --> Total execution time: 0.0231
ERROR - 2021-12-05 11:07:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 11:07:49 --> Config Class Initialized
INFO - 2021-12-05 11:07:49 --> Hooks Class Initialized
DEBUG - 2021-12-05 11:07:49 --> UTF-8 Support Enabled
INFO - 2021-12-05 11:07:49 --> Utf8 Class Initialized
INFO - 2021-12-05 11:07:49 --> URI Class Initialized
DEBUG - 2021-12-05 11:07:49 --> No URI present. Default controller set.
INFO - 2021-12-05 11:07:49 --> Router Class Initialized
INFO - 2021-12-05 11:07:49 --> Output Class Initialized
INFO - 2021-12-05 11:07:49 --> Security Class Initialized
DEBUG - 2021-12-05 11:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 11:07:49 --> Input Class Initialized
INFO - 2021-12-05 11:07:49 --> Language Class Initialized
INFO - 2021-12-05 11:07:49 --> Loader Class Initialized
INFO - 2021-12-05 11:07:49 --> Helper loaded: url_helper
INFO - 2021-12-05 11:07:49 --> Helper loaded: form_helper
INFO - 2021-12-05 11:07:49 --> Helper loaded: common_helper
INFO - 2021-12-05 11:07:49 --> Database Driver Class Initialized
DEBUG - 2021-12-05 11:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 11:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 11:07:49 --> Controller Class Initialized
INFO - 2021-12-05 11:07:49 --> Form Validation Class Initialized
DEBUG - 2021-12-05 11:07:49 --> Encrypt Class Initialized
DEBUG - 2021-12-05 11:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 11:07:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 11:07:49 --> Email Class Initialized
INFO - 2021-12-05 11:07:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 11:07:49 --> Calendar Class Initialized
INFO - 2021-12-05 11:07:49 --> Model "Login_model" initialized
INFO - 2021-12-05 11:07:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 11:07:49 --> Final output sent to browser
DEBUG - 2021-12-05 11:07:49 --> Total execution time: 0.0287
ERROR - 2021-12-05 11:39:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 11:39:49 --> Config Class Initialized
INFO - 2021-12-05 11:39:49 --> Hooks Class Initialized
DEBUG - 2021-12-05 11:39:49 --> UTF-8 Support Enabled
INFO - 2021-12-05 11:39:49 --> Utf8 Class Initialized
INFO - 2021-12-05 11:39:49 --> URI Class Initialized
DEBUG - 2021-12-05 11:39:49 --> No URI present. Default controller set.
INFO - 2021-12-05 11:39:49 --> Router Class Initialized
INFO - 2021-12-05 11:39:49 --> Output Class Initialized
INFO - 2021-12-05 11:39:49 --> Security Class Initialized
DEBUG - 2021-12-05 11:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 11:39:49 --> Input Class Initialized
INFO - 2021-12-05 11:39:49 --> Language Class Initialized
INFO - 2021-12-05 11:39:49 --> Loader Class Initialized
INFO - 2021-12-05 11:39:49 --> Helper loaded: url_helper
INFO - 2021-12-05 11:39:49 --> Helper loaded: form_helper
INFO - 2021-12-05 11:39:49 --> Helper loaded: common_helper
INFO - 2021-12-05 11:39:49 --> Database Driver Class Initialized
DEBUG - 2021-12-05 11:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 11:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 11:39:49 --> Controller Class Initialized
INFO - 2021-12-05 11:39:49 --> Form Validation Class Initialized
DEBUG - 2021-12-05 11:39:49 --> Encrypt Class Initialized
DEBUG - 2021-12-05 11:39:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 11:39:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 11:39:49 --> Email Class Initialized
INFO - 2021-12-05 11:39:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 11:39:49 --> Calendar Class Initialized
INFO - 2021-12-05 11:39:49 --> Model "Login_model" initialized
INFO - 2021-12-05 11:39:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 11:39:49 --> Final output sent to browser
DEBUG - 2021-12-05 11:39:49 --> Total execution time: 0.0242
ERROR - 2021-12-05 13:03:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 13:03:18 --> Config Class Initialized
INFO - 2021-12-05 13:03:18 --> Hooks Class Initialized
DEBUG - 2021-12-05 13:03:18 --> UTF-8 Support Enabled
INFO - 2021-12-05 13:03:18 --> Utf8 Class Initialized
INFO - 2021-12-05 13:03:18 --> URI Class Initialized
DEBUG - 2021-12-05 13:03:18 --> No URI present. Default controller set.
INFO - 2021-12-05 13:03:18 --> Router Class Initialized
INFO - 2021-12-05 13:03:18 --> Output Class Initialized
INFO - 2021-12-05 13:03:18 --> Security Class Initialized
DEBUG - 2021-12-05 13:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 13:03:18 --> Input Class Initialized
INFO - 2021-12-05 13:03:18 --> Language Class Initialized
INFO - 2021-12-05 13:03:18 --> Loader Class Initialized
INFO - 2021-12-05 13:03:18 --> Helper loaded: url_helper
INFO - 2021-12-05 13:03:18 --> Helper loaded: form_helper
INFO - 2021-12-05 13:03:18 --> Helper loaded: common_helper
INFO - 2021-12-05 13:03:18 --> Database Driver Class Initialized
DEBUG - 2021-12-05 13:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 13:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 13:03:18 --> Controller Class Initialized
INFO - 2021-12-05 13:03:18 --> Form Validation Class Initialized
DEBUG - 2021-12-05 13:03:18 --> Encrypt Class Initialized
DEBUG - 2021-12-05 13:03:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 13:03:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 13:03:18 --> Email Class Initialized
INFO - 2021-12-05 13:03:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 13:03:18 --> Calendar Class Initialized
INFO - 2021-12-05 13:03:18 --> Model "Login_model" initialized
INFO - 2021-12-05 13:03:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 13:03:18 --> Final output sent to browser
DEBUG - 2021-12-05 13:03:18 --> Total execution time: 0.0364
ERROR - 2021-12-05 14:18:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 14:18:17 --> Config Class Initialized
INFO - 2021-12-05 14:18:17 --> Hooks Class Initialized
DEBUG - 2021-12-05 14:18:17 --> UTF-8 Support Enabled
INFO - 2021-12-05 14:18:17 --> Utf8 Class Initialized
INFO - 2021-12-05 14:18:17 --> URI Class Initialized
DEBUG - 2021-12-05 14:18:17 --> No URI present. Default controller set.
INFO - 2021-12-05 14:18:17 --> Router Class Initialized
INFO - 2021-12-05 14:18:17 --> Output Class Initialized
INFO - 2021-12-05 14:18:17 --> Security Class Initialized
DEBUG - 2021-12-05 14:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 14:18:17 --> Input Class Initialized
INFO - 2021-12-05 14:18:17 --> Language Class Initialized
INFO - 2021-12-05 14:18:17 --> Loader Class Initialized
INFO - 2021-12-05 14:18:17 --> Helper loaded: url_helper
INFO - 2021-12-05 14:18:17 --> Helper loaded: form_helper
INFO - 2021-12-05 14:18:17 --> Helper loaded: common_helper
INFO - 2021-12-05 14:18:17 --> Database Driver Class Initialized
DEBUG - 2021-12-05 14:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 14:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 14:18:17 --> Controller Class Initialized
INFO - 2021-12-05 14:18:17 --> Form Validation Class Initialized
DEBUG - 2021-12-05 14:18:17 --> Encrypt Class Initialized
DEBUG - 2021-12-05 14:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 14:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 14:18:17 --> Email Class Initialized
INFO - 2021-12-05 14:18:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 14:18:17 --> Calendar Class Initialized
INFO - 2021-12-05 14:18:17 --> Model "Login_model" initialized
INFO - 2021-12-05 14:18:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 14:18:17 --> Final output sent to browser
DEBUG - 2021-12-05 14:18:17 --> Total execution time: 0.0364
ERROR - 2021-12-05 14:18:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 14:18:20 --> Config Class Initialized
INFO - 2021-12-05 14:18:20 --> Hooks Class Initialized
DEBUG - 2021-12-05 14:18:20 --> UTF-8 Support Enabled
INFO - 2021-12-05 14:18:20 --> Utf8 Class Initialized
INFO - 2021-12-05 14:18:20 --> URI Class Initialized
INFO - 2021-12-05 14:18:20 --> Router Class Initialized
INFO - 2021-12-05 14:18:20 --> Output Class Initialized
INFO - 2021-12-05 14:18:20 --> Security Class Initialized
DEBUG - 2021-12-05 14:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 14:18:20 --> Input Class Initialized
INFO - 2021-12-05 14:18:20 --> Language Class Initialized
ERROR - 2021-12-05 14:18:20 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-05 14:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 14:18:42 --> Config Class Initialized
INFO - 2021-12-05 14:18:42 --> Hooks Class Initialized
DEBUG - 2021-12-05 14:18:42 --> UTF-8 Support Enabled
INFO - 2021-12-05 14:18:42 --> Utf8 Class Initialized
INFO - 2021-12-05 14:18:42 --> URI Class Initialized
INFO - 2021-12-05 14:18:42 --> Router Class Initialized
INFO - 2021-12-05 14:18:42 --> Output Class Initialized
INFO - 2021-12-05 14:18:42 --> Security Class Initialized
DEBUG - 2021-12-05 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 14:18:42 --> Input Class Initialized
INFO - 2021-12-05 14:18:42 --> Language Class Initialized
INFO - 2021-12-05 14:18:42 --> Loader Class Initialized
INFO - 2021-12-05 14:18:42 --> Helper loaded: url_helper
INFO - 2021-12-05 14:18:42 --> Helper loaded: form_helper
INFO - 2021-12-05 14:18:42 --> Helper loaded: common_helper
INFO - 2021-12-05 14:18:42 --> Database Driver Class Initialized
DEBUG - 2021-12-05 14:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 14:18:42 --> Controller Class Initialized
INFO - 2021-12-05 14:18:42 --> Form Validation Class Initialized
DEBUG - 2021-12-05 14:18:42 --> Encrypt Class Initialized
DEBUG - 2021-12-05 14:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 14:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 14:18:42 --> Email Class Initialized
INFO - 2021-12-05 14:18:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 14:18:42 --> Calendar Class Initialized
INFO - 2021-12-05 14:18:42 --> Model "Login_model" initialized
INFO - 2021-12-05 14:18:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 14:18:42 --> Final output sent to browser
DEBUG - 2021-12-05 14:18:42 --> Total execution time: 0.0219
ERROR - 2021-12-05 14:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 14:18:42 --> Config Class Initialized
INFO - 2021-12-05 14:18:42 --> Hooks Class Initialized
DEBUG - 2021-12-05 14:18:42 --> UTF-8 Support Enabled
INFO - 2021-12-05 14:18:42 --> Utf8 Class Initialized
INFO - 2021-12-05 14:18:42 --> URI Class Initialized
INFO - 2021-12-05 14:18:42 --> Router Class Initialized
INFO - 2021-12-05 14:18:42 --> Output Class Initialized
INFO - 2021-12-05 14:18:42 --> Security Class Initialized
DEBUG - 2021-12-05 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 14:18:42 --> Input Class Initialized
INFO - 2021-12-05 14:18:42 --> Language Class Initialized
INFO - 2021-12-05 14:18:42 --> Loader Class Initialized
INFO - 2021-12-05 14:18:42 --> Helper loaded: url_helper
INFO - 2021-12-05 14:18:42 --> Helper loaded: form_helper
INFO - 2021-12-05 14:18:42 --> Helper loaded: common_helper
INFO - 2021-12-05 14:18:43 --> Database Driver Class Initialized
DEBUG - 2021-12-05 14:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 14:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 14:18:43 --> Controller Class Initialized
INFO - 2021-12-05 14:18:43 --> Form Validation Class Initialized
DEBUG - 2021-12-05 14:18:43 --> Encrypt Class Initialized
DEBUG - 2021-12-05 14:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 14:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 14:18:43 --> Email Class Initialized
INFO - 2021-12-05 14:18:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 14:18:43 --> Calendar Class Initialized
INFO - 2021-12-05 14:18:43 --> Model "Login_model" initialized
ERROR - 2021-12-05 14:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 14:18:43 --> Config Class Initialized
INFO - 2021-12-05 14:18:43 --> Hooks Class Initialized
DEBUG - 2021-12-05 14:18:43 --> UTF-8 Support Enabled
INFO - 2021-12-05 14:18:43 --> Utf8 Class Initialized
INFO - 2021-12-05 14:18:43 --> URI Class Initialized
INFO - 2021-12-05 14:18:43 --> Router Class Initialized
INFO - 2021-12-05 14:18:43 --> Output Class Initialized
INFO - 2021-12-05 14:18:43 --> Security Class Initialized
DEBUG - 2021-12-05 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 14:18:43 --> Input Class Initialized
INFO - 2021-12-05 14:18:43 --> Language Class Initialized
INFO - 2021-12-05 14:18:43 --> Loader Class Initialized
INFO - 2021-12-05 14:18:43 --> Helper loaded: url_helper
INFO - 2021-12-05 14:18:43 --> Helper loaded: form_helper
INFO - 2021-12-05 14:18:43 --> Helper loaded: common_helper
INFO - 2021-12-05 14:18:43 --> Database Driver Class Initialized
DEBUG - 2021-12-05 14:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 14:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 14:18:43 --> Controller Class Initialized
INFO - 2021-12-05 14:18:43 --> Form Validation Class Initialized
DEBUG - 2021-12-05 14:18:43 --> Encrypt Class Initialized
DEBUG - 2021-12-05 14:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 14:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 14:18:43 --> Email Class Initialized
INFO - 2021-12-05 14:18:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 14:18:43 --> Calendar Class Initialized
INFO - 2021-12-05 14:18:43 --> Model "Login_model" initialized
ERROR - 2021-12-05 14:18:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 14:18:44 --> Config Class Initialized
INFO - 2021-12-05 14:18:44 --> Hooks Class Initialized
DEBUG - 2021-12-05 14:18:44 --> UTF-8 Support Enabled
INFO - 2021-12-05 14:18:44 --> Utf8 Class Initialized
INFO - 2021-12-05 14:18:44 --> URI Class Initialized
DEBUG - 2021-12-05 14:18:44 --> No URI present. Default controller set.
INFO - 2021-12-05 14:18:44 --> Router Class Initialized
INFO - 2021-12-05 14:18:44 --> Output Class Initialized
INFO - 2021-12-05 14:18:44 --> Security Class Initialized
DEBUG - 2021-12-05 14:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 14:18:44 --> Input Class Initialized
INFO - 2021-12-05 14:18:44 --> Language Class Initialized
INFO - 2021-12-05 14:18:44 --> Loader Class Initialized
INFO - 2021-12-05 14:18:44 --> Helper loaded: url_helper
INFO - 2021-12-05 14:18:44 --> Helper loaded: form_helper
INFO - 2021-12-05 14:18:44 --> Helper loaded: common_helper
INFO - 2021-12-05 14:18:44 --> Database Driver Class Initialized
DEBUG - 2021-12-05 14:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 14:18:44 --> Controller Class Initialized
INFO - 2021-12-05 14:18:44 --> Form Validation Class Initialized
DEBUG - 2021-12-05 14:18:44 --> Encrypt Class Initialized
DEBUG - 2021-12-05 14:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 14:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 14:18:44 --> Email Class Initialized
INFO - 2021-12-05 14:18:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 14:18:44 --> Calendar Class Initialized
INFO - 2021-12-05 14:18:44 --> Model "Login_model" initialized
INFO - 2021-12-05 14:18:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 14:18:44 --> Final output sent to browser
DEBUG - 2021-12-05 14:18:44 --> Total execution time: 0.0230
ERROR - 2021-12-05 16:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 16:23:15 --> Config Class Initialized
INFO - 2021-12-05 16:23:15 --> Hooks Class Initialized
DEBUG - 2021-12-05 16:23:15 --> UTF-8 Support Enabled
INFO - 2021-12-05 16:23:15 --> Utf8 Class Initialized
INFO - 2021-12-05 16:23:15 --> URI Class Initialized
DEBUG - 2021-12-05 16:23:15 --> No URI present. Default controller set.
INFO - 2021-12-05 16:23:15 --> Router Class Initialized
INFO - 2021-12-05 16:23:15 --> Output Class Initialized
INFO - 2021-12-05 16:23:15 --> Security Class Initialized
DEBUG - 2021-12-05 16:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 16:23:15 --> Input Class Initialized
INFO - 2021-12-05 16:23:15 --> Language Class Initialized
INFO - 2021-12-05 16:23:15 --> Loader Class Initialized
INFO - 2021-12-05 16:23:15 --> Helper loaded: url_helper
INFO - 2021-12-05 16:23:15 --> Helper loaded: form_helper
INFO - 2021-12-05 16:23:15 --> Helper loaded: common_helper
INFO - 2021-12-05 16:23:15 --> Database Driver Class Initialized
DEBUG - 2021-12-05 16:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 16:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 16:23:15 --> Controller Class Initialized
INFO - 2021-12-05 16:23:15 --> Form Validation Class Initialized
DEBUG - 2021-12-05 16:23:15 --> Encrypt Class Initialized
DEBUG - 2021-12-05 16:23:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 16:23:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 16:23:15 --> Email Class Initialized
INFO - 2021-12-05 16:23:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 16:23:15 --> Calendar Class Initialized
INFO - 2021-12-05 16:23:15 --> Model "Login_model" initialized
INFO - 2021-12-05 16:23:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 16:23:15 --> Final output sent to browser
DEBUG - 2021-12-05 16:23:15 --> Total execution time: 0.0295
ERROR - 2021-12-05 16:49:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 16:49:44 --> Config Class Initialized
INFO - 2021-12-05 16:49:44 --> Hooks Class Initialized
DEBUG - 2021-12-05 16:49:44 --> UTF-8 Support Enabled
INFO - 2021-12-05 16:49:44 --> Utf8 Class Initialized
INFO - 2021-12-05 16:49:44 --> URI Class Initialized
DEBUG - 2021-12-05 16:49:44 --> No URI present. Default controller set.
INFO - 2021-12-05 16:49:44 --> Router Class Initialized
INFO - 2021-12-05 16:49:44 --> Output Class Initialized
INFO - 2021-12-05 16:49:44 --> Security Class Initialized
DEBUG - 2021-12-05 16:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 16:49:44 --> Input Class Initialized
INFO - 2021-12-05 16:49:44 --> Language Class Initialized
INFO - 2021-12-05 16:49:44 --> Loader Class Initialized
INFO - 2021-12-05 16:49:44 --> Helper loaded: url_helper
INFO - 2021-12-05 16:49:44 --> Helper loaded: form_helper
INFO - 2021-12-05 16:49:44 --> Helper loaded: common_helper
INFO - 2021-12-05 16:49:44 --> Database Driver Class Initialized
DEBUG - 2021-12-05 16:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 16:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 16:49:44 --> Controller Class Initialized
INFO - 2021-12-05 16:49:44 --> Form Validation Class Initialized
DEBUG - 2021-12-05 16:49:44 --> Encrypt Class Initialized
DEBUG - 2021-12-05 16:49:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 16:49:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 16:49:44 --> Email Class Initialized
INFO - 2021-12-05 16:49:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 16:49:44 --> Calendar Class Initialized
INFO - 2021-12-05 16:49:44 --> Model "Login_model" initialized
INFO - 2021-12-05 16:49:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 16:49:44 --> Final output sent to browser
DEBUG - 2021-12-05 16:49:44 --> Total execution time: 0.0239
ERROR - 2021-12-05 20:23:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 20:23:30 --> Config Class Initialized
INFO - 2021-12-05 20:23:30 --> Hooks Class Initialized
DEBUG - 2021-12-05 20:23:30 --> UTF-8 Support Enabled
INFO - 2021-12-05 20:23:30 --> Utf8 Class Initialized
INFO - 2021-12-05 20:23:30 --> URI Class Initialized
DEBUG - 2021-12-05 20:23:30 --> No URI present. Default controller set.
INFO - 2021-12-05 20:23:30 --> Router Class Initialized
INFO - 2021-12-05 20:23:30 --> Output Class Initialized
INFO - 2021-12-05 20:23:30 --> Security Class Initialized
DEBUG - 2021-12-05 20:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 20:23:30 --> Input Class Initialized
INFO - 2021-12-05 20:23:30 --> Language Class Initialized
INFO - 2021-12-05 20:23:30 --> Loader Class Initialized
INFO - 2021-12-05 20:23:30 --> Helper loaded: url_helper
INFO - 2021-12-05 20:23:30 --> Helper loaded: form_helper
INFO - 2021-12-05 20:23:30 --> Helper loaded: common_helper
INFO - 2021-12-05 20:23:30 --> Database Driver Class Initialized
DEBUG - 2021-12-05 20:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 20:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 20:23:30 --> Controller Class Initialized
INFO - 2021-12-05 20:23:30 --> Form Validation Class Initialized
DEBUG - 2021-12-05 20:23:30 --> Encrypt Class Initialized
DEBUG - 2021-12-05 20:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 20:23:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 20:23:30 --> Email Class Initialized
INFO - 2021-12-05 20:23:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 20:23:30 --> Calendar Class Initialized
INFO - 2021-12-05 20:23:30 --> Model "Login_model" initialized
INFO - 2021-12-05 20:23:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 20:23:30 --> Final output sent to browser
DEBUG - 2021-12-05 20:23:30 --> Total execution time: 0.0659
ERROR - 2021-12-05 21:02:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 21:02:48 --> Config Class Initialized
INFO - 2021-12-05 21:02:48 --> Hooks Class Initialized
DEBUG - 2021-12-05 21:02:48 --> UTF-8 Support Enabled
INFO - 2021-12-05 21:02:48 --> Utf8 Class Initialized
INFO - 2021-12-05 21:02:48 --> URI Class Initialized
DEBUG - 2021-12-05 21:02:48 --> No URI present. Default controller set.
INFO - 2021-12-05 21:02:48 --> Router Class Initialized
INFO - 2021-12-05 21:02:48 --> Output Class Initialized
INFO - 2021-12-05 21:02:48 --> Security Class Initialized
DEBUG - 2021-12-05 21:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 21:02:48 --> Input Class Initialized
INFO - 2021-12-05 21:02:48 --> Language Class Initialized
INFO - 2021-12-05 21:02:48 --> Loader Class Initialized
INFO - 2021-12-05 21:02:48 --> Helper loaded: url_helper
INFO - 2021-12-05 21:02:48 --> Helper loaded: form_helper
INFO - 2021-12-05 21:02:48 --> Helper loaded: common_helper
INFO - 2021-12-05 21:02:48 --> Database Driver Class Initialized
DEBUG - 2021-12-05 21:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 21:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 21:02:48 --> Controller Class Initialized
INFO - 2021-12-05 21:02:48 --> Form Validation Class Initialized
DEBUG - 2021-12-05 21:02:48 --> Encrypt Class Initialized
DEBUG - 2021-12-05 21:02:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 21:02:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 21:02:48 --> Email Class Initialized
INFO - 2021-12-05 21:02:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 21:02:48 --> Calendar Class Initialized
INFO - 2021-12-05 21:02:48 --> Model "Login_model" initialized
INFO - 2021-12-05 21:02:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 21:02:48 --> Final output sent to browser
DEBUG - 2021-12-05 21:02:48 --> Total execution time: 0.0385
ERROR - 2021-12-05 21:18:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 21:18:50 --> Config Class Initialized
INFO - 2021-12-05 21:18:50 --> Hooks Class Initialized
DEBUG - 2021-12-05 21:18:50 --> UTF-8 Support Enabled
INFO - 2021-12-05 21:18:50 --> Utf8 Class Initialized
INFO - 2021-12-05 21:18:50 --> URI Class Initialized
DEBUG - 2021-12-05 21:18:50 --> No URI present. Default controller set.
INFO - 2021-12-05 21:18:50 --> Router Class Initialized
INFO - 2021-12-05 21:18:50 --> Output Class Initialized
INFO - 2021-12-05 21:18:50 --> Security Class Initialized
DEBUG - 2021-12-05 21:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 21:18:50 --> Input Class Initialized
INFO - 2021-12-05 21:18:50 --> Language Class Initialized
INFO - 2021-12-05 21:18:50 --> Loader Class Initialized
INFO - 2021-12-05 21:18:50 --> Helper loaded: url_helper
INFO - 2021-12-05 21:18:50 --> Helper loaded: form_helper
INFO - 2021-12-05 21:18:50 --> Helper loaded: common_helper
INFO - 2021-12-05 21:18:50 --> Database Driver Class Initialized
DEBUG - 2021-12-05 21:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 21:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 21:18:50 --> Controller Class Initialized
INFO - 2021-12-05 21:18:50 --> Form Validation Class Initialized
DEBUG - 2021-12-05 21:18:50 --> Encrypt Class Initialized
DEBUG - 2021-12-05 21:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 21:18:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 21:18:50 --> Email Class Initialized
INFO - 2021-12-05 21:18:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 21:18:50 --> Calendar Class Initialized
INFO - 2021-12-05 21:18:50 --> Model "Login_model" initialized
INFO - 2021-12-05 21:18:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 21:18:50 --> Final output sent to browser
DEBUG - 2021-12-05 21:18:50 --> Total execution time: 0.0350
ERROR - 2021-12-05 21:24:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 21:24:13 --> Config Class Initialized
INFO - 2021-12-05 21:24:13 --> Hooks Class Initialized
DEBUG - 2021-12-05 21:24:13 --> UTF-8 Support Enabled
INFO - 2021-12-05 21:24:13 --> Utf8 Class Initialized
INFO - 2021-12-05 21:24:13 --> URI Class Initialized
DEBUG - 2021-12-05 21:24:13 --> No URI present. Default controller set.
INFO - 2021-12-05 21:24:13 --> Router Class Initialized
INFO - 2021-12-05 21:24:13 --> Output Class Initialized
INFO - 2021-12-05 21:24:13 --> Security Class Initialized
DEBUG - 2021-12-05 21:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 21:24:13 --> Input Class Initialized
INFO - 2021-12-05 21:24:13 --> Language Class Initialized
INFO - 2021-12-05 21:24:13 --> Loader Class Initialized
INFO - 2021-12-05 21:24:13 --> Helper loaded: url_helper
INFO - 2021-12-05 21:24:13 --> Helper loaded: form_helper
INFO - 2021-12-05 21:24:13 --> Helper loaded: common_helper
INFO - 2021-12-05 21:24:13 --> Database Driver Class Initialized
DEBUG - 2021-12-05 21:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 21:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 21:24:13 --> Controller Class Initialized
INFO - 2021-12-05 21:24:13 --> Form Validation Class Initialized
DEBUG - 2021-12-05 21:24:13 --> Encrypt Class Initialized
DEBUG - 2021-12-05 21:24:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 21:24:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 21:24:13 --> Email Class Initialized
INFO - 2021-12-05 21:24:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 21:24:13 --> Calendar Class Initialized
INFO - 2021-12-05 21:24:13 --> Model "Login_model" initialized
INFO - 2021-12-05 21:24:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 21:24:13 --> Final output sent to browser
DEBUG - 2021-12-05 21:24:13 --> Total execution time: 0.4460
ERROR - 2021-12-05 23:42:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-05 23:42:04 --> Config Class Initialized
INFO - 2021-12-05 23:42:04 --> Hooks Class Initialized
DEBUG - 2021-12-05 23:42:04 --> UTF-8 Support Enabled
INFO - 2021-12-05 23:42:04 --> Utf8 Class Initialized
INFO - 2021-12-05 23:42:04 --> URI Class Initialized
DEBUG - 2021-12-05 23:42:04 --> No URI present. Default controller set.
INFO - 2021-12-05 23:42:04 --> Router Class Initialized
INFO - 2021-12-05 23:42:04 --> Output Class Initialized
INFO - 2021-12-05 23:42:04 --> Security Class Initialized
DEBUG - 2021-12-05 23:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-05 23:42:04 --> Input Class Initialized
INFO - 2021-12-05 23:42:04 --> Language Class Initialized
INFO - 2021-12-05 23:42:04 --> Loader Class Initialized
INFO - 2021-12-05 23:42:04 --> Helper loaded: url_helper
INFO - 2021-12-05 23:42:04 --> Helper loaded: form_helper
INFO - 2021-12-05 23:42:04 --> Helper loaded: common_helper
INFO - 2021-12-05 23:42:04 --> Database Driver Class Initialized
DEBUG - 2021-12-05 23:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-05 23:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-05 23:42:04 --> Controller Class Initialized
INFO - 2021-12-05 23:42:04 --> Form Validation Class Initialized
DEBUG - 2021-12-05 23:42:04 --> Encrypt Class Initialized
DEBUG - 2021-12-05 23:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-05 23:42:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-05 23:42:04 --> Email Class Initialized
INFO - 2021-12-05 23:42:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-05 23:42:04 --> Calendar Class Initialized
INFO - 2021-12-05 23:42:04 --> Model "Login_model" initialized
INFO - 2021-12-05 23:42:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-05 23:42:04 --> Final output sent to browser
DEBUG - 2021-12-05 23:42:04 --> Total execution time: 0.0248
