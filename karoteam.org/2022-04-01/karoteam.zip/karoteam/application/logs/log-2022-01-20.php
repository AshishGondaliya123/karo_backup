<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-20 03:07:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 03:07:15 --> Config Class Initialized
INFO - 2022-01-20 03:07:15 --> Hooks Class Initialized
DEBUG - 2022-01-20 03:07:15 --> UTF-8 Support Enabled
INFO - 2022-01-20 03:07:15 --> Utf8 Class Initialized
INFO - 2022-01-20 03:07:15 --> URI Class Initialized
DEBUG - 2022-01-20 03:07:15 --> No URI present. Default controller set.
INFO - 2022-01-20 03:07:15 --> Router Class Initialized
INFO - 2022-01-20 03:07:15 --> Output Class Initialized
INFO - 2022-01-20 03:07:15 --> Security Class Initialized
DEBUG - 2022-01-20 03:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 03:07:15 --> Input Class Initialized
INFO - 2022-01-20 03:07:15 --> Language Class Initialized
INFO - 2022-01-20 03:07:15 --> Loader Class Initialized
INFO - 2022-01-20 03:07:15 --> Helper loaded: url_helper
INFO - 2022-01-20 03:07:15 --> Helper loaded: form_helper
INFO - 2022-01-20 03:07:15 --> Helper loaded: common_helper
INFO - 2022-01-20 03:07:15 --> Database Driver Class Initialized
DEBUG - 2022-01-20 03:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 03:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 03:07:15 --> Controller Class Initialized
INFO - 2022-01-20 03:07:15 --> Form Validation Class Initialized
DEBUG - 2022-01-20 03:07:15 --> Encrypt Class Initialized
DEBUG - 2022-01-20 03:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 03:07:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 03:07:15 --> Email Class Initialized
INFO - 2022-01-20 03:07:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 03:07:15 --> Calendar Class Initialized
INFO - 2022-01-20 03:07:15 --> Model "Login_model" initialized
INFO - 2022-01-20 03:07:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-20 03:07:15 --> Final output sent to browser
DEBUG - 2022-01-20 03:07:15 --> Total execution time: 0.0525
ERROR - 2022-01-20 04:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 04:05:01 --> Config Class Initialized
INFO - 2022-01-20 04:05:01 --> Hooks Class Initialized
DEBUG - 2022-01-20 04:05:01 --> UTF-8 Support Enabled
INFO - 2022-01-20 04:05:01 --> Utf8 Class Initialized
INFO - 2022-01-20 04:05:01 --> URI Class Initialized
DEBUG - 2022-01-20 04:05:01 --> No URI present. Default controller set.
INFO - 2022-01-20 04:05:01 --> Router Class Initialized
INFO - 2022-01-20 04:05:01 --> Output Class Initialized
INFO - 2022-01-20 04:05:01 --> Security Class Initialized
DEBUG - 2022-01-20 04:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 04:05:01 --> Input Class Initialized
INFO - 2022-01-20 04:05:01 --> Language Class Initialized
INFO - 2022-01-20 04:05:01 --> Loader Class Initialized
INFO - 2022-01-20 04:05:01 --> Helper loaded: url_helper
INFO - 2022-01-20 04:05:01 --> Helper loaded: form_helper
INFO - 2022-01-20 04:05:01 --> Helper loaded: common_helper
INFO - 2022-01-20 04:05:01 --> Database Driver Class Initialized
DEBUG - 2022-01-20 04:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 04:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 04:05:01 --> Controller Class Initialized
INFO - 2022-01-20 04:05:01 --> Form Validation Class Initialized
DEBUG - 2022-01-20 04:05:01 --> Encrypt Class Initialized
DEBUG - 2022-01-20 04:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 04:05:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 04:05:01 --> Email Class Initialized
INFO - 2022-01-20 04:05:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 04:05:01 --> Calendar Class Initialized
INFO - 2022-01-20 04:05:01 --> Model "Login_model" initialized
INFO - 2022-01-20 04:05:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-20 04:05:01 --> Final output sent to browser
DEBUG - 2022-01-20 04:05:01 --> Total execution time: 0.0221
ERROR - 2022-01-20 07:37:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 07:37:41 --> Config Class Initialized
INFO - 2022-01-20 07:37:41 --> Hooks Class Initialized
DEBUG - 2022-01-20 07:37:41 --> UTF-8 Support Enabled
INFO - 2022-01-20 07:37:41 --> Utf8 Class Initialized
INFO - 2022-01-20 07:37:41 --> URI Class Initialized
DEBUG - 2022-01-20 07:37:41 --> No URI present. Default controller set.
INFO - 2022-01-20 07:37:41 --> Router Class Initialized
INFO - 2022-01-20 07:37:41 --> Output Class Initialized
INFO - 2022-01-20 07:37:41 --> Security Class Initialized
DEBUG - 2022-01-20 07:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 07:37:41 --> Input Class Initialized
INFO - 2022-01-20 07:37:41 --> Language Class Initialized
INFO - 2022-01-20 07:37:41 --> Loader Class Initialized
INFO - 2022-01-20 07:37:41 --> Helper loaded: url_helper
INFO - 2022-01-20 07:37:41 --> Helper loaded: form_helper
INFO - 2022-01-20 07:37:41 --> Helper loaded: common_helper
INFO - 2022-01-20 07:37:41 --> Database Driver Class Initialized
DEBUG - 2022-01-20 07:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 07:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 07:37:41 --> Controller Class Initialized
INFO - 2022-01-20 07:37:41 --> Form Validation Class Initialized
DEBUG - 2022-01-20 07:37:41 --> Encrypt Class Initialized
DEBUG - 2022-01-20 07:37:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 07:37:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 07:37:41 --> Email Class Initialized
INFO - 2022-01-20 07:37:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 07:37:41 --> Calendar Class Initialized
INFO - 2022-01-20 07:37:41 --> Model "Login_model" initialized
INFO - 2022-01-20 07:37:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-20 07:37:41 --> Final output sent to browser
DEBUG - 2022-01-20 07:37:41 --> Total execution time: 0.0221
ERROR - 2022-01-20 14:09:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 14:09:57 --> Config Class Initialized
INFO - 2022-01-20 14:09:57 --> Hooks Class Initialized
DEBUG - 2022-01-20 14:09:57 --> UTF-8 Support Enabled
INFO - 2022-01-20 14:09:57 --> Utf8 Class Initialized
INFO - 2022-01-20 14:09:57 --> URI Class Initialized
INFO - 2022-01-20 14:09:57 --> Router Class Initialized
INFO - 2022-01-20 14:09:57 --> Output Class Initialized
INFO - 2022-01-20 14:09:57 --> Security Class Initialized
DEBUG - 2022-01-20 14:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 14:09:57 --> Input Class Initialized
INFO - 2022-01-20 14:09:57 --> Language Class Initialized
ERROR - 2022-01-20 14:09:57 --> 404 Page Not Found: Git/config
ERROR - 2022-01-20 14:17:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 14:17:53 --> Config Class Initialized
INFO - 2022-01-20 14:17:53 --> Hooks Class Initialized
DEBUG - 2022-01-20 14:17:53 --> UTF-8 Support Enabled
INFO - 2022-01-20 14:17:53 --> Utf8 Class Initialized
INFO - 2022-01-20 14:17:53 --> URI Class Initialized
DEBUG - 2022-01-20 14:17:53 --> No URI present. Default controller set.
INFO - 2022-01-20 14:17:53 --> Router Class Initialized
INFO - 2022-01-20 14:17:53 --> Output Class Initialized
INFO - 2022-01-20 14:17:53 --> Security Class Initialized
DEBUG - 2022-01-20 14:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 14:17:53 --> Input Class Initialized
INFO - 2022-01-20 14:17:53 --> Language Class Initialized
INFO - 2022-01-20 14:17:53 --> Loader Class Initialized
INFO - 2022-01-20 14:17:53 --> Helper loaded: url_helper
INFO - 2022-01-20 14:17:53 --> Helper loaded: form_helper
INFO - 2022-01-20 14:17:53 --> Helper loaded: common_helper
INFO - 2022-01-20 14:17:53 --> Database Driver Class Initialized
DEBUG - 2022-01-20 14:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 14:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 14:17:53 --> Controller Class Initialized
INFO - 2022-01-20 14:17:53 --> Form Validation Class Initialized
DEBUG - 2022-01-20 14:17:53 --> Encrypt Class Initialized
DEBUG - 2022-01-20 14:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:17:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 14:17:53 --> Email Class Initialized
INFO - 2022-01-20 14:17:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 14:17:53 --> Calendar Class Initialized
INFO - 2022-01-20 14:17:53 --> Model "Login_model" initialized
INFO - 2022-01-20 14:17:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-20 14:17:53 --> Final output sent to browser
DEBUG - 2022-01-20 14:17:53 --> Total execution time: 0.0284
ERROR - 2022-01-20 14:17:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 14:17:55 --> Config Class Initialized
INFO - 2022-01-20 14:17:55 --> Hooks Class Initialized
DEBUG - 2022-01-20 14:17:55 --> UTF-8 Support Enabled
INFO - 2022-01-20 14:17:55 --> Utf8 Class Initialized
INFO - 2022-01-20 14:17:55 --> URI Class Initialized
INFO - 2022-01-20 14:17:55 --> Router Class Initialized
INFO - 2022-01-20 14:17:55 --> Output Class Initialized
INFO - 2022-01-20 14:17:55 --> Security Class Initialized
DEBUG - 2022-01-20 14:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 14:17:55 --> Input Class Initialized
INFO - 2022-01-20 14:17:55 --> Language Class Initialized
ERROR - 2022-01-20 14:17:55 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-20 14:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 14:18:15 --> Config Class Initialized
INFO - 2022-01-20 14:18:15 --> Hooks Class Initialized
DEBUG - 2022-01-20 14:18:15 --> UTF-8 Support Enabled
INFO - 2022-01-20 14:18:15 --> Utf8 Class Initialized
INFO - 2022-01-20 14:18:15 --> URI Class Initialized
DEBUG - 2022-01-20 14:18:15 --> No URI present. Default controller set.
INFO - 2022-01-20 14:18:15 --> Router Class Initialized
INFO - 2022-01-20 14:18:15 --> Output Class Initialized
INFO - 2022-01-20 14:18:15 --> Security Class Initialized
DEBUG - 2022-01-20 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 14:18:15 --> Input Class Initialized
INFO - 2022-01-20 14:18:15 --> Language Class Initialized
INFO - 2022-01-20 14:18:15 --> Loader Class Initialized
INFO - 2022-01-20 14:18:15 --> Helper loaded: url_helper
INFO - 2022-01-20 14:18:15 --> Helper loaded: form_helper
INFO - 2022-01-20 14:18:15 --> Helper loaded: common_helper
INFO - 2022-01-20 14:18:15 --> Database Driver Class Initialized
DEBUG - 2022-01-20 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 14:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 14:18:15 --> Controller Class Initialized
INFO - 2022-01-20 14:18:15 --> Form Validation Class Initialized
DEBUG - 2022-01-20 14:18:15 --> Encrypt Class Initialized
DEBUG - 2022-01-20 14:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 14:18:15 --> Email Class Initialized
INFO - 2022-01-20 14:18:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 14:18:15 --> Calendar Class Initialized
INFO - 2022-01-20 14:18:15 --> Model "Login_model" initialized
INFO - 2022-01-20 14:18:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-20 14:18:15 --> Final output sent to browser
DEBUG - 2022-01-20 14:18:15 --> Total execution time: 0.0236
ERROR - 2022-01-20 14:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 14:18:16 --> Config Class Initialized
INFO - 2022-01-20 14:18:16 --> Hooks Class Initialized
DEBUG - 2022-01-20 14:18:16 --> UTF-8 Support Enabled
INFO - 2022-01-20 14:18:16 --> Utf8 Class Initialized
INFO - 2022-01-20 14:18:16 --> URI Class Initialized
INFO - 2022-01-20 14:18:16 --> Router Class Initialized
INFO - 2022-01-20 14:18:16 --> Output Class Initialized
INFO - 2022-01-20 14:18:16 --> Security Class Initialized
DEBUG - 2022-01-20 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 14:18:16 --> Input Class Initialized
INFO - 2022-01-20 14:18:16 --> Language Class Initialized
INFO - 2022-01-20 14:18:16 --> Loader Class Initialized
INFO - 2022-01-20 14:18:16 --> Helper loaded: url_helper
INFO - 2022-01-20 14:18:16 --> Helper loaded: form_helper
INFO - 2022-01-20 14:18:16 --> Helper loaded: common_helper
INFO - 2022-01-20 14:18:16 --> Database Driver Class Initialized
DEBUG - 2022-01-20 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 14:18:16 --> Controller Class Initialized
INFO - 2022-01-20 14:18:16 --> Form Validation Class Initialized
DEBUG - 2022-01-20 14:18:16 --> Encrypt Class Initialized
DEBUG - 2022-01-20 14:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 14:18:16 --> Email Class Initialized
INFO - 2022-01-20 14:18:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 14:18:16 --> Calendar Class Initialized
INFO - 2022-01-20 14:18:16 --> Model "Login_model" initialized
ERROR - 2022-01-20 14:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 14:18:16 --> Config Class Initialized
INFO - 2022-01-20 14:18:16 --> Hooks Class Initialized
DEBUG - 2022-01-20 14:18:16 --> UTF-8 Support Enabled
INFO - 2022-01-20 14:18:16 --> Utf8 Class Initialized
INFO - 2022-01-20 14:18:16 --> URI Class Initialized
INFO - 2022-01-20 14:18:16 --> Router Class Initialized
INFO - 2022-01-20 14:18:16 --> Output Class Initialized
INFO - 2022-01-20 14:18:16 --> Security Class Initialized
DEBUG - 2022-01-20 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 14:18:16 --> Input Class Initialized
INFO - 2022-01-20 14:18:16 --> Language Class Initialized
INFO - 2022-01-20 14:18:16 --> Loader Class Initialized
INFO - 2022-01-20 14:18:16 --> Helper loaded: url_helper
INFO - 2022-01-20 14:18:16 --> Helper loaded: form_helper
INFO - 2022-01-20 14:18:16 --> Helper loaded: common_helper
INFO - 2022-01-20 14:18:16 --> Database Driver Class Initialized
DEBUG - 2022-01-20 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 14:18:16 --> Controller Class Initialized
INFO - 2022-01-20 14:18:16 --> Form Validation Class Initialized
DEBUG - 2022-01-20 14:18:16 --> Encrypt Class Initialized
DEBUG - 2022-01-20 14:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 14:18:16 --> Email Class Initialized
INFO - 2022-01-20 14:18:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 14:18:16 --> Calendar Class Initialized
INFO - 2022-01-20 14:18:16 --> Model "Login_model" initialized
ERROR - 2022-01-20 14:18:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 14:18:17 --> Config Class Initialized
INFO - 2022-01-20 14:18:17 --> Hooks Class Initialized
DEBUG - 2022-01-20 14:18:17 --> UTF-8 Support Enabled
INFO - 2022-01-20 14:18:17 --> Utf8 Class Initialized
INFO - 2022-01-20 14:18:17 --> URI Class Initialized
INFO - 2022-01-20 14:18:17 --> Router Class Initialized
INFO - 2022-01-20 14:18:17 --> Output Class Initialized
INFO - 2022-01-20 14:18:17 --> Security Class Initialized
DEBUG - 2022-01-20 14:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 14:18:17 --> Input Class Initialized
INFO - 2022-01-20 14:18:17 --> Language Class Initialized
INFO - 2022-01-20 14:18:17 --> Loader Class Initialized
INFO - 2022-01-20 14:18:17 --> Helper loaded: url_helper
INFO - 2022-01-20 14:18:17 --> Helper loaded: form_helper
INFO - 2022-01-20 14:18:17 --> Helper loaded: common_helper
INFO - 2022-01-20 14:18:17 --> Database Driver Class Initialized
DEBUG - 2022-01-20 14:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 14:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 14:18:17 --> Controller Class Initialized
INFO - 2022-01-20 14:18:17 --> Form Validation Class Initialized
DEBUG - 2022-01-20 14:18:17 --> Encrypt Class Initialized
DEBUG - 2022-01-20 14:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 14:18:17 --> Email Class Initialized
INFO - 2022-01-20 14:18:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 14:18:17 --> Calendar Class Initialized
INFO - 2022-01-20 14:18:17 --> Model "Login_model" initialized
INFO - 2022-01-20 14:18:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-20 14:18:17 --> Final output sent to browser
DEBUG - 2022-01-20 14:18:17 --> Total execution time: 0.0352
ERROR - 2022-01-20 15:15:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 15:15:46 --> Config Class Initialized
INFO - 2022-01-20 15:15:46 --> Hooks Class Initialized
DEBUG - 2022-01-20 15:15:46 --> UTF-8 Support Enabled
INFO - 2022-01-20 15:15:46 --> Utf8 Class Initialized
INFO - 2022-01-20 15:15:46 --> URI Class Initialized
DEBUG - 2022-01-20 15:15:46 --> No URI present. Default controller set.
INFO - 2022-01-20 15:15:46 --> Router Class Initialized
INFO - 2022-01-20 15:15:46 --> Output Class Initialized
INFO - 2022-01-20 15:15:46 --> Security Class Initialized
DEBUG - 2022-01-20 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 15:15:46 --> Input Class Initialized
INFO - 2022-01-20 15:15:46 --> Language Class Initialized
INFO - 2022-01-20 15:15:46 --> Loader Class Initialized
INFO - 2022-01-20 15:15:46 --> Helper loaded: url_helper
INFO - 2022-01-20 15:15:46 --> Helper loaded: form_helper
INFO - 2022-01-20 15:15:46 --> Helper loaded: common_helper
INFO - 2022-01-20 15:15:46 --> Database Driver Class Initialized
DEBUG - 2022-01-20 15:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 15:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 15:15:46 --> Controller Class Initialized
INFO - 2022-01-20 15:15:46 --> Form Validation Class Initialized
DEBUG - 2022-01-20 15:15:46 --> Encrypt Class Initialized
DEBUG - 2022-01-20 15:15:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:15:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 15:15:46 --> Email Class Initialized
INFO - 2022-01-20 15:15:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 15:15:46 --> Calendar Class Initialized
INFO - 2022-01-20 15:15:46 --> Model "Login_model" initialized
INFO - 2022-01-20 15:15:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-20 15:15:46 --> Final output sent to browser
DEBUG - 2022-01-20 15:15:46 --> Total execution time: 0.0250
ERROR - 2022-01-20 15:15:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 15:15:50 --> Config Class Initialized
INFO - 2022-01-20 15:15:50 --> Hooks Class Initialized
DEBUG - 2022-01-20 15:15:50 --> UTF-8 Support Enabled
INFO - 2022-01-20 15:15:50 --> Utf8 Class Initialized
INFO - 2022-01-20 15:15:50 --> URI Class Initialized
DEBUG - 2022-01-20 15:15:50 --> No URI present. Default controller set.
INFO - 2022-01-20 15:15:50 --> Router Class Initialized
INFO - 2022-01-20 15:15:50 --> Output Class Initialized
INFO - 2022-01-20 15:15:50 --> Security Class Initialized
DEBUG - 2022-01-20 15:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 15:15:50 --> Input Class Initialized
INFO - 2022-01-20 15:15:50 --> Language Class Initialized
INFO - 2022-01-20 15:15:50 --> Loader Class Initialized
INFO - 2022-01-20 15:15:50 --> Helper loaded: url_helper
INFO - 2022-01-20 15:15:50 --> Helper loaded: form_helper
INFO - 2022-01-20 15:15:50 --> Helper loaded: common_helper
INFO - 2022-01-20 15:15:50 --> Database Driver Class Initialized
DEBUG - 2022-01-20 15:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 15:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 15:15:50 --> Controller Class Initialized
INFO - 2022-01-20 15:15:50 --> Form Validation Class Initialized
DEBUG - 2022-01-20 15:15:50 --> Encrypt Class Initialized
DEBUG - 2022-01-20 15:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:15:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 15:15:50 --> Email Class Initialized
INFO - 2022-01-20 15:15:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 15:15:50 --> Calendar Class Initialized
INFO - 2022-01-20 15:15:50 --> Model "Login_model" initialized
INFO - 2022-01-20 15:15:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-20 15:15:50 --> Final output sent to browser
DEBUG - 2022-01-20 15:15:50 --> Total execution time: 0.0227
ERROR - 2022-01-20 21:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-20 21:54:46 --> Config Class Initialized
INFO - 2022-01-20 21:54:46 --> Hooks Class Initialized
DEBUG - 2022-01-20 21:54:46 --> UTF-8 Support Enabled
INFO - 2022-01-20 21:54:46 --> Utf8 Class Initialized
INFO - 2022-01-20 21:54:46 --> URI Class Initialized
DEBUG - 2022-01-20 21:54:46 --> No URI present. Default controller set.
INFO - 2022-01-20 21:54:46 --> Router Class Initialized
INFO - 2022-01-20 21:54:46 --> Output Class Initialized
INFO - 2022-01-20 21:54:46 --> Security Class Initialized
DEBUG - 2022-01-20 21:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-20 21:54:46 --> Input Class Initialized
INFO - 2022-01-20 21:54:46 --> Language Class Initialized
INFO - 2022-01-20 21:54:46 --> Loader Class Initialized
INFO - 2022-01-20 21:54:46 --> Helper loaded: url_helper
INFO - 2022-01-20 21:54:46 --> Helper loaded: form_helper
INFO - 2022-01-20 21:54:46 --> Helper loaded: common_helper
INFO - 2022-01-20 21:54:46 --> Database Driver Class Initialized
DEBUG - 2022-01-20 21:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-20 21:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-20 21:54:46 --> Controller Class Initialized
INFO - 2022-01-20 21:54:46 --> Form Validation Class Initialized
DEBUG - 2022-01-20 21:54:46 --> Encrypt Class Initialized
DEBUG - 2022-01-20 21:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 21:54:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-20 21:54:46 --> Email Class Initialized
INFO - 2022-01-20 21:54:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-20 21:54:46 --> Calendar Class Initialized
INFO - 2022-01-20 21:54:46 --> Model "Login_model" initialized
INFO - 2022-01-20 21:54:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-20 21:54:46 --> Final output sent to browser
DEBUG - 2022-01-20 21:54:46 --> Total execution time: 0.1615
