<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-18 00:28:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 00:28:10 --> Config Class Initialized
INFO - 2022-02-18 00:28:10 --> Hooks Class Initialized
DEBUG - 2022-02-18 00:28:10 --> UTF-8 Support Enabled
INFO - 2022-02-18 00:28:10 --> Utf8 Class Initialized
INFO - 2022-02-18 00:28:10 --> URI Class Initialized
DEBUG - 2022-02-18 00:28:10 --> No URI present. Default controller set.
INFO - 2022-02-18 00:28:10 --> Router Class Initialized
INFO - 2022-02-18 00:28:10 --> Output Class Initialized
INFO - 2022-02-18 00:28:10 --> Security Class Initialized
DEBUG - 2022-02-18 00:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 00:28:10 --> Input Class Initialized
INFO - 2022-02-18 00:28:10 --> Language Class Initialized
INFO - 2022-02-18 00:28:10 --> Loader Class Initialized
INFO - 2022-02-18 00:28:10 --> Helper loaded: url_helper
INFO - 2022-02-18 00:28:10 --> Helper loaded: form_helper
INFO - 2022-02-18 00:28:10 --> Helper loaded: common_helper
INFO - 2022-02-18 00:28:10 --> Database Driver Class Initialized
DEBUG - 2022-02-18 00:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 00:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 00:28:10 --> Controller Class Initialized
INFO - 2022-02-18 00:28:10 --> Form Validation Class Initialized
DEBUG - 2022-02-18 00:28:10 --> Encrypt Class Initialized
DEBUG - 2022-02-18 00:28:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 00:28:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 00:28:10 --> Email Class Initialized
INFO - 2022-02-18 00:28:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 00:28:10 --> Calendar Class Initialized
INFO - 2022-02-18 00:28:10 --> Model "Login_model" initialized
INFO - 2022-02-18 00:28:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-18 00:28:10 --> Final output sent to browser
DEBUG - 2022-02-18 00:28:10 --> Total execution time: 0.1820
ERROR - 2022-02-18 10:23:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 10:23:54 --> Config Class Initialized
INFO - 2022-02-18 10:23:54 --> Hooks Class Initialized
DEBUG - 2022-02-18 10:23:54 --> UTF-8 Support Enabled
INFO - 2022-02-18 10:23:54 --> Utf8 Class Initialized
INFO - 2022-02-18 10:23:54 --> URI Class Initialized
DEBUG - 2022-02-18 10:23:54 --> No URI present. Default controller set.
INFO - 2022-02-18 10:23:54 --> Router Class Initialized
INFO - 2022-02-18 10:23:54 --> Output Class Initialized
INFO - 2022-02-18 10:23:54 --> Security Class Initialized
DEBUG - 2022-02-18 10:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 10:23:54 --> Input Class Initialized
INFO - 2022-02-18 10:23:54 --> Language Class Initialized
INFO - 2022-02-18 10:23:54 --> Loader Class Initialized
INFO - 2022-02-18 10:23:54 --> Helper loaded: url_helper
INFO - 2022-02-18 10:23:54 --> Helper loaded: form_helper
INFO - 2022-02-18 10:23:54 --> Helper loaded: common_helper
INFO - 2022-02-18 10:23:54 --> Database Driver Class Initialized
DEBUG - 2022-02-18 10:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 10:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 10:23:54 --> Controller Class Initialized
INFO - 2022-02-18 10:23:54 --> Form Validation Class Initialized
DEBUG - 2022-02-18 10:23:54 --> Encrypt Class Initialized
DEBUG - 2022-02-18 10:23:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:23:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 10:23:54 --> Email Class Initialized
INFO - 2022-02-18 10:23:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 10:23:54 --> Calendar Class Initialized
INFO - 2022-02-18 10:23:54 --> Model "Login_model" initialized
INFO - 2022-02-18 10:23:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-18 10:23:54 --> Final output sent to browser
DEBUG - 2022-02-18 10:23:54 --> Total execution time: 0.0378
ERROR - 2022-02-18 12:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 12:26:28 --> Config Class Initialized
INFO - 2022-02-18 12:26:28 --> Hooks Class Initialized
DEBUG - 2022-02-18 12:26:28 --> UTF-8 Support Enabled
INFO - 2022-02-18 12:26:28 --> Utf8 Class Initialized
INFO - 2022-02-18 12:26:28 --> URI Class Initialized
DEBUG - 2022-02-18 12:26:28 --> No URI present. Default controller set.
INFO - 2022-02-18 12:26:28 --> Router Class Initialized
INFO - 2022-02-18 12:26:28 --> Output Class Initialized
INFO - 2022-02-18 12:26:28 --> Security Class Initialized
DEBUG - 2022-02-18 12:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 12:26:28 --> Input Class Initialized
INFO - 2022-02-18 12:26:28 --> Language Class Initialized
INFO - 2022-02-18 12:26:28 --> Loader Class Initialized
INFO - 2022-02-18 12:26:28 --> Helper loaded: url_helper
INFO - 2022-02-18 12:26:28 --> Helper loaded: form_helper
INFO - 2022-02-18 12:26:28 --> Helper loaded: common_helper
INFO - 2022-02-18 12:26:28 --> Database Driver Class Initialized
DEBUG - 2022-02-18 12:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 12:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 12:26:28 --> Controller Class Initialized
INFO - 2022-02-18 12:26:28 --> Form Validation Class Initialized
DEBUG - 2022-02-18 12:26:28 --> Encrypt Class Initialized
DEBUG - 2022-02-18 12:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 12:26:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 12:26:28 --> Email Class Initialized
INFO - 2022-02-18 12:26:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 12:26:28 --> Calendar Class Initialized
INFO - 2022-02-18 12:26:28 --> Model "Login_model" initialized
INFO - 2022-02-18 12:26:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-18 12:26:28 --> Final output sent to browser
DEBUG - 2022-02-18 12:26:28 --> Total execution time: 0.0422
ERROR - 2022-02-18 14:18:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 14:18:11 --> Config Class Initialized
INFO - 2022-02-18 14:18:11 --> Hooks Class Initialized
DEBUG - 2022-02-18 14:18:11 --> UTF-8 Support Enabled
INFO - 2022-02-18 14:18:11 --> Utf8 Class Initialized
INFO - 2022-02-18 14:18:11 --> URI Class Initialized
DEBUG - 2022-02-18 14:18:11 --> No URI present. Default controller set.
INFO - 2022-02-18 14:18:11 --> Router Class Initialized
INFO - 2022-02-18 14:18:11 --> Output Class Initialized
INFO - 2022-02-18 14:18:11 --> Security Class Initialized
DEBUG - 2022-02-18 14:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 14:18:11 --> Input Class Initialized
INFO - 2022-02-18 14:18:11 --> Language Class Initialized
INFO - 2022-02-18 14:18:11 --> Loader Class Initialized
INFO - 2022-02-18 14:18:11 --> Helper loaded: url_helper
INFO - 2022-02-18 14:18:11 --> Helper loaded: form_helper
INFO - 2022-02-18 14:18:11 --> Helper loaded: common_helper
INFO - 2022-02-18 14:18:11 --> Database Driver Class Initialized
DEBUG - 2022-02-18 14:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 14:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 14:18:11 --> Controller Class Initialized
INFO - 2022-02-18 14:18:11 --> Form Validation Class Initialized
DEBUG - 2022-02-18 14:18:11 --> Encrypt Class Initialized
DEBUG - 2022-02-18 14:18:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:18:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 14:18:11 --> Email Class Initialized
INFO - 2022-02-18 14:18:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 14:18:11 --> Calendar Class Initialized
INFO - 2022-02-18 14:18:11 --> Model "Login_model" initialized
INFO - 2022-02-18 14:18:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-18 14:18:11 --> Final output sent to browser
DEBUG - 2022-02-18 14:18:11 --> Total execution time: 0.0356
ERROR - 2022-02-18 14:18:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 14:18:11 --> Config Class Initialized
INFO - 2022-02-18 14:18:11 --> Hooks Class Initialized
DEBUG - 2022-02-18 14:18:11 --> UTF-8 Support Enabled
INFO - 2022-02-18 14:18:11 --> Utf8 Class Initialized
INFO - 2022-02-18 14:18:11 --> URI Class Initialized
INFO - 2022-02-18 14:18:11 --> Router Class Initialized
INFO - 2022-02-18 14:18:11 --> Output Class Initialized
INFO - 2022-02-18 14:18:11 --> Security Class Initialized
DEBUG - 2022-02-18 14:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 14:18:11 --> Input Class Initialized
INFO - 2022-02-18 14:18:11 --> Language Class Initialized
ERROR - 2022-02-18 14:18:11 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-18 14:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 14:18:21 --> Config Class Initialized
INFO - 2022-02-18 14:18:21 --> Hooks Class Initialized
DEBUG - 2022-02-18 14:18:21 --> UTF-8 Support Enabled
INFO - 2022-02-18 14:18:21 --> Utf8 Class Initialized
INFO - 2022-02-18 14:18:21 --> URI Class Initialized
INFO - 2022-02-18 14:18:21 --> Router Class Initialized
INFO - 2022-02-18 14:18:21 --> Output Class Initialized
INFO - 2022-02-18 14:18:21 --> Security Class Initialized
DEBUG - 2022-02-18 14:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 14:18:21 --> Input Class Initialized
INFO - 2022-02-18 14:18:21 --> Language Class Initialized
INFO - 2022-02-18 14:18:21 --> Loader Class Initialized
INFO - 2022-02-18 14:18:21 --> Helper loaded: url_helper
INFO - 2022-02-18 14:18:21 --> Helper loaded: form_helper
INFO - 2022-02-18 14:18:21 --> Helper loaded: common_helper
INFO - 2022-02-18 14:18:21 --> Database Driver Class Initialized
DEBUG - 2022-02-18 14:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 14:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 14:18:21 --> Controller Class Initialized
INFO - 2022-02-18 14:18:21 --> Form Validation Class Initialized
DEBUG - 2022-02-18 14:18:21 --> Encrypt Class Initialized
DEBUG - 2022-02-18 14:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:18:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 14:18:21 --> Email Class Initialized
INFO - 2022-02-18 14:18:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 14:18:21 --> Calendar Class Initialized
INFO - 2022-02-18 14:18:21 --> Model "Login_model" initialized
INFO - 2022-02-18 14:18:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-18 14:18:21 --> Final output sent to browser
DEBUG - 2022-02-18 14:18:21 --> Total execution time: 0.0336
ERROR - 2022-02-18 14:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 14:18:22 --> Config Class Initialized
INFO - 2022-02-18 14:18:22 --> Hooks Class Initialized
DEBUG - 2022-02-18 14:18:22 --> UTF-8 Support Enabled
INFO - 2022-02-18 14:18:22 --> Utf8 Class Initialized
INFO - 2022-02-18 14:18:22 --> URI Class Initialized
DEBUG - 2022-02-18 14:18:22 --> No URI present. Default controller set.
INFO - 2022-02-18 14:18:22 --> Router Class Initialized
INFO - 2022-02-18 14:18:22 --> Output Class Initialized
INFO - 2022-02-18 14:18:22 --> Security Class Initialized
DEBUG - 2022-02-18 14:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 14:18:22 --> Input Class Initialized
INFO - 2022-02-18 14:18:22 --> Language Class Initialized
INFO - 2022-02-18 14:18:22 --> Loader Class Initialized
INFO - 2022-02-18 14:18:22 --> Helper loaded: url_helper
INFO - 2022-02-18 14:18:22 --> Helper loaded: form_helper
INFO - 2022-02-18 14:18:22 --> Helper loaded: common_helper
INFO - 2022-02-18 14:18:22 --> Database Driver Class Initialized
DEBUG - 2022-02-18 14:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 14:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 14:18:22 --> Controller Class Initialized
INFO - 2022-02-18 14:18:22 --> Form Validation Class Initialized
DEBUG - 2022-02-18 14:18:22 --> Encrypt Class Initialized
DEBUG - 2022-02-18 14:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 14:18:22 --> Email Class Initialized
INFO - 2022-02-18 14:18:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 14:18:22 --> Calendar Class Initialized
INFO - 2022-02-18 14:18:22 --> Model "Login_model" initialized
INFO - 2022-02-18 14:18:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-18 14:18:22 --> Final output sent to browser
DEBUG - 2022-02-18 14:18:22 --> Total execution time: 0.0226
ERROR - 2022-02-18 14:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 14:18:22 --> Config Class Initialized
INFO - 2022-02-18 14:18:22 --> Hooks Class Initialized
DEBUG - 2022-02-18 14:18:22 --> UTF-8 Support Enabled
INFO - 2022-02-18 14:18:22 --> Utf8 Class Initialized
INFO - 2022-02-18 14:18:22 --> URI Class Initialized
INFO - 2022-02-18 14:18:22 --> Router Class Initialized
INFO - 2022-02-18 14:18:22 --> Output Class Initialized
INFO - 2022-02-18 14:18:22 --> Security Class Initialized
DEBUG - 2022-02-18 14:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 14:18:22 --> Input Class Initialized
INFO - 2022-02-18 14:18:22 --> Language Class Initialized
INFO - 2022-02-18 14:18:22 --> Loader Class Initialized
INFO - 2022-02-18 14:18:22 --> Helper loaded: url_helper
INFO - 2022-02-18 14:18:22 --> Helper loaded: form_helper
INFO - 2022-02-18 14:18:22 --> Helper loaded: common_helper
INFO - 2022-02-18 14:18:22 --> Database Driver Class Initialized
DEBUG - 2022-02-18 14:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 14:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 14:18:22 --> Controller Class Initialized
INFO - 2022-02-18 14:18:22 --> Form Validation Class Initialized
DEBUG - 2022-02-18 14:18:22 --> Encrypt Class Initialized
DEBUG - 2022-02-18 14:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 14:18:22 --> Email Class Initialized
INFO - 2022-02-18 14:18:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 14:18:22 --> Calendar Class Initialized
INFO - 2022-02-18 14:18:22 --> Model "Login_model" initialized
ERROR - 2022-02-18 14:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 14:18:23 --> Config Class Initialized
INFO - 2022-02-18 14:18:23 --> Hooks Class Initialized
DEBUG - 2022-02-18 14:18:23 --> UTF-8 Support Enabled
INFO - 2022-02-18 14:18:23 --> Utf8 Class Initialized
INFO - 2022-02-18 14:18:23 --> URI Class Initialized
INFO - 2022-02-18 14:18:23 --> Router Class Initialized
INFO - 2022-02-18 14:18:23 --> Output Class Initialized
INFO - 2022-02-18 14:18:23 --> Security Class Initialized
DEBUG - 2022-02-18 14:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 14:18:23 --> Input Class Initialized
INFO - 2022-02-18 14:18:23 --> Language Class Initialized
INFO - 2022-02-18 14:18:23 --> Loader Class Initialized
INFO - 2022-02-18 14:18:23 --> Helper loaded: url_helper
INFO - 2022-02-18 14:18:23 --> Helper loaded: form_helper
INFO - 2022-02-18 14:18:23 --> Helper loaded: common_helper
INFO - 2022-02-18 14:18:23 --> Database Driver Class Initialized
DEBUG - 2022-02-18 14:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 14:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 14:18:23 --> Controller Class Initialized
INFO - 2022-02-18 14:18:23 --> Form Validation Class Initialized
DEBUG - 2022-02-18 14:18:23 --> Encrypt Class Initialized
DEBUG - 2022-02-18 14:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:18:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 14:18:23 --> Email Class Initialized
INFO - 2022-02-18 14:18:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 14:18:23 --> Calendar Class Initialized
INFO - 2022-02-18 14:18:23 --> Model "Login_model" initialized
ERROR - 2022-02-18 15:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 15:35:39 --> Config Class Initialized
INFO - 2022-02-18 15:35:39 --> Hooks Class Initialized
DEBUG - 2022-02-18 15:35:39 --> UTF-8 Support Enabled
INFO - 2022-02-18 15:35:39 --> Utf8 Class Initialized
INFO - 2022-02-18 15:35:39 --> URI Class Initialized
DEBUG - 2022-02-18 15:35:39 --> No URI present. Default controller set.
INFO - 2022-02-18 15:35:39 --> Router Class Initialized
INFO - 2022-02-18 15:35:39 --> Output Class Initialized
INFO - 2022-02-18 15:35:39 --> Security Class Initialized
DEBUG - 2022-02-18 15:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 15:35:39 --> Input Class Initialized
INFO - 2022-02-18 15:35:39 --> Language Class Initialized
INFO - 2022-02-18 15:35:39 --> Loader Class Initialized
INFO - 2022-02-18 15:35:39 --> Helper loaded: url_helper
INFO - 2022-02-18 15:35:39 --> Helper loaded: form_helper
INFO - 2022-02-18 15:35:39 --> Helper loaded: common_helper
INFO - 2022-02-18 15:35:39 --> Database Driver Class Initialized
DEBUG - 2022-02-18 15:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 15:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 15:35:39 --> Controller Class Initialized
INFO - 2022-02-18 15:35:39 --> Form Validation Class Initialized
DEBUG - 2022-02-18 15:35:39 --> Encrypt Class Initialized
DEBUG - 2022-02-18 15:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:35:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 15:35:39 --> Email Class Initialized
INFO - 2022-02-18 15:35:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 15:35:39 --> Calendar Class Initialized
INFO - 2022-02-18 15:35:39 --> Model "Login_model" initialized
INFO - 2022-02-18 15:35:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-18 15:35:39 --> Final output sent to browser
DEBUG - 2022-02-18 15:35:39 --> Total execution time: 0.0295
ERROR - 2022-02-18 20:43:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-18 20:43:03 --> Config Class Initialized
INFO - 2022-02-18 20:43:03 --> Hooks Class Initialized
DEBUG - 2022-02-18 20:43:03 --> UTF-8 Support Enabled
INFO - 2022-02-18 20:43:03 --> Utf8 Class Initialized
INFO - 2022-02-18 20:43:03 --> URI Class Initialized
DEBUG - 2022-02-18 20:43:03 --> No URI present. Default controller set.
INFO - 2022-02-18 20:43:03 --> Router Class Initialized
INFO - 2022-02-18 20:43:03 --> Output Class Initialized
INFO - 2022-02-18 20:43:03 --> Security Class Initialized
DEBUG - 2022-02-18 20:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-18 20:43:03 --> Input Class Initialized
INFO - 2022-02-18 20:43:03 --> Language Class Initialized
INFO - 2022-02-18 20:43:03 --> Loader Class Initialized
INFO - 2022-02-18 20:43:03 --> Helper loaded: url_helper
INFO - 2022-02-18 20:43:03 --> Helper loaded: form_helper
INFO - 2022-02-18 20:43:03 --> Helper loaded: common_helper
INFO - 2022-02-18 20:43:03 --> Database Driver Class Initialized
DEBUG - 2022-02-18 20:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-18 20:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-18 20:43:03 --> Controller Class Initialized
INFO - 2022-02-18 20:43:03 --> Form Validation Class Initialized
DEBUG - 2022-02-18 20:43:03 --> Encrypt Class Initialized
DEBUG - 2022-02-18 20:43:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 20:43:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-18 20:43:03 --> Email Class Initialized
INFO - 2022-02-18 20:43:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-18 20:43:03 --> Calendar Class Initialized
INFO - 2022-02-18 20:43:03 --> Model "Login_model" initialized
INFO - 2022-02-18 20:43:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-18 20:43:03 --> Final output sent to browser
DEBUG - 2022-02-18 20:43:03 --> Total execution time: 0.0253
