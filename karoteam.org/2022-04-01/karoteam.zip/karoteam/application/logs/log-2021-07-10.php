<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-10 20:38:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-10 20:38:47 --> Config Class Initialized
INFO - 2021-07-10 20:38:47 --> Hooks Class Initialized
DEBUG - 2021-07-10 20:38:47 --> UTF-8 Support Enabled
INFO - 2021-07-10 20:38:47 --> Utf8 Class Initialized
INFO - 2021-07-10 20:38:47 --> URI Class Initialized
DEBUG - 2021-07-10 20:38:47 --> No URI present. Default controller set.
INFO - 2021-07-10 20:38:47 --> Router Class Initialized
INFO - 2021-07-10 20:38:47 --> Output Class Initialized
INFO - 2021-07-10 20:38:47 --> Security Class Initialized
DEBUG - 2021-07-10 20:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 20:38:47 --> Input Class Initialized
INFO - 2021-07-10 20:38:47 --> Language Class Initialized
INFO - 2021-07-10 20:38:47 --> Loader Class Initialized
INFO - 2021-07-10 20:38:47 --> Helper loaded: url_helper
INFO - 2021-07-10 20:38:47 --> Helper loaded: form_helper
INFO - 2021-07-10 20:38:47 --> Helper loaded: common_helper
INFO - 2021-07-10 20:38:47 --> Database Driver Class Initialized
DEBUG - 2021-07-10 20:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 20:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 20:38:47 --> Controller Class Initialized
INFO - 2021-07-10 20:38:47 --> Form Validation Class Initialized
DEBUG - 2021-07-10 20:38:47 --> Encrypt Class Initialized
DEBUG - 2021-07-10 20:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-10 20:38:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-10 20:38:47 --> Email Class Initialized
INFO - 2021-07-10 20:38:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-10 20:38:47 --> Calendar Class Initialized
INFO - 2021-07-10 20:38:47 --> Model "Login_model" initialized
INFO - 2021-07-10 20:38:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-10 20:38:47 --> Final output sent to browser
DEBUG - 2021-07-10 20:38:47 --> Total execution time: 0.0449
ERROR - 2021-07-10 20:38:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-10 20:38:48 --> Config Class Initialized
INFO - 2021-07-10 20:38:48 --> Hooks Class Initialized
DEBUG - 2021-07-10 20:38:48 --> UTF-8 Support Enabled
INFO - 2021-07-10 20:38:48 --> Utf8 Class Initialized
INFO - 2021-07-10 20:38:48 --> URI Class Initialized
INFO - 2021-07-10 20:38:48 --> Router Class Initialized
INFO - 2021-07-10 20:38:48 --> Output Class Initialized
INFO - 2021-07-10 20:38:48 --> Security Class Initialized
DEBUG - 2021-07-10 20:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 20:38:48 --> Input Class Initialized
INFO - 2021-07-10 20:38:48 --> Language Class Initialized
ERROR - 2021-07-10 20:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-10 20:39:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-10 20:39:23 --> Config Class Initialized
INFO - 2021-07-10 20:39:23 --> Hooks Class Initialized
DEBUG - 2021-07-10 20:39:23 --> UTF-8 Support Enabled
INFO - 2021-07-10 20:39:23 --> Utf8 Class Initialized
INFO - 2021-07-10 20:39:23 --> URI Class Initialized
INFO - 2021-07-10 20:39:23 --> Router Class Initialized
INFO - 2021-07-10 20:39:23 --> Output Class Initialized
INFO - 2021-07-10 20:39:23 --> Security Class Initialized
DEBUG - 2021-07-10 20:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 20:39:23 --> Input Class Initialized
INFO - 2021-07-10 20:39:23 --> Language Class Initialized
ERROR - 2021-07-10 20:39:23 --> 404 Page Not Found: Adstxt/index
