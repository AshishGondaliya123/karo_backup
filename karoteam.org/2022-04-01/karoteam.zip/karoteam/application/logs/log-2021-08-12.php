<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-12 11:05:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-12 11:05:18 --> Config Class Initialized
INFO - 2021-08-12 11:05:18 --> Hooks Class Initialized
DEBUG - 2021-08-12 11:05:18 --> UTF-8 Support Enabled
INFO - 2021-08-12 11:05:18 --> Utf8 Class Initialized
INFO - 2021-08-12 11:05:18 --> URI Class Initialized
DEBUG - 2021-08-12 11:05:18 --> No URI present. Default controller set.
INFO - 2021-08-12 11:05:18 --> Router Class Initialized
INFO - 2021-08-12 11:05:18 --> Output Class Initialized
INFO - 2021-08-12 11:05:18 --> Security Class Initialized
DEBUG - 2021-08-12 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-12 11:05:18 --> Input Class Initialized
INFO - 2021-08-12 11:05:18 --> Language Class Initialized
INFO - 2021-08-12 11:05:18 --> Loader Class Initialized
INFO - 2021-08-12 11:05:18 --> Helper loaded: url_helper
INFO - 2021-08-12 11:05:18 --> Helper loaded: form_helper
INFO - 2021-08-12 11:05:18 --> Helper loaded: common_helper
INFO - 2021-08-12 11:05:18 --> Database Driver Class Initialized
DEBUG - 2021-08-12 11:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-12 11:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-12 11:05:18 --> Controller Class Initialized
INFO - 2021-08-12 11:05:18 --> Form Validation Class Initialized
DEBUG - 2021-08-12 11:05:18 --> Encrypt Class Initialized
DEBUG - 2021-08-12 11:05:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-12 11:05:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-12 11:05:18 --> Email Class Initialized
INFO - 2021-08-12 11:05:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-12 11:05:18 --> Calendar Class Initialized
INFO - 2021-08-12 11:05:18 --> Model "Login_model" initialized
INFO - 2021-08-12 11:05:18 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-12 11:05:18 --> Final output sent to browser
DEBUG - 2021-08-12 11:05:18 --> Total execution time: 0.1459
ERROR - 2021-08-12 11:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-12 11:05:19 --> Config Class Initialized
INFO - 2021-08-12 11:05:19 --> Hooks Class Initialized
DEBUG - 2021-08-12 11:05:19 --> UTF-8 Support Enabled
INFO - 2021-08-12 11:05:19 --> Utf8 Class Initialized
INFO - 2021-08-12 11:05:19 --> URI Class Initialized
DEBUG - 2021-08-12 11:05:19 --> No URI present. Default controller set.
INFO - 2021-08-12 11:05:19 --> Router Class Initialized
INFO - 2021-08-12 11:05:19 --> Output Class Initialized
INFO - 2021-08-12 11:05:19 --> Security Class Initialized
DEBUG - 2021-08-12 11:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-12 11:05:19 --> Input Class Initialized
INFO - 2021-08-12 11:05:19 --> Language Class Initialized
INFO - 2021-08-12 11:05:19 --> Loader Class Initialized
INFO - 2021-08-12 11:05:19 --> Helper loaded: url_helper
INFO - 2021-08-12 11:05:19 --> Helper loaded: form_helper
INFO - 2021-08-12 11:05:19 --> Helper loaded: common_helper
INFO - 2021-08-12 11:05:19 --> Database Driver Class Initialized
DEBUG - 2021-08-12 11:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-12 11:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-12 11:05:19 --> Controller Class Initialized
INFO - 2021-08-12 11:05:19 --> Form Validation Class Initialized
DEBUG - 2021-08-12 11:05:19 --> Encrypt Class Initialized
DEBUG - 2021-08-12 11:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-12 11:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-12 11:05:19 --> Email Class Initialized
INFO - 2021-08-12 11:05:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-12 11:05:19 --> Calendar Class Initialized
INFO - 2021-08-12 11:05:19 --> Model "Login_model" initialized
INFO - 2021-08-12 11:05:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-12 11:05:19 --> Final output sent to browser
DEBUG - 2021-08-12 11:05:19 --> Total execution time: 0.0905
