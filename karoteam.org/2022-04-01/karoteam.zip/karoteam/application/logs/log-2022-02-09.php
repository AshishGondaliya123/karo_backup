<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-09 04:18:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:18:56 --> Config Class Initialized
INFO - 2022-02-09 04:18:56 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:18:56 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:18:56 --> Utf8 Class Initialized
INFO - 2022-02-09 04:18:56 --> URI Class Initialized
DEBUG - 2022-02-09 04:18:56 --> No URI present. Default controller set.
INFO - 2022-02-09 04:18:56 --> Router Class Initialized
INFO - 2022-02-09 04:18:56 --> Output Class Initialized
INFO - 2022-02-09 04:18:56 --> Security Class Initialized
DEBUG - 2022-02-09 04:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:18:56 --> Input Class Initialized
INFO - 2022-02-09 04:18:56 --> Language Class Initialized
INFO - 2022-02-09 04:18:56 --> Loader Class Initialized
INFO - 2022-02-09 04:18:56 --> Helper loaded: url_helper
INFO - 2022-02-09 04:18:56 --> Helper loaded: form_helper
INFO - 2022-02-09 04:18:56 --> Helper loaded: common_helper
INFO - 2022-02-09 04:18:56 --> Database Driver Class Initialized
DEBUG - 2022-02-09 04:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 04:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 04:18:56 --> Controller Class Initialized
INFO - 2022-02-09 04:18:56 --> Form Validation Class Initialized
DEBUG - 2022-02-09 04:18:56 --> Encrypt Class Initialized
DEBUG - 2022-02-09 04:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 04:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 04:18:56 --> Email Class Initialized
INFO - 2022-02-09 04:18:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 04:18:56 --> Calendar Class Initialized
INFO - 2022-02-09 04:18:56 --> Model "Login_model" initialized
INFO - 2022-02-09 04:18:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 04:18:56 --> Final output sent to browser
DEBUG - 2022-02-09 04:18:56 --> Total execution time: 0.0320
ERROR - 2022-02-09 04:18:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:18:56 --> Config Class Initialized
INFO - 2022-02-09 04:18:56 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:18:56 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:18:56 --> Utf8 Class Initialized
INFO - 2022-02-09 04:18:56 --> URI Class Initialized
DEBUG - 2022-02-09 04:18:56 --> No URI present. Default controller set.
INFO - 2022-02-09 04:18:56 --> Router Class Initialized
INFO - 2022-02-09 04:18:56 --> Output Class Initialized
INFO - 2022-02-09 04:18:56 --> Security Class Initialized
DEBUG - 2022-02-09 04:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:18:56 --> Input Class Initialized
INFO - 2022-02-09 04:18:56 --> Language Class Initialized
INFO - 2022-02-09 04:18:56 --> Loader Class Initialized
INFO - 2022-02-09 04:18:56 --> Helper loaded: url_helper
INFO - 2022-02-09 04:18:56 --> Helper loaded: form_helper
INFO - 2022-02-09 04:18:56 --> Helper loaded: common_helper
INFO - 2022-02-09 04:18:56 --> Database Driver Class Initialized
DEBUG - 2022-02-09 04:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 04:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 04:18:56 --> Controller Class Initialized
INFO - 2022-02-09 04:18:56 --> Form Validation Class Initialized
DEBUG - 2022-02-09 04:18:56 --> Encrypt Class Initialized
DEBUG - 2022-02-09 04:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 04:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 04:18:56 --> Email Class Initialized
INFO - 2022-02-09 04:18:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 04:18:56 --> Calendar Class Initialized
INFO - 2022-02-09 04:18:56 --> Model "Login_model" initialized
INFO - 2022-02-09 04:18:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 04:18:56 --> Final output sent to browser
DEBUG - 2022-02-09 04:18:56 --> Total execution time: 0.0224
ERROR - 2022-02-09 04:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:18:57 --> Config Class Initialized
INFO - 2022-02-09 04:18:57 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:18:57 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:18:57 --> Utf8 Class Initialized
INFO - 2022-02-09 04:18:57 --> URI Class Initialized
DEBUG - 2022-02-09 04:18:57 --> No URI present. Default controller set.
INFO - 2022-02-09 04:18:57 --> Router Class Initialized
INFO - 2022-02-09 04:18:57 --> Output Class Initialized
INFO - 2022-02-09 04:18:57 --> Security Class Initialized
DEBUG - 2022-02-09 04:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:18:57 --> Input Class Initialized
INFO - 2022-02-09 04:18:57 --> Language Class Initialized
INFO - 2022-02-09 04:18:57 --> Loader Class Initialized
INFO - 2022-02-09 04:18:57 --> Helper loaded: url_helper
INFO - 2022-02-09 04:18:57 --> Helper loaded: form_helper
INFO - 2022-02-09 04:18:57 --> Helper loaded: common_helper
INFO - 2022-02-09 04:18:57 --> Database Driver Class Initialized
DEBUG - 2022-02-09 04:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 04:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 04:18:57 --> Controller Class Initialized
INFO - 2022-02-09 04:18:57 --> Form Validation Class Initialized
DEBUG - 2022-02-09 04:18:57 --> Encrypt Class Initialized
DEBUG - 2022-02-09 04:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 04:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 04:18:57 --> Email Class Initialized
INFO - 2022-02-09 04:18:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 04:18:57 --> Calendar Class Initialized
INFO - 2022-02-09 04:18:57 --> Model "Login_model" initialized
INFO - 2022-02-09 04:18:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 04:18:57 --> Final output sent to browser
DEBUG - 2022-02-09 04:18:57 --> Total execution time: 0.0343
ERROR - 2022-02-09 04:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:18:58 --> Config Class Initialized
INFO - 2022-02-09 04:18:58 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:18:58 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:18:58 --> Utf8 Class Initialized
INFO - 2022-02-09 04:18:58 --> URI Class Initialized
INFO - 2022-02-09 04:18:58 --> Router Class Initialized
INFO - 2022-02-09 04:18:58 --> Output Class Initialized
INFO - 2022-02-09 04:18:58 --> Security Class Initialized
DEBUG - 2022-02-09 04:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:18:58 --> Input Class Initialized
INFO - 2022-02-09 04:18:58 --> Language Class Initialized
ERROR - 2022-02-09 04:18:58 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-09 04:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:18:58 --> Config Class Initialized
INFO - 2022-02-09 04:18:58 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:18:58 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:18:58 --> Utf8 Class Initialized
INFO - 2022-02-09 04:18:58 --> URI Class Initialized
INFO - 2022-02-09 04:18:58 --> Router Class Initialized
INFO - 2022-02-09 04:18:58 --> Output Class Initialized
INFO - 2022-02-09 04:18:58 --> Security Class Initialized
DEBUG - 2022-02-09 04:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:18:58 --> Input Class Initialized
INFO - 2022-02-09 04:18:58 --> Language Class Initialized
ERROR - 2022-02-09 04:18:58 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-09 04:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:18:58 --> Config Class Initialized
INFO - 2022-02-09 04:18:58 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:18:58 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:18:58 --> Utf8 Class Initialized
INFO - 2022-02-09 04:18:58 --> URI Class Initialized
INFO - 2022-02-09 04:18:58 --> Router Class Initialized
INFO - 2022-02-09 04:18:58 --> Output Class Initialized
INFO - 2022-02-09 04:18:58 --> Security Class Initialized
DEBUG - 2022-02-09 04:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:18:58 --> Input Class Initialized
INFO - 2022-02-09 04:18:58 --> Language Class Initialized
ERROR - 2022-02-09 04:18:58 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-09 04:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:18:59 --> Config Class Initialized
INFO - 2022-02-09 04:18:59 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:18:59 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:18:59 --> Utf8 Class Initialized
INFO - 2022-02-09 04:18:59 --> URI Class Initialized
INFO - 2022-02-09 04:18:59 --> Router Class Initialized
INFO - 2022-02-09 04:18:59 --> Output Class Initialized
INFO - 2022-02-09 04:18:59 --> Security Class Initialized
DEBUG - 2022-02-09 04:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:18:59 --> Input Class Initialized
INFO - 2022-02-09 04:18:59 --> Language Class Initialized
ERROR - 2022-02-09 04:18:59 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-09 04:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:18:59 --> Config Class Initialized
INFO - 2022-02-09 04:18:59 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:18:59 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:18:59 --> Utf8 Class Initialized
INFO - 2022-02-09 04:18:59 --> URI Class Initialized
INFO - 2022-02-09 04:18:59 --> Router Class Initialized
INFO - 2022-02-09 04:18:59 --> Output Class Initialized
INFO - 2022-02-09 04:18:59 --> Security Class Initialized
DEBUG - 2022-02-09 04:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:18:59 --> Input Class Initialized
INFO - 2022-02-09 04:18:59 --> Language Class Initialized
ERROR - 2022-02-09 04:18:59 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-09 04:19:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:00 --> Config Class Initialized
INFO - 2022-02-09 04:19:00 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:00 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:00 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:00 --> URI Class Initialized
INFO - 2022-02-09 04:19:00 --> Router Class Initialized
INFO - 2022-02-09 04:19:00 --> Output Class Initialized
INFO - 2022-02-09 04:19:00 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:00 --> Input Class Initialized
INFO - 2022-02-09 04:19:00 --> Language Class Initialized
ERROR - 2022-02-09 04:19:00 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-09 04:19:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:00 --> Config Class Initialized
INFO - 2022-02-09 04:19:00 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:00 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:00 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:00 --> URI Class Initialized
INFO - 2022-02-09 04:19:00 --> Router Class Initialized
INFO - 2022-02-09 04:19:00 --> Output Class Initialized
INFO - 2022-02-09 04:19:00 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:00 --> Input Class Initialized
INFO - 2022-02-09 04:19:00 --> Language Class Initialized
ERROR - 2022-02-09 04:19:00 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-09 04:19:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:00 --> Config Class Initialized
INFO - 2022-02-09 04:19:00 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:00 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:00 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:00 --> URI Class Initialized
INFO - 2022-02-09 04:19:00 --> Router Class Initialized
INFO - 2022-02-09 04:19:00 --> Output Class Initialized
INFO - 2022-02-09 04:19:00 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:00 --> Input Class Initialized
INFO - 2022-02-09 04:19:00 --> Language Class Initialized
ERROR - 2022-02-09 04:19:00 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-09 04:19:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:01 --> Config Class Initialized
INFO - 2022-02-09 04:19:01 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:01 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:01 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:01 --> URI Class Initialized
INFO - 2022-02-09 04:19:01 --> Router Class Initialized
INFO - 2022-02-09 04:19:01 --> Output Class Initialized
INFO - 2022-02-09 04:19:01 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:01 --> Input Class Initialized
INFO - 2022-02-09 04:19:01 --> Language Class Initialized
ERROR - 2022-02-09 04:19:01 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-09 04:19:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:01 --> Config Class Initialized
INFO - 2022-02-09 04:19:01 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:01 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:01 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:01 --> URI Class Initialized
INFO - 2022-02-09 04:19:01 --> Router Class Initialized
INFO - 2022-02-09 04:19:01 --> Output Class Initialized
INFO - 2022-02-09 04:19:01 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:01 --> Input Class Initialized
INFO - 2022-02-09 04:19:01 --> Language Class Initialized
ERROR - 2022-02-09 04:19:01 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-09 04:19:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:02 --> Config Class Initialized
INFO - 2022-02-09 04:19:02 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:02 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:02 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:02 --> URI Class Initialized
INFO - 2022-02-09 04:19:02 --> Router Class Initialized
INFO - 2022-02-09 04:19:02 --> Output Class Initialized
INFO - 2022-02-09 04:19:02 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:02 --> Input Class Initialized
INFO - 2022-02-09 04:19:02 --> Language Class Initialized
ERROR - 2022-02-09 04:19:02 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-09 04:19:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:02 --> Config Class Initialized
INFO - 2022-02-09 04:19:02 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:02 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:02 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:02 --> URI Class Initialized
INFO - 2022-02-09 04:19:02 --> Router Class Initialized
INFO - 2022-02-09 04:19:02 --> Output Class Initialized
INFO - 2022-02-09 04:19:02 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:02 --> Input Class Initialized
INFO - 2022-02-09 04:19:02 --> Language Class Initialized
ERROR - 2022-02-09 04:19:02 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-09 04:19:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:02 --> Config Class Initialized
INFO - 2022-02-09 04:19:02 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:02 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:02 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:02 --> URI Class Initialized
INFO - 2022-02-09 04:19:02 --> Router Class Initialized
INFO - 2022-02-09 04:19:02 --> Output Class Initialized
INFO - 2022-02-09 04:19:02 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:02 --> Input Class Initialized
INFO - 2022-02-09 04:19:02 --> Language Class Initialized
ERROR - 2022-02-09 04:19:02 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-09 04:19:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:03 --> Config Class Initialized
INFO - 2022-02-09 04:19:03 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:03 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:03 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:03 --> URI Class Initialized
INFO - 2022-02-09 04:19:03 --> Router Class Initialized
INFO - 2022-02-09 04:19:03 --> Output Class Initialized
INFO - 2022-02-09 04:19:03 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:03 --> Input Class Initialized
INFO - 2022-02-09 04:19:03 --> Language Class Initialized
ERROR - 2022-02-09 04:19:03 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-09 04:19:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:03 --> Config Class Initialized
INFO - 2022-02-09 04:19:03 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:03 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:03 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:03 --> URI Class Initialized
INFO - 2022-02-09 04:19:03 --> Router Class Initialized
INFO - 2022-02-09 04:19:03 --> Output Class Initialized
INFO - 2022-02-09 04:19:03 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:03 --> Input Class Initialized
INFO - 2022-02-09 04:19:03 --> Language Class Initialized
ERROR - 2022-02-09 04:19:03 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-09 04:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 04:19:04 --> Config Class Initialized
INFO - 2022-02-09 04:19:04 --> Hooks Class Initialized
DEBUG - 2022-02-09 04:19:04 --> UTF-8 Support Enabled
INFO - 2022-02-09 04:19:04 --> Utf8 Class Initialized
INFO - 2022-02-09 04:19:04 --> URI Class Initialized
INFO - 2022-02-09 04:19:04 --> Router Class Initialized
INFO - 2022-02-09 04:19:04 --> Output Class Initialized
INFO - 2022-02-09 04:19:04 --> Security Class Initialized
DEBUG - 2022-02-09 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 04:19:04 --> Input Class Initialized
INFO - 2022-02-09 04:19:04 --> Language Class Initialized
ERROR - 2022-02-09 04:19:04 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-09 06:54:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 06:54:52 --> Config Class Initialized
INFO - 2022-02-09 06:54:52 --> Hooks Class Initialized
DEBUG - 2022-02-09 06:54:52 --> UTF-8 Support Enabled
INFO - 2022-02-09 06:54:52 --> Utf8 Class Initialized
INFO - 2022-02-09 06:54:52 --> URI Class Initialized
DEBUG - 2022-02-09 06:54:52 --> No URI present. Default controller set.
INFO - 2022-02-09 06:54:52 --> Router Class Initialized
INFO - 2022-02-09 06:54:52 --> Output Class Initialized
INFO - 2022-02-09 06:54:52 --> Security Class Initialized
DEBUG - 2022-02-09 06:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 06:54:52 --> Input Class Initialized
INFO - 2022-02-09 06:54:52 --> Language Class Initialized
INFO - 2022-02-09 06:54:52 --> Loader Class Initialized
INFO - 2022-02-09 06:54:52 --> Helper loaded: url_helper
INFO - 2022-02-09 06:54:52 --> Helper loaded: form_helper
INFO - 2022-02-09 06:54:52 --> Helper loaded: common_helper
INFO - 2022-02-09 06:54:52 --> Database Driver Class Initialized
DEBUG - 2022-02-09 06:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 06:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 06:54:52 --> Controller Class Initialized
INFO - 2022-02-09 06:54:52 --> Form Validation Class Initialized
DEBUG - 2022-02-09 06:54:52 --> Encrypt Class Initialized
DEBUG - 2022-02-09 06:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 06:54:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 06:54:52 --> Email Class Initialized
INFO - 2022-02-09 06:54:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 06:54:52 --> Calendar Class Initialized
INFO - 2022-02-09 06:54:52 --> Model "Login_model" initialized
INFO - 2022-02-09 06:54:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 06:54:52 --> Final output sent to browser
DEBUG - 2022-02-09 06:54:52 --> Total execution time: 0.0363
ERROR - 2022-02-09 06:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 06:59:59 --> Config Class Initialized
INFO - 2022-02-09 06:59:59 --> Hooks Class Initialized
DEBUG - 2022-02-09 06:59:59 --> UTF-8 Support Enabled
INFO - 2022-02-09 06:59:59 --> Utf8 Class Initialized
INFO - 2022-02-09 06:59:59 --> URI Class Initialized
DEBUG - 2022-02-09 06:59:59 --> No URI present. Default controller set.
INFO - 2022-02-09 06:59:59 --> Router Class Initialized
INFO - 2022-02-09 06:59:59 --> Output Class Initialized
INFO - 2022-02-09 06:59:59 --> Security Class Initialized
DEBUG - 2022-02-09 06:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 06:59:59 --> Input Class Initialized
INFO - 2022-02-09 06:59:59 --> Language Class Initialized
INFO - 2022-02-09 06:59:59 --> Loader Class Initialized
INFO - 2022-02-09 06:59:59 --> Helper loaded: url_helper
INFO - 2022-02-09 06:59:59 --> Helper loaded: form_helper
INFO - 2022-02-09 06:59:59 --> Helper loaded: common_helper
INFO - 2022-02-09 06:59:59 --> Database Driver Class Initialized
DEBUG - 2022-02-09 06:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 06:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 06:59:59 --> Controller Class Initialized
INFO - 2022-02-09 06:59:59 --> Form Validation Class Initialized
DEBUG - 2022-02-09 06:59:59 --> Encrypt Class Initialized
DEBUG - 2022-02-09 06:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 06:59:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 06:59:59 --> Email Class Initialized
INFO - 2022-02-09 06:59:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 06:59:59 --> Calendar Class Initialized
INFO - 2022-02-09 06:59:59 --> Model "Login_model" initialized
INFO - 2022-02-09 06:59:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 06:59:59 --> Final output sent to browser
DEBUG - 2022-02-09 06:59:59 --> Total execution time: 0.0218
ERROR - 2022-02-09 10:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 10:25:29 --> Config Class Initialized
INFO - 2022-02-09 10:25:29 --> Hooks Class Initialized
DEBUG - 2022-02-09 10:25:29 --> UTF-8 Support Enabled
INFO - 2022-02-09 10:25:29 --> Utf8 Class Initialized
INFO - 2022-02-09 10:25:29 --> URI Class Initialized
DEBUG - 2022-02-09 10:25:29 --> No URI present. Default controller set.
INFO - 2022-02-09 10:25:29 --> Router Class Initialized
INFO - 2022-02-09 10:25:29 --> Output Class Initialized
INFO - 2022-02-09 10:25:29 --> Security Class Initialized
DEBUG - 2022-02-09 10:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 10:25:29 --> Input Class Initialized
INFO - 2022-02-09 10:25:29 --> Language Class Initialized
INFO - 2022-02-09 10:25:29 --> Loader Class Initialized
INFO - 2022-02-09 10:25:29 --> Helper loaded: url_helper
INFO - 2022-02-09 10:25:29 --> Helper loaded: form_helper
INFO - 2022-02-09 10:25:29 --> Helper loaded: common_helper
INFO - 2022-02-09 10:25:29 --> Database Driver Class Initialized
DEBUG - 2022-02-09 10:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 10:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 10:25:29 --> Controller Class Initialized
INFO - 2022-02-09 10:25:29 --> Form Validation Class Initialized
DEBUG - 2022-02-09 10:25:29 --> Encrypt Class Initialized
DEBUG - 2022-02-09 10:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:25:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 10:25:29 --> Email Class Initialized
INFO - 2022-02-09 10:25:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 10:25:29 --> Calendar Class Initialized
INFO - 2022-02-09 10:25:29 --> Model "Login_model" initialized
INFO - 2022-02-09 10:25:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 10:25:29 --> Final output sent to browser
DEBUG - 2022-02-09 10:25:29 --> Total execution time: 0.0579
ERROR - 2022-02-09 10:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 10:25:29 --> Config Class Initialized
INFO - 2022-02-09 10:25:29 --> Hooks Class Initialized
DEBUG - 2022-02-09 10:25:29 --> UTF-8 Support Enabled
INFO - 2022-02-09 10:25:29 --> Utf8 Class Initialized
INFO - 2022-02-09 10:25:29 --> URI Class Initialized
DEBUG - 2022-02-09 10:25:29 --> No URI present. Default controller set.
INFO - 2022-02-09 10:25:29 --> Router Class Initialized
INFO - 2022-02-09 10:25:30 --> Output Class Initialized
INFO - 2022-02-09 10:25:30 --> Security Class Initialized
DEBUG - 2022-02-09 10:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 10:25:30 --> Input Class Initialized
INFO - 2022-02-09 10:25:30 --> Language Class Initialized
INFO - 2022-02-09 10:25:30 --> Loader Class Initialized
INFO - 2022-02-09 10:25:30 --> Helper loaded: url_helper
INFO - 2022-02-09 10:25:30 --> Helper loaded: form_helper
INFO - 2022-02-09 10:25:30 --> Helper loaded: common_helper
INFO - 2022-02-09 10:25:30 --> Database Driver Class Initialized
DEBUG - 2022-02-09 10:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 10:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 10:25:30 --> Controller Class Initialized
INFO - 2022-02-09 10:25:30 --> Form Validation Class Initialized
DEBUG - 2022-02-09 10:25:30 --> Encrypt Class Initialized
DEBUG - 2022-02-09 10:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:25:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 10:25:30 --> Email Class Initialized
INFO - 2022-02-09 10:25:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 10:25:30 --> Calendar Class Initialized
INFO - 2022-02-09 10:25:30 --> Model "Login_model" initialized
INFO - 2022-02-09 10:25:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 10:25:30 --> Final output sent to browser
DEBUG - 2022-02-09 10:25:30 --> Total execution time: 0.0328
ERROR - 2022-02-09 14:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 14:19:37 --> Config Class Initialized
INFO - 2022-02-09 14:19:37 --> Hooks Class Initialized
DEBUG - 2022-02-09 14:19:37 --> UTF-8 Support Enabled
INFO - 2022-02-09 14:19:37 --> Utf8 Class Initialized
INFO - 2022-02-09 14:19:37 --> URI Class Initialized
DEBUG - 2022-02-09 14:19:37 --> No URI present. Default controller set.
INFO - 2022-02-09 14:19:37 --> Router Class Initialized
INFO - 2022-02-09 14:19:37 --> Output Class Initialized
INFO - 2022-02-09 14:19:37 --> Security Class Initialized
DEBUG - 2022-02-09 14:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 14:19:37 --> Input Class Initialized
INFO - 2022-02-09 14:19:37 --> Language Class Initialized
INFO - 2022-02-09 14:19:37 --> Loader Class Initialized
INFO - 2022-02-09 14:19:37 --> Helper loaded: url_helper
INFO - 2022-02-09 14:19:37 --> Helper loaded: form_helper
INFO - 2022-02-09 14:19:37 --> Helper loaded: common_helper
INFO - 2022-02-09 14:19:37 --> Database Driver Class Initialized
DEBUG - 2022-02-09 14:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 14:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 14:19:37 --> Controller Class Initialized
INFO - 2022-02-09 14:19:37 --> Form Validation Class Initialized
DEBUG - 2022-02-09 14:19:37 --> Encrypt Class Initialized
DEBUG - 2022-02-09 14:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 14:19:37 --> Email Class Initialized
INFO - 2022-02-09 14:19:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 14:19:37 --> Calendar Class Initialized
INFO - 2022-02-09 14:19:37 --> Model "Login_model" initialized
INFO - 2022-02-09 14:19:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 14:19:37 --> Final output sent to browser
DEBUG - 2022-02-09 14:19:37 --> Total execution time: 0.0352
ERROR - 2022-02-09 14:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 14:19:38 --> Config Class Initialized
INFO - 2022-02-09 14:19:38 --> Hooks Class Initialized
DEBUG - 2022-02-09 14:19:38 --> UTF-8 Support Enabled
INFO - 2022-02-09 14:19:38 --> Utf8 Class Initialized
INFO - 2022-02-09 14:19:38 --> URI Class Initialized
INFO - 2022-02-09 14:19:38 --> Router Class Initialized
INFO - 2022-02-09 14:19:38 --> Output Class Initialized
INFO - 2022-02-09 14:19:38 --> Security Class Initialized
DEBUG - 2022-02-09 14:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 14:19:38 --> Input Class Initialized
INFO - 2022-02-09 14:19:38 --> Language Class Initialized
ERROR - 2022-02-09 14:19:38 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-09 14:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 14:19:46 --> Config Class Initialized
INFO - 2022-02-09 14:19:46 --> Hooks Class Initialized
DEBUG - 2022-02-09 14:19:46 --> UTF-8 Support Enabled
INFO - 2022-02-09 14:19:46 --> Utf8 Class Initialized
INFO - 2022-02-09 14:19:46 --> URI Class Initialized
INFO - 2022-02-09 14:19:46 --> Router Class Initialized
INFO - 2022-02-09 14:19:46 --> Output Class Initialized
INFO - 2022-02-09 14:19:46 --> Security Class Initialized
DEBUG - 2022-02-09 14:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 14:19:46 --> Input Class Initialized
INFO - 2022-02-09 14:19:46 --> Language Class Initialized
INFO - 2022-02-09 14:19:46 --> Loader Class Initialized
INFO - 2022-02-09 14:19:46 --> Helper loaded: url_helper
INFO - 2022-02-09 14:19:46 --> Helper loaded: form_helper
INFO - 2022-02-09 14:19:46 --> Helper loaded: common_helper
INFO - 2022-02-09 14:19:46 --> Database Driver Class Initialized
DEBUG - 2022-02-09 14:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 14:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 14:19:46 --> Controller Class Initialized
INFO - 2022-02-09 14:19:46 --> Form Validation Class Initialized
DEBUG - 2022-02-09 14:19:46 --> Encrypt Class Initialized
DEBUG - 2022-02-09 14:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 14:19:46 --> Email Class Initialized
INFO - 2022-02-09 14:19:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 14:19:46 --> Calendar Class Initialized
INFO - 2022-02-09 14:19:46 --> Model "Login_model" initialized
INFO - 2022-02-09 14:19:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 14:19:46 --> Final output sent to browser
DEBUG - 2022-02-09 14:19:46 --> Total execution time: 0.0461
ERROR - 2022-02-09 14:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 14:19:47 --> Config Class Initialized
INFO - 2022-02-09 14:19:47 --> Hooks Class Initialized
DEBUG - 2022-02-09 14:19:47 --> UTF-8 Support Enabled
INFO - 2022-02-09 14:19:47 --> Utf8 Class Initialized
INFO - 2022-02-09 14:19:47 --> URI Class Initialized
INFO - 2022-02-09 14:19:47 --> Router Class Initialized
INFO - 2022-02-09 14:19:47 --> Output Class Initialized
INFO - 2022-02-09 14:19:47 --> Security Class Initialized
DEBUG - 2022-02-09 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 14:19:47 --> Input Class Initialized
INFO - 2022-02-09 14:19:47 --> Language Class Initialized
INFO - 2022-02-09 14:19:47 --> Loader Class Initialized
INFO - 2022-02-09 14:19:47 --> Helper loaded: url_helper
INFO - 2022-02-09 14:19:47 --> Helper loaded: form_helper
INFO - 2022-02-09 14:19:47 --> Helper loaded: common_helper
INFO - 2022-02-09 14:19:47 --> Database Driver Class Initialized
DEBUG - 2022-02-09 14:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 14:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 14:19:47 --> Controller Class Initialized
INFO - 2022-02-09 14:19:47 --> Form Validation Class Initialized
DEBUG - 2022-02-09 14:19:47 --> Encrypt Class Initialized
DEBUG - 2022-02-09 14:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:19:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 14:19:47 --> Email Class Initialized
INFO - 2022-02-09 14:19:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 14:19:47 --> Calendar Class Initialized
INFO - 2022-02-09 14:19:47 --> Model "Login_model" initialized
ERROR - 2022-02-09 14:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 14:19:47 --> Config Class Initialized
INFO - 2022-02-09 14:19:47 --> Hooks Class Initialized
DEBUG - 2022-02-09 14:19:47 --> UTF-8 Support Enabled
INFO - 2022-02-09 14:19:47 --> Utf8 Class Initialized
INFO - 2022-02-09 14:19:47 --> URI Class Initialized
INFO - 2022-02-09 14:19:47 --> Router Class Initialized
INFO - 2022-02-09 14:19:47 --> Output Class Initialized
INFO - 2022-02-09 14:19:47 --> Security Class Initialized
DEBUG - 2022-02-09 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 14:19:47 --> Input Class Initialized
INFO - 2022-02-09 14:19:47 --> Language Class Initialized
INFO - 2022-02-09 14:19:47 --> Loader Class Initialized
INFO - 2022-02-09 14:19:47 --> Helper loaded: url_helper
INFO - 2022-02-09 14:19:47 --> Helper loaded: form_helper
INFO - 2022-02-09 14:19:47 --> Helper loaded: common_helper
INFO - 2022-02-09 14:19:47 --> Database Driver Class Initialized
DEBUG - 2022-02-09 14:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 14:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 14:19:47 --> Controller Class Initialized
INFO - 2022-02-09 14:19:47 --> Form Validation Class Initialized
DEBUG - 2022-02-09 14:19:47 --> Encrypt Class Initialized
DEBUG - 2022-02-09 14:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:19:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 14:19:47 --> Email Class Initialized
INFO - 2022-02-09 14:19:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 14:19:47 --> Calendar Class Initialized
INFO - 2022-02-09 14:19:47 --> Model "Login_model" initialized
ERROR - 2022-02-09 14:19:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 14:19:48 --> Config Class Initialized
INFO - 2022-02-09 14:19:48 --> Hooks Class Initialized
DEBUG - 2022-02-09 14:19:48 --> UTF-8 Support Enabled
INFO - 2022-02-09 14:19:48 --> Utf8 Class Initialized
INFO - 2022-02-09 14:19:48 --> URI Class Initialized
DEBUG - 2022-02-09 14:19:48 --> No URI present. Default controller set.
INFO - 2022-02-09 14:19:48 --> Router Class Initialized
INFO - 2022-02-09 14:19:48 --> Output Class Initialized
INFO - 2022-02-09 14:19:48 --> Security Class Initialized
DEBUG - 2022-02-09 14:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 14:19:48 --> Input Class Initialized
INFO - 2022-02-09 14:19:48 --> Language Class Initialized
INFO - 2022-02-09 14:19:48 --> Loader Class Initialized
INFO - 2022-02-09 14:19:48 --> Helper loaded: url_helper
INFO - 2022-02-09 14:19:48 --> Helper loaded: form_helper
INFO - 2022-02-09 14:19:48 --> Helper loaded: common_helper
INFO - 2022-02-09 14:19:48 --> Database Driver Class Initialized
DEBUG - 2022-02-09 14:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 14:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 14:19:48 --> Controller Class Initialized
INFO - 2022-02-09 14:19:48 --> Form Validation Class Initialized
DEBUG - 2022-02-09 14:19:48 --> Encrypt Class Initialized
DEBUG - 2022-02-09 14:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:19:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 14:19:49 --> Email Class Initialized
INFO - 2022-02-09 14:19:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 14:19:49 --> Calendar Class Initialized
INFO - 2022-02-09 14:19:49 --> Model "Login_model" initialized
INFO - 2022-02-09 14:19:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 14:19:49 --> Final output sent to browser
DEBUG - 2022-02-09 14:19:49 --> Total execution time: 0.0391
ERROR - 2022-02-09 15:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 15:52:55 --> Config Class Initialized
INFO - 2022-02-09 15:52:55 --> Hooks Class Initialized
DEBUG - 2022-02-09 15:52:55 --> UTF-8 Support Enabled
INFO - 2022-02-09 15:52:55 --> Utf8 Class Initialized
INFO - 2022-02-09 15:52:55 --> URI Class Initialized
DEBUG - 2022-02-09 15:52:55 --> No URI present. Default controller set.
INFO - 2022-02-09 15:52:55 --> Router Class Initialized
INFO - 2022-02-09 15:52:55 --> Output Class Initialized
INFO - 2022-02-09 15:52:55 --> Security Class Initialized
DEBUG - 2022-02-09 15:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 15:52:55 --> Input Class Initialized
INFO - 2022-02-09 15:52:55 --> Language Class Initialized
INFO - 2022-02-09 15:52:55 --> Loader Class Initialized
INFO - 2022-02-09 15:52:55 --> Helper loaded: url_helper
INFO - 2022-02-09 15:52:55 --> Helper loaded: form_helper
INFO - 2022-02-09 15:52:55 --> Helper loaded: common_helper
INFO - 2022-02-09 15:52:55 --> Database Driver Class Initialized
DEBUG - 2022-02-09 15:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 15:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 15:52:55 --> Controller Class Initialized
INFO - 2022-02-09 15:52:55 --> Form Validation Class Initialized
DEBUG - 2022-02-09 15:52:55 --> Encrypt Class Initialized
DEBUG - 2022-02-09 15:52:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:52:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 15:52:55 --> Email Class Initialized
INFO - 2022-02-09 15:52:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 15:52:55 --> Calendar Class Initialized
INFO - 2022-02-09 15:52:55 --> Model "Login_model" initialized
INFO - 2022-02-09 15:52:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 15:52:55 --> Final output sent to browser
DEBUG - 2022-02-09 15:52:55 --> Total execution time: 0.0411
ERROR - 2022-02-09 16:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 16:17:44 --> Config Class Initialized
INFO - 2022-02-09 16:17:44 --> Hooks Class Initialized
DEBUG - 2022-02-09 16:17:44 --> UTF-8 Support Enabled
INFO - 2022-02-09 16:17:44 --> Utf8 Class Initialized
INFO - 2022-02-09 16:17:44 --> URI Class Initialized
DEBUG - 2022-02-09 16:17:44 --> No URI present. Default controller set.
INFO - 2022-02-09 16:17:44 --> Router Class Initialized
INFO - 2022-02-09 16:17:44 --> Output Class Initialized
INFO - 2022-02-09 16:17:44 --> Security Class Initialized
DEBUG - 2022-02-09 16:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 16:17:44 --> Input Class Initialized
INFO - 2022-02-09 16:17:44 --> Language Class Initialized
INFO - 2022-02-09 16:17:44 --> Loader Class Initialized
INFO - 2022-02-09 16:17:44 --> Helper loaded: url_helper
INFO - 2022-02-09 16:17:44 --> Helper loaded: form_helper
INFO - 2022-02-09 16:17:44 --> Helper loaded: common_helper
INFO - 2022-02-09 16:17:44 --> Database Driver Class Initialized
DEBUG - 2022-02-09 16:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 16:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 16:17:44 --> Controller Class Initialized
INFO - 2022-02-09 16:17:44 --> Form Validation Class Initialized
DEBUG - 2022-02-09 16:17:44 --> Encrypt Class Initialized
DEBUG - 2022-02-09 16:17:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:17:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 16:17:44 --> Email Class Initialized
INFO - 2022-02-09 16:17:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 16:17:44 --> Calendar Class Initialized
INFO - 2022-02-09 16:17:44 --> Model "Login_model" initialized
INFO - 2022-02-09 16:17:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 16:17:44 --> Final output sent to browser
DEBUG - 2022-02-09 16:17:44 --> Total execution time: 0.0233
ERROR - 2022-02-09 22:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-09 22:50:36 --> Config Class Initialized
INFO - 2022-02-09 22:50:36 --> Hooks Class Initialized
DEBUG - 2022-02-09 22:50:36 --> UTF-8 Support Enabled
INFO - 2022-02-09 22:50:36 --> Utf8 Class Initialized
INFO - 2022-02-09 22:50:36 --> URI Class Initialized
DEBUG - 2022-02-09 22:50:36 --> No URI present. Default controller set.
INFO - 2022-02-09 22:50:36 --> Router Class Initialized
INFO - 2022-02-09 22:50:36 --> Output Class Initialized
INFO - 2022-02-09 22:50:36 --> Security Class Initialized
DEBUG - 2022-02-09 22:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-09 22:50:36 --> Input Class Initialized
INFO - 2022-02-09 22:50:36 --> Language Class Initialized
INFO - 2022-02-09 22:50:36 --> Loader Class Initialized
INFO - 2022-02-09 22:50:36 --> Helper loaded: url_helper
INFO - 2022-02-09 22:50:36 --> Helper loaded: form_helper
INFO - 2022-02-09 22:50:36 --> Helper loaded: common_helper
INFO - 2022-02-09 22:50:36 --> Database Driver Class Initialized
DEBUG - 2022-02-09 22:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-09 22:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-09 22:50:36 --> Controller Class Initialized
INFO - 2022-02-09 22:50:36 --> Form Validation Class Initialized
DEBUG - 2022-02-09 22:50:36 --> Encrypt Class Initialized
DEBUG - 2022-02-09 22:50:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 22:50:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-09 22:50:36 --> Email Class Initialized
INFO - 2022-02-09 22:50:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-09 22:50:36 --> Calendar Class Initialized
INFO - 2022-02-09 22:50:36 --> Model "Login_model" initialized
INFO - 2022-02-09 22:50:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-09 22:50:36 --> Final output sent to browser
DEBUG - 2022-02-09 22:50:36 --> Total execution time: 0.0315
