<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-10 01:57:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-08-10 01:57:14 --> Config Class Initialized
INFO - 2021-08-10 01:57:14 --> Hooks Class Initialized
DEBUG - 2021-08-10 01:57:14 --> UTF-8 Support Enabled
INFO - 2021-08-10 01:57:14 --> Utf8 Class Initialized
INFO - 2021-08-10 01:57:14 --> URI Class Initialized
DEBUG - 2021-08-10 01:57:14 --> No URI present. Default controller set.
INFO - 2021-08-10 01:57:14 --> Router Class Initialized
INFO - 2021-08-10 01:57:14 --> Output Class Initialized
INFO - 2021-08-10 01:57:14 --> Security Class Initialized
DEBUG - 2021-08-10 01:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 01:57:14 --> Input Class Initialized
INFO - 2021-08-10 01:57:14 --> Language Class Initialized
INFO - 2021-08-10 01:57:14 --> Loader Class Initialized
INFO - 2021-08-10 01:57:14 --> Helper loaded: url_helper
INFO - 2021-08-10 01:57:14 --> Helper loaded: form_helper
INFO - 2021-08-10 01:57:14 --> Helper loaded: common_helper
INFO - 2021-08-10 01:57:14 --> Database Driver Class Initialized
DEBUG - 2021-08-10 01:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 01:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 01:57:14 --> Controller Class Initialized
INFO - 2021-08-10 01:57:14 --> Form Validation Class Initialized
DEBUG - 2021-08-10 01:57:14 --> Encrypt Class Initialized
DEBUG - 2021-08-10 01:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-08-10 01:57:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-08-10 01:57:14 --> Email Class Initialized
INFO - 2021-08-10 01:57:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-08-10 01:57:14 --> Calendar Class Initialized
INFO - 2021-08-10 01:57:14 --> Model "Login_model" initialized
INFO - 2021-08-10 01:57:14 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-08-10 01:57:14 --> Final output sent to browser
DEBUG - 2021-08-10 01:57:14 --> Total execution time: 0.0408
