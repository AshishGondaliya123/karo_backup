<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-03 06:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 06:23:53 --> Config Class Initialized
INFO - 2022-03-03 06:23:53 --> Hooks Class Initialized
DEBUG - 2022-03-03 06:23:53 --> UTF-8 Support Enabled
INFO - 2022-03-03 06:23:53 --> Utf8 Class Initialized
INFO - 2022-03-03 06:23:53 --> URI Class Initialized
DEBUG - 2022-03-03 06:23:53 --> No URI present. Default controller set.
INFO - 2022-03-03 06:23:53 --> Router Class Initialized
INFO - 2022-03-03 06:23:53 --> Output Class Initialized
INFO - 2022-03-03 06:23:53 --> Security Class Initialized
DEBUG - 2022-03-03 06:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 06:23:53 --> Input Class Initialized
INFO - 2022-03-03 06:23:53 --> Language Class Initialized
INFO - 2022-03-03 06:23:53 --> Loader Class Initialized
INFO - 2022-03-03 06:23:53 --> Helper loaded: url_helper
INFO - 2022-03-03 06:23:53 --> Helper loaded: form_helper
INFO - 2022-03-03 06:23:53 --> Helper loaded: common_helper
INFO - 2022-03-03 06:23:53 --> Database Driver Class Initialized
DEBUG - 2022-03-03 06:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 06:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 06:23:53 --> Controller Class Initialized
INFO - 2022-03-03 06:23:53 --> Form Validation Class Initialized
DEBUG - 2022-03-03 06:23:53 --> Encrypt Class Initialized
DEBUG - 2022-03-03 06:23:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 06:23:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 06:23:53 --> Email Class Initialized
INFO - 2022-03-03 06:23:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 06:23:53 --> Calendar Class Initialized
INFO - 2022-03-03 06:23:53 --> Model "Login_model" initialized
INFO - 2022-03-03 06:23:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-03 06:23:53 --> Final output sent to browser
DEBUG - 2022-03-03 06:23:53 --> Total execution time: 0.1880
ERROR - 2022-03-03 07:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 07:55:49 --> Config Class Initialized
INFO - 2022-03-03 07:55:49 --> Hooks Class Initialized
DEBUG - 2022-03-03 07:55:49 --> UTF-8 Support Enabled
INFO - 2022-03-03 07:55:49 --> Utf8 Class Initialized
INFO - 2022-03-03 07:55:49 --> URI Class Initialized
DEBUG - 2022-03-03 07:55:49 --> No URI present. Default controller set.
INFO - 2022-03-03 07:55:49 --> Router Class Initialized
INFO - 2022-03-03 07:55:49 --> Output Class Initialized
INFO - 2022-03-03 07:55:49 --> Security Class Initialized
DEBUG - 2022-03-03 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 07:55:49 --> Input Class Initialized
INFO - 2022-03-03 07:55:49 --> Language Class Initialized
INFO - 2022-03-03 07:55:49 --> Loader Class Initialized
INFO - 2022-03-03 07:55:49 --> Helper loaded: url_helper
INFO - 2022-03-03 07:55:49 --> Helper loaded: form_helper
INFO - 2022-03-03 07:55:49 --> Helper loaded: common_helper
INFO - 2022-03-03 07:55:49 --> Database Driver Class Initialized
DEBUG - 2022-03-03 07:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 07:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 07:55:49 --> Controller Class Initialized
INFO - 2022-03-03 07:55:49 --> Form Validation Class Initialized
DEBUG - 2022-03-03 07:55:49 --> Encrypt Class Initialized
DEBUG - 2022-03-03 07:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 07:55:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 07:55:49 --> Email Class Initialized
INFO - 2022-03-03 07:55:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 07:55:49 --> Calendar Class Initialized
INFO - 2022-03-03 07:55:49 --> Model "Login_model" initialized
INFO - 2022-03-03 07:55:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-03 07:55:49 --> Final output sent to browser
DEBUG - 2022-03-03 07:55:49 --> Total execution time: 0.0237
ERROR - 2022-03-03 07:55:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 07:55:49 --> Config Class Initialized
INFO - 2022-03-03 07:55:49 --> Hooks Class Initialized
DEBUG - 2022-03-03 07:55:49 --> UTF-8 Support Enabled
INFO - 2022-03-03 07:55:49 --> Utf8 Class Initialized
INFO - 2022-03-03 07:55:49 --> URI Class Initialized
INFO - 2022-03-03 07:55:49 --> Router Class Initialized
INFO - 2022-03-03 07:55:49 --> Output Class Initialized
INFO - 2022-03-03 07:55:49 --> Security Class Initialized
DEBUG - 2022-03-03 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 07:55:49 --> Input Class Initialized
INFO - 2022-03-03 07:55:49 --> Language Class Initialized
ERROR - 2022-03-03 07:55:49 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-03-03 10:48:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 10:48:52 --> Config Class Initialized
INFO - 2022-03-03 10:48:52 --> Hooks Class Initialized
DEBUG - 2022-03-03 10:48:52 --> UTF-8 Support Enabled
INFO - 2022-03-03 10:48:52 --> Utf8 Class Initialized
INFO - 2022-03-03 10:48:52 --> URI Class Initialized
DEBUG - 2022-03-03 10:48:52 --> No URI present. Default controller set.
INFO - 2022-03-03 10:48:52 --> Router Class Initialized
INFO - 2022-03-03 10:48:52 --> Output Class Initialized
INFO - 2022-03-03 10:48:52 --> Security Class Initialized
DEBUG - 2022-03-03 10:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 10:48:52 --> Input Class Initialized
INFO - 2022-03-03 10:48:52 --> Language Class Initialized
INFO - 2022-03-03 10:48:52 --> Loader Class Initialized
INFO - 2022-03-03 10:48:52 --> Helper loaded: url_helper
INFO - 2022-03-03 10:48:52 --> Helper loaded: form_helper
INFO - 2022-03-03 10:48:52 --> Helper loaded: common_helper
INFO - 2022-03-03 10:48:52 --> Database Driver Class Initialized
DEBUG - 2022-03-03 10:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 10:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 10:48:52 --> Controller Class Initialized
INFO - 2022-03-03 10:48:52 --> Form Validation Class Initialized
DEBUG - 2022-03-03 10:48:52 --> Encrypt Class Initialized
DEBUG - 2022-03-03 10:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 10:48:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 10:48:52 --> Email Class Initialized
INFO - 2022-03-03 10:48:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 10:48:52 --> Calendar Class Initialized
INFO - 2022-03-03 10:48:52 --> Model "Login_model" initialized
INFO - 2022-03-03 10:48:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-03 10:48:52 --> Final output sent to browser
DEBUG - 2022-03-03 10:48:52 --> Total execution time: 0.0437
ERROR - 2022-03-03 14:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 14:20:37 --> Config Class Initialized
INFO - 2022-03-03 14:20:37 --> Hooks Class Initialized
DEBUG - 2022-03-03 14:20:37 --> UTF-8 Support Enabled
INFO - 2022-03-03 14:20:37 --> Utf8 Class Initialized
INFO - 2022-03-03 14:20:37 --> URI Class Initialized
DEBUG - 2022-03-03 14:20:37 --> No URI present. Default controller set.
INFO - 2022-03-03 14:20:37 --> Router Class Initialized
INFO - 2022-03-03 14:20:37 --> Output Class Initialized
INFO - 2022-03-03 14:20:37 --> Security Class Initialized
DEBUG - 2022-03-03 14:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 14:20:37 --> Input Class Initialized
INFO - 2022-03-03 14:20:37 --> Language Class Initialized
INFO - 2022-03-03 14:20:37 --> Loader Class Initialized
INFO - 2022-03-03 14:20:37 --> Helper loaded: url_helper
INFO - 2022-03-03 14:20:37 --> Helper loaded: form_helper
INFO - 2022-03-03 14:20:37 --> Helper loaded: common_helper
INFO - 2022-03-03 14:20:37 --> Database Driver Class Initialized
DEBUG - 2022-03-03 14:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 14:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 14:20:37 --> Controller Class Initialized
INFO - 2022-03-03 14:20:37 --> Form Validation Class Initialized
DEBUG - 2022-03-03 14:20:37 --> Encrypt Class Initialized
DEBUG - 2022-03-03 14:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 14:20:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 14:20:37 --> Email Class Initialized
INFO - 2022-03-03 14:20:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 14:20:37 --> Calendar Class Initialized
INFO - 2022-03-03 14:20:37 --> Model "Login_model" initialized
INFO - 2022-03-03 14:20:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-03 14:20:37 --> Final output sent to browser
DEBUG - 2022-03-03 14:20:37 --> Total execution time: 0.0301
ERROR - 2022-03-03 14:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 14:20:37 --> Config Class Initialized
INFO - 2022-03-03 14:20:37 --> Hooks Class Initialized
DEBUG - 2022-03-03 14:20:37 --> UTF-8 Support Enabled
INFO - 2022-03-03 14:20:37 --> Utf8 Class Initialized
INFO - 2022-03-03 14:20:37 --> URI Class Initialized
INFO - 2022-03-03 14:20:37 --> Router Class Initialized
INFO - 2022-03-03 14:20:37 --> Output Class Initialized
INFO - 2022-03-03 14:20:37 --> Security Class Initialized
DEBUG - 2022-03-03 14:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 14:20:37 --> Input Class Initialized
INFO - 2022-03-03 14:20:37 --> Language Class Initialized
ERROR - 2022-03-03 14:20:37 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-03 14:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 14:21:09 --> Config Class Initialized
INFO - 2022-03-03 14:21:09 --> Hooks Class Initialized
DEBUG - 2022-03-03 14:21:09 --> UTF-8 Support Enabled
INFO - 2022-03-03 14:21:09 --> Utf8 Class Initialized
INFO - 2022-03-03 14:21:09 --> URI Class Initialized
INFO - 2022-03-03 14:21:09 --> Router Class Initialized
INFO - 2022-03-03 14:21:09 --> Output Class Initialized
INFO - 2022-03-03 14:21:09 --> Security Class Initialized
DEBUG - 2022-03-03 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 14:21:09 --> Input Class Initialized
INFO - 2022-03-03 14:21:09 --> Language Class Initialized
INFO - 2022-03-03 14:21:09 --> Loader Class Initialized
INFO - 2022-03-03 14:21:09 --> Helper loaded: url_helper
INFO - 2022-03-03 14:21:09 --> Helper loaded: form_helper
INFO - 2022-03-03 14:21:09 --> Helper loaded: common_helper
INFO - 2022-03-03 14:21:09 --> Database Driver Class Initialized
DEBUG - 2022-03-03 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 14:21:09 --> Controller Class Initialized
INFO - 2022-03-03 14:21:09 --> Form Validation Class Initialized
DEBUG - 2022-03-03 14:21:09 --> Encrypt Class Initialized
DEBUG - 2022-03-03 14:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 14:21:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 14:21:09 --> Email Class Initialized
INFO - 2022-03-03 14:21:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 14:21:09 --> Calendar Class Initialized
INFO - 2022-03-03 14:21:09 --> Model "Login_model" initialized
ERROR - 2022-03-03 14:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 14:21:09 --> Config Class Initialized
INFO - 2022-03-03 14:21:09 --> Hooks Class Initialized
DEBUG - 2022-03-03 14:21:09 --> UTF-8 Support Enabled
INFO - 2022-03-03 14:21:09 --> Utf8 Class Initialized
INFO - 2022-03-03 14:21:09 --> URI Class Initialized
INFO - 2022-03-03 14:21:09 --> Router Class Initialized
INFO - 2022-03-03 14:21:09 --> Output Class Initialized
INFO - 2022-03-03 14:21:09 --> Security Class Initialized
DEBUG - 2022-03-03 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 14:21:09 --> Input Class Initialized
INFO - 2022-03-03 14:21:09 --> Language Class Initialized
INFO - 2022-03-03 14:21:09 --> Loader Class Initialized
INFO - 2022-03-03 14:21:09 --> Helper loaded: url_helper
INFO - 2022-03-03 14:21:09 --> Helper loaded: form_helper
INFO - 2022-03-03 14:21:09 --> Helper loaded: common_helper
INFO - 2022-03-03 14:21:09 --> Database Driver Class Initialized
DEBUG - 2022-03-03 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 14:21:09 --> Controller Class Initialized
INFO - 2022-03-03 14:21:09 --> Form Validation Class Initialized
DEBUG - 2022-03-03 14:21:09 --> Encrypt Class Initialized
DEBUG - 2022-03-03 14:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 14:21:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 14:21:09 --> Email Class Initialized
INFO - 2022-03-03 14:21:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 14:21:09 --> Calendar Class Initialized
INFO - 2022-03-03 14:21:09 --> Model "Login_model" initialized
ERROR - 2022-03-03 14:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 14:21:10 --> Config Class Initialized
INFO - 2022-03-03 14:21:10 --> Hooks Class Initialized
DEBUG - 2022-03-03 14:21:10 --> UTF-8 Support Enabled
INFO - 2022-03-03 14:21:10 --> Utf8 Class Initialized
INFO - 2022-03-03 14:21:10 --> URI Class Initialized
DEBUG - 2022-03-03 14:21:10 --> No URI present. Default controller set.
INFO - 2022-03-03 14:21:10 --> Router Class Initialized
INFO - 2022-03-03 14:21:10 --> Output Class Initialized
INFO - 2022-03-03 14:21:10 --> Security Class Initialized
DEBUG - 2022-03-03 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 14:21:10 --> Input Class Initialized
INFO - 2022-03-03 14:21:10 --> Language Class Initialized
INFO - 2022-03-03 14:21:10 --> Loader Class Initialized
INFO - 2022-03-03 14:21:10 --> Helper loaded: url_helper
INFO - 2022-03-03 14:21:10 --> Helper loaded: form_helper
INFO - 2022-03-03 14:21:10 --> Helper loaded: common_helper
INFO - 2022-03-03 14:21:10 --> Database Driver Class Initialized
DEBUG - 2022-03-03 14:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 14:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 14:21:10 --> Controller Class Initialized
INFO - 2022-03-03 14:21:10 --> Form Validation Class Initialized
DEBUG - 2022-03-03 14:21:10 --> Encrypt Class Initialized
DEBUG - 2022-03-03 14:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 14:21:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 14:21:10 --> Email Class Initialized
INFO - 2022-03-03 14:21:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 14:21:10 --> Calendar Class Initialized
INFO - 2022-03-03 14:21:10 --> Model "Login_model" initialized
INFO - 2022-03-03 14:21:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-03 14:21:10 --> Final output sent to browser
DEBUG - 2022-03-03 14:21:10 --> Total execution time: 0.0211
ERROR - 2022-03-03 14:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 14:21:11 --> Config Class Initialized
INFO - 2022-03-03 14:21:11 --> Hooks Class Initialized
DEBUG - 2022-03-03 14:21:11 --> UTF-8 Support Enabled
INFO - 2022-03-03 14:21:11 --> Utf8 Class Initialized
INFO - 2022-03-03 14:21:11 --> URI Class Initialized
INFO - 2022-03-03 14:21:11 --> Router Class Initialized
INFO - 2022-03-03 14:21:11 --> Output Class Initialized
INFO - 2022-03-03 14:21:11 --> Security Class Initialized
DEBUG - 2022-03-03 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 14:21:11 --> Input Class Initialized
INFO - 2022-03-03 14:21:11 --> Language Class Initialized
INFO - 2022-03-03 14:21:11 --> Loader Class Initialized
INFO - 2022-03-03 14:21:11 --> Helper loaded: url_helper
INFO - 2022-03-03 14:21:11 --> Helper loaded: form_helper
INFO - 2022-03-03 14:21:11 --> Helper loaded: common_helper
INFO - 2022-03-03 14:21:11 --> Database Driver Class Initialized
DEBUG - 2022-03-03 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 14:21:11 --> Controller Class Initialized
INFO - 2022-03-03 14:21:11 --> Form Validation Class Initialized
DEBUG - 2022-03-03 14:21:11 --> Encrypt Class Initialized
DEBUG - 2022-03-03 14:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 14:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 14:21:11 --> Email Class Initialized
INFO - 2022-03-03 14:21:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 14:21:11 --> Calendar Class Initialized
INFO - 2022-03-03 14:21:11 --> Model "Login_model" initialized
INFO - 2022-03-03 14:21:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-03 14:21:11 --> Final output sent to browser
DEBUG - 2022-03-03 14:21:11 --> Total execution time: 0.0350
ERROR - 2022-03-03 15:38:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 15:38:28 --> Config Class Initialized
INFO - 2022-03-03 15:38:28 --> Hooks Class Initialized
DEBUG - 2022-03-03 15:38:28 --> UTF-8 Support Enabled
INFO - 2022-03-03 15:38:28 --> Utf8 Class Initialized
INFO - 2022-03-03 15:38:28 --> URI Class Initialized
DEBUG - 2022-03-03 15:38:28 --> No URI present. Default controller set.
INFO - 2022-03-03 15:38:28 --> Router Class Initialized
INFO - 2022-03-03 15:38:28 --> Output Class Initialized
INFO - 2022-03-03 15:38:28 --> Security Class Initialized
DEBUG - 2022-03-03 15:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 15:38:28 --> Input Class Initialized
INFO - 2022-03-03 15:38:28 --> Language Class Initialized
INFO - 2022-03-03 15:38:28 --> Loader Class Initialized
INFO - 2022-03-03 15:38:28 --> Helper loaded: url_helper
INFO - 2022-03-03 15:38:28 --> Helper loaded: form_helper
INFO - 2022-03-03 15:38:28 --> Helper loaded: common_helper
INFO - 2022-03-03 15:38:28 --> Database Driver Class Initialized
DEBUG - 2022-03-03 15:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 15:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 15:38:28 --> Controller Class Initialized
INFO - 2022-03-03 15:38:28 --> Form Validation Class Initialized
DEBUG - 2022-03-03 15:38:28 --> Encrypt Class Initialized
DEBUG - 2022-03-03 15:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 15:38:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 15:38:28 --> Email Class Initialized
INFO - 2022-03-03 15:38:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 15:38:28 --> Calendar Class Initialized
INFO - 2022-03-03 15:38:28 --> Model "Login_model" initialized
INFO - 2022-03-03 15:38:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-03 15:38:28 --> Final output sent to browser
DEBUG - 2022-03-03 15:38:28 --> Total execution time: 0.0294
ERROR - 2022-03-03 16:27:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-03 16:27:36 --> Config Class Initialized
INFO - 2022-03-03 16:27:36 --> Hooks Class Initialized
DEBUG - 2022-03-03 16:27:36 --> UTF-8 Support Enabled
INFO - 2022-03-03 16:27:36 --> Utf8 Class Initialized
INFO - 2022-03-03 16:27:36 --> URI Class Initialized
DEBUG - 2022-03-03 16:27:36 --> No URI present. Default controller set.
INFO - 2022-03-03 16:27:36 --> Router Class Initialized
INFO - 2022-03-03 16:27:36 --> Output Class Initialized
INFO - 2022-03-03 16:27:36 --> Security Class Initialized
DEBUG - 2022-03-03 16:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-03 16:27:36 --> Input Class Initialized
INFO - 2022-03-03 16:27:36 --> Language Class Initialized
INFO - 2022-03-03 16:27:36 --> Loader Class Initialized
INFO - 2022-03-03 16:27:36 --> Helper loaded: url_helper
INFO - 2022-03-03 16:27:36 --> Helper loaded: form_helper
INFO - 2022-03-03 16:27:36 --> Helper loaded: common_helper
INFO - 2022-03-03 16:27:36 --> Database Driver Class Initialized
DEBUG - 2022-03-03 16:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-03 16:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-03 16:27:36 --> Controller Class Initialized
INFO - 2022-03-03 16:27:36 --> Form Validation Class Initialized
DEBUG - 2022-03-03 16:27:36 --> Encrypt Class Initialized
DEBUG - 2022-03-03 16:27:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-03 16:27:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-03 16:27:36 --> Email Class Initialized
INFO - 2022-03-03 16:27:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-03 16:27:36 --> Calendar Class Initialized
INFO - 2022-03-03 16:27:36 --> Model "Login_model" initialized
INFO - 2022-03-03 16:27:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-03 16:27:36 --> Final output sent to browser
DEBUG - 2022-03-03 16:27:36 --> Total execution time: 0.0290
