<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-04 04:55:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 04:55:46 --> Config Class Initialized
INFO - 2021-10-04 04:55:46 --> Hooks Class Initialized
DEBUG - 2021-10-04 04:55:46 --> UTF-8 Support Enabled
INFO - 2021-10-04 04:55:46 --> Utf8 Class Initialized
INFO - 2021-10-04 04:55:46 --> URI Class Initialized
DEBUG - 2021-10-04 04:55:46 --> No URI present. Default controller set.
INFO - 2021-10-04 04:55:46 --> Router Class Initialized
INFO - 2021-10-04 04:55:46 --> Output Class Initialized
INFO - 2021-10-04 04:55:46 --> Security Class Initialized
DEBUG - 2021-10-04 04:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 04:55:46 --> Input Class Initialized
INFO - 2021-10-04 04:55:46 --> Language Class Initialized
INFO - 2021-10-04 04:55:46 --> Loader Class Initialized
INFO - 2021-10-04 04:55:46 --> Helper loaded: url_helper
INFO - 2021-10-04 04:55:46 --> Helper loaded: form_helper
INFO - 2021-10-04 04:55:46 --> Helper loaded: common_helper
INFO - 2021-10-04 04:55:46 --> Database Driver Class Initialized
DEBUG - 2021-10-04 04:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-04 04:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-04 04:55:46 --> Controller Class Initialized
INFO - 2021-10-04 04:55:46 --> Form Validation Class Initialized
DEBUG - 2021-10-04 04:55:46 --> Encrypt Class Initialized
DEBUG - 2021-10-04 04:55:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-04 04:55:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-04 04:55:46 --> Email Class Initialized
INFO - 2021-10-04 04:55:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-04 04:55:46 --> Calendar Class Initialized
INFO - 2021-10-04 04:55:46 --> Model "Login_model" initialized
INFO - 2021-10-04 04:55:46 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-04 04:55:46 --> Final output sent to browser
DEBUG - 2021-10-04 04:55:46 --> Total execution time: 0.0557
ERROR - 2021-10-04 07:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 07:59:58 --> Config Class Initialized
INFO - 2021-10-04 07:59:58 --> Hooks Class Initialized
DEBUG - 2021-10-04 07:59:58 --> UTF-8 Support Enabled
INFO - 2021-10-04 07:59:58 --> Utf8 Class Initialized
INFO - 2021-10-04 07:59:58 --> URI Class Initialized
DEBUG - 2021-10-04 07:59:58 --> No URI present. Default controller set.
INFO - 2021-10-04 07:59:58 --> Router Class Initialized
INFO - 2021-10-04 07:59:58 --> Output Class Initialized
INFO - 2021-10-04 07:59:58 --> Security Class Initialized
DEBUG - 2021-10-04 07:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 07:59:58 --> Input Class Initialized
INFO - 2021-10-04 07:59:58 --> Language Class Initialized
INFO - 2021-10-04 07:59:58 --> Loader Class Initialized
INFO - 2021-10-04 07:59:58 --> Helper loaded: url_helper
INFO - 2021-10-04 07:59:58 --> Helper loaded: form_helper
INFO - 2021-10-04 07:59:58 --> Helper loaded: common_helper
INFO - 2021-10-04 07:59:58 --> Database Driver Class Initialized
DEBUG - 2021-10-04 07:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-04 07:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-04 07:59:58 --> Controller Class Initialized
INFO - 2021-10-04 07:59:58 --> Form Validation Class Initialized
DEBUG - 2021-10-04 07:59:58 --> Encrypt Class Initialized
DEBUG - 2021-10-04 07:59:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-04 07:59:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-04 07:59:58 --> Email Class Initialized
INFO - 2021-10-04 07:59:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-04 07:59:58 --> Calendar Class Initialized
INFO - 2021-10-04 07:59:58 --> Model "Login_model" initialized
INFO - 2021-10-04 07:59:58 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-04 07:59:58 --> Final output sent to browser
DEBUG - 2021-10-04 07:59:58 --> Total execution time: 0.0530
ERROR - 2021-10-04 07:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 07:59:58 --> Config Class Initialized
INFO - 2021-10-04 07:59:58 --> Hooks Class Initialized
DEBUG - 2021-10-04 07:59:58 --> UTF-8 Support Enabled
INFO - 2021-10-04 07:59:58 --> Utf8 Class Initialized
INFO - 2021-10-04 07:59:58 --> URI Class Initialized
INFO - 2021-10-04 07:59:58 --> Router Class Initialized
INFO - 2021-10-04 07:59:58 --> Output Class Initialized
INFO - 2021-10-04 07:59:58 --> Security Class Initialized
DEBUG - 2021-10-04 07:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 07:59:58 --> Input Class Initialized
INFO - 2021-10-04 07:59:58 --> Language Class Initialized
ERROR - 2021-10-04 07:59:58 --> 404 Page Not Found: Blog/index
ERROR - 2021-10-04 07:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 07:59:58 --> Config Class Initialized
INFO - 2021-10-04 07:59:58 --> Hooks Class Initialized
DEBUG - 2021-10-04 07:59:58 --> UTF-8 Support Enabled
INFO - 2021-10-04 07:59:58 --> Utf8 Class Initialized
INFO - 2021-10-04 07:59:58 --> URI Class Initialized
INFO - 2021-10-04 07:59:58 --> Router Class Initialized
INFO - 2021-10-04 07:59:58 --> Output Class Initialized
INFO - 2021-10-04 07:59:58 --> Security Class Initialized
DEBUG - 2021-10-04 07:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 07:59:58 --> Input Class Initialized
INFO - 2021-10-04 07:59:58 --> Language Class Initialized
ERROR - 2021-10-04 07:59:58 --> 404 Page Not Found: Wp/index
ERROR - 2021-10-04 07:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 07:59:59 --> Config Class Initialized
INFO - 2021-10-04 07:59:59 --> Hooks Class Initialized
DEBUG - 2021-10-04 07:59:59 --> UTF-8 Support Enabled
INFO - 2021-10-04 07:59:59 --> Utf8 Class Initialized
INFO - 2021-10-04 07:59:59 --> URI Class Initialized
INFO - 2021-10-04 07:59:59 --> Router Class Initialized
INFO - 2021-10-04 07:59:59 --> Output Class Initialized
INFO - 2021-10-04 07:59:59 --> Security Class Initialized
DEBUG - 2021-10-04 07:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 07:59:59 --> Input Class Initialized
INFO - 2021-10-04 07:59:59 --> Language Class Initialized
ERROR - 2021-10-04 07:59:59 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-10-04 07:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 07:59:59 --> Config Class Initialized
INFO - 2021-10-04 07:59:59 --> Hooks Class Initialized
DEBUG - 2021-10-04 07:59:59 --> UTF-8 Support Enabled
INFO - 2021-10-04 07:59:59 --> Utf8 Class Initialized
INFO - 2021-10-04 07:59:59 --> URI Class Initialized
INFO - 2021-10-04 07:59:59 --> Router Class Initialized
INFO - 2021-10-04 07:59:59 --> Output Class Initialized
INFO - 2021-10-04 07:59:59 --> Security Class Initialized
DEBUG - 2021-10-04 07:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 07:59:59 --> Input Class Initialized
INFO - 2021-10-04 07:59:59 --> Language Class Initialized
ERROR - 2021-10-04 07:59:59 --> 404 Page Not Found: New/index
ERROR - 2021-10-04 07:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 07:59:59 --> Config Class Initialized
INFO - 2021-10-04 07:59:59 --> Hooks Class Initialized
DEBUG - 2021-10-04 07:59:59 --> UTF-8 Support Enabled
INFO - 2021-10-04 07:59:59 --> Utf8 Class Initialized
INFO - 2021-10-04 07:59:59 --> URI Class Initialized
INFO - 2021-10-04 07:59:59 --> Router Class Initialized
INFO - 2021-10-04 07:59:59 --> Output Class Initialized
INFO - 2021-10-04 07:59:59 --> Security Class Initialized
DEBUG - 2021-10-04 07:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 07:59:59 --> Input Class Initialized
INFO - 2021-10-04 07:59:59 --> Language Class Initialized
ERROR - 2021-10-04 07:59:59 --> 404 Page Not Found: Old/index
ERROR - 2021-10-04 08:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:00 --> Config Class Initialized
INFO - 2021-10-04 08:00:00 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:00 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:00 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:00 --> URI Class Initialized
INFO - 2021-10-04 08:00:00 --> Router Class Initialized
INFO - 2021-10-04 08:00:00 --> Output Class Initialized
INFO - 2021-10-04 08:00:00 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:00 --> Input Class Initialized
INFO - 2021-10-04 08:00:00 --> Language Class Initialized
ERROR - 2021-10-04 08:00:00 --> 404 Page Not Found: Test/index
ERROR - 2021-10-04 08:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:00 --> Config Class Initialized
INFO - 2021-10-04 08:00:00 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:00 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:00 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:00 --> URI Class Initialized
INFO - 2021-10-04 08:00:00 --> Router Class Initialized
INFO - 2021-10-04 08:00:00 --> Output Class Initialized
INFO - 2021-10-04 08:00:00 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:00 --> Input Class Initialized
INFO - 2021-10-04 08:00:00 --> Language Class Initialized
ERROR - 2021-10-04 08:00:00 --> 404 Page Not Found: Main/index
ERROR - 2021-10-04 08:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:00 --> Config Class Initialized
INFO - 2021-10-04 08:00:00 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:00 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:00 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:00 --> URI Class Initialized
INFO - 2021-10-04 08:00:00 --> Router Class Initialized
INFO - 2021-10-04 08:00:00 --> Output Class Initialized
INFO - 2021-10-04 08:00:00 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:00 --> Input Class Initialized
INFO - 2021-10-04 08:00:00 --> Language Class Initialized
ERROR - 2021-10-04 08:00:00 --> 404 Page Not Found: Site/index
ERROR - 2021-10-04 08:00:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:01 --> Config Class Initialized
INFO - 2021-10-04 08:00:01 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:01 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:01 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:01 --> URI Class Initialized
INFO - 2021-10-04 08:00:01 --> Router Class Initialized
INFO - 2021-10-04 08:00:01 --> Output Class Initialized
INFO - 2021-10-04 08:00:01 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:01 --> Input Class Initialized
INFO - 2021-10-04 08:00:01 --> Language Class Initialized
ERROR - 2021-10-04 08:00:01 --> 404 Page Not Found: Backup/index
ERROR - 2021-10-04 08:00:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:01 --> Config Class Initialized
INFO - 2021-10-04 08:00:01 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:01 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:01 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:01 --> URI Class Initialized
INFO - 2021-10-04 08:00:01 --> Router Class Initialized
INFO - 2021-10-04 08:00:01 --> Output Class Initialized
INFO - 2021-10-04 08:00:01 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:01 --> Input Class Initialized
INFO - 2021-10-04 08:00:01 --> Language Class Initialized
ERROR - 2021-10-04 08:00:01 --> 404 Page Not Found: Demo/index
ERROR - 2021-10-04 08:00:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:03 --> Config Class Initialized
INFO - 2021-10-04 08:00:03 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:03 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:03 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:03 --> URI Class Initialized
INFO - 2021-10-04 08:00:03 --> Router Class Initialized
INFO - 2021-10-04 08:00:03 --> Output Class Initialized
INFO - 2021-10-04 08:00:03 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:03 --> Input Class Initialized
INFO - 2021-10-04 08:00:03 --> Language Class Initialized
ERROR - 2021-10-04 08:00:03 --> 404 Page Not Found: Home/index
ERROR - 2021-10-04 08:00:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:03 --> Config Class Initialized
INFO - 2021-10-04 08:00:03 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:03 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:03 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:03 --> URI Class Initialized
INFO - 2021-10-04 08:00:03 --> Router Class Initialized
INFO - 2021-10-04 08:00:03 --> Output Class Initialized
INFO - 2021-10-04 08:00:03 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:03 --> Input Class Initialized
INFO - 2021-10-04 08:00:03 --> Language Class Initialized
ERROR - 2021-10-04 08:00:03 --> 404 Page Not Found: Tmp/index
ERROR - 2021-10-04 08:00:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:04 --> Config Class Initialized
INFO - 2021-10-04 08:00:04 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:04 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:04 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:04 --> URI Class Initialized
INFO - 2021-10-04 08:00:04 --> Router Class Initialized
INFO - 2021-10-04 08:00:04 --> Output Class Initialized
INFO - 2021-10-04 08:00:04 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:04 --> Input Class Initialized
INFO - 2021-10-04 08:00:04 --> Language Class Initialized
ERROR - 2021-10-04 08:00:04 --> 404 Page Not Found: Cms/index
ERROR - 2021-10-04 08:00:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:05 --> Config Class Initialized
INFO - 2021-10-04 08:00:05 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:05 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:05 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:05 --> URI Class Initialized
INFO - 2021-10-04 08:00:05 --> Router Class Initialized
INFO - 2021-10-04 08:00:05 --> Output Class Initialized
INFO - 2021-10-04 08:00:05 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:05 --> Input Class Initialized
INFO - 2021-10-04 08:00:05 --> Language Class Initialized
ERROR - 2021-10-04 08:00:05 --> 404 Page Not Found: Dev/index
ERROR - 2021-10-04 08:00:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:05 --> Config Class Initialized
INFO - 2021-10-04 08:00:05 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:05 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:05 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:05 --> URI Class Initialized
INFO - 2021-10-04 08:00:05 --> Router Class Initialized
INFO - 2021-10-04 08:00:05 --> Output Class Initialized
INFO - 2021-10-04 08:00:05 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:05 --> Input Class Initialized
INFO - 2021-10-04 08:00:05 --> Language Class Initialized
ERROR - 2021-10-04 08:00:05 --> 404 Page Not Found: Old-wp/index
ERROR - 2021-10-04 08:00:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:06 --> Config Class Initialized
INFO - 2021-10-04 08:00:06 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:06 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:06 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:06 --> URI Class Initialized
INFO - 2021-10-04 08:00:06 --> Router Class Initialized
INFO - 2021-10-04 08:00:06 --> Output Class Initialized
INFO - 2021-10-04 08:00:06 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:06 --> Input Class Initialized
INFO - 2021-10-04 08:00:06 --> Language Class Initialized
ERROR - 2021-10-04 08:00:06 --> 404 Page Not Found: Web/index
ERROR - 2021-10-04 08:00:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:06 --> Config Class Initialized
INFO - 2021-10-04 08:00:06 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:06 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:06 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:06 --> URI Class Initialized
INFO - 2021-10-04 08:00:06 --> Router Class Initialized
INFO - 2021-10-04 08:00:06 --> Output Class Initialized
INFO - 2021-10-04 08:00:06 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:06 --> Input Class Initialized
INFO - 2021-10-04 08:00:06 --> Language Class Initialized
ERROR - 2021-10-04 08:00:06 --> 404 Page Not Found: Old-site/index
ERROR - 2021-10-04 08:00:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:07 --> Config Class Initialized
INFO - 2021-10-04 08:00:07 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:07 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:07 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:07 --> URI Class Initialized
INFO - 2021-10-04 08:00:07 --> Router Class Initialized
INFO - 2021-10-04 08:00:07 --> Output Class Initialized
INFO - 2021-10-04 08:00:07 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:07 --> Input Class Initialized
INFO - 2021-10-04 08:00:07 --> Language Class Initialized
ERROR - 2021-10-04 08:00:07 --> 404 Page Not Found: Temp/index
ERROR - 2021-10-04 08:00:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:07 --> Config Class Initialized
INFO - 2021-10-04 08:00:07 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:07 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:07 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:07 --> URI Class Initialized
INFO - 2021-10-04 08:00:07 --> Router Class Initialized
INFO - 2021-10-04 08:00:07 --> Output Class Initialized
INFO - 2021-10-04 08:00:07 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:07 --> Input Class Initialized
INFO - 2021-10-04 08:00:07 --> Language Class Initialized
ERROR - 2021-10-04 08:00:07 --> 404 Page Not Found: 2018/index
ERROR - 2021-10-04 08:00:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:07 --> Config Class Initialized
INFO - 2021-10-04 08:00:07 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:07 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:07 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:07 --> URI Class Initialized
INFO - 2021-10-04 08:00:07 --> Router Class Initialized
INFO - 2021-10-04 08:00:07 --> Output Class Initialized
INFO - 2021-10-04 08:00:07 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:07 --> Input Class Initialized
INFO - 2021-10-04 08:00:07 --> Language Class Initialized
ERROR - 2021-10-04 08:00:07 --> 404 Page Not Found: 2019/index
ERROR - 2021-10-04 08:00:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:08 --> Config Class Initialized
INFO - 2021-10-04 08:00:08 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:08 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:08 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:08 --> URI Class Initialized
INFO - 2021-10-04 08:00:08 --> Router Class Initialized
INFO - 2021-10-04 08:00:08 --> Output Class Initialized
INFO - 2021-10-04 08:00:08 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:08 --> Input Class Initialized
INFO - 2021-10-04 08:00:08 --> Language Class Initialized
ERROR - 2021-10-04 08:00:08 --> 404 Page Not Found: Bk/index
ERROR - 2021-10-04 08:00:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:08 --> Config Class Initialized
INFO - 2021-10-04 08:00:08 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:08 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:08 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:08 --> URI Class Initialized
INFO - 2021-10-04 08:00:08 --> Router Class Initialized
INFO - 2021-10-04 08:00:08 --> Output Class Initialized
INFO - 2021-10-04 08:00:08 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:08 --> Input Class Initialized
INFO - 2021-10-04 08:00:08 --> Language Class Initialized
ERROR - 2021-10-04 08:00:08 --> 404 Page Not Found: Wp1/index
ERROR - 2021-10-04 08:00:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:09 --> Config Class Initialized
INFO - 2021-10-04 08:00:09 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:09 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:09 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:09 --> URI Class Initialized
INFO - 2021-10-04 08:00:09 --> Router Class Initialized
INFO - 2021-10-04 08:00:09 --> Output Class Initialized
INFO - 2021-10-04 08:00:09 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:09 --> Input Class Initialized
INFO - 2021-10-04 08:00:09 --> Language Class Initialized
ERROR - 2021-10-04 08:00:09 --> 404 Page Not Found: Wp2/index
ERROR - 2021-10-04 08:00:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:09 --> Config Class Initialized
INFO - 2021-10-04 08:00:09 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:09 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:09 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:09 --> URI Class Initialized
INFO - 2021-10-04 08:00:09 --> Router Class Initialized
INFO - 2021-10-04 08:00:09 --> Output Class Initialized
INFO - 2021-10-04 08:00:09 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:09 --> Input Class Initialized
INFO - 2021-10-04 08:00:09 --> Language Class Initialized
ERROR - 2021-10-04 08:00:09 --> 404 Page Not Found: V1/index
ERROR - 2021-10-04 08:00:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:09 --> Config Class Initialized
INFO - 2021-10-04 08:00:09 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:09 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:09 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:09 --> URI Class Initialized
INFO - 2021-10-04 08:00:09 --> Router Class Initialized
INFO - 2021-10-04 08:00:09 --> Output Class Initialized
INFO - 2021-10-04 08:00:09 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:09 --> Input Class Initialized
INFO - 2021-10-04 08:00:09 --> Language Class Initialized
ERROR - 2021-10-04 08:00:09 --> 404 Page Not Found: V2/index
ERROR - 2021-10-04 08:00:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:10 --> Config Class Initialized
INFO - 2021-10-04 08:00:10 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:10 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:10 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:10 --> URI Class Initialized
INFO - 2021-10-04 08:00:10 --> Router Class Initialized
INFO - 2021-10-04 08:00:10 --> Output Class Initialized
INFO - 2021-10-04 08:00:10 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:10 --> Input Class Initialized
INFO - 2021-10-04 08:00:10 --> Language Class Initialized
ERROR - 2021-10-04 08:00:10 --> 404 Page Not Found: Bak/index
ERROR - 2021-10-04 08:00:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:10 --> Config Class Initialized
INFO - 2021-10-04 08:00:10 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:10 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:10 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:10 --> URI Class Initialized
INFO - 2021-10-04 08:00:10 --> Router Class Initialized
INFO - 2021-10-04 08:00:10 --> Output Class Initialized
INFO - 2021-10-04 08:00:10 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:10 --> Input Class Initialized
INFO - 2021-10-04 08:00:10 --> Language Class Initialized
ERROR - 2021-10-04 08:00:10 --> 404 Page Not Found: Install/index
ERROR - 2021-10-04 08:00:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:10 --> Config Class Initialized
INFO - 2021-10-04 08:00:10 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:10 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:10 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:10 --> URI Class Initialized
INFO - 2021-10-04 08:00:10 --> Router Class Initialized
INFO - 2021-10-04 08:00:10 --> Output Class Initialized
INFO - 2021-10-04 08:00:10 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:10 --> Input Class Initialized
INFO - 2021-10-04 08:00:10 --> Language Class Initialized
ERROR - 2021-10-04 08:00:10 --> 404 Page Not Found: 2020/index
ERROR - 2021-10-04 08:00:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:00:11 --> Config Class Initialized
INFO - 2021-10-04 08:00:11 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:00:11 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:00:11 --> Utf8 Class Initialized
INFO - 2021-10-04 08:00:11 --> URI Class Initialized
INFO - 2021-10-04 08:00:11 --> Router Class Initialized
INFO - 2021-10-04 08:00:11 --> Output Class Initialized
INFO - 2021-10-04 08:00:11 --> Security Class Initialized
DEBUG - 2021-10-04 08:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:00:11 --> Input Class Initialized
INFO - 2021-10-04 08:00:11 --> Language Class Initialized
ERROR - 2021-10-04 08:00:11 --> 404 Page Not Found: New-site/index
ERROR - 2021-10-04 08:43:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 08:43:56 --> Config Class Initialized
INFO - 2021-10-04 08:43:56 --> Hooks Class Initialized
DEBUG - 2021-10-04 08:43:56 --> UTF-8 Support Enabled
INFO - 2021-10-04 08:43:56 --> Utf8 Class Initialized
INFO - 2021-10-04 08:43:56 --> URI Class Initialized
DEBUG - 2021-10-04 08:43:56 --> No URI present. Default controller set.
INFO - 2021-10-04 08:43:56 --> Router Class Initialized
INFO - 2021-10-04 08:43:56 --> Output Class Initialized
INFO - 2021-10-04 08:43:56 --> Security Class Initialized
DEBUG - 2021-10-04 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 08:43:56 --> Input Class Initialized
INFO - 2021-10-04 08:43:56 --> Language Class Initialized
INFO - 2021-10-04 08:43:56 --> Loader Class Initialized
INFO - 2021-10-04 08:43:56 --> Helper loaded: url_helper
INFO - 2021-10-04 08:43:56 --> Helper loaded: form_helper
INFO - 2021-10-04 08:43:56 --> Helper loaded: common_helper
INFO - 2021-10-04 08:43:56 --> Database Driver Class Initialized
DEBUG - 2021-10-04 08:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-04 08:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-04 08:43:56 --> Controller Class Initialized
INFO - 2021-10-04 08:43:56 --> Form Validation Class Initialized
DEBUG - 2021-10-04 08:43:56 --> Encrypt Class Initialized
DEBUG - 2021-10-04 08:43:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-04 08:43:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-04 08:43:56 --> Email Class Initialized
INFO - 2021-10-04 08:43:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-04 08:43:56 --> Calendar Class Initialized
INFO - 2021-10-04 08:43:56 --> Model "Login_model" initialized
INFO - 2021-10-04 08:43:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-04 08:43:56 --> Final output sent to browser
DEBUG - 2021-10-04 08:43:56 --> Total execution time: 0.0577
ERROR - 2021-10-04 09:02:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-04 09:02:29 --> Config Class Initialized
INFO - 2021-10-04 09:02:29 --> Hooks Class Initialized
DEBUG - 2021-10-04 09:02:29 --> UTF-8 Support Enabled
INFO - 2021-10-04 09:02:29 --> Utf8 Class Initialized
INFO - 2021-10-04 09:02:29 --> URI Class Initialized
DEBUG - 2021-10-04 09:02:29 --> No URI present. Default controller set.
INFO - 2021-10-04 09:02:29 --> Router Class Initialized
INFO - 2021-10-04 09:02:29 --> Output Class Initialized
INFO - 2021-10-04 09:02:29 --> Security Class Initialized
DEBUG - 2021-10-04 09:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-04 09:02:29 --> Input Class Initialized
INFO - 2021-10-04 09:02:29 --> Language Class Initialized
INFO - 2021-10-04 09:02:29 --> Loader Class Initialized
INFO - 2021-10-04 09:02:29 --> Helper loaded: url_helper
INFO - 2021-10-04 09:02:29 --> Helper loaded: form_helper
INFO - 2021-10-04 09:02:29 --> Helper loaded: common_helper
INFO - 2021-10-04 09:02:29 --> Database Driver Class Initialized
DEBUG - 2021-10-04 09:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-04 09:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-04 09:02:29 --> Controller Class Initialized
INFO - 2021-10-04 09:02:29 --> Form Validation Class Initialized
DEBUG - 2021-10-04 09:02:29 --> Encrypt Class Initialized
DEBUG - 2021-10-04 09:02:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-04 09:02:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-04 09:02:29 --> Email Class Initialized
INFO - 2021-10-04 09:02:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-04 09:02:29 --> Calendar Class Initialized
INFO - 2021-10-04 09:02:29 --> Model "Login_model" initialized
INFO - 2021-10-04 09:02:29 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-04 09:02:29 --> Final output sent to browser
DEBUG - 2021-10-04 09:02:29 --> Total execution time: 0.0461
