<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-13 02:55:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 02:55:55 --> Config Class Initialized
INFO - 2022-01-13 02:55:55 --> Hooks Class Initialized
DEBUG - 2022-01-13 02:55:55 --> UTF-8 Support Enabled
INFO - 2022-01-13 02:55:55 --> Utf8 Class Initialized
INFO - 2022-01-13 02:55:55 --> URI Class Initialized
DEBUG - 2022-01-13 02:55:55 --> No URI present. Default controller set.
INFO - 2022-01-13 02:55:55 --> Router Class Initialized
INFO - 2022-01-13 02:55:55 --> Output Class Initialized
INFO - 2022-01-13 02:55:55 --> Security Class Initialized
DEBUG - 2022-01-13 02:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 02:55:55 --> Input Class Initialized
INFO - 2022-01-13 02:55:55 --> Language Class Initialized
INFO - 2022-01-13 02:55:55 --> Loader Class Initialized
INFO - 2022-01-13 02:55:55 --> Helper loaded: url_helper
INFO - 2022-01-13 02:55:55 --> Helper loaded: form_helper
INFO - 2022-01-13 02:55:55 --> Helper loaded: common_helper
INFO - 2022-01-13 02:55:55 --> Database Driver Class Initialized
DEBUG - 2022-01-13 02:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 02:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 02:55:55 --> Controller Class Initialized
INFO - 2022-01-13 02:55:55 --> Form Validation Class Initialized
DEBUG - 2022-01-13 02:55:55 --> Encrypt Class Initialized
DEBUG - 2022-01-13 02:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 02:55:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 02:55:55 --> Email Class Initialized
INFO - 2022-01-13 02:55:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 02:55:55 --> Calendar Class Initialized
INFO - 2022-01-13 02:55:55 --> Model "Login_model" initialized
INFO - 2022-01-13 02:55:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 02:55:55 --> Final output sent to browser
DEBUG - 2022-01-13 02:55:55 --> Total execution time: 0.0236
ERROR - 2022-01-13 07:29:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 07:29:45 --> Config Class Initialized
INFO - 2022-01-13 07:29:45 --> Hooks Class Initialized
DEBUG - 2022-01-13 07:29:45 --> UTF-8 Support Enabled
INFO - 2022-01-13 07:29:45 --> Utf8 Class Initialized
INFO - 2022-01-13 07:29:45 --> URI Class Initialized
DEBUG - 2022-01-13 07:29:45 --> No URI present. Default controller set.
INFO - 2022-01-13 07:29:45 --> Router Class Initialized
INFO - 2022-01-13 07:29:45 --> Output Class Initialized
INFO - 2022-01-13 07:29:45 --> Security Class Initialized
DEBUG - 2022-01-13 07:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 07:29:45 --> Input Class Initialized
INFO - 2022-01-13 07:29:45 --> Language Class Initialized
INFO - 2022-01-13 07:29:45 --> Loader Class Initialized
INFO - 2022-01-13 07:29:45 --> Helper loaded: url_helper
INFO - 2022-01-13 07:29:45 --> Helper loaded: form_helper
INFO - 2022-01-13 07:29:45 --> Helper loaded: common_helper
INFO - 2022-01-13 07:29:45 --> Database Driver Class Initialized
DEBUG - 2022-01-13 07:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 07:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 07:29:45 --> Controller Class Initialized
INFO - 2022-01-13 07:29:45 --> Form Validation Class Initialized
DEBUG - 2022-01-13 07:29:45 --> Encrypt Class Initialized
DEBUG - 2022-01-13 07:29:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 07:29:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 07:29:45 --> Email Class Initialized
INFO - 2022-01-13 07:29:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 07:29:45 --> Calendar Class Initialized
INFO - 2022-01-13 07:29:45 --> Model "Login_model" initialized
INFO - 2022-01-13 07:29:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 07:29:45 --> Final output sent to browser
DEBUG - 2022-01-13 07:29:45 --> Total execution time: 0.0289
ERROR - 2022-01-13 08:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 08:14:33 --> Config Class Initialized
INFO - 2022-01-13 08:14:33 --> Hooks Class Initialized
DEBUG - 2022-01-13 08:14:33 --> UTF-8 Support Enabled
INFO - 2022-01-13 08:14:33 --> Utf8 Class Initialized
INFO - 2022-01-13 08:14:33 --> URI Class Initialized
DEBUG - 2022-01-13 08:14:33 --> No URI present. Default controller set.
INFO - 2022-01-13 08:14:33 --> Router Class Initialized
INFO - 2022-01-13 08:14:33 --> Output Class Initialized
INFO - 2022-01-13 08:14:33 --> Security Class Initialized
DEBUG - 2022-01-13 08:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 08:14:33 --> Input Class Initialized
INFO - 2022-01-13 08:14:33 --> Language Class Initialized
INFO - 2022-01-13 08:14:33 --> Loader Class Initialized
INFO - 2022-01-13 08:14:33 --> Helper loaded: url_helper
INFO - 2022-01-13 08:14:33 --> Helper loaded: form_helper
INFO - 2022-01-13 08:14:33 --> Helper loaded: common_helper
INFO - 2022-01-13 08:14:33 --> Database Driver Class Initialized
DEBUG - 2022-01-13 08:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 08:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 08:14:33 --> Controller Class Initialized
INFO - 2022-01-13 08:14:33 --> Form Validation Class Initialized
DEBUG - 2022-01-13 08:14:33 --> Encrypt Class Initialized
DEBUG - 2022-01-13 08:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 08:14:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 08:14:33 --> Email Class Initialized
INFO - 2022-01-13 08:14:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 08:14:33 --> Calendar Class Initialized
INFO - 2022-01-13 08:14:33 --> Model "Login_model" initialized
INFO - 2022-01-13 08:14:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 08:14:33 --> Final output sent to browser
DEBUG - 2022-01-13 08:14:33 --> Total execution time: 0.0287
ERROR - 2022-01-13 08:19:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 08:19:11 --> Config Class Initialized
INFO - 2022-01-13 08:19:11 --> Hooks Class Initialized
DEBUG - 2022-01-13 08:19:11 --> UTF-8 Support Enabled
INFO - 2022-01-13 08:19:11 --> Utf8 Class Initialized
INFO - 2022-01-13 08:19:11 --> URI Class Initialized
DEBUG - 2022-01-13 08:19:11 --> No URI present. Default controller set.
INFO - 2022-01-13 08:19:11 --> Router Class Initialized
INFO - 2022-01-13 08:19:11 --> Output Class Initialized
INFO - 2022-01-13 08:19:11 --> Security Class Initialized
DEBUG - 2022-01-13 08:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 08:19:11 --> Input Class Initialized
INFO - 2022-01-13 08:19:11 --> Language Class Initialized
INFO - 2022-01-13 08:19:11 --> Loader Class Initialized
INFO - 2022-01-13 08:19:11 --> Helper loaded: url_helper
INFO - 2022-01-13 08:19:11 --> Helper loaded: form_helper
INFO - 2022-01-13 08:19:11 --> Helper loaded: common_helper
INFO - 2022-01-13 08:19:11 --> Database Driver Class Initialized
DEBUG - 2022-01-13 08:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 08:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 08:19:11 --> Controller Class Initialized
INFO - 2022-01-13 08:19:11 --> Form Validation Class Initialized
DEBUG - 2022-01-13 08:19:11 --> Encrypt Class Initialized
DEBUG - 2022-01-13 08:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 08:19:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 08:19:11 --> Email Class Initialized
INFO - 2022-01-13 08:19:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 08:19:11 --> Calendar Class Initialized
INFO - 2022-01-13 08:19:11 --> Model "Login_model" initialized
INFO - 2022-01-13 08:19:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 08:19:11 --> Final output sent to browser
DEBUG - 2022-01-13 08:19:11 --> Total execution time: 0.0408
ERROR - 2022-01-13 13:12:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 13:12:20 --> Config Class Initialized
INFO - 2022-01-13 13:12:20 --> Hooks Class Initialized
DEBUG - 2022-01-13 13:12:20 --> UTF-8 Support Enabled
INFO - 2022-01-13 13:12:20 --> Utf8 Class Initialized
INFO - 2022-01-13 13:12:20 --> URI Class Initialized
DEBUG - 2022-01-13 13:12:20 --> No URI present. Default controller set.
INFO - 2022-01-13 13:12:20 --> Router Class Initialized
INFO - 2022-01-13 13:12:20 --> Output Class Initialized
INFO - 2022-01-13 13:12:20 --> Security Class Initialized
DEBUG - 2022-01-13 13:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 13:12:20 --> Input Class Initialized
INFO - 2022-01-13 13:12:20 --> Language Class Initialized
INFO - 2022-01-13 13:12:20 --> Loader Class Initialized
INFO - 2022-01-13 13:12:20 --> Helper loaded: url_helper
INFO - 2022-01-13 13:12:20 --> Helper loaded: form_helper
INFO - 2022-01-13 13:12:20 --> Helper loaded: common_helper
INFO - 2022-01-13 13:12:20 --> Database Driver Class Initialized
DEBUG - 2022-01-13 13:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 13:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 13:12:20 --> Controller Class Initialized
INFO - 2022-01-13 13:12:20 --> Form Validation Class Initialized
DEBUG - 2022-01-13 13:12:20 --> Encrypt Class Initialized
DEBUG - 2022-01-13 13:12:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:12:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 13:12:20 --> Email Class Initialized
INFO - 2022-01-13 13:12:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 13:12:20 --> Calendar Class Initialized
INFO - 2022-01-13 13:12:20 --> Model "Login_model" initialized
INFO - 2022-01-13 13:12:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 13:12:20 --> Final output sent to browser
DEBUG - 2022-01-13 13:12:20 --> Total execution time: 0.0272
ERROR - 2022-01-13 14:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 14:18:06 --> Config Class Initialized
INFO - 2022-01-13 14:18:06 --> Hooks Class Initialized
DEBUG - 2022-01-13 14:18:06 --> UTF-8 Support Enabled
INFO - 2022-01-13 14:18:06 --> Utf8 Class Initialized
INFO - 2022-01-13 14:18:06 --> URI Class Initialized
DEBUG - 2022-01-13 14:18:06 --> No URI present. Default controller set.
INFO - 2022-01-13 14:18:06 --> Router Class Initialized
INFO - 2022-01-13 14:18:06 --> Output Class Initialized
INFO - 2022-01-13 14:18:06 --> Security Class Initialized
DEBUG - 2022-01-13 14:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 14:18:06 --> Input Class Initialized
INFO - 2022-01-13 14:18:06 --> Language Class Initialized
INFO - 2022-01-13 14:18:06 --> Loader Class Initialized
INFO - 2022-01-13 14:18:06 --> Helper loaded: url_helper
INFO - 2022-01-13 14:18:06 --> Helper loaded: form_helper
INFO - 2022-01-13 14:18:06 --> Helper loaded: common_helper
INFO - 2022-01-13 14:18:06 --> Database Driver Class Initialized
DEBUG - 2022-01-13 14:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 14:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 14:18:06 --> Controller Class Initialized
INFO - 2022-01-13 14:18:06 --> Form Validation Class Initialized
DEBUG - 2022-01-13 14:18:06 --> Encrypt Class Initialized
DEBUG - 2022-01-13 14:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 14:18:06 --> Email Class Initialized
INFO - 2022-01-13 14:18:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 14:18:06 --> Calendar Class Initialized
INFO - 2022-01-13 14:18:06 --> Model "Login_model" initialized
INFO - 2022-01-13 14:18:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 14:18:06 --> Final output sent to browser
DEBUG - 2022-01-13 14:18:06 --> Total execution time: 0.0249
ERROR - 2022-01-13 14:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 14:18:07 --> Config Class Initialized
INFO - 2022-01-13 14:18:07 --> Hooks Class Initialized
DEBUG - 2022-01-13 14:18:07 --> UTF-8 Support Enabled
INFO - 2022-01-13 14:18:07 --> Utf8 Class Initialized
INFO - 2022-01-13 14:18:07 --> URI Class Initialized
INFO - 2022-01-13 14:18:07 --> Router Class Initialized
INFO - 2022-01-13 14:18:07 --> Output Class Initialized
INFO - 2022-01-13 14:18:07 --> Security Class Initialized
DEBUG - 2022-01-13 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 14:18:07 --> Input Class Initialized
INFO - 2022-01-13 14:18:07 --> Language Class Initialized
ERROR - 2022-01-13 14:18:07 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-13 14:18:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 14:18:20 --> Config Class Initialized
INFO - 2022-01-13 14:18:20 --> Hooks Class Initialized
DEBUG - 2022-01-13 14:18:20 --> UTF-8 Support Enabled
INFO - 2022-01-13 14:18:20 --> Utf8 Class Initialized
INFO - 2022-01-13 14:18:20 --> URI Class Initialized
INFO - 2022-01-13 14:18:20 --> Router Class Initialized
INFO - 2022-01-13 14:18:20 --> Output Class Initialized
INFO - 2022-01-13 14:18:20 --> Security Class Initialized
DEBUG - 2022-01-13 14:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 14:18:20 --> Input Class Initialized
INFO - 2022-01-13 14:18:20 --> Language Class Initialized
INFO - 2022-01-13 14:18:20 --> Loader Class Initialized
INFO - 2022-01-13 14:18:20 --> Helper loaded: url_helper
INFO - 2022-01-13 14:18:20 --> Helper loaded: form_helper
INFO - 2022-01-13 14:18:20 --> Helper loaded: common_helper
INFO - 2022-01-13 14:18:20 --> Database Driver Class Initialized
DEBUG - 2022-01-13 14:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 14:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 14:18:20 --> Controller Class Initialized
INFO - 2022-01-13 14:18:20 --> Form Validation Class Initialized
DEBUG - 2022-01-13 14:18:20 --> Encrypt Class Initialized
DEBUG - 2022-01-13 14:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:18:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 14:18:20 --> Email Class Initialized
INFO - 2022-01-13 14:18:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 14:18:20 --> Calendar Class Initialized
INFO - 2022-01-13 14:18:20 --> Model "Login_model" initialized
ERROR - 2022-01-13 14:18:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 14:18:20 --> Config Class Initialized
INFO - 2022-01-13 14:18:20 --> Hooks Class Initialized
DEBUG - 2022-01-13 14:18:20 --> UTF-8 Support Enabled
INFO - 2022-01-13 14:18:20 --> Utf8 Class Initialized
INFO - 2022-01-13 14:18:20 --> URI Class Initialized
INFO - 2022-01-13 14:18:20 --> Router Class Initialized
INFO - 2022-01-13 14:18:20 --> Output Class Initialized
INFO - 2022-01-13 14:18:20 --> Security Class Initialized
DEBUG - 2022-01-13 14:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 14:18:20 --> Input Class Initialized
INFO - 2022-01-13 14:18:20 --> Language Class Initialized
INFO - 2022-01-13 14:18:20 --> Loader Class Initialized
INFO - 2022-01-13 14:18:20 --> Helper loaded: url_helper
INFO - 2022-01-13 14:18:20 --> Helper loaded: form_helper
INFO - 2022-01-13 14:18:20 --> Helper loaded: common_helper
INFO - 2022-01-13 14:18:20 --> Database Driver Class Initialized
DEBUG - 2022-01-13 14:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 14:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 14:18:20 --> Controller Class Initialized
INFO - 2022-01-13 14:18:20 --> Form Validation Class Initialized
DEBUG - 2022-01-13 14:18:20 --> Encrypt Class Initialized
DEBUG - 2022-01-13 14:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:18:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 14:18:20 --> Email Class Initialized
INFO - 2022-01-13 14:18:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 14:18:20 --> Calendar Class Initialized
INFO - 2022-01-13 14:18:20 --> Model "Login_model" initialized
ERROR - 2022-01-13 14:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 14:18:21 --> Config Class Initialized
INFO - 2022-01-13 14:18:21 --> Hooks Class Initialized
DEBUG - 2022-01-13 14:18:21 --> UTF-8 Support Enabled
INFO - 2022-01-13 14:18:21 --> Utf8 Class Initialized
INFO - 2022-01-13 14:18:21 --> URI Class Initialized
DEBUG - 2022-01-13 14:18:21 --> No URI present. Default controller set.
INFO - 2022-01-13 14:18:21 --> Router Class Initialized
INFO - 2022-01-13 14:18:21 --> Output Class Initialized
INFO - 2022-01-13 14:18:21 --> Security Class Initialized
DEBUG - 2022-01-13 14:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 14:18:21 --> Input Class Initialized
INFO - 2022-01-13 14:18:21 --> Language Class Initialized
INFO - 2022-01-13 14:18:21 --> Loader Class Initialized
INFO - 2022-01-13 14:18:21 --> Helper loaded: url_helper
INFO - 2022-01-13 14:18:21 --> Helper loaded: form_helper
INFO - 2022-01-13 14:18:21 --> Helper loaded: common_helper
INFO - 2022-01-13 14:18:21 --> Database Driver Class Initialized
DEBUG - 2022-01-13 14:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 14:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 14:18:21 --> Controller Class Initialized
INFO - 2022-01-13 14:18:21 --> Form Validation Class Initialized
DEBUG - 2022-01-13 14:18:21 --> Encrypt Class Initialized
DEBUG - 2022-01-13 14:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:18:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 14:18:21 --> Email Class Initialized
INFO - 2022-01-13 14:18:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 14:18:21 --> Calendar Class Initialized
INFO - 2022-01-13 14:18:21 --> Model "Login_model" initialized
INFO - 2022-01-13 14:18:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 14:18:21 --> Final output sent to browser
DEBUG - 2022-01-13 14:18:21 --> Total execution time: 0.0208
ERROR - 2022-01-13 14:18:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 14:18:22 --> Config Class Initialized
INFO - 2022-01-13 14:18:22 --> Hooks Class Initialized
DEBUG - 2022-01-13 14:18:22 --> UTF-8 Support Enabled
INFO - 2022-01-13 14:18:22 --> Utf8 Class Initialized
INFO - 2022-01-13 14:18:22 --> URI Class Initialized
INFO - 2022-01-13 14:18:22 --> Router Class Initialized
INFO - 2022-01-13 14:18:22 --> Output Class Initialized
INFO - 2022-01-13 14:18:22 --> Security Class Initialized
DEBUG - 2022-01-13 14:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 14:18:22 --> Input Class Initialized
INFO - 2022-01-13 14:18:22 --> Language Class Initialized
INFO - 2022-01-13 14:18:22 --> Loader Class Initialized
INFO - 2022-01-13 14:18:22 --> Helper loaded: url_helper
INFO - 2022-01-13 14:18:22 --> Helper loaded: form_helper
INFO - 2022-01-13 14:18:22 --> Helper loaded: common_helper
INFO - 2022-01-13 14:18:22 --> Database Driver Class Initialized
DEBUG - 2022-01-13 14:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 14:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 14:18:22 --> Controller Class Initialized
INFO - 2022-01-13 14:18:22 --> Form Validation Class Initialized
DEBUG - 2022-01-13 14:18:22 --> Encrypt Class Initialized
DEBUG - 2022-01-13 14:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 14:18:22 --> Email Class Initialized
INFO - 2022-01-13 14:18:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 14:18:22 --> Calendar Class Initialized
INFO - 2022-01-13 14:18:22 --> Model "Login_model" initialized
INFO - 2022-01-13 14:18:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 14:18:22 --> Final output sent to browser
DEBUG - 2022-01-13 14:18:22 --> Total execution time: 0.0299
ERROR - 2022-01-13 15:37:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 15:37:55 --> Config Class Initialized
INFO - 2022-01-13 15:37:55 --> Hooks Class Initialized
DEBUG - 2022-01-13 15:37:55 --> UTF-8 Support Enabled
INFO - 2022-01-13 15:37:55 --> Utf8 Class Initialized
INFO - 2022-01-13 15:37:55 --> URI Class Initialized
DEBUG - 2022-01-13 15:37:55 --> No URI present. Default controller set.
INFO - 2022-01-13 15:37:55 --> Router Class Initialized
INFO - 2022-01-13 15:37:55 --> Output Class Initialized
INFO - 2022-01-13 15:37:55 --> Security Class Initialized
DEBUG - 2022-01-13 15:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 15:37:55 --> Input Class Initialized
INFO - 2022-01-13 15:37:55 --> Language Class Initialized
INFO - 2022-01-13 15:37:55 --> Loader Class Initialized
INFO - 2022-01-13 15:37:55 --> Helper loaded: url_helper
INFO - 2022-01-13 15:37:55 --> Helper loaded: form_helper
INFO - 2022-01-13 15:37:55 --> Helper loaded: common_helper
INFO - 2022-01-13 15:37:55 --> Database Driver Class Initialized
DEBUG - 2022-01-13 15:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 15:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 15:37:55 --> Controller Class Initialized
INFO - 2022-01-13 15:37:55 --> Form Validation Class Initialized
DEBUG - 2022-01-13 15:37:55 --> Encrypt Class Initialized
DEBUG - 2022-01-13 15:37:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:37:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 15:37:55 --> Email Class Initialized
INFO - 2022-01-13 15:37:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 15:37:55 --> Calendar Class Initialized
INFO - 2022-01-13 15:37:55 --> Model "Login_model" initialized
INFO - 2022-01-13 15:37:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 15:37:55 --> Final output sent to browser
DEBUG - 2022-01-13 15:37:55 --> Total execution time: 0.0380
ERROR - 2022-01-13 17:00:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 17:00:50 --> Config Class Initialized
INFO - 2022-01-13 17:00:50 --> Hooks Class Initialized
DEBUG - 2022-01-13 17:00:50 --> UTF-8 Support Enabled
INFO - 2022-01-13 17:00:50 --> Utf8 Class Initialized
INFO - 2022-01-13 17:00:50 --> URI Class Initialized
DEBUG - 2022-01-13 17:00:50 --> No URI present. Default controller set.
INFO - 2022-01-13 17:00:50 --> Router Class Initialized
INFO - 2022-01-13 17:00:50 --> Output Class Initialized
INFO - 2022-01-13 17:00:50 --> Security Class Initialized
DEBUG - 2022-01-13 17:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 17:00:50 --> Input Class Initialized
INFO - 2022-01-13 17:00:50 --> Language Class Initialized
INFO - 2022-01-13 17:00:50 --> Loader Class Initialized
INFO - 2022-01-13 17:00:50 --> Helper loaded: url_helper
INFO - 2022-01-13 17:00:50 --> Helper loaded: form_helper
INFO - 2022-01-13 17:00:50 --> Helper loaded: common_helper
INFO - 2022-01-13 17:00:50 --> Database Driver Class Initialized
DEBUG - 2022-01-13 17:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 17:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 17:00:50 --> Controller Class Initialized
INFO - 2022-01-13 17:00:50 --> Form Validation Class Initialized
DEBUG - 2022-01-13 17:00:50 --> Encrypt Class Initialized
DEBUG - 2022-01-13 17:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 17:00:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 17:00:50 --> Email Class Initialized
INFO - 2022-01-13 17:00:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 17:00:50 --> Calendar Class Initialized
INFO - 2022-01-13 17:00:50 --> Model "Login_model" initialized
INFO - 2022-01-13 17:00:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 17:00:50 --> Final output sent to browser
DEBUG - 2022-01-13 17:00:50 --> Total execution time: 0.0417
ERROR - 2022-01-13 20:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-13 20:21:44 --> Config Class Initialized
INFO - 2022-01-13 20:21:44 --> Hooks Class Initialized
DEBUG - 2022-01-13 20:21:44 --> UTF-8 Support Enabled
INFO - 2022-01-13 20:21:44 --> Utf8 Class Initialized
INFO - 2022-01-13 20:21:44 --> URI Class Initialized
DEBUG - 2022-01-13 20:21:44 --> No URI present. Default controller set.
INFO - 2022-01-13 20:21:44 --> Router Class Initialized
INFO - 2022-01-13 20:21:44 --> Output Class Initialized
INFO - 2022-01-13 20:21:44 --> Security Class Initialized
DEBUG - 2022-01-13 20:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-13 20:21:44 --> Input Class Initialized
INFO - 2022-01-13 20:21:44 --> Language Class Initialized
INFO - 2022-01-13 20:21:44 --> Loader Class Initialized
INFO - 2022-01-13 20:21:44 --> Helper loaded: url_helper
INFO - 2022-01-13 20:21:44 --> Helper loaded: form_helper
INFO - 2022-01-13 20:21:44 --> Helper loaded: common_helper
INFO - 2022-01-13 20:21:44 --> Database Driver Class Initialized
DEBUG - 2022-01-13 20:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-13 20:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-13 20:21:44 --> Controller Class Initialized
INFO - 2022-01-13 20:21:44 --> Form Validation Class Initialized
DEBUG - 2022-01-13 20:21:44 --> Encrypt Class Initialized
DEBUG - 2022-01-13 20:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 20:21:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-13 20:21:44 --> Email Class Initialized
INFO - 2022-01-13 20:21:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-13 20:21:44 --> Calendar Class Initialized
INFO - 2022-01-13 20:21:44 --> Model "Login_model" initialized
INFO - 2022-01-13 20:21:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-13 20:21:44 --> Final output sent to browser
DEBUG - 2022-01-13 20:21:44 --> Total execution time: 0.0246
