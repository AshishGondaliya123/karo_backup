<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-08 04:51:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 04:51:00 --> Config Class Initialized
INFO - 2022-01-08 04:51:00 --> Hooks Class Initialized
DEBUG - 2022-01-08 04:51:00 --> UTF-8 Support Enabled
INFO - 2022-01-08 04:51:00 --> Utf8 Class Initialized
INFO - 2022-01-08 04:51:00 --> URI Class Initialized
DEBUG - 2022-01-08 04:51:00 --> No URI present. Default controller set.
INFO - 2022-01-08 04:51:00 --> Router Class Initialized
INFO - 2022-01-08 04:51:00 --> Output Class Initialized
INFO - 2022-01-08 04:51:00 --> Security Class Initialized
DEBUG - 2022-01-08 04:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 04:51:00 --> Input Class Initialized
INFO - 2022-01-08 04:51:00 --> Language Class Initialized
INFO - 2022-01-08 04:51:00 --> Loader Class Initialized
INFO - 2022-01-08 04:51:00 --> Helper loaded: url_helper
INFO - 2022-01-08 04:51:00 --> Helper loaded: form_helper
INFO - 2022-01-08 04:51:00 --> Helper loaded: common_helper
INFO - 2022-01-08 04:51:00 --> Database Driver Class Initialized
DEBUG - 2022-01-08 04:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 04:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 04:51:00 --> Controller Class Initialized
INFO - 2022-01-08 04:51:00 --> Form Validation Class Initialized
DEBUG - 2022-01-08 04:51:00 --> Encrypt Class Initialized
DEBUG - 2022-01-08 04:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 04:51:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 04:51:00 --> Email Class Initialized
INFO - 2022-01-08 04:51:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 04:51:00 --> Calendar Class Initialized
INFO - 2022-01-08 04:51:00 --> Model "Login_model" initialized
INFO - 2022-01-08 04:51:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-08 04:51:00 --> Final output sent to browser
DEBUG - 2022-01-08 04:51:00 --> Total execution time: 0.0239
ERROR - 2022-01-08 11:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 11:49:09 --> Config Class Initialized
INFO - 2022-01-08 11:49:09 --> Hooks Class Initialized
DEBUG - 2022-01-08 11:49:09 --> UTF-8 Support Enabled
INFO - 2022-01-08 11:49:09 --> Utf8 Class Initialized
INFO - 2022-01-08 11:49:09 --> URI Class Initialized
DEBUG - 2022-01-08 11:49:09 --> No URI present. Default controller set.
INFO - 2022-01-08 11:49:09 --> Router Class Initialized
INFO - 2022-01-08 11:49:09 --> Output Class Initialized
INFO - 2022-01-08 11:49:09 --> Security Class Initialized
DEBUG - 2022-01-08 11:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 11:49:09 --> Input Class Initialized
INFO - 2022-01-08 11:49:09 --> Language Class Initialized
INFO - 2022-01-08 11:49:09 --> Loader Class Initialized
INFO - 2022-01-08 11:49:09 --> Helper loaded: url_helper
INFO - 2022-01-08 11:49:09 --> Helper loaded: form_helper
INFO - 2022-01-08 11:49:09 --> Helper loaded: common_helper
INFO - 2022-01-08 11:49:09 --> Database Driver Class Initialized
DEBUG - 2022-01-08 11:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 11:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 11:49:09 --> Controller Class Initialized
INFO - 2022-01-08 11:49:09 --> Form Validation Class Initialized
DEBUG - 2022-01-08 11:49:09 --> Encrypt Class Initialized
DEBUG - 2022-01-08 11:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 11:49:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 11:49:09 --> Email Class Initialized
INFO - 2022-01-08 11:49:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 11:49:09 --> Calendar Class Initialized
INFO - 2022-01-08 11:49:09 --> Model "Login_model" initialized
INFO - 2022-01-08 11:49:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-08 11:49:09 --> Final output sent to browser
DEBUG - 2022-01-08 11:49:09 --> Total execution time: 0.0237
ERROR - 2022-01-08 15:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 15:01:23 --> Config Class Initialized
INFO - 2022-01-08 15:01:23 --> Hooks Class Initialized
DEBUG - 2022-01-08 15:01:23 --> UTF-8 Support Enabled
INFO - 2022-01-08 15:01:23 --> Utf8 Class Initialized
INFO - 2022-01-08 15:01:23 --> URI Class Initialized
DEBUG - 2022-01-08 15:01:23 --> No URI present. Default controller set.
INFO - 2022-01-08 15:01:23 --> Router Class Initialized
INFO - 2022-01-08 15:01:23 --> Output Class Initialized
INFO - 2022-01-08 15:01:23 --> Security Class Initialized
DEBUG - 2022-01-08 15:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 15:01:23 --> Input Class Initialized
INFO - 2022-01-08 15:01:23 --> Language Class Initialized
INFO - 2022-01-08 15:01:23 --> Loader Class Initialized
INFO - 2022-01-08 15:01:23 --> Helper loaded: url_helper
INFO - 2022-01-08 15:01:23 --> Helper loaded: form_helper
INFO - 2022-01-08 15:01:23 --> Helper loaded: common_helper
INFO - 2022-01-08 15:01:23 --> Database Driver Class Initialized
DEBUG - 2022-01-08 15:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 15:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 15:01:23 --> Controller Class Initialized
INFO - 2022-01-08 15:01:23 --> Form Validation Class Initialized
DEBUG - 2022-01-08 15:01:23 --> Encrypt Class Initialized
DEBUG - 2022-01-08 15:01:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 15:01:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 15:01:23 --> Email Class Initialized
INFO - 2022-01-08 15:01:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 15:01:23 --> Calendar Class Initialized
INFO - 2022-01-08 15:01:23 --> Model "Login_model" initialized
INFO - 2022-01-08 15:01:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-08 15:01:23 --> Final output sent to browser
DEBUG - 2022-01-08 15:01:23 --> Total execution time: 0.0438
ERROR - 2022-01-08 15:01:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 15:01:25 --> Config Class Initialized
INFO - 2022-01-08 15:01:25 --> Hooks Class Initialized
DEBUG - 2022-01-08 15:01:25 --> UTF-8 Support Enabled
INFO - 2022-01-08 15:01:25 --> Utf8 Class Initialized
INFO - 2022-01-08 15:01:25 --> URI Class Initialized
INFO - 2022-01-08 15:01:25 --> Router Class Initialized
INFO - 2022-01-08 15:01:25 --> Output Class Initialized
INFO - 2022-01-08 15:01:25 --> Security Class Initialized
DEBUG - 2022-01-08 15:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 15:01:25 --> Input Class Initialized
INFO - 2022-01-08 15:01:25 --> Language Class Initialized
ERROR - 2022-01-08 15:01:25 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-08 15:01:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 15:01:37 --> Config Class Initialized
INFO - 2022-01-08 15:01:37 --> Hooks Class Initialized
DEBUG - 2022-01-08 15:01:37 --> UTF-8 Support Enabled
INFO - 2022-01-08 15:01:37 --> Utf8 Class Initialized
INFO - 2022-01-08 15:01:37 --> URI Class Initialized
DEBUG - 2022-01-08 15:01:37 --> No URI present. Default controller set.
INFO - 2022-01-08 15:01:37 --> Router Class Initialized
INFO - 2022-01-08 15:01:37 --> Output Class Initialized
INFO - 2022-01-08 15:01:37 --> Security Class Initialized
DEBUG - 2022-01-08 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 15:01:37 --> Input Class Initialized
INFO - 2022-01-08 15:01:37 --> Language Class Initialized
INFO - 2022-01-08 15:01:37 --> Loader Class Initialized
INFO - 2022-01-08 15:01:37 --> Helper loaded: url_helper
INFO - 2022-01-08 15:01:37 --> Helper loaded: form_helper
INFO - 2022-01-08 15:01:37 --> Helper loaded: common_helper
INFO - 2022-01-08 15:01:37 --> Database Driver Class Initialized
DEBUG - 2022-01-08 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 15:01:37 --> Controller Class Initialized
INFO - 2022-01-08 15:01:37 --> Form Validation Class Initialized
DEBUG - 2022-01-08 15:01:37 --> Encrypt Class Initialized
DEBUG - 2022-01-08 15:01:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 15:01:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 15:01:37 --> Email Class Initialized
INFO - 2022-01-08 15:01:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 15:01:37 --> Calendar Class Initialized
INFO - 2022-01-08 15:01:37 --> Model "Login_model" initialized
INFO - 2022-01-08 15:01:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-08 15:01:37 --> Final output sent to browser
DEBUG - 2022-01-08 15:01:37 --> Total execution time: 0.0266
ERROR - 2022-01-08 15:01:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 15:01:39 --> Config Class Initialized
INFO - 2022-01-08 15:01:39 --> Hooks Class Initialized
DEBUG - 2022-01-08 15:01:39 --> UTF-8 Support Enabled
INFO - 2022-01-08 15:01:39 --> Utf8 Class Initialized
INFO - 2022-01-08 15:01:39 --> URI Class Initialized
INFO - 2022-01-08 15:01:39 --> Router Class Initialized
INFO - 2022-01-08 15:01:39 --> Output Class Initialized
INFO - 2022-01-08 15:01:39 --> Security Class Initialized
DEBUG - 2022-01-08 15:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 15:01:39 --> Input Class Initialized
INFO - 2022-01-08 15:01:39 --> Language Class Initialized
INFO - 2022-01-08 15:01:39 --> Loader Class Initialized
INFO - 2022-01-08 15:01:39 --> Helper loaded: url_helper
INFO - 2022-01-08 15:01:39 --> Helper loaded: form_helper
INFO - 2022-01-08 15:01:39 --> Helper loaded: common_helper
INFO - 2022-01-08 15:01:39 --> Database Driver Class Initialized
DEBUG - 2022-01-08 15:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 15:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 15:01:39 --> Controller Class Initialized
INFO - 2022-01-08 15:01:39 --> Form Validation Class Initialized
DEBUG - 2022-01-08 15:01:39 --> Encrypt Class Initialized
DEBUG - 2022-01-08 15:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 15:01:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 15:01:39 --> Email Class Initialized
INFO - 2022-01-08 15:01:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 15:01:39 --> Calendar Class Initialized
INFO - 2022-01-08 15:01:39 --> Model "Login_model" initialized
ERROR - 2022-01-08 15:01:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 15:01:39 --> Config Class Initialized
INFO - 2022-01-08 15:01:39 --> Hooks Class Initialized
DEBUG - 2022-01-08 15:01:39 --> UTF-8 Support Enabled
INFO - 2022-01-08 15:01:39 --> Utf8 Class Initialized
INFO - 2022-01-08 15:01:39 --> URI Class Initialized
INFO - 2022-01-08 15:01:39 --> Router Class Initialized
INFO - 2022-01-08 15:01:39 --> Output Class Initialized
INFO - 2022-01-08 15:01:39 --> Security Class Initialized
DEBUG - 2022-01-08 15:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 15:01:39 --> Input Class Initialized
INFO - 2022-01-08 15:01:39 --> Language Class Initialized
INFO - 2022-01-08 15:01:39 --> Loader Class Initialized
INFO - 2022-01-08 15:01:39 --> Helper loaded: url_helper
INFO - 2022-01-08 15:01:39 --> Helper loaded: form_helper
INFO - 2022-01-08 15:01:39 --> Helper loaded: common_helper
INFO - 2022-01-08 15:01:39 --> Database Driver Class Initialized
DEBUG - 2022-01-08 15:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 15:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 15:01:39 --> Controller Class Initialized
INFO - 2022-01-08 15:01:39 --> Form Validation Class Initialized
DEBUG - 2022-01-08 15:01:39 --> Encrypt Class Initialized
DEBUG - 2022-01-08 15:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 15:01:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 15:01:39 --> Email Class Initialized
INFO - 2022-01-08 15:01:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 15:01:39 --> Calendar Class Initialized
INFO - 2022-01-08 15:01:39 --> Model "Login_model" initialized
ERROR - 2022-01-08 15:01:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 15:01:40 --> Config Class Initialized
INFO - 2022-01-08 15:01:40 --> Hooks Class Initialized
DEBUG - 2022-01-08 15:01:40 --> UTF-8 Support Enabled
INFO - 2022-01-08 15:01:40 --> Utf8 Class Initialized
INFO - 2022-01-08 15:01:40 --> URI Class Initialized
INFO - 2022-01-08 15:01:40 --> Router Class Initialized
INFO - 2022-01-08 15:01:40 --> Output Class Initialized
INFO - 2022-01-08 15:01:40 --> Security Class Initialized
DEBUG - 2022-01-08 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 15:01:40 --> Input Class Initialized
INFO - 2022-01-08 15:01:40 --> Language Class Initialized
INFO - 2022-01-08 15:01:40 --> Loader Class Initialized
INFO - 2022-01-08 15:01:40 --> Helper loaded: url_helper
INFO - 2022-01-08 15:01:40 --> Helper loaded: form_helper
INFO - 2022-01-08 15:01:40 --> Helper loaded: common_helper
INFO - 2022-01-08 15:01:40 --> Database Driver Class Initialized
DEBUG - 2022-01-08 15:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 15:01:40 --> Controller Class Initialized
INFO - 2022-01-08 15:01:40 --> Form Validation Class Initialized
DEBUG - 2022-01-08 15:01:40 --> Encrypt Class Initialized
DEBUG - 2022-01-08 15:01:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 15:01:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 15:01:40 --> Email Class Initialized
INFO - 2022-01-08 15:01:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 15:01:40 --> Calendar Class Initialized
INFO - 2022-01-08 15:01:40 --> Model "Login_model" initialized
INFO - 2022-01-08 15:01:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-08 15:01:40 --> Final output sent to browser
DEBUG - 2022-01-08 15:01:40 --> Total execution time: 0.0266
ERROR - 2022-01-08 17:32:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 17:32:24 --> Config Class Initialized
INFO - 2022-01-08 17:32:24 --> Hooks Class Initialized
DEBUG - 2022-01-08 17:32:24 --> UTF-8 Support Enabled
INFO - 2022-01-08 17:32:24 --> Utf8 Class Initialized
INFO - 2022-01-08 17:32:24 --> URI Class Initialized
DEBUG - 2022-01-08 17:32:24 --> No URI present. Default controller set.
INFO - 2022-01-08 17:32:24 --> Router Class Initialized
INFO - 2022-01-08 17:32:24 --> Output Class Initialized
INFO - 2022-01-08 17:32:24 --> Security Class Initialized
DEBUG - 2022-01-08 17:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 17:32:24 --> Input Class Initialized
INFO - 2022-01-08 17:32:24 --> Language Class Initialized
INFO - 2022-01-08 17:32:24 --> Loader Class Initialized
INFO - 2022-01-08 17:32:24 --> Helper loaded: url_helper
INFO - 2022-01-08 17:32:24 --> Helper loaded: form_helper
INFO - 2022-01-08 17:32:24 --> Helper loaded: common_helper
INFO - 2022-01-08 17:32:24 --> Database Driver Class Initialized
DEBUG - 2022-01-08 17:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 17:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 17:32:24 --> Controller Class Initialized
INFO - 2022-01-08 17:32:24 --> Form Validation Class Initialized
DEBUG - 2022-01-08 17:32:24 --> Encrypt Class Initialized
DEBUG - 2022-01-08 17:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 17:32:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 17:32:24 --> Email Class Initialized
INFO - 2022-01-08 17:32:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 17:32:24 --> Calendar Class Initialized
INFO - 2022-01-08 17:32:24 --> Model "Login_model" initialized
INFO - 2022-01-08 17:32:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-08 17:32:24 --> Final output sent to browser
DEBUG - 2022-01-08 17:32:24 --> Total execution time: 0.0232
ERROR - 2022-01-08 19:25:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 19:25:35 --> Config Class Initialized
INFO - 2022-01-08 19:25:35 --> Hooks Class Initialized
DEBUG - 2022-01-08 19:25:35 --> UTF-8 Support Enabled
INFO - 2022-01-08 19:25:35 --> Utf8 Class Initialized
INFO - 2022-01-08 19:25:35 --> URI Class Initialized
DEBUG - 2022-01-08 19:25:35 --> No URI present. Default controller set.
INFO - 2022-01-08 19:25:35 --> Router Class Initialized
INFO - 2022-01-08 19:25:35 --> Output Class Initialized
INFO - 2022-01-08 19:25:35 --> Security Class Initialized
DEBUG - 2022-01-08 19:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 19:25:35 --> Input Class Initialized
INFO - 2022-01-08 19:25:35 --> Language Class Initialized
INFO - 2022-01-08 19:25:35 --> Loader Class Initialized
INFO - 2022-01-08 19:25:35 --> Helper loaded: url_helper
INFO - 2022-01-08 19:25:35 --> Helper loaded: form_helper
INFO - 2022-01-08 19:25:35 --> Helper loaded: common_helper
INFO - 2022-01-08 19:25:35 --> Database Driver Class Initialized
DEBUG - 2022-01-08 19:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 19:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 19:25:35 --> Controller Class Initialized
INFO - 2022-01-08 19:25:35 --> Form Validation Class Initialized
DEBUG - 2022-01-08 19:25:35 --> Encrypt Class Initialized
DEBUG - 2022-01-08 19:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 19:25:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 19:25:35 --> Email Class Initialized
INFO - 2022-01-08 19:25:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 19:25:35 --> Calendar Class Initialized
INFO - 2022-01-08 19:25:35 --> Model "Login_model" initialized
INFO - 2022-01-08 19:25:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-08 19:25:35 --> Final output sent to browser
DEBUG - 2022-01-08 19:25:35 --> Total execution time: 0.0435
ERROR - 2022-01-08 20:04:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-08 20:04:27 --> Config Class Initialized
INFO - 2022-01-08 20:04:27 --> Hooks Class Initialized
DEBUG - 2022-01-08 20:04:27 --> UTF-8 Support Enabled
INFO - 2022-01-08 20:04:27 --> Utf8 Class Initialized
INFO - 2022-01-08 20:04:27 --> URI Class Initialized
DEBUG - 2022-01-08 20:04:27 --> No URI present. Default controller set.
INFO - 2022-01-08 20:04:27 --> Router Class Initialized
INFO - 2022-01-08 20:04:27 --> Output Class Initialized
INFO - 2022-01-08 20:04:27 --> Security Class Initialized
DEBUG - 2022-01-08 20:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-08 20:04:27 --> Input Class Initialized
INFO - 2022-01-08 20:04:27 --> Language Class Initialized
INFO - 2022-01-08 20:04:27 --> Loader Class Initialized
INFO - 2022-01-08 20:04:27 --> Helper loaded: url_helper
INFO - 2022-01-08 20:04:27 --> Helper loaded: form_helper
INFO - 2022-01-08 20:04:27 --> Helper loaded: common_helper
INFO - 2022-01-08 20:04:27 --> Database Driver Class Initialized
DEBUG - 2022-01-08 20:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-08 20:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-08 20:04:27 --> Controller Class Initialized
INFO - 2022-01-08 20:04:27 --> Form Validation Class Initialized
DEBUG - 2022-01-08 20:04:27 --> Encrypt Class Initialized
DEBUG - 2022-01-08 20:04:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 20:04:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-08 20:04:27 --> Email Class Initialized
INFO - 2022-01-08 20:04:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-08 20:04:27 --> Calendar Class Initialized
INFO - 2022-01-08 20:04:27 --> Model "Login_model" initialized
INFO - 2022-01-08 20:04:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-08 20:04:27 --> Final output sent to browser
DEBUG - 2022-01-08 20:04:27 --> Total execution time: 0.0671
