<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-06 00:14:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-06 00:14:59 --> Config Class Initialized
INFO - 2022-02-06 00:14:59 --> Hooks Class Initialized
DEBUG - 2022-02-06 00:14:59 --> UTF-8 Support Enabled
INFO - 2022-02-06 00:14:59 --> Utf8 Class Initialized
INFO - 2022-02-06 00:14:59 --> URI Class Initialized
DEBUG - 2022-02-06 00:14:59 --> No URI present. Default controller set.
INFO - 2022-02-06 00:14:59 --> Router Class Initialized
INFO - 2022-02-06 00:14:59 --> Output Class Initialized
INFO - 2022-02-06 00:14:59 --> Security Class Initialized
DEBUG - 2022-02-06 00:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-06 00:14:59 --> Input Class Initialized
INFO - 2022-02-06 00:14:59 --> Language Class Initialized
INFO - 2022-02-06 00:14:59 --> Loader Class Initialized
INFO - 2022-02-06 00:14:59 --> Helper loaded: url_helper
INFO - 2022-02-06 00:14:59 --> Helper loaded: form_helper
INFO - 2022-02-06 00:14:59 --> Helper loaded: common_helper
INFO - 2022-02-06 00:14:59 --> Database Driver Class Initialized
DEBUG - 2022-02-06 00:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-06 00:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-06 00:14:59 --> Controller Class Initialized
INFO - 2022-02-06 00:14:59 --> Form Validation Class Initialized
DEBUG - 2022-02-06 00:14:59 --> Encrypt Class Initialized
DEBUG - 2022-02-06 00:14:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 00:14:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-06 00:14:59 --> Email Class Initialized
INFO - 2022-02-06 00:14:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-06 00:14:59 --> Calendar Class Initialized
INFO - 2022-02-06 00:14:59 --> Model "Login_model" initialized
INFO - 2022-02-06 00:14:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-06 00:14:59 --> Final output sent to browser
DEBUG - 2022-02-06 00:14:59 --> Total execution time: 0.0443
ERROR - 2022-02-06 15:08:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-06 15:08:48 --> Config Class Initialized
INFO - 2022-02-06 15:08:48 --> Hooks Class Initialized
DEBUG - 2022-02-06 15:08:48 --> UTF-8 Support Enabled
INFO - 2022-02-06 15:08:48 --> Utf8 Class Initialized
INFO - 2022-02-06 15:08:48 --> URI Class Initialized
DEBUG - 2022-02-06 15:08:48 --> No URI present. Default controller set.
INFO - 2022-02-06 15:08:48 --> Router Class Initialized
INFO - 2022-02-06 15:08:48 --> Output Class Initialized
INFO - 2022-02-06 15:08:48 --> Security Class Initialized
DEBUG - 2022-02-06 15:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-06 15:08:48 --> Input Class Initialized
INFO - 2022-02-06 15:08:48 --> Language Class Initialized
INFO - 2022-02-06 15:08:48 --> Loader Class Initialized
INFO - 2022-02-06 15:08:48 --> Helper loaded: url_helper
INFO - 2022-02-06 15:08:48 --> Helper loaded: form_helper
INFO - 2022-02-06 15:08:48 --> Helper loaded: common_helper
INFO - 2022-02-06 15:08:48 --> Database Driver Class Initialized
DEBUG - 2022-02-06 15:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-06 15:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-06 15:08:48 --> Controller Class Initialized
INFO - 2022-02-06 15:08:48 --> Form Validation Class Initialized
DEBUG - 2022-02-06 15:08:48 --> Encrypt Class Initialized
DEBUG - 2022-02-06 15:08:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 15:08:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-06 15:08:48 --> Email Class Initialized
INFO - 2022-02-06 15:08:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-06 15:08:48 --> Calendar Class Initialized
INFO - 2022-02-06 15:08:48 --> Model "Login_model" initialized
INFO - 2022-02-06 15:08:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-06 15:08:48 --> Final output sent to browser
DEBUG - 2022-02-06 15:08:48 --> Total execution time: 0.0682
ERROR - 2022-02-06 15:08:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-06 15:08:48 --> Config Class Initialized
INFO - 2022-02-06 15:08:48 --> Hooks Class Initialized
DEBUG - 2022-02-06 15:08:48 --> UTF-8 Support Enabled
INFO - 2022-02-06 15:08:48 --> Utf8 Class Initialized
INFO - 2022-02-06 15:08:48 --> URI Class Initialized
INFO - 2022-02-06 15:08:48 --> Router Class Initialized
INFO - 2022-02-06 15:08:48 --> Output Class Initialized
INFO - 2022-02-06 15:08:48 --> Security Class Initialized
DEBUG - 2022-02-06 15:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-06 15:08:48 --> Input Class Initialized
INFO - 2022-02-06 15:08:48 --> Language Class Initialized
ERROR - 2022-02-06 15:08:48 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-06 15:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-06 15:09:24 --> Config Class Initialized
INFO - 2022-02-06 15:09:24 --> Hooks Class Initialized
DEBUG - 2022-02-06 15:09:24 --> UTF-8 Support Enabled
INFO - 2022-02-06 15:09:24 --> Utf8 Class Initialized
INFO - 2022-02-06 15:09:24 --> URI Class Initialized
DEBUG - 2022-02-06 15:09:24 --> No URI present. Default controller set.
INFO - 2022-02-06 15:09:24 --> Router Class Initialized
INFO - 2022-02-06 15:09:24 --> Output Class Initialized
INFO - 2022-02-06 15:09:24 --> Security Class Initialized
DEBUG - 2022-02-06 15:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-06 15:09:24 --> Input Class Initialized
INFO - 2022-02-06 15:09:24 --> Language Class Initialized
INFO - 2022-02-06 15:09:24 --> Loader Class Initialized
INFO - 2022-02-06 15:09:24 --> Helper loaded: url_helper
INFO - 2022-02-06 15:09:24 --> Helper loaded: form_helper
INFO - 2022-02-06 15:09:24 --> Helper loaded: common_helper
INFO - 2022-02-06 15:09:24 --> Database Driver Class Initialized
DEBUG - 2022-02-06 15:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-06 15:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-06 15:09:24 --> Controller Class Initialized
INFO - 2022-02-06 15:09:24 --> Form Validation Class Initialized
DEBUG - 2022-02-06 15:09:24 --> Encrypt Class Initialized
DEBUG - 2022-02-06 15:09:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 15:09:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-06 15:09:24 --> Email Class Initialized
INFO - 2022-02-06 15:09:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-06 15:09:24 --> Calendar Class Initialized
INFO - 2022-02-06 15:09:24 --> Model "Login_model" initialized
INFO - 2022-02-06 15:09:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-06 15:09:24 --> Final output sent to browser
DEBUG - 2022-02-06 15:09:24 --> Total execution time: 0.0341
ERROR - 2022-02-06 15:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-06 15:09:24 --> Config Class Initialized
INFO - 2022-02-06 15:09:24 --> Hooks Class Initialized
DEBUG - 2022-02-06 15:09:24 --> UTF-8 Support Enabled
INFO - 2022-02-06 15:09:24 --> Utf8 Class Initialized
INFO - 2022-02-06 15:09:24 --> URI Class Initialized
INFO - 2022-02-06 15:09:24 --> Router Class Initialized
INFO - 2022-02-06 15:09:24 --> Output Class Initialized
INFO - 2022-02-06 15:09:24 --> Security Class Initialized
DEBUG - 2022-02-06 15:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-06 15:09:24 --> Input Class Initialized
INFO - 2022-02-06 15:09:24 --> Language Class Initialized
INFO - 2022-02-06 15:09:24 --> Loader Class Initialized
INFO - 2022-02-06 15:09:24 --> Helper loaded: url_helper
INFO - 2022-02-06 15:09:24 --> Helper loaded: form_helper
INFO - 2022-02-06 15:09:24 --> Helper loaded: common_helper
INFO - 2022-02-06 15:09:24 --> Database Driver Class Initialized
DEBUG - 2022-02-06 15:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-06 15:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-06 15:09:24 --> Controller Class Initialized
INFO - 2022-02-06 15:09:24 --> Form Validation Class Initialized
DEBUG - 2022-02-06 15:09:24 --> Encrypt Class Initialized
DEBUG - 2022-02-06 15:09:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 15:09:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-06 15:09:24 --> Email Class Initialized
INFO - 2022-02-06 15:09:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-06 15:09:24 --> Calendar Class Initialized
INFO - 2022-02-06 15:09:24 --> Model "Login_model" initialized
ERROR - 2022-02-06 15:09:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-06 15:09:25 --> Config Class Initialized
INFO - 2022-02-06 15:09:25 --> Hooks Class Initialized
DEBUG - 2022-02-06 15:09:25 --> UTF-8 Support Enabled
INFO - 2022-02-06 15:09:25 --> Utf8 Class Initialized
INFO - 2022-02-06 15:09:25 --> URI Class Initialized
INFO - 2022-02-06 15:09:25 --> Router Class Initialized
INFO - 2022-02-06 15:09:25 --> Output Class Initialized
INFO - 2022-02-06 15:09:25 --> Security Class Initialized
DEBUG - 2022-02-06 15:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-06 15:09:25 --> Input Class Initialized
INFO - 2022-02-06 15:09:25 --> Language Class Initialized
INFO - 2022-02-06 15:09:25 --> Loader Class Initialized
INFO - 2022-02-06 15:09:25 --> Helper loaded: url_helper
INFO - 2022-02-06 15:09:25 --> Helper loaded: form_helper
INFO - 2022-02-06 15:09:25 --> Helper loaded: common_helper
INFO - 2022-02-06 15:09:25 --> Database Driver Class Initialized
DEBUG - 2022-02-06 15:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-06 15:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-06 15:09:25 --> Controller Class Initialized
INFO - 2022-02-06 15:09:25 --> Form Validation Class Initialized
DEBUG - 2022-02-06 15:09:25 --> Encrypt Class Initialized
DEBUG - 2022-02-06 15:09:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 15:09:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-06 15:09:25 --> Email Class Initialized
INFO - 2022-02-06 15:09:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-06 15:09:25 --> Calendar Class Initialized
INFO - 2022-02-06 15:09:25 --> Model "Login_model" initialized
ERROR - 2022-02-06 15:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-06 15:09:26 --> Config Class Initialized
INFO - 2022-02-06 15:09:26 --> Hooks Class Initialized
DEBUG - 2022-02-06 15:09:26 --> UTF-8 Support Enabled
INFO - 2022-02-06 15:09:26 --> Utf8 Class Initialized
INFO - 2022-02-06 15:09:26 --> URI Class Initialized
INFO - 2022-02-06 15:09:26 --> Router Class Initialized
INFO - 2022-02-06 15:09:26 --> Output Class Initialized
INFO - 2022-02-06 15:09:26 --> Security Class Initialized
DEBUG - 2022-02-06 15:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-06 15:09:26 --> Input Class Initialized
INFO - 2022-02-06 15:09:26 --> Language Class Initialized
INFO - 2022-02-06 15:09:26 --> Loader Class Initialized
INFO - 2022-02-06 15:09:26 --> Helper loaded: url_helper
INFO - 2022-02-06 15:09:26 --> Helper loaded: form_helper
INFO - 2022-02-06 15:09:26 --> Helper loaded: common_helper
INFO - 2022-02-06 15:09:26 --> Database Driver Class Initialized
DEBUG - 2022-02-06 15:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-06 15:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-06 15:09:26 --> Controller Class Initialized
INFO - 2022-02-06 15:09:26 --> Form Validation Class Initialized
DEBUG - 2022-02-06 15:09:26 --> Encrypt Class Initialized
DEBUG - 2022-02-06 15:09:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 15:09:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-06 15:09:26 --> Email Class Initialized
INFO - 2022-02-06 15:09:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-06 15:09:26 --> Calendar Class Initialized
INFO - 2022-02-06 15:09:26 --> Model "Login_model" initialized
INFO - 2022-02-06 15:09:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-06 15:09:26 --> Final output sent to browser
DEBUG - 2022-02-06 15:09:26 --> Total execution time: 0.0312
ERROR - 2022-02-06 19:45:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-06 19:45:04 --> Config Class Initialized
INFO - 2022-02-06 19:45:04 --> Hooks Class Initialized
DEBUG - 2022-02-06 19:45:04 --> UTF-8 Support Enabled
INFO - 2022-02-06 19:45:04 --> Utf8 Class Initialized
INFO - 2022-02-06 19:45:04 --> URI Class Initialized
DEBUG - 2022-02-06 19:45:04 --> No URI present. Default controller set.
INFO - 2022-02-06 19:45:04 --> Router Class Initialized
INFO - 2022-02-06 19:45:04 --> Output Class Initialized
INFO - 2022-02-06 19:45:04 --> Security Class Initialized
DEBUG - 2022-02-06 19:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-06 19:45:04 --> Input Class Initialized
INFO - 2022-02-06 19:45:04 --> Language Class Initialized
INFO - 2022-02-06 19:45:04 --> Loader Class Initialized
INFO - 2022-02-06 19:45:04 --> Helper loaded: url_helper
INFO - 2022-02-06 19:45:04 --> Helper loaded: form_helper
INFO - 2022-02-06 19:45:04 --> Helper loaded: common_helper
INFO - 2022-02-06 19:45:04 --> Database Driver Class Initialized
DEBUG - 2022-02-06 19:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-06 19:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-06 19:45:04 --> Controller Class Initialized
INFO - 2022-02-06 19:45:04 --> Form Validation Class Initialized
DEBUG - 2022-02-06 19:45:04 --> Encrypt Class Initialized
DEBUG - 2022-02-06 19:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 19:45:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-06 19:45:04 --> Email Class Initialized
INFO - 2022-02-06 19:45:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-06 19:45:04 --> Calendar Class Initialized
INFO - 2022-02-06 19:45:04 --> Model "Login_model" initialized
INFO - 2022-02-06 19:45:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-06 19:45:04 --> Final output sent to browser
DEBUG - 2022-02-06 19:45:04 --> Total execution time: 0.0240
