<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-26 04:52:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 04:52:50 --> Config Class Initialized
INFO - 2021-12-26 04:52:50 --> Hooks Class Initialized
DEBUG - 2021-12-26 04:52:50 --> UTF-8 Support Enabled
INFO - 2021-12-26 04:52:50 --> Utf8 Class Initialized
INFO - 2021-12-26 04:52:50 --> URI Class Initialized
DEBUG - 2021-12-26 04:52:50 --> No URI present. Default controller set.
INFO - 2021-12-26 04:52:50 --> Router Class Initialized
INFO - 2021-12-26 04:52:50 --> Output Class Initialized
INFO - 2021-12-26 04:52:50 --> Security Class Initialized
DEBUG - 2021-12-26 04:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 04:52:50 --> Input Class Initialized
INFO - 2021-12-26 04:52:50 --> Language Class Initialized
INFO - 2021-12-26 04:52:50 --> Loader Class Initialized
INFO - 2021-12-26 04:52:50 --> Helper loaded: url_helper
INFO - 2021-12-26 04:52:50 --> Helper loaded: form_helper
INFO - 2021-12-26 04:52:50 --> Helper loaded: common_helper
INFO - 2021-12-26 04:52:50 --> Database Driver Class Initialized
DEBUG - 2021-12-26 04:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 04:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 04:52:50 --> Controller Class Initialized
INFO - 2021-12-26 04:52:50 --> Form Validation Class Initialized
DEBUG - 2021-12-26 04:52:50 --> Encrypt Class Initialized
DEBUG - 2021-12-26 04:52:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 04:52:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 04:52:50 --> Email Class Initialized
INFO - 2021-12-26 04:52:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 04:52:50 --> Calendar Class Initialized
INFO - 2021-12-26 04:52:50 --> Model "Login_model" initialized
INFO - 2021-12-26 04:52:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 04:52:50 --> Final output sent to browser
DEBUG - 2021-12-26 04:52:50 --> Total execution time: 0.0231
ERROR - 2021-12-26 05:55:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 05:55:51 --> Config Class Initialized
INFO - 2021-12-26 05:55:51 --> Hooks Class Initialized
DEBUG - 2021-12-26 05:55:51 --> UTF-8 Support Enabled
INFO - 2021-12-26 05:55:51 --> Utf8 Class Initialized
INFO - 2021-12-26 05:55:51 --> URI Class Initialized
DEBUG - 2021-12-26 05:55:51 --> No URI present. Default controller set.
INFO - 2021-12-26 05:55:51 --> Router Class Initialized
INFO - 2021-12-26 05:55:51 --> Output Class Initialized
INFO - 2021-12-26 05:55:51 --> Security Class Initialized
DEBUG - 2021-12-26 05:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 05:55:51 --> Input Class Initialized
INFO - 2021-12-26 05:55:51 --> Language Class Initialized
INFO - 2021-12-26 05:55:51 --> Loader Class Initialized
INFO - 2021-12-26 05:55:51 --> Helper loaded: url_helper
INFO - 2021-12-26 05:55:51 --> Helper loaded: form_helper
INFO - 2021-12-26 05:55:51 --> Helper loaded: common_helper
INFO - 2021-12-26 05:55:51 --> Database Driver Class Initialized
DEBUG - 2021-12-26 05:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 05:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 05:55:51 --> Controller Class Initialized
INFO - 2021-12-26 05:55:51 --> Form Validation Class Initialized
DEBUG - 2021-12-26 05:55:51 --> Encrypt Class Initialized
DEBUG - 2021-12-26 05:55:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 05:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 05:55:51 --> Email Class Initialized
INFO - 2021-12-26 05:55:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 05:55:51 --> Calendar Class Initialized
INFO - 2021-12-26 05:55:51 --> Model "Login_model" initialized
INFO - 2021-12-26 05:55:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 05:55:51 --> Final output sent to browser
DEBUG - 2021-12-26 05:55:51 --> Total execution time: 0.0234
ERROR - 2021-12-26 08:53:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 08:53:10 --> Config Class Initialized
INFO - 2021-12-26 08:53:10 --> Hooks Class Initialized
DEBUG - 2021-12-26 08:53:10 --> UTF-8 Support Enabled
INFO - 2021-12-26 08:53:10 --> Utf8 Class Initialized
INFO - 2021-12-26 08:53:10 --> URI Class Initialized
DEBUG - 2021-12-26 08:53:10 --> No URI present. Default controller set.
INFO - 2021-12-26 08:53:10 --> Router Class Initialized
INFO - 2021-12-26 08:53:10 --> Output Class Initialized
INFO - 2021-12-26 08:53:10 --> Security Class Initialized
DEBUG - 2021-12-26 08:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 08:53:10 --> Input Class Initialized
INFO - 2021-12-26 08:53:10 --> Language Class Initialized
INFO - 2021-12-26 08:53:10 --> Loader Class Initialized
INFO - 2021-12-26 08:53:10 --> Helper loaded: url_helper
INFO - 2021-12-26 08:53:10 --> Helper loaded: form_helper
INFO - 2021-12-26 08:53:10 --> Helper loaded: common_helper
INFO - 2021-12-26 08:53:10 --> Database Driver Class Initialized
DEBUG - 2021-12-26 08:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 08:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 08:53:10 --> Controller Class Initialized
INFO - 2021-12-26 08:53:10 --> Form Validation Class Initialized
DEBUG - 2021-12-26 08:53:10 --> Encrypt Class Initialized
DEBUG - 2021-12-26 08:53:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 08:53:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 08:53:10 --> Email Class Initialized
INFO - 2021-12-26 08:53:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 08:53:10 --> Calendar Class Initialized
INFO - 2021-12-26 08:53:10 --> Model "Login_model" initialized
INFO - 2021-12-26 08:53:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 08:53:10 --> Final output sent to browser
DEBUG - 2021-12-26 08:53:10 --> Total execution time: 0.0270
ERROR - 2021-12-26 13:39:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 13:39:06 --> Config Class Initialized
INFO - 2021-12-26 13:39:06 --> Hooks Class Initialized
DEBUG - 2021-12-26 13:39:06 --> UTF-8 Support Enabled
INFO - 2021-12-26 13:39:06 --> Utf8 Class Initialized
INFO - 2021-12-26 13:39:06 --> URI Class Initialized
DEBUG - 2021-12-26 13:39:06 --> No URI present. Default controller set.
INFO - 2021-12-26 13:39:06 --> Router Class Initialized
INFO - 2021-12-26 13:39:06 --> Output Class Initialized
INFO - 2021-12-26 13:39:06 --> Security Class Initialized
DEBUG - 2021-12-26 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 13:39:06 --> Input Class Initialized
INFO - 2021-12-26 13:39:06 --> Language Class Initialized
INFO - 2021-12-26 13:39:06 --> Loader Class Initialized
INFO - 2021-12-26 13:39:06 --> Helper loaded: url_helper
INFO - 2021-12-26 13:39:06 --> Helper loaded: form_helper
INFO - 2021-12-26 13:39:06 --> Helper loaded: common_helper
INFO - 2021-12-26 13:39:06 --> Database Driver Class Initialized
DEBUG - 2021-12-26 13:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 13:39:06 --> Controller Class Initialized
INFO - 2021-12-26 13:39:06 --> Form Validation Class Initialized
DEBUG - 2021-12-26 13:39:06 --> Encrypt Class Initialized
DEBUG - 2021-12-26 13:39:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 13:39:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 13:39:06 --> Email Class Initialized
INFO - 2021-12-26 13:39:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 13:39:06 --> Calendar Class Initialized
INFO - 2021-12-26 13:39:06 --> Model "Login_model" initialized
INFO - 2021-12-26 13:39:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 13:39:06 --> Final output sent to browser
DEBUG - 2021-12-26 13:39:06 --> Total execution time: 0.0290
ERROR - 2021-12-26 14:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 14:18:48 --> Config Class Initialized
INFO - 2021-12-26 14:18:48 --> Hooks Class Initialized
DEBUG - 2021-12-26 14:18:48 --> UTF-8 Support Enabled
INFO - 2021-12-26 14:18:48 --> Utf8 Class Initialized
INFO - 2021-12-26 14:18:48 --> URI Class Initialized
DEBUG - 2021-12-26 14:18:48 --> No URI present. Default controller set.
INFO - 2021-12-26 14:18:48 --> Router Class Initialized
INFO - 2021-12-26 14:18:48 --> Output Class Initialized
INFO - 2021-12-26 14:18:48 --> Security Class Initialized
DEBUG - 2021-12-26 14:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 14:18:48 --> Input Class Initialized
INFO - 2021-12-26 14:18:48 --> Language Class Initialized
INFO - 2021-12-26 14:18:48 --> Loader Class Initialized
INFO - 2021-12-26 14:18:48 --> Helper loaded: url_helper
INFO - 2021-12-26 14:18:48 --> Helper loaded: form_helper
INFO - 2021-12-26 14:18:48 --> Helper loaded: common_helper
INFO - 2021-12-26 14:18:48 --> Database Driver Class Initialized
DEBUG - 2021-12-26 14:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 14:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 14:18:48 --> Controller Class Initialized
INFO - 2021-12-26 14:18:48 --> Form Validation Class Initialized
DEBUG - 2021-12-26 14:18:48 --> Encrypt Class Initialized
DEBUG - 2021-12-26 14:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 14:18:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 14:18:48 --> Email Class Initialized
INFO - 2021-12-26 14:18:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 14:18:48 --> Calendar Class Initialized
INFO - 2021-12-26 14:18:48 --> Model "Login_model" initialized
INFO - 2021-12-26 14:18:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 14:18:48 --> Final output sent to browser
DEBUG - 2021-12-26 14:18:48 --> Total execution time: 0.6979
ERROR - 2021-12-26 14:18:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 14:18:49 --> Config Class Initialized
INFO - 2021-12-26 14:18:49 --> Hooks Class Initialized
DEBUG - 2021-12-26 14:18:49 --> UTF-8 Support Enabled
INFO - 2021-12-26 14:18:49 --> Utf8 Class Initialized
INFO - 2021-12-26 14:18:49 --> URI Class Initialized
INFO - 2021-12-26 14:18:49 --> Router Class Initialized
INFO - 2021-12-26 14:18:49 --> Output Class Initialized
INFO - 2021-12-26 14:18:49 --> Security Class Initialized
DEBUG - 2021-12-26 14:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 14:18:49 --> Input Class Initialized
INFO - 2021-12-26 14:18:49 --> Language Class Initialized
ERROR - 2021-12-26 14:18:49 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-26 14:18:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 14:18:56 --> Config Class Initialized
INFO - 2021-12-26 14:18:56 --> Hooks Class Initialized
DEBUG - 2021-12-26 14:18:56 --> UTF-8 Support Enabled
INFO - 2021-12-26 14:18:56 --> Utf8 Class Initialized
INFO - 2021-12-26 14:18:56 --> URI Class Initialized
INFO - 2021-12-26 14:18:56 --> Router Class Initialized
INFO - 2021-12-26 14:18:56 --> Output Class Initialized
INFO - 2021-12-26 14:18:56 --> Security Class Initialized
DEBUG - 2021-12-26 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 14:18:56 --> Input Class Initialized
INFO - 2021-12-26 14:18:56 --> Language Class Initialized
INFO - 2021-12-26 14:18:56 --> Loader Class Initialized
INFO - 2021-12-26 14:18:56 --> Helper loaded: url_helper
INFO - 2021-12-26 14:18:56 --> Helper loaded: form_helper
INFO - 2021-12-26 14:18:56 --> Helper loaded: common_helper
INFO - 2021-12-26 14:18:56 --> Database Driver Class Initialized
DEBUG - 2021-12-26 14:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 14:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 14:18:56 --> Controller Class Initialized
INFO - 2021-12-26 14:18:56 --> Form Validation Class Initialized
DEBUG - 2021-12-26 14:18:56 --> Encrypt Class Initialized
DEBUG - 2021-12-26 14:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 14:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 14:18:56 --> Email Class Initialized
INFO - 2021-12-26 14:18:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 14:18:56 --> Calendar Class Initialized
INFO - 2021-12-26 14:18:56 --> Model "Login_model" initialized
ERROR - 2021-12-26 14:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 14:18:57 --> Config Class Initialized
INFO - 2021-12-26 14:18:57 --> Hooks Class Initialized
DEBUG - 2021-12-26 14:18:57 --> UTF-8 Support Enabled
INFO - 2021-12-26 14:18:57 --> Utf8 Class Initialized
INFO - 2021-12-26 14:18:57 --> URI Class Initialized
INFO - 2021-12-26 14:18:57 --> Router Class Initialized
INFO - 2021-12-26 14:18:57 --> Output Class Initialized
INFO - 2021-12-26 14:18:57 --> Security Class Initialized
DEBUG - 2021-12-26 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 14:18:57 --> Input Class Initialized
INFO - 2021-12-26 14:18:57 --> Language Class Initialized
INFO - 2021-12-26 14:18:57 --> Loader Class Initialized
INFO - 2021-12-26 14:18:57 --> Helper loaded: url_helper
INFO - 2021-12-26 14:18:57 --> Helper loaded: form_helper
INFO - 2021-12-26 14:18:57 --> Helper loaded: common_helper
INFO - 2021-12-26 14:18:57 --> Database Driver Class Initialized
DEBUG - 2021-12-26 14:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 14:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 14:18:57 --> Controller Class Initialized
INFO - 2021-12-26 14:18:57 --> Form Validation Class Initialized
DEBUG - 2021-12-26 14:18:57 --> Encrypt Class Initialized
DEBUG - 2021-12-26 14:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 14:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 14:18:57 --> Email Class Initialized
INFO - 2021-12-26 14:18:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 14:18:57 --> Calendar Class Initialized
INFO - 2021-12-26 14:18:57 --> Model "Login_model" initialized
ERROR - 2021-12-26 14:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 14:18:57 --> Config Class Initialized
INFO - 2021-12-26 14:18:57 --> Hooks Class Initialized
DEBUG - 2021-12-26 14:18:57 --> UTF-8 Support Enabled
INFO - 2021-12-26 14:18:57 --> Utf8 Class Initialized
INFO - 2021-12-26 14:18:57 --> URI Class Initialized
DEBUG - 2021-12-26 14:18:57 --> No URI present. Default controller set.
INFO - 2021-12-26 14:18:57 --> Router Class Initialized
INFO - 2021-12-26 14:18:57 --> Output Class Initialized
INFO - 2021-12-26 14:18:57 --> Security Class Initialized
DEBUG - 2021-12-26 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 14:18:57 --> Input Class Initialized
INFO - 2021-12-26 14:18:57 --> Language Class Initialized
INFO - 2021-12-26 14:18:57 --> Loader Class Initialized
INFO - 2021-12-26 14:18:57 --> Helper loaded: url_helper
INFO - 2021-12-26 14:18:57 --> Helper loaded: form_helper
INFO - 2021-12-26 14:18:57 --> Helper loaded: common_helper
INFO - 2021-12-26 14:18:57 --> Database Driver Class Initialized
DEBUG - 2021-12-26 14:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 14:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 14:18:57 --> Controller Class Initialized
INFO - 2021-12-26 14:18:57 --> Form Validation Class Initialized
DEBUG - 2021-12-26 14:18:57 --> Encrypt Class Initialized
DEBUG - 2021-12-26 14:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 14:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 14:18:57 --> Email Class Initialized
INFO - 2021-12-26 14:18:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 14:18:57 --> Calendar Class Initialized
INFO - 2021-12-26 14:18:57 --> Model "Login_model" initialized
INFO - 2021-12-26 14:18:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 14:18:57 --> Final output sent to browser
DEBUG - 2021-12-26 14:18:57 --> Total execution time: 0.0369
ERROR - 2021-12-26 14:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 14:18:58 --> Config Class Initialized
INFO - 2021-12-26 14:18:58 --> Hooks Class Initialized
DEBUG - 2021-12-26 14:18:58 --> UTF-8 Support Enabled
INFO - 2021-12-26 14:18:58 --> Utf8 Class Initialized
INFO - 2021-12-26 14:18:58 --> URI Class Initialized
INFO - 2021-12-26 14:18:58 --> Router Class Initialized
INFO - 2021-12-26 14:18:58 --> Output Class Initialized
INFO - 2021-12-26 14:18:58 --> Security Class Initialized
DEBUG - 2021-12-26 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 14:18:58 --> Input Class Initialized
INFO - 2021-12-26 14:18:58 --> Language Class Initialized
INFO - 2021-12-26 14:18:58 --> Loader Class Initialized
INFO - 2021-12-26 14:18:58 --> Helper loaded: url_helper
INFO - 2021-12-26 14:18:58 --> Helper loaded: form_helper
INFO - 2021-12-26 14:18:58 --> Helper loaded: common_helper
INFO - 2021-12-26 14:18:58 --> Database Driver Class Initialized
DEBUG - 2021-12-26 14:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 14:18:58 --> Controller Class Initialized
INFO - 2021-12-26 14:18:58 --> Form Validation Class Initialized
DEBUG - 2021-12-26 14:18:58 --> Encrypt Class Initialized
DEBUG - 2021-12-26 14:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 14:18:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 14:18:58 --> Email Class Initialized
INFO - 2021-12-26 14:18:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 14:18:58 --> Calendar Class Initialized
INFO - 2021-12-26 14:18:58 --> Model "Login_model" initialized
INFO - 2021-12-26 14:18:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 14:18:58 --> Final output sent to browser
DEBUG - 2021-12-26 14:18:58 --> Total execution time: 0.0229
ERROR - 2021-12-26 16:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 16:35:50 --> Config Class Initialized
INFO - 2021-12-26 16:35:50 --> Hooks Class Initialized
DEBUG - 2021-12-26 16:35:50 --> UTF-8 Support Enabled
INFO - 2021-12-26 16:35:50 --> Utf8 Class Initialized
INFO - 2021-12-26 16:35:50 --> URI Class Initialized
DEBUG - 2021-12-26 16:35:50 --> No URI present. Default controller set.
INFO - 2021-12-26 16:35:50 --> Router Class Initialized
INFO - 2021-12-26 16:35:50 --> Output Class Initialized
INFO - 2021-12-26 16:35:50 --> Security Class Initialized
DEBUG - 2021-12-26 16:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 16:35:50 --> Input Class Initialized
INFO - 2021-12-26 16:35:50 --> Language Class Initialized
INFO - 2021-12-26 16:35:50 --> Loader Class Initialized
INFO - 2021-12-26 16:35:50 --> Helper loaded: url_helper
INFO - 2021-12-26 16:35:50 --> Helper loaded: form_helper
INFO - 2021-12-26 16:35:50 --> Helper loaded: common_helper
INFO - 2021-12-26 16:35:50 --> Database Driver Class Initialized
DEBUG - 2021-12-26 16:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 16:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 16:35:50 --> Controller Class Initialized
INFO - 2021-12-26 16:35:50 --> Form Validation Class Initialized
DEBUG - 2021-12-26 16:35:50 --> Encrypt Class Initialized
DEBUG - 2021-12-26 16:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 16:35:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 16:35:50 --> Email Class Initialized
INFO - 2021-12-26 16:35:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 16:35:50 --> Calendar Class Initialized
INFO - 2021-12-26 16:35:50 --> Model "Login_model" initialized
INFO - 2021-12-26 16:35:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 16:35:50 --> Final output sent to browser
DEBUG - 2021-12-26 16:35:50 --> Total execution time: 0.0282
ERROR - 2021-12-26 17:18:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 17:18:04 --> Config Class Initialized
INFO - 2021-12-26 17:18:04 --> Hooks Class Initialized
DEBUG - 2021-12-26 17:18:04 --> UTF-8 Support Enabled
INFO - 2021-12-26 17:18:04 --> Utf8 Class Initialized
INFO - 2021-12-26 17:18:04 --> URI Class Initialized
DEBUG - 2021-12-26 17:18:04 --> No URI present. Default controller set.
INFO - 2021-12-26 17:18:04 --> Router Class Initialized
INFO - 2021-12-26 17:18:04 --> Output Class Initialized
INFO - 2021-12-26 17:18:04 --> Security Class Initialized
DEBUG - 2021-12-26 17:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 17:18:04 --> Input Class Initialized
INFO - 2021-12-26 17:18:04 --> Language Class Initialized
INFO - 2021-12-26 17:18:04 --> Loader Class Initialized
INFO - 2021-12-26 17:18:04 --> Helper loaded: url_helper
INFO - 2021-12-26 17:18:04 --> Helper loaded: form_helper
INFO - 2021-12-26 17:18:04 --> Helper loaded: common_helper
INFO - 2021-12-26 17:18:04 --> Database Driver Class Initialized
DEBUG - 2021-12-26 17:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 17:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 17:18:04 --> Controller Class Initialized
INFO - 2021-12-26 17:18:04 --> Form Validation Class Initialized
DEBUG - 2021-12-26 17:18:04 --> Encrypt Class Initialized
DEBUG - 2021-12-26 17:18:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 17:18:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 17:18:04 --> Email Class Initialized
INFO - 2021-12-26 17:18:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 17:18:04 --> Calendar Class Initialized
INFO - 2021-12-26 17:18:04 --> Model "Login_model" initialized
INFO - 2021-12-26 17:18:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 17:18:04 --> Final output sent to browser
DEBUG - 2021-12-26 17:18:04 --> Total execution time: 0.0274
ERROR - 2021-12-26 17:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 17:18:05 --> Config Class Initialized
INFO - 2021-12-26 17:18:05 --> Hooks Class Initialized
DEBUG - 2021-12-26 17:18:05 --> UTF-8 Support Enabled
INFO - 2021-12-26 17:18:05 --> Utf8 Class Initialized
INFO - 2021-12-26 17:18:05 --> URI Class Initialized
INFO - 2021-12-26 17:18:05 --> Router Class Initialized
INFO - 2021-12-26 17:18:05 --> Output Class Initialized
INFO - 2021-12-26 17:18:05 --> Security Class Initialized
DEBUG - 2021-12-26 17:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 17:18:05 --> Input Class Initialized
INFO - 2021-12-26 17:18:05 --> Language Class Initialized
ERROR - 2021-12-26 17:18:05 --> 404 Page Not Found: Register/index
ERROR - 2021-12-26 17:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 17:18:06 --> Config Class Initialized
INFO - 2021-12-26 17:18:06 --> Hooks Class Initialized
DEBUG - 2021-12-26 17:18:06 --> UTF-8 Support Enabled
INFO - 2021-12-26 17:18:06 --> Utf8 Class Initialized
INFO - 2021-12-26 17:18:06 --> URI Class Initialized
INFO - 2021-12-26 17:18:06 --> Router Class Initialized
INFO - 2021-12-26 17:18:06 --> Output Class Initialized
INFO - 2021-12-26 17:18:06 --> Security Class Initialized
DEBUG - 2021-12-26 17:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 17:18:06 --> Input Class Initialized
INFO - 2021-12-26 17:18:06 --> Language Class Initialized
INFO - 2021-12-26 17:18:06 --> Loader Class Initialized
INFO - 2021-12-26 17:18:06 --> Helper loaded: url_helper
INFO - 2021-12-26 17:18:06 --> Helper loaded: form_helper
INFO - 2021-12-26 17:18:06 --> Helper loaded: common_helper
INFO - 2021-12-26 17:18:06 --> Database Driver Class Initialized
DEBUG - 2021-12-26 17:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 17:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 17:18:06 --> Controller Class Initialized
INFO - 2021-12-26 17:18:06 --> Form Validation Class Initialized
DEBUG - 2021-12-26 17:18:06 --> Encrypt Class Initialized
DEBUG - 2021-12-26 17:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 17:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 17:18:06 --> Email Class Initialized
INFO - 2021-12-26 17:18:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 17:18:06 --> Calendar Class Initialized
INFO - 2021-12-26 17:18:06 --> Model "Login_model" initialized
INFO - 2021-12-26 17:18:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 17:18:06 --> Final output sent to browser
DEBUG - 2021-12-26 17:18:06 --> Total execution time: 0.0241
ERROR - 2021-12-26 17:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 17:18:06 --> Config Class Initialized
INFO - 2021-12-26 17:18:06 --> Hooks Class Initialized
DEBUG - 2021-12-26 17:18:06 --> UTF-8 Support Enabled
INFO - 2021-12-26 17:18:06 --> Utf8 Class Initialized
INFO - 2021-12-26 17:18:06 --> URI Class Initialized
DEBUG - 2021-12-26 17:18:06 --> No URI present. Default controller set.
INFO - 2021-12-26 17:18:06 --> Router Class Initialized
INFO - 2021-12-26 17:18:06 --> Output Class Initialized
INFO - 2021-12-26 17:18:06 --> Security Class Initialized
DEBUG - 2021-12-26 17:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 17:18:06 --> Input Class Initialized
INFO - 2021-12-26 17:18:06 --> Language Class Initialized
INFO - 2021-12-26 17:18:06 --> Loader Class Initialized
INFO - 2021-12-26 17:18:06 --> Helper loaded: url_helper
INFO - 2021-12-26 17:18:06 --> Helper loaded: form_helper
INFO - 2021-12-26 17:18:06 --> Helper loaded: common_helper
INFO - 2021-12-26 17:18:06 --> Database Driver Class Initialized
DEBUG - 2021-12-26 17:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 17:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 17:18:06 --> Controller Class Initialized
INFO - 2021-12-26 17:18:06 --> Form Validation Class Initialized
DEBUG - 2021-12-26 17:18:06 --> Encrypt Class Initialized
DEBUG - 2021-12-26 17:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 17:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 17:18:06 --> Email Class Initialized
INFO - 2021-12-26 17:18:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 17:18:06 --> Calendar Class Initialized
INFO - 2021-12-26 17:18:06 --> Model "Login_model" initialized
INFO - 2021-12-26 17:18:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 17:18:06 --> Final output sent to browser
DEBUG - 2021-12-26 17:18:06 --> Total execution time: 0.0226
ERROR - 2021-12-26 17:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 17:18:07 --> Config Class Initialized
INFO - 2021-12-26 17:18:07 --> Hooks Class Initialized
DEBUG - 2021-12-26 17:18:07 --> UTF-8 Support Enabled
INFO - 2021-12-26 17:18:07 --> Utf8 Class Initialized
INFO - 2021-12-26 17:18:07 --> URI Class Initialized
INFO - 2021-12-26 17:18:07 --> Router Class Initialized
INFO - 2021-12-26 17:18:07 --> Output Class Initialized
INFO - 2021-12-26 17:18:07 --> Security Class Initialized
DEBUG - 2021-12-26 17:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 17:18:07 --> Input Class Initialized
INFO - 2021-12-26 17:18:07 --> Language Class Initialized
INFO - 2021-12-26 17:18:07 --> Loader Class Initialized
INFO - 2021-12-26 17:18:07 --> Helper loaded: url_helper
INFO - 2021-12-26 17:18:07 --> Helper loaded: form_helper
INFO - 2021-12-26 17:18:07 --> Helper loaded: common_helper
INFO - 2021-12-26 17:18:07 --> Database Driver Class Initialized
DEBUG - 2021-12-26 17:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 17:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 17:18:07 --> Controller Class Initialized
INFO - 2021-12-26 17:18:07 --> Form Validation Class Initialized
DEBUG - 2021-12-26 17:18:07 --> Encrypt Class Initialized
DEBUG - 2021-12-26 17:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 17:18:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 17:18:07 --> Email Class Initialized
INFO - 2021-12-26 17:18:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 17:18:07 --> Calendar Class Initialized
INFO - 2021-12-26 17:18:07 --> Model "Login_model" initialized
ERROR - 2021-12-26 17:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 17:18:08 --> Config Class Initialized
INFO - 2021-12-26 17:18:08 --> Hooks Class Initialized
DEBUG - 2021-12-26 17:18:08 --> UTF-8 Support Enabled
INFO - 2021-12-26 17:18:08 --> Utf8 Class Initialized
INFO - 2021-12-26 17:18:08 --> URI Class Initialized
INFO - 2021-12-26 17:18:08 --> Router Class Initialized
INFO - 2021-12-26 17:18:08 --> Output Class Initialized
INFO - 2021-12-26 17:18:08 --> Security Class Initialized
DEBUG - 2021-12-26 17:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 17:18:08 --> Input Class Initialized
INFO - 2021-12-26 17:18:08 --> Language Class Initialized
INFO - 2021-12-26 17:18:08 --> Loader Class Initialized
INFO - 2021-12-26 17:18:08 --> Helper loaded: url_helper
INFO - 2021-12-26 17:18:08 --> Helper loaded: form_helper
INFO - 2021-12-26 17:18:08 --> Helper loaded: common_helper
INFO - 2021-12-26 17:18:08 --> Database Driver Class Initialized
DEBUG - 2021-12-26 17:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 17:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 17:18:08 --> Controller Class Initialized
INFO - 2021-12-26 17:18:08 --> Form Validation Class Initialized
DEBUG - 2021-12-26 17:18:08 --> Encrypt Class Initialized
DEBUG - 2021-12-26 17:18:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 17:18:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 17:18:08 --> Email Class Initialized
INFO - 2021-12-26 17:18:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 17:18:08 --> Calendar Class Initialized
INFO - 2021-12-26 17:18:08 --> Model "Login_model" initialized
INFO - 2021-12-26 17:18:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 17:18:08 --> Final output sent to browser
DEBUG - 2021-12-26 17:18:08 --> Total execution time: 0.0227
ERROR - 2021-12-26 21:22:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 21:22:45 --> Config Class Initialized
INFO - 2021-12-26 21:22:45 --> Hooks Class Initialized
DEBUG - 2021-12-26 21:22:45 --> UTF-8 Support Enabled
INFO - 2021-12-26 21:22:45 --> Utf8 Class Initialized
INFO - 2021-12-26 21:22:45 --> URI Class Initialized
DEBUG - 2021-12-26 21:22:45 --> No URI present. Default controller set.
INFO - 2021-12-26 21:22:45 --> Router Class Initialized
INFO - 2021-12-26 21:22:45 --> Output Class Initialized
INFO - 2021-12-26 21:22:45 --> Security Class Initialized
DEBUG - 2021-12-26 21:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 21:22:45 --> Input Class Initialized
INFO - 2021-12-26 21:22:45 --> Language Class Initialized
INFO - 2021-12-26 21:22:45 --> Loader Class Initialized
INFO - 2021-12-26 21:22:45 --> Helper loaded: url_helper
INFO - 2021-12-26 21:22:45 --> Helper loaded: form_helper
INFO - 2021-12-26 21:22:45 --> Helper loaded: common_helper
INFO - 2021-12-26 21:22:45 --> Database Driver Class Initialized
DEBUG - 2021-12-26 21:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 21:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 21:22:46 --> Controller Class Initialized
INFO - 2021-12-26 21:22:46 --> Form Validation Class Initialized
DEBUG - 2021-12-26 21:22:46 --> Encrypt Class Initialized
DEBUG - 2021-12-26 21:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 21:22:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 21:22:46 --> Email Class Initialized
INFO - 2021-12-26 21:22:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 21:22:46 --> Calendar Class Initialized
INFO - 2021-12-26 21:22:46 --> Model "Login_model" initialized
INFO - 2021-12-26 21:22:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 21:22:46 --> Final output sent to browser
DEBUG - 2021-12-26 21:22:46 --> Total execution time: 0.1234
ERROR - 2021-12-26 21:56:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 21:56:52 --> Config Class Initialized
INFO - 2021-12-26 21:56:52 --> Hooks Class Initialized
DEBUG - 2021-12-26 21:56:52 --> UTF-8 Support Enabled
INFO - 2021-12-26 21:56:52 --> Utf8 Class Initialized
INFO - 2021-12-26 21:56:52 --> URI Class Initialized
DEBUG - 2021-12-26 21:56:52 --> No URI present. Default controller set.
INFO - 2021-12-26 21:56:52 --> Router Class Initialized
INFO - 2021-12-26 21:56:52 --> Output Class Initialized
INFO - 2021-12-26 21:56:52 --> Security Class Initialized
DEBUG - 2021-12-26 21:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 21:56:52 --> Input Class Initialized
INFO - 2021-12-26 21:56:52 --> Language Class Initialized
INFO - 2021-12-26 21:56:52 --> Loader Class Initialized
INFO - 2021-12-26 21:56:52 --> Helper loaded: url_helper
INFO - 2021-12-26 21:56:52 --> Helper loaded: form_helper
INFO - 2021-12-26 21:56:52 --> Helper loaded: common_helper
INFO - 2021-12-26 21:56:52 --> Database Driver Class Initialized
DEBUG - 2021-12-26 21:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 21:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 21:56:52 --> Controller Class Initialized
INFO - 2021-12-26 21:56:52 --> Form Validation Class Initialized
DEBUG - 2021-12-26 21:56:52 --> Encrypt Class Initialized
DEBUG - 2021-12-26 21:56:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 21:56:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 21:56:52 --> Email Class Initialized
INFO - 2021-12-26 21:56:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 21:56:52 --> Calendar Class Initialized
INFO - 2021-12-26 21:56:52 --> Model "Login_model" initialized
INFO - 2021-12-26 21:56:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 21:56:52 --> Final output sent to browser
DEBUG - 2021-12-26 21:56:52 --> Total execution time: 0.0594
ERROR - 2021-12-26 21:58:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 21:58:21 --> Config Class Initialized
INFO - 2021-12-26 21:58:21 --> Hooks Class Initialized
DEBUG - 2021-12-26 21:58:21 --> UTF-8 Support Enabled
INFO - 2021-12-26 21:58:21 --> Utf8 Class Initialized
INFO - 2021-12-26 21:58:21 --> URI Class Initialized
DEBUG - 2021-12-26 21:58:21 --> No URI present. Default controller set.
INFO - 2021-12-26 21:58:21 --> Router Class Initialized
INFO - 2021-12-26 21:58:21 --> Output Class Initialized
INFO - 2021-12-26 21:58:21 --> Security Class Initialized
DEBUG - 2021-12-26 21:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 21:58:21 --> Input Class Initialized
INFO - 2021-12-26 21:58:21 --> Language Class Initialized
INFO - 2021-12-26 21:58:21 --> Loader Class Initialized
INFO - 2021-12-26 21:58:21 --> Helper loaded: url_helper
INFO - 2021-12-26 21:58:21 --> Helper loaded: form_helper
INFO - 2021-12-26 21:58:21 --> Helper loaded: common_helper
INFO - 2021-12-26 21:58:21 --> Database Driver Class Initialized
DEBUG - 2021-12-26 21:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 21:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 21:58:21 --> Controller Class Initialized
INFO - 2021-12-26 21:58:21 --> Form Validation Class Initialized
DEBUG - 2021-12-26 21:58:21 --> Encrypt Class Initialized
DEBUG - 2021-12-26 21:58:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 21:58:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 21:58:21 --> Email Class Initialized
INFO - 2021-12-26 21:58:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 21:58:21 --> Calendar Class Initialized
INFO - 2021-12-26 21:58:21 --> Model "Login_model" initialized
INFO - 2021-12-26 21:58:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 21:58:21 --> Final output sent to browser
DEBUG - 2021-12-26 21:58:21 --> Total execution time: 0.0241
ERROR - 2021-12-26 21:58:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 21:58:28 --> Config Class Initialized
INFO - 2021-12-26 21:58:28 --> Hooks Class Initialized
DEBUG - 2021-12-26 21:58:28 --> UTF-8 Support Enabled
INFO - 2021-12-26 21:58:28 --> Utf8 Class Initialized
INFO - 2021-12-26 21:58:28 --> URI Class Initialized
DEBUG - 2021-12-26 21:58:28 --> No URI present. Default controller set.
INFO - 2021-12-26 21:58:28 --> Router Class Initialized
INFO - 2021-12-26 21:58:28 --> Output Class Initialized
INFO - 2021-12-26 21:58:28 --> Security Class Initialized
DEBUG - 2021-12-26 21:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 21:58:28 --> Input Class Initialized
INFO - 2021-12-26 21:58:28 --> Language Class Initialized
INFO - 2021-12-26 21:58:28 --> Loader Class Initialized
INFO - 2021-12-26 21:58:28 --> Helper loaded: url_helper
INFO - 2021-12-26 21:58:28 --> Helper loaded: form_helper
INFO - 2021-12-26 21:58:28 --> Helper loaded: common_helper
INFO - 2021-12-26 21:58:28 --> Database Driver Class Initialized
DEBUG - 2021-12-26 21:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 21:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 21:58:28 --> Controller Class Initialized
INFO - 2021-12-26 21:58:28 --> Form Validation Class Initialized
DEBUG - 2021-12-26 21:58:28 --> Encrypt Class Initialized
DEBUG - 2021-12-26 21:58:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 21:58:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 21:58:28 --> Email Class Initialized
INFO - 2021-12-26 21:58:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 21:58:28 --> Calendar Class Initialized
INFO - 2021-12-26 21:58:28 --> Model "Login_model" initialized
INFO - 2021-12-26 21:58:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 21:58:28 --> Final output sent to browser
DEBUG - 2021-12-26 21:58:28 --> Total execution time: 0.0227
ERROR - 2021-12-26 23:45:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 23:45:37 --> Config Class Initialized
INFO - 2021-12-26 23:45:37 --> Hooks Class Initialized
DEBUG - 2021-12-26 23:45:37 --> UTF-8 Support Enabled
INFO - 2021-12-26 23:45:37 --> Utf8 Class Initialized
INFO - 2021-12-26 23:45:37 --> URI Class Initialized
DEBUG - 2021-12-26 23:45:37 --> No URI present. Default controller set.
INFO - 2021-12-26 23:45:37 --> Router Class Initialized
INFO - 2021-12-26 23:45:37 --> Output Class Initialized
INFO - 2021-12-26 23:45:37 --> Security Class Initialized
DEBUG - 2021-12-26 23:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 23:45:37 --> Input Class Initialized
INFO - 2021-12-26 23:45:37 --> Language Class Initialized
INFO - 2021-12-26 23:45:37 --> Loader Class Initialized
INFO - 2021-12-26 23:45:37 --> Helper loaded: url_helper
INFO - 2021-12-26 23:45:37 --> Helper loaded: form_helper
INFO - 2021-12-26 23:45:37 --> Helper loaded: common_helper
INFO - 2021-12-26 23:45:37 --> Database Driver Class Initialized
DEBUG - 2021-12-26 23:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 23:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 23:45:37 --> Controller Class Initialized
INFO - 2021-12-26 23:45:37 --> Form Validation Class Initialized
DEBUG - 2021-12-26 23:45:37 --> Encrypt Class Initialized
DEBUG - 2021-12-26 23:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 23:45:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 23:45:37 --> Email Class Initialized
INFO - 2021-12-26 23:45:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 23:45:37 --> Calendar Class Initialized
INFO - 2021-12-26 23:45:37 --> Model "Login_model" initialized
INFO - 2021-12-26 23:45:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 23:45:37 --> Final output sent to browser
DEBUG - 2021-12-26 23:45:37 --> Total execution time: 0.0224
ERROR - 2021-12-26 23:45:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-26 23:45:59 --> Config Class Initialized
INFO - 2021-12-26 23:45:59 --> Hooks Class Initialized
DEBUG - 2021-12-26 23:45:59 --> UTF-8 Support Enabled
INFO - 2021-12-26 23:45:59 --> Utf8 Class Initialized
INFO - 2021-12-26 23:45:59 --> URI Class Initialized
DEBUG - 2021-12-26 23:45:59 --> No URI present. Default controller set.
INFO - 2021-12-26 23:45:59 --> Router Class Initialized
INFO - 2021-12-26 23:45:59 --> Output Class Initialized
INFO - 2021-12-26 23:45:59 --> Security Class Initialized
DEBUG - 2021-12-26 23:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-26 23:45:59 --> Input Class Initialized
INFO - 2021-12-26 23:45:59 --> Language Class Initialized
INFO - 2021-12-26 23:45:59 --> Loader Class Initialized
INFO - 2021-12-26 23:45:59 --> Helper loaded: url_helper
INFO - 2021-12-26 23:45:59 --> Helper loaded: form_helper
INFO - 2021-12-26 23:45:59 --> Helper loaded: common_helper
INFO - 2021-12-26 23:45:59 --> Database Driver Class Initialized
DEBUG - 2021-12-26 23:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-26 23:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-26 23:45:59 --> Controller Class Initialized
INFO - 2021-12-26 23:45:59 --> Form Validation Class Initialized
DEBUG - 2021-12-26 23:45:59 --> Encrypt Class Initialized
DEBUG - 2021-12-26 23:45:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-26 23:45:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-26 23:45:59 --> Email Class Initialized
INFO - 2021-12-26 23:45:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-26 23:45:59 --> Calendar Class Initialized
INFO - 2021-12-26 23:45:59 --> Model "Login_model" initialized
INFO - 2021-12-26 23:45:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-26 23:45:59 --> Final output sent to browser
DEBUG - 2021-12-26 23:45:59 --> Total execution time: 0.0585
