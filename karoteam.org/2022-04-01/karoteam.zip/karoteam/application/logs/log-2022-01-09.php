<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-09 09:44:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 09:44:31 --> Config Class Initialized
INFO - 2022-01-09 09:44:31 --> Hooks Class Initialized
DEBUG - 2022-01-09 09:44:31 --> UTF-8 Support Enabled
INFO - 2022-01-09 09:44:31 --> Utf8 Class Initialized
INFO - 2022-01-09 09:44:31 --> URI Class Initialized
DEBUG - 2022-01-09 09:44:31 --> No URI present. Default controller set.
INFO - 2022-01-09 09:44:31 --> Router Class Initialized
INFO - 2022-01-09 09:44:31 --> Output Class Initialized
INFO - 2022-01-09 09:44:31 --> Security Class Initialized
DEBUG - 2022-01-09 09:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 09:44:31 --> Input Class Initialized
INFO - 2022-01-09 09:44:31 --> Language Class Initialized
INFO - 2022-01-09 09:44:31 --> Loader Class Initialized
INFO - 2022-01-09 09:44:31 --> Helper loaded: url_helper
INFO - 2022-01-09 09:44:31 --> Helper loaded: form_helper
INFO - 2022-01-09 09:44:31 --> Helper loaded: common_helper
INFO - 2022-01-09 09:44:31 --> Database Driver Class Initialized
DEBUG - 2022-01-09 09:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 09:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 09:44:31 --> Controller Class Initialized
INFO - 2022-01-09 09:44:31 --> Form Validation Class Initialized
DEBUG - 2022-01-09 09:44:31 --> Encrypt Class Initialized
DEBUG - 2022-01-09 09:44:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 09:44:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 09:44:31 --> Email Class Initialized
INFO - 2022-01-09 09:44:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 09:44:31 --> Calendar Class Initialized
INFO - 2022-01-09 09:44:31 --> Model "Login_model" initialized
INFO - 2022-01-09 09:44:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 09:44:31 --> Final output sent to browser
DEBUG - 2022-01-09 09:44:31 --> Total execution time: 0.0230
ERROR - 2022-01-09 09:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 09:44:32 --> Config Class Initialized
INFO - 2022-01-09 09:44:32 --> Hooks Class Initialized
DEBUG - 2022-01-09 09:44:32 --> UTF-8 Support Enabled
INFO - 2022-01-09 09:44:32 --> Utf8 Class Initialized
INFO - 2022-01-09 09:44:32 --> URI Class Initialized
INFO - 2022-01-09 09:44:32 --> Router Class Initialized
INFO - 2022-01-09 09:44:32 --> Output Class Initialized
INFO - 2022-01-09 09:44:32 --> Security Class Initialized
DEBUG - 2022-01-09 09:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 09:44:32 --> Input Class Initialized
INFO - 2022-01-09 09:44:32 --> Language Class Initialized
ERROR - 2022-01-09 09:44:32 --> 404 Page Not Found: Register/index
ERROR - 2022-01-09 09:44:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 09:44:37 --> Config Class Initialized
INFO - 2022-01-09 09:44:37 --> Hooks Class Initialized
DEBUG - 2022-01-09 09:44:37 --> UTF-8 Support Enabled
INFO - 2022-01-09 09:44:37 --> Utf8 Class Initialized
INFO - 2022-01-09 09:44:37 --> URI Class Initialized
INFO - 2022-01-09 09:44:37 --> Router Class Initialized
INFO - 2022-01-09 09:44:37 --> Output Class Initialized
INFO - 2022-01-09 09:44:37 --> Security Class Initialized
DEBUG - 2022-01-09 09:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 09:44:37 --> Input Class Initialized
INFO - 2022-01-09 09:44:37 --> Language Class Initialized
INFO - 2022-01-09 09:44:37 --> Loader Class Initialized
INFO - 2022-01-09 09:44:37 --> Helper loaded: url_helper
INFO - 2022-01-09 09:44:37 --> Helper loaded: form_helper
INFO - 2022-01-09 09:44:37 --> Helper loaded: common_helper
INFO - 2022-01-09 09:44:37 --> Database Driver Class Initialized
DEBUG - 2022-01-09 09:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 09:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 09:44:37 --> Controller Class Initialized
INFO - 2022-01-09 09:44:37 --> Form Validation Class Initialized
DEBUG - 2022-01-09 09:44:37 --> Encrypt Class Initialized
DEBUG - 2022-01-09 09:44:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 09:44:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 09:44:37 --> Email Class Initialized
INFO - 2022-01-09 09:44:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 09:44:37 --> Calendar Class Initialized
INFO - 2022-01-09 09:44:37 --> Model "Login_model" initialized
INFO - 2022-01-09 09:44:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 09:44:37 --> Final output sent to browser
DEBUG - 2022-01-09 09:44:37 --> Total execution time: 0.0218
ERROR - 2022-01-09 09:44:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 09:44:38 --> Config Class Initialized
INFO - 2022-01-09 09:44:38 --> Hooks Class Initialized
DEBUG - 2022-01-09 09:44:38 --> UTF-8 Support Enabled
INFO - 2022-01-09 09:44:38 --> Utf8 Class Initialized
INFO - 2022-01-09 09:44:38 --> URI Class Initialized
DEBUG - 2022-01-09 09:44:38 --> No URI present. Default controller set.
INFO - 2022-01-09 09:44:38 --> Router Class Initialized
INFO - 2022-01-09 09:44:38 --> Output Class Initialized
INFO - 2022-01-09 09:44:38 --> Security Class Initialized
DEBUG - 2022-01-09 09:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 09:44:38 --> Input Class Initialized
INFO - 2022-01-09 09:44:38 --> Language Class Initialized
INFO - 2022-01-09 09:44:38 --> Loader Class Initialized
INFO - 2022-01-09 09:44:38 --> Helper loaded: url_helper
INFO - 2022-01-09 09:44:38 --> Helper loaded: form_helper
INFO - 2022-01-09 09:44:38 --> Helper loaded: common_helper
INFO - 2022-01-09 09:44:38 --> Database Driver Class Initialized
DEBUG - 2022-01-09 09:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 09:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 09:44:38 --> Controller Class Initialized
INFO - 2022-01-09 09:44:38 --> Form Validation Class Initialized
DEBUG - 2022-01-09 09:44:38 --> Encrypt Class Initialized
DEBUG - 2022-01-09 09:44:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 09:44:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 09:44:38 --> Email Class Initialized
INFO - 2022-01-09 09:44:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 09:44:38 --> Calendar Class Initialized
INFO - 2022-01-09 09:44:38 --> Model "Login_model" initialized
INFO - 2022-01-09 09:44:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 09:44:38 --> Final output sent to browser
DEBUG - 2022-01-09 09:44:38 --> Total execution time: 0.0265
ERROR - 2022-01-09 09:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 09:44:42 --> Config Class Initialized
INFO - 2022-01-09 09:44:42 --> Hooks Class Initialized
DEBUG - 2022-01-09 09:44:42 --> UTF-8 Support Enabled
INFO - 2022-01-09 09:44:42 --> Utf8 Class Initialized
INFO - 2022-01-09 09:44:42 --> URI Class Initialized
INFO - 2022-01-09 09:44:42 --> Router Class Initialized
INFO - 2022-01-09 09:44:42 --> Output Class Initialized
INFO - 2022-01-09 09:44:42 --> Security Class Initialized
DEBUG - 2022-01-09 09:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 09:44:42 --> Input Class Initialized
INFO - 2022-01-09 09:44:42 --> Language Class Initialized
INFO - 2022-01-09 09:44:42 --> Loader Class Initialized
INFO - 2022-01-09 09:44:42 --> Helper loaded: url_helper
INFO - 2022-01-09 09:44:42 --> Helper loaded: form_helper
INFO - 2022-01-09 09:44:42 --> Helper loaded: common_helper
INFO - 2022-01-09 09:44:42 --> Database Driver Class Initialized
DEBUG - 2022-01-09 09:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 09:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 09:44:42 --> Controller Class Initialized
INFO - 2022-01-09 09:44:42 --> Form Validation Class Initialized
DEBUG - 2022-01-09 09:44:42 --> Encrypt Class Initialized
DEBUG - 2022-01-09 09:44:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 09:44:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 09:44:42 --> Email Class Initialized
INFO - 2022-01-09 09:44:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 09:44:42 --> Calendar Class Initialized
INFO - 2022-01-09 09:44:42 --> Model "Login_model" initialized
ERROR - 2022-01-09 09:44:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 09:44:46 --> Config Class Initialized
INFO - 2022-01-09 09:44:46 --> Hooks Class Initialized
DEBUG - 2022-01-09 09:44:46 --> UTF-8 Support Enabled
INFO - 2022-01-09 09:44:46 --> Utf8 Class Initialized
INFO - 2022-01-09 09:44:46 --> URI Class Initialized
INFO - 2022-01-09 09:44:46 --> Router Class Initialized
INFO - 2022-01-09 09:44:46 --> Output Class Initialized
INFO - 2022-01-09 09:44:46 --> Security Class Initialized
DEBUG - 2022-01-09 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 09:44:46 --> Input Class Initialized
INFO - 2022-01-09 09:44:46 --> Language Class Initialized
INFO - 2022-01-09 09:44:46 --> Loader Class Initialized
INFO - 2022-01-09 09:44:46 --> Helper loaded: url_helper
INFO - 2022-01-09 09:44:46 --> Helper loaded: form_helper
INFO - 2022-01-09 09:44:46 --> Helper loaded: common_helper
INFO - 2022-01-09 09:44:46 --> Database Driver Class Initialized
DEBUG - 2022-01-09 09:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 09:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 09:44:46 --> Controller Class Initialized
INFO - 2022-01-09 09:44:46 --> Form Validation Class Initialized
DEBUG - 2022-01-09 09:44:46 --> Encrypt Class Initialized
DEBUG - 2022-01-09 09:44:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 09:44:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 09:44:46 --> Email Class Initialized
INFO - 2022-01-09 09:44:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 09:44:46 --> Calendar Class Initialized
INFO - 2022-01-09 09:44:46 --> Model "Login_model" initialized
INFO - 2022-01-09 09:44:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 09:44:46 --> Final output sent to browser
DEBUG - 2022-01-09 09:44:46 --> Total execution time: 0.0230
ERROR - 2022-01-09 12:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 12:12:18 --> Config Class Initialized
INFO - 2022-01-09 12:12:18 --> Hooks Class Initialized
DEBUG - 2022-01-09 12:12:18 --> UTF-8 Support Enabled
INFO - 2022-01-09 12:12:18 --> Utf8 Class Initialized
INFO - 2022-01-09 12:12:18 --> URI Class Initialized
DEBUG - 2022-01-09 12:12:18 --> No URI present. Default controller set.
INFO - 2022-01-09 12:12:18 --> Router Class Initialized
INFO - 2022-01-09 12:12:18 --> Output Class Initialized
INFO - 2022-01-09 12:12:18 --> Security Class Initialized
DEBUG - 2022-01-09 12:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 12:12:18 --> Input Class Initialized
INFO - 2022-01-09 12:12:18 --> Language Class Initialized
INFO - 2022-01-09 12:12:18 --> Loader Class Initialized
INFO - 2022-01-09 12:12:18 --> Helper loaded: url_helper
INFO - 2022-01-09 12:12:18 --> Helper loaded: form_helper
INFO - 2022-01-09 12:12:18 --> Helper loaded: common_helper
INFO - 2022-01-09 12:12:18 --> Database Driver Class Initialized
DEBUG - 2022-01-09 12:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 12:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 12:12:18 --> Controller Class Initialized
INFO - 2022-01-09 12:12:18 --> Form Validation Class Initialized
DEBUG - 2022-01-09 12:12:18 --> Encrypt Class Initialized
DEBUG - 2022-01-09 12:12:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 12:12:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 12:12:18 --> Email Class Initialized
INFO - 2022-01-09 12:12:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 12:12:18 --> Calendar Class Initialized
INFO - 2022-01-09 12:12:18 --> Model "Login_model" initialized
INFO - 2022-01-09 12:12:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 12:12:18 --> Final output sent to browser
DEBUG - 2022-01-09 12:12:18 --> Total execution time: 0.0235
ERROR - 2022-01-09 14:22:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 14:22:27 --> Config Class Initialized
INFO - 2022-01-09 14:22:27 --> Hooks Class Initialized
DEBUG - 2022-01-09 14:22:27 --> UTF-8 Support Enabled
INFO - 2022-01-09 14:22:27 --> Utf8 Class Initialized
INFO - 2022-01-09 14:22:27 --> URI Class Initialized
DEBUG - 2022-01-09 14:22:27 --> No URI present. Default controller set.
INFO - 2022-01-09 14:22:27 --> Router Class Initialized
INFO - 2022-01-09 14:22:27 --> Output Class Initialized
INFO - 2022-01-09 14:22:27 --> Security Class Initialized
DEBUG - 2022-01-09 14:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 14:22:27 --> Input Class Initialized
INFO - 2022-01-09 14:22:27 --> Language Class Initialized
INFO - 2022-01-09 14:22:27 --> Loader Class Initialized
INFO - 2022-01-09 14:22:27 --> Helper loaded: url_helper
INFO - 2022-01-09 14:22:27 --> Helper loaded: form_helper
INFO - 2022-01-09 14:22:27 --> Helper loaded: common_helper
INFO - 2022-01-09 14:22:27 --> Database Driver Class Initialized
DEBUG - 2022-01-09 14:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 14:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 14:22:27 --> Controller Class Initialized
INFO - 2022-01-09 14:22:27 --> Form Validation Class Initialized
DEBUG - 2022-01-09 14:22:27 --> Encrypt Class Initialized
DEBUG - 2022-01-09 14:22:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 14:22:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 14:22:27 --> Email Class Initialized
INFO - 2022-01-09 14:22:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 14:22:27 --> Calendar Class Initialized
INFO - 2022-01-09 14:22:27 --> Model "Login_model" initialized
INFO - 2022-01-09 14:22:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 14:22:27 --> Final output sent to browser
DEBUG - 2022-01-09 14:22:27 --> Total execution time: 0.0259
ERROR - 2022-01-09 14:22:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 14:22:30 --> Config Class Initialized
INFO - 2022-01-09 14:22:30 --> Hooks Class Initialized
DEBUG - 2022-01-09 14:22:30 --> UTF-8 Support Enabled
INFO - 2022-01-09 14:22:30 --> Utf8 Class Initialized
INFO - 2022-01-09 14:22:30 --> URI Class Initialized
INFO - 2022-01-09 14:22:30 --> Router Class Initialized
INFO - 2022-01-09 14:22:30 --> Output Class Initialized
INFO - 2022-01-09 14:22:30 --> Security Class Initialized
DEBUG - 2022-01-09 14:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 14:22:30 --> Input Class Initialized
INFO - 2022-01-09 14:22:30 --> Language Class Initialized
ERROR - 2022-01-09 14:22:30 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-09 14:24:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 14:24:12 --> Config Class Initialized
INFO - 2022-01-09 14:24:12 --> Hooks Class Initialized
DEBUG - 2022-01-09 14:24:12 --> UTF-8 Support Enabled
INFO - 2022-01-09 14:24:12 --> Utf8 Class Initialized
INFO - 2022-01-09 14:24:12 --> URI Class Initialized
INFO - 2022-01-09 14:24:12 --> Router Class Initialized
INFO - 2022-01-09 14:24:12 --> Output Class Initialized
INFO - 2022-01-09 14:24:12 --> Security Class Initialized
DEBUG - 2022-01-09 14:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 14:24:12 --> Input Class Initialized
INFO - 2022-01-09 14:24:12 --> Language Class Initialized
INFO - 2022-01-09 14:24:12 --> Loader Class Initialized
INFO - 2022-01-09 14:24:12 --> Helper loaded: url_helper
INFO - 2022-01-09 14:24:12 --> Helper loaded: form_helper
INFO - 2022-01-09 14:24:12 --> Helper loaded: common_helper
INFO - 2022-01-09 14:24:12 --> Database Driver Class Initialized
DEBUG - 2022-01-09 14:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 14:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 14:24:12 --> Controller Class Initialized
INFO - 2022-01-09 14:24:12 --> Form Validation Class Initialized
DEBUG - 2022-01-09 14:24:12 --> Encrypt Class Initialized
DEBUG - 2022-01-09 14:24:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 14:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 14:24:12 --> Email Class Initialized
INFO - 2022-01-09 14:24:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 14:24:12 --> Calendar Class Initialized
INFO - 2022-01-09 14:24:12 --> Model "Login_model" initialized
ERROR - 2022-01-09 14:24:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 14:24:12 --> Config Class Initialized
INFO - 2022-01-09 14:24:12 --> Hooks Class Initialized
DEBUG - 2022-01-09 14:24:12 --> UTF-8 Support Enabled
INFO - 2022-01-09 14:24:12 --> Utf8 Class Initialized
INFO - 2022-01-09 14:24:12 --> URI Class Initialized
INFO - 2022-01-09 14:24:12 --> Router Class Initialized
INFO - 2022-01-09 14:24:12 --> Output Class Initialized
INFO - 2022-01-09 14:24:12 --> Security Class Initialized
DEBUG - 2022-01-09 14:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 14:24:12 --> Input Class Initialized
INFO - 2022-01-09 14:24:12 --> Language Class Initialized
INFO - 2022-01-09 14:24:12 --> Loader Class Initialized
INFO - 2022-01-09 14:24:12 --> Helper loaded: url_helper
INFO - 2022-01-09 14:24:12 --> Helper loaded: form_helper
INFO - 2022-01-09 14:24:12 --> Helper loaded: common_helper
INFO - 2022-01-09 14:24:12 --> Database Driver Class Initialized
DEBUG - 2022-01-09 14:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 14:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 14:24:12 --> Controller Class Initialized
INFO - 2022-01-09 14:24:12 --> Form Validation Class Initialized
DEBUG - 2022-01-09 14:24:12 --> Encrypt Class Initialized
DEBUG - 2022-01-09 14:24:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 14:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 14:24:12 --> Email Class Initialized
INFO - 2022-01-09 14:24:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 14:24:12 --> Calendar Class Initialized
INFO - 2022-01-09 14:24:12 --> Model "Login_model" initialized
ERROR - 2022-01-09 14:24:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 14:24:13 --> Config Class Initialized
INFO - 2022-01-09 14:24:13 --> Hooks Class Initialized
DEBUG - 2022-01-09 14:24:13 --> UTF-8 Support Enabled
INFO - 2022-01-09 14:24:13 --> Utf8 Class Initialized
INFO - 2022-01-09 14:24:13 --> URI Class Initialized
DEBUG - 2022-01-09 14:24:13 --> No URI present. Default controller set.
INFO - 2022-01-09 14:24:13 --> Router Class Initialized
INFO - 2022-01-09 14:24:13 --> Output Class Initialized
INFO - 2022-01-09 14:24:13 --> Security Class Initialized
DEBUG - 2022-01-09 14:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 14:24:13 --> Input Class Initialized
INFO - 2022-01-09 14:24:13 --> Language Class Initialized
INFO - 2022-01-09 14:24:13 --> Loader Class Initialized
INFO - 2022-01-09 14:24:13 --> Helper loaded: url_helper
INFO - 2022-01-09 14:24:13 --> Helper loaded: form_helper
INFO - 2022-01-09 14:24:13 --> Helper loaded: common_helper
INFO - 2022-01-09 14:24:13 --> Database Driver Class Initialized
DEBUG - 2022-01-09 14:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 14:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 14:24:13 --> Controller Class Initialized
INFO - 2022-01-09 14:24:13 --> Form Validation Class Initialized
DEBUG - 2022-01-09 14:24:13 --> Encrypt Class Initialized
DEBUG - 2022-01-09 14:24:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 14:24:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 14:24:13 --> Email Class Initialized
INFO - 2022-01-09 14:24:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 14:24:13 --> Calendar Class Initialized
INFO - 2022-01-09 14:24:13 --> Model "Login_model" initialized
INFO - 2022-01-09 14:24:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 14:24:13 --> Final output sent to browser
DEBUG - 2022-01-09 14:24:13 --> Total execution time: 0.0305
ERROR - 2022-01-09 14:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 14:24:14 --> Config Class Initialized
INFO - 2022-01-09 14:24:14 --> Hooks Class Initialized
DEBUG - 2022-01-09 14:24:14 --> UTF-8 Support Enabled
INFO - 2022-01-09 14:24:14 --> Utf8 Class Initialized
INFO - 2022-01-09 14:24:14 --> URI Class Initialized
INFO - 2022-01-09 14:24:14 --> Router Class Initialized
INFO - 2022-01-09 14:24:14 --> Output Class Initialized
INFO - 2022-01-09 14:24:14 --> Security Class Initialized
DEBUG - 2022-01-09 14:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 14:24:14 --> Input Class Initialized
INFO - 2022-01-09 14:24:14 --> Language Class Initialized
INFO - 2022-01-09 14:24:14 --> Loader Class Initialized
INFO - 2022-01-09 14:24:14 --> Helper loaded: url_helper
INFO - 2022-01-09 14:24:14 --> Helper loaded: form_helper
INFO - 2022-01-09 14:24:14 --> Helper loaded: common_helper
INFO - 2022-01-09 14:24:14 --> Database Driver Class Initialized
DEBUG - 2022-01-09 14:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 14:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 14:24:14 --> Controller Class Initialized
INFO - 2022-01-09 14:24:14 --> Form Validation Class Initialized
DEBUG - 2022-01-09 14:24:14 --> Encrypt Class Initialized
DEBUG - 2022-01-09 14:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 14:24:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 14:24:14 --> Email Class Initialized
INFO - 2022-01-09 14:24:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 14:24:14 --> Calendar Class Initialized
INFO - 2022-01-09 14:24:14 --> Model "Login_model" initialized
INFO - 2022-01-09 14:24:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 14:24:14 --> Final output sent to browser
DEBUG - 2022-01-09 14:24:14 --> Total execution time: 0.0224
ERROR - 2022-01-09 20:04:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 20:04:19 --> Config Class Initialized
INFO - 2022-01-09 20:04:19 --> Hooks Class Initialized
DEBUG - 2022-01-09 20:04:19 --> UTF-8 Support Enabled
INFO - 2022-01-09 20:04:19 --> Utf8 Class Initialized
INFO - 2022-01-09 20:04:19 --> URI Class Initialized
DEBUG - 2022-01-09 20:04:19 --> No URI present. Default controller set.
INFO - 2022-01-09 20:04:19 --> Router Class Initialized
INFO - 2022-01-09 20:04:19 --> Output Class Initialized
INFO - 2022-01-09 20:04:19 --> Security Class Initialized
DEBUG - 2022-01-09 20:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 20:04:19 --> Input Class Initialized
INFO - 2022-01-09 20:04:19 --> Language Class Initialized
INFO - 2022-01-09 20:04:19 --> Loader Class Initialized
INFO - 2022-01-09 20:04:19 --> Helper loaded: url_helper
INFO - 2022-01-09 20:04:19 --> Helper loaded: form_helper
INFO - 2022-01-09 20:04:19 --> Helper loaded: common_helper
INFO - 2022-01-09 20:04:19 --> Database Driver Class Initialized
DEBUG - 2022-01-09 20:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 20:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 20:04:19 --> Controller Class Initialized
INFO - 2022-01-09 20:04:19 --> Form Validation Class Initialized
DEBUG - 2022-01-09 20:04:19 --> Encrypt Class Initialized
DEBUG - 2022-01-09 20:04:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 20:04:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 20:04:19 --> Email Class Initialized
INFO - 2022-01-09 20:04:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 20:04:19 --> Calendar Class Initialized
INFO - 2022-01-09 20:04:19 --> Model "Login_model" initialized
INFO - 2022-01-09 20:04:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 20:04:19 --> Final output sent to browser
DEBUG - 2022-01-09 20:04:19 --> Total execution time: 0.0469
ERROR - 2022-01-09 22:59:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-09 22:59:07 --> Config Class Initialized
INFO - 2022-01-09 22:59:07 --> Hooks Class Initialized
DEBUG - 2022-01-09 22:59:07 --> UTF-8 Support Enabled
INFO - 2022-01-09 22:59:07 --> Utf8 Class Initialized
INFO - 2022-01-09 22:59:07 --> URI Class Initialized
DEBUG - 2022-01-09 22:59:07 --> No URI present. Default controller set.
INFO - 2022-01-09 22:59:07 --> Router Class Initialized
INFO - 2022-01-09 22:59:07 --> Output Class Initialized
INFO - 2022-01-09 22:59:07 --> Security Class Initialized
DEBUG - 2022-01-09 22:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-09 22:59:07 --> Input Class Initialized
INFO - 2022-01-09 22:59:07 --> Language Class Initialized
INFO - 2022-01-09 22:59:07 --> Loader Class Initialized
INFO - 2022-01-09 22:59:07 --> Helper loaded: url_helper
INFO - 2022-01-09 22:59:07 --> Helper loaded: form_helper
INFO - 2022-01-09 22:59:07 --> Helper loaded: common_helper
INFO - 2022-01-09 22:59:07 --> Database Driver Class Initialized
DEBUG - 2022-01-09 22:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-09 22:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-09 22:59:07 --> Controller Class Initialized
INFO - 2022-01-09 22:59:07 --> Form Validation Class Initialized
DEBUG - 2022-01-09 22:59:07 --> Encrypt Class Initialized
DEBUG - 2022-01-09 22:59:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 22:59:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-09 22:59:07 --> Email Class Initialized
INFO - 2022-01-09 22:59:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-09 22:59:07 --> Calendar Class Initialized
INFO - 2022-01-09 22:59:07 --> Model "Login_model" initialized
INFO - 2022-01-09 22:59:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-09 22:59:07 --> Final output sent to browser
DEBUG - 2022-01-09 22:59:07 --> Total execution time: 0.0258
