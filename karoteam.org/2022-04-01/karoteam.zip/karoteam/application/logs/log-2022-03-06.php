<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-06 06:02:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:49 --> Config Class Initialized
INFO - 2022-03-06 06:02:49 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:49 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:49 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:49 --> URI Class Initialized
DEBUG - 2022-03-06 06:02:49 --> No URI present. Default controller set.
INFO - 2022-03-06 06:02:49 --> Router Class Initialized
INFO - 2022-03-06 06:02:49 --> Output Class Initialized
INFO - 2022-03-06 06:02:49 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:49 --> Input Class Initialized
INFO - 2022-03-06 06:02:49 --> Language Class Initialized
INFO - 2022-03-06 06:02:49 --> Loader Class Initialized
INFO - 2022-03-06 06:02:49 --> Helper loaded: url_helper
INFO - 2022-03-06 06:02:49 --> Helper loaded: form_helper
INFO - 2022-03-06 06:02:49 --> Helper loaded: common_helper
INFO - 2022-03-06 06:02:49 --> Database Driver Class Initialized
DEBUG - 2022-03-06 06:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 06:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 06:02:49 --> Controller Class Initialized
INFO - 2022-03-06 06:02:49 --> Form Validation Class Initialized
DEBUG - 2022-03-06 06:02:49 --> Encrypt Class Initialized
DEBUG - 2022-03-06 06:02:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 06:02:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 06:02:49 --> Email Class Initialized
INFO - 2022-03-06 06:02:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 06:02:49 --> Calendar Class Initialized
INFO - 2022-03-06 06:02:49 --> Model "Login_model" initialized
INFO - 2022-03-06 06:02:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 06:02:49 --> Final output sent to browser
DEBUG - 2022-03-06 06:02:49 --> Total execution time: 0.0267
ERROR - 2022-03-06 06:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:50 --> Config Class Initialized
INFO - 2022-03-06 06:02:50 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:50 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:50 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:50 --> URI Class Initialized
DEBUG - 2022-03-06 06:02:50 --> No URI present. Default controller set.
INFO - 2022-03-06 06:02:50 --> Router Class Initialized
INFO - 2022-03-06 06:02:50 --> Output Class Initialized
INFO - 2022-03-06 06:02:50 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:50 --> Input Class Initialized
INFO - 2022-03-06 06:02:50 --> Language Class Initialized
INFO - 2022-03-06 06:02:50 --> Loader Class Initialized
INFO - 2022-03-06 06:02:50 --> Helper loaded: url_helper
INFO - 2022-03-06 06:02:50 --> Helper loaded: form_helper
INFO - 2022-03-06 06:02:50 --> Helper loaded: common_helper
INFO - 2022-03-06 06:02:50 --> Database Driver Class Initialized
DEBUG - 2022-03-06 06:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 06:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 06:02:50 --> Controller Class Initialized
INFO - 2022-03-06 06:02:50 --> Form Validation Class Initialized
DEBUG - 2022-03-06 06:02:50 --> Encrypt Class Initialized
DEBUG - 2022-03-06 06:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 06:02:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 06:02:50 --> Email Class Initialized
INFO - 2022-03-06 06:02:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 06:02:50 --> Calendar Class Initialized
INFO - 2022-03-06 06:02:50 --> Model "Login_model" initialized
INFO - 2022-03-06 06:02:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 06:02:50 --> Final output sent to browser
DEBUG - 2022-03-06 06:02:50 --> Total execution time: 0.0225
ERROR - 2022-03-06 06:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:50 --> Config Class Initialized
INFO - 2022-03-06 06:02:50 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:50 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:50 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:50 --> URI Class Initialized
INFO - 2022-03-06 06:02:50 --> Router Class Initialized
INFO - 2022-03-06 06:02:50 --> Output Class Initialized
INFO - 2022-03-06 06:02:50 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:50 --> Input Class Initialized
INFO - 2022-03-06 06:02:50 --> Language Class Initialized
ERROR - 2022-03-06 06:02:50 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-06 06:02:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:51 --> Config Class Initialized
INFO - 2022-03-06 06:02:51 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:51 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:51 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:51 --> URI Class Initialized
INFO - 2022-03-06 06:02:51 --> Router Class Initialized
INFO - 2022-03-06 06:02:51 --> Output Class Initialized
INFO - 2022-03-06 06:02:51 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:51 --> Input Class Initialized
INFO - 2022-03-06 06:02:51 --> Language Class Initialized
ERROR - 2022-03-06 06:02:51 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-06 06:02:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:51 --> Config Class Initialized
INFO - 2022-03-06 06:02:51 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:51 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:51 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:51 --> URI Class Initialized
INFO - 2022-03-06 06:02:51 --> Router Class Initialized
INFO - 2022-03-06 06:02:51 --> Output Class Initialized
INFO - 2022-03-06 06:02:51 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:51 --> Input Class Initialized
INFO - 2022-03-06 06:02:51 --> Language Class Initialized
ERROR - 2022-03-06 06:02:51 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-06 06:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:52 --> Config Class Initialized
INFO - 2022-03-06 06:02:52 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:52 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:52 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:52 --> URI Class Initialized
INFO - 2022-03-06 06:02:52 --> Router Class Initialized
INFO - 2022-03-06 06:02:52 --> Output Class Initialized
INFO - 2022-03-06 06:02:52 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:52 --> Input Class Initialized
INFO - 2022-03-06 06:02:52 --> Language Class Initialized
ERROR - 2022-03-06 06:02:52 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-06 06:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:52 --> Config Class Initialized
INFO - 2022-03-06 06:02:52 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:52 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:52 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:52 --> URI Class Initialized
INFO - 2022-03-06 06:02:52 --> Router Class Initialized
INFO - 2022-03-06 06:02:52 --> Output Class Initialized
INFO - 2022-03-06 06:02:52 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:52 --> Input Class Initialized
INFO - 2022-03-06 06:02:52 --> Language Class Initialized
ERROR - 2022-03-06 06:02:52 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-06 06:02:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:53 --> Config Class Initialized
INFO - 2022-03-06 06:02:53 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:53 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:53 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:53 --> URI Class Initialized
INFO - 2022-03-06 06:02:53 --> Router Class Initialized
INFO - 2022-03-06 06:02:53 --> Output Class Initialized
INFO - 2022-03-06 06:02:53 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:53 --> Input Class Initialized
INFO - 2022-03-06 06:02:53 --> Language Class Initialized
ERROR - 2022-03-06 06:02:53 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-06 06:02:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:53 --> Config Class Initialized
INFO - 2022-03-06 06:02:53 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:53 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:53 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:53 --> URI Class Initialized
INFO - 2022-03-06 06:02:53 --> Router Class Initialized
INFO - 2022-03-06 06:02:53 --> Output Class Initialized
INFO - 2022-03-06 06:02:53 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:53 --> Input Class Initialized
INFO - 2022-03-06 06:02:53 --> Language Class Initialized
ERROR - 2022-03-06 06:02:53 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2022-03-06 06:02:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:53 --> Config Class Initialized
INFO - 2022-03-06 06:02:53 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:53 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:53 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:53 --> URI Class Initialized
INFO - 2022-03-06 06:02:53 --> Router Class Initialized
INFO - 2022-03-06 06:02:53 --> Output Class Initialized
INFO - 2022-03-06 06:02:53 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:53 --> Input Class Initialized
INFO - 2022-03-06 06:02:53 --> Language Class Initialized
ERROR - 2022-03-06 06:02:53 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-03-06 06:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:54 --> Config Class Initialized
INFO - 2022-03-06 06:02:54 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:54 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:54 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:54 --> URI Class Initialized
INFO - 2022-03-06 06:02:54 --> Router Class Initialized
INFO - 2022-03-06 06:02:54 --> Output Class Initialized
INFO - 2022-03-06 06:02:54 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:54 --> Input Class Initialized
INFO - 2022-03-06 06:02:54 --> Language Class Initialized
ERROR - 2022-03-06 06:02:54 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-06 06:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:54 --> Config Class Initialized
INFO - 2022-03-06 06:02:54 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:54 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:54 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:54 --> URI Class Initialized
INFO - 2022-03-06 06:02:54 --> Router Class Initialized
INFO - 2022-03-06 06:02:54 --> Output Class Initialized
INFO - 2022-03-06 06:02:54 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:54 --> Input Class Initialized
INFO - 2022-03-06 06:02:54 --> Language Class Initialized
ERROR - 2022-03-06 06:02:54 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-06 06:02:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:55 --> Config Class Initialized
INFO - 2022-03-06 06:02:55 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:55 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:55 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:55 --> URI Class Initialized
INFO - 2022-03-06 06:02:55 --> Router Class Initialized
INFO - 2022-03-06 06:02:55 --> Output Class Initialized
INFO - 2022-03-06 06:02:55 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:55 --> Input Class Initialized
INFO - 2022-03-06 06:02:55 --> Language Class Initialized
ERROR - 2022-03-06 06:02:55 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-06 06:02:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:55 --> Config Class Initialized
INFO - 2022-03-06 06:02:55 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:55 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:55 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:55 --> URI Class Initialized
INFO - 2022-03-06 06:02:55 --> Router Class Initialized
INFO - 2022-03-06 06:02:55 --> Output Class Initialized
INFO - 2022-03-06 06:02:55 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:55 --> Input Class Initialized
INFO - 2022-03-06 06:02:55 --> Language Class Initialized
ERROR - 2022-03-06 06:02:55 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-06 06:02:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:56 --> Config Class Initialized
INFO - 2022-03-06 06:02:56 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:56 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:56 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:56 --> URI Class Initialized
INFO - 2022-03-06 06:02:56 --> Router Class Initialized
INFO - 2022-03-06 06:02:56 --> Output Class Initialized
INFO - 2022-03-06 06:02:56 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:56 --> Input Class Initialized
INFO - 2022-03-06 06:02:56 --> Language Class Initialized
ERROR - 2022-03-06 06:02:56 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-06 06:02:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:56 --> Config Class Initialized
INFO - 2022-03-06 06:02:56 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:56 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:56 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:56 --> URI Class Initialized
INFO - 2022-03-06 06:02:56 --> Router Class Initialized
INFO - 2022-03-06 06:02:56 --> Output Class Initialized
INFO - 2022-03-06 06:02:56 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:56 --> Input Class Initialized
INFO - 2022-03-06 06:02:56 --> Language Class Initialized
ERROR - 2022-03-06 06:02:56 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-06 06:02:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 06:02:56 --> Config Class Initialized
INFO - 2022-03-06 06:02:56 --> Hooks Class Initialized
DEBUG - 2022-03-06 06:02:56 --> UTF-8 Support Enabled
INFO - 2022-03-06 06:02:56 --> Utf8 Class Initialized
INFO - 2022-03-06 06:02:56 --> URI Class Initialized
INFO - 2022-03-06 06:02:56 --> Router Class Initialized
INFO - 2022-03-06 06:02:56 --> Output Class Initialized
INFO - 2022-03-06 06:02:56 --> Security Class Initialized
DEBUG - 2022-03-06 06:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 06:02:56 --> Input Class Initialized
INFO - 2022-03-06 06:02:56 --> Language Class Initialized
ERROR - 2022-03-06 06:02:56 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-03-06 08:29:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 08:29:03 --> Config Class Initialized
INFO - 2022-03-06 08:29:03 --> Hooks Class Initialized
DEBUG - 2022-03-06 08:29:03 --> UTF-8 Support Enabled
INFO - 2022-03-06 08:29:03 --> Utf8 Class Initialized
INFO - 2022-03-06 08:29:03 --> URI Class Initialized
DEBUG - 2022-03-06 08:29:03 --> No URI present. Default controller set.
INFO - 2022-03-06 08:29:03 --> Router Class Initialized
INFO - 2022-03-06 08:29:03 --> Output Class Initialized
INFO - 2022-03-06 08:29:03 --> Security Class Initialized
DEBUG - 2022-03-06 08:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 08:29:03 --> Input Class Initialized
INFO - 2022-03-06 08:29:03 --> Language Class Initialized
INFO - 2022-03-06 08:29:03 --> Loader Class Initialized
INFO - 2022-03-06 08:29:03 --> Helper loaded: url_helper
INFO - 2022-03-06 08:29:03 --> Helper loaded: form_helper
INFO - 2022-03-06 08:29:03 --> Helper loaded: common_helper
INFO - 2022-03-06 08:29:03 --> Database Driver Class Initialized
DEBUG - 2022-03-06 08:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 08:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 08:29:03 --> Controller Class Initialized
INFO - 2022-03-06 08:29:03 --> Form Validation Class Initialized
DEBUG - 2022-03-06 08:29:03 --> Encrypt Class Initialized
DEBUG - 2022-03-06 08:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 08:29:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 08:29:03 --> Email Class Initialized
INFO - 2022-03-06 08:29:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 08:29:03 --> Calendar Class Initialized
INFO - 2022-03-06 08:29:03 --> Model "Login_model" initialized
INFO - 2022-03-06 08:29:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 08:29:03 --> Final output sent to browser
DEBUG - 2022-03-06 08:29:03 --> Total execution time: 0.0591
ERROR - 2022-03-06 10:33:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 10:33:59 --> Config Class Initialized
INFO - 2022-03-06 10:33:59 --> Hooks Class Initialized
DEBUG - 2022-03-06 10:33:59 --> UTF-8 Support Enabled
INFO - 2022-03-06 10:33:59 --> Utf8 Class Initialized
INFO - 2022-03-06 10:33:59 --> URI Class Initialized
DEBUG - 2022-03-06 10:33:59 --> No URI present. Default controller set.
INFO - 2022-03-06 10:33:59 --> Router Class Initialized
INFO - 2022-03-06 10:33:59 --> Output Class Initialized
INFO - 2022-03-06 10:33:59 --> Security Class Initialized
DEBUG - 2022-03-06 10:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 10:33:59 --> Input Class Initialized
INFO - 2022-03-06 10:33:59 --> Language Class Initialized
INFO - 2022-03-06 10:33:59 --> Loader Class Initialized
INFO - 2022-03-06 10:33:59 --> Helper loaded: url_helper
INFO - 2022-03-06 10:33:59 --> Helper loaded: form_helper
INFO - 2022-03-06 10:33:59 --> Helper loaded: common_helper
INFO - 2022-03-06 10:33:59 --> Database Driver Class Initialized
DEBUG - 2022-03-06 10:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 10:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 10:33:59 --> Controller Class Initialized
INFO - 2022-03-06 10:33:59 --> Form Validation Class Initialized
DEBUG - 2022-03-06 10:33:59 --> Encrypt Class Initialized
DEBUG - 2022-03-06 10:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 10:33:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 10:33:59 --> Email Class Initialized
INFO - 2022-03-06 10:33:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 10:33:59 --> Calendar Class Initialized
INFO - 2022-03-06 10:33:59 --> Model "Login_model" initialized
INFO - 2022-03-06 10:33:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 10:33:59 --> Final output sent to browser
DEBUG - 2022-03-06 10:33:59 --> Total execution time: 0.0237
ERROR - 2022-03-06 10:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 10:34:03 --> Config Class Initialized
INFO - 2022-03-06 10:34:03 --> Hooks Class Initialized
DEBUG - 2022-03-06 10:34:03 --> UTF-8 Support Enabled
INFO - 2022-03-06 10:34:03 --> Utf8 Class Initialized
INFO - 2022-03-06 10:34:03 --> URI Class Initialized
DEBUG - 2022-03-06 10:34:03 --> No URI present. Default controller set.
INFO - 2022-03-06 10:34:03 --> Router Class Initialized
INFO - 2022-03-06 10:34:03 --> Output Class Initialized
INFO - 2022-03-06 10:34:03 --> Security Class Initialized
DEBUG - 2022-03-06 10:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 10:34:03 --> Input Class Initialized
INFO - 2022-03-06 10:34:03 --> Language Class Initialized
INFO - 2022-03-06 10:34:03 --> Loader Class Initialized
INFO - 2022-03-06 10:34:03 --> Helper loaded: url_helper
INFO - 2022-03-06 10:34:03 --> Helper loaded: form_helper
INFO - 2022-03-06 10:34:03 --> Helper loaded: common_helper
INFO - 2022-03-06 10:34:03 --> Database Driver Class Initialized
DEBUG - 2022-03-06 10:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 10:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 10:34:03 --> Controller Class Initialized
INFO - 2022-03-06 10:34:03 --> Form Validation Class Initialized
DEBUG - 2022-03-06 10:34:03 --> Encrypt Class Initialized
DEBUG - 2022-03-06 10:34:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 10:34:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 10:34:03 --> Email Class Initialized
INFO - 2022-03-06 10:34:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 10:34:03 --> Calendar Class Initialized
INFO - 2022-03-06 10:34:03 --> Model "Login_model" initialized
INFO - 2022-03-06 10:34:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 10:34:03 --> Final output sent to browser
DEBUG - 2022-03-06 10:34:03 --> Total execution time: 0.0353
ERROR - 2022-03-06 14:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 14:18:01 --> Config Class Initialized
INFO - 2022-03-06 14:18:01 --> Hooks Class Initialized
DEBUG - 2022-03-06 14:18:01 --> UTF-8 Support Enabled
INFO - 2022-03-06 14:18:01 --> Utf8 Class Initialized
INFO - 2022-03-06 14:18:01 --> URI Class Initialized
DEBUG - 2022-03-06 14:18:01 --> No URI present. Default controller set.
INFO - 2022-03-06 14:18:01 --> Router Class Initialized
INFO - 2022-03-06 14:18:01 --> Output Class Initialized
INFO - 2022-03-06 14:18:01 --> Security Class Initialized
DEBUG - 2022-03-06 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 14:18:01 --> Input Class Initialized
INFO - 2022-03-06 14:18:01 --> Language Class Initialized
INFO - 2022-03-06 14:18:01 --> Loader Class Initialized
INFO - 2022-03-06 14:18:01 --> Helper loaded: url_helper
INFO - 2022-03-06 14:18:01 --> Helper loaded: form_helper
INFO - 2022-03-06 14:18:01 --> Helper loaded: common_helper
INFO - 2022-03-06 14:18:01 --> Database Driver Class Initialized
DEBUG - 2022-03-06 14:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 14:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 14:18:01 --> Controller Class Initialized
INFO - 2022-03-06 14:18:01 --> Form Validation Class Initialized
DEBUG - 2022-03-06 14:18:01 --> Encrypt Class Initialized
DEBUG - 2022-03-06 14:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 14:18:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 14:18:01 --> Email Class Initialized
INFO - 2022-03-06 14:18:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 14:18:01 --> Calendar Class Initialized
INFO - 2022-03-06 14:18:01 --> Model "Login_model" initialized
INFO - 2022-03-06 14:18:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 14:18:01 --> Final output sent to browser
DEBUG - 2022-03-06 14:18:01 --> Total execution time: 0.0363
ERROR - 2022-03-06 14:18:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 14:18:02 --> Config Class Initialized
INFO - 2022-03-06 14:18:02 --> Hooks Class Initialized
DEBUG - 2022-03-06 14:18:02 --> UTF-8 Support Enabled
INFO - 2022-03-06 14:18:02 --> Utf8 Class Initialized
INFO - 2022-03-06 14:18:02 --> URI Class Initialized
INFO - 2022-03-06 14:18:02 --> Router Class Initialized
INFO - 2022-03-06 14:18:02 --> Output Class Initialized
INFO - 2022-03-06 14:18:02 --> Security Class Initialized
DEBUG - 2022-03-06 14:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 14:18:02 --> Input Class Initialized
INFO - 2022-03-06 14:18:02 --> Language Class Initialized
ERROR - 2022-03-06 14:18:02 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-06 14:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 14:18:15 --> Config Class Initialized
INFO - 2022-03-06 14:18:15 --> Hooks Class Initialized
DEBUG - 2022-03-06 14:18:15 --> UTF-8 Support Enabled
INFO - 2022-03-06 14:18:15 --> Utf8 Class Initialized
INFO - 2022-03-06 14:18:15 --> URI Class Initialized
INFO - 2022-03-06 14:18:15 --> Router Class Initialized
INFO - 2022-03-06 14:18:15 --> Output Class Initialized
INFO - 2022-03-06 14:18:15 --> Security Class Initialized
DEBUG - 2022-03-06 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 14:18:15 --> Input Class Initialized
INFO - 2022-03-06 14:18:15 --> Language Class Initialized
INFO - 2022-03-06 14:18:15 --> Loader Class Initialized
INFO - 2022-03-06 14:18:15 --> Helper loaded: url_helper
INFO - 2022-03-06 14:18:15 --> Helper loaded: form_helper
INFO - 2022-03-06 14:18:15 --> Helper loaded: common_helper
INFO - 2022-03-06 14:18:15 --> Database Driver Class Initialized
DEBUG - 2022-03-06 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 14:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 14:18:15 --> Controller Class Initialized
INFO - 2022-03-06 14:18:15 --> Form Validation Class Initialized
DEBUG - 2022-03-06 14:18:15 --> Encrypt Class Initialized
DEBUG - 2022-03-06 14:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 14:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 14:18:15 --> Email Class Initialized
INFO - 2022-03-06 14:18:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 14:18:15 --> Calendar Class Initialized
INFO - 2022-03-06 14:18:15 --> Model "Login_model" initialized
ERROR - 2022-03-06 14:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 14:18:16 --> Config Class Initialized
INFO - 2022-03-06 14:18:16 --> Hooks Class Initialized
DEBUG - 2022-03-06 14:18:16 --> UTF-8 Support Enabled
INFO - 2022-03-06 14:18:16 --> Utf8 Class Initialized
INFO - 2022-03-06 14:18:16 --> URI Class Initialized
INFO - 2022-03-06 14:18:16 --> Router Class Initialized
INFO - 2022-03-06 14:18:16 --> Output Class Initialized
INFO - 2022-03-06 14:18:16 --> Security Class Initialized
DEBUG - 2022-03-06 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 14:18:16 --> Input Class Initialized
INFO - 2022-03-06 14:18:16 --> Language Class Initialized
INFO - 2022-03-06 14:18:16 --> Loader Class Initialized
INFO - 2022-03-06 14:18:16 --> Helper loaded: url_helper
INFO - 2022-03-06 14:18:16 --> Helper loaded: form_helper
INFO - 2022-03-06 14:18:16 --> Helper loaded: common_helper
INFO - 2022-03-06 14:18:16 --> Database Driver Class Initialized
DEBUG - 2022-03-06 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 14:18:16 --> Controller Class Initialized
INFO - 2022-03-06 14:18:16 --> Form Validation Class Initialized
DEBUG - 2022-03-06 14:18:16 --> Encrypt Class Initialized
DEBUG - 2022-03-06 14:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 14:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 14:18:16 --> Email Class Initialized
INFO - 2022-03-06 14:18:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 14:18:16 --> Calendar Class Initialized
INFO - 2022-03-06 14:18:16 --> Model "Login_model" initialized
ERROR - 2022-03-06 14:18:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 14:18:17 --> Config Class Initialized
INFO - 2022-03-06 14:18:17 --> Hooks Class Initialized
DEBUG - 2022-03-06 14:18:17 --> UTF-8 Support Enabled
INFO - 2022-03-06 14:18:17 --> Utf8 Class Initialized
INFO - 2022-03-06 14:18:17 --> URI Class Initialized
DEBUG - 2022-03-06 14:18:17 --> No URI present. Default controller set.
INFO - 2022-03-06 14:18:17 --> Router Class Initialized
INFO - 2022-03-06 14:18:17 --> Output Class Initialized
INFO - 2022-03-06 14:18:17 --> Security Class Initialized
DEBUG - 2022-03-06 14:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 14:18:17 --> Input Class Initialized
INFO - 2022-03-06 14:18:17 --> Language Class Initialized
INFO - 2022-03-06 14:18:17 --> Loader Class Initialized
INFO - 2022-03-06 14:18:17 --> Helper loaded: url_helper
INFO - 2022-03-06 14:18:17 --> Helper loaded: form_helper
INFO - 2022-03-06 14:18:17 --> Helper loaded: common_helper
INFO - 2022-03-06 14:18:17 --> Database Driver Class Initialized
DEBUG - 2022-03-06 14:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 14:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 14:18:17 --> Controller Class Initialized
INFO - 2022-03-06 14:18:17 --> Form Validation Class Initialized
DEBUG - 2022-03-06 14:18:17 --> Encrypt Class Initialized
DEBUG - 2022-03-06 14:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 14:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 14:18:17 --> Email Class Initialized
INFO - 2022-03-06 14:18:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 14:18:17 --> Calendar Class Initialized
INFO - 2022-03-06 14:18:17 --> Model "Login_model" initialized
INFO - 2022-03-06 14:18:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 14:18:17 --> Final output sent to browser
DEBUG - 2022-03-06 14:18:17 --> Total execution time: 0.0207
ERROR - 2022-03-06 14:18:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 14:18:17 --> Config Class Initialized
INFO - 2022-03-06 14:18:17 --> Hooks Class Initialized
DEBUG - 2022-03-06 14:18:17 --> UTF-8 Support Enabled
INFO - 2022-03-06 14:18:17 --> Utf8 Class Initialized
INFO - 2022-03-06 14:18:17 --> URI Class Initialized
INFO - 2022-03-06 14:18:17 --> Router Class Initialized
INFO - 2022-03-06 14:18:17 --> Output Class Initialized
INFO - 2022-03-06 14:18:17 --> Security Class Initialized
DEBUG - 2022-03-06 14:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 14:18:17 --> Input Class Initialized
INFO - 2022-03-06 14:18:17 --> Language Class Initialized
INFO - 2022-03-06 14:18:17 --> Loader Class Initialized
INFO - 2022-03-06 14:18:17 --> Helper loaded: url_helper
INFO - 2022-03-06 14:18:17 --> Helper loaded: form_helper
INFO - 2022-03-06 14:18:17 --> Helper loaded: common_helper
INFO - 2022-03-06 14:18:17 --> Database Driver Class Initialized
DEBUG - 2022-03-06 14:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 14:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 14:18:17 --> Controller Class Initialized
INFO - 2022-03-06 14:18:17 --> Form Validation Class Initialized
DEBUG - 2022-03-06 14:18:17 --> Encrypt Class Initialized
DEBUG - 2022-03-06 14:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 14:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 14:18:17 --> Email Class Initialized
INFO - 2022-03-06 14:18:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 14:18:17 --> Calendar Class Initialized
INFO - 2022-03-06 14:18:17 --> Model "Login_model" initialized
INFO - 2022-03-06 14:18:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 14:18:17 --> Final output sent to browser
DEBUG - 2022-03-06 14:18:17 --> Total execution time: 0.0241
ERROR - 2022-03-06 16:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:26 --> Config Class Initialized
INFO - 2022-03-06 16:05:26 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:26 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:26 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:26 --> URI Class Initialized
INFO - 2022-03-06 16:05:26 --> Router Class Initialized
INFO - 2022-03-06 16:05:26 --> Output Class Initialized
INFO - 2022-03-06 16:05:26 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:26 --> Input Class Initialized
INFO - 2022-03-06 16:05:26 --> Language Class Initialized
ERROR - 2022-03-06 16:05:26 --> 404 Page Not Found: Leafphp/index
ERROR - 2022-03-06 16:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:26 --> Config Class Initialized
INFO - 2022-03-06 16:05:26 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:26 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:26 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:26 --> URI Class Initialized
INFO - 2022-03-06 16:05:26 --> Router Class Initialized
INFO - 2022-03-06 16:05:26 --> Output Class Initialized
INFO - 2022-03-06 16:05:26 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:26 --> Input Class Initialized
INFO - 2022-03-06 16:05:26 --> Language Class Initialized
ERROR - 2022-03-06 16:05:26 --> 404 Page Not Found: Alexphp/index
ERROR - 2022-03-06 16:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:27 --> Config Class Initialized
INFO - 2022-03-06 16:05:27 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:27 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:27 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:27 --> URI Class Initialized
INFO - 2022-03-06 16:05:27 --> Router Class Initialized
INFO - 2022-03-06 16:05:27 --> Output Class Initialized
INFO - 2022-03-06 16:05:27 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:27 --> Input Class Initialized
INFO - 2022-03-06 16:05:27 --> Language Class Initialized
ERROR - 2022-03-06 16:05:27 --> 404 Page Not Found: Mailerphp/index
ERROR - 2022-03-06 16:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:27 --> Config Class Initialized
INFO - 2022-03-06 16:05:27 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:27 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:27 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:27 --> URI Class Initialized
INFO - 2022-03-06 16:05:27 --> Router Class Initialized
INFO - 2022-03-06 16:05:27 --> Output Class Initialized
INFO - 2022-03-06 16:05:27 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:27 --> Input Class Initialized
INFO - 2022-03-06 16:05:27 --> Language Class Initialized
ERROR - 2022-03-06 16:05:27 --> 404 Page Not Found: Anonephp/index
ERROR - 2022-03-06 16:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:28 --> Config Class Initialized
INFO - 2022-03-06 16:05:28 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:28 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:28 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:28 --> URI Class Initialized
INFO - 2022-03-06 16:05:28 --> Router Class Initialized
INFO - 2022-03-06 16:05:28 --> Output Class Initialized
INFO - 2022-03-06 16:05:28 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:28 --> Input Class Initialized
INFO - 2022-03-06 16:05:28 --> Language Class Initialized
ERROR - 2022-03-06 16:05:28 --> 404 Page Not Found: Aphp/index
ERROR - 2022-03-06 16:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:28 --> Config Class Initialized
INFO - 2022-03-06 16:05:28 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:28 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:28 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:28 --> URI Class Initialized
INFO - 2022-03-06 16:05:28 --> Router Class Initialized
INFO - 2022-03-06 16:05:28 --> Output Class Initialized
INFO - 2022-03-06 16:05:28 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:28 --> Input Class Initialized
INFO - 2022-03-06 16:05:28 --> Language Class Initialized
ERROR - 2022-03-06 16:05:28 --> 404 Page Not Found: Wp-configerphp/index
ERROR - 2022-03-06 16:05:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:29 --> Config Class Initialized
INFO - 2022-03-06 16:05:29 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:29 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:29 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:29 --> URI Class Initialized
INFO - 2022-03-06 16:05:29 --> Router Class Initialized
INFO - 2022-03-06 16:05:29 --> Output Class Initialized
INFO - 2022-03-06 16:05:29 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:29 --> Input Class Initialized
INFO - 2022-03-06 16:05:29 --> Language Class Initialized
ERROR - 2022-03-06 16:05:29 --> 404 Page Not Found: Alfaphp/index
ERROR - 2022-03-06 16:05:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:29 --> Config Class Initialized
INFO - 2022-03-06 16:05:29 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:29 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:29 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:29 --> URI Class Initialized
INFO - 2022-03-06 16:05:29 --> Router Class Initialized
INFO - 2022-03-06 16:05:29 --> Output Class Initialized
INFO - 2022-03-06 16:05:29 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:29 --> Input Class Initialized
INFO - 2022-03-06 16:05:29 --> Language Class Initialized
ERROR - 2022-03-06 16:05:29 --> 404 Page Not Found: Wsophp/index
ERROR - 2022-03-06 16:05:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:30 --> Config Class Initialized
INFO - 2022-03-06 16:05:30 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:30 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:30 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:30 --> URI Class Initialized
INFO - 2022-03-06 16:05:30 --> Router Class Initialized
INFO - 2022-03-06 16:05:30 --> Output Class Initialized
INFO - 2022-03-06 16:05:30 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:30 --> Input Class Initialized
INFO - 2022-03-06 16:05:30 --> Language Class Initialized
ERROR - 2022-03-06 16:05:30 --> 404 Page Not Found: Cphp/index
ERROR - 2022-03-06 16:05:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:30 --> Config Class Initialized
INFO - 2022-03-06 16:05:30 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:30 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:30 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:30 --> URI Class Initialized
INFO - 2022-03-06 16:05:30 --> Router Class Initialized
INFO - 2022-03-06 16:05:30 --> Output Class Initialized
INFO - 2022-03-06 16:05:30 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:30 --> Input Class Initialized
INFO - 2022-03-06 16:05:30 --> Language Class Initialized
ERROR - 2022-03-06 16:05:30 --> 404 Page Not Found: 1php/index
ERROR - 2022-03-06 16:05:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:31 --> Config Class Initialized
INFO - 2022-03-06 16:05:31 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:31 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:31 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:31 --> URI Class Initialized
INFO - 2022-03-06 16:05:31 --> Router Class Initialized
INFO - 2022-03-06 16:05:31 --> Output Class Initialized
INFO - 2022-03-06 16:05:31 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:31 --> Input Class Initialized
INFO - 2022-03-06 16:05:31 --> Language Class Initialized
ERROR - 2022-03-06 16:05:31 --> 404 Page Not Found: Sendphp/index
ERROR - 2022-03-06 16:05:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:31 --> Config Class Initialized
INFO - 2022-03-06 16:05:31 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:31 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:31 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:31 --> URI Class Initialized
INFO - 2022-03-06 16:05:31 --> Router Class Initialized
INFO - 2022-03-06 16:05:31 --> Output Class Initialized
INFO - 2022-03-06 16:05:31 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:31 --> Input Class Initialized
INFO - 2022-03-06 16:05:31 --> Language Class Initialized
ERROR - 2022-03-06 16:05:31 --> 404 Page Not Found: 3php/index
ERROR - 2022-03-06 16:05:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:32 --> Config Class Initialized
INFO - 2022-03-06 16:05:32 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:32 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:32 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:32 --> URI Class Initialized
INFO - 2022-03-06 16:05:32 --> Router Class Initialized
INFO - 2022-03-06 16:05:32 --> Output Class Initialized
INFO - 2022-03-06 16:05:32 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:32 --> Input Class Initialized
INFO - 2022-03-06 16:05:32 --> Language Class Initialized
ERROR - 2022-03-06 16:05:32 --> 404 Page Not Found: 404php/index
ERROR - 2022-03-06 16:05:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:32 --> Config Class Initialized
INFO - 2022-03-06 16:05:32 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:32 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:32 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:32 --> URI Class Initialized
INFO - 2022-03-06 16:05:32 --> Router Class Initialized
INFO - 2022-03-06 16:05:32 --> Output Class Initialized
INFO - 2022-03-06 16:05:32 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:32 --> Input Class Initialized
INFO - 2022-03-06 16:05:32 --> Language Class Initialized
ERROR - 2022-03-06 16:05:32 --> 404 Page Not Found: Symphp/index
ERROR - 2022-03-06 16:05:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:33 --> Config Class Initialized
INFO - 2022-03-06 16:05:33 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:33 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:33 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:33 --> URI Class Initialized
INFO - 2022-03-06 16:05:33 --> Router Class Initialized
INFO - 2022-03-06 16:05:33 --> Output Class Initialized
INFO - 2022-03-06 16:05:33 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:33 --> Input Class Initialized
INFO - 2022-03-06 16:05:33 --> Language Class Initialized
ERROR - 2022-03-06 16:05:33 --> 404 Page Not Found: Wp-confirmphp/index
ERROR - 2022-03-06 16:05:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:33 --> Config Class Initialized
INFO - 2022-03-06 16:05:33 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:33 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:33 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:33 --> URI Class Initialized
INFO - 2022-03-06 16:05:33 --> Router Class Initialized
INFO - 2022-03-06 16:05:33 --> Output Class Initialized
INFO - 2022-03-06 16:05:33 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:33 --> Input Class Initialized
INFO - 2022-03-06 16:05:33 --> Language Class Initialized
ERROR - 2022-03-06 16:05:33 --> 404 Page Not Found: Drphp/index
ERROR - 2022-03-06 16:05:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:34 --> Config Class Initialized
INFO - 2022-03-06 16:05:34 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:34 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:34 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:34 --> URI Class Initialized
INFO - 2022-03-06 16:05:34 --> Router Class Initialized
INFO - 2022-03-06 16:05:34 --> Output Class Initialized
INFO - 2022-03-06 16:05:34 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:34 --> Input Class Initialized
INFO - 2022-03-06 16:05:34 --> Language Class Initialized
ERROR - 2022-03-06 16:05:34 --> 404 Page Not Found: Uploadphp/index
ERROR - 2022-03-06 16:05:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:34 --> Config Class Initialized
INFO - 2022-03-06 16:05:34 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:34 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:34 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:34 --> URI Class Initialized
INFO - 2022-03-06 16:05:34 --> Router Class Initialized
INFO - 2022-03-06 16:05:34 --> Output Class Initialized
INFO - 2022-03-06 16:05:34 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:34 --> Input Class Initialized
INFO - 2022-03-06 16:05:34 --> Language Class Initialized
ERROR - 2022-03-06 16:05:34 --> 404 Page Not Found: Bypassphp/index
ERROR - 2022-03-06 16:05:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:35 --> Config Class Initialized
INFO - 2022-03-06 16:05:35 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:35 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:35 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:35 --> URI Class Initialized
INFO - 2022-03-06 16:05:35 --> Router Class Initialized
INFO - 2022-03-06 16:05:35 --> Output Class Initialized
INFO - 2022-03-06 16:05:35 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:35 --> Input Class Initialized
INFO - 2022-03-06 16:05:35 --> Language Class Initialized
ERROR - 2022-03-06 16:05:35 --> 404 Page Not Found: Wp-blogphp/index
ERROR - 2022-03-06 16:05:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:36 --> Config Class Initialized
INFO - 2022-03-06 16:05:36 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:36 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:36 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:36 --> URI Class Initialized
INFO - 2022-03-06 16:05:36 --> Router Class Initialized
INFO - 2022-03-06 16:05:36 --> Output Class Initialized
INFO - 2022-03-06 16:05:36 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:36 --> Input Class Initialized
INFO - 2022-03-06 16:05:36 --> Language Class Initialized
ERROR - 2022-03-06 16:05:36 --> 404 Page Not Found: Dataphp/index
ERROR - 2022-03-06 16:05:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:36 --> Config Class Initialized
INFO - 2022-03-06 16:05:36 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:36 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:36 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:36 --> URI Class Initialized
INFO - 2022-03-06 16:05:36 --> Router Class Initialized
INFO - 2022-03-06 16:05:36 --> Output Class Initialized
INFO - 2022-03-06 16:05:36 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:36 --> Input Class Initialized
INFO - 2022-03-06 16:05:36 --> Language Class Initialized
ERROR - 2022-03-06 16:05:36 --> 404 Page Not Found: Owlphp/index
ERROR - 2022-03-06 16:05:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:37 --> Config Class Initialized
INFO - 2022-03-06 16:05:37 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:37 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:37 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:37 --> URI Class Initialized
INFO - 2022-03-06 16:05:37 --> Router Class Initialized
INFO - 2022-03-06 16:05:37 --> Output Class Initialized
INFO - 2022-03-06 16:05:37 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:37 --> Input Class Initialized
INFO - 2022-03-06 16:05:37 --> Language Class Initialized
ERROR - 2022-03-06 16:05:37 --> 404 Page Not Found: Vulnphp/index
ERROR - 2022-03-06 16:05:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:37 --> Config Class Initialized
INFO - 2022-03-06 16:05:37 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:37 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:37 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:37 --> URI Class Initialized
INFO - 2022-03-06 16:05:37 --> Router Class Initialized
INFO - 2022-03-06 16:05:37 --> Output Class Initialized
INFO - 2022-03-06 16:05:37 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:37 --> Input Class Initialized
INFO - 2022-03-06 16:05:37 --> Language Class Initialized
ERROR - 2022-03-06 16:05:37 --> 404 Page Not Found: Symlinkphp/index
ERROR - 2022-03-06 16:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:38 --> Config Class Initialized
INFO - 2022-03-06 16:05:38 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:38 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:38 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:38 --> URI Class Initialized
INFO - 2022-03-06 16:05:38 --> Router Class Initialized
INFO - 2022-03-06 16:05:38 --> Output Class Initialized
INFO - 2022-03-06 16:05:38 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:38 --> Input Class Initialized
INFO - 2022-03-06 16:05:38 --> Language Class Initialized
ERROR - 2022-03-06 16:05:38 --> 404 Page Not Found: Ohayophp/index
ERROR - 2022-03-06 16:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:38 --> Config Class Initialized
INFO - 2022-03-06 16:05:38 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:38 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:38 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:38 --> URI Class Initialized
INFO - 2022-03-06 16:05:38 --> Router Class Initialized
INFO - 2022-03-06 16:05:38 --> Output Class Initialized
INFO - 2022-03-06 16:05:38 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:38 --> Input Class Initialized
INFO - 2022-03-06 16:05:38 --> Language Class Initialized
ERROR - 2022-03-06 16:05:38 --> 404 Page Not Found: 100php/index
ERROR - 2022-03-06 16:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:39 --> Config Class Initialized
INFO - 2022-03-06 16:05:39 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:39 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:39 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:39 --> URI Class Initialized
INFO - 2022-03-06 16:05:39 --> Router Class Initialized
INFO - 2022-03-06 16:05:39 --> Output Class Initialized
INFO - 2022-03-06 16:05:39 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:39 --> Input Class Initialized
INFO - 2022-03-06 16:05:39 --> Language Class Initialized
ERROR - 2022-03-06 16:05:39 --> 404 Page Not Found: 777php/index
ERROR - 2022-03-06 16:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:39 --> Config Class Initialized
INFO - 2022-03-06 16:05:39 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:39 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:39 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:39 --> URI Class Initialized
INFO - 2022-03-06 16:05:39 --> Router Class Initialized
INFO - 2022-03-06 16:05:39 --> Output Class Initialized
INFO - 2022-03-06 16:05:39 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:39 --> Input Class Initialized
INFO - 2022-03-06 16:05:39 --> Language Class Initialized
ERROR - 2022-03-06 16:05:39 --> 404 Page Not Found: Wp-content/wp-logins.php
ERROR - 2022-03-06 16:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:40 --> Config Class Initialized
INFO - 2022-03-06 16:05:40 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:40 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:40 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:40 --> URI Class Initialized
INFO - 2022-03-06 16:05:40 --> Router Class Initialized
INFO - 2022-03-06 16:05:40 --> Output Class Initialized
INFO - 2022-03-06 16:05:40 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:40 --> Input Class Initialized
INFO - 2022-03-06 16:05:40 --> Language Class Initialized
ERROR - 2022-03-06 16:05:40 --> 404 Page Not Found: 1indexphp/index
ERROR - 2022-03-06 16:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:40 --> Config Class Initialized
INFO - 2022-03-06 16:05:40 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:40 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:40 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:40 --> URI Class Initialized
INFO - 2022-03-06 16:05:40 --> Router Class Initialized
INFO - 2022-03-06 16:05:40 --> Output Class Initialized
INFO - 2022-03-06 16:05:40 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:40 --> Input Class Initialized
INFO - 2022-03-06 16:05:40 --> Language Class Initialized
ERROR - 2022-03-06 16:05:40 --> 404 Page Not Found: Wp-wsophp/index
ERROR - 2022-03-06 16:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:41 --> Config Class Initialized
INFO - 2022-03-06 16:05:41 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:41 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:41 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:41 --> URI Class Initialized
INFO - 2022-03-06 16:05:41 --> Router Class Initialized
INFO - 2022-03-06 16:05:41 --> Output Class Initialized
INFO - 2022-03-06 16:05:41 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:41 --> Input Class Initialized
INFO - 2022-03-06 16:05:41 --> Language Class Initialized
ERROR - 2022-03-06 16:05:41 --> 404 Page Not Found: 2indexphp/index
ERROR - 2022-03-06 16:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:41 --> Config Class Initialized
INFO - 2022-03-06 16:05:41 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:41 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:41 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:41 --> URI Class Initialized
INFO - 2022-03-06 16:05:41 --> Router Class Initialized
INFO - 2022-03-06 16:05:41 --> Output Class Initialized
INFO - 2022-03-06 16:05:41 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:41 --> Input Class Initialized
INFO - 2022-03-06 16:05:41 --> Language Class Initialized
ERROR - 2022-03-06 16:05:41 --> 404 Page Not Found: Wp-content/wp-admin.php
ERROR - 2022-03-06 16:05:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:42 --> Config Class Initialized
INFO - 2022-03-06 16:05:42 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:42 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:42 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:42 --> URI Class Initialized
INFO - 2022-03-06 16:05:42 --> Router Class Initialized
INFO - 2022-03-06 16:05:42 --> Output Class Initialized
INFO - 2022-03-06 16:05:42 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:42 --> Input Class Initialized
INFO - 2022-03-06 16:05:42 --> Language Class Initialized
ERROR - 2022-03-06 16:05:42 --> 404 Page Not Found: Wp-configerphp/index
ERROR - 2022-03-06 16:05:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:42 --> Config Class Initialized
INFO - 2022-03-06 16:05:42 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:42 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:42 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:42 --> URI Class Initialized
INFO - 2022-03-06 16:05:42 --> Router Class Initialized
INFO - 2022-03-06 16:05:42 --> Output Class Initialized
INFO - 2022-03-06 16:05:42 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:42 --> Input Class Initialized
INFO - 2022-03-06 16:05:42 --> Language Class Initialized
ERROR - 2022-03-06 16:05:42 --> 404 Page Not Found: Wp-adminphp/index
ERROR - 2022-03-06 16:05:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:43 --> Config Class Initialized
INFO - 2022-03-06 16:05:43 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:43 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:43 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:43 --> URI Class Initialized
INFO - 2022-03-06 16:05:43 --> Router Class Initialized
INFO - 2022-03-06 16:05:43 --> Output Class Initialized
INFO - 2022-03-06 16:05:43 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:43 --> Input Class Initialized
INFO - 2022-03-06 16:05:43 --> Language Class Initialized
ERROR - 2022-03-06 16:05:43 --> 404 Page Not Found: Miniphp/index
ERROR - 2022-03-06 16:05:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:43 --> Config Class Initialized
INFO - 2022-03-06 16:05:43 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:43 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:43 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:43 --> URI Class Initialized
INFO - 2022-03-06 16:05:43 --> Router Class Initialized
INFO - 2022-03-06 16:05:43 --> Output Class Initialized
INFO - 2022-03-06 16:05:43 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:43 --> Input Class Initialized
INFO - 2022-03-06 16:05:43 --> Language Class Initialized
ERROR - 2022-03-06 16:05:43 --> 404 Page Not Found: Old-indexphp/index
ERROR - 2022-03-06 16:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:44 --> Config Class Initialized
INFO - 2022-03-06 16:05:44 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:44 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:44 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:44 --> URI Class Initialized
INFO - 2022-03-06 16:05:44 --> Router Class Initialized
INFO - 2022-03-06 16:05:44 --> Output Class Initialized
INFO - 2022-03-06 16:05:44 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:44 --> Input Class Initialized
INFO - 2022-03-06 16:05:44 --> Language Class Initialized
ERROR - 2022-03-06 16:05:44 --> 404 Page Not Found: Docphp/index
ERROR - 2022-03-06 16:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:44 --> Config Class Initialized
INFO - 2022-03-06 16:05:44 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:44 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:44 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:44 --> URI Class Initialized
INFO - 2022-03-06 16:05:44 --> Router Class Initialized
INFO - 2022-03-06 16:05:44 --> Output Class Initialized
INFO - 2022-03-06 16:05:44 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:44 --> Input Class Initialized
INFO - 2022-03-06 16:05:44 --> Language Class Initialized
ERROR - 2022-03-06 16:05:44 --> 404 Page Not Found: Upsphp/index
ERROR - 2022-03-06 16:05:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:45 --> Config Class Initialized
INFO - 2022-03-06 16:05:45 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:45 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:45 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:45 --> URI Class Initialized
INFO - 2022-03-06 16:05:45 --> Router Class Initialized
INFO - 2022-03-06 16:05:45 --> Output Class Initialized
INFO - 2022-03-06 16:05:45 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:45 --> Input Class Initialized
INFO - 2022-03-06 16:05:45 --> Language Class Initialized
ERROR - 2022-03-06 16:05:45 --> 404 Page Not Found: Shxphp/index
ERROR - 2022-03-06 16:05:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:45 --> Config Class Initialized
INFO - 2022-03-06 16:05:45 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:45 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:45 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:45 --> URI Class Initialized
INFO - 2022-03-06 16:05:45 --> Router Class Initialized
INFO - 2022-03-06 16:05:45 --> Output Class Initialized
INFO - 2022-03-06 16:05:45 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:45 --> Input Class Initialized
INFO - 2022-03-06 16:05:45 --> Language Class Initialized
ERROR - 2022-03-06 16:05:45 --> 404 Page Not Found: FoxWSOphp/index
ERROR - 2022-03-06 16:05:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:46 --> Config Class Initialized
INFO - 2022-03-06 16:05:46 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:46 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:46 --> URI Class Initialized
INFO - 2022-03-06 16:05:46 --> Router Class Initialized
INFO - 2022-03-06 16:05:46 --> Output Class Initialized
INFO - 2022-03-06 16:05:46 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:46 --> Input Class Initialized
INFO - 2022-03-06 16:05:46 --> Language Class Initialized
ERROR - 2022-03-06 16:05:46 --> 404 Page Not Found: Foxphp/index
ERROR - 2022-03-06 16:05:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:46 --> Config Class Initialized
INFO - 2022-03-06 16:05:46 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:46 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:46 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:46 --> URI Class Initialized
INFO - 2022-03-06 16:05:46 --> Router Class Initialized
INFO - 2022-03-06 16:05:46 --> Output Class Initialized
INFO - 2022-03-06 16:05:46 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:46 --> Input Class Initialized
INFO - 2022-03-06 16:05:46 --> Language Class Initialized
ERROR - 2022-03-06 16:05:46 --> 404 Page Not Found: Xphp/index
ERROR - 2022-03-06 16:05:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:47 --> Config Class Initialized
INFO - 2022-03-06 16:05:47 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:47 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:47 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:47 --> URI Class Initialized
INFO - 2022-03-06 16:05:47 --> Router Class Initialized
INFO - 2022-03-06 16:05:47 --> Output Class Initialized
INFO - 2022-03-06 16:05:47 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:47 --> Input Class Initialized
INFO - 2022-03-06 16:05:47 --> Language Class Initialized
ERROR - 2022-03-06 16:05:47 --> 404 Page Not Found: Cmsphp/index
ERROR - 2022-03-06 16:05:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:47 --> Config Class Initialized
INFO - 2022-03-06 16:05:47 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:47 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:47 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:47 --> URI Class Initialized
INFO - 2022-03-06 16:05:47 --> Router Class Initialized
INFO - 2022-03-06 16:05:47 --> Output Class Initialized
INFO - 2022-03-06 16:05:47 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:47 --> Input Class Initialized
INFO - 2022-03-06 16:05:47 --> Language Class Initialized
ERROR - 2022-03-06 16:05:47 --> 404 Page Not Found: Stindexphp/index
ERROR - 2022-03-06 16:05:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:48 --> Config Class Initialized
INFO - 2022-03-06 16:05:48 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:48 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:48 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:48 --> URI Class Initialized
INFO - 2022-03-06 16:05:48 --> Router Class Initialized
INFO - 2022-03-06 16:05:48 --> Output Class Initialized
INFO - 2022-03-06 16:05:48 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:48 --> Input Class Initialized
INFO - 2022-03-06 16:05:48 --> Language Class Initialized
ERROR - 2022-03-06 16:05:48 --> 404 Page Not Found: Wp-uploadsphp/index
ERROR - 2022-03-06 16:05:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:48 --> Config Class Initialized
INFO - 2022-03-06 16:05:48 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:48 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:48 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:48 --> URI Class Initialized
INFO - 2022-03-06 16:05:48 --> Router Class Initialized
INFO - 2022-03-06 16:05:48 --> Output Class Initialized
INFO - 2022-03-06 16:05:48 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:48 --> Input Class Initialized
INFO - 2022-03-06 16:05:48 --> Language Class Initialized
ERROR - 2022-03-06 16:05:48 --> 404 Page Not Found: Autoload_classmapphp/index
ERROR - 2022-03-06 16:05:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:48 --> Config Class Initialized
INFO - 2022-03-06 16:05:48 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:48 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:48 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:48 --> URI Class Initialized
INFO - 2022-03-06 16:05:48 --> Router Class Initialized
INFO - 2022-03-06 16:05:48 --> Output Class Initialized
INFO - 2022-03-06 16:05:48 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:48 --> Input Class Initialized
INFO - 2022-03-06 16:05:48 --> Language Class Initialized
ERROR - 2022-03-06 16:05:48 --> 404 Page Not Found: Gelphp/index
ERROR - 2022-03-06 16:05:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:49 --> Config Class Initialized
INFO - 2022-03-06 16:05:49 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:49 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:49 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:49 --> URI Class Initialized
INFO - 2022-03-06 16:05:49 --> Router Class Initialized
INFO - 2022-03-06 16:05:49 --> Output Class Initialized
INFO - 2022-03-06 16:05:49 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:49 --> Input Class Initialized
INFO - 2022-03-06 16:05:49 --> Language Class Initialized
ERROR - 2022-03-06 16:05:49 --> 404 Page Not Found: Defau1tphp/index
ERROR - 2022-03-06 16:05:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:50 --> Config Class Initialized
INFO - 2022-03-06 16:05:50 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:50 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:50 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:50 --> URI Class Initialized
INFO - 2022-03-06 16:05:50 --> Router Class Initialized
INFO - 2022-03-06 16:05:50 --> Output Class Initialized
INFO - 2022-03-06 16:05:50 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:50 --> Input Class Initialized
INFO - 2022-03-06 16:05:50 --> Language Class Initialized
ERROR - 2022-03-06 16:05:50 --> 404 Page Not Found: 0bytephp/index
ERROR - 2022-03-06 16:05:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:50 --> Config Class Initialized
INFO - 2022-03-06 16:05:50 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:50 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:50 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:50 --> URI Class Initialized
INFO - 2022-03-06 16:05:50 --> Router Class Initialized
INFO - 2022-03-06 16:05:50 --> Output Class Initialized
INFO - 2022-03-06 16:05:50 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:50 --> Input Class Initialized
INFO - 2022-03-06 16:05:50 --> Language Class Initialized
ERROR - 2022-03-06 16:05:50 --> 404 Page Not Found: Wpphp/index
ERROR - 2022-03-06 16:05:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:51 --> Config Class Initialized
INFO - 2022-03-06 16:05:51 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:51 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:51 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:51 --> URI Class Initialized
INFO - 2022-03-06 16:05:51 --> Router Class Initialized
INFO - 2022-03-06 16:05:51 --> Output Class Initialized
INFO - 2022-03-06 16:05:51 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:51 --> Input Class Initialized
INFO - 2022-03-06 16:05:51 --> Language Class Initialized
ERROR - 2022-03-06 16:05:51 --> 404 Page Not Found: 41php/index
ERROR - 2022-03-06 16:05:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:52 --> Config Class Initialized
INFO - 2022-03-06 16:05:52 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:52 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:52 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:52 --> URI Class Initialized
INFO - 2022-03-06 16:05:52 --> Router Class Initialized
INFO - 2022-03-06 16:05:52 --> Output Class Initialized
INFO - 2022-03-06 16:05:52 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:52 --> Input Class Initialized
INFO - 2022-03-06 16:05:52 --> Language Class Initialized
ERROR - 2022-03-06 16:05:52 --> 404 Page Not Found: Media-adminphp/index
ERROR - 2022-03-06 16:05:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:52 --> Config Class Initialized
INFO - 2022-03-06 16:05:52 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:52 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:52 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:52 --> URI Class Initialized
INFO - 2022-03-06 16:05:52 --> Router Class Initialized
INFO - 2022-03-06 16:05:52 --> Output Class Initialized
INFO - 2022-03-06 16:05:52 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:52 --> Input Class Initialized
INFO - 2022-03-06 16:05:52 --> Language Class Initialized
ERROR - 2022-03-06 16:05:52 --> 404 Page Not Found: 4pricephp/index
ERROR - 2022-03-06 16:05:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:53 --> Config Class Initialized
INFO - 2022-03-06 16:05:53 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:53 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:53 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:53 --> URI Class Initialized
INFO - 2022-03-06 16:05:53 --> Router Class Initialized
INFO - 2022-03-06 16:05:53 --> Output Class Initialized
INFO - 2022-03-06 16:05:53 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:53 --> Input Class Initialized
INFO - 2022-03-06 16:05:53 --> Language Class Initialized
ERROR - 2022-03-06 16:05:53 --> 404 Page Not Found: MARIJUANAphp/index
ERROR - 2022-03-06 16:05:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:53 --> Config Class Initialized
INFO - 2022-03-06 16:05:53 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:53 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:53 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:53 --> URI Class Initialized
INFO - 2022-03-06 16:05:53 --> Router Class Initialized
INFO - 2022-03-06 16:05:53 --> Output Class Initialized
INFO - 2022-03-06 16:05:53 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:53 --> Input Class Initialized
INFO - 2022-03-06 16:05:53 --> Language Class Initialized
ERROR - 2022-03-06 16:05:53 --> 404 Page Not Found: Fphp/index
ERROR - 2022-03-06 16:05:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:54 --> Config Class Initialized
INFO - 2022-03-06 16:05:54 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:54 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:54 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:54 --> URI Class Initialized
INFO - 2022-03-06 16:05:54 --> Router Class Initialized
INFO - 2022-03-06 16:05:54 --> Output Class Initialized
INFO - 2022-03-06 16:05:54 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:54 --> Input Class Initialized
INFO - 2022-03-06 16:05:54 --> Language Class Initialized
ERROR - 2022-03-06 16:05:54 --> 404 Page Not Found: Fkphp/index
ERROR - 2022-03-06 16:05:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:54 --> Config Class Initialized
INFO - 2022-03-06 16:05:54 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:54 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:54 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:54 --> URI Class Initialized
INFO - 2022-03-06 16:05:54 --> Router Class Initialized
INFO - 2022-03-06 16:05:54 --> Output Class Initialized
INFO - 2022-03-06 16:05:54 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:54 --> Input Class Initialized
INFO - 2022-03-06 16:05:54 --> Language Class Initialized
ERROR - 2022-03-06 16:05:54 --> 404 Page Not Found: Zaxphp/index
ERROR - 2022-03-06 16:05:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:56 --> Config Class Initialized
INFO - 2022-03-06 16:05:56 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:56 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:56 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:56 --> URI Class Initialized
INFO - 2022-03-06 16:05:56 --> Router Class Initialized
INFO - 2022-03-06 16:05:56 --> Output Class Initialized
INFO - 2022-03-06 16:05:56 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:56 --> Input Class Initialized
INFO - 2022-03-06 16:05:56 --> Language Class Initialized
ERROR - 2022-03-06 16:05:56 --> 404 Page Not Found: Xoxphp/index
ERROR - 2022-03-06 16:05:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:56 --> Config Class Initialized
INFO - 2022-03-06 16:05:56 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:56 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:56 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:56 --> URI Class Initialized
INFO - 2022-03-06 16:05:56 --> Router Class Initialized
INFO - 2022-03-06 16:05:56 --> Output Class Initialized
INFO - 2022-03-06 16:05:56 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:56 --> Input Class Initialized
INFO - 2022-03-06 16:05:56 --> Language Class Initialized
ERROR - 2022-03-06 16:05:56 --> 404 Page Not Found: Ophp/index
ERROR - 2022-03-06 16:05:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:57 --> Config Class Initialized
INFO - 2022-03-06 16:05:57 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:57 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:57 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:57 --> URI Class Initialized
INFO - 2022-03-06 16:05:57 --> Router Class Initialized
INFO - 2022-03-06 16:05:57 --> Output Class Initialized
INFO - 2022-03-06 16:05:57 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:57 --> Input Class Initialized
INFO - 2022-03-06 16:05:57 --> Language Class Initialized
ERROR - 2022-03-06 16:05:57 --> 404 Page Not Found: Newphp/index
ERROR - 2022-03-06 16:05:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:57 --> Config Class Initialized
INFO - 2022-03-06 16:05:57 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:57 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:57 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:57 --> URI Class Initialized
INFO - 2022-03-06 16:05:57 --> Router Class Initialized
INFO - 2022-03-06 16:05:57 --> Output Class Initialized
INFO - 2022-03-06 16:05:57 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:57 --> Input Class Initialized
INFO - 2022-03-06 16:05:57 --> Language Class Initialized
ERROR - 2022-03-06 16:05:57 --> 404 Page Not Found: 3indexphp/index
ERROR - 2022-03-06 16:05:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:58 --> Config Class Initialized
INFO - 2022-03-06 16:05:58 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:58 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:58 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:58 --> URI Class Initialized
INFO - 2022-03-06 16:05:58 --> Router Class Initialized
INFO - 2022-03-06 16:05:58 --> Output Class Initialized
INFO - 2022-03-06 16:05:58 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:58 --> Input Class Initialized
INFO - 2022-03-06 16:05:58 --> Language Class Initialized
ERROR - 2022-03-06 16:05:58 --> 404 Page Not Found: Sindexphp/index
ERROR - 2022-03-06 16:05:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:58 --> Config Class Initialized
INFO - 2022-03-06 16:05:58 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:58 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:58 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:58 --> URI Class Initialized
INFO - 2022-03-06 16:05:58 --> Router Class Initialized
INFO - 2022-03-06 16:05:58 --> Output Class Initialized
INFO - 2022-03-06 16:05:58 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:58 --> Input Class Initialized
INFO - 2022-03-06 16:05:58 --> Language Class Initialized
ERROR - 2022-03-06 16:05:58 --> 404 Page Not Found: Baindexphp/index
ERROR - 2022-03-06 16:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:59 --> Config Class Initialized
INFO - 2022-03-06 16:05:59 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:59 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:59 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:59 --> URI Class Initialized
INFO - 2022-03-06 16:05:59 --> Router Class Initialized
INFO - 2022-03-06 16:05:59 --> Output Class Initialized
INFO - 2022-03-06 16:05:59 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:59 --> Input Class Initialized
INFO - 2022-03-06 16:05:59 --> Language Class Initialized
ERROR - 2022-03-06 16:05:59 --> 404 Page Not Found: New-indexphp/index
ERROR - 2022-03-06 16:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:05:59 --> Config Class Initialized
INFO - 2022-03-06 16:05:59 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:05:59 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:05:59 --> Utf8 Class Initialized
INFO - 2022-03-06 16:05:59 --> URI Class Initialized
INFO - 2022-03-06 16:05:59 --> Router Class Initialized
INFO - 2022-03-06 16:05:59 --> Output Class Initialized
INFO - 2022-03-06 16:05:59 --> Security Class Initialized
DEBUG - 2022-03-06 16:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:05:59 --> Input Class Initialized
INFO - 2022-03-06 16:05:59 --> Language Class Initialized
ERROR - 2022-03-06 16:05:59 --> 404 Page Not Found: Wiphp/index
ERROR - 2022-03-06 16:06:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:00 --> Config Class Initialized
INFO - 2022-03-06 16:06:00 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:00 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:00 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:00 --> URI Class Initialized
INFO - 2022-03-06 16:06:00 --> Router Class Initialized
INFO - 2022-03-06 16:06:00 --> Output Class Initialized
INFO - 2022-03-06 16:06:00 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:00 --> Input Class Initialized
INFO - 2022-03-06 16:06:00 --> Language Class Initialized
ERROR - 2022-03-06 16:06:00 --> 404 Page Not Found: XxXphp/index
ERROR - 2022-03-06 16:06:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:01 --> Config Class Initialized
INFO - 2022-03-06 16:06:01 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:01 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:01 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:01 --> URI Class Initialized
INFO - 2022-03-06 16:06:01 --> Router Class Initialized
INFO - 2022-03-06 16:06:01 --> Output Class Initialized
INFO - 2022-03-06 16:06:01 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:01 --> Input Class Initialized
INFO - 2022-03-06 16:06:01 --> Language Class Initialized
ERROR - 2022-03-06 16:06:01 --> 404 Page Not Found: Marphp/index
ERROR - 2022-03-06 16:06:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:01 --> Config Class Initialized
INFO - 2022-03-06 16:06:01 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:01 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:01 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:01 --> URI Class Initialized
INFO - 2022-03-06 16:06:01 --> Router Class Initialized
INFO - 2022-03-06 16:06:01 --> Output Class Initialized
INFO - 2022-03-06 16:06:01 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:01 --> Input Class Initialized
INFO - 2022-03-06 16:06:01 --> Language Class Initialized
ERROR - 2022-03-06 16:06:01 --> 404 Page Not Found: Rootphp/index
ERROR - 2022-03-06 16:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:02 --> Config Class Initialized
INFO - 2022-03-06 16:06:02 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:02 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:02 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:02 --> URI Class Initialized
INFO - 2022-03-06 16:06:02 --> Router Class Initialized
INFO - 2022-03-06 16:06:02 --> Output Class Initialized
INFO - 2022-03-06 16:06:02 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:02 --> Input Class Initialized
INFO - 2022-03-06 16:06:02 --> Language Class Initialized
ERROR - 2022-03-06 16:06:02 --> 404 Page Not Found: 11indexphp/index
ERROR - 2022-03-06 16:06:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:03 --> Config Class Initialized
INFO - 2022-03-06 16:06:03 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:03 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:03 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:03 --> URI Class Initialized
INFO - 2022-03-06 16:06:03 --> Router Class Initialized
INFO - 2022-03-06 16:06:03 --> Output Class Initialized
INFO - 2022-03-06 16:06:03 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:03 --> Input Class Initialized
INFO - 2022-03-06 16:06:03 --> Language Class Initialized
ERROR - 2022-03-06 16:06:03 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-03-06 16:06:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:04 --> Config Class Initialized
INFO - 2022-03-06 16:06:04 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:04 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:04 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:04 --> URI Class Initialized
INFO - 2022-03-06 16:06:04 --> Router Class Initialized
INFO - 2022-03-06 16:06:04 --> Output Class Initialized
INFO - 2022-03-06 16:06:04 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:04 --> Input Class Initialized
INFO - 2022-03-06 16:06:04 --> Language Class Initialized
ERROR - 2022-03-06 16:06:04 --> 404 Page Not Found: Neephp/index
ERROR - 2022-03-06 16:06:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:04 --> Config Class Initialized
INFO - 2022-03-06 16:06:04 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:04 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:04 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:04 --> URI Class Initialized
INFO - 2022-03-06 16:06:04 --> Router Class Initialized
INFO - 2022-03-06 16:06:04 --> Output Class Initialized
INFO - 2022-03-06 16:06:04 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:04 --> Input Class Initialized
INFO - 2022-03-06 16:06:04 --> Language Class Initialized
ERROR - 2022-03-06 16:06:04 --> 404 Page Not Found: Vphp/index
ERROR - 2022-03-06 16:06:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:05 --> Config Class Initialized
INFO - 2022-03-06 16:06:05 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:05 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:05 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:05 --> URI Class Initialized
INFO - 2022-03-06 16:06:05 --> Router Class Initialized
INFO - 2022-03-06 16:06:05 --> Output Class Initialized
INFO - 2022-03-06 16:06:05 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:05 --> Input Class Initialized
INFO - 2022-03-06 16:06:05 --> Language Class Initialized
ERROR - 2022-03-06 16:06:05 --> 404 Page Not Found: Zphp/index
ERROR - 2022-03-06 16:06:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:05 --> Config Class Initialized
INFO - 2022-03-06 16:06:05 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:05 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:05 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:05 --> URI Class Initialized
INFO - 2022-03-06 16:06:05 --> Router Class Initialized
INFO - 2022-03-06 16:06:05 --> Output Class Initialized
INFO - 2022-03-06 16:06:05 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:05 --> Input Class Initialized
INFO - 2022-03-06 16:06:05 --> Language Class Initialized
ERROR - 2022-03-06 16:06:05 --> 404 Page Not Found: Xxphp/index
ERROR - 2022-03-06 16:06:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:06 --> Config Class Initialized
INFO - 2022-03-06 16:06:06 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:06 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:06 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:06 --> URI Class Initialized
INFO - 2022-03-06 16:06:06 --> Router Class Initialized
INFO - 2022-03-06 16:06:06 --> Output Class Initialized
INFO - 2022-03-06 16:06:06 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:06 --> Input Class Initialized
INFO - 2022-03-06 16:06:06 --> Language Class Initialized
ERROR - 2022-03-06 16:06:06 --> 404 Page Not Found: Gphp/index
ERROR - 2022-03-06 16:06:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:07 --> Config Class Initialized
INFO - 2022-03-06 16:06:07 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:07 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:07 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:07 --> URI Class Initialized
INFO - 2022-03-06 16:06:07 --> Router Class Initialized
INFO - 2022-03-06 16:06:07 --> Output Class Initialized
INFO - 2022-03-06 16:06:07 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:07 --> Input Class Initialized
INFO - 2022-03-06 16:06:07 --> Language Class Initialized
ERROR - 2022-03-06 16:06:07 --> 404 Page Not Found: Mphp/index
ERROR - 2022-03-06 16:06:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:07 --> Config Class Initialized
INFO - 2022-03-06 16:06:07 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:07 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:07 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:07 --> URI Class Initialized
INFO - 2022-03-06 16:06:07 --> Router Class Initialized
INFO - 2022-03-06 16:06:07 --> Output Class Initialized
INFO - 2022-03-06 16:06:07 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:07 --> Input Class Initialized
INFO - 2022-03-06 16:06:07 --> Language Class Initialized
ERROR - 2022-03-06 16:06:07 --> 404 Page Not Found: Shellphp/index
ERROR - 2022-03-06 16:06:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:06:08 --> Config Class Initialized
INFO - 2022-03-06 16:06:08 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:06:08 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:06:08 --> Utf8 Class Initialized
INFO - 2022-03-06 16:06:08 --> URI Class Initialized
INFO - 2022-03-06 16:06:08 --> Router Class Initialized
INFO - 2022-03-06 16:06:08 --> Output Class Initialized
INFO - 2022-03-06 16:06:08 --> Security Class Initialized
DEBUG - 2022-03-06 16:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:06:08 --> Input Class Initialized
INFO - 2022-03-06 16:06:08 --> Language Class Initialized
ERROR - 2022-03-06 16:06:08 --> 404 Page Not Found: Sh3llphp/index
ERROR - 2022-03-06 16:44:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:44:55 --> Config Class Initialized
INFO - 2022-03-06 16:44:55 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:44:55 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:44:55 --> Utf8 Class Initialized
INFO - 2022-03-06 16:44:55 --> URI Class Initialized
INFO - 2022-03-06 16:44:55 --> Router Class Initialized
INFO - 2022-03-06 16:44:55 --> Output Class Initialized
INFO - 2022-03-06 16:44:55 --> Security Class Initialized
DEBUG - 2022-03-06 16:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:44:55 --> Input Class Initialized
INFO - 2022-03-06 16:44:55 --> Language Class Initialized
ERROR - 2022-03-06 16:44:55 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-03-06 16:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:44:56 --> Config Class Initialized
INFO - 2022-03-06 16:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:44:56 --> Utf8 Class Initialized
INFO - 2022-03-06 16:44:56 --> URI Class Initialized
INFO - 2022-03-06 16:44:56 --> Router Class Initialized
INFO - 2022-03-06 16:44:56 --> Output Class Initialized
INFO - 2022-03-06 16:44:56 --> Security Class Initialized
DEBUG - 2022-03-06 16:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:44:56 --> Input Class Initialized
INFO - 2022-03-06 16:44:56 --> Language Class Initialized
ERROR - 2022-03-06 16:44:56 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-03-06 16:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 16:44:57 --> Config Class Initialized
INFO - 2022-03-06 16:44:57 --> Hooks Class Initialized
DEBUG - 2022-03-06 16:44:57 --> UTF-8 Support Enabled
INFO - 2022-03-06 16:44:57 --> Utf8 Class Initialized
INFO - 2022-03-06 16:44:57 --> URI Class Initialized
DEBUG - 2022-03-06 16:44:57 --> No URI present. Default controller set.
INFO - 2022-03-06 16:44:57 --> Router Class Initialized
INFO - 2022-03-06 16:44:57 --> Output Class Initialized
INFO - 2022-03-06 16:44:57 --> Security Class Initialized
DEBUG - 2022-03-06 16:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 16:44:57 --> Input Class Initialized
INFO - 2022-03-06 16:44:57 --> Language Class Initialized
INFO - 2022-03-06 16:44:57 --> Loader Class Initialized
INFO - 2022-03-06 16:44:57 --> Helper loaded: url_helper
INFO - 2022-03-06 16:44:57 --> Helper loaded: form_helper
INFO - 2022-03-06 16:44:57 --> Helper loaded: common_helper
INFO - 2022-03-06 16:44:57 --> Database Driver Class Initialized
DEBUG - 2022-03-06 16:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 16:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 16:44:57 --> Controller Class Initialized
INFO - 2022-03-06 16:44:57 --> Form Validation Class Initialized
DEBUG - 2022-03-06 16:44:57 --> Encrypt Class Initialized
DEBUG - 2022-03-06 16:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 16:44:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 16:44:57 --> Email Class Initialized
INFO - 2022-03-06 16:44:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 16:44:57 --> Calendar Class Initialized
INFO - 2022-03-06 16:44:57 --> Model "Login_model" initialized
INFO - 2022-03-06 16:44:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 16:44:57 --> Final output sent to browser
DEBUG - 2022-03-06 16:44:57 --> Total execution time: 0.0309
ERROR - 2022-03-06 18:17:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 18:17:33 --> Config Class Initialized
INFO - 2022-03-06 18:17:33 --> Hooks Class Initialized
DEBUG - 2022-03-06 18:17:33 --> UTF-8 Support Enabled
INFO - 2022-03-06 18:17:33 --> Utf8 Class Initialized
INFO - 2022-03-06 18:17:33 --> URI Class Initialized
DEBUG - 2022-03-06 18:17:33 --> No URI present. Default controller set.
INFO - 2022-03-06 18:17:33 --> Router Class Initialized
INFO - 2022-03-06 18:17:33 --> Output Class Initialized
INFO - 2022-03-06 18:17:33 --> Security Class Initialized
DEBUG - 2022-03-06 18:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 18:17:33 --> Input Class Initialized
INFO - 2022-03-06 18:17:33 --> Language Class Initialized
INFO - 2022-03-06 18:17:33 --> Loader Class Initialized
INFO - 2022-03-06 18:17:33 --> Helper loaded: url_helper
INFO - 2022-03-06 18:17:33 --> Helper loaded: form_helper
INFO - 2022-03-06 18:17:33 --> Helper loaded: common_helper
INFO - 2022-03-06 18:17:33 --> Database Driver Class Initialized
DEBUG - 2022-03-06 18:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 18:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 18:17:33 --> Controller Class Initialized
INFO - 2022-03-06 18:17:33 --> Form Validation Class Initialized
DEBUG - 2022-03-06 18:17:33 --> Encrypt Class Initialized
DEBUG - 2022-03-06 18:17:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 18:17:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 18:17:33 --> Email Class Initialized
INFO - 2022-03-06 18:17:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 18:17:33 --> Calendar Class Initialized
INFO - 2022-03-06 18:17:33 --> Model "Login_model" initialized
INFO - 2022-03-06 18:17:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 18:17:33 --> Final output sent to browser
DEBUG - 2022-03-06 18:17:33 --> Total execution time: 0.0389
ERROR - 2022-03-06 19:59:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 19:59:23 --> Config Class Initialized
INFO - 2022-03-06 19:59:23 --> Hooks Class Initialized
DEBUG - 2022-03-06 19:59:23 --> UTF-8 Support Enabled
INFO - 2022-03-06 19:59:23 --> Utf8 Class Initialized
INFO - 2022-03-06 19:59:23 --> URI Class Initialized
DEBUG - 2022-03-06 19:59:23 --> No URI present. Default controller set.
INFO - 2022-03-06 19:59:23 --> Router Class Initialized
INFO - 2022-03-06 19:59:23 --> Output Class Initialized
INFO - 2022-03-06 19:59:23 --> Security Class Initialized
DEBUG - 2022-03-06 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 19:59:23 --> Input Class Initialized
INFO - 2022-03-06 19:59:23 --> Language Class Initialized
INFO - 2022-03-06 19:59:23 --> Loader Class Initialized
INFO - 2022-03-06 19:59:23 --> Helper loaded: url_helper
INFO - 2022-03-06 19:59:23 --> Helper loaded: form_helper
INFO - 2022-03-06 19:59:23 --> Helper loaded: common_helper
INFO - 2022-03-06 19:59:23 --> Database Driver Class Initialized
DEBUG - 2022-03-06 19:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 19:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 19:59:23 --> Controller Class Initialized
INFO - 2022-03-06 19:59:23 --> Form Validation Class Initialized
DEBUG - 2022-03-06 19:59:23 --> Encrypt Class Initialized
DEBUG - 2022-03-06 19:59:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 19:59:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 19:59:23 --> Email Class Initialized
INFO - 2022-03-06 19:59:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 19:59:23 --> Calendar Class Initialized
INFO - 2022-03-06 19:59:23 --> Model "Login_model" initialized
INFO - 2022-03-06 19:59:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 19:59:23 --> Final output sent to browser
DEBUG - 2022-03-06 19:59:23 --> Total execution time: 0.0449
ERROR - 2022-03-06 21:25:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 21:25:06 --> Config Class Initialized
INFO - 2022-03-06 21:25:06 --> Hooks Class Initialized
DEBUG - 2022-03-06 21:25:06 --> UTF-8 Support Enabled
INFO - 2022-03-06 21:25:06 --> Utf8 Class Initialized
INFO - 2022-03-06 21:25:06 --> URI Class Initialized
DEBUG - 2022-03-06 21:25:06 --> No URI present. Default controller set.
INFO - 2022-03-06 21:25:06 --> Router Class Initialized
INFO - 2022-03-06 21:25:06 --> Output Class Initialized
INFO - 2022-03-06 21:25:06 --> Security Class Initialized
DEBUG - 2022-03-06 21:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 21:25:06 --> Input Class Initialized
INFO - 2022-03-06 21:25:06 --> Language Class Initialized
INFO - 2022-03-06 21:25:06 --> Loader Class Initialized
INFO - 2022-03-06 21:25:06 --> Helper loaded: url_helper
INFO - 2022-03-06 21:25:06 --> Helper loaded: form_helper
INFO - 2022-03-06 21:25:06 --> Helper loaded: common_helper
INFO - 2022-03-06 21:25:06 --> Database Driver Class Initialized
DEBUG - 2022-03-06 21:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 21:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 21:25:06 --> Controller Class Initialized
INFO - 2022-03-06 21:25:06 --> Form Validation Class Initialized
DEBUG - 2022-03-06 21:25:06 --> Encrypt Class Initialized
DEBUG - 2022-03-06 21:25:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 21:25:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 21:25:06 --> Email Class Initialized
INFO - 2022-03-06 21:25:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 21:25:06 --> Calendar Class Initialized
INFO - 2022-03-06 21:25:06 --> Model "Login_model" initialized
INFO - 2022-03-06 21:25:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 21:25:06 --> Final output sent to browser
DEBUG - 2022-03-06 21:25:06 --> Total execution time: 0.1762
ERROR - 2022-03-06 22:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:48:14 --> Config Class Initialized
INFO - 2022-03-06 22:48:14 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:48:14 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:48:14 --> Utf8 Class Initialized
INFO - 2022-03-06 22:48:14 --> URI Class Initialized
INFO - 2022-03-06 22:48:14 --> Router Class Initialized
INFO - 2022-03-06 22:48:14 --> Output Class Initialized
INFO - 2022-03-06 22:48:14 --> Security Class Initialized
DEBUG - 2022-03-06 22:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:48:14 --> Input Class Initialized
INFO - 2022-03-06 22:48:14 --> Language Class Initialized
INFO - 2022-03-06 22:48:14 --> Loader Class Initialized
INFO - 2022-03-06 22:48:14 --> Helper loaded: url_helper
INFO - 2022-03-06 22:48:14 --> Helper loaded: form_helper
INFO - 2022-03-06 22:48:14 --> Helper loaded: common_helper
INFO - 2022-03-06 22:48:14 --> Database Driver Class Initialized
DEBUG - 2022-03-06 22:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 22:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 22:48:14 --> Controller Class Initialized
ERROR - 2022-03-06 22:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:48:14 --> Config Class Initialized
INFO - 2022-03-06 22:48:14 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:48:14 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:48:14 --> Utf8 Class Initialized
INFO - 2022-03-06 22:48:14 --> URI Class Initialized
INFO - 2022-03-06 22:48:14 --> Router Class Initialized
INFO - 2022-03-06 22:48:14 --> Output Class Initialized
INFO - 2022-03-06 22:48:14 --> Security Class Initialized
DEBUG - 2022-03-06 22:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:48:14 --> Input Class Initialized
INFO - 2022-03-06 22:48:14 --> Language Class Initialized
INFO - 2022-03-06 22:48:14 --> Loader Class Initialized
INFO - 2022-03-06 22:48:14 --> Helper loaded: url_helper
INFO - 2022-03-06 22:48:14 --> Helper loaded: form_helper
INFO - 2022-03-06 22:48:14 --> Helper loaded: common_helper
INFO - 2022-03-06 22:48:14 --> Database Driver Class Initialized
DEBUG - 2022-03-06 22:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 22:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 22:48:14 --> Controller Class Initialized
ERROR - 2022-03-06 22:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:48:16 --> Config Class Initialized
INFO - 2022-03-06 22:48:16 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:48:16 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:48:16 --> Utf8 Class Initialized
INFO - 2022-03-06 22:48:16 --> URI Class Initialized
INFO - 2022-03-06 22:48:16 --> Router Class Initialized
INFO - 2022-03-06 22:48:16 --> Output Class Initialized
INFO - 2022-03-06 22:48:16 --> Security Class Initialized
DEBUG - 2022-03-06 22:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:48:16 --> Input Class Initialized
INFO - 2022-03-06 22:48:16 --> Language Class Initialized
INFO - 2022-03-06 22:48:16 --> Loader Class Initialized
INFO - 2022-03-06 22:48:16 --> Helper loaded: url_helper
INFO - 2022-03-06 22:48:16 --> Helper loaded: form_helper
INFO - 2022-03-06 22:48:16 --> Helper loaded: common_helper
INFO - 2022-03-06 22:48:16 --> Database Driver Class Initialized
DEBUG - 2022-03-06 22:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 22:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 22:48:16 --> Controller Class Initialized
INFO - 2022-03-06 22:48:16 --> Form Validation Class Initialized
DEBUG - 2022-03-06 22:48:16 --> Encrypt Class Initialized
DEBUG - 2022-03-06 22:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 22:48:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 22:48:16 --> Email Class Initialized
INFO - 2022-03-06 22:48:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 22:48:16 --> Calendar Class Initialized
INFO - 2022-03-06 22:48:16 --> Model "Login_model" initialized
INFO - 2022-03-06 22:48:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 22:48:16 --> Final output sent to browser
DEBUG - 2022-03-06 22:48:16 --> Total execution time: 0.0263
ERROR - 2022-03-06 22:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:50:53 --> Config Class Initialized
INFO - 2022-03-06 22:50:53 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:50:53 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:50:53 --> Utf8 Class Initialized
INFO - 2022-03-06 22:50:53 --> URI Class Initialized
INFO - 2022-03-06 22:50:53 --> Router Class Initialized
INFO - 2022-03-06 22:50:53 --> Output Class Initialized
INFO - 2022-03-06 22:50:53 --> Security Class Initialized
DEBUG - 2022-03-06 22:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:50:53 --> Input Class Initialized
INFO - 2022-03-06 22:50:53 --> Language Class Initialized
INFO - 2022-03-06 22:50:53 --> Loader Class Initialized
INFO - 2022-03-06 22:50:53 --> Helper loaded: url_helper
INFO - 2022-03-06 22:50:53 --> Helper loaded: form_helper
INFO - 2022-03-06 22:50:53 --> Helper loaded: common_helper
INFO - 2022-03-06 22:50:53 --> Database Driver Class Initialized
DEBUG - 2022-03-06 22:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 22:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 22:50:53 --> Controller Class Initialized
INFO - 2022-03-06 22:50:53 --> Form Validation Class Initialized
DEBUG - 2022-03-06 22:50:53 --> Encrypt Class Initialized
DEBUG - 2022-03-06 22:50:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 22:50:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 22:50:53 --> Email Class Initialized
INFO - 2022-03-06 22:50:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 22:50:53 --> Calendar Class Initialized
INFO - 2022-03-06 22:50:53 --> Model "Login_model" initialized
INFO - 2022-03-06 22:50:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-06 22:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:50:53 --> Config Class Initialized
INFO - 2022-03-06 22:50:53 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:50:53 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:50:53 --> Utf8 Class Initialized
INFO - 2022-03-06 22:50:53 --> URI Class Initialized
INFO - 2022-03-06 22:50:53 --> Router Class Initialized
INFO - 2022-03-06 22:50:53 --> Output Class Initialized
INFO - 2022-03-06 22:50:53 --> Security Class Initialized
DEBUG - 2022-03-06 22:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:50:53 --> Input Class Initialized
INFO - 2022-03-06 22:50:53 --> Language Class Initialized
INFO - 2022-03-06 22:50:53 --> Loader Class Initialized
INFO - 2022-03-06 22:50:53 --> Helper loaded: url_helper
INFO - 2022-03-06 22:50:53 --> Helper loaded: form_helper
INFO - 2022-03-06 22:50:53 --> Helper loaded: common_helper
INFO - 2022-03-06 22:50:53 --> Database Driver Class Initialized
DEBUG - 2022-03-06 22:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 22:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 22:50:53 --> Controller Class Initialized
INFO - 2022-03-06 22:50:53 --> Form Validation Class Initialized
DEBUG - 2022-03-06 22:50:53 --> Encrypt Class Initialized
INFO - 2022-03-06 22:50:53 --> Model "Login_model" initialized
INFO - 2022-03-06 22:50:53 --> Model "Dashboard_model" initialized
INFO - 2022-03-06 22:50:53 --> Model "Case_model" initialized
INFO - 2022-03-06 22:51:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-06 22:51:14 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-06 22:51:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-06 22:51:14 --> Final output sent to browser
DEBUG - 2022-03-06 22:51:14 --> Total execution time: 20.2316
ERROR - 2022-03-06 22:51:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:51:16 --> Config Class Initialized
INFO - 2022-03-06 22:51:16 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:51:16 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:51:16 --> Utf8 Class Initialized
INFO - 2022-03-06 22:51:16 --> URI Class Initialized
INFO - 2022-03-06 22:51:16 --> Router Class Initialized
INFO - 2022-03-06 22:51:16 --> Output Class Initialized
INFO - 2022-03-06 22:51:16 --> Security Class Initialized
DEBUG - 2022-03-06 22:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:51:16 --> Input Class Initialized
INFO - 2022-03-06 22:51:16 --> Language Class Initialized
ERROR - 2022-03-06 22:51:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-06 22:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:51:31 --> Config Class Initialized
INFO - 2022-03-06 22:51:31 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:51:31 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:51:31 --> Utf8 Class Initialized
INFO - 2022-03-06 22:51:31 --> URI Class Initialized
INFO - 2022-03-06 22:51:31 --> Router Class Initialized
INFO - 2022-03-06 22:51:31 --> Output Class Initialized
INFO - 2022-03-06 22:51:31 --> Security Class Initialized
DEBUG - 2022-03-06 22:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:51:31 --> Input Class Initialized
INFO - 2022-03-06 22:51:31 --> Language Class Initialized
INFO - 2022-03-06 22:51:31 --> Loader Class Initialized
INFO - 2022-03-06 22:51:31 --> Helper loaded: url_helper
INFO - 2022-03-06 22:51:31 --> Helper loaded: form_helper
INFO - 2022-03-06 22:51:31 --> Helper loaded: common_helper
INFO - 2022-03-06 22:51:31 --> Database Driver Class Initialized
DEBUG - 2022-03-06 22:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 22:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 22:51:31 --> Controller Class Initialized
INFO - 2022-03-06 22:51:31 --> Form Validation Class Initialized
INFO - 2022-03-06 22:51:31 --> Model "Case_model" initialized
INFO - 2022-03-06 22:51:31 --> Model "Hospital_model" initialized
INFO - 2022-03-06 22:51:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-06 22:51:31 --> File loaded: /home3/karoteam/public_html/application/views/transaction/upcomingFollowup.php
INFO - 2022-03-06 22:51:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-06 22:51:31 --> Final output sent to browser
DEBUG - 2022-03-06 22:51:31 --> Total execution time: 0.0620
ERROR - 2022-03-06 22:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:51:31 --> Config Class Initialized
INFO - 2022-03-06 22:51:31 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:51:31 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:51:31 --> Utf8 Class Initialized
INFO - 2022-03-06 22:51:31 --> URI Class Initialized
INFO - 2022-03-06 22:51:31 --> Router Class Initialized
INFO - 2022-03-06 22:51:31 --> Output Class Initialized
INFO - 2022-03-06 22:51:31 --> Security Class Initialized
DEBUG - 2022-03-06 22:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:51:31 --> Input Class Initialized
INFO - 2022-03-06 22:51:31 --> Language Class Initialized
ERROR - 2022-03-06 22:51:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-06 22:51:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:51:39 --> Config Class Initialized
INFO - 2022-03-06 22:51:39 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:51:39 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:51:39 --> Utf8 Class Initialized
INFO - 2022-03-06 22:51:39 --> URI Class Initialized
INFO - 2022-03-06 22:51:39 --> Router Class Initialized
INFO - 2022-03-06 22:51:39 --> Output Class Initialized
INFO - 2022-03-06 22:51:39 --> Security Class Initialized
DEBUG - 2022-03-06 22:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:51:39 --> Input Class Initialized
INFO - 2022-03-06 22:51:39 --> Language Class Initialized
INFO - 2022-03-06 22:51:39 --> Loader Class Initialized
INFO - 2022-03-06 22:51:39 --> Helper loaded: url_helper
INFO - 2022-03-06 22:51:39 --> Helper loaded: form_helper
INFO - 2022-03-06 22:51:39 --> Helper loaded: common_helper
INFO - 2022-03-06 22:51:39 --> Database Driver Class Initialized
DEBUG - 2022-03-06 22:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 22:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 22:51:39 --> Controller Class Initialized
INFO - 2022-03-06 22:51:39 --> Form Validation Class Initialized
DEBUG - 2022-03-06 22:51:39 --> Encrypt Class Initialized
INFO - 2022-03-06 22:51:39 --> Model "Patient_model" initialized
INFO - 2022-03-06 22:51:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-06 22:51:39 --> Model "Referredby_model" initialized
INFO - 2022-03-06 22:51:39 --> Model "Prefix_master" initialized
INFO - 2022-03-06 22:51:39 --> Model "Hospital_model" initialized
INFO - 2022-03-06 22:51:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-06 22:51:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-06 22:51:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-06 22:51:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:51:48 --> Config Class Initialized
INFO - 2022-03-06 22:51:48 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:51:48 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:51:48 --> Utf8 Class Initialized
INFO - 2022-03-06 22:51:48 --> URI Class Initialized
INFO - 2022-03-06 22:51:48 --> Router Class Initialized
INFO - 2022-03-06 22:51:48 --> Output Class Initialized
INFO - 2022-03-06 22:51:48 --> Security Class Initialized
DEBUG - 2022-03-06 22:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:51:48 --> Input Class Initialized
INFO - 2022-03-06 22:51:48 --> Language Class Initialized
ERROR - 2022-03-06 22:51:48 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-06 22:51:53 --> Final output sent to browser
DEBUG - 2022-03-06 22:51:53 --> Total execution time: 7.8804
ERROR - 2022-03-06 22:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:52:24 --> Config Class Initialized
INFO - 2022-03-06 22:52:24 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:52:24 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:52:24 --> Utf8 Class Initialized
INFO - 2022-03-06 22:52:24 --> URI Class Initialized
INFO - 2022-03-06 22:52:24 --> Router Class Initialized
INFO - 2022-03-06 22:52:24 --> Output Class Initialized
INFO - 2022-03-06 22:52:24 --> Security Class Initialized
DEBUG - 2022-03-06 22:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:52:24 --> Input Class Initialized
INFO - 2022-03-06 22:52:24 --> Language Class Initialized
INFO - 2022-03-06 22:52:24 --> Loader Class Initialized
INFO - 2022-03-06 22:52:24 --> Helper loaded: url_helper
INFO - 2022-03-06 22:52:24 --> Helper loaded: form_helper
INFO - 2022-03-06 22:52:24 --> Helper loaded: common_helper
INFO - 2022-03-06 22:52:24 --> Database Driver Class Initialized
DEBUG - 2022-03-06 22:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 22:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 22:52:24 --> Controller Class Initialized
INFO - 2022-03-06 22:52:24 --> Form Validation Class Initialized
DEBUG - 2022-03-06 22:52:24 --> Encrypt Class Initialized
DEBUG - 2022-03-06 22:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 22:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 22:52:24 --> Email Class Initialized
INFO - 2022-03-06 22:52:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 22:52:24 --> Calendar Class Initialized
INFO - 2022-03-06 22:52:24 --> Model "Login_model" initialized
ERROR - 2022-03-06 22:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 22:52:24 --> Config Class Initialized
INFO - 2022-03-06 22:52:24 --> Hooks Class Initialized
DEBUG - 2022-03-06 22:52:24 --> UTF-8 Support Enabled
INFO - 2022-03-06 22:52:24 --> Utf8 Class Initialized
INFO - 2022-03-06 22:52:24 --> URI Class Initialized
INFO - 2022-03-06 22:52:24 --> Router Class Initialized
INFO - 2022-03-06 22:52:24 --> Output Class Initialized
INFO - 2022-03-06 22:52:24 --> Security Class Initialized
DEBUG - 2022-03-06 22:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 22:52:24 --> Input Class Initialized
INFO - 2022-03-06 22:52:24 --> Language Class Initialized
INFO - 2022-03-06 22:52:24 --> Loader Class Initialized
INFO - 2022-03-06 22:52:24 --> Helper loaded: url_helper
INFO - 2022-03-06 22:52:24 --> Helper loaded: form_helper
INFO - 2022-03-06 22:52:24 --> Helper loaded: common_helper
INFO - 2022-03-06 22:52:24 --> Database Driver Class Initialized
DEBUG - 2022-03-06 22:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 22:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 22:52:24 --> Controller Class Initialized
INFO - 2022-03-06 22:52:24 --> Form Validation Class Initialized
DEBUG - 2022-03-06 22:52:24 --> Encrypt Class Initialized
DEBUG - 2022-03-06 22:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 22:52:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 22:52:24 --> Email Class Initialized
INFO - 2022-03-06 22:52:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 22:52:24 --> Calendar Class Initialized
INFO - 2022-03-06 22:52:24 --> Model "Login_model" initialized
INFO - 2022-03-06 22:52:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 22:52:24 --> Final output sent to browser
DEBUG - 2022-03-06 22:52:24 --> Total execution time: 0.0224
ERROR - 2022-03-06 23:58:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-06 23:58:41 --> Config Class Initialized
INFO - 2022-03-06 23:58:41 --> Hooks Class Initialized
DEBUG - 2022-03-06 23:58:41 --> UTF-8 Support Enabled
INFO - 2022-03-06 23:58:41 --> Utf8 Class Initialized
INFO - 2022-03-06 23:58:41 --> URI Class Initialized
DEBUG - 2022-03-06 23:58:41 --> No URI present. Default controller set.
INFO - 2022-03-06 23:58:41 --> Router Class Initialized
INFO - 2022-03-06 23:58:41 --> Output Class Initialized
INFO - 2022-03-06 23:58:41 --> Security Class Initialized
DEBUG - 2022-03-06 23:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-06 23:58:41 --> Input Class Initialized
INFO - 2022-03-06 23:58:41 --> Language Class Initialized
INFO - 2022-03-06 23:58:41 --> Loader Class Initialized
INFO - 2022-03-06 23:58:41 --> Helper loaded: url_helper
INFO - 2022-03-06 23:58:41 --> Helper loaded: form_helper
INFO - 2022-03-06 23:58:41 --> Helper loaded: common_helper
INFO - 2022-03-06 23:58:41 --> Database Driver Class Initialized
DEBUG - 2022-03-06 23:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-06 23:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-06 23:58:41 --> Controller Class Initialized
INFO - 2022-03-06 23:58:41 --> Form Validation Class Initialized
DEBUG - 2022-03-06 23:58:41 --> Encrypt Class Initialized
DEBUG - 2022-03-06 23:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 23:58:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-06 23:58:41 --> Email Class Initialized
INFO - 2022-03-06 23:58:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-06 23:58:41 --> Calendar Class Initialized
INFO - 2022-03-06 23:58:41 --> Model "Login_model" initialized
INFO - 2022-03-06 23:58:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-06 23:58:41 --> Final output sent to browser
DEBUG - 2022-03-06 23:58:41 --> Total execution time: 0.0380
