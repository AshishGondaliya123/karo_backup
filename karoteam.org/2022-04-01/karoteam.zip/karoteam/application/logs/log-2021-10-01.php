<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-01 05:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 05:29:43 --> Config Class Initialized
INFO - 2021-10-01 05:29:43 --> Hooks Class Initialized
DEBUG - 2021-10-01 05:29:43 --> UTF-8 Support Enabled
INFO - 2021-10-01 05:29:43 --> Utf8 Class Initialized
INFO - 2021-10-01 05:29:43 --> URI Class Initialized
DEBUG - 2021-10-01 05:29:43 --> No URI present. Default controller set.
INFO - 2021-10-01 05:29:43 --> Router Class Initialized
INFO - 2021-10-01 05:29:43 --> Output Class Initialized
INFO - 2021-10-01 05:29:43 --> Security Class Initialized
DEBUG - 2021-10-01 05:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 05:29:43 --> Input Class Initialized
INFO - 2021-10-01 05:29:43 --> Language Class Initialized
INFO - 2021-10-01 05:29:43 --> Loader Class Initialized
INFO - 2021-10-01 05:29:43 --> Helper loaded: url_helper
INFO - 2021-10-01 05:29:43 --> Helper loaded: form_helper
INFO - 2021-10-01 05:29:43 --> Helper loaded: common_helper
INFO - 2021-10-01 05:29:43 --> Database Driver Class Initialized
DEBUG - 2021-10-01 05:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-01 05:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-01 05:29:43 --> Controller Class Initialized
INFO - 2021-10-01 05:29:43 --> Form Validation Class Initialized
DEBUG - 2021-10-01 05:29:43 --> Encrypt Class Initialized
DEBUG - 2021-10-01 05:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-01 05:29:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-01 05:29:43 --> Email Class Initialized
INFO - 2021-10-01 05:29:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-01 05:29:43 --> Calendar Class Initialized
INFO - 2021-10-01 05:29:43 --> Model "Login_model" initialized
INFO - 2021-10-01 05:29:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-01 05:29:43 --> Final output sent to browser
DEBUG - 2021-10-01 05:29:43 --> Total execution time: 0.0648
ERROR - 2021-10-01 16:08:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 16:08:04 --> Config Class Initialized
INFO - 2021-10-01 16:08:04 --> Hooks Class Initialized
DEBUG - 2021-10-01 16:08:04 --> UTF-8 Support Enabled
INFO - 2021-10-01 16:08:04 --> Utf8 Class Initialized
INFO - 2021-10-01 16:08:04 --> URI Class Initialized
INFO - 2021-10-01 16:08:04 --> Router Class Initialized
INFO - 2021-10-01 16:08:04 --> Output Class Initialized
INFO - 2021-10-01 16:08:04 --> Security Class Initialized
DEBUG - 2021-10-01 16:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 16:08:04 --> Input Class Initialized
INFO - 2021-10-01 16:08:04 --> Language Class Initialized
ERROR - 2021-10-01 16:08:04 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-10-01 17:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 17:19:59 --> Config Class Initialized
INFO - 2021-10-01 17:19:59 --> Hooks Class Initialized
DEBUG - 2021-10-01 17:19:59 --> UTF-8 Support Enabled
INFO - 2021-10-01 17:19:59 --> Utf8 Class Initialized
INFO - 2021-10-01 17:19:59 --> URI Class Initialized
INFO - 2021-10-01 17:19:59 --> Router Class Initialized
INFO - 2021-10-01 17:19:59 --> Output Class Initialized
INFO - 2021-10-01 17:19:59 --> Security Class Initialized
DEBUG - 2021-10-01 17:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 17:19:59 --> Input Class Initialized
INFO - 2021-10-01 17:19:59 --> Language Class Initialized
ERROR - 2021-10-01 17:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 17:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 17:20:00 --> Config Class Initialized
INFO - 2021-10-01 17:20:00 --> Hooks Class Initialized
DEBUG - 2021-10-01 17:20:00 --> UTF-8 Support Enabled
INFO - 2021-10-01 17:20:00 --> Utf8 Class Initialized
INFO - 2021-10-01 17:20:00 --> URI Class Initialized
DEBUG - 2021-10-01 17:20:00 --> No URI present. Default controller set.
INFO - 2021-10-01 17:20:00 --> Router Class Initialized
INFO - 2021-10-01 17:20:00 --> Output Class Initialized
INFO - 2021-10-01 17:20:00 --> Security Class Initialized
DEBUG - 2021-10-01 17:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 17:20:00 --> Input Class Initialized
INFO - 2021-10-01 17:20:00 --> Language Class Initialized
INFO - 2021-10-01 17:20:00 --> Loader Class Initialized
INFO - 2021-10-01 17:20:00 --> Helper loaded: url_helper
INFO - 2021-10-01 17:20:00 --> Helper loaded: form_helper
INFO - 2021-10-01 17:20:00 --> Helper loaded: common_helper
INFO - 2021-10-01 17:20:00 --> Database Driver Class Initialized
DEBUG - 2021-10-01 17:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-01 17:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-01 17:20:00 --> Controller Class Initialized
INFO - 2021-10-01 17:20:00 --> Form Validation Class Initialized
DEBUG - 2021-10-01 17:20:00 --> Encrypt Class Initialized
DEBUG - 2021-10-01 17:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-01 17:20:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-01 17:20:00 --> Email Class Initialized
INFO - 2021-10-01 17:20:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-01 17:20:00 --> Calendar Class Initialized
INFO - 2021-10-01 17:20:00 --> Model "Login_model" initialized
INFO - 2021-10-01 17:20:00 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-01 17:20:00 --> Final output sent to browser
DEBUG - 2021-10-01 17:20:00 --> Total execution time: 0.2084
ERROR - 2021-10-01 17:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 17:20:00 --> Config Class Initialized
INFO - 2021-10-01 17:20:00 --> Hooks Class Initialized
DEBUG - 2021-10-01 17:20:00 --> UTF-8 Support Enabled
INFO - 2021-10-01 17:20:00 --> Utf8 Class Initialized
INFO - 2021-10-01 17:20:00 --> URI Class Initialized
INFO - 2021-10-01 17:20:00 --> Router Class Initialized
INFO - 2021-10-01 17:20:00 --> Output Class Initialized
INFO - 2021-10-01 17:20:00 --> Security Class Initialized
DEBUG - 2021-10-01 17:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 17:20:00 --> Input Class Initialized
INFO - 2021-10-01 17:20:00 --> Language Class Initialized
ERROR - 2021-10-01 17:20:00 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2021-10-01 17:20:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 17:20:01 --> Config Class Initialized
INFO - 2021-10-01 17:20:01 --> Hooks Class Initialized
DEBUG - 2021-10-01 17:20:01 --> UTF-8 Support Enabled
INFO - 2021-10-01 17:20:01 --> Utf8 Class Initialized
INFO - 2021-10-01 17:20:01 --> URI Class Initialized
INFO - 2021-10-01 17:20:01 --> Router Class Initialized
INFO - 2021-10-01 17:20:01 --> Output Class Initialized
INFO - 2021-10-01 17:20:01 --> Security Class Initialized
DEBUG - 2021-10-01 17:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 17:20:01 --> Input Class Initialized
INFO - 2021-10-01 17:20:01 --> Language Class Initialized
ERROR - 2021-10-01 17:20:01 --> 404 Page Not Found: Blog/index
ERROR - 2021-10-01 17:20:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 17:20:02 --> Config Class Initialized
INFO - 2021-10-01 17:20:02 --> Hooks Class Initialized
DEBUG - 2021-10-01 17:20:02 --> UTF-8 Support Enabled
INFO - 2021-10-01 17:20:02 --> Utf8 Class Initialized
INFO - 2021-10-01 17:20:02 --> URI Class Initialized
INFO - 2021-10-01 17:20:02 --> Router Class Initialized
INFO - 2021-10-01 17:20:02 --> Output Class Initialized
INFO - 2021-10-01 17:20:02 --> Security Class Initialized
DEBUG - 2021-10-01 17:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 17:20:02 --> Input Class Initialized
INFO - 2021-10-01 17:20:02 --> Language Class Initialized
ERROR - 2021-10-01 17:20:02 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-10-01 17:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 17:20:03 --> Config Class Initialized
INFO - 2021-10-01 17:20:03 --> Hooks Class Initialized
DEBUG - 2021-10-01 17:20:03 --> UTF-8 Support Enabled
INFO - 2021-10-01 17:20:03 --> Utf8 Class Initialized
INFO - 2021-10-01 17:20:03 --> URI Class Initialized
INFO - 2021-10-01 17:20:03 --> Router Class Initialized
INFO - 2021-10-01 17:20:03 --> Output Class Initialized
INFO - 2021-10-01 17:20:03 --> Security Class Initialized
DEBUG - 2021-10-01 17:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 17:20:03 --> Input Class Initialized
INFO - 2021-10-01 17:20:03 --> Language Class Initialized
ERROR - 2021-10-01 17:20:03 --> 404 Page Not Found: Wp/index
ERROR - 2021-10-01 18:46:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 18:46:41 --> Config Class Initialized
INFO - 2021-10-01 18:46:41 --> Hooks Class Initialized
DEBUG - 2021-10-01 18:46:41 --> UTF-8 Support Enabled
INFO - 2021-10-01 18:46:41 --> Utf8 Class Initialized
INFO - 2021-10-01 18:46:41 --> URI Class Initialized
DEBUG - 2021-10-01 18:46:41 --> No URI present. Default controller set.
INFO - 2021-10-01 18:46:41 --> Router Class Initialized
INFO - 2021-10-01 18:46:41 --> Output Class Initialized
INFO - 2021-10-01 18:46:41 --> Security Class Initialized
DEBUG - 2021-10-01 18:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 18:46:41 --> Input Class Initialized
INFO - 2021-10-01 18:46:41 --> Language Class Initialized
INFO - 2021-10-01 18:46:41 --> Loader Class Initialized
INFO - 2021-10-01 18:46:41 --> Helper loaded: url_helper
INFO - 2021-10-01 18:46:41 --> Helper loaded: form_helper
INFO - 2021-10-01 18:46:41 --> Helper loaded: common_helper
INFO - 2021-10-01 18:46:41 --> Database Driver Class Initialized
DEBUG - 2021-10-01 18:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-01 18:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-01 18:46:41 --> Controller Class Initialized
INFO - 2021-10-01 18:46:41 --> Form Validation Class Initialized
DEBUG - 2021-10-01 18:46:41 --> Encrypt Class Initialized
DEBUG - 2021-10-01 18:46:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-01 18:46:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-01 18:46:41 --> Email Class Initialized
INFO - 2021-10-01 18:46:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-01 18:46:41 --> Calendar Class Initialized
INFO - 2021-10-01 18:46:41 --> Model "Login_model" initialized
INFO - 2021-10-01 18:46:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-01 18:46:41 --> Final output sent to browser
DEBUG - 2021-10-01 18:46:41 --> Total execution time: 0.6544
ERROR - 2021-10-01 20:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 20:51:33 --> Config Class Initialized
INFO - 2021-10-01 20:51:33 --> Hooks Class Initialized
DEBUG - 2021-10-01 20:51:33 --> UTF-8 Support Enabled
INFO - 2021-10-01 20:51:33 --> Utf8 Class Initialized
INFO - 2021-10-01 20:51:33 --> URI Class Initialized
INFO - 2021-10-01 20:51:33 --> Router Class Initialized
INFO - 2021-10-01 20:51:33 --> Output Class Initialized
INFO - 2021-10-01 20:51:33 --> Security Class Initialized
DEBUG - 2021-10-01 20:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 20:51:33 --> Input Class Initialized
INFO - 2021-10-01 20:51:33 --> Language Class Initialized
ERROR - 2021-10-01 20:51:33 --> 404 Page Not Found: Wp-includes/index
ERROR - 2021-10-01 22:10:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-01 22:10:07 --> Config Class Initialized
INFO - 2021-10-01 22:10:07 --> Hooks Class Initialized
DEBUG - 2021-10-01 22:10:07 --> UTF-8 Support Enabled
INFO - 2021-10-01 22:10:07 --> Utf8 Class Initialized
INFO - 2021-10-01 22:10:07 --> URI Class Initialized
DEBUG - 2021-10-01 22:10:07 --> No URI present. Default controller set.
INFO - 2021-10-01 22:10:07 --> Router Class Initialized
INFO - 2021-10-01 22:10:07 --> Output Class Initialized
INFO - 2021-10-01 22:10:07 --> Security Class Initialized
DEBUG - 2021-10-01 22:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-01 22:10:07 --> Input Class Initialized
INFO - 2021-10-01 22:10:07 --> Language Class Initialized
INFO - 2021-10-01 22:10:07 --> Loader Class Initialized
INFO - 2021-10-01 22:10:07 --> Helper loaded: url_helper
INFO - 2021-10-01 22:10:07 --> Helper loaded: form_helper
INFO - 2021-10-01 22:10:07 --> Helper loaded: common_helper
INFO - 2021-10-01 22:10:07 --> Database Driver Class Initialized
DEBUG - 2021-10-01 22:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-01 22:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-01 22:10:07 --> Controller Class Initialized
INFO - 2021-10-01 22:10:07 --> Form Validation Class Initialized
DEBUG - 2021-10-01 22:10:07 --> Encrypt Class Initialized
DEBUG - 2021-10-01 22:10:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-01 22:10:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-01 22:10:07 --> Email Class Initialized
INFO - 2021-10-01 22:10:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-01 22:10:07 --> Calendar Class Initialized
INFO - 2021-10-01 22:10:07 --> Model "Login_model" initialized
INFO - 2021-10-01 22:10:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-01 22:10:07 --> Final output sent to browser
DEBUG - 2021-10-01 22:10:07 --> Total execution time: 0.0615
