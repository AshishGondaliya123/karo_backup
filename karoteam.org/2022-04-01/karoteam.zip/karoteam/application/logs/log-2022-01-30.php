<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-30 10:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 10:22:06 --> Config Class Initialized
INFO - 2022-01-30 10:22:06 --> Hooks Class Initialized
DEBUG - 2022-01-30 10:22:06 --> UTF-8 Support Enabled
INFO - 2022-01-30 10:22:06 --> Utf8 Class Initialized
INFO - 2022-01-30 10:22:06 --> URI Class Initialized
DEBUG - 2022-01-30 10:22:06 --> No URI present. Default controller set.
INFO - 2022-01-30 10:22:06 --> Router Class Initialized
INFO - 2022-01-30 10:22:06 --> Output Class Initialized
INFO - 2022-01-30 10:22:06 --> Security Class Initialized
DEBUG - 2022-01-30 10:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 10:22:06 --> Input Class Initialized
INFO - 2022-01-30 10:22:06 --> Language Class Initialized
INFO - 2022-01-30 10:22:06 --> Loader Class Initialized
INFO - 2022-01-30 10:22:06 --> Helper loaded: url_helper
INFO - 2022-01-30 10:22:06 --> Helper loaded: form_helper
INFO - 2022-01-30 10:22:06 --> Helper loaded: common_helper
INFO - 2022-01-30 10:22:06 --> Database Driver Class Initialized
DEBUG - 2022-01-30 10:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 10:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 10:22:06 --> Controller Class Initialized
INFO - 2022-01-30 10:22:06 --> Form Validation Class Initialized
DEBUG - 2022-01-30 10:22:06 --> Encrypt Class Initialized
DEBUG - 2022-01-30 10:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 10:22:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 10:22:06 --> Email Class Initialized
INFO - 2022-01-30 10:22:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 10:22:06 --> Calendar Class Initialized
INFO - 2022-01-30 10:22:06 --> Model "Login_model" initialized
INFO - 2022-01-30 10:22:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-30 10:22:06 --> Final output sent to browser
DEBUG - 2022-01-30 10:22:06 --> Total execution time: 0.0229
ERROR - 2022-01-30 10:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 10:22:07 --> Config Class Initialized
INFO - 2022-01-30 10:22:07 --> Hooks Class Initialized
DEBUG - 2022-01-30 10:22:07 --> UTF-8 Support Enabled
INFO - 2022-01-30 10:22:07 --> Utf8 Class Initialized
INFO - 2022-01-30 10:22:07 --> URI Class Initialized
DEBUG - 2022-01-30 10:22:07 --> No URI present. Default controller set.
INFO - 2022-01-30 10:22:07 --> Router Class Initialized
INFO - 2022-01-30 10:22:07 --> Output Class Initialized
INFO - 2022-01-30 10:22:07 --> Security Class Initialized
DEBUG - 2022-01-30 10:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 10:22:07 --> Input Class Initialized
INFO - 2022-01-30 10:22:07 --> Language Class Initialized
INFO - 2022-01-30 10:22:07 --> Loader Class Initialized
INFO - 2022-01-30 10:22:07 --> Helper loaded: url_helper
INFO - 2022-01-30 10:22:07 --> Helper loaded: form_helper
INFO - 2022-01-30 10:22:07 --> Helper loaded: common_helper
INFO - 2022-01-30 10:22:07 --> Database Driver Class Initialized
DEBUG - 2022-01-30 10:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 10:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 10:22:07 --> Controller Class Initialized
INFO - 2022-01-30 10:22:07 --> Form Validation Class Initialized
DEBUG - 2022-01-30 10:22:07 --> Encrypt Class Initialized
DEBUG - 2022-01-30 10:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 10:22:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 10:22:07 --> Email Class Initialized
INFO - 2022-01-30 10:22:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 10:22:07 --> Calendar Class Initialized
INFO - 2022-01-30 10:22:07 --> Model "Login_model" initialized
INFO - 2022-01-30 10:22:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-30 10:22:07 --> Final output sent to browser
DEBUG - 2022-01-30 10:22:07 --> Total execution time: 0.0281
ERROR - 2022-01-30 11:43:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 11:43:12 --> Config Class Initialized
INFO - 2022-01-30 11:43:12 --> Hooks Class Initialized
DEBUG - 2022-01-30 11:43:12 --> UTF-8 Support Enabled
INFO - 2022-01-30 11:43:12 --> Utf8 Class Initialized
INFO - 2022-01-30 11:43:12 --> URI Class Initialized
DEBUG - 2022-01-30 11:43:12 --> No URI present. Default controller set.
INFO - 2022-01-30 11:43:12 --> Router Class Initialized
INFO - 2022-01-30 11:43:12 --> Output Class Initialized
INFO - 2022-01-30 11:43:12 --> Security Class Initialized
DEBUG - 2022-01-30 11:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 11:43:12 --> Input Class Initialized
INFO - 2022-01-30 11:43:12 --> Language Class Initialized
INFO - 2022-01-30 11:43:12 --> Loader Class Initialized
INFO - 2022-01-30 11:43:12 --> Helper loaded: url_helper
INFO - 2022-01-30 11:43:12 --> Helper loaded: form_helper
INFO - 2022-01-30 11:43:12 --> Helper loaded: common_helper
INFO - 2022-01-30 11:43:12 --> Database Driver Class Initialized
DEBUG - 2022-01-30 11:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 11:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 11:43:12 --> Controller Class Initialized
INFO - 2022-01-30 11:43:12 --> Form Validation Class Initialized
DEBUG - 2022-01-30 11:43:12 --> Encrypt Class Initialized
DEBUG - 2022-01-30 11:43:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 11:43:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 11:43:12 --> Email Class Initialized
INFO - 2022-01-30 11:43:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 11:43:12 --> Calendar Class Initialized
INFO - 2022-01-30 11:43:12 --> Model "Login_model" initialized
INFO - 2022-01-30 11:43:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-30 11:43:12 --> Final output sent to browser
DEBUG - 2022-01-30 11:43:12 --> Total execution time: 0.0235
ERROR - 2022-01-30 11:48:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 11:48:12 --> Config Class Initialized
INFO - 2022-01-30 11:48:12 --> Hooks Class Initialized
DEBUG - 2022-01-30 11:48:12 --> UTF-8 Support Enabled
INFO - 2022-01-30 11:48:12 --> Utf8 Class Initialized
INFO - 2022-01-30 11:48:12 --> URI Class Initialized
DEBUG - 2022-01-30 11:48:12 --> No URI present. Default controller set.
INFO - 2022-01-30 11:48:12 --> Router Class Initialized
INFO - 2022-01-30 11:48:12 --> Output Class Initialized
INFO - 2022-01-30 11:48:12 --> Security Class Initialized
DEBUG - 2022-01-30 11:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 11:48:12 --> Input Class Initialized
INFO - 2022-01-30 11:48:12 --> Language Class Initialized
INFO - 2022-01-30 11:48:12 --> Loader Class Initialized
INFO - 2022-01-30 11:48:12 --> Helper loaded: url_helper
INFO - 2022-01-30 11:48:12 --> Helper loaded: form_helper
INFO - 2022-01-30 11:48:12 --> Helper loaded: common_helper
INFO - 2022-01-30 11:48:12 --> Database Driver Class Initialized
DEBUG - 2022-01-30 11:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 11:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 11:48:12 --> Controller Class Initialized
INFO - 2022-01-30 11:48:12 --> Form Validation Class Initialized
DEBUG - 2022-01-30 11:48:12 --> Encrypt Class Initialized
DEBUG - 2022-01-30 11:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 11:48:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 11:48:12 --> Email Class Initialized
INFO - 2022-01-30 11:48:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 11:48:12 --> Calendar Class Initialized
INFO - 2022-01-30 11:48:12 --> Model "Login_model" initialized
INFO - 2022-01-30 11:48:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-30 11:48:12 --> Final output sent to browser
DEBUG - 2022-01-30 11:48:12 --> Total execution time: 0.0276
ERROR - 2022-01-30 14:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 14:19:17 --> Config Class Initialized
INFO - 2022-01-30 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-01-30 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-01-30 14:19:17 --> Utf8 Class Initialized
INFO - 2022-01-30 14:19:17 --> URI Class Initialized
DEBUG - 2022-01-30 14:19:17 --> No URI present. Default controller set.
INFO - 2022-01-30 14:19:17 --> Router Class Initialized
INFO - 2022-01-30 14:19:17 --> Output Class Initialized
INFO - 2022-01-30 14:19:17 --> Security Class Initialized
DEBUG - 2022-01-30 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 14:19:17 --> Input Class Initialized
INFO - 2022-01-30 14:19:17 --> Language Class Initialized
INFO - 2022-01-30 14:19:17 --> Loader Class Initialized
INFO - 2022-01-30 14:19:17 --> Helper loaded: url_helper
INFO - 2022-01-30 14:19:17 --> Helper loaded: form_helper
INFO - 2022-01-30 14:19:17 --> Helper loaded: common_helper
INFO - 2022-01-30 14:19:17 --> Database Driver Class Initialized
DEBUG - 2022-01-30 14:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 14:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 14:19:17 --> Controller Class Initialized
INFO - 2022-01-30 14:19:17 --> Form Validation Class Initialized
DEBUG - 2022-01-30 14:19:17 --> Encrypt Class Initialized
DEBUG - 2022-01-30 14:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 14:19:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 14:19:17 --> Email Class Initialized
INFO - 2022-01-30 14:19:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 14:19:17 --> Calendar Class Initialized
INFO - 2022-01-30 14:19:17 --> Model "Login_model" initialized
INFO - 2022-01-30 14:19:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-30 14:19:17 --> Final output sent to browser
DEBUG - 2022-01-30 14:19:17 --> Total execution time: 0.0256
ERROR - 2022-01-30 14:19:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 14:19:18 --> Config Class Initialized
INFO - 2022-01-30 14:19:18 --> Hooks Class Initialized
DEBUG - 2022-01-30 14:19:18 --> UTF-8 Support Enabled
INFO - 2022-01-30 14:19:18 --> Utf8 Class Initialized
INFO - 2022-01-30 14:19:18 --> URI Class Initialized
INFO - 2022-01-30 14:19:18 --> Router Class Initialized
INFO - 2022-01-30 14:19:18 --> Output Class Initialized
INFO - 2022-01-30 14:19:18 --> Security Class Initialized
DEBUG - 2022-01-30 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 14:19:18 --> Input Class Initialized
INFO - 2022-01-30 14:19:18 --> Language Class Initialized
ERROR - 2022-01-30 14:19:18 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-30 14:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 14:19:37 --> Config Class Initialized
INFO - 2022-01-30 14:19:37 --> Hooks Class Initialized
DEBUG - 2022-01-30 14:19:37 --> UTF-8 Support Enabled
INFO - 2022-01-30 14:19:37 --> Utf8 Class Initialized
INFO - 2022-01-30 14:19:37 --> URI Class Initialized
INFO - 2022-01-30 14:19:37 --> Router Class Initialized
INFO - 2022-01-30 14:19:37 --> Output Class Initialized
INFO - 2022-01-30 14:19:37 --> Security Class Initialized
DEBUG - 2022-01-30 14:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 14:19:37 --> Input Class Initialized
INFO - 2022-01-30 14:19:37 --> Language Class Initialized
INFO - 2022-01-30 14:19:37 --> Loader Class Initialized
INFO - 2022-01-30 14:19:37 --> Helper loaded: url_helper
INFO - 2022-01-30 14:19:37 --> Helper loaded: form_helper
INFO - 2022-01-30 14:19:37 --> Helper loaded: common_helper
INFO - 2022-01-30 14:19:37 --> Database Driver Class Initialized
DEBUG - 2022-01-30 14:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 14:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 14:19:37 --> Controller Class Initialized
INFO - 2022-01-30 14:19:37 --> Form Validation Class Initialized
DEBUG - 2022-01-30 14:19:37 --> Encrypt Class Initialized
DEBUG - 2022-01-30 14:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 14:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 14:19:37 --> Email Class Initialized
INFO - 2022-01-30 14:19:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 14:19:37 --> Calendar Class Initialized
INFO - 2022-01-30 14:19:37 --> Model "Login_model" initialized
INFO - 2022-01-30 14:19:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-30 14:19:37 --> Final output sent to browser
DEBUG - 2022-01-30 14:19:37 --> Total execution time: 0.0266
ERROR - 2022-01-30 14:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 14:19:37 --> Config Class Initialized
INFO - 2022-01-30 14:19:37 --> Hooks Class Initialized
DEBUG - 2022-01-30 14:19:37 --> UTF-8 Support Enabled
INFO - 2022-01-30 14:19:37 --> Utf8 Class Initialized
INFO - 2022-01-30 14:19:37 --> URI Class Initialized
DEBUG - 2022-01-30 14:19:37 --> No URI present. Default controller set.
INFO - 2022-01-30 14:19:37 --> Router Class Initialized
INFO - 2022-01-30 14:19:37 --> Output Class Initialized
INFO - 2022-01-30 14:19:37 --> Security Class Initialized
DEBUG - 2022-01-30 14:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 14:19:37 --> Input Class Initialized
INFO - 2022-01-30 14:19:37 --> Language Class Initialized
INFO - 2022-01-30 14:19:37 --> Loader Class Initialized
INFO - 2022-01-30 14:19:37 --> Helper loaded: url_helper
INFO - 2022-01-30 14:19:37 --> Helper loaded: form_helper
INFO - 2022-01-30 14:19:37 --> Helper loaded: common_helper
INFO - 2022-01-30 14:19:37 --> Database Driver Class Initialized
DEBUG - 2022-01-30 14:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 14:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 14:19:37 --> Controller Class Initialized
INFO - 2022-01-30 14:19:37 --> Form Validation Class Initialized
DEBUG - 2022-01-30 14:19:37 --> Encrypt Class Initialized
DEBUG - 2022-01-30 14:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 14:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 14:19:37 --> Email Class Initialized
INFO - 2022-01-30 14:19:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 14:19:37 --> Calendar Class Initialized
INFO - 2022-01-30 14:19:37 --> Model "Login_model" initialized
INFO - 2022-01-30 14:19:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-30 14:19:37 --> Final output sent to browser
DEBUG - 2022-01-30 14:19:37 --> Total execution time: 0.0299
ERROR - 2022-01-30 14:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 14:19:38 --> Config Class Initialized
INFO - 2022-01-30 14:19:38 --> Hooks Class Initialized
DEBUG - 2022-01-30 14:19:38 --> UTF-8 Support Enabled
INFO - 2022-01-30 14:19:38 --> Utf8 Class Initialized
INFO - 2022-01-30 14:19:38 --> URI Class Initialized
INFO - 2022-01-30 14:19:38 --> Router Class Initialized
INFO - 2022-01-30 14:19:38 --> Output Class Initialized
INFO - 2022-01-30 14:19:38 --> Security Class Initialized
DEBUG - 2022-01-30 14:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 14:19:38 --> Input Class Initialized
INFO - 2022-01-30 14:19:38 --> Language Class Initialized
INFO - 2022-01-30 14:19:38 --> Loader Class Initialized
INFO - 2022-01-30 14:19:38 --> Helper loaded: url_helper
INFO - 2022-01-30 14:19:38 --> Helper loaded: form_helper
INFO - 2022-01-30 14:19:38 --> Helper loaded: common_helper
INFO - 2022-01-30 14:19:38 --> Database Driver Class Initialized
DEBUG - 2022-01-30 14:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 14:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 14:19:38 --> Controller Class Initialized
INFO - 2022-01-30 14:19:38 --> Form Validation Class Initialized
DEBUG - 2022-01-30 14:19:38 --> Encrypt Class Initialized
DEBUG - 2022-01-30 14:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 14:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 14:19:38 --> Email Class Initialized
INFO - 2022-01-30 14:19:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 14:19:38 --> Calendar Class Initialized
INFO - 2022-01-30 14:19:38 --> Model "Login_model" initialized
ERROR - 2022-01-30 14:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 14:19:39 --> Config Class Initialized
INFO - 2022-01-30 14:19:39 --> Hooks Class Initialized
DEBUG - 2022-01-30 14:19:39 --> UTF-8 Support Enabled
INFO - 2022-01-30 14:19:39 --> Utf8 Class Initialized
INFO - 2022-01-30 14:19:39 --> URI Class Initialized
INFO - 2022-01-30 14:19:39 --> Router Class Initialized
INFO - 2022-01-30 14:19:39 --> Output Class Initialized
INFO - 2022-01-30 14:19:39 --> Security Class Initialized
DEBUG - 2022-01-30 14:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 14:19:39 --> Input Class Initialized
INFO - 2022-01-30 14:19:39 --> Language Class Initialized
INFO - 2022-01-30 14:19:39 --> Loader Class Initialized
INFO - 2022-01-30 14:19:39 --> Helper loaded: url_helper
INFO - 2022-01-30 14:19:39 --> Helper loaded: form_helper
INFO - 2022-01-30 14:19:39 --> Helper loaded: common_helper
INFO - 2022-01-30 14:19:39 --> Database Driver Class Initialized
DEBUG - 2022-01-30 14:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 14:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 14:19:39 --> Controller Class Initialized
INFO - 2022-01-30 14:19:39 --> Form Validation Class Initialized
DEBUG - 2022-01-30 14:19:39 --> Encrypt Class Initialized
DEBUG - 2022-01-30 14:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 14:19:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 14:19:39 --> Email Class Initialized
INFO - 2022-01-30 14:19:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 14:19:39 --> Calendar Class Initialized
INFO - 2022-01-30 14:19:39 --> Model "Login_model" initialized
ERROR - 2022-01-30 20:32:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 20:32:46 --> Config Class Initialized
INFO - 2022-01-30 20:32:46 --> Hooks Class Initialized
DEBUG - 2022-01-30 20:32:46 --> UTF-8 Support Enabled
INFO - 2022-01-30 20:32:46 --> Utf8 Class Initialized
INFO - 2022-01-30 20:32:46 --> URI Class Initialized
INFO - 2022-01-30 20:32:46 --> Router Class Initialized
INFO - 2022-01-30 20:32:46 --> Output Class Initialized
INFO - 2022-01-30 20:32:46 --> Security Class Initialized
DEBUG - 2022-01-30 20:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 20:32:46 --> Input Class Initialized
INFO - 2022-01-30 20:32:46 --> Language Class Initialized
ERROR - 2022-01-30 20:32:46 --> 404 Page Not Found: Wp-admin/index
ERROR - 2022-01-30 22:13:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-30 22:13:20 --> Config Class Initialized
INFO - 2022-01-30 22:13:20 --> Hooks Class Initialized
DEBUG - 2022-01-30 22:13:20 --> UTF-8 Support Enabled
INFO - 2022-01-30 22:13:20 --> Utf8 Class Initialized
INFO - 2022-01-30 22:13:20 --> URI Class Initialized
DEBUG - 2022-01-30 22:13:20 --> No URI present. Default controller set.
INFO - 2022-01-30 22:13:20 --> Router Class Initialized
INFO - 2022-01-30 22:13:20 --> Output Class Initialized
INFO - 2022-01-30 22:13:20 --> Security Class Initialized
DEBUG - 2022-01-30 22:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-30 22:13:20 --> Input Class Initialized
INFO - 2022-01-30 22:13:20 --> Language Class Initialized
INFO - 2022-01-30 22:13:20 --> Loader Class Initialized
INFO - 2022-01-30 22:13:20 --> Helper loaded: url_helper
INFO - 2022-01-30 22:13:20 --> Helper loaded: form_helper
INFO - 2022-01-30 22:13:20 --> Helper loaded: common_helper
INFO - 2022-01-30 22:13:20 --> Database Driver Class Initialized
DEBUG - 2022-01-30 22:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-30 22:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-30 22:13:20 --> Controller Class Initialized
INFO - 2022-01-30 22:13:20 --> Form Validation Class Initialized
DEBUG - 2022-01-30 22:13:20 --> Encrypt Class Initialized
DEBUG - 2022-01-30 22:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-30 22:13:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-30 22:13:20 --> Email Class Initialized
INFO - 2022-01-30 22:13:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-30 22:13:20 --> Calendar Class Initialized
INFO - 2022-01-30 22:13:20 --> Model "Login_model" initialized
INFO - 2022-01-30 22:13:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-30 22:13:20 --> Final output sent to browser
DEBUG - 2022-01-30 22:13:20 --> Total execution time: 0.0418
