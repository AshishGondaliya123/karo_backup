<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-02 00:29:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 00:29:27 --> Config Class Initialized
INFO - 2021-12-02 00:29:27 --> Hooks Class Initialized
DEBUG - 2021-12-02 00:29:27 --> UTF-8 Support Enabled
INFO - 2021-12-02 00:29:27 --> Utf8 Class Initialized
INFO - 2021-12-02 00:29:27 --> URI Class Initialized
DEBUG - 2021-12-02 00:29:27 --> No URI present. Default controller set.
INFO - 2021-12-02 00:29:27 --> Router Class Initialized
INFO - 2021-12-02 00:29:27 --> Output Class Initialized
INFO - 2021-12-02 00:29:27 --> Security Class Initialized
DEBUG - 2021-12-02 00:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 00:29:27 --> Input Class Initialized
INFO - 2021-12-02 00:29:27 --> Language Class Initialized
INFO - 2021-12-02 00:29:27 --> Loader Class Initialized
INFO - 2021-12-02 00:29:27 --> Helper loaded: url_helper
INFO - 2021-12-02 00:29:27 --> Helper loaded: form_helper
INFO - 2021-12-02 00:29:27 --> Helper loaded: common_helper
INFO - 2021-12-02 00:29:27 --> Database Driver Class Initialized
DEBUG - 2021-12-02 00:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 00:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 00:29:27 --> Controller Class Initialized
INFO - 2021-12-02 00:29:27 --> Form Validation Class Initialized
DEBUG - 2021-12-02 00:29:27 --> Encrypt Class Initialized
DEBUG - 2021-12-02 00:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 00:29:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 00:29:27 --> Email Class Initialized
INFO - 2021-12-02 00:29:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 00:29:27 --> Calendar Class Initialized
INFO - 2021-12-02 00:29:27 --> Model "Login_model" initialized
INFO - 2021-12-02 00:29:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-02 00:29:27 --> Final output sent to browser
DEBUG - 2021-12-02 00:29:27 --> Total execution time: 0.1060
ERROR - 2021-12-02 09:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:23:06 --> Config Class Initialized
INFO - 2021-12-02 09:23:06 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:23:06 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:23:06 --> Utf8 Class Initialized
INFO - 2021-12-02 09:23:06 --> URI Class Initialized
DEBUG - 2021-12-02 09:23:06 --> No URI present. Default controller set.
INFO - 2021-12-02 09:23:06 --> Router Class Initialized
INFO - 2021-12-02 09:23:06 --> Output Class Initialized
INFO - 2021-12-02 09:23:06 --> Security Class Initialized
DEBUG - 2021-12-02 09:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:23:06 --> Input Class Initialized
INFO - 2021-12-02 09:23:06 --> Language Class Initialized
INFO - 2021-12-02 09:23:06 --> Loader Class Initialized
INFO - 2021-12-02 09:23:06 --> Helper loaded: url_helper
INFO - 2021-12-02 09:23:06 --> Helper loaded: form_helper
INFO - 2021-12-02 09:23:06 --> Helper loaded: common_helper
INFO - 2021-12-02 09:23:06 --> Database Driver Class Initialized
DEBUG - 2021-12-02 09:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 09:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 09:23:06 --> Controller Class Initialized
INFO - 2021-12-02 09:23:06 --> Form Validation Class Initialized
DEBUG - 2021-12-02 09:23:06 --> Encrypt Class Initialized
DEBUG - 2021-12-02 09:23:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 09:23:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 09:23:06 --> Email Class Initialized
INFO - 2021-12-02 09:23:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 09:23:06 --> Calendar Class Initialized
INFO - 2021-12-02 09:23:06 --> Model "Login_model" initialized
INFO - 2021-12-02 09:23:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-02 09:23:06 --> Final output sent to browser
DEBUG - 2021-12-02 09:23:06 --> Total execution time: 0.0366
ERROR - 2021-12-02 09:25:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:25:58 --> Config Class Initialized
INFO - 2021-12-02 09:25:58 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:25:58 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:25:58 --> Utf8 Class Initialized
INFO - 2021-12-02 09:25:58 --> URI Class Initialized
DEBUG - 2021-12-02 09:25:58 --> No URI present. Default controller set.
INFO - 2021-12-02 09:25:58 --> Router Class Initialized
INFO - 2021-12-02 09:25:58 --> Output Class Initialized
INFO - 2021-12-02 09:25:58 --> Security Class Initialized
DEBUG - 2021-12-02 09:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:25:58 --> Input Class Initialized
INFO - 2021-12-02 09:25:58 --> Language Class Initialized
INFO - 2021-12-02 09:25:58 --> Loader Class Initialized
INFO - 2021-12-02 09:25:58 --> Helper loaded: url_helper
INFO - 2021-12-02 09:25:58 --> Helper loaded: form_helper
INFO - 2021-12-02 09:25:58 --> Helper loaded: common_helper
INFO - 2021-12-02 09:25:58 --> Database Driver Class Initialized
DEBUG - 2021-12-02 09:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 09:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 09:25:58 --> Controller Class Initialized
INFO - 2021-12-02 09:25:58 --> Form Validation Class Initialized
DEBUG - 2021-12-02 09:25:58 --> Encrypt Class Initialized
DEBUG - 2021-12-02 09:25:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 09:25:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 09:25:58 --> Email Class Initialized
INFO - 2021-12-02 09:25:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 09:25:58 --> Calendar Class Initialized
INFO - 2021-12-02 09:25:58 --> Model "Login_model" initialized
INFO - 2021-12-02 09:25:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-02 09:25:58 --> Final output sent to browser
DEBUG - 2021-12-02 09:25:58 --> Total execution time: 0.0245
ERROR - 2021-12-02 09:25:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:25:59 --> Config Class Initialized
INFO - 2021-12-02 09:25:59 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:25:59 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:25:59 --> Utf8 Class Initialized
INFO - 2021-12-02 09:25:59 --> URI Class Initialized
DEBUG - 2021-12-02 09:25:59 --> No URI present. Default controller set.
INFO - 2021-12-02 09:25:59 --> Router Class Initialized
INFO - 2021-12-02 09:25:59 --> Output Class Initialized
INFO - 2021-12-02 09:25:59 --> Security Class Initialized
DEBUG - 2021-12-02 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:25:59 --> Input Class Initialized
INFO - 2021-12-02 09:25:59 --> Language Class Initialized
INFO - 2021-12-02 09:25:59 --> Loader Class Initialized
INFO - 2021-12-02 09:25:59 --> Helper loaded: url_helper
INFO - 2021-12-02 09:25:59 --> Helper loaded: form_helper
INFO - 2021-12-02 09:25:59 --> Helper loaded: common_helper
INFO - 2021-12-02 09:25:59 --> Database Driver Class Initialized
DEBUG - 2021-12-02 09:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 09:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 09:25:59 --> Controller Class Initialized
INFO - 2021-12-02 09:25:59 --> Form Validation Class Initialized
DEBUG - 2021-12-02 09:25:59 --> Encrypt Class Initialized
DEBUG - 2021-12-02 09:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 09:25:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 09:25:59 --> Email Class Initialized
INFO - 2021-12-02 09:25:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 09:25:59 --> Calendar Class Initialized
INFO - 2021-12-02 09:25:59 --> Model "Login_model" initialized
INFO - 2021-12-02 09:25:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-02 09:25:59 --> Final output sent to browser
DEBUG - 2021-12-02 09:25:59 --> Total execution time: 0.0251
ERROR - 2021-12-02 09:25:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:25:59 --> Config Class Initialized
INFO - 2021-12-02 09:25:59 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:25:59 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:25:59 --> Utf8 Class Initialized
INFO - 2021-12-02 09:25:59 --> URI Class Initialized
INFO - 2021-12-02 09:25:59 --> Router Class Initialized
INFO - 2021-12-02 09:25:59 --> Output Class Initialized
INFO - 2021-12-02 09:25:59 --> Security Class Initialized
DEBUG - 2021-12-02 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:25:59 --> Input Class Initialized
INFO - 2021-12-02 09:25:59 --> Language Class Initialized
ERROR - 2021-12-02 09:25:59 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-02 09:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:00 --> Config Class Initialized
INFO - 2021-12-02 09:26:00 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:00 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:00 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:00 --> URI Class Initialized
INFO - 2021-12-02 09:26:00 --> Router Class Initialized
INFO - 2021-12-02 09:26:00 --> Output Class Initialized
INFO - 2021-12-02 09:26:00 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:00 --> Input Class Initialized
INFO - 2021-12-02 09:26:00 --> Language Class Initialized
ERROR - 2021-12-02 09:26:00 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-02 09:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:00 --> Config Class Initialized
INFO - 2021-12-02 09:26:00 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:00 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:00 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:00 --> URI Class Initialized
INFO - 2021-12-02 09:26:00 --> Router Class Initialized
INFO - 2021-12-02 09:26:00 --> Output Class Initialized
INFO - 2021-12-02 09:26:00 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:00 --> Input Class Initialized
INFO - 2021-12-02 09:26:00 --> Language Class Initialized
ERROR - 2021-12-02 09:26:00 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-02 09:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:01 --> Config Class Initialized
INFO - 2021-12-02 09:26:01 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:01 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:01 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:01 --> URI Class Initialized
INFO - 2021-12-02 09:26:01 --> Router Class Initialized
INFO - 2021-12-02 09:26:01 --> Output Class Initialized
INFO - 2021-12-02 09:26:01 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:01 --> Input Class Initialized
INFO - 2021-12-02 09:26:01 --> Language Class Initialized
ERROR - 2021-12-02 09:26:01 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-02 09:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:01 --> Config Class Initialized
INFO - 2021-12-02 09:26:01 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:01 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:01 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:01 --> URI Class Initialized
INFO - 2021-12-02 09:26:01 --> Router Class Initialized
INFO - 2021-12-02 09:26:01 --> Output Class Initialized
INFO - 2021-12-02 09:26:01 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:01 --> Input Class Initialized
INFO - 2021-12-02 09:26:01 --> Language Class Initialized
ERROR - 2021-12-02 09:26:01 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-02 09:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:01 --> Config Class Initialized
INFO - 2021-12-02 09:26:01 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:01 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:01 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:01 --> URI Class Initialized
INFO - 2021-12-02 09:26:01 --> Router Class Initialized
INFO - 2021-12-02 09:26:01 --> Output Class Initialized
INFO - 2021-12-02 09:26:01 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:01 --> Input Class Initialized
INFO - 2021-12-02 09:26:01 --> Language Class Initialized
ERROR - 2021-12-02 09:26:01 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-02 09:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:02 --> Config Class Initialized
INFO - 2021-12-02 09:26:02 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:02 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:02 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:02 --> URI Class Initialized
INFO - 2021-12-02 09:26:02 --> Router Class Initialized
INFO - 2021-12-02 09:26:02 --> Output Class Initialized
INFO - 2021-12-02 09:26:02 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:02 --> Input Class Initialized
INFO - 2021-12-02 09:26:02 --> Language Class Initialized
ERROR - 2021-12-02 09:26:02 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-02 09:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:02 --> Config Class Initialized
INFO - 2021-12-02 09:26:02 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:02 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:02 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:02 --> URI Class Initialized
INFO - 2021-12-02 09:26:02 --> Router Class Initialized
INFO - 2021-12-02 09:26:02 --> Output Class Initialized
INFO - 2021-12-02 09:26:02 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:02 --> Input Class Initialized
INFO - 2021-12-02 09:26:02 --> Language Class Initialized
ERROR - 2021-12-02 09:26:02 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-12-02 09:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:03 --> Config Class Initialized
INFO - 2021-12-02 09:26:03 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:03 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:03 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:03 --> URI Class Initialized
INFO - 2021-12-02 09:26:03 --> Router Class Initialized
INFO - 2021-12-02 09:26:03 --> Output Class Initialized
INFO - 2021-12-02 09:26:03 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:03 --> Input Class Initialized
INFO - 2021-12-02 09:26:03 --> Language Class Initialized
ERROR - 2021-12-02 09:26:03 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-02 09:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:03 --> Config Class Initialized
INFO - 2021-12-02 09:26:03 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:03 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:03 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:03 --> URI Class Initialized
INFO - 2021-12-02 09:26:03 --> Router Class Initialized
INFO - 2021-12-02 09:26:03 --> Output Class Initialized
INFO - 2021-12-02 09:26:03 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:03 --> Input Class Initialized
INFO - 2021-12-02 09:26:03 --> Language Class Initialized
ERROR - 2021-12-02 09:26:03 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-02 09:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:04 --> Config Class Initialized
INFO - 2021-12-02 09:26:04 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:04 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:04 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:04 --> URI Class Initialized
INFO - 2021-12-02 09:26:04 --> Router Class Initialized
INFO - 2021-12-02 09:26:04 --> Output Class Initialized
INFO - 2021-12-02 09:26:04 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:04 --> Input Class Initialized
INFO - 2021-12-02 09:26:04 --> Language Class Initialized
ERROR - 2021-12-02 09:26:04 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-02 09:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:04 --> Config Class Initialized
INFO - 2021-12-02 09:26:04 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:04 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:04 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:04 --> URI Class Initialized
INFO - 2021-12-02 09:26:04 --> Router Class Initialized
INFO - 2021-12-02 09:26:04 --> Output Class Initialized
INFO - 2021-12-02 09:26:04 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:04 --> Input Class Initialized
INFO - 2021-12-02 09:26:04 --> Language Class Initialized
ERROR - 2021-12-02 09:26:04 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-02 09:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:04 --> Config Class Initialized
INFO - 2021-12-02 09:26:04 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:04 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:04 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:04 --> URI Class Initialized
INFO - 2021-12-02 09:26:04 --> Router Class Initialized
INFO - 2021-12-02 09:26:04 --> Output Class Initialized
INFO - 2021-12-02 09:26:04 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:04 --> Input Class Initialized
INFO - 2021-12-02 09:26:04 --> Language Class Initialized
ERROR - 2021-12-02 09:26:04 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-02 09:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:05 --> Config Class Initialized
INFO - 2021-12-02 09:26:05 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:05 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:05 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:05 --> URI Class Initialized
INFO - 2021-12-02 09:26:05 --> Router Class Initialized
INFO - 2021-12-02 09:26:05 --> Output Class Initialized
INFO - 2021-12-02 09:26:05 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:05 --> Input Class Initialized
INFO - 2021-12-02 09:26:05 --> Language Class Initialized
ERROR - 2021-12-02 09:26:05 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-02 09:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:05 --> Config Class Initialized
INFO - 2021-12-02 09:26:05 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:05 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:05 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:05 --> URI Class Initialized
INFO - 2021-12-02 09:26:05 --> Router Class Initialized
INFO - 2021-12-02 09:26:05 --> Output Class Initialized
INFO - 2021-12-02 09:26:05 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:05 --> Input Class Initialized
INFO - 2021-12-02 09:26:05 --> Language Class Initialized
ERROR - 2021-12-02 09:26:05 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-02 09:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 09:26:06 --> Config Class Initialized
INFO - 2021-12-02 09:26:06 --> Hooks Class Initialized
DEBUG - 2021-12-02 09:26:06 --> UTF-8 Support Enabled
INFO - 2021-12-02 09:26:06 --> Utf8 Class Initialized
INFO - 2021-12-02 09:26:06 --> URI Class Initialized
INFO - 2021-12-02 09:26:06 --> Router Class Initialized
INFO - 2021-12-02 09:26:06 --> Output Class Initialized
INFO - 2021-12-02 09:26:06 --> Security Class Initialized
DEBUG - 2021-12-02 09:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 09:26:06 --> Input Class Initialized
INFO - 2021-12-02 09:26:06 --> Language Class Initialized
ERROR - 2021-12-02 09:26:06 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-02 10:15:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 10:15:57 --> Config Class Initialized
INFO - 2021-12-02 10:15:57 --> Hooks Class Initialized
DEBUG - 2021-12-02 10:15:57 --> UTF-8 Support Enabled
INFO - 2021-12-02 10:15:57 --> Utf8 Class Initialized
INFO - 2021-12-02 10:15:57 --> URI Class Initialized
DEBUG - 2021-12-02 10:15:57 --> No URI present. Default controller set.
INFO - 2021-12-02 10:15:57 --> Router Class Initialized
INFO - 2021-12-02 10:15:57 --> Output Class Initialized
INFO - 2021-12-02 10:15:57 --> Security Class Initialized
DEBUG - 2021-12-02 10:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 10:15:57 --> Input Class Initialized
INFO - 2021-12-02 10:15:57 --> Language Class Initialized
INFO - 2021-12-02 10:15:57 --> Loader Class Initialized
INFO - 2021-12-02 10:15:57 --> Helper loaded: url_helper
INFO - 2021-12-02 10:15:57 --> Helper loaded: form_helper
INFO - 2021-12-02 10:15:57 --> Helper loaded: common_helper
INFO - 2021-12-02 10:15:57 --> Database Driver Class Initialized
DEBUG - 2021-12-02 10:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 10:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 10:15:57 --> Controller Class Initialized
INFO - 2021-12-02 10:15:57 --> Form Validation Class Initialized
DEBUG - 2021-12-02 10:15:57 --> Encrypt Class Initialized
DEBUG - 2021-12-02 10:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 10:15:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 10:15:57 --> Email Class Initialized
INFO - 2021-12-02 10:15:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 10:15:57 --> Calendar Class Initialized
INFO - 2021-12-02 10:15:57 --> Model "Login_model" initialized
INFO - 2021-12-02 10:15:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-02 10:15:57 --> Final output sent to browser
DEBUG - 2021-12-02 10:15:57 --> Total execution time: 0.0258
ERROR - 2021-12-02 10:15:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 10:15:59 --> Config Class Initialized
INFO - 2021-12-02 10:15:59 --> Hooks Class Initialized
DEBUG - 2021-12-02 10:15:59 --> UTF-8 Support Enabled
INFO - 2021-12-02 10:15:59 --> Utf8 Class Initialized
INFO - 2021-12-02 10:15:59 --> URI Class Initialized
DEBUG - 2021-12-02 10:15:59 --> No URI present. Default controller set.
INFO - 2021-12-02 10:15:59 --> Router Class Initialized
INFO - 2021-12-02 10:15:59 --> Output Class Initialized
INFO - 2021-12-02 10:15:59 --> Security Class Initialized
DEBUG - 2021-12-02 10:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 10:15:59 --> Input Class Initialized
INFO - 2021-12-02 10:15:59 --> Language Class Initialized
INFO - 2021-12-02 10:15:59 --> Loader Class Initialized
INFO - 2021-12-02 10:15:59 --> Helper loaded: url_helper
INFO - 2021-12-02 10:15:59 --> Helper loaded: form_helper
INFO - 2021-12-02 10:15:59 --> Helper loaded: common_helper
INFO - 2021-12-02 10:15:59 --> Database Driver Class Initialized
DEBUG - 2021-12-02 10:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 10:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 10:15:59 --> Controller Class Initialized
INFO - 2021-12-02 10:15:59 --> Form Validation Class Initialized
DEBUG - 2021-12-02 10:15:59 --> Encrypt Class Initialized
DEBUG - 2021-12-02 10:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 10:15:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 10:15:59 --> Email Class Initialized
INFO - 2021-12-02 10:15:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 10:15:59 --> Calendar Class Initialized
INFO - 2021-12-02 10:15:59 --> Model "Login_model" initialized
INFO - 2021-12-02 10:15:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-02 10:15:59 --> Final output sent to browser
DEBUG - 2021-12-02 10:15:59 --> Total execution time: 0.0236
ERROR - 2021-12-02 14:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 14:19:57 --> Config Class Initialized
INFO - 2021-12-02 14:19:57 --> Hooks Class Initialized
DEBUG - 2021-12-02 14:19:57 --> UTF-8 Support Enabled
INFO - 2021-12-02 14:19:57 --> Utf8 Class Initialized
INFO - 2021-12-02 14:19:57 --> URI Class Initialized
DEBUG - 2021-12-02 14:19:57 --> No URI present. Default controller set.
INFO - 2021-12-02 14:19:57 --> Router Class Initialized
INFO - 2021-12-02 14:19:57 --> Output Class Initialized
INFO - 2021-12-02 14:19:57 --> Security Class Initialized
DEBUG - 2021-12-02 14:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 14:19:57 --> Input Class Initialized
INFO - 2021-12-02 14:19:57 --> Language Class Initialized
INFO - 2021-12-02 14:19:57 --> Loader Class Initialized
INFO - 2021-12-02 14:19:57 --> Helper loaded: url_helper
INFO - 2021-12-02 14:19:57 --> Helper loaded: form_helper
INFO - 2021-12-02 14:19:57 --> Helper loaded: common_helper
INFO - 2021-12-02 14:19:57 --> Database Driver Class Initialized
DEBUG - 2021-12-02 14:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 14:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 14:19:57 --> Controller Class Initialized
INFO - 2021-12-02 14:19:57 --> Form Validation Class Initialized
DEBUG - 2021-12-02 14:19:57 --> Encrypt Class Initialized
DEBUG - 2021-12-02 14:19:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 14:19:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 14:19:57 --> Email Class Initialized
INFO - 2021-12-02 14:19:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 14:19:57 --> Calendar Class Initialized
INFO - 2021-12-02 14:19:57 --> Model "Login_model" initialized
INFO - 2021-12-02 14:19:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-02 14:19:57 --> Final output sent to browser
DEBUG - 2021-12-02 14:19:57 --> Total execution time: 0.0248
ERROR - 2021-12-02 14:20:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 14:20:02 --> Config Class Initialized
INFO - 2021-12-02 14:20:02 --> Hooks Class Initialized
DEBUG - 2021-12-02 14:20:02 --> UTF-8 Support Enabled
INFO - 2021-12-02 14:20:02 --> Utf8 Class Initialized
INFO - 2021-12-02 14:20:02 --> URI Class Initialized
INFO - 2021-12-02 14:20:02 --> Router Class Initialized
INFO - 2021-12-02 14:20:02 --> Output Class Initialized
INFO - 2021-12-02 14:20:02 --> Security Class Initialized
DEBUG - 2021-12-02 14:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 14:20:02 --> Input Class Initialized
INFO - 2021-12-02 14:20:02 --> Language Class Initialized
ERROR - 2021-12-02 14:20:02 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-02 14:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 14:20:10 --> Config Class Initialized
INFO - 2021-12-02 14:20:10 --> Hooks Class Initialized
DEBUG - 2021-12-02 14:20:10 --> UTF-8 Support Enabled
INFO - 2021-12-02 14:20:10 --> Utf8 Class Initialized
INFO - 2021-12-02 14:20:10 --> URI Class Initialized
INFO - 2021-12-02 14:20:10 --> Router Class Initialized
INFO - 2021-12-02 14:20:10 --> Output Class Initialized
INFO - 2021-12-02 14:20:10 --> Security Class Initialized
DEBUG - 2021-12-02 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 14:20:10 --> Input Class Initialized
INFO - 2021-12-02 14:20:10 --> Language Class Initialized
INFO - 2021-12-02 14:20:10 --> Loader Class Initialized
INFO - 2021-12-02 14:20:10 --> Helper loaded: url_helper
INFO - 2021-12-02 14:20:10 --> Helper loaded: form_helper
INFO - 2021-12-02 14:20:10 --> Helper loaded: common_helper
INFO - 2021-12-02 14:20:10 --> Database Driver Class Initialized
DEBUG - 2021-12-02 14:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 14:20:10 --> Controller Class Initialized
INFO - 2021-12-02 14:20:10 --> Form Validation Class Initialized
DEBUG - 2021-12-02 14:20:10 --> Encrypt Class Initialized
DEBUG - 2021-12-02 14:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 14:20:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 14:20:10 --> Email Class Initialized
INFO - 2021-12-02 14:20:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 14:20:10 --> Calendar Class Initialized
INFO - 2021-12-02 14:20:10 --> Model "Login_model" initialized
INFO - 2021-12-02 14:20:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-02 14:20:10 --> Final output sent to browser
DEBUG - 2021-12-02 14:20:10 --> Total execution time: 0.0218
ERROR - 2021-12-02 14:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 14:20:11 --> Config Class Initialized
INFO - 2021-12-02 14:20:11 --> Hooks Class Initialized
DEBUG - 2021-12-02 14:20:11 --> UTF-8 Support Enabled
INFO - 2021-12-02 14:20:11 --> Utf8 Class Initialized
INFO - 2021-12-02 14:20:11 --> URI Class Initialized
DEBUG - 2021-12-02 14:20:11 --> No URI present. Default controller set.
INFO - 2021-12-02 14:20:11 --> Router Class Initialized
INFO - 2021-12-02 14:20:11 --> Output Class Initialized
INFO - 2021-12-02 14:20:11 --> Security Class Initialized
DEBUG - 2021-12-02 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 14:20:11 --> Input Class Initialized
INFO - 2021-12-02 14:20:11 --> Language Class Initialized
INFO - 2021-12-02 14:20:11 --> Loader Class Initialized
INFO - 2021-12-02 14:20:11 --> Helper loaded: url_helper
INFO - 2021-12-02 14:20:11 --> Helper loaded: form_helper
INFO - 2021-12-02 14:20:11 --> Helper loaded: common_helper
INFO - 2021-12-02 14:20:11 --> Database Driver Class Initialized
DEBUG - 2021-12-02 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 14:20:11 --> Controller Class Initialized
INFO - 2021-12-02 14:20:11 --> Form Validation Class Initialized
DEBUG - 2021-12-02 14:20:11 --> Encrypt Class Initialized
DEBUG - 2021-12-02 14:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 14:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 14:20:11 --> Email Class Initialized
INFO - 2021-12-02 14:20:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 14:20:11 --> Calendar Class Initialized
INFO - 2021-12-02 14:20:11 --> Model "Login_model" initialized
INFO - 2021-12-02 14:20:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-02 14:20:11 --> Final output sent to browser
DEBUG - 2021-12-02 14:20:11 --> Total execution time: 0.0231
ERROR - 2021-12-02 14:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 14:20:11 --> Config Class Initialized
INFO - 2021-12-02 14:20:11 --> Hooks Class Initialized
DEBUG - 2021-12-02 14:20:11 --> UTF-8 Support Enabled
INFO - 2021-12-02 14:20:11 --> Utf8 Class Initialized
INFO - 2021-12-02 14:20:11 --> URI Class Initialized
INFO - 2021-12-02 14:20:11 --> Router Class Initialized
INFO - 2021-12-02 14:20:11 --> Output Class Initialized
INFO - 2021-12-02 14:20:11 --> Security Class Initialized
DEBUG - 2021-12-02 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 14:20:11 --> Input Class Initialized
INFO - 2021-12-02 14:20:11 --> Language Class Initialized
INFO - 2021-12-02 14:20:11 --> Loader Class Initialized
INFO - 2021-12-02 14:20:11 --> Helper loaded: url_helper
INFO - 2021-12-02 14:20:11 --> Helper loaded: form_helper
INFO - 2021-12-02 14:20:11 --> Helper loaded: common_helper
INFO - 2021-12-02 14:20:11 --> Database Driver Class Initialized
DEBUG - 2021-12-02 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 14:20:11 --> Controller Class Initialized
INFO - 2021-12-02 14:20:11 --> Form Validation Class Initialized
DEBUG - 2021-12-02 14:20:11 --> Encrypt Class Initialized
DEBUG - 2021-12-02 14:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 14:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 14:20:11 --> Email Class Initialized
INFO - 2021-12-02 14:20:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 14:20:11 --> Calendar Class Initialized
INFO - 2021-12-02 14:20:11 --> Model "Login_model" initialized
ERROR - 2021-12-02 14:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 14:20:12 --> Config Class Initialized
INFO - 2021-12-02 14:20:12 --> Hooks Class Initialized
DEBUG - 2021-12-02 14:20:12 --> UTF-8 Support Enabled
INFO - 2021-12-02 14:20:12 --> Utf8 Class Initialized
INFO - 2021-12-02 14:20:12 --> URI Class Initialized
INFO - 2021-12-02 14:20:12 --> Router Class Initialized
INFO - 2021-12-02 14:20:12 --> Output Class Initialized
INFO - 2021-12-02 14:20:12 --> Security Class Initialized
DEBUG - 2021-12-02 14:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 14:20:12 --> Input Class Initialized
INFO - 2021-12-02 14:20:12 --> Language Class Initialized
INFO - 2021-12-02 14:20:12 --> Loader Class Initialized
INFO - 2021-12-02 14:20:12 --> Helper loaded: url_helper
INFO - 2021-12-02 14:20:12 --> Helper loaded: form_helper
INFO - 2021-12-02 14:20:12 --> Helper loaded: common_helper
INFO - 2021-12-02 14:20:12 --> Database Driver Class Initialized
DEBUG - 2021-12-02 14:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-02 14:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-02 14:20:12 --> Controller Class Initialized
INFO - 2021-12-02 14:20:12 --> Form Validation Class Initialized
DEBUG - 2021-12-02 14:20:12 --> Encrypt Class Initialized
DEBUG - 2021-12-02 14:20:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-02 14:20:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-02 14:20:12 --> Email Class Initialized
INFO - 2021-12-02 14:20:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-02 14:20:12 --> Calendar Class Initialized
INFO - 2021-12-02 14:20:12 --> Model "Login_model" initialized
ERROR - 2021-12-02 15:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-02 15:41:03 --> Config Class Initialized
INFO - 2021-12-02 15:41:03 --> Hooks Class Initialized
DEBUG - 2021-12-02 15:41:03 --> UTF-8 Support Enabled
INFO - 2021-12-02 15:41:03 --> Utf8 Class Initialized
INFO - 2021-12-02 15:41:03 --> URI Class Initialized
INFO - 2021-12-02 15:41:03 --> Router Class Initialized
INFO - 2021-12-02 15:41:03 --> Output Class Initialized
INFO - 2021-12-02 15:41:03 --> Security Class Initialized
DEBUG - 2021-12-02 15:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-02 15:41:03 --> Input Class Initialized
INFO - 2021-12-02 15:41:03 --> Language Class Initialized
ERROR - 2021-12-02 15:41:03 --> 404 Page Not Found: Configurationphp_old/index
