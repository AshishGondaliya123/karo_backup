<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-13 11:06:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 11:06:54 --> Config Class Initialized
INFO - 2022-03-13 11:06:54 --> Hooks Class Initialized
DEBUG - 2022-03-13 11:06:54 --> UTF-8 Support Enabled
INFO - 2022-03-13 11:06:54 --> Utf8 Class Initialized
INFO - 2022-03-13 11:06:54 --> URI Class Initialized
DEBUG - 2022-03-13 11:06:54 --> No URI present. Default controller set.
INFO - 2022-03-13 11:06:54 --> Router Class Initialized
INFO - 2022-03-13 11:06:54 --> Output Class Initialized
INFO - 2022-03-13 11:06:54 --> Security Class Initialized
DEBUG - 2022-03-13 11:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 11:06:54 --> Input Class Initialized
INFO - 2022-03-13 11:06:54 --> Language Class Initialized
INFO - 2022-03-13 11:06:54 --> Loader Class Initialized
INFO - 2022-03-13 11:06:54 --> Helper loaded: url_helper
INFO - 2022-03-13 11:06:54 --> Helper loaded: form_helper
INFO - 2022-03-13 11:06:54 --> Helper loaded: common_helper
INFO - 2022-03-13 11:06:54 --> Database Driver Class Initialized
DEBUG - 2022-03-13 11:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 11:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 11:06:54 --> Controller Class Initialized
INFO - 2022-03-13 11:06:54 --> Form Validation Class Initialized
DEBUG - 2022-03-13 11:06:54 --> Encrypt Class Initialized
DEBUG - 2022-03-13 11:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 11:06:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 11:06:54 --> Email Class Initialized
INFO - 2022-03-13 11:06:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 11:06:54 --> Calendar Class Initialized
INFO - 2022-03-13 11:06:54 --> Model "Login_model" initialized
INFO - 2022-03-13 11:06:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 11:06:54 --> Final output sent to browser
DEBUG - 2022-03-13 11:06:54 --> Total execution time: 0.0367
ERROR - 2022-03-13 11:07:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 11:07:29 --> Config Class Initialized
INFO - 2022-03-13 11:07:29 --> Hooks Class Initialized
DEBUG - 2022-03-13 11:07:29 --> UTF-8 Support Enabled
INFO - 2022-03-13 11:07:29 --> Utf8 Class Initialized
INFO - 2022-03-13 11:07:29 --> URI Class Initialized
DEBUG - 2022-03-13 11:07:29 --> No URI present. Default controller set.
INFO - 2022-03-13 11:07:29 --> Router Class Initialized
INFO - 2022-03-13 11:07:29 --> Output Class Initialized
INFO - 2022-03-13 11:07:29 --> Security Class Initialized
DEBUG - 2022-03-13 11:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 11:07:29 --> Input Class Initialized
INFO - 2022-03-13 11:07:29 --> Language Class Initialized
INFO - 2022-03-13 11:07:29 --> Loader Class Initialized
INFO - 2022-03-13 11:07:29 --> Helper loaded: url_helper
INFO - 2022-03-13 11:07:29 --> Helper loaded: form_helper
INFO - 2022-03-13 11:07:29 --> Helper loaded: common_helper
INFO - 2022-03-13 11:07:29 --> Database Driver Class Initialized
DEBUG - 2022-03-13 11:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 11:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 11:07:29 --> Controller Class Initialized
INFO - 2022-03-13 11:07:29 --> Form Validation Class Initialized
DEBUG - 2022-03-13 11:07:29 --> Encrypt Class Initialized
DEBUG - 2022-03-13 11:07:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 11:07:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 11:07:29 --> Email Class Initialized
INFO - 2022-03-13 11:07:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 11:07:29 --> Calendar Class Initialized
INFO - 2022-03-13 11:07:29 --> Model "Login_model" initialized
INFO - 2022-03-13 11:07:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 11:07:29 --> Final output sent to browser
DEBUG - 2022-03-13 11:07:29 --> Total execution time: 0.0204
ERROR - 2022-03-13 11:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 11:09:29 --> Config Class Initialized
INFO - 2022-03-13 11:09:29 --> Hooks Class Initialized
DEBUG - 2022-03-13 11:09:29 --> UTF-8 Support Enabled
INFO - 2022-03-13 11:09:29 --> Utf8 Class Initialized
INFO - 2022-03-13 11:09:29 --> URI Class Initialized
DEBUG - 2022-03-13 11:09:29 --> No URI present. Default controller set.
INFO - 2022-03-13 11:09:29 --> Router Class Initialized
INFO - 2022-03-13 11:09:29 --> Output Class Initialized
INFO - 2022-03-13 11:09:29 --> Security Class Initialized
DEBUG - 2022-03-13 11:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 11:09:29 --> Input Class Initialized
INFO - 2022-03-13 11:09:29 --> Language Class Initialized
INFO - 2022-03-13 11:09:29 --> Loader Class Initialized
INFO - 2022-03-13 11:09:29 --> Helper loaded: url_helper
INFO - 2022-03-13 11:09:29 --> Helper loaded: form_helper
INFO - 2022-03-13 11:09:29 --> Helper loaded: common_helper
INFO - 2022-03-13 11:09:29 --> Database Driver Class Initialized
DEBUG - 2022-03-13 11:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 11:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 11:09:29 --> Controller Class Initialized
INFO - 2022-03-13 11:09:29 --> Form Validation Class Initialized
DEBUG - 2022-03-13 11:09:29 --> Encrypt Class Initialized
DEBUG - 2022-03-13 11:09:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 11:09:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 11:09:29 --> Email Class Initialized
INFO - 2022-03-13 11:09:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 11:09:29 --> Calendar Class Initialized
INFO - 2022-03-13 11:09:29 --> Model "Login_model" initialized
INFO - 2022-03-13 11:09:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 11:09:29 --> Final output sent to browser
DEBUG - 2022-03-13 11:09:29 --> Total execution time: 0.0236
ERROR - 2022-03-13 14:00:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 14:00:24 --> Config Class Initialized
INFO - 2022-03-13 14:00:24 --> Hooks Class Initialized
DEBUG - 2022-03-13 14:00:24 --> UTF-8 Support Enabled
INFO - 2022-03-13 14:00:24 --> Utf8 Class Initialized
INFO - 2022-03-13 14:00:24 --> URI Class Initialized
DEBUG - 2022-03-13 14:00:24 --> No URI present. Default controller set.
INFO - 2022-03-13 14:00:24 --> Router Class Initialized
INFO - 2022-03-13 14:00:24 --> Output Class Initialized
INFO - 2022-03-13 14:00:24 --> Security Class Initialized
DEBUG - 2022-03-13 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 14:00:24 --> Input Class Initialized
INFO - 2022-03-13 14:00:24 --> Language Class Initialized
INFO - 2022-03-13 14:00:24 --> Loader Class Initialized
INFO - 2022-03-13 14:00:24 --> Helper loaded: url_helper
INFO - 2022-03-13 14:00:24 --> Helper loaded: form_helper
INFO - 2022-03-13 14:00:24 --> Helper loaded: common_helper
INFO - 2022-03-13 14:00:24 --> Database Driver Class Initialized
DEBUG - 2022-03-13 14:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 14:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 14:00:24 --> Controller Class Initialized
INFO - 2022-03-13 14:00:24 --> Form Validation Class Initialized
DEBUG - 2022-03-13 14:00:24 --> Encrypt Class Initialized
DEBUG - 2022-03-13 14:00:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 14:00:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 14:00:24 --> Email Class Initialized
INFO - 2022-03-13 14:00:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 14:00:24 --> Calendar Class Initialized
INFO - 2022-03-13 14:00:24 --> Model "Login_model" initialized
INFO - 2022-03-13 14:00:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 14:00:24 --> Final output sent to browser
DEBUG - 2022-03-13 14:00:24 --> Total execution time: 0.0543
ERROR - 2022-03-13 14:21:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 14:21:52 --> Config Class Initialized
INFO - 2022-03-13 14:21:52 --> Hooks Class Initialized
DEBUG - 2022-03-13 14:21:52 --> UTF-8 Support Enabled
INFO - 2022-03-13 14:21:52 --> Utf8 Class Initialized
INFO - 2022-03-13 14:21:52 --> URI Class Initialized
DEBUG - 2022-03-13 14:21:52 --> No URI present. Default controller set.
INFO - 2022-03-13 14:21:52 --> Router Class Initialized
INFO - 2022-03-13 14:21:52 --> Output Class Initialized
INFO - 2022-03-13 14:21:52 --> Security Class Initialized
DEBUG - 2022-03-13 14:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 14:21:52 --> Input Class Initialized
INFO - 2022-03-13 14:21:52 --> Language Class Initialized
INFO - 2022-03-13 14:21:52 --> Loader Class Initialized
INFO - 2022-03-13 14:21:52 --> Helper loaded: url_helper
INFO - 2022-03-13 14:21:52 --> Helper loaded: form_helper
INFO - 2022-03-13 14:21:52 --> Helper loaded: common_helper
INFO - 2022-03-13 14:21:52 --> Database Driver Class Initialized
DEBUG - 2022-03-13 14:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 14:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 14:21:52 --> Controller Class Initialized
INFO - 2022-03-13 14:21:52 --> Form Validation Class Initialized
DEBUG - 2022-03-13 14:21:52 --> Encrypt Class Initialized
DEBUG - 2022-03-13 14:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 14:21:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 14:21:52 --> Email Class Initialized
INFO - 2022-03-13 14:21:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 14:21:52 --> Calendar Class Initialized
INFO - 2022-03-13 14:21:52 --> Model "Login_model" initialized
INFO - 2022-03-13 14:21:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 14:21:52 --> Final output sent to browser
DEBUG - 2022-03-13 14:21:52 --> Total execution time: 0.0361
ERROR - 2022-03-13 14:21:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 14:21:52 --> Config Class Initialized
INFO - 2022-03-13 14:21:52 --> Hooks Class Initialized
DEBUG - 2022-03-13 14:21:52 --> UTF-8 Support Enabled
INFO - 2022-03-13 14:21:52 --> Utf8 Class Initialized
INFO - 2022-03-13 14:21:52 --> URI Class Initialized
INFO - 2022-03-13 14:21:52 --> Router Class Initialized
INFO - 2022-03-13 14:21:52 --> Output Class Initialized
INFO - 2022-03-13 14:21:52 --> Security Class Initialized
DEBUG - 2022-03-13 14:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 14:21:52 --> Input Class Initialized
INFO - 2022-03-13 14:21:52 --> Language Class Initialized
ERROR - 2022-03-13 14:21:52 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-13 14:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 14:22:01 --> Config Class Initialized
INFO - 2022-03-13 14:22:01 --> Hooks Class Initialized
DEBUG - 2022-03-13 14:22:01 --> UTF-8 Support Enabled
INFO - 2022-03-13 14:22:01 --> Utf8 Class Initialized
INFO - 2022-03-13 14:22:01 --> URI Class Initialized
INFO - 2022-03-13 14:22:01 --> Router Class Initialized
INFO - 2022-03-13 14:22:01 --> Output Class Initialized
INFO - 2022-03-13 14:22:01 --> Security Class Initialized
DEBUG - 2022-03-13 14:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 14:22:01 --> Input Class Initialized
INFO - 2022-03-13 14:22:01 --> Language Class Initialized
INFO - 2022-03-13 14:22:01 --> Loader Class Initialized
INFO - 2022-03-13 14:22:01 --> Helper loaded: url_helper
INFO - 2022-03-13 14:22:01 --> Helper loaded: form_helper
INFO - 2022-03-13 14:22:01 --> Helper loaded: common_helper
INFO - 2022-03-13 14:22:01 --> Database Driver Class Initialized
DEBUG - 2022-03-13 14:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 14:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 14:22:01 --> Controller Class Initialized
INFO - 2022-03-13 14:22:01 --> Form Validation Class Initialized
DEBUG - 2022-03-13 14:22:01 --> Encrypt Class Initialized
DEBUG - 2022-03-13 14:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 14:22:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 14:22:01 --> Email Class Initialized
INFO - 2022-03-13 14:22:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 14:22:01 --> Calendar Class Initialized
INFO - 2022-03-13 14:22:01 --> Model "Login_model" initialized
ERROR - 2022-03-13 14:22:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 14:22:02 --> Config Class Initialized
INFO - 2022-03-13 14:22:02 --> Hooks Class Initialized
DEBUG - 2022-03-13 14:22:02 --> UTF-8 Support Enabled
INFO - 2022-03-13 14:22:02 --> Utf8 Class Initialized
INFO - 2022-03-13 14:22:02 --> URI Class Initialized
INFO - 2022-03-13 14:22:02 --> Router Class Initialized
INFO - 2022-03-13 14:22:02 --> Output Class Initialized
INFO - 2022-03-13 14:22:02 --> Security Class Initialized
DEBUG - 2022-03-13 14:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 14:22:02 --> Input Class Initialized
INFO - 2022-03-13 14:22:02 --> Language Class Initialized
INFO - 2022-03-13 14:22:02 --> Loader Class Initialized
INFO - 2022-03-13 14:22:02 --> Helper loaded: url_helper
INFO - 2022-03-13 14:22:02 --> Helper loaded: form_helper
INFO - 2022-03-13 14:22:02 --> Helper loaded: common_helper
INFO - 2022-03-13 14:22:02 --> Database Driver Class Initialized
DEBUG - 2022-03-13 14:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 14:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 14:22:02 --> Controller Class Initialized
INFO - 2022-03-13 14:22:02 --> Form Validation Class Initialized
DEBUG - 2022-03-13 14:22:02 --> Encrypt Class Initialized
DEBUG - 2022-03-13 14:22:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 14:22:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 14:22:02 --> Email Class Initialized
INFO - 2022-03-13 14:22:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 14:22:02 --> Calendar Class Initialized
INFO - 2022-03-13 14:22:02 --> Model "Login_model" initialized
ERROR - 2022-03-13 14:22:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 14:22:03 --> Config Class Initialized
INFO - 2022-03-13 14:22:03 --> Hooks Class Initialized
DEBUG - 2022-03-13 14:22:03 --> UTF-8 Support Enabled
INFO - 2022-03-13 14:22:03 --> Utf8 Class Initialized
INFO - 2022-03-13 14:22:03 --> URI Class Initialized
INFO - 2022-03-13 14:22:03 --> Router Class Initialized
INFO - 2022-03-13 14:22:03 --> Output Class Initialized
INFO - 2022-03-13 14:22:03 --> Security Class Initialized
DEBUG - 2022-03-13 14:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 14:22:03 --> Input Class Initialized
INFO - 2022-03-13 14:22:03 --> Language Class Initialized
INFO - 2022-03-13 14:22:03 --> Loader Class Initialized
INFO - 2022-03-13 14:22:03 --> Helper loaded: url_helper
INFO - 2022-03-13 14:22:03 --> Helper loaded: form_helper
INFO - 2022-03-13 14:22:03 --> Helper loaded: common_helper
INFO - 2022-03-13 14:22:03 --> Database Driver Class Initialized
DEBUG - 2022-03-13 14:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 14:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 14:22:03 --> Controller Class Initialized
INFO - 2022-03-13 14:22:03 --> Form Validation Class Initialized
DEBUG - 2022-03-13 14:22:03 --> Encrypt Class Initialized
DEBUG - 2022-03-13 14:22:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 14:22:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 14:22:03 --> Email Class Initialized
INFO - 2022-03-13 14:22:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 14:22:03 --> Calendar Class Initialized
INFO - 2022-03-13 14:22:03 --> Model "Login_model" initialized
INFO - 2022-03-13 14:22:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 14:22:03 --> Final output sent to browser
DEBUG - 2022-03-13 14:22:03 --> Total execution time: 0.0305
ERROR - 2022-03-13 14:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 14:22:04 --> Config Class Initialized
INFO - 2022-03-13 14:22:04 --> Hooks Class Initialized
DEBUG - 2022-03-13 14:22:04 --> UTF-8 Support Enabled
INFO - 2022-03-13 14:22:04 --> Utf8 Class Initialized
INFO - 2022-03-13 14:22:04 --> URI Class Initialized
DEBUG - 2022-03-13 14:22:04 --> No URI present. Default controller set.
INFO - 2022-03-13 14:22:04 --> Router Class Initialized
INFO - 2022-03-13 14:22:04 --> Output Class Initialized
INFO - 2022-03-13 14:22:04 --> Security Class Initialized
DEBUG - 2022-03-13 14:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 14:22:04 --> Input Class Initialized
INFO - 2022-03-13 14:22:04 --> Language Class Initialized
INFO - 2022-03-13 14:22:04 --> Loader Class Initialized
INFO - 2022-03-13 14:22:04 --> Helper loaded: url_helper
INFO - 2022-03-13 14:22:04 --> Helper loaded: form_helper
INFO - 2022-03-13 14:22:04 --> Helper loaded: common_helper
INFO - 2022-03-13 14:22:04 --> Database Driver Class Initialized
DEBUG - 2022-03-13 14:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 14:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 14:22:04 --> Controller Class Initialized
INFO - 2022-03-13 14:22:04 --> Form Validation Class Initialized
DEBUG - 2022-03-13 14:22:04 --> Encrypt Class Initialized
DEBUG - 2022-03-13 14:22:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 14:22:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 14:22:04 --> Email Class Initialized
INFO - 2022-03-13 14:22:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 14:22:04 --> Calendar Class Initialized
INFO - 2022-03-13 14:22:04 --> Model "Login_model" initialized
INFO - 2022-03-13 14:22:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 14:22:04 --> Final output sent to browser
DEBUG - 2022-03-13 14:22:04 --> Total execution time: 0.0275
ERROR - 2022-03-13 23:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:10:53 --> Config Class Initialized
INFO - 2022-03-13 23:10:53 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:10:53 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:10:53 --> Utf8 Class Initialized
INFO - 2022-03-13 23:10:53 --> URI Class Initialized
DEBUG - 2022-03-13 23:10:53 --> No URI present. Default controller set.
INFO - 2022-03-13 23:10:53 --> Router Class Initialized
INFO - 2022-03-13 23:10:53 --> Output Class Initialized
INFO - 2022-03-13 23:10:53 --> Security Class Initialized
DEBUG - 2022-03-13 23:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:10:53 --> Input Class Initialized
INFO - 2022-03-13 23:10:53 --> Language Class Initialized
INFO - 2022-03-13 23:10:53 --> Loader Class Initialized
INFO - 2022-03-13 23:10:53 --> Helper loaded: url_helper
INFO - 2022-03-13 23:10:53 --> Helper loaded: form_helper
INFO - 2022-03-13 23:10:53 --> Helper loaded: common_helper
INFO - 2022-03-13 23:10:53 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:10:53 --> Controller Class Initialized
INFO - 2022-03-13 23:10:53 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:10:53 --> Encrypt Class Initialized
DEBUG - 2022-03-13 23:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 23:10:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 23:10:53 --> Email Class Initialized
INFO - 2022-03-13 23:10:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 23:10:53 --> Calendar Class Initialized
INFO - 2022-03-13 23:10:53 --> Model "Login_model" initialized
INFO - 2022-03-13 23:10:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 23:10:53 --> Final output sent to browser
DEBUG - 2022-03-13 23:10:53 --> Total execution time: 0.0245
ERROR - 2022-03-13 23:10:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:10:54 --> Config Class Initialized
INFO - 2022-03-13 23:10:54 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:10:54 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:10:54 --> Utf8 Class Initialized
INFO - 2022-03-13 23:10:54 --> URI Class Initialized
INFO - 2022-03-13 23:10:54 --> Router Class Initialized
INFO - 2022-03-13 23:10:54 --> Output Class Initialized
INFO - 2022-03-13 23:10:54 --> Security Class Initialized
DEBUG - 2022-03-13 23:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:10:54 --> Input Class Initialized
INFO - 2022-03-13 23:10:54 --> Language Class Initialized
ERROR - 2022-03-13 23:10:54 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2022-03-13 23:10:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:10:54 --> Config Class Initialized
INFO - 2022-03-13 23:10:54 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:10:54 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:10:54 --> Utf8 Class Initialized
INFO - 2022-03-13 23:10:54 --> URI Class Initialized
INFO - 2022-03-13 23:10:54 --> Router Class Initialized
INFO - 2022-03-13 23:10:54 --> Output Class Initialized
INFO - 2022-03-13 23:10:54 --> Security Class Initialized
DEBUG - 2022-03-13 23:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:10:54 --> Input Class Initialized
INFO - 2022-03-13 23:10:54 --> Language Class Initialized
ERROR - 2022-03-13 23:10:54 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2022-03-13 23:10:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:10:55 --> Config Class Initialized
INFO - 2022-03-13 23:10:55 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:10:55 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:10:55 --> Utf8 Class Initialized
INFO - 2022-03-13 23:10:55 --> URI Class Initialized
INFO - 2022-03-13 23:10:55 --> Router Class Initialized
INFO - 2022-03-13 23:10:55 --> Output Class Initialized
INFO - 2022-03-13 23:10:55 --> Security Class Initialized
DEBUG - 2022-03-13 23:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:10:55 --> Input Class Initialized
INFO - 2022-03-13 23:10:55 --> Language Class Initialized
ERROR - 2022-03-13 23:10:55 --> 404 Page Not Found: Blog/index
ERROR - 2022-03-13 23:10:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:10:55 --> Config Class Initialized
INFO - 2022-03-13 23:10:55 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:10:55 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:10:55 --> Utf8 Class Initialized
INFO - 2022-03-13 23:10:55 --> URI Class Initialized
INFO - 2022-03-13 23:10:55 --> Router Class Initialized
INFO - 2022-03-13 23:10:55 --> Output Class Initialized
INFO - 2022-03-13 23:10:55 --> Security Class Initialized
DEBUG - 2022-03-13 23:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:10:55 --> Input Class Initialized
INFO - 2022-03-13 23:10:55 --> Language Class Initialized
ERROR - 2022-03-13 23:10:55 --> 404 Page Not Found: Wordpress/index
ERROR - 2022-03-13 23:10:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:10:56 --> Config Class Initialized
INFO - 2022-03-13 23:10:56 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:10:56 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:10:56 --> Utf8 Class Initialized
INFO - 2022-03-13 23:10:56 --> URI Class Initialized
INFO - 2022-03-13 23:10:56 --> Router Class Initialized
INFO - 2022-03-13 23:10:56 --> Output Class Initialized
INFO - 2022-03-13 23:10:56 --> Security Class Initialized
DEBUG - 2022-03-13 23:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:10:56 --> Input Class Initialized
INFO - 2022-03-13 23:10:56 --> Language Class Initialized
ERROR - 2022-03-13 23:10:56 --> 404 Page Not Found: Wp/index
ERROR - 2022-03-13 23:36:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:36:12 --> Config Class Initialized
INFO - 2022-03-13 23:36:12 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:36:12 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:36:12 --> Utf8 Class Initialized
INFO - 2022-03-13 23:36:12 --> URI Class Initialized
DEBUG - 2022-03-13 23:36:12 --> No URI present. Default controller set.
INFO - 2022-03-13 23:36:12 --> Router Class Initialized
INFO - 2022-03-13 23:36:12 --> Output Class Initialized
INFO - 2022-03-13 23:36:12 --> Security Class Initialized
DEBUG - 2022-03-13 23:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:36:12 --> Input Class Initialized
INFO - 2022-03-13 23:36:12 --> Language Class Initialized
INFO - 2022-03-13 23:36:12 --> Loader Class Initialized
INFO - 2022-03-13 23:36:12 --> Helper loaded: url_helper
INFO - 2022-03-13 23:36:12 --> Helper loaded: form_helper
INFO - 2022-03-13 23:36:12 --> Helper loaded: common_helper
INFO - 2022-03-13 23:36:12 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:36:12 --> Controller Class Initialized
INFO - 2022-03-13 23:36:12 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:36:12 --> Encrypt Class Initialized
DEBUG - 2022-03-13 23:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 23:36:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 23:36:12 --> Email Class Initialized
INFO - 2022-03-13 23:36:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 23:36:12 --> Calendar Class Initialized
INFO - 2022-03-13 23:36:12 --> Model "Login_model" initialized
INFO - 2022-03-13 23:36:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 23:36:12 --> Final output sent to browser
DEBUG - 2022-03-13 23:36:12 --> Total execution time: 0.0267
ERROR - 2022-03-13 23:36:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:36:13 --> Config Class Initialized
INFO - 2022-03-13 23:36:13 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:36:13 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:36:13 --> Utf8 Class Initialized
INFO - 2022-03-13 23:36:13 --> URI Class Initialized
DEBUG - 2022-03-13 23:36:13 --> No URI present. Default controller set.
INFO - 2022-03-13 23:36:13 --> Router Class Initialized
INFO - 2022-03-13 23:36:13 --> Output Class Initialized
INFO - 2022-03-13 23:36:13 --> Security Class Initialized
DEBUG - 2022-03-13 23:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:36:13 --> Input Class Initialized
INFO - 2022-03-13 23:36:13 --> Language Class Initialized
INFO - 2022-03-13 23:36:13 --> Loader Class Initialized
INFO - 2022-03-13 23:36:13 --> Helper loaded: url_helper
INFO - 2022-03-13 23:36:13 --> Helper loaded: form_helper
INFO - 2022-03-13 23:36:13 --> Helper loaded: common_helper
INFO - 2022-03-13 23:36:13 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:36:13 --> Controller Class Initialized
INFO - 2022-03-13 23:36:14 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:36:14 --> Encrypt Class Initialized
DEBUG - 2022-03-13 23:36:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 23:36:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 23:36:14 --> Email Class Initialized
INFO - 2022-03-13 23:36:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 23:36:14 --> Calendar Class Initialized
INFO - 2022-03-13 23:36:14 --> Model "Login_model" initialized
INFO - 2022-03-13 23:36:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 23:36:14 --> Final output sent to browser
DEBUG - 2022-03-13 23:36:14 --> Total execution time: 0.0251
ERROR - 2022-03-13 23:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:36:43 --> Config Class Initialized
INFO - 2022-03-13 23:36:43 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:36:43 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:36:43 --> Utf8 Class Initialized
INFO - 2022-03-13 23:36:43 --> URI Class Initialized
DEBUG - 2022-03-13 23:36:43 --> No URI present. Default controller set.
INFO - 2022-03-13 23:36:43 --> Router Class Initialized
INFO - 2022-03-13 23:36:43 --> Output Class Initialized
INFO - 2022-03-13 23:36:43 --> Security Class Initialized
DEBUG - 2022-03-13 23:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:36:43 --> Input Class Initialized
INFO - 2022-03-13 23:36:43 --> Language Class Initialized
INFO - 2022-03-13 23:36:43 --> Loader Class Initialized
INFO - 2022-03-13 23:36:43 --> Helper loaded: url_helper
INFO - 2022-03-13 23:36:43 --> Helper loaded: form_helper
INFO - 2022-03-13 23:36:43 --> Helper loaded: common_helper
INFO - 2022-03-13 23:36:43 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:36:43 --> Controller Class Initialized
INFO - 2022-03-13 23:36:43 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:36:43 --> Encrypt Class Initialized
DEBUG - 2022-03-13 23:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 23:36:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 23:36:43 --> Email Class Initialized
INFO - 2022-03-13 23:36:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 23:36:43 --> Calendar Class Initialized
INFO - 2022-03-13 23:36:43 --> Model "Login_model" initialized
INFO - 2022-03-13 23:36:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-13 23:36:43 --> Final output sent to browser
DEBUG - 2022-03-13 23:36:43 --> Total execution time: 0.0275
ERROR - 2022-03-13 23:36:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:36:57 --> Config Class Initialized
INFO - 2022-03-13 23:36:57 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:36:57 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:36:57 --> Utf8 Class Initialized
INFO - 2022-03-13 23:36:57 --> URI Class Initialized
INFO - 2022-03-13 23:36:57 --> Router Class Initialized
INFO - 2022-03-13 23:36:57 --> Output Class Initialized
INFO - 2022-03-13 23:36:57 --> Security Class Initialized
DEBUG - 2022-03-13 23:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:36:57 --> Input Class Initialized
INFO - 2022-03-13 23:36:57 --> Language Class Initialized
INFO - 2022-03-13 23:36:57 --> Loader Class Initialized
INFO - 2022-03-13 23:36:57 --> Helper loaded: url_helper
INFO - 2022-03-13 23:36:57 --> Helper loaded: form_helper
INFO - 2022-03-13 23:36:57 --> Helper loaded: common_helper
INFO - 2022-03-13 23:36:57 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:36:57 --> Controller Class Initialized
INFO - 2022-03-13 23:36:57 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:36:57 --> Encrypt Class Initialized
DEBUG - 2022-03-13 23:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-13 23:36:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-13 23:36:57 --> Email Class Initialized
INFO - 2022-03-13 23:36:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-13 23:36:57 --> Calendar Class Initialized
INFO - 2022-03-13 23:36:57 --> Model "Login_model" initialized
INFO - 2022-03-13 23:36:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-13 23:36:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:36:57 --> Config Class Initialized
INFO - 2022-03-13 23:36:57 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:36:57 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:36:57 --> Utf8 Class Initialized
INFO - 2022-03-13 23:36:57 --> URI Class Initialized
INFO - 2022-03-13 23:36:57 --> Router Class Initialized
INFO - 2022-03-13 23:36:57 --> Output Class Initialized
INFO - 2022-03-13 23:36:57 --> Security Class Initialized
DEBUG - 2022-03-13 23:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:36:58 --> Input Class Initialized
INFO - 2022-03-13 23:36:58 --> Language Class Initialized
INFO - 2022-03-13 23:36:58 --> Loader Class Initialized
INFO - 2022-03-13 23:36:58 --> Helper loaded: url_helper
INFO - 2022-03-13 23:36:58 --> Helper loaded: form_helper
INFO - 2022-03-13 23:36:58 --> Helper loaded: common_helper
INFO - 2022-03-13 23:36:58 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:36:58 --> Controller Class Initialized
INFO - 2022-03-13 23:36:58 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:36:58 --> Encrypt Class Initialized
INFO - 2022-03-13 23:36:58 --> Model "Login_model" initialized
INFO - 2022-03-13 23:36:58 --> Model "Dashboard_model" initialized
INFO - 2022-03-13 23:36:58 --> Model "Case_model" initialized
INFO - 2022-03-13 23:36:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:36:58 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-13 23:36:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:36:58 --> Final output sent to browser
DEBUG - 2022-03-13 23:36:58 --> Total execution time: 0.3467
ERROR - 2022-03-13 23:37:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:37:12 --> Config Class Initialized
INFO - 2022-03-13 23:37:12 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:37:12 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:37:12 --> Utf8 Class Initialized
INFO - 2022-03-13 23:37:12 --> URI Class Initialized
INFO - 2022-03-13 23:37:12 --> Router Class Initialized
INFO - 2022-03-13 23:37:12 --> Output Class Initialized
INFO - 2022-03-13 23:37:12 --> Security Class Initialized
DEBUG - 2022-03-13 23:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:37:12 --> Input Class Initialized
INFO - 2022-03-13 23:37:12 --> Language Class Initialized
INFO - 2022-03-13 23:37:12 --> Loader Class Initialized
INFO - 2022-03-13 23:37:12 --> Helper loaded: url_helper
INFO - 2022-03-13 23:37:12 --> Helper loaded: form_helper
INFO - 2022-03-13 23:37:12 --> Helper loaded: common_helper
INFO - 2022-03-13 23:37:12 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:37:12 --> Controller Class Initialized
INFO - 2022-03-13 23:37:12 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:37:12 --> Encrypt Class Initialized
INFO - 2022-03-13 23:37:12 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:37:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:37:12 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:37:12 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:37:12 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:37:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:37:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-13 23:37:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:37:12 --> Final output sent to browser
DEBUG - 2022-03-13 23:37:12 --> Total execution time: 0.0586
ERROR - 2022-03-13 23:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:37:26 --> Config Class Initialized
INFO - 2022-03-13 23:37:26 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:37:26 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:37:26 --> Utf8 Class Initialized
INFO - 2022-03-13 23:37:26 --> URI Class Initialized
INFO - 2022-03-13 23:37:26 --> Router Class Initialized
INFO - 2022-03-13 23:37:26 --> Output Class Initialized
INFO - 2022-03-13 23:37:26 --> Security Class Initialized
DEBUG - 2022-03-13 23:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:37:26 --> Input Class Initialized
INFO - 2022-03-13 23:37:26 --> Language Class Initialized
INFO - 2022-03-13 23:37:26 --> Loader Class Initialized
INFO - 2022-03-13 23:37:26 --> Helper loaded: url_helper
INFO - 2022-03-13 23:37:26 --> Helper loaded: form_helper
INFO - 2022-03-13 23:37:26 --> Helper loaded: common_helper
INFO - 2022-03-13 23:37:26 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:37:26 --> Controller Class Initialized
INFO - 2022-03-13 23:37:26 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:37:26 --> Encrypt Class Initialized
INFO - 2022-03-13 23:37:26 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:37:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:37:26 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:37:26 --> Model "Users_model" initialized
INFO - 2022-03-13 23:37:26 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:37:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:37:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:37:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:37:26 --> Final output sent to browser
DEBUG - 2022-03-13 23:37:26 --> Total execution time: 0.2358
ERROR - 2022-03-13 23:37:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:37:41 --> Config Class Initialized
INFO - 2022-03-13 23:37:41 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:37:41 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:37:41 --> Utf8 Class Initialized
INFO - 2022-03-13 23:37:41 --> URI Class Initialized
INFO - 2022-03-13 23:37:41 --> Router Class Initialized
INFO - 2022-03-13 23:37:41 --> Output Class Initialized
INFO - 2022-03-13 23:37:41 --> Security Class Initialized
DEBUG - 2022-03-13 23:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:37:41 --> Input Class Initialized
INFO - 2022-03-13 23:37:41 --> Language Class Initialized
INFO - 2022-03-13 23:37:41 --> Loader Class Initialized
INFO - 2022-03-13 23:37:41 --> Helper loaded: url_helper
INFO - 2022-03-13 23:37:41 --> Helper loaded: form_helper
INFO - 2022-03-13 23:37:41 --> Helper loaded: common_helper
INFO - 2022-03-13 23:37:41 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:37:41 --> Controller Class Initialized
INFO - 2022-03-13 23:37:41 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:37:41 --> Encrypt Class Initialized
INFO - 2022-03-13 23:37:41 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:37:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:37:41 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:37:41 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:37:41 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:37:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:37:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:37:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:37:41 --> Final output sent to browser
DEBUG - 2022-03-13 23:37:41 --> Total execution time: 0.2197
ERROR - 2022-03-13 23:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:38:00 --> Config Class Initialized
INFO - 2022-03-13 23:38:00 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:38:00 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:38:00 --> Utf8 Class Initialized
INFO - 2022-03-13 23:38:00 --> URI Class Initialized
INFO - 2022-03-13 23:38:00 --> Router Class Initialized
INFO - 2022-03-13 23:38:00 --> Output Class Initialized
INFO - 2022-03-13 23:38:00 --> Security Class Initialized
DEBUG - 2022-03-13 23:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:38:00 --> Input Class Initialized
INFO - 2022-03-13 23:38:00 --> Language Class Initialized
INFO - 2022-03-13 23:38:00 --> Loader Class Initialized
INFO - 2022-03-13 23:38:00 --> Helper loaded: url_helper
INFO - 2022-03-13 23:38:00 --> Helper loaded: form_helper
INFO - 2022-03-13 23:38:00 --> Helper loaded: common_helper
INFO - 2022-03-13 23:38:00 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:38:00 --> Controller Class Initialized
INFO - 2022-03-13 23:38:00 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:38:00 --> Final output sent to browser
DEBUG - 2022-03-13 23:38:00 --> Total execution time: 0.0228
ERROR - 2022-03-13 23:38:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:38:37 --> Config Class Initialized
INFO - 2022-03-13 23:38:37 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:38:37 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:38:37 --> Utf8 Class Initialized
INFO - 2022-03-13 23:38:37 --> URI Class Initialized
INFO - 2022-03-13 23:38:37 --> Router Class Initialized
INFO - 2022-03-13 23:38:37 --> Output Class Initialized
INFO - 2022-03-13 23:38:37 --> Security Class Initialized
DEBUG - 2022-03-13 23:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:38:37 --> Input Class Initialized
INFO - 2022-03-13 23:38:37 --> Language Class Initialized
INFO - 2022-03-13 23:38:37 --> Loader Class Initialized
INFO - 2022-03-13 23:38:37 --> Helper loaded: url_helper
INFO - 2022-03-13 23:38:37 --> Helper loaded: form_helper
INFO - 2022-03-13 23:38:37 --> Helper loaded: common_helper
INFO - 2022-03-13 23:38:37 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:38:37 --> Controller Class Initialized
INFO - 2022-03-13 23:38:37 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:38:37 --> Encrypt Class Initialized
INFO - 2022-03-13 23:38:37 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:38:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:38:37 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:38:37 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:38:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:38:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:38:38 --> Config Class Initialized
INFO - 2022-03-13 23:38:38 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:38:38 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:38:38 --> Utf8 Class Initialized
INFO - 2022-03-13 23:38:38 --> URI Class Initialized
INFO - 2022-03-13 23:38:38 --> Router Class Initialized
INFO - 2022-03-13 23:38:38 --> Output Class Initialized
INFO - 2022-03-13 23:38:38 --> Security Class Initialized
DEBUG - 2022-03-13 23:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:38:38 --> Input Class Initialized
INFO - 2022-03-13 23:38:38 --> Language Class Initialized
INFO - 2022-03-13 23:38:38 --> Loader Class Initialized
INFO - 2022-03-13 23:38:38 --> Helper loaded: url_helper
INFO - 2022-03-13 23:38:38 --> Helper loaded: form_helper
INFO - 2022-03-13 23:38:38 --> Helper loaded: common_helper
INFO - 2022-03-13 23:38:38 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:38:38 --> Controller Class Initialized
INFO - 2022-03-13 23:38:38 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:38:38 --> Encrypt Class Initialized
INFO - 2022-03-13 23:38:38 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:38:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:38:38 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:38:38 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:38:38 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:38:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:38:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:38:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:38:38 --> Final output sent to browser
DEBUG - 2022-03-13 23:38:38 --> Total execution time: 0.0544
ERROR - 2022-03-13 23:38:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:38:39 --> Config Class Initialized
INFO - 2022-03-13 23:38:39 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:38:39 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:38:39 --> Utf8 Class Initialized
INFO - 2022-03-13 23:38:39 --> URI Class Initialized
INFO - 2022-03-13 23:38:39 --> Router Class Initialized
INFO - 2022-03-13 23:38:39 --> Output Class Initialized
INFO - 2022-03-13 23:38:39 --> Security Class Initialized
DEBUG - 2022-03-13 23:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:38:39 --> Input Class Initialized
INFO - 2022-03-13 23:38:39 --> Language Class Initialized
INFO - 2022-03-13 23:38:39 --> Loader Class Initialized
INFO - 2022-03-13 23:38:39 --> Helper loaded: url_helper
INFO - 2022-03-13 23:38:39 --> Helper loaded: form_helper
INFO - 2022-03-13 23:38:39 --> Helper loaded: common_helper
INFO - 2022-03-13 23:38:39 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:38:39 --> Controller Class Initialized
INFO - 2022-03-13 23:38:39 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:38:39 --> Encrypt Class Initialized
INFO - 2022-03-13 23:38:39 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:38:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:38:39 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:38:39 --> Model "Users_model" initialized
INFO - 2022-03-13 23:38:39 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:38:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:38:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:38:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:38:39 --> Final output sent to browser
DEBUG - 2022-03-13 23:38:39 --> Total execution time: 0.0553
ERROR - 2022-03-13 23:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:41:54 --> Config Class Initialized
INFO - 2022-03-13 23:41:54 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:41:54 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:41:54 --> Utf8 Class Initialized
INFO - 2022-03-13 23:41:54 --> URI Class Initialized
INFO - 2022-03-13 23:41:54 --> Router Class Initialized
INFO - 2022-03-13 23:41:54 --> Output Class Initialized
INFO - 2022-03-13 23:41:54 --> Security Class Initialized
DEBUG - 2022-03-13 23:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:41:54 --> Input Class Initialized
INFO - 2022-03-13 23:41:54 --> Language Class Initialized
INFO - 2022-03-13 23:41:54 --> Loader Class Initialized
INFO - 2022-03-13 23:41:54 --> Helper loaded: url_helper
INFO - 2022-03-13 23:41:54 --> Helper loaded: form_helper
INFO - 2022-03-13 23:41:54 --> Helper loaded: common_helper
INFO - 2022-03-13 23:41:55 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:41:55 --> Controller Class Initialized
INFO - 2022-03-13 23:41:55 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:41:55 --> Encrypt Class Initialized
INFO - 2022-03-13 23:41:55 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:41:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:41:55 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:41:55 --> Model "Users_model" initialized
INFO - 2022-03-13 23:41:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:41:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:41:55 --> Config Class Initialized
INFO - 2022-03-13 23:41:55 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:41:55 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:41:55 --> Utf8 Class Initialized
INFO - 2022-03-13 23:41:55 --> URI Class Initialized
INFO - 2022-03-13 23:41:55 --> Router Class Initialized
INFO - 2022-03-13 23:41:55 --> Output Class Initialized
INFO - 2022-03-13 23:41:55 --> Security Class Initialized
DEBUG - 2022-03-13 23:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:41:55 --> Input Class Initialized
INFO - 2022-03-13 23:41:55 --> Language Class Initialized
INFO - 2022-03-13 23:41:55 --> Loader Class Initialized
INFO - 2022-03-13 23:41:55 --> Helper loaded: url_helper
INFO - 2022-03-13 23:41:55 --> Helper loaded: form_helper
INFO - 2022-03-13 23:41:55 --> Helper loaded: common_helper
INFO - 2022-03-13 23:41:55 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:41:55 --> Controller Class Initialized
INFO - 2022-03-13 23:41:55 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:41:55 --> Encrypt Class Initialized
INFO - 2022-03-13 23:41:55 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:41:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:41:55 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:41:55 --> Model "Users_model" initialized
INFO - 2022-03-13 23:41:55 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:41:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:41:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:41:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:41:55 --> Final output sent to browser
DEBUG - 2022-03-13 23:41:55 --> Total execution time: 0.0737
ERROR - 2022-03-13 23:42:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:42:35 --> Config Class Initialized
INFO - 2022-03-13 23:42:35 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:42:35 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:42:35 --> Utf8 Class Initialized
INFO - 2022-03-13 23:42:35 --> URI Class Initialized
INFO - 2022-03-13 23:42:35 --> Router Class Initialized
INFO - 2022-03-13 23:42:35 --> Output Class Initialized
INFO - 2022-03-13 23:42:35 --> Security Class Initialized
DEBUG - 2022-03-13 23:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:42:35 --> Input Class Initialized
INFO - 2022-03-13 23:42:35 --> Language Class Initialized
INFO - 2022-03-13 23:42:35 --> Loader Class Initialized
INFO - 2022-03-13 23:42:35 --> Helper loaded: url_helper
INFO - 2022-03-13 23:42:35 --> Helper loaded: form_helper
INFO - 2022-03-13 23:42:35 --> Helper loaded: common_helper
INFO - 2022-03-13 23:42:35 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:42:35 --> Controller Class Initialized
INFO - 2022-03-13 23:42:35 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:42:35 --> Encrypt Class Initialized
INFO - 2022-03-13 23:42:35 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:42:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:42:35 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:42:35 --> Model "Users_model" initialized
INFO - 2022-03-13 23:42:35 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:42:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:42:37 --> Config Class Initialized
INFO - 2022-03-13 23:42:37 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:42:37 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:42:37 --> Utf8 Class Initialized
INFO - 2022-03-13 23:42:37 --> URI Class Initialized
INFO - 2022-03-13 23:42:37 --> Router Class Initialized
INFO - 2022-03-13 23:42:37 --> Output Class Initialized
INFO - 2022-03-13 23:42:37 --> Security Class Initialized
DEBUG - 2022-03-13 23:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:42:37 --> Input Class Initialized
INFO - 2022-03-13 23:42:37 --> Language Class Initialized
INFO - 2022-03-13 23:42:37 --> Loader Class Initialized
INFO - 2022-03-13 23:42:37 --> Helper loaded: url_helper
INFO - 2022-03-13 23:42:37 --> Helper loaded: form_helper
INFO - 2022-03-13 23:42:37 --> Helper loaded: common_helper
INFO - 2022-03-13 23:42:37 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:42:37 --> Controller Class Initialized
INFO - 2022-03-13 23:42:37 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:42:37 --> Encrypt Class Initialized
INFO - 2022-03-13 23:42:37 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:42:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:42:37 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:42:37 --> Model "Users_model" initialized
INFO - 2022-03-13 23:42:37 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:42:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:42:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:42:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:42:37 --> Final output sent to browser
DEBUG - 2022-03-13 23:42:37 --> Total execution time: 0.0578
ERROR - 2022-03-13 23:43:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:43:01 --> Config Class Initialized
INFO - 2022-03-13 23:43:01 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:43:01 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:43:01 --> Utf8 Class Initialized
INFO - 2022-03-13 23:43:01 --> URI Class Initialized
INFO - 2022-03-13 23:43:01 --> Router Class Initialized
INFO - 2022-03-13 23:43:01 --> Output Class Initialized
INFO - 2022-03-13 23:43:01 --> Security Class Initialized
DEBUG - 2022-03-13 23:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:43:01 --> Input Class Initialized
INFO - 2022-03-13 23:43:01 --> Language Class Initialized
INFO - 2022-03-13 23:43:01 --> Loader Class Initialized
INFO - 2022-03-13 23:43:01 --> Helper loaded: url_helper
INFO - 2022-03-13 23:43:01 --> Helper loaded: form_helper
INFO - 2022-03-13 23:43:01 --> Helper loaded: common_helper
INFO - 2022-03-13 23:43:01 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:43:01 --> Controller Class Initialized
INFO - 2022-03-13 23:43:01 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:43:01 --> Encrypt Class Initialized
INFO - 2022-03-13 23:43:01 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:43:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:43:01 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:43:01 --> Model "Users_model" initialized
INFO - 2022-03-13 23:43:01 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:43:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:43:02 --> Config Class Initialized
INFO - 2022-03-13 23:43:02 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:43:02 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:43:02 --> Utf8 Class Initialized
INFO - 2022-03-13 23:43:02 --> URI Class Initialized
INFO - 2022-03-13 23:43:02 --> Router Class Initialized
INFO - 2022-03-13 23:43:02 --> Output Class Initialized
INFO - 2022-03-13 23:43:02 --> Security Class Initialized
DEBUG - 2022-03-13 23:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:43:02 --> Input Class Initialized
INFO - 2022-03-13 23:43:02 --> Language Class Initialized
INFO - 2022-03-13 23:43:02 --> Loader Class Initialized
INFO - 2022-03-13 23:43:02 --> Helper loaded: url_helper
INFO - 2022-03-13 23:43:02 --> Helper loaded: form_helper
INFO - 2022-03-13 23:43:02 --> Helper loaded: common_helper
INFO - 2022-03-13 23:43:02 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:43:02 --> Controller Class Initialized
INFO - 2022-03-13 23:43:02 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:43:02 --> Encrypt Class Initialized
INFO - 2022-03-13 23:43:02 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:43:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:43:02 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:43:02 --> Model "Users_model" initialized
INFO - 2022-03-13 23:43:02 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:43:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:43:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:43:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:43:02 --> Final output sent to browser
DEBUG - 2022-03-13 23:43:02 --> Total execution time: 0.0634
ERROR - 2022-03-13 23:46:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:46:33 --> Config Class Initialized
INFO - 2022-03-13 23:46:33 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:46:33 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:46:33 --> Utf8 Class Initialized
INFO - 2022-03-13 23:46:33 --> URI Class Initialized
INFO - 2022-03-13 23:46:33 --> Router Class Initialized
INFO - 2022-03-13 23:46:33 --> Output Class Initialized
INFO - 2022-03-13 23:46:33 --> Security Class Initialized
DEBUG - 2022-03-13 23:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:46:33 --> Input Class Initialized
INFO - 2022-03-13 23:46:33 --> Language Class Initialized
INFO - 2022-03-13 23:46:33 --> Loader Class Initialized
INFO - 2022-03-13 23:46:33 --> Helper loaded: url_helper
INFO - 2022-03-13 23:46:33 --> Helper loaded: form_helper
INFO - 2022-03-13 23:46:33 --> Helper loaded: common_helper
INFO - 2022-03-13 23:46:33 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:46:33 --> Controller Class Initialized
INFO - 2022-03-13 23:46:33 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:46:33 --> Encrypt Class Initialized
INFO - 2022-03-13 23:46:33 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:46:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:46:33 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:46:33 --> Model "Users_model" initialized
INFO - 2022-03-13 23:46:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:46:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:46:34 --> Config Class Initialized
INFO - 2022-03-13 23:46:34 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:46:34 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:46:34 --> Utf8 Class Initialized
INFO - 2022-03-13 23:46:34 --> URI Class Initialized
INFO - 2022-03-13 23:46:34 --> Router Class Initialized
INFO - 2022-03-13 23:46:34 --> Output Class Initialized
INFO - 2022-03-13 23:46:34 --> Security Class Initialized
DEBUG - 2022-03-13 23:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:46:34 --> Input Class Initialized
INFO - 2022-03-13 23:46:34 --> Language Class Initialized
INFO - 2022-03-13 23:46:34 --> Loader Class Initialized
INFO - 2022-03-13 23:46:34 --> Helper loaded: url_helper
INFO - 2022-03-13 23:46:34 --> Helper loaded: form_helper
INFO - 2022-03-13 23:46:34 --> Helper loaded: common_helper
INFO - 2022-03-13 23:46:34 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:46:34 --> Controller Class Initialized
INFO - 2022-03-13 23:46:34 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:46:34 --> Encrypt Class Initialized
INFO - 2022-03-13 23:46:34 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:46:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:46:34 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:46:34 --> Model "Users_model" initialized
INFO - 2022-03-13 23:46:34 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:46:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:46:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:46:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:46:34 --> Final output sent to browser
DEBUG - 2022-03-13 23:46:34 --> Total execution time: 0.0670
ERROR - 2022-03-13 23:46:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:46:41 --> Config Class Initialized
INFO - 2022-03-13 23:46:41 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:46:41 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:46:41 --> Utf8 Class Initialized
INFO - 2022-03-13 23:46:41 --> URI Class Initialized
INFO - 2022-03-13 23:46:41 --> Router Class Initialized
INFO - 2022-03-13 23:46:41 --> Output Class Initialized
INFO - 2022-03-13 23:46:41 --> Security Class Initialized
DEBUG - 2022-03-13 23:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:46:41 --> Input Class Initialized
INFO - 2022-03-13 23:46:41 --> Language Class Initialized
INFO - 2022-03-13 23:46:41 --> Loader Class Initialized
INFO - 2022-03-13 23:46:41 --> Helper loaded: url_helper
INFO - 2022-03-13 23:46:41 --> Helper loaded: form_helper
INFO - 2022-03-13 23:46:41 --> Helper loaded: common_helper
INFO - 2022-03-13 23:46:41 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:46:41 --> Controller Class Initialized
INFO - 2022-03-13 23:46:41 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:46:41 --> Encrypt Class Initialized
INFO - 2022-03-13 23:46:41 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:46:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:46:41 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:46:41 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:46:41 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:46:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:46:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:46:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:46:41 --> Final output sent to browser
DEBUG - 2022-03-13 23:46:41 --> Total execution time: 0.0410
ERROR - 2022-03-13 23:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:47:07 --> Config Class Initialized
INFO - 2022-03-13 23:47:07 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:47:07 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:47:07 --> Utf8 Class Initialized
INFO - 2022-03-13 23:47:07 --> URI Class Initialized
INFO - 2022-03-13 23:47:07 --> Router Class Initialized
INFO - 2022-03-13 23:47:07 --> Output Class Initialized
INFO - 2022-03-13 23:47:07 --> Security Class Initialized
DEBUG - 2022-03-13 23:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:47:07 --> Input Class Initialized
INFO - 2022-03-13 23:47:07 --> Language Class Initialized
INFO - 2022-03-13 23:47:07 --> Loader Class Initialized
INFO - 2022-03-13 23:47:07 --> Helper loaded: url_helper
INFO - 2022-03-13 23:47:07 --> Helper loaded: form_helper
INFO - 2022-03-13 23:47:07 --> Helper loaded: common_helper
INFO - 2022-03-13 23:47:07 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:47:07 --> Controller Class Initialized
INFO - 2022-03-13 23:47:07 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:47:07 --> Encrypt Class Initialized
INFO - 2022-03-13 23:47:07 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:47:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:47:07 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:47:07 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:47:07 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:47:07 --> Config Class Initialized
INFO - 2022-03-13 23:47:07 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:47:07 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:47:07 --> Utf8 Class Initialized
INFO - 2022-03-13 23:47:07 --> URI Class Initialized
INFO - 2022-03-13 23:47:07 --> Router Class Initialized
INFO - 2022-03-13 23:47:08 --> Output Class Initialized
INFO - 2022-03-13 23:47:08 --> Security Class Initialized
DEBUG - 2022-03-13 23:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:47:08 --> Input Class Initialized
INFO - 2022-03-13 23:47:08 --> Language Class Initialized
INFO - 2022-03-13 23:47:08 --> Loader Class Initialized
INFO - 2022-03-13 23:47:08 --> Helper loaded: url_helper
INFO - 2022-03-13 23:47:08 --> Helper loaded: form_helper
INFO - 2022-03-13 23:47:08 --> Helper loaded: common_helper
INFO - 2022-03-13 23:47:08 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:47:08 --> Controller Class Initialized
INFO - 2022-03-13 23:47:08 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:47:08 --> Encrypt Class Initialized
INFO - 2022-03-13 23:47:08 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:47:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:47:08 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:47:08 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:47:08 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:47:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:47:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:47:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:47:08 --> Final output sent to browser
DEBUG - 2022-03-13 23:47:08 --> Total execution time: 0.0433
ERROR - 2022-03-13 23:47:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:47:09 --> Config Class Initialized
INFO - 2022-03-13 23:47:09 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:47:09 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:47:09 --> Utf8 Class Initialized
INFO - 2022-03-13 23:47:09 --> URI Class Initialized
INFO - 2022-03-13 23:47:09 --> Router Class Initialized
INFO - 2022-03-13 23:47:09 --> Output Class Initialized
INFO - 2022-03-13 23:47:09 --> Security Class Initialized
DEBUG - 2022-03-13 23:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:47:09 --> Input Class Initialized
INFO - 2022-03-13 23:47:09 --> Language Class Initialized
INFO - 2022-03-13 23:47:09 --> Loader Class Initialized
INFO - 2022-03-13 23:47:09 --> Helper loaded: url_helper
INFO - 2022-03-13 23:47:09 --> Helper loaded: form_helper
INFO - 2022-03-13 23:47:09 --> Helper loaded: common_helper
INFO - 2022-03-13 23:47:09 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:47:09 --> Controller Class Initialized
INFO - 2022-03-13 23:47:09 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:47:09 --> Encrypt Class Initialized
INFO - 2022-03-13 23:47:09 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:47:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:47:09 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:47:09 --> Model "Users_model" initialized
INFO - 2022-03-13 23:47:09 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:47:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:47:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:47:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:47:09 --> Final output sent to browser
DEBUG - 2022-03-13 23:47:09 --> Total execution time: 0.0889
ERROR - 2022-03-13 23:47:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:47:17 --> Config Class Initialized
INFO - 2022-03-13 23:47:17 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:47:17 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:47:17 --> Utf8 Class Initialized
INFO - 2022-03-13 23:47:17 --> URI Class Initialized
INFO - 2022-03-13 23:47:17 --> Router Class Initialized
INFO - 2022-03-13 23:47:17 --> Output Class Initialized
INFO - 2022-03-13 23:47:17 --> Security Class Initialized
DEBUG - 2022-03-13 23:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:47:17 --> Input Class Initialized
INFO - 2022-03-13 23:47:17 --> Language Class Initialized
INFO - 2022-03-13 23:47:17 --> Loader Class Initialized
INFO - 2022-03-13 23:47:17 --> Helper loaded: url_helper
INFO - 2022-03-13 23:47:17 --> Helper loaded: form_helper
INFO - 2022-03-13 23:47:17 --> Helper loaded: common_helper
INFO - 2022-03-13 23:47:17 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:47:17 --> Controller Class Initialized
INFO - 2022-03-13 23:47:17 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:47:17 --> Encrypt Class Initialized
INFO - 2022-03-13 23:47:17 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:47:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:47:17 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:47:17 --> Model "Users_model" initialized
INFO - 2022-03-13 23:47:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:47:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:47:17 --> Config Class Initialized
INFO - 2022-03-13 23:47:17 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:47:17 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:47:17 --> Utf8 Class Initialized
INFO - 2022-03-13 23:47:17 --> URI Class Initialized
INFO - 2022-03-13 23:47:17 --> Router Class Initialized
INFO - 2022-03-13 23:47:17 --> Output Class Initialized
INFO - 2022-03-13 23:47:17 --> Security Class Initialized
DEBUG - 2022-03-13 23:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:47:17 --> Input Class Initialized
INFO - 2022-03-13 23:47:17 --> Language Class Initialized
INFO - 2022-03-13 23:47:17 --> Loader Class Initialized
INFO - 2022-03-13 23:47:17 --> Helper loaded: url_helper
INFO - 2022-03-13 23:47:17 --> Helper loaded: form_helper
INFO - 2022-03-13 23:47:17 --> Helper loaded: common_helper
INFO - 2022-03-13 23:47:17 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:47:17 --> Controller Class Initialized
INFO - 2022-03-13 23:47:17 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:47:17 --> Encrypt Class Initialized
INFO - 2022-03-13 23:47:17 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:47:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:47:17 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:47:17 --> Model "Users_model" initialized
INFO - 2022-03-13 23:47:17 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:47:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:47:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:47:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:47:18 --> Final output sent to browser
DEBUG - 2022-03-13 23:47:18 --> Total execution time: 0.0742
ERROR - 2022-03-13 23:47:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:47:21 --> Config Class Initialized
INFO - 2022-03-13 23:47:21 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:47:21 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:47:21 --> Utf8 Class Initialized
INFO - 2022-03-13 23:47:21 --> URI Class Initialized
INFO - 2022-03-13 23:47:21 --> Router Class Initialized
INFO - 2022-03-13 23:47:21 --> Output Class Initialized
INFO - 2022-03-13 23:47:21 --> Security Class Initialized
DEBUG - 2022-03-13 23:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:47:21 --> Input Class Initialized
INFO - 2022-03-13 23:47:21 --> Language Class Initialized
INFO - 2022-03-13 23:47:21 --> Loader Class Initialized
INFO - 2022-03-13 23:47:21 --> Helper loaded: url_helper
INFO - 2022-03-13 23:47:21 --> Helper loaded: form_helper
INFO - 2022-03-13 23:47:21 --> Helper loaded: common_helper
INFO - 2022-03-13 23:47:21 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:47:21 --> Controller Class Initialized
INFO - 2022-03-13 23:47:21 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:47:21 --> Encrypt Class Initialized
INFO - 2022-03-13 23:47:21 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:47:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:47:21 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:47:21 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:47:21 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:47:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:47:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:47:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:47:21 --> Final output sent to browser
DEBUG - 2022-03-13 23:47:21 --> Total execution time: 0.0710
ERROR - 2022-03-13 23:48:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:48:51 --> Config Class Initialized
INFO - 2022-03-13 23:48:51 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:48:51 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:48:51 --> Utf8 Class Initialized
INFO - 2022-03-13 23:48:51 --> URI Class Initialized
INFO - 2022-03-13 23:48:51 --> Router Class Initialized
INFO - 2022-03-13 23:48:51 --> Output Class Initialized
INFO - 2022-03-13 23:48:51 --> Security Class Initialized
DEBUG - 2022-03-13 23:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:48:51 --> Input Class Initialized
INFO - 2022-03-13 23:48:51 --> Language Class Initialized
INFO - 2022-03-13 23:48:51 --> Loader Class Initialized
INFO - 2022-03-13 23:48:51 --> Helper loaded: url_helper
INFO - 2022-03-13 23:48:51 --> Helper loaded: form_helper
INFO - 2022-03-13 23:48:51 --> Helper loaded: common_helper
INFO - 2022-03-13 23:48:51 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:48:51 --> Controller Class Initialized
INFO - 2022-03-13 23:48:51 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:48:51 --> Encrypt Class Initialized
INFO - 2022-03-13 23:48:51 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:48:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:48:51 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:48:51 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:48:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:48:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:48:51 --> Config Class Initialized
INFO - 2022-03-13 23:48:51 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:48:51 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:48:51 --> Utf8 Class Initialized
INFO - 2022-03-13 23:48:51 --> URI Class Initialized
INFO - 2022-03-13 23:48:51 --> Router Class Initialized
INFO - 2022-03-13 23:48:51 --> Output Class Initialized
INFO - 2022-03-13 23:48:51 --> Security Class Initialized
DEBUG - 2022-03-13 23:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:48:51 --> Input Class Initialized
INFO - 2022-03-13 23:48:51 --> Language Class Initialized
INFO - 2022-03-13 23:48:51 --> Loader Class Initialized
INFO - 2022-03-13 23:48:51 --> Helper loaded: url_helper
INFO - 2022-03-13 23:48:51 --> Helper loaded: form_helper
INFO - 2022-03-13 23:48:51 --> Helper loaded: common_helper
INFO - 2022-03-13 23:48:51 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:48:51 --> Controller Class Initialized
INFO - 2022-03-13 23:48:51 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:48:51 --> Encrypt Class Initialized
INFO - 2022-03-13 23:48:51 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:48:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:48:52 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:48:52 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:48:52 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:48:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:48:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:48:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:48:52 --> Final output sent to browser
DEBUG - 2022-03-13 23:48:52 --> Total execution time: 0.1572
ERROR - 2022-03-13 23:48:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:48:53 --> Config Class Initialized
INFO - 2022-03-13 23:48:53 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:48:53 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:48:53 --> Utf8 Class Initialized
INFO - 2022-03-13 23:48:53 --> URI Class Initialized
INFO - 2022-03-13 23:48:53 --> Router Class Initialized
INFO - 2022-03-13 23:48:53 --> Output Class Initialized
INFO - 2022-03-13 23:48:53 --> Security Class Initialized
DEBUG - 2022-03-13 23:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:48:53 --> Input Class Initialized
INFO - 2022-03-13 23:48:53 --> Language Class Initialized
INFO - 2022-03-13 23:48:53 --> Loader Class Initialized
INFO - 2022-03-13 23:48:53 --> Helper loaded: url_helper
INFO - 2022-03-13 23:48:53 --> Helper loaded: form_helper
INFO - 2022-03-13 23:48:53 --> Helper loaded: common_helper
INFO - 2022-03-13 23:48:53 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:48:53 --> Controller Class Initialized
INFO - 2022-03-13 23:48:53 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:48:53 --> Encrypt Class Initialized
INFO - 2022-03-13 23:48:53 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:48:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:48:53 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:48:53 --> Model "Users_model" initialized
INFO - 2022-03-13 23:48:53 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:48:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:48:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:48:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:48:53 --> Final output sent to browser
DEBUG - 2022-03-13 23:48:53 --> Total execution time: 0.0996
ERROR - 2022-03-13 23:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:49:02 --> Config Class Initialized
INFO - 2022-03-13 23:49:02 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:49:02 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:49:02 --> Utf8 Class Initialized
INFO - 2022-03-13 23:49:02 --> URI Class Initialized
INFO - 2022-03-13 23:49:02 --> Router Class Initialized
INFO - 2022-03-13 23:49:02 --> Output Class Initialized
INFO - 2022-03-13 23:49:02 --> Security Class Initialized
DEBUG - 2022-03-13 23:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:49:02 --> Input Class Initialized
INFO - 2022-03-13 23:49:02 --> Language Class Initialized
INFO - 2022-03-13 23:49:02 --> Loader Class Initialized
INFO - 2022-03-13 23:49:02 --> Helper loaded: url_helper
INFO - 2022-03-13 23:49:02 --> Helper loaded: form_helper
INFO - 2022-03-13 23:49:02 --> Helper loaded: common_helper
INFO - 2022-03-13 23:49:02 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:49:02 --> Controller Class Initialized
INFO - 2022-03-13 23:49:02 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:49:02 --> Encrypt Class Initialized
INFO - 2022-03-13 23:49:02 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:49:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:49:02 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:49:02 --> Model "Users_model" initialized
INFO - 2022-03-13 23:49:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:49:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:49:03 --> Config Class Initialized
INFO - 2022-03-13 23:49:03 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:49:03 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:49:03 --> Utf8 Class Initialized
INFO - 2022-03-13 23:49:03 --> URI Class Initialized
INFO - 2022-03-13 23:49:03 --> Router Class Initialized
INFO - 2022-03-13 23:49:03 --> Output Class Initialized
INFO - 2022-03-13 23:49:03 --> Security Class Initialized
DEBUG - 2022-03-13 23:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:49:03 --> Input Class Initialized
INFO - 2022-03-13 23:49:03 --> Language Class Initialized
INFO - 2022-03-13 23:49:03 --> Loader Class Initialized
INFO - 2022-03-13 23:49:03 --> Helper loaded: url_helper
INFO - 2022-03-13 23:49:03 --> Helper loaded: form_helper
INFO - 2022-03-13 23:49:03 --> Helper loaded: common_helper
INFO - 2022-03-13 23:49:03 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:49:03 --> Controller Class Initialized
INFO - 2022-03-13 23:49:03 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:49:03 --> Encrypt Class Initialized
INFO - 2022-03-13 23:49:03 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:49:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:49:03 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:49:03 --> Model "Users_model" initialized
INFO - 2022-03-13 23:49:03 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:49:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:49:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:49:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:49:03 --> Final output sent to browser
DEBUG - 2022-03-13 23:49:03 --> Total execution time: 0.0535
ERROR - 2022-03-13 23:49:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:49:06 --> Config Class Initialized
INFO - 2022-03-13 23:49:06 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:49:06 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:49:06 --> Utf8 Class Initialized
INFO - 2022-03-13 23:49:06 --> URI Class Initialized
INFO - 2022-03-13 23:49:06 --> Router Class Initialized
INFO - 2022-03-13 23:49:06 --> Output Class Initialized
INFO - 2022-03-13 23:49:06 --> Security Class Initialized
DEBUG - 2022-03-13 23:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:49:06 --> Input Class Initialized
INFO - 2022-03-13 23:49:06 --> Language Class Initialized
INFO - 2022-03-13 23:49:06 --> Loader Class Initialized
INFO - 2022-03-13 23:49:06 --> Helper loaded: url_helper
INFO - 2022-03-13 23:49:06 --> Helper loaded: form_helper
INFO - 2022-03-13 23:49:06 --> Helper loaded: common_helper
INFO - 2022-03-13 23:49:06 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:49:06 --> Controller Class Initialized
INFO - 2022-03-13 23:49:06 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:49:06 --> Encrypt Class Initialized
INFO - 2022-03-13 23:49:06 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:49:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:49:06 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:49:06 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:49:06 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:49:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:49:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:49:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:49:06 --> Final output sent to browser
DEBUG - 2022-03-13 23:49:06 --> Total execution time: 0.0404
ERROR - 2022-03-13 23:49:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:49:58 --> Config Class Initialized
INFO - 2022-03-13 23:49:58 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:49:58 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:49:58 --> Utf8 Class Initialized
INFO - 2022-03-13 23:49:58 --> URI Class Initialized
INFO - 2022-03-13 23:49:58 --> Router Class Initialized
INFO - 2022-03-13 23:49:58 --> Output Class Initialized
INFO - 2022-03-13 23:49:58 --> Security Class Initialized
DEBUG - 2022-03-13 23:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:49:58 --> Input Class Initialized
INFO - 2022-03-13 23:49:58 --> Language Class Initialized
INFO - 2022-03-13 23:49:58 --> Loader Class Initialized
INFO - 2022-03-13 23:49:58 --> Helper loaded: url_helper
INFO - 2022-03-13 23:49:58 --> Helper loaded: form_helper
INFO - 2022-03-13 23:49:58 --> Helper loaded: common_helper
INFO - 2022-03-13 23:49:58 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:49:58 --> Controller Class Initialized
INFO - 2022-03-13 23:49:58 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:49:58 --> Encrypt Class Initialized
INFO - 2022-03-13 23:49:58 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:49:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:49:58 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:49:58 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:49:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:49:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:49:58 --> Config Class Initialized
INFO - 2022-03-13 23:49:58 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:49:58 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:49:58 --> Utf8 Class Initialized
INFO - 2022-03-13 23:49:58 --> URI Class Initialized
INFO - 2022-03-13 23:49:58 --> Router Class Initialized
INFO - 2022-03-13 23:49:58 --> Output Class Initialized
INFO - 2022-03-13 23:49:58 --> Security Class Initialized
DEBUG - 2022-03-13 23:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:49:58 --> Input Class Initialized
INFO - 2022-03-13 23:49:58 --> Language Class Initialized
INFO - 2022-03-13 23:49:58 --> Loader Class Initialized
INFO - 2022-03-13 23:49:58 --> Helper loaded: url_helper
INFO - 2022-03-13 23:49:58 --> Helper loaded: form_helper
INFO - 2022-03-13 23:49:58 --> Helper loaded: common_helper
INFO - 2022-03-13 23:49:58 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:49:58 --> Controller Class Initialized
INFO - 2022-03-13 23:49:58 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:49:58 --> Encrypt Class Initialized
INFO - 2022-03-13 23:49:58 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:49:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:49:58 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:49:58 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:49:58 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:49:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:49:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:49:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:49:58 --> Final output sent to browser
DEBUG - 2022-03-13 23:49:58 --> Total execution time: 0.0593
ERROR - 2022-03-13 23:49:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:49:59 --> Config Class Initialized
INFO - 2022-03-13 23:49:59 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:49:59 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:49:59 --> Utf8 Class Initialized
INFO - 2022-03-13 23:49:59 --> URI Class Initialized
INFO - 2022-03-13 23:49:59 --> Router Class Initialized
INFO - 2022-03-13 23:49:59 --> Output Class Initialized
INFO - 2022-03-13 23:49:59 --> Security Class Initialized
DEBUG - 2022-03-13 23:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:49:59 --> Input Class Initialized
INFO - 2022-03-13 23:49:59 --> Language Class Initialized
INFO - 2022-03-13 23:49:59 --> Loader Class Initialized
INFO - 2022-03-13 23:49:59 --> Helper loaded: url_helper
INFO - 2022-03-13 23:49:59 --> Helper loaded: form_helper
INFO - 2022-03-13 23:49:59 --> Helper loaded: common_helper
INFO - 2022-03-13 23:49:59 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:49:59 --> Controller Class Initialized
INFO - 2022-03-13 23:49:59 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:49:59 --> Encrypt Class Initialized
INFO - 2022-03-13 23:49:59 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:49:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:49:59 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:49:59 --> Model "Users_model" initialized
INFO - 2022-03-13 23:49:59 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:49:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:49:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:49:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:49:59 --> Final output sent to browser
DEBUG - 2022-03-13 23:49:59 --> Total execution time: 0.0531
ERROR - 2022-03-13 23:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:50:09 --> Config Class Initialized
INFO - 2022-03-13 23:50:09 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:50:09 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:50:09 --> Utf8 Class Initialized
INFO - 2022-03-13 23:50:09 --> URI Class Initialized
INFO - 2022-03-13 23:50:09 --> Router Class Initialized
INFO - 2022-03-13 23:50:09 --> Output Class Initialized
INFO - 2022-03-13 23:50:09 --> Security Class Initialized
DEBUG - 2022-03-13 23:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:50:09 --> Input Class Initialized
INFO - 2022-03-13 23:50:09 --> Language Class Initialized
INFO - 2022-03-13 23:50:09 --> Loader Class Initialized
INFO - 2022-03-13 23:50:09 --> Helper loaded: url_helper
INFO - 2022-03-13 23:50:09 --> Helper loaded: form_helper
INFO - 2022-03-13 23:50:09 --> Helper loaded: common_helper
INFO - 2022-03-13 23:50:09 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:50:09 --> Controller Class Initialized
INFO - 2022-03-13 23:50:09 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:50:09 --> Encrypt Class Initialized
INFO - 2022-03-13 23:50:09 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:50:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:50:09 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:50:09 --> Model "Users_model" initialized
INFO - 2022-03-13 23:50:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:50:09 --> Config Class Initialized
INFO - 2022-03-13 23:50:09 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:50:09 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:50:09 --> Utf8 Class Initialized
INFO - 2022-03-13 23:50:09 --> URI Class Initialized
INFO - 2022-03-13 23:50:09 --> Router Class Initialized
INFO - 2022-03-13 23:50:09 --> Output Class Initialized
INFO - 2022-03-13 23:50:09 --> Security Class Initialized
DEBUG - 2022-03-13 23:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:50:09 --> Input Class Initialized
INFO - 2022-03-13 23:50:09 --> Language Class Initialized
INFO - 2022-03-13 23:50:09 --> Loader Class Initialized
INFO - 2022-03-13 23:50:09 --> Helper loaded: url_helper
INFO - 2022-03-13 23:50:09 --> Helper loaded: form_helper
INFO - 2022-03-13 23:50:09 --> Helper loaded: common_helper
INFO - 2022-03-13 23:50:09 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:50:09 --> Controller Class Initialized
INFO - 2022-03-13 23:50:09 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:50:09 --> Encrypt Class Initialized
INFO - 2022-03-13 23:50:09 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:50:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:50:09 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:50:09 --> Model "Users_model" initialized
INFO - 2022-03-13 23:50:09 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:50:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:50:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:50:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:50:09 --> Final output sent to browser
DEBUG - 2022-03-13 23:50:09 --> Total execution time: 0.0622
ERROR - 2022-03-13 23:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:50:36 --> Config Class Initialized
INFO - 2022-03-13 23:50:36 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:50:36 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:50:36 --> Utf8 Class Initialized
INFO - 2022-03-13 23:50:36 --> URI Class Initialized
INFO - 2022-03-13 23:50:36 --> Router Class Initialized
INFO - 2022-03-13 23:50:36 --> Output Class Initialized
INFO - 2022-03-13 23:50:36 --> Security Class Initialized
DEBUG - 2022-03-13 23:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:50:36 --> Input Class Initialized
INFO - 2022-03-13 23:50:36 --> Language Class Initialized
INFO - 2022-03-13 23:50:36 --> Loader Class Initialized
INFO - 2022-03-13 23:50:36 --> Helper loaded: url_helper
INFO - 2022-03-13 23:50:36 --> Helper loaded: form_helper
INFO - 2022-03-13 23:50:36 --> Helper loaded: common_helper
INFO - 2022-03-13 23:50:36 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:50:36 --> Controller Class Initialized
INFO - 2022-03-13 23:50:36 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:50:36 --> Encrypt Class Initialized
INFO - 2022-03-13 23:50:36 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:50:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:50:36 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:50:36 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:50:36 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:50:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:50:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:50:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:50:36 --> Final output sent to browser
DEBUG - 2022-03-13 23:50:36 --> Total execution time: 0.0440
ERROR - 2022-03-13 23:51:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:51:34 --> Config Class Initialized
INFO - 2022-03-13 23:51:34 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:51:34 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:51:34 --> Utf8 Class Initialized
INFO - 2022-03-13 23:51:34 --> URI Class Initialized
INFO - 2022-03-13 23:51:34 --> Router Class Initialized
INFO - 2022-03-13 23:51:34 --> Output Class Initialized
INFO - 2022-03-13 23:51:34 --> Security Class Initialized
DEBUG - 2022-03-13 23:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:51:34 --> Input Class Initialized
INFO - 2022-03-13 23:51:34 --> Language Class Initialized
INFO - 2022-03-13 23:51:34 --> Loader Class Initialized
INFO - 2022-03-13 23:51:34 --> Helper loaded: url_helper
INFO - 2022-03-13 23:51:34 --> Helper loaded: form_helper
INFO - 2022-03-13 23:51:34 --> Helper loaded: common_helper
INFO - 2022-03-13 23:51:34 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:51:34 --> Controller Class Initialized
INFO - 2022-03-13 23:51:34 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:51:34 --> Encrypt Class Initialized
INFO - 2022-03-13 23:51:34 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:51:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:51:34 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:51:34 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:51:34 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:51:34 --> Upload Class Initialized
INFO - 2022-03-13 23:51:34 --> Final output sent to browser
DEBUG - 2022-03-13 23:51:34 --> Total execution time: 0.0479
ERROR - 2022-03-13 23:51:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:51:54 --> Config Class Initialized
INFO - 2022-03-13 23:51:54 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:51:54 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:51:54 --> Utf8 Class Initialized
INFO - 2022-03-13 23:51:54 --> URI Class Initialized
INFO - 2022-03-13 23:51:54 --> Router Class Initialized
INFO - 2022-03-13 23:51:54 --> Output Class Initialized
INFO - 2022-03-13 23:51:54 --> Security Class Initialized
DEBUG - 2022-03-13 23:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:51:54 --> Input Class Initialized
INFO - 2022-03-13 23:51:54 --> Language Class Initialized
INFO - 2022-03-13 23:51:54 --> Loader Class Initialized
INFO - 2022-03-13 23:51:54 --> Helper loaded: url_helper
INFO - 2022-03-13 23:51:54 --> Helper loaded: form_helper
INFO - 2022-03-13 23:51:54 --> Helper loaded: common_helper
INFO - 2022-03-13 23:51:54 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:51:54 --> Controller Class Initialized
INFO - 2022-03-13 23:51:54 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:51:54 --> Encrypt Class Initialized
INFO - 2022-03-13 23:51:54 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:51:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:51:54 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:51:54 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:51:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:51:55 --> Config Class Initialized
INFO - 2022-03-13 23:51:55 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:51:55 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:51:55 --> Utf8 Class Initialized
INFO - 2022-03-13 23:51:55 --> URI Class Initialized
INFO - 2022-03-13 23:51:55 --> Router Class Initialized
INFO - 2022-03-13 23:51:55 --> Output Class Initialized
INFO - 2022-03-13 23:51:55 --> Security Class Initialized
DEBUG - 2022-03-13 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:51:55 --> Input Class Initialized
INFO - 2022-03-13 23:51:55 --> Language Class Initialized
INFO - 2022-03-13 23:51:55 --> Loader Class Initialized
INFO - 2022-03-13 23:51:55 --> Helper loaded: url_helper
INFO - 2022-03-13 23:51:55 --> Helper loaded: form_helper
INFO - 2022-03-13 23:51:55 --> Helper loaded: common_helper
INFO - 2022-03-13 23:51:55 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:51:55 --> Controller Class Initialized
INFO - 2022-03-13 23:51:55 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:51:55 --> Encrypt Class Initialized
INFO - 2022-03-13 23:51:55 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:51:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:51:55 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:51:55 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:51:55 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:51:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:51:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:51:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:51:55 --> Final output sent to browser
DEBUG - 2022-03-13 23:51:55 --> Total execution time: 0.0419
ERROR - 2022-03-13 23:51:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:51:56 --> Config Class Initialized
INFO - 2022-03-13 23:51:56 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:51:56 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:51:56 --> Utf8 Class Initialized
INFO - 2022-03-13 23:51:56 --> URI Class Initialized
INFO - 2022-03-13 23:51:56 --> Router Class Initialized
INFO - 2022-03-13 23:51:56 --> Output Class Initialized
INFO - 2022-03-13 23:51:56 --> Security Class Initialized
DEBUG - 2022-03-13 23:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:51:56 --> Input Class Initialized
INFO - 2022-03-13 23:51:56 --> Language Class Initialized
INFO - 2022-03-13 23:51:56 --> Loader Class Initialized
INFO - 2022-03-13 23:51:56 --> Helper loaded: url_helper
INFO - 2022-03-13 23:51:56 --> Helper loaded: form_helper
INFO - 2022-03-13 23:51:56 --> Helper loaded: common_helper
INFO - 2022-03-13 23:51:56 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:51:56 --> Controller Class Initialized
INFO - 2022-03-13 23:51:56 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:51:56 --> Encrypt Class Initialized
INFO - 2022-03-13 23:51:56 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:51:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:51:56 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:51:56 --> Model "Users_model" initialized
INFO - 2022-03-13 23:51:56 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:51:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:51:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:51:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:51:56 --> Final output sent to browser
DEBUG - 2022-03-13 23:51:56 --> Total execution time: 0.0587
ERROR - 2022-03-13 23:52:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:52:11 --> Config Class Initialized
INFO - 2022-03-13 23:52:11 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:52:11 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:52:11 --> Utf8 Class Initialized
INFO - 2022-03-13 23:52:11 --> URI Class Initialized
INFO - 2022-03-13 23:52:11 --> Router Class Initialized
INFO - 2022-03-13 23:52:11 --> Output Class Initialized
INFO - 2022-03-13 23:52:11 --> Security Class Initialized
DEBUG - 2022-03-13 23:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:52:11 --> Input Class Initialized
INFO - 2022-03-13 23:52:11 --> Language Class Initialized
INFO - 2022-03-13 23:52:11 --> Loader Class Initialized
INFO - 2022-03-13 23:52:11 --> Helper loaded: url_helper
INFO - 2022-03-13 23:52:11 --> Helper loaded: form_helper
INFO - 2022-03-13 23:52:11 --> Helper loaded: common_helper
INFO - 2022-03-13 23:52:11 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:52:11 --> Controller Class Initialized
INFO - 2022-03-13 23:52:11 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:52:11 --> Encrypt Class Initialized
INFO - 2022-03-13 23:52:11 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:52:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:52:11 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:52:11 --> Model "Users_model" initialized
INFO - 2022-03-13 23:52:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:52:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:52:11 --> Config Class Initialized
INFO - 2022-03-13 23:52:11 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:52:11 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:52:11 --> Utf8 Class Initialized
INFO - 2022-03-13 23:52:11 --> URI Class Initialized
INFO - 2022-03-13 23:52:11 --> Router Class Initialized
INFO - 2022-03-13 23:52:11 --> Output Class Initialized
INFO - 2022-03-13 23:52:11 --> Security Class Initialized
DEBUG - 2022-03-13 23:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:52:11 --> Input Class Initialized
INFO - 2022-03-13 23:52:11 --> Language Class Initialized
INFO - 2022-03-13 23:52:11 --> Loader Class Initialized
INFO - 2022-03-13 23:52:11 --> Helper loaded: url_helper
INFO - 2022-03-13 23:52:11 --> Helper loaded: form_helper
INFO - 2022-03-13 23:52:11 --> Helper loaded: common_helper
INFO - 2022-03-13 23:52:11 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:52:11 --> Controller Class Initialized
INFO - 2022-03-13 23:52:11 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:52:11 --> Encrypt Class Initialized
INFO - 2022-03-13 23:52:11 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:52:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:52:11 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:52:11 --> Model "Users_model" initialized
INFO - 2022-03-13 23:52:11 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:52:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:52:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:52:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:52:11 --> Final output sent to browser
DEBUG - 2022-03-13 23:52:11 --> Total execution time: 0.0605
ERROR - 2022-03-13 23:52:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:52:19 --> Config Class Initialized
INFO - 2022-03-13 23:52:19 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:52:19 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:52:19 --> Utf8 Class Initialized
INFO - 2022-03-13 23:52:19 --> URI Class Initialized
INFO - 2022-03-13 23:52:19 --> Router Class Initialized
INFO - 2022-03-13 23:52:19 --> Output Class Initialized
INFO - 2022-03-13 23:52:19 --> Security Class Initialized
DEBUG - 2022-03-13 23:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:52:19 --> Input Class Initialized
INFO - 2022-03-13 23:52:19 --> Language Class Initialized
INFO - 2022-03-13 23:52:19 --> Loader Class Initialized
INFO - 2022-03-13 23:52:19 --> Helper loaded: url_helper
INFO - 2022-03-13 23:52:19 --> Helper loaded: form_helper
INFO - 2022-03-13 23:52:19 --> Helper loaded: common_helper
INFO - 2022-03-13 23:52:19 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:52:19 --> Controller Class Initialized
INFO - 2022-03-13 23:52:19 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:52:19 --> Encrypt Class Initialized
INFO - 2022-03-13 23:52:19 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:52:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:52:19 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:52:19 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:52:19 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:52:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:52:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:52:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:52:19 --> Final output sent to browser
DEBUG - 2022-03-13 23:52:19 --> Total execution time: 0.0700
ERROR - 2022-03-13 23:52:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:52:47 --> Config Class Initialized
INFO - 2022-03-13 23:52:47 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:52:47 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:52:47 --> Utf8 Class Initialized
INFO - 2022-03-13 23:52:47 --> URI Class Initialized
INFO - 2022-03-13 23:52:47 --> Router Class Initialized
INFO - 2022-03-13 23:52:47 --> Output Class Initialized
INFO - 2022-03-13 23:52:47 --> Security Class Initialized
DEBUG - 2022-03-13 23:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:52:47 --> Input Class Initialized
INFO - 2022-03-13 23:52:47 --> Language Class Initialized
INFO - 2022-03-13 23:52:47 --> Loader Class Initialized
INFO - 2022-03-13 23:52:47 --> Helper loaded: url_helper
INFO - 2022-03-13 23:52:47 --> Helper loaded: form_helper
INFO - 2022-03-13 23:52:47 --> Helper loaded: common_helper
INFO - 2022-03-13 23:52:47 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:52:47 --> Controller Class Initialized
INFO - 2022-03-13 23:52:47 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:52:47 --> Encrypt Class Initialized
INFO - 2022-03-13 23:52:47 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:52:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:52:47 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:52:47 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:52:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:52:48 --> Config Class Initialized
INFO - 2022-03-13 23:52:48 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:52:48 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:52:48 --> Utf8 Class Initialized
INFO - 2022-03-13 23:52:48 --> URI Class Initialized
INFO - 2022-03-13 23:52:48 --> Router Class Initialized
INFO - 2022-03-13 23:52:48 --> Output Class Initialized
INFO - 2022-03-13 23:52:48 --> Security Class Initialized
DEBUG - 2022-03-13 23:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:52:48 --> Input Class Initialized
INFO - 2022-03-13 23:52:48 --> Language Class Initialized
INFO - 2022-03-13 23:52:48 --> Loader Class Initialized
INFO - 2022-03-13 23:52:48 --> Helper loaded: url_helper
INFO - 2022-03-13 23:52:48 --> Helper loaded: form_helper
INFO - 2022-03-13 23:52:48 --> Helper loaded: common_helper
INFO - 2022-03-13 23:52:48 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:52:48 --> Controller Class Initialized
INFO - 2022-03-13 23:52:48 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:52:48 --> Encrypt Class Initialized
INFO - 2022-03-13 23:52:48 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:52:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:52:48 --> Model "Referredby_model" initialized
INFO - 2022-03-13 23:52:48 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:52:48 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:52:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:52:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-13 23:52:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:52:48 --> Final output sent to browser
DEBUG - 2022-03-13 23:52:48 --> Total execution time: 0.0419
ERROR - 2022-03-13 23:52:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:52:49 --> Config Class Initialized
INFO - 2022-03-13 23:52:49 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:52:49 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:52:49 --> Utf8 Class Initialized
INFO - 2022-03-13 23:52:49 --> URI Class Initialized
INFO - 2022-03-13 23:52:49 --> Router Class Initialized
INFO - 2022-03-13 23:52:49 --> Output Class Initialized
INFO - 2022-03-13 23:52:49 --> Security Class Initialized
DEBUG - 2022-03-13 23:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:52:49 --> Input Class Initialized
INFO - 2022-03-13 23:52:49 --> Language Class Initialized
INFO - 2022-03-13 23:52:49 --> Loader Class Initialized
INFO - 2022-03-13 23:52:49 --> Helper loaded: url_helper
INFO - 2022-03-13 23:52:49 --> Helper loaded: form_helper
INFO - 2022-03-13 23:52:49 --> Helper loaded: common_helper
INFO - 2022-03-13 23:52:49 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:52:49 --> Controller Class Initialized
INFO - 2022-03-13 23:52:49 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:52:49 --> Encrypt Class Initialized
INFO - 2022-03-13 23:52:49 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:52:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:52:49 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:52:49 --> Model "Users_model" initialized
INFO - 2022-03-13 23:52:49 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:52:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:52:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:52:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:52:49 --> Final output sent to browser
DEBUG - 2022-03-13 23:52:49 --> Total execution time: 0.0763
ERROR - 2022-03-13 23:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:57:42 --> Config Class Initialized
INFO - 2022-03-13 23:57:42 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:57:42 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:57:42 --> Utf8 Class Initialized
INFO - 2022-03-13 23:57:42 --> URI Class Initialized
INFO - 2022-03-13 23:57:42 --> Router Class Initialized
INFO - 2022-03-13 23:57:42 --> Output Class Initialized
INFO - 2022-03-13 23:57:42 --> Security Class Initialized
DEBUG - 2022-03-13 23:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:57:42 --> Input Class Initialized
INFO - 2022-03-13 23:57:42 --> Language Class Initialized
INFO - 2022-03-13 23:57:42 --> Loader Class Initialized
INFO - 2022-03-13 23:57:42 --> Helper loaded: url_helper
INFO - 2022-03-13 23:57:42 --> Helper loaded: form_helper
INFO - 2022-03-13 23:57:42 --> Helper loaded: common_helper
INFO - 2022-03-13 23:57:42 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:57:42 --> Controller Class Initialized
INFO - 2022-03-13 23:57:42 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:57:42 --> Encrypt Class Initialized
INFO - 2022-03-13 23:57:42 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:57:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:57:42 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:57:42 --> Model "Users_model" initialized
INFO - 2022-03-13 23:57:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-13 23:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-13 23:57:42 --> Config Class Initialized
INFO - 2022-03-13 23:57:42 --> Hooks Class Initialized
DEBUG - 2022-03-13 23:57:42 --> UTF-8 Support Enabled
INFO - 2022-03-13 23:57:42 --> Utf8 Class Initialized
INFO - 2022-03-13 23:57:42 --> URI Class Initialized
INFO - 2022-03-13 23:57:42 --> Router Class Initialized
INFO - 2022-03-13 23:57:42 --> Output Class Initialized
INFO - 2022-03-13 23:57:42 --> Security Class Initialized
DEBUG - 2022-03-13 23:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-13 23:57:42 --> Input Class Initialized
INFO - 2022-03-13 23:57:42 --> Language Class Initialized
INFO - 2022-03-13 23:57:42 --> Loader Class Initialized
INFO - 2022-03-13 23:57:42 --> Helper loaded: url_helper
INFO - 2022-03-13 23:57:42 --> Helper loaded: form_helper
INFO - 2022-03-13 23:57:42 --> Helper loaded: common_helper
INFO - 2022-03-13 23:57:42 --> Database Driver Class Initialized
DEBUG - 2022-03-13 23:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-13 23:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-13 23:57:42 --> Controller Class Initialized
INFO - 2022-03-13 23:57:42 --> Form Validation Class Initialized
DEBUG - 2022-03-13 23:57:42 --> Encrypt Class Initialized
INFO - 2022-03-13 23:57:42 --> Model "Patient_model" initialized
INFO - 2022-03-13 23:57:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-13 23:57:42 --> Model "Prefix_master" initialized
INFO - 2022-03-13 23:57:42 --> Model "Users_model" initialized
INFO - 2022-03-13 23:57:42 --> Model "Hospital_model" initialized
INFO - 2022-03-13 23:57:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-13 23:57:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-13 23:57:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-13 23:57:42 --> Final output sent to browser
DEBUG - 2022-03-13 23:57:42 --> Total execution time: 0.0777
