<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-16 05:52:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 05:52:51 --> Config Class Initialized
INFO - 2021-06-16 05:52:51 --> Hooks Class Initialized
DEBUG - 2021-06-16 05:52:51 --> UTF-8 Support Enabled
INFO - 2021-06-16 05:52:51 --> Utf8 Class Initialized
INFO - 2021-06-16 05:52:51 --> URI Class Initialized
DEBUG - 2021-06-16 05:52:51 --> No URI present. Default controller set.
INFO - 2021-06-16 05:52:51 --> Router Class Initialized
INFO - 2021-06-16 05:52:51 --> Output Class Initialized
INFO - 2021-06-16 05:52:51 --> Security Class Initialized
DEBUG - 2021-06-16 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 05:52:51 --> Input Class Initialized
INFO - 2021-06-16 05:52:51 --> Language Class Initialized
INFO - 2021-06-16 05:52:51 --> Loader Class Initialized
INFO - 2021-06-16 05:52:51 --> Helper loaded: url_helper
INFO - 2021-06-16 05:52:51 --> Helper loaded: form_helper
INFO - 2021-06-16 05:52:51 --> Helper loaded: common_helper
INFO - 2021-06-16 05:52:51 --> Database Driver Class Initialized
DEBUG - 2021-06-16 05:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 05:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 05:52:51 --> Controller Class Initialized
INFO - 2021-06-16 05:52:51 --> Form Validation Class Initialized
DEBUG - 2021-06-16 05:52:51 --> Encrypt Class Initialized
DEBUG - 2021-06-16 05:52:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 05:52:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 05:52:51 --> Email Class Initialized
INFO - 2021-06-16 05:52:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 05:52:51 --> Calendar Class Initialized
INFO - 2021-06-16 05:52:51 --> Model "Login_model" initialized
INFO - 2021-06-16 05:52:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-16 05:52:51 --> Final output sent to browser
DEBUG - 2021-06-16 05:52:51 --> Total execution time: 0.0501
ERROR - 2021-06-16 06:13:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 06:13:31 --> Config Class Initialized
INFO - 2021-06-16 06:13:31 --> Hooks Class Initialized
DEBUG - 2021-06-16 06:13:31 --> UTF-8 Support Enabled
INFO - 2021-06-16 06:13:31 --> Utf8 Class Initialized
INFO - 2021-06-16 06:13:31 --> URI Class Initialized
DEBUG - 2021-06-16 06:13:31 --> No URI present. Default controller set.
INFO - 2021-06-16 06:13:31 --> Router Class Initialized
INFO - 2021-06-16 06:13:31 --> Output Class Initialized
INFO - 2021-06-16 06:13:31 --> Security Class Initialized
DEBUG - 2021-06-16 06:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 06:13:31 --> Input Class Initialized
INFO - 2021-06-16 06:13:31 --> Language Class Initialized
INFO - 2021-06-16 06:13:31 --> Loader Class Initialized
INFO - 2021-06-16 06:13:31 --> Helper loaded: url_helper
INFO - 2021-06-16 06:13:31 --> Helper loaded: form_helper
INFO - 2021-06-16 06:13:31 --> Helper loaded: common_helper
INFO - 2021-06-16 06:13:31 --> Database Driver Class Initialized
DEBUG - 2021-06-16 06:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 06:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 06:13:31 --> Controller Class Initialized
INFO - 2021-06-16 06:13:31 --> Form Validation Class Initialized
DEBUG - 2021-06-16 06:13:31 --> Encrypt Class Initialized
DEBUG - 2021-06-16 06:13:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 06:13:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 06:13:31 --> Email Class Initialized
INFO - 2021-06-16 06:13:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 06:13:31 --> Calendar Class Initialized
INFO - 2021-06-16 06:13:31 --> Model "Login_model" initialized
INFO - 2021-06-16 06:13:31 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-16 06:13:31 --> Final output sent to browser
DEBUG - 2021-06-16 06:13:31 --> Total execution time: 0.0178
ERROR - 2021-06-16 17:32:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:32:34 --> Config Class Initialized
INFO - 2021-06-16 17:32:34 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:32:34 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:32:34 --> Utf8 Class Initialized
INFO - 2021-06-16 17:32:34 --> URI Class Initialized
DEBUG - 2021-06-16 17:32:34 --> No URI present. Default controller set.
INFO - 2021-06-16 17:32:34 --> Router Class Initialized
INFO - 2021-06-16 17:32:34 --> Output Class Initialized
INFO - 2021-06-16 17:32:34 --> Security Class Initialized
DEBUG - 2021-06-16 17:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:32:34 --> Input Class Initialized
INFO - 2021-06-16 17:32:34 --> Language Class Initialized
INFO - 2021-06-16 17:32:34 --> Loader Class Initialized
INFO - 2021-06-16 17:32:34 --> Helper loaded: url_helper
INFO - 2021-06-16 17:32:34 --> Helper loaded: form_helper
INFO - 2021-06-16 17:32:34 --> Helper loaded: common_helper
INFO - 2021-06-16 17:32:34 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:32:34 --> Controller Class Initialized
INFO - 2021-06-16 17:32:34 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:32:34 --> Encrypt Class Initialized
DEBUG - 2021-06-16 17:32:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 17:32:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 17:32:34 --> Email Class Initialized
INFO - 2021-06-16 17:32:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 17:32:34 --> Calendar Class Initialized
INFO - 2021-06-16 17:32:34 --> Model "Login_model" initialized
INFO - 2021-06-16 17:32:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-16 17:32:34 --> Final output sent to browser
DEBUG - 2021-06-16 17:32:34 --> Total execution time: 0.0326
ERROR - 2021-06-16 17:32:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:32:34 --> Config Class Initialized
INFO - 2021-06-16 17:32:34 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:32:34 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:32:34 --> Utf8 Class Initialized
INFO - 2021-06-16 17:32:34 --> URI Class Initialized
INFO - 2021-06-16 17:32:34 --> Router Class Initialized
INFO - 2021-06-16 17:32:34 --> Output Class Initialized
INFO - 2021-06-16 17:32:34 --> Security Class Initialized
DEBUG - 2021-06-16 17:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:32:34 --> Input Class Initialized
INFO - 2021-06-16 17:32:34 --> Language Class Initialized
ERROR - 2021-06-16 17:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-16 17:32:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:32:35 --> Config Class Initialized
INFO - 2021-06-16 17:32:35 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:32:35 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:32:35 --> Utf8 Class Initialized
INFO - 2021-06-16 17:32:35 --> URI Class Initialized
DEBUG - 2021-06-16 17:32:35 --> No URI present. Default controller set.
INFO - 2021-06-16 17:32:35 --> Router Class Initialized
INFO - 2021-06-16 17:32:35 --> Output Class Initialized
INFO - 2021-06-16 17:32:35 --> Security Class Initialized
DEBUG - 2021-06-16 17:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:32:35 --> Input Class Initialized
INFO - 2021-06-16 17:32:35 --> Language Class Initialized
INFO - 2021-06-16 17:32:35 --> Loader Class Initialized
INFO - 2021-06-16 17:32:35 --> Helper loaded: url_helper
INFO - 2021-06-16 17:32:35 --> Helper loaded: form_helper
INFO - 2021-06-16 17:32:35 --> Helper loaded: common_helper
INFO - 2021-06-16 17:32:35 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:32:35 --> Controller Class Initialized
INFO - 2021-06-16 17:32:35 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:32:35 --> Encrypt Class Initialized
DEBUG - 2021-06-16 17:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 17:32:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 17:32:35 --> Email Class Initialized
INFO - 2021-06-16 17:32:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 17:32:35 --> Calendar Class Initialized
INFO - 2021-06-16 17:32:35 --> Model "Login_model" initialized
INFO - 2021-06-16 17:32:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-16 17:32:35 --> Final output sent to browser
DEBUG - 2021-06-16 17:32:35 --> Total execution time: 0.0178
ERROR - 2021-06-16 17:32:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:32:35 --> Config Class Initialized
INFO - 2021-06-16 17:32:35 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:32:35 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:32:35 --> Utf8 Class Initialized
INFO - 2021-06-16 17:32:35 --> URI Class Initialized
INFO - 2021-06-16 17:32:35 --> Router Class Initialized
INFO - 2021-06-16 17:32:35 --> Output Class Initialized
INFO - 2021-06-16 17:32:35 --> Security Class Initialized
DEBUG - 2021-06-16 17:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:32:35 --> Input Class Initialized
INFO - 2021-06-16 17:32:35 --> Language Class Initialized
ERROR - 2021-06-16 17:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-16 17:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:32:36 --> Config Class Initialized
INFO - 2021-06-16 17:32:36 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:32:36 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:32:36 --> Utf8 Class Initialized
INFO - 2021-06-16 17:32:36 --> URI Class Initialized
INFO - 2021-06-16 17:32:36 --> Router Class Initialized
INFO - 2021-06-16 17:32:36 --> Output Class Initialized
INFO - 2021-06-16 17:32:36 --> Security Class Initialized
DEBUG - 2021-06-16 17:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:32:36 --> Input Class Initialized
INFO - 2021-06-16 17:32:36 --> Language Class Initialized
ERROR - 2021-06-16 17:32:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-16 17:32:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:32:40 --> Config Class Initialized
INFO - 2021-06-16 17:32:40 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:32:40 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:32:40 --> Utf8 Class Initialized
INFO - 2021-06-16 17:32:40 --> URI Class Initialized
INFO - 2021-06-16 17:32:40 --> Router Class Initialized
INFO - 2021-06-16 17:32:40 --> Output Class Initialized
INFO - 2021-06-16 17:32:40 --> Security Class Initialized
DEBUG - 2021-06-16 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:32:40 --> Input Class Initialized
INFO - 2021-06-16 17:32:40 --> Language Class Initialized
INFO - 2021-06-16 17:32:40 --> Loader Class Initialized
INFO - 2021-06-16 17:32:40 --> Helper loaded: url_helper
INFO - 2021-06-16 17:32:40 --> Helper loaded: form_helper
INFO - 2021-06-16 17:32:40 --> Helper loaded: common_helper
INFO - 2021-06-16 17:32:40 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:32:40 --> Controller Class Initialized
INFO - 2021-06-16 17:32:40 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:32:40 --> Encrypt Class Initialized
DEBUG - 2021-06-16 17:32:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 17:32:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 17:32:40 --> Email Class Initialized
INFO - 2021-06-16 17:32:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 17:32:40 --> Calendar Class Initialized
INFO - 2021-06-16 17:32:40 --> Model "Login_model" initialized
INFO - 2021-06-16 17:32:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-16 17:32:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:32:40 --> Config Class Initialized
INFO - 2021-06-16 17:32:40 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:32:40 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:32:40 --> Utf8 Class Initialized
INFO - 2021-06-16 17:32:40 --> URI Class Initialized
INFO - 2021-06-16 17:32:40 --> Router Class Initialized
INFO - 2021-06-16 17:32:40 --> Output Class Initialized
INFO - 2021-06-16 17:32:40 --> Security Class Initialized
DEBUG - 2021-06-16 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:32:40 --> Input Class Initialized
INFO - 2021-06-16 17:32:40 --> Language Class Initialized
INFO - 2021-06-16 17:32:40 --> Loader Class Initialized
INFO - 2021-06-16 17:32:40 --> Helper loaded: url_helper
INFO - 2021-06-16 17:32:40 --> Helper loaded: form_helper
INFO - 2021-06-16 17:32:40 --> Helper loaded: common_helper
INFO - 2021-06-16 17:32:40 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:32:40 --> Controller Class Initialized
INFO - 2021-06-16 17:32:40 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:32:40 --> Encrypt Class Initialized
INFO - 2021-06-16 17:32:40 --> Model "Login_model" initialized
INFO - 2021-06-16 17:32:40 --> Model "Dashboard_model" initialized
INFO - 2021-06-16 17:32:40 --> Model "Case_model" initialized
INFO - 2021-06-16 17:32:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 17:32:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-16 17:32:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-16 17:32:50 --> Final output sent to browser
DEBUG - 2021-06-16 17:32:50 --> Total execution time: 9.5096
ERROR - 2021-06-16 17:32:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:32:51 --> Config Class Initialized
INFO - 2021-06-16 17:32:51 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:32:51 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:32:51 --> Utf8 Class Initialized
INFO - 2021-06-16 17:32:51 --> URI Class Initialized
INFO - 2021-06-16 17:32:51 --> Router Class Initialized
INFO - 2021-06-16 17:32:51 --> Output Class Initialized
INFO - 2021-06-16 17:32:51 --> Security Class Initialized
DEBUG - 2021-06-16 17:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:32:51 --> Input Class Initialized
INFO - 2021-06-16 17:32:51 --> Language Class Initialized
ERROR - 2021-06-16 17:32:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-16 17:33:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:33:15 --> Config Class Initialized
INFO - 2021-06-16 17:33:15 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:33:15 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:33:15 --> Utf8 Class Initialized
INFO - 2021-06-16 17:33:15 --> URI Class Initialized
INFO - 2021-06-16 17:33:15 --> Router Class Initialized
INFO - 2021-06-16 17:33:15 --> Output Class Initialized
INFO - 2021-06-16 17:33:15 --> Security Class Initialized
DEBUG - 2021-06-16 17:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:33:15 --> Input Class Initialized
INFO - 2021-06-16 17:33:15 --> Language Class Initialized
INFO - 2021-06-16 17:33:15 --> Loader Class Initialized
INFO - 2021-06-16 17:33:15 --> Helper loaded: url_helper
INFO - 2021-06-16 17:33:15 --> Helper loaded: form_helper
INFO - 2021-06-16 17:33:15 --> Helper loaded: common_helper
INFO - 2021-06-16 17:33:15 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:33:15 --> Controller Class Initialized
INFO - 2021-06-16 17:33:15 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:33:15 --> Encrypt Class Initialized
INFO - 2021-06-16 17:33:15 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:33:15 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:33:15 --> Model "Referredby_model" initialized
INFO - 2021-06-16 17:33:15 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:33:15 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:33:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 17:33:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-16 17:33:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-16 17:33:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:33:21 --> Config Class Initialized
INFO - 2021-06-16 17:33:21 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:33:21 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:33:21 --> Utf8 Class Initialized
INFO - 2021-06-16 17:33:21 --> URI Class Initialized
INFO - 2021-06-16 17:33:21 --> Router Class Initialized
INFO - 2021-06-16 17:33:21 --> Output Class Initialized
INFO - 2021-06-16 17:33:21 --> Security Class Initialized
DEBUG - 2021-06-16 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:33:21 --> Input Class Initialized
INFO - 2021-06-16 17:33:21 --> Language Class Initialized
ERROR - 2021-06-16 17:33:21 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-16 17:33:24 --> Final output sent to browser
DEBUG - 2021-06-16 17:33:24 --> Total execution time: 4.5148
ERROR - 2021-06-16 17:33:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:33:46 --> Config Class Initialized
INFO - 2021-06-16 17:33:46 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:33:46 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:33:46 --> Utf8 Class Initialized
INFO - 2021-06-16 17:33:46 --> URI Class Initialized
INFO - 2021-06-16 17:33:46 --> Router Class Initialized
INFO - 2021-06-16 17:33:46 --> Output Class Initialized
INFO - 2021-06-16 17:33:46 --> Security Class Initialized
DEBUG - 2021-06-16 17:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:33:46 --> Input Class Initialized
INFO - 2021-06-16 17:33:46 --> Language Class Initialized
INFO - 2021-06-16 17:33:46 --> Loader Class Initialized
INFO - 2021-06-16 17:33:46 --> Helper loaded: url_helper
INFO - 2021-06-16 17:33:46 --> Helper loaded: form_helper
INFO - 2021-06-16 17:33:46 --> Helper loaded: common_helper
INFO - 2021-06-16 17:33:46 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:33:46 --> Controller Class Initialized
INFO - 2021-06-16 17:33:46 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:33:46 --> Encrypt Class Initialized
INFO - 2021-06-16 17:33:46 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:33:46 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:33:46 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:33:46 --> Model "Users_model" initialized
INFO - 2021-06-16 17:33:46 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:33:46 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
INFO - 2021-06-16 17:33:47 --> Final output sent to browser
DEBUG - 2021-06-16 17:33:47 --> Total execution time: 0.8659
ERROR - 2021-06-16 17:34:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:34:05 --> Config Class Initialized
INFO - 2021-06-16 17:34:05 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:34:05 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:34:05 --> Utf8 Class Initialized
INFO - 2021-06-16 17:34:05 --> URI Class Initialized
INFO - 2021-06-16 17:34:05 --> Router Class Initialized
INFO - 2021-06-16 17:34:05 --> Output Class Initialized
INFO - 2021-06-16 17:34:05 --> Security Class Initialized
DEBUG - 2021-06-16 17:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:34:05 --> Input Class Initialized
INFO - 2021-06-16 17:34:05 --> Language Class Initialized
INFO - 2021-06-16 17:34:05 --> Loader Class Initialized
INFO - 2021-06-16 17:34:05 --> Helper loaded: url_helper
INFO - 2021-06-16 17:34:05 --> Helper loaded: form_helper
INFO - 2021-06-16 17:34:05 --> Helper loaded: common_helper
INFO - 2021-06-16 17:34:05 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:34:05 --> Controller Class Initialized
INFO - 2021-06-16 17:34:05 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:34:05 --> Encrypt Class Initialized
INFO - 2021-06-16 17:34:05 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:34:05 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:34:05 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:34:05 --> Model "Users_model" initialized
INFO - 2021-06-16 17:34:05 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:34:05 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 17:34:05 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patientcase/index.php
INFO - 2021-06-16 17:34:05 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-16 17:34:05 --> Final output sent to browser
DEBUG - 2021-06-16 17:34:05 --> Total execution time: 0.1084
ERROR - 2021-06-16 17:34:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:34:06 --> Config Class Initialized
INFO - 2021-06-16 17:34:06 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:34:06 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:34:06 --> Utf8 Class Initialized
INFO - 2021-06-16 17:34:06 --> URI Class Initialized
INFO - 2021-06-16 17:34:06 --> Router Class Initialized
INFO - 2021-06-16 17:34:06 --> Output Class Initialized
INFO - 2021-06-16 17:34:06 --> Security Class Initialized
DEBUG - 2021-06-16 17:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:34:06 --> Input Class Initialized
INFO - 2021-06-16 17:34:06 --> Language Class Initialized
ERROR - 2021-06-16 17:34:06 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-16 17:34:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:34:19 --> Config Class Initialized
INFO - 2021-06-16 17:34:19 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:34:19 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:34:19 --> Utf8 Class Initialized
INFO - 2021-06-16 17:34:19 --> URI Class Initialized
INFO - 2021-06-16 17:34:19 --> Router Class Initialized
INFO - 2021-06-16 17:34:19 --> Output Class Initialized
INFO - 2021-06-16 17:34:19 --> Security Class Initialized
DEBUG - 2021-06-16 17:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:34:19 --> Input Class Initialized
INFO - 2021-06-16 17:34:19 --> Language Class Initialized
INFO - 2021-06-16 17:34:19 --> Loader Class Initialized
INFO - 2021-06-16 17:34:19 --> Helper loaded: url_helper
INFO - 2021-06-16 17:34:19 --> Helper loaded: form_helper
INFO - 2021-06-16 17:34:19 --> Helper loaded: common_helper
INFO - 2021-06-16 17:34:19 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:34:19 --> Controller Class Initialized
INFO - 2021-06-16 17:34:19 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:34:19 --> Encrypt Class Initialized
INFO - 2021-06-16 17:34:19 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:34:19 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:34:19 --> Model "Referredby_model" initialized
INFO - 2021-06-16 17:34:19 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:34:19 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:34:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 17:34:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-16 17:34:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-16 17:34:27 --> Final output sent to browser
DEBUG - 2021-06-16 17:34:27 --> Total execution time: 4.1476
ERROR - 2021-06-16 17:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:34:30 --> Config Class Initialized
INFO - 2021-06-16 17:34:30 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:34:30 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:34:30 --> Utf8 Class Initialized
INFO - 2021-06-16 17:34:30 --> URI Class Initialized
INFO - 2021-06-16 17:34:30 --> Router Class Initialized
INFO - 2021-06-16 17:34:30 --> Output Class Initialized
INFO - 2021-06-16 17:34:30 --> Security Class Initialized
DEBUG - 2021-06-16 17:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:34:30 --> Input Class Initialized
INFO - 2021-06-16 17:34:30 --> Language Class Initialized
INFO - 2021-06-16 17:34:30 --> Loader Class Initialized
INFO - 2021-06-16 17:34:30 --> Helper loaded: url_helper
INFO - 2021-06-16 17:34:30 --> Helper loaded: form_helper
INFO - 2021-06-16 17:34:30 --> Helper loaded: common_helper
INFO - 2021-06-16 17:34:30 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:34:30 --> Controller Class Initialized
INFO - 2021-06-16 17:34:30 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:34:30 --> Encrypt Class Initialized
INFO - 2021-06-16 17:34:30 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:34:30 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:34:30 --> Model "Referredby_model" initialized
INFO - 2021-06-16 17:34:30 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:34:30 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:34:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 17:34:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-16 17:34:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-16 17:34:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:34:36 --> Config Class Initialized
INFO - 2021-06-16 17:34:36 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:34:36 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:34:36 --> Utf8 Class Initialized
INFO - 2021-06-16 17:34:36 --> URI Class Initialized
INFO - 2021-06-16 17:34:36 --> Router Class Initialized
INFO - 2021-06-16 17:34:36 --> Output Class Initialized
INFO - 2021-06-16 17:34:36 --> Security Class Initialized
DEBUG - 2021-06-16 17:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:34:36 --> Input Class Initialized
INFO - 2021-06-16 17:34:36 --> Language Class Initialized
ERROR - 2021-06-16 17:34:36 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-16 17:34:39 --> Final output sent to browser
DEBUG - 2021-06-16 17:34:39 --> Total execution time: 4.2823
ERROR - 2021-06-16 17:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:35:39 --> Config Class Initialized
INFO - 2021-06-16 17:35:39 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:35:39 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:35:39 --> Utf8 Class Initialized
INFO - 2021-06-16 17:35:39 --> URI Class Initialized
INFO - 2021-06-16 17:35:39 --> Router Class Initialized
INFO - 2021-06-16 17:35:39 --> Output Class Initialized
INFO - 2021-06-16 17:35:39 --> Security Class Initialized
DEBUG - 2021-06-16 17:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:35:39 --> Input Class Initialized
INFO - 2021-06-16 17:35:39 --> Language Class Initialized
INFO - 2021-06-16 17:35:39 --> Loader Class Initialized
INFO - 2021-06-16 17:35:39 --> Helper loaded: url_helper
INFO - 2021-06-16 17:35:39 --> Helper loaded: form_helper
INFO - 2021-06-16 17:35:39 --> Helper loaded: common_helper
INFO - 2021-06-16 17:35:39 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:35:39 --> Controller Class Initialized
INFO - 2021-06-16 17:35:39 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:35:39 --> Encrypt Class Initialized
INFO - 2021-06-16 17:35:39 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:35:39 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:35:39 --> Model "Referredby_model" initialized
INFO - 2021-06-16 17:35:39 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:35:39 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:35:40 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 17:35:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-16 17:35:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-16 17:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:35:45 --> Config Class Initialized
INFO - 2021-06-16 17:35:45 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:35:45 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:35:45 --> Utf8 Class Initialized
INFO - 2021-06-16 17:35:45 --> URI Class Initialized
INFO - 2021-06-16 17:35:45 --> Router Class Initialized
INFO - 2021-06-16 17:35:45 --> Output Class Initialized
INFO - 2021-06-16 17:35:45 --> Security Class Initialized
DEBUG - 2021-06-16 17:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:35:45 --> Input Class Initialized
INFO - 2021-06-16 17:35:45 --> Language Class Initialized
ERROR - 2021-06-16 17:35:45 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-16 17:35:49 --> Final output sent to browser
DEBUG - 2021-06-16 17:35:49 --> Total execution time: 4.7403
ERROR - 2021-06-16 17:36:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:36:10 --> Config Class Initialized
INFO - 2021-06-16 17:36:10 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:36:10 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:36:10 --> Utf8 Class Initialized
INFO - 2021-06-16 17:36:10 --> URI Class Initialized
INFO - 2021-06-16 17:36:10 --> Router Class Initialized
INFO - 2021-06-16 17:36:10 --> Output Class Initialized
INFO - 2021-06-16 17:36:10 --> Security Class Initialized
DEBUG - 2021-06-16 17:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:36:10 --> Input Class Initialized
INFO - 2021-06-16 17:36:10 --> Language Class Initialized
INFO - 2021-06-16 17:36:10 --> Loader Class Initialized
INFO - 2021-06-16 17:36:10 --> Helper loaded: url_helper
INFO - 2021-06-16 17:36:10 --> Helper loaded: form_helper
INFO - 2021-06-16 17:36:10 --> Helper loaded: common_helper
INFO - 2021-06-16 17:36:10 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:36:10 --> Controller Class Initialized
INFO - 2021-06-16 17:36:10 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:36:10 --> Encrypt Class Initialized
INFO - 2021-06-16 17:36:10 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:36:10 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:36:10 --> Model "Referredby_model" initialized
INFO - 2021-06-16 17:36:10 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:36:10 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:36:10 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 17:36:14 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-16 17:36:14 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-16 17:36:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:36:15 --> Config Class Initialized
INFO - 2021-06-16 17:36:15 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:36:15 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:36:15 --> Utf8 Class Initialized
INFO - 2021-06-16 17:36:15 --> URI Class Initialized
INFO - 2021-06-16 17:36:15 --> Router Class Initialized
INFO - 2021-06-16 17:36:15 --> Output Class Initialized
INFO - 2021-06-16 17:36:15 --> Security Class Initialized
DEBUG - 2021-06-16 17:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:36:15 --> Input Class Initialized
INFO - 2021-06-16 17:36:15 --> Language Class Initialized
ERROR - 2021-06-16 17:36:15 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-16 17:36:17 --> Final output sent to browser
DEBUG - 2021-06-16 17:36:17 --> Total execution time: 3.9822
ERROR - 2021-06-16 17:37:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:37:18 --> Config Class Initialized
INFO - 2021-06-16 17:37:18 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:37:18 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:37:18 --> Utf8 Class Initialized
INFO - 2021-06-16 17:37:18 --> URI Class Initialized
INFO - 2021-06-16 17:37:18 --> Router Class Initialized
INFO - 2021-06-16 17:37:18 --> Output Class Initialized
INFO - 2021-06-16 17:37:18 --> Security Class Initialized
DEBUG - 2021-06-16 17:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:37:18 --> Input Class Initialized
INFO - 2021-06-16 17:37:18 --> Language Class Initialized
INFO - 2021-06-16 17:37:18 --> Loader Class Initialized
INFO - 2021-06-16 17:37:18 --> Helper loaded: url_helper
INFO - 2021-06-16 17:37:18 --> Helper loaded: form_helper
INFO - 2021-06-16 17:37:18 --> Helper loaded: common_helper
INFO - 2021-06-16 17:37:18 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:37:18 --> Controller Class Initialized
INFO - 2021-06-16 17:37:18 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:37:18 --> Encrypt Class Initialized
INFO - 2021-06-16 17:37:18 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:37:18 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:37:18 --> Model "Referredby_model" initialized
INFO - 2021-06-16 17:37:18 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:37:18 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:37:18 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
ERROR - 2021-06-16 17:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:37:20 --> Config Class Initialized
INFO - 2021-06-16 17:37:20 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:37:20 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:37:20 --> Utf8 Class Initialized
INFO - 2021-06-16 17:37:20 --> URI Class Initialized
INFO - 2021-06-16 17:37:20 --> Router Class Initialized
INFO - 2021-06-16 17:37:20 --> Output Class Initialized
INFO - 2021-06-16 17:37:20 --> Security Class Initialized
DEBUG - 2021-06-16 17:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:37:20 --> Input Class Initialized
INFO - 2021-06-16 17:37:20 --> Language Class Initialized
INFO - 2021-06-16 17:37:20 --> Loader Class Initialized
INFO - 2021-06-16 17:37:20 --> Helper loaded: url_helper
INFO - 2021-06-16 17:37:20 --> Helper loaded: form_helper
INFO - 2021-06-16 17:37:20 --> Helper loaded: common_helper
INFO - 2021-06-16 17:37:20 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:37:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-16 17:37:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-16 17:37:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:37:24 --> Config Class Initialized
INFO - 2021-06-16 17:37:24 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:37:24 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:37:24 --> Utf8 Class Initialized
INFO - 2021-06-16 17:37:24 --> URI Class Initialized
INFO - 2021-06-16 17:37:24 --> Router Class Initialized
INFO - 2021-06-16 17:37:24 --> Output Class Initialized
INFO - 2021-06-16 17:37:24 --> Security Class Initialized
DEBUG - 2021-06-16 17:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:37:24 --> Input Class Initialized
INFO - 2021-06-16 17:37:24 --> Language Class Initialized
ERROR - 2021-06-16 17:37:24 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-16 17:37:26 --> Final output sent to browser
DEBUG - 2021-06-16 17:37:26 --> Total execution time: 4.8992
INFO - 2021-06-16 17:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:37:26 --> Controller Class Initialized
INFO - 2021-06-16 17:37:26 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:37:26 --> Encrypt Class Initialized
INFO - 2021-06-16 17:37:26 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:37:26 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:37:26 --> Model "Referredby_model" initialized
INFO - 2021-06-16 17:37:26 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:37:26 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:37:26 --> Final output sent to browser
DEBUG - 2021-06-16 17:37:26 --> Total execution time: 6.3269
ERROR - 2021-06-16 17:37:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:37:34 --> Config Class Initialized
INFO - 2021-06-16 17:37:34 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:37:34 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:37:34 --> Utf8 Class Initialized
INFO - 2021-06-16 17:37:34 --> URI Class Initialized
INFO - 2021-06-16 17:37:34 --> Router Class Initialized
INFO - 2021-06-16 17:37:34 --> Output Class Initialized
INFO - 2021-06-16 17:37:34 --> Security Class Initialized
DEBUG - 2021-06-16 17:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:37:34 --> Input Class Initialized
INFO - 2021-06-16 17:37:34 --> Language Class Initialized
INFO - 2021-06-16 17:37:34 --> Loader Class Initialized
INFO - 2021-06-16 17:37:34 --> Helper loaded: url_helper
INFO - 2021-06-16 17:37:34 --> Helper loaded: form_helper
INFO - 2021-06-16 17:37:34 --> Helper loaded: common_helper
INFO - 2021-06-16 17:37:34 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:37:34 --> Controller Class Initialized
INFO - 2021-06-16 17:37:34 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:37:34 --> Encrypt Class Initialized
INFO - 2021-06-16 17:37:34 --> Model "Patient_model" initialized
INFO - 2021-06-16 17:37:34 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 17:37:34 --> Model "Referredby_model" initialized
INFO - 2021-06-16 17:37:34 --> Model "Prefix_master" initialized
INFO - 2021-06-16 17:37:34 --> Model "Hospital_model" initialized
INFO - 2021-06-16 17:37:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 17:37:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-16 17:37:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-16 17:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:37:47 --> Config Class Initialized
INFO - 2021-06-16 17:37:47 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:37:47 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:37:47 --> Utf8 Class Initialized
INFO - 2021-06-16 17:37:47 --> URI Class Initialized
INFO - 2021-06-16 17:37:47 --> Router Class Initialized
INFO - 2021-06-16 17:37:47 --> Output Class Initialized
INFO - 2021-06-16 17:37:47 --> Security Class Initialized
DEBUG - 2021-06-16 17:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:37:47 --> Input Class Initialized
INFO - 2021-06-16 17:37:47 --> Language Class Initialized
ERROR - 2021-06-16 17:37:47 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-16 17:37:47 --> Final output sent to browser
DEBUG - 2021-06-16 17:37:47 --> Total execution time: 5.2409
ERROR - 2021-06-16 17:38:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:38:41 --> Config Class Initialized
INFO - 2021-06-16 17:38:41 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:38:41 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:38:41 --> Utf8 Class Initialized
INFO - 2021-06-16 17:38:41 --> URI Class Initialized
INFO - 2021-06-16 17:38:41 --> Router Class Initialized
INFO - 2021-06-16 17:38:41 --> Output Class Initialized
INFO - 2021-06-16 17:38:41 --> Security Class Initialized
DEBUG - 2021-06-16 17:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:38:41 --> Input Class Initialized
INFO - 2021-06-16 17:38:41 --> Language Class Initialized
INFO - 2021-06-16 17:38:41 --> Loader Class Initialized
INFO - 2021-06-16 17:38:41 --> Helper loaded: url_helper
INFO - 2021-06-16 17:38:41 --> Helper loaded: form_helper
INFO - 2021-06-16 17:38:41 --> Helper loaded: common_helper
INFO - 2021-06-16 17:38:41 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:38:41 --> Controller Class Initialized
INFO - 2021-06-16 17:38:41 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:38:41 --> Encrypt Class Initialized
DEBUG - 2021-06-16 17:38:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 17:38:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 17:38:41 --> Email Class Initialized
INFO - 2021-06-16 17:38:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 17:38:41 --> Calendar Class Initialized
INFO - 2021-06-16 17:38:41 --> Model "Login_model" initialized
ERROR - 2021-06-16 17:38:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:38:42 --> Config Class Initialized
INFO - 2021-06-16 17:38:42 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:38:42 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:38:42 --> Utf8 Class Initialized
INFO - 2021-06-16 17:38:42 --> URI Class Initialized
INFO - 2021-06-16 17:38:42 --> Router Class Initialized
INFO - 2021-06-16 17:38:42 --> Output Class Initialized
INFO - 2021-06-16 17:38:42 --> Security Class Initialized
DEBUG - 2021-06-16 17:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:38:42 --> Input Class Initialized
INFO - 2021-06-16 17:38:42 --> Language Class Initialized
INFO - 2021-06-16 17:38:42 --> Loader Class Initialized
INFO - 2021-06-16 17:38:42 --> Helper loaded: url_helper
INFO - 2021-06-16 17:38:42 --> Helper loaded: form_helper
INFO - 2021-06-16 17:38:42 --> Helper loaded: common_helper
INFO - 2021-06-16 17:38:42 --> Database Driver Class Initialized
DEBUG - 2021-06-16 17:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 17:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 17:38:42 --> Controller Class Initialized
INFO - 2021-06-16 17:38:42 --> Form Validation Class Initialized
DEBUG - 2021-06-16 17:38:42 --> Encrypt Class Initialized
DEBUG - 2021-06-16 17:38:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 17:38:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 17:38:42 --> Email Class Initialized
INFO - 2021-06-16 17:38:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 17:38:42 --> Calendar Class Initialized
INFO - 2021-06-16 17:38:42 --> Model "Login_model" initialized
INFO - 2021-06-16 17:38:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-16 17:38:42 --> Final output sent to browser
DEBUG - 2021-06-16 17:38:42 --> Total execution time: 0.0168
ERROR - 2021-06-16 17:38:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 17:38:43 --> Config Class Initialized
INFO - 2021-06-16 17:38:43 --> Hooks Class Initialized
DEBUG - 2021-06-16 17:38:43 --> UTF-8 Support Enabled
INFO - 2021-06-16 17:38:43 --> Utf8 Class Initialized
INFO - 2021-06-16 17:38:43 --> URI Class Initialized
INFO - 2021-06-16 17:38:43 --> Router Class Initialized
INFO - 2021-06-16 17:38:43 --> Output Class Initialized
INFO - 2021-06-16 17:38:43 --> Security Class Initialized
DEBUG - 2021-06-16 17:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 17:38:43 --> Input Class Initialized
INFO - 2021-06-16 17:38:43 --> Language Class Initialized
ERROR - 2021-06-16 17:38:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-16 18:42:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:42:14 --> Config Class Initialized
INFO - 2021-06-16 18:42:14 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:42:14 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:42:14 --> Utf8 Class Initialized
INFO - 2021-06-16 18:42:14 --> URI Class Initialized
DEBUG - 2021-06-16 18:42:14 --> No URI present. Default controller set.
INFO - 2021-06-16 18:42:14 --> Router Class Initialized
INFO - 2021-06-16 18:42:14 --> Output Class Initialized
INFO - 2021-06-16 18:42:14 --> Security Class Initialized
DEBUG - 2021-06-16 18:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:42:14 --> Input Class Initialized
INFO - 2021-06-16 18:42:14 --> Language Class Initialized
INFO - 2021-06-16 18:42:14 --> Loader Class Initialized
INFO - 2021-06-16 18:42:14 --> Helper loaded: url_helper
INFO - 2021-06-16 18:42:14 --> Helper loaded: form_helper
INFO - 2021-06-16 18:42:14 --> Helper loaded: common_helper
INFO - 2021-06-16 18:42:14 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:42:14 --> Controller Class Initialized
INFO - 2021-06-16 18:42:14 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:42:14 --> Encrypt Class Initialized
DEBUG - 2021-06-16 18:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 18:42:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 18:42:14 --> Email Class Initialized
INFO - 2021-06-16 18:42:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 18:42:14 --> Calendar Class Initialized
INFO - 2021-06-16 18:42:14 --> Model "Login_model" initialized
INFO - 2021-06-16 18:42:14 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-16 18:42:14 --> Final output sent to browser
DEBUG - 2021-06-16 18:42:14 --> Total execution time: 0.0425
ERROR - 2021-06-16 18:42:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:42:16 --> Config Class Initialized
INFO - 2021-06-16 18:42:16 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:42:16 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:42:16 --> Utf8 Class Initialized
INFO - 2021-06-16 18:42:16 --> URI Class Initialized
DEBUG - 2021-06-16 18:42:16 --> No URI present. Default controller set.
INFO - 2021-06-16 18:42:16 --> Router Class Initialized
INFO - 2021-06-16 18:42:16 --> Output Class Initialized
INFO - 2021-06-16 18:42:16 --> Security Class Initialized
DEBUG - 2021-06-16 18:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:42:16 --> Input Class Initialized
INFO - 2021-06-16 18:42:16 --> Language Class Initialized
INFO - 2021-06-16 18:42:16 --> Loader Class Initialized
INFO - 2021-06-16 18:42:16 --> Helper loaded: url_helper
INFO - 2021-06-16 18:42:16 --> Helper loaded: form_helper
INFO - 2021-06-16 18:42:16 --> Helper loaded: common_helper
INFO - 2021-06-16 18:42:16 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:42:16 --> Controller Class Initialized
INFO - 2021-06-16 18:42:16 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:42:16 --> Encrypt Class Initialized
DEBUG - 2021-06-16 18:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 18:42:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 18:42:16 --> Email Class Initialized
INFO - 2021-06-16 18:42:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 18:42:16 --> Calendar Class Initialized
INFO - 2021-06-16 18:42:16 --> Model "Login_model" initialized
INFO - 2021-06-16 18:42:16 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-16 18:42:16 --> Final output sent to browser
DEBUG - 2021-06-16 18:42:16 --> Total execution time: 0.0194
ERROR - 2021-06-16 18:42:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:42:17 --> Config Class Initialized
INFO - 2021-06-16 18:42:17 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:42:17 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:42:17 --> Utf8 Class Initialized
INFO - 2021-06-16 18:42:17 --> URI Class Initialized
INFO - 2021-06-16 18:42:17 --> Router Class Initialized
INFO - 2021-06-16 18:42:17 --> Output Class Initialized
INFO - 2021-06-16 18:42:17 --> Security Class Initialized
DEBUG - 2021-06-16 18:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:42:17 --> Input Class Initialized
INFO - 2021-06-16 18:42:17 --> Language Class Initialized
ERROR - 2021-06-16 18:42:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-16 18:48:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:48:19 --> Config Class Initialized
INFO - 2021-06-16 18:48:19 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:48:19 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:48:19 --> Utf8 Class Initialized
INFO - 2021-06-16 18:48:19 --> URI Class Initialized
DEBUG - 2021-06-16 18:48:19 --> No URI present. Default controller set.
INFO - 2021-06-16 18:48:19 --> Router Class Initialized
INFO - 2021-06-16 18:48:19 --> Output Class Initialized
INFO - 2021-06-16 18:48:19 --> Security Class Initialized
DEBUG - 2021-06-16 18:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:48:19 --> Input Class Initialized
INFO - 2021-06-16 18:48:19 --> Language Class Initialized
INFO - 2021-06-16 18:48:19 --> Loader Class Initialized
INFO - 2021-06-16 18:48:19 --> Helper loaded: url_helper
INFO - 2021-06-16 18:48:19 --> Helper loaded: form_helper
INFO - 2021-06-16 18:48:19 --> Helper loaded: common_helper
INFO - 2021-06-16 18:48:19 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:48:19 --> Controller Class Initialized
INFO - 2021-06-16 18:48:19 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:48:19 --> Encrypt Class Initialized
DEBUG - 2021-06-16 18:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 18:48:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 18:48:19 --> Email Class Initialized
INFO - 2021-06-16 18:48:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 18:48:19 --> Calendar Class Initialized
INFO - 2021-06-16 18:48:19 --> Model "Login_model" initialized
INFO - 2021-06-16 18:48:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-16 18:48:19 --> Final output sent to browser
DEBUG - 2021-06-16 18:48:19 --> Total execution time: 0.0182
ERROR - 2021-06-16 18:48:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:48:20 --> Config Class Initialized
INFO - 2021-06-16 18:48:20 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:48:20 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:48:20 --> Utf8 Class Initialized
INFO - 2021-06-16 18:48:20 --> URI Class Initialized
DEBUG - 2021-06-16 18:48:20 --> No URI present. Default controller set.
INFO - 2021-06-16 18:48:20 --> Router Class Initialized
INFO - 2021-06-16 18:48:20 --> Output Class Initialized
INFO - 2021-06-16 18:48:20 --> Security Class Initialized
DEBUG - 2021-06-16 18:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:48:20 --> Input Class Initialized
INFO - 2021-06-16 18:48:20 --> Language Class Initialized
INFO - 2021-06-16 18:48:20 --> Loader Class Initialized
INFO - 2021-06-16 18:48:20 --> Helper loaded: url_helper
INFO - 2021-06-16 18:48:20 --> Helper loaded: form_helper
INFO - 2021-06-16 18:48:20 --> Helper loaded: common_helper
INFO - 2021-06-16 18:48:20 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:48:20 --> Controller Class Initialized
INFO - 2021-06-16 18:48:20 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:48:20 --> Encrypt Class Initialized
DEBUG - 2021-06-16 18:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 18:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 18:48:20 --> Email Class Initialized
INFO - 2021-06-16 18:48:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 18:48:20 --> Calendar Class Initialized
INFO - 2021-06-16 18:48:20 --> Model "Login_model" initialized
INFO - 2021-06-16 18:48:20 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-16 18:48:20 --> Final output sent to browser
DEBUG - 2021-06-16 18:48:20 --> Total execution time: 0.0226
ERROR - 2021-06-16 18:48:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:48:21 --> Config Class Initialized
INFO - 2021-06-16 18:48:21 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:48:21 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:48:21 --> Utf8 Class Initialized
INFO - 2021-06-16 18:48:21 --> URI Class Initialized
INFO - 2021-06-16 18:48:21 --> Router Class Initialized
INFO - 2021-06-16 18:48:21 --> Output Class Initialized
INFO - 2021-06-16 18:48:21 --> Security Class Initialized
DEBUG - 2021-06-16 18:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:48:21 --> Input Class Initialized
INFO - 2021-06-16 18:48:21 --> Language Class Initialized
ERROR - 2021-06-16 18:48:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-16 18:48:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:48:24 --> Config Class Initialized
INFO - 2021-06-16 18:48:24 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:48:24 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:48:24 --> Utf8 Class Initialized
INFO - 2021-06-16 18:48:24 --> URI Class Initialized
INFO - 2021-06-16 18:48:24 --> Router Class Initialized
INFO - 2021-06-16 18:48:24 --> Output Class Initialized
INFO - 2021-06-16 18:48:24 --> Security Class Initialized
DEBUG - 2021-06-16 18:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:48:24 --> Input Class Initialized
INFO - 2021-06-16 18:48:24 --> Language Class Initialized
INFO - 2021-06-16 18:48:24 --> Loader Class Initialized
INFO - 2021-06-16 18:48:24 --> Helper loaded: url_helper
INFO - 2021-06-16 18:48:24 --> Helper loaded: form_helper
INFO - 2021-06-16 18:48:24 --> Helper loaded: common_helper
INFO - 2021-06-16 18:48:24 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:48:24 --> Controller Class Initialized
INFO - 2021-06-16 18:48:24 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:48:24 --> Encrypt Class Initialized
DEBUG - 2021-06-16 18:48:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-16 18:48:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-16 18:48:24 --> Email Class Initialized
INFO - 2021-06-16 18:48:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-16 18:48:24 --> Calendar Class Initialized
INFO - 2021-06-16 18:48:24 --> Model "Login_model" initialized
INFO - 2021-06-16 18:48:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-16 18:48:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:48:24 --> Config Class Initialized
INFO - 2021-06-16 18:48:24 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:48:24 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:48:24 --> Utf8 Class Initialized
INFO - 2021-06-16 18:48:24 --> URI Class Initialized
INFO - 2021-06-16 18:48:24 --> Router Class Initialized
INFO - 2021-06-16 18:48:24 --> Output Class Initialized
INFO - 2021-06-16 18:48:24 --> Security Class Initialized
DEBUG - 2021-06-16 18:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:48:24 --> Input Class Initialized
INFO - 2021-06-16 18:48:24 --> Language Class Initialized
INFO - 2021-06-16 18:48:24 --> Loader Class Initialized
INFO - 2021-06-16 18:48:24 --> Helper loaded: url_helper
INFO - 2021-06-16 18:48:24 --> Helper loaded: form_helper
INFO - 2021-06-16 18:48:24 --> Helper loaded: common_helper
INFO - 2021-06-16 18:48:24 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:48:24 --> Controller Class Initialized
INFO - 2021-06-16 18:48:24 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:48:24 --> Encrypt Class Initialized
INFO - 2021-06-16 18:48:24 --> Model "Login_model" initialized
INFO - 2021-06-16 18:48:24 --> Model "Dashboard_model" initialized
INFO - 2021-06-16 18:48:24 --> Model "Case_model" initialized
INFO - 2021-06-16 18:48:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 18:48:33 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-16 18:48:33 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-16 18:48:33 --> Final output sent to browser
DEBUG - 2021-06-16 18:48:33 --> Total execution time: 9.3945
ERROR - 2021-06-16 18:48:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:48:34 --> Config Class Initialized
INFO - 2021-06-16 18:48:34 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:48:34 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:48:34 --> Utf8 Class Initialized
INFO - 2021-06-16 18:48:34 --> URI Class Initialized
INFO - 2021-06-16 18:48:34 --> Router Class Initialized
INFO - 2021-06-16 18:48:34 --> Output Class Initialized
INFO - 2021-06-16 18:48:34 --> Security Class Initialized
DEBUG - 2021-06-16 18:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:48:34 --> Input Class Initialized
INFO - 2021-06-16 18:48:34 --> Language Class Initialized
ERROR - 2021-06-16 18:48:34 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-16 18:51:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:51:01 --> Config Class Initialized
INFO - 2021-06-16 18:51:01 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:51:01 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:51:01 --> Utf8 Class Initialized
INFO - 2021-06-16 18:51:01 --> URI Class Initialized
INFO - 2021-06-16 18:51:01 --> Router Class Initialized
INFO - 2021-06-16 18:51:01 --> Output Class Initialized
INFO - 2021-06-16 18:51:01 --> Security Class Initialized
DEBUG - 2021-06-16 18:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:51:01 --> Input Class Initialized
INFO - 2021-06-16 18:51:01 --> Language Class Initialized
INFO - 2021-06-16 18:51:01 --> Loader Class Initialized
INFO - 2021-06-16 18:51:01 --> Helper loaded: url_helper
INFO - 2021-06-16 18:51:01 --> Helper loaded: form_helper
INFO - 2021-06-16 18:51:01 --> Helper loaded: common_helper
INFO - 2021-06-16 18:51:01 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:51:01 --> Controller Class Initialized
INFO - 2021-06-16 18:51:01 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:51:01 --> Encrypt Class Initialized
INFO - 2021-06-16 18:51:01 --> Model "Patient_model" initialized
INFO - 2021-06-16 18:51:01 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 18:51:01 --> Model "Referredby_model" initialized
INFO - 2021-06-16 18:51:01 --> Model "Prefix_master" initialized
INFO - 2021-06-16 18:51:01 --> Model "Hospital_model" initialized
INFO - 2021-06-16 18:51:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 18:51:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-16 18:51:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-16 18:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:51:07 --> Config Class Initialized
INFO - 2021-06-16 18:51:07 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:51:07 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:51:07 --> Utf8 Class Initialized
INFO - 2021-06-16 18:51:07 --> URI Class Initialized
INFO - 2021-06-16 18:51:07 --> Router Class Initialized
INFO - 2021-06-16 18:51:07 --> Output Class Initialized
INFO - 2021-06-16 18:51:07 --> Security Class Initialized
DEBUG - 2021-06-16 18:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:51:07 --> Input Class Initialized
INFO - 2021-06-16 18:51:07 --> Language Class Initialized
ERROR - 2021-06-16 18:51:07 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-16 18:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:51:07 --> Config Class Initialized
INFO - 2021-06-16 18:51:07 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:51:07 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:51:07 --> Utf8 Class Initialized
INFO - 2021-06-16 18:51:07 --> URI Class Initialized
INFO - 2021-06-16 18:51:07 --> Router Class Initialized
INFO - 2021-06-16 18:51:07 --> Output Class Initialized
INFO - 2021-06-16 18:51:07 --> Security Class Initialized
DEBUG - 2021-06-16 18:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:51:07 --> Input Class Initialized
INFO - 2021-06-16 18:51:07 --> Language Class Initialized
INFO - 2021-06-16 18:51:07 --> Loader Class Initialized
INFO - 2021-06-16 18:51:07 --> Helper loaded: url_helper
INFO - 2021-06-16 18:51:07 --> Helper loaded: form_helper
INFO - 2021-06-16 18:51:07 --> Helper loaded: common_helper
INFO - 2021-06-16 18:51:07 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:51:09 --> Final output sent to browser
DEBUG - 2021-06-16 18:51:09 --> Total execution time: 5.2452
INFO - 2021-06-16 18:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:51:09 --> Controller Class Initialized
INFO - 2021-06-16 18:51:09 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:51:09 --> Encrypt Class Initialized
INFO - 2021-06-16 18:51:09 --> Model "Patient_model" initialized
INFO - 2021-06-16 18:51:09 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 18:51:09 --> Model "Referredby_model" initialized
INFO - 2021-06-16 18:51:09 --> Model "Prefix_master" initialized
INFO - 2021-06-16 18:51:09 --> Model "Hospital_model" initialized
INFO - 2021-06-16 18:51:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-16 18:51:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-16 18:51:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-16 18:51:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:51:16 --> Config Class Initialized
INFO - 2021-06-16 18:51:16 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:51:16 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:51:16 --> Utf8 Class Initialized
INFO - 2021-06-16 18:51:16 --> URI Class Initialized
INFO - 2021-06-16 18:51:16 --> Router Class Initialized
INFO - 2021-06-16 18:51:16 --> Output Class Initialized
INFO - 2021-06-16 18:51:16 --> Security Class Initialized
DEBUG - 2021-06-16 18:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:51:16 --> Input Class Initialized
INFO - 2021-06-16 18:51:16 --> Language Class Initialized
ERROR - 2021-06-16 18:51:16 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-16 18:51:17 --> Final output sent to browser
DEBUG - 2021-06-16 18:51:17 --> Total execution time: 7.5051
ERROR - 2021-06-16 18:51:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:51:38 --> Config Class Initialized
INFO - 2021-06-16 18:51:38 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:51:38 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:51:38 --> Utf8 Class Initialized
INFO - 2021-06-16 18:51:38 --> URI Class Initialized
INFO - 2021-06-16 18:51:38 --> Router Class Initialized
INFO - 2021-06-16 18:51:38 --> Output Class Initialized
INFO - 2021-06-16 18:51:38 --> Security Class Initialized
DEBUG - 2021-06-16 18:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:51:38 --> Input Class Initialized
INFO - 2021-06-16 18:51:38 --> Language Class Initialized
INFO - 2021-06-16 18:51:38 --> Loader Class Initialized
INFO - 2021-06-16 18:51:38 --> Helper loaded: url_helper
INFO - 2021-06-16 18:51:38 --> Helper loaded: form_helper
INFO - 2021-06-16 18:51:38 --> Helper loaded: common_helper
INFO - 2021-06-16 18:51:38 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:51:38 --> Controller Class Initialized
INFO - 2021-06-16 18:51:38 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:51:38 --> Encrypt Class Initialized
INFO - 2021-06-16 18:51:38 --> Model "Patient_model" initialized
INFO - 2021-06-16 18:51:38 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 18:51:38 --> Model "Prefix_master" initialized
INFO - 2021-06-16 18:51:38 --> Model "Users_model" initialized
INFO - 2021-06-16 18:51:38 --> Model "Hospital_model" initialized
INFO - 2021-06-16 18:51:38 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
INFO - 2021-06-16 18:51:39 --> Final output sent to browser
DEBUG - 2021-06-16 18:51:39 --> Total execution time: 0.7142
ERROR - 2021-06-16 18:52:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:52:21 --> Config Class Initialized
INFO - 2021-06-16 18:52:21 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:52:21 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:52:21 --> Utf8 Class Initialized
INFO - 2021-06-16 18:52:21 --> URI Class Initialized
INFO - 2021-06-16 18:52:21 --> Router Class Initialized
INFO - 2021-06-16 18:52:21 --> Output Class Initialized
INFO - 2021-06-16 18:52:21 --> Security Class Initialized
DEBUG - 2021-06-16 18:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:52:21 --> Input Class Initialized
INFO - 2021-06-16 18:52:21 --> Language Class Initialized
INFO - 2021-06-16 18:52:21 --> Loader Class Initialized
INFO - 2021-06-16 18:52:21 --> Helper loaded: url_helper
INFO - 2021-06-16 18:52:21 --> Helper loaded: form_helper
INFO - 2021-06-16 18:52:21 --> Helper loaded: common_helper
INFO - 2021-06-16 18:52:21 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:52:21 --> Controller Class Initialized
INFO - 2021-06-16 18:52:21 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:52:21 --> Encrypt Class Initialized
INFO - 2021-06-16 18:52:21 --> Model "Patient_model" initialized
INFO - 2021-06-16 18:52:21 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 18:52:21 --> Model "Prefix_master" initialized
INFO - 2021-06-16 18:52:21 --> Model "Users_model" initialized
INFO - 2021-06-16 18:52:21 --> Model "Hospital_model" initialized
INFO - 2021-06-16 18:52:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
INFO - 2021-06-16 18:52:21 --> Final output sent to browser
DEBUG - 2021-06-16 18:52:21 --> Total execution time: 0.5317
ERROR - 2021-06-16 18:52:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:52:22 --> Config Class Initialized
INFO - 2021-06-16 18:52:22 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:52:22 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:52:22 --> Utf8 Class Initialized
INFO - 2021-06-16 18:52:22 --> URI Class Initialized
INFO - 2021-06-16 18:52:22 --> Router Class Initialized
INFO - 2021-06-16 18:52:22 --> Output Class Initialized
INFO - 2021-06-16 18:52:22 --> Security Class Initialized
DEBUG - 2021-06-16 18:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:52:22 --> Input Class Initialized
INFO - 2021-06-16 18:52:22 --> Language Class Initialized
ERROR - 2021-06-16 18:52:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-16 18:52:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:52:32 --> Config Class Initialized
INFO - 2021-06-16 18:52:32 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:52:32 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:52:32 --> Utf8 Class Initialized
INFO - 2021-06-16 18:52:32 --> URI Class Initialized
INFO - 2021-06-16 18:52:32 --> Router Class Initialized
INFO - 2021-06-16 18:52:32 --> Output Class Initialized
INFO - 2021-06-16 18:52:32 --> Security Class Initialized
DEBUG - 2021-06-16 18:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:52:32 --> Input Class Initialized
INFO - 2021-06-16 18:52:32 --> Language Class Initialized
INFO - 2021-06-16 18:52:32 --> Loader Class Initialized
INFO - 2021-06-16 18:52:32 --> Helper loaded: url_helper
INFO - 2021-06-16 18:52:32 --> Helper loaded: form_helper
INFO - 2021-06-16 18:52:32 --> Helper loaded: common_helper
INFO - 2021-06-16 18:52:32 --> Database Driver Class Initialized
DEBUG - 2021-06-16 18:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-16 18:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-16 18:52:32 --> Controller Class Initialized
INFO - 2021-06-16 18:52:32 --> Form Validation Class Initialized
DEBUG - 2021-06-16 18:52:32 --> Encrypt Class Initialized
INFO - 2021-06-16 18:52:32 --> Model "Patient_model" initialized
INFO - 2021-06-16 18:52:32 --> Model "Patientcase_model" initialized
INFO - 2021-06-16 18:52:32 --> Model "Prefix_master" initialized
INFO - 2021-06-16 18:52:32 --> Model "Users_model" initialized
INFO - 2021-06-16 18:52:32 --> Model "Hospital_model" initialized
INFO - 2021-06-16 18:52:32 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-16 18:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:52:33 --> Config Class Initialized
INFO - 2021-06-16 18:52:33 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:52:33 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:52:33 --> Utf8 Class Initialized
INFO - 2021-06-16 18:52:33 --> URI Class Initialized
INFO - 2021-06-16 18:52:33 --> Router Class Initialized
INFO - 2021-06-16 18:52:33 --> Output Class Initialized
INFO - 2021-06-16 18:52:33 --> Security Class Initialized
DEBUG - 2021-06-16 18:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:52:33 --> Input Class Initialized
INFO - 2021-06-16 18:52:33 --> Language Class Initialized
ERROR - 2021-06-16 18:52:33 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-16 18:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:52:33 --> Config Class Initialized
INFO - 2021-06-16 18:52:33 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:52:33 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:52:33 --> Utf8 Class Initialized
INFO - 2021-06-16 18:52:33 --> URI Class Initialized
INFO - 2021-06-16 18:52:33 --> Router Class Initialized
INFO - 2021-06-16 18:52:33 --> Output Class Initialized
INFO - 2021-06-16 18:52:33 --> Security Class Initialized
DEBUG - 2021-06-16 18:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:52:33 --> Input Class Initialized
INFO - 2021-06-16 18:52:33 --> Language Class Initialized
ERROR - 2021-06-16 18:52:33 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-06-16 18:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-16 18:52:33 --> Config Class Initialized
INFO - 2021-06-16 18:52:33 --> Hooks Class Initialized
DEBUG - 2021-06-16 18:52:33 --> UTF-8 Support Enabled
INFO - 2021-06-16 18:52:33 --> Utf8 Class Initialized
INFO - 2021-06-16 18:52:33 --> URI Class Initialized
INFO - 2021-06-16 18:52:33 --> Router Class Initialized
INFO - 2021-06-16 18:52:33 --> Output Class Initialized
INFO - 2021-06-16 18:52:33 --> Security Class Initialized
DEBUG - 2021-06-16 18:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-16 18:52:33 --> Input Class Initialized
INFO - 2021-06-16 18:52:33 --> Language Class Initialized
ERROR - 2021-06-16 18:52:33 --> 404 Page Not Found: Karoclient/images
INFO - 2021-06-16 18:52:33 --> Final output sent to browser
DEBUG - 2021-06-16 18:52:33 --> Total execution time: 1.0895
