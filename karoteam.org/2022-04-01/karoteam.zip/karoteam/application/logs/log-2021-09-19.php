<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-19 19:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-19 19:40:16 --> Config Class Initialized
INFO - 2021-09-19 19:40:16 --> Hooks Class Initialized
DEBUG - 2021-09-19 19:40:16 --> UTF-8 Support Enabled
INFO - 2021-09-19 19:40:16 --> Utf8 Class Initialized
INFO - 2021-09-19 19:40:16 --> URI Class Initialized
INFO - 2021-09-19 19:40:16 --> Router Class Initialized
INFO - 2021-09-19 19:40:16 --> Output Class Initialized
INFO - 2021-09-19 19:40:16 --> Security Class Initialized
DEBUG - 2021-09-19 19:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-19 19:40:16 --> Input Class Initialized
INFO - 2021-09-19 19:40:16 --> Language Class Initialized
ERROR - 2021-09-19 19:40:16 --> 404 Page Not Found: Wp-content/index
