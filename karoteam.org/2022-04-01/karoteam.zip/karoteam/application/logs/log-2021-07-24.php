<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-24 04:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-24 04:29:21 --> Config Class Initialized
INFO - 2021-07-24 04:29:21 --> Hooks Class Initialized
DEBUG - 2021-07-24 04:29:21 --> UTF-8 Support Enabled
INFO - 2021-07-24 04:29:21 --> Utf8 Class Initialized
INFO - 2021-07-24 04:29:21 --> URI Class Initialized
DEBUG - 2021-07-24 04:29:21 --> No URI present. Default controller set.
INFO - 2021-07-24 04:29:21 --> Router Class Initialized
INFO - 2021-07-24 04:29:21 --> Output Class Initialized
INFO - 2021-07-24 04:29:21 --> Security Class Initialized
DEBUG - 2021-07-24 04:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 04:29:21 --> Input Class Initialized
INFO - 2021-07-24 04:29:21 --> Language Class Initialized
INFO - 2021-07-24 04:29:21 --> Loader Class Initialized
INFO - 2021-07-24 04:29:21 --> Helper loaded: url_helper
INFO - 2021-07-24 04:29:21 --> Helper loaded: form_helper
INFO - 2021-07-24 04:29:21 --> Helper loaded: common_helper
INFO - 2021-07-24 04:29:22 --> Database Driver Class Initialized
DEBUG - 2021-07-24 04:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 04:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 04:29:22 --> Controller Class Initialized
INFO - 2021-07-24 04:29:22 --> Form Validation Class Initialized
DEBUG - 2021-07-24 04:29:22 --> Encrypt Class Initialized
DEBUG - 2021-07-24 04:29:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-24 04:29:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-24 04:29:22 --> Email Class Initialized
INFO - 2021-07-24 04:29:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-24 04:29:22 --> Calendar Class Initialized
INFO - 2021-07-24 04:29:22 --> Model "Login_model" initialized
INFO - 2021-07-24 04:29:22 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-24 04:29:22 --> Final output sent to browser
DEBUG - 2021-07-24 04:29:22 --> Total execution time: 0.0478
ERROR - 2021-07-24 07:01:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-24 07:01:29 --> Config Class Initialized
INFO - 2021-07-24 07:01:29 --> Hooks Class Initialized
DEBUG - 2021-07-24 07:01:29 --> UTF-8 Support Enabled
INFO - 2021-07-24 07:01:29 --> Utf8 Class Initialized
INFO - 2021-07-24 07:01:29 --> URI Class Initialized
DEBUG - 2021-07-24 07:01:29 --> No URI present. Default controller set.
INFO - 2021-07-24 07:01:29 --> Router Class Initialized
INFO - 2021-07-24 07:01:29 --> Output Class Initialized
INFO - 2021-07-24 07:01:29 --> Security Class Initialized
DEBUG - 2021-07-24 07:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 07:01:29 --> Input Class Initialized
INFO - 2021-07-24 07:01:29 --> Language Class Initialized
INFO - 2021-07-24 07:01:29 --> Loader Class Initialized
INFO - 2021-07-24 07:01:29 --> Helper loaded: url_helper
INFO - 2021-07-24 07:01:29 --> Helper loaded: form_helper
INFO - 2021-07-24 07:01:29 --> Helper loaded: common_helper
INFO - 2021-07-24 07:01:29 --> Database Driver Class Initialized
DEBUG - 2021-07-24 07:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 07:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 07:01:29 --> Controller Class Initialized
INFO - 2021-07-24 07:01:29 --> Form Validation Class Initialized
DEBUG - 2021-07-24 07:01:29 --> Encrypt Class Initialized
DEBUG - 2021-07-24 07:01:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-24 07:01:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-24 07:01:29 --> Email Class Initialized
INFO - 2021-07-24 07:01:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-24 07:01:29 --> Calendar Class Initialized
INFO - 2021-07-24 07:01:29 --> Model "Login_model" initialized
INFO - 2021-07-24 07:01:29 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-24 07:01:29 --> Final output sent to browser
DEBUG - 2021-07-24 07:01:29 --> Total execution time: 0.0484
ERROR - 2021-07-24 12:34:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-24 12:34:04 --> Config Class Initialized
INFO - 2021-07-24 12:34:04 --> Hooks Class Initialized
DEBUG - 2021-07-24 12:34:04 --> UTF-8 Support Enabled
INFO - 2021-07-24 12:34:04 --> Utf8 Class Initialized
INFO - 2021-07-24 12:34:04 --> URI Class Initialized
DEBUG - 2021-07-24 12:34:04 --> No URI present. Default controller set.
INFO - 2021-07-24 12:34:04 --> Router Class Initialized
INFO - 2021-07-24 12:34:04 --> Output Class Initialized
INFO - 2021-07-24 12:34:04 --> Security Class Initialized
DEBUG - 2021-07-24 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 12:34:04 --> Input Class Initialized
INFO - 2021-07-24 12:34:04 --> Language Class Initialized
INFO - 2021-07-24 12:34:04 --> Loader Class Initialized
INFO - 2021-07-24 12:34:04 --> Helper loaded: url_helper
INFO - 2021-07-24 12:34:04 --> Helper loaded: form_helper
INFO - 2021-07-24 12:34:04 --> Helper loaded: common_helper
INFO - 2021-07-24 12:34:04 --> Database Driver Class Initialized
DEBUG - 2021-07-24 12:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 12:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 12:34:04 --> Controller Class Initialized
INFO - 2021-07-24 12:34:04 --> Form Validation Class Initialized
DEBUG - 2021-07-24 12:34:04 --> Encrypt Class Initialized
DEBUG - 2021-07-24 12:34:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-24 12:34:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-24 12:34:04 --> Email Class Initialized
INFO - 2021-07-24 12:34:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-24 12:34:04 --> Calendar Class Initialized
INFO - 2021-07-24 12:34:04 --> Model "Login_model" initialized
INFO - 2021-07-24 12:34:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-24 12:34:04 --> Final output sent to browser
DEBUG - 2021-07-24 12:34:04 --> Total execution time: 0.0415
ERROR - 2021-07-24 14:23:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-24 14:23:59 --> Config Class Initialized
INFO - 2021-07-24 14:23:59 --> Hooks Class Initialized
DEBUG - 2021-07-24 14:23:59 --> UTF-8 Support Enabled
INFO - 2021-07-24 14:23:59 --> Utf8 Class Initialized
INFO - 2021-07-24 14:23:59 --> URI Class Initialized
DEBUG - 2021-07-24 14:23:59 --> No URI present. Default controller set.
INFO - 2021-07-24 14:23:59 --> Router Class Initialized
INFO - 2021-07-24 14:23:59 --> Output Class Initialized
INFO - 2021-07-24 14:23:59 --> Security Class Initialized
DEBUG - 2021-07-24 14:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 14:23:59 --> Input Class Initialized
INFO - 2021-07-24 14:23:59 --> Language Class Initialized
INFO - 2021-07-24 14:23:59 --> Loader Class Initialized
INFO - 2021-07-24 14:23:59 --> Helper loaded: url_helper
INFO - 2021-07-24 14:23:59 --> Helper loaded: form_helper
INFO - 2021-07-24 14:23:59 --> Helper loaded: common_helper
INFO - 2021-07-24 14:23:59 --> Database Driver Class Initialized
DEBUG - 2021-07-24 14:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 14:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 14:23:59 --> Controller Class Initialized
INFO - 2021-07-24 14:23:59 --> Form Validation Class Initialized
DEBUG - 2021-07-24 14:23:59 --> Encrypt Class Initialized
DEBUG - 2021-07-24 14:23:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-24 14:23:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-24 14:23:59 --> Email Class Initialized
INFO - 2021-07-24 14:23:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-24 14:23:59 --> Calendar Class Initialized
INFO - 2021-07-24 14:23:59 --> Model "Login_model" initialized
INFO - 2021-07-24 14:23:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-24 14:23:59 --> Final output sent to browser
DEBUG - 2021-07-24 14:23:59 --> Total execution time: 0.0555
ERROR - 2021-07-24 14:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-24 14:48:40 --> Config Class Initialized
INFO - 2021-07-24 14:48:40 --> Hooks Class Initialized
DEBUG - 2021-07-24 14:48:40 --> UTF-8 Support Enabled
INFO - 2021-07-24 14:48:40 --> Utf8 Class Initialized
INFO - 2021-07-24 14:48:40 --> URI Class Initialized
DEBUG - 2021-07-24 14:48:40 --> No URI present. Default controller set.
INFO - 2021-07-24 14:48:40 --> Router Class Initialized
INFO - 2021-07-24 14:48:40 --> Output Class Initialized
INFO - 2021-07-24 14:48:40 --> Security Class Initialized
DEBUG - 2021-07-24 14:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-24 14:48:40 --> Input Class Initialized
INFO - 2021-07-24 14:48:40 --> Language Class Initialized
INFO - 2021-07-24 14:48:40 --> Loader Class Initialized
INFO - 2021-07-24 14:48:40 --> Helper loaded: url_helper
INFO - 2021-07-24 14:48:40 --> Helper loaded: form_helper
INFO - 2021-07-24 14:48:40 --> Helper loaded: common_helper
INFO - 2021-07-24 14:48:40 --> Database Driver Class Initialized
DEBUG - 2021-07-24 14:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-24 14:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-24 14:48:40 --> Controller Class Initialized
INFO - 2021-07-24 14:48:40 --> Form Validation Class Initialized
DEBUG - 2021-07-24 14:48:40 --> Encrypt Class Initialized
DEBUG - 2021-07-24 14:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-24 14:48:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-24 14:48:40 --> Email Class Initialized
INFO - 2021-07-24 14:48:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-24 14:48:40 --> Calendar Class Initialized
INFO - 2021-07-24 14:48:40 --> Model "Login_model" initialized
INFO - 2021-07-24 14:48:40 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-24 14:48:40 --> Final output sent to browser
DEBUG - 2021-07-24 14:48:40 --> Total execution time: 0.0576
