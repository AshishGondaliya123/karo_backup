<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-22 01:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 01:31:55 --> Config Class Initialized
INFO - 2022-03-22 01:31:55 --> Hooks Class Initialized
DEBUG - 2022-03-22 01:31:55 --> UTF-8 Support Enabled
INFO - 2022-03-22 01:31:55 --> Utf8 Class Initialized
INFO - 2022-03-22 01:31:55 --> URI Class Initialized
DEBUG - 2022-03-22 01:31:55 --> No URI present. Default controller set.
INFO - 2022-03-22 01:31:55 --> Router Class Initialized
INFO - 2022-03-22 01:31:55 --> Output Class Initialized
INFO - 2022-03-22 01:31:55 --> Security Class Initialized
DEBUG - 2022-03-22 01:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 01:31:55 --> Input Class Initialized
INFO - 2022-03-22 01:31:55 --> Language Class Initialized
INFO - 2022-03-22 01:31:55 --> Loader Class Initialized
INFO - 2022-03-22 01:31:55 --> Helper loaded: url_helper
INFO - 2022-03-22 01:31:55 --> Helper loaded: form_helper
INFO - 2022-03-22 01:31:55 --> Helper loaded: common_helper
INFO - 2022-03-22 01:31:55 --> Database Driver Class Initialized
DEBUG - 2022-03-22 01:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 01:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 01:31:55 --> Controller Class Initialized
INFO - 2022-03-22 01:31:55 --> Form Validation Class Initialized
DEBUG - 2022-03-22 01:31:55 --> Encrypt Class Initialized
DEBUG - 2022-03-22 01:31:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 01:31:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 01:31:55 --> Email Class Initialized
INFO - 2022-03-22 01:31:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 01:31:55 --> Calendar Class Initialized
INFO - 2022-03-22 01:31:55 --> Model "Login_model" initialized
INFO - 2022-03-22 01:31:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 01:31:55 --> Final output sent to browser
DEBUG - 2022-03-22 01:31:55 --> Total execution time: 0.0314
ERROR - 2022-03-22 02:41:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:41:38 --> Config Class Initialized
INFO - 2022-03-22 02:41:38 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:41:38 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:41:38 --> Utf8 Class Initialized
INFO - 2022-03-22 02:41:38 --> URI Class Initialized
DEBUG - 2022-03-22 02:41:38 --> No URI present. Default controller set.
INFO - 2022-03-22 02:41:38 --> Router Class Initialized
INFO - 2022-03-22 02:41:38 --> Output Class Initialized
INFO - 2022-03-22 02:41:38 --> Security Class Initialized
DEBUG - 2022-03-22 02:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:41:38 --> Input Class Initialized
INFO - 2022-03-22 02:41:38 --> Language Class Initialized
INFO - 2022-03-22 02:41:38 --> Loader Class Initialized
INFO - 2022-03-22 02:41:38 --> Helper loaded: url_helper
INFO - 2022-03-22 02:41:38 --> Helper loaded: form_helper
INFO - 2022-03-22 02:41:38 --> Helper loaded: common_helper
INFO - 2022-03-22 02:41:38 --> Database Driver Class Initialized
DEBUG - 2022-03-22 02:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:41:38 --> Controller Class Initialized
INFO - 2022-03-22 02:41:38 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:41:38 --> Encrypt Class Initialized
DEBUG - 2022-03-22 02:41:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 02:41:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 02:41:38 --> Email Class Initialized
INFO - 2022-03-22 02:41:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 02:41:38 --> Calendar Class Initialized
INFO - 2022-03-22 02:41:38 --> Model "Login_model" initialized
INFO - 2022-03-22 02:41:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 02:41:38 --> Final output sent to browser
DEBUG - 2022-03-22 02:41:38 --> Total execution time: 0.0304
ERROR - 2022-03-22 02:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:42:40 --> Config Class Initialized
INFO - 2022-03-22 02:42:40 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:42:40 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:42:40 --> Utf8 Class Initialized
INFO - 2022-03-22 02:42:40 --> URI Class Initialized
INFO - 2022-03-22 02:42:40 --> Router Class Initialized
INFO - 2022-03-22 02:42:40 --> Output Class Initialized
INFO - 2022-03-22 02:42:40 --> Security Class Initialized
DEBUG - 2022-03-22 02:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:42:40 --> Input Class Initialized
INFO - 2022-03-22 02:42:40 --> Language Class Initialized
INFO - 2022-03-22 02:42:40 --> Loader Class Initialized
INFO - 2022-03-22 02:42:40 --> Helper loaded: url_helper
INFO - 2022-03-22 02:42:40 --> Helper loaded: form_helper
INFO - 2022-03-22 02:42:40 --> Helper loaded: common_helper
INFO - 2022-03-22 02:42:40 --> Database Driver Class Initialized
DEBUG - 2022-03-22 02:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:42:40 --> Controller Class Initialized
INFO - 2022-03-22 02:42:40 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:42:40 --> Encrypt Class Initialized
DEBUG - 2022-03-22 02:42:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 02:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 02:42:40 --> Email Class Initialized
INFO - 2022-03-22 02:42:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 02:42:40 --> Calendar Class Initialized
INFO - 2022-03-22 02:42:40 --> Model "Login_model" initialized
INFO - 2022-03-22 02:42:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-22 02:42:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:42:41 --> Config Class Initialized
INFO - 2022-03-22 02:42:41 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:42:41 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:42:41 --> Utf8 Class Initialized
INFO - 2022-03-22 02:42:41 --> URI Class Initialized
INFO - 2022-03-22 02:42:41 --> Router Class Initialized
INFO - 2022-03-22 02:42:41 --> Output Class Initialized
INFO - 2022-03-22 02:42:41 --> Security Class Initialized
DEBUG - 2022-03-22 02:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:42:41 --> Input Class Initialized
INFO - 2022-03-22 02:42:41 --> Language Class Initialized
INFO - 2022-03-22 02:42:41 --> Loader Class Initialized
INFO - 2022-03-22 02:42:41 --> Helper loaded: url_helper
INFO - 2022-03-22 02:42:41 --> Helper loaded: form_helper
INFO - 2022-03-22 02:42:41 --> Helper loaded: common_helper
INFO - 2022-03-22 02:42:41 --> Database Driver Class Initialized
DEBUG - 2022-03-22 02:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:42:41 --> Controller Class Initialized
INFO - 2022-03-22 02:42:41 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:42:41 --> Encrypt Class Initialized
INFO - 2022-03-22 02:42:41 --> Model "Login_model" initialized
INFO - 2022-03-22 02:42:41 --> Model "Dashboard_model" initialized
INFO - 2022-03-22 02:42:41 --> Model "Case_model" initialized
INFO - 2022-03-22 02:42:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 02:43:12 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-22 02:43:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 02:43:12 --> Final output sent to browser
DEBUG - 2022-03-22 02:43:12 --> Total execution time: 31.1700
ERROR - 2022-03-22 02:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:43:14 --> Config Class Initialized
INFO - 2022-03-22 02:43:14 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:43:14 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:43:14 --> Utf8 Class Initialized
INFO - 2022-03-22 02:43:14 --> URI Class Initialized
INFO - 2022-03-22 02:43:14 --> Router Class Initialized
INFO - 2022-03-22 02:43:14 --> Output Class Initialized
INFO - 2022-03-22 02:43:14 --> Security Class Initialized
DEBUG - 2022-03-22 02:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:43:14 --> Input Class Initialized
INFO - 2022-03-22 02:43:14 --> Language Class Initialized
ERROR - 2022-03-22 02:43:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-22 02:43:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:43:19 --> Config Class Initialized
INFO - 2022-03-22 02:43:19 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:43:19 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:43:19 --> Utf8 Class Initialized
INFO - 2022-03-22 02:43:19 --> URI Class Initialized
INFO - 2022-03-22 02:43:19 --> Router Class Initialized
INFO - 2022-03-22 02:43:19 --> Output Class Initialized
INFO - 2022-03-22 02:43:19 --> Security Class Initialized
DEBUG - 2022-03-22 02:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:43:19 --> Input Class Initialized
INFO - 2022-03-22 02:43:19 --> Language Class Initialized
INFO - 2022-03-22 02:43:19 --> Loader Class Initialized
INFO - 2022-03-22 02:43:19 --> Helper loaded: url_helper
INFO - 2022-03-22 02:43:19 --> Helper loaded: form_helper
INFO - 2022-03-22 02:43:19 --> Helper loaded: common_helper
INFO - 2022-03-22 02:43:19 --> Database Driver Class Initialized
DEBUG - 2022-03-22 02:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:43:19 --> Controller Class Initialized
INFO - 2022-03-22 02:43:19 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:43:19 --> Encrypt Class Initialized
INFO - 2022-03-22 02:43:19 --> Model "Patient_model" initialized
INFO - 2022-03-22 02:43:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 02:43:19 --> Model "Referredby_model" initialized
INFO - 2022-03-22 02:43:19 --> Model "Prefix_master" initialized
INFO - 2022-03-22 02:43:19 --> Model "Hospital_model" initialized
INFO - 2022-03-22 02:43:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 02:43:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-22 02:43:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-22 02:43:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:43:31 --> Config Class Initialized
INFO - 2022-03-22 02:43:31 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:43:31 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:43:31 --> Utf8 Class Initialized
INFO - 2022-03-22 02:43:31 --> URI Class Initialized
INFO - 2022-03-22 02:43:31 --> Router Class Initialized
INFO - 2022-03-22 02:43:31 --> Output Class Initialized
INFO - 2022-03-22 02:43:31 --> Security Class Initialized
DEBUG - 2022-03-22 02:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:43:31 --> Input Class Initialized
INFO - 2022-03-22 02:43:31 --> Language Class Initialized
ERROR - 2022-03-22 02:43:31 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-22 02:43:32 --> Final output sent to browser
DEBUG - 2022-03-22 02:43:32 --> Total execution time: 10.4068
ERROR - 2022-03-22 02:44:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:44:28 --> Config Class Initialized
INFO - 2022-03-22 02:44:28 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:44:28 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:44:28 --> Utf8 Class Initialized
INFO - 2022-03-22 02:44:28 --> URI Class Initialized
INFO - 2022-03-22 02:44:28 --> Router Class Initialized
INFO - 2022-03-22 02:44:28 --> Output Class Initialized
INFO - 2022-03-22 02:44:28 --> Security Class Initialized
DEBUG - 2022-03-22 02:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:44:28 --> Input Class Initialized
INFO - 2022-03-22 02:44:28 --> Language Class Initialized
INFO - 2022-03-22 02:44:28 --> Loader Class Initialized
INFO - 2022-03-22 02:44:28 --> Helper loaded: url_helper
INFO - 2022-03-22 02:44:28 --> Helper loaded: form_helper
INFO - 2022-03-22 02:44:28 --> Helper loaded: common_helper
INFO - 2022-03-22 02:44:28 --> Database Driver Class Initialized
DEBUG - 2022-03-22 02:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:44:28 --> Controller Class Initialized
INFO - 2022-03-22 02:44:28 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:44:28 --> Encrypt Class Initialized
INFO - 2022-03-22 02:44:28 --> Model "Patient_model" initialized
INFO - 2022-03-22 02:44:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 02:44:28 --> Model "Referredby_model" initialized
INFO - 2022-03-22 02:44:28 --> Model "Prefix_master" initialized
INFO - 2022-03-22 02:44:28 --> Model "Hospital_model" initialized
INFO - 2022-03-22 02:44:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 02:44:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 02:44:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 02:44:28 --> Final output sent to browser
DEBUG - 2022-03-22 02:44:28 --> Total execution time: 0.1622
ERROR - 2022-03-22 02:44:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:44:29 --> Config Class Initialized
INFO - 2022-03-22 02:44:29 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:44:29 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:44:29 --> Utf8 Class Initialized
INFO - 2022-03-22 02:44:29 --> URI Class Initialized
INFO - 2022-03-22 02:44:29 --> Router Class Initialized
INFO - 2022-03-22 02:44:29 --> Output Class Initialized
INFO - 2022-03-22 02:44:29 --> Security Class Initialized
DEBUG - 2022-03-22 02:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:44:29 --> Input Class Initialized
INFO - 2022-03-22 02:44:29 --> Language Class Initialized
ERROR - 2022-03-22 02:44:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-22 02:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:48:06 --> Config Class Initialized
INFO - 2022-03-22 02:48:06 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:48:06 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:48:06 --> Utf8 Class Initialized
INFO - 2022-03-22 02:48:06 --> URI Class Initialized
INFO - 2022-03-22 02:48:06 --> Router Class Initialized
INFO - 2022-03-22 02:48:06 --> Output Class Initialized
INFO - 2022-03-22 02:48:06 --> Security Class Initialized
DEBUG - 2022-03-22 02:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:48:06 --> Input Class Initialized
INFO - 2022-03-22 02:48:06 --> Language Class Initialized
INFO - 2022-03-22 02:48:06 --> Loader Class Initialized
INFO - 2022-03-22 02:48:06 --> Helper loaded: url_helper
INFO - 2022-03-22 02:48:06 --> Helper loaded: form_helper
INFO - 2022-03-22 02:48:06 --> Helper loaded: common_helper
INFO - 2022-03-22 02:48:06 --> Database Driver Class Initialized
DEBUG - 2022-03-22 02:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:48:06 --> Controller Class Initialized
INFO - 2022-03-22 02:48:06 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:48:06 --> Encrypt Class Initialized
INFO - 2022-03-22 02:48:06 --> Model "Patient_model" initialized
INFO - 2022-03-22 02:48:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 02:48:06 --> Model "Referredby_model" initialized
INFO - 2022-03-22 02:48:06 --> Model "Prefix_master" initialized
INFO - 2022-03-22 02:48:06 --> Model "Hospital_model" initialized
INFO - 2022-03-22 02:48:06 --> Final output sent to browser
DEBUG - 2022-03-22 02:48:06 --> Total execution time: 0.0414
ERROR - 2022-03-22 02:48:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:48:26 --> Config Class Initialized
INFO - 2022-03-22 02:48:26 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:48:26 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:48:26 --> Utf8 Class Initialized
INFO - 2022-03-22 02:48:26 --> URI Class Initialized
INFO - 2022-03-22 02:48:26 --> Router Class Initialized
INFO - 2022-03-22 02:48:26 --> Output Class Initialized
INFO - 2022-03-22 02:48:26 --> Security Class Initialized
DEBUG - 2022-03-22 02:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:48:26 --> Input Class Initialized
INFO - 2022-03-22 02:48:26 --> Language Class Initialized
INFO - 2022-03-22 02:48:26 --> Loader Class Initialized
INFO - 2022-03-22 02:48:26 --> Helper loaded: url_helper
INFO - 2022-03-22 02:48:26 --> Helper loaded: form_helper
INFO - 2022-03-22 02:48:26 --> Helper loaded: common_helper
INFO - 2022-03-22 02:48:26 --> Database Driver Class Initialized
DEBUG - 2022-03-22 02:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:48:26 --> Controller Class Initialized
INFO - 2022-03-22 02:48:26 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:48:26 --> Encrypt Class Initialized
INFO - 2022-03-22 02:48:26 --> Model "Patient_model" initialized
INFO - 2022-03-22 02:48:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 02:48:26 --> Model "Referredby_model" initialized
INFO - 2022-03-22 02:48:26 --> Model "Prefix_master" initialized
INFO - 2022-03-22 02:48:26 --> Model "Hospital_model" initialized
INFO - 2022-03-22 02:48:26 --> Final output sent to browser
DEBUG - 2022-03-22 02:48:26 --> Total execution time: 0.0414
ERROR - 2022-03-22 02:57:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:57:24 --> Config Class Initialized
INFO - 2022-03-22 02:57:24 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:57:24 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:57:24 --> Utf8 Class Initialized
INFO - 2022-03-22 02:57:24 --> URI Class Initialized
INFO - 2022-03-22 02:57:24 --> Router Class Initialized
INFO - 2022-03-22 02:57:24 --> Output Class Initialized
INFO - 2022-03-22 02:57:24 --> Security Class Initialized
DEBUG - 2022-03-22 02:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:57:24 --> Input Class Initialized
INFO - 2022-03-22 02:57:24 --> Language Class Initialized
INFO - 2022-03-22 02:57:24 --> Loader Class Initialized
INFO - 2022-03-22 02:57:24 --> Helper loaded: url_helper
INFO - 2022-03-22 02:57:24 --> Helper loaded: form_helper
INFO - 2022-03-22 02:57:24 --> Helper loaded: common_helper
INFO - 2022-03-22 02:57:24 --> Database Driver Class Initialized
ERROR - 2022-03-22 02:57:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:57:24 --> Config Class Initialized
INFO - 2022-03-22 02:57:24 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:57:24 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:57:24 --> Utf8 Class Initialized
INFO - 2022-03-22 02:57:24 --> URI Class Initialized
INFO - 2022-03-22 02:57:24 --> Router Class Initialized
INFO - 2022-03-22 02:57:24 --> Output Class Initialized
INFO - 2022-03-22 02:57:24 --> Security Class Initialized
DEBUG - 2022-03-22 02:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:57:24 --> Input Class Initialized
INFO - 2022-03-22 02:57:24 --> Language Class Initialized
INFO - 2022-03-22 02:57:24 --> Loader Class Initialized
INFO - 2022-03-22 02:57:24 --> Helper loaded: url_helper
INFO - 2022-03-22 02:57:24 --> Helper loaded: form_helper
INFO - 2022-03-22 02:57:24 --> Helper loaded: common_helper
INFO - 2022-03-22 02:57:24 --> Database Driver Class Initialized
DEBUG - 2022-03-22 02:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:57:25 --> Controller Class Initialized
INFO - 2022-03-22 02:57:25 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:57:25 --> Encrypt Class Initialized
DEBUG - 2022-03-22 02:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:57:25 --> Model "Patient_model" initialized
INFO - 2022-03-22 02:57:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 02:57:25 --> Model "Referredby_model" initialized
INFO - 2022-03-22 02:57:25 --> Model "Prefix_master" initialized
INFO - 2022-03-22 02:57:25 --> Model "Hospital_model" initialized
INFO - 2022-03-22 02:57:25 --> Final output sent to browser
DEBUG - 2022-03-22 02:57:25 --> Total execution time: 0.8262
INFO - 2022-03-22 02:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:57:25 --> Controller Class Initialized
INFO - 2022-03-22 02:57:25 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:57:25 --> Encrypt Class Initialized
INFO - 2022-03-22 02:57:25 --> Model "Patient_model" initialized
INFO - 2022-03-22 02:57:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 02:57:25 --> Model "Referredby_model" initialized
INFO - 2022-03-22 02:57:25 --> Model "Prefix_master" initialized
INFO - 2022-03-22 02:57:25 --> Model "Hospital_model" initialized
INFO - 2022-03-22 02:57:25 --> Final output sent to browser
DEBUG - 2022-03-22 02:57:25 --> Total execution time: 0.7499
ERROR - 2022-03-22 02:59:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 02:59:39 --> Config Class Initialized
INFO - 2022-03-22 02:59:39 --> Hooks Class Initialized
DEBUG - 2022-03-22 02:59:39 --> UTF-8 Support Enabled
INFO - 2022-03-22 02:59:39 --> Utf8 Class Initialized
INFO - 2022-03-22 02:59:39 --> URI Class Initialized
INFO - 2022-03-22 02:59:39 --> Router Class Initialized
INFO - 2022-03-22 02:59:39 --> Output Class Initialized
INFO - 2022-03-22 02:59:39 --> Security Class Initialized
DEBUG - 2022-03-22 02:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 02:59:39 --> Input Class Initialized
INFO - 2022-03-22 02:59:39 --> Language Class Initialized
INFO - 2022-03-22 02:59:39 --> Loader Class Initialized
INFO - 2022-03-22 02:59:39 --> Helper loaded: url_helper
INFO - 2022-03-22 02:59:39 --> Helper loaded: form_helper
INFO - 2022-03-22 02:59:39 --> Helper loaded: common_helper
INFO - 2022-03-22 02:59:39 --> Database Driver Class Initialized
DEBUG - 2022-03-22 02:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 02:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 02:59:39 --> Controller Class Initialized
INFO - 2022-03-22 02:59:39 --> Form Validation Class Initialized
DEBUG - 2022-03-22 02:59:39 --> Encrypt Class Initialized
INFO - 2022-03-22 02:59:39 --> Model "Patient_model" initialized
INFO - 2022-03-22 02:59:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 02:59:39 --> Model "Referredby_model" initialized
INFO - 2022-03-22 02:59:39 --> Model "Prefix_master" initialized
INFO - 2022-03-22 02:59:39 --> Model "Hospital_model" initialized
INFO - 2022-03-22 02:59:39 --> Final output sent to browser
DEBUG - 2022-03-22 02:59:39 --> Total execution time: 0.0728
ERROR - 2022-03-22 03:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 03:12:18 --> Config Class Initialized
INFO - 2022-03-22 03:12:18 --> Hooks Class Initialized
DEBUG - 2022-03-22 03:12:18 --> UTF-8 Support Enabled
INFO - 2022-03-22 03:12:18 --> Utf8 Class Initialized
INFO - 2022-03-22 03:12:18 --> URI Class Initialized
INFO - 2022-03-22 03:12:18 --> Router Class Initialized
INFO - 2022-03-22 03:12:18 --> Output Class Initialized
INFO - 2022-03-22 03:12:18 --> Security Class Initialized
DEBUG - 2022-03-22 03:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 03:12:18 --> Input Class Initialized
INFO - 2022-03-22 03:12:18 --> Language Class Initialized
INFO - 2022-03-22 03:12:18 --> Loader Class Initialized
INFO - 2022-03-22 03:12:18 --> Helper loaded: url_helper
INFO - 2022-03-22 03:12:18 --> Helper loaded: form_helper
INFO - 2022-03-22 03:12:18 --> Helper loaded: common_helper
INFO - 2022-03-22 03:12:18 --> Database Driver Class Initialized
DEBUG - 2022-03-22 03:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 03:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 03:12:18 --> Controller Class Initialized
INFO - 2022-03-22 03:12:18 --> Form Validation Class Initialized
DEBUG - 2022-03-22 03:12:18 --> Encrypt Class Initialized
INFO - 2022-03-22 03:12:18 --> Model "Patient_model" initialized
INFO - 2022-03-22 03:12:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 03:12:18 --> Model "Referredby_model" initialized
INFO - 2022-03-22 03:12:18 --> Model "Prefix_master" initialized
INFO - 2022-03-22 03:12:18 --> Model "Hospital_model" initialized
INFO - 2022-03-22 03:12:18 --> Final output sent to browser
DEBUG - 2022-03-22 03:12:18 --> Total execution time: 0.0320
ERROR - 2022-03-22 04:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 04:15:52 --> Config Class Initialized
INFO - 2022-03-22 04:15:52 --> Hooks Class Initialized
DEBUG - 2022-03-22 04:15:52 --> UTF-8 Support Enabled
INFO - 2022-03-22 04:15:52 --> Utf8 Class Initialized
INFO - 2022-03-22 04:15:52 --> URI Class Initialized
INFO - 2022-03-22 04:15:52 --> Router Class Initialized
INFO - 2022-03-22 04:15:52 --> Output Class Initialized
INFO - 2022-03-22 04:15:52 --> Security Class Initialized
DEBUG - 2022-03-22 04:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 04:15:52 --> Input Class Initialized
INFO - 2022-03-22 04:15:52 --> Language Class Initialized
INFO - 2022-03-22 04:15:52 --> Loader Class Initialized
INFO - 2022-03-22 04:15:52 --> Helper loaded: url_helper
INFO - 2022-03-22 04:15:52 --> Helper loaded: form_helper
INFO - 2022-03-22 04:15:52 --> Helper loaded: common_helper
INFO - 2022-03-22 04:15:52 --> Database Driver Class Initialized
DEBUG - 2022-03-22 04:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 04:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 04:15:52 --> Controller Class Initialized
INFO - 2022-03-22 04:15:52 --> Form Validation Class Initialized
DEBUG - 2022-03-22 04:15:52 --> Encrypt Class Initialized
INFO - 2022-03-22 04:15:52 --> Model "Patient_model" initialized
INFO - 2022-03-22 04:15:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 04:15:52 --> Model "Referredby_model" initialized
INFO - 2022-03-22 04:15:52 --> Model "Prefix_master" initialized
INFO - 2022-03-22 04:15:52 --> Model "Hospital_model" initialized
INFO - 2022-03-22 04:15:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 04:15:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 04:15:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 04:15:52 --> Final output sent to browser
DEBUG - 2022-03-22 04:15:52 --> Total execution time: 0.2159
ERROR - 2022-03-22 04:15:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 04:15:54 --> Config Class Initialized
INFO - 2022-03-22 04:15:54 --> Hooks Class Initialized
DEBUG - 2022-03-22 04:15:54 --> UTF-8 Support Enabled
INFO - 2022-03-22 04:15:54 --> Utf8 Class Initialized
INFO - 2022-03-22 04:15:54 --> URI Class Initialized
INFO - 2022-03-22 04:15:54 --> Router Class Initialized
INFO - 2022-03-22 04:15:54 --> Output Class Initialized
INFO - 2022-03-22 04:15:54 --> Security Class Initialized
DEBUG - 2022-03-22 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 04:15:54 --> Input Class Initialized
INFO - 2022-03-22 04:15:54 --> Language Class Initialized
ERROR - 2022-03-22 04:15:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-22 05:08:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:08:54 --> Config Class Initialized
INFO - 2022-03-22 05:08:54 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:08:54 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:08:54 --> Utf8 Class Initialized
INFO - 2022-03-22 05:08:54 --> URI Class Initialized
INFO - 2022-03-22 05:08:54 --> Router Class Initialized
INFO - 2022-03-22 05:08:54 --> Output Class Initialized
INFO - 2022-03-22 05:08:54 --> Security Class Initialized
DEBUG - 2022-03-22 05:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:08:54 --> Input Class Initialized
INFO - 2022-03-22 05:08:54 --> Language Class Initialized
INFO - 2022-03-22 05:08:54 --> Loader Class Initialized
INFO - 2022-03-22 05:08:54 --> Helper loaded: url_helper
INFO - 2022-03-22 05:08:54 --> Helper loaded: form_helper
INFO - 2022-03-22 05:08:54 --> Helper loaded: common_helper
INFO - 2022-03-22 05:08:54 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:08:54 --> Controller Class Initialized
INFO - 2022-03-22 05:08:54 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:08:54 --> Encrypt Class Initialized
DEBUG - 2022-03-22 05:08:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 05:08:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 05:08:54 --> Email Class Initialized
INFO - 2022-03-22 05:08:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 05:08:54 --> Calendar Class Initialized
INFO - 2022-03-22 05:08:54 --> Model "Login_model" initialized
INFO - 2022-03-22 05:08:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 05:08:54 --> Final output sent to browser
DEBUG - 2022-03-22 05:08:54 --> Total execution time: 0.0605
ERROR - 2022-03-22 05:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:08:56 --> Config Class Initialized
INFO - 2022-03-22 05:08:56 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:08:56 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:08:56 --> Utf8 Class Initialized
INFO - 2022-03-22 05:08:56 --> URI Class Initialized
INFO - 2022-03-22 05:08:56 --> Router Class Initialized
INFO - 2022-03-22 05:08:56 --> Output Class Initialized
INFO - 2022-03-22 05:08:56 --> Security Class Initialized
DEBUG - 2022-03-22 05:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:08:56 --> Input Class Initialized
INFO - 2022-03-22 05:08:56 --> Language Class Initialized
INFO - 2022-03-22 05:08:56 --> Loader Class Initialized
INFO - 2022-03-22 05:08:56 --> Helper loaded: url_helper
INFO - 2022-03-22 05:08:56 --> Helper loaded: form_helper
INFO - 2022-03-22 05:08:56 --> Helper loaded: common_helper
INFO - 2022-03-22 05:08:56 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:08:56 --> Controller Class Initialized
INFO - 2022-03-22 05:08:56 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:08:56 --> Encrypt Class Initialized
DEBUG - 2022-03-22 05:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 05:08:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 05:08:56 --> Email Class Initialized
INFO - 2022-03-22 05:08:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 05:08:56 --> Calendar Class Initialized
INFO - 2022-03-22 05:08:56 --> Model "Login_model" initialized
INFO - 2022-03-22 05:08:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 05:08:56 --> Final output sent to browser
DEBUG - 2022-03-22 05:08:56 --> Total execution time: 0.0443
ERROR - 2022-03-22 05:09:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:09:08 --> Config Class Initialized
INFO - 2022-03-22 05:09:08 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:09:08 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:09:08 --> Utf8 Class Initialized
INFO - 2022-03-22 05:09:08 --> URI Class Initialized
INFO - 2022-03-22 05:09:08 --> Router Class Initialized
INFO - 2022-03-22 05:09:08 --> Output Class Initialized
INFO - 2022-03-22 05:09:08 --> Security Class Initialized
DEBUG - 2022-03-22 05:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:09:08 --> Input Class Initialized
INFO - 2022-03-22 05:09:08 --> Language Class Initialized
INFO - 2022-03-22 05:09:08 --> Loader Class Initialized
INFO - 2022-03-22 05:09:08 --> Helper loaded: url_helper
INFO - 2022-03-22 05:09:08 --> Helper loaded: form_helper
INFO - 2022-03-22 05:09:08 --> Helper loaded: common_helper
INFO - 2022-03-22 05:09:08 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:09:08 --> Controller Class Initialized
INFO - 2022-03-22 05:09:08 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:09:08 --> Encrypt Class Initialized
DEBUG - 2022-03-22 05:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 05:09:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 05:09:08 --> Email Class Initialized
INFO - 2022-03-22 05:09:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 05:09:08 --> Calendar Class Initialized
INFO - 2022-03-22 05:09:08 --> Model "Login_model" initialized
INFO - 2022-03-22 05:09:08 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-22 05:09:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:09:09 --> Config Class Initialized
INFO - 2022-03-22 05:09:09 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:09:09 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:09:09 --> Utf8 Class Initialized
INFO - 2022-03-22 05:09:09 --> URI Class Initialized
INFO - 2022-03-22 05:09:09 --> Router Class Initialized
INFO - 2022-03-22 05:09:09 --> Output Class Initialized
INFO - 2022-03-22 05:09:09 --> Security Class Initialized
DEBUG - 2022-03-22 05:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:09:09 --> Input Class Initialized
INFO - 2022-03-22 05:09:09 --> Language Class Initialized
INFO - 2022-03-22 05:09:09 --> Loader Class Initialized
INFO - 2022-03-22 05:09:09 --> Helper loaded: url_helper
INFO - 2022-03-22 05:09:09 --> Helper loaded: form_helper
INFO - 2022-03-22 05:09:09 --> Helper loaded: common_helper
INFO - 2022-03-22 05:09:09 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:09:09 --> Controller Class Initialized
INFO - 2022-03-22 05:09:09 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:09:09 --> Encrypt Class Initialized
INFO - 2022-03-22 05:09:09 --> Model "Login_model" initialized
INFO - 2022-03-22 05:09:09 --> Model "Dashboard_model" initialized
INFO - 2022-03-22 05:09:09 --> Model "Case_model" initialized
INFO - 2022-03-22 05:09:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 05:09:10 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-22 05:09:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 05:09:10 --> Final output sent to browser
DEBUG - 2022-03-22 05:09:10 --> Total execution time: 0.6518
ERROR - 2022-03-22 05:16:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:16:06 --> Config Class Initialized
INFO - 2022-03-22 05:16:06 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:16:06 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:16:06 --> Utf8 Class Initialized
INFO - 2022-03-22 05:16:07 --> URI Class Initialized
INFO - 2022-03-22 05:16:07 --> Router Class Initialized
INFO - 2022-03-22 05:16:07 --> Output Class Initialized
INFO - 2022-03-22 05:16:07 --> Security Class Initialized
DEBUG - 2022-03-22 05:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:16:07 --> Input Class Initialized
INFO - 2022-03-22 05:16:07 --> Language Class Initialized
INFO - 2022-03-22 05:16:07 --> Loader Class Initialized
INFO - 2022-03-22 05:16:07 --> Helper loaded: url_helper
INFO - 2022-03-22 05:16:07 --> Helper loaded: form_helper
INFO - 2022-03-22 05:16:07 --> Helper loaded: common_helper
INFO - 2022-03-22 05:16:07 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:16:07 --> Controller Class Initialized
INFO - 2022-03-22 05:16:07 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:16:07 --> Encrypt Class Initialized
INFO - 2022-03-22 05:16:07 --> Model "Patient_model" initialized
INFO - 2022-03-22 05:16:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 05:16:07 --> Model "Referredby_model" initialized
INFO - 2022-03-22 05:16:07 --> Model "Prefix_master" initialized
INFO - 2022-03-22 05:16:07 --> Model "Hospital_model" initialized
INFO - 2022-03-22 05:16:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 05:16:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 05:16:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 05:16:07 --> Final output sent to browser
DEBUG - 2022-03-22 05:16:07 --> Total execution time: 0.1580
ERROR - 2022-03-22 05:24:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:24:49 --> Config Class Initialized
INFO - 2022-03-22 05:24:49 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:24:49 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:24:49 --> Utf8 Class Initialized
INFO - 2022-03-22 05:24:49 --> URI Class Initialized
INFO - 2022-03-22 05:24:49 --> Router Class Initialized
INFO - 2022-03-22 05:24:49 --> Output Class Initialized
INFO - 2022-03-22 05:24:49 --> Security Class Initialized
DEBUG - 2022-03-22 05:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:24:49 --> Input Class Initialized
INFO - 2022-03-22 05:24:49 --> Language Class Initialized
INFO - 2022-03-22 05:24:49 --> Loader Class Initialized
INFO - 2022-03-22 05:24:49 --> Helper loaded: url_helper
INFO - 2022-03-22 05:24:49 --> Helper loaded: form_helper
INFO - 2022-03-22 05:24:49 --> Helper loaded: common_helper
INFO - 2022-03-22 05:24:49 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:24:49 --> Controller Class Initialized
INFO - 2022-03-22 05:24:49 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:24:49 --> Encrypt Class Initialized
INFO - 2022-03-22 05:24:49 --> Model "Patient_model" initialized
INFO - 2022-03-22 05:24:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 05:24:49 --> Model "Referredby_model" initialized
INFO - 2022-03-22 05:24:49 --> Model "Prefix_master" initialized
INFO - 2022-03-22 05:24:49 --> Model "Hospital_model" initialized
INFO - 2022-03-22 05:24:49 --> Upload Class Initialized
INFO - 2022-03-22 05:24:49 --> Final output sent to browser
DEBUG - 2022-03-22 05:24:49 --> Total execution time: 0.1250
ERROR - 2022-03-22 05:53:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:53:13 --> Config Class Initialized
INFO - 2022-03-22 05:53:13 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:53:13 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:53:13 --> Utf8 Class Initialized
INFO - 2022-03-22 05:53:13 --> URI Class Initialized
INFO - 2022-03-22 05:53:13 --> Router Class Initialized
INFO - 2022-03-22 05:53:13 --> Output Class Initialized
INFO - 2022-03-22 05:53:13 --> Security Class Initialized
DEBUG - 2022-03-22 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:53:13 --> Input Class Initialized
INFO - 2022-03-22 05:53:13 --> Language Class Initialized
INFO - 2022-03-22 05:53:13 --> Loader Class Initialized
INFO - 2022-03-22 05:53:13 --> Helper loaded: url_helper
INFO - 2022-03-22 05:53:13 --> Helper loaded: form_helper
INFO - 2022-03-22 05:53:13 --> Helper loaded: common_helper
INFO - 2022-03-22 05:53:13 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:53:13 --> Controller Class Initialized
INFO - 2022-03-22 05:53:13 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:53:13 --> Encrypt Class Initialized
INFO - 2022-03-22 05:53:13 --> Model "Patient_model" initialized
INFO - 2022-03-22 05:53:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 05:53:13 --> Model "Referredby_model" initialized
INFO - 2022-03-22 05:53:13 --> Model "Prefix_master" initialized
INFO - 2022-03-22 05:53:13 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 05:53:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:53:14 --> Config Class Initialized
INFO - 2022-03-22 05:53:14 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:53:14 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:53:14 --> Utf8 Class Initialized
INFO - 2022-03-22 05:53:14 --> URI Class Initialized
INFO - 2022-03-22 05:53:14 --> Router Class Initialized
INFO - 2022-03-22 05:53:14 --> Output Class Initialized
INFO - 2022-03-22 05:53:14 --> Security Class Initialized
DEBUG - 2022-03-22 05:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:53:14 --> Input Class Initialized
INFO - 2022-03-22 05:53:14 --> Language Class Initialized
INFO - 2022-03-22 05:53:14 --> Loader Class Initialized
INFO - 2022-03-22 05:53:14 --> Helper loaded: url_helper
INFO - 2022-03-22 05:53:14 --> Helper loaded: form_helper
INFO - 2022-03-22 05:53:14 --> Helper loaded: common_helper
INFO - 2022-03-22 05:53:14 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:53:14 --> Controller Class Initialized
INFO - 2022-03-22 05:53:14 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:53:14 --> Encrypt Class Initialized
INFO - 2022-03-22 05:53:14 --> Model "Patient_model" initialized
INFO - 2022-03-22 05:53:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 05:53:14 --> Model "Referredby_model" initialized
INFO - 2022-03-22 05:53:14 --> Model "Prefix_master" initialized
INFO - 2022-03-22 05:53:14 --> Model "Hospital_model" initialized
INFO - 2022-03-22 05:53:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 05:53:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 05:53:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 05:53:14 --> Final output sent to browser
DEBUG - 2022-03-22 05:53:14 --> Total execution time: 0.1341
ERROR - 2022-03-22 05:53:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:53:15 --> Config Class Initialized
INFO - 2022-03-22 05:53:15 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:53:15 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:53:15 --> Utf8 Class Initialized
INFO - 2022-03-22 05:53:15 --> URI Class Initialized
INFO - 2022-03-22 05:53:15 --> Router Class Initialized
INFO - 2022-03-22 05:53:15 --> Output Class Initialized
INFO - 2022-03-22 05:53:15 --> Security Class Initialized
DEBUG - 2022-03-22 05:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:53:15 --> Input Class Initialized
INFO - 2022-03-22 05:53:15 --> Language Class Initialized
INFO - 2022-03-22 05:53:15 --> Loader Class Initialized
INFO - 2022-03-22 05:53:15 --> Helper loaded: url_helper
INFO - 2022-03-22 05:53:15 --> Helper loaded: form_helper
INFO - 2022-03-22 05:53:15 --> Helper loaded: common_helper
INFO - 2022-03-22 05:53:15 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:53:15 --> Controller Class Initialized
INFO - 2022-03-22 05:53:15 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:53:15 --> Encrypt Class Initialized
INFO - 2022-03-22 05:53:15 --> Model "Patient_model" initialized
INFO - 2022-03-22 05:53:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 05:53:15 --> Model "Prefix_master" initialized
INFO - 2022-03-22 05:53:15 --> Model "Users_model" initialized
INFO - 2022-03-22 05:53:15 --> Model "Hospital_model" initialized
INFO - 2022-03-22 05:53:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 05:53:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 05:53:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 05:53:16 --> Final output sent to browser
DEBUG - 2022-03-22 05:53:16 --> Total execution time: 0.5837
ERROR - 2022-03-22 05:53:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:53:32 --> Config Class Initialized
INFO - 2022-03-22 05:53:32 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:53:32 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:53:32 --> Utf8 Class Initialized
INFO - 2022-03-22 05:53:32 --> URI Class Initialized
INFO - 2022-03-22 05:53:32 --> Router Class Initialized
INFO - 2022-03-22 05:53:32 --> Output Class Initialized
INFO - 2022-03-22 05:53:32 --> Security Class Initialized
DEBUG - 2022-03-22 05:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:53:32 --> Input Class Initialized
INFO - 2022-03-22 05:53:32 --> Language Class Initialized
INFO - 2022-03-22 05:53:32 --> Loader Class Initialized
INFO - 2022-03-22 05:53:32 --> Helper loaded: url_helper
INFO - 2022-03-22 05:53:32 --> Helper loaded: form_helper
INFO - 2022-03-22 05:53:32 --> Helper loaded: common_helper
INFO - 2022-03-22 05:53:32 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:53:32 --> Controller Class Initialized
INFO - 2022-03-22 05:53:32 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:53:32 --> Encrypt Class Initialized
INFO - 2022-03-22 05:53:32 --> Model "Patient_model" initialized
INFO - 2022-03-22 05:53:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 05:53:32 --> Model "Referredby_model" initialized
INFO - 2022-03-22 05:53:32 --> Model "Prefix_master" initialized
INFO - 2022-03-22 05:53:32 --> Model "Hospital_model" initialized
INFO - 2022-03-22 05:53:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 05:53:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 05:53:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 05:53:32 --> Final output sent to browser
DEBUG - 2022-03-22 05:53:32 --> Total execution time: 0.0635
ERROR - 2022-03-22 05:56:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:56:22 --> Config Class Initialized
INFO - 2022-03-22 05:56:22 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:56:22 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:56:22 --> Utf8 Class Initialized
INFO - 2022-03-22 05:56:22 --> URI Class Initialized
INFO - 2022-03-22 05:56:22 --> Router Class Initialized
INFO - 2022-03-22 05:56:22 --> Output Class Initialized
INFO - 2022-03-22 05:56:22 --> Security Class Initialized
DEBUG - 2022-03-22 05:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:56:22 --> Input Class Initialized
INFO - 2022-03-22 05:56:22 --> Language Class Initialized
INFO - 2022-03-22 05:56:22 --> Loader Class Initialized
INFO - 2022-03-22 05:56:22 --> Helper loaded: url_helper
INFO - 2022-03-22 05:56:22 --> Helper loaded: form_helper
INFO - 2022-03-22 05:56:22 --> Helper loaded: common_helper
INFO - 2022-03-22 05:56:22 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:56:22 --> Controller Class Initialized
INFO - 2022-03-22 05:56:22 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:56:22 --> Encrypt Class Initialized
INFO - 2022-03-22 05:56:22 --> Model "Patient_model" initialized
INFO - 2022-03-22 05:56:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 05:56:22 --> Model "Referredby_model" initialized
INFO - 2022-03-22 05:56:22 --> Model "Prefix_master" initialized
INFO - 2022-03-22 05:56:22 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 05:56:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:56:23 --> Config Class Initialized
INFO - 2022-03-22 05:56:23 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:56:23 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:56:23 --> Utf8 Class Initialized
INFO - 2022-03-22 05:56:23 --> URI Class Initialized
INFO - 2022-03-22 05:56:23 --> Router Class Initialized
INFO - 2022-03-22 05:56:23 --> Output Class Initialized
INFO - 2022-03-22 05:56:23 --> Security Class Initialized
DEBUG - 2022-03-22 05:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:56:23 --> Input Class Initialized
INFO - 2022-03-22 05:56:23 --> Language Class Initialized
INFO - 2022-03-22 05:56:23 --> Loader Class Initialized
INFO - 2022-03-22 05:56:23 --> Helper loaded: url_helper
INFO - 2022-03-22 05:56:23 --> Helper loaded: form_helper
INFO - 2022-03-22 05:56:23 --> Helper loaded: common_helper
INFO - 2022-03-22 05:56:23 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:56:23 --> Controller Class Initialized
INFO - 2022-03-22 05:56:23 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:56:23 --> Encrypt Class Initialized
INFO - 2022-03-22 05:56:23 --> Model "Patient_model" initialized
INFO - 2022-03-22 05:56:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 05:56:23 --> Model "Referredby_model" initialized
INFO - 2022-03-22 05:56:23 --> Model "Prefix_master" initialized
INFO - 2022-03-22 05:56:23 --> Model "Hospital_model" initialized
INFO - 2022-03-22 05:56:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 05:56:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 05:56:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 05:56:23 --> Final output sent to browser
DEBUG - 2022-03-22 05:56:23 --> Total execution time: 0.0979
ERROR - 2022-03-22 05:56:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 05:56:25 --> Config Class Initialized
INFO - 2022-03-22 05:56:25 --> Hooks Class Initialized
DEBUG - 2022-03-22 05:56:25 --> UTF-8 Support Enabled
INFO - 2022-03-22 05:56:25 --> Utf8 Class Initialized
INFO - 2022-03-22 05:56:25 --> URI Class Initialized
INFO - 2022-03-22 05:56:25 --> Router Class Initialized
INFO - 2022-03-22 05:56:25 --> Output Class Initialized
INFO - 2022-03-22 05:56:25 --> Security Class Initialized
DEBUG - 2022-03-22 05:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 05:56:25 --> Input Class Initialized
INFO - 2022-03-22 05:56:25 --> Language Class Initialized
INFO - 2022-03-22 05:56:25 --> Loader Class Initialized
INFO - 2022-03-22 05:56:25 --> Helper loaded: url_helper
INFO - 2022-03-22 05:56:25 --> Helper loaded: form_helper
INFO - 2022-03-22 05:56:25 --> Helper loaded: common_helper
INFO - 2022-03-22 05:56:25 --> Database Driver Class Initialized
DEBUG - 2022-03-22 05:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 05:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 05:56:25 --> Controller Class Initialized
INFO - 2022-03-22 05:56:25 --> Form Validation Class Initialized
DEBUG - 2022-03-22 05:56:25 --> Encrypt Class Initialized
INFO - 2022-03-22 05:56:25 --> Model "Patient_model" initialized
INFO - 2022-03-22 05:56:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 05:56:25 --> Model "Prefix_master" initialized
INFO - 2022-03-22 05:56:25 --> Model "Users_model" initialized
INFO - 2022-03-22 05:56:25 --> Model "Hospital_model" initialized
INFO - 2022-03-22 05:56:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 05:56:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 05:56:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 05:56:28 --> Final output sent to browser
DEBUG - 2022-03-22 05:56:28 --> Total execution time: 2.8568
ERROR - 2022-03-22 06:00:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:00:51 --> Config Class Initialized
INFO - 2022-03-22 06:00:51 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:00:51 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:00:51 --> Utf8 Class Initialized
INFO - 2022-03-22 06:00:51 --> URI Class Initialized
INFO - 2022-03-22 06:00:51 --> Router Class Initialized
INFO - 2022-03-22 06:00:51 --> Output Class Initialized
INFO - 2022-03-22 06:00:51 --> Security Class Initialized
DEBUG - 2022-03-22 06:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:00:51 --> Input Class Initialized
INFO - 2022-03-22 06:00:51 --> Language Class Initialized
INFO - 2022-03-22 06:00:51 --> Loader Class Initialized
INFO - 2022-03-22 06:00:51 --> Helper loaded: url_helper
INFO - 2022-03-22 06:00:51 --> Helper loaded: form_helper
INFO - 2022-03-22 06:00:51 --> Helper loaded: common_helper
INFO - 2022-03-22 06:00:51 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:00:51 --> Controller Class Initialized
INFO - 2022-03-22 06:00:51 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:00:51 --> Encrypt Class Initialized
INFO - 2022-03-22 06:00:51 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:00:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:00:51 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:00:51 --> Model "Users_model" initialized
INFO - 2022-03-22 06:00:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 06:00:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:00:52 --> Config Class Initialized
INFO - 2022-03-22 06:00:52 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:00:52 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:00:52 --> Utf8 Class Initialized
INFO - 2022-03-22 06:00:52 --> URI Class Initialized
INFO - 2022-03-22 06:00:52 --> Router Class Initialized
INFO - 2022-03-22 06:00:52 --> Output Class Initialized
INFO - 2022-03-22 06:00:52 --> Security Class Initialized
DEBUG - 2022-03-22 06:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:00:52 --> Input Class Initialized
INFO - 2022-03-22 06:00:52 --> Language Class Initialized
INFO - 2022-03-22 06:00:52 --> Loader Class Initialized
INFO - 2022-03-22 06:00:52 --> Helper loaded: url_helper
INFO - 2022-03-22 06:00:52 --> Helper loaded: form_helper
INFO - 2022-03-22 06:00:52 --> Helper loaded: common_helper
INFO - 2022-03-22 06:00:52 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:00:52 --> Controller Class Initialized
INFO - 2022-03-22 06:00:52 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:00:52 --> Encrypt Class Initialized
INFO - 2022-03-22 06:00:52 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:00:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:00:52 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:00:52 --> Model "Users_model" initialized
INFO - 2022-03-22 06:00:52 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:00:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:00:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 06:00:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:00:53 --> Final output sent to browser
DEBUG - 2022-03-22 06:00:53 --> Total execution time: 1.1531
ERROR - 2022-03-22 06:06:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:06:17 --> Config Class Initialized
INFO - 2022-03-22 06:06:17 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:06:17 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:06:17 --> Utf8 Class Initialized
INFO - 2022-03-22 06:06:17 --> URI Class Initialized
INFO - 2022-03-22 06:06:17 --> Router Class Initialized
INFO - 2022-03-22 06:06:17 --> Output Class Initialized
INFO - 2022-03-22 06:06:17 --> Security Class Initialized
DEBUG - 2022-03-22 06:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:06:17 --> Input Class Initialized
INFO - 2022-03-22 06:06:17 --> Language Class Initialized
INFO - 2022-03-22 06:06:17 --> Loader Class Initialized
INFO - 2022-03-22 06:06:17 --> Helper loaded: url_helper
INFO - 2022-03-22 06:06:17 --> Helper loaded: form_helper
INFO - 2022-03-22 06:06:17 --> Helper loaded: common_helper
INFO - 2022-03-22 06:06:17 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:06:17 --> Controller Class Initialized
INFO - 2022-03-22 06:06:17 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:06:17 --> Encrypt Class Initialized
INFO - 2022-03-22 06:06:17 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:06:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:06:17 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:06:17 --> Model "Users_model" initialized
INFO - 2022-03-22 06:06:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 06:06:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:06:17 --> Config Class Initialized
INFO - 2022-03-22 06:06:17 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:06:17 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:06:17 --> Utf8 Class Initialized
INFO - 2022-03-22 06:06:17 --> URI Class Initialized
INFO - 2022-03-22 06:06:17 --> Router Class Initialized
INFO - 2022-03-22 06:06:17 --> Output Class Initialized
INFO - 2022-03-22 06:06:17 --> Security Class Initialized
DEBUG - 2022-03-22 06:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:06:17 --> Input Class Initialized
INFO - 2022-03-22 06:06:17 --> Language Class Initialized
INFO - 2022-03-22 06:06:17 --> Loader Class Initialized
INFO - 2022-03-22 06:06:17 --> Helper loaded: url_helper
INFO - 2022-03-22 06:06:17 --> Helper loaded: form_helper
INFO - 2022-03-22 06:06:17 --> Helper loaded: common_helper
INFO - 2022-03-22 06:06:17 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:06:17 --> Controller Class Initialized
INFO - 2022-03-22 06:06:17 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:06:17 --> Encrypt Class Initialized
INFO - 2022-03-22 06:06:17 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:06:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:06:17 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:06:17 --> Model "Users_model" initialized
INFO - 2022-03-22 06:06:17 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:06:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:06:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 06:06:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:06:18 --> Final output sent to browser
DEBUG - 2022-03-22 06:06:18 --> Total execution time: 0.1133
ERROR - 2022-03-22 06:08:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:08:05 --> Config Class Initialized
INFO - 2022-03-22 06:08:05 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:08:05 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:08:05 --> Utf8 Class Initialized
INFO - 2022-03-22 06:08:05 --> URI Class Initialized
INFO - 2022-03-22 06:08:05 --> Router Class Initialized
INFO - 2022-03-22 06:08:05 --> Output Class Initialized
INFO - 2022-03-22 06:08:05 --> Security Class Initialized
DEBUG - 2022-03-22 06:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:08:05 --> Input Class Initialized
INFO - 2022-03-22 06:08:05 --> Language Class Initialized
INFO - 2022-03-22 06:08:05 --> Loader Class Initialized
INFO - 2022-03-22 06:08:05 --> Helper loaded: url_helper
INFO - 2022-03-22 06:08:05 --> Helper loaded: form_helper
INFO - 2022-03-22 06:08:05 --> Helper loaded: common_helper
INFO - 2022-03-22 06:08:05 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:08:05 --> Controller Class Initialized
INFO - 2022-03-22 06:08:05 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:08:05 --> Encrypt Class Initialized
INFO - 2022-03-22 06:08:05 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:08:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:08:05 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:08:05 --> Model "Users_model" initialized
INFO - 2022-03-22 06:08:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 06:08:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:08:06 --> Config Class Initialized
INFO - 2022-03-22 06:08:06 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:08:06 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:08:06 --> Utf8 Class Initialized
INFO - 2022-03-22 06:08:06 --> URI Class Initialized
INFO - 2022-03-22 06:08:06 --> Router Class Initialized
INFO - 2022-03-22 06:08:06 --> Output Class Initialized
INFO - 2022-03-22 06:08:06 --> Security Class Initialized
DEBUG - 2022-03-22 06:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:08:06 --> Input Class Initialized
INFO - 2022-03-22 06:08:06 --> Language Class Initialized
INFO - 2022-03-22 06:08:06 --> Loader Class Initialized
INFO - 2022-03-22 06:08:06 --> Helper loaded: url_helper
INFO - 2022-03-22 06:08:06 --> Helper loaded: form_helper
INFO - 2022-03-22 06:08:06 --> Helper loaded: common_helper
INFO - 2022-03-22 06:08:06 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:08:06 --> Controller Class Initialized
INFO - 2022-03-22 06:08:06 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:08:06 --> Encrypt Class Initialized
INFO - 2022-03-22 06:08:06 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:08:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:08:06 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:08:06 --> Model "Users_model" initialized
INFO - 2022-03-22 06:08:06 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:08:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:08:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 06:08:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:08:06 --> Final output sent to browser
DEBUG - 2022-03-22 06:08:06 --> Total execution time: 0.1245
ERROR - 2022-03-22 06:09:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:09:09 --> Config Class Initialized
INFO - 2022-03-22 06:09:09 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:09:09 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:09:09 --> Utf8 Class Initialized
INFO - 2022-03-22 06:09:09 --> URI Class Initialized
INFO - 2022-03-22 06:09:09 --> Router Class Initialized
INFO - 2022-03-22 06:09:09 --> Output Class Initialized
INFO - 2022-03-22 06:09:09 --> Security Class Initialized
DEBUG - 2022-03-22 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:09:09 --> Input Class Initialized
INFO - 2022-03-22 06:09:09 --> Language Class Initialized
INFO - 2022-03-22 06:09:09 --> Loader Class Initialized
INFO - 2022-03-22 06:09:09 --> Helper loaded: url_helper
INFO - 2022-03-22 06:09:09 --> Helper loaded: form_helper
INFO - 2022-03-22 06:09:09 --> Helper loaded: common_helper
INFO - 2022-03-22 06:09:09 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:09:09 --> Controller Class Initialized
INFO - 2022-03-22 06:09:09 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:09:09 --> Encrypt Class Initialized
INFO - 2022-03-22 06:09:09 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:09:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:09:09 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:09:09 --> Model "Users_model" initialized
INFO - 2022-03-22 06:09:09 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:09:09 --> Upload Class Initialized
INFO - 2022-03-22 06:09:09 --> Final output sent to browser
DEBUG - 2022-03-22 06:09:09 --> Total execution time: 0.1697
ERROR - 2022-03-22 06:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:09:16 --> Config Class Initialized
INFO - 2022-03-22 06:09:16 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:09:16 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:09:16 --> Utf8 Class Initialized
INFO - 2022-03-22 06:09:16 --> URI Class Initialized
INFO - 2022-03-22 06:09:16 --> Router Class Initialized
INFO - 2022-03-22 06:09:16 --> Output Class Initialized
INFO - 2022-03-22 06:09:16 --> Security Class Initialized
DEBUG - 2022-03-22 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:09:16 --> Input Class Initialized
INFO - 2022-03-22 06:09:16 --> Language Class Initialized
INFO - 2022-03-22 06:09:16 --> Loader Class Initialized
INFO - 2022-03-22 06:09:16 --> Helper loaded: url_helper
INFO - 2022-03-22 06:09:16 --> Helper loaded: form_helper
INFO - 2022-03-22 06:09:16 --> Helper loaded: common_helper
INFO - 2022-03-22 06:09:16 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:09:16 --> Controller Class Initialized
INFO - 2022-03-22 06:09:16 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:09:16 --> Encrypt Class Initialized
INFO - 2022-03-22 06:09:16 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:09:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:09:16 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:09:16 --> Model "Users_model" initialized
INFO - 2022-03-22 06:09:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 06:09:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:09:17 --> Config Class Initialized
INFO - 2022-03-22 06:09:17 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:09:17 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:09:17 --> Utf8 Class Initialized
INFO - 2022-03-22 06:09:17 --> URI Class Initialized
INFO - 2022-03-22 06:09:17 --> Router Class Initialized
INFO - 2022-03-22 06:09:17 --> Output Class Initialized
INFO - 2022-03-22 06:09:17 --> Security Class Initialized
DEBUG - 2022-03-22 06:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:09:17 --> Input Class Initialized
INFO - 2022-03-22 06:09:17 --> Language Class Initialized
INFO - 2022-03-22 06:09:17 --> Loader Class Initialized
INFO - 2022-03-22 06:09:17 --> Helper loaded: url_helper
INFO - 2022-03-22 06:09:17 --> Helper loaded: form_helper
INFO - 2022-03-22 06:09:17 --> Helper loaded: common_helper
INFO - 2022-03-22 06:09:17 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:09:17 --> Controller Class Initialized
INFO - 2022-03-22 06:09:17 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:09:17 --> Encrypt Class Initialized
INFO - 2022-03-22 06:09:17 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:09:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:09:17 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:09:17 --> Model "Users_model" initialized
INFO - 2022-03-22 06:09:17 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:09:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:09:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 06:09:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:09:17 --> Final output sent to browser
DEBUG - 2022-03-22 06:09:17 --> Total execution time: 0.1098
ERROR - 2022-03-22 06:24:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:24:00 --> Config Class Initialized
INFO - 2022-03-22 06:24:00 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:24:00 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:24:00 --> Utf8 Class Initialized
INFO - 2022-03-22 06:24:00 --> URI Class Initialized
INFO - 2022-03-22 06:24:00 --> Router Class Initialized
INFO - 2022-03-22 06:24:00 --> Output Class Initialized
INFO - 2022-03-22 06:24:00 --> Security Class Initialized
DEBUG - 2022-03-22 06:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:24:00 --> Input Class Initialized
INFO - 2022-03-22 06:24:00 --> Language Class Initialized
INFO - 2022-03-22 06:24:00 --> Loader Class Initialized
INFO - 2022-03-22 06:24:00 --> Helper loaded: url_helper
INFO - 2022-03-22 06:24:00 --> Helper loaded: form_helper
INFO - 2022-03-22 06:24:00 --> Helper loaded: common_helper
INFO - 2022-03-22 06:24:00 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:24:00 --> Controller Class Initialized
INFO - 2022-03-22 06:24:00 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:24:00 --> Encrypt Class Initialized
INFO - 2022-03-22 06:24:00 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:24:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:24:00 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:24:00 --> Model "Users_model" initialized
INFO - 2022-03-22 06:24:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 06:24:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:24:01 --> Config Class Initialized
INFO - 2022-03-22 06:24:01 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:24:01 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:24:01 --> Utf8 Class Initialized
INFO - 2022-03-22 06:24:01 --> URI Class Initialized
INFO - 2022-03-22 06:24:01 --> Router Class Initialized
INFO - 2022-03-22 06:24:01 --> Output Class Initialized
INFO - 2022-03-22 06:24:01 --> Security Class Initialized
DEBUG - 2022-03-22 06:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:24:01 --> Input Class Initialized
INFO - 2022-03-22 06:24:01 --> Language Class Initialized
INFO - 2022-03-22 06:24:01 --> Loader Class Initialized
INFO - 2022-03-22 06:24:01 --> Helper loaded: url_helper
INFO - 2022-03-22 06:24:01 --> Helper loaded: form_helper
INFO - 2022-03-22 06:24:01 --> Helper loaded: common_helper
INFO - 2022-03-22 06:24:01 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:24:01 --> Controller Class Initialized
INFO - 2022-03-22 06:24:01 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:24:01 --> Encrypt Class Initialized
INFO - 2022-03-22 06:24:01 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:24:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:24:01 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:24:01 --> Model "Users_model" initialized
INFO - 2022-03-22 06:24:01 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:24:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:24:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 06:24:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:24:01 --> Final output sent to browser
DEBUG - 2022-03-22 06:24:01 --> Total execution time: 0.1574
ERROR - 2022-03-22 06:24:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:24:12 --> Config Class Initialized
INFO - 2022-03-22 06:24:12 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:24:12 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:24:12 --> Utf8 Class Initialized
INFO - 2022-03-22 06:24:12 --> URI Class Initialized
INFO - 2022-03-22 06:24:12 --> Router Class Initialized
INFO - 2022-03-22 06:24:12 --> Output Class Initialized
INFO - 2022-03-22 06:24:12 --> Security Class Initialized
DEBUG - 2022-03-22 06:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:24:12 --> Input Class Initialized
INFO - 2022-03-22 06:24:12 --> Language Class Initialized
INFO - 2022-03-22 06:24:12 --> Loader Class Initialized
INFO - 2022-03-22 06:24:12 --> Helper loaded: url_helper
INFO - 2022-03-22 06:24:12 --> Helper loaded: form_helper
INFO - 2022-03-22 06:24:12 --> Helper loaded: common_helper
INFO - 2022-03-22 06:24:12 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:24:12 --> Controller Class Initialized
INFO - 2022-03-22 06:24:12 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:24:12 --> Encrypt Class Initialized
INFO - 2022-03-22 06:24:12 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:24:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:24:12 --> Model "Referredby_model" initialized
INFO - 2022-03-22 06:24:12 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:24:12 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:24:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:24:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-22 06:24:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:24:14 --> Final output sent to browser
DEBUG - 2022-03-22 06:24:14 --> Total execution time: 1.1458
ERROR - 2022-03-22 06:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:24:29 --> Config Class Initialized
INFO - 2022-03-22 06:24:29 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:24:29 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:24:29 --> Utf8 Class Initialized
INFO - 2022-03-22 06:24:29 --> URI Class Initialized
INFO - 2022-03-22 06:24:29 --> Router Class Initialized
INFO - 2022-03-22 06:24:29 --> Output Class Initialized
INFO - 2022-03-22 06:24:29 --> Security Class Initialized
DEBUG - 2022-03-22 06:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:24:29 --> Input Class Initialized
INFO - 2022-03-22 06:24:29 --> Language Class Initialized
INFO - 2022-03-22 06:24:29 --> Loader Class Initialized
INFO - 2022-03-22 06:24:29 --> Helper loaded: url_helper
INFO - 2022-03-22 06:24:29 --> Helper loaded: form_helper
INFO - 2022-03-22 06:24:29 --> Helper loaded: common_helper
INFO - 2022-03-22 06:24:29 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:24:29 --> Controller Class Initialized
INFO - 2022-03-22 06:24:29 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:24:29 --> Encrypt Class Initialized
INFO - 2022-03-22 06:24:29 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:24:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:24:29 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:24:29 --> Model "Users_model" initialized
INFO - 2022-03-22 06:24:29 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:24:30 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-22 06:24:34 --> Final output sent to browser
DEBUG - 2022-03-22 06:24:34 --> Total execution time: 4.9975
ERROR - 2022-03-22 06:35:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:35:29 --> Config Class Initialized
INFO - 2022-03-22 06:35:29 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:35:29 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:35:29 --> Utf8 Class Initialized
INFO - 2022-03-22 06:35:29 --> URI Class Initialized
INFO - 2022-03-22 06:35:29 --> Router Class Initialized
INFO - 2022-03-22 06:35:29 --> Output Class Initialized
INFO - 2022-03-22 06:35:29 --> Security Class Initialized
DEBUG - 2022-03-22 06:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:35:29 --> Input Class Initialized
INFO - 2022-03-22 06:35:29 --> Language Class Initialized
INFO - 2022-03-22 06:35:29 --> Loader Class Initialized
INFO - 2022-03-22 06:35:29 --> Helper loaded: url_helper
INFO - 2022-03-22 06:35:29 --> Helper loaded: form_helper
INFO - 2022-03-22 06:35:29 --> Helper loaded: common_helper
INFO - 2022-03-22 06:35:29 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:35:30 --> Controller Class Initialized
INFO - 2022-03-22 06:35:30 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:35:30 --> Encrypt Class Initialized
INFO - 2022-03-22 06:35:30 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:35:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:35:30 --> Model "Referredby_model" initialized
INFO - 2022-03-22 06:35:30 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:35:30 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:35:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:35:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 06:35:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:35:30 --> Final output sent to browser
DEBUG - 2022-03-22 06:35:30 --> Total execution time: 0.2105
ERROR - 2022-03-22 06:35:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:35:35 --> Config Class Initialized
INFO - 2022-03-22 06:35:35 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:35:35 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:35:35 --> Utf8 Class Initialized
INFO - 2022-03-22 06:35:35 --> URI Class Initialized
INFO - 2022-03-22 06:35:35 --> Router Class Initialized
INFO - 2022-03-22 06:35:35 --> Output Class Initialized
INFO - 2022-03-22 06:35:35 --> Security Class Initialized
DEBUG - 2022-03-22 06:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:35:35 --> Input Class Initialized
INFO - 2022-03-22 06:35:35 --> Language Class Initialized
INFO - 2022-03-22 06:35:35 --> Loader Class Initialized
INFO - 2022-03-22 06:35:35 --> Helper loaded: url_helper
INFO - 2022-03-22 06:35:35 --> Helper loaded: form_helper
INFO - 2022-03-22 06:35:35 --> Helper loaded: common_helper
INFO - 2022-03-22 06:35:35 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:35:35 --> Controller Class Initialized
INFO - 2022-03-22 06:35:35 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:35:35 --> Encrypt Class Initialized
INFO - 2022-03-22 06:35:35 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:35:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:35:35 --> Model "Referredby_model" initialized
INFO - 2022-03-22 06:35:35 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:35:35 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 06:35:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:35:36 --> Config Class Initialized
INFO - 2022-03-22 06:35:36 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:35:36 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:35:36 --> Utf8 Class Initialized
INFO - 2022-03-22 06:35:36 --> URI Class Initialized
INFO - 2022-03-22 06:35:36 --> Router Class Initialized
INFO - 2022-03-22 06:35:36 --> Output Class Initialized
INFO - 2022-03-22 06:35:36 --> Security Class Initialized
DEBUG - 2022-03-22 06:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:35:36 --> Input Class Initialized
INFO - 2022-03-22 06:35:36 --> Language Class Initialized
INFO - 2022-03-22 06:35:36 --> Loader Class Initialized
INFO - 2022-03-22 06:35:36 --> Helper loaded: url_helper
INFO - 2022-03-22 06:35:36 --> Helper loaded: form_helper
INFO - 2022-03-22 06:35:36 --> Helper loaded: common_helper
INFO - 2022-03-22 06:35:36 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:35:36 --> Controller Class Initialized
INFO - 2022-03-22 06:35:36 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:35:36 --> Encrypt Class Initialized
INFO - 2022-03-22 06:35:36 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:35:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:35:36 --> Model "Referredby_model" initialized
INFO - 2022-03-22 06:35:36 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:35:36 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:35:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:35:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 06:35:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:35:36 --> Final output sent to browser
DEBUG - 2022-03-22 06:35:36 --> Total execution time: 0.0781
ERROR - 2022-03-22 06:35:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:35:38 --> Config Class Initialized
INFO - 2022-03-22 06:35:38 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:35:38 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:35:38 --> Utf8 Class Initialized
INFO - 2022-03-22 06:35:38 --> URI Class Initialized
INFO - 2022-03-22 06:35:38 --> Router Class Initialized
INFO - 2022-03-22 06:35:38 --> Output Class Initialized
INFO - 2022-03-22 06:35:38 --> Security Class Initialized
DEBUG - 2022-03-22 06:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:35:38 --> Input Class Initialized
INFO - 2022-03-22 06:35:38 --> Language Class Initialized
INFO - 2022-03-22 06:35:38 --> Loader Class Initialized
INFO - 2022-03-22 06:35:38 --> Helper loaded: url_helper
INFO - 2022-03-22 06:35:38 --> Helper loaded: form_helper
INFO - 2022-03-22 06:35:38 --> Helper loaded: common_helper
INFO - 2022-03-22 06:35:38 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:35:38 --> Controller Class Initialized
INFO - 2022-03-22 06:35:38 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:35:38 --> Encrypt Class Initialized
INFO - 2022-03-22 06:35:38 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:35:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:35:38 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:35:38 --> Model "Users_model" initialized
INFO - 2022-03-22 06:35:38 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:35:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:35:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 06:35:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:35:38 --> Final output sent to browser
DEBUG - 2022-03-22 06:35:38 --> Total execution time: 0.1542
ERROR - 2022-03-22 06:36:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:36:14 --> Config Class Initialized
INFO - 2022-03-22 06:36:14 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:36:14 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:36:14 --> Utf8 Class Initialized
INFO - 2022-03-22 06:36:14 --> URI Class Initialized
INFO - 2022-03-22 06:36:14 --> Router Class Initialized
INFO - 2022-03-22 06:36:14 --> Output Class Initialized
INFO - 2022-03-22 06:36:14 --> Security Class Initialized
DEBUG - 2022-03-22 06:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:36:14 --> Input Class Initialized
INFO - 2022-03-22 06:36:14 --> Language Class Initialized
INFO - 2022-03-22 06:36:14 --> Loader Class Initialized
INFO - 2022-03-22 06:36:14 --> Helper loaded: url_helper
INFO - 2022-03-22 06:36:14 --> Helper loaded: form_helper
INFO - 2022-03-22 06:36:14 --> Helper loaded: common_helper
INFO - 2022-03-22 06:36:14 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:36:14 --> Controller Class Initialized
INFO - 2022-03-22 06:36:14 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:36:14 --> Encrypt Class Initialized
INFO - 2022-03-22 06:36:14 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:36:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:36:14 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:36:14 --> Model "Users_model" initialized
INFO - 2022-03-22 06:36:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 06:36:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:36:15 --> Config Class Initialized
INFO - 2022-03-22 06:36:15 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:36:15 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:36:15 --> Utf8 Class Initialized
INFO - 2022-03-22 06:36:15 --> URI Class Initialized
INFO - 2022-03-22 06:36:15 --> Router Class Initialized
INFO - 2022-03-22 06:36:15 --> Output Class Initialized
INFO - 2022-03-22 06:36:15 --> Security Class Initialized
DEBUG - 2022-03-22 06:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:36:15 --> Input Class Initialized
INFO - 2022-03-22 06:36:15 --> Language Class Initialized
INFO - 2022-03-22 06:36:15 --> Loader Class Initialized
INFO - 2022-03-22 06:36:15 --> Helper loaded: url_helper
INFO - 2022-03-22 06:36:15 --> Helper loaded: form_helper
INFO - 2022-03-22 06:36:15 --> Helper loaded: common_helper
INFO - 2022-03-22 06:36:15 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:36:15 --> Controller Class Initialized
INFO - 2022-03-22 06:36:15 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:36:15 --> Encrypt Class Initialized
INFO - 2022-03-22 06:36:15 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:36:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:36:15 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:36:15 --> Model "Users_model" initialized
INFO - 2022-03-22 06:36:15 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:36:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:36:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 06:36:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:36:16 --> Final output sent to browser
DEBUG - 2022-03-22 06:36:16 --> Total execution time: 0.0980
ERROR - 2022-03-22 06:43:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:43:40 --> Config Class Initialized
INFO - 2022-03-22 06:43:40 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:43:40 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:43:40 --> Utf8 Class Initialized
INFO - 2022-03-22 06:43:40 --> URI Class Initialized
INFO - 2022-03-22 06:43:40 --> Router Class Initialized
INFO - 2022-03-22 06:43:40 --> Output Class Initialized
INFO - 2022-03-22 06:43:40 --> Security Class Initialized
DEBUG - 2022-03-22 06:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:43:40 --> Input Class Initialized
INFO - 2022-03-22 06:43:40 --> Language Class Initialized
INFO - 2022-03-22 06:43:40 --> Loader Class Initialized
INFO - 2022-03-22 06:43:40 --> Helper loaded: url_helper
INFO - 2022-03-22 06:43:40 --> Helper loaded: form_helper
INFO - 2022-03-22 06:43:40 --> Helper loaded: common_helper
INFO - 2022-03-22 06:43:40 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:43:40 --> Controller Class Initialized
INFO - 2022-03-22 06:43:40 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:43:40 --> Encrypt Class Initialized
INFO - 2022-03-22 06:43:40 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:43:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:43:40 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:43:40 --> Model "Users_model" initialized
INFO - 2022-03-22 06:43:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 06:43:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 06:43:41 --> Config Class Initialized
INFO - 2022-03-22 06:43:41 --> Hooks Class Initialized
DEBUG - 2022-03-22 06:43:41 --> UTF-8 Support Enabled
INFO - 2022-03-22 06:43:41 --> Utf8 Class Initialized
INFO - 2022-03-22 06:43:41 --> URI Class Initialized
INFO - 2022-03-22 06:43:41 --> Router Class Initialized
INFO - 2022-03-22 06:43:41 --> Output Class Initialized
INFO - 2022-03-22 06:43:41 --> Security Class Initialized
DEBUG - 2022-03-22 06:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 06:43:41 --> Input Class Initialized
INFO - 2022-03-22 06:43:41 --> Language Class Initialized
INFO - 2022-03-22 06:43:41 --> Loader Class Initialized
INFO - 2022-03-22 06:43:41 --> Helper loaded: url_helper
INFO - 2022-03-22 06:43:41 --> Helper loaded: form_helper
INFO - 2022-03-22 06:43:41 --> Helper loaded: common_helper
INFO - 2022-03-22 06:43:41 --> Database Driver Class Initialized
DEBUG - 2022-03-22 06:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 06:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 06:43:41 --> Controller Class Initialized
INFO - 2022-03-22 06:43:41 --> Form Validation Class Initialized
DEBUG - 2022-03-22 06:43:41 --> Encrypt Class Initialized
INFO - 2022-03-22 06:43:41 --> Model "Patient_model" initialized
INFO - 2022-03-22 06:43:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 06:43:41 --> Model "Prefix_master" initialized
INFO - 2022-03-22 06:43:41 --> Model "Users_model" initialized
INFO - 2022-03-22 06:43:41 --> Model "Hospital_model" initialized
INFO - 2022-03-22 06:43:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 06:43:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 06:43:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 06:43:41 --> Final output sent to browser
DEBUG - 2022-03-22 06:43:41 --> Total execution time: 0.0961
ERROR - 2022-03-22 07:17:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 07:17:59 --> Config Class Initialized
INFO - 2022-03-22 07:17:59 --> Hooks Class Initialized
DEBUG - 2022-03-22 07:17:59 --> UTF-8 Support Enabled
INFO - 2022-03-22 07:17:59 --> Utf8 Class Initialized
INFO - 2022-03-22 07:17:59 --> URI Class Initialized
INFO - 2022-03-22 07:17:59 --> Router Class Initialized
INFO - 2022-03-22 07:17:59 --> Output Class Initialized
INFO - 2022-03-22 07:17:59 --> Security Class Initialized
DEBUG - 2022-03-22 07:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 07:17:59 --> Input Class Initialized
INFO - 2022-03-22 07:17:59 --> Language Class Initialized
INFO - 2022-03-22 07:17:59 --> Loader Class Initialized
INFO - 2022-03-22 07:17:59 --> Helper loaded: url_helper
INFO - 2022-03-22 07:17:59 --> Helper loaded: form_helper
INFO - 2022-03-22 07:17:59 --> Helper loaded: common_helper
INFO - 2022-03-22 07:17:59 --> Database Driver Class Initialized
DEBUG - 2022-03-22 07:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 07:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 07:17:59 --> Controller Class Initialized
INFO - 2022-03-22 07:17:59 --> Form Validation Class Initialized
DEBUG - 2022-03-22 07:17:59 --> Encrypt Class Initialized
INFO - 2022-03-22 07:17:59 --> Model "Patient_model" initialized
INFO - 2022-03-22 07:17:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 07:17:59 --> Model "Prefix_master" initialized
INFO - 2022-03-22 07:17:59 --> Model "Users_model" initialized
INFO - 2022-03-22 07:17:59 --> Model "Hospital_model" initialized
INFO - 2022-03-22 07:17:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 07:17:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 07:17:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 07:17:59 --> Final output sent to browser
DEBUG - 2022-03-22 07:17:59 --> Total execution time: 0.1882
ERROR - 2022-03-22 07:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 07:18:31 --> Config Class Initialized
INFO - 2022-03-22 07:18:31 --> Hooks Class Initialized
DEBUG - 2022-03-22 07:18:31 --> UTF-8 Support Enabled
INFO - 2022-03-22 07:18:31 --> Utf8 Class Initialized
INFO - 2022-03-22 07:18:31 --> URI Class Initialized
INFO - 2022-03-22 07:18:31 --> Router Class Initialized
INFO - 2022-03-22 07:18:31 --> Output Class Initialized
INFO - 2022-03-22 07:18:31 --> Security Class Initialized
DEBUG - 2022-03-22 07:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 07:18:31 --> Input Class Initialized
INFO - 2022-03-22 07:18:31 --> Language Class Initialized
INFO - 2022-03-22 07:18:31 --> Loader Class Initialized
INFO - 2022-03-22 07:18:31 --> Helper loaded: url_helper
INFO - 2022-03-22 07:18:31 --> Helper loaded: form_helper
INFO - 2022-03-22 07:18:31 --> Helper loaded: common_helper
INFO - 2022-03-22 07:18:31 --> Database Driver Class Initialized
DEBUG - 2022-03-22 07:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 07:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 07:18:31 --> Controller Class Initialized
INFO - 2022-03-22 07:18:31 --> Form Validation Class Initialized
DEBUG - 2022-03-22 07:18:31 --> Encrypt Class Initialized
INFO - 2022-03-22 07:18:31 --> Model "Patient_model" initialized
INFO - 2022-03-22 07:18:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 07:18:31 --> Model "Referredby_model" initialized
INFO - 2022-03-22 07:18:31 --> Model "Prefix_master" initialized
INFO - 2022-03-22 07:18:31 --> Model "Hospital_model" initialized
INFO - 2022-03-22 07:18:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 07:18:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-22 07:18:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 07:18:31 --> Final output sent to browser
DEBUG - 2022-03-22 07:18:31 --> Total execution time: 0.2145
ERROR - 2022-03-22 07:18:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 07:18:47 --> Config Class Initialized
INFO - 2022-03-22 07:18:47 --> Hooks Class Initialized
DEBUG - 2022-03-22 07:18:47 --> UTF-8 Support Enabled
INFO - 2022-03-22 07:18:47 --> Utf8 Class Initialized
INFO - 2022-03-22 07:18:47 --> URI Class Initialized
INFO - 2022-03-22 07:18:47 --> Router Class Initialized
INFO - 2022-03-22 07:18:47 --> Output Class Initialized
INFO - 2022-03-22 07:18:47 --> Security Class Initialized
DEBUG - 2022-03-22 07:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 07:18:47 --> Input Class Initialized
INFO - 2022-03-22 07:18:47 --> Language Class Initialized
INFO - 2022-03-22 07:18:47 --> Loader Class Initialized
INFO - 2022-03-22 07:18:47 --> Helper loaded: url_helper
INFO - 2022-03-22 07:18:47 --> Helper loaded: form_helper
INFO - 2022-03-22 07:18:47 --> Helper loaded: common_helper
INFO - 2022-03-22 07:18:47 --> Database Driver Class Initialized
DEBUG - 2022-03-22 07:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 07:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 07:18:47 --> Controller Class Initialized
INFO - 2022-03-22 07:18:47 --> Form Validation Class Initialized
DEBUG - 2022-03-22 07:18:47 --> Encrypt Class Initialized
INFO - 2022-03-22 07:18:47 --> Model "Patient_model" initialized
INFO - 2022-03-22 07:18:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 07:18:47 --> Model "Prefix_master" initialized
INFO - 2022-03-22 07:18:47 --> Model "Users_model" initialized
INFO - 2022-03-22 07:18:47 --> Model "Hospital_model" initialized
INFO - 2022-03-22 07:18:47 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-22 07:18:50 --> Final output sent to browser
DEBUG - 2022-03-22 07:18:50 --> Total execution time: 3.1677
ERROR - 2022-03-22 07:20:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 07:20:20 --> Config Class Initialized
INFO - 2022-03-22 07:20:20 --> Hooks Class Initialized
DEBUG - 2022-03-22 07:20:20 --> UTF-8 Support Enabled
INFO - 2022-03-22 07:20:20 --> Utf8 Class Initialized
INFO - 2022-03-22 07:20:20 --> URI Class Initialized
INFO - 2022-03-22 07:20:20 --> Router Class Initialized
INFO - 2022-03-22 07:20:20 --> Output Class Initialized
INFO - 2022-03-22 07:20:20 --> Security Class Initialized
DEBUG - 2022-03-22 07:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 07:20:20 --> Input Class Initialized
INFO - 2022-03-22 07:20:20 --> Language Class Initialized
INFO - 2022-03-22 07:20:20 --> Loader Class Initialized
INFO - 2022-03-22 07:20:20 --> Helper loaded: url_helper
INFO - 2022-03-22 07:20:20 --> Helper loaded: form_helper
INFO - 2022-03-22 07:20:20 --> Helper loaded: common_helper
INFO - 2022-03-22 07:20:20 --> Database Driver Class Initialized
DEBUG - 2022-03-22 07:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 07:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 07:20:20 --> Controller Class Initialized
INFO - 2022-03-22 07:20:20 --> Form Validation Class Initialized
DEBUG - 2022-03-22 07:20:20 --> Encrypt Class Initialized
INFO - 2022-03-22 07:20:20 --> Model "Patient_model" initialized
INFO - 2022-03-22 07:20:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 07:20:20 --> Model "Referredby_model" initialized
INFO - 2022-03-22 07:20:20 --> Model "Prefix_master" initialized
INFO - 2022-03-22 07:20:20 --> Model "Hospital_model" initialized
INFO - 2022-03-22 07:20:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 07:20:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-22 07:20:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 07:20:21 --> Final output sent to browser
DEBUG - 2022-03-22 07:20:21 --> Total execution time: 0.0978
ERROR - 2022-03-22 07:20:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 07:20:32 --> Config Class Initialized
INFO - 2022-03-22 07:20:32 --> Hooks Class Initialized
DEBUG - 2022-03-22 07:20:32 --> UTF-8 Support Enabled
INFO - 2022-03-22 07:20:32 --> Utf8 Class Initialized
INFO - 2022-03-22 07:20:32 --> URI Class Initialized
INFO - 2022-03-22 07:20:32 --> Router Class Initialized
INFO - 2022-03-22 07:20:32 --> Output Class Initialized
INFO - 2022-03-22 07:20:32 --> Security Class Initialized
DEBUG - 2022-03-22 07:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 07:20:32 --> Input Class Initialized
INFO - 2022-03-22 07:20:32 --> Language Class Initialized
INFO - 2022-03-22 07:20:32 --> Loader Class Initialized
INFO - 2022-03-22 07:20:32 --> Helper loaded: url_helper
INFO - 2022-03-22 07:20:32 --> Helper loaded: form_helper
INFO - 2022-03-22 07:20:32 --> Helper loaded: common_helper
INFO - 2022-03-22 07:20:32 --> Database Driver Class Initialized
DEBUG - 2022-03-22 07:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 07:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 07:20:32 --> Controller Class Initialized
INFO - 2022-03-22 07:20:32 --> Form Validation Class Initialized
DEBUG - 2022-03-22 07:20:32 --> Encrypt Class Initialized
INFO - 2022-03-22 07:20:32 --> Model "Patient_model" initialized
INFO - 2022-03-22 07:20:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 07:20:32 --> Model "Prefix_master" initialized
INFO - 2022-03-22 07:20:32 --> Model "Users_model" initialized
INFO - 2022-03-22 07:20:32 --> Model "Hospital_model" initialized
INFO - 2022-03-22 07:20:33 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-22 07:20:34 --> Final output sent to browser
DEBUG - 2022-03-22 07:20:34 --> Total execution time: 1.8235
ERROR - 2022-03-22 07:45:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 07:45:39 --> Config Class Initialized
INFO - 2022-03-22 07:45:39 --> Hooks Class Initialized
DEBUG - 2022-03-22 07:45:39 --> UTF-8 Support Enabled
INFO - 2022-03-22 07:45:39 --> Utf8 Class Initialized
INFO - 2022-03-22 07:45:39 --> URI Class Initialized
INFO - 2022-03-22 07:45:40 --> Router Class Initialized
INFO - 2022-03-22 07:45:40 --> Output Class Initialized
INFO - 2022-03-22 07:45:40 --> Security Class Initialized
DEBUG - 2022-03-22 07:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 07:45:40 --> Input Class Initialized
INFO - 2022-03-22 07:45:40 --> Language Class Initialized
ERROR - 2022-03-22 07:45:40 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-03-22 07:45:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 07:45:40 --> Config Class Initialized
INFO - 2022-03-22 07:45:40 --> Hooks Class Initialized
DEBUG - 2022-03-22 07:45:40 --> UTF-8 Support Enabled
INFO - 2022-03-22 07:45:40 --> Utf8 Class Initialized
INFO - 2022-03-22 07:45:40 --> URI Class Initialized
INFO - 2022-03-22 07:45:40 --> Router Class Initialized
INFO - 2022-03-22 07:45:40 --> Output Class Initialized
INFO - 2022-03-22 07:45:40 --> Security Class Initialized
DEBUG - 2022-03-22 07:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 07:45:40 --> Input Class Initialized
INFO - 2022-03-22 07:45:40 --> Language Class Initialized
ERROR - 2022-03-22 07:45:40 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-03-22 07:45:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 07:45:42 --> Config Class Initialized
INFO - 2022-03-22 07:45:42 --> Hooks Class Initialized
DEBUG - 2022-03-22 07:45:42 --> UTF-8 Support Enabled
INFO - 2022-03-22 07:45:42 --> Utf8 Class Initialized
INFO - 2022-03-22 07:45:42 --> URI Class Initialized
DEBUG - 2022-03-22 07:45:42 --> No URI present. Default controller set.
INFO - 2022-03-22 07:45:42 --> Router Class Initialized
INFO - 2022-03-22 07:45:42 --> Output Class Initialized
INFO - 2022-03-22 07:45:42 --> Security Class Initialized
DEBUG - 2022-03-22 07:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 07:45:42 --> Input Class Initialized
INFO - 2022-03-22 07:45:42 --> Language Class Initialized
INFO - 2022-03-22 07:45:42 --> Loader Class Initialized
INFO - 2022-03-22 07:45:42 --> Helper loaded: url_helper
INFO - 2022-03-22 07:45:42 --> Helper loaded: form_helper
INFO - 2022-03-22 07:45:42 --> Helper loaded: common_helper
INFO - 2022-03-22 07:45:42 --> Database Driver Class Initialized
DEBUG - 2022-03-22 07:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 07:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 07:45:42 --> Controller Class Initialized
INFO - 2022-03-22 07:45:42 --> Form Validation Class Initialized
DEBUG - 2022-03-22 07:45:42 --> Encrypt Class Initialized
DEBUG - 2022-03-22 07:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 07:45:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 07:45:42 --> Email Class Initialized
INFO - 2022-03-22 07:45:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 07:45:42 --> Calendar Class Initialized
INFO - 2022-03-22 07:45:42 --> Model "Login_model" initialized
INFO - 2022-03-22 07:45:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 07:45:42 --> Final output sent to browser
DEBUG - 2022-03-22 07:45:42 --> Total execution time: 0.1245
ERROR - 2022-03-22 12:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 12:27:33 --> Config Class Initialized
INFO - 2022-03-22 12:27:33 --> Hooks Class Initialized
DEBUG - 2022-03-22 12:27:33 --> UTF-8 Support Enabled
INFO - 2022-03-22 12:27:33 --> Utf8 Class Initialized
INFO - 2022-03-22 12:27:33 --> URI Class Initialized
DEBUG - 2022-03-22 12:27:33 --> No URI present. Default controller set.
INFO - 2022-03-22 12:27:33 --> Router Class Initialized
INFO - 2022-03-22 12:27:33 --> Output Class Initialized
INFO - 2022-03-22 12:27:33 --> Security Class Initialized
DEBUG - 2022-03-22 12:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 12:27:33 --> Input Class Initialized
INFO - 2022-03-22 12:27:33 --> Language Class Initialized
INFO - 2022-03-22 12:27:33 --> Loader Class Initialized
INFO - 2022-03-22 12:27:33 --> Helper loaded: url_helper
INFO - 2022-03-22 12:27:33 --> Helper loaded: form_helper
INFO - 2022-03-22 12:27:33 --> Helper loaded: common_helper
INFO - 2022-03-22 12:27:33 --> Database Driver Class Initialized
DEBUG - 2022-03-22 12:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 12:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 12:27:33 --> Controller Class Initialized
INFO - 2022-03-22 12:27:33 --> Form Validation Class Initialized
DEBUG - 2022-03-22 12:27:33 --> Encrypt Class Initialized
DEBUG - 2022-03-22 12:27:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:27:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 12:27:33 --> Email Class Initialized
INFO - 2022-03-22 12:27:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 12:27:33 --> Calendar Class Initialized
INFO - 2022-03-22 12:27:33 --> Model "Login_model" initialized
INFO - 2022-03-22 12:27:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 12:27:33 --> Final output sent to browser
DEBUG - 2022-03-22 12:27:33 --> Total execution time: 0.0810
ERROR - 2022-03-22 14:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 14:22:38 --> Config Class Initialized
INFO - 2022-03-22 14:22:38 --> Hooks Class Initialized
DEBUG - 2022-03-22 14:22:38 --> UTF-8 Support Enabled
INFO - 2022-03-22 14:22:38 --> Utf8 Class Initialized
INFO - 2022-03-22 14:22:38 --> URI Class Initialized
DEBUG - 2022-03-22 14:22:38 --> No URI present. Default controller set.
INFO - 2022-03-22 14:22:38 --> Router Class Initialized
INFO - 2022-03-22 14:22:38 --> Output Class Initialized
INFO - 2022-03-22 14:22:38 --> Security Class Initialized
DEBUG - 2022-03-22 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 14:22:38 --> Input Class Initialized
INFO - 2022-03-22 14:22:38 --> Language Class Initialized
INFO - 2022-03-22 14:22:38 --> Loader Class Initialized
INFO - 2022-03-22 14:22:38 --> Helper loaded: url_helper
INFO - 2022-03-22 14:22:38 --> Helper loaded: form_helper
INFO - 2022-03-22 14:22:38 --> Helper loaded: common_helper
INFO - 2022-03-22 14:22:38 --> Database Driver Class Initialized
DEBUG - 2022-03-22 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 14:22:38 --> Controller Class Initialized
INFO - 2022-03-22 14:22:38 --> Form Validation Class Initialized
DEBUG - 2022-03-22 14:22:38 --> Encrypt Class Initialized
DEBUG - 2022-03-22 14:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 14:22:38 --> Email Class Initialized
INFO - 2022-03-22 14:22:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 14:22:38 --> Calendar Class Initialized
INFO - 2022-03-22 14:22:38 --> Model "Login_model" initialized
INFO - 2022-03-22 14:22:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 14:22:38 --> Final output sent to browser
DEBUG - 2022-03-22 14:22:38 --> Total execution time: 0.0689
ERROR - 2022-03-22 14:22:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 14:22:39 --> Config Class Initialized
INFO - 2022-03-22 14:22:39 --> Hooks Class Initialized
DEBUG - 2022-03-22 14:22:39 --> UTF-8 Support Enabled
INFO - 2022-03-22 14:22:39 --> Utf8 Class Initialized
INFO - 2022-03-22 14:22:39 --> URI Class Initialized
INFO - 2022-03-22 14:22:39 --> Router Class Initialized
INFO - 2022-03-22 14:22:39 --> Output Class Initialized
INFO - 2022-03-22 14:22:39 --> Security Class Initialized
DEBUG - 2022-03-22 14:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 14:22:39 --> Input Class Initialized
INFO - 2022-03-22 14:22:39 --> Language Class Initialized
ERROR - 2022-03-22 14:22:39 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-22 14:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 14:22:54 --> Config Class Initialized
INFO - 2022-03-22 14:22:54 --> Hooks Class Initialized
DEBUG - 2022-03-22 14:22:54 --> UTF-8 Support Enabled
INFO - 2022-03-22 14:22:54 --> Utf8 Class Initialized
INFO - 2022-03-22 14:22:54 --> URI Class Initialized
DEBUG - 2022-03-22 14:22:54 --> No URI present. Default controller set.
INFO - 2022-03-22 14:22:54 --> Router Class Initialized
INFO - 2022-03-22 14:22:54 --> Output Class Initialized
INFO - 2022-03-22 14:22:54 --> Security Class Initialized
DEBUG - 2022-03-22 14:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 14:22:54 --> Input Class Initialized
INFO - 2022-03-22 14:22:54 --> Language Class Initialized
INFO - 2022-03-22 14:22:54 --> Loader Class Initialized
INFO - 2022-03-22 14:22:54 --> Helper loaded: url_helper
INFO - 2022-03-22 14:22:54 --> Helper loaded: form_helper
INFO - 2022-03-22 14:22:54 --> Helper loaded: common_helper
INFO - 2022-03-22 14:22:54 --> Database Driver Class Initialized
DEBUG - 2022-03-22 14:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 14:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 14:22:54 --> Controller Class Initialized
INFO - 2022-03-22 14:22:54 --> Form Validation Class Initialized
DEBUG - 2022-03-22 14:22:54 --> Encrypt Class Initialized
DEBUG - 2022-03-22 14:22:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:22:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 14:22:54 --> Email Class Initialized
INFO - 2022-03-22 14:22:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 14:22:54 --> Calendar Class Initialized
INFO - 2022-03-22 14:22:54 --> Model "Login_model" initialized
INFO - 2022-03-22 14:22:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 14:22:54 --> Final output sent to browser
DEBUG - 2022-03-22 14:22:54 --> Total execution time: 0.0088
ERROR - 2022-03-22 14:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 14:22:55 --> Config Class Initialized
INFO - 2022-03-22 14:22:55 --> Hooks Class Initialized
DEBUG - 2022-03-22 14:22:55 --> UTF-8 Support Enabled
INFO - 2022-03-22 14:22:55 --> Utf8 Class Initialized
INFO - 2022-03-22 14:22:55 --> URI Class Initialized
INFO - 2022-03-22 14:22:55 --> Router Class Initialized
INFO - 2022-03-22 14:22:55 --> Output Class Initialized
INFO - 2022-03-22 14:22:55 --> Security Class Initialized
DEBUG - 2022-03-22 14:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 14:22:55 --> Input Class Initialized
INFO - 2022-03-22 14:22:55 --> Language Class Initialized
INFO - 2022-03-22 14:22:55 --> Loader Class Initialized
INFO - 2022-03-22 14:22:55 --> Helper loaded: url_helper
INFO - 2022-03-22 14:22:55 --> Helper loaded: form_helper
INFO - 2022-03-22 14:22:55 --> Helper loaded: common_helper
INFO - 2022-03-22 14:22:55 --> Database Driver Class Initialized
DEBUG - 2022-03-22 14:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 14:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 14:22:55 --> Controller Class Initialized
INFO - 2022-03-22 14:22:55 --> Form Validation Class Initialized
DEBUG - 2022-03-22 14:22:55 --> Encrypt Class Initialized
DEBUG - 2022-03-22 14:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:22:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 14:22:55 --> Email Class Initialized
INFO - 2022-03-22 14:22:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 14:22:55 --> Calendar Class Initialized
INFO - 2022-03-22 14:22:55 --> Model "Login_model" initialized
INFO - 2022-03-22 14:22:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 14:22:55 --> Final output sent to browser
DEBUG - 2022-03-22 14:22:55 --> Total execution time: 0.0108
ERROR - 2022-03-22 14:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 14:22:55 --> Config Class Initialized
INFO - 2022-03-22 14:22:55 --> Hooks Class Initialized
DEBUG - 2022-03-22 14:22:55 --> UTF-8 Support Enabled
INFO - 2022-03-22 14:22:55 --> Utf8 Class Initialized
INFO - 2022-03-22 14:22:55 --> URI Class Initialized
INFO - 2022-03-22 14:22:55 --> Router Class Initialized
INFO - 2022-03-22 14:22:55 --> Output Class Initialized
INFO - 2022-03-22 14:22:55 --> Security Class Initialized
DEBUG - 2022-03-22 14:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 14:22:55 --> Input Class Initialized
INFO - 2022-03-22 14:22:55 --> Language Class Initialized
INFO - 2022-03-22 14:22:55 --> Loader Class Initialized
INFO - 2022-03-22 14:22:55 --> Helper loaded: url_helper
INFO - 2022-03-22 14:22:55 --> Helper loaded: form_helper
INFO - 2022-03-22 14:22:55 --> Helper loaded: common_helper
INFO - 2022-03-22 14:22:55 --> Database Driver Class Initialized
DEBUG - 2022-03-22 14:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 14:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 14:22:55 --> Controller Class Initialized
INFO - 2022-03-22 14:22:55 --> Form Validation Class Initialized
DEBUG - 2022-03-22 14:22:55 --> Encrypt Class Initialized
DEBUG - 2022-03-22 14:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:22:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 14:22:55 --> Email Class Initialized
INFO - 2022-03-22 14:22:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 14:22:55 --> Calendar Class Initialized
INFO - 2022-03-22 14:22:55 --> Model "Login_model" initialized
ERROR - 2022-03-22 14:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 14:22:56 --> Config Class Initialized
INFO - 2022-03-22 14:22:56 --> Hooks Class Initialized
DEBUG - 2022-03-22 14:22:56 --> UTF-8 Support Enabled
INFO - 2022-03-22 14:22:56 --> Utf8 Class Initialized
INFO - 2022-03-22 14:22:56 --> URI Class Initialized
INFO - 2022-03-22 14:22:56 --> Router Class Initialized
INFO - 2022-03-22 14:22:56 --> Output Class Initialized
INFO - 2022-03-22 14:22:56 --> Security Class Initialized
DEBUG - 2022-03-22 14:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 14:22:56 --> Input Class Initialized
INFO - 2022-03-22 14:22:56 --> Language Class Initialized
INFO - 2022-03-22 14:22:56 --> Loader Class Initialized
INFO - 2022-03-22 14:22:56 --> Helper loaded: url_helper
INFO - 2022-03-22 14:22:56 --> Helper loaded: form_helper
INFO - 2022-03-22 14:22:56 --> Helper loaded: common_helper
INFO - 2022-03-22 14:22:56 --> Database Driver Class Initialized
DEBUG - 2022-03-22 14:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 14:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 14:22:56 --> Controller Class Initialized
INFO - 2022-03-22 14:22:56 --> Form Validation Class Initialized
DEBUG - 2022-03-22 14:22:56 --> Encrypt Class Initialized
DEBUG - 2022-03-22 14:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:22:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 14:22:56 --> Email Class Initialized
INFO - 2022-03-22 14:22:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 14:22:56 --> Calendar Class Initialized
INFO - 2022-03-22 14:22:56 --> Model "Login_model" initialized
ERROR - 2022-03-22 17:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 17:13:11 --> Config Class Initialized
INFO - 2022-03-22 17:13:11 --> Hooks Class Initialized
DEBUG - 2022-03-22 17:13:11 --> UTF-8 Support Enabled
INFO - 2022-03-22 17:13:11 --> Utf8 Class Initialized
INFO - 2022-03-22 17:13:11 --> URI Class Initialized
DEBUG - 2022-03-22 17:13:11 --> No URI present. Default controller set.
INFO - 2022-03-22 17:13:11 --> Router Class Initialized
INFO - 2022-03-22 17:13:11 --> Output Class Initialized
INFO - 2022-03-22 17:13:11 --> Security Class Initialized
DEBUG - 2022-03-22 17:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 17:13:11 --> Input Class Initialized
INFO - 2022-03-22 17:13:11 --> Language Class Initialized
INFO - 2022-03-22 17:13:11 --> Loader Class Initialized
INFO - 2022-03-22 17:13:11 --> Helper loaded: url_helper
INFO - 2022-03-22 17:13:11 --> Helper loaded: form_helper
INFO - 2022-03-22 17:13:11 --> Helper loaded: common_helper
INFO - 2022-03-22 17:13:11 --> Database Driver Class Initialized
DEBUG - 2022-03-22 17:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 17:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 17:13:11 --> Controller Class Initialized
INFO - 2022-03-22 17:13:11 --> Form Validation Class Initialized
DEBUG - 2022-03-22 17:13:11 --> Encrypt Class Initialized
DEBUG - 2022-03-22 17:13:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 17:13:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 17:13:11 --> Email Class Initialized
INFO - 2022-03-22 17:13:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 17:13:11 --> Calendar Class Initialized
INFO - 2022-03-22 17:13:12 --> Model "Login_model" initialized
INFO - 2022-03-22 17:13:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 17:13:12 --> Final output sent to browser
DEBUG - 2022-03-22 17:13:12 --> Total execution time: 0.0674
ERROR - 2022-03-22 17:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 17:42:31 --> Config Class Initialized
INFO - 2022-03-22 17:42:31 --> Hooks Class Initialized
DEBUG - 2022-03-22 17:42:31 --> UTF-8 Support Enabled
INFO - 2022-03-22 17:42:31 --> Utf8 Class Initialized
INFO - 2022-03-22 17:42:31 --> URI Class Initialized
DEBUG - 2022-03-22 17:42:31 --> No URI present. Default controller set.
INFO - 2022-03-22 17:42:31 --> Router Class Initialized
INFO - 2022-03-22 17:42:31 --> Output Class Initialized
INFO - 2022-03-22 17:42:31 --> Security Class Initialized
DEBUG - 2022-03-22 17:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 17:42:31 --> Input Class Initialized
INFO - 2022-03-22 17:42:31 --> Language Class Initialized
INFO - 2022-03-22 17:42:31 --> Loader Class Initialized
INFO - 2022-03-22 17:42:31 --> Helper loaded: url_helper
INFO - 2022-03-22 17:42:31 --> Helper loaded: form_helper
INFO - 2022-03-22 17:42:31 --> Helper loaded: common_helper
INFO - 2022-03-22 17:42:31 --> Database Driver Class Initialized
DEBUG - 2022-03-22 17:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 17:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 17:42:31 --> Controller Class Initialized
INFO - 2022-03-22 17:42:31 --> Form Validation Class Initialized
DEBUG - 2022-03-22 17:42:31 --> Encrypt Class Initialized
DEBUG - 2022-03-22 17:42:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 17:42:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 17:42:31 --> Email Class Initialized
INFO - 2022-03-22 17:42:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 17:42:31 --> Calendar Class Initialized
INFO - 2022-03-22 17:42:31 --> Model "Login_model" initialized
INFO - 2022-03-22 17:42:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 17:42:31 --> Final output sent to browser
DEBUG - 2022-03-22 17:42:31 --> Total execution time: 0.0562
ERROR - 2022-03-22 22:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 22:54:44 --> Config Class Initialized
INFO - 2022-03-22 22:54:44 --> Hooks Class Initialized
DEBUG - 2022-03-22 22:54:44 --> UTF-8 Support Enabled
INFO - 2022-03-22 22:54:44 --> Utf8 Class Initialized
INFO - 2022-03-22 22:54:44 --> URI Class Initialized
DEBUG - 2022-03-22 22:54:44 --> No URI present. Default controller set.
INFO - 2022-03-22 22:54:44 --> Router Class Initialized
INFO - 2022-03-22 22:54:44 --> Output Class Initialized
INFO - 2022-03-22 22:54:44 --> Security Class Initialized
DEBUG - 2022-03-22 22:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 22:54:44 --> Input Class Initialized
INFO - 2022-03-22 22:54:44 --> Language Class Initialized
INFO - 2022-03-22 22:54:44 --> Loader Class Initialized
INFO - 2022-03-22 22:54:44 --> Helper loaded: url_helper
INFO - 2022-03-22 22:54:44 --> Helper loaded: form_helper
INFO - 2022-03-22 22:54:44 --> Helper loaded: common_helper
INFO - 2022-03-22 22:54:44 --> Database Driver Class Initialized
DEBUG - 2022-03-22 22:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 22:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 22:54:44 --> Controller Class Initialized
INFO - 2022-03-22 22:54:44 --> Form Validation Class Initialized
DEBUG - 2022-03-22 22:54:44 --> Encrypt Class Initialized
DEBUG - 2022-03-22 22:54:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 22:54:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 22:54:44 --> Email Class Initialized
INFO - 2022-03-22 22:54:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 22:54:44 --> Calendar Class Initialized
INFO - 2022-03-22 22:54:44 --> Model "Login_model" initialized
INFO - 2022-03-22 22:54:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 22:54:44 --> Final output sent to browser
DEBUG - 2022-03-22 22:54:44 --> Total execution time: 0.0647
ERROR - 2022-03-22 22:55:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 22:55:04 --> Config Class Initialized
INFO - 2022-03-22 22:55:04 --> Hooks Class Initialized
DEBUG - 2022-03-22 22:55:04 --> UTF-8 Support Enabled
INFO - 2022-03-22 22:55:04 --> Utf8 Class Initialized
INFO - 2022-03-22 22:55:04 --> URI Class Initialized
INFO - 2022-03-22 22:55:04 --> Router Class Initialized
INFO - 2022-03-22 22:55:04 --> Output Class Initialized
INFO - 2022-03-22 22:55:04 --> Security Class Initialized
DEBUG - 2022-03-22 22:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 22:55:04 --> Input Class Initialized
INFO - 2022-03-22 22:55:04 --> Language Class Initialized
INFO - 2022-03-22 22:55:04 --> Loader Class Initialized
INFO - 2022-03-22 22:55:04 --> Helper loaded: url_helper
INFO - 2022-03-22 22:55:04 --> Helper loaded: form_helper
INFO - 2022-03-22 22:55:04 --> Helper loaded: common_helper
INFO - 2022-03-22 22:55:04 --> Database Driver Class Initialized
DEBUG - 2022-03-22 22:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 22:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 22:55:04 --> Controller Class Initialized
INFO - 2022-03-22 22:55:04 --> Form Validation Class Initialized
DEBUG - 2022-03-22 22:55:04 --> Encrypt Class Initialized
DEBUG - 2022-03-22 22:55:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 22:55:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 22:55:04 --> Email Class Initialized
INFO - 2022-03-22 22:55:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 22:55:04 --> Calendar Class Initialized
INFO - 2022-03-22 22:55:04 --> Model "Login_model" initialized
INFO - 2022-03-22 22:55:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-22 22:55:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 22:55:05 --> Config Class Initialized
INFO - 2022-03-22 22:55:05 --> Hooks Class Initialized
DEBUG - 2022-03-22 22:55:05 --> UTF-8 Support Enabled
INFO - 2022-03-22 22:55:05 --> Utf8 Class Initialized
INFO - 2022-03-22 22:55:05 --> URI Class Initialized
INFO - 2022-03-22 22:55:05 --> Router Class Initialized
INFO - 2022-03-22 22:55:05 --> Output Class Initialized
INFO - 2022-03-22 22:55:05 --> Security Class Initialized
DEBUG - 2022-03-22 22:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 22:55:05 --> Input Class Initialized
INFO - 2022-03-22 22:55:05 --> Language Class Initialized
INFO - 2022-03-22 22:55:05 --> Loader Class Initialized
INFO - 2022-03-22 22:55:05 --> Helper loaded: url_helper
INFO - 2022-03-22 22:55:05 --> Helper loaded: form_helper
INFO - 2022-03-22 22:55:05 --> Helper loaded: common_helper
INFO - 2022-03-22 22:55:05 --> Database Driver Class Initialized
DEBUG - 2022-03-22 22:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 22:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 22:55:05 --> Controller Class Initialized
INFO - 2022-03-22 22:55:05 --> Form Validation Class Initialized
DEBUG - 2022-03-22 22:55:05 --> Encrypt Class Initialized
INFO - 2022-03-22 22:55:05 --> Model "Login_model" initialized
INFO - 2022-03-22 22:55:05 --> Model "Dashboard_model" initialized
INFO - 2022-03-22 22:55:05 --> Model "Case_model" initialized
INFO - 2022-03-22 22:55:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 22:55:09 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-22 22:55:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 22:55:09 --> Final output sent to browser
DEBUG - 2022-03-22 22:55:09 --> Total execution time: 3.9801
ERROR - 2022-03-22 22:55:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 22:55:44 --> Config Class Initialized
INFO - 2022-03-22 22:55:44 --> Hooks Class Initialized
DEBUG - 2022-03-22 22:55:44 --> UTF-8 Support Enabled
INFO - 2022-03-22 22:55:44 --> Utf8 Class Initialized
INFO - 2022-03-22 22:55:44 --> URI Class Initialized
INFO - 2022-03-22 22:55:44 --> Router Class Initialized
INFO - 2022-03-22 22:55:44 --> Output Class Initialized
INFO - 2022-03-22 22:55:44 --> Security Class Initialized
DEBUG - 2022-03-22 22:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 22:55:44 --> Input Class Initialized
INFO - 2022-03-22 22:55:44 --> Language Class Initialized
INFO - 2022-03-22 22:55:44 --> Loader Class Initialized
INFO - 2022-03-22 22:55:44 --> Helper loaded: url_helper
INFO - 2022-03-22 22:55:44 --> Helper loaded: form_helper
INFO - 2022-03-22 22:55:44 --> Helper loaded: common_helper
INFO - 2022-03-22 22:55:44 --> Database Driver Class Initialized
DEBUG - 2022-03-22 22:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 22:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 22:55:44 --> Controller Class Initialized
INFO - 2022-03-22 22:55:44 --> Form Validation Class Initialized
DEBUG - 2022-03-22 22:55:44 --> Encrypt Class Initialized
INFO - 2022-03-22 22:55:44 --> Model "Patient_model" initialized
INFO - 2022-03-22 22:55:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 22:55:44 --> Model "Referredby_model" initialized
INFO - 2022-03-22 22:55:44 --> Model "Prefix_master" initialized
INFO - 2022-03-22 22:55:44 --> Model "Hospital_model" initialized
INFO - 2022-03-22 22:55:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 22:55:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 22:55:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 22:55:45 --> Final output sent to browser
DEBUG - 2022-03-22 22:55:45 --> Total execution time: 0.2451
ERROR - 2022-03-22 22:55:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 22:55:48 --> Config Class Initialized
INFO - 2022-03-22 22:55:48 --> Hooks Class Initialized
DEBUG - 2022-03-22 22:55:48 --> UTF-8 Support Enabled
INFO - 2022-03-22 22:55:48 --> Utf8 Class Initialized
INFO - 2022-03-22 22:55:48 --> URI Class Initialized
INFO - 2022-03-22 22:55:48 --> Router Class Initialized
INFO - 2022-03-22 22:55:48 --> Output Class Initialized
INFO - 2022-03-22 22:55:48 --> Security Class Initialized
DEBUG - 2022-03-22 22:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 22:55:48 --> Input Class Initialized
INFO - 2022-03-22 22:55:48 --> Language Class Initialized
INFO - 2022-03-22 22:55:48 --> Loader Class Initialized
INFO - 2022-03-22 22:55:48 --> Helper loaded: url_helper
INFO - 2022-03-22 22:55:48 --> Helper loaded: form_helper
INFO - 2022-03-22 22:55:48 --> Helper loaded: common_helper
INFO - 2022-03-22 22:55:48 --> Database Driver Class Initialized
DEBUG - 2022-03-22 22:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 22:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 22:55:48 --> Controller Class Initialized
INFO - 2022-03-22 22:55:48 --> Form Validation Class Initialized
DEBUG - 2022-03-22 22:55:48 --> Encrypt Class Initialized
INFO - 2022-03-22 22:55:48 --> Model "Patient_model" initialized
INFO - 2022-03-22 22:55:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 22:55:48 --> Model "Referredby_model" initialized
INFO - 2022-03-22 22:55:48 --> Model "Prefix_master" initialized
INFO - 2022-03-22 22:55:48 --> Model "Hospital_model" initialized
INFO - 2022-03-22 22:55:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 22:55:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-22 22:55:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 22:55:48 --> Final output sent to browser
DEBUG - 2022-03-22 22:55:48 --> Total execution time: 0.0552
ERROR - 2022-03-22 22:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 22:56:04 --> Config Class Initialized
INFO - 2022-03-22 22:56:04 --> Hooks Class Initialized
DEBUG - 2022-03-22 22:56:04 --> UTF-8 Support Enabled
INFO - 2022-03-22 22:56:04 --> Utf8 Class Initialized
INFO - 2022-03-22 22:56:04 --> URI Class Initialized
INFO - 2022-03-22 22:56:04 --> Router Class Initialized
INFO - 2022-03-22 22:56:04 --> Output Class Initialized
INFO - 2022-03-22 22:56:04 --> Security Class Initialized
DEBUG - 2022-03-22 22:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 22:56:04 --> Input Class Initialized
INFO - 2022-03-22 22:56:04 --> Language Class Initialized
INFO - 2022-03-22 22:56:04 --> Loader Class Initialized
INFO - 2022-03-22 22:56:04 --> Helper loaded: url_helper
INFO - 2022-03-22 22:56:04 --> Helper loaded: form_helper
INFO - 2022-03-22 22:56:04 --> Helper loaded: common_helper
INFO - 2022-03-22 22:56:04 --> Database Driver Class Initialized
DEBUG - 2022-03-22 22:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 22:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 22:56:04 --> Controller Class Initialized
INFO - 2022-03-22 22:56:04 --> Form Validation Class Initialized
DEBUG - 2022-03-22 22:56:04 --> Encrypt Class Initialized
INFO - 2022-03-22 22:56:04 --> Model "Patient_model" initialized
INFO - 2022-03-22 22:56:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 22:56:04 --> Model "Prefix_master" initialized
INFO - 2022-03-22 22:56:04 --> Model "Users_model" initialized
INFO - 2022-03-22 22:56:04 --> Model "Hospital_model" initialized
INFO - 2022-03-22 22:56:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 22:56:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 22:56:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 22:56:04 --> Final output sent to browser
DEBUG - 2022-03-22 22:56:04 --> Total execution time: 0.2957
ERROR - 2022-03-22 23:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:16:50 --> Config Class Initialized
INFO - 2022-03-22 23:16:50 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:16:50 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:16:50 --> Utf8 Class Initialized
INFO - 2022-03-22 23:16:50 --> URI Class Initialized
INFO - 2022-03-22 23:16:50 --> Router Class Initialized
INFO - 2022-03-22 23:16:50 --> Output Class Initialized
INFO - 2022-03-22 23:16:50 --> Security Class Initialized
DEBUG - 2022-03-22 23:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:16:50 --> Input Class Initialized
INFO - 2022-03-22 23:16:50 --> Language Class Initialized
INFO - 2022-03-22 23:16:50 --> Loader Class Initialized
INFO - 2022-03-22 23:16:50 --> Helper loaded: url_helper
INFO - 2022-03-22 23:16:50 --> Helper loaded: form_helper
INFO - 2022-03-22 23:16:50 --> Helper loaded: common_helper
INFO - 2022-03-22 23:16:50 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:16:50 --> Controller Class Initialized
INFO - 2022-03-22 23:16:50 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:16:50 --> Encrypt Class Initialized
DEBUG - 2022-03-22 23:16:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 23:16:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 23:16:50 --> Email Class Initialized
INFO - 2022-03-22 23:16:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 23:16:50 --> Calendar Class Initialized
INFO - 2022-03-22 23:16:50 --> Model "Login_model" initialized
INFO - 2022-03-22 23:16:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 23:16:50 --> Final output sent to browser
DEBUG - 2022-03-22 23:16:50 --> Total execution time: 0.0567
ERROR - 2022-03-22 23:17:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:17:16 --> Config Class Initialized
INFO - 2022-03-22 23:17:16 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:17:16 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:17:16 --> Utf8 Class Initialized
INFO - 2022-03-22 23:17:16 --> URI Class Initialized
INFO - 2022-03-22 23:17:16 --> Router Class Initialized
INFO - 2022-03-22 23:17:16 --> Output Class Initialized
INFO - 2022-03-22 23:17:16 --> Security Class Initialized
DEBUG - 2022-03-22 23:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:17:16 --> Input Class Initialized
INFO - 2022-03-22 23:17:16 --> Language Class Initialized
INFO - 2022-03-22 23:17:16 --> Loader Class Initialized
INFO - 2022-03-22 23:17:16 --> Helper loaded: url_helper
INFO - 2022-03-22 23:17:16 --> Helper loaded: form_helper
INFO - 2022-03-22 23:17:16 --> Helper loaded: common_helper
INFO - 2022-03-22 23:17:16 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:17:16 --> Controller Class Initialized
INFO - 2022-03-22 23:17:16 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:17:16 --> Encrypt Class Initialized
DEBUG - 2022-03-22 23:17:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 23:17:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 23:17:16 --> Email Class Initialized
INFO - 2022-03-22 23:17:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 23:17:16 --> Calendar Class Initialized
INFO - 2022-03-22 23:17:16 --> Model "Login_model" initialized
INFO - 2022-03-22 23:17:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-22 23:17:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:17:16 --> Config Class Initialized
INFO - 2022-03-22 23:17:16 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:17:16 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:17:16 --> Utf8 Class Initialized
INFO - 2022-03-22 23:17:16 --> URI Class Initialized
INFO - 2022-03-22 23:17:16 --> Router Class Initialized
INFO - 2022-03-22 23:17:16 --> Output Class Initialized
INFO - 2022-03-22 23:17:16 --> Security Class Initialized
DEBUG - 2022-03-22 23:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:17:16 --> Input Class Initialized
INFO - 2022-03-22 23:17:16 --> Language Class Initialized
INFO - 2022-03-22 23:17:16 --> Loader Class Initialized
INFO - 2022-03-22 23:17:16 --> Helper loaded: url_helper
INFO - 2022-03-22 23:17:16 --> Helper loaded: form_helper
INFO - 2022-03-22 23:17:16 --> Helper loaded: common_helper
INFO - 2022-03-22 23:17:16 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:17:16 --> Controller Class Initialized
INFO - 2022-03-22 23:17:16 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:17:16 --> Encrypt Class Initialized
INFO - 2022-03-22 23:17:16 --> Model "Login_model" initialized
INFO - 2022-03-22 23:17:16 --> Model "Dashboard_model" initialized
INFO - 2022-03-22 23:17:16 --> Model "Case_model" initialized
INFO - 2022-03-22 23:17:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:17:17 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-22 23:17:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:17:17 --> Final output sent to browser
DEBUG - 2022-03-22 23:17:17 --> Total execution time: 0.2302
ERROR - 2022-03-22 23:17:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:17:42 --> Config Class Initialized
INFO - 2022-03-22 23:17:42 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:17:42 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:17:42 --> Utf8 Class Initialized
INFO - 2022-03-22 23:17:42 --> URI Class Initialized
INFO - 2022-03-22 23:17:42 --> Router Class Initialized
INFO - 2022-03-22 23:17:42 --> Output Class Initialized
INFO - 2022-03-22 23:17:42 --> Security Class Initialized
DEBUG - 2022-03-22 23:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:17:42 --> Input Class Initialized
INFO - 2022-03-22 23:17:42 --> Language Class Initialized
INFO - 2022-03-22 23:17:42 --> Loader Class Initialized
INFO - 2022-03-22 23:17:42 --> Helper loaded: url_helper
INFO - 2022-03-22 23:17:42 --> Helper loaded: form_helper
INFO - 2022-03-22 23:17:42 --> Helper loaded: common_helper
INFO - 2022-03-22 23:17:42 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:17:42 --> Controller Class Initialized
INFO - 2022-03-22 23:17:42 --> Form Validation Class Initialized
INFO - 2022-03-22 23:17:42 --> Model "Case_model" initialized
INFO - 2022-03-22 23:17:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:17:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:17:42 --> Model "Case_model" initialized
INFO - 2022-03-22 23:17:43 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2022-03-22 23:17:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:17:43 --> Final output sent to browser
DEBUG - 2022-03-22 23:17:43 --> Total execution time: 0.0332
ERROR - 2022-03-22 23:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:18:59 --> Config Class Initialized
INFO - 2022-03-22 23:18:59 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:18:59 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:18:59 --> Utf8 Class Initialized
INFO - 2022-03-22 23:18:59 --> URI Class Initialized
INFO - 2022-03-22 23:18:59 --> Router Class Initialized
INFO - 2022-03-22 23:18:59 --> Output Class Initialized
INFO - 2022-03-22 23:18:59 --> Security Class Initialized
DEBUG - 2022-03-22 23:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:18:59 --> Input Class Initialized
INFO - 2022-03-22 23:18:59 --> Language Class Initialized
INFO - 2022-03-22 23:18:59 --> Loader Class Initialized
INFO - 2022-03-22 23:18:59 --> Helper loaded: url_helper
INFO - 2022-03-22 23:18:59 --> Helper loaded: form_helper
INFO - 2022-03-22 23:18:59 --> Helper loaded: common_helper
INFO - 2022-03-22 23:18:59 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:18:59 --> Controller Class Initialized
INFO - 2022-03-22 23:18:59 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:18:59 --> Encrypt Class Initialized
INFO - 2022-03-22 23:18:59 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:18:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:18:59 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:18:59 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:18:59 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:18:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:18:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-22 23:18:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:18:59 --> Final output sent to browser
DEBUG - 2022-03-22 23:18:59 --> Total execution time: 0.0854
ERROR - 2022-03-22 23:34:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:34:16 --> Config Class Initialized
INFO - 2022-03-22 23:34:16 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:34:16 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:34:16 --> Utf8 Class Initialized
INFO - 2022-03-22 23:34:16 --> URI Class Initialized
DEBUG - 2022-03-22 23:34:16 --> No URI present. Default controller set.
INFO - 2022-03-22 23:34:16 --> Router Class Initialized
INFO - 2022-03-22 23:34:16 --> Output Class Initialized
INFO - 2022-03-22 23:34:16 --> Security Class Initialized
DEBUG - 2022-03-22 23:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:34:16 --> Input Class Initialized
INFO - 2022-03-22 23:34:16 --> Language Class Initialized
INFO - 2022-03-22 23:34:16 --> Loader Class Initialized
INFO - 2022-03-22 23:34:16 --> Helper loaded: url_helper
INFO - 2022-03-22 23:34:16 --> Helper loaded: form_helper
INFO - 2022-03-22 23:34:16 --> Helper loaded: common_helper
INFO - 2022-03-22 23:34:16 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:34:16 --> Controller Class Initialized
INFO - 2022-03-22 23:34:17 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:34:17 --> Encrypt Class Initialized
DEBUG - 2022-03-22 23:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 23:34:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 23:34:17 --> Email Class Initialized
INFO - 2022-03-22 23:34:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 23:34:17 --> Calendar Class Initialized
INFO - 2022-03-22 23:34:17 --> Model "Login_model" initialized
INFO - 2022-03-22 23:34:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-22 23:34:17 --> Final output sent to browser
DEBUG - 2022-03-22 23:34:17 --> Total execution time: 0.0847
ERROR - 2022-03-22 23:34:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:34:33 --> Config Class Initialized
INFO - 2022-03-22 23:34:33 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:34:33 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:34:33 --> Utf8 Class Initialized
INFO - 2022-03-22 23:34:33 --> URI Class Initialized
INFO - 2022-03-22 23:34:33 --> Router Class Initialized
INFO - 2022-03-22 23:34:33 --> Output Class Initialized
INFO - 2022-03-22 23:34:33 --> Security Class Initialized
DEBUG - 2022-03-22 23:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:34:33 --> Input Class Initialized
INFO - 2022-03-22 23:34:33 --> Language Class Initialized
INFO - 2022-03-22 23:34:33 --> Loader Class Initialized
INFO - 2022-03-22 23:34:33 --> Helper loaded: url_helper
INFO - 2022-03-22 23:34:33 --> Helper loaded: form_helper
INFO - 2022-03-22 23:34:33 --> Helper loaded: common_helper
INFO - 2022-03-22 23:34:33 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:34:33 --> Controller Class Initialized
INFO - 2022-03-22 23:34:33 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:34:33 --> Encrypt Class Initialized
DEBUG - 2022-03-22 23:34:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 23:34:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 23:34:33 --> Email Class Initialized
INFO - 2022-03-22 23:34:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 23:34:33 --> Calendar Class Initialized
INFO - 2022-03-22 23:34:33 --> Model "Login_model" initialized
INFO - 2022-03-22 23:34:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-22 23:34:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:34:33 --> Config Class Initialized
INFO - 2022-03-22 23:34:33 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:34:33 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:34:33 --> Utf8 Class Initialized
INFO - 2022-03-22 23:34:33 --> URI Class Initialized
INFO - 2022-03-22 23:34:33 --> Router Class Initialized
INFO - 2022-03-22 23:34:33 --> Output Class Initialized
INFO - 2022-03-22 23:34:33 --> Security Class Initialized
DEBUG - 2022-03-22 23:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:34:33 --> Input Class Initialized
INFO - 2022-03-22 23:34:33 --> Language Class Initialized
INFO - 2022-03-22 23:34:33 --> Loader Class Initialized
INFO - 2022-03-22 23:34:33 --> Helper loaded: url_helper
INFO - 2022-03-22 23:34:33 --> Helper loaded: form_helper
INFO - 2022-03-22 23:34:33 --> Helper loaded: common_helper
INFO - 2022-03-22 23:34:33 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:34:33 --> Controller Class Initialized
INFO - 2022-03-22 23:34:33 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:34:33 --> Encrypt Class Initialized
INFO - 2022-03-22 23:34:33 --> Model "Login_model" initialized
INFO - 2022-03-22 23:34:33 --> Model "Dashboard_model" initialized
INFO - 2022-03-22 23:34:33 --> Model "Case_model" initialized
ERROR - 2022-03-22 23:34:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:34:36 --> Config Class Initialized
INFO - 2022-03-22 23:34:36 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:34:36 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:34:36 --> Utf8 Class Initialized
INFO - 2022-03-22 23:34:36 --> URI Class Initialized
INFO - 2022-03-22 23:34:36 --> Router Class Initialized
INFO - 2022-03-22 23:34:36 --> Output Class Initialized
INFO - 2022-03-22 23:34:36 --> Security Class Initialized
DEBUG - 2022-03-22 23:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:34:36 --> Input Class Initialized
INFO - 2022-03-22 23:34:36 --> Language Class Initialized
INFO - 2022-03-22 23:34:36 --> Loader Class Initialized
INFO - 2022-03-22 23:34:36 --> Helper loaded: url_helper
INFO - 2022-03-22 23:34:36 --> Helper loaded: form_helper
INFO - 2022-03-22 23:34:36 --> Helper loaded: common_helper
INFO - 2022-03-22 23:34:36 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:34:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:34:55 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-22 23:34:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:34:55 --> Final output sent to browser
DEBUG - 2022-03-22 23:34:55 --> Total execution time: 21.1704
INFO - 2022-03-22 23:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:34:55 --> Controller Class Initialized
INFO - 2022-03-22 23:34:55 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:34:55 --> Encrypt Class Initialized
DEBUG - 2022-03-22 23:34:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 23:34:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-22 23:34:55 --> Email Class Initialized
INFO - 2022-03-22 23:34:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-22 23:34:55 --> Calendar Class Initialized
INFO - 2022-03-22 23:34:55 --> Model "Login_model" initialized
INFO - 2022-03-22 23:34:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-22 23:34:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:34:55 --> Config Class Initialized
INFO - 2022-03-22 23:34:55 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:34:55 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:34:55 --> Utf8 Class Initialized
INFO - 2022-03-22 23:34:55 --> URI Class Initialized
INFO - 2022-03-22 23:34:55 --> Router Class Initialized
INFO - 2022-03-22 23:34:55 --> Output Class Initialized
INFO - 2022-03-22 23:34:55 --> Security Class Initialized
DEBUG - 2022-03-22 23:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:34:55 --> Input Class Initialized
INFO - 2022-03-22 23:34:55 --> Language Class Initialized
INFO - 2022-03-22 23:34:55 --> Loader Class Initialized
INFO - 2022-03-22 23:34:55 --> Helper loaded: url_helper
INFO - 2022-03-22 23:34:55 --> Helper loaded: form_helper
INFO - 2022-03-22 23:34:55 --> Helper loaded: common_helper
INFO - 2022-03-22 23:34:55 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:34:55 --> Controller Class Initialized
INFO - 2022-03-22 23:34:55 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:34:55 --> Encrypt Class Initialized
INFO - 2022-03-22 23:34:55 --> Model "Login_model" initialized
INFO - 2022-03-22 23:34:55 --> Model "Dashboard_model" initialized
INFO - 2022-03-22 23:34:55 --> Model "Case_model" initialized
INFO - 2022-03-22 23:35:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:35:17 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-22 23:35:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:35:17 --> Final output sent to browser
DEBUG - 2022-03-22 23:35:17 --> Total execution time: 21.3019
ERROR - 2022-03-22 23:35:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:35:17 --> Config Class Initialized
INFO - 2022-03-22 23:35:17 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:35:17 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:35:17 --> Utf8 Class Initialized
INFO - 2022-03-22 23:35:17 --> URI Class Initialized
INFO - 2022-03-22 23:35:17 --> Router Class Initialized
INFO - 2022-03-22 23:35:17 --> Output Class Initialized
INFO - 2022-03-22 23:35:17 --> Security Class Initialized
DEBUG - 2022-03-22 23:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:35:17 --> Input Class Initialized
INFO - 2022-03-22 23:35:17 --> Language Class Initialized
ERROR - 2022-03-22 23:35:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-22 23:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:36:42 --> Config Class Initialized
INFO - 2022-03-22 23:36:42 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:36:42 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:36:42 --> Utf8 Class Initialized
INFO - 2022-03-22 23:36:42 --> URI Class Initialized
INFO - 2022-03-22 23:36:42 --> Router Class Initialized
INFO - 2022-03-22 23:36:42 --> Output Class Initialized
INFO - 2022-03-22 23:36:42 --> Security Class Initialized
DEBUG - 2022-03-22 23:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:36:42 --> Input Class Initialized
INFO - 2022-03-22 23:36:42 --> Language Class Initialized
INFO - 2022-03-22 23:36:42 --> Loader Class Initialized
INFO - 2022-03-22 23:36:42 --> Helper loaded: url_helper
INFO - 2022-03-22 23:36:42 --> Helper loaded: form_helper
INFO - 2022-03-22 23:36:42 --> Helper loaded: common_helper
INFO - 2022-03-22 23:36:42 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:36:42 --> Controller Class Initialized
INFO - 2022-03-22 23:36:42 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:36:42 --> Encrypt Class Initialized
INFO - 2022-03-22 23:36:42 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:36:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:36:42 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:36:42 --> Model "Users_model" initialized
INFO - 2022-03-22 23:36:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 23:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:36:43 --> Config Class Initialized
INFO - 2022-03-22 23:36:43 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:36:43 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:36:43 --> Utf8 Class Initialized
INFO - 2022-03-22 23:36:43 --> URI Class Initialized
INFO - 2022-03-22 23:36:43 --> Router Class Initialized
INFO - 2022-03-22 23:36:43 --> Output Class Initialized
INFO - 2022-03-22 23:36:43 --> Security Class Initialized
DEBUG - 2022-03-22 23:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:36:43 --> Input Class Initialized
INFO - 2022-03-22 23:36:43 --> Language Class Initialized
INFO - 2022-03-22 23:36:43 --> Loader Class Initialized
INFO - 2022-03-22 23:36:43 --> Helper loaded: url_helper
INFO - 2022-03-22 23:36:43 --> Helper loaded: form_helper
INFO - 2022-03-22 23:36:43 --> Helper loaded: common_helper
INFO - 2022-03-22 23:36:43 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:36:43 --> Controller Class Initialized
INFO - 2022-03-22 23:36:43 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:36:43 --> Encrypt Class Initialized
INFO - 2022-03-22 23:36:43 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:36:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:36:43 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:36:43 --> Model "Users_model" initialized
INFO - 2022-03-22 23:36:43 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:36:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:36:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:36:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:36:45 --> Final output sent to browser
DEBUG - 2022-03-22 23:36:45 --> Total execution time: 1.2645
ERROR - 2022-03-22 23:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:37:16 --> Config Class Initialized
INFO - 2022-03-22 23:37:16 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:37:16 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:37:16 --> Utf8 Class Initialized
INFO - 2022-03-22 23:37:16 --> URI Class Initialized
INFO - 2022-03-22 23:37:16 --> Router Class Initialized
INFO - 2022-03-22 23:37:16 --> Output Class Initialized
INFO - 2022-03-22 23:37:16 --> Security Class Initialized
DEBUG - 2022-03-22 23:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:37:16 --> Input Class Initialized
INFO - 2022-03-22 23:37:16 --> Language Class Initialized
INFO - 2022-03-22 23:37:16 --> Loader Class Initialized
INFO - 2022-03-22 23:37:16 --> Helper loaded: url_helper
INFO - 2022-03-22 23:37:16 --> Helper loaded: form_helper
INFO - 2022-03-22 23:37:16 --> Helper loaded: common_helper
INFO - 2022-03-22 23:37:16 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:37:16 --> Controller Class Initialized
INFO - 2022-03-22 23:37:16 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:37:16 --> Encrypt Class Initialized
INFO - 2022-03-22 23:37:16 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:37:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:37:16 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:37:16 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:37:16 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:37:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:37:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 23:37:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:37:17 --> Final output sent to browser
DEBUG - 2022-03-22 23:37:17 --> Total execution time: 1.2001
ERROR - 2022-03-22 23:37:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:37:39 --> Config Class Initialized
INFO - 2022-03-22 23:37:39 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:37:39 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:37:39 --> Utf8 Class Initialized
INFO - 2022-03-22 23:37:39 --> URI Class Initialized
INFO - 2022-03-22 23:37:39 --> Router Class Initialized
INFO - 2022-03-22 23:37:39 --> Output Class Initialized
INFO - 2022-03-22 23:37:39 --> Security Class Initialized
DEBUG - 2022-03-22 23:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:37:39 --> Input Class Initialized
INFO - 2022-03-22 23:37:39 --> Language Class Initialized
INFO - 2022-03-22 23:37:39 --> Loader Class Initialized
INFO - 2022-03-22 23:37:39 --> Helper loaded: url_helper
INFO - 2022-03-22 23:37:39 --> Helper loaded: form_helper
INFO - 2022-03-22 23:37:39 --> Helper loaded: common_helper
INFO - 2022-03-22 23:37:39 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:37:39 --> Controller Class Initialized
INFO - 2022-03-22 23:37:39 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:37:39 --> Encrypt Class Initialized
INFO - 2022-03-22 23:37:39 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:37:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:37:39 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:37:39 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:37:39 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 23:37:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:37:39 --> Config Class Initialized
INFO - 2022-03-22 23:37:39 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:37:39 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:37:39 --> Utf8 Class Initialized
INFO - 2022-03-22 23:37:39 --> URI Class Initialized
INFO - 2022-03-22 23:37:39 --> Router Class Initialized
INFO - 2022-03-22 23:37:39 --> Output Class Initialized
INFO - 2022-03-22 23:37:39 --> Security Class Initialized
DEBUG - 2022-03-22 23:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:37:39 --> Input Class Initialized
INFO - 2022-03-22 23:37:39 --> Language Class Initialized
INFO - 2022-03-22 23:37:39 --> Loader Class Initialized
INFO - 2022-03-22 23:37:39 --> Helper loaded: url_helper
INFO - 2022-03-22 23:37:39 --> Helper loaded: form_helper
INFO - 2022-03-22 23:37:39 --> Helper loaded: common_helper
INFO - 2022-03-22 23:37:39 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:37:39 --> Controller Class Initialized
INFO - 2022-03-22 23:37:39 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:37:39 --> Encrypt Class Initialized
INFO - 2022-03-22 23:37:39 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:37:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:37:39 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:37:39 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:37:39 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:37:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:37:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 23:37:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:37:39 --> Final output sent to browser
DEBUG - 2022-03-22 23:37:39 --> Total execution time: 0.0320
ERROR - 2022-03-22 23:37:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:37:40 --> Config Class Initialized
INFO - 2022-03-22 23:37:40 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:37:40 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:37:40 --> Utf8 Class Initialized
INFO - 2022-03-22 23:37:40 --> URI Class Initialized
INFO - 2022-03-22 23:37:40 --> Router Class Initialized
INFO - 2022-03-22 23:37:40 --> Output Class Initialized
INFO - 2022-03-22 23:37:40 --> Security Class Initialized
DEBUG - 2022-03-22 23:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:37:40 --> Input Class Initialized
INFO - 2022-03-22 23:37:40 --> Language Class Initialized
INFO - 2022-03-22 23:37:40 --> Loader Class Initialized
INFO - 2022-03-22 23:37:40 --> Helper loaded: url_helper
INFO - 2022-03-22 23:37:40 --> Helper loaded: form_helper
INFO - 2022-03-22 23:37:40 --> Helper loaded: common_helper
INFO - 2022-03-22 23:37:40 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:37:40 --> Controller Class Initialized
INFO - 2022-03-22 23:37:40 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:37:40 --> Encrypt Class Initialized
INFO - 2022-03-22 23:37:40 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:37:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:37:40 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:37:40 --> Model "Users_model" initialized
INFO - 2022-03-22 23:37:40 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:37:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:37:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:37:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:37:40 --> Final output sent to browser
DEBUG - 2022-03-22 23:37:40 --> Total execution time: 0.0380
ERROR - 2022-03-22 23:41:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:41:20 --> Config Class Initialized
INFO - 2022-03-22 23:41:20 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:41:20 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:41:20 --> Utf8 Class Initialized
INFO - 2022-03-22 23:41:20 --> URI Class Initialized
INFO - 2022-03-22 23:41:20 --> Router Class Initialized
INFO - 2022-03-22 23:41:20 --> Output Class Initialized
INFO - 2022-03-22 23:41:20 --> Security Class Initialized
DEBUG - 2022-03-22 23:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:41:20 --> Input Class Initialized
INFO - 2022-03-22 23:41:20 --> Language Class Initialized
INFO - 2022-03-22 23:41:20 --> Loader Class Initialized
INFO - 2022-03-22 23:41:20 --> Helper loaded: url_helper
INFO - 2022-03-22 23:41:20 --> Helper loaded: form_helper
INFO - 2022-03-22 23:41:20 --> Helper loaded: common_helper
INFO - 2022-03-22 23:41:20 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:41:20 --> Controller Class Initialized
INFO - 2022-03-22 23:41:20 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:41:20 --> Encrypt Class Initialized
INFO - 2022-03-22 23:41:20 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:41:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:41:20 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:41:20 --> Model "Users_model" initialized
INFO - 2022-03-22 23:41:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 23:41:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:41:21 --> Config Class Initialized
INFO - 2022-03-22 23:41:21 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:41:21 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:41:21 --> Utf8 Class Initialized
INFO - 2022-03-22 23:41:21 --> URI Class Initialized
INFO - 2022-03-22 23:41:21 --> Router Class Initialized
INFO - 2022-03-22 23:41:21 --> Output Class Initialized
INFO - 2022-03-22 23:41:21 --> Security Class Initialized
DEBUG - 2022-03-22 23:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:41:21 --> Input Class Initialized
INFO - 2022-03-22 23:41:21 --> Language Class Initialized
INFO - 2022-03-22 23:41:21 --> Loader Class Initialized
INFO - 2022-03-22 23:41:21 --> Helper loaded: url_helper
INFO - 2022-03-22 23:41:21 --> Helper loaded: form_helper
INFO - 2022-03-22 23:41:21 --> Helper loaded: common_helper
INFO - 2022-03-22 23:41:21 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:41:21 --> Controller Class Initialized
INFO - 2022-03-22 23:41:21 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:41:21 --> Encrypt Class Initialized
INFO - 2022-03-22 23:41:21 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:41:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:41:21 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:41:21 --> Model "Users_model" initialized
INFO - 2022-03-22 23:41:21 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:41:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:41:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:41:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:41:21 --> Final output sent to browser
DEBUG - 2022-03-22 23:41:21 --> Total execution time: 0.0439
ERROR - 2022-03-22 23:41:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:41:40 --> Config Class Initialized
INFO - 2022-03-22 23:41:40 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:41:40 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:41:40 --> Utf8 Class Initialized
INFO - 2022-03-22 23:41:40 --> URI Class Initialized
INFO - 2022-03-22 23:41:40 --> Router Class Initialized
INFO - 2022-03-22 23:41:40 --> Output Class Initialized
INFO - 2022-03-22 23:41:40 --> Security Class Initialized
DEBUG - 2022-03-22 23:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:41:40 --> Input Class Initialized
INFO - 2022-03-22 23:41:40 --> Language Class Initialized
INFO - 2022-03-22 23:41:40 --> Loader Class Initialized
INFO - 2022-03-22 23:41:40 --> Helper loaded: url_helper
INFO - 2022-03-22 23:41:40 --> Helper loaded: form_helper
INFO - 2022-03-22 23:41:40 --> Helper loaded: common_helper
INFO - 2022-03-22 23:41:40 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:41:40 --> Controller Class Initialized
INFO - 2022-03-22 23:41:40 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:41:40 --> Encrypt Class Initialized
INFO - 2022-03-22 23:41:40 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:41:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:41:40 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:41:40 --> Model "Users_model" initialized
INFO - 2022-03-22 23:41:40 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:41:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:41:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:41:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:41:40 --> Final output sent to browser
DEBUG - 2022-03-22 23:41:40 --> Total execution time: 0.0464
ERROR - 2022-03-22 23:42:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:42:07 --> Config Class Initialized
INFO - 2022-03-22 23:42:07 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:42:07 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:42:07 --> Utf8 Class Initialized
INFO - 2022-03-22 23:42:07 --> URI Class Initialized
INFO - 2022-03-22 23:42:07 --> Router Class Initialized
INFO - 2022-03-22 23:42:07 --> Output Class Initialized
INFO - 2022-03-22 23:42:07 --> Security Class Initialized
DEBUG - 2022-03-22 23:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:42:07 --> Input Class Initialized
INFO - 2022-03-22 23:42:07 --> Language Class Initialized
INFO - 2022-03-22 23:42:07 --> Loader Class Initialized
INFO - 2022-03-22 23:42:07 --> Helper loaded: url_helper
INFO - 2022-03-22 23:42:07 --> Helper loaded: form_helper
INFO - 2022-03-22 23:42:07 --> Helper loaded: common_helper
INFO - 2022-03-22 23:42:07 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:42:07 --> Controller Class Initialized
INFO - 2022-03-22 23:42:07 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:42:07 --> Encrypt Class Initialized
INFO - 2022-03-22 23:42:07 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:42:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:42:07 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:42:07 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:42:07 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:42:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:42:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-22 23:42:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-22 23:42:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:42:15 --> Config Class Initialized
INFO - 2022-03-22 23:42:15 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:42:15 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:42:15 --> Utf8 Class Initialized
INFO - 2022-03-22 23:42:15 --> URI Class Initialized
INFO - 2022-03-22 23:42:15 --> Router Class Initialized
INFO - 2022-03-22 23:42:15 --> Output Class Initialized
INFO - 2022-03-22 23:42:15 --> Security Class Initialized
DEBUG - 2022-03-22 23:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:42:15 --> Input Class Initialized
INFO - 2022-03-22 23:42:15 --> Language Class Initialized
ERROR - 2022-03-22 23:42:15 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-22 23:42:15 --> Final output sent to browser
DEBUG - 2022-03-22 23:42:15 --> Total execution time: 6.4411
ERROR - 2022-03-22 23:43:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:43:44 --> Config Class Initialized
INFO - 2022-03-22 23:43:44 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:43:44 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:43:44 --> Utf8 Class Initialized
INFO - 2022-03-22 23:43:44 --> URI Class Initialized
INFO - 2022-03-22 23:43:44 --> Router Class Initialized
INFO - 2022-03-22 23:43:44 --> Output Class Initialized
INFO - 2022-03-22 23:43:44 --> Security Class Initialized
DEBUG - 2022-03-22 23:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:43:44 --> Input Class Initialized
INFO - 2022-03-22 23:43:44 --> Language Class Initialized
INFO - 2022-03-22 23:43:44 --> Loader Class Initialized
INFO - 2022-03-22 23:43:44 --> Helper loaded: url_helper
INFO - 2022-03-22 23:43:44 --> Helper loaded: form_helper
INFO - 2022-03-22 23:43:44 --> Helper loaded: common_helper
INFO - 2022-03-22 23:43:44 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:43:44 --> Controller Class Initialized
INFO - 2022-03-22 23:43:44 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:43:44 --> Encrypt Class Initialized
INFO - 2022-03-22 23:43:44 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:43:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:43:44 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:43:44 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:43:44 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:43:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:43:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 23:43:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:43:44 --> Final output sent to browser
DEBUG - 2022-03-22 23:43:44 --> Total execution time: 0.0278
ERROR - 2022-03-22 23:43:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:43:44 --> Config Class Initialized
INFO - 2022-03-22 23:43:44 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:43:44 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:43:44 --> Utf8 Class Initialized
INFO - 2022-03-22 23:43:44 --> URI Class Initialized
INFO - 2022-03-22 23:43:44 --> Router Class Initialized
INFO - 2022-03-22 23:43:44 --> Output Class Initialized
INFO - 2022-03-22 23:43:44 --> Security Class Initialized
DEBUG - 2022-03-22 23:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:43:44 --> Input Class Initialized
INFO - 2022-03-22 23:43:44 --> Language Class Initialized
ERROR - 2022-03-22 23:43:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-22 23:43:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:43:44 --> Config Class Initialized
INFO - 2022-03-22 23:43:44 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:43:44 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:43:44 --> Utf8 Class Initialized
INFO - 2022-03-22 23:43:44 --> URI Class Initialized
INFO - 2022-03-22 23:43:44 --> Router Class Initialized
INFO - 2022-03-22 23:43:44 --> Output Class Initialized
INFO - 2022-03-22 23:43:44 --> Security Class Initialized
DEBUG - 2022-03-22 23:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:43:44 --> Input Class Initialized
INFO - 2022-03-22 23:43:44 --> Language Class Initialized
ERROR - 2022-03-22 23:43:44 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-22 23:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:43:54 --> Config Class Initialized
INFO - 2022-03-22 23:43:54 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:43:54 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:43:54 --> Utf8 Class Initialized
INFO - 2022-03-22 23:43:54 --> URI Class Initialized
INFO - 2022-03-22 23:43:54 --> Router Class Initialized
INFO - 2022-03-22 23:43:54 --> Output Class Initialized
INFO - 2022-03-22 23:43:54 --> Security Class Initialized
DEBUG - 2022-03-22 23:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:43:54 --> Input Class Initialized
INFO - 2022-03-22 23:43:54 --> Language Class Initialized
INFO - 2022-03-22 23:43:54 --> Loader Class Initialized
INFO - 2022-03-22 23:43:54 --> Helper loaded: url_helper
INFO - 2022-03-22 23:43:54 --> Helper loaded: form_helper
INFO - 2022-03-22 23:43:54 --> Helper loaded: common_helper
INFO - 2022-03-22 23:43:54 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:43:54 --> Controller Class Initialized
INFO - 2022-03-22 23:43:54 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:43:54 --> Encrypt Class Initialized
INFO - 2022-03-22 23:43:54 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:43:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:43:54 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:43:54 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:43:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 23:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:43:54 --> Config Class Initialized
INFO - 2022-03-22 23:43:54 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:43:54 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:43:54 --> Utf8 Class Initialized
INFO - 2022-03-22 23:43:54 --> URI Class Initialized
INFO - 2022-03-22 23:43:54 --> Router Class Initialized
INFO - 2022-03-22 23:43:54 --> Output Class Initialized
INFO - 2022-03-22 23:43:54 --> Security Class Initialized
DEBUG - 2022-03-22 23:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:43:54 --> Input Class Initialized
INFO - 2022-03-22 23:43:54 --> Language Class Initialized
INFO - 2022-03-22 23:43:54 --> Loader Class Initialized
INFO - 2022-03-22 23:43:54 --> Helper loaded: url_helper
INFO - 2022-03-22 23:43:54 --> Helper loaded: form_helper
INFO - 2022-03-22 23:43:54 --> Helper loaded: common_helper
INFO - 2022-03-22 23:43:54 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:43:54 --> Controller Class Initialized
INFO - 2022-03-22 23:43:54 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:43:54 --> Encrypt Class Initialized
INFO - 2022-03-22 23:43:54 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:43:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:43:54 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:43:54 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:43:54 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:43:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:44:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-22 23:44:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-22 23:44:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:44:01 --> Config Class Initialized
INFO - 2022-03-22 23:44:01 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:44:01 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:44:01 --> Utf8 Class Initialized
INFO - 2022-03-22 23:44:01 --> URI Class Initialized
INFO - 2022-03-22 23:44:01 --> Router Class Initialized
INFO - 2022-03-22 23:44:01 --> Output Class Initialized
INFO - 2022-03-22 23:44:01 --> Security Class Initialized
DEBUG - 2022-03-22 23:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:44:01 --> Input Class Initialized
INFO - 2022-03-22 23:44:01 --> Language Class Initialized
ERROR - 2022-03-22 23:44:01 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-22 23:44:01 --> Final output sent to browser
DEBUG - 2022-03-22 23:44:01 --> Total execution time: 5.7361
ERROR - 2022-03-22 23:45:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:45:39 --> Config Class Initialized
INFO - 2022-03-22 23:45:39 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:45:39 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:45:39 --> Utf8 Class Initialized
INFO - 2022-03-22 23:45:39 --> URI Class Initialized
INFO - 2022-03-22 23:45:39 --> Router Class Initialized
INFO - 2022-03-22 23:45:39 --> Output Class Initialized
INFO - 2022-03-22 23:45:39 --> Security Class Initialized
DEBUG - 2022-03-22 23:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:45:39 --> Input Class Initialized
INFO - 2022-03-22 23:45:39 --> Language Class Initialized
INFO - 2022-03-22 23:45:39 --> Loader Class Initialized
INFO - 2022-03-22 23:45:39 --> Helper loaded: url_helper
INFO - 2022-03-22 23:45:39 --> Helper loaded: form_helper
INFO - 2022-03-22 23:45:39 --> Helper loaded: common_helper
INFO - 2022-03-22 23:45:39 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:45:39 --> Controller Class Initialized
INFO - 2022-03-22 23:45:39 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:45:39 --> Encrypt Class Initialized
INFO - 2022-03-22 23:45:39 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:45:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:45:39 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:45:39 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:45:39 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:45:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:45:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 23:45:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:45:39 --> Final output sent to browser
DEBUG - 2022-03-22 23:45:39 --> Total execution time: 0.0304
ERROR - 2022-03-22 23:46:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:46:04 --> Config Class Initialized
INFO - 2022-03-22 23:46:04 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:46:04 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:46:04 --> Utf8 Class Initialized
INFO - 2022-03-22 23:46:04 --> URI Class Initialized
INFO - 2022-03-22 23:46:04 --> Router Class Initialized
INFO - 2022-03-22 23:46:04 --> Output Class Initialized
INFO - 2022-03-22 23:46:04 --> Security Class Initialized
DEBUG - 2022-03-22 23:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:46:04 --> Input Class Initialized
INFO - 2022-03-22 23:46:04 --> Language Class Initialized
INFO - 2022-03-22 23:46:04 --> Loader Class Initialized
INFO - 2022-03-22 23:46:04 --> Helper loaded: url_helper
INFO - 2022-03-22 23:46:04 --> Helper loaded: form_helper
INFO - 2022-03-22 23:46:04 --> Helper loaded: common_helper
INFO - 2022-03-22 23:46:04 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:46:04 --> Controller Class Initialized
INFO - 2022-03-22 23:46:04 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:46:04 --> Encrypt Class Initialized
INFO - 2022-03-22 23:46:04 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:46:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:46:04 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:46:04 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:46:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 23:46:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:46:05 --> Config Class Initialized
INFO - 2022-03-22 23:46:05 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:46:05 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:46:05 --> Utf8 Class Initialized
INFO - 2022-03-22 23:46:05 --> URI Class Initialized
INFO - 2022-03-22 23:46:05 --> Router Class Initialized
INFO - 2022-03-22 23:46:05 --> Output Class Initialized
INFO - 2022-03-22 23:46:05 --> Security Class Initialized
DEBUG - 2022-03-22 23:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:46:05 --> Input Class Initialized
INFO - 2022-03-22 23:46:05 --> Language Class Initialized
INFO - 2022-03-22 23:46:05 --> Loader Class Initialized
INFO - 2022-03-22 23:46:05 --> Helper loaded: url_helper
INFO - 2022-03-22 23:46:05 --> Helper loaded: form_helper
INFO - 2022-03-22 23:46:05 --> Helper loaded: common_helper
INFO - 2022-03-22 23:46:05 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:46:05 --> Controller Class Initialized
INFO - 2022-03-22 23:46:05 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:46:05 --> Encrypt Class Initialized
INFO - 2022-03-22 23:46:05 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:46:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:46:05 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:46:05 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:46:05 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:46:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:46:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 23:46:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:46:05 --> Final output sent to browser
DEBUG - 2022-03-22 23:46:05 --> Total execution time: 0.0283
ERROR - 2022-03-22 23:46:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:46:05 --> Config Class Initialized
INFO - 2022-03-22 23:46:05 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:46:05 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:46:05 --> Utf8 Class Initialized
INFO - 2022-03-22 23:46:05 --> URI Class Initialized
INFO - 2022-03-22 23:46:05 --> Router Class Initialized
INFO - 2022-03-22 23:46:05 --> Output Class Initialized
INFO - 2022-03-22 23:46:05 --> Security Class Initialized
DEBUG - 2022-03-22 23:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:46:05 --> Input Class Initialized
INFO - 2022-03-22 23:46:05 --> Language Class Initialized
INFO - 2022-03-22 23:46:05 --> Loader Class Initialized
INFO - 2022-03-22 23:46:05 --> Helper loaded: url_helper
INFO - 2022-03-22 23:46:05 --> Helper loaded: form_helper
INFO - 2022-03-22 23:46:05 --> Helper loaded: common_helper
INFO - 2022-03-22 23:46:05 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:46:05 --> Controller Class Initialized
INFO - 2022-03-22 23:46:05 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:46:05 --> Encrypt Class Initialized
INFO - 2022-03-22 23:46:05 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:46:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:46:05 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:46:05 --> Model "Users_model" initialized
INFO - 2022-03-22 23:46:05 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:46:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:46:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:46:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:46:05 --> Final output sent to browser
DEBUG - 2022-03-22 23:46:05 --> Total execution time: 0.0533
ERROR - 2022-03-22 23:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:49:48 --> Config Class Initialized
INFO - 2022-03-22 23:49:48 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:49:48 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:49:48 --> Utf8 Class Initialized
INFO - 2022-03-22 23:49:48 --> URI Class Initialized
INFO - 2022-03-22 23:49:48 --> Router Class Initialized
INFO - 2022-03-22 23:49:48 --> Output Class Initialized
INFO - 2022-03-22 23:49:48 --> Security Class Initialized
DEBUG - 2022-03-22 23:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:49:48 --> Input Class Initialized
INFO - 2022-03-22 23:49:48 --> Language Class Initialized
INFO - 2022-03-22 23:49:48 --> Loader Class Initialized
INFO - 2022-03-22 23:49:48 --> Helper loaded: url_helper
INFO - 2022-03-22 23:49:48 --> Helper loaded: form_helper
INFO - 2022-03-22 23:49:48 --> Helper loaded: common_helper
INFO - 2022-03-22 23:49:48 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:49:48 --> Controller Class Initialized
INFO - 2022-03-22 23:49:48 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:49:48 --> Encrypt Class Initialized
INFO - 2022-03-22 23:49:48 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:49:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:49:48 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:49:48 --> Model "Users_model" initialized
INFO - 2022-03-22 23:49:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 23:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:49:48 --> Config Class Initialized
INFO - 2022-03-22 23:49:48 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:49:48 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:49:48 --> Utf8 Class Initialized
INFO - 2022-03-22 23:49:48 --> URI Class Initialized
INFO - 2022-03-22 23:49:48 --> Router Class Initialized
INFO - 2022-03-22 23:49:48 --> Output Class Initialized
INFO - 2022-03-22 23:49:48 --> Security Class Initialized
DEBUG - 2022-03-22 23:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:49:48 --> Input Class Initialized
INFO - 2022-03-22 23:49:48 --> Language Class Initialized
INFO - 2022-03-22 23:49:48 --> Loader Class Initialized
INFO - 2022-03-22 23:49:48 --> Helper loaded: url_helper
INFO - 2022-03-22 23:49:48 --> Helper loaded: form_helper
INFO - 2022-03-22 23:49:48 --> Helper loaded: common_helper
INFO - 2022-03-22 23:49:48 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:49:48 --> Controller Class Initialized
INFO - 2022-03-22 23:49:48 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:49:48 --> Encrypt Class Initialized
INFO - 2022-03-22 23:49:48 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:49:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:49:48 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:49:48 --> Model "Users_model" initialized
INFO - 2022-03-22 23:49:48 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:49:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:49:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:49:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:49:48 --> Final output sent to browser
DEBUG - 2022-03-22 23:49:48 --> Total execution time: 0.0549
ERROR - 2022-03-22 23:49:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:49:56 --> Config Class Initialized
INFO - 2022-03-22 23:49:56 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:49:56 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:49:56 --> Utf8 Class Initialized
INFO - 2022-03-22 23:49:56 --> URI Class Initialized
INFO - 2022-03-22 23:49:56 --> Router Class Initialized
INFO - 2022-03-22 23:49:56 --> Output Class Initialized
INFO - 2022-03-22 23:49:56 --> Security Class Initialized
DEBUG - 2022-03-22 23:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:49:56 --> Input Class Initialized
INFO - 2022-03-22 23:49:56 --> Language Class Initialized
INFO - 2022-03-22 23:49:56 --> Loader Class Initialized
INFO - 2022-03-22 23:49:56 --> Helper loaded: url_helper
INFO - 2022-03-22 23:49:56 --> Helper loaded: form_helper
INFO - 2022-03-22 23:49:56 --> Helper loaded: common_helper
INFO - 2022-03-22 23:49:56 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:49:56 --> Controller Class Initialized
INFO - 2022-03-22 23:49:56 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:49:56 --> Encrypt Class Initialized
INFO - 2022-03-22 23:49:56 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:49:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:49:56 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:49:56 --> Model "Users_model" initialized
INFO - 2022-03-22 23:49:56 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:49:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:49:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:49:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:49:56 --> Final output sent to browser
DEBUG - 2022-03-22 23:49:56 --> Total execution time: 0.0386
ERROR - 2022-03-22 23:49:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:49:59 --> Config Class Initialized
INFO - 2022-03-22 23:49:59 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:49:59 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:49:59 --> Utf8 Class Initialized
INFO - 2022-03-22 23:49:59 --> URI Class Initialized
INFO - 2022-03-22 23:49:59 --> Router Class Initialized
INFO - 2022-03-22 23:49:59 --> Output Class Initialized
INFO - 2022-03-22 23:49:59 --> Security Class Initialized
DEBUG - 2022-03-22 23:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:49:59 --> Input Class Initialized
INFO - 2022-03-22 23:49:59 --> Language Class Initialized
INFO - 2022-03-22 23:49:59 --> Loader Class Initialized
INFO - 2022-03-22 23:49:59 --> Helper loaded: url_helper
INFO - 2022-03-22 23:49:59 --> Helper loaded: form_helper
INFO - 2022-03-22 23:49:59 --> Helper loaded: common_helper
INFO - 2022-03-22 23:49:59 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:49:59 --> Controller Class Initialized
INFO - 2022-03-22 23:49:59 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:49:59 --> Encrypt Class Initialized
INFO - 2022-03-22 23:49:59 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:49:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:49:59 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:49:59 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:49:59 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:49:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:49:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 23:49:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:49:59 --> Final output sent to browser
DEBUG - 2022-03-22 23:49:59 --> Total execution time: 0.0357
ERROR - 2022-03-22 23:50:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:50:25 --> Config Class Initialized
INFO - 2022-03-22 23:50:25 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:50:25 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:50:25 --> Utf8 Class Initialized
INFO - 2022-03-22 23:50:25 --> URI Class Initialized
INFO - 2022-03-22 23:50:25 --> Router Class Initialized
INFO - 2022-03-22 23:50:25 --> Output Class Initialized
INFO - 2022-03-22 23:50:25 --> Security Class Initialized
DEBUG - 2022-03-22 23:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:50:25 --> Input Class Initialized
INFO - 2022-03-22 23:50:25 --> Language Class Initialized
INFO - 2022-03-22 23:50:25 --> Loader Class Initialized
INFO - 2022-03-22 23:50:25 --> Helper loaded: url_helper
INFO - 2022-03-22 23:50:25 --> Helper loaded: form_helper
INFO - 2022-03-22 23:50:25 --> Helper loaded: common_helper
INFO - 2022-03-22 23:50:25 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:50:25 --> Controller Class Initialized
INFO - 2022-03-22 23:50:25 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:50:25 --> Encrypt Class Initialized
INFO - 2022-03-22 23:50:25 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:50:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:50:25 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:50:25 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:50:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 23:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:50:26 --> Config Class Initialized
INFO - 2022-03-22 23:50:26 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:50:26 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:50:26 --> Utf8 Class Initialized
INFO - 2022-03-22 23:50:26 --> URI Class Initialized
INFO - 2022-03-22 23:50:26 --> Router Class Initialized
INFO - 2022-03-22 23:50:26 --> Output Class Initialized
INFO - 2022-03-22 23:50:26 --> Security Class Initialized
DEBUG - 2022-03-22 23:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:50:26 --> Input Class Initialized
INFO - 2022-03-22 23:50:26 --> Language Class Initialized
INFO - 2022-03-22 23:50:26 --> Loader Class Initialized
INFO - 2022-03-22 23:50:26 --> Helper loaded: url_helper
INFO - 2022-03-22 23:50:26 --> Helper loaded: form_helper
INFO - 2022-03-22 23:50:26 --> Helper loaded: common_helper
INFO - 2022-03-22 23:50:26 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:50:26 --> Controller Class Initialized
INFO - 2022-03-22 23:50:26 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:50:26 --> Encrypt Class Initialized
INFO - 2022-03-22 23:50:26 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:50:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:50:26 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:50:26 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:50:26 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:50:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:50:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 23:50:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:50:26 --> Final output sent to browser
DEBUG - 2022-03-22 23:50:26 --> Total execution time: 0.0392
ERROR - 2022-03-22 23:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:50:26 --> Config Class Initialized
INFO - 2022-03-22 23:50:26 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:50:26 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:50:26 --> Utf8 Class Initialized
INFO - 2022-03-22 23:50:26 --> URI Class Initialized
INFO - 2022-03-22 23:50:26 --> Router Class Initialized
INFO - 2022-03-22 23:50:26 --> Output Class Initialized
INFO - 2022-03-22 23:50:26 --> Security Class Initialized
DEBUG - 2022-03-22 23:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:50:26 --> Input Class Initialized
INFO - 2022-03-22 23:50:26 --> Language Class Initialized
INFO - 2022-03-22 23:50:26 --> Loader Class Initialized
INFO - 2022-03-22 23:50:26 --> Helper loaded: url_helper
INFO - 2022-03-22 23:50:26 --> Helper loaded: form_helper
INFO - 2022-03-22 23:50:26 --> Helper loaded: common_helper
INFO - 2022-03-22 23:50:26 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:50:26 --> Controller Class Initialized
INFO - 2022-03-22 23:50:26 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:50:26 --> Encrypt Class Initialized
INFO - 2022-03-22 23:50:26 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:50:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:50:26 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:50:26 --> Model "Users_model" initialized
INFO - 2022-03-22 23:50:26 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:50:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:50:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:50:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:50:26 --> Final output sent to browser
DEBUG - 2022-03-22 23:50:26 --> Total execution time: 0.0497
ERROR - 2022-03-22 23:52:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:52:10 --> Config Class Initialized
INFO - 2022-03-22 23:52:10 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:52:10 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:52:10 --> Utf8 Class Initialized
INFO - 2022-03-22 23:52:10 --> URI Class Initialized
INFO - 2022-03-22 23:52:10 --> Router Class Initialized
INFO - 2022-03-22 23:52:10 --> Output Class Initialized
INFO - 2022-03-22 23:52:10 --> Security Class Initialized
DEBUG - 2022-03-22 23:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:52:10 --> Input Class Initialized
INFO - 2022-03-22 23:52:10 --> Language Class Initialized
INFO - 2022-03-22 23:52:10 --> Loader Class Initialized
INFO - 2022-03-22 23:52:10 --> Helper loaded: url_helper
INFO - 2022-03-22 23:52:10 --> Helper loaded: form_helper
INFO - 2022-03-22 23:52:10 --> Helper loaded: common_helper
INFO - 2022-03-22 23:52:10 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:52:10 --> Controller Class Initialized
INFO - 2022-03-22 23:52:10 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:52:10 --> Encrypt Class Initialized
INFO - 2022-03-22 23:52:10 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:52:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:52:10 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:52:10 --> Model "Users_model" initialized
INFO - 2022-03-22 23:52:10 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:52:10 --> Upload Class Initialized
INFO - 2022-03-22 23:52:10 --> Final output sent to browser
DEBUG - 2022-03-22 23:52:10 --> Total execution time: 0.0292
ERROR - 2022-03-22 23:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:53:27 --> Config Class Initialized
INFO - 2022-03-22 23:53:27 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:53:27 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:53:27 --> Utf8 Class Initialized
INFO - 2022-03-22 23:53:27 --> URI Class Initialized
INFO - 2022-03-22 23:53:27 --> Router Class Initialized
INFO - 2022-03-22 23:53:27 --> Output Class Initialized
INFO - 2022-03-22 23:53:27 --> Security Class Initialized
DEBUG - 2022-03-22 23:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:53:27 --> Input Class Initialized
INFO - 2022-03-22 23:53:27 --> Language Class Initialized
INFO - 2022-03-22 23:53:27 --> Loader Class Initialized
INFO - 2022-03-22 23:53:27 --> Helper loaded: url_helper
INFO - 2022-03-22 23:53:27 --> Helper loaded: form_helper
INFO - 2022-03-22 23:53:27 --> Helper loaded: common_helper
INFO - 2022-03-22 23:53:27 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:53:27 --> Controller Class Initialized
INFO - 2022-03-22 23:53:27 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:53:27 --> Encrypt Class Initialized
INFO - 2022-03-22 23:53:27 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:53:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:53:27 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:53:27 --> Model "Users_model" initialized
INFO - 2022-03-22 23:53:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 23:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:53:28 --> Config Class Initialized
INFO - 2022-03-22 23:53:28 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:53:28 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:53:28 --> Utf8 Class Initialized
INFO - 2022-03-22 23:53:28 --> URI Class Initialized
INFO - 2022-03-22 23:53:28 --> Router Class Initialized
INFO - 2022-03-22 23:53:28 --> Output Class Initialized
INFO - 2022-03-22 23:53:28 --> Security Class Initialized
DEBUG - 2022-03-22 23:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:53:28 --> Input Class Initialized
INFO - 2022-03-22 23:53:28 --> Language Class Initialized
INFO - 2022-03-22 23:53:28 --> Loader Class Initialized
INFO - 2022-03-22 23:53:28 --> Helper loaded: url_helper
INFO - 2022-03-22 23:53:28 --> Helper loaded: form_helper
INFO - 2022-03-22 23:53:28 --> Helper loaded: common_helper
INFO - 2022-03-22 23:53:28 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:53:28 --> Controller Class Initialized
INFO - 2022-03-22 23:53:28 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:53:28 --> Encrypt Class Initialized
INFO - 2022-03-22 23:53:28 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:53:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:53:28 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:53:28 --> Model "Users_model" initialized
INFO - 2022-03-22 23:53:28 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:53:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:53:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:53:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:53:28 --> Final output sent to browser
DEBUG - 2022-03-22 23:53:28 --> Total execution time: 0.0380
ERROR - 2022-03-22 23:56:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:56:42 --> Config Class Initialized
INFO - 2022-03-22 23:56:42 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:56:42 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:56:42 --> Utf8 Class Initialized
INFO - 2022-03-22 23:56:42 --> URI Class Initialized
INFO - 2022-03-22 23:56:42 --> Router Class Initialized
INFO - 2022-03-22 23:56:42 --> Output Class Initialized
INFO - 2022-03-22 23:56:42 --> Security Class Initialized
DEBUG - 2022-03-22 23:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:56:42 --> Input Class Initialized
INFO - 2022-03-22 23:56:42 --> Language Class Initialized
INFO - 2022-03-22 23:56:42 --> Loader Class Initialized
INFO - 2022-03-22 23:56:42 --> Helper loaded: url_helper
INFO - 2022-03-22 23:56:42 --> Helper loaded: form_helper
INFO - 2022-03-22 23:56:42 --> Helper loaded: common_helper
INFO - 2022-03-22 23:56:42 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:56:42 --> Controller Class Initialized
INFO - 2022-03-22 23:56:42 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:56:42 --> Encrypt Class Initialized
INFO - 2022-03-22 23:56:42 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:56:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:56:42 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:56:42 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:56:42 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:56:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:56:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 23:56:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:56:42 --> Final output sent to browser
DEBUG - 2022-03-22 23:56:42 --> Total execution time: 0.1005
ERROR - 2022-03-22 23:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:57:04 --> Config Class Initialized
INFO - 2022-03-22 23:57:04 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:57:04 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:57:04 --> Utf8 Class Initialized
INFO - 2022-03-22 23:57:04 --> URI Class Initialized
INFO - 2022-03-22 23:57:04 --> Router Class Initialized
INFO - 2022-03-22 23:57:04 --> Output Class Initialized
INFO - 2022-03-22 23:57:04 --> Security Class Initialized
DEBUG - 2022-03-22 23:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:57:04 --> Input Class Initialized
INFO - 2022-03-22 23:57:04 --> Language Class Initialized
INFO - 2022-03-22 23:57:04 --> Loader Class Initialized
INFO - 2022-03-22 23:57:04 --> Helper loaded: url_helper
INFO - 2022-03-22 23:57:04 --> Helper loaded: form_helper
INFO - 2022-03-22 23:57:04 --> Helper loaded: common_helper
INFO - 2022-03-22 23:57:04 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:57:04 --> Controller Class Initialized
INFO - 2022-03-22 23:57:04 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:57:04 --> Encrypt Class Initialized
INFO - 2022-03-22 23:57:04 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:57:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:57:04 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:57:04 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:57:04 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:57:04 --> Upload Class Initialized
INFO - 2022-03-22 23:57:04 --> Final output sent to browser
DEBUG - 2022-03-22 23:57:04 --> Total execution time: 0.0110
ERROR - 2022-03-22 23:59:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:59:57 --> Config Class Initialized
INFO - 2022-03-22 23:59:57 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:59:57 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:59:57 --> Utf8 Class Initialized
INFO - 2022-03-22 23:59:57 --> URI Class Initialized
INFO - 2022-03-22 23:59:57 --> Router Class Initialized
INFO - 2022-03-22 23:59:57 --> Output Class Initialized
INFO - 2022-03-22 23:59:57 --> Security Class Initialized
DEBUG - 2022-03-22 23:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:59:57 --> Input Class Initialized
INFO - 2022-03-22 23:59:57 --> Language Class Initialized
INFO - 2022-03-22 23:59:57 --> Loader Class Initialized
INFO - 2022-03-22 23:59:57 --> Helper loaded: url_helper
INFO - 2022-03-22 23:59:57 --> Helper loaded: form_helper
INFO - 2022-03-22 23:59:57 --> Helper loaded: common_helper
INFO - 2022-03-22 23:59:57 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:59:57 --> Controller Class Initialized
INFO - 2022-03-22 23:59:57 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:59:57 --> Encrypt Class Initialized
INFO - 2022-03-22 23:59:57 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:59:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:59:57 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:59:57 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:59:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-22 23:59:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:59:57 --> Config Class Initialized
INFO - 2022-03-22 23:59:57 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:59:57 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:59:57 --> Utf8 Class Initialized
INFO - 2022-03-22 23:59:57 --> URI Class Initialized
INFO - 2022-03-22 23:59:57 --> Router Class Initialized
INFO - 2022-03-22 23:59:57 --> Output Class Initialized
INFO - 2022-03-22 23:59:57 --> Security Class Initialized
DEBUG - 2022-03-22 23:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:59:57 --> Input Class Initialized
INFO - 2022-03-22 23:59:57 --> Language Class Initialized
INFO - 2022-03-22 23:59:57 --> Loader Class Initialized
INFO - 2022-03-22 23:59:57 --> Helper loaded: url_helper
INFO - 2022-03-22 23:59:57 --> Helper loaded: form_helper
INFO - 2022-03-22 23:59:57 --> Helper loaded: common_helper
INFO - 2022-03-22 23:59:57 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:59:57 --> Controller Class Initialized
INFO - 2022-03-22 23:59:57 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:59:57 --> Encrypt Class Initialized
INFO - 2022-03-22 23:59:57 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:59:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:59:57 --> Model "Referredby_model" initialized
INFO - 2022-03-22 23:59:57 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:59:57 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:59:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:59:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-22 23:59:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:59:57 --> Final output sent to browser
DEBUG - 2022-03-22 23:59:57 --> Total execution time: 0.0472
ERROR - 2022-03-22 23:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-22 23:59:58 --> Config Class Initialized
INFO - 2022-03-22 23:59:58 --> Hooks Class Initialized
DEBUG - 2022-03-22 23:59:58 --> UTF-8 Support Enabled
INFO - 2022-03-22 23:59:58 --> Utf8 Class Initialized
INFO - 2022-03-22 23:59:58 --> URI Class Initialized
INFO - 2022-03-22 23:59:58 --> Router Class Initialized
INFO - 2022-03-22 23:59:58 --> Output Class Initialized
INFO - 2022-03-22 23:59:58 --> Security Class Initialized
DEBUG - 2022-03-22 23:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-22 23:59:58 --> Input Class Initialized
INFO - 2022-03-22 23:59:58 --> Language Class Initialized
INFO - 2022-03-22 23:59:58 --> Loader Class Initialized
INFO - 2022-03-22 23:59:58 --> Helper loaded: url_helper
INFO - 2022-03-22 23:59:58 --> Helper loaded: form_helper
INFO - 2022-03-22 23:59:58 --> Helper loaded: common_helper
INFO - 2022-03-22 23:59:58 --> Database Driver Class Initialized
DEBUG - 2022-03-22 23:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-22 23:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-22 23:59:58 --> Controller Class Initialized
INFO - 2022-03-22 23:59:58 --> Form Validation Class Initialized
DEBUG - 2022-03-22 23:59:58 --> Encrypt Class Initialized
INFO - 2022-03-22 23:59:58 --> Model "Patient_model" initialized
INFO - 2022-03-22 23:59:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-22 23:59:58 --> Model "Prefix_master" initialized
INFO - 2022-03-22 23:59:58 --> Model "Users_model" initialized
INFO - 2022-03-22 23:59:58 --> Model "Hospital_model" initialized
INFO - 2022-03-22 23:59:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-22 23:59:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-22 23:59:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-22 23:59:58 --> Final output sent to browser
DEBUG - 2022-03-22 23:59:58 --> Total execution time: 0.0839
