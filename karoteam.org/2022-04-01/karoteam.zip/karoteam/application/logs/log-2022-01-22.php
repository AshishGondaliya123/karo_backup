<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-22 02:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 02:16:03 --> Config Class Initialized
INFO - 2022-01-22 02:16:03 --> Hooks Class Initialized
DEBUG - 2022-01-22 02:16:03 --> UTF-8 Support Enabled
INFO - 2022-01-22 02:16:03 --> Utf8 Class Initialized
INFO - 2022-01-22 02:16:03 --> URI Class Initialized
DEBUG - 2022-01-22 02:16:03 --> No URI present. Default controller set.
INFO - 2022-01-22 02:16:03 --> Router Class Initialized
INFO - 2022-01-22 02:16:03 --> Output Class Initialized
INFO - 2022-01-22 02:16:03 --> Security Class Initialized
DEBUG - 2022-01-22 02:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 02:16:03 --> Input Class Initialized
INFO - 2022-01-22 02:16:03 --> Language Class Initialized
INFO - 2022-01-22 02:16:03 --> Loader Class Initialized
INFO - 2022-01-22 02:16:03 --> Helper loaded: url_helper
INFO - 2022-01-22 02:16:03 --> Helper loaded: form_helper
INFO - 2022-01-22 02:16:03 --> Helper loaded: common_helper
INFO - 2022-01-22 02:16:03 --> Database Driver Class Initialized
DEBUG - 2022-01-22 02:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 02:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 02:16:03 --> Controller Class Initialized
INFO - 2022-01-22 02:16:03 --> Form Validation Class Initialized
DEBUG - 2022-01-22 02:16:03 --> Encrypt Class Initialized
DEBUG - 2022-01-22 02:16:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 02:16:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 02:16:03 --> Email Class Initialized
INFO - 2022-01-22 02:16:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 02:16:03 --> Calendar Class Initialized
INFO - 2022-01-22 02:16:03 --> Model "Login_model" initialized
INFO - 2022-01-22 02:16:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-22 02:16:03 --> Final output sent to browser
DEBUG - 2022-01-22 02:16:03 --> Total execution time: 0.0250
ERROR - 2022-01-22 13:53:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 13:53:58 --> Config Class Initialized
INFO - 2022-01-22 13:53:58 --> Hooks Class Initialized
DEBUG - 2022-01-22 13:53:58 --> UTF-8 Support Enabled
INFO - 2022-01-22 13:53:58 --> Utf8 Class Initialized
INFO - 2022-01-22 13:53:58 --> URI Class Initialized
DEBUG - 2022-01-22 13:53:58 --> No URI present. Default controller set.
INFO - 2022-01-22 13:53:58 --> Router Class Initialized
INFO - 2022-01-22 13:53:58 --> Output Class Initialized
INFO - 2022-01-22 13:53:58 --> Security Class Initialized
DEBUG - 2022-01-22 13:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 13:53:58 --> Input Class Initialized
INFO - 2022-01-22 13:53:58 --> Language Class Initialized
INFO - 2022-01-22 13:53:58 --> Loader Class Initialized
INFO - 2022-01-22 13:53:58 --> Helper loaded: url_helper
INFO - 2022-01-22 13:53:58 --> Helper loaded: form_helper
INFO - 2022-01-22 13:53:58 --> Helper loaded: common_helper
INFO - 2022-01-22 13:53:58 --> Database Driver Class Initialized
DEBUG - 2022-01-22 13:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 13:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 13:53:58 --> Controller Class Initialized
INFO - 2022-01-22 13:53:58 --> Form Validation Class Initialized
DEBUG - 2022-01-22 13:53:58 --> Encrypt Class Initialized
DEBUG - 2022-01-22 13:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 13:53:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 13:53:58 --> Email Class Initialized
INFO - 2022-01-22 13:53:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 13:53:58 --> Calendar Class Initialized
INFO - 2022-01-22 13:53:58 --> Model "Login_model" initialized
INFO - 2022-01-22 13:53:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-22 13:53:58 --> Final output sent to browser
DEBUG - 2022-01-22 13:53:58 --> Total execution time: 0.0260
ERROR - 2022-01-22 14:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 14:17:48 --> Config Class Initialized
INFO - 2022-01-22 14:17:48 --> Hooks Class Initialized
DEBUG - 2022-01-22 14:17:48 --> UTF-8 Support Enabled
INFO - 2022-01-22 14:17:48 --> Utf8 Class Initialized
INFO - 2022-01-22 14:17:48 --> URI Class Initialized
DEBUG - 2022-01-22 14:17:48 --> No URI present. Default controller set.
INFO - 2022-01-22 14:17:48 --> Router Class Initialized
INFO - 2022-01-22 14:17:48 --> Output Class Initialized
INFO - 2022-01-22 14:17:48 --> Security Class Initialized
DEBUG - 2022-01-22 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 14:17:48 --> Input Class Initialized
INFO - 2022-01-22 14:17:48 --> Language Class Initialized
INFO - 2022-01-22 14:17:48 --> Loader Class Initialized
INFO - 2022-01-22 14:17:48 --> Helper loaded: url_helper
INFO - 2022-01-22 14:17:48 --> Helper loaded: form_helper
INFO - 2022-01-22 14:17:48 --> Helper loaded: common_helper
INFO - 2022-01-22 14:17:48 --> Database Driver Class Initialized
DEBUG - 2022-01-22 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 14:17:48 --> Controller Class Initialized
INFO - 2022-01-22 14:17:48 --> Form Validation Class Initialized
DEBUG - 2022-01-22 14:17:48 --> Encrypt Class Initialized
DEBUG - 2022-01-22 14:17:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 14:17:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 14:17:48 --> Email Class Initialized
INFO - 2022-01-22 14:17:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 14:17:48 --> Calendar Class Initialized
INFO - 2022-01-22 14:17:48 --> Model "Login_model" initialized
INFO - 2022-01-22 14:17:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-22 14:17:48 --> Final output sent to browser
DEBUG - 2022-01-22 14:17:48 --> Total execution time: 0.0325
ERROR - 2022-01-22 14:17:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 14:17:49 --> Config Class Initialized
INFO - 2022-01-22 14:17:49 --> Hooks Class Initialized
DEBUG - 2022-01-22 14:17:49 --> UTF-8 Support Enabled
INFO - 2022-01-22 14:17:49 --> Utf8 Class Initialized
INFO - 2022-01-22 14:17:49 --> URI Class Initialized
INFO - 2022-01-22 14:17:49 --> Router Class Initialized
INFO - 2022-01-22 14:17:49 --> Output Class Initialized
INFO - 2022-01-22 14:17:49 --> Security Class Initialized
DEBUG - 2022-01-22 14:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 14:17:49 --> Input Class Initialized
INFO - 2022-01-22 14:17:49 --> Language Class Initialized
ERROR - 2022-01-22 14:17:49 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-22 14:18:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 14:18:13 --> Config Class Initialized
INFO - 2022-01-22 14:18:13 --> Hooks Class Initialized
DEBUG - 2022-01-22 14:18:13 --> UTF-8 Support Enabled
INFO - 2022-01-22 14:18:13 --> Utf8 Class Initialized
INFO - 2022-01-22 14:18:13 --> URI Class Initialized
DEBUG - 2022-01-22 14:18:13 --> No URI present. Default controller set.
INFO - 2022-01-22 14:18:13 --> Router Class Initialized
INFO - 2022-01-22 14:18:13 --> Output Class Initialized
INFO - 2022-01-22 14:18:13 --> Security Class Initialized
DEBUG - 2022-01-22 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 14:18:13 --> Input Class Initialized
INFO - 2022-01-22 14:18:13 --> Language Class Initialized
INFO - 2022-01-22 14:18:13 --> Loader Class Initialized
INFO - 2022-01-22 14:18:13 --> Helper loaded: url_helper
INFO - 2022-01-22 14:18:13 --> Helper loaded: form_helper
INFO - 2022-01-22 14:18:13 --> Helper loaded: common_helper
INFO - 2022-01-22 14:18:13 --> Database Driver Class Initialized
DEBUG - 2022-01-22 14:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 14:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 14:18:13 --> Controller Class Initialized
INFO - 2022-01-22 14:18:13 --> Form Validation Class Initialized
DEBUG - 2022-01-22 14:18:13 --> Encrypt Class Initialized
DEBUG - 2022-01-22 14:18:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 14:18:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 14:18:13 --> Email Class Initialized
INFO - 2022-01-22 14:18:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 14:18:13 --> Calendar Class Initialized
INFO - 2022-01-22 14:18:13 --> Model "Login_model" initialized
INFO - 2022-01-22 14:18:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-22 14:18:13 --> Final output sent to browser
DEBUG - 2022-01-22 14:18:13 --> Total execution time: 0.0347
ERROR - 2022-01-22 14:18:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 14:18:14 --> Config Class Initialized
INFO - 2022-01-22 14:18:14 --> Hooks Class Initialized
DEBUG - 2022-01-22 14:18:14 --> UTF-8 Support Enabled
INFO - 2022-01-22 14:18:14 --> Utf8 Class Initialized
INFO - 2022-01-22 14:18:14 --> URI Class Initialized
INFO - 2022-01-22 14:18:14 --> Router Class Initialized
INFO - 2022-01-22 14:18:14 --> Output Class Initialized
INFO - 2022-01-22 14:18:14 --> Security Class Initialized
DEBUG - 2022-01-22 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 14:18:14 --> Input Class Initialized
INFO - 2022-01-22 14:18:14 --> Language Class Initialized
INFO - 2022-01-22 14:18:14 --> Loader Class Initialized
INFO - 2022-01-22 14:18:14 --> Helper loaded: url_helper
INFO - 2022-01-22 14:18:14 --> Helper loaded: form_helper
INFO - 2022-01-22 14:18:14 --> Helper loaded: common_helper
INFO - 2022-01-22 14:18:14 --> Database Driver Class Initialized
DEBUG - 2022-01-22 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 14:18:14 --> Controller Class Initialized
INFO - 2022-01-22 14:18:14 --> Form Validation Class Initialized
DEBUG - 2022-01-22 14:18:14 --> Encrypt Class Initialized
DEBUG - 2022-01-22 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 14:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 14:18:14 --> Email Class Initialized
INFO - 2022-01-22 14:18:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 14:18:14 --> Calendar Class Initialized
INFO - 2022-01-22 14:18:14 --> Model "Login_model" initialized
ERROR - 2022-01-22 14:18:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 14:18:14 --> Config Class Initialized
INFO - 2022-01-22 14:18:14 --> Hooks Class Initialized
DEBUG - 2022-01-22 14:18:14 --> UTF-8 Support Enabled
INFO - 2022-01-22 14:18:14 --> Utf8 Class Initialized
INFO - 2022-01-22 14:18:14 --> URI Class Initialized
INFO - 2022-01-22 14:18:14 --> Router Class Initialized
INFO - 2022-01-22 14:18:14 --> Output Class Initialized
INFO - 2022-01-22 14:18:14 --> Security Class Initialized
DEBUG - 2022-01-22 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 14:18:14 --> Input Class Initialized
INFO - 2022-01-22 14:18:14 --> Language Class Initialized
INFO - 2022-01-22 14:18:14 --> Loader Class Initialized
INFO - 2022-01-22 14:18:14 --> Helper loaded: url_helper
INFO - 2022-01-22 14:18:14 --> Helper loaded: form_helper
INFO - 2022-01-22 14:18:14 --> Helper loaded: common_helper
INFO - 2022-01-22 14:18:14 --> Database Driver Class Initialized
DEBUG - 2022-01-22 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 14:18:14 --> Controller Class Initialized
INFO - 2022-01-22 14:18:14 --> Form Validation Class Initialized
DEBUG - 2022-01-22 14:18:14 --> Encrypt Class Initialized
DEBUG - 2022-01-22 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 14:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 14:18:14 --> Email Class Initialized
INFO - 2022-01-22 14:18:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 14:18:14 --> Calendar Class Initialized
INFO - 2022-01-22 14:18:14 --> Model "Login_model" initialized
ERROR - 2022-01-22 14:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 14:18:15 --> Config Class Initialized
INFO - 2022-01-22 14:18:15 --> Hooks Class Initialized
DEBUG - 2022-01-22 14:18:15 --> UTF-8 Support Enabled
INFO - 2022-01-22 14:18:15 --> Utf8 Class Initialized
INFO - 2022-01-22 14:18:15 --> URI Class Initialized
INFO - 2022-01-22 14:18:15 --> Router Class Initialized
INFO - 2022-01-22 14:18:15 --> Output Class Initialized
INFO - 2022-01-22 14:18:15 --> Security Class Initialized
DEBUG - 2022-01-22 14:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 14:18:15 --> Input Class Initialized
INFO - 2022-01-22 14:18:15 --> Language Class Initialized
INFO - 2022-01-22 14:18:15 --> Loader Class Initialized
INFO - 2022-01-22 14:18:15 --> Helper loaded: url_helper
INFO - 2022-01-22 14:18:15 --> Helper loaded: form_helper
INFO - 2022-01-22 14:18:15 --> Helper loaded: common_helper
INFO - 2022-01-22 14:18:15 --> Database Driver Class Initialized
DEBUG - 2022-01-22 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 14:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 14:18:15 --> Controller Class Initialized
INFO - 2022-01-22 14:18:15 --> Form Validation Class Initialized
DEBUG - 2022-01-22 14:18:15 --> Encrypt Class Initialized
DEBUG - 2022-01-22 14:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 14:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 14:18:15 --> Email Class Initialized
INFO - 2022-01-22 14:18:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 14:18:15 --> Calendar Class Initialized
INFO - 2022-01-22 14:18:15 --> Model "Login_model" initialized
INFO - 2022-01-22 14:18:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-22 14:18:15 --> Final output sent to browser
DEBUG - 2022-01-22 14:18:15 --> Total execution time: 0.0300
ERROR - 2022-01-22 14:26:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 14:26:43 --> Config Class Initialized
INFO - 2022-01-22 14:26:43 --> Hooks Class Initialized
DEBUG - 2022-01-22 14:26:43 --> UTF-8 Support Enabled
INFO - 2022-01-22 14:26:43 --> Utf8 Class Initialized
INFO - 2022-01-22 14:26:43 --> URI Class Initialized
DEBUG - 2022-01-22 14:26:43 --> No URI present. Default controller set.
INFO - 2022-01-22 14:26:43 --> Router Class Initialized
INFO - 2022-01-22 14:26:43 --> Output Class Initialized
INFO - 2022-01-22 14:26:43 --> Security Class Initialized
DEBUG - 2022-01-22 14:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 14:26:43 --> Input Class Initialized
INFO - 2022-01-22 14:26:43 --> Language Class Initialized
INFO - 2022-01-22 14:26:43 --> Loader Class Initialized
INFO - 2022-01-22 14:26:43 --> Helper loaded: url_helper
INFO - 2022-01-22 14:26:43 --> Helper loaded: form_helper
INFO - 2022-01-22 14:26:43 --> Helper loaded: common_helper
INFO - 2022-01-22 14:26:43 --> Database Driver Class Initialized
DEBUG - 2022-01-22 14:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 14:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 14:26:43 --> Controller Class Initialized
INFO - 2022-01-22 14:26:43 --> Form Validation Class Initialized
DEBUG - 2022-01-22 14:26:43 --> Encrypt Class Initialized
DEBUG - 2022-01-22 14:26:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 14:26:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 14:26:43 --> Email Class Initialized
INFO - 2022-01-22 14:26:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 14:26:43 --> Calendar Class Initialized
INFO - 2022-01-22 14:26:43 --> Model "Login_model" initialized
INFO - 2022-01-22 14:26:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-22 14:26:43 --> Final output sent to browser
DEBUG - 2022-01-22 14:26:43 --> Total execution time: 0.0284
ERROR - 2022-01-22 16:24:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 16:24:54 --> Config Class Initialized
INFO - 2022-01-22 16:24:54 --> Hooks Class Initialized
DEBUG - 2022-01-22 16:24:54 --> UTF-8 Support Enabled
INFO - 2022-01-22 16:24:54 --> Utf8 Class Initialized
INFO - 2022-01-22 16:24:54 --> URI Class Initialized
DEBUG - 2022-01-22 16:24:54 --> No URI present. Default controller set.
INFO - 2022-01-22 16:24:54 --> Router Class Initialized
INFO - 2022-01-22 16:24:54 --> Output Class Initialized
INFO - 2022-01-22 16:24:54 --> Security Class Initialized
DEBUG - 2022-01-22 16:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 16:24:54 --> Input Class Initialized
INFO - 2022-01-22 16:24:54 --> Language Class Initialized
INFO - 2022-01-22 16:24:54 --> Loader Class Initialized
INFO - 2022-01-22 16:24:54 --> Helper loaded: url_helper
INFO - 2022-01-22 16:24:54 --> Helper loaded: form_helper
INFO - 2022-01-22 16:24:54 --> Helper loaded: common_helper
INFO - 2022-01-22 16:24:54 --> Database Driver Class Initialized
DEBUG - 2022-01-22 16:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 16:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 16:24:54 --> Controller Class Initialized
INFO - 2022-01-22 16:24:54 --> Form Validation Class Initialized
DEBUG - 2022-01-22 16:24:54 --> Encrypt Class Initialized
DEBUG - 2022-01-22 16:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 16:24:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 16:24:54 --> Email Class Initialized
INFO - 2022-01-22 16:24:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 16:24:54 --> Calendar Class Initialized
INFO - 2022-01-22 16:24:54 --> Model "Login_model" initialized
INFO - 2022-01-22 16:24:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-22 16:24:54 --> Final output sent to browser
DEBUG - 2022-01-22 16:24:54 --> Total execution time: 0.0241
ERROR - 2022-01-22 18:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-22 18:21:29 --> Config Class Initialized
INFO - 2022-01-22 18:21:29 --> Hooks Class Initialized
DEBUG - 2022-01-22 18:21:29 --> UTF-8 Support Enabled
INFO - 2022-01-22 18:21:29 --> Utf8 Class Initialized
INFO - 2022-01-22 18:21:29 --> URI Class Initialized
DEBUG - 2022-01-22 18:21:29 --> No URI present. Default controller set.
INFO - 2022-01-22 18:21:29 --> Router Class Initialized
INFO - 2022-01-22 18:21:29 --> Output Class Initialized
INFO - 2022-01-22 18:21:29 --> Security Class Initialized
DEBUG - 2022-01-22 18:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-22 18:21:29 --> Input Class Initialized
INFO - 2022-01-22 18:21:29 --> Language Class Initialized
INFO - 2022-01-22 18:21:29 --> Loader Class Initialized
INFO - 2022-01-22 18:21:29 --> Helper loaded: url_helper
INFO - 2022-01-22 18:21:29 --> Helper loaded: form_helper
INFO - 2022-01-22 18:21:29 --> Helper loaded: common_helper
INFO - 2022-01-22 18:21:29 --> Database Driver Class Initialized
DEBUG - 2022-01-22 18:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-22 18:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-22 18:21:29 --> Controller Class Initialized
INFO - 2022-01-22 18:21:29 --> Form Validation Class Initialized
DEBUG - 2022-01-22 18:21:29 --> Encrypt Class Initialized
DEBUG - 2022-01-22 18:21:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 18:21:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-22 18:21:29 --> Email Class Initialized
INFO - 2022-01-22 18:21:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-22 18:21:29 --> Calendar Class Initialized
INFO - 2022-01-22 18:21:29 --> Model "Login_model" initialized
INFO - 2022-01-22 18:21:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-22 18:21:29 --> Final output sent to browser
DEBUG - 2022-01-22 18:21:29 --> Total execution time: 0.0298
