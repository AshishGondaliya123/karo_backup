<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-22 17:33:34 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:33:34 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:35:15 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:35:15 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:36:20 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:36:20 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:37:26 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:37:26 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:40:39 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:40:39 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:45:07 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:45:07 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:45:13 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:45:13 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:45:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 55
ERROR - 2021-04-22 17:49:11 --> Severity: Warning --> include(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:49:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
INFO - 2021-04-22 17:49:11 --> Config Class Initialized
INFO - 2021-04-22 17:49:11 --> Hooks Class Initialized
DEBUG - 2021-04-22 17:49:11 --> UTF-8 Support Enabled
INFO - 2021-04-22 17:49:11 --> Utf8 Class Initialized
INFO - 2021-04-22 17:49:11 --> URI Class Initialized
DEBUG - 2021-04-22 17:49:11 --> No URI present. Default controller set.
INFO - 2021-04-22 17:49:11 --> Router Class Initialized
INFO - 2021-04-22 17:49:11 --> Output Class Initialized
INFO - 2021-04-22 17:49:11 --> Security Class Initialized
DEBUG - 2021-04-22 17:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 17:49:11 --> Input Class Initialized
INFO - 2021-04-22 17:49:11 --> Language Class Initialized
INFO - 2021-04-22 17:49:11 --> Loader Class Initialized
INFO - 2021-04-22 17:49:11 --> Helper loaded: url_helper
INFO - 2021-04-22 17:49:11 --> Helper loaded: form_helper
INFO - 2021-04-22 17:49:11 --> Helper loaded: common_helper
INFO - 2021-04-22 17:49:11 --> Database Driver Class Initialized
DEBUG - 2021-04-22 17:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 17:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 17:49:11 --> Controller Class Initialized
INFO - 2021-04-22 17:49:11 --> Form Validation Class Initialized
INFO - 2021-04-22 17:49:11 --> Encrypt Class Initialized
DEBUG - 2021-04-22 17:49:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 17:49:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 17:49:11 --> Email Class Initialized
INFO - 2021-04-22 17:49:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 17:49:11 --> Calendar Class Initialized
INFO - 2021-04-22 17:49:11 --> Model "Login_model" initialized
INFO - 2021-04-22 17:49:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-04-22 17:49:11 --> Final output sent to browser
DEBUG - 2021-04-22 17:49:11 --> Total execution time: 0.1724
ERROR - 2021-04-22 17:49:14 --> Severity: Warning --> include(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:49:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
INFO - 2021-04-22 17:49:14 --> Config Class Initialized
INFO - 2021-04-22 17:49:14 --> Hooks Class Initialized
DEBUG - 2021-04-22 17:49:14 --> UTF-8 Support Enabled
INFO - 2021-04-22 17:49:14 --> Utf8 Class Initialized
INFO - 2021-04-22 17:49:14 --> URI Class Initialized
DEBUG - 2021-04-22 17:49:14 --> No URI present. Default controller set.
INFO - 2021-04-22 17:49:14 --> Router Class Initialized
INFO - 2021-04-22 17:49:14 --> Output Class Initialized
INFO - 2021-04-22 17:49:14 --> Security Class Initialized
DEBUG - 2021-04-22 17:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 17:49:14 --> Input Class Initialized
INFO - 2021-04-22 17:49:14 --> Language Class Initialized
INFO - 2021-04-22 17:49:14 --> Loader Class Initialized
INFO - 2021-04-22 17:49:14 --> Helper loaded: url_helper
INFO - 2021-04-22 17:49:14 --> Helper loaded: form_helper
INFO - 2021-04-22 17:49:14 --> Helper loaded: common_helper
INFO - 2021-04-22 17:49:14 --> Database Driver Class Initialized
DEBUG - 2021-04-22 17:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 17:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 17:49:14 --> Controller Class Initialized
INFO - 2021-04-22 17:49:14 --> Form Validation Class Initialized
INFO - 2021-04-22 17:49:14 --> Encrypt Class Initialized
DEBUG - 2021-04-22 17:49:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 17:49:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 17:49:14 --> Email Class Initialized
INFO - 2021-04-22 17:49:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 17:49:14 --> Calendar Class Initialized
INFO - 2021-04-22 17:49:14 --> Model "Login_model" initialized
INFO - 2021-04-22 17:49:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-04-22 17:49:14 --> Final output sent to browser
DEBUG - 2021-04-22 17:49:14 --> Total execution time: 0.1693
ERROR - 2021-04-22 17:49:44 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:49:44 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:49:54 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:49:54 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:50:28 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:50:28 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:55:54 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:55:54 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:57:09 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:57:09 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:57:30 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:57:30 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:57:42 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 17:57:42 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 18:03:55 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 18:03:55 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 18:05:00 --> Severity: Warning --> require(C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php): failed to open stream: No such file or directory C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 18:05:00 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\study\karosoftware\vendor\composer/../symfony/polyfill-ctype/bootstrap.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\study\karosoftware\vendor\composer\autoload_real.php 66
ERROR - 2021-04-22 18:07:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:07:41 --> Config Class Initialized
INFO - 2021-04-22 18:07:41 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:07:41 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:07:41 --> Utf8 Class Initialized
INFO - 2021-04-22 18:07:41 --> URI Class Initialized
DEBUG - 2021-04-22 18:07:41 --> No URI present. Default controller set.
INFO - 2021-04-22 18:07:41 --> Router Class Initialized
INFO - 2021-04-22 18:07:41 --> Output Class Initialized
INFO - 2021-04-22 18:07:41 --> Security Class Initialized
DEBUG - 2021-04-22 18:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:07:41 --> Input Class Initialized
INFO - 2021-04-22 18:07:41 --> Language Class Initialized
ERROR - 2021-04-22 18:08:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:08:33 --> Config Class Initialized
INFO - 2021-04-22 18:08:33 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:08:33 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:08:33 --> Utf8 Class Initialized
INFO - 2021-04-22 18:08:33 --> URI Class Initialized
DEBUG - 2021-04-22 18:08:33 --> No URI present. Default controller set.
INFO - 2021-04-22 18:08:33 --> Router Class Initialized
INFO - 2021-04-22 18:08:33 --> Output Class Initialized
INFO - 2021-04-22 18:08:33 --> Security Class Initialized
DEBUG - 2021-04-22 18:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:08:33 --> Input Class Initialized
INFO - 2021-04-22 18:08:33 --> Language Class Initialized
INFO - 2021-04-22 18:08:33 --> Loader Class Initialized
INFO - 2021-04-22 18:08:33 --> Helper loaded: url_helper
INFO - 2021-04-22 18:08:33 --> Helper loaded: form_helper
INFO - 2021-04-22 18:08:33 --> Helper loaded: common_helper
INFO - 2021-04-22 18:08:33 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:08:33 --> Controller Class Initialized
INFO - 2021-04-22 18:08:33 --> Form Validation Class Initialized
INFO - 2021-04-22 18:08:33 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:08:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:08:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:08:33 --> Email Class Initialized
INFO - 2021-04-22 18:08:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:08:33 --> Calendar Class Initialized
INFO - 2021-04-22 18:08:33 --> Model "Login_model" initialized
INFO - 2021-04-22 18:08:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-04-22 18:08:33 --> Final output sent to browser
DEBUG - 2021-04-22 18:08:33 --> Total execution time: 0.1645
ERROR - 2021-04-22 18:08:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:08:36 --> Config Class Initialized
INFO - 2021-04-22 18:08:36 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:08:36 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:08:36 --> Utf8 Class Initialized
INFO - 2021-04-22 18:08:36 --> URI Class Initialized
DEBUG - 2021-04-22 18:08:36 --> No URI present. Default controller set.
INFO - 2021-04-22 18:08:36 --> Router Class Initialized
INFO - 2021-04-22 18:08:36 --> Output Class Initialized
INFO - 2021-04-22 18:08:36 --> Security Class Initialized
DEBUG - 2021-04-22 18:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:08:36 --> Input Class Initialized
INFO - 2021-04-22 18:08:36 --> Language Class Initialized
INFO - 2021-04-22 18:08:36 --> Loader Class Initialized
INFO - 2021-04-22 18:08:36 --> Helper loaded: url_helper
INFO - 2021-04-22 18:08:36 --> Helper loaded: form_helper
INFO - 2021-04-22 18:08:36 --> Helper loaded: common_helper
INFO - 2021-04-22 18:08:36 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:08:36 --> Controller Class Initialized
INFO - 2021-04-22 18:08:36 --> Form Validation Class Initialized
INFO - 2021-04-22 18:08:36 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:08:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:08:36 --> Email Class Initialized
INFO - 2021-04-22 18:08:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:08:36 --> Calendar Class Initialized
INFO - 2021-04-22 18:08:36 --> Model "Login_model" initialized
INFO - 2021-04-22 18:08:36 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-04-22 18:08:36 --> Final output sent to browser
DEBUG - 2021-04-22 18:08:36 --> Total execution time: 0.2376
ERROR - 2021-04-22 18:08:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:08:36 --> Config Class Initialized
INFO - 2021-04-22 18:08:36 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:08:36 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:08:36 --> Utf8 Class Initialized
INFO - 2021-04-22 18:08:36 --> URI Class Initialized
INFO - 2021-04-22 18:08:36 --> Router Class Initialized
INFO - 2021-04-22 18:08:36 --> Output Class Initialized
INFO - 2021-04-22 18:08:36 --> Security Class Initialized
DEBUG - 2021-04-22 18:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:08:36 --> Input Class Initialized
INFO - 2021-04-22 18:08:36 --> Language Class Initialized
ERROR - 2021-04-22 18:08:36 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:08:37 --> Config Class Initialized
INFO - 2021-04-22 18:08:37 --> Config Class Initialized
INFO - 2021-04-22 18:08:37 --> Hooks Class Initialized
INFO - 2021-04-22 18:08:37 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:08:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:08:37 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:08:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:08:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:08:37 --> URI Class Initialized
INFO - 2021-04-22 18:08:37 --> URI Class Initialized
INFO - 2021-04-22 18:08:37 --> Router Class Initialized
INFO - 2021-04-22 18:08:37 --> Router Class Initialized
INFO - 2021-04-22 18:08:37 --> Output Class Initialized
INFO - 2021-04-22 18:08:37 --> Output Class Initialized
INFO - 2021-04-22 18:08:37 --> Security Class Initialized
INFO - 2021-04-22 18:08:37 --> Security Class Initialized
ERROR - 2021-04-22 18:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2021-04-22 18:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-22 18:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:08:37 --> Input Class Initialized
INFO - 2021-04-22 18:08:37 --> Input Class Initialized
INFO - 2021-04-22 18:08:37 --> Language Class Initialized
INFO - 2021-04-22 18:08:37 --> Language Class Initialized
INFO - 2021-04-22 18:08:37 --> Config Class Initialized
INFO - 2021-04-22 18:08:37 --> Hooks Class Initialized
ERROR - 2021-04-22 18:08:37 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:08:37 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:08:37 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:08:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:08:37 --> URI Class Initialized
INFO - 2021-04-22 18:08:37 --> Router Class Initialized
INFO - 2021-04-22 18:08:37 --> Output Class Initialized
INFO - 2021-04-22 18:08:37 --> Security Class Initialized
DEBUG - 2021-04-22 18:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:08:37 --> Input Class Initialized
INFO - 2021-04-22 18:08:37 --> Language Class Initialized
ERROR - 2021-04-22 18:08:37 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:08:37 --> Config Class Initialized
INFO - 2021-04-22 18:08:37 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:08:37 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:08:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:08:37 --> URI Class Initialized
INFO - 2021-04-22 18:08:37 --> Router Class Initialized
INFO - 2021-04-22 18:08:37 --> Output Class Initialized
INFO - 2021-04-22 18:08:37 --> Security Class Initialized
DEBUG - 2021-04-22 18:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:08:37 --> Input Class Initialized
INFO - 2021-04-22 18:08:37 --> Language Class Initialized
ERROR - 2021-04-22 18:08:37 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:08:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:08:37 --> Config Class Initialized
INFO - 2021-04-22 18:08:37 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:08:37 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:08:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:08:37 --> URI Class Initialized
INFO - 2021-04-22 18:08:37 --> Router Class Initialized
INFO - 2021-04-22 18:08:37 --> Output Class Initialized
INFO - 2021-04-22 18:08:37 --> Security Class Initialized
DEBUG - 2021-04-22 18:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:08:37 --> Input Class Initialized
INFO - 2021-04-22 18:08:37 --> Language Class Initialized
ERROR - 2021-04-22 18:08:37 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:10:03 --> Config Class Initialized
INFO - 2021-04-22 18:10:03 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:10:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:10:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:10:03 --> URI Class Initialized
INFO - 2021-04-22 18:10:03 --> Router Class Initialized
INFO - 2021-04-22 18:10:03 --> Output Class Initialized
INFO - 2021-04-22 18:10:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:10:03 --> Input Class Initialized
INFO - 2021-04-22 18:10:03 --> Language Class Initialized
INFO - 2021-04-22 18:10:03 --> Loader Class Initialized
INFO - 2021-04-22 18:10:03 --> Helper loaded: url_helper
INFO - 2021-04-22 18:10:03 --> Helper loaded: form_helper
INFO - 2021-04-22 18:10:03 --> Helper loaded: common_helper
INFO - 2021-04-22 18:10:03 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:10:03 --> Controller Class Initialized
INFO - 2021-04-22 18:10:03 --> Form Validation Class Initialized
INFO - 2021-04-22 18:10:03 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:10:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:10:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:10:03 --> Email Class Initialized
INFO - 2021-04-22 18:10:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:10:03 --> Calendar Class Initialized
INFO - 2021-04-22 18:10:03 --> Model "Login_model" initialized
INFO - 2021-04-22 18:10:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-22 18:10:03 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-04-22 18:10:03 --> Final output sent to browser
DEBUG - 2021-04-22 18:10:03 --> Total execution time: 0.1724
ERROR - 2021-04-22 18:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:10:03 --> Config Class Initialized
INFO - 2021-04-22 18:10:03 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:10:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:10:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:10:03 --> URI Class Initialized
ERROR - 2021-04-22 18:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:10:03 --> Router Class Initialized
INFO - 2021-04-22 18:10:03 --> Config Class Initialized
INFO - 2021-04-22 18:10:03 --> Hooks Class Initialized
INFO - 2021-04-22 18:10:03 --> Output Class Initialized
ERROR - 2021-04-22 18:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2021-04-22 18:10:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:10:03 --> Security Class Initialized
INFO - 2021-04-22 18:10:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:10:03 --> Config Class Initialized
INFO - 2021-04-22 18:10:03 --> Hooks Class Initialized
INFO - 2021-04-22 18:10:03 --> URI Class Initialized
DEBUG - 2021-04-22 18:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:10:03 --> Input Class Initialized
INFO - 2021-04-22 18:10:03 --> Language Class Initialized
ERROR - 2021-04-22 18:10:03 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:10:03 --> Router Class Initialized
DEBUG - 2021-04-22 18:10:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:10:03 --> Output Class Initialized
INFO - 2021-04-22 18:10:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:10:03 --> URI Class Initialized
INFO - 2021-04-22 18:10:03 --> Security Class Initialized
INFO - 2021-04-22 18:10:03 --> Router Class Initialized
DEBUG - 2021-04-22 18:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:10:03 --> Input Class Initialized
INFO - 2021-04-22 18:10:03 --> Language Class Initialized
INFO - 2021-04-22 18:10:03 --> Output Class Initialized
ERROR - 2021-04-22 18:10:03 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:10:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:10:03 --> Input Class Initialized
INFO - 2021-04-22 18:10:03 --> Language Class Initialized
ERROR - 2021-04-22 18:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:10:03 --> 404 Page Not Found: Karoclient/images
INFO - 2021-04-22 18:10:03 --> Config Class Initialized
INFO - 2021-04-22 18:10:03 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:10:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:10:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:10:03 --> URI Class Initialized
INFO - 2021-04-22 18:10:03 --> Router Class Initialized
INFO - 2021-04-22 18:10:03 --> Output Class Initialized
INFO - 2021-04-22 18:10:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:10:03 --> Input Class Initialized
INFO - 2021-04-22 18:10:03 --> Language Class Initialized
ERROR - 2021-04-22 18:10:03 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:37 --> Config Class Initialized
INFO - 2021-04-22 18:11:37 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:11:37 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:37 --> URI Class Initialized
INFO - 2021-04-22 18:11:37 --> Router Class Initialized
INFO - 2021-04-22 18:11:37 --> Output Class Initialized
INFO - 2021-04-22 18:11:37 --> Security Class Initialized
DEBUG - 2021-04-22 18:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:37 --> Input Class Initialized
INFO - 2021-04-22 18:11:37 --> Language Class Initialized
INFO - 2021-04-22 18:11:37 --> Loader Class Initialized
INFO - 2021-04-22 18:11:37 --> Helper loaded: url_helper
INFO - 2021-04-22 18:11:37 --> Helper loaded: form_helper
INFO - 2021-04-22 18:11:37 --> Helper loaded: common_helper
INFO - 2021-04-22 18:11:37 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:11:37 --> Controller Class Initialized
INFO - 2021-04-22 18:11:37 --> Form Validation Class Initialized
INFO - 2021-04-22 18:11:37 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:11:37 --> Email Class Initialized
INFO - 2021-04-22 18:11:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:11:37 --> Calendar Class Initialized
INFO - 2021-04-22 18:11:37 --> Model "Login_model" initialized
INFO - 2021-04-22 18:11:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-22 18:11:37 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-04-22 18:11:37 --> Final output sent to browser
DEBUG - 2021-04-22 18:11:37 --> Total execution time: 0.0853
ERROR - 2021-04-22 18:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:37 --> Config Class Initialized
INFO - 2021-04-22 18:11:37 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:11:37 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:37 --> URI Class Initialized
ERROR - 2021-04-22 18:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:37 --> Router Class Initialized
INFO - 2021-04-22 18:11:37 --> Output Class Initialized
INFO - 2021-04-22 18:11:37 --> Config Class Initialized
INFO - 2021-04-22 18:11:37 --> Hooks Class Initialized
INFO - 2021-04-22 18:11:37 --> Security Class Initialized
DEBUG - 2021-04-22 18:11:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:37 --> Input Class Initialized
INFO - 2021-04-22 18:11:37 --> Language Class Initialized
INFO - 2021-04-22 18:11:37 --> URI Class Initialized
ERROR - 2021-04-22 18:11:37 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:11:37 --> Router Class Initialized
ERROR - 2021-04-22 18:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:37 --> Output Class Initialized
INFO - 2021-04-22 18:11:37 --> Config Class Initialized
INFO - 2021-04-22 18:11:37 --> Hooks Class Initialized
INFO - 2021-04-22 18:11:37 --> Security Class Initialized
DEBUG - 2021-04-22 18:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:37 --> Input Class Initialized
INFO - 2021-04-22 18:11:37 --> Language Class Initialized
ERROR - 2021-04-22 18:11:37 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:11:37 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:37 --> URI Class Initialized
INFO - 2021-04-22 18:11:37 --> Router Class Initialized
INFO - 2021-04-22 18:11:37 --> Output Class Initialized
ERROR - 2021-04-22 18:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:37 --> Security Class Initialized
INFO - 2021-04-22 18:11:37 --> Config Class Initialized
INFO - 2021-04-22 18:11:37 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:37 --> Input Class Initialized
INFO - 2021-04-22 18:11:37 --> Language Class Initialized
ERROR - 2021-04-22 18:11:37 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:11:37 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:37 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:37 --> URI Class Initialized
INFO - 2021-04-22 18:11:38 --> Router Class Initialized
INFO - 2021-04-22 18:11:38 --> Output Class Initialized
INFO - 2021-04-22 18:11:38 --> Security Class Initialized
DEBUG - 2021-04-22 18:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:38 --> Input Class Initialized
INFO - 2021-04-22 18:11:38 --> Language Class Initialized
ERROR - 2021-04-22 18:11:38 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:38 --> Config Class Initialized
INFO - 2021-04-22 18:11:38 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:11:38 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:38 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:38 --> URI Class Initialized
INFO - 2021-04-22 18:11:38 --> Router Class Initialized
INFO - 2021-04-22 18:11:38 --> Output Class Initialized
INFO - 2021-04-22 18:11:38 --> Security Class Initialized
DEBUG - 2021-04-22 18:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:38 --> Input Class Initialized
INFO - 2021-04-22 18:11:38 --> Language Class Initialized
ERROR - 2021-04-22 18:11:38 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:38 --> Config Class Initialized
INFO - 2021-04-22 18:11:38 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:11:38 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:38 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:38 --> URI Class Initialized
INFO - 2021-04-22 18:11:38 --> Router Class Initialized
INFO - 2021-04-22 18:11:38 --> Output Class Initialized
INFO - 2021-04-22 18:11:38 --> Security Class Initialized
DEBUG - 2021-04-22 18:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:38 --> Input Class Initialized
INFO - 2021-04-22 18:11:38 --> Language Class Initialized
ERROR - 2021-04-22 18:11:38 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:40 --> Config Class Initialized
INFO - 2021-04-22 18:11:40 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:11:40 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:40 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:40 --> URI Class Initialized
INFO - 2021-04-22 18:11:40 --> Router Class Initialized
INFO - 2021-04-22 18:11:40 --> Output Class Initialized
INFO - 2021-04-22 18:11:40 --> Security Class Initialized
DEBUG - 2021-04-22 18:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:40 --> Input Class Initialized
INFO - 2021-04-22 18:11:40 --> Language Class Initialized
INFO - 2021-04-22 18:11:40 --> Loader Class Initialized
INFO - 2021-04-22 18:11:40 --> Helper loaded: url_helper
INFO - 2021-04-22 18:11:40 --> Helper loaded: form_helper
INFO - 2021-04-22 18:11:40 --> Helper loaded: common_helper
INFO - 2021-04-22 18:11:40 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:11:40 --> Controller Class Initialized
INFO - 2021-04-22 18:11:40 --> Form Validation Class Initialized
INFO - 2021-04-22 18:11:40 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:11:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:11:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:11:40 --> Email Class Initialized
INFO - 2021-04-22 18:11:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:11:40 --> Calendar Class Initialized
INFO - 2021-04-22 18:11:40 --> Model "Login_model" initialized
INFO - 2021-04-22 18:11:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-22 18:11:40 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-04-22 18:11:40 --> Final output sent to browser
DEBUG - 2021-04-22 18:11:40 --> Total execution time: 0.0579
ERROR - 2021-04-22 18:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:40 --> Config Class Initialized
INFO - 2021-04-22 18:11:40 --> Hooks Class Initialized
ERROR - 2021-04-22 18:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:40 --> Config Class Initialized
INFO - 2021-04-22 18:11:40 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:11:40 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:40 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:40 --> URI Class Initialized
DEBUG - 2021-04-22 18:11:40 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:40 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:40 --> Router Class Initialized
INFO - 2021-04-22 18:11:40 --> URI Class Initialized
INFO - 2021-04-22 18:11:40 --> Output Class Initialized
INFO - 2021-04-22 18:11:40 --> Router Class Initialized
INFO - 2021-04-22 18:11:40 --> Security Class Initialized
DEBUG - 2021-04-22 18:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:40 --> Input Class Initialized
INFO - 2021-04-22 18:11:40 --> Language Class Initialized
INFO - 2021-04-22 18:11:40 --> Output Class Initialized
ERROR - 2021-04-22 18:11:41 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:11:41 --> Security Class Initialized
DEBUG - 2021-04-22 18:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-22 18:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:41 --> Input Class Initialized
ERROR - 2021-04-22 18:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:11:41 --> Language Class Initialized
INFO - 2021-04-22 18:11:41 --> Config Class Initialized
INFO - 2021-04-22 18:11:41 --> Hooks Class Initialized
ERROR - 2021-04-22 18:11:41 --> 404 Page Not Found: Karoclient/images
INFO - 2021-04-22 18:11:41 --> Config Class Initialized
INFO - 2021-04-22 18:11:41 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:11:41 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:41 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:11:41 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:11:41 --> Utf8 Class Initialized
INFO - 2021-04-22 18:11:41 --> URI Class Initialized
INFO - 2021-04-22 18:11:41 --> Router Class Initialized
INFO - 2021-04-22 18:11:41 --> URI Class Initialized
INFO - 2021-04-22 18:11:41 --> Router Class Initialized
INFO - 2021-04-22 18:11:41 --> Output Class Initialized
INFO - 2021-04-22 18:11:41 --> Security Class Initialized
INFO - 2021-04-22 18:11:41 --> Output Class Initialized
DEBUG - 2021-04-22 18:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:41 --> Security Class Initialized
INFO - 2021-04-22 18:11:41 --> Input Class Initialized
INFO - 2021-04-22 18:11:41 --> Language Class Initialized
DEBUG - 2021-04-22 18:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:11:41 --> Input Class Initialized
ERROR - 2021-04-22 18:11:41 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:11:41 --> Language Class Initialized
ERROR - 2021-04-22 18:11:41 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:12:28 --> Config Class Initialized
INFO - 2021-04-22 18:12:28 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:12:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:12:28 --> Utf8 Class Initialized
INFO - 2021-04-22 18:12:28 --> URI Class Initialized
INFO - 2021-04-22 18:12:28 --> Router Class Initialized
INFO - 2021-04-22 18:12:28 --> Output Class Initialized
INFO - 2021-04-22 18:12:28 --> Security Class Initialized
DEBUG - 2021-04-22 18:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:12:28 --> Input Class Initialized
INFO - 2021-04-22 18:12:28 --> Language Class Initialized
INFO - 2021-04-22 18:12:28 --> Loader Class Initialized
INFO - 2021-04-22 18:12:28 --> Helper loaded: url_helper
INFO - 2021-04-22 18:12:28 --> Helper loaded: form_helper
INFO - 2021-04-22 18:12:28 --> Helper loaded: common_helper
INFO - 2021-04-22 18:12:28 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:12:28 --> Controller Class Initialized
INFO - 2021-04-22 18:12:28 --> Form Validation Class Initialized
INFO - 2021-04-22 18:12:28 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:12:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:12:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:12:28 --> Email Class Initialized
INFO - 2021-04-22 18:12:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:12:28 --> Calendar Class Initialized
INFO - 2021-04-22 18:12:28 --> Model "Login_model" initialized
INFO - 2021-04-22 18:12:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-22 18:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:12:28 --> Config Class Initialized
INFO - 2021-04-22 18:12:28 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:12:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:12:28 --> Utf8 Class Initialized
INFO - 2021-04-22 18:12:28 --> URI Class Initialized
INFO - 2021-04-22 18:12:28 --> Router Class Initialized
INFO - 2021-04-22 18:12:28 --> Output Class Initialized
INFO - 2021-04-22 18:12:28 --> Security Class Initialized
DEBUG - 2021-04-22 18:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:12:28 --> Input Class Initialized
INFO - 2021-04-22 18:12:28 --> Language Class Initialized
INFO - 2021-04-22 18:12:28 --> Loader Class Initialized
INFO - 2021-04-22 18:12:28 --> Helper loaded: url_helper
INFO - 2021-04-22 18:12:28 --> Helper loaded: form_helper
INFO - 2021-04-22 18:12:28 --> Helper loaded: common_helper
INFO - 2021-04-22 18:12:28 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:12:28 --> Controller Class Initialized
INFO - 2021-04-22 18:12:28 --> Form Validation Class Initialized
INFO - 2021-04-22 18:12:28 --> Encrypt Class Initialized
INFO - 2021-04-22 18:12:28 --> Model "Login_model" initialized
INFO - 2021-04-22 18:12:28 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:12:28 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:12:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\study\karosoftware\application\models\Dashboard_model.php 12
ERROR - 2021-04-22 18:12:29 --> Severity: Notice --> Undefined index: all C:\xampp\htdocs\study\karosoftware\application\controllers\Dashboard.php 33
ERROR - 2021-04-22 18:12:29 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:12:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:35 --> Config Class Initialized
INFO - 2021-04-22 18:14:35 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:35 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:35 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:35 --> URI Class Initialized
INFO - 2021-04-22 18:14:35 --> Router Class Initialized
INFO - 2021-04-22 18:14:35 --> Output Class Initialized
INFO - 2021-04-22 18:14:35 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:35 --> Input Class Initialized
INFO - 2021-04-22 18:14:35 --> Language Class Initialized
INFO - 2021-04-22 18:14:35 --> Loader Class Initialized
INFO - 2021-04-22 18:14:35 --> Helper loaded: url_helper
INFO - 2021-04-22 18:14:35 --> Helper loaded: form_helper
INFO - 2021-04-22 18:14:35 --> Helper loaded: common_helper
INFO - 2021-04-22 18:14:35 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:14:35 --> Controller Class Initialized
INFO - 2021-04-22 18:14:35 --> Form Validation Class Initialized
INFO - 2021-04-22 18:14:35 --> Encrypt Class Initialized
INFO - 2021-04-22 18:14:35 --> Model "Login_model" initialized
INFO - 2021-04-22 18:14:35 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:14:35 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:14:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\study\karosoftware\application\models\Dashboard_model.php 12
ERROR - 2021-04-22 18:14:36 --> Severity: Notice --> Undefined index: all C:\xampp\htdocs\study\karosoftware\application\controllers\Dashboard.php 33
ERROR - 2021-04-22 18:14:36 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:14:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:51 --> Config Class Initialized
INFO - 2021-04-22 18:14:51 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:51 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:51 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:51 --> URI Class Initialized
INFO - 2021-04-22 18:14:51 --> Router Class Initialized
INFO - 2021-04-22 18:14:51 --> Output Class Initialized
INFO - 2021-04-22 18:14:51 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:51 --> Input Class Initialized
INFO - 2021-04-22 18:14:51 --> Language Class Initialized
INFO - 2021-04-22 18:14:51 --> Loader Class Initialized
INFO - 2021-04-22 18:14:51 --> Helper loaded: url_helper
INFO - 2021-04-22 18:14:51 --> Helper loaded: form_helper
INFO - 2021-04-22 18:14:51 --> Helper loaded: common_helper
INFO - 2021-04-22 18:14:51 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:14:51 --> Controller Class Initialized
INFO - 2021-04-22 18:14:51 --> Form Validation Class Initialized
INFO - 2021-04-22 18:14:51 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:14:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:14:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:14:51 --> Email Class Initialized
INFO - 2021-04-22 18:14:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:14:51 --> Calendar Class Initialized
INFO - 2021-04-22 18:14:51 --> Model "Login_model" initialized
INFO - 2021-04-22 18:14:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-22 18:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:51 --> Config Class Initialized
INFO - 2021-04-22 18:14:51 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:51 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:51 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:51 --> URI Class Initialized
INFO - 2021-04-22 18:14:51 --> Router Class Initialized
INFO - 2021-04-22 18:14:51 --> Output Class Initialized
INFO - 2021-04-22 18:14:51 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:51 --> Input Class Initialized
INFO - 2021-04-22 18:14:51 --> Language Class Initialized
INFO - 2021-04-22 18:14:51 --> Loader Class Initialized
INFO - 2021-04-22 18:14:51 --> Helper loaded: url_helper
INFO - 2021-04-22 18:14:51 --> Helper loaded: form_helper
INFO - 2021-04-22 18:14:51 --> Helper loaded: common_helper
INFO - 2021-04-22 18:14:51 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:14:51 --> Controller Class Initialized
INFO - 2021-04-22 18:14:51 --> Form Validation Class Initialized
INFO - 2021-04-22 18:14:51 --> Encrypt Class Initialized
INFO - 2021-04-22 18:14:51 --> Model "Diseases_model" initialized
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
INFO - 2021-04-22 18:14:51 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:14:51 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Undefined variable: case_name C:\xampp\htdocs\study\karosoftware\application\views\footer.php 3
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 10
ERROR - 2021-04-22 18:14:51 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 11
INFO - 2021-04-22 18:14:51 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:14:51 --> Final output sent to browser
DEBUG - 2021-04-22 18:14:51 --> Total execution time: 0.1325
ERROR - 2021-04-22 18:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:51 --> Config Class Initialized
INFO - 2021-04-22 18:14:51 --> Hooks Class Initialized
ERROR - 2021-04-22 18:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:51 --> Config Class Initialized
INFO - 2021-04-22 18:14:51 --> Hooks Class Initialized
INFO - 2021-04-22 18:14:51 --> Config Class Initialized
INFO - 2021-04-22 18:14:51 --> Hooks Class Initialized
INFO - 2021-04-22 18:14:51 --> Config Class Initialized
INFO - 2021-04-22 18:14:51 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:51 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:51 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:14:51 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:51 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:51 --> URI Class Initialized
DEBUG - 2021-04-22 18:14:51 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:51 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:51 --> URI Class Initialized
INFO - 2021-04-22 18:14:51 --> URI Class Initialized
INFO - 2021-04-22 18:14:51 --> Router Class Initialized
DEBUG - 2021-04-22 18:14:51 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:51 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:51 --> Router Class Initialized
INFO - 2021-04-22 18:14:51 --> Output Class Initialized
INFO - 2021-04-22 18:14:51 --> Security Class Initialized
INFO - 2021-04-22 18:14:51 --> URI Class Initialized
INFO - 2021-04-22 18:14:51 --> Router Class Initialized
DEBUG - 2021-04-22 18:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:51 --> Input Class Initialized
INFO - 2021-04-22 18:14:51 --> Output Class Initialized
INFO - 2021-04-22 18:14:51 --> Router Class Initialized
INFO - 2021-04-22 18:14:51 --> Language Class Initialized
INFO - 2021-04-22 18:14:51 --> Output Class Initialized
INFO - 2021-04-22 18:14:51 --> Security Class Initialized
ERROR - 2021-04-22 18:14:51 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:14:51 --> Output Class Initialized
INFO - 2021-04-22 18:14:51 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:51 --> Input Class Initialized
INFO - 2021-04-22 18:14:51 --> Language Class Initialized
DEBUG - 2021-04-22 18:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:51 --> Security Class Initialized
INFO - 2021-04-22 18:14:51 --> Input Class Initialized
INFO - 2021-04-22 18:14:51 --> Language Class Initialized
ERROR - 2021-04-22 18:14:51 --> 404 Page Not Found: Karoclient/css
DEBUG - 2021-04-22 18:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:51 --> Input Class Initialized
INFO - 2021-04-22 18:14:51 --> Language Class Initialized
ERROR - 2021-04-22 18:14:51 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:14:51 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:14:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:52 --> Config Class Initialized
INFO - 2021-04-22 18:14:52 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:52 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:52 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:52 --> URI Class Initialized
INFO - 2021-04-22 18:14:52 --> Router Class Initialized
INFO - 2021-04-22 18:14:52 --> Output Class Initialized
INFO - 2021-04-22 18:14:52 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:52 --> Input Class Initialized
INFO - 2021-04-22 18:14:52 --> Language Class Initialized
ERROR - 2021-04-22 18:14:52 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:14:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:52 --> Config Class Initialized
INFO - 2021-04-22 18:14:52 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:52 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:52 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:52 --> URI Class Initialized
INFO - 2021-04-22 18:14:52 --> Router Class Initialized
INFO - 2021-04-22 18:14:52 --> Output Class Initialized
INFO - 2021-04-22 18:14:52 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:52 --> Input Class Initialized
INFO - 2021-04-22 18:14:52 --> Language Class Initialized
ERROR - 2021-04-22 18:14:52 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:52 --> Config Class Initialized
INFO - 2021-04-22 18:14:52 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:52 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:52 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:52 --> URI Class Initialized
INFO - 2021-04-22 18:14:52 --> Router Class Initialized
INFO - 2021-04-22 18:14:52 --> Output Class Initialized
INFO - 2021-04-22 18:14:52 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:52 --> Input Class Initialized
INFO - 2021-04-22 18:14:52 --> Language Class Initialized
ERROR - 2021-04-22 18:14:52 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:52 --> Config Class Initialized
INFO - 2021-04-22 18:14:52 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:52 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:52 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:52 --> URI Class Initialized
INFO - 2021-04-22 18:14:52 --> Router Class Initialized
INFO - 2021-04-22 18:14:52 --> Output Class Initialized
INFO - 2021-04-22 18:14:52 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:52 --> Input Class Initialized
INFO - 2021-04-22 18:14:52 --> Language Class Initialized
ERROR - 2021-04-22 18:14:52 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:53 --> Config Class Initialized
INFO - 2021-04-22 18:14:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:53 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:53 --> URI Class Initialized
INFO - 2021-04-22 18:14:53 --> Router Class Initialized
INFO - 2021-04-22 18:14:53 --> Output Class Initialized
INFO - 2021-04-22 18:14:53 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:53 --> Input Class Initialized
INFO - 2021-04-22 18:14:53 --> Language Class Initialized
ERROR - 2021-04-22 18:14:53 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:53 --> Config Class Initialized
INFO - 2021-04-22 18:14:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:53 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:53 --> URI Class Initialized
INFO - 2021-04-22 18:14:53 --> Router Class Initialized
INFO - 2021-04-22 18:14:53 --> Output Class Initialized
INFO - 2021-04-22 18:14:53 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:53 --> Input Class Initialized
INFO - 2021-04-22 18:14:53 --> Language Class Initialized
ERROR - 2021-04-22 18:14:53 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:53 --> Config Class Initialized
INFO - 2021-04-22 18:14:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:53 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:53 --> URI Class Initialized
INFO - 2021-04-22 18:14:53 --> Router Class Initialized
INFO - 2021-04-22 18:14:53 --> Output Class Initialized
INFO - 2021-04-22 18:14:53 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:53 --> Input Class Initialized
INFO - 2021-04-22 18:14:53 --> Language Class Initialized
ERROR - 2021-04-22 18:14:53 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:53 --> Config Class Initialized
INFO - 2021-04-22 18:14:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:53 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:53 --> URI Class Initialized
INFO - 2021-04-22 18:14:53 --> Router Class Initialized
INFO - 2021-04-22 18:14:53 --> Output Class Initialized
INFO - 2021-04-22 18:14:53 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:53 --> Input Class Initialized
INFO - 2021-04-22 18:14:53 --> Language Class Initialized
ERROR - 2021-04-22 18:14:53 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:53 --> Config Class Initialized
INFO - 2021-04-22 18:14:53 --> Hooks Class Initialized
ERROR - 2021-04-22 18:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:53 --> Config Class Initialized
INFO - 2021-04-22 18:14:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:53 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:53 --> URI Class Initialized
DEBUG - 2021-04-22 18:14:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:53 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:53 --> Router Class Initialized
INFO - 2021-04-22 18:14:53 --> URI Class Initialized
INFO - 2021-04-22 18:14:53 --> Router Class Initialized
INFO - 2021-04-22 18:14:53 --> Output Class Initialized
INFO - 2021-04-22 18:14:53 --> Security Class Initialized
INFO - 2021-04-22 18:14:53 --> Output Class Initialized
DEBUG - 2021-04-22 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:53 --> Input Class Initialized
INFO - 2021-04-22 18:14:53 --> Security Class Initialized
INFO - 2021-04-22 18:14:53 --> Language Class Initialized
DEBUG - 2021-04-22 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:53 --> Input Class Initialized
ERROR - 2021-04-22 18:14:53 --> 404 Page Not Found: Karoclient/images
INFO - 2021-04-22 18:14:53 --> Language Class Initialized
ERROR - 2021-04-22 18:14:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:53 --> Config Class Initialized
INFO - 2021-04-22 18:14:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:53 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:53 --> URI Class Initialized
INFO - 2021-04-22 18:14:53 --> Router Class Initialized
INFO - 2021-04-22 18:14:53 --> Output Class Initialized
INFO - 2021-04-22 18:14:53 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:53 --> Input Class Initialized
INFO - 2021-04-22 18:14:53 --> Language Class Initialized
ERROR - 2021-04-22 18:14:53 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:53 --> Config Class Initialized
INFO - 2021-04-22 18:14:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:53 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:53 --> URI Class Initialized
INFO - 2021-04-22 18:14:53 --> Router Class Initialized
INFO - 2021-04-22 18:14:53 --> Output Class Initialized
INFO - 2021-04-22 18:14:53 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:53 --> Input Class Initialized
INFO - 2021-04-22 18:14:53 --> Language Class Initialized
ERROR - 2021-04-22 18:14:53 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:53 --> Config Class Initialized
INFO - 2021-04-22 18:14:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:53 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:53 --> URI Class Initialized
INFO - 2021-04-22 18:14:53 --> Router Class Initialized
INFO - 2021-04-22 18:14:53 --> Output Class Initialized
INFO - 2021-04-22 18:14:53 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:53 --> Input Class Initialized
INFO - 2021-04-22 18:14:53 --> Language Class Initialized
ERROR - 2021-04-22 18:14:53 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:59 --> Config Class Initialized
INFO - 2021-04-22 18:14:59 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:59 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:59 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:59 --> URI Class Initialized
INFO - 2021-04-22 18:14:59 --> Router Class Initialized
INFO - 2021-04-22 18:14:59 --> Output Class Initialized
INFO - 2021-04-22 18:14:59 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:59 --> Input Class Initialized
INFO - 2021-04-22 18:14:59 --> Language Class Initialized
ERROR - 2021-04-22 18:14:59 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:59 --> Config Class Initialized
INFO - 2021-04-22 18:14:59 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:59 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:59 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:59 --> URI Class Initialized
INFO - 2021-04-22 18:14:59 --> Router Class Initialized
INFO - 2021-04-22 18:14:59 --> Output Class Initialized
INFO - 2021-04-22 18:14:59 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:59 --> Input Class Initialized
INFO - 2021-04-22 18:14:59 --> Language Class Initialized
ERROR - 2021-04-22 18:14:59 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:59 --> Config Class Initialized
INFO - 2021-04-22 18:14:59 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:59 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:59 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:59 --> URI Class Initialized
INFO - 2021-04-22 18:14:59 --> Router Class Initialized
INFO - 2021-04-22 18:14:59 --> Output Class Initialized
INFO - 2021-04-22 18:14:59 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:59 --> Input Class Initialized
INFO - 2021-04-22 18:14:59 --> Language Class Initialized
ERROR - 2021-04-22 18:14:59 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:14:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:14:59 --> Config Class Initialized
INFO - 2021-04-22 18:14:59 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:14:59 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:14:59 --> Utf8 Class Initialized
INFO - 2021-04-22 18:14:59 --> URI Class Initialized
INFO - 2021-04-22 18:14:59 --> Router Class Initialized
INFO - 2021-04-22 18:14:59 --> Output Class Initialized
INFO - 2021-04-22 18:14:59 --> Security Class Initialized
DEBUG - 2021-04-22 18:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:14:59 --> Input Class Initialized
INFO - 2021-04-22 18:14:59 --> Language Class Initialized
ERROR - 2021-04-22 18:14:59 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:01 --> Config Class Initialized
INFO - 2021-04-22 18:15:01 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:01 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:01 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:01 --> URI Class Initialized
INFO - 2021-04-22 18:15:01 --> Router Class Initialized
INFO - 2021-04-22 18:15:01 --> Output Class Initialized
INFO - 2021-04-22 18:15:01 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:01 --> Input Class Initialized
INFO - 2021-04-22 18:15:01 --> Language Class Initialized
ERROR - 2021-04-22 18:15:01 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
INFO - 2021-04-22 18:15:19 --> Loader Class Initialized
INFO - 2021-04-22 18:15:19 --> Helper loaded: url_helper
INFO - 2021-04-22 18:15:19 --> Helper loaded: form_helper
INFO - 2021-04-22 18:15:19 --> Helper loaded: common_helper
INFO - 2021-04-22 18:15:19 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:15:19 --> Controller Class Initialized
INFO - 2021-04-22 18:15:19 --> Form Validation Class Initialized
INFO - 2021-04-22 18:15:19 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:15:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:15:19 --> Email Class Initialized
INFO - 2021-04-22 18:15:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:15:19 --> Calendar Class Initialized
INFO - 2021-04-22 18:15:19 --> Model "Login_model" initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
INFO - 2021-04-22 18:15:19 --> Loader Class Initialized
INFO - 2021-04-22 18:15:19 --> Helper loaded: url_helper
INFO - 2021-04-22 18:15:19 --> Helper loaded: form_helper
INFO - 2021-04-22 18:15:19 --> Helper loaded: common_helper
INFO - 2021-04-22 18:15:19 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:15:19 --> Controller Class Initialized
INFO - 2021-04-22 18:15:19 --> Form Validation Class Initialized
INFO - 2021-04-22 18:15:19 --> Encrypt Class Initialized
INFO - 2021-04-22 18:15:19 --> Model "Diseases_model" initialized
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
INFO - 2021-04-22 18:15:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:15:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Undefined variable: case_name C:\xampp\htdocs\study\karosoftware\application\views\footer.php 3
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 10
ERROR - 2021-04-22 18:15:19 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 11
INFO - 2021-04-22 18:15:19 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:15:19 --> Final output sent to browser
DEBUG - 2021-04-22 18:15:19 --> Total execution time: 0.0834
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/images
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:19 --> Config Class Initialized
INFO - 2021-04-22 18:15:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:19 --> URI Class Initialized
INFO - 2021-04-22 18:15:19 --> Router Class Initialized
INFO - 2021-04-22 18:15:19 --> Output Class Initialized
INFO - 2021-04-22 18:15:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:19 --> Input Class Initialized
INFO - 2021-04-22 18:15:19 --> Language Class Initialized
ERROR - 2021-04-22 18:15:19 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:20 --> Config Class Initialized
INFO - 2021-04-22 18:15:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:20 --> URI Class Initialized
INFO - 2021-04-22 18:15:20 --> Router Class Initialized
INFO - 2021-04-22 18:15:20 --> Output Class Initialized
INFO - 2021-04-22 18:15:20 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:20 --> Input Class Initialized
INFO - 2021-04-22 18:15:20 --> Language Class Initialized
ERROR - 2021-04-22 18:15:20 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:20 --> Config Class Initialized
INFO - 2021-04-22 18:15:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:20 --> URI Class Initialized
INFO - 2021-04-22 18:15:20 --> Router Class Initialized
INFO - 2021-04-22 18:15:20 --> Output Class Initialized
INFO - 2021-04-22 18:15:20 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:20 --> Input Class Initialized
INFO - 2021-04-22 18:15:20 --> Language Class Initialized
ERROR - 2021-04-22 18:15:20 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:20 --> Config Class Initialized
INFO - 2021-04-22 18:15:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:20 --> URI Class Initialized
INFO - 2021-04-22 18:15:20 --> Router Class Initialized
INFO - 2021-04-22 18:15:20 --> Output Class Initialized
INFO - 2021-04-22 18:15:20 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:20 --> Input Class Initialized
INFO - 2021-04-22 18:15:20 --> Language Class Initialized
ERROR - 2021-04-22 18:15:20 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:15:20 --> Config Class Initialized
INFO - 2021-04-22 18:15:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:15:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:15:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:15:20 --> URI Class Initialized
INFO - 2021-04-22 18:15:20 --> Router Class Initialized
INFO - 2021-04-22 18:15:20 --> Output Class Initialized
INFO - 2021-04-22 18:15:20 --> Security Class Initialized
DEBUG - 2021-04-22 18:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:15:20 --> Input Class Initialized
INFO - 2021-04-22 18:15:20 --> Language Class Initialized
ERROR - 2021-04-22 18:15:20 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:00 --> Config Class Initialized
INFO - 2021-04-22 18:16:00 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:00 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:00 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:00 --> URI Class Initialized
INFO - 2021-04-22 18:16:00 --> Router Class Initialized
INFO - 2021-04-22 18:16:00 --> Output Class Initialized
INFO - 2021-04-22 18:16:00 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:00 --> Input Class Initialized
INFO - 2021-04-22 18:16:00 --> Language Class Initialized
INFO - 2021-04-22 18:16:00 --> Loader Class Initialized
INFO - 2021-04-22 18:16:00 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:00 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:00 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:00 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:01 --> Controller Class Initialized
INFO - 2021-04-22 18:16:01 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:01 --> Encrypt Class Initialized
INFO - 2021-04-22 18:16:01 --> Model "Diseases_model" initialized
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
INFO - 2021-04-22 18:16:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:16:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Undefined variable: case_name C:\xampp\htdocs\study\karosoftware\application\views\footer.php 3
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 10
ERROR - 2021-04-22 18:16:01 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 11
INFO - 2021-04-22 18:16:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:16:01 --> Final output sent to browser
DEBUG - 2021-04-22 18:16:01 --> Total execution time: 0.2724
ERROR - 2021-04-22 18:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:01 --> Config Class Initialized
INFO - 2021-04-22 18:16:01 --> Config Class Initialized
INFO - 2021-04-22 18:16:01 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:01 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:16:01 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:01 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:01 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:01 --> URI Class Initialized
INFO - 2021-04-22 18:16:01 --> URI Class Initialized
INFO - 2021-04-22 18:16:01 --> Router Class Initialized
INFO - 2021-04-22 18:16:01 --> Router Class Initialized
INFO - 2021-04-22 18:16:01 --> Config Class Initialized
INFO - 2021-04-22 18:16:01 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:01 --> Config Class Initialized
INFO - 2021-04-22 18:16:01 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:01 --> Output Class Initialized
INFO - 2021-04-22 18:16:01 --> Output Class Initialized
INFO - 2021-04-22 18:16:01 --> Security Class Initialized
INFO - 2021-04-22 18:16:01 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:01 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:01 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:01 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:01 --> Input Class Initialized
INFO - 2021-04-22 18:16:01 --> Language Class Initialized
INFO - 2021-04-22 18:16:01 --> Language Class Initialized
INFO - 2021-04-22 18:16:01 --> URI Class Initialized
ERROR - 2021-04-22 18:16:01 --> 404 Page Not Found: Karoclient/css
DEBUG - 2021-04-22 18:16:01 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:01 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:16:01 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:16:01 --> Router Class Initialized
INFO - 2021-04-22 18:16:01 --> URI Class Initialized
INFO - 2021-04-22 18:16:01 --> Output Class Initialized
INFO - 2021-04-22 18:16:01 --> Router Class Initialized
INFO - 2021-04-22 18:16:01 --> Security Class Initialized
INFO - 2021-04-22 18:16:01 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:01 --> Input Class Initialized
INFO - 2021-04-22 18:16:01 --> Language Class Initialized
INFO - 2021-04-22 18:16:01 --> Security Class Initialized
ERROR - 2021-04-22 18:16:01 --> 404 Page Not Found: Karoclient/css
DEBUG - 2021-04-22 18:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:01 --> Input Class Initialized
INFO - 2021-04-22 18:16:01 --> Language Class Initialized
ERROR - 2021-04-22 18:16:01 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:01 --> Config Class Initialized
INFO - 2021-04-22 18:16:01 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:01 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:01 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:01 --> URI Class Initialized
INFO - 2021-04-22 18:16:01 --> Router Class Initialized
INFO - 2021-04-22 18:16:01 --> Output Class Initialized
INFO - 2021-04-22 18:16:01 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:01 --> Input Class Initialized
INFO - 2021-04-22 18:16:01 --> Language Class Initialized
ERROR - 2021-04-22 18:16:01 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:02 --> Config Class Initialized
INFO - 2021-04-22 18:16:02 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:02 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:02 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:02 --> URI Class Initialized
INFO - 2021-04-22 18:16:02 --> Router Class Initialized
INFO - 2021-04-22 18:16:02 --> Output Class Initialized
INFO - 2021-04-22 18:16:02 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:02 --> Input Class Initialized
INFO - 2021-04-22 18:16:02 --> Language Class Initialized
ERROR - 2021-04-22 18:16:02 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:02 --> Config Class Initialized
INFO - 2021-04-22 18:16:02 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:02 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:02 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:02 --> URI Class Initialized
INFO - 2021-04-22 18:16:02 --> Router Class Initialized
INFO - 2021-04-22 18:16:02 --> Output Class Initialized
INFO - 2021-04-22 18:16:02 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:02 --> Input Class Initialized
INFO - 2021-04-22 18:16:02 --> Language Class Initialized
ERROR - 2021-04-22 18:16:02 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:02 --> Config Class Initialized
INFO - 2021-04-22 18:16:02 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:02 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:02 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:02 --> URI Class Initialized
INFO - 2021-04-22 18:16:02 --> Router Class Initialized
INFO - 2021-04-22 18:16:02 --> Output Class Initialized
INFO - 2021-04-22 18:16:02 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:02 --> Input Class Initialized
INFO - 2021-04-22 18:16:02 --> Language Class Initialized
ERROR - 2021-04-22 18:16:02 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:02 --> Config Class Initialized
INFO - 2021-04-22 18:16:02 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:02 --> Config Class Initialized
INFO - 2021-04-22 18:16:02 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:02 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:02 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:02 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:02 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:02 --> URI Class Initialized
INFO - 2021-04-22 18:16:02 --> URI Class Initialized
INFO - 2021-04-22 18:16:02 --> Router Class Initialized
INFO - 2021-04-22 18:16:02 --> Router Class Initialized
INFO - 2021-04-22 18:16:02 --> Output Class Initialized
INFO - 2021-04-22 18:16:02 --> Output Class Initialized
INFO - 2021-04-22 18:16:02 --> Security Class Initialized
INFO - 2021-04-22 18:16:02 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:02 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:02 --> Input Class Initialized
INFO - 2021-04-22 18:16:02 --> Language Class Initialized
INFO - 2021-04-22 18:16:02 --> Language Class Initialized
ERROR - 2021-04-22 18:16:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:16:02 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:16:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:02 --> Config Class Initialized
INFO - 2021-04-22 18:16:02 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:02 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:02 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:02 --> URI Class Initialized
INFO - 2021-04-22 18:16:02 --> Router Class Initialized
INFO - 2021-04-22 18:16:02 --> Output Class Initialized
INFO - 2021-04-22 18:16:02 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:02 --> Input Class Initialized
INFO - 2021-04-22 18:16:02 --> Language Class Initialized
ERROR - 2021-04-22 18:16:02 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:02 --> Config Class Initialized
INFO - 2021-04-22 18:16:02 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:02 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:02 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:02 --> URI Class Initialized
INFO - 2021-04-22 18:16:03 --> Router Class Initialized
INFO - 2021-04-22 18:16:03 --> Output Class Initialized
INFO - 2021-04-22 18:16:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:03 --> Input Class Initialized
INFO - 2021-04-22 18:16:03 --> Language Class Initialized
ERROR - 2021-04-22 18:16:03 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:03 --> Config Class Initialized
INFO - 2021-04-22 18:16:03 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:03 --> URI Class Initialized
INFO - 2021-04-22 18:16:03 --> Router Class Initialized
INFO - 2021-04-22 18:16:03 --> Output Class Initialized
INFO - 2021-04-22 18:16:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:03 --> Input Class Initialized
INFO - 2021-04-22 18:16:03 --> Language Class Initialized
ERROR - 2021-04-22 18:16:03 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:03 --> Config Class Initialized
INFO - 2021-04-22 18:16:03 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:03 --> URI Class Initialized
INFO - 2021-04-22 18:16:03 --> Router Class Initialized
INFO - 2021-04-22 18:16:03 --> Output Class Initialized
INFO - 2021-04-22 18:16:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:03 --> Input Class Initialized
INFO - 2021-04-22 18:16:03 --> Language Class Initialized
ERROR - 2021-04-22 18:16:03 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:03 --> Config Class Initialized
INFO - 2021-04-22 18:16:03 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:03 --> URI Class Initialized
INFO - 2021-04-22 18:16:03 --> Router Class Initialized
INFO - 2021-04-22 18:16:03 --> Output Class Initialized
INFO - 2021-04-22 18:16:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:03 --> Input Class Initialized
INFO - 2021-04-22 18:16:03 --> Language Class Initialized
ERROR - 2021-04-22 18:16:03 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:03 --> Config Class Initialized
INFO - 2021-04-22 18:16:03 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:03 --> URI Class Initialized
INFO - 2021-04-22 18:16:03 --> Router Class Initialized
INFO - 2021-04-22 18:16:03 --> Output Class Initialized
INFO - 2021-04-22 18:16:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:03 --> Input Class Initialized
INFO - 2021-04-22 18:16:03 --> Language Class Initialized
ERROR - 2021-04-22 18:16:03 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:03 --> Config Class Initialized
INFO - 2021-04-22 18:16:03 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:03 --> URI Class Initialized
INFO - 2021-04-22 18:16:03 --> Router Class Initialized
INFO - 2021-04-22 18:16:03 --> Output Class Initialized
INFO - 2021-04-22 18:16:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:03 --> Input Class Initialized
INFO - 2021-04-22 18:16:03 --> Language Class Initialized
ERROR - 2021-04-22 18:16:03 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:05 --> Config Class Initialized
INFO - 2021-04-22 18:16:05 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:05 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:05 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:05 --> URI Class Initialized
INFO - 2021-04-22 18:16:05 --> Router Class Initialized
INFO - 2021-04-22 18:16:05 --> Output Class Initialized
INFO - 2021-04-22 18:16:05 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:05 --> Input Class Initialized
INFO - 2021-04-22 18:16:05 --> Language Class Initialized
ERROR - 2021-04-22 18:16:05 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:05 --> Config Class Initialized
INFO - 2021-04-22 18:16:05 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:05 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:05 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:05 --> URI Class Initialized
INFO - 2021-04-22 18:16:05 --> Router Class Initialized
INFO - 2021-04-22 18:16:05 --> Output Class Initialized
INFO - 2021-04-22 18:16:05 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:05 --> Input Class Initialized
INFO - 2021-04-22 18:16:05 --> Language Class Initialized
ERROR - 2021-04-22 18:16:05 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:05 --> Config Class Initialized
INFO - 2021-04-22 18:16:05 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:05 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:05 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:05 --> URI Class Initialized
INFO - 2021-04-22 18:16:05 --> Router Class Initialized
INFO - 2021-04-22 18:16:05 --> Output Class Initialized
INFO - 2021-04-22 18:16:05 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:05 --> Input Class Initialized
INFO - 2021-04-22 18:16:05 --> Language Class Initialized
ERROR - 2021-04-22 18:16:05 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:05 --> Config Class Initialized
INFO - 2021-04-22 18:16:05 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:05 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:05 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:05 --> URI Class Initialized
INFO - 2021-04-22 18:16:05 --> Router Class Initialized
INFO - 2021-04-22 18:16:05 --> Output Class Initialized
INFO - 2021-04-22 18:16:05 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:05 --> Input Class Initialized
INFO - 2021-04-22 18:16:05 --> Language Class Initialized
ERROR - 2021-04-22 18:16:05 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:06 --> Config Class Initialized
INFO - 2021-04-22 18:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:06 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:06 --> URI Class Initialized
INFO - 2021-04-22 18:16:06 --> Router Class Initialized
INFO - 2021-04-22 18:16:06 --> Output Class Initialized
INFO - 2021-04-22 18:16:06 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:06 --> Input Class Initialized
INFO - 2021-04-22 18:16:06 --> Language Class Initialized
ERROR - 2021-04-22 18:16:06 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
INFO - 2021-04-22 18:16:15 --> Loader Class Initialized
INFO - 2021-04-22 18:16:15 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:15 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:15 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:15 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:15 --> Controller Class Initialized
INFO - 2021-04-22 18:16:15 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:15 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:16:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:16:15 --> Email Class Initialized
INFO - 2021-04-22 18:16:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:16:15 --> Calendar Class Initialized
INFO - 2021-04-22 18:16:15 --> Model "Login_model" initialized
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
INFO - 2021-04-22 18:16:15 --> Loader Class Initialized
INFO - 2021-04-22 18:16:15 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:15 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:15 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:15 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:15 --> Controller Class Initialized
INFO - 2021-04-22 18:16:15 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:15 --> Encrypt Class Initialized
INFO - 2021-04-22 18:16:15 --> Model "Diseases_model" initialized
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
INFO - 2021-04-22 18:16:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:16:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Undefined variable: case_name C:\xampp\htdocs\study\karosoftware\application\views\footer.php 3
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 10
ERROR - 2021-04-22 18:16:15 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 11
INFO - 2021-04-22 18:16:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:16:15 --> Final output sent to browser
DEBUG - 2021-04-22 18:16:15 --> Total execution time: 0.1008
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/css
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:15 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:15 --> Config Class Initialized
INFO - 2021-04-22 18:16:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:15 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:15 --> URI Class Initialized
INFO - 2021-04-22 18:16:15 --> Router Class Initialized
INFO - 2021-04-22 18:16:15 --> Output Class Initialized
INFO - 2021-04-22 18:16:15 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:15 --> Input Class Initialized
INFO - 2021-04-22 18:16:15 --> Language Class Initialized
ERROR - 2021-04-22 18:16:16 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:16 --> Config Class Initialized
INFO - 2021-04-22 18:16:16 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:16 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:16 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:16 --> URI Class Initialized
INFO - 2021-04-22 18:16:16 --> Router Class Initialized
INFO - 2021-04-22 18:16:16 --> Output Class Initialized
INFO - 2021-04-22 18:16:16 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:16 --> Input Class Initialized
INFO - 2021-04-22 18:16:16 --> Language Class Initialized
ERROR - 2021-04-22 18:16:16 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:16 --> Config Class Initialized
INFO - 2021-04-22 18:16:16 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:16 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:16 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:16 --> URI Class Initialized
INFO - 2021-04-22 18:16:16 --> Router Class Initialized
INFO - 2021-04-22 18:16:16 --> Output Class Initialized
INFO - 2021-04-22 18:16:16 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:16 --> Input Class Initialized
INFO - 2021-04-22 18:16:16 --> Language Class Initialized
ERROR - 2021-04-22 18:16:16 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:16 --> Config Class Initialized
INFO - 2021-04-22 18:16:16 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:16 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:16 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:16 --> URI Class Initialized
INFO - 2021-04-22 18:16:16 --> Router Class Initialized
INFO - 2021-04-22 18:16:16 --> Output Class Initialized
INFO - 2021-04-22 18:16:16 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:16 --> Input Class Initialized
INFO - 2021-04-22 18:16:16 --> Language Class Initialized
ERROR - 2021-04-22 18:16:16 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:17 --> Config Class Initialized
INFO - 2021-04-22 18:16:17 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:17 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:17 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:17 --> URI Class Initialized
INFO - 2021-04-22 18:16:17 --> Router Class Initialized
INFO - 2021-04-22 18:16:17 --> Output Class Initialized
INFO - 2021-04-22 18:16:17 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:17 --> Input Class Initialized
INFO - 2021-04-22 18:16:17 --> Language Class Initialized
ERROR - 2021-04-22 18:16:17 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:17 --> Config Class Initialized
INFO - 2021-04-22 18:16:17 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:17 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:17 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:17 --> URI Class Initialized
INFO - 2021-04-22 18:16:17 --> Router Class Initialized
INFO - 2021-04-22 18:16:17 --> Output Class Initialized
INFO - 2021-04-22 18:16:17 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:17 --> Input Class Initialized
INFO - 2021-04-22 18:16:17 --> Language Class Initialized
ERROR - 2021-04-22 18:16:17 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:17 --> Config Class Initialized
INFO - 2021-04-22 18:16:17 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:17 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:17 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:17 --> URI Class Initialized
INFO - 2021-04-22 18:16:17 --> Router Class Initialized
INFO - 2021-04-22 18:16:17 --> Output Class Initialized
INFO - 2021-04-22 18:16:17 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:17 --> Input Class Initialized
INFO - 2021-04-22 18:16:17 --> Language Class Initialized
ERROR - 2021-04-22 18:16:17 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:17 --> Config Class Initialized
INFO - 2021-04-22 18:16:17 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:17 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:17 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:17 --> URI Class Initialized
INFO - 2021-04-22 18:16:17 --> Router Class Initialized
INFO - 2021-04-22 18:16:17 --> Output Class Initialized
INFO - 2021-04-22 18:16:17 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:17 --> Input Class Initialized
INFO - 2021-04-22 18:16:17 --> Language Class Initialized
ERROR - 2021-04-22 18:16:17 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:20 --> No URI present. Default controller set.
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:20 --> Input Class Initialized
INFO - 2021-04-22 18:16:20 --> Language Class Initialized
INFO - 2021-04-22 18:16:20 --> Loader Class Initialized
INFO - 2021-04-22 18:16:20 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:20 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:20 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:20 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:20 --> Controller Class Initialized
INFO - 2021-04-22 18:16:20 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:20 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:16:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:16:20 --> Email Class Initialized
INFO - 2021-04-22 18:16:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:16:20 --> Calendar Class Initialized
INFO - 2021-04-22 18:16:20 --> Model "Login_model" initialized
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:20 --> Input Class Initialized
INFO - 2021-04-22 18:16:20 --> Language Class Initialized
INFO - 2021-04-22 18:16:20 --> Loader Class Initialized
INFO - 2021-04-22 18:16:20 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:20 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:20 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:20 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:20 --> Controller Class Initialized
INFO - 2021-04-22 18:16:20 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:20 --> Encrypt Class Initialized
INFO - 2021-04-22 18:16:20 --> Model "Diseases_model" initialized
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
INFO - 2021-04-22 18:16:20 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:16:20 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Undefined variable: case_name C:\xampp\htdocs\study\karosoftware\application\views\footer.php 3
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 10
ERROR - 2021-04-22 18:16:20 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 11
INFO - 2021-04-22 18:16:20 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:16:20 --> Final output sent to browser
DEBUG - 2021-04-22 18:16:20 --> Total execution time: 0.1023
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:20 --> Input Class Initialized
INFO - 2021-04-22 18:16:20 --> Language Class Initialized
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
ERROR - 2021-04-22 18:16:20 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:20 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:20 --> Input Class Initialized
INFO - 2021-04-22 18:16:20 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:20 --> Input Class Initialized
INFO - 2021-04-22 18:16:20 --> Language Class Initialized
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
INFO - 2021-04-22 18:16:20 --> Language Class Initialized
ERROR - 2021-04-22 18:16:20 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:20 --> 404 Page Not Found: Karoclient/css
DEBUG - 2021-04-22 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:20 --> Input Class Initialized
ERROR - 2021-04-22 18:16:20 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:16:20 --> Language Class Initialized
ERROR - 2021-04-22 18:16:20 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:16:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
INFO - 2021-04-22 18:16:20 --> Config Class Initialized
INFO - 2021-04-22 18:16:20 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
INFO - 2021-04-22 18:16:20 --> URI Class Initialized
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
INFO - 2021-04-22 18:16:20 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:20 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:20 --> Input Class Initialized
INFO - 2021-04-22 18:16:20 --> Language Class Initialized
INFO - 2021-04-22 18:16:20 --> Output Class Initialized
INFO - 2021-04-22 18:16:20 --> Language Class Initialized
ERROR - 2021-04-22 18:16:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:16:20 --> 404 Page Not Found: Karoclient/images
INFO - 2021-04-22 18:16:20 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:21 --> Config Class Initialized
INFO - 2021-04-22 18:16:21 --> Config Class Initialized
INFO - 2021-04-22 18:16:21 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:21 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:21 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:21 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:21 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:21 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:21 --> URI Class Initialized
INFO - 2021-04-22 18:16:21 --> URI Class Initialized
INFO - 2021-04-22 18:16:21 --> Router Class Initialized
INFO - 2021-04-22 18:16:21 --> Router Class Initialized
INFO - 2021-04-22 18:16:21 --> Output Class Initialized
INFO - 2021-04-22 18:16:21 --> Output Class Initialized
INFO - 2021-04-22 18:16:21 --> Security Class Initialized
INFO - 2021-04-22 18:16:21 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:21 --> Config Class Initialized
INFO - 2021-04-22 18:16:21 --> Hooks Class Initialized
ERROR - 2021-04-22 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:21 --> Config Class Initialized
INFO - 2021-04-22 18:16:21 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:21 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:21 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:21 --> URI Class Initialized
ERROR - 2021-04-22 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2021-04-22 18:16:21 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:21 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:21 --> Router Class Initialized
INFO - 2021-04-22 18:16:21 --> Config Class Initialized
INFO - 2021-04-22 18:16:21 --> URI Class Initialized
INFO - 2021-04-22 18:16:21 --> Hooks Class Initialized
ERROR - 2021-04-22 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:21 --> Output Class Initialized
INFO - 2021-04-22 18:16:21 --> Router Class Initialized
INFO - 2021-04-22 18:16:21 --> Config Class Initialized
INFO - 2021-04-22 18:16:21 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:21 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:21 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:21 --> Output Class Initialized
INFO - 2021-04-22 18:16:21 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:21 --> URI Class Initialized
INFO - 2021-04-22 18:16:21 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:21 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:21 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:21 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
INFO - 2021-04-22 18:16:21 --> URI Class Initialized
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
INFO - 2021-04-22 18:16:21 --> Output Class Initialized
INFO - 2021-04-22 18:16:21 --> Router Class Initialized
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:21 --> Security Class Initialized
INFO - 2021-04-22 18:16:21 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
INFO - 2021-04-22 18:16:21 --> Security Class Initialized
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:21 --> Config Class Initialized
INFO - 2021-04-22 18:16:21 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:21 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:21 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:21 --> URI Class Initialized
INFO - 2021-04-22 18:16:21 --> Router Class Initialized
INFO - 2021-04-22 18:16:21 --> Output Class Initialized
INFO - 2021-04-22 18:16:21 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:21 --> Config Class Initialized
INFO - 2021-04-22 18:16:21 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:21 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:21 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:21 --> URI Class Initialized
INFO - 2021-04-22 18:16:21 --> Router Class Initialized
INFO - 2021-04-22 18:16:21 --> Output Class Initialized
INFO - 2021-04-22 18:16:21 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:21 --> Config Class Initialized
INFO - 2021-04-22 18:16:21 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:21 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:21 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:21 --> URI Class Initialized
INFO - 2021-04-22 18:16:21 --> Router Class Initialized
INFO - 2021-04-22 18:16:21 --> Output Class Initialized
INFO - 2021-04-22 18:16:21 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:21 --> Input Class Initialized
INFO - 2021-04-22 18:16:21 --> Language Class Initialized
ERROR - 2021-04-22 18:16:21 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:22 --> Config Class Initialized
INFO - 2021-04-22 18:16:22 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:22 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:22 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:22 --> URI Class Initialized
INFO - 2021-04-22 18:16:22 --> Router Class Initialized
INFO - 2021-04-22 18:16:22 --> Output Class Initialized
INFO - 2021-04-22 18:16:22 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:22 --> Input Class Initialized
INFO - 2021-04-22 18:16:22 --> Language Class Initialized
ERROR - 2021-04-22 18:16:22 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:22 --> Config Class Initialized
INFO - 2021-04-22 18:16:22 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:22 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:22 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:22 --> URI Class Initialized
INFO - 2021-04-22 18:16:22 --> Router Class Initialized
INFO - 2021-04-22 18:16:22 --> Output Class Initialized
INFO - 2021-04-22 18:16:22 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:22 --> Input Class Initialized
INFO - 2021-04-22 18:16:22 --> Language Class Initialized
ERROR - 2021-04-22 18:16:22 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:22 --> Config Class Initialized
INFO - 2021-04-22 18:16:22 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:22 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:22 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:22 --> URI Class Initialized
INFO - 2021-04-22 18:16:22 --> Router Class Initialized
INFO - 2021-04-22 18:16:22 --> Output Class Initialized
INFO - 2021-04-22 18:16:22 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:22 --> Input Class Initialized
INFO - 2021-04-22 18:16:22 --> Language Class Initialized
ERROR - 2021-04-22 18:16:22 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:22 --> Config Class Initialized
INFO - 2021-04-22 18:16:22 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:22 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:22 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:22 --> URI Class Initialized
INFO - 2021-04-22 18:16:22 --> Router Class Initialized
INFO - 2021-04-22 18:16:22 --> Output Class Initialized
INFO - 2021-04-22 18:16:22 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:22 --> Input Class Initialized
INFO - 2021-04-22 18:16:22 --> Language Class Initialized
ERROR - 2021-04-22 18:16:22 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:24 --> Config Class Initialized
INFO - 2021-04-22 18:16:24 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:24 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:24 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:24 --> URI Class Initialized
INFO - 2021-04-22 18:16:24 --> Router Class Initialized
INFO - 2021-04-22 18:16:24 --> Output Class Initialized
INFO - 2021-04-22 18:16:24 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:24 --> Input Class Initialized
INFO - 2021-04-22 18:16:24 --> Language Class Initialized
INFO - 2021-04-22 18:16:24 --> Loader Class Initialized
INFO - 2021-04-22 18:16:24 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:24 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:24 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:24 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:24 --> Controller Class Initialized
INFO - 2021-04-22 18:16:24 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:24 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:16:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:16:24 --> Email Class Initialized
INFO - 2021-04-22 18:16:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:16:24 --> Calendar Class Initialized
INFO - 2021-04-22 18:16:24 --> Model "Login_model" initialized
ERROR - 2021-04-22 18:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:24 --> Config Class Initialized
INFO - 2021-04-22 18:16:24 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:24 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:24 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:24 --> URI Class Initialized
INFO - 2021-04-22 18:16:24 --> Router Class Initialized
INFO - 2021-04-22 18:16:24 --> Output Class Initialized
INFO - 2021-04-22 18:16:24 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:24 --> Input Class Initialized
INFO - 2021-04-22 18:16:24 --> Language Class Initialized
INFO - 2021-04-22 18:16:24 --> Loader Class Initialized
INFO - 2021-04-22 18:16:24 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:24 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:24 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:24 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:24 --> Controller Class Initialized
INFO - 2021-04-22 18:16:24 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:24 --> Encrypt Class Initialized
INFO - 2021-04-22 18:16:24 --> Model "Diseases_model" initialized
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
INFO - 2021-04-22 18:16:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:16:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Undefined variable: case_name C:\xampp\htdocs\study\karosoftware\application\views\footer.php 3
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 10
ERROR - 2021-04-22 18:16:24 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 11
INFO - 2021-04-22 18:16:24 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:16:24 --> Final output sent to browser
DEBUG - 2021-04-22 18:16:24 --> Total execution time: 0.1343
ERROR - 2021-04-22 18:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:24 --> Config Class Initialized
INFO - 2021-04-22 18:16:24 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:24 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:25 --> Config Class Initialized
INFO - 2021-04-22 18:16:25 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:25 --> URI Class Initialized
INFO - 2021-04-22 18:16:25 --> Router Class Initialized
INFO - 2021-04-22 18:16:25 --> Output Class Initialized
INFO - 2021-04-22 18:16:25 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:25 --> Input Class Initialized
INFO - 2021-04-22 18:16:25 --> Language Class Initialized
ERROR - 2021-04-22 18:16:25 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:26 --> Config Class Initialized
INFO - 2021-04-22 18:16:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:26 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:26 --> URI Class Initialized
INFO - 2021-04-22 18:16:26 --> Router Class Initialized
INFO - 2021-04-22 18:16:26 --> Output Class Initialized
INFO - 2021-04-22 18:16:26 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:26 --> Input Class Initialized
INFO - 2021-04-22 18:16:26 --> Language Class Initialized
ERROR - 2021-04-22 18:16:26 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:26 --> Config Class Initialized
INFO - 2021-04-22 18:16:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:26 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:26 --> URI Class Initialized
INFO - 2021-04-22 18:16:26 --> Router Class Initialized
INFO - 2021-04-22 18:16:26 --> Output Class Initialized
INFO - 2021-04-22 18:16:26 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:26 --> Input Class Initialized
INFO - 2021-04-22 18:16:26 --> Language Class Initialized
ERROR - 2021-04-22 18:16:26 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:26 --> Config Class Initialized
INFO - 2021-04-22 18:16:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:26 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:26 --> URI Class Initialized
INFO - 2021-04-22 18:16:26 --> Router Class Initialized
INFO - 2021-04-22 18:16:26 --> Output Class Initialized
INFO - 2021-04-22 18:16:26 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:26 --> Input Class Initialized
INFO - 2021-04-22 18:16:26 --> Language Class Initialized
ERROR - 2021-04-22 18:16:26 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:26 --> Config Class Initialized
INFO - 2021-04-22 18:16:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:26 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:26 --> URI Class Initialized
INFO - 2021-04-22 18:16:26 --> Router Class Initialized
INFO - 2021-04-22 18:16:26 --> Output Class Initialized
INFO - 2021-04-22 18:16:26 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:26 --> Input Class Initialized
INFO - 2021-04-22 18:16:26 --> Language Class Initialized
ERROR - 2021-04-22 18:16:26 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:28 --> Config Class Initialized
INFO - 2021-04-22 18:16:28 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:28 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:28 --> URI Class Initialized
INFO - 2021-04-22 18:16:28 --> Router Class Initialized
INFO - 2021-04-22 18:16:28 --> Output Class Initialized
INFO - 2021-04-22 18:16:28 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:28 --> Input Class Initialized
INFO - 2021-04-22 18:16:28 --> Language Class Initialized
INFO - 2021-04-22 18:16:28 --> Loader Class Initialized
INFO - 2021-04-22 18:16:28 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:28 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:28 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:28 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:28 --> Controller Class Initialized
INFO - 2021-04-22 18:16:28 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:28 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:16:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:16:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:16:28 --> Email Class Initialized
INFO - 2021-04-22 18:16:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:16:28 --> Calendar Class Initialized
INFO - 2021-04-22 18:16:28 --> Model "Login_model" initialized
ERROR - 2021-04-22 18:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:28 --> Config Class Initialized
INFO - 2021-04-22 18:16:28 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:28 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:28 --> URI Class Initialized
INFO - 2021-04-22 18:16:28 --> Router Class Initialized
INFO - 2021-04-22 18:16:28 --> Output Class Initialized
INFO - 2021-04-22 18:16:28 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:28 --> Input Class Initialized
INFO - 2021-04-22 18:16:28 --> Language Class Initialized
INFO - 2021-04-22 18:16:28 --> Loader Class Initialized
INFO - 2021-04-22 18:16:28 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:28 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:28 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:28 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:28 --> Controller Class Initialized
INFO - 2021-04-22 18:16:28 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:28 --> Encrypt Class Initialized
INFO - 2021-04-22 18:16:28 --> Model "Diseases_model" initialized
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
INFO - 2021-04-22 18:16:28 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:16:28 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Undefined variable: case_name C:\xampp\htdocs\study\karosoftware\application\views\footer.php 3
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 10
ERROR - 2021-04-22 18:16:28 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 11
INFO - 2021-04-22 18:16:28 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:16:28 --> Final output sent to browser
DEBUG - 2021-04-22 18:16:28 --> Total execution time: 0.0708
ERROR - 2021-04-22 18:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:28 --> Config Class Initialized
INFO - 2021-04-22 18:16:28 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:28 --> Config Class Initialized
INFO - 2021-04-22 18:16:28 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:16:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:28 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:28 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:28 --> URI Class Initialized
INFO - 2021-04-22 18:16:28 --> URI Class Initialized
ERROR - 2021-04-22 18:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:28 --> Router Class Initialized
INFO - 2021-04-22 18:16:28 --> Router Class Initialized
INFO - 2021-04-22 18:16:28 --> Config Class Initialized
INFO - 2021-04-22 18:16:28 --> Hooks Class Initialized
ERROR - 2021-04-22 18:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:28 --> Output Class Initialized
INFO - 2021-04-22 18:16:28 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:28 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:28 --> Security Class Initialized
INFO - 2021-04-22 18:16:28 --> Security Class Initialized
INFO - 2021-04-22 18:16:28 --> Config Class Initialized
INFO - 2021-04-22 18:16:28 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:28 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-22 18:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:28 --> Input Class Initialized
INFO - 2021-04-22 18:16:28 --> Input Class Initialized
INFO - 2021-04-22 18:16:28 --> Language Class Initialized
INFO - 2021-04-22 18:16:28 --> Language Class Initialized
INFO - 2021-04-22 18:16:28 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:28 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:16:28 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:28 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:16:28 --> URI Class Initialized
INFO - 2021-04-22 18:16:28 --> Output Class Initialized
INFO - 2021-04-22 18:16:28 --> Router Class Initialized
INFO - 2021-04-22 18:16:28 --> Security Class Initialized
INFO - 2021-04-22 18:16:28 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:28 --> Security Class Initialized
INFO - 2021-04-22 18:16:28 --> Input Class Initialized
INFO - 2021-04-22 18:16:28 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:28 --> Input Class Initialized
ERROR - 2021-04-22 18:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:28 --> Language Class Initialized
ERROR - 2021-04-22 18:16:28 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:28 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:16:28 --> Config Class Initialized
INFO - 2021-04-22 18:16:28 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:28 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:28 --> URI Class Initialized
INFO - 2021-04-22 18:16:28 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/usersprofile
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:29 --> Config Class Initialized
INFO - 2021-04-22 18:16:29 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:29 --> URI Class Initialized
INFO - 2021-04-22 18:16:29 --> Router Class Initialized
INFO - 2021-04-22 18:16:29 --> Output Class Initialized
INFO - 2021-04-22 18:16:29 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:29 --> Input Class Initialized
INFO - 2021-04-22 18:16:29 --> Language Class Initialized
ERROR - 2021-04-22 18:16:29 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:30 --> Config Class Initialized
INFO - 2021-04-22 18:16:30 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:30 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:30 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:30 --> URI Class Initialized
INFO - 2021-04-22 18:16:30 --> Router Class Initialized
INFO - 2021-04-22 18:16:30 --> Output Class Initialized
INFO - 2021-04-22 18:16:30 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:30 --> Input Class Initialized
INFO - 2021-04-22 18:16:30 --> Language Class Initialized
ERROR - 2021-04-22 18:16:30 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:30 --> Config Class Initialized
INFO - 2021-04-22 18:16:30 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:30 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:30 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:30 --> URI Class Initialized
INFO - 2021-04-22 18:16:30 --> Router Class Initialized
INFO - 2021-04-22 18:16:30 --> Output Class Initialized
INFO - 2021-04-22 18:16:30 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:30 --> Input Class Initialized
INFO - 2021-04-22 18:16:30 --> Language Class Initialized
ERROR - 2021-04-22 18:16:30 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:30 --> Config Class Initialized
INFO - 2021-04-22 18:16:30 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:30 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:30 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:30 --> URI Class Initialized
INFO - 2021-04-22 18:16:30 --> Router Class Initialized
INFO - 2021-04-22 18:16:30 --> Output Class Initialized
INFO - 2021-04-22 18:16:30 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:30 --> Input Class Initialized
INFO - 2021-04-22 18:16:30 --> Language Class Initialized
ERROR - 2021-04-22 18:16:30 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:30 --> Config Class Initialized
INFO - 2021-04-22 18:16:30 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:30 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:30 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:30 --> URI Class Initialized
INFO - 2021-04-22 18:16:30 --> Router Class Initialized
INFO - 2021-04-22 18:16:30 --> Output Class Initialized
INFO - 2021-04-22 18:16:30 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:30 --> Input Class Initialized
INFO - 2021-04-22 18:16:30 --> Language Class Initialized
ERROR - 2021-04-22 18:16:30 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:33 --> Config Class Initialized
INFO - 2021-04-22 18:16:33 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:33 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:33 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:33 --> URI Class Initialized
INFO - 2021-04-22 18:16:33 --> Router Class Initialized
INFO - 2021-04-22 18:16:33 --> Output Class Initialized
INFO - 2021-04-22 18:16:33 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:33 --> Input Class Initialized
INFO - 2021-04-22 18:16:33 --> Language Class Initialized
INFO - 2021-04-22 18:16:33 --> Loader Class Initialized
INFO - 2021-04-22 18:16:33 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:33 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:33 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:33 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:33 --> Controller Class Initialized
INFO - 2021-04-22 18:16:33 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:33 --> Encrypt Class Initialized
INFO - 2021-04-22 18:16:33 --> Model "Login_model" initialized
INFO - 2021-04-22 18:16:33 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:16:33 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:16:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\study\karosoftware\application\models\Dashboard_model.php 12
ERROR - 2021-04-22 18:16:33 --> Severity: Notice --> Undefined index: all C:\xampp\htdocs\study\karosoftware\application\controllers\Dashboard.php 33
ERROR - 2021-04-22 18:16:33 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:16:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:16:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:38 --> Config Class Initialized
INFO - 2021-04-22 18:16:38 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:38 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:38 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:38 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:38 --> No URI present. Default controller set.
INFO - 2021-04-22 18:16:38 --> Router Class Initialized
INFO - 2021-04-22 18:16:38 --> Output Class Initialized
INFO - 2021-04-22 18:16:38 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:38 --> Input Class Initialized
INFO - 2021-04-22 18:16:38 --> Language Class Initialized
INFO - 2021-04-22 18:16:38 --> Loader Class Initialized
INFO - 2021-04-22 18:16:38 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:38 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:38 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:38 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:38 --> Controller Class Initialized
INFO - 2021-04-22 18:16:38 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:38 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:16:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:16:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:16:38 --> Email Class Initialized
INFO - 2021-04-22 18:16:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:16:38 --> Calendar Class Initialized
INFO - 2021-04-22 18:16:38 --> Model "Login_model" initialized
ERROR - 2021-04-22 18:16:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:38 --> Config Class Initialized
INFO - 2021-04-22 18:16:38 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
INFO - 2021-04-22 18:16:39 --> Loader Class Initialized
INFO - 2021-04-22 18:16:39 --> Helper loaded: url_helper
INFO - 2021-04-22 18:16:39 --> Helper loaded: form_helper
INFO - 2021-04-22 18:16:39 --> Helper loaded: common_helper
INFO - 2021-04-22 18:16:39 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:16:39 --> Controller Class Initialized
INFO - 2021-04-22 18:16:39 --> Form Validation Class Initialized
INFO - 2021-04-22 18:16:39 --> Encrypt Class Initialized
INFO - 2021-04-22 18:16:39 --> Model "Diseases_model" initialized
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
INFO - 2021-04-22 18:16:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:16:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Undefined variable: case_name C:\xampp\htdocs\study\karosoftware\application\views\footer.php 3
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 10
ERROR - 2021-04-22 18:16:39 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 11
INFO - 2021-04-22 18:16:39 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:16:39 --> Final output sent to browser
DEBUG - 2021-04-22 18:16:39 --> Total execution time: 0.2246
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/css
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/images
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:39 --> Config Class Initialized
INFO - 2021-04-22 18:16:39 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:39 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:39 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:39 --> URI Class Initialized
INFO - 2021-04-22 18:16:39 --> Router Class Initialized
INFO - 2021-04-22 18:16:39 --> Output Class Initialized
INFO - 2021-04-22 18:16:39 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:39 --> Input Class Initialized
INFO - 2021-04-22 18:16:39 --> Language Class Initialized
ERROR - 2021-04-22 18:16:39 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:40 --> Config Class Initialized
INFO - 2021-04-22 18:16:40 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:40 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:40 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:40 --> URI Class Initialized
INFO - 2021-04-22 18:16:40 --> Router Class Initialized
INFO - 2021-04-22 18:16:40 --> Output Class Initialized
INFO - 2021-04-22 18:16:40 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:40 --> Input Class Initialized
INFO - 2021-04-22 18:16:40 --> Language Class Initialized
ERROR - 2021-04-22 18:16:40 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:40 --> Config Class Initialized
INFO - 2021-04-22 18:16:40 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:40 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:40 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:40 --> URI Class Initialized
INFO - 2021-04-22 18:16:40 --> Router Class Initialized
INFO - 2021-04-22 18:16:40 --> Output Class Initialized
INFO - 2021-04-22 18:16:40 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:40 --> Input Class Initialized
INFO - 2021-04-22 18:16:40 --> Language Class Initialized
ERROR - 2021-04-22 18:16:40 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:40 --> Config Class Initialized
INFO - 2021-04-22 18:16:40 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:40 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:40 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:40 --> URI Class Initialized
INFO - 2021-04-22 18:16:40 --> Router Class Initialized
INFO - 2021-04-22 18:16:40 --> Output Class Initialized
INFO - 2021-04-22 18:16:40 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:40 --> Input Class Initialized
INFO - 2021-04-22 18:16:40 --> Language Class Initialized
ERROR - 2021-04-22 18:16:40 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:16:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:16:40 --> Config Class Initialized
INFO - 2021-04-22 18:16:40 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:16:40 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:16:40 --> Utf8 Class Initialized
INFO - 2021-04-22 18:16:40 --> URI Class Initialized
INFO - 2021-04-22 18:16:40 --> Router Class Initialized
INFO - 2021-04-22 18:16:40 --> Output Class Initialized
INFO - 2021-04-22 18:16:40 --> Security Class Initialized
DEBUG - 2021-04-22 18:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:16:40 --> Input Class Initialized
INFO - 2021-04-22 18:16:40 --> Language Class Initialized
ERROR - 2021-04-22 18:16:40 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:17:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:17:56 --> Config Class Initialized
INFO - 2021-04-22 18:17:56 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:17:56 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:17:56 --> Utf8 Class Initialized
INFO - 2021-04-22 18:17:56 --> URI Class Initialized
INFO - 2021-04-22 18:17:56 --> Router Class Initialized
INFO - 2021-04-22 18:17:56 --> Output Class Initialized
INFO - 2021-04-22 18:17:56 --> Security Class Initialized
DEBUG - 2021-04-22 18:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:17:56 --> Input Class Initialized
INFO - 2021-04-22 18:17:56 --> Language Class Initialized
ERROR - 2021-04-22 18:17:56 --> 404 Page Not Found: Logout/index
ERROR - 2021-04-22 18:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:06 --> Config Class Initialized
INFO - 2021-04-22 18:18:06 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:06 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:06 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:06 --> URI Class Initialized
DEBUG - 2021-04-22 18:18:06 --> No URI present. Default controller set.
INFO - 2021-04-22 18:18:06 --> Router Class Initialized
INFO - 2021-04-22 18:18:06 --> Output Class Initialized
INFO - 2021-04-22 18:18:06 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:06 --> Input Class Initialized
INFO - 2021-04-22 18:18:06 --> Language Class Initialized
INFO - 2021-04-22 18:18:06 --> Loader Class Initialized
INFO - 2021-04-22 18:18:06 --> Helper loaded: url_helper
INFO - 2021-04-22 18:18:06 --> Helper loaded: form_helper
INFO - 2021-04-22 18:18:06 --> Helper loaded: common_helper
INFO - 2021-04-22 18:18:06 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:18:06 --> Controller Class Initialized
INFO - 2021-04-22 18:18:06 --> Form Validation Class Initialized
INFO - 2021-04-22 18:18:06 --> Encrypt Class Initialized
DEBUG - 2021-04-22 18:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 18:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 18:18:06 --> Email Class Initialized
INFO - 2021-04-22 18:18:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 18:18:06 --> Calendar Class Initialized
INFO - 2021-04-22 18:18:06 --> Model "Login_model" initialized
ERROR - 2021-04-22 18:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:06 --> Config Class Initialized
INFO - 2021-04-22 18:18:06 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:06 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:06 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:06 --> URI Class Initialized
INFO - 2021-04-22 18:18:06 --> Router Class Initialized
INFO - 2021-04-22 18:18:06 --> Output Class Initialized
INFO - 2021-04-22 18:18:06 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:06 --> Input Class Initialized
INFO - 2021-04-22 18:18:06 --> Language Class Initialized
INFO - 2021-04-22 18:18:06 --> Loader Class Initialized
INFO - 2021-04-22 18:18:06 --> Helper loaded: url_helper
INFO - 2021-04-22 18:18:06 --> Helper loaded: form_helper
INFO - 2021-04-22 18:18:06 --> Helper loaded: common_helper
INFO - 2021-04-22 18:18:06 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:18:06 --> Controller Class Initialized
INFO - 2021-04-22 18:18:06 --> Form Validation Class Initialized
INFO - 2021-04-22 18:18:06 --> Encrypt Class Initialized
INFO - 2021-04-22 18:18:06 --> Model "Diseases_model" initialized
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 178
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 179
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 180
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 181
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 182
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\study\karosoftware\application\views\header.php 183
INFO - 2021-04-22 18:18:06 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:18:06 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Undefined variable: case_name C:\xampp\htdocs\study\karosoftware\application\views\footer.php 3
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 10
ERROR - 2021-04-22 18:18:06 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\study\karosoftware\application\views\footer.php 11
INFO - 2021-04-22 18:18:06 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:18:06 --> Final output sent to browser
DEBUG - 2021-04-22 18:18:06 --> Total execution time: 0.1143
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/images
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/usersprofile
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:07 --> Config Class Initialized
INFO - 2021-04-22 18:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:07 --> URI Class Initialized
INFO - 2021-04-22 18:18:07 --> Router Class Initialized
INFO - 2021-04-22 18:18:07 --> Output Class Initialized
INFO - 2021-04-22 18:18:07 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:07 --> Input Class Initialized
INFO - 2021-04-22 18:18:07 --> Language Class Initialized
ERROR - 2021-04-22 18:18:07 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:08 --> Config Class Initialized
INFO - 2021-04-22 18:18:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:08 --> URI Class Initialized
INFO - 2021-04-22 18:18:08 --> Router Class Initialized
INFO - 2021-04-22 18:18:08 --> Output Class Initialized
INFO - 2021-04-22 18:18:08 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:08 --> Input Class Initialized
INFO - 2021-04-22 18:18:08 --> Language Class Initialized
ERROR - 2021-04-22 18:18:08 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:08 --> Config Class Initialized
INFO - 2021-04-22 18:18:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:08 --> URI Class Initialized
INFO - 2021-04-22 18:18:08 --> Router Class Initialized
INFO - 2021-04-22 18:18:08 --> Output Class Initialized
INFO - 2021-04-22 18:18:08 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:08 --> Input Class Initialized
INFO - 2021-04-22 18:18:08 --> Language Class Initialized
ERROR - 2021-04-22 18:18:08 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:08 --> Config Class Initialized
INFO - 2021-04-22 18:18:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:08 --> URI Class Initialized
INFO - 2021-04-22 18:18:08 --> Router Class Initialized
INFO - 2021-04-22 18:18:08 --> Output Class Initialized
INFO - 2021-04-22 18:18:08 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:08 --> Input Class Initialized
INFO - 2021-04-22 18:18:08 --> Language Class Initialized
ERROR - 2021-04-22 18:18:08 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:18:08 --> Config Class Initialized
INFO - 2021-04-22 18:18:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:18:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:18:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:18:08 --> URI Class Initialized
INFO - 2021-04-22 18:18:08 --> Router Class Initialized
INFO - 2021-04-22 18:18:08 --> Output Class Initialized
INFO - 2021-04-22 18:18:08 --> Security Class Initialized
DEBUG - 2021-04-22 18:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:18:08 --> Input Class Initialized
INFO - 2021-04-22 18:18:08 --> Language Class Initialized
ERROR - 2021-04-22 18:18:08 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:08 --> Config Class Initialized
INFO - 2021-04-22 18:21:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:08 --> URI Class Initialized
INFO - 2021-04-22 18:21:08 --> Router Class Initialized
INFO - 2021-04-22 18:21:08 --> Output Class Initialized
INFO - 2021-04-22 18:21:08 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:08 --> Input Class Initialized
INFO - 2021-04-22 18:21:08 --> Language Class Initialized
INFO - 2021-04-22 18:21:08 --> Loader Class Initialized
INFO - 2021-04-22 18:21:08 --> Helper loaded: url_helper
INFO - 2021-04-22 18:21:08 --> Helper loaded: form_helper
INFO - 2021-04-22 18:21:08 --> Helper loaded: common_helper
INFO - 2021-04-22 18:21:08 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:21:08 --> Controller Class Initialized
INFO - 2021-04-22 18:21:08 --> Form Validation Class Initialized
INFO - 2021-04-22 18:21:08 --> Encrypt Class Initialized
INFO - 2021-04-22 18:21:08 --> Model "Diseases_model" initialized
INFO - 2021-04-22 18:21:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:21:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
INFO - 2021-04-22 18:21:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:21:08 --> Final output sent to browser
DEBUG - 2021-04-22 18:21:08 --> Total execution time: 0.0662
ERROR - 2021-04-22 18:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:08 --> Config Class Initialized
INFO - 2021-04-22 18:21:08 --> Hooks Class Initialized
INFO - 2021-04-22 18:21:08 --> Config Class Initialized
INFO - 2021-04-22 18:21:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:08 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:21:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:08 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:08 --> URI Class Initialized
INFO - 2021-04-22 18:21:08 --> URI Class Initialized
INFO - 2021-04-22 18:21:08 --> Router Class Initialized
INFO - 2021-04-22 18:21:08 --> Config Class Initialized
INFO - 2021-04-22 18:21:08 --> Hooks Class Initialized
INFO - 2021-04-22 18:21:08 --> Output Class Initialized
INFO - 2021-04-22 18:21:08 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:08 --> Router Class Initialized
INFO - 2021-04-22 18:21:08 --> URI Class Initialized
DEBUG - 2021-04-22 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:08 --> Input Class Initialized
INFO - 2021-04-22 18:21:08 --> Language Class Initialized
INFO - 2021-04-22 18:21:08 --> Router Class Initialized
INFO - 2021-04-22 18:21:08 --> Output Class Initialized
ERROR - 2021-04-22 18:21:08 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:21:08 --> Security Class Initialized
INFO - 2021-04-22 18:21:08 --> Output Class Initialized
DEBUG - 2021-04-22 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:08 --> Security Class Initialized
INFO - 2021-04-22 18:21:08 --> Input Class Initialized
INFO - 2021-04-22 18:21:08 --> Language Class Initialized
DEBUG - 2021-04-22 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:08 --> Input Class Initialized
ERROR - 2021-04-22 18:21:08 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:21:08 --> Language Class Initialized
ERROR - 2021-04-22 18:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:08 --> Config Class Initialized
INFO - 2021-04-22 18:21:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:08 --> Utf8 Class Initialized
ERROR - 2021-04-22 18:21:08 --> 404 Page Not Found: Karoclient/css
INFO - 2021-04-22 18:21:08 --> URI Class Initialized
INFO - 2021-04-22 18:21:08 --> Router Class Initialized
INFO - 2021-04-22 18:21:08 --> Output Class Initialized
ERROR - 2021-04-22 18:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:08 --> Security Class Initialized
INFO - 2021-04-22 18:21:08 --> Config Class Initialized
INFO - 2021-04-22 18:21:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:08 --> Input Class Initialized
INFO - 2021-04-22 18:21:08 --> Language Class Initialized
ERROR - 2021-04-22 18:21:08 --> 404 Page Not Found: Karoclient/css
DEBUG - 2021-04-22 18:21:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:08 --> URI Class Initialized
INFO - 2021-04-22 18:21:08 --> Router Class Initialized
INFO - 2021-04-22 18:21:08 --> Output Class Initialized
INFO - 2021-04-22 18:21:08 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:08 --> Input Class Initialized
INFO - 2021-04-22 18:21:08 --> Language Class Initialized
ERROR - 2021-04-22 18:21:08 --> 404 Page Not Found: Karoclient/css
ERROR - 2021-04-22 18:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:09 --> Config Class Initialized
INFO - 2021-04-22 18:21:09 --> Hooks Class Initialized
INFO - 2021-04-22 18:21:09 --> Config Class Initialized
INFO - 2021-04-22 18:21:09 --> Hooks Class Initialized
ERROR - 2021-04-22 18:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:09 --> Config Class Initialized
INFO - 2021-04-22 18:21:09 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:09 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:09 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:21:09 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:09 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:09 --> URI Class Initialized
INFO - 2021-04-22 18:21:09 --> URI Class Initialized
DEBUG - 2021-04-22 18:21:09 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:09 --> Router Class Initialized
INFO - 2021-04-22 18:21:09 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:09 --> Router Class Initialized
INFO - 2021-04-22 18:21:09 --> URI Class Initialized
INFO - 2021-04-22 18:21:09 --> Output Class Initialized
INFO - 2021-04-22 18:21:09 --> Output Class Initialized
INFO - 2021-04-22 18:21:09 --> Router Class Initialized
INFO - 2021-04-22 18:21:09 --> Security Class Initialized
INFO - 2021-04-22 18:21:09 --> Security Class Initialized
INFO - 2021-04-22 18:21:09 --> Output Class Initialized
DEBUG - 2021-04-22 18:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-22 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:09 --> Input Class Initialized
INFO - 2021-04-22 18:21:09 --> Input Class Initialized
INFO - 2021-04-22 18:21:09 --> Language Class Initialized
INFO - 2021-04-22 18:21:09 --> Language Class Initialized
INFO - 2021-04-22 18:21:09 --> Security Class Initialized
ERROR - 2021-04-22 18:21:09 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:09 --> Input Class Initialized
ERROR - 2021-04-22 18:21:09 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:21:09 --> Language Class Initialized
ERROR - 2021-04-22 18:21:09 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:09 --> Config Class Initialized
INFO - 2021-04-22 18:21:09 --> Hooks Class Initialized
INFO - 2021-04-22 18:21:09 --> Config Class Initialized
INFO - 2021-04-22 18:21:09 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:09 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:09 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:21:09 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:09 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:09 --> URI Class Initialized
INFO - 2021-04-22 18:21:09 --> URI Class Initialized
INFO - 2021-04-22 18:21:09 --> Router Class Initialized
INFO - 2021-04-22 18:21:09 --> Router Class Initialized
INFO - 2021-04-22 18:21:09 --> Output Class Initialized
INFO - 2021-04-22 18:21:09 --> Output Class Initialized
INFO - 2021-04-22 18:21:09 --> Security Class Initialized
INFO - 2021-04-22 18:21:09 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:09 --> Input Class Initialized
DEBUG - 2021-04-22 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:09 --> Input Class Initialized
INFO - 2021-04-22 18:21:09 --> Language Class Initialized
INFO - 2021-04-22 18:21:09 --> Language Class Initialized
ERROR - 2021-04-22 18:21:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:21:09 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:10 --> Config Class Initialized
INFO - 2021-04-22 18:21:10 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:10 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:10 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:10 --> URI Class Initialized
INFO - 2021-04-22 18:21:10 --> Router Class Initialized
INFO - 2021-04-22 18:21:10 --> Output Class Initialized
INFO - 2021-04-22 18:21:10 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:10 --> Input Class Initialized
INFO - 2021-04-22 18:21:10 --> Language Class Initialized
ERROR - 2021-04-22 18:21:10 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:10 --> Config Class Initialized
INFO - 2021-04-22 18:21:10 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:10 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:10 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:10 --> URI Class Initialized
INFO - 2021-04-22 18:21:10 --> Router Class Initialized
INFO - 2021-04-22 18:21:10 --> Output Class Initialized
ERROR - 2021-04-22 18:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2021-04-22 18:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:10 --> Security Class Initialized
ERROR - 2021-04-22 18:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:10 --> Config Class Initialized
INFO - 2021-04-22 18:21:10 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:10 --> Input Class Initialized
INFO - 2021-04-22 18:21:10 --> Config Class Initialized
INFO - 2021-04-22 18:21:10 --> Hooks Class Initialized
INFO - 2021-04-22 18:21:10 --> Config Class Initialized
INFO - 2021-04-22 18:21:10 --> Language Class Initialized
INFO - 2021-04-22 18:21:10 --> Hooks Class Initialized
ERROR - 2021-04-22 18:21:10 --> 404 Page Not Found: Karoclient/js
DEBUG - 2021-04-22 18:21:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-22 18:21:10 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:10 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:10 --> Utf8 Class Initialized
DEBUG - 2021-04-22 18:21:10 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:10 --> URI Class Initialized
INFO - 2021-04-22 18:21:10 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:10 --> URI Class Initialized
INFO - 2021-04-22 18:21:10 --> URI Class Initialized
INFO - 2021-04-22 18:21:10 --> Router Class Initialized
INFO - 2021-04-22 18:21:10 --> Router Class Initialized
INFO - 2021-04-22 18:21:10 --> Router Class Initialized
INFO - 2021-04-22 18:21:10 --> Output Class Initialized
INFO - 2021-04-22 18:21:10 --> Output Class Initialized
INFO - 2021-04-22 18:21:10 --> Security Class Initialized
INFO - 2021-04-22 18:21:10 --> Output Class Initialized
INFO - 2021-04-22 18:21:10 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:10 --> Input Class Initialized
INFO - 2021-04-22 18:21:10 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:10 --> Language Class Initialized
DEBUG - 2021-04-22 18:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-22 18:21:10 --> 404 Page Not Found: Karoclient/js
INFO - 2021-04-22 18:21:10 --> Input Class Initialized
INFO - 2021-04-22 18:21:10 --> Language Class Initialized
INFO - 2021-04-22 18:21:10 --> Input Class Initialized
INFO - 2021-04-22 18:21:10 --> Language Class Initialized
ERROR - 2021-04-22 18:21:10 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:10 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:10 --> Config Class Initialized
INFO - 2021-04-22 18:21:10 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:10 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:10 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:10 --> URI Class Initialized
INFO - 2021-04-22 18:21:10 --> Router Class Initialized
INFO - 2021-04-22 18:21:10 --> Output Class Initialized
INFO - 2021-04-22 18:21:10 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:10 --> Input Class Initialized
INFO - 2021-04-22 18:21:10 --> Language Class Initialized
ERROR - 2021-04-22 18:21:10 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:11 --> Config Class Initialized
INFO - 2021-04-22 18:21:11 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:11 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:11 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:11 --> URI Class Initialized
INFO - 2021-04-22 18:21:11 --> Router Class Initialized
INFO - 2021-04-22 18:21:11 --> Output Class Initialized
INFO - 2021-04-22 18:21:11 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:11 --> Input Class Initialized
INFO - 2021-04-22 18:21:11 --> Language Class Initialized
ERROR - 2021-04-22 18:21:11 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:13 --> Config Class Initialized
INFO - 2021-04-22 18:21:13 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:13 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:13 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:13 --> URI Class Initialized
INFO - 2021-04-22 18:21:13 --> Router Class Initialized
INFO - 2021-04-22 18:21:13 --> Output Class Initialized
INFO - 2021-04-22 18:21:13 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:13 --> Input Class Initialized
INFO - 2021-04-22 18:21:13 --> Language Class Initialized
ERROR - 2021-04-22 18:21:13 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:13 --> Config Class Initialized
INFO - 2021-04-22 18:21:13 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:13 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:13 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:13 --> URI Class Initialized
INFO - 2021-04-22 18:21:13 --> Router Class Initialized
INFO - 2021-04-22 18:21:13 --> Output Class Initialized
INFO - 2021-04-22 18:21:13 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:13 --> Input Class Initialized
INFO - 2021-04-22 18:21:13 --> Language Class Initialized
ERROR - 2021-04-22 18:21:13 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:13 --> Config Class Initialized
INFO - 2021-04-22 18:21:13 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:13 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:13 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:13 --> URI Class Initialized
INFO - 2021-04-22 18:21:13 --> Router Class Initialized
INFO - 2021-04-22 18:21:13 --> Output Class Initialized
INFO - 2021-04-22 18:21:13 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:13 --> Input Class Initialized
INFO - 2021-04-22 18:21:13 --> Language Class Initialized
ERROR - 2021-04-22 18:21:13 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:13 --> Config Class Initialized
INFO - 2021-04-22 18:21:13 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:13 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:13 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:13 --> URI Class Initialized
INFO - 2021-04-22 18:21:13 --> Router Class Initialized
INFO - 2021-04-22 18:21:13 --> Output Class Initialized
INFO - 2021-04-22 18:21:13 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:13 --> Input Class Initialized
INFO - 2021-04-22 18:21:13 --> Language Class Initialized
ERROR - 2021-04-22 18:21:13 --> 404 Page Not Found: Karoclient/js
ERROR - 2021-04-22 18:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:14 --> Config Class Initialized
INFO - 2021-04-22 18:21:14 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:14 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:14 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:14 --> URI Class Initialized
INFO - 2021-04-22 18:21:14 --> Router Class Initialized
INFO - 2021-04-22 18:21:14 --> Output Class Initialized
INFO - 2021-04-22 18:21:14 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:14 --> Input Class Initialized
INFO - 2021-04-22 18:21:14 --> Language Class Initialized
ERROR - 2021-04-22 18:21:14 --> 404 Page Not Found: Karoclient/images
ERROR - 2021-04-22 18:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:25 --> Config Class Initialized
INFO - 2021-04-22 18:21:25 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:25 --> URI Class Initialized
INFO - 2021-04-22 18:21:25 --> Router Class Initialized
INFO - 2021-04-22 18:21:25 --> Output Class Initialized
INFO - 2021-04-22 18:21:25 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:25 --> Input Class Initialized
INFO - 2021-04-22 18:21:25 --> Language Class Initialized
INFO - 2021-04-22 18:21:25 --> Loader Class Initialized
INFO - 2021-04-22 18:21:25 --> Helper loaded: url_helper
INFO - 2021-04-22 18:21:25 --> Helper loaded: form_helper
INFO - 2021-04-22 18:21:25 --> Helper loaded: common_helper
INFO - 2021-04-22 18:21:25 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:21:25 --> Controller Class Initialized
INFO - 2021-04-22 18:21:25 --> Form Validation Class Initialized
INFO - 2021-04-22 18:21:25 --> Encrypt Class Initialized
INFO - 2021-04-22 18:21:25 --> Model "Diseases_model" initialized
INFO - 2021-04-22 18:21:25 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:21:25 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
INFO - 2021-04-22 18:21:25 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:21:25 --> Final output sent to browser
DEBUG - 2021-04-22 18:21:25 --> Total execution time: 0.0940
ERROR - 2021-04-22 18:21:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:56 --> Config Class Initialized
INFO - 2021-04-22 18:21:56 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:56 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:56 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:56 --> URI Class Initialized
INFO - 2021-04-22 18:21:56 --> Router Class Initialized
INFO - 2021-04-22 18:21:56 --> Output Class Initialized
INFO - 2021-04-22 18:21:56 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:57 --> Input Class Initialized
INFO - 2021-04-22 18:21:57 --> Language Class Initialized
INFO - 2021-04-22 18:21:57 --> Loader Class Initialized
INFO - 2021-04-22 18:21:57 --> Helper loaded: url_helper
INFO - 2021-04-22 18:21:57 --> Helper loaded: form_helper
INFO - 2021-04-22 18:21:57 --> Helper loaded: common_helper
INFO - 2021-04-22 18:21:57 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:21:57 --> Controller Class Initialized
INFO - 2021-04-22 18:21:57 --> Form Validation Class Initialized
INFO - 2021-04-22 18:21:57 --> Encrypt Class Initialized
INFO - 2021-04-22 18:21:57 --> Model "Diseases_model" initialized
INFO - 2021-04-22 18:21:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:21:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\diseases/index.php
INFO - 2021-04-22 18:21:57 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:21:57 --> Final output sent to browser
DEBUG - 2021-04-22 18:21:57 --> Total execution time: 0.1340
ERROR - 2021-04-22 18:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:21:58 --> Config Class Initialized
INFO - 2021-04-22 18:21:58 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:21:58 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:21:58 --> Utf8 Class Initialized
INFO - 2021-04-22 18:21:58 --> URI Class Initialized
INFO - 2021-04-22 18:21:58 --> Router Class Initialized
INFO - 2021-04-22 18:21:58 --> Output Class Initialized
INFO - 2021-04-22 18:21:58 --> Security Class Initialized
DEBUG - 2021-04-22 18:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:21:58 --> Input Class Initialized
INFO - 2021-04-22 18:21:58 --> Language Class Initialized
ERROR - 2021-04-22 18:21:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:22:07 --> Config Class Initialized
INFO - 2021-04-22 18:22:07 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:22:07 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:22:07 --> Utf8 Class Initialized
INFO - 2021-04-22 18:22:07 --> URI Class Initialized
INFO - 2021-04-22 18:22:07 --> Router Class Initialized
INFO - 2021-04-22 18:22:07 --> Output Class Initialized
INFO - 2021-04-22 18:22:07 --> Security Class Initialized
DEBUG - 2021-04-22 18:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:22:07 --> Input Class Initialized
INFO - 2021-04-22 18:22:07 --> Language Class Initialized
INFO - 2021-04-22 18:22:07 --> Loader Class Initialized
INFO - 2021-04-22 18:22:07 --> Helper loaded: url_helper
INFO - 2021-04-22 18:22:07 --> Helper loaded: form_helper
INFO - 2021-04-22 18:22:07 --> Helper loaded: common_helper
INFO - 2021-04-22 18:22:07 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:22:07 --> Controller Class Initialized
INFO - 2021-04-22 18:22:07 --> Form Validation Class Initialized
INFO - 2021-04-22 18:22:07 --> Encrypt Class Initialized
INFO - 2021-04-22 18:22:07 --> Model "Login_model" initialized
INFO - 2021-04-22 18:22:07 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:22:07 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:22:07 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:22:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:24:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:24:58 --> Config Class Initialized
INFO - 2021-04-22 18:24:58 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:24:58 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:24:58 --> Utf8 Class Initialized
INFO - 2021-04-22 18:24:58 --> URI Class Initialized
INFO - 2021-04-22 18:24:58 --> Router Class Initialized
INFO - 2021-04-22 18:24:58 --> Output Class Initialized
INFO - 2021-04-22 18:24:58 --> Security Class Initialized
DEBUG - 2021-04-22 18:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:24:58 --> Input Class Initialized
INFO - 2021-04-22 18:24:58 --> Language Class Initialized
INFO - 2021-04-22 18:24:58 --> Loader Class Initialized
INFO - 2021-04-22 18:24:58 --> Helper loaded: url_helper
INFO - 2021-04-22 18:24:58 --> Helper loaded: form_helper
INFO - 2021-04-22 18:24:58 --> Helper loaded: common_helper
INFO - 2021-04-22 18:24:58 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:24:58 --> Controller Class Initialized
INFO - 2021-04-22 18:24:58 --> Form Validation Class Initialized
INFO - 2021-04-22 18:24:58 --> Encrypt Class Initialized
INFO - 2021-04-22 18:24:58 --> Model "Login_model" initialized
INFO - 2021-04-22 18:24:58 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:24:58 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:24:58 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:24:58 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:26:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:26:43 --> Config Class Initialized
INFO - 2021-04-22 18:26:43 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:26:43 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:26:43 --> Utf8 Class Initialized
INFO - 2021-04-22 18:26:43 --> URI Class Initialized
INFO - 2021-04-22 18:26:43 --> Router Class Initialized
INFO - 2021-04-22 18:26:43 --> Output Class Initialized
INFO - 2021-04-22 18:26:43 --> Security Class Initialized
DEBUG - 2021-04-22 18:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:26:43 --> Input Class Initialized
INFO - 2021-04-22 18:26:43 --> Language Class Initialized
INFO - 2021-04-22 18:26:43 --> Loader Class Initialized
INFO - 2021-04-22 18:26:43 --> Helper loaded: url_helper
INFO - 2021-04-22 18:26:43 --> Helper loaded: form_helper
INFO - 2021-04-22 18:26:43 --> Helper loaded: common_helper
INFO - 2021-04-22 18:26:43 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:26:43 --> Controller Class Initialized
INFO - 2021-04-22 18:26:44 --> Form Validation Class Initialized
INFO - 2021-04-22 18:26:44 --> Encrypt Class Initialized
INFO - 2021-04-22 18:26:44 --> Model "Login_model" initialized
INFO - 2021-04-22 18:26:44 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:26:44 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:26:44 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:26:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:26:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:26:48 --> Config Class Initialized
INFO - 2021-04-22 18:26:48 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:26:48 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:26:48 --> Utf8 Class Initialized
INFO - 2021-04-22 18:26:48 --> URI Class Initialized
INFO - 2021-04-22 18:26:48 --> Router Class Initialized
INFO - 2021-04-22 18:26:48 --> Output Class Initialized
INFO - 2021-04-22 18:26:48 --> Security Class Initialized
DEBUG - 2021-04-22 18:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:26:48 --> Input Class Initialized
INFO - 2021-04-22 18:26:48 --> Language Class Initialized
INFO - 2021-04-22 18:26:48 --> Loader Class Initialized
INFO - 2021-04-22 18:26:48 --> Helper loaded: url_helper
INFO - 2021-04-22 18:26:48 --> Helper loaded: form_helper
INFO - 2021-04-22 18:26:48 --> Helper loaded: common_helper
INFO - 2021-04-22 18:26:48 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:26:48 --> Controller Class Initialized
INFO - 2021-04-22 18:26:48 --> Form Validation Class Initialized
INFO - 2021-04-22 18:26:48 --> Encrypt Class Initialized
INFO - 2021-04-22 18:26:48 --> Model "Login_model" initialized
INFO - 2021-04-22 18:26:48 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:26:48 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:26:48 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:26:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:31:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:31:19 --> Config Class Initialized
INFO - 2021-04-22 18:31:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:31:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:31:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:31:19 --> URI Class Initialized
INFO - 2021-04-22 18:31:19 --> Router Class Initialized
INFO - 2021-04-22 18:31:19 --> Output Class Initialized
INFO - 2021-04-22 18:31:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:31:19 --> Input Class Initialized
INFO - 2021-04-22 18:31:19 --> Language Class Initialized
INFO - 2021-04-22 18:31:19 --> Loader Class Initialized
INFO - 2021-04-22 18:31:19 --> Helper loaded: url_helper
INFO - 2021-04-22 18:31:19 --> Helper loaded: form_helper
INFO - 2021-04-22 18:31:19 --> Helper loaded: common_helper
INFO - 2021-04-22 18:31:19 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:31:19 --> Controller Class Initialized
INFO - 2021-04-22 18:31:19 --> Form Validation Class Initialized
INFO - 2021-04-22 18:31:19 --> Encrypt Class Initialized
INFO - 2021-04-22 18:31:19 --> Model "Login_model" initialized
INFO - 2021-04-22 18:31:19 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:31:19 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:31:19 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:31:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:32:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:32:33 --> Config Class Initialized
INFO - 2021-04-22 18:32:33 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:32:33 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:32:33 --> Utf8 Class Initialized
INFO - 2021-04-22 18:32:33 --> URI Class Initialized
INFO - 2021-04-22 18:32:33 --> Router Class Initialized
INFO - 2021-04-22 18:32:33 --> Output Class Initialized
INFO - 2021-04-22 18:32:33 --> Security Class Initialized
DEBUG - 2021-04-22 18:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:32:33 --> Input Class Initialized
INFO - 2021-04-22 18:32:33 --> Language Class Initialized
INFO - 2021-04-22 18:32:33 --> Loader Class Initialized
INFO - 2021-04-22 18:32:33 --> Helper loaded: url_helper
INFO - 2021-04-22 18:32:33 --> Helper loaded: form_helper
INFO - 2021-04-22 18:32:33 --> Helper loaded: common_helper
INFO - 2021-04-22 18:32:33 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:32:33 --> Controller Class Initialized
INFO - 2021-04-22 18:32:33 --> Form Validation Class Initialized
INFO - 2021-04-22 18:32:33 --> Encrypt Class Initialized
INFO - 2021-04-22 18:32:33 --> Model "Login_model" initialized
INFO - 2021-04-22 18:32:33 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:32:33 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:32:34 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:32:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:33:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:33:02 --> Config Class Initialized
INFO - 2021-04-22 18:33:02 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:33:02 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:33:02 --> Utf8 Class Initialized
INFO - 2021-04-22 18:33:02 --> URI Class Initialized
INFO - 2021-04-22 18:33:02 --> Router Class Initialized
INFO - 2021-04-22 18:33:02 --> Output Class Initialized
INFO - 2021-04-22 18:33:02 --> Security Class Initialized
DEBUG - 2021-04-22 18:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:33:02 --> Input Class Initialized
INFO - 2021-04-22 18:33:02 --> Language Class Initialized
INFO - 2021-04-22 18:33:02 --> Loader Class Initialized
INFO - 2021-04-22 18:33:02 --> Helper loaded: url_helper
INFO - 2021-04-22 18:33:02 --> Helper loaded: form_helper
INFO - 2021-04-22 18:33:02 --> Helper loaded: common_helper
INFO - 2021-04-22 18:33:02 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:33:02 --> Controller Class Initialized
INFO - 2021-04-22 18:33:02 --> Form Validation Class Initialized
INFO - 2021-04-22 18:33:02 --> Encrypt Class Initialized
INFO - 2021-04-22 18:33:02 --> Model "Login_model" initialized
INFO - 2021-04-22 18:33:02 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:33:02 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:33:02 --> Query error: The user specified as a definer ('karodbu'@'14.140.202.214') does not exist - Invalid query: SELECT SUM(TotalPatient) as TotalPatient ,AgeGroup
FROM
( 
SELECT CALCULATEAGE(YEAR(patient_dob)) AS AgeGroup, COUNT(CALCULATEAGE(YEAR(patient_dob)))  AS TotalPatient FROM patient_master
       
    WHERE  IFNULL(`status`,0)!= '1' AND patient_dob IS NOT NULL AND patient_dob != '0000-00-00' 
     GROUP BY  CALCULATEAGE(YEAR(patient_dob))
     
     UNION 
     
  SELECT calculateWithoutDOBAge(SUBSTRING(patient_age,1,2)) AS AgeGroup, COUNT(calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))) AS 
  TotalPatient FROM patient_master WHERE IFNULL(`status`,0)!= '1' AND IFNULL(patient_dob,'')='0000-00-00'  AND IFNULL(patient_age,'')!='' 
        GROUP BY calculateWithoutDOBAge(SUBSTRING(patient_age,1,2))
        )B GROUP BY AgeGroup
INFO - 2021-04-22 18:33:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-04-22 18:33:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:33:40 --> Config Class Initialized
INFO - 2021-04-22 18:33:40 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:33:40 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:33:40 --> Utf8 Class Initialized
INFO - 2021-04-22 18:33:40 --> URI Class Initialized
INFO - 2021-04-22 18:33:40 --> Router Class Initialized
INFO - 2021-04-22 18:33:40 --> Output Class Initialized
INFO - 2021-04-22 18:33:40 --> Security Class Initialized
DEBUG - 2021-04-22 18:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:33:40 --> Input Class Initialized
INFO - 2021-04-22 18:33:40 --> Language Class Initialized
INFO - 2021-04-22 18:33:40 --> Loader Class Initialized
INFO - 2021-04-22 18:33:40 --> Helper loaded: url_helper
INFO - 2021-04-22 18:33:40 --> Helper loaded: form_helper
INFO - 2021-04-22 18:33:40 --> Helper loaded: common_helper
INFO - 2021-04-22 18:33:40 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:33:40 --> Controller Class Initialized
INFO - 2021-04-22 18:33:40 --> Form Validation Class Initialized
INFO - 2021-04-22 18:33:40 --> Encrypt Class Initialized
INFO - 2021-04-22 18:33:40 --> Model "Login_model" initialized
INFO - 2021-04-22 18:33:40 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:33:40 --> Model "Case_model" initialized
INFO - 2021-04-22 18:33:49 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:34:06 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-04-22 18:34:06 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:34:06 --> Final output sent to browser
DEBUG - 2021-04-22 18:34:06 --> Total execution time: 26.1469
ERROR - 2021-04-22 18:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:08 --> Config Class Initialized
INFO - 2021-04-22 18:34:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:08 --> URI Class Initialized
INFO - 2021-04-22 18:34:08 --> Router Class Initialized
INFO - 2021-04-22 18:34:08 --> Output Class Initialized
INFO - 2021-04-22 18:34:08 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:08 --> Input Class Initialized
INFO - 2021-04-22 18:34:08 --> Language Class Initialized
ERROR - 2021-04-22 18:34:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:26 --> Config Class Initialized
INFO - 2021-04-22 18:34:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:26 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:26 --> URI Class Initialized
INFO - 2021-04-22 18:34:26 --> Router Class Initialized
INFO - 2021-04-22 18:34:26 --> Output Class Initialized
INFO - 2021-04-22 18:34:26 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:26 --> Input Class Initialized
INFO - 2021-04-22 18:34:26 --> Language Class Initialized
INFO - 2021-04-22 18:34:26 --> Loader Class Initialized
INFO - 2021-04-22 18:34:26 --> Helper loaded: url_helper
INFO - 2021-04-22 18:34:26 --> Helper loaded: form_helper
INFO - 2021-04-22 18:34:26 --> Helper loaded: common_helper
INFO - 2021-04-22 18:34:26 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:34:26 --> Controller Class Initialized
INFO - 2021-04-22 18:34:26 --> Form Validation Class Initialized
INFO - 2021-04-22 18:34:26 --> Encrypt Class Initialized
INFO - 2021-04-22 18:34:26 --> Model "Payment_model" initialized
INFO - 2021-04-22 18:34:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:34:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\payment/index.php
INFO - 2021-04-22 18:34:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:34:26 --> Final output sent to browser
DEBUG - 2021-04-22 18:34:26 --> Total execution time: 0.2109
ERROR - 2021-04-22 18:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:26 --> Config Class Initialized
INFO - 2021-04-22 18:34:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:26 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:26 --> URI Class Initialized
INFO - 2021-04-22 18:34:26 --> Router Class Initialized
INFO - 2021-04-22 18:34:26 --> Output Class Initialized
INFO - 2021-04-22 18:34:26 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:26 --> Input Class Initialized
INFO - 2021-04-22 18:34:26 --> Language Class Initialized
ERROR - 2021-04-22 18:34:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:34:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:35 --> Config Class Initialized
INFO - 2021-04-22 18:34:35 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:35 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:35 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:35 --> URI Class Initialized
INFO - 2021-04-22 18:34:35 --> Router Class Initialized
INFO - 2021-04-22 18:34:35 --> Output Class Initialized
INFO - 2021-04-22 18:34:35 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:35 --> Input Class Initialized
INFO - 2021-04-22 18:34:35 --> Language Class Initialized
INFO - 2021-04-22 18:34:35 --> Loader Class Initialized
INFO - 2021-04-22 18:34:35 --> Helper loaded: url_helper
INFO - 2021-04-22 18:34:35 --> Helper loaded: form_helper
INFO - 2021-04-22 18:34:35 --> Helper loaded: common_helper
INFO - 2021-04-22 18:34:35 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:34:35 --> Controller Class Initialized
INFO - 2021-04-22 18:34:35 --> Form Validation Class Initialized
INFO - 2021-04-22 18:34:35 --> Encrypt Class Initialized
INFO - 2021-04-22 18:34:35 --> Model "Payment_model" initialized
INFO - 2021-04-22 18:34:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:34:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\payment/index.php
INFO - 2021-04-22 18:34:35 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:34:35 --> Final output sent to browser
DEBUG - 2021-04-22 18:34:35 --> Total execution time: 0.0663
ERROR - 2021-04-22 18:34:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:35 --> Config Class Initialized
INFO - 2021-04-22 18:34:35 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:35 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:35 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:35 --> URI Class Initialized
INFO - 2021-04-22 18:34:35 --> Router Class Initialized
INFO - 2021-04-22 18:34:35 --> Output Class Initialized
INFO - 2021-04-22 18:34:35 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:35 --> Input Class Initialized
INFO - 2021-04-22 18:34:35 --> Language Class Initialized
ERROR - 2021-04-22 18:34:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:45 --> Config Class Initialized
INFO - 2021-04-22 18:34:45 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:45 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:45 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:45 --> URI Class Initialized
INFO - 2021-04-22 18:34:45 --> Router Class Initialized
INFO - 2021-04-22 18:34:45 --> Output Class Initialized
INFO - 2021-04-22 18:34:45 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:45 --> Input Class Initialized
INFO - 2021-04-22 18:34:45 --> Language Class Initialized
INFO - 2021-04-22 18:34:45 --> Loader Class Initialized
INFO - 2021-04-22 18:34:45 --> Helper loaded: url_helper
INFO - 2021-04-22 18:34:45 --> Helper loaded: form_helper
INFO - 2021-04-22 18:34:45 --> Helper loaded: common_helper
INFO - 2021-04-22 18:34:45 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:34:45 --> Controller Class Initialized
INFO - 2021-04-22 18:34:45 --> Form Validation Class Initialized
INFO - 2021-04-22 18:34:45 --> Encrypt Class Initialized
INFO - 2021-04-22 18:34:45 --> Model "Payment_model" initialized
ERROR - 2021-04-22 18:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:45 --> Config Class Initialized
INFO - 2021-04-22 18:34:45 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:45 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:45 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:45 --> URI Class Initialized
INFO - 2021-04-22 18:34:45 --> Router Class Initialized
INFO - 2021-04-22 18:34:45 --> Output Class Initialized
INFO - 2021-04-22 18:34:45 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:45 --> Input Class Initialized
INFO - 2021-04-22 18:34:45 --> Language Class Initialized
INFO - 2021-04-22 18:34:45 --> Loader Class Initialized
INFO - 2021-04-22 18:34:45 --> Helper loaded: url_helper
INFO - 2021-04-22 18:34:45 --> Helper loaded: form_helper
INFO - 2021-04-22 18:34:45 --> Helper loaded: common_helper
INFO - 2021-04-22 18:34:45 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:34:45 --> Controller Class Initialized
INFO - 2021-04-22 18:34:45 --> Form Validation Class Initialized
INFO - 2021-04-22 18:34:45 --> Encrypt Class Initialized
INFO - 2021-04-22 18:34:45 --> Model "Payment_model" initialized
INFO - 2021-04-22 18:34:45 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:34:45 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\payment/index.php
INFO - 2021-04-22 18:34:45 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:34:45 --> Final output sent to browser
DEBUG - 2021-04-22 18:34:45 --> Total execution time: 0.2873
ERROR - 2021-04-22 18:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:45 --> Config Class Initialized
INFO - 2021-04-22 18:34:45 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:45 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:45 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:45 --> URI Class Initialized
INFO - 2021-04-22 18:34:45 --> Router Class Initialized
INFO - 2021-04-22 18:34:45 --> Output Class Initialized
INFO - 2021-04-22 18:34:45 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:45 --> Input Class Initialized
INFO - 2021-04-22 18:34:45 --> Language Class Initialized
ERROR - 2021-04-22 18:34:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:34:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:58 --> Config Class Initialized
INFO - 2021-04-22 18:34:58 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:58 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:58 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:58 --> URI Class Initialized
INFO - 2021-04-22 18:34:58 --> Router Class Initialized
INFO - 2021-04-22 18:34:58 --> Output Class Initialized
INFO - 2021-04-22 18:34:58 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:58 --> Input Class Initialized
INFO - 2021-04-22 18:34:58 --> Language Class Initialized
INFO - 2021-04-22 18:34:58 --> Loader Class Initialized
INFO - 2021-04-22 18:34:58 --> Helper loaded: url_helper
INFO - 2021-04-22 18:34:58 --> Helper loaded: form_helper
INFO - 2021-04-22 18:34:58 --> Helper loaded: common_helper
INFO - 2021-04-22 18:34:58 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:34:58 --> Controller Class Initialized
INFO - 2021-04-22 18:34:58 --> Form Validation Class Initialized
INFO - 2021-04-22 18:34:58 --> Encrypt Class Initialized
INFO - 2021-04-22 18:34:58 --> Model "Referredby_model" initialized
INFO - 2021-04-22 18:34:58 --> Model "Users_model" initialized
INFO - 2021-04-22 18:34:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:34:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\users/index.php
INFO - 2021-04-22 18:34:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:34:58 --> Final output sent to browser
DEBUG - 2021-04-22 18:34:58 --> Total execution time: 0.2130
ERROR - 2021-04-22 18:34:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:34:59 --> Config Class Initialized
INFO - 2021-04-22 18:34:59 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:34:59 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:34:59 --> Utf8 Class Initialized
INFO - 2021-04-22 18:34:59 --> URI Class Initialized
INFO - 2021-04-22 18:34:59 --> Router Class Initialized
INFO - 2021-04-22 18:34:59 --> Output Class Initialized
INFO - 2021-04-22 18:34:59 --> Security Class Initialized
DEBUG - 2021-04-22 18:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:34:59 --> Input Class Initialized
INFO - 2021-04-22 18:34:59 --> Language Class Initialized
ERROR - 2021-04-22 18:34:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:35:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:08 --> Config Class Initialized
INFO - 2021-04-22 18:35:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:08 --> URI Class Initialized
INFO - 2021-04-22 18:35:08 --> Router Class Initialized
INFO - 2021-04-22 18:35:08 --> Output Class Initialized
INFO - 2021-04-22 18:35:08 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:08 --> Input Class Initialized
INFO - 2021-04-22 18:35:08 --> Language Class Initialized
INFO - 2021-04-22 18:35:08 --> Loader Class Initialized
INFO - 2021-04-22 18:35:08 --> Helper loaded: url_helper
ERROR - 2021-04-22 18:35:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:08 --> Helper loaded: form_helper
INFO - 2021-04-22 18:35:08 --> Helper loaded: common_helper
INFO - 2021-04-22 18:35:08 --> Config Class Initialized
INFO - 2021-04-22 18:35:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:08 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:08 --> URI Class Initialized
INFO - 2021-04-22 18:35:08 --> Database Driver Class Initialized
INFO - 2021-04-22 18:35:08 --> Router Class Initialized
INFO - 2021-04-22 18:35:08 --> Output Class Initialized
DEBUG - 2021-04-22 18:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:35:08 --> Security Class Initialized
INFO - 2021-04-22 18:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:35:08 --> Controller Class Initialized
DEBUG - 2021-04-22 18:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:08 --> Input Class Initialized
INFO - 2021-04-22 18:35:08 --> Language Class Initialized
INFO - 2021-04-22 18:35:08 --> Form Validation Class Initialized
INFO - 2021-04-22 18:35:08 --> Encrypt Class Initialized
INFO - 2021-04-22 18:35:08 --> Model "Referredby_model" initialized
INFO - 2021-04-22 18:35:08 --> Model "Users_model" initialized
INFO - 2021-04-22 18:35:08 --> Loader Class Initialized
INFO - 2021-04-22 18:35:08 --> Helper loaded: url_helper
INFO - 2021-04-22 18:35:08 --> Helper loaded: form_helper
INFO - 2021-04-22 18:35:08 --> Helper loaded: common_helper
INFO - 2021-04-22 18:35:08 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:35:08 --> Final output sent to browser
DEBUG - 2021-04-22 18:35:08 --> Total execution time: 0.1332
INFO - 2021-04-22 18:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:35:08 --> Controller Class Initialized
INFO - 2021-04-22 18:35:08 --> Form Validation Class Initialized
INFO - 2021-04-22 18:35:08 --> Encrypt Class Initialized
INFO - 2021-04-22 18:35:08 --> Model "Hospital_model" initialized
INFO - 2021-04-22 18:35:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:35:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\hospital/index.php
INFO - 2021-04-22 18:35:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:35:08 --> Final output sent to browser
DEBUG - 2021-04-22 18:35:08 --> Total execution time: 0.1092
ERROR - 2021-04-22 18:35:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:09 --> Config Class Initialized
INFO - 2021-04-22 18:35:09 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:09 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:09 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:09 --> URI Class Initialized
INFO - 2021-04-22 18:35:09 --> Router Class Initialized
INFO - 2021-04-22 18:35:09 --> Output Class Initialized
INFO - 2021-04-22 18:35:09 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:09 --> Input Class Initialized
INFO - 2021-04-22 18:35:09 --> Language Class Initialized
ERROR - 2021-04-22 18:35:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:14 --> Config Class Initialized
INFO - 2021-04-22 18:35:14 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:14 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:14 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:14 --> URI Class Initialized
INFO - 2021-04-22 18:35:14 --> Router Class Initialized
INFO - 2021-04-22 18:35:14 --> Output Class Initialized
INFO - 2021-04-22 18:35:14 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:14 --> Input Class Initialized
INFO - 2021-04-22 18:35:14 --> Language Class Initialized
INFO - 2021-04-22 18:35:14 --> Loader Class Initialized
INFO - 2021-04-22 18:35:14 --> Helper loaded: url_helper
INFO - 2021-04-22 18:35:14 --> Helper loaded: form_helper
INFO - 2021-04-22 18:35:14 --> Helper loaded: common_helper
INFO - 2021-04-22 18:35:14 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:35:14 --> Controller Class Initialized
INFO - 2021-04-22 18:35:14 --> Form Validation Class Initialized
INFO - 2021-04-22 18:35:14 --> Encrypt Class Initialized
INFO - 2021-04-22 18:35:14 --> Model "Referredby_model" initialized
INFO - 2021-04-22 18:35:14 --> Model "Donner_model" initialized
INFO - 2021-04-22 18:35:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:35:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\donner/index.php
INFO - 2021-04-22 18:35:14 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:35:14 --> Final output sent to browser
DEBUG - 2021-04-22 18:35:14 --> Total execution time: 0.2778
ERROR - 2021-04-22 18:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:14 --> Config Class Initialized
INFO - 2021-04-22 18:35:14 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:14 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:14 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:14 --> URI Class Initialized
INFO - 2021-04-22 18:35:14 --> Router Class Initialized
INFO - 2021-04-22 18:35:14 --> Output Class Initialized
INFO - 2021-04-22 18:35:14 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:14 --> Input Class Initialized
INFO - 2021-04-22 18:35:14 --> Language Class Initialized
ERROR - 2021-04-22 18:35:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:35:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:19 --> Config Class Initialized
INFO - 2021-04-22 18:35:19 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:19 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:19 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:19 --> URI Class Initialized
INFO - 2021-04-22 18:35:19 --> Router Class Initialized
INFO - 2021-04-22 18:35:19 --> Output Class Initialized
INFO - 2021-04-22 18:35:19 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:20 --> Input Class Initialized
INFO - 2021-04-22 18:35:20 --> Language Class Initialized
INFO - 2021-04-22 18:35:20 --> Loader Class Initialized
INFO - 2021-04-22 18:35:20 --> Helper loaded: url_helper
INFO - 2021-04-22 18:35:20 --> Helper loaded: form_helper
INFO - 2021-04-22 18:35:20 --> Helper loaded: common_helper
INFO - 2021-04-22 18:35:20 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:35:20 --> Controller Class Initialized
INFO - 2021-04-22 18:35:20 --> Form Validation Class Initialized
INFO - 2021-04-22 18:35:20 --> Encrypt Class Initialized
INFO - 2021-04-22 18:35:20 --> Model "Hospital_model" initialized
INFO - 2021-04-22 18:35:20 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:35:20 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\hospital/depart.php
INFO - 2021-04-22 18:35:20 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:35:20 --> Final output sent to browser
DEBUG - 2021-04-22 18:35:20 --> Total execution time: 0.1941
ERROR - 2021-04-22 18:35:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:20 --> Config Class Initialized
INFO - 2021-04-22 18:35:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:20 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:20 --> URI Class Initialized
INFO - 2021-04-22 18:35:20 --> Router Class Initialized
INFO - 2021-04-22 18:35:20 --> Output Class Initialized
INFO - 2021-04-22 18:35:20 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:20 --> Input Class Initialized
INFO - 2021-04-22 18:35:20 --> Language Class Initialized
ERROR - 2021-04-22 18:35:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:26 --> Config Class Initialized
INFO - 2021-04-22 18:35:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:26 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:26 --> URI Class Initialized
INFO - 2021-04-22 18:35:26 --> Router Class Initialized
INFO - 2021-04-22 18:35:26 --> Output Class Initialized
INFO - 2021-04-22 18:35:26 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:26 --> Input Class Initialized
INFO - 2021-04-22 18:35:26 --> Language Class Initialized
INFO - 2021-04-22 18:35:26 --> Loader Class Initialized
INFO - 2021-04-22 18:35:26 --> Helper loaded: url_helper
INFO - 2021-04-22 18:35:26 --> Helper loaded: form_helper
INFO - 2021-04-22 18:35:26 --> Helper loaded: common_helper
INFO - 2021-04-22 18:35:26 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:35:26 --> Controller Class Initialized
INFO - 2021-04-22 18:35:26 --> Form Validation Class Initialized
INFO - 2021-04-22 18:35:26 --> Encrypt Class Initialized
INFO - 2021-04-22 18:35:26 --> Model "Patient_model" initialized
INFO - 2021-04-22 18:35:26 --> Model "Patientcase_model" initialized
INFO - 2021-04-22 18:35:26 --> Model "Referredby_model" initialized
INFO - 2021-04-22 18:35:26 --> Model "Prefix_master" initialized
INFO - 2021-04-22 18:35:26 --> Model "Hospital_model" initialized
INFO - 2021-04-22 18:35:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:35:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patient/index.php
INFO - 2021-04-22 18:35:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:35:26 --> Final output sent to browser
DEBUG - 2021-04-22 18:35:26 --> Total execution time: 0.2471
ERROR - 2021-04-22 18:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:26 --> Config Class Initialized
INFO - 2021-04-22 18:35:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:26 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:26 --> URI Class Initialized
INFO - 2021-04-22 18:35:26 --> Router Class Initialized
INFO - 2021-04-22 18:35:27 --> Output Class Initialized
INFO - 2021-04-22 18:35:27 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:27 --> Input Class Initialized
INFO - 2021-04-22 18:35:27 --> Language Class Initialized
ERROR - 2021-04-22 18:35:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:35:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:32 --> Config Class Initialized
INFO - 2021-04-22 18:35:32 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:32 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:32 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:32 --> URI Class Initialized
INFO - 2021-04-22 18:35:32 --> Router Class Initialized
INFO - 2021-04-22 18:35:32 --> Output Class Initialized
INFO - 2021-04-22 18:35:32 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:32 --> Input Class Initialized
INFO - 2021-04-22 18:35:32 --> Language Class Initialized
INFO - 2021-04-22 18:35:32 --> Loader Class Initialized
INFO - 2021-04-22 18:35:32 --> Helper loaded: url_helper
INFO - 2021-04-22 18:35:32 --> Helper loaded: form_helper
INFO - 2021-04-22 18:35:32 --> Helper loaded: common_helper
INFO - 2021-04-22 18:35:32 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:35:32 --> Controller Class Initialized
INFO - 2021-04-22 18:35:32 --> Form Validation Class Initialized
INFO - 2021-04-22 18:35:32 --> Encrypt Class Initialized
INFO - 2021-04-22 18:35:32 --> Model "Patient_model" initialized
INFO - 2021-04-22 18:35:32 --> Model "Patientcase_model" initialized
INFO - 2021-04-22 18:35:32 --> Model "Referredby_model" initialized
INFO - 2021-04-22 18:35:32 --> Model "Prefix_master" initialized
INFO - 2021-04-22 18:35:32 --> Model "Hospital_model" initialized
INFO - 2021-04-22 18:35:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:35:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patient/patientview.php
INFO - 2021-04-22 18:35:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:35:43 --> Final output sent to browser
DEBUG - 2021-04-22 18:35:43 --> Total execution time: 10.7593
ERROR - 2021-04-22 18:35:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:35:43 --> Config Class Initialized
INFO - 2021-04-22 18:35:43 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:35:43 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:35:43 --> Utf8 Class Initialized
INFO - 2021-04-22 18:35:43 --> URI Class Initialized
INFO - 2021-04-22 18:35:43 --> Router Class Initialized
INFO - 2021-04-22 18:35:43 --> Output Class Initialized
INFO - 2021-04-22 18:35:43 --> Security Class Initialized
DEBUG - 2021-04-22 18:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:35:43 --> Input Class Initialized
INFO - 2021-04-22 18:35:43 --> Language Class Initialized
ERROR - 2021-04-22 18:35:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:36:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:36:24 --> Config Class Initialized
INFO - 2021-04-22 18:36:24 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:36:25 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:36:25 --> Utf8 Class Initialized
INFO - 2021-04-22 18:36:25 --> URI Class Initialized
INFO - 2021-04-22 18:36:25 --> Router Class Initialized
INFO - 2021-04-22 18:36:25 --> Output Class Initialized
INFO - 2021-04-22 18:36:25 --> Security Class Initialized
DEBUG - 2021-04-22 18:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:36:25 --> Input Class Initialized
INFO - 2021-04-22 18:36:25 --> Language Class Initialized
INFO - 2021-04-22 18:36:25 --> Loader Class Initialized
INFO - 2021-04-22 18:36:25 --> Helper loaded: url_helper
INFO - 2021-04-22 18:36:25 --> Helper loaded: form_helper
INFO - 2021-04-22 18:36:25 --> Helper loaded: common_helper
INFO - 2021-04-22 18:36:25 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:36:25 --> Controller Class Initialized
INFO - 2021-04-22 18:36:25 --> Form Validation Class Initialized
INFO - 2021-04-22 18:36:25 --> Model "Case_model" initialized
INFO - 2021-04-22 18:36:25 --> Model "Patientcase_model" initialized
INFO - 2021-04-22 18:36:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:36:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/new_case.php
INFO - 2021-04-22 18:36:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:36:26 --> Final output sent to browser
DEBUG - 2021-04-22 18:36:26 --> Total execution time: 1.6053
ERROR - 2021-04-22 18:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:36:26 --> Config Class Initialized
INFO - 2021-04-22 18:36:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:36:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:36:26 --> Utf8 Class Initialized
INFO - 2021-04-22 18:36:26 --> URI Class Initialized
INFO - 2021-04-22 18:36:26 --> Router Class Initialized
INFO - 2021-04-22 18:36:26 --> Output Class Initialized
INFO - 2021-04-22 18:36:26 --> Security Class Initialized
DEBUG - 2021-04-22 18:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:36:26 --> Input Class Initialized
INFO - 2021-04-22 18:36:26 --> Language Class Initialized
ERROR - 2021-04-22 18:36:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:36:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:36:40 --> Config Class Initialized
INFO - 2021-04-22 18:36:40 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:36:40 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:36:40 --> Utf8 Class Initialized
INFO - 2021-04-22 18:36:40 --> URI Class Initialized
INFO - 2021-04-22 18:36:40 --> Router Class Initialized
INFO - 2021-04-22 18:36:40 --> Output Class Initialized
INFO - 2021-04-22 18:36:40 --> Security Class Initialized
DEBUG - 2021-04-22 18:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:36:40 --> Input Class Initialized
INFO - 2021-04-22 18:36:40 --> Language Class Initialized
INFO - 2021-04-22 18:36:40 --> Loader Class Initialized
INFO - 2021-04-22 18:36:40 --> Helper loaded: url_helper
INFO - 2021-04-22 18:36:40 --> Helper loaded: form_helper
INFO - 2021-04-22 18:36:40 --> Helper loaded: common_helper
INFO - 2021-04-22 18:36:40 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:36:40 --> Controller Class Initialized
INFO - 2021-04-22 18:36:40 --> Form Validation Class Initialized
INFO - 2021-04-22 18:36:40 --> Model "Case_model" initialized
INFO - 2021-04-22 18:36:40 --> Model "Patientcase_model" initialized
ERROR - 2021-04-22 18:36:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:36:47 --> Config Class Initialized
INFO - 2021-04-22 18:36:47 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:36:47 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:36:47 --> Utf8 Class Initialized
INFO - 2021-04-22 18:36:47 --> URI Class Initialized
INFO - 2021-04-22 18:36:47 --> Router Class Initialized
INFO - 2021-04-22 18:36:47 --> Output Class Initialized
INFO - 2021-04-22 18:36:47 --> Security Class Initialized
DEBUG - 2021-04-22 18:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:36:47 --> Input Class Initialized
INFO - 2021-04-22 18:36:47 --> Language Class Initialized
INFO - 2021-04-22 18:36:47 --> Loader Class Initialized
INFO - 2021-04-22 18:36:47 --> Helper loaded: url_helper
INFO - 2021-04-22 18:36:47 --> Helper loaded: form_helper
INFO - 2021-04-22 18:36:47 --> Helper loaded: common_helper
INFO - 2021-04-22 18:36:47 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:36:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:36:50 --> Model "Case_model" initialized
INFO - 2021-04-22 18:37:02 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\cases/all_case.php
INFO - 2021-04-22 18:37:02 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:37:02 --> Final output sent to browser
DEBUG - 2021-04-22 18:37:02 --> Total execution time: 21.1992
INFO - 2021-04-22 18:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:37:02 --> Controller Class Initialized
INFO - 2021-04-22 18:37:02 --> Form Validation Class Initialized
INFO - 2021-04-22 18:37:02 --> Encrypt Class Initialized
INFO - 2021-04-22 18:37:02 --> Model "Login_model" initialized
INFO - 2021-04-22 18:37:02 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:37:02 --> Model "Case_model" initialized
INFO - 2021-04-22 18:37:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:37:31 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-04-22 18:37:31 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:37:31 --> Final output sent to browser
DEBUG - 2021-04-22 18:37:31 --> Total execution time: 43.4095
ERROR - 2021-04-22 18:37:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:37:31 --> Config Class Initialized
INFO - 2021-04-22 18:37:31 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:37:31 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:37:31 --> Utf8 Class Initialized
INFO - 2021-04-22 18:37:31 --> URI Class Initialized
INFO - 2021-04-22 18:37:31 --> Router Class Initialized
INFO - 2021-04-22 18:37:31 --> Output Class Initialized
INFO - 2021-04-22 18:37:31 --> Security Class Initialized
DEBUG - 2021-04-22 18:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:37:31 --> Input Class Initialized
INFO - 2021-04-22 18:37:31 --> Language Class Initialized
ERROR - 2021-04-22 18:37:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:38:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:38:17 --> Config Class Initialized
INFO - 2021-04-22 18:38:17 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:38:17 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:38:17 --> Utf8 Class Initialized
INFO - 2021-04-22 18:38:17 --> URI Class Initialized
INFO - 2021-04-22 18:38:17 --> Router Class Initialized
INFO - 2021-04-22 18:38:17 --> Output Class Initialized
INFO - 2021-04-22 18:38:17 --> Security Class Initialized
DEBUG - 2021-04-22 18:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:38:17 --> Input Class Initialized
INFO - 2021-04-22 18:38:17 --> Language Class Initialized
INFO - 2021-04-22 18:38:17 --> Loader Class Initialized
INFO - 2021-04-22 18:38:17 --> Helper loaded: url_helper
INFO - 2021-04-22 18:38:17 --> Helper loaded: form_helper
INFO - 2021-04-22 18:38:17 --> Helper loaded: common_helper
INFO - 2021-04-22 18:38:17 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:38:17 --> Controller Class Initialized
INFO - 2021-04-22 18:38:17 --> Form Validation Class Initialized
INFO - 2021-04-22 18:38:17 --> Encrypt Class Initialized
INFO - 2021-04-22 18:38:17 --> Model "Login_model" initialized
INFO - 2021-04-22 18:38:17 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:38:17 --> Model "Case_model" initialized
INFO - 2021-04-22 18:38:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:38:47 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-04-22 18:38:47 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:38:47 --> Final output sent to browser
DEBUG - 2021-04-22 18:38:47 --> Total execution time: 29.6468
ERROR - 2021-04-22 18:38:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:38:47 --> Config Class Initialized
INFO - 2021-04-22 18:38:47 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:38:47 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:38:47 --> Utf8 Class Initialized
INFO - 2021-04-22 18:38:47 --> URI Class Initialized
INFO - 2021-04-22 18:38:47 --> Router Class Initialized
INFO - 2021-04-22 18:38:47 --> Output Class Initialized
INFO - 2021-04-22 18:38:47 --> Security Class Initialized
DEBUG - 2021-04-22 18:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:38:47 --> Input Class Initialized
INFO - 2021-04-22 18:38:47 --> Language Class Initialized
ERROR - 2021-04-22 18:38:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:39:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:39:29 --> Config Class Initialized
INFO - 2021-04-22 18:39:29 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:39:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:39:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:39:29 --> URI Class Initialized
INFO - 2021-04-22 18:39:29 --> Router Class Initialized
INFO - 2021-04-22 18:39:29 --> Output Class Initialized
INFO - 2021-04-22 18:39:29 --> Security Class Initialized
DEBUG - 2021-04-22 18:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:39:29 --> Input Class Initialized
INFO - 2021-04-22 18:39:29 --> Language Class Initialized
INFO - 2021-04-22 18:39:29 --> Loader Class Initialized
INFO - 2021-04-22 18:39:29 --> Helper loaded: url_helper
INFO - 2021-04-22 18:39:29 --> Helper loaded: form_helper
INFO - 2021-04-22 18:39:29 --> Helper loaded: common_helper
INFO - 2021-04-22 18:39:29 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:39:29 --> Controller Class Initialized
INFO - 2021-04-22 18:39:29 --> Form Validation Class Initialized
INFO - 2021-04-22 18:39:29 --> Encrypt Class Initialized
INFO - 2021-04-22 18:39:29 --> Model "Login_model" initialized
INFO - 2021-04-22 18:39:29 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:39:29 --> Model "Case_model" initialized
INFO - 2021-04-22 18:39:29 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:39:29 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/birthday.php
INFO - 2021-04-22 18:39:29 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:39:29 --> Final output sent to browser
DEBUG - 2021-04-22 18:39:29 --> Total execution time: 0.1371
ERROR - 2021-04-22 18:39:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:39:29 --> Config Class Initialized
INFO - 2021-04-22 18:39:29 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:39:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:39:29 --> Utf8 Class Initialized
INFO - 2021-04-22 18:39:29 --> URI Class Initialized
INFO - 2021-04-22 18:39:29 --> Router Class Initialized
INFO - 2021-04-22 18:39:29 --> Output Class Initialized
INFO - 2021-04-22 18:39:29 --> Security Class Initialized
DEBUG - 2021-04-22 18:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:39:29 --> Input Class Initialized
INFO - 2021-04-22 18:39:29 --> Language Class Initialized
ERROR - 2021-04-22 18:39:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 18:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:40:03 --> Config Class Initialized
INFO - 2021-04-22 18:40:03 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:40:03 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:40:03 --> Utf8 Class Initialized
INFO - 2021-04-22 18:40:03 --> URI Class Initialized
INFO - 2021-04-22 18:40:03 --> Router Class Initialized
INFO - 2021-04-22 18:40:03 --> Output Class Initialized
INFO - 2021-04-22 18:40:03 --> Security Class Initialized
DEBUG - 2021-04-22 18:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:40:03 --> Input Class Initialized
INFO - 2021-04-22 18:40:03 --> Language Class Initialized
INFO - 2021-04-22 18:40:03 --> Loader Class Initialized
INFO - 2021-04-22 18:40:03 --> Helper loaded: url_helper
INFO - 2021-04-22 18:40:03 --> Helper loaded: form_helper
INFO - 2021-04-22 18:40:03 --> Helper loaded: common_helper
INFO - 2021-04-22 18:40:03 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:40:03 --> Controller Class Initialized
INFO - 2021-04-22 18:40:03 --> Form Validation Class Initialized
INFO - 2021-04-22 18:40:03 --> Encrypt Class Initialized
INFO - 2021-04-22 18:40:03 --> Model "Login_model" initialized
INFO - 2021-04-22 18:40:03 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:40:03 --> Model "Case_model" initialized
ERROR - 2021-04-22 18:40:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:40:04 --> Config Class Initialized
INFO - 2021-04-22 18:40:04 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:40:04 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:40:04 --> Utf8 Class Initialized
INFO - 2021-04-22 18:40:04 --> URI Class Initialized
INFO - 2021-04-22 18:40:04 --> Router Class Initialized
INFO - 2021-04-22 18:40:04 --> Output Class Initialized
INFO - 2021-04-22 18:40:04 --> Security Class Initialized
DEBUG - 2021-04-22 18:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:40:04 --> Input Class Initialized
INFO - 2021-04-22 18:40:04 --> Language Class Initialized
INFO - 2021-04-22 18:40:04 --> Loader Class Initialized
INFO - 2021-04-22 18:40:04 --> Helper loaded: url_helper
INFO - 2021-04-22 18:40:04 --> Helper loaded: form_helper
INFO - 2021-04-22 18:40:04 --> Helper loaded: common_helper
INFO - 2021-04-22 18:40:04 --> Database Driver Class Initialized
DEBUG - 2021-04-22 18:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 18:40:11 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:40:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-04-22 18:40:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:40:30 --> Final output sent to browser
DEBUG - 2021-04-22 18:40:30 --> Total execution time: 27.0128
INFO - 2021-04-22 18:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 18:40:30 --> Controller Class Initialized
INFO - 2021-04-22 18:40:30 --> Form Validation Class Initialized
INFO - 2021-04-22 18:40:30 --> Encrypt Class Initialized
INFO - 2021-04-22 18:40:30 --> Model "Login_model" initialized
INFO - 2021-04-22 18:40:30 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 18:40:30 --> Model "Case_model" initialized
INFO - 2021-04-22 18:40:37 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 18:40:55 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-04-22 18:40:55 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 18:40:55 --> Final output sent to browser
DEBUG - 2021-04-22 18:40:55 --> Total execution time: 50.5993
ERROR - 2021-04-22 18:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 18:40:55 --> Config Class Initialized
INFO - 2021-04-22 18:40:55 --> Hooks Class Initialized
DEBUG - 2021-04-22 18:40:55 --> UTF-8 Support Enabled
INFO - 2021-04-22 18:40:55 --> Utf8 Class Initialized
INFO - 2021-04-22 18:40:55 --> URI Class Initialized
INFO - 2021-04-22 18:40:55 --> Router Class Initialized
INFO - 2021-04-22 18:40:55 --> Output Class Initialized
INFO - 2021-04-22 18:40:55 --> Security Class Initialized
DEBUG - 2021-04-22 18:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 18:40:55 --> Input Class Initialized
INFO - 2021-04-22 18:40:55 --> Language Class Initialized
ERROR - 2021-04-22 18:40:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:22:09 --> Config Class Initialized
INFO - 2021-04-22 19:22:09 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:22:09 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:22:09 --> Utf8 Class Initialized
INFO - 2021-04-22 19:22:09 --> URI Class Initialized
DEBUG - 2021-04-22 19:22:09 --> No URI present. Default controller set.
INFO - 2021-04-22 19:22:09 --> Router Class Initialized
INFO - 2021-04-22 19:22:09 --> Output Class Initialized
INFO - 2021-04-22 19:22:09 --> Security Class Initialized
DEBUG - 2021-04-22 19:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:22:09 --> Input Class Initialized
INFO - 2021-04-22 19:22:09 --> Language Class Initialized
INFO - 2021-04-22 19:22:09 --> Loader Class Initialized
INFO - 2021-04-22 19:22:09 --> Helper loaded: url_helper
INFO - 2021-04-22 19:22:09 --> Helper loaded: form_helper
INFO - 2021-04-22 19:22:09 --> Helper loaded: common_helper
INFO - 2021-04-22 19:22:09 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:22:09 --> Controller Class Initialized
INFO - 2021-04-22 19:22:09 --> Form Validation Class Initialized
INFO - 2021-04-22 19:22:09 --> Encrypt Class Initialized
DEBUG - 2021-04-22 19:22:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 19:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 19:22:09 --> Email Class Initialized
INFO - 2021-04-22 19:22:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 19:22:09 --> Calendar Class Initialized
INFO - 2021-04-22 19:22:09 --> Model "Login_model" initialized
INFO - 2021-04-22 19:22:09 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-04-22 19:22:09 --> Final output sent to browser
DEBUG - 2021-04-22 19:22:09 --> Total execution time: 0.0632
ERROR - 2021-04-22 19:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:22:58 --> Config Class Initialized
INFO - 2021-04-22 19:22:58 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:22:58 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:22:58 --> Utf8 Class Initialized
INFO - 2021-04-22 19:22:58 --> URI Class Initialized
INFO - 2021-04-22 19:22:58 --> Router Class Initialized
INFO - 2021-04-22 19:22:58 --> Output Class Initialized
INFO - 2021-04-22 19:22:58 --> Security Class Initialized
DEBUG - 2021-04-22 19:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:22:58 --> Input Class Initialized
INFO - 2021-04-22 19:22:58 --> Language Class Initialized
INFO - 2021-04-22 19:22:58 --> Loader Class Initialized
INFO - 2021-04-22 19:22:58 --> Helper loaded: url_helper
INFO - 2021-04-22 19:22:58 --> Helper loaded: form_helper
INFO - 2021-04-22 19:22:58 --> Helper loaded: common_helper
INFO - 2021-04-22 19:22:58 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:22:58 --> Controller Class Initialized
INFO - 2021-04-22 19:22:58 --> Form Validation Class Initialized
INFO - 2021-04-22 19:22:58 --> Encrypt Class Initialized
DEBUG - 2021-04-22 19:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 19:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 19:22:58 --> Email Class Initialized
INFO - 2021-04-22 19:22:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 19:22:58 --> Calendar Class Initialized
INFO - 2021-04-22 19:22:58 --> Model "Login_model" initialized
INFO - 2021-04-22 19:22:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-22 19:22:58 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-04-22 19:22:58 --> Final output sent to browser
DEBUG - 2021-04-22 19:22:58 --> Total execution time: 0.0525
ERROR - 2021-04-22 19:23:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:23:16 --> Config Class Initialized
INFO - 2021-04-22 19:23:16 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:23:16 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:23:16 --> Utf8 Class Initialized
INFO - 2021-04-22 19:23:16 --> URI Class Initialized
INFO - 2021-04-22 19:23:16 --> Router Class Initialized
INFO - 2021-04-22 19:23:16 --> Output Class Initialized
INFO - 2021-04-22 19:23:16 --> Security Class Initialized
DEBUG - 2021-04-22 19:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:23:16 --> Input Class Initialized
INFO - 2021-04-22 19:23:16 --> Language Class Initialized
INFO - 2021-04-22 19:23:16 --> Loader Class Initialized
INFO - 2021-04-22 19:23:16 --> Helper loaded: url_helper
INFO - 2021-04-22 19:23:16 --> Helper loaded: form_helper
INFO - 2021-04-22 19:23:16 --> Helper loaded: common_helper
INFO - 2021-04-22 19:23:16 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:23:16 --> Controller Class Initialized
INFO - 2021-04-22 19:23:16 --> Form Validation Class Initialized
INFO - 2021-04-22 19:23:16 --> Encrypt Class Initialized
DEBUG - 2021-04-22 19:23:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-22 19:23:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-04-22 19:23:16 --> Email Class Initialized
INFO - 2021-04-22 19:23:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-04-22 19:23:16 --> Calendar Class Initialized
INFO - 2021-04-22 19:23:16 --> Model "Login_model" initialized
INFO - 2021-04-22 19:23:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-22 19:23:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:23:16 --> Config Class Initialized
INFO - 2021-04-22 19:23:16 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:23:16 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:23:16 --> Utf8 Class Initialized
INFO - 2021-04-22 19:23:16 --> URI Class Initialized
INFO - 2021-04-22 19:23:16 --> Router Class Initialized
INFO - 2021-04-22 19:23:16 --> Output Class Initialized
INFO - 2021-04-22 19:23:16 --> Security Class Initialized
DEBUG - 2021-04-22 19:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:23:16 --> Input Class Initialized
INFO - 2021-04-22 19:23:16 --> Language Class Initialized
INFO - 2021-04-22 19:23:16 --> Loader Class Initialized
INFO - 2021-04-22 19:23:16 --> Helper loaded: url_helper
INFO - 2021-04-22 19:23:16 --> Helper loaded: form_helper
INFO - 2021-04-22 19:23:16 --> Helper loaded: common_helper
INFO - 2021-04-22 19:23:16 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:23:16 --> Controller Class Initialized
INFO - 2021-04-22 19:23:16 --> Form Validation Class Initialized
INFO - 2021-04-22 19:23:16 --> Encrypt Class Initialized
INFO - 2021-04-22 19:23:16 --> Model "Login_model" initialized
INFO - 2021-04-22 19:23:16 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:23:16 --> Model "Case_model" initialized
INFO - 2021-04-22 19:23:23 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:23:36 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-04-22 19:23:36 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:23:36 --> Final output sent to browser
DEBUG - 2021-04-22 19:23:36 --> Total execution time: 20.4401
ERROR - 2021-04-22 19:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:23:37 --> Config Class Initialized
INFO - 2021-04-22 19:23:37 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:23:37 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:23:37 --> Utf8 Class Initialized
INFO - 2021-04-22 19:23:37 --> URI Class Initialized
INFO - 2021-04-22 19:23:37 --> Router Class Initialized
INFO - 2021-04-22 19:23:37 --> Output Class Initialized
INFO - 2021-04-22 19:23:37 --> Security Class Initialized
DEBUG - 2021-04-22 19:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:23:37 --> Input Class Initialized
INFO - 2021-04-22 19:23:37 --> Language Class Initialized
ERROR - 2021-04-22 19:23:37 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:26:12 --> Config Class Initialized
INFO - 2021-04-22 19:26:12 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:26:12 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:26:12 --> Utf8 Class Initialized
INFO - 2021-04-22 19:26:12 --> URI Class Initialized
INFO - 2021-04-22 19:26:12 --> Router Class Initialized
INFO - 2021-04-22 19:26:12 --> Output Class Initialized
INFO - 2021-04-22 19:26:12 --> Security Class Initialized
DEBUG - 2021-04-22 19:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:26:12 --> Input Class Initialized
INFO - 2021-04-22 19:26:12 --> Language Class Initialized
INFO - 2021-04-22 19:26:12 --> Loader Class Initialized
INFO - 2021-04-22 19:26:12 --> Helper loaded: url_helper
INFO - 2021-04-22 19:26:12 --> Helper loaded: form_helper
INFO - 2021-04-22 19:26:12 --> Helper loaded: common_helper
INFO - 2021-04-22 19:26:12 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:26:12 --> Controller Class Initialized
INFO - 2021-04-22 19:26:12 --> Form Validation Class Initialized
INFO - 2021-04-22 19:26:12 --> Encrypt Class Initialized
INFO - 2021-04-22 19:26:12 --> Model "Hospital_model" initialized
INFO - 2021-04-22 19:26:12 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:26:12 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\hospital/index.php
INFO - 2021-04-22 19:26:12 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:26:12 --> Final output sent to browser
DEBUG - 2021-04-22 19:26:12 --> Total execution time: 0.0686
ERROR - 2021-04-22 19:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:26:12 --> Config Class Initialized
INFO - 2021-04-22 19:26:12 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:26:12 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:26:12 --> Utf8 Class Initialized
INFO - 2021-04-22 19:26:12 --> URI Class Initialized
INFO - 2021-04-22 19:26:12 --> Router Class Initialized
INFO - 2021-04-22 19:26:12 --> Output Class Initialized
INFO - 2021-04-22 19:26:12 --> Security Class Initialized
DEBUG - 2021-04-22 19:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:26:12 --> Input Class Initialized
INFO - 2021-04-22 19:26:12 --> Language Class Initialized
ERROR - 2021-04-22 19:26:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:26:28 --> Config Class Initialized
INFO - 2021-04-22 19:26:28 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:26:29 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:26:29 --> Utf8 Class Initialized
INFO - 2021-04-22 19:26:29 --> URI Class Initialized
INFO - 2021-04-22 19:26:29 --> Router Class Initialized
INFO - 2021-04-22 19:26:29 --> Output Class Initialized
INFO - 2021-04-22 19:26:29 --> Security Class Initialized
DEBUG - 2021-04-22 19:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:26:29 --> Input Class Initialized
INFO - 2021-04-22 19:26:29 --> Language Class Initialized
INFO - 2021-04-22 19:26:29 --> Loader Class Initialized
INFO - 2021-04-22 19:26:29 --> Helper loaded: url_helper
INFO - 2021-04-22 19:26:29 --> Helper loaded: form_helper
INFO - 2021-04-22 19:26:29 --> Helper loaded: common_helper
INFO - 2021-04-22 19:26:29 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:26:29 --> Controller Class Initialized
INFO - 2021-04-22 19:26:29 --> Model "Referredby_model" initialized
INFO - 2021-04-22 19:26:29 --> Final output sent to browser
DEBUG - 2021-04-22 19:26:29 --> Total execution time: 0.0623
ERROR - 2021-04-22 19:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:26:45 --> Config Class Initialized
INFO - 2021-04-22 19:26:45 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:26:45 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:26:45 --> Utf8 Class Initialized
INFO - 2021-04-22 19:26:45 --> URI Class Initialized
INFO - 2021-04-22 19:26:45 --> Router Class Initialized
INFO - 2021-04-22 19:26:45 --> Output Class Initialized
INFO - 2021-04-22 19:26:45 --> Security Class Initialized
DEBUG - 2021-04-22 19:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:26:45 --> Input Class Initialized
INFO - 2021-04-22 19:26:45 --> Language Class Initialized
INFO - 2021-04-22 19:26:45 --> Loader Class Initialized
INFO - 2021-04-22 19:26:45 --> Helper loaded: url_helper
INFO - 2021-04-22 19:26:45 --> Helper loaded: form_helper
INFO - 2021-04-22 19:26:45 --> Helper loaded: common_helper
INFO - 2021-04-22 19:26:45 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:26:45 --> Controller Class Initialized
INFO - 2021-04-22 19:26:45 --> Form Validation Class Initialized
INFO - 2021-04-22 19:26:45 --> Encrypt Class Initialized
INFO - 2021-04-22 19:26:45 --> Model "Referredby_model" initialized
INFO - 2021-04-22 19:26:45 --> Model "Users_model" initialized
INFO - 2021-04-22 19:26:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:26:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\users/index.php
INFO - 2021-04-22 19:26:46 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:26:46 --> Final output sent to browser
DEBUG - 2021-04-22 19:26:46 --> Total execution time: 0.2289
ERROR - 2021-04-22 19:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:26:46 --> Config Class Initialized
INFO - 2021-04-22 19:26:46 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:26:46 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:26:46 --> Utf8 Class Initialized
INFO - 2021-04-22 19:26:46 --> URI Class Initialized
INFO - 2021-04-22 19:26:46 --> Router Class Initialized
INFO - 2021-04-22 19:26:46 --> Output Class Initialized
INFO - 2021-04-22 19:26:46 --> Security Class Initialized
DEBUG - 2021-04-22 19:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:26:46 --> Input Class Initialized
INFO - 2021-04-22 19:26:46 --> Language Class Initialized
ERROR - 2021-04-22 19:26:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:27:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:27:11 --> Config Class Initialized
INFO - 2021-04-22 19:27:11 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:27:11 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:27:11 --> Utf8 Class Initialized
INFO - 2021-04-22 19:27:11 --> URI Class Initialized
INFO - 2021-04-22 19:27:11 --> Router Class Initialized
INFO - 2021-04-22 19:27:11 --> Output Class Initialized
INFO - 2021-04-22 19:27:12 --> Security Class Initialized
DEBUG - 2021-04-22 19:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:27:12 --> Input Class Initialized
INFO - 2021-04-22 19:27:12 --> Language Class Initialized
INFO - 2021-04-22 19:27:12 --> Loader Class Initialized
INFO - 2021-04-22 19:27:12 --> Helper loaded: url_helper
INFO - 2021-04-22 19:27:12 --> Helper loaded: form_helper
INFO - 2021-04-22 19:27:12 --> Helper loaded: common_helper
INFO - 2021-04-22 19:27:12 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:27:12 --> Controller Class Initialized
INFO - 2021-04-22 19:27:12 --> Form Validation Class Initialized
INFO - 2021-04-22 19:27:12 --> Encrypt Class Initialized
INFO - 2021-04-22 19:27:12 --> Model "Referredby_model" initialized
INFO - 2021-04-22 19:27:12 --> Model "Users_model" initialized
INFO - 2021-04-22 19:27:12 --> Final output sent to browser
DEBUG - 2021-04-22 19:27:12 --> Total execution time: 0.1649
ERROR - 2021-04-22 19:27:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:27:53 --> Config Class Initialized
INFO - 2021-04-22 19:27:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:27:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:27:53 --> Utf8 Class Initialized
INFO - 2021-04-22 19:27:53 --> URI Class Initialized
INFO - 2021-04-22 19:27:53 --> Router Class Initialized
INFO - 2021-04-22 19:27:53 --> Output Class Initialized
INFO - 2021-04-22 19:27:53 --> Security Class Initialized
DEBUG - 2021-04-22 19:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:27:53 --> Input Class Initialized
INFO - 2021-04-22 19:27:53 --> Language Class Initialized
INFO - 2021-04-22 19:27:53 --> Loader Class Initialized
INFO - 2021-04-22 19:27:53 --> Helper loaded: url_helper
INFO - 2021-04-22 19:27:53 --> Helper loaded: form_helper
INFO - 2021-04-22 19:27:53 --> Helper loaded: common_helper
INFO - 2021-04-22 19:27:53 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:27:53 --> Controller Class Initialized
INFO - 2021-04-22 19:27:53 --> Form Validation Class Initialized
INFO - 2021-04-22 19:27:53 --> Encrypt Class Initialized
INFO - 2021-04-22 19:27:53 --> Model "Hospital_model" initialized
INFO - 2021-04-22 19:27:53 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:27:53 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\hospital/depart.php
INFO - 2021-04-22 19:27:53 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:27:53 --> Final output sent to browser
DEBUG - 2021-04-22 19:27:53 --> Total execution time: 0.0658
ERROR - 2021-04-22 19:27:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:27:53 --> Config Class Initialized
INFO - 2021-04-22 19:27:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:27:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:27:53 --> Utf8 Class Initialized
INFO - 2021-04-22 19:27:53 --> URI Class Initialized
INFO - 2021-04-22 19:27:53 --> Router Class Initialized
INFO - 2021-04-22 19:27:53 --> Output Class Initialized
INFO - 2021-04-22 19:27:53 --> Security Class Initialized
DEBUG - 2021-04-22 19:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:27:53 --> Input Class Initialized
INFO - 2021-04-22 19:27:53 --> Language Class Initialized
ERROR - 2021-04-22 19:27:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:28:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:28:15 --> Config Class Initialized
INFO - 2021-04-22 19:28:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:28:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:28:15 --> Utf8 Class Initialized
INFO - 2021-04-22 19:28:15 --> URI Class Initialized
INFO - 2021-04-22 19:28:15 --> Router Class Initialized
INFO - 2021-04-22 19:28:15 --> Output Class Initialized
INFO - 2021-04-22 19:28:15 --> Security Class Initialized
DEBUG - 2021-04-22 19:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:28:15 --> Input Class Initialized
INFO - 2021-04-22 19:28:15 --> Language Class Initialized
INFO - 2021-04-22 19:28:15 --> Loader Class Initialized
INFO - 2021-04-22 19:28:15 --> Helper loaded: url_helper
INFO - 2021-04-22 19:28:15 --> Helper loaded: form_helper
INFO - 2021-04-22 19:28:15 --> Helper loaded: common_helper
INFO - 2021-04-22 19:28:15 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:28:15 --> Controller Class Initialized
INFO - 2021-04-22 19:28:15 --> Form Validation Class Initialized
INFO - 2021-04-22 19:28:15 --> Encrypt Class Initialized
INFO - 2021-04-22 19:28:15 --> Model "Referredby_model" initialized
INFO - 2021-04-22 19:28:15 --> Model "Donner_model" initialized
INFO - 2021-04-22 19:28:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:28:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\donner/index.php
INFO - 2021-04-22 19:28:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:28:15 --> Final output sent to browser
DEBUG - 2021-04-22 19:28:15 --> Total execution time: 0.1262
ERROR - 2021-04-22 19:28:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:28:15 --> Config Class Initialized
INFO - 2021-04-22 19:28:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:28:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:28:15 --> Utf8 Class Initialized
INFO - 2021-04-22 19:28:15 --> URI Class Initialized
INFO - 2021-04-22 19:28:15 --> Router Class Initialized
INFO - 2021-04-22 19:28:15 --> Output Class Initialized
INFO - 2021-04-22 19:28:15 --> Security Class Initialized
DEBUG - 2021-04-22 19:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:28:15 --> Input Class Initialized
INFO - 2021-04-22 19:28:15 --> Language Class Initialized
ERROR - 2021-04-22 19:28:15 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:28:20 --> Config Class Initialized
INFO - 2021-04-22 19:28:20 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:28:20 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:28:20 --> Utf8 Class Initialized
INFO - 2021-04-22 19:28:20 --> URI Class Initialized
INFO - 2021-04-22 19:28:20 --> Router Class Initialized
INFO - 2021-04-22 19:28:20 --> Output Class Initialized
INFO - 2021-04-22 19:28:20 --> Security Class Initialized
DEBUG - 2021-04-22 19:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:28:20 --> Input Class Initialized
INFO - 2021-04-22 19:28:20 --> Language Class Initialized
INFO - 2021-04-22 19:28:20 --> Loader Class Initialized
INFO - 2021-04-22 19:28:20 --> Helper loaded: url_helper
INFO - 2021-04-22 19:28:20 --> Helper loaded: form_helper
INFO - 2021-04-22 19:28:20 --> Helper loaded: common_helper
INFO - 2021-04-22 19:28:20 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:28:20 --> Controller Class Initialized
INFO - 2021-04-22 19:28:20 --> Form Validation Class Initialized
INFO - 2021-04-22 19:28:20 --> Encrypt Class Initialized
INFO - 2021-04-22 19:28:20 --> Model "Login_model" initialized
INFO - 2021-04-22 19:28:20 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:28:20 --> Model "Case_model" initialized
INFO - 2021-04-22 19:28:27 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:28:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-04-22 19:28:41 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:28:41 --> Final output sent to browser
DEBUG - 2021-04-22 19:28:41 --> Total execution time: 21.1197
ERROR - 2021-04-22 19:28:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:28:41 --> Config Class Initialized
INFO - 2021-04-22 19:28:41 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:28:41 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:28:41 --> Utf8 Class Initialized
INFO - 2021-04-22 19:28:41 --> URI Class Initialized
INFO - 2021-04-22 19:28:41 --> Router Class Initialized
INFO - 2021-04-22 19:28:41 --> Output Class Initialized
INFO - 2021-04-22 19:28:41 --> Security Class Initialized
DEBUG - 2021-04-22 19:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:28:41 --> Input Class Initialized
INFO - 2021-04-22 19:28:41 --> Language Class Initialized
ERROR - 2021-04-22 19:28:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:31:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:31:42 --> Config Class Initialized
INFO - 2021-04-22 19:31:42 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:31:42 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:31:42 --> Utf8 Class Initialized
INFO - 2021-04-22 19:31:42 --> URI Class Initialized
INFO - 2021-04-22 19:31:42 --> Router Class Initialized
INFO - 2021-04-22 19:31:42 --> Output Class Initialized
INFO - 2021-04-22 19:31:42 --> Security Class Initialized
DEBUG - 2021-04-22 19:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:31:42 --> Input Class Initialized
INFO - 2021-04-22 19:31:42 --> Language Class Initialized
INFO - 2021-04-22 19:31:42 --> Loader Class Initialized
INFO - 2021-04-22 19:31:42 --> Helper loaded: url_helper
INFO - 2021-04-22 19:31:42 --> Helper loaded: form_helper
INFO - 2021-04-22 19:31:42 --> Helper loaded: common_helper
INFO - 2021-04-22 19:31:42 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:31:42 --> Controller Class Initialized
INFO - 2021-04-22 19:31:42 --> Form Validation Class Initialized
INFO - 2021-04-22 19:31:42 --> Encrypt Class Initialized
INFO - 2021-04-22 19:31:42 --> Model "Patient_model" initialized
INFO - 2021-04-22 19:31:42 --> Model "Patientcase_model" initialized
INFO - 2021-04-22 19:31:42 --> Model "Referredby_model" initialized
INFO - 2021-04-22 19:31:42 --> Model "Prefix_master" initialized
INFO - 2021-04-22 19:31:42 --> Model "Hospital_model" initialized
INFO - 2021-04-22 19:31:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:31:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patient/index.php
INFO - 2021-04-22 19:31:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:31:43 --> Final output sent to browser
DEBUG - 2021-04-22 19:31:43 --> Total execution time: 0.2121
ERROR - 2021-04-22 19:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:31:43 --> Config Class Initialized
INFO - 2021-04-22 19:31:43 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:31:43 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:31:43 --> Utf8 Class Initialized
INFO - 2021-04-22 19:31:43 --> URI Class Initialized
INFO - 2021-04-22 19:31:43 --> Router Class Initialized
INFO - 2021-04-22 19:31:43 --> Output Class Initialized
INFO - 2021-04-22 19:31:43 --> Security Class Initialized
DEBUG - 2021-04-22 19:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:31:43 --> Input Class Initialized
INFO - 2021-04-22 19:31:43 --> Language Class Initialized
ERROR - 2021-04-22 19:31:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:31:47 --> Config Class Initialized
INFO - 2021-04-22 19:31:47 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:31:47 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:31:47 --> Utf8 Class Initialized
INFO - 2021-04-22 19:31:47 --> URI Class Initialized
INFO - 2021-04-22 19:31:47 --> Router Class Initialized
INFO - 2021-04-22 19:31:47 --> Output Class Initialized
INFO - 2021-04-22 19:31:47 --> Security Class Initialized
DEBUG - 2021-04-22 19:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:31:47 --> Input Class Initialized
INFO - 2021-04-22 19:31:47 --> Language Class Initialized
INFO - 2021-04-22 19:31:47 --> Loader Class Initialized
INFO - 2021-04-22 19:31:47 --> Helper loaded: url_helper
INFO - 2021-04-22 19:31:47 --> Helper loaded: form_helper
INFO - 2021-04-22 19:31:47 --> Helper loaded: common_helper
INFO - 2021-04-22 19:31:47 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:31:47 --> Controller Class Initialized
INFO - 2021-04-22 19:31:47 --> Form Validation Class Initialized
INFO - 2021-04-22 19:31:47 --> Encrypt Class Initialized
INFO - 2021-04-22 19:31:47 --> Model "Patient_model" initialized
INFO - 2021-04-22 19:31:47 --> Model "Patientcase_model" initialized
INFO - 2021-04-22 19:31:47 --> Model "Referredby_model" initialized
INFO - 2021-04-22 19:31:47 --> Model "Prefix_master" initialized
INFO - 2021-04-22 19:31:47 --> Model "Hospital_model" initialized
INFO - 2021-04-22 19:31:47 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:31:55 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patient/patientview.php
INFO - 2021-04-22 19:31:55 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:31:55 --> Final output sent to browser
DEBUG - 2021-04-22 19:31:55 --> Total execution time: 8.5418
ERROR - 2021-04-22 19:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:31:55 --> Config Class Initialized
INFO - 2021-04-22 19:31:55 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:31:55 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:31:55 --> Utf8 Class Initialized
INFO - 2021-04-22 19:31:55 --> URI Class Initialized
INFO - 2021-04-22 19:31:55 --> Router Class Initialized
INFO - 2021-04-22 19:31:55 --> Output Class Initialized
INFO - 2021-04-22 19:31:55 --> Security Class Initialized
DEBUG - 2021-04-22 19:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:31:55 --> Input Class Initialized
INFO - 2021-04-22 19:31:55 --> Language Class Initialized
ERROR - 2021-04-22 19:31:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:31:56 --> Config Class Initialized
INFO - 2021-04-22 19:31:56 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:31:56 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:31:56 --> Utf8 Class Initialized
INFO - 2021-04-22 19:31:56 --> URI Class Initialized
INFO - 2021-04-22 19:31:56 --> Router Class Initialized
INFO - 2021-04-22 19:31:56 --> Output Class Initialized
INFO - 2021-04-22 19:31:56 --> Security Class Initialized
DEBUG - 2021-04-22 19:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:31:56 --> Input Class Initialized
INFO - 2021-04-22 19:31:56 --> Language Class Initialized
INFO - 2021-04-22 19:31:56 --> Loader Class Initialized
INFO - 2021-04-22 19:31:56 --> Helper loaded: url_helper
INFO - 2021-04-22 19:31:56 --> Helper loaded: form_helper
INFO - 2021-04-22 19:31:56 --> Helper loaded: common_helper
INFO - 2021-04-22 19:31:56 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:31:56 --> Controller Class Initialized
INFO - 2021-04-22 19:31:56 --> Form Validation Class Initialized
INFO - 2021-04-22 19:31:56 --> Encrypt Class Initialized
INFO - 2021-04-22 19:31:56 --> Model "Patient_model" initialized
INFO - 2021-04-22 19:31:56 --> Model "Patientcase_model" initialized
INFO - 2021-04-22 19:31:56 --> Model "Referredby_model" initialized
INFO - 2021-04-22 19:31:56 --> Model "Prefix_master" initialized
INFO - 2021-04-22 19:31:56 --> Model "Hospital_model" initialized
INFO - 2021-04-22 19:31:56 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:32:05 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patient/patientview.php
INFO - 2021-04-22 19:32:05 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:32:05 --> Final output sent to browser
DEBUG - 2021-04-22 19:32:05 --> Total execution time: 9.5183
ERROR - 2021-04-22 19:32:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:32:06 --> Config Class Initialized
INFO - 2021-04-22 19:32:06 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:32:06 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:32:06 --> Utf8 Class Initialized
INFO - 2021-04-22 19:32:06 --> URI Class Initialized
INFO - 2021-04-22 19:32:06 --> Router Class Initialized
INFO - 2021-04-22 19:32:06 --> Output Class Initialized
INFO - 2021-04-22 19:32:06 --> Security Class Initialized
DEBUG - 2021-04-22 19:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:32:06 --> Input Class Initialized
INFO - 2021-04-22 19:32:06 --> Language Class Initialized
ERROR - 2021-04-22 19:32:06 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:32:26 --> Config Class Initialized
INFO - 2021-04-22 19:32:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:32:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:32:26 --> Utf8 Class Initialized
INFO - 2021-04-22 19:32:26 --> URI Class Initialized
INFO - 2021-04-22 19:32:26 --> Router Class Initialized
INFO - 2021-04-22 19:32:26 --> Output Class Initialized
INFO - 2021-04-22 19:32:26 --> Security Class Initialized
DEBUG - 2021-04-22 19:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:32:26 --> Input Class Initialized
INFO - 2021-04-22 19:32:26 --> Language Class Initialized
INFO - 2021-04-22 19:32:26 --> Loader Class Initialized
INFO - 2021-04-22 19:32:26 --> Helper loaded: url_helper
INFO - 2021-04-22 19:32:26 --> Helper loaded: form_helper
INFO - 2021-04-22 19:32:26 --> Helper loaded: common_helper
INFO - 2021-04-22 19:32:26 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:32:26 --> Controller Class Initialized
INFO - 2021-04-22 19:32:26 --> Form Validation Class Initialized
INFO - 2021-04-22 19:32:26 --> Encrypt Class Initialized
INFO - 2021-04-22 19:32:26 --> Model "Login_model" initialized
INFO - 2021-04-22 19:32:26 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:32:26 --> Model "Case_model" initialized
INFO - 2021-04-22 19:32:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:32:45 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-04-22 19:32:45 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:32:45 --> Final output sent to browser
DEBUG - 2021-04-22 19:32:45 --> Total execution time: 19.0943
ERROR - 2021-04-22 19:32:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:32:46 --> Config Class Initialized
INFO - 2021-04-22 19:32:46 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:32:46 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:32:46 --> Utf8 Class Initialized
INFO - 2021-04-22 19:32:46 --> URI Class Initialized
INFO - 2021-04-22 19:32:46 --> Router Class Initialized
INFO - 2021-04-22 19:32:46 --> Output Class Initialized
INFO - 2021-04-22 19:32:46 --> Security Class Initialized
DEBUG - 2021-04-22 19:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:32:46 --> Input Class Initialized
INFO - 2021-04-22 19:32:46 --> Language Class Initialized
ERROR - 2021-04-22 19:32:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:36:43 --> Config Class Initialized
INFO - 2021-04-22 19:36:43 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:36:43 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:36:43 --> Utf8 Class Initialized
INFO - 2021-04-22 19:36:43 --> URI Class Initialized
INFO - 2021-04-22 19:36:43 --> Router Class Initialized
INFO - 2021-04-22 19:36:43 --> Output Class Initialized
INFO - 2021-04-22 19:36:43 --> Security Class Initialized
DEBUG - 2021-04-22 19:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:36:43 --> Input Class Initialized
INFO - 2021-04-22 19:36:43 --> Language Class Initialized
INFO - 2021-04-22 19:36:43 --> Loader Class Initialized
INFO - 2021-04-22 19:36:43 --> Helper loaded: url_helper
INFO - 2021-04-22 19:36:43 --> Helper loaded: form_helper
INFO - 2021-04-22 19:36:43 --> Helper loaded: common_helper
INFO - 2021-04-22 19:36:43 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:36:43 --> Controller Class Initialized
INFO - 2021-04-22 19:36:43 --> Form Validation Class Initialized
INFO - 2021-04-22 19:36:43 --> Encrypt Class Initialized
INFO - 2021-04-22 19:36:43 --> Model "Patient_model" initialized
INFO - 2021-04-22 19:36:43 --> Model "Patientcase_model" initialized
INFO - 2021-04-22 19:36:43 --> Model "Referredby_model" initialized
INFO - 2021-04-22 19:36:43 --> Model "Prefix_master" initialized
INFO - 2021-04-22 19:36:43 --> Model "Hospital_model" initialized
INFO - 2021-04-22 19:36:43 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:36:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\patient/patientview.php
INFO - 2021-04-22 19:36:50 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:36:51 --> Final output sent to browser
DEBUG - 2021-04-22 19:36:51 --> Total execution time: 7.8958
ERROR - 2021-04-22 19:36:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:36:51 --> Config Class Initialized
INFO - 2021-04-22 19:36:51 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:36:51 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:36:51 --> Utf8 Class Initialized
INFO - 2021-04-22 19:36:51 --> URI Class Initialized
INFO - 2021-04-22 19:36:51 --> Router Class Initialized
INFO - 2021-04-22 19:36:51 --> Output Class Initialized
INFO - 2021-04-22 19:36:51 --> Security Class Initialized
DEBUG - 2021-04-22 19:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:36:51 --> Input Class Initialized
INFO - 2021-04-22 19:36:51 --> Language Class Initialized
ERROR - 2021-04-22 19:36:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:44:26 --> Config Class Initialized
INFO - 2021-04-22 19:44:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:44:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:44:26 --> Utf8 Class Initialized
INFO - 2021-04-22 19:44:26 --> URI Class Initialized
INFO - 2021-04-22 19:44:26 --> Router Class Initialized
INFO - 2021-04-22 19:44:26 --> Output Class Initialized
INFO - 2021-04-22 19:44:26 --> Security Class Initialized
DEBUG - 2021-04-22 19:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:44:26 --> Input Class Initialized
INFO - 2021-04-22 19:44:26 --> Language Class Initialized
INFO - 2021-04-22 19:44:26 --> Loader Class Initialized
INFO - 2021-04-22 19:44:26 --> Helper loaded: url_helper
INFO - 2021-04-22 19:44:26 --> Helper loaded: form_helper
INFO - 2021-04-22 19:44:26 --> Helper loaded: common_helper
INFO - 2021-04-22 19:44:26 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:44:26 --> Controller Class Initialized
INFO - 2021-04-22 19:44:26 --> Form Validation Class Initialized
INFO - 2021-04-22 19:44:26 --> Encrypt Class Initialized
INFO - 2021-04-22 19:44:26 --> Model "Login_model" initialized
INFO - 2021-04-22 19:44:26 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:44:26 --> Model "Case_model" initialized
INFO - 2021-04-22 19:44:33 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:44:48 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-04-22 19:44:48 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:44:48 --> Final output sent to browser
DEBUG - 2021-04-22 19:44:48 --> Total execution time: 21.4365
ERROR - 2021-04-22 19:44:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:44:48 --> Config Class Initialized
INFO - 2021-04-22 19:44:48 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:44:48 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:44:48 --> Utf8 Class Initialized
INFO - 2021-04-22 19:44:48 --> URI Class Initialized
INFO - 2021-04-22 19:44:48 --> Router Class Initialized
INFO - 2021-04-22 19:44:48 --> Output Class Initialized
INFO - 2021-04-22 19:44:48 --> Security Class Initialized
DEBUG - 2021-04-22 19:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:44:48 --> Input Class Initialized
INFO - 2021-04-22 19:44:48 --> Language Class Initialized
ERROR - 2021-04-22 19:44:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:44:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:44:59 --> Config Class Initialized
INFO - 2021-04-22 19:44:59 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:44:59 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:44:59 --> Utf8 Class Initialized
INFO - 2021-04-22 19:44:59 --> URI Class Initialized
INFO - 2021-04-22 19:44:59 --> Router Class Initialized
INFO - 2021-04-22 19:44:59 --> Output Class Initialized
INFO - 2021-04-22 19:44:59 --> Security Class Initialized
DEBUG - 2021-04-22 19:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:44:59 --> Input Class Initialized
INFO - 2021-04-22 19:44:59 --> Language Class Initialized
INFO - 2021-04-22 19:44:59 --> Loader Class Initialized
INFO - 2021-04-22 19:44:59 --> Helper loaded: url_helper
INFO - 2021-04-22 19:44:59 --> Helper loaded: form_helper
INFO - 2021-04-22 19:44:59 --> Helper loaded: common_helper
INFO - 2021-04-22 19:44:59 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:44:59 --> Controller Class Initialized
INFO - 2021-04-22 19:44:59 --> Form Validation Class Initialized
INFO - 2021-04-22 19:44:59 --> Encrypt Class Initialized
INFO - 2021-04-22 19:44:59 --> Model "Login_model" initialized
INFO - 2021-04-22 19:44:59 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:44:59 --> Model "Case_model" initialized
INFO - 2021-04-22 19:44:59 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:44:59 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/birthday.php
INFO - 2021-04-22 19:44:59 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:44:59 --> Final output sent to browser
DEBUG - 2021-04-22 19:44:59 --> Total execution time: 0.1294
ERROR - 2021-04-22 19:45:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:45:00 --> Config Class Initialized
INFO - 2021-04-22 19:45:00 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:45:00 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:45:00 --> Utf8 Class Initialized
INFO - 2021-04-22 19:45:00 --> URI Class Initialized
INFO - 2021-04-22 19:45:00 --> Router Class Initialized
INFO - 2021-04-22 19:45:00 --> Output Class Initialized
INFO - 2021-04-22 19:45:00 --> Security Class Initialized
DEBUG - 2021-04-22 19:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:45:00 --> Input Class Initialized
INFO - 2021-04-22 19:45:00 --> Language Class Initialized
ERROR - 2021-04-22 19:45:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:45:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:45:08 --> Config Class Initialized
INFO - 2021-04-22 19:45:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:45:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:45:08 --> Utf8 Class Initialized
INFO - 2021-04-22 19:45:08 --> URI Class Initialized
INFO - 2021-04-22 19:45:08 --> Router Class Initialized
INFO - 2021-04-22 19:45:08 --> Output Class Initialized
INFO - 2021-04-22 19:45:08 --> Security Class Initialized
DEBUG - 2021-04-22 19:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:45:08 --> Input Class Initialized
INFO - 2021-04-22 19:45:08 --> Language Class Initialized
INFO - 2021-04-22 19:45:08 --> Loader Class Initialized
INFO - 2021-04-22 19:45:08 --> Helper loaded: url_helper
INFO - 2021-04-22 19:45:08 --> Helper loaded: form_helper
INFO - 2021-04-22 19:45:08 --> Helper loaded: common_helper
INFO - 2021-04-22 19:45:08 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:45:08 --> Controller Class Initialized
INFO - 2021-04-22 19:45:08 --> Form Validation Class Initialized
INFO - 2021-04-22 19:45:08 --> Encrypt Class Initialized
INFO - 2021-04-22 19:45:08 --> Model "Login_model" initialized
INFO - 2021-04-22 19:45:08 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:45:08 --> Model "Case_model" initialized
INFO - 2021-04-22 19:45:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:45:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/birthday.php
INFO - 2021-04-22 19:45:08 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:45:08 --> Final output sent to browser
DEBUG - 2021-04-22 19:45:08 --> Total execution time: 0.0705
ERROR - 2021-04-22 19:45:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:45:08 --> Config Class Initialized
INFO - 2021-04-22 19:45:08 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:45:08 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:45:08 --> Utf8 Class Initialized
INFO - 2021-04-22 19:45:08 --> URI Class Initialized
INFO - 2021-04-22 19:45:08 --> Router Class Initialized
INFO - 2021-04-22 19:45:08 --> Output Class Initialized
INFO - 2021-04-22 19:45:09 --> Security Class Initialized
DEBUG - 2021-04-22 19:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:45:09 --> Input Class Initialized
INFO - 2021-04-22 19:45:09 --> Language Class Initialized
ERROR - 2021-04-22 19:45:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:45:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:45:26 --> Config Class Initialized
INFO - 2021-04-22 19:45:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:45:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:45:26 --> Utf8 Class Initialized
INFO - 2021-04-22 19:45:26 --> URI Class Initialized
INFO - 2021-04-22 19:45:26 --> Router Class Initialized
INFO - 2021-04-22 19:45:26 --> Output Class Initialized
INFO - 2021-04-22 19:45:26 --> Security Class Initialized
DEBUG - 2021-04-22 19:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:45:26 --> Input Class Initialized
INFO - 2021-04-22 19:45:26 --> Language Class Initialized
INFO - 2021-04-22 19:45:26 --> Loader Class Initialized
INFO - 2021-04-22 19:45:26 --> Helper loaded: url_helper
INFO - 2021-04-22 19:45:26 --> Helper loaded: form_helper
INFO - 2021-04-22 19:45:26 --> Helper loaded: common_helper
INFO - 2021-04-22 19:45:26 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:45:26 --> Controller Class Initialized
INFO - 2021-04-22 19:45:26 --> Form Validation Class Initialized
INFO - 2021-04-22 19:45:26 --> Encrypt Class Initialized
INFO - 2021-04-22 19:45:26 --> Model "Login_model" initialized
INFO - 2021-04-22 19:45:26 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:45:26 --> Model "Case_model" initialized
INFO - 2021-04-22 19:45:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:45:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/birthday.php
INFO - 2021-04-22 19:45:26 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:45:26 --> Final output sent to browser
DEBUG - 2021-04-22 19:45:26 --> Total execution time: 0.0591
ERROR - 2021-04-22 19:45:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:45:26 --> Config Class Initialized
INFO - 2021-04-22 19:45:26 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:45:26 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:45:26 --> Utf8 Class Initialized
INFO - 2021-04-22 19:45:26 --> URI Class Initialized
INFO - 2021-04-22 19:45:26 --> Router Class Initialized
INFO - 2021-04-22 19:45:26 --> Output Class Initialized
INFO - 2021-04-22 19:45:26 --> Security Class Initialized
DEBUG - 2021-04-22 19:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:45:26 --> Input Class Initialized
INFO - 2021-04-22 19:45:26 --> Language Class Initialized
ERROR - 2021-04-22 19:45:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:45:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:45:42 --> Config Class Initialized
INFO - 2021-04-22 19:45:42 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:45:42 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:45:42 --> Utf8 Class Initialized
INFO - 2021-04-22 19:45:42 --> URI Class Initialized
INFO - 2021-04-22 19:45:42 --> Router Class Initialized
INFO - 2021-04-22 19:45:42 --> Output Class Initialized
INFO - 2021-04-22 19:45:42 --> Security Class Initialized
DEBUG - 2021-04-22 19:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:45:42 --> Input Class Initialized
INFO - 2021-04-22 19:45:42 --> Language Class Initialized
INFO - 2021-04-22 19:45:42 --> Loader Class Initialized
INFO - 2021-04-22 19:45:42 --> Helper loaded: url_helper
INFO - 2021-04-22 19:45:42 --> Helper loaded: form_helper
INFO - 2021-04-22 19:45:42 --> Helper loaded: common_helper
INFO - 2021-04-22 19:45:42 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:45:42 --> Controller Class Initialized
INFO - 2021-04-22 19:45:42 --> Form Validation Class Initialized
INFO - 2021-04-22 19:45:42 --> Encrypt Class Initialized
INFO - 2021-04-22 19:45:42 --> Model "Login_model" initialized
INFO - 2021-04-22 19:45:42 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:45:42 --> Model "Case_model" initialized
INFO - 2021-04-22 19:45:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:45:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/birthday.php
INFO - 2021-04-22 19:45:42 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:45:42 --> Final output sent to browser
DEBUG - 2021-04-22 19:45:42 --> Total execution time: 0.0671
ERROR - 2021-04-22 19:45:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:45:53 --> Config Class Initialized
INFO - 2021-04-22 19:45:53 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:45:53 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:45:53 --> Utf8 Class Initialized
INFO - 2021-04-22 19:45:53 --> URI Class Initialized
INFO - 2021-04-22 19:45:53 --> Router Class Initialized
INFO - 2021-04-22 19:45:53 --> Output Class Initialized
INFO - 2021-04-22 19:45:53 --> Security Class Initialized
DEBUG - 2021-04-22 19:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:45:53 --> Input Class Initialized
INFO - 2021-04-22 19:45:53 --> Language Class Initialized
ERROR - 2021-04-22 19:45:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:48:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:48:28 --> Config Class Initialized
INFO - 2021-04-22 19:48:28 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:48:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:48:28 --> Utf8 Class Initialized
INFO - 2021-04-22 19:48:28 --> URI Class Initialized
INFO - 2021-04-22 19:48:28 --> Router Class Initialized
INFO - 2021-04-22 19:48:28 --> Output Class Initialized
INFO - 2021-04-22 19:48:28 --> Security Class Initialized
DEBUG - 2021-04-22 19:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:48:28 --> Input Class Initialized
INFO - 2021-04-22 19:48:28 --> Language Class Initialized
INFO - 2021-04-22 19:48:28 --> Loader Class Initialized
INFO - 2021-04-22 19:48:28 --> Helper loaded: url_helper
INFO - 2021-04-22 19:48:28 --> Helper loaded: form_helper
INFO - 2021-04-22 19:48:28 --> Helper loaded: common_helper
INFO - 2021-04-22 19:48:28 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:48:28 --> Controller Class Initialized
INFO - 2021-04-22 19:48:28 --> Form Validation Class Initialized
INFO - 2021-04-22 19:48:28 --> Encrypt Class Initialized
INFO - 2021-04-22 19:48:28 --> Model "Login_model" initialized
INFO - 2021-04-22 19:48:28 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:48:28 --> Model "Case_model" initialized
INFO - 2021-04-22 19:48:28 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:48:28 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/birthday.php
INFO - 2021-04-22 19:48:28 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:48:28 --> Final output sent to browser
DEBUG - 2021-04-22 19:48:28 --> Total execution time: 0.0735
ERROR - 2021-04-22 19:48:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:48:28 --> Config Class Initialized
INFO - 2021-04-22 19:48:28 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:48:28 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:48:28 --> Utf8 Class Initialized
INFO - 2021-04-22 19:48:28 --> URI Class Initialized
INFO - 2021-04-22 19:48:28 --> Router Class Initialized
INFO - 2021-04-22 19:48:28 --> Output Class Initialized
INFO - 2021-04-22 19:48:28 --> Security Class Initialized
DEBUG - 2021-04-22 19:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:48:28 --> Input Class Initialized
INFO - 2021-04-22 19:48:28 --> Language Class Initialized
ERROR - 2021-04-22 19:48:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:49:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:49:01 --> Config Class Initialized
INFO - 2021-04-22 19:49:01 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:49:01 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:49:01 --> Utf8 Class Initialized
INFO - 2021-04-22 19:49:01 --> URI Class Initialized
INFO - 2021-04-22 19:49:01 --> Router Class Initialized
INFO - 2021-04-22 19:49:01 --> Output Class Initialized
INFO - 2021-04-22 19:49:01 --> Security Class Initialized
DEBUG - 2021-04-22 19:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:49:01 --> Input Class Initialized
INFO - 2021-04-22 19:49:01 --> Language Class Initialized
INFO - 2021-04-22 19:49:01 --> Loader Class Initialized
INFO - 2021-04-22 19:49:01 --> Helper loaded: url_helper
INFO - 2021-04-22 19:49:01 --> Helper loaded: form_helper
INFO - 2021-04-22 19:49:01 --> Helper loaded: common_helper
INFO - 2021-04-22 19:49:01 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:49:01 --> Controller Class Initialized
INFO - 2021-04-22 19:49:01 --> Form Validation Class Initialized
INFO - 2021-04-22 19:49:01 --> Encrypt Class Initialized
INFO - 2021-04-22 19:49:01 --> Model "Login_model" initialized
INFO - 2021-04-22 19:49:01 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:49:01 --> Model "Case_model" initialized
INFO - 2021-04-22 19:49:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:49:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/birthday.php
INFO - 2021-04-22 19:49:01 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:49:01 --> Final output sent to browser
DEBUG - 2021-04-22 19:49:01 --> Total execution time: 0.0827
ERROR - 2021-04-22 19:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:49:02 --> Config Class Initialized
INFO - 2021-04-22 19:49:02 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:49:02 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:49:02 --> Utf8 Class Initialized
INFO - 2021-04-22 19:49:02 --> URI Class Initialized
INFO - 2021-04-22 19:49:02 --> Router Class Initialized
INFO - 2021-04-22 19:49:02 --> Output Class Initialized
INFO - 2021-04-22 19:49:02 --> Security Class Initialized
DEBUG - 2021-04-22 19:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:49:02 --> Input Class Initialized
INFO - 2021-04-22 19:49:02 --> Language Class Initialized
ERROR - 2021-04-22 19:49:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:49:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:49:15 --> Config Class Initialized
INFO - 2021-04-22 19:49:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:49:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:49:15 --> Utf8 Class Initialized
INFO - 2021-04-22 19:49:15 --> URI Class Initialized
INFO - 2021-04-22 19:49:15 --> Router Class Initialized
INFO - 2021-04-22 19:49:15 --> Output Class Initialized
INFO - 2021-04-22 19:49:15 --> Security Class Initialized
DEBUG - 2021-04-22 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:49:15 --> Input Class Initialized
INFO - 2021-04-22 19:49:15 --> Language Class Initialized
INFO - 2021-04-22 19:49:15 --> Loader Class Initialized
INFO - 2021-04-22 19:49:15 --> Helper loaded: url_helper
INFO - 2021-04-22 19:49:15 --> Helper loaded: form_helper
INFO - 2021-04-22 19:49:15 --> Helper loaded: common_helper
INFO - 2021-04-22 19:49:15 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:49:15 --> Controller Class Initialized
INFO - 2021-04-22 19:49:15 --> Form Validation Class Initialized
INFO - 2021-04-22 19:49:15 --> Encrypt Class Initialized
INFO - 2021-04-22 19:49:15 --> Model "Login_model" initialized
INFO - 2021-04-22 19:49:15 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:49:15 --> Model "Case_model" initialized
INFO - 2021-04-22 19:49:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:49:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/birthday.php
INFO - 2021-04-22 19:49:15 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:49:15 --> Final output sent to browser
DEBUG - 2021-04-22 19:49:15 --> Total execution time: 0.0716
ERROR - 2021-04-22 19:49:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:49:15 --> Config Class Initialized
INFO - 2021-04-22 19:49:15 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:49:15 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:49:15 --> Utf8 Class Initialized
INFO - 2021-04-22 19:49:15 --> URI Class Initialized
INFO - 2021-04-22 19:49:15 --> Router Class Initialized
INFO - 2021-04-22 19:49:15 --> Output Class Initialized
INFO - 2021-04-22 19:49:15 --> Security Class Initialized
DEBUG - 2021-04-22 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:49:15 --> Input Class Initialized
INFO - 2021-04-22 19:49:15 --> Language Class Initialized
ERROR - 2021-04-22 19:49:15 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-04-22 19:57:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:57:30 --> Config Class Initialized
INFO - 2021-04-22 19:57:30 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:57:30 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:57:30 --> Utf8 Class Initialized
INFO - 2021-04-22 19:57:30 --> URI Class Initialized
INFO - 2021-04-22 19:57:30 --> Router Class Initialized
INFO - 2021-04-22 19:57:30 --> Output Class Initialized
INFO - 2021-04-22 19:57:30 --> Security Class Initialized
DEBUG - 2021-04-22 19:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:57:30 --> Input Class Initialized
INFO - 2021-04-22 19:57:30 --> Language Class Initialized
INFO - 2021-04-22 19:57:30 --> Loader Class Initialized
INFO - 2021-04-22 19:57:30 --> Helper loaded: url_helper
INFO - 2021-04-22 19:57:30 --> Helper loaded: form_helper
INFO - 2021-04-22 19:57:30 --> Helper loaded: common_helper
INFO - 2021-04-22 19:57:30 --> Database Driver Class Initialized
DEBUG - 2021-04-22 19:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-22 19:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-22 19:57:30 --> Controller Class Initialized
INFO - 2021-04-22 19:57:30 --> Form Validation Class Initialized
INFO - 2021-04-22 19:57:30 --> Encrypt Class Initialized
INFO - 2021-04-22 19:57:30 --> Model "Login_model" initialized
INFO - 2021-04-22 19:57:30 --> Model "Dashboard_model" initialized
INFO - 2021-04-22 19:57:30 --> Model "Case_model" initialized
INFO - 2021-04-22 19:57:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-04-22 19:57:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/birthday.php
INFO - 2021-04-22 19:57:30 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-04-22 19:57:30 --> Final output sent to browser
DEBUG - 2021-04-22 19:57:30 --> Total execution time: 0.0582
ERROR - 2021-04-22 19:57:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-04-22 19:57:30 --> Config Class Initialized
INFO - 2021-04-22 19:57:30 --> Hooks Class Initialized
DEBUG - 2021-04-22 19:57:30 --> UTF-8 Support Enabled
INFO - 2021-04-22 19:57:30 --> Utf8 Class Initialized
INFO - 2021-04-22 19:57:30 --> URI Class Initialized
INFO - 2021-04-22 19:57:30 --> Router Class Initialized
INFO - 2021-04-22 19:57:30 --> Output Class Initialized
INFO - 2021-04-22 19:57:30 --> Security Class Initialized
DEBUG - 2021-04-22 19:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-22 19:57:30 --> Input Class Initialized
INFO - 2021-04-22 19:57:30 --> Language Class Initialized
ERROR - 2021-04-22 19:57:30 --> 404 Page Not Found: Karoclient/usersprofile
