<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-27 03:40:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-27 03:40:42 --> Config Class Initialized
INFO - 2021-07-27 03:40:42 --> Hooks Class Initialized
DEBUG - 2021-07-27 03:40:42 --> UTF-8 Support Enabled
INFO - 2021-07-27 03:40:42 --> Utf8 Class Initialized
INFO - 2021-07-27 03:40:42 --> URI Class Initialized
DEBUG - 2021-07-27 03:40:42 --> No URI present. Default controller set.
INFO - 2021-07-27 03:40:42 --> Router Class Initialized
INFO - 2021-07-27 03:40:42 --> Output Class Initialized
INFO - 2021-07-27 03:40:42 --> Security Class Initialized
DEBUG - 2021-07-27 03:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-27 03:40:42 --> Input Class Initialized
INFO - 2021-07-27 03:40:42 --> Language Class Initialized
INFO - 2021-07-27 03:40:42 --> Loader Class Initialized
INFO - 2021-07-27 03:40:42 --> Helper loaded: url_helper
INFO - 2021-07-27 03:40:42 --> Helper loaded: form_helper
INFO - 2021-07-27 03:40:42 --> Helper loaded: common_helper
INFO - 2021-07-27 03:40:42 --> Database Driver Class Initialized
DEBUG - 2021-07-27 03:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-27 03:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-27 03:40:42 --> Controller Class Initialized
INFO - 2021-07-27 03:40:42 --> Form Validation Class Initialized
DEBUG - 2021-07-27 03:40:42 --> Encrypt Class Initialized
DEBUG - 2021-07-27 03:40:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-27 03:40:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-27 03:40:42 --> Email Class Initialized
INFO - 2021-07-27 03:40:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-27 03:40:42 --> Calendar Class Initialized
INFO - 2021-07-27 03:40:42 --> Model "Login_model" initialized
INFO - 2021-07-27 03:40:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-27 03:40:42 --> Final output sent to browser
DEBUG - 2021-07-27 03:40:42 --> Total execution time: 0.0441
ERROR - 2021-07-27 05:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-27 05:17:02 --> Config Class Initialized
INFO - 2021-07-27 05:17:02 --> Hooks Class Initialized
DEBUG - 2021-07-27 05:17:02 --> UTF-8 Support Enabled
INFO - 2021-07-27 05:17:02 --> Utf8 Class Initialized
INFO - 2021-07-27 05:17:02 --> URI Class Initialized
DEBUG - 2021-07-27 05:17:02 --> No URI present. Default controller set.
INFO - 2021-07-27 05:17:02 --> Router Class Initialized
INFO - 2021-07-27 05:17:02 --> Output Class Initialized
INFO - 2021-07-27 05:17:02 --> Security Class Initialized
DEBUG - 2021-07-27 05:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-27 05:17:02 --> Input Class Initialized
INFO - 2021-07-27 05:17:02 --> Language Class Initialized
INFO - 2021-07-27 05:17:02 --> Loader Class Initialized
INFO - 2021-07-27 05:17:02 --> Helper loaded: url_helper
INFO - 2021-07-27 05:17:02 --> Helper loaded: form_helper
INFO - 2021-07-27 05:17:02 --> Helper loaded: common_helper
INFO - 2021-07-27 05:17:02 --> Database Driver Class Initialized
DEBUG - 2021-07-27 05:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-27 05:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-27 05:17:02 --> Controller Class Initialized
INFO - 2021-07-27 05:17:02 --> Form Validation Class Initialized
DEBUG - 2021-07-27 05:17:02 --> Encrypt Class Initialized
DEBUG - 2021-07-27 05:17:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-27 05:17:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-27 05:17:03 --> Email Class Initialized
INFO - 2021-07-27 05:17:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-27 05:17:03 --> Calendar Class Initialized
INFO - 2021-07-27 05:17:03 --> Model "Login_model" initialized
INFO - 2021-07-27 05:17:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-27 05:17:03 --> Final output sent to browser
DEBUG - 2021-07-27 05:17:03 --> Total execution time: 0.0920
