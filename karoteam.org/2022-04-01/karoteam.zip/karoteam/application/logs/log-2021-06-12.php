<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-12 09:17:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:17:05 --> Config Class Initialized
INFO - 2021-06-12 09:17:05 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:17:05 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:17:05 --> Utf8 Class Initialized
INFO - 2021-06-12 09:17:05 --> URI Class Initialized
DEBUG - 2021-06-12 09:17:05 --> No URI present. Default controller set.
INFO - 2021-06-12 09:17:05 --> Router Class Initialized
INFO - 2021-06-12 09:17:05 --> Output Class Initialized
INFO - 2021-06-12 09:17:05 --> Security Class Initialized
DEBUG - 2021-06-12 09:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:17:05 --> Input Class Initialized
INFO - 2021-06-12 09:17:05 --> Language Class Initialized
INFO - 2021-06-12 09:17:05 --> Loader Class Initialized
INFO - 2021-06-12 09:17:05 --> Helper loaded: url_helper
INFO - 2021-06-12 09:17:05 --> Helper loaded: form_helper
INFO - 2021-06-12 09:17:05 --> Helper loaded: common_helper
INFO - 2021-06-12 09:17:05 --> Database Driver Class Initialized
DEBUG - 2021-06-12 09:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 09:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 09:17:05 --> Controller Class Initialized
INFO - 2021-06-12 09:17:05 --> Form Validation Class Initialized
DEBUG - 2021-06-12 09:17:05 --> Encrypt Class Initialized
DEBUG - 2021-06-12 09:17:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-12 09:17:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-12 09:17:05 --> Email Class Initialized
INFO - 2021-06-12 09:17:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-12 09:17:05 --> Calendar Class Initialized
INFO - 2021-06-12 09:17:05 --> Model "Login_model" initialized
INFO - 2021-06-12 09:17:05 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-12 09:17:05 --> Final output sent to browser
DEBUG - 2021-06-12 09:17:05 --> Total execution time: 0.0360
ERROR - 2021-06-12 09:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:17:07 --> Config Class Initialized
INFO - 2021-06-12 09:17:07 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:17:07 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:17:07 --> Utf8 Class Initialized
INFO - 2021-06-12 09:17:07 --> URI Class Initialized
INFO - 2021-06-12 09:17:07 --> Router Class Initialized
INFO - 2021-06-12 09:17:07 --> Output Class Initialized
INFO - 2021-06-12 09:17:07 --> Security Class Initialized
DEBUG - 2021-06-12 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:17:07 --> Input Class Initialized
INFO - 2021-06-12 09:17:07 --> Language Class Initialized
ERROR - 2021-06-12 09:17:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-12 09:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:17:27 --> Config Class Initialized
INFO - 2021-06-12 09:17:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:17:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:17:27 --> Utf8 Class Initialized
INFO - 2021-06-12 09:17:27 --> URI Class Initialized
INFO - 2021-06-12 09:17:27 --> Router Class Initialized
INFO - 2021-06-12 09:17:27 --> Output Class Initialized
INFO - 2021-06-12 09:17:27 --> Security Class Initialized
DEBUG - 2021-06-12 09:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:17:27 --> Input Class Initialized
INFO - 2021-06-12 09:17:27 --> Language Class Initialized
INFO - 2021-06-12 09:17:27 --> Loader Class Initialized
INFO - 2021-06-12 09:17:27 --> Helper loaded: url_helper
INFO - 2021-06-12 09:17:27 --> Helper loaded: form_helper
INFO - 2021-06-12 09:17:27 --> Helper loaded: common_helper
INFO - 2021-06-12 09:17:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 09:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 09:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 09:17:27 --> Controller Class Initialized
INFO - 2021-06-12 09:17:27 --> Form Validation Class Initialized
DEBUG - 2021-06-12 09:17:27 --> Encrypt Class Initialized
DEBUG - 2021-06-12 09:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-12 09:17:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-12 09:17:27 --> Email Class Initialized
INFO - 2021-06-12 09:17:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-12 09:17:27 --> Calendar Class Initialized
INFO - 2021-06-12 09:17:27 --> Model "Login_model" initialized
INFO - 2021-06-12 09:17:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-12 09:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:17:27 --> Config Class Initialized
INFO - 2021-06-12 09:17:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:17:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:17:27 --> Utf8 Class Initialized
INFO - 2021-06-12 09:17:27 --> URI Class Initialized
INFO - 2021-06-12 09:17:27 --> Router Class Initialized
INFO - 2021-06-12 09:17:27 --> Output Class Initialized
INFO - 2021-06-12 09:17:27 --> Security Class Initialized
DEBUG - 2021-06-12 09:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:17:27 --> Input Class Initialized
INFO - 2021-06-12 09:17:27 --> Language Class Initialized
INFO - 2021-06-12 09:17:27 --> Loader Class Initialized
INFO - 2021-06-12 09:17:27 --> Helper loaded: url_helper
INFO - 2021-06-12 09:17:27 --> Helper loaded: form_helper
INFO - 2021-06-12 09:17:27 --> Helper loaded: common_helper
INFO - 2021-06-12 09:17:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 09:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 09:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 09:17:27 --> Controller Class Initialized
INFO - 2021-06-12 09:17:27 --> Form Validation Class Initialized
DEBUG - 2021-06-12 09:17:27 --> Encrypt Class Initialized
INFO - 2021-06-12 09:17:27 --> Model "Login_model" initialized
INFO - 2021-06-12 09:17:27 --> Model "Dashboard_model" initialized
INFO - 2021-06-12 09:17:27 --> Model "Case_model" initialized
INFO - 2021-06-12 09:17:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-12 09:17:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-12 09:17:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-12 09:17:37 --> Final output sent to browser
DEBUG - 2021-06-12 09:17:37 --> Total execution time: 9.2323
ERROR - 2021-06-12 09:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:17:37 --> Config Class Initialized
INFO - 2021-06-12 09:17:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:17:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:17:37 --> Utf8 Class Initialized
INFO - 2021-06-12 09:17:37 --> URI Class Initialized
INFO - 2021-06-12 09:17:37 --> Router Class Initialized
INFO - 2021-06-12 09:17:37 --> Output Class Initialized
INFO - 2021-06-12 09:17:37 --> Security Class Initialized
DEBUG - 2021-06-12 09:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:17:37 --> Input Class Initialized
INFO - 2021-06-12 09:17:37 --> Language Class Initialized
ERROR - 2021-06-12 09:17:37 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-12 09:19:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:19:30 --> Config Class Initialized
INFO - 2021-06-12 09:19:30 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:19:30 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:19:30 --> Utf8 Class Initialized
INFO - 2021-06-12 09:19:30 --> URI Class Initialized
INFO - 2021-06-12 09:19:30 --> Router Class Initialized
INFO - 2021-06-12 09:19:30 --> Output Class Initialized
INFO - 2021-06-12 09:19:30 --> Security Class Initialized
DEBUG - 2021-06-12 09:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:19:30 --> Input Class Initialized
INFO - 2021-06-12 09:19:30 --> Language Class Initialized
INFO - 2021-06-12 09:19:30 --> Loader Class Initialized
INFO - 2021-06-12 09:19:30 --> Helper loaded: url_helper
INFO - 2021-06-12 09:19:30 --> Helper loaded: form_helper
INFO - 2021-06-12 09:19:30 --> Helper loaded: common_helper
INFO - 2021-06-12 09:19:30 --> Database Driver Class Initialized
DEBUG - 2021-06-12 09:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 09:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 09:19:30 --> Controller Class Initialized
INFO - 2021-06-12 09:19:30 --> Form Validation Class Initialized
DEBUG - 2021-06-12 09:19:30 --> Encrypt Class Initialized
INFO - 2021-06-12 09:19:30 --> Model "Patient_model" initialized
INFO - 2021-06-12 09:19:30 --> Model "Patientcase_model" initialized
INFO - 2021-06-12 09:19:30 --> Model "Referredby_model" initialized
INFO - 2021-06-12 09:19:30 --> Model "Prefix_master" initialized
INFO - 2021-06-12 09:19:30 --> Model "Hospital_model" initialized
INFO - 2021-06-12 09:19:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-12 09:19:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/index.php
INFO - 2021-06-12 09:19:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-12 09:19:30 --> Final output sent to browser
DEBUG - 2021-06-12 09:19:30 --> Total execution time: 0.0299
ERROR - 2021-06-12 09:19:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:19:31 --> Config Class Initialized
INFO - 2021-06-12 09:19:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:19:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:19:31 --> Utf8 Class Initialized
INFO - 2021-06-12 09:19:31 --> URI Class Initialized
INFO - 2021-06-12 09:19:31 --> Router Class Initialized
INFO - 2021-06-12 09:19:31 --> Output Class Initialized
INFO - 2021-06-12 09:19:31 --> Security Class Initialized
DEBUG - 2021-06-12 09:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:19:31 --> Input Class Initialized
INFO - 2021-06-12 09:19:31 --> Language Class Initialized
INFO - 2021-06-12 09:19:31 --> Loader Class Initialized
INFO - 2021-06-12 09:19:31 --> Helper loaded: url_helper
INFO - 2021-06-12 09:19:31 --> Helper loaded: form_helper
INFO - 2021-06-12 09:19:31 --> Helper loaded: common_helper
INFO - 2021-06-12 09:19:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 09:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 09:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 09:19:31 --> Controller Class Initialized
INFO - 2021-06-12 09:19:31 --> Form Validation Class Initialized
DEBUG - 2021-06-12 09:19:31 --> Encrypt Class Initialized
INFO - 2021-06-12 09:19:31 --> Model "Patient_model" initialized
INFO - 2021-06-12 09:19:31 --> Model "Patientcase_model" initialized
INFO - 2021-06-12 09:19:31 --> Model "Referredby_model" initialized
INFO - 2021-06-12 09:19:31 --> Model "Prefix_master" initialized
INFO - 2021-06-12 09:19:31 --> Model "Hospital_model" initialized
INFO - 2021-06-12 09:19:31 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-12 09:19:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-12 09:19:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-12 09:19:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:19:35 --> Config Class Initialized
INFO - 2021-06-12 09:19:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:19:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:19:35 --> Utf8 Class Initialized
INFO - 2021-06-12 09:19:35 --> URI Class Initialized
INFO - 2021-06-12 09:19:35 --> Router Class Initialized
INFO - 2021-06-12 09:19:35 --> Output Class Initialized
INFO - 2021-06-12 09:19:35 --> Security Class Initialized
DEBUG - 2021-06-12 09:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:19:35 --> Input Class Initialized
INFO - 2021-06-12 09:19:35 --> Language Class Initialized
ERROR - 2021-06-12 09:19:35 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-12 09:19:36 --> Final output sent to browser
DEBUG - 2021-06-12 09:19:36 --> Total execution time: 4.0237
ERROR - 2021-06-12 09:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:19:42 --> Config Class Initialized
INFO - 2021-06-12 09:19:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:19:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:19:42 --> Utf8 Class Initialized
INFO - 2021-06-12 09:19:42 --> URI Class Initialized
INFO - 2021-06-12 09:19:42 --> Router Class Initialized
INFO - 2021-06-12 09:19:42 --> Output Class Initialized
INFO - 2021-06-12 09:19:42 --> Security Class Initialized
DEBUG - 2021-06-12 09:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:19:42 --> Input Class Initialized
INFO - 2021-06-12 09:19:42 --> Language Class Initialized
INFO - 2021-06-12 09:19:42 --> Loader Class Initialized
INFO - 2021-06-12 09:19:42 --> Helper loaded: url_helper
INFO - 2021-06-12 09:19:42 --> Helper loaded: form_helper
INFO - 2021-06-12 09:19:42 --> Helper loaded: common_helper
INFO - 2021-06-12 09:19:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 09:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 09:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 09:19:42 --> Controller Class Initialized
INFO - 2021-06-12 09:19:42 --> Form Validation Class Initialized
DEBUG - 2021-06-12 09:19:42 --> Encrypt Class Initialized
INFO - 2021-06-12 09:19:42 --> Model "Patient_model" initialized
INFO - 2021-06-12 09:19:42 --> Model "Patientcase_model" initialized
INFO - 2021-06-12 09:19:42 --> Model "Prefix_master" initialized
INFO - 2021-06-12 09:19:42 --> Model "Users_model" initialized
INFO - 2021-06-12 09:19:42 --> Model "Hospital_model" initialized
INFO - 2021-06-12 09:19:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-12 09:19:43 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found /home1/techywbu/karo.notioninfosoft.com/application/controllers/Patientcase.php 496
ERROR - 2021-06-12 09:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 09:19:44 --> Config Class Initialized
INFO - 2021-06-12 09:19:44 --> Hooks Class Initialized
DEBUG - 2021-06-12 09:19:44 --> UTF-8 Support Enabled
INFO - 2021-06-12 09:19:44 --> Utf8 Class Initialized
INFO - 2021-06-12 09:19:44 --> URI Class Initialized
INFO - 2021-06-12 09:19:44 --> Router Class Initialized
INFO - 2021-06-12 09:19:44 --> Output Class Initialized
INFO - 2021-06-12 09:19:44 --> Security Class Initialized
DEBUG - 2021-06-12 09:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 09:19:44 --> Input Class Initialized
INFO - 2021-06-12 09:19:44 --> Language Class Initialized
ERROR - 2021-06-12 09:19:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-12 10:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-12 10:23:45 --> Config Class Initialized
INFO - 2021-06-12 10:23:45 --> Hooks Class Initialized
DEBUG - 2021-06-12 10:23:45 --> UTF-8 Support Enabled
INFO - 2021-06-12 10:23:45 --> Utf8 Class Initialized
INFO - 2021-06-12 10:23:45 --> URI Class Initialized
DEBUG - 2021-06-12 10:23:45 --> No URI present. Default controller set.
INFO - 2021-06-12 10:23:45 --> Router Class Initialized
INFO - 2021-06-12 10:23:45 --> Output Class Initialized
INFO - 2021-06-12 10:23:45 --> Security Class Initialized
DEBUG - 2021-06-12 10:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 10:23:45 --> Input Class Initialized
INFO - 2021-06-12 10:23:45 --> Language Class Initialized
INFO - 2021-06-12 10:23:45 --> Loader Class Initialized
INFO - 2021-06-12 10:23:45 --> Helper loaded: url_helper
INFO - 2021-06-12 10:23:45 --> Helper loaded: form_helper
INFO - 2021-06-12 10:23:45 --> Helper loaded: common_helper
INFO - 2021-06-12 10:23:45 --> Database Driver Class Initialized
DEBUG - 2021-06-12 10:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 10:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 10:23:45 --> Controller Class Initialized
INFO - 2021-06-12 10:23:45 --> Form Validation Class Initialized
DEBUG - 2021-06-12 10:23:45 --> Encrypt Class Initialized
DEBUG - 2021-06-12 10:23:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-12 10:23:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-12 10:23:45 --> Email Class Initialized
INFO - 2021-06-12 10:23:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-12 10:23:45 --> Calendar Class Initialized
INFO - 2021-06-12 10:23:45 --> Model "Login_model" initialized
INFO - 2021-06-12 10:23:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-12 10:23:45 --> Final output sent to browser
DEBUG - 2021-06-12 10:23:45 --> Total execution time: 0.0402
