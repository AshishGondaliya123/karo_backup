<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-15 01:42:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 01:42:06 --> Config Class Initialized
INFO - 2021-06-15 01:42:06 --> Hooks Class Initialized
DEBUG - 2021-06-15 01:42:06 --> UTF-8 Support Enabled
INFO - 2021-06-15 01:42:06 --> Utf8 Class Initialized
INFO - 2021-06-15 01:42:06 --> URI Class Initialized
DEBUG - 2021-06-15 01:42:06 --> No URI present. Default controller set.
INFO - 2021-06-15 01:42:06 --> Router Class Initialized
INFO - 2021-06-15 01:42:06 --> Output Class Initialized
INFO - 2021-06-15 01:42:06 --> Security Class Initialized
DEBUG - 2021-06-15 01:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 01:42:06 --> Input Class Initialized
INFO - 2021-06-15 01:42:06 --> Language Class Initialized
INFO - 2021-06-15 01:42:06 --> Loader Class Initialized
INFO - 2021-06-15 01:42:06 --> Helper loaded: url_helper
INFO - 2021-06-15 01:42:06 --> Helper loaded: form_helper
INFO - 2021-06-15 01:42:06 --> Helper loaded: common_helper
INFO - 2021-06-15 01:42:06 --> Database Driver Class Initialized
DEBUG - 2021-06-15 01:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 01:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 01:42:06 --> Controller Class Initialized
INFO - 2021-06-15 01:42:06 --> Form Validation Class Initialized
DEBUG - 2021-06-15 01:42:06 --> Encrypt Class Initialized
DEBUG - 2021-06-15 01:42:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 01:42:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 01:42:06 --> Email Class Initialized
INFO - 2021-06-15 01:42:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 01:42:06 --> Calendar Class Initialized
INFO - 2021-06-15 01:42:06 --> Model "Login_model" initialized
INFO - 2021-06-15 01:42:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 01:42:06 --> Final output sent to browser
DEBUG - 2021-06-15 01:42:06 --> Total execution time: 0.0413
ERROR - 2021-06-15 03:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 03:39:00 --> Config Class Initialized
INFO - 2021-06-15 03:39:00 --> Hooks Class Initialized
DEBUG - 2021-06-15 03:39:00 --> UTF-8 Support Enabled
INFO - 2021-06-15 03:39:00 --> Utf8 Class Initialized
INFO - 2021-06-15 03:39:00 --> URI Class Initialized
DEBUG - 2021-06-15 03:39:00 --> No URI present. Default controller set.
INFO - 2021-06-15 03:39:00 --> Router Class Initialized
INFO - 2021-06-15 03:39:00 --> Output Class Initialized
INFO - 2021-06-15 03:39:00 --> Security Class Initialized
DEBUG - 2021-06-15 03:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 03:39:00 --> Input Class Initialized
INFO - 2021-06-15 03:39:00 --> Language Class Initialized
INFO - 2021-06-15 03:39:00 --> Loader Class Initialized
INFO - 2021-06-15 03:39:00 --> Helper loaded: url_helper
INFO - 2021-06-15 03:39:00 --> Helper loaded: form_helper
INFO - 2021-06-15 03:39:00 --> Helper loaded: common_helper
INFO - 2021-06-15 03:39:00 --> Database Driver Class Initialized
DEBUG - 2021-06-15 03:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 03:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 03:39:00 --> Controller Class Initialized
INFO - 2021-06-15 03:39:00 --> Form Validation Class Initialized
DEBUG - 2021-06-15 03:39:00 --> Encrypt Class Initialized
DEBUG - 2021-06-15 03:39:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 03:39:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 03:39:00 --> Email Class Initialized
INFO - 2021-06-15 03:39:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 03:39:00 --> Calendar Class Initialized
INFO - 2021-06-15 03:39:00 --> Model "Login_model" initialized
INFO - 2021-06-15 03:39:00 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 03:39:00 --> Final output sent to browser
DEBUG - 2021-06-15 03:39:00 --> Total execution time: 0.0361
ERROR - 2021-06-15 07:50:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 07:50:42 --> Config Class Initialized
INFO - 2021-06-15 07:50:42 --> Hooks Class Initialized
DEBUG - 2021-06-15 07:50:42 --> UTF-8 Support Enabled
INFO - 2021-06-15 07:50:42 --> Utf8 Class Initialized
INFO - 2021-06-15 07:50:42 --> URI Class Initialized
DEBUG - 2021-06-15 07:50:42 --> No URI present. Default controller set.
INFO - 2021-06-15 07:50:42 --> Router Class Initialized
INFO - 2021-06-15 07:50:42 --> Output Class Initialized
INFO - 2021-06-15 07:50:42 --> Security Class Initialized
DEBUG - 2021-06-15 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 07:50:42 --> Input Class Initialized
INFO - 2021-06-15 07:50:42 --> Language Class Initialized
INFO - 2021-06-15 07:50:42 --> Loader Class Initialized
INFO - 2021-06-15 07:50:42 --> Helper loaded: url_helper
INFO - 2021-06-15 07:50:42 --> Helper loaded: form_helper
INFO - 2021-06-15 07:50:42 --> Helper loaded: common_helper
INFO - 2021-06-15 07:50:42 --> Database Driver Class Initialized
DEBUG - 2021-06-15 07:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 07:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 07:50:42 --> Controller Class Initialized
INFO - 2021-06-15 07:50:42 --> Form Validation Class Initialized
DEBUG - 2021-06-15 07:50:42 --> Encrypt Class Initialized
DEBUG - 2021-06-15 07:50:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 07:50:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 07:50:42 --> Email Class Initialized
INFO - 2021-06-15 07:50:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 07:50:42 --> Calendar Class Initialized
INFO - 2021-06-15 07:50:42 --> Model "Login_model" initialized
INFO - 2021-06-15 07:50:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 07:50:42 --> Final output sent to browser
DEBUG - 2021-06-15 07:50:42 --> Total execution time: 0.1128
ERROR - 2021-06-15 14:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:19:59 --> Config Class Initialized
INFO - 2021-06-15 14:19:59 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:19:59 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:19:59 --> Utf8 Class Initialized
INFO - 2021-06-15 14:19:59 --> URI Class Initialized
INFO - 2021-06-15 14:19:59 --> Router Class Initialized
INFO - 2021-06-15 14:19:59 --> Output Class Initialized
INFO - 2021-06-15 14:19:59 --> Security Class Initialized
DEBUG - 2021-06-15 14:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:19:59 --> Input Class Initialized
INFO - 2021-06-15 14:19:59 --> Language Class Initialized
ERROR - 2021-06-15 14:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-15 14:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:00 --> Config Class Initialized
INFO - 2021-06-15 14:20:00 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:00 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:00 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:00 --> URI Class Initialized
DEBUG - 2021-06-15 14:20:00 --> No URI present. Default controller set.
INFO - 2021-06-15 14:20:00 --> Router Class Initialized
INFO - 2021-06-15 14:20:00 --> Output Class Initialized
INFO - 2021-06-15 14:20:00 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:00 --> Input Class Initialized
INFO - 2021-06-15 14:20:00 --> Language Class Initialized
INFO - 2021-06-15 14:20:00 --> Loader Class Initialized
INFO - 2021-06-15 14:20:00 --> Helper loaded: url_helper
INFO - 2021-06-15 14:20:00 --> Helper loaded: form_helper
INFO - 2021-06-15 14:20:00 --> Helper loaded: common_helper
INFO - 2021-06-15 14:20:00 --> Database Driver Class Initialized
DEBUG - 2021-06-15 14:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 14:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 14:20:00 --> Controller Class Initialized
INFO - 2021-06-15 14:20:00 --> Form Validation Class Initialized
DEBUG - 2021-06-15 14:20:00 --> Encrypt Class Initialized
DEBUG - 2021-06-15 14:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 14:20:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 14:20:00 --> Email Class Initialized
INFO - 2021-06-15 14:20:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 14:20:00 --> Calendar Class Initialized
INFO - 2021-06-15 14:20:00 --> Model "Login_model" initialized
INFO - 2021-06-15 14:20:00 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 14:20:00 --> Final output sent to browser
DEBUG - 2021-06-15 14:20:00 --> Total execution time: 0.0306
ERROR - 2021-06-15 14:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:00 --> Config Class Initialized
INFO - 2021-06-15 14:20:00 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:00 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:00 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:00 --> URI Class Initialized
INFO - 2021-06-15 14:20:00 --> Router Class Initialized
INFO - 2021-06-15 14:20:00 --> Output Class Initialized
INFO - 2021-06-15 14:20:00 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:00 --> Input Class Initialized
INFO - 2021-06-15 14:20:00 --> Language Class Initialized
ERROR - 2021-06-15 14:20:00 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-06-15 14:20:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:01 --> Config Class Initialized
INFO - 2021-06-15 14:20:01 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:01 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:01 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:01 --> URI Class Initialized
INFO - 2021-06-15 14:20:01 --> Router Class Initialized
INFO - 2021-06-15 14:20:01 --> Output Class Initialized
INFO - 2021-06-15 14:20:01 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:01 --> Input Class Initialized
INFO - 2021-06-15 14:20:01 --> Language Class Initialized
ERROR - 2021-06-15 14:20:01 --> 404 Page Not Found: Issmall/index
ERROR - 2021-06-15 14:20:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:09 --> Config Class Initialized
INFO - 2021-06-15 14:20:09 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:09 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:09 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:09 --> URI Class Initialized
INFO - 2021-06-15 14:20:09 --> Router Class Initialized
INFO - 2021-06-15 14:20:09 --> Output Class Initialized
INFO - 2021-06-15 14:20:09 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:09 --> Input Class Initialized
INFO - 2021-06-15 14:20:09 --> Language Class Initialized
ERROR - 2021-06-15 14:20:09 --> 404 Page Not Found: Fckeditor/fckconfig.js
ERROR - 2021-06-15 14:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:10 --> Config Class Initialized
INFO - 2021-06-15 14:20:10 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:10 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:10 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:10 --> URI Class Initialized
INFO - 2021-06-15 14:20:10 --> Router Class Initialized
INFO - 2021-06-15 14:20:10 --> Output Class Initialized
INFO - 2021-06-15 14:20:10 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:10 --> Input Class Initialized
INFO - 2021-06-15 14:20:10 --> Language Class Initialized
ERROR - 2021-06-15 14:20:10 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-06-15 14:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:10 --> Config Class Initialized
INFO - 2021-06-15 14:20:10 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:10 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:10 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:10 --> URI Class Initialized
INFO - 2021-06-15 14:20:10 --> Router Class Initialized
INFO - 2021-06-15 14:20:10 --> Output Class Initialized
INFO - 2021-06-15 14:20:10 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:10 --> Input Class Initialized
INFO - 2021-06-15 14:20:10 --> Language Class Initialized
ERROR - 2021-06-15 14:20:10 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-06-15 14:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:11 --> Config Class Initialized
INFO - 2021-06-15 14:20:11 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:11 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:11 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:11 --> URI Class Initialized
INFO - 2021-06-15 14:20:11 --> Router Class Initialized
INFO - 2021-06-15 14:20:11 --> Output Class Initialized
INFO - 2021-06-15 14:20:11 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:11 --> Input Class Initialized
INFO - 2021-06-15 14:20:11 --> Language Class Initialized
ERROR - 2021-06-15 14:20:11 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-06-15 14:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:12 --> Config Class Initialized
INFO - 2021-06-15 14:20:12 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:12 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:12 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:12 --> URI Class Initialized
INFO - 2021-06-15 14:20:12 --> Router Class Initialized
INFO - 2021-06-15 14:20:12 --> Output Class Initialized
INFO - 2021-06-15 14:20:12 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:12 --> Input Class Initialized
INFO - 2021-06-15 14:20:12 --> Language Class Initialized
ERROR - 2021-06-15 14:20:12 --> 404 Page Not Found: Fckeditor/fckeditor.js
ERROR - 2021-06-15 14:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:12 --> Config Class Initialized
INFO - 2021-06-15 14:20:12 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:12 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:12 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:12 --> URI Class Initialized
INFO - 2021-06-15 14:20:12 --> Router Class Initialized
INFO - 2021-06-15 14:20:12 --> Output Class Initialized
INFO - 2021-06-15 14:20:12 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:12 --> Input Class Initialized
INFO - 2021-06-15 14:20:12 --> Language Class Initialized
ERROR - 2021-06-15 14:20:12 --> 404 Page Not Found: FCK/editor
ERROR - 2021-06-15 14:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:13 --> Config Class Initialized
INFO - 2021-06-15 14:20:13 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:13 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:13 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:13 --> URI Class Initialized
INFO - 2021-06-15 14:20:13 --> Router Class Initialized
INFO - 2021-06-15 14:20:13 --> Output Class Initialized
INFO - 2021-06-15 14:20:13 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:13 --> Input Class Initialized
INFO - 2021-06-15 14:20:13 --> Language Class Initialized
ERROR - 2021-06-15 14:20:13 --> 404 Page Not Found: FCK/fckeditor.js
ERROR - 2021-06-15 14:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:13 --> Config Class Initialized
INFO - 2021-06-15 14:20:13 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:13 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:13 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:13 --> URI Class Initialized
INFO - 2021-06-15 14:20:13 --> Router Class Initialized
INFO - 2021-06-15 14:20:13 --> Output Class Initialized
INFO - 2021-06-15 14:20:13 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:13 --> Input Class Initialized
INFO - 2021-06-15 14:20:13 --> Language Class Initialized
ERROR - 2021-06-15 14:20:13 --> 404 Page Not Found: Fckeditorjs/index
ERROR - 2021-06-15 14:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:14 --> Config Class Initialized
INFO - 2021-06-15 14:20:14 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:14 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:14 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:14 --> URI Class Initialized
INFO - 2021-06-15 14:20:14 --> Router Class Initialized
INFO - 2021-06-15 14:20:14 --> Output Class Initialized
INFO - 2021-06-15 14:20:14 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:14 --> Input Class Initialized
INFO - 2021-06-15 14:20:14 --> Language Class Initialized
ERROR - 2021-06-15 14:20:14 --> 404 Page Not Found: Editor/fckeditor.js
ERROR - 2021-06-15 14:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:14 --> Config Class Initialized
INFO - 2021-06-15 14:20:14 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:14 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:14 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:14 --> URI Class Initialized
INFO - 2021-06-15 14:20:14 --> Router Class Initialized
INFO - 2021-06-15 14:20:14 --> Output Class Initialized
INFO - 2021-06-15 14:20:14 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:14 --> Input Class Initialized
INFO - 2021-06-15 14:20:14 --> Language Class Initialized
ERROR - 2021-06-15 14:20:14 --> 404 Page Not Found: Editor/js
ERROR - 2021-06-15 14:20:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:15 --> Config Class Initialized
INFO - 2021-06-15 14:20:15 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:15 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:15 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:15 --> URI Class Initialized
INFO - 2021-06-15 14:20:15 --> Router Class Initialized
INFO - 2021-06-15 14:20:15 --> Output Class Initialized
INFO - 2021-06-15 14:20:15 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:15 --> Input Class Initialized
INFO - 2021-06-15 14:20:15 --> Language Class Initialized
ERROR - 2021-06-15 14:20:15 --> 404 Page Not Found: New_gb/help
ERROR - 2021-06-15 14:20:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:15 --> Config Class Initialized
INFO - 2021-06-15 14:20:15 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:15 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:15 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:15 --> URI Class Initialized
INFO - 2021-06-15 14:20:15 --> Router Class Initialized
INFO - 2021-06-15 14:20:15 --> Output Class Initialized
INFO - 2021-06-15 14:20:15 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:15 --> Input Class Initialized
INFO - 2021-06-15 14:20:15 --> Language Class Initialized
ERROR - 2021-06-15 14:20:15 --> 404 Page Not Found: Web2/login_template
ERROR - 2021-06-15 14:20:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:15 --> Config Class Initialized
INFO - 2021-06-15 14:20:15 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:15 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:15 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:15 --> URI Class Initialized
INFO - 2021-06-15 14:20:15 --> Router Class Initialized
INFO - 2021-06-15 14:20:15 --> Output Class Initialized
INFO - 2021-06-15 14:20:15 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:15 --> Input Class Initialized
INFO - 2021-06-15 14:20:15 --> Language Class Initialized
ERROR - 2021-06-15 14:20:15 --> 404 Page Not Found: Ckeditor/ckeditor.js
ERROR - 2021-06-15 14:20:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:16 --> Config Class Initialized
INFO - 2021-06-15 14:20:16 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:16 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:16 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:16 --> URI Class Initialized
DEBUG - 2021-06-15 14:20:16 --> No URI present. Default controller set.
INFO - 2021-06-15 14:20:16 --> Router Class Initialized
INFO - 2021-06-15 14:20:16 --> Output Class Initialized
INFO - 2021-06-15 14:20:16 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:16 --> Input Class Initialized
INFO - 2021-06-15 14:20:16 --> Language Class Initialized
INFO - 2021-06-15 14:20:16 --> Loader Class Initialized
INFO - 2021-06-15 14:20:16 --> Helper loaded: url_helper
INFO - 2021-06-15 14:20:16 --> Helper loaded: form_helper
INFO - 2021-06-15 14:20:16 --> Helper loaded: common_helper
INFO - 2021-06-15 14:20:16 --> Database Driver Class Initialized
DEBUG - 2021-06-15 14:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 14:20:16 --> Controller Class Initialized
INFO - 2021-06-15 14:20:16 --> Form Validation Class Initialized
DEBUG - 2021-06-15 14:20:16 --> Encrypt Class Initialized
DEBUG - 2021-06-15 14:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 14:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 14:20:16 --> Email Class Initialized
INFO - 2021-06-15 14:20:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 14:20:16 --> Calendar Class Initialized
INFO - 2021-06-15 14:20:16 --> Model "Login_model" initialized
INFO - 2021-06-15 14:20:16 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 14:20:16 --> Final output sent to browser
DEBUG - 2021-06-15 14:20:16 --> Total execution time: 0.0492
ERROR - 2021-06-15 14:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:17 --> Config Class Initialized
INFO - 2021-06-15 14:20:17 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:17 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:17 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:17 --> URI Class Initialized
INFO - 2021-06-15 14:20:17 --> Router Class Initialized
INFO - 2021-06-15 14:20:17 --> Output Class Initialized
INFO - 2021-06-15 14:20:17 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:17 --> Input Class Initialized
INFO - 2021-06-15 14:20:17 --> Language Class Initialized
ERROR - 2021-06-15 14:20:17 --> 404 Page Not Found: Tpl/user
ERROR - 2021-06-15 14:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:17 --> Config Class Initialized
INFO - 2021-06-15 14:20:17 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:17 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:17 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:17 --> URI Class Initialized
INFO - 2021-06-15 14:20:17 --> Router Class Initialized
INFO - 2021-06-15 14:20:17 --> Output Class Initialized
INFO - 2021-06-15 14:20:17 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:17 --> Input Class Initialized
INFO - 2021-06-15 14:20:17 --> Language Class Initialized
ERROR - 2021-06-15 14:20:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-15 14:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:18 --> Config Class Initialized
INFO - 2021-06-15 14:20:18 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:18 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:18 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:18 --> URI Class Initialized
INFO - 2021-06-15 14:20:18 --> Router Class Initialized
INFO - 2021-06-15 14:20:18 --> Output Class Initialized
INFO - 2021-06-15 14:20:18 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:18 --> Input Class Initialized
INFO - 2021-06-15 14:20:18 --> Language Class Initialized
ERROR - 2021-06-15 14:20:18 --> 404 Page Not Found: Images/login
ERROR - 2021-06-15 14:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:18 --> Config Class Initialized
INFO - 2021-06-15 14:20:18 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:18 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:18 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:18 --> URI Class Initialized
INFO - 2021-06-15 14:20:18 --> Router Class Initialized
INFO - 2021-06-15 14:20:18 --> Output Class Initialized
INFO - 2021-06-15 14:20:18 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:18 --> Input Class Initialized
INFO - 2021-06-15 14:20:18 --> Language Class Initialized
ERROR - 2021-06-15 14:20:18 --> 404 Page Not Found: Images/login
ERROR - 2021-06-15 14:20:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:19 --> Config Class Initialized
INFO - 2021-06-15 14:20:19 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:19 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:19 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:19 --> URI Class Initialized
INFO - 2021-06-15 14:20:19 --> Router Class Initialized
INFO - 2021-06-15 14:20:19 --> Output Class Initialized
INFO - 2021-06-15 14:20:19 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:19 --> Input Class Initialized
INFO - 2021-06-15 14:20:19 --> Language Class Initialized
ERROR - 2021-06-15 14:20:19 --> 404 Page Not Found: Tpl/login
ERROR - 2021-06-15 14:20:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:19 --> Config Class Initialized
INFO - 2021-06-15 14:20:19 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:19 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:19 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:19 --> URI Class Initialized
INFO - 2021-06-15 14:20:19 --> Router Class Initialized
INFO - 2021-06-15 14:20:19 --> Output Class Initialized
INFO - 2021-06-15 14:20:19 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:19 --> Input Class Initialized
INFO - 2021-06-15 14:20:19 --> Language Class Initialized
ERROR - 2021-06-15 14:20:19 --> 404 Page Not Found: Images/login
ERROR - 2021-06-15 14:20:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:20 --> Config Class Initialized
INFO - 2021-06-15 14:20:20 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:20 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:20 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:20 --> URI Class Initialized
INFO - 2021-06-15 14:20:20 --> Router Class Initialized
INFO - 2021-06-15 14:20:20 --> Output Class Initialized
INFO - 2021-06-15 14:20:20 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:20 --> Input Class Initialized
INFO - 2021-06-15 14:20:20 --> Language Class Initialized
ERROR - 2021-06-15 14:20:20 --> 404 Page Not Found: Docs/index
ERROR - 2021-06-15 14:20:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:20 --> Config Class Initialized
INFO - 2021-06-15 14:20:20 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:20 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:20 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:20 --> URI Class Initialized
INFO - 2021-06-15 14:20:20 --> Router Class Initialized
INFO - 2021-06-15 14:20:20 --> Output Class Initialized
INFO - 2021-06-15 14:20:20 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:20 --> Input Class Initialized
INFO - 2021-06-15 14:20:20 --> Language Class Initialized
ERROR - 2021-06-15 14:20:20 --> 404 Page Not Found: Docscss/index
ERROR - 2021-06-15 14:20:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:22 --> Config Class Initialized
INFO - 2021-06-15 14:20:22 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:22 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:22 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:22 --> URI Class Initialized
INFO - 2021-06-15 14:20:22 --> Router Class Initialized
INFO - 2021-06-15 14:20:22 --> Output Class Initialized
INFO - 2021-06-15 14:20:22 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:22 --> Input Class Initialized
INFO - 2021-06-15 14:20:22 --> Language Class Initialized
ERROR - 2021-06-15 14:20:22 --> 404 Page Not Found: Phpmyadmin/themes
ERROR - 2021-06-15 14:20:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:22 --> Config Class Initialized
INFO - 2021-06-15 14:20:22 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:22 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:22 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:22 --> URI Class Initialized
INFO - 2021-06-15 14:20:22 --> Router Class Initialized
INFO - 2021-06-15 14:20:22 --> Output Class Initialized
INFO - 2021-06-15 14:20:22 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:22 --> Input Class Initialized
INFO - 2021-06-15 14:20:22 --> Language Class Initialized
ERROR - 2021-06-15 14:20:22 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-06-15 14:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:23 --> Config Class Initialized
INFO - 2021-06-15 14:20:23 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:23 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:23 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:23 --> URI Class Initialized
INFO - 2021-06-15 14:20:23 --> Router Class Initialized
INFO - 2021-06-15 14:20:23 --> Output Class Initialized
INFO - 2021-06-15 14:20:23 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:23 --> Input Class Initialized
INFO - 2021-06-15 14:20:23 --> Language Class Initialized
ERROR - 2021-06-15 14:20:23 --> 404 Page Not Found: Phpmyadmin/docs.css
ERROR - 2021-06-15 14:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:23 --> Config Class Initialized
INFO - 2021-06-15 14:20:23 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:23 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:23 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:23 --> URI Class Initialized
INFO - 2021-06-15 14:20:23 --> Router Class Initialized
INFO - 2021-06-15 14:20:23 --> Output Class Initialized
INFO - 2021-06-15 14:20:23 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:23 --> Input Class Initialized
INFO - 2021-06-15 14:20:23 --> Language Class Initialized
ERROR - 2021-06-15 14:20:23 --> 404 Page Not Found: Images/login
ERROR - 2021-06-15 14:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:24 --> Config Class Initialized
INFO - 2021-06-15 14:20:24 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:24 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:24 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:24 --> URI Class Initialized
INFO - 2021-06-15 14:20:24 --> Router Class Initialized
INFO - 2021-06-15 14:20:24 --> Output Class Initialized
INFO - 2021-06-15 14:20:24 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:24 --> Input Class Initialized
INFO - 2021-06-15 14:20:24 --> Language Class Initialized
ERROR - 2021-06-15 14:20:24 --> 404 Page Not Found: Images/login
ERROR - 2021-06-15 14:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:24 --> Config Class Initialized
INFO - 2021-06-15 14:20:24 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:24 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:24 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:24 --> URI Class Initialized
INFO - 2021-06-15 14:20:24 --> Router Class Initialized
INFO - 2021-06-15 14:20:24 --> Output Class Initialized
INFO - 2021-06-15 14:20:24 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:24 --> Input Class Initialized
INFO - 2021-06-15 14:20:24 --> Language Class Initialized
ERROR - 2021-06-15 14:20:24 --> 404 Page Not Found: Images/login
ERROR - 2021-06-15 14:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:25 --> Config Class Initialized
INFO - 2021-06-15 14:20:25 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:25 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:25 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:25 --> URI Class Initialized
INFO - 2021-06-15 14:20:25 --> Router Class Initialized
INFO - 2021-06-15 14:20:25 --> Output Class Initialized
INFO - 2021-06-15 14:20:25 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:25 --> Input Class Initialized
INFO - 2021-06-15 14:20:25 --> Language Class Initialized
ERROR - 2021-06-15 14:20:25 --> 404 Page Not Found: Next/img
ERROR - 2021-06-15 14:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:26 --> Config Class Initialized
INFO - 2021-06-15 14:20:26 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:26 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:26 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:26 --> URI Class Initialized
INFO - 2021-06-15 14:20:26 --> Router Class Initialized
INFO - 2021-06-15 14:20:26 --> Output Class Initialized
INFO - 2021-06-15 14:20:26 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:26 --> Input Class Initialized
INFO - 2021-06-15 14:20:26 --> Language Class Initialized
ERROR - 2021-06-15 14:20:26 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-06-15 14:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:26 --> Config Class Initialized
INFO - 2021-06-15 14:20:26 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:26 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:26 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:26 --> URI Class Initialized
INFO - 2021-06-15 14:20:26 --> Router Class Initialized
INFO - 2021-06-15 14:20:26 --> Output Class Initialized
INFO - 2021-06-15 14:20:26 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:26 --> Input Class Initialized
INFO - 2021-06-15 14:20:26 --> Language Class Initialized
ERROR - 2021-06-15 14:20:26 --> 404 Page Not Found: Auth/login
ERROR - 2021-06-15 14:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:27 --> Config Class Initialized
INFO - 2021-06-15 14:20:27 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:27 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:27 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:27 --> URI Class Initialized
INFO - 2021-06-15 14:20:27 --> Router Class Initialized
INFO - 2021-06-15 14:20:27 --> Output Class Initialized
INFO - 2021-06-15 14:20:27 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:27 --> Input Class Initialized
INFO - 2021-06-15 14:20:27 --> Language Class Initialized
ERROR - 2021-06-15 14:20:27 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-06-15 14:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:27 --> Config Class Initialized
INFO - 2021-06-15 14:20:27 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:27 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:27 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:27 --> URI Class Initialized
INFO - 2021-06-15 14:20:27 --> Router Class Initialized
INFO - 2021-06-15 14:20:27 --> Output Class Initialized
INFO - 2021-06-15 14:20:27 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:27 --> Input Class Initialized
INFO - 2021-06-15 14:20:27 --> Language Class Initialized
ERROR - 2021-06-15 14:20:27 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-06-15 14:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:28 --> Config Class Initialized
INFO - 2021-06-15 14:20:28 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:28 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:28 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:28 --> URI Class Initialized
INFO - 2021-06-15 14:20:28 --> Router Class Initialized
INFO - 2021-06-15 14:20:28 --> Output Class Initialized
INFO - 2021-06-15 14:20:28 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:28 --> Input Class Initialized
INFO - 2021-06-15 14:20:28 --> Language Class Initialized
ERROR - 2021-06-15 14:20:28 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-06-15 14:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:28 --> Config Class Initialized
INFO - 2021-06-15 14:20:28 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:28 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:28 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:28 --> URI Class Initialized
INFO - 2021-06-15 14:20:28 --> Router Class Initialized
INFO - 2021-06-15 14:20:28 --> Output Class Initialized
INFO - 2021-06-15 14:20:28 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:28 --> Input Class Initialized
INFO - 2021-06-15 14:20:28 --> Language Class Initialized
ERROR - 2021-06-15 14:20:28 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-06-15 14:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:29 --> Config Class Initialized
INFO - 2021-06-15 14:20:29 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:29 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:29 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:29 --> URI Class Initialized
INFO - 2021-06-15 14:20:29 --> Router Class Initialized
INFO - 2021-06-15 14:20:29 --> Output Class Initialized
INFO - 2021-06-15 14:20:29 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:29 --> Input Class Initialized
INFO - 2021-06-15 14:20:29 --> Language Class Initialized
ERROR - 2021-06-15 14:20:29 --> 404 Page Not Found: Common/help
ERROR - 2021-06-15 14:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:29 --> Config Class Initialized
INFO - 2021-06-15 14:20:29 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:29 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:29 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:29 --> URI Class Initialized
INFO - 2021-06-15 14:20:29 --> Router Class Initialized
INFO - 2021-06-15 14:20:29 --> Output Class Initialized
INFO - 2021-06-15 14:20:29 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:29 --> Input Class Initialized
INFO - 2021-06-15 14:20:29 --> Language Class Initialized
ERROR - 2021-06-15 14:20:29 --> 404 Page Not Found: Common/help
ERROR - 2021-06-15 14:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:30 --> Config Class Initialized
INFO - 2021-06-15 14:20:30 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:30 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:30 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:30 --> URI Class Initialized
INFO - 2021-06-15 14:20:30 --> Router Class Initialized
INFO - 2021-06-15 14:20:30 --> Output Class Initialized
INFO - 2021-06-15 14:20:30 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:30 --> Input Class Initialized
INFO - 2021-06-15 14:20:30 --> Language Class Initialized
ERROR - 2021-06-15 14:20:30 --> 404 Page Not Found: Coremail/common
ERROR - 2021-06-15 14:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:30 --> Config Class Initialized
INFO - 2021-06-15 14:20:30 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:30 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:30 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:30 --> URI Class Initialized
INFO - 2021-06-15 14:20:30 --> Router Class Initialized
INFO - 2021-06-15 14:20:30 --> Output Class Initialized
INFO - 2021-06-15 14:20:30 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:30 --> Input Class Initialized
INFO - 2021-06-15 14:20:30 --> Language Class Initialized
ERROR - 2021-06-15 14:20:30 --> 404 Page Not Found: Coremail/common
ERROR - 2021-06-15 14:20:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:31 --> Config Class Initialized
INFO - 2021-06-15 14:20:31 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:31 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:31 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:31 --> URI Class Initialized
INFO - 2021-06-15 14:20:31 --> Router Class Initialized
INFO - 2021-06-15 14:20:31 --> Output Class Initialized
INFO - 2021-06-15 14:20:31 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:31 --> Input Class Initialized
INFO - 2021-06-15 14:20:31 --> Language Class Initialized
ERROR - 2021-06-15 14:20:31 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-15 14:20:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:31 --> Config Class Initialized
INFO - 2021-06-15 14:20:31 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:31 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:31 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:31 --> URI Class Initialized
INFO - 2021-06-15 14:20:31 --> Router Class Initialized
INFO - 2021-06-15 14:20:31 --> Output Class Initialized
INFO - 2021-06-15 14:20:31 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:31 --> Input Class Initialized
INFO - 2021-06-15 14:20:31 --> Language Class Initialized
ERROR - 2021-06-15 14:20:31 --> 404 Page Not Found: E/master
ERROR - 2021-06-15 14:20:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:32 --> Config Class Initialized
INFO - 2021-06-15 14:20:32 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:32 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:32 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:32 --> URI Class Initialized
INFO - 2021-06-15 14:20:32 --> Router Class Initialized
INFO - 2021-06-15 14:20:32 --> Output Class Initialized
INFO - 2021-06-15 14:20:32 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:32 --> Input Class Initialized
INFO - 2021-06-15 14:20:32 --> Language Class Initialized
ERROR - 2021-06-15 14:20:32 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-06-15 14:20:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:33 --> Config Class Initialized
INFO - 2021-06-15 14:20:33 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:33 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:33 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:33 --> URI Class Initialized
INFO - 2021-06-15 14:20:33 --> Router Class Initialized
INFO - 2021-06-15 14:20:33 --> Output Class Initialized
INFO - 2021-06-15 14:20:33 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:33 --> Input Class Initialized
INFO - 2021-06-15 14:20:33 --> Language Class Initialized
ERROR - 2021-06-15 14:20:33 --> 404 Page Not Found: Admin/index
ERROR - 2021-06-15 14:20:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:33 --> Config Class Initialized
INFO - 2021-06-15 14:20:33 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:33 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:33 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:33 --> URI Class Initialized
INFO - 2021-06-15 14:20:33 --> Router Class Initialized
INFO - 2021-06-15 14:20:33 --> Output Class Initialized
INFO - 2021-06-15 14:20:33 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:33 --> Input Class Initialized
INFO - 2021-06-15 14:20:33 --> Language Class Initialized
ERROR - 2021-06-15 14:20:33 --> 404 Page Not Found: Listphp/index
ERROR - 2021-06-15 14:20:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:34 --> Config Class Initialized
INFO - 2021-06-15 14:20:34 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:34 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:34 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:34 --> URI Class Initialized
INFO - 2021-06-15 14:20:34 --> Router Class Initialized
INFO - 2021-06-15 14:20:34 --> Output Class Initialized
INFO - 2021-06-15 14:20:34 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:34 --> Input Class Initialized
INFO - 2021-06-15 14:20:34 --> Language Class Initialized
ERROR - 2021-06-15 14:20:34 --> 404 Page Not Found: Admin/template
ERROR - 2021-06-15 14:20:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:34 --> Config Class Initialized
INFO - 2021-06-15 14:20:34 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:34 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:34 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:34 --> URI Class Initialized
INFO - 2021-06-15 14:20:34 --> Router Class Initialized
INFO - 2021-06-15 14:20:34 --> Output Class Initialized
INFO - 2021-06-15 14:20:34 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:34 --> Input Class Initialized
INFO - 2021-06-15 14:20:34 --> Language Class Initialized
ERROR - 2021-06-15 14:20:34 --> 404 Page Not Found: Images/hwem.css
ERROR - 2021-06-15 14:20:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:35 --> Config Class Initialized
INFO - 2021-06-15 14:20:35 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:35 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:35 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:35 --> URI Class Initialized
INFO - 2021-06-15 14:20:35 --> Router Class Initialized
INFO - 2021-06-15 14:20:35 --> Output Class Initialized
INFO - 2021-06-15 14:20:35 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:35 --> Input Class Initialized
INFO - 2021-06-15 14:20:35 --> Language Class Initialized
ERROR - 2021-06-15 14:20:35 --> 404 Page Not Found: Dialog/dialog.js
ERROR - 2021-06-15 14:20:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:35 --> Config Class Initialized
INFO - 2021-06-15 14:20:35 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:35 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:35 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:35 --> URI Class Initialized
INFO - 2021-06-15 14:20:35 --> Router Class Initialized
INFO - 2021-06-15 14:20:35 --> Output Class Initialized
INFO - 2021-06-15 14:20:35 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:35 --> Input Class Initialized
INFO - 2021-06-15 14:20:35 --> Language Class Initialized
ERROR - 2021-06-15 14:20:35 --> 404 Page Not Found: Editorjs/index
ERROR - 2021-06-15 14:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:36 --> Config Class Initialized
INFO - 2021-06-15 14:20:36 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:36 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:36 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:36 --> URI Class Initialized
INFO - 2021-06-15 14:20:36 --> Router Class Initialized
INFO - 2021-06-15 14:20:36 --> Output Class Initialized
INFO - 2021-06-15 14:20:36 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:36 --> Input Class Initialized
INFO - 2021-06-15 14:20:36 --> Language Class Initialized
ERROR - 2021-06-15 14:20:36 --> 404 Page Not Found: Images/2_11.gif
ERROR - 2021-06-15 14:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:36 --> Config Class Initialized
INFO - 2021-06-15 14:20:36 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:36 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:36 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:36 --> URI Class Initialized
INFO - 2021-06-15 14:20:36 --> Router Class Initialized
INFO - 2021-06-15 14:20:36 --> Output Class Initialized
INFO - 2021-06-15 14:20:36 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:36 --> Input Class Initialized
INFO - 2021-06-15 14:20:36 --> Language Class Initialized
ERROR - 2021-06-15 14:20:36 --> 404 Page Not Found: Js/buttons.js
ERROR - 2021-06-15 14:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:37 --> Config Class Initialized
INFO - 2021-06-15 14:20:37 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:37 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:37 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:37 --> URI Class Initialized
INFO - 2021-06-15 14:20:37 --> Router Class Initialized
INFO - 2021-06-15 14:20:37 --> Output Class Initialized
INFO - 2021-06-15 14:20:37 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:37 --> Input Class Initialized
INFO - 2021-06-15 14:20:37 --> Language Class Initialized
ERROR - 2021-06-15 14:20:37 --> 404 Page Not Found: Admin/inc
ERROR - 2021-06-15 14:20:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:38 --> Config Class Initialized
INFO - 2021-06-15 14:20:38 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:38 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:38 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:38 --> URI Class Initialized
INFO - 2021-06-15 14:20:38 --> Router Class Initialized
INFO - 2021-06-15 14:20:38 --> Output Class Initialized
INFO - 2021-06-15 14:20:38 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:38 --> Input Class Initialized
INFO - 2021-06-15 14:20:38 --> Language Class Initialized
ERROR - 2021-06-15 14:20:38 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-06-15 14:20:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:38 --> Config Class Initialized
INFO - 2021-06-15 14:20:38 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:38 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:38 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:38 --> URI Class Initialized
INFO - 2021-06-15 14:20:38 --> Router Class Initialized
INFO - 2021-06-15 14:20:38 --> Output Class Initialized
INFO - 2021-06-15 14:20:38 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:38 --> Input Class Initialized
INFO - 2021-06-15 14:20:38 --> Language Class Initialized
ERROR - 2021-06-15 14:20:38 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-06-15 14:20:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:39 --> Config Class Initialized
INFO - 2021-06-15 14:20:39 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:39 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:39 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:39 --> URI Class Initialized
INFO - 2021-06-15 14:20:39 --> Router Class Initialized
INFO - 2021-06-15 14:20:39 --> Output Class Initialized
INFO - 2021-06-15 14:20:39 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:39 --> Input Class Initialized
INFO - 2021-06-15 14:20:39 --> Language Class Initialized
ERROR - 2021-06-15 14:20:39 --> 404 Page Not Found: Default/images
ERROR - 2021-06-15 14:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:40 --> Config Class Initialized
INFO - 2021-06-15 14:20:40 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:40 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:40 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:40 --> URI Class Initialized
INFO - 2021-06-15 14:20:40 --> Router Class Initialized
INFO - 2021-06-15 14:20:40 --> Output Class Initialized
INFO - 2021-06-15 14:20:40 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:40 --> Input Class Initialized
INFO - 2021-06-15 14:20:40 --> Language Class Initialized
ERROR - 2021-06-15 14:20:40 --> 404 Page Not Found: Extman/default
ERROR - 2021-06-15 14:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:40 --> Config Class Initialized
INFO - 2021-06-15 14:20:40 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:40 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:40 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:40 --> URI Class Initialized
INFO - 2021-06-15 14:20:40 --> Router Class Initialized
INFO - 2021-06-15 14:20:40 --> Output Class Initialized
INFO - 2021-06-15 14:20:40 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:40 --> Input Class Initialized
INFO - 2021-06-15 14:20:40 --> Language Class Initialized
ERROR - 2021-06-15 14:20:40 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-06-15 14:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:41 --> Config Class Initialized
INFO - 2021-06-15 14:20:41 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:41 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:41 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:41 --> URI Class Initialized
INFO - 2021-06-15 14:20:41 --> Router Class Initialized
INFO - 2021-06-15 14:20:41 --> Output Class Initialized
INFO - 2021-06-15 14:20:41 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:41 --> Input Class Initialized
INFO - 2021-06-15 14:20:41 --> Language Class Initialized
ERROR - 2021-06-15 14:20:41 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-06-15 14:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:41 --> Config Class Initialized
INFO - 2021-06-15 14:20:41 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:41 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:41 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:41 --> URI Class Initialized
INFO - 2021-06-15 14:20:41 --> Router Class Initialized
INFO - 2021-06-15 14:20:41 --> Output Class Initialized
INFO - 2021-06-15 14:20:41 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:41 --> Input Class Initialized
INFO - 2021-06-15 14:20:41 --> Language Class Initialized
ERROR - 2021-06-15 14:20:41 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-06-15 14:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:42 --> Config Class Initialized
INFO - 2021-06-15 14:20:42 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:42 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:42 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:42 --> URI Class Initialized
INFO - 2021-06-15 14:20:42 --> Router Class Initialized
INFO - 2021-06-15 14:20:42 --> Output Class Initialized
INFO - 2021-06-15 14:20:42 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:42 --> Input Class Initialized
INFO - 2021-06-15 14:20:42 --> Language Class Initialized
ERROR - 2021-06-15 14:20:42 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-06-15 14:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:42 --> Config Class Initialized
INFO - 2021-06-15 14:20:42 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:42 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:42 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:42 --> URI Class Initialized
INFO - 2021-06-15 14:20:42 --> Router Class Initialized
INFO - 2021-06-15 14:20:42 --> Output Class Initialized
INFO - 2021-06-15 14:20:42 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:42 --> Input Class Initialized
INFO - 2021-06-15 14:20:42 --> Language Class Initialized
ERROR - 2021-06-15 14:20:42 --> 404 Page Not Found: Help/ch_gb
ERROR - 2021-06-15 14:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:42 --> Config Class Initialized
INFO - 2021-06-15 14:20:42 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:42 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:42 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:42 --> URI Class Initialized
INFO - 2021-06-15 14:20:42 --> Router Class Initialized
INFO - 2021-06-15 14:20:42 --> Output Class Initialized
INFO - 2021-06-15 14:20:42 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:42 --> Input Class Initialized
INFO - 2021-06-15 14:20:42 --> Language Class Initialized
ERROR - 2021-06-15 14:20:42 --> 404 Page Not Found: Admin/index.php
ERROR - 2021-06-15 14:20:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:43 --> Config Class Initialized
INFO - 2021-06-15 14:20:43 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:43 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:43 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:43 --> URI Class Initialized
DEBUG - 2021-06-15 14:20:43 --> No URI present. Default controller set.
INFO - 2021-06-15 14:20:43 --> Router Class Initialized
INFO - 2021-06-15 14:20:43 --> Output Class Initialized
INFO - 2021-06-15 14:20:43 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:43 --> Input Class Initialized
INFO - 2021-06-15 14:20:43 --> Language Class Initialized
INFO - 2021-06-15 14:20:43 --> Loader Class Initialized
INFO - 2021-06-15 14:20:43 --> Helper loaded: url_helper
INFO - 2021-06-15 14:20:43 --> Helper loaded: form_helper
INFO - 2021-06-15 14:20:43 --> Helper loaded: common_helper
INFO - 2021-06-15 14:20:43 --> Database Driver Class Initialized
DEBUG - 2021-06-15 14:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 14:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 14:20:43 --> Controller Class Initialized
INFO - 2021-06-15 14:20:43 --> Form Validation Class Initialized
DEBUG - 2021-06-15 14:20:43 --> Encrypt Class Initialized
DEBUG - 2021-06-15 14:20:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 14:20:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 14:20:43 --> Email Class Initialized
INFO - 2021-06-15 14:20:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 14:20:43 --> Calendar Class Initialized
INFO - 2021-06-15 14:20:43 --> Model "Login_model" initialized
INFO - 2021-06-15 14:20:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 14:20:43 --> Final output sent to browser
DEBUG - 2021-06-15 14:20:43 --> Total execution time: 0.0261
ERROR - 2021-06-15 14:20:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:43 --> Config Class Initialized
INFO - 2021-06-15 14:20:43 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:43 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:43 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:43 --> URI Class Initialized
DEBUG - 2021-06-15 14:20:43 --> No URI present. Default controller set.
INFO - 2021-06-15 14:20:43 --> Router Class Initialized
INFO - 2021-06-15 14:20:43 --> Output Class Initialized
INFO - 2021-06-15 14:20:43 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:43 --> Input Class Initialized
INFO - 2021-06-15 14:20:43 --> Language Class Initialized
INFO - 2021-06-15 14:20:43 --> Loader Class Initialized
INFO - 2021-06-15 14:20:43 --> Helper loaded: url_helper
INFO - 2021-06-15 14:20:43 --> Helper loaded: form_helper
INFO - 2021-06-15 14:20:43 --> Helper loaded: common_helper
INFO - 2021-06-15 14:20:43 --> Database Driver Class Initialized
DEBUG - 2021-06-15 14:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 14:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 14:20:43 --> Controller Class Initialized
INFO - 2021-06-15 14:20:43 --> Form Validation Class Initialized
DEBUG - 2021-06-15 14:20:43 --> Encrypt Class Initialized
DEBUG - 2021-06-15 14:20:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 14:20:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 14:20:43 --> Email Class Initialized
INFO - 2021-06-15 14:20:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 14:20:43 --> Calendar Class Initialized
INFO - 2021-06-15 14:20:43 --> Model "Login_model" initialized
INFO - 2021-06-15 14:20:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 14:20:43 --> Final output sent to browser
DEBUG - 2021-06-15 14:20:43 --> Total execution time: 0.0182
ERROR - 2021-06-15 14:20:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:44 --> Config Class Initialized
INFO - 2021-06-15 14:20:44 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:44 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:44 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:44 --> URI Class Initialized
DEBUG - 2021-06-15 14:20:44 --> No URI present. Default controller set.
INFO - 2021-06-15 14:20:44 --> Router Class Initialized
INFO - 2021-06-15 14:20:44 --> Output Class Initialized
INFO - 2021-06-15 14:20:44 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:44 --> Input Class Initialized
INFO - 2021-06-15 14:20:44 --> Language Class Initialized
INFO - 2021-06-15 14:20:44 --> Loader Class Initialized
INFO - 2021-06-15 14:20:44 --> Helper loaded: url_helper
INFO - 2021-06-15 14:20:44 --> Helper loaded: form_helper
INFO - 2021-06-15 14:20:44 --> Helper loaded: common_helper
INFO - 2021-06-15 14:20:44 --> Database Driver Class Initialized
DEBUG - 2021-06-15 14:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 14:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 14:20:44 --> Controller Class Initialized
INFO - 2021-06-15 14:20:44 --> Form Validation Class Initialized
DEBUG - 2021-06-15 14:20:44 --> Encrypt Class Initialized
DEBUG - 2021-06-15 14:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 14:20:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 14:20:44 --> Email Class Initialized
INFO - 2021-06-15 14:20:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 14:20:44 --> Calendar Class Initialized
INFO - 2021-06-15 14:20:44 --> Model "Login_model" initialized
INFO - 2021-06-15 14:20:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 14:20:44 --> Final output sent to browser
DEBUG - 2021-06-15 14:20:44 --> Total execution time: 0.0394
ERROR - 2021-06-15 14:20:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:45 --> Config Class Initialized
INFO - 2021-06-15 14:20:45 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:45 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:45 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:45 --> URI Class Initialized
DEBUG - 2021-06-15 14:20:45 --> No URI present. Default controller set.
INFO - 2021-06-15 14:20:45 --> Router Class Initialized
INFO - 2021-06-15 14:20:45 --> Output Class Initialized
INFO - 2021-06-15 14:20:45 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:45 --> Input Class Initialized
INFO - 2021-06-15 14:20:45 --> Language Class Initialized
INFO - 2021-06-15 14:20:45 --> Loader Class Initialized
INFO - 2021-06-15 14:20:45 --> Helper loaded: url_helper
INFO - 2021-06-15 14:20:45 --> Helper loaded: form_helper
INFO - 2021-06-15 14:20:45 --> Helper loaded: common_helper
INFO - 2021-06-15 14:20:45 --> Database Driver Class Initialized
DEBUG - 2021-06-15 14:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 14:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 14:20:45 --> Controller Class Initialized
INFO - 2021-06-15 14:20:45 --> Form Validation Class Initialized
DEBUG - 2021-06-15 14:20:45 --> Encrypt Class Initialized
DEBUG - 2021-06-15 14:20:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 14:20:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 14:20:45 --> Email Class Initialized
INFO - 2021-06-15 14:20:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 14:20:45 --> Calendar Class Initialized
INFO - 2021-06-15 14:20:45 --> Model "Login_model" initialized
INFO - 2021-06-15 14:20:45 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 14:20:45 --> Final output sent to browser
DEBUG - 2021-06-15 14:20:45 --> Total execution time: 0.0346
ERROR - 2021-06-15 14:20:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:45 --> Config Class Initialized
INFO - 2021-06-15 14:20:45 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:45 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:45 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:45 --> URI Class Initialized
INFO - 2021-06-15 14:20:45 --> Router Class Initialized
INFO - 2021-06-15 14:20:45 --> Output Class Initialized
INFO - 2021-06-15 14:20:45 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:45 --> Input Class Initialized
INFO - 2021-06-15 14:20:45 --> Language Class Initialized
ERROR - 2021-06-15 14:20:45 --> 404 Page Not Found: Admin/js
ERROR - 2021-06-15 14:20:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:46 --> Config Class Initialized
INFO - 2021-06-15 14:20:46 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:46 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:46 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:46 --> URI Class Initialized
INFO - 2021-06-15 14:20:46 --> Router Class Initialized
INFO - 2021-06-15 14:20:46 --> Output Class Initialized
INFO - 2021-06-15 14:20:46 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:46 --> Input Class Initialized
INFO - 2021-06-15 14:20:46 --> Language Class Initialized
ERROR - 2021-06-15 14:20:46 --> 404 Page Not Found: Ids/admin
ERROR - 2021-06-15 14:20:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:46 --> Config Class Initialized
INFO - 2021-06-15 14:20:46 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:46 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:46 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:46 --> URI Class Initialized
INFO - 2021-06-15 14:20:46 --> Router Class Initialized
INFO - 2021-06-15 14:20:46 --> Output Class Initialized
INFO - 2021-06-15 14:20:46 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:46 --> Input Class Initialized
INFO - 2021-06-15 14:20:46 --> Language Class Initialized
ERROR - 2021-06-15 14:20:46 --> 404 Page Not Found: Ids/admin
ERROR - 2021-06-15 14:20:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:46 --> Config Class Initialized
INFO - 2021-06-15 14:20:46 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:46 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:46 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:46 --> URI Class Initialized
INFO - 2021-06-15 14:20:46 --> Router Class Initialized
INFO - 2021-06-15 14:20:46 --> Output Class Initialized
INFO - 2021-06-15 14:20:46 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:46 --> Input Class Initialized
INFO - 2021-06-15 14:20:46 --> Language Class Initialized
ERROR - 2021-06-15 14:20:46 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-06-15 14:20:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:47 --> Config Class Initialized
INFO - 2021-06-15 14:20:47 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:47 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:47 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:47 --> URI Class Initialized
INFO - 2021-06-15 14:20:47 --> Router Class Initialized
INFO - 2021-06-15 14:20:47 --> Output Class Initialized
INFO - 2021-06-15 14:20:47 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:47 --> Input Class Initialized
INFO - 2021-06-15 14:20:47 --> Language Class Initialized
ERROR - 2021-06-15 14:20:47 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-06-15 14:20:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:47 --> Config Class Initialized
INFO - 2021-06-15 14:20:47 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:47 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:47 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:47 --> URI Class Initialized
INFO - 2021-06-15 14:20:47 --> Router Class Initialized
INFO - 2021-06-15 14:20:47 --> Output Class Initialized
INFO - 2021-06-15 14:20:47 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:47 --> Input Class Initialized
INFO - 2021-06-15 14:20:47 --> Language Class Initialized
ERROR - 2021-06-15 14:20:47 --> 404 Page Not Found: UserCenter/css
ERROR - 2021-06-15 14:20:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:48 --> Config Class Initialized
INFO - 2021-06-15 14:20:48 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:48 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:48 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:48 --> URI Class Initialized
INFO - 2021-06-15 14:20:48 --> Router Class Initialized
INFO - 2021-06-15 14:20:48 --> Output Class Initialized
INFO - 2021-06-15 14:20:48 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:48 --> Input Class Initialized
INFO - 2021-06-15 14:20:48 --> Language Class Initialized
ERROR - 2021-06-15 14:20:48 --> 404 Page Not Found: Bencandyphp/index
ERROR - 2021-06-15 14:20:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:48 --> Config Class Initialized
INFO - 2021-06-15 14:20:48 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:48 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:48 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:48 --> URI Class Initialized
INFO - 2021-06-15 14:20:48 --> Router Class Initialized
INFO - 2021-06-15 14:20:48 --> Output Class Initialized
INFO - 2021-06-15 14:20:48 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:48 --> Input Class Initialized
INFO - 2021-06-15 14:20:48 --> Language Class Initialized
ERROR - 2021-06-15 14:20:48 --> 404 Page Not Found: Images/default
ERROR - 2021-06-15 14:20:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:49 --> Config Class Initialized
INFO - 2021-06-15 14:20:49 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:49 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:49 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:49 --> URI Class Initialized
INFO - 2021-06-15 14:20:49 --> Router Class Initialized
INFO - 2021-06-15 14:20:49 --> Output Class Initialized
INFO - 2021-06-15 14:20:49 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:49 --> Input Class Initialized
INFO - 2021-06-15 14:20:49 --> Language Class Initialized
ERROR - 2021-06-15 14:20:49 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-06-15 14:20:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:49 --> Config Class Initialized
INFO - 2021-06-15 14:20:49 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:49 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:49 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:49 --> URI Class Initialized
INFO - 2021-06-15 14:20:49 --> Router Class Initialized
INFO - 2021-06-15 14:20:49 --> Output Class Initialized
INFO - 2021-06-15 14:20:49 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:49 --> Input Class Initialized
INFO - 2021-06-15 14:20:49 --> Language Class Initialized
ERROR - 2021-06-15 14:20:49 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-06-15 14:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:50 --> Config Class Initialized
INFO - 2021-06-15 14:20:50 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:50 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:50 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:50 --> URI Class Initialized
INFO - 2021-06-15 14:20:50 --> Router Class Initialized
INFO - 2021-06-15 14:20:50 --> Output Class Initialized
INFO - 2021-06-15 14:20:50 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:50 --> Input Class Initialized
INFO - 2021-06-15 14:20:50 --> Language Class Initialized
ERROR - 2021-06-15 14:20:50 --> 404 Page Not Found: Admin/SouthidcEditor
ERROR - 2021-06-15 14:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:51 --> Config Class Initialized
INFO - 2021-06-15 14:20:51 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:51 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:51 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:51 --> URI Class Initialized
INFO - 2021-06-15 14:20:51 --> Router Class Initialized
INFO - 2021-06-15 14:20:51 --> Output Class Initialized
INFO - 2021-06-15 14:20:51 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:51 --> Input Class Initialized
INFO - 2021-06-15 14:20:51 --> Language Class Initialized
ERROR - 2021-06-15 14:20:51 --> 404 Page Not Found: Default/css
ERROR - 2021-06-15 14:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:51 --> Config Class Initialized
INFO - 2021-06-15 14:20:51 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:51 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:51 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:51 --> URI Class Initialized
INFO - 2021-06-15 14:20:51 --> Router Class Initialized
INFO - 2021-06-15 14:20:51 --> Output Class Initialized
INFO - 2021-06-15 14:20:51 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:51 --> Input Class Initialized
INFO - 2021-06-15 14:20:51 --> Language Class Initialized
ERROR - 2021-06-15 14:20:51 --> 404 Page Not Found: App/home
ERROR - 2021-06-15 14:20:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:52 --> Config Class Initialized
INFO - 2021-06-15 14:20:52 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:52 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:52 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:52 --> URI Class Initialized
INFO - 2021-06-15 14:20:52 --> Router Class Initialized
INFO - 2021-06-15 14:20:52 --> Output Class Initialized
INFO - 2021-06-15 14:20:52 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:52 --> Input Class Initialized
INFO - 2021-06-15 14:20:52 --> Language Class Initialized
ERROR - 2021-06-15 14:20:52 --> 404 Page Not Found: Images/login9
ERROR - 2021-06-15 14:20:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:52 --> Config Class Initialized
INFO - 2021-06-15 14:20:52 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:52 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:52 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:52 --> URI Class Initialized
INFO - 2021-06-15 14:20:52 --> Router Class Initialized
INFO - 2021-06-15 14:20:52 --> Output Class Initialized
INFO - 2021-06-15 14:20:52 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:52 --> Input Class Initialized
INFO - 2021-06-15 14:20:52 --> Language Class Initialized
ERROR - 2021-06-15 14:20:52 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-06-15 14:20:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:52 --> Config Class Initialized
INFO - 2021-06-15 14:20:52 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:52 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:52 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:52 --> URI Class Initialized
INFO - 2021-06-15 14:20:52 --> Router Class Initialized
INFO - 2021-06-15 14:20:52 --> Output Class Initialized
INFO - 2021-06-15 14:20:52 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:52 --> Input Class Initialized
INFO - 2021-06-15 14:20:52 --> Language Class Initialized
ERROR - 2021-06-15 14:20:52 --> 404 Page Not Found: App/js
ERROR - 2021-06-15 14:20:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:53 --> Config Class Initialized
INFO - 2021-06-15 14:20:53 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:53 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:53 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:53 --> URI Class Initialized
INFO - 2021-06-15 14:20:53 --> Router Class Initialized
INFO - 2021-06-15 14:20:53 --> Output Class Initialized
INFO - 2021-06-15 14:20:53 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:53 --> Input Class Initialized
INFO - 2021-06-15 14:20:53 --> Language Class Initialized
ERROR - 2021-06-15 14:20:53 --> 404 Page Not Found: Console/js
ERROR - 2021-06-15 14:20:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:53 --> Config Class Initialized
INFO - 2021-06-15 14:20:53 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:53 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:53 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:53 --> URI Class Initialized
INFO - 2021-06-15 14:20:53 --> Router Class Initialized
INFO - 2021-06-15 14:20:53 --> Output Class Initialized
INFO - 2021-06-15 14:20:53 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:53 --> Input Class Initialized
INFO - 2021-06-15 14:20:53 --> Language Class Initialized
ERROR - 2021-06-15 14:20:53 --> 404 Page Not Found: Console/include
ERROR - 2021-06-15 14:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:54 --> Config Class Initialized
INFO - 2021-06-15 14:20:54 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:54 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:54 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:54 --> URI Class Initialized
INFO - 2021-06-15 14:20:54 --> Router Class Initialized
INFO - 2021-06-15 14:20:54 --> Output Class Initialized
INFO - 2021-06-15 14:20:54 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:54 --> Input Class Initialized
INFO - 2021-06-15 14:20:54 --> Language Class Initialized
ERROR - 2021-06-15 14:20:54 --> 404 Page Not Found: Console/auth
ERROR - 2021-06-15 14:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:54 --> Config Class Initialized
INFO - 2021-06-15 14:20:54 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:54 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:54 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:54 --> URI Class Initialized
INFO - 2021-06-15 14:20:54 --> Router Class Initialized
INFO - 2021-06-15 14:20:54 --> Output Class Initialized
INFO - 2021-06-15 14:20:54 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:54 --> Input Class Initialized
INFO - 2021-06-15 14:20:54 --> Language Class Initialized
ERROR - 2021-06-15 14:20:54 --> 404 Page Not Found: Console/js
ERROR - 2021-06-15 14:20:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:55 --> Config Class Initialized
INFO - 2021-06-15 14:20:55 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:55 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:55 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:55 --> URI Class Initialized
INFO - 2021-06-15 14:20:55 --> Router Class Initialized
INFO - 2021-06-15 14:20:55 --> Output Class Initialized
INFO - 2021-06-15 14:20:55 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:55 --> Input Class Initialized
INFO - 2021-06-15 14:20:55 --> Language Class Initialized
ERROR - 2021-06-15 14:20:55 --> 404 Page Not Found: App/images
ERROR - 2021-06-15 14:20:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:55 --> Config Class Initialized
INFO - 2021-06-15 14:20:55 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:55 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:55 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:55 --> URI Class Initialized
INFO - 2021-06-15 14:20:55 --> Router Class Initialized
INFO - 2021-06-15 14:20:55 --> Output Class Initialized
INFO - 2021-06-15 14:20:55 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:55 --> Input Class Initialized
INFO - 2021-06-15 14:20:55 --> Language Class Initialized
ERROR - 2021-06-15 14:20:55 --> 404 Page Not Found: App/images
ERROR - 2021-06-15 14:20:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:56 --> Config Class Initialized
INFO - 2021-06-15 14:20:56 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:56 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:56 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:56 --> URI Class Initialized
INFO - 2021-06-15 14:20:56 --> Router Class Initialized
INFO - 2021-06-15 14:20:56 --> Output Class Initialized
INFO - 2021-06-15 14:20:56 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:56 --> Input Class Initialized
INFO - 2021-06-15 14:20:56 --> Language Class Initialized
ERROR - 2021-06-15 14:20:56 --> 404 Page Not Found: Addons/theme
ERROR - 2021-06-15 14:20:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:56 --> Config Class Initialized
INFO - 2021-06-15 14:20:56 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:56 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:56 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:56 --> URI Class Initialized
INFO - 2021-06-15 14:20:56 --> Router Class Initialized
INFO - 2021-06-15 14:20:56 --> Output Class Initialized
INFO - 2021-06-15 14:20:56 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:56 --> Input Class Initialized
INFO - 2021-06-15 14:20:56 --> Language Class Initialized
ERROR - 2021-06-15 14:20:56 --> 404 Page Not Found: Apps/admin
ERROR - 2021-06-15 14:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:57 --> Config Class Initialized
INFO - 2021-06-15 14:20:57 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:57 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:57 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:57 --> URI Class Initialized
INFO - 2021-06-15 14:20:57 --> Router Class Initialized
INFO - 2021-06-15 14:20:57 --> Output Class Initialized
INFO - 2021-06-15 14:20:57 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:57 --> Input Class Initialized
INFO - 2021-06-15 14:20:57 --> Language Class Initialized
ERROR - 2021-06-15 14:20:57 --> 404 Page Not Found: Addons/theme
ERROR - 2021-06-15 14:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:57 --> Config Class Initialized
INFO - 2021-06-15 14:20:57 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:57 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:57 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:57 --> URI Class Initialized
INFO - 2021-06-15 14:20:57 --> Router Class Initialized
INFO - 2021-06-15 14:20:57 --> Output Class Initialized
INFO - 2021-06-15 14:20:57 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:57 --> Input Class Initialized
INFO - 2021-06-15 14:20:57 --> Language Class Initialized
ERROR - 2021-06-15 14:20:57 --> 404 Page Not Found: Addons/theme
ERROR - 2021-06-15 14:20:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:59 --> Config Class Initialized
INFO - 2021-06-15 14:20:59 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:59 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:59 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:59 --> URI Class Initialized
INFO - 2021-06-15 14:20:59 --> Router Class Initialized
INFO - 2021-06-15 14:20:59 --> Output Class Initialized
INFO - 2021-06-15 14:20:59 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:59 --> Input Class Initialized
INFO - 2021-06-15 14:20:59 --> Language Class Initialized
ERROR - 2021-06-15 14:20:59 --> 404 Page Not Found: Skin/frontend
ERROR - 2021-06-15 14:20:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:20:59 --> Config Class Initialized
INFO - 2021-06-15 14:20:59 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:20:59 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:20:59 --> Utf8 Class Initialized
INFO - 2021-06-15 14:20:59 --> URI Class Initialized
INFO - 2021-06-15 14:20:59 --> Router Class Initialized
INFO - 2021-06-15 14:20:59 --> Output Class Initialized
INFO - 2021-06-15 14:20:59 --> Security Class Initialized
DEBUG - 2021-06-15 14:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:20:59 --> Input Class Initialized
INFO - 2021-06-15 14:20:59 --> Language Class Initialized
ERROR - 2021-06-15 14:20:59 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-06-15 14:21:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:00 --> Config Class Initialized
INFO - 2021-06-15 14:21:00 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:00 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:00 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:00 --> URI Class Initialized
INFO - 2021-06-15 14:21:00 --> Router Class Initialized
INFO - 2021-06-15 14:21:00 --> Output Class Initialized
INFO - 2021-06-15 14:21:00 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:00 --> Input Class Initialized
INFO - 2021-06-15 14:21:00 --> Language Class Initialized
ERROR - 2021-06-15 14:21:00 --> 404 Page Not Found: Ymail/images
ERROR - 2021-06-15 14:21:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:00 --> Config Class Initialized
INFO - 2021-06-15 14:21:00 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:00 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:00 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:00 --> URI Class Initialized
INFO - 2021-06-15 14:21:00 --> Router Class Initialized
INFO - 2021-06-15 14:21:00 --> Output Class Initialized
INFO - 2021-06-15 14:21:00 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:00 --> Input Class Initialized
INFO - 2021-06-15 14:21:00 --> Language Class Initialized
ERROR - 2021-06-15 14:21:00 --> 404 Page Not Found: Advfile/ad12.js
ERROR - 2021-06-15 14:21:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:01 --> Config Class Initialized
INFO - 2021-06-15 14:21:01 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:01 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:01 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:01 --> URI Class Initialized
INFO - 2021-06-15 14:21:01 --> Router Class Initialized
INFO - 2021-06-15 14:21:01 --> Output Class Initialized
INFO - 2021-06-15 14:21:01 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:01 --> Input Class Initialized
INFO - 2021-06-15 14:21:01 --> Language Class Initialized
ERROR - 2021-06-15 14:21:01 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-06-15 14:21:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:01 --> Config Class Initialized
INFO - 2021-06-15 14:21:01 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:01 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:01 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:01 --> URI Class Initialized
INFO - 2021-06-15 14:21:01 --> Router Class Initialized
INFO - 2021-06-15 14:21:01 --> Output Class Initialized
INFO - 2021-06-15 14:21:01 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:01 --> Input Class Initialized
INFO - 2021-06-15 14:21:01 --> Language Class Initialized
ERROR - 2021-06-15 14:21:01 --> 404 Page Not Found: Pub/guiedit
ERROR - 2021-06-15 14:21:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:02 --> Config Class Initialized
INFO - 2021-06-15 14:21:02 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:02 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:02 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:02 --> URI Class Initialized
INFO - 2021-06-15 14:21:02 --> Router Class Initialized
INFO - 2021-06-15 14:21:02 --> Output Class Initialized
INFO - 2021-06-15 14:21:02 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:02 --> Input Class Initialized
INFO - 2021-06-15 14:21:02 --> Language Class Initialized
ERROR - 2021-06-15 14:21:02 --> 404 Page Not Found: Pub/skins
ERROR - 2021-06-15 14:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:03 --> Config Class Initialized
INFO - 2021-06-15 14:21:03 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:03 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:03 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:03 --> URI Class Initialized
INFO - 2021-06-15 14:21:03 --> Router Class Initialized
INFO - 2021-06-15 14:21:03 --> Output Class Initialized
INFO - 2021-06-15 14:21:03 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:03 --> Input Class Initialized
INFO - 2021-06-15 14:21:03 --> Language Class Initialized
ERROR - 2021-06-15 14:21:03 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-06-15 14:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:03 --> Config Class Initialized
INFO - 2021-06-15 14:21:03 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:03 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:03 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:03 --> URI Class Initialized
INFO - 2021-06-15 14:21:03 --> Router Class Initialized
INFO - 2021-06-15 14:21:03 --> Output Class Initialized
INFO - 2021-06-15 14:21:03 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:03 --> Input Class Initialized
INFO - 2021-06-15 14:21:03 --> Language Class Initialized
ERROR - 2021-06-15 14:21:03 --> 404 Page Not Found: Pluginphp/index
ERROR - 2021-06-15 14:21:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:04 --> Config Class Initialized
INFO - 2021-06-15 14:21:04 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:04 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:04 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:04 --> URI Class Initialized
INFO - 2021-06-15 14:21:04 --> Router Class Initialized
INFO - 2021-06-15 14:21:04 --> Output Class Initialized
INFO - 2021-06-15 14:21:04 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:04 --> Input Class Initialized
INFO - 2021-06-15 14:21:04 --> Language Class Initialized
ERROR - 2021-06-15 14:21:04 --> 404 Page Not Found: Admin/login.aspx
ERROR - 2021-06-15 14:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:05 --> Config Class Initialized
INFO - 2021-06-15 14:21:05 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:05 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:05 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:05 --> URI Class Initialized
INFO - 2021-06-15 14:21:05 --> Router Class Initialized
INFO - 2021-06-15 14:21:05 --> Output Class Initialized
INFO - 2021-06-15 14:21:05 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:05 --> Input Class Initialized
INFO - 2021-06-15 14:21:05 --> Language Class Initialized
ERROR - 2021-06-15 14:21:05 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-06-15 14:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:05 --> Config Class Initialized
INFO - 2021-06-15 14:21:05 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:05 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:05 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:05 --> URI Class Initialized
INFO - 2021-06-15 14:21:05 --> Router Class Initialized
INFO - 2021-06-15 14:21:05 --> Output Class Initialized
INFO - 2021-06-15 14:21:05 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:05 --> Input Class Initialized
INFO - 2021-06-15 14:21:05 --> Language Class Initialized
ERROR - 2021-06-15 14:21:05 --> 404 Page Not Found: Template/1
ERROR - 2021-06-15 14:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:06 --> Config Class Initialized
INFO - 2021-06-15 14:21:06 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:06 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:06 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:06 --> URI Class Initialized
INFO - 2021-06-15 14:21:06 --> Router Class Initialized
INFO - 2021-06-15 14:21:06 --> Output Class Initialized
INFO - 2021-06-15 14:21:06 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:06 --> Input Class Initialized
INFO - 2021-06-15 14:21:06 --> Language Class Initialized
ERROR - 2021-06-15 14:21:06 --> 404 Page Not Found: Back/scripts
ERROR - 2021-06-15 14:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:06 --> Config Class Initialized
INFO - 2021-06-15 14:21:06 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:06 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:06 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:06 --> URI Class Initialized
INFO - 2021-06-15 14:21:06 --> Router Class Initialized
INFO - 2021-06-15 14:21:06 --> Output Class Initialized
INFO - 2021-06-15 14:21:06 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:06 --> Input Class Initialized
INFO - 2021-06-15 14:21:06 --> Language Class Initialized
ERROR - 2021-06-15 14:21:06 --> 404 Page Not Found: Install/index
ERROR - 2021-06-15 14:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:07 --> Config Class Initialized
INFO - 2021-06-15 14:21:07 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:07 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:07 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:07 --> URI Class Initialized
INFO - 2021-06-15 14:21:07 --> Router Class Initialized
INFO - 2021-06-15 14:21:07 --> Output Class Initialized
INFO - 2021-06-15 14:21:07 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:07 --> Input Class Initialized
INFO - 2021-06-15 14:21:07 --> Language Class Initialized
ERROR - 2021-06-15 14:21:07 --> 404 Page Not Found: Wq_StranJFjs/index
ERROR - 2021-06-15 14:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:07 --> Config Class Initialized
INFO - 2021-06-15 14:21:07 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:07 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:07 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:07 --> URI Class Initialized
INFO - 2021-06-15 14:21:07 --> Router Class Initialized
INFO - 2021-06-15 14:21:07 --> Output Class Initialized
INFO - 2021-06-15 14:21:07 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:07 --> Input Class Initialized
INFO - 2021-06-15 14:21:07 --> Language Class Initialized
ERROR - 2021-06-15 14:21:07 --> 404 Page Not Found: Admin/login.asp
ERROR - 2021-06-15 14:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:08 --> Config Class Initialized
INFO - 2021-06-15 14:21:08 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:08 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:08 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:08 --> URI Class Initialized
INFO - 2021-06-15 14:21:08 --> Router Class Initialized
INFO - 2021-06-15 14:21:08 --> Output Class Initialized
INFO - 2021-06-15 14:21:08 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:08 --> Input Class Initialized
INFO - 2021-06-15 14:21:08 --> Language Class Initialized
ERROR - 2021-06-15 14:21:08 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-06-15 14:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:08 --> Config Class Initialized
INFO - 2021-06-15 14:21:08 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:08 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:08 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:08 --> URI Class Initialized
INFO - 2021-06-15 14:21:08 --> Router Class Initialized
INFO - 2021-06-15 14:21:08 --> Output Class Initialized
INFO - 2021-06-15 14:21:08 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:08 --> Input Class Initialized
INFO - 2021-06-15 14:21:08 --> Language Class Initialized
ERROR - 2021-06-15 14:21:08 --> 404 Page Not Found: Script/valid_formdata.js
ERROR - 2021-06-15 14:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:09 --> Config Class Initialized
INFO - 2021-06-15 14:21:09 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:09 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:09 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:09 --> URI Class Initialized
INFO - 2021-06-15 14:21:09 --> Router Class Initialized
INFO - 2021-06-15 14:21:09 --> Output Class Initialized
INFO - 2021-06-15 14:21:09 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:09 --> Input Class Initialized
INFO - 2021-06-15 14:21:09 --> Language Class Initialized
ERROR - 2021-06-15 14:21:09 --> 404 Page Not Found: Themes/graphics
ERROR - 2021-06-15 14:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:09 --> Config Class Initialized
INFO - 2021-06-15 14:21:09 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:09 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:09 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:09 --> URI Class Initialized
INFO - 2021-06-15 14:21:09 --> Router Class Initialized
INFO - 2021-06-15 14:21:09 --> Output Class Initialized
INFO - 2021-06-15 14:21:09 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:09 --> Input Class Initialized
INFO - 2021-06-15 14:21:09 --> Language Class Initialized
ERROR - 2021-06-15 14:21:09 --> 404 Page Not Found: Themes/default
ERROR - 2021-06-15 14:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:09 --> Config Class Initialized
INFO - 2021-06-15 14:21:09 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:09 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:09 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:09 --> URI Class Initialized
INFO - 2021-06-15 14:21:09 --> Router Class Initialized
INFO - 2021-06-15 14:21:09 --> Output Class Initialized
INFO - 2021-06-15 14:21:09 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:09 --> Input Class Initialized
INFO - 2021-06-15 14:21:09 --> Language Class Initialized
ERROR - 2021-06-15 14:21:09 --> 404 Page Not Found: Themes/default
ERROR - 2021-06-15 14:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:10 --> Config Class Initialized
INFO - 2021-06-15 14:21:10 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:10 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:10 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:10 --> URI Class Initialized
INFO - 2021-06-15 14:21:10 --> Router Class Initialized
INFO - 2021-06-15 14:21:10 --> Output Class Initialized
INFO - 2021-06-15 14:21:10 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:10 --> Input Class Initialized
INFO - 2021-06-15 14:21:10 --> Language Class Initialized
ERROR - 2021-06-15 14:21:10 --> 404 Page Not Found: Kindeditor-minjs/index
ERROR - 2021-06-15 14:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:11 --> Config Class Initialized
INFO - 2021-06-15 14:21:11 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:11 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:11 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:11 --> URI Class Initialized
INFO - 2021-06-15 14:21:11 --> Router Class Initialized
INFO - 2021-06-15 14:21:11 --> Output Class Initialized
INFO - 2021-06-15 14:21:11 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:11 --> Input Class Initialized
INFO - 2021-06-15 14:21:11 --> Language Class Initialized
ERROR - 2021-06-15 14:21:11 --> 404 Page Not Found: Kindeditorjs/index
ERROR - 2021-06-15 14:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:11 --> Config Class Initialized
INFO - 2021-06-15 14:21:11 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:11 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:11 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:11 --> URI Class Initialized
INFO - 2021-06-15 14:21:11 --> Router Class Initialized
INFO - 2021-06-15 14:21:11 --> Output Class Initialized
INFO - 2021-06-15 14:21:11 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:11 --> Input Class Initialized
INFO - 2021-06-15 14:21:11 --> Language Class Initialized
ERROR - 2021-06-15 14:21:11 --> 404 Page Not Found: Lang/en.js
ERROR - 2021-06-15 14:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:12 --> Config Class Initialized
INFO - 2021-06-15 14:21:12 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:12 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:12 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:12 --> URI Class Initialized
INFO - 2021-06-15 14:21:12 --> Router Class Initialized
INFO - 2021-06-15 14:21:12 --> Output Class Initialized
INFO - 2021-06-15 14:21:12 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:12 --> Input Class Initialized
INFO - 2021-06-15 14:21:12 --> Language Class Initialized
ERROR - 2021-06-15 14:21:12 --> 404 Page Not Found: Themes/default
ERROR - 2021-06-15 14:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:12 --> Config Class Initialized
INFO - 2021-06-15 14:21:12 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:12 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:12 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:12 --> URI Class Initialized
INFO - 2021-06-15 14:21:12 --> Router Class Initialized
INFO - 2021-06-15 14:21:12 --> Output Class Initialized
INFO - 2021-06-15 14:21:12 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:12 --> Input Class Initialized
INFO - 2021-06-15 14:21:12 --> Language Class Initialized
ERROR - 2021-06-15 14:21:12 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-06-15 14:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:13 --> Config Class Initialized
INFO - 2021-06-15 14:21:13 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:13 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:13 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:13 --> URI Class Initialized
INFO - 2021-06-15 14:21:13 --> Router Class Initialized
INFO - 2021-06-15 14:21:13 --> Output Class Initialized
INFO - 2021-06-15 14:21:13 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:13 --> Input Class Initialized
INFO - 2021-06-15 14:21:13 --> Language Class Initialized
ERROR - 2021-06-15 14:21:13 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-06-15 14:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:13 --> Config Class Initialized
INFO - 2021-06-15 14:21:13 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:13 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:13 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:13 --> URI Class Initialized
INFO - 2021-06-15 14:21:13 --> Router Class Initialized
INFO - 2021-06-15 14:21:13 --> Output Class Initialized
INFO - 2021-06-15 14:21:13 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:13 --> Input Class Initialized
INFO - 2021-06-15 14:21:13 --> Language Class Initialized
ERROR - 2021-06-15 14:21:13 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-06-15 14:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:13 --> Config Class Initialized
INFO - 2021-06-15 14:21:13 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:13 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:13 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:13 --> URI Class Initialized
INFO - 2021-06-15 14:21:13 --> Router Class Initialized
INFO - 2021-06-15 14:21:13 --> Output Class Initialized
INFO - 2021-06-15 14:21:13 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:13 --> Input Class Initialized
INFO - 2021-06-15 14:21:13 --> Language Class Initialized
ERROR - 2021-06-15 14:21:13 --> 404 Page Not Found: Plugins/anchor
ERROR - 2021-06-15 14:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:14 --> Config Class Initialized
INFO - 2021-06-15 14:21:14 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:14 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:14 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:14 --> URI Class Initialized
INFO - 2021-06-15 14:21:14 --> Router Class Initialized
INFO - 2021-06-15 14:21:14 --> Output Class Initialized
INFO - 2021-06-15 14:21:14 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:14 --> Input Class Initialized
INFO - 2021-06-15 14:21:14 --> Language Class Initialized
ERROR - 2021-06-15 14:21:14 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-06-15 14:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:14 --> Config Class Initialized
INFO - 2021-06-15 14:21:14 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:14 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:14 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:14 --> URI Class Initialized
INFO - 2021-06-15 14:21:14 --> Router Class Initialized
INFO - 2021-06-15 14:21:14 --> Output Class Initialized
INFO - 2021-06-15 14:21:14 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:14 --> Input Class Initialized
INFO - 2021-06-15 14:21:14 --> Language Class Initialized
ERROR - 2021-06-15 14:21:14 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-06-15 14:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:15 --> Config Class Initialized
INFO - 2021-06-15 14:21:15 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:15 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:15 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:15 --> URI Class Initialized
INFO - 2021-06-15 14:21:15 --> Router Class Initialized
INFO - 2021-06-15 14:21:15 --> Output Class Initialized
INFO - 2021-06-15 14:21:15 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:15 --> Input Class Initialized
INFO - 2021-06-15 14:21:15 --> Language Class Initialized
ERROR - 2021-06-15 14:21:15 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-06-15 14:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:15 --> Config Class Initialized
INFO - 2021-06-15 14:21:15 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:15 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:15 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:15 --> URI Class Initialized
INFO - 2021-06-15 14:21:15 --> Router Class Initialized
INFO - 2021-06-15 14:21:15 --> Output Class Initialized
INFO - 2021-06-15 14:21:15 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:15 --> Input Class Initialized
INFO - 2021-06-15 14:21:15 --> Language Class Initialized
ERROR - 2021-06-15 14:21:15 --> 404 Page Not Found: API/DW
ERROR - 2021-06-15 14:21:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:16 --> Config Class Initialized
INFO - 2021-06-15 14:21:16 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:16 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:16 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:16 --> URI Class Initialized
INFO - 2021-06-15 14:21:16 --> Router Class Initialized
INFO - 2021-06-15 14:21:16 --> Output Class Initialized
INFO - 2021-06-15 14:21:16 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:16 --> Input Class Initialized
INFO - 2021-06-15 14:21:16 --> Language Class Initialized
ERROR - 2021-06-15 14:21:16 --> 404 Page Not Found: API/DW
ERROR - 2021-06-15 14:21:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:16 --> Config Class Initialized
INFO - 2021-06-15 14:21:16 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:16 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:16 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:16 --> URI Class Initialized
INFO - 2021-06-15 14:21:16 --> Router Class Initialized
INFO - 2021-06-15 14:21:16 --> Output Class Initialized
INFO - 2021-06-15 14:21:16 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:16 --> Input Class Initialized
INFO - 2021-06-15 14:21:16 --> Language Class Initialized
ERROR - 2021-06-15 14:21:16 --> 404 Page Not Found: API/DW
ERROR - 2021-06-15 14:21:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:17 --> Config Class Initialized
INFO - 2021-06-15 14:21:17 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:17 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:17 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:17 --> URI Class Initialized
INFO - 2021-06-15 14:21:17 --> Router Class Initialized
INFO - 2021-06-15 14:21:17 --> Output Class Initialized
INFO - 2021-06-15 14:21:17 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:17 --> Input Class Initialized
INFO - 2021-06-15 14:21:17 --> Language Class Initialized
ERROR - 2021-06-15 14:21:17 --> 404 Page Not Found: Admin/Common
ERROR - 2021-06-15 14:21:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:17 --> Config Class Initialized
INFO - 2021-06-15 14:21:17 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:17 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:17 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:17 --> URI Class Initialized
INFO - 2021-06-15 14:21:17 --> Router Class Initialized
INFO - 2021-06-15 14:21:17 --> Output Class Initialized
INFO - 2021-06-15 14:21:17 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:17 --> Input Class Initialized
INFO - 2021-06-15 14:21:17 --> Language Class Initialized
ERROR - 2021-06-15 14:21:17 --> 404 Page Not Found: API/DW
ERROR - 2021-06-15 14:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:18 --> Config Class Initialized
INFO - 2021-06-15 14:21:18 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:18 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:18 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:18 --> URI Class Initialized
INFO - 2021-06-15 14:21:18 --> Router Class Initialized
INFO - 2021-06-15 14:21:18 --> Output Class Initialized
INFO - 2021-06-15 14:21:18 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:18 --> Input Class Initialized
INFO - 2021-06-15 14:21:18 --> Language Class Initialized
ERROR - 2021-06-15 14:21:18 --> 404 Page Not Found: API/DW
ERROR - 2021-06-15 14:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:18 --> Config Class Initialized
INFO - 2021-06-15 14:21:18 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:18 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:18 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:18 --> URI Class Initialized
INFO - 2021-06-15 14:21:18 --> Router Class Initialized
INFO - 2021-06-15 14:21:18 --> Output Class Initialized
INFO - 2021-06-15 14:21:18 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:18 --> Input Class Initialized
INFO - 2021-06-15 14:21:18 --> Language Class Initialized
ERROR - 2021-06-15 14:21:18 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-06-15 14:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:18 --> Config Class Initialized
INFO - 2021-06-15 14:21:18 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:18 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:18 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:18 --> URI Class Initialized
INFO - 2021-06-15 14:21:18 --> Router Class Initialized
INFO - 2021-06-15 14:21:18 --> Output Class Initialized
INFO - 2021-06-15 14:21:18 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:18 --> Input Class Initialized
INFO - 2021-06-15 14:21:18 --> Language Class Initialized
ERROR - 2021-06-15 14:21:18 --> 404 Page Not Found: Admin/Images
ERROR - 2021-06-15 14:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:19 --> Config Class Initialized
INFO - 2021-06-15 14:21:19 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:19 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:19 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:19 --> URI Class Initialized
INFO - 2021-06-15 14:21:19 --> Router Class Initialized
INFO - 2021-06-15 14:21:19 --> Output Class Initialized
INFO - 2021-06-15 14:21:19 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:19 --> Input Class Initialized
INFO - 2021-06-15 14:21:19 --> Language Class Initialized
ERROR - 2021-06-15 14:21:19 --> 404 Page Not Found: Template/Default
ERROR - 2021-06-15 14:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:19 --> Config Class Initialized
INFO - 2021-06-15 14:21:19 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:19 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:19 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:19 --> URI Class Initialized
INFO - 2021-06-15 14:21:19 --> Router Class Initialized
INFO - 2021-06-15 14:21:19 --> Output Class Initialized
INFO - 2021-06-15 14:21:19 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:19 --> Input Class Initialized
INFO - 2021-06-15 14:21:19 --> Language Class Initialized
ERROR - 2021-06-15 14:21:19 --> 404 Page Not Found: Prompt/images
ERROR - 2021-06-15 14:21:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:20 --> Config Class Initialized
INFO - 2021-06-15 14:21:20 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:20 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:20 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:20 --> URI Class Initialized
INFO - 2021-06-15 14:21:20 --> Router Class Initialized
INFO - 2021-06-15 14:21:20 --> Output Class Initialized
INFO - 2021-06-15 14:21:20 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:20 --> Input Class Initialized
INFO - 2021-06-15 14:21:20 --> Language Class Initialized
ERROR - 2021-06-15 14:21:20 --> 404 Page Not Found: Admin/Images
ERROR - 2021-06-15 14:21:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:20 --> Config Class Initialized
INFO - 2021-06-15 14:21:20 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:20 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:20 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:20 --> URI Class Initialized
INFO - 2021-06-15 14:21:20 --> Router Class Initialized
INFO - 2021-06-15 14:21:20 --> Output Class Initialized
INFO - 2021-06-15 14:21:20 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:20 --> Input Class Initialized
INFO - 2021-06-15 14:21:20 --> Language Class Initialized
ERROR - 2021-06-15 14:21:20 --> 404 Page Not Found: Help/user
ERROR - 2021-06-15 14:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:21 --> Config Class Initialized
INFO - 2021-06-15 14:21:21 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:21 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:21 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:21 --> URI Class Initialized
INFO - 2021-06-15 14:21:21 --> Router Class Initialized
INFO - 2021-06-15 14:21:21 --> Output Class Initialized
INFO - 2021-06-15 14:21:21 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:21 --> Input Class Initialized
INFO - 2021-06-15 14:21:21 --> Language Class Initialized
ERROR - 2021-06-15 14:21:21 --> 404 Page Not Found: Media/com_hikashop
ERROR - 2021-06-15 14:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:21 --> Config Class Initialized
INFO - 2021-06-15 14:21:21 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:21 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:21 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:21 --> URI Class Initialized
INFO - 2021-06-15 14:21:21 --> Router Class Initialized
INFO - 2021-06-15 14:21:21 --> Output Class Initialized
INFO - 2021-06-15 14:21:21 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:21 --> Input Class Initialized
INFO - 2021-06-15 14:21:21 --> Language Class Initialized
ERROR - 2021-06-15 14:21:21 --> 404 Page Not Found: Templates/jsn_glass_pro
ERROR - 2021-06-15 14:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:22 --> Config Class Initialized
INFO - 2021-06-15 14:21:22 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:22 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:22 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:22 --> URI Class Initialized
INFO - 2021-06-15 14:21:22 --> Router Class Initialized
INFO - 2021-06-15 14:21:22 --> Output Class Initialized
INFO - 2021-06-15 14:21:22 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:22 --> Input Class Initialized
INFO - 2021-06-15 14:21:22 --> Language Class Initialized
ERROR - 2021-06-15 14:21:22 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-06-15 14:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:22 --> Config Class Initialized
INFO - 2021-06-15 14:21:22 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:22 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:22 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:22 --> URI Class Initialized
INFO - 2021-06-15 14:21:22 --> Router Class Initialized
INFO - 2021-06-15 14:21:22 --> Output Class Initialized
INFO - 2021-06-15 14:21:22 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:22 --> Input Class Initialized
INFO - 2021-06-15 14:21:22 --> Language Class Initialized
ERROR - 2021-06-15 14:21:22 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-06-15 14:21:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:23 --> Config Class Initialized
INFO - 2021-06-15 14:21:23 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:23 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:23 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:23 --> URI Class Initialized
INFO - 2021-06-15 14:21:23 --> Router Class Initialized
INFO - 2021-06-15 14:21:23 --> Output Class Initialized
INFO - 2021-06-15 14:21:23 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:23 --> Input Class Initialized
INFO - 2021-06-15 14:21:23 --> Language Class Initialized
ERROR - 2021-06-15 14:21:23 --> 404 Page Not Found: Public/js
ERROR - 2021-06-15 14:21:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:23 --> Config Class Initialized
INFO - 2021-06-15 14:21:23 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:23 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:23 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:23 --> URI Class Initialized
INFO - 2021-06-15 14:21:23 --> Router Class Initialized
INFO - 2021-06-15 14:21:23 --> Output Class Initialized
INFO - 2021-06-15 14:21:23 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:23 --> Input Class Initialized
INFO - 2021-06-15 14:21:23 --> Language Class Initialized
ERROR - 2021-06-15 14:21:23 --> 404 Page Not Found: Dokuphp/index
ERROR - 2021-06-15 14:21:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:23 --> Config Class Initialized
INFO - 2021-06-15 14:21:23 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:23 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:23 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:23 --> URI Class Initialized
INFO - 2021-06-15 14:21:23 --> Router Class Initialized
INFO - 2021-06-15 14:21:23 --> Output Class Initialized
INFO - 2021-06-15 14:21:23 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:23 --> Input Class Initialized
INFO - 2021-06-15 14:21:23 --> Language Class Initialized
ERROR - 2021-06-15 14:21:23 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-06-15 14:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:24 --> Config Class Initialized
INFO - 2021-06-15 14:21:24 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:24 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:24 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:24 --> URI Class Initialized
INFO - 2021-06-15 14:21:24 --> Router Class Initialized
INFO - 2021-06-15 14:21:24 --> Output Class Initialized
INFO - 2021-06-15 14:21:24 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:24 --> Input Class Initialized
INFO - 2021-06-15 14:21:24 --> Language Class Initialized
ERROR - 2021-06-15 14:21:24 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-06-15 14:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:24 --> Config Class Initialized
INFO - 2021-06-15 14:21:24 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:24 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:24 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:24 --> URI Class Initialized
INFO - 2021-06-15 14:21:24 --> Router Class Initialized
INFO - 2021-06-15 14:21:24 --> Output Class Initialized
INFO - 2021-06-15 14:21:24 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:24 --> Input Class Initialized
INFO - 2021-06-15 14:21:24 --> Language Class Initialized
ERROR - 2021-06-15 14:21:24 --> 404 Page Not Found: Scripts/jquery
ERROR - 2021-06-15 14:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:25 --> Config Class Initialized
INFO - 2021-06-15 14:21:25 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:25 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:25 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:25 --> URI Class Initialized
INFO - 2021-06-15 14:21:25 --> Router Class Initialized
INFO - 2021-06-15 14:21:25 --> Output Class Initialized
INFO - 2021-06-15 14:21:25 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:25 --> Input Class Initialized
INFO - 2021-06-15 14:21:25 --> Language Class Initialized
ERROR - 2021-06-15 14:21:25 --> 404 Page Not Found: Admin/start
ERROR - 2021-06-15 14:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:25 --> Config Class Initialized
INFO - 2021-06-15 14:21:25 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:25 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:25 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:25 --> URI Class Initialized
INFO - 2021-06-15 14:21:25 --> Router Class Initialized
INFO - 2021-06-15 14:21:25 --> Output Class Initialized
INFO - 2021-06-15 14:21:25 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:25 --> Input Class Initialized
INFO - 2021-06-15 14:21:25 --> Language Class Initialized
ERROR - 2021-06-15 14:21:25 --> 404 Page Not Found: App/Tpl
ERROR - 2021-06-15 14:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:26 --> Config Class Initialized
INFO - 2021-06-15 14:21:26 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:26 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:26 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:26 --> URI Class Initialized
INFO - 2021-06-15 14:21:26 --> Router Class Initialized
INFO - 2021-06-15 14:21:26 --> Output Class Initialized
INFO - 2021-06-15 14:21:26 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:26 --> Input Class Initialized
INFO - 2021-06-15 14:21:26 --> Language Class Initialized
ERROR - 2021-06-15 14:21:26 --> 404 Page Not Found: Style/default
ERROR - 2021-06-15 14:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:26 --> Config Class Initialized
INFO - 2021-06-15 14:21:26 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:26 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:26 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:26 --> URI Class Initialized
INFO - 2021-06-15 14:21:26 --> Router Class Initialized
INFO - 2021-06-15 14:21:26 --> Output Class Initialized
INFO - 2021-06-15 14:21:26 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:26 --> Input Class Initialized
INFO - 2021-06-15 14:21:26 --> Language Class Initialized
ERROR - 2021-06-15 14:21:26 --> 404 Page Not Found: Stylesheetcss/index
ERROR - 2021-06-15 14:21:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:27 --> Config Class Initialized
INFO - 2021-06-15 14:21:27 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:27 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:27 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:27 --> URI Class Initialized
INFO - 2021-06-15 14:21:27 --> Router Class Initialized
INFO - 2021-06-15 14:21:27 --> Output Class Initialized
INFO - 2021-06-15 14:21:27 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:27 --> Input Class Initialized
INFO - 2021-06-15 14:21:27 --> Language Class Initialized
ERROR - 2021-06-15 14:21:27 --> 404 Page Not Found: Includes/general.js
ERROR - 2021-06-15 14:21:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:27 --> Config Class Initialized
INFO - 2021-06-15 14:21:27 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:27 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:27 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:27 --> URI Class Initialized
INFO - 2021-06-15 14:21:27 --> Router Class Initialized
INFO - 2021-06-15 14:21:27 --> Output Class Initialized
INFO - 2021-06-15 14:21:27 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:27 --> Input Class Initialized
INFO - 2021-06-15 14:21:27 --> Language Class Initialized
ERROR - 2021-06-15 14:21:27 --> 404 Page Not Found: Archiver/index
ERROR - 2021-06-15 14:21:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:28 --> Config Class Initialized
INFO - 2021-06-15 14:21:28 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:28 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:28 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:28 --> URI Class Initialized
INFO - 2021-06-15 14:21:28 --> Router Class Initialized
INFO - 2021-06-15 14:21:28 --> Output Class Initialized
INFO - 2021-06-15 14:21:28 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:28 --> Input Class Initialized
INFO - 2021-06-15 14:21:28 --> Language Class Initialized
ERROR - 2021-06-15 14:21:28 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-06-15 14:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:29 --> Config Class Initialized
INFO - 2021-06-15 14:21:29 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:29 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:29 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:29 --> URI Class Initialized
INFO - 2021-06-15 14:21:29 --> Router Class Initialized
INFO - 2021-06-15 14:21:29 --> Output Class Initialized
INFO - 2021-06-15 14:21:29 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:29 --> Input Class Initialized
INFO - 2021-06-15 14:21:29 --> Language Class Initialized
ERROR - 2021-06-15 14:21:29 --> 404 Page Not Found: Inc/rsd.php
ERROR - 2021-06-15 14:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:30 --> Config Class Initialized
INFO - 2021-06-15 14:21:30 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:30 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:30 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:30 --> URI Class Initialized
INFO - 2021-06-15 14:21:30 --> Router Class Initialized
INFO - 2021-06-15 14:21:30 --> Output Class Initialized
INFO - 2021-06-15 14:21:30 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:30 --> Input Class Initialized
INFO - 2021-06-15 14:21:30 --> Language Class Initialized
ERROR - 2021-06-15 14:21:30 --> 404 Page Not Found: Rssphp/index
ERROR - 2021-06-15 14:21:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:31 --> Config Class Initialized
INFO - 2021-06-15 14:21:31 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:31 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:31 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:31 --> URI Class Initialized
INFO - 2021-06-15 14:21:31 --> Router Class Initialized
INFO - 2021-06-15 14:21:31 --> Output Class Initialized
INFO - 2021-06-15 14:21:31 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:31 --> Input Class Initialized
INFO - 2021-06-15 14:21:31 --> Language Class Initialized
ERROR - 2021-06-15 14:21:31 --> 404 Page Not Found: Adminsoft/templates
ERROR - 2021-06-15 14:21:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:31 --> Config Class Initialized
INFO - 2021-06-15 14:21:31 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:31 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:31 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:31 --> URI Class Initialized
INFO - 2021-06-15 14:21:31 --> Router Class Initialized
INFO - 2021-06-15 14:21:31 --> Output Class Initialized
INFO - 2021-06-15 14:21:31 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:31 --> Input Class Initialized
INFO - 2021-06-15 14:21:31 --> Language Class Initialized
ERROR - 2021-06-15 14:21:31 --> 404 Page Not Found: Archive/archive.css
ERROR - 2021-06-15 14:21:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:32 --> Config Class Initialized
INFO - 2021-06-15 14:21:32 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:32 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:32 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:32 --> URI Class Initialized
INFO - 2021-06-15 14:21:32 --> Router Class Initialized
INFO - 2021-06-15 14:21:32 --> Output Class Initialized
INFO - 2021-06-15 14:21:32 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:32 --> Input Class Initialized
INFO - 2021-06-15 14:21:32 --> Language Class Initialized
ERROR - 2021-06-15 14:21:32 --> 404 Page Not Found: Clientscript/vbulletin_ajax_htmlloader.js
ERROR - 2021-06-15 14:21:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:32 --> Config Class Initialized
INFO - 2021-06-15 14:21:32 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:32 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:32 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:32 --> URI Class Initialized
INFO - 2021-06-15 14:21:32 --> Router Class Initialized
INFO - 2021-06-15 14:21:33 --> Output Class Initialized
INFO - 2021-06-15 14:21:33 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:33 --> Input Class Initialized
INFO - 2021-06-15 14:21:33 --> Language Class Initialized
ERROR - 2021-06-15 14:21:33 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-06-15 14:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:33 --> Config Class Initialized
INFO - 2021-06-15 14:21:33 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:33 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:33 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:33 --> URI Class Initialized
INFO - 2021-06-15 14:21:33 --> Router Class Initialized
INFO - 2021-06-15 14:21:33 --> Output Class Initialized
INFO - 2021-06-15 14:21:33 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:33 --> Input Class Initialized
INFO - 2021-06-15 14:21:33 --> Language Class Initialized
ERROR - 2021-06-15 14:21:33 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-06-15 14:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:33 --> Config Class Initialized
INFO - 2021-06-15 14:21:33 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:33 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:33 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:33 --> URI Class Initialized
INFO - 2021-06-15 14:21:33 --> Router Class Initialized
INFO - 2021-06-15 14:21:33 --> Output Class Initialized
INFO - 2021-06-15 14:21:33 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:33 --> Input Class Initialized
INFO - 2021-06-15 14:21:33 --> Language Class Initialized
ERROR - 2021-06-15 14:21:33 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-06-15 14:21:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:34 --> Config Class Initialized
INFO - 2021-06-15 14:21:34 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:34 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:34 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:34 --> URI Class Initialized
INFO - 2021-06-15 14:21:34 --> Router Class Initialized
INFO - 2021-06-15 14:21:34 --> Output Class Initialized
INFO - 2021-06-15 14:21:34 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:34 --> Input Class Initialized
INFO - 2021-06-15 14:21:34 --> Language Class Initialized
ERROR - 2021-06-15 14:21:34 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-06-15 14:21:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:34 --> Config Class Initialized
INFO - 2021-06-15 14:21:34 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:34 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:34 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:34 --> URI Class Initialized
INFO - 2021-06-15 14:21:34 --> Router Class Initialized
INFO - 2021-06-15 14:21:34 --> Output Class Initialized
INFO - 2021-06-15 14:21:34 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:34 --> Input Class Initialized
INFO - 2021-06-15 14:21:34 --> Language Class Initialized
ERROR - 2021-06-15 14:21:34 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-06-15 14:21:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:35 --> Config Class Initialized
INFO - 2021-06-15 14:21:35 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:35 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:35 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:35 --> URI Class Initialized
INFO - 2021-06-15 14:21:35 --> Router Class Initialized
INFO - 2021-06-15 14:21:35 --> Output Class Initialized
INFO - 2021-06-15 14:21:35 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:35 --> Input Class Initialized
INFO - 2021-06-15 14:21:35 --> Language Class Initialized
ERROR - 2021-06-15 14:21:35 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-06-15 14:21:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:35 --> Config Class Initialized
INFO - 2021-06-15 14:21:35 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:35 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:35 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:35 --> URI Class Initialized
INFO - 2021-06-15 14:21:35 --> Router Class Initialized
INFO - 2021-06-15 14:21:35 --> Output Class Initialized
INFO - 2021-06-15 14:21:35 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:35 --> Input Class Initialized
INFO - 2021-06-15 14:21:35 --> Language Class Initialized
ERROR - 2021-06-15 14:21:35 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-06-15 14:21:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:36 --> Config Class Initialized
INFO - 2021-06-15 14:21:36 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:36 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:36 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:36 --> URI Class Initialized
INFO - 2021-06-15 14:21:36 --> Router Class Initialized
INFO - 2021-06-15 14:21:36 --> Output Class Initialized
INFO - 2021-06-15 14:21:36 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:36 --> Input Class Initialized
INFO - 2021-06-15 14:21:36 --> Language Class Initialized
ERROR - 2021-06-15 14:21:36 --> 404 Page Not Found: Common/common.js
ERROR - 2021-06-15 14:21:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:36 --> Config Class Initialized
INFO - 2021-06-15 14:21:36 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:36 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:36 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:36 --> URI Class Initialized
INFO - 2021-06-15 14:21:36 --> Router Class Initialized
INFO - 2021-06-15 14:21:36 --> Output Class Initialized
INFO - 2021-06-15 14:21:36 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:36 --> Input Class Initialized
INFO - 2021-06-15 14:21:36 --> Language Class Initialized
ERROR - 2021-06-15 14:21:36 --> 404 Page Not Found: Externphp/index
ERROR - 2021-06-15 14:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:37 --> Config Class Initialized
INFO - 2021-06-15 14:21:37 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:37 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:37 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:37 --> URI Class Initialized
INFO - 2021-06-15 14:21:37 --> Router Class Initialized
INFO - 2021-06-15 14:21:37 --> Output Class Initialized
INFO - 2021-06-15 14:21:37 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:37 --> Input Class Initialized
INFO - 2021-06-15 14:21:37 --> Language Class Initialized
ERROR - 2021-06-15 14:21:37 --> 404 Page Not Found: 404jpg/index
ERROR - 2021-06-15 14:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:37 --> Config Class Initialized
INFO - 2021-06-15 14:21:37 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:37 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:37 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:37 --> URI Class Initialized
INFO - 2021-06-15 14:21:37 --> Router Class Initialized
INFO - 2021-06-15 14:21:37 --> Output Class Initialized
INFO - 2021-06-15 14:21:37 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:37 --> Input Class Initialized
INFO - 2021-06-15 14:21:37 --> Language Class Initialized
ERROR - 2021-06-15 14:21:37 --> 404 Page Not Found: Ks_inc/ajax.js
ERROR - 2021-06-15 14:21:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:37 --> Config Class Initialized
INFO - 2021-06-15 14:21:37 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:37 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:37 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:37 --> URI Class Initialized
INFO - 2021-06-15 14:21:37 --> Router Class Initialized
INFO - 2021-06-15 14:21:37 --> Output Class Initialized
INFO - 2021-06-15 14:21:37 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:37 --> Input Class Initialized
INFO - 2021-06-15 14:21:37 --> Language Class Initialized
ERROR - 2021-06-15 14:21:37 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-06-15 14:21:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:38 --> Config Class Initialized
INFO - 2021-06-15 14:21:38 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:38 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:38 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:38 --> URI Class Initialized
INFO - 2021-06-15 14:21:38 --> Router Class Initialized
INFO - 2021-06-15 14:21:38 --> Output Class Initialized
INFO - 2021-06-15 14:21:38 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:38 --> Input Class Initialized
INFO - 2021-06-15 14:21:38 --> Language Class Initialized
ERROR - 2021-06-15 14:21:38 --> 404 Page Not Found: Static/hgicon.png
ERROR - 2021-06-15 14:21:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:38 --> Config Class Initialized
INFO - 2021-06-15 14:21:38 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:38 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:38 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:38 --> URI Class Initialized
INFO - 2021-06-15 14:21:38 --> Router Class Initialized
INFO - 2021-06-15 14:21:38 --> Output Class Initialized
INFO - 2021-06-15 14:21:38 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:38 --> Input Class Initialized
INFO - 2021-06-15 14:21:38 --> Language Class Initialized
ERROR - 2021-06-15 14:21:38 --> 404 Page Not Found: Base/login
ERROR - 2021-06-15 14:21:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:39 --> Config Class Initialized
INFO - 2021-06-15 14:21:39 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:39 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:39 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:39 --> URI Class Initialized
INFO - 2021-06-15 14:21:39 --> Router Class Initialized
INFO - 2021-06-15 14:21:39 --> Output Class Initialized
INFO - 2021-06-15 14:21:39 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:39 --> Input Class Initialized
INFO - 2021-06-15 14:21:39 --> Language Class Initialized
ERROR - 2021-06-15 14:21:39 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-06-15 14:21:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:40 --> Config Class Initialized
INFO - 2021-06-15 14:21:40 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:40 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:40 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:40 --> URI Class Initialized
INFO - 2021-06-15 14:21:40 --> Router Class Initialized
INFO - 2021-06-15 14:21:40 --> Output Class Initialized
INFO - 2021-06-15 14:21:40 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:40 --> Input Class Initialized
INFO - 2021-06-15 14:21:40 --> Language Class Initialized
ERROR - 2021-06-15 14:21:40 --> 404 Page Not Found: Js/ajax_x.js
ERROR - 2021-06-15 14:21:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:40 --> Config Class Initialized
INFO - 2021-06-15 14:21:40 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:40 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:40 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:40 --> URI Class Initialized
INFO - 2021-06-15 14:21:40 --> Router Class Initialized
INFO - 2021-06-15 14:21:40 --> Output Class Initialized
INFO - 2021-06-15 14:21:40 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:40 --> Input Class Initialized
INFO - 2021-06-15 14:21:40 --> Language Class Initialized
ERROR - 2021-06-15 14:21:40 --> 404 Page Not Found: Adminphp/index
ERROR - 2021-06-15 14:21:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:41 --> Config Class Initialized
INFO - 2021-06-15 14:21:41 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:41 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:41 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:41 --> URI Class Initialized
DEBUG - 2021-06-15 14:21:41 --> No URI present. Default controller set.
INFO - 2021-06-15 14:21:41 --> Router Class Initialized
INFO - 2021-06-15 14:21:41 --> Output Class Initialized
INFO - 2021-06-15 14:21:41 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:41 --> Input Class Initialized
INFO - 2021-06-15 14:21:41 --> Language Class Initialized
INFO - 2021-06-15 14:21:41 --> Loader Class Initialized
INFO - 2021-06-15 14:21:41 --> Helper loaded: url_helper
INFO - 2021-06-15 14:21:41 --> Helper loaded: form_helper
INFO - 2021-06-15 14:21:41 --> Helper loaded: common_helper
INFO - 2021-06-15 14:21:41 --> Database Driver Class Initialized
DEBUG - 2021-06-15 14:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 14:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 14:21:41 --> Controller Class Initialized
INFO - 2021-06-15 14:21:41 --> Form Validation Class Initialized
DEBUG - 2021-06-15 14:21:41 --> Encrypt Class Initialized
DEBUG - 2021-06-15 14:21:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 14:21:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 14:21:41 --> Email Class Initialized
INFO - 2021-06-15 14:21:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 14:21:41 --> Calendar Class Initialized
INFO - 2021-06-15 14:21:41 --> Model "Login_model" initialized
INFO - 2021-06-15 14:21:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 14:21:41 --> Final output sent to browser
DEBUG - 2021-06-15 14:21:41 --> Total execution time: 0.0203
ERROR - 2021-06-15 14:21:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:41 --> Config Class Initialized
INFO - 2021-06-15 14:21:41 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:41 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:41 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:41 --> URI Class Initialized
INFO - 2021-06-15 14:21:41 --> Router Class Initialized
INFO - 2021-06-15 14:21:41 --> Output Class Initialized
INFO - 2021-06-15 14:21:41 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:41 --> Input Class Initialized
INFO - 2021-06-15 14:21:41 --> Language Class Initialized
ERROR - 2021-06-15 14:21:41 --> 404 Page Not Found: Images/logo_product-cml.png
ERROR - 2021-06-15 14:21:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:42 --> Config Class Initialized
INFO - 2021-06-15 14:21:42 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:42 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:42 --> URI Class Initialized
INFO - 2021-06-15 14:21:42 --> Router Class Initialized
INFO - 2021-06-15 14:21:42 --> Output Class Initialized
INFO - 2021-06-15 14:21:42 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:42 --> Input Class Initialized
INFO - 2021-06-15 14:21:42 --> Language Class Initialized
ERROR - 2021-06-15 14:21:42 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-06-15 14:21:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:42 --> Config Class Initialized
INFO - 2021-06-15 14:21:42 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:42 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:42 --> URI Class Initialized
INFO - 2021-06-15 14:21:42 --> Router Class Initialized
INFO - 2021-06-15 14:21:42 --> Output Class Initialized
INFO - 2021-06-15 14:21:42 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:42 --> Input Class Initialized
INFO - 2021-06-15 14:21:42 --> Language Class Initialized
ERROR - 2021-06-15 14:21:42 --> 404 Page Not Found: Max-templates/classic
ERROR - 2021-06-15 14:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:43 --> Config Class Initialized
INFO - 2021-06-15 14:21:43 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:43 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:43 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:43 --> URI Class Initialized
INFO - 2021-06-15 14:21:43 --> Router Class Initialized
INFO - 2021-06-15 14:21:43 --> Output Class Initialized
INFO - 2021-06-15 14:21:43 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:43 --> Input Class Initialized
INFO - 2021-06-15 14:21:43 --> Language Class Initialized
ERROR - 2021-06-15 14:21:43 --> 404 Page Not Found: Admin/login.php
ERROR - 2021-06-15 14:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:44 --> Config Class Initialized
INFO - 2021-06-15 14:21:44 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:44 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:44 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:44 --> URI Class Initialized
INFO - 2021-06-15 14:21:44 --> Router Class Initialized
INFO - 2021-06-15 14:21:44 --> Output Class Initialized
INFO - 2021-06-15 14:21:44 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:44 --> Input Class Initialized
INFO - 2021-06-15 14:21:44 --> Language Class Initialized
ERROR - 2021-06-15 14:21:44 --> 404 Page Not Found: Images/logo_88x31.gif
ERROR - 2021-06-15 14:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:44 --> Config Class Initialized
INFO - 2021-06-15 14:21:44 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:44 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:44 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:44 --> URI Class Initialized
INFO - 2021-06-15 14:21:44 --> Router Class Initialized
INFO - 2021-06-15 14:21:44 --> Output Class Initialized
INFO - 2021-06-15 14:21:44 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:44 --> Input Class Initialized
INFO - 2021-06-15 14:21:44 --> Language Class Initialized
ERROR - 2021-06-15 14:21:44 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-06-15 14:21:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:45 --> Config Class Initialized
INFO - 2021-06-15 14:21:45 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:45 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:45 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:45 --> URI Class Initialized
INFO - 2021-06-15 14:21:45 --> Router Class Initialized
INFO - 2021-06-15 14:21:45 --> Output Class Initialized
INFO - 2021-06-15 14:21:45 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:45 --> Input Class Initialized
INFO - 2021-06-15 14:21:45 --> Language Class Initialized
ERROR - 2021-06-15 14:21:45 --> 404 Page Not Found: Admin/index
ERROR - 2021-06-15 14:21:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:45 --> Config Class Initialized
INFO - 2021-06-15 14:21:45 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:45 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:45 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:45 --> URI Class Initialized
INFO - 2021-06-15 14:21:45 --> Router Class Initialized
INFO - 2021-06-15 14:21:45 --> Output Class Initialized
INFO - 2021-06-15 14:21:45 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:45 --> Input Class Initialized
INFO - 2021-06-15 14:21:45 --> Language Class Initialized
ERROR - 2021-06-15 14:21:45 --> 404 Page Not Found: Plug/publish
ERROR - 2021-06-15 14:21:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:46 --> Config Class Initialized
INFO - 2021-06-15 14:21:46 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:46 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:46 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:46 --> URI Class Initialized
INFO - 2021-06-15 14:21:46 --> Router Class Initialized
INFO - 2021-06-15 14:21:46 --> Output Class Initialized
INFO - 2021-06-15 14:21:46 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:46 --> Input Class Initialized
INFO - 2021-06-15 14:21:46 --> Language Class Initialized
ERROR - 2021-06-15 14:21:46 --> 404 Page Not Found: Public/about.html
ERROR - 2021-06-15 14:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:47 --> Config Class Initialized
INFO - 2021-06-15 14:21:47 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:47 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:47 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:47 --> URI Class Initialized
INFO - 2021-06-15 14:21:47 --> Router Class Initialized
INFO - 2021-06-15 14:21:47 --> Output Class Initialized
INFO - 2021-06-15 14:21:47 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:47 --> Input Class Initialized
INFO - 2021-06-15 14:21:47 --> Language Class Initialized
ERROR - 2021-06-15 14:21:47 --> 404 Page Not Found: Help/en
ERROR - 2021-06-15 14:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:48 --> Config Class Initialized
INFO - 2021-06-15 14:21:48 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:48 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:48 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:48 --> URI Class Initialized
INFO - 2021-06-15 14:21:48 --> Router Class Initialized
INFO - 2021-06-15 14:21:48 --> Output Class Initialized
INFO - 2021-06-15 14:21:48 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:48 --> Input Class Initialized
INFO - 2021-06-15 14:21:48 --> Language Class Initialized
ERROR - 2021-06-15 14:21:48 --> 404 Page Not Found: Public/Admin
ERROR - 2021-06-15 14:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:48 --> Config Class Initialized
INFO - 2021-06-15 14:21:48 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:48 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:48 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:48 --> URI Class Initialized
INFO - 2021-06-15 14:21:48 --> Router Class Initialized
INFO - 2021-06-15 14:21:48 --> Output Class Initialized
INFO - 2021-06-15 14:21:48 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:48 --> Input Class Initialized
INFO - 2021-06-15 14:21:48 --> Language Class Initialized
ERROR - 2021-06-15 14:21:48 --> 404 Page Not Found: Imagesschool/style1
ERROR - 2021-06-15 14:21:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:49 --> Config Class Initialized
INFO - 2021-06-15 14:21:49 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:49 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:49 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:49 --> URI Class Initialized
INFO - 2021-06-15 14:21:49 --> Router Class Initialized
INFO - 2021-06-15 14:21:49 --> Output Class Initialized
INFO - 2021-06-15 14:21:49 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:49 --> Input Class Initialized
INFO - 2021-06-15 14:21:49 --> Language Class Initialized
ERROR - 2021-06-15 14:21:49 --> 404 Page Not Found: Script/login.js
ERROR - 2021-06-15 14:21:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:49 --> Config Class Initialized
INFO - 2021-06-15 14:21:49 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:49 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:49 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:49 --> URI Class Initialized
INFO - 2021-06-15 14:21:49 --> Router Class Initialized
INFO - 2021-06-15 14:21:49 --> Output Class Initialized
INFO - 2021-06-15 14:21:49 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:49 --> Input Class Initialized
INFO - 2021-06-15 14:21:49 --> Language Class Initialized
ERROR - 2021-06-15 14:21:49 --> 404 Page Not Found: Customdir/images
ERROR - 2021-06-15 14:21:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:50 --> Config Class Initialized
INFO - 2021-06-15 14:21:50 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:50 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:50 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:50 --> URI Class Initialized
INFO - 2021-06-15 14:21:50 --> Router Class Initialized
INFO - 2021-06-15 14:21:50 --> Output Class Initialized
INFO - 2021-06-15 14:21:50 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:50 --> Input Class Initialized
INFO - 2021-06-15 14:21:50 --> Language Class Initialized
ERROR - 2021-06-15 14:21:50 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-06-15 14:21:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:50 --> Config Class Initialized
INFO - 2021-06-15 14:21:50 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:50 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:50 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:50 --> URI Class Initialized
INFO - 2021-06-15 14:21:50 --> Router Class Initialized
INFO - 2021-06-15 14:21:50 --> Output Class Initialized
INFO - 2021-06-15 14:21:50 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:50 --> Input Class Initialized
INFO - 2021-06-15 14:21:50 --> Language Class Initialized
ERROR - 2021-06-15 14:21:50 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-06-15 14:21:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:51 --> Config Class Initialized
INFO - 2021-06-15 14:21:51 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:51 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:51 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:51 --> URI Class Initialized
INFO - 2021-06-15 14:21:51 --> Router Class Initialized
INFO - 2021-06-15 14:21:51 --> Output Class Initialized
INFO - 2021-06-15 14:21:51 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:51 --> Input Class Initialized
INFO - 2021-06-15 14:21:51 --> Language Class Initialized
ERROR - 2021-06-15 14:21:51 --> 404 Page Not Found: Images/logo-white.png
ERROR - 2021-06-15 14:21:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:52 --> Config Class Initialized
INFO - 2021-06-15 14:21:52 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:52 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:52 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:52 --> URI Class Initialized
INFO - 2021-06-15 14:21:52 --> Router Class Initialized
INFO - 2021-06-15 14:21:52 --> Output Class Initialized
INFO - 2021-06-15 14:21:52 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:52 --> Input Class Initialized
INFO - 2021-06-15 14:21:52 --> Language Class Initialized
ERROR - 2021-06-15 14:21:52 --> 404 Page Not Found: Include/dedeajax2.js
ERROR - 2021-06-15 14:21:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:52 --> Config Class Initialized
INFO - 2021-06-15 14:21:52 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:52 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:52 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:52 --> URI Class Initialized
INFO - 2021-06-15 14:21:52 --> Router Class Initialized
INFO - 2021-06-15 14:21:52 --> Output Class Initialized
INFO - 2021-06-15 14:21:52 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:52 --> Input Class Initialized
INFO - 2021-06-15 14:21:52 --> Language Class Initialized
ERROR - 2021-06-15 14:21:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-15 14:21:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:53 --> Config Class Initialized
INFO - 2021-06-15 14:21:53 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:53 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:53 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:53 --> URI Class Initialized
INFO - 2021-06-15 14:21:53 --> Router Class Initialized
INFO - 2021-06-15 14:21:53 --> Output Class Initialized
INFO - 2021-06-15 14:21:53 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:53 --> Input Class Initialized
INFO - 2021-06-15 14:21:53 --> Language Class Initialized
ERROR - 2021-06-15 14:21:53 --> 404 Page Not Found: Include/dialog
ERROR - 2021-06-15 14:21:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:53 --> Config Class Initialized
INFO - 2021-06-15 14:21:53 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:53 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:53 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:53 --> URI Class Initialized
INFO - 2021-06-15 14:21:53 --> Router Class Initialized
INFO - 2021-06-15 14:21:53 --> Output Class Initialized
INFO - 2021-06-15 14:21:53 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:53 --> Input Class Initialized
INFO - 2021-06-15 14:21:53 --> Language Class Initialized
ERROR - 2021-06-15 14:21:53 --> 404 Page Not Found: Plus/download.php
ERROR - 2021-06-15 14:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:54 --> Config Class Initialized
INFO - 2021-06-15 14:21:54 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:54 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:54 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:54 --> URI Class Initialized
INFO - 2021-06-15 14:21:54 --> Router Class Initialized
INFO - 2021-06-15 14:21:54 --> Output Class Initialized
INFO - 2021-06-15 14:21:54 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:54 --> Input Class Initialized
INFO - 2021-06-15 14:21:54 --> Language Class Initialized
ERROR - 2021-06-15 14:21:54 --> 404 Page Not Found: Diggphp/index
ERROR - 2021-06-15 14:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:54 --> Config Class Initialized
INFO - 2021-06-15 14:21:54 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:54 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:54 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:54 --> URI Class Initialized
INFO - 2021-06-15 14:21:54 --> Router Class Initialized
INFO - 2021-06-15 14:21:54 --> Output Class Initialized
INFO - 2021-06-15 14:21:54 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:54 --> Input Class Initialized
INFO - 2021-06-15 14:21:54 --> Language Class Initialized
ERROR - 2021-06-15 14:21:54 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-06-15 14:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:55 --> Config Class Initialized
INFO - 2021-06-15 14:21:55 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:55 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:55 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:55 --> URI Class Initialized
INFO - 2021-06-15 14:21:55 --> Router Class Initialized
INFO - 2021-06-15 14:21:55 --> Output Class Initialized
INFO - 2021-06-15 14:21:55 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:55 --> Input Class Initialized
INFO - 2021-06-15 14:21:55 --> Language Class Initialized
ERROR - 2021-06-15 14:21:55 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-06-15 14:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:55 --> Config Class Initialized
INFO - 2021-06-15 14:21:55 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:55 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:55 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:55 --> URI Class Initialized
INFO - 2021-06-15 14:21:55 --> Router Class Initialized
INFO - 2021-06-15 14:21:55 --> Output Class Initialized
INFO - 2021-06-15 14:21:55 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:55 --> Input Class Initialized
INFO - 2021-06-15 14:21:55 --> Language Class Initialized
ERROR - 2021-06-15 14:21:55 --> 404 Page Not Found: Plus/heightsearch.php
ERROR - 2021-06-15 14:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:55 --> Config Class Initialized
INFO - 2021-06-15 14:21:55 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:55 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:55 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:55 --> URI Class Initialized
INFO - 2021-06-15 14:21:55 --> Router Class Initialized
INFO - 2021-06-15 14:21:55 --> Output Class Initialized
INFO - 2021-06-15 14:21:55 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:55 --> Input Class Initialized
INFO - 2021-06-15 14:21:55 --> Language Class Initialized
ERROR - 2021-06-15 14:21:55 --> 404 Page Not Found: Member/space
ERROR - 2021-06-15 14:21:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:56 --> Config Class Initialized
INFO - 2021-06-15 14:21:56 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:56 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:56 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:56 --> URI Class Initialized
INFO - 2021-06-15 14:21:56 --> Router Class Initialized
INFO - 2021-06-15 14:21:56 --> Output Class Initialized
INFO - 2021-06-15 14:21:56 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:56 --> Input Class Initialized
INFO - 2021-06-15 14:21:56 --> Language Class Initialized
ERROR - 2021-06-15 14:21:56 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-06-15 14:21:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:56 --> Config Class Initialized
INFO - 2021-06-15 14:21:56 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:56 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:56 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:56 --> URI Class Initialized
INFO - 2021-06-15 14:21:56 --> Router Class Initialized
INFO - 2021-06-15 14:21:56 --> Output Class Initialized
INFO - 2021-06-15 14:21:56 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:56 --> Input Class Initialized
INFO - 2021-06-15 14:21:56 --> Language Class Initialized
ERROR - 2021-06-15 14:21:56 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-06-15 14:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:57 --> Config Class Initialized
INFO - 2021-06-15 14:21:57 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:57 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:57 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:57 --> URI Class Initialized
INFO - 2021-06-15 14:21:57 --> Router Class Initialized
INFO - 2021-06-15 14:21:57 --> Output Class Initialized
INFO - 2021-06-15 14:21:57 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:57 --> Input Class Initialized
INFO - 2021-06-15 14:21:57 --> Language Class Initialized
ERROR - 2021-06-15 14:21:57 --> 404 Page Not Found: Help/index
ERROR - 2021-06-15 14:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:57 --> Config Class Initialized
INFO - 2021-06-15 14:21:57 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:57 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:57 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:57 --> URI Class Initialized
INFO - 2021-06-15 14:21:57 --> Router Class Initialized
INFO - 2021-06-15 14:21:57 --> Output Class Initialized
INFO - 2021-06-15 14:21:57 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:57 --> Input Class Initialized
INFO - 2021-06-15 14:21:57 --> Language Class Initialized
ERROR - 2021-06-15 14:21:57 --> 404 Page Not Found: Images/branding
ERROR - 2021-06-15 14:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:58 --> Config Class Initialized
INFO - 2021-06-15 14:21:58 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:58 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:58 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:58 --> URI Class Initialized
INFO - 2021-06-15 14:21:58 --> Router Class Initialized
INFO - 2021-06-15 14:21:58 --> Output Class Initialized
INFO - 2021-06-15 14:21:58 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:58 --> Input Class Initialized
INFO - 2021-06-15 14:21:58 --> Language Class Initialized
ERROR - 2021-06-15 14:21:58 --> 404 Page Not Found: Install/logo.gif
ERROR - 2021-06-15 14:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:58 --> Config Class Initialized
INFO - 2021-06-15 14:21:58 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:58 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:58 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:58 --> URI Class Initialized
INFO - 2021-06-15 14:21:58 --> Router Class Initialized
INFO - 2021-06-15 14:21:58 --> Output Class Initialized
INFO - 2021-06-15 14:21:58 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:58 --> Input Class Initialized
INFO - 2021-06-15 14:21:58 --> Language Class Initialized
ERROR - 2021-06-15 14:21:58 --> 404 Page Not Found: M/index
ERROR - 2021-06-15 14:21:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:59 --> Config Class Initialized
INFO - 2021-06-15 14:21:59 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:59 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:59 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:59 --> URI Class Initialized
INFO - 2021-06-15 14:21:59 --> Router Class Initialized
INFO - 2021-06-15 14:21:59 --> Output Class Initialized
INFO - 2021-06-15 14:21:59 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:59 --> Input Class Initialized
INFO - 2021-06-15 14:21:59 --> Language Class Initialized
ERROR - 2021-06-15 14:21:59 --> 404 Page Not Found: Adminphp/index
ERROR - 2021-06-15 14:21:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:21:59 --> Config Class Initialized
INFO - 2021-06-15 14:21:59 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:21:59 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:21:59 --> Utf8 Class Initialized
INFO - 2021-06-15 14:21:59 --> URI Class Initialized
INFO - 2021-06-15 14:21:59 --> Router Class Initialized
INFO - 2021-06-15 14:21:59 --> Output Class Initialized
INFO - 2021-06-15 14:21:59 --> Security Class Initialized
DEBUG - 2021-06-15 14:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:21:59 --> Input Class Initialized
INFO - 2021-06-15 14:21:59 --> Language Class Initialized
ERROR - 2021-06-15 14:21:59 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-06-15 14:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:00 --> Config Class Initialized
INFO - 2021-06-15 14:22:00 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:00 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:00 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:00 --> URI Class Initialized
INFO - 2021-06-15 14:22:00 --> Router Class Initialized
INFO - 2021-06-15 14:22:00 --> Output Class Initialized
INFO - 2021-06-15 14:22:00 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:00 --> Input Class Initialized
INFO - 2021-06-15 14:22:00 --> Language Class Initialized
ERROR - 2021-06-15 14:22:00 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-06-15 14:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:00 --> Config Class Initialized
INFO - 2021-06-15 14:22:00 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:00 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:00 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:00 --> URI Class Initialized
INFO - 2021-06-15 14:22:00 --> Router Class Initialized
INFO - 2021-06-15 14:22:00 --> Output Class Initialized
INFO - 2021-06-15 14:22:00 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:00 --> Input Class Initialized
INFO - 2021-06-15 14:22:00 --> Language Class Initialized
ERROR - 2021-06-15 14:22:00 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-06-15 14:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:00 --> Config Class Initialized
INFO - 2021-06-15 14:22:00 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:00 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:00 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:00 --> URI Class Initialized
INFO - 2021-06-15 14:22:00 --> Router Class Initialized
INFO - 2021-06-15 14:22:00 --> Output Class Initialized
INFO - 2021-06-15 14:22:00 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:00 --> Input Class Initialized
INFO - 2021-06-15 14:22:00 --> Language Class Initialized
ERROR - 2021-06-15 14:22:00 --> 404 Page Not Found: Webbuilder/script
ERROR - 2021-06-15 14:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:01 --> Config Class Initialized
INFO - 2021-06-15 14:22:01 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:01 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:01 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:01 --> URI Class Initialized
INFO - 2021-06-15 14:22:01 --> Router Class Initialized
INFO - 2021-06-15 14:22:01 --> Output Class Initialized
INFO - 2021-06-15 14:22:01 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:01 --> Input Class Initialized
INFO - 2021-06-15 14:22:01 --> Language Class Initialized
ERROR - 2021-06-15 14:22:01 --> 404 Page Not Found: Images/login_Name.jpg
ERROR - 2021-06-15 14:22:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:02 --> Config Class Initialized
INFO - 2021-06-15 14:22:02 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:02 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:02 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:02 --> URI Class Initialized
INFO - 2021-06-15 14:22:02 --> Router Class Initialized
INFO - 2021-06-15 14:22:02 --> Output Class Initialized
INFO - 2021-06-15 14:22:02 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:02 --> Input Class Initialized
INFO - 2021-06-15 14:22:02 --> Language Class Initialized
ERROR - 2021-06-15 14:22:02 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-06-15 14:22:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:02 --> Config Class Initialized
INFO - 2021-06-15 14:22:02 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:02 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:02 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:02 --> URI Class Initialized
INFO - 2021-06-15 14:22:02 --> Router Class Initialized
INFO - 2021-06-15 14:22:02 --> Output Class Initialized
INFO - 2021-06-15 14:22:02 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:02 --> Input Class Initialized
INFO - 2021-06-15 14:22:02 --> Language Class Initialized
ERROR - 2021-06-15 14:22:02 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-06-15 14:22:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:03 --> Config Class Initialized
INFO - 2021-06-15 14:22:03 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:03 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:03 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:03 --> URI Class Initialized
INFO - 2021-06-15 14:22:03 --> Router Class Initialized
INFO - 2021-06-15 14:22:03 --> Output Class Initialized
INFO - 2021-06-15 14:22:03 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:03 --> Input Class Initialized
INFO - 2021-06-15 14:22:03 --> Language Class Initialized
ERROR - 2021-06-15 14:22:03 --> 404 Page Not Found: Site/Pages
ERROR - 2021-06-15 14:22:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:03 --> Config Class Initialized
INFO - 2021-06-15 14:22:03 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:03 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:03 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:03 --> URI Class Initialized
INFO - 2021-06-15 14:22:03 --> Router Class Initialized
INFO - 2021-06-15 14:22:03 --> Output Class Initialized
INFO - 2021-06-15 14:22:03 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:03 --> Input Class Initialized
INFO - 2021-06-15 14:22:03 --> Language Class Initialized
ERROR - 2021-06-15 14:22:03 --> 404 Page Not Found: Site/SystemThemes
ERROR - 2021-06-15 14:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:04 --> Config Class Initialized
INFO - 2021-06-15 14:22:04 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:04 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:04 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:04 --> URI Class Initialized
INFO - 2021-06-15 14:22:04 --> Router Class Initialized
INFO - 2021-06-15 14:22:04 --> Output Class Initialized
INFO - 2021-06-15 14:22:04 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:04 --> Input Class Initialized
INFO - 2021-06-15 14:22:04 --> Language Class Initialized
ERROR - 2021-06-15 14:22:04 --> 404 Page Not Found: Forumphp/index
ERROR - 2021-06-15 14:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:04 --> Config Class Initialized
INFO - 2021-06-15 14:22:04 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:04 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:04 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:04 --> URI Class Initialized
INFO - 2021-06-15 14:22:04 --> Router Class Initialized
INFO - 2021-06-15 14:22:04 --> Output Class Initialized
INFO - 2021-06-15 14:22:04 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:04 --> Input Class Initialized
INFO - 2021-06-15 14:22:04 --> Language Class Initialized
ERROR - 2021-06-15 14:22:04 --> 404 Page Not Found: Archiver/index
ERROR - 2021-06-15 14:22:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:05 --> Config Class Initialized
INFO - 2021-06-15 14:22:05 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:05 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:05 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:05 --> URI Class Initialized
INFO - 2021-06-15 14:22:05 --> Router Class Initialized
INFO - 2021-06-15 14:22:05 --> Output Class Initialized
INFO - 2021-06-15 14:22:05 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:05 --> Input Class Initialized
INFO - 2021-06-15 14:22:05 --> Language Class Initialized
ERROR - 2021-06-15 14:22:05 --> 404 Page Not Found: Uc_server/control
ERROR - 2021-06-15 14:22:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:05 --> Config Class Initialized
INFO - 2021-06-15 14:22:05 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:05 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:05 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:05 --> URI Class Initialized
INFO - 2021-06-15 14:22:05 --> Router Class Initialized
INFO - 2021-06-15 14:22:05 --> Output Class Initialized
INFO - 2021-06-15 14:22:05 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:05 --> Input Class Initialized
INFO - 2021-06-15 14:22:05 --> Language Class Initialized
ERROR - 2021-06-15 14:22:05 --> 404 Page Not Found: Img/pic
ERROR - 2021-06-15 14:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:06 --> Config Class Initialized
INFO - 2021-06-15 14:22:06 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:06 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:06 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:06 --> URI Class Initialized
INFO - 2021-06-15 14:22:06 --> Router Class Initialized
INFO - 2021-06-15 14:22:06 --> Output Class Initialized
INFO - 2021-06-15 14:22:06 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:06 --> Input Class Initialized
INFO - 2021-06-15 14:22:06 --> Language Class Initialized
ERROR - 2021-06-15 14:22:06 --> 404 Page Not Found: Business/images
ERROR - 2021-06-15 14:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:06 --> Config Class Initialized
INFO - 2021-06-15 14:22:06 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:06 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:06 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:06 --> URI Class Initialized
INFO - 2021-06-15 14:22:06 --> Router Class Initialized
INFO - 2021-06-15 14:22:06 --> Output Class Initialized
INFO - 2021-06-15 14:22:06 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:06 --> Input Class Initialized
INFO - 2021-06-15 14:22:06 --> Language Class Initialized
ERROR - 2021-06-15 14:22:06 --> 404 Page Not Found: Include/EcsServerApi.js
ERROR - 2021-06-15 14:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:07 --> Config Class Initialized
INFO - 2021-06-15 14:22:07 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:07 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:07 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:07 --> URI Class Initialized
INFO - 2021-06-15 14:22:07 --> Router Class Initialized
INFO - 2021-06-15 14:22:07 --> Output Class Initialized
INFO - 2021-06-15 14:22:07 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:07 --> Input Class Initialized
INFO - 2021-06-15 14:22:07 --> Language Class Initialized
ERROR - 2021-06-15 14:22:07 --> 404 Page Not Found: Images/Default_bg_002.gif
ERROR - 2021-06-15 14:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:07 --> Config Class Initialized
INFO - 2021-06-15 14:22:07 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:07 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:07 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:07 --> URI Class Initialized
INFO - 2021-06-15 14:22:07 --> Router Class Initialized
INFO - 2021-06-15 14:22:07 --> Output Class Initialized
INFO - 2021-06-15 14:22:07 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:07 --> Input Class Initialized
INFO - 2021-06-15 14:22:07 --> Language Class Initialized
ERROR - 2021-06-15 14:22:07 --> 404 Page Not Found: Eams/static
ERROR - 2021-06-15 14:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:08 --> Config Class Initialized
INFO - 2021-06-15 14:22:08 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:08 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:08 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:08 --> URI Class Initialized
INFO - 2021-06-15 14:22:08 --> Router Class Initialized
INFO - 2021-06-15 14:22:08 --> Output Class Initialized
INFO - 2021-06-15 14:22:08 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:08 --> Input Class Initialized
INFO - 2021-06-15 14:22:08 --> Language Class Initialized
ERROR - 2021-06-15 14:22:08 --> 404 Page Not Found: Custom/SkinTemplate
ERROR - 2021-06-15 14:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:08 --> Config Class Initialized
INFO - 2021-06-15 14:22:08 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:08 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:08 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:08 --> URI Class Initialized
INFO - 2021-06-15 14:22:08 --> Router Class Initialized
INFO - 2021-06-15 14:22:08 --> Output Class Initialized
INFO - 2021-06-15 14:22:08 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:08 --> Input Class Initialized
INFO - 2021-06-15 14:22:08 --> Language Class Initialized
ERROR - 2021-06-15 14:22:08 --> 404 Page Not Found: Admin/admin_login.php
ERROR - 2021-06-15 14:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:09 --> Config Class Initialized
INFO - 2021-06-15 14:22:09 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:09 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:09 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:09 --> URI Class Initialized
INFO - 2021-06-15 14:22:09 --> Router Class Initialized
INFO - 2021-06-15 14:22:09 --> Output Class Initialized
INFO - 2021-06-15 14:22:09 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:09 --> Input Class Initialized
INFO - 2021-06-15 14:22:09 --> Language Class Initialized
ERROR - 2021-06-15 14:22:09 --> 404 Page Not Found: Data/images
ERROR - 2021-06-15 14:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:09 --> Config Class Initialized
INFO - 2021-06-15 14:22:09 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:09 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:09 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:09 --> URI Class Initialized
INFO - 2021-06-15 14:22:09 --> Router Class Initialized
INFO - 2021-06-15 14:22:09 --> Output Class Initialized
INFO - 2021-06-15 14:22:09 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:09 --> Input Class Initialized
INFO - 2021-06-15 14:22:09 --> Language Class Initialized
ERROR - 2021-06-15 14:22:09 --> 404 Page Not Found: Static/images
ERROR - 2021-06-15 14:22:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:10 --> Config Class Initialized
INFO - 2021-06-15 14:22:10 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:10 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:10 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:10 --> URI Class Initialized
INFO - 2021-06-15 14:22:10 --> Router Class Initialized
INFO - 2021-06-15 14:22:10 --> Output Class Initialized
INFO - 2021-06-15 14:22:10 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:10 --> Input Class Initialized
INFO - 2021-06-15 14:22:10 --> Language Class Initialized
ERROR - 2021-06-15 14:22:10 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2021-06-15 14:22:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:10 --> Config Class Initialized
INFO - 2021-06-15 14:22:10 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:10 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:10 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:10 --> URI Class Initialized
INFO - 2021-06-15 14:22:10 --> Router Class Initialized
INFO - 2021-06-15 14:22:10 --> Output Class Initialized
INFO - 2021-06-15 14:22:10 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:10 --> Input Class Initialized
INFO - 2021-06-15 14:22:10 --> Language Class Initialized
ERROR - 2021-06-15 14:22:10 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-06-15 14:22:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:14 --> Config Class Initialized
INFO - 2021-06-15 14:22:14 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:14 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:14 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:14 --> URI Class Initialized
INFO - 2021-06-15 14:22:14 --> Router Class Initialized
INFO - 2021-06-15 14:22:14 --> Output Class Initialized
INFO - 2021-06-15 14:22:14 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:14 --> Input Class Initialized
INFO - 2021-06-15 14:22:14 --> Language Class Initialized
ERROR - 2021-06-15 14:22:14 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-15 14:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:15 --> Config Class Initialized
INFO - 2021-06-15 14:22:15 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:15 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:15 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:15 --> URI Class Initialized
INFO - 2021-06-15 14:22:15 --> Router Class Initialized
INFO - 2021-06-15 14:22:15 --> Output Class Initialized
INFO - 2021-06-15 14:22:15 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:15 --> Input Class Initialized
INFO - 2021-06-15 14:22:15 --> Language Class Initialized
ERROR - 2021-06-15 14:22:15 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-06-15 14:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:15 --> Config Class Initialized
INFO - 2021-06-15 14:22:15 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:15 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:15 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:15 --> URI Class Initialized
INFO - 2021-06-15 14:22:15 --> Router Class Initialized
INFO - 2021-06-15 14:22:15 --> Output Class Initialized
INFO - 2021-06-15 14:22:15 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:15 --> Input Class Initialized
INFO - 2021-06-15 14:22:15 --> Language Class Initialized
ERROR - 2021-06-15 14:22:15 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-06-15 14:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:15 --> Config Class Initialized
INFO - 2021-06-15 14:22:15 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:15 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:15 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:15 --> URI Class Initialized
INFO - 2021-06-15 14:22:15 --> Router Class Initialized
INFO - 2021-06-15 14:22:15 --> Output Class Initialized
INFO - 2021-06-15 14:22:15 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:15 --> Input Class Initialized
INFO - 2021-06-15 14:22:15 --> Language Class Initialized
ERROR - 2021-06-15 14:22:15 --> 404 Page Not Found: Was5/web
ERROR - 2021-06-15 14:22:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:16 --> Config Class Initialized
INFO - 2021-06-15 14:22:16 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:16 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:16 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:16 --> URI Class Initialized
INFO - 2021-06-15 14:22:16 --> Router Class Initialized
INFO - 2021-06-15 14:22:16 --> Output Class Initialized
INFO - 2021-06-15 14:22:16 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:16 --> Input Class Initialized
INFO - 2021-06-15 14:22:16 --> Language Class Initialized
ERROR - 2021-06-15 14:22:16 --> 404 Page Not Found: Was/main.html
ERROR - 2021-06-15 14:22:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:16 --> Config Class Initialized
INFO - 2021-06-15 14:22:16 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:16 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:16 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:16 --> URI Class Initialized
INFO - 2021-06-15 14:22:16 --> Router Class Initialized
INFO - 2021-06-15 14:22:16 --> Output Class Initialized
INFO - 2021-06-15 14:22:16 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:16 --> Input Class Initialized
INFO - 2021-06-15 14:22:16 --> Language Class Initialized
ERROR - 2021-06-15 14:22:16 --> 404 Page Not Found: Logo/logo_jw.png
ERROR - 2021-06-15 14:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:17 --> Config Class Initialized
INFO - 2021-06-15 14:22:17 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:17 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:17 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:17 --> URI Class Initialized
INFO - 2021-06-15 14:22:17 --> Router Class Initialized
INFO - 2021-06-15 14:22:17 --> Output Class Initialized
INFO - 2021-06-15 14:22:17 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:17 --> Input Class Initialized
INFO - 2021-06-15 14:22:17 --> Language Class Initialized
ERROR - 2021-06-15 14:22:17 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-15 14:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:17 --> Config Class Initialized
INFO - 2021-06-15 14:22:17 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:17 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:17 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:17 --> URI Class Initialized
INFO - 2021-06-15 14:22:17 --> Router Class Initialized
INFO - 2021-06-15 14:22:17 --> Output Class Initialized
INFO - 2021-06-15 14:22:17 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:17 --> Input Class Initialized
INFO - 2021-06-15 14:22:17 --> Language Class Initialized
ERROR - 2021-06-15 14:22:17 --> 404 Page Not Found: Weblog/index
ERROR - 2021-06-15 14:22:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:18 --> Config Class Initialized
INFO - 2021-06-15 14:22:18 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:18 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:18 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:18 --> URI Class Initialized
INFO - 2021-06-15 14:22:18 --> Router Class Initialized
INFO - 2021-06-15 14:22:18 --> Output Class Initialized
INFO - 2021-06-15 14:22:18 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:18 --> Input Class Initialized
INFO - 2021-06-15 14:22:18 --> Language Class Initialized
ERROR - 2021-06-15 14:22:18 --> 404 Page Not Found: Blog/index
ERROR - 2021-06-15 14:22:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:19 --> Config Class Initialized
INFO - 2021-06-15 14:22:19 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:19 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:19 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:19 --> URI Class Initialized
INFO - 2021-06-15 14:22:19 --> Router Class Initialized
INFO - 2021-06-15 14:22:19 --> Output Class Initialized
INFO - 2021-06-15 14:22:19 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:19 --> Input Class Initialized
INFO - 2021-06-15 14:22:19 --> Language Class Initialized
ERROR - 2021-06-15 14:22:19 --> 404 Page Not Found: Forum/index
ERROR - 2021-06-15 14:22:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:19 --> Config Class Initialized
INFO - 2021-06-15 14:22:19 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:19 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:19 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:19 --> URI Class Initialized
INFO - 2021-06-15 14:22:19 --> Router Class Initialized
INFO - 2021-06-15 14:22:19 --> Output Class Initialized
INFO - 2021-06-15 14:22:19 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:19 --> Input Class Initialized
INFO - 2021-06-15 14:22:19 --> Language Class Initialized
ERROR - 2021-06-15 14:22:19 --> 404 Page Not Found: Bbs/index
ERROR - 2021-06-15 14:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:20 --> Config Class Initialized
INFO - 2021-06-15 14:22:20 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:20 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:20 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:20 --> URI Class Initialized
INFO - 2021-06-15 14:22:20 --> Router Class Initialized
INFO - 2021-06-15 14:22:20 --> Output Class Initialized
INFO - 2021-06-15 14:22:20 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:20 --> Input Class Initialized
INFO - 2021-06-15 14:22:20 --> Language Class Initialized
ERROR - 2021-06-15 14:22:20 --> 404 Page Not Found: Wcm/index
ERROR - 2021-06-15 14:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 14:22:20 --> Config Class Initialized
INFO - 2021-06-15 14:22:20 --> Hooks Class Initialized
DEBUG - 2021-06-15 14:22:20 --> UTF-8 Support Enabled
INFO - 2021-06-15 14:22:20 --> Utf8 Class Initialized
INFO - 2021-06-15 14:22:20 --> URI Class Initialized
INFO - 2021-06-15 14:22:20 --> Router Class Initialized
INFO - 2021-06-15 14:22:20 --> Output Class Initialized
INFO - 2021-06-15 14:22:20 --> Security Class Initialized
DEBUG - 2021-06-15 14:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 14:22:20 --> Input Class Initialized
INFO - 2021-06-15 14:22:20 --> Language Class Initialized
ERROR - 2021-06-15 14:22:20 --> 404 Page Not Found: Admin/editor
ERROR - 2021-06-15 15:02:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:02:04 --> Config Class Initialized
INFO - 2021-06-15 15:02:04 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:02:04 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:02:04 --> Utf8 Class Initialized
INFO - 2021-06-15 15:02:04 --> URI Class Initialized
DEBUG - 2021-06-15 15:02:04 --> No URI present. Default controller set.
INFO - 2021-06-15 15:02:04 --> Router Class Initialized
INFO - 2021-06-15 15:02:04 --> Output Class Initialized
INFO - 2021-06-15 15:02:04 --> Security Class Initialized
DEBUG - 2021-06-15 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:02:04 --> Input Class Initialized
INFO - 2021-06-15 15:02:04 --> Language Class Initialized
INFO - 2021-06-15 15:02:04 --> Loader Class Initialized
INFO - 2021-06-15 15:02:04 --> Helper loaded: url_helper
INFO - 2021-06-15 15:02:04 --> Helper loaded: form_helper
INFO - 2021-06-15 15:02:04 --> Helper loaded: common_helper
INFO - 2021-06-15 15:02:04 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:02:04 --> Controller Class Initialized
INFO - 2021-06-15 15:02:04 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:02:04 --> Encrypt Class Initialized
DEBUG - 2021-06-15 15:02:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 15:02:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 15:02:04 --> Email Class Initialized
INFO - 2021-06-15 15:02:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 15:02:04 --> Calendar Class Initialized
INFO - 2021-06-15 15:02:04 --> Model "Login_model" initialized
INFO - 2021-06-15 15:02:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 15:02:04 --> Final output sent to browser
DEBUG - 2021-06-15 15:02:04 --> Total execution time: 0.1036
ERROR - 2021-06-15 15:02:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:02:04 --> Config Class Initialized
INFO - 2021-06-15 15:02:04 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:02:04 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:02:04 --> Utf8 Class Initialized
INFO - 2021-06-15 15:02:04 --> URI Class Initialized
INFO - 2021-06-15 15:02:04 --> Router Class Initialized
INFO - 2021-06-15 15:02:04 --> Output Class Initialized
INFO - 2021-06-15 15:02:04 --> Security Class Initialized
DEBUG - 2021-06-15 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:02:04 --> Input Class Initialized
INFO - 2021-06-15 15:02:04 --> Language Class Initialized
ERROR - 2021-06-15 15:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-15 15:02:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:02:04 --> Config Class Initialized
INFO - 2021-06-15 15:02:04 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:02:04 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:02:04 --> Utf8 Class Initialized
INFO - 2021-06-15 15:02:04 --> URI Class Initialized
DEBUG - 2021-06-15 15:02:04 --> No URI present. Default controller set.
INFO - 2021-06-15 15:02:04 --> Router Class Initialized
INFO - 2021-06-15 15:02:04 --> Output Class Initialized
INFO - 2021-06-15 15:02:04 --> Security Class Initialized
DEBUG - 2021-06-15 15:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:02:04 --> Input Class Initialized
INFO - 2021-06-15 15:02:04 --> Language Class Initialized
INFO - 2021-06-15 15:02:04 --> Loader Class Initialized
INFO - 2021-06-15 15:02:04 --> Helper loaded: url_helper
INFO - 2021-06-15 15:02:04 --> Helper loaded: form_helper
INFO - 2021-06-15 15:02:04 --> Helper loaded: common_helper
INFO - 2021-06-15 15:02:04 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:02:04 --> Controller Class Initialized
INFO - 2021-06-15 15:02:04 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:02:04 --> Encrypt Class Initialized
DEBUG - 2021-06-15 15:02:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 15:02:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 15:02:04 --> Email Class Initialized
INFO - 2021-06-15 15:02:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 15:02:04 --> Calendar Class Initialized
INFO - 2021-06-15 15:02:04 --> Model "Login_model" initialized
INFO - 2021-06-15 15:02:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 15:02:04 --> Final output sent to browser
DEBUG - 2021-06-15 15:02:04 --> Total execution time: 0.0205
ERROR - 2021-06-15 15:02:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:02:05 --> Config Class Initialized
INFO - 2021-06-15 15:02:05 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:02:05 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:02:05 --> Utf8 Class Initialized
INFO - 2021-06-15 15:02:05 --> URI Class Initialized
INFO - 2021-06-15 15:02:05 --> Router Class Initialized
INFO - 2021-06-15 15:02:05 --> Output Class Initialized
INFO - 2021-06-15 15:02:05 --> Security Class Initialized
DEBUG - 2021-06-15 15:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:02:05 --> Input Class Initialized
INFO - 2021-06-15 15:02:05 --> Language Class Initialized
ERROR - 2021-06-15 15:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-15 15:02:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:02:05 --> Config Class Initialized
INFO - 2021-06-15 15:02:05 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:02:05 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:02:05 --> Utf8 Class Initialized
INFO - 2021-06-15 15:02:05 --> URI Class Initialized
INFO - 2021-06-15 15:02:05 --> Router Class Initialized
INFO - 2021-06-15 15:02:05 --> Output Class Initialized
INFO - 2021-06-15 15:02:05 --> Security Class Initialized
DEBUG - 2021-06-15 15:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:02:05 --> Input Class Initialized
INFO - 2021-06-15 15:02:05 --> Language Class Initialized
ERROR - 2021-06-15 15:02:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-15 15:02:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:02:09 --> Config Class Initialized
INFO - 2021-06-15 15:02:09 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:02:09 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:02:09 --> Utf8 Class Initialized
INFO - 2021-06-15 15:02:09 --> URI Class Initialized
INFO - 2021-06-15 15:02:09 --> Router Class Initialized
INFO - 2021-06-15 15:02:09 --> Output Class Initialized
INFO - 2021-06-15 15:02:09 --> Security Class Initialized
DEBUG - 2021-06-15 15:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:02:09 --> Input Class Initialized
INFO - 2021-06-15 15:02:09 --> Language Class Initialized
INFO - 2021-06-15 15:02:09 --> Loader Class Initialized
INFO - 2021-06-15 15:02:09 --> Helper loaded: url_helper
INFO - 2021-06-15 15:02:09 --> Helper loaded: form_helper
INFO - 2021-06-15 15:02:09 --> Helper loaded: common_helper
INFO - 2021-06-15 15:02:09 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:02:09 --> Controller Class Initialized
INFO - 2021-06-15 15:02:09 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:02:09 --> Encrypt Class Initialized
DEBUG - 2021-06-15 15:02:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 15:02:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 15:02:09 --> Email Class Initialized
INFO - 2021-06-15 15:02:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 15:02:09 --> Calendar Class Initialized
INFO - 2021-06-15 15:02:09 --> Model "Login_model" initialized
INFO - 2021-06-15 15:02:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-06-15 15:02:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 15:02:09 --> Final output sent to browser
DEBUG - 2021-06-15 15:02:09 --> Total execution time: 0.0192
ERROR - 2021-06-15 15:13:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:13:20 --> Config Class Initialized
INFO - 2021-06-15 15:13:20 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:13:20 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:13:20 --> Utf8 Class Initialized
INFO - 2021-06-15 15:13:20 --> URI Class Initialized
INFO - 2021-06-15 15:13:20 --> Router Class Initialized
INFO - 2021-06-15 15:13:20 --> Output Class Initialized
INFO - 2021-06-15 15:13:20 --> Security Class Initialized
DEBUG - 2021-06-15 15:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:13:20 --> Input Class Initialized
INFO - 2021-06-15 15:13:20 --> Language Class Initialized
INFO - 2021-06-15 15:13:20 --> Loader Class Initialized
INFO - 2021-06-15 15:13:20 --> Helper loaded: url_helper
INFO - 2021-06-15 15:13:20 --> Helper loaded: form_helper
INFO - 2021-06-15 15:13:20 --> Helper loaded: common_helper
INFO - 2021-06-15 15:13:20 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:13:20 --> Controller Class Initialized
INFO - 2021-06-15 15:13:20 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:13:20 --> Encrypt Class Initialized
DEBUG - 2021-06-15 15:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 15:13:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 15:13:20 --> Email Class Initialized
INFO - 2021-06-15 15:13:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 15:13:20 --> Calendar Class Initialized
INFO - 2021-06-15 15:13:20 --> Model "Login_model" initialized
INFO - 2021-06-15 15:13:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-15 15:13:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:13:20 --> Config Class Initialized
INFO - 2021-06-15 15:13:20 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:13:20 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:13:20 --> Utf8 Class Initialized
INFO - 2021-06-15 15:13:20 --> URI Class Initialized
INFO - 2021-06-15 15:13:20 --> Router Class Initialized
INFO - 2021-06-15 15:13:20 --> Output Class Initialized
INFO - 2021-06-15 15:13:20 --> Security Class Initialized
DEBUG - 2021-06-15 15:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:13:20 --> Input Class Initialized
INFO - 2021-06-15 15:13:20 --> Language Class Initialized
INFO - 2021-06-15 15:13:20 --> Loader Class Initialized
INFO - 2021-06-15 15:13:20 --> Helper loaded: url_helper
INFO - 2021-06-15 15:13:20 --> Helper loaded: form_helper
INFO - 2021-06-15 15:13:20 --> Helper loaded: common_helper
INFO - 2021-06-15 15:13:20 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:13:20 --> Controller Class Initialized
INFO - 2021-06-15 15:13:20 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:13:20 --> Encrypt Class Initialized
INFO - 2021-06-15 15:13:20 --> Model "Login_model" initialized
INFO - 2021-06-15 15:13:20 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 15:13:20 --> Model "Case_model" initialized
INFO - 2021-06-15 15:13:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:13:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-15 15:13:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:13:30 --> Final output sent to browser
DEBUG - 2021-06-15 15:13:30 --> Total execution time: 9.4052
ERROR - 2021-06-15 15:13:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:13:31 --> Config Class Initialized
INFO - 2021-06-15 15:13:31 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:13:31 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:13:31 --> Utf8 Class Initialized
INFO - 2021-06-15 15:13:31 --> URI Class Initialized
INFO - 2021-06-15 15:13:31 --> Router Class Initialized
INFO - 2021-06-15 15:13:31 --> Output Class Initialized
INFO - 2021-06-15 15:13:31 --> Security Class Initialized
DEBUG - 2021-06-15 15:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:13:31 --> Input Class Initialized
INFO - 2021-06-15 15:13:31 --> Language Class Initialized
ERROR - 2021-06-15 15:13:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:13:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:13:49 --> Config Class Initialized
INFO - 2021-06-15 15:13:49 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:13:49 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:13:49 --> Utf8 Class Initialized
INFO - 2021-06-15 15:13:49 --> URI Class Initialized
DEBUG - 2021-06-15 15:13:49 --> No URI present. Default controller set.
INFO - 2021-06-15 15:13:49 --> Router Class Initialized
INFO - 2021-06-15 15:13:49 --> Output Class Initialized
INFO - 2021-06-15 15:13:49 --> Security Class Initialized
DEBUG - 2021-06-15 15:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:13:49 --> Input Class Initialized
INFO - 2021-06-15 15:13:49 --> Language Class Initialized
INFO - 2021-06-15 15:13:49 --> Loader Class Initialized
INFO - 2021-06-15 15:13:49 --> Helper loaded: url_helper
INFO - 2021-06-15 15:13:49 --> Helper loaded: form_helper
INFO - 2021-06-15 15:13:49 --> Helper loaded: common_helper
INFO - 2021-06-15 15:13:49 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:13:49 --> Controller Class Initialized
INFO - 2021-06-15 15:13:49 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:13:49 --> Encrypt Class Initialized
DEBUG - 2021-06-15 15:13:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 15:13:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 15:13:49 --> Email Class Initialized
INFO - 2021-06-15 15:13:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 15:13:49 --> Calendar Class Initialized
INFO - 2021-06-15 15:13:49 --> Model "Login_model" initialized
INFO - 2021-06-15 15:13:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 15:13:49 --> Final output sent to browser
DEBUG - 2021-06-15 15:13:49 --> Total execution time: 0.0206
ERROR - 2021-06-15 15:13:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:13:50 --> Config Class Initialized
INFO - 2021-06-15 15:13:50 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:13:50 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:13:50 --> Utf8 Class Initialized
INFO - 2021-06-15 15:13:50 --> URI Class Initialized
INFO - 2021-06-15 15:13:50 --> Router Class Initialized
INFO - 2021-06-15 15:13:50 --> Output Class Initialized
INFO - 2021-06-15 15:13:50 --> Security Class Initialized
DEBUG - 2021-06-15 15:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:13:50 --> Input Class Initialized
INFO - 2021-06-15 15:13:50 --> Language Class Initialized
ERROR - 2021-06-15 15:13:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-15 15:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:14:09 --> Config Class Initialized
INFO - 2021-06-15 15:14:09 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:14:09 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:14:09 --> Utf8 Class Initialized
INFO - 2021-06-15 15:14:09 --> URI Class Initialized
INFO - 2021-06-15 15:14:09 --> Router Class Initialized
INFO - 2021-06-15 15:14:09 --> Output Class Initialized
INFO - 2021-06-15 15:14:09 --> Security Class Initialized
DEBUG - 2021-06-15 15:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:14:09 --> Input Class Initialized
INFO - 2021-06-15 15:14:09 --> Language Class Initialized
INFO - 2021-06-15 15:14:09 --> Loader Class Initialized
INFO - 2021-06-15 15:14:09 --> Helper loaded: url_helper
INFO - 2021-06-15 15:14:09 --> Helper loaded: form_helper
INFO - 2021-06-15 15:14:09 --> Helper loaded: common_helper
INFO - 2021-06-15 15:14:09 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:14:09 --> Controller Class Initialized
INFO - 2021-06-15 15:14:09 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:14:09 --> Encrypt Class Initialized
DEBUG - 2021-06-15 15:14:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 15:14:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 15:14:09 --> Email Class Initialized
INFO - 2021-06-15 15:14:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 15:14:09 --> Calendar Class Initialized
INFO - 2021-06-15 15:14:09 --> Model "Login_model" initialized
INFO - 2021-06-15 15:14:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-15 15:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:14:09 --> Config Class Initialized
INFO - 2021-06-15 15:14:09 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:14:09 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:14:09 --> Utf8 Class Initialized
INFO - 2021-06-15 15:14:09 --> URI Class Initialized
INFO - 2021-06-15 15:14:09 --> Router Class Initialized
INFO - 2021-06-15 15:14:09 --> Output Class Initialized
INFO - 2021-06-15 15:14:09 --> Security Class Initialized
DEBUG - 2021-06-15 15:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:14:09 --> Input Class Initialized
INFO - 2021-06-15 15:14:09 --> Language Class Initialized
INFO - 2021-06-15 15:14:09 --> Loader Class Initialized
INFO - 2021-06-15 15:14:09 --> Helper loaded: url_helper
INFO - 2021-06-15 15:14:09 --> Helper loaded: form_helper
INFO - 2021-06-15 15:14:09 --> Helper loaded: common_helper
INFO - 2021-06-15 15:14:09 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:14:09 --> Controller Class Initialized
INFO - 2021-06-15 15:14:09 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:14:09 --> Encrypt Class Initialized
INFO - 2021-06-15 15:14:09 --> Model "Login_model" initialized
INFO - 2021-06-15 15:14:09 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 15:14:09 --> Model "Case_model" initialized
INFO - 2021-06-15 15:14:12 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:14:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-15 15:14:19 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:14:19 --> Final output sent to browser
DEBUG - 2021-06-15 15:14:19 --> Total execution time: 9.3837
ERROR - 2021-06-15 15:14:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:14:19 --> Config Class Initialized
INFO - 2021-06-15 15:14:19 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:14:19 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:14:19 --> Utf8 Class Initialized
INFO - 2021-06-15 15:14:19 --> URI Class Initialized
INFO - 2021-06-15 15:14:19 --> Router Class Initialized
INFO - 2021-06-15 15:14:19 --> Output Class Initialized
INFO - 2021-06-15 15:14:19 --> Security Class Initialized
DEBUG - 2021-06-15 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:14:19 --> Input Class Initialized
INFO - 2021-06-15 15:14:19 --> Language Class Initialized
ERROR - 2021-06-15 15:14:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:16:11 --> Config Class Initialized
INFO - 2021-06-15 15:16:11 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:16:11 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:16:11 --> Utf8 Class Initialized
INFO - 2021-06-15 15:16:11 --> URI Class Initialized
INFO - 2021-06-15 15:16:11 --> Router Class Initialized
INFO - 2021-06-15 15:16:11 --> Output Class Initialized
INFO - 2021-06-15 15:16:11 --> Security Class Initialized
DEBUG - 2021-06-15 15:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:16:11 --> Input Class Initialized
INFO - 2021-06-15 15:16:11 --> Language Class Initialized
INFO - 2021-06-15 15:16:11 --> Loader Class Initialized
INFO - 2021-06-15 15:16:11 --> Helper loaded: url_helper
INFO - 2021-06-15 15:16:11 --> Helper loaded: form_helper
INFO - 2021-06-15 15:16:11 --> Helper loaded: common_helper
INFO - 2021-06-15 15:16:11 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:16:11 --> Controller Class Initialized
INFO - 2021-06-15 15:16:11 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:16:11 --> Encrypt Class Initialized
INFO - 2021-06-15 15:16:11 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:16:11 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:16:11 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:16:11 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:16:11 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:16:11 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:16:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-15 15:16:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-15 15:16:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:16:16 --> Config Class Initialized
INFO - 2021-06-15 15:16:16 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:16:16 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:16:16 --> Utf8 Class Initialized
INFO - 2021-06-15 15:16:16 --> URI Class Initialized
INFO - 2021-06-15 15:16:16 --> Router Class Initialized
INFO - 2021-06-15 15:16:16 --> Output Class Initialized
INFO - 2021-06-15 15:16:16 --> Security Class Initialized
DEBUG - 2021-06-15 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:16:16 --> Input Class Initialized
INFO - 2021-06-15 15:16:16 --> Language Class Initialized
ERROR - 2021-06-15 15:16:16 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-15 15:16:17 --> Final output sent to browser
DEBUG - 2021-06-15 15:16:17 --> Total execution time: 4.2199
ERROR - 2021-06-15 15:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:16:24 --> Config Class Initialized
INFO - 2021-06-15 15:16:24 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:16:24 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:16:24 --> Utf8 Class Initialized
INFO - 2021-06-15 15:16:24 --> URI Class Initialized
INFO - 2021-06-15 15:16:24 --> Router Class Initialized
INFO - 2021-06-15 15:16:24 --> Output Class Initialized
INFO - 2021-06-15 15:16:24 --> Security Class Initialized
DEBUG - 2021-06-15 15:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:16:24 --> Input Class Initialized
INFO - 2021-06-15 15:16:24 --> Language Class Initialized
INFO - 2021-06-15 15:16:24 --> Loader Class Initialized
INFO - 2021-06-15 15:16:24 --> Helper loaded: url_helper
INFO - 2021-06-15 15:16:24 --> Helper loaded: form_helper
INFO - 2021-06-15 15:16:24 --> Helper loaded: common_helper
INFO - 2021-06-15 15:16:24 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:16:24 --> Controller Class Initialized
INFO - 2021-06-15 15:16:24 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:16:24 --> Encrypt Class Initialized
INFO - 2021-06-15 15:16:24 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:16:24 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:16:24 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:16:24 --> Model "Users_model" initialized
INFO - 2021-06-15 15:16:24 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:16:24 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-15 15:16:24 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found /home1/techywbu/karo.notioninfosoft.com/application/controllers/Patientcase.php 496
ERROR - 2021-06-15 15:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:16:25 --> Config Class Initialized
INFO - 2021-06-15 15:16:25 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:16:25 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:16:25 --> Utf8 Class Initialized
INFO - 2021-06-15 15:16:25 --> URI Class Initialized
INFO - 2021-06-15 15:16:25 --> Router Class Initialized
INFO - 2021-06-15 15:16:25 --> Output Class Initialized
INFO - 2021-06-15 15:16:25 --> Security Class Initialized
DEBUG - 2021-06-15 15:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:16:25 --> Input Class Initialized
INFO - 2021-06-15 15:16:25 --> Language Class Initialized
ERROR - 2021-06-15 15:16:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-15 15:17:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:17:49 --> Config Class Initialized
INFO - 2021-06-15 15:17:49 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:17:49 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:17:49 --> Utf8 Class Initialized
INFO - 2021-06-15 15:17:49 --> URI Class Initialized
INFO - 2021-06-15 15:17:49 --> Router Class Initialized
INFO - 2021-06-15 15:17:49 --> Output Class Initialized
INFO - 2021-06-15 15:17:49 --> Security Class Initialized
DEBUG - 2021-06-15 15:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:17:49 --> Input Class Initialized
INFO - 2021-06-15 15:17:49 --> Language Class Initialized
INFO - 2021-06-15 15:17:49 --> Loader Class Initialized
INFO - 2021-06-15 15:17:49 --> Helper loaded: url_helper
INFO - 2021-06-15 15:17:49 --> Helper loaded: form_helper
INFO - 2021-06-15 15:17:49 --> Helper loaded: common_helper
INFO - 2021-06-15 15:17:49 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:17:49 --> Controller Class Initialized
INFO - 2021-06-15 15:17:49 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:17:49 --> Encrypt Class Initialized
INFO - 2021-06-15 15:17:49 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:17:49 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:17:49 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:17:49 --> Model "Users_model" initialized
INFO - 2021-06-15 15:17:49 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:17:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-15 15:17:49 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found /home1/techywbu/karo.notioninfosoft.com/application/controllers/Patientcase.php 496
ERROR - 2021-06-15 15:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:18:48 --> Config Class Initialized
INFO - 2021-06-15 15:18:48 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:18:48 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:18:48 --> Utf8 Class Initialized
INFO - 2021-06-15 15:18:48 --> URI Class Initialized
INFO - 2021-06-15 15:18:48 --> Router Class Initialized
INFO - 2021-06-15 15:18:48 --> Output Class Initialized
INFO - 2021-06-15 15:18:48 --> Security Class Initialized
DEBUG - 2021-06-15 15:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:18:48 --> Input Class Initialized
INFO - 2021-06-15 15:18:48 --> Language Class Initialized
INFO - 2021-06-15 15:18:48 --> Loader Class Initialized
INFO - 2021-06-15 15:18:48 --> Helper loaded: url_helper
INFO - 2021-06-15 15:18:48 --> Helper loaded: form_helper
INFO - 2021-06-15 15:18:48 --> Helper loaded: common_helper
INFO - 2021-06-15 15:18:48 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:18:48 --> Controller Class Initialized
INFO - 2021-06-15 15:18:48 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:18:48 --> Encrypt Class Initialized
INFO - 2021-06-15 15:18:48 --> Model "Login_model" initialized
INFO - 2021-06-15 15:18:48 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 15:18:48 --> Model "Case_model" initialized
ERROR - 2021-06-15 15:18:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:18:49 --> Config Class Initialized
INFO - 2021-06-15 15:18:49 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:18:49 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:18:49 --> Utf8 Class Initialized
INFO - 2021-06-15 15:18:49 --> URI Class Initialized
INFO - 2021-06-15 15:18:49 --> Router Class Initialized
INFO - 2021-06-15 15:18:49 --> Output Class Initialized
INFO - 2021-06-15 15:18:49 --> Security Class Initialized
DEBUG - 2021-06-15 15:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:18:49 --> Input Class Initialized
INFO - 2021-06-15 15:18:49 --> Language Class Initialized
INFO - 2021-06-15 15:18:49 --> Loader Class Initialized
INFO - 2021-06-15 15:18:49 --> Helper loaded: url_helper
INFO - 2021-06-15 15:18:49 --> Helper loaded: form_helper
INFO - 2021-06-15 15:18:49 --> Helper loaded: common_helper
INFO - 2021-06-15 15:18:49 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:18:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:18:57 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-15 15:18:57 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:18:57 --> Final output sent to browser
DEBUG - 2021-06-15 15:18:57 --> Total execution time: 9.3318
INFO - 2021-06-15 15:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:18:57 --> Controller Class Initialized
INFO - 2021-06-15 15:18:57 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:18:57 --> Encrypt Class Initialized
INFO - 2021-06-15 15:18:57 --> Model "Login_model" initialized
INFO - 2021-06-15 15:18:57 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 15:18:57 --> Model "Case_model" initialized
ERROR - 2021-06-15 15:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:18:58 --> Config Class Initialized
INFO - 2021-06-15 15:18:58 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:18:58 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:18:58 --> Utf8 Class Initialized
INFO - 2021-06-15 15:18:58 --> URI Class Initialized
INFO - 2021-06-15 15:18:58 --> Router Class Initialized
INFO - 2021-06-15 15:18:58 --> Output Class Initialized
INFO - 2021-06-15 15:18:58 --> Security Class Initialized
DEBUG - 2021-06-15 15:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:18:58 --> Input Class Initialized
INFO - 2021-06-15 15:18:58 --> Language Class Initialized
INFO - 2021-06-15 15:18:58 --> Loader Class Initialized
INFO - 2021-06-15 15:18:58 --> Helper loaded: url_helper
INFO - 2021-06-15 15:18:58 --> Helper loaded: form_helper
INFO - 2021-06-15 15:18:58 --> Helper loaded: common_helper
INFO - 2021-06-15 15:18:58 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:18:58 --> Controller Class Initialized
INFO - 2021-06-15 15:18:58 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:18:58 --> Encrypt Class Initialized
INFO - 2021-06-15 15:18:58 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:18:58 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:18:58 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:18:58 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:18:58 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:18:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:19:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:19:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-15 15:19:04 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-15 15:19:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:19:05 --> Config Class Initialized
INFO - 2021-06-15 15:19:05 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:19:05 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:19:05 --> Utf8 Class Initialized
INFO - 2021-06-15 15:19:05 --> URI Class Initialized
INFO - 2021-06-15 15:19:05 --> Router Class Initialized
INFO - 2021-06-15 15:19:05 --> Output Class Initialized
INFO - 2021-06-15 15:19:05 --> Security Class Initialized
DEBUG - 2021-06-15 15:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:19:05 --> Input Class Initialized
INFO - 2021-06-15 15:19:05 --> Language Class Initialized
ERROR - 2021-06-15 15:19:05 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-15 15:19:06 --> Final output sent to browser
DEBUG - 2021-06-15 15:19:06 --> Total execution time: 5.7871
INFO - 2021-06-15 15:19:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-15 15:19:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:19:07 --> Final output sent to browser
DEBUG - 2021-06-15 15:19:07 --> Total execution time: 18.2258
ERROR - 2021-06-15 15:19:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:19:32 --> Config Class Initialized
INFO - 2021-06-15 15:19:32 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:19:32 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:19:32 --> Utf8 Class Initialized
INFO - 2021-06-15 15:19:32 --> URI Class Initialized
INFO - 2021-06-15 15:19:32 --> Router Class Initialized
INFO - 2021-06-15 15:19:32 --> Output Class Initialized
INFO - 2021-06-15 15:19:32 --> Security Class Initialized
DEBUG - 2021-06-15 15:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:19:32 --> Input Class Initialized
INFO - 2021-06-15 15:19:32 --> Language Class Initialized
INFO - 2021-06-15 15:19:32 --> Loader Class Initialized
INFO - 2021-06-15 15:19:32 --> Helper loaded: url_helper
INFO - 2021-06-15 15:19:32 --> Helper loaded: form_helper
INFO - 2021-06-15 15:19:32 --> Helper loaded: common_helper
INFO - 2021-06-15 15:19:32 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:19:32 --> Controller Class Initialized
INFO - 2021-06-15 15:19:32 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:19:32 --> Encrypt Class Initialized
INFO - 2021-06-15 15:19:32 --> Model "Login_model" initialized
INFO - 2021-06-15 15:19:32 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 15:19:32 --> Model "Case_model" initialized
INFO - 2021-06-15 15:19:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:19:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-15 15:19:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:19:42 --> Final output sent to browser
DEBUG - 2021-06-15 15:19:42 --> Total execution time: 9.8158
ERROR - 2021-06-15 15:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:19:42 --> Config Class Initialized
INFO - 2021-06-15 15:19:42 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:19:42 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:19:42 --> Utf8 Class Initialized
INFO - 2021-06-15 15:19:42 --> URI Class Initialized
INFO - 2021-06-15 15:19:42 --> Router Class Initialized
INFO - 2021-06-15 15:19:42 --> Output Class Initialized
INFO - 2021-06-15 15:19:42 --> Security Class Initialized
DEBUG - 2021-06-15 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:19:42 --> Input Class Initialized
INFO - 2021-06-15 15:19:42 --> Language Class Initialized
ERROR - 2021-06-15 15:19:42 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:19:47 --> Config Class Initialized
INFO - 2021-06-15 15:19:47 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:19:47 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:19:47 --> Utf8 Class Initialized
INFO - 2021-06-15 15:19:47 --> URI Class Initialized
INFO - 2021-06-15 15:19:47 --> Router Class Initialized
INFO - 2021-06-15 15:19:47 --> Output Class Initialized
INFO - 2021-06-15 15:19:47 --> Security Class Initialized
DEBUG - 2021-06-15 15:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:19:47 --> Input Class Initialized
INFO - 2021-06-15 15:19:47 --> Language Class Initialized
INFO - 2021-06-15 15:19:47 --> Loader Class Initialized
INFO - 2021-06-15 15:19:47 --> Helper loaded: url_helper
INFO - 2021-06-15 15:19:47 --> Helper loaded: form_helper
INFO - 2021-06-15 15:19:47 --> Helper loaded: common_helper
INFO - 2021-06-15 15:19:47 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:19:47 --> Controller Class Initialized
INFO - 2021-06-15 15:19:47 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:19:47 --> Encrypt Class Initialized
INFO - 2021-06-15 15:19:47 --> Model "Login_model" initialized
INFO - 2021-06-15 15:19:47 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 15:19:47 --> Model "Case_model" initialized
INFO - 2021-06-15 15:19:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:19:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/birthday.php
INFO - 2021-06-15 15:19:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:19:47 --> Final output sent to browser
DEBUG - 2021-06-15 15:19:47 --> Total execution time: 0.0254
ERROR - 2021-06-15 15:19:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:19:48 --> Config Class Initialized
INFO - 2021-06-15 15:19:48 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:19:48 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:19:48 --> Utf8 Class Initialized
INFO - 2021-06-15 15:19:48 --> URI Class Initialized
INFO - 2021-06-15 15:19:48 --> Router Class Initialized
INFO - 2021-06-15 15:19:48 --> Output Class Initialized
INFO - 2021-06-15 15:19:48 --> Security Class Initialized
DEBUG - 2021-06-15 15:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:19:48 --> Input Class Initialized
INFO - 2021-06-15 15:19:48 --> Language Class Initialized
ERROR - 2021-06-15 15:19:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:19:59 --> Config Class Initialized
INFO - 2021-06-15 15:19:59 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:19:59 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:19:59 --> Utf8 Class Initialized
INFO - 2021-06-15 15:19:59 --> URI Class Initialized
INFO - 2021-06-15 15:19:59 --> Router Class Initialized
INFO - 2021-06-15 15:19:59 --> Output Class Initialized
INFO - 2021-06-15 15:19:59 --> Security Class Initialized
DEBUG - 2021-06-15 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:19:59 --> Input Class Initialized
INFO - 2021-06-15 15:19:59 --> Language Class Initialized
INFO - 2021-06-15 15:19:59 --> Loader Class Initialized
INFO - 2021-06-15 15:19:59 --> Helper loaded: url_helper
INFO - 2021-06-15 15:19:59 --> Helper loaded: form_helper
INFO - 2021-06-15 15:19:59 --> Helper loaded: common_helper
INFO - 2021-06-15 15:19:59 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:19:59 --> Controller Class Initialized
INFO - 2021-06-15 15:19:59 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:19:59 --> Encrypt Class Initialized
INFO - 2021-06-15 15:19:59 --> Model "Login_model" initialized
INFO - 2021-06-15 15:19:59 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 15:19:59 --> Model "Case_model" initialized
INFO - 2021-06-15 15:19:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:19:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/birthday.php
INFO - 2021-06-15 15:19:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:19:59 --> Final output sent to browser
DEBUG - 2021-06-15 15:19:59 --> Total execution time: 0.0224
ERROR - 2021-06-15 15:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:19:59 --> Config Class Initialized
INFO - 2021-06-15 15:19:59 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:19:59 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:19:59 --> Utf8 Class Initialized
INFO - 2021-06-15 15:19:59 --> URI Class Initialized
INFO - 2021-06-15 15:19:59 --> Router Class Initialized
INFO - 2021-06-15 15:19:59 --> Output Class Initialized
INFO - 2021-06-15 15:19:59 --> Security Class Initialized
DEBUG - 2021-06-15 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:19:59 --> Input Class Initialized
INFO - 2021-06-15 15:19:59 --> Language Class Initialized
ERROR - 2021-06-15 15:19:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:20:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:20:35 --> Config Class Initialized
INFO - 2021-06-15 15:20:35 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:20:35 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:20:35 --> Utf8 Class Initialized
INFO - 2021-06-15 15:20:35 --> URI Class Initialized
INFO - 2021-06-15 15:20:35 --> Router Class Initialized
INFO - 2021-06-15 15:20:35 --> Output Class Initialized
INFO - 2021-06-15 15:20:35 --> Security Class Initialized
DEBUG - 2021-06-15 15:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:20:35 --> Input Class Initialized
INFO - 2021-06-15 15:20:35 --> Language Class Initialized
INFO - 2021-06-15 15:20:35 --> Loader Class Initialized
INFO - 2021-06-15 15:20:35 --> Helper loaded: url_helper
INFO - 2021-06-15 15:20:35 --> Helper loaded: form_helper
INFO - 2021-06-15 15:20:35 --> Helper loaded: common_helper
INFO - 2021-06-15 15:20:35 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:20:35 --> Controller Class Initialized
INFO - 2021-06-15 15:20:35 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:20:35 --> Encrypt Class Initialized
INFO - 2021-06-15 15:20:35 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:20:35 --> Model "Users_model" initialized
INFO - 2021-06-15 15:20:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:20:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-15 15:20:35 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:20:35 --> Final output sent to browser
DEBUG - 2021-06-15 15:20:35 --> Total execution time: 0.0212
ERROR - 2021-06-15 15:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:20:36 --> Config Class Initialized
INFO - 2021-06-15 15:20:36 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:20:36 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:20:36 --> Utf8 Class Initialized
INFO - 2021-06-15 15:20:36 --> URI Class Initialized
INFO - 2021-06-15 15:20:36 --> Router Class Initialized
INFO - 2021-06-15 15:20:36 --> Output Class Initialized
INFO - 2021-06-15 15:20:36 --> Security Class Initialized
DEBUG - 2021-06-15 15:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:20:36 --> Input Class Initialized
INFO - 2021-06-15 15:20:36 --> Language Class Initialized
ERROR - 2021-06-15 15:20:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:20:42 --> Config Class Initialized
INFO - 2021-06-15 15:20:42 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:20:42 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:20:42 --> Utf8 Class Initialized
INFO - 2021-06-15 15:20:42 --> URI Class Initialized
INFO - 2021-06-15 15:20:42 --> Router Class Initialized
INFO - 2021-06-15 15:20:42 --> Output Class Initialized
INFO - 2021-06-15 15:20:42 --> Security Class Initialized
DEBUG - 2021-06-15 15:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:20:42 --> Input Class Initialized
INFO - 2021-06-15 15:20:42 --> Language Class Initialized
INFO - 2021-06-15 15:20:42 --> Loader Class Initialized
INFO - 2021-06-15 15:20:42 --> Helper loaded: url_helper
INFO - 2021-06-15 15:20:42 --> Helper loaded: form_helper
INFO - 2021-06-15 15:20:42 --> Helper loaded: common_helper
INFO - 2021-06-15 15:20:42 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:20:42 --> Controller Class Initialized
INFO - 2021-06-15 15:20:42 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:20:42 --> Encrypt Class Initialized
INFO - 2021-06-15 15:20:42 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:20:42 --> Model "Users_model" initialized
INFO - 2021-06-15 15:20:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:20:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-15 15:20:42 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:20:42 --> Final output sent to browser
DEBUG - 2021-06-15 15:20:42 --> Total execution time: 0.0543
ERROR - 2021-06-15 15:20:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:20:43 --> Config Class Initialized
INFO - 2021-06-15 15:20:43 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:20:43 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:20:43 --> Utf8 Class Initialized
INFO - 2021-06-15 15:20:43 --> URI Class Initialized
INFO - 2021-06-15 15:20:43 --> Router Class Initialized
INFO - 2021-06-15 15:20:43 --> Output Class Initialized
INFO - 2021-06-15 15:20:43 --> Security Class Initialized
DEBUG - 2021-06-15 15:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:20:43 --> Input Class Initialized
INFO - 2021-06-15 15:20:43 --> Language Class Initialized
ERROR - 2021-06-15 15:20:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:20:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:20:49 --> Config Class Initialized
INFO - 2021-06-15 15:20:49 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:20:49 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:20:49 --> Utf8 Class Initialized
INFO - 2021-06-15 15:20:49 --> URI Class Initialized
INFO - 2021-06-15 15:20:49 --> Router Class Initialized
INFO - 2021-06-15 15:20:49 --> Output Class Initialized
INFO - 2021-06-15 15:20:49 --> Security Class Initialized
DEBUG - 2021-06-15 15:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:20:49 --> Input Class Initialized
INFO - 2021-06-15 15:20:49 --> Language Class Initialized
INFO - 2021-06-15 15:20:49 --> Loader Class Initialized
INFO - 2021-06-15 15:20:49 --> Helper loaded: url_helper
INFO - 2021-06-15 15:20:49 --> Helper loaded: form_helper
INFO - 2021-06-15 15:20:49 --> Helper loaded: common_helper
INFO - 2021-06-15 15:20:49 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:20:49 --> Controller Class Initialized
INFO - 2021-06-15 15:20:49 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:20:49 --> Encrypt Class Initialized
INFO - 2021-06-15 15:20:49 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:20:49 --> Model "Users_model" initialized
INFO - 2021-06-15 15:20:49 --> Upload Class Initialized
ERROR - 2021-06-15 15:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:20:50 --> Config Class Initialized
INFO - 2021-06-15 15:20:50 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:20:50 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:20:50 --> Utf8 Class Initialized
INFO - 2021-06-15 15:20:50 --> URI Class Initialized
INFO - 2021-06-15 15:20:50 --> Router Class Initialized
INFO - 2021-06-15 15:20:50 --> Output Class Initialized
INFO - 2021-06-15 15:20:50 --> Security Class Initialized
DEBUG - 2021-06-15 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:20:50 --> Input Class Initialized
INFO - 2021-06-15 15:20:50 --> Language Class Initialized
INFO - 2021-06-15 15:20:50 --> Loader Class Initialized
INFO - 2021-06-15 15:20:50 --> Helper loaded: url_helper
INFO - 2021-06-15 15:20:50 --> Helper loaded: form_helper
INFO - 2021-06-15 15:20:50 --> Helper loaded: common_helper
INFO - 2021-06-15 15:20:50 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:20:50 --> Controller Class Initialized
INFO - 2021-06-15 15:20:50 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:20:50 --> Encrypt Class Initialized
INFO - 2021-06-15 15:20:50 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:20:50 --> Model "Users_model" initialized
INFO - 2021-06-15 15:20:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:20:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-15 15:20:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:20:50 --> Final output sent to browser
DEBUG - 2021-06-15 15:20:50 --> Total execution time: 0.0191
ERROR - 2021-06-15 15:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:20:50 --> Config Class Initialized
INFO - 2021-06-15 15:20:50 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:20:50 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:20:50 --> Utf8 Class Initialized
INFO - 2021-06-15 15:20:50 --> URI Class Initialized
INFO - 2021-06-15 15:20:50 --> Router Class Initialized
INFO - 2021-06-15 15:20:50 --> Output Class Initialized
INFO - 2021-06-15 15:20:50 --> Security Class Initialized
DEBUG - 2021-06-15 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:20:50 --> Input Class Initialized
INFO - 2021-06-15 15:20:50 --> Language Class Initialized
ERROR - 2021-06-15 15:20:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:21:03 --> Config Class Initialized
INFO - 2021-06-15 15:21:03 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:21:03 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:21:03 --> Utf8 Class Initialized
INFO - 2021-06-15 15:21:03 --> URI Class Initialized
INFO - 2021-06-15 15:21:03 --> Router Class Initialized
INFO - 2021-06-15 15:21:03 --> Output Class Initialized
INFO - 2021-06-15 15:21:03 --> Security Class Initialized
DEBUG - 2021-06-15 15:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:21:03 --> Input Class Initialized
INFO - 2021-06-15 15:21:03 --> Language Class Initialized
INFO - 2021-06-15 15:21:03 --> Loader Class Initialized
INFO - 2021-06-15 15:21:03 --> Helper loaded: url_helper
INFO - 2021-06-15 15:21:03 --> Helper loaded: form_helper
INFO - 2021-06-15 15:21:03 --> Helper loaded: common_helper
INFO - 2021-06-15 15:21:03 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:21:03 --> Controller Class Initialized
INFO - 2021-06-15 15:21:03 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:21:03 --> Encrypt Class Initialized
INFO - 2021-06-15 15:21:03 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:21:03 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:21:03 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:21:03 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:21:03 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:21:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:21:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/index.php
INFO - 2021-06-15 15:21:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:21:03 --> Final output sent to browser
DEBUG - 2021-06-15 15:21:03 --> Total execution time: 0.0447
ERROR - 2021-06-15 15:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:21:05 --> Config Class Initialized
INFO - 2021-06-15 15:21:05 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:21:05 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:21:05 --> Utf8 Class Initialized
INFO - 2021-06-15 15:21:05 --> URI Class Initialized
INFO - 2021-06-15 15:21:05 --> Router Class Initialized
INFO - 2021-06-15 15:21:05 --> Output Class Initialized
INFO - 2021-06-15 15:21:05 --> Security Class Initialized
DEBUG - 2021-06-15 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:21:05 --> Input Class Initialized
INFO - 2021-06-15 15:21:05 --> Language Class Initialized
ERROR - 2021-06-15 15:21:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:06 --> Config Class Initialized
INFO - 2021-06-15 15:22:06 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:06 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:06 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:06 --> URI Class Initialized
INFO - 2021-06-15 15:22:06 --> Router Class Initialized
INFO - 2021-06-15 15:22:06 --> Output Class Initialized
INFO - 2021-06-15 15:22:06 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:06 --> Input Class Initialized
INFO - 2021-06-15 15:22:06 --> Language Class Initialized
INFO - 2021-06-15 15:22:06 --> Loader Class Initialized
INFO - 2021-06-15 15:22:06 --> Helper loaded: url_helper
INFO - 2021-06-15 15:22:06 --> Helper loaded: form_helper
INFO - 2021-06-15 15:22:06 --> Helper loaded: common_helper
INFO - 2021-06-15 15:22:06 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:22:06 --> Controller Class Initialized
INFO - 2021-06-15 15:22:06 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:22:06 --> Encrypt Class Initialized
INFO - 2021-06-15 15:22:06 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:22:06 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:22:06 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:22:06 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:22:06 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:22:07 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:22:11 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-15 15:22:11 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-15 15:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:11 --> Config Class Initialized
INFO - 2021-06-15 15:22:11 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:11 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:11 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:11 --> URI Class Initialized
INFO - 2021-06-15 15:22:11 --> Router Class Initialized
INFO - 2021-06-15 15:22:11 --> Output Class Initialized
INFO - 2021-06-15 15:22:11 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:11 --> Input Class Initialized
INFO - 2021-06-15 15:22:11 --> Language Class Initialized
ERROR - 2021-06-15 15:22:11 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-15 15:22:12 --> Final output sent to browser
DEBUG - 2021-06-15 15:22:12 --> Total execution time: 4.3658
ERROR - 2021-06-15 15:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:17 --> Config Class Initialized
INFO - 2021-06-15 15:22:17 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:17 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:17 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:17 --> URI Class Initialized
INFO - 2021-06-15 15:22:17 --> Router Class Initialized
INFO - 2021-06-15 15:22:17 --> Output Class Initialized
INFO - 2021-06-15 15:22:17 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:17 --> Input Class Initialized
INFO - 2021-06-15 15:22:17 --> Language Class Initialized
INFO - 2021-06-15 15:22:17 --> Loader Class Initialized
INFO - 2021-06-15 15:22:17 --> Helper loaded: url_helper
INFO - 2021-06-15 15:22:17 --> Helper loaded: form_helper
INFO - 2021-06-15 15:22:17 --> Helper loaded: common_helper
INFO - 2021-06-15 15:22:17 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:22:17 --> Controller Class Initialized
INFO - 2021-06-15 15:22:17 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:22:17 --> Encrypt Class Initialized
INFO - 2021-06-15 15:22:17 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:22:17 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:22:17 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:22:17 --> Model "Users_model" initialized
INFO - 2021-06-15 15:22:17 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:22:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:22:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patientcase/index.php
INFO - 2021-06-15 15:22:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:22:17 --> Final output sent to browser
DEBUG - 2021-06-15 15:22:17 --> Total execution time: 0.1036
ERROR - 2021-06-15 15:22:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:18 --> Config Class Initialized
INFO - 2021-06-15 15:22:18 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:18 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:18 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:18 --> URI Class Initialized
INFO - 2021-06-15 15:22:18 --> Router Class Initialized
INFO - 2021-06-15 15:22:18 --> Output Class Initialized
INFO - 2021-06-15 15:22:18 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:18 --> Input Class Initialized
INFO - 2021-06-15 15:22:18 --> Language Class Initialized
ERROR - 2021-06-15 15:22:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:22:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:26 --> Config Class Initialized
INFO - 2021-06-15 15:22:26 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:26 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:26 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:26 --> URI Class Initialized
INFO - 2021-06-15 15:22:26 --> Router Class Initialized
INFO - 2021-06-15 15:22:26 --> Output Class Initialized
INFO - 2021-06-15 15:22:26 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:26 --> Input Class Initialized
INFO - 2021-06-15 15:22:26 --> Language Class Initialized
INFO - 2021-06-15 15:22:26 --> Loader Class Initialized
INFO - 2021-06-15 15:22:26 --> Helper loaded: url_helper
INFO - 2021-06-15 15:22:26 --> Helper loaded: form_helper
INFO - 2021-06-15 15:22:26 --> Helper loaded: common_helper
INFO - 2021-06-15 15:22:26 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:22:26 --> Controller Class Initialized
INFO - 2021-06-15 15:22:26 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:22:26 --> Encrypt Class Initialized
INFO - 2021-06-15 15:22:26 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:22:26 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:22:26 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:22:26 --> Model "Users_model" initialized
INFO - 2021-06-15 15:22:26 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:22:26 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:22:26 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patientcase/index.php
INFO - 2021-06-15 15:22:26 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:22:26 --> Final output sent to browser
DEBUG - 2021-06-15 15:22:26 --> Total execution time: 0.0438
ERROR - 2021-06-15 15:22:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:26 --> Config Class Initialized
INFO - 2021-06-15 15:22:26 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:26 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:26 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:26 --> URI Class Initialized
INFO - 2021-06-15 15:22:26 --> Router Class Initialized
INFO - 2021-06-15 15:22:26 --> Output Class Initialized
INFO - 2021-06-15 15:22:26 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:26 --> Input Class Initialized
INFO - 2021-06-15 15:22:26 --> Language Class Initialized
ERROR - 2021-06-15 15:22:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:22:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:46 --> Config Class Initialized
INFO - 2021-06-15 15:22:46 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:46 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:46 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:46 --> URI Class Initialized
INFO - 2021-06-15 15:22:46 --> Router Class Initialized
INFO - 2021-06-15 15:22:46 --> Output Class Initialized
INFO - 2021-06-15 15:22:46 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:46 --> Input Class Initialized
INFO - 2021-06-15 15:22:46 --> Language Class Initialized
INFO - 2021-06-15 15:22:46 --> Loader Class Initialized
INFO - 2021-06-15 15:22:46 --> Helper loaded: url_helper
INFO - 2021-06-15 15:22:46 --> Helper loaded: form_helper
INFO - 2021-06-15 15:22:46 --> Helper loaded: common_helper
INFO - 2021-06-15 15:22:46 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:22:46 --> Controller Class Initialized
INFO - 2021-06-15 15:22:46 --> Form Validation Class Initialized
INFO - 2021-06-15 15:22:46 --> Model "Case_model" initialized
INFO - 2021-06-15 15:22:46 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:22:48 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:22:48 --> Model "Case_model" initialized
INFO - 2021-06-15 15:22:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/cases/open_case.php
INFO - 2021-06-15 15:22:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:22:51 --> Final output sent to browser
DEBUG - 2021-06-15 15:22:51 --> Total execution time: 4.3748
ERROR - 2021-06-15 15:22:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:51 --> Config Class Initialized
INFO - 2021-06-15 15:22:51 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:51 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:51 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:51 --> URI Class Initialized
INFO - 2021-06-15 15:22:51 --> Router Class Initialized
INFO - 2021-06-15 15:22:51 --> Output Class Initialized
INFO - 2021-06-15 15:22:51 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:51 --> Input Class Initialized
INFO - 2021-06-15 15:22:51 --> Language Class Initialized
ERROR - 2021-06-15 15:22:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:56 --> Config Class Initialized
INFO - 2021-06-15 15:22:56 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:56 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:56 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:56 --> URI Class Initialized
INFO - 2021-06-15 15:22:56 --> Router Class Initialized
INFO - 2021-06-15 15:22:56 --> Output Class Initialized
INFO - 2021-06-15 15:22:56 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:56 --> Input Class Initialized
INFO - 2021-06-15 15:22:56 --> Language Class Initialized
INFO - 2021-06-15 15:22:56 --> Loader Class Initialized
INFO - 2021-06-15 15:22:56 --> Helper loaded: url_helper
INFO - 2021-06-15 15:22:56 --> Helper loaded: form_helper
INFO - 2021-06-15 15:22:56 --> Helper loaded: common_helper
INFO - 2021-06-15 15:22:56 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:22:56 --> Controller Class Initialized
INFO - 2021-06-15 15:22:56 --> Form Validation Class Initialized
INFO - 2021-06-15 15:22:56 --> Model "Case_model" initialized
INFO - 2021-06-15 15:22:56 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:22:56 --> Final output sent to browser
DEBUG - 2021-06-15 15:22:56 --> Total execution time: 0.0306
ERROR - 2021-06-15 15:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:58 --> Config Class Initialized
INFO - 2021-06-15 15:22:58 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:58 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:58 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:58 --> URI Class Initialized
INFO - 2021-06-15 15:22:58 --> Router Class Initialized
INFO - 2021-06-15 15:22:58 --> Output Class Initialized
INFO - 2021-06-15 15:22:58 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:58 --> Input Class Initialized
INFO - 2021-06-15 15:22:58 --> Language Class Initialized
INFO - 2021-06-15 15:22:58 --> Loader Class Initialized
INFO - 2021-06-15 15:22:58 --> Helper loaded: url_helper
INFO - 2021-06-15 15:22:58 --> Helper loaded: form_helper
INFO - 2021-06-15 15:22:58 --> Helper loaded: common_helper
INFO - 2021-06-15 15:22:58 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:22:58 --> Controller Class Initialized
INFO - 2021-06-15 15:22:58 --> Form Validation Class Initialized
INFO - 2021-06-15 15:22:58 --> Model "Case_model" initialized
INFO - 2021-06-15 15:22:58 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:22:58 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:22:58 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/cases/patient_amount_disbursed.php
INFO - 2021-06-15 15:22:58 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:22:58 --> Final output sent to browser
DEBUG - 2021-06-15 15:22:58 --> Total execution time: 0.0977
ERROR - 2021-06-15 15:22:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:22:59 --> Config Class Initialized
INFO - 2021-06-15 15:22:59 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:22:59 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:22:59 --> Utf8 Class Initialized
INFO - 2021-06-15 15:22:59 --> URI Class Initialized
INFO - 2021-06-15 15:22:59 --> Router Class Initialized
INFO - 2021-06-15 15:22:59 --> Output Class Initialized
INFO - 2021-06-15 15:22:59 --> Security Class Initialized
DEBUG - 2021-06-15 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:22:59 --> Input Class Initialized
INFO - 2021-06-15 15:22:59 --> Language Class Initialized
ERROR - 2021-06-15 15:22:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:23:18 --> Config Class Initialized
INFO - 2021-06-15 15:23:18 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:23:18 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:23:18 --> Utf8 Class Initialized
INFO - 2021-06-15 15:23:18 --> URI Class Initialized
INFO - 2021-06-15 15:23:18 --> Router Class Initialized
INFO - 2021-06-15 15:23:18 --> Output Class Initialized
INFO - 2021-06-15 15:23:18 --> Security Class Initialized
DEBUG - 2021-06-15 15:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:23:18 --> Input Class Initialized
INFO - 2021-06-15 15:23:18 --> Language Class Initialized
INFO - 2021-06-15 15:23:18 --> Loader Class Initialized
INFO - 2021-06-15 15:23:18 --> Helper loaded: url_helper
INFO - 2021-06-15 15:23:18 --> Helper loaded: form_helper
INFO - 2021-06-15 15:23:18 --> Helper loaded: common_helper
INFO - 2021-06-15 15:23:18 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:23:18 --> Controller Class Initialized
INFO - 2021-06-15 15:23:18 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:23:18 --> Encrypt Class Initialized
INFO - 2021-06-15 15:23:18 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:23:18 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:23:18 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:23:18 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:23:18 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:23:18 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:23:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-15 15:23:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-15 15:23:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:23:24 --> Config Class Initialized
INFO - 2021-06-15 15:23:24 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:23:24 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:23:24 --> Utf8 Class Initialized
INFO - 2021-06-15 15:23:24 --> URI Class Initialized
INFO - 2021-06-15 15:23:24 --> Router Class Initialized
INFO - 2021-06-15 15:23:24 --> Output Class Initialized
INFO - 2021-06-15 15:23:24 --> Security Class Initialized
DEBUG - 2021-06-15 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:23:24 --> Input Class Initialized
INFO - 2021-06-15 15:23:24 --> Language Class Initialized
ERROR - 2021-06-15 15:23:24 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-15 15:23:24 --> Final output sent to browser
DEBUG - 2021-06-15 15:23:24 --> Total execution time: 4.7130
ERROR - 2021-06-15 15:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:23:27 --> Config Class Initialized
INFO - 2021-06-15 15:23:27 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:23:27 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:23:27 --> Utf8 Class Initialized
INFO - 2021-06-15 15:23:27 --> URI Class Initialized
INFO - 2021-06-15 15:23:27 --> Router Class Initialized
INFO - 2021-06-15 15:23:27 --> Output Class Initialized
INFO - 2021-06-15 15:23:27 --> Security Class Initialized
DEBUG - 2021-06-15 15:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:23:27 --> Input Class Initialized
INFO - 2021-06-15 15:23:27 --> Language Class Initialized
INFO - 2021-06-15 15:23:27 --> Loader Class Initialized
INFO - 2021-06-15 15:23:27 --> Helper loaded: url_helper
INFO - 2021-06-15 15:23:27 --> Helper loaded: form_helper
INFO - 2021-06-15 15:23:27 --> Helper loaded: common_helper
INFO - 2021-06-15 15:23:27 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:23:27 --> Controller Class Initialized
INFO - 2021-06-15 15:23:27 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:23:27 --> Encrypt Class Initialized
INFO - 2021-06-15 15:23:27 --> Model "Patient_model" initialized
INFO - 2021-06-15 15:23:27 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:23:27 --> Model "Prefix_master" initialized
INFO - 2021-06-15 15:23:27 --> Model "Users_model" initialized
INFO - 2021-06-15 15:23:27 --> Model "Hospital_model" initialized
INFO - 2021-06-15 15:23:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:23:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patientcase/index.php
INFO - 2021-06-15 15:23:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:23:28 --> Final output sent to browser
DEBUG - 2021-06-15 15:23:28 --> Total execution time: 0.0464
ERROR - 2021-06-15 15:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:23:28 --> Config Class Initialized
INFO - 2021-06-15 15:23:28 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:23:28 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:23:28 --> Utf8 Class Initialized
INFO - 2021-06-15 15:23:28 --> URI Class Initialized
INFO - 2021-06-15 15:23:28 --> Router Class Initialized
INFO - 2021-06-15 15:23:28 --> Output Class Initialized
INFO - 2021-06-15 15:23:28 --> Security Class Initialized
DEBUG - 2021-06-15 15:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:23:28 --> Input Class Initialized
INFO - 2021-06-15 15:23:28 --> Language Class Initialized
ERROR - 2021-06-15 15:23:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:23:35 --> Config Class Initialized
INFO - 2021-06-15 15:23:35 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:23:35 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:23:35 --> Utf8 Class Initialized
INFO - 2021-06-15 15:23:35 --> URI Class Initialized
INFO - 2021-06-15 15:23:35 --> Router Class Initialized
INFO - 2021-06-15 15:23:35 --> Output Class Initialized
INFO - 2021-06-15 15:23:35 --> Security Class Initialized
DEBUG - 2021-06-15 15:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:23:35 --> Input Class Initialized
INFO - 2021-06-15 15:23:35 --> Language Class Initialized
INFO - 2021-06-15 15:23:35 --> Loader Class Initialized
INFO - 2021-06-15 15:23:35 --> Helper loaded: url_helper
INFO - 2021-06-15 15:23:35 --> Helper loaded: form_helper
INFO - 2021-06-15 15:23:35 --> Helper loaded: common_helper
INFO - 2021-06-15 15:23:35 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:23:35 --> Controller Class Initialized
INFO - 2021-06-15 15:23:35 --> Form Validation Class Initialized
INFO - 2021-06-15 15:23:35 --> Model "Case_model" initialized
INFO - 2021-06-15 15:23:35 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:23:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:23:37 --> Model "Case_model" initialized
INFO - 2021-06-15 15:23:40 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/cases/open_case.php
INFO - 2021-06-15 15:23:40 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-15 15:23:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:23:41 --> Config Class Initialized
INFO - 2021-06-15 15:23:41 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:23:41 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:23:41 --> Utf8 Class Initialized
INFO - 2021-06-15 15:23:41 --> URI Class Initialized
INFO - 2021-06-15 15:23:41 --> Router Class Initialized
INFO - 2021-06-15 15:23:41 --> Output Class Initialized
INFO - 2021-06-15 15:23:41 --> Security Class Initialized
DEBUG - 2021-06-15 15:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:23:41 --> Input Class Initialized
INFO - 2021-06-15 15:23:41 --> Language Class Initialized
ERROR - 2021-06-15 15:23:41 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-15 15:23:41 --> Final output sent to browser
DEBUG - 2021-06-15 15:23:41 --> Total execution time: 4.7379
ERROR - 2021-06-15 15:23:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:23:44 --> Config Class Initialized
INFO - 2021-06-15 15:23:44 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:23:44 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:23:44 --> Utf8 Class Initialized
INFO - 2021-06-15 15:23:44 --> URI Class Initialized
INFO - 2021-06-15 15:23:44 --> Router Class Initialized
INFO - 2021-06-15 15:23:44 --> Output Class Initialized
INFO - 2021-06-15 15:23:44 --> Security Class Initialized
DEBUG - 2021-06-15 15:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:23:44 --> Input Class Initialized
INFO - 2021-06-15 15:23:44 --> Language Class Initialized
INFO - 2021-06-15 15:23:44 --> Loader Class Initialized
INFO - 2021-06-15 15:23:44 --> Helper loaded: url_helper
INFO - 2021-06-15 15:23:44 --> Helper loaded: form_helper
INFO - 2021-06-15 15:23:44 --> Helper loaded: common_helper
INFO - 2021-06-15 15:23:44 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:23:44 --> Controller Class Initialized
INFO - 2021-06-15 15:23:44 --> Form Validation Class Initialized
INFO - 2021-06-15 15:23:44 --> Model "Case_model" initialized
INFO - 2021-06-15 15:23:44 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:23:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:23:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/cases/patient_amount_disbursed.php
INFO - 2021-06-15 15:23:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:23:44 --> Final output sent to browser
DEBUG - 2021-06-15 15:23:44 --> Total execution time: 0.0391
ERROR - 2021-06-15 15:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:23:45 --> Config Class Initialized
INFO - 2021-06-15 15:23:45 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:23:45 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:23:45 --> Utf8 Class Initialized
INFO - 2021-06-15 15:23:45 --> URI Class Initialized
INFO - 2021-06-15 15:23:45 --> Router Class Initialized
INFO - 2021-06-15 15:23:45 --> Output Class Initialized
INFO - 2021-06-15 15:23:45 --> Security Class Initialized
DEBUG - 2021-06-15 15:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:23:45 --> Input Class Initialized
INFO - 2021-06-15 15:23:45 --> Language Class Initialized
ERROR - 2021-06-15 15:23:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:23:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:23:47 --> Config Class Initialized
INFO - 2021-06-15 15:23:47 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:23:47 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:23:47 --> Utf8 Class Initialized
INFO - 2021-06-15 15:23:47 --> URI Class Initialized
INFO - 2021-06-15 15:23:47 --> Router Class Initialized
INFO - 2021-06-15 15:23:47 --> Output Class Initialized
INFO - 2021-06-15 15:23:47 --> Security Class Initialized
DEBUG - 2021-06-15 15:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:23:47 --> Input Class Initialized
INFO - 2021-06-15 15:23:47 --> Language Class Initialized
INFO - 2021-06-15 15:23:47 --> Loader Class Initialized
INFO - 2021-06-15 15:23:47 --> Helper loaded: url_helper
INFO - 2021-06-15 15:23:47 --> Helper loaded: form_helper
INFO - 2021-06-15 15:23:47 --> Helper loaded: common_helper
INFO - 2021-06-15 15:23:47 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:23:47 --> Controller Class Initialized
INFO - 2021-06-15 15:23:47 --> Form Validation Class Initialized
INFO - 2021-06-15 15:23:47 --> Model "Case_model" initialized
INFO - 2021-06-15 15:23:47 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 15:23:47 --> Final output sent to browser
DEBUG - 2021-06-15 15:23:47 --> Total execution time: 0.0183
ERROR - 2021-06-15 15:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:24:21 --> Config Class Initialized
INFO - 2021-06-15 15:24:21 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:24:21 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:24:21 --> Utf8 Class Initialized
INFO - 2021-06-15 15:24:21 --> URI Class Initialized
INFO - 2021-06-15 15:24:21 --> Router Class Initialized
INFO - 2021-06-15 15:24:21 --> Output Class Initialized
INFO - 2021-06-15 15:24:21 --> Security Class Initialized
DEBUG - 2021-06-15 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:24:21 --> Input Class Initialized
INFO - 2021-06-15 15:24:21 --> Language Class Initialized
INFO - 2021-06-15 15:24:21 --> Loader Class Initialized
INFO - 2021-06-15 15:24:21 --> Helper loaded: url_helper
INFO - 2021-06-15 15:24:21 --> Helper loaded: form_helper
INFO - 2021-06-15 15:24:21 --> Helper loaded: common_helper
INFO - 2021-06-15 15:24:21 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:24:21 --> Controller Class Initialized
INFO - 2021-06-15 15:24:21 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:24:21 --> Encrypt Class Initialized
INFO - 2021-06-15 15:24:21 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:24:21 --> Model "Users_model" initialized
INFO - 2021-06-15 15:24:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:24:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-15 15:24:21 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:24:21 --> Final output sent to browser
DEBUG - 2021-06-15 15:24:21 --> Total execution time: 0.0401
ERROR - 2021-06-15 15:24:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:24:22 --> Config Class Initialized
INFO - 2021-06-15 15:24:22 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:24:22 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:24:22 --> Utf8 Class Initialized
INFO - 2021-06-15 15:24:22 --> URI Class Initialized
INFO - 2021-06-15 15:24:22 --> Router Class Initialized
INFO - 2021-06-15 15:24:22 --> Output Class Initialized
INFO - 2021-06-15 15:24:22 --> Security Class Initialized
DEBUG - 2021-06-15 15:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:24:22 --> Input Class Initialized
INFO - 2021-06-15 15:24:22 --> Language Class Initialized
ERROR - 2021-06-15 15:24:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:24:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:24:52 --> Config Class Initialized
INFO - 2021-06-15 15:24:52 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:24:52 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:24:52 --> Utf8 Class Initialized
INFO - 2021-06-15 15:24:52 --> URI Class Initialized
INFO - 2021-06-15 15:24:52 --> Router Class Initialized
INFO - 2021-06-15 15:24:52 --> Output Class Initialized
INFO - 2021-06-15 15:24:52 --> Security Class Initialized
DEBUG - 2021-06-15 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:24:52 --> Input Class Initialized
INFO - 2021-06-15 15:24:52 --> Language Class Initialized
INFO - 2021-06-15 15:24:52 --> Loader Class Initialized
INFO - 2021-06-15 15:24:52 --> Helper loaded: url_helper
INFO - 2021-06-15 15:24:52 --> Helper loaded: form_helper
INFO - 2021-06-15 15:24:52 --> Helper loaded: common_helper
INFO - 2021-06-15 15:24:52 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:24:52 --> Controller Class Initialized
INFO - 2021-06-15 15:24:52 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:24:52 --> Encrypt Class Initialized
INFO - 2021-06-15 15:24:52 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:24:52 --> Model "Users_model" initialized
INFO - 2021-06-15 15:24:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:24:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-15 15:24:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:24:52 --> Final output sent to browser
DEBUG - 2021-06-15 15:24:52 --> Total execution time: 0.0185
ERROR - 2021-06-15 15:24:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:24:52 --> Config Class Initialized
INFO - 2021-06-15 15:24:52 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:24:52 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:24:52 --> Utf8 Class Initialized
INFO - 2021-06-15 15:24:52 --> URI Class Initialized
INFO - 2021-06-15 15:24:52 --> Router Class Initialized
INFO - 2021-06-15 15:24:52 --> Output Class Initialized
INFO - 2021-06-15 15:24:52 --> Security Class Initialized
DEBUG - 2021-06-15 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:24:52 --> Input Class Initialized
INFO - 2021-06-15 15:24:52 --> Language Class Initialized
ERROR - 2021-06-15 15:24:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:25:12 --> Config Class Initialized
INFO - 2021-06-15 15:25:12 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:25:12 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:25:12 --> Utf8 Class Initialized
INFO - 2021-06-15 15:25:12 --> URI Class Initialized
INFO - 2021-06-15 15:25:12 --> Router Class Initialized
INFO - 2021-06-15 15:25:12 --> Output Class Initialized
INFO - 2021-06-15 15:25:12 --> Security Class Initialized
DEBUG - 2021-06-15 15:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:25:12 --> Input Class Initialized
INFO - 2021-06-15 15:25:12 --> Language Class Initialized
INFO - 2021-06-15 15:25:12 --> Loader Class Initialized
INFO - 2021-06-15 15:25:12 --> Helper loaded: url_helper
INFO - 2021-06-15 15:25:12 --> Helper loaded: form_helper
INFO - 2021-06-15 15:25:12 --> Helper loaded: common_helper
INFO - 2021-06-15 15:25:12 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:25:12 --> Controller Class Initialized
INFO - 2021-06-15 15:25:12 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:25:12 --> Encrypt Class Initialized
INFO - 2021-06-15 15:25:12 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:25:12 --> Model "Users_model" initialized
INFO - 2021-06-15 15:25:12 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:25:12 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-15 15:25:12 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:25:12 --> Final output sent to browser
DEBUG - 2021-06-15 15:25:12 --> Total execution time: 0.0212
ERROR - 2021-06-15 15:25:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:25:13 --> Config Class Initialized
INFO - 2021-06-15 15:25:13 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:25:13 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:25:13 --> Utf8 Class Initialized
INFO - 2021-06-15 15:25:13 --> URI Class Initialized
INFO - 2021-06-15 15:25:13 --> Router Class Initialized
INFO - 2021-06-15 15:25:13 --> Output Class Initialized
INFO - 2021-06-15 15:25:13 --> Security Class Initialized
DEBUG - 2021-06-15 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:25:13 --> Input Class Initialized
INFO - 2021-06-15 15:25:13 --> Language Class Initialized
ERROR - 2021-06-15 15:25:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:25:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:25:13 --> Config Class Initialized
INFO - 2021-06-15 15:25:13 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:25:13 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:25:13 --> Utf8 Class Initialized
INFO - 2021-06-15 15:25:13 --> URI Class Initialized
INFO - 2021-06-15 15:25:13 --> Router Class Initialized
INFO - 2021-06-15 15:25:13 --> Output Class Initialized
INFO - 2021-06-15 15:25:13 --> Security Class Initialized
DEBUG - 2021-06-15 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:25:13 --> Input Class Initialized
INFO - 2021-06-15 15:25:13 --> Language Class Initialized
ERROR - 2021-06-15 15:25:13 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 15:25:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:25:28 --> Config Class Initialized
INFO - 2021-06-15 15:25:28 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:25:28 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:25:28 --> Utf8 Class Initialized
INFO - 2021-06-15 15:25:28 --> URI Class Initialized
INFO - 2021-06-15 15:25:28 --> Router Class Initialized
INFO - 2021-06-15 15:25:28 --> Output Class Initialized
INFO - 2021-06-15 15:25:28 --> Security Class Initialized
DEBUG - 2021-06-15 15:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:25:28 --> Input Class Initialized
INFO - 2021-06-15 15:25:28 --> Language Class Initialized
INFO - 2021-06-15 15:25:28 --> Loader Class Initialized
INFO - 2021-06-15 15:25:28 --> Helper loaded: url_helper
INFO - 2021-06-15 15:25:28 --> Helper loaded: form_helper
INFO - 2021-06-15 15:25:28 --> Helper loaded: common_helper
INFO - 2021-06-15 15:25:28 --> Database Driver Class Initialized
DEBUG - 2021-06-15 15:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 15:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 15:25:28 --> Controller Class Initialized
INFO - 2021-06-15 15:25:28 --> Form Validation Class Initialized
DEBUG - 2021-06-15 15:25:28 --> Encrypt Class Initialized
INFO - 2021-06-15 15:25:28 --> Model "Referredby_model" initialized
INFO - 2021-06-15 15:25:28 --> Model "Users_model" initialized
INFO - 2021-06-15 15:25:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 15:25:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-06-15 15:25:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 15:25:28 --> Final output sent to browser
DEBUG - 2021-06-15 15:25:28 --> Total execution time: 0.0237
ERROR - 2021-06-15 15:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 15:25:29 --> Config Class Initialized
INFO - 2021-06-15 15:25:29 --> Hooks Class Initialized
DEBUG - 2021-06-15 15:25:29 --> UTF-8 Support Enabled
INFO - 2021-06-15 15:25:29 --> Utf8 Class Initialized
INFO - 2021-06-15 15:25:29 --> URI Class Initialized
INFO - 2021-06-15 15:25:29 --> Router Class Initialized
INFO - 2021-06-15 15:25:29 --> Output Class Initialized
INFO - 2021-06-15 15:25:29 --> Security Class Initialized
DEBUG - 2021-06-15 15:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 15:25:29 --> Input Class Initialized
INFO - 2021-06-15 15:25:29 --> Language Class Initialized
ERROR - 2021-06-15 15:25:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 17:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:31:15 --> Config Class Initialized
INFO - 2021-06-15 17:31:15 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:31:15 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:31:15 --> Utf8 Class Initialized
INFO - 2021-06-15 17:31:15 --> URI Class Initialized
DEBUG - 2021-06-15 17:31:15 --> No URI present. Default controller set.
INFO - 2021-06-15 17:31:15 --> Router Class Initialized
INFO - 2021-06-15 17:31:15 --> Output Class Initialized
INFO - 2021-06-15 17:31:15 --> Security Class Initialized
DEBUG - 2021-06-15 17:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:31:15 --> Input Class Initialized
INFO - 2021-06-15 17:31:15 --> Language Class Initialized
INFO - 2021-06-15 17:31:15 --> Loader Class Initialized
INFO - 2021-06-15 17:31:15 --> Helper loaded: url_helper
INFO - 2021-06-15 17:31:15 --> Helper loaded: form_helper
INFO - 2021-06-15 17:31:15 --> Helper loaded: common_helper
INFO - 2021-06-15 17:31:15 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:31:15 --> Controller Class Initialized
INFO - 2021-06-15 17:31:15 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:31:15 --> Encrypt Class Initialized
DEBUG - 2021-06-15 17:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 17:31:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 17:31:15 --> Email Class Initialized
INFO - 2021-06-15 17:31:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 17:31:15 --> Calendar Class Initialized
INFO - 2021-06-15 17:31:15 --> Model "Login_model" initialized
INFO - 2021-06-15 17:31:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 17:31:15 --> Final output sent to browser
DEBUG - 2021-06-15 17:31:15 --> Total execution time: 0.0560
ERROR - 2021-06-15 17:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:31:16 --> Config Class Initialized
INFO - 2021-06-15 17:31:16 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:31:16 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:31:16 --> Utf8 Class Initialized
INFO - 2021-06-15 17:31:16 --> URI Class Initialized
DEBUG - 2021-06-15 17:31:16 --> No URI present. Default controller set.
INFO - 2021-06-15 17:31:16 --> Router Class Initialized
INFO - 2021-06-15 17:31:16 --> Output Class Initialized
INFO - 2021-06-15 17:31:16 --> Security Class Initialized
DEBUG - 2021-06-15 17:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:31:16 --> Input Class Initialized
INFO - 2021-06-15 17:31:16 --> Language Class Initialized
INFO - 2021-06-15 17:31:16 --> Loader Class Initialized
INFO - 2021-06-15 17:31:16 --> Helper loaded: url_helper
INFO - 2021-06-15 17:31:16 --> Helper loaded: form_helper
INFO - 2021-06-15 17:31:16 --> Helper loaded: common_helper
INFO - 2021-06-15 17:31:16 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:31:16 --> Controller Class Initialized
INFO - 2021-06-15 17:31:16 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:31:16 --> Encrypt Class Initialized
DEBUG - 2021-06-15 17:31:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 17:31:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 17:31:16 --> Email Class Initialized
INFO - 2021-06-15 17:31:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 17:31:16 --> Calendar Class Initialized
INFO - 2021-06-15 17:31:16 --> Model "Login_model" initialized
INFO - 2021-06-15 17:31:16 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-06-15 17:31:16 --> Final output sent to browser
DEBUG - 2021-06-15 17:31:16 --> Total execution time: 0.0264
ERROR - 2021-06-15 17:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:31:17 --> Config Class Initialized
INFO - 2021-06-15 17:31:17 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:31:17 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:31:17 --> Utf8 Class Initialized
INFO - 2021-06-15 17:31:17 --> URI Class Initialized
INFO - 2021-06-15 17:31:17 --> Router Class Initialized
INFO - 2021-06-15 17:31:17 --> Output Class Initialized
INFO - 2021-06-15 17:31:17 --> Security Class Initialized
DEBUG - 2021-06-15 17:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:31:17 --> Input Class Initialized
INFO - 2021-06-15 17:31:17 --> Language Class Initialized
ERROR - 2021-06-15 17:31:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-15 17:31:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:31:21 --> Config Class Initialized
INFO - 2021-06-15 17:31:21 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:31:21 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:31:21 --> Utf8 Class Initialized
INFO - 2021-06-15 17:31:21 --> URI Class Initialized
INFO - 2021-06-15 17:31:21 --> Router Class Initialized
INFO - 2021-06-15 17:31:21 --> Output Class Initialized
INFO - 2021-06-15 17:31:21 --> Security Class Initialized
DEBUG - 2021-06-15 17:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:31:21 --> Input Class Initialized
INFO - 2021-06-15 17:31:21 --> Language Class Initialized
INFO - 2021-06-15 17:31:21 --> Loader Class Initialized
INFO - 2021-06-15 17:31:21 --> Helper loaded: url_helper
INFO - 2021-06-15 17:31:21 --> Helper loaded: form_helper
INFO - 2021-06-15 17:31:21 --> Helper loaded: common_helper
INFO - 2021-06-15 17:31:21 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:31:21 --> Controller Class Initialized
INFO - 2021-06-15 17:31:21 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:31:21 --> Encrypt Class Initialized
DEBUG - 2021-06-15 17:31:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-06-15 17:31:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-06-15 17:31:21 --> Email Class Initialized
INFO - 2021-06-15 17:31:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-06-15 17:31:21 --> Calendar Class Initialized
INFO - 2021-06-15 17:31:21 --> Model "Login_model" initialized
INFO - 2021-06-15 17:31:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-06-15 17:31:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:31:21 --> Config Class Initialized
INFO - 2021-06-15 17:31:21 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:31:21 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:31:21 --> Utf8 Class Initialized
INFO - 2021-06-15 17:31:21 --> URI Class Initialized
INFO - 2021-06-15 17:31:21 --> Router Class Initialized
INFO - 2021-06-15 17:31:21 --> Output Class Initialized
INFO - 2021-06-15 17:31:21 --> Security Class Initialized
DEBUG - 2021-06-15 17:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:31:21 --> Input Class Initialized
INFO - 2021-06-15 17:31:21 --> Language Class Initialized
INFO - 2021-06-15 17:31:21 --> Loader Class Initialized
INFO - 2021-06-15 17:31:21 --> Helper loaded: url_helper
INFO - 2021-06-15 17:31:21 --> Helper loaded: form_helper
INFO - 2021-06-15 17:31:21 --> Helper loaded: common_helper
INFO - 2021-06-15 17:31:21 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:31:21 --> Controller Class Initialized
INFO - 2021-06-15 17:31:21 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:31:21 --> Encrypt Class Initialized
INFO - 2021-06-15 17:31:21 --> Model "Login_model" initialized
INFO - 2021-06-15 17:31:21 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 17:31:21 --> Model "Case_model" initialized
INFO - 2021-06-15 17:31:24 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 17:31:32 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-15 17:31:32 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 17:31:32 --> Final output sent to browser
DEBUG - 2021-06-15 17:31:32 --> Total execution time: 10.4973
ERROR - 2021-06-15 17:31:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:31:33 --> Config Class Initialized
INFO - 2021-06-15 17:31:33 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:31:33 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:31:33 --> Utf8 Class Initialized
INFO - 2021-06-15 17:31:33 --> URI Class Initialized
INFO - 2021-06-15 17:31:33 --> Router Class Initialized
INFO - 2021-06-15 17:31:33 --> Output Class Initialized
INFO - 2021-06-15 17:31:33 --> Security Class Initialized
DEBUG - 2021-06-15 17:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:31:33 --> Input Class Initialized
INFO - 2021-06-15 17:31:33 --> Language Class Initialized
ERROR - 2021-06-15 17:31:33 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 17:33:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:33:08 --> Config Class Initialized
INFO - 2021-06-15 17:33:08 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:33:08 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:33:08 --> Utf8 Class Initialized
INFO - 2021-06-15 17:33:08 --> URI Class Initialized
INFO - 2021-06-15 17:33:08 --> Router Class Initialized
INFO - 2021-06-15 17:33:08 --> Output Class Initialized
INFO - 2021-06-15 17:33:08 --> Security Class Initialized
DEBUG - 2021-06-15 17:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:33:08 --> Input Class Initialized
INFO - 2021-06-15 17:33:08 --> Language Class Initialized
INFO - 2021-06-15 17:33:08 --> Loader Class Initialized
INFO - 2021-06-15 17:33:08 --> Helper loaded: url_helper
INFO - 2021-06-15 17:33:08 --> Helper loaded: form_helper
INFO - 2021-06-15 17:33:08 --> Helper loaded: common_helper
INFO - 2021-06-15 17:33:08 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:33:08 --> Controller Class Initialized
INFO - 2021-06-15 17:33:08 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:33:08 --> Encrypt Class Initialized
INFO - 2021-06-15 17:33:08 --> Model "Login_model" initialized
INFO - 2021-06-15 17:33:08 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 17:33:08 --> Model "Case_model" initialized
INFO - 2021-06-15 17:33:10 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 17:33:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-15 17:33:17 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 17:33:17 --> Final output sent to browser
DEBUG - 2021-06-15 17:33:17 --> Total execution time: 9.5964
ERROR - 2021-06-15 17:33:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:33:19 --> Config Class Initialized
INFO - 2021-06-15 17:33:19 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:33:19 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:33:19 --> Utf8 Class Initialized
INFO - 2021-06-15 17:33:19 --> URI Class Initialized
INFO - 2021-06-15 17:33:19 --> Router Class Initialized
INFO - 2021-06-15 17:33:19 --> Output Class Initialized
INFO - 2021-06-15 17:33:19 --> Security Class Initialized
DEBUG - 2021-06-15 17:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:33:19 --> Input Class Initialized
INFO - 2021-06-15 17:33:19 --> Language Class Initialized
ERROR - 2021-06-15 17:33:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 17:33:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:33:34 --> Config Class Initialized
INFO - 2021-06-15 17:33:34 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:33:34 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:33:34 --> Utf8 Class Initialized
INFO - 2021-06-15 17:33:34 --> URI Class Initialized
INFO - 2021-06-15 17:33:34 --> Router Class Initialized
INFO - 2021-06-15 17:33:34 --> Output Class Initialized
INFO - 2021-06-15 17:33:34 --> Security Class Initialized
DEBUG - 2021-06-15 17:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:33:34 --> Input Class Initialized
INFO - 2021-06-15 17:33:34 --> Language Class Initialized
INFO - 2021-06-15 17:33:34 --> Loader Class Initialized
INFO - 2021-06-15 17:33:34 --> Helper loaded: url_helper
INFO - 2021-06-15 17:33:34 --> Helper loaded: form_helper
INFO - 2021-06-15 17:33:34 --> Helper loaded: common_helper
INFO - 2021-06-15 17:33:34 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:33:34 --> Controller Class Initialized
INFO - 2021-06-15 17:33:34 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:33:34 --> Encrypt Class Initialized
INFO - 2021-06-15 17:33:34 --> Model "Login_model" initialized
INFO - 2021-06-15 17:33:34 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 17:33:34 --> Model "Case_model" initialized
INFO - 2021-06-15 17:33:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 17:33:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-15 17:33:44 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 17:33:44 --> Final output sent to browser
DEBUG - 2021-06-15 17:33:44 --> Total execution time: 9.6848
ERROR - 2021-06-15 17:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:33:47 --> Config Class Initialized
INFO - 2021-06-15 17:33:47 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:33:47 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:33:47 --> Utf8 Class Initialized
INFO - 2021-06-15 17:33:47 --> URI Class Initialized
INFO - 2021-06-15 17:33:47 --> Router Class Initialized
INFO - 2021-06-15 17:33:47 --> Output Class Initialized
INFO - 2021-06-15 17:33:47 --> Security Class Initialized
DEBUG - 2021-06-15 17:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:33:47 --> Input Class Initialized
INFO - 2021-06-15 17:33:47 --> Language Class Initialized
ERROR - 2021-06-15 17:33:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 17:35:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:35:53 --> Config Class Initialized
INFO - 2021-06-15 17:35:53 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:35:53 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:35:53 --> Utf8 Class Initialized
INFO - 2021-06-15 17:35:53 --> URI Class Initialized
INFO - 2021-06-15 17:35:53 --> Router Class Initialized
INFO - 2021-06-15 17:35:53 --> Output Class Initialized
INFO - 2021-06-15 17:35:53 --> Security Class Initialized
DEBUG - 2021-06-15 17:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:35:53 --> Input Class Initialized
INFO - 2021-06-15 17:35:53 --> Language Class Initialized
INFO - 2021-06-15 17:35:53 --> Loader Class Initialized
INFO - 2021-06-15 17:35:53 --> Helper loaded: url_helper
INFO - 2021-06-15 17:35:53 --> Helper loaded: form_helper
INFO - 2021-06-15 17:35:53 --> Helper loaded: common_helper
INFO - 2021-06-15 17:35:53 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:35:53 --> Controller Class Initialized
INFO - 2021-06-15 17:35:54 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:35:54 --> Encrypt Class Initialized
INFO - 2021-06-15 17:35:54 --> Model "Login_model" initialized
INFO - 2021-06-15 17:35:54 --> Model "Dashboard_model" initialized
INFO - 2021-06-15 17:35:54 --> Model "Case_model" initialized
INFO - 2021-06-15 17:35:56 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 17:36:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-06-15 17:36:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 17:36:03 --> Final output sent to browser
DEBUG - 2021-06-15 17:36:03 --> Total execution time: 9.4245
ERROR - 2021-06-15 17:36:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:36:05 --> Config Class Initialized
INFO - 2021-06-15 17:36:05 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:36:05 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:36:05 --> Utf8 Class Initialized
INFO - 2021-06-15 17:36:05 --> URI Class Initialized
INFO - 2021-06-15 17:36:05 --> Router Class Initialized
INFO - 2021-06-15 17:36:05 --> Output Class Initialized
INFO - 2021-06-15 17:36:05 --> Security Class Initialized
DEBUG - 2021-06-15 17:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:36:05 --> Input Class Initialized
INFO - 2021-06-15 17:36:05 --> Language Class Initialized
ERROR - 2021-06-15 17:36:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 17:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:38:16 --> Config Class Initialized
INFO - 2021-06-15 17:38:16 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:38:16 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:38:16 --> Utf8 Class Initialized
INFO - 2021-06-15 17:38:16 --> URI Class Initialized
INFO - 2021-06-15 17:38:16 --> Router Class Initialized
INFO - 2021-06-15 17:38:16 --> Output Class Initialized
INFO - 2021-06-15 17:38:16 --> Security Class Initialized
DEBUG - 2021-06-15 17:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:38:16 --> Input Class Initialized
INFO - 2021-06-15 17:38:16 --> Language Class Initialized
INFO - 2021-06-15 17:38:16 --> Loader Class Initialized
INFO - 2021-06-15 17:38:16 --> Helper loaded: url_helper
INFO - 2021-06-15 17:38:16 --> Helper loaded: form_helper
INFO - 2021-06-15 17:38:16 --> Helper loaded: common_helper
INFO - 2021-06-15 17:38:16 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:38:16 --> Controller Class Initialized
INFO - 2021-06-15 17:38:16 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:38:16 --> Encrypt Class Initialized
INFO - 2021-06-15 17:38:16 --> Model "Patient_model" initialized
INFO - 2021-06-15 17:38:16 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 17:38:16 --> Model "Referredby_model" initialized
INFO - 2021-06-15 17:38:16 --> Model "Prefix_master" initialized
INFO - 2021-06-15 17:38:16 --> Model "Hospital_model" initialized
INFO - 2021-06-15 17:38:16 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 17:38:16 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patient_by_category.php
INFO - 2021-06-15 17:38:16 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-06-15 17:38:16 --> Final output sent to browser
DEBUG - 2021-06-15 17:38:16 --> Total execution time: 0.0450
ERROR - 2021-06-15 17:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:38:16 --> Config Class Initialized
INFO - 2021-06-15 17:38:16 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:38:16 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:38:16 --> Utf8 Class Initialized
INFO - 2021-06-15 17:38:16 --> URI Class Initialized
INFO - 2021-06-15 17:38:16 --> Router Class Initialized
INFO - 2021-06-15 17:38:16 --> Output Class Initialized
INFO - 2021-06-15 17:38:16 --> Security Class Initialized
DEBUG - 2021-06-15 17:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:38:16 --> Input Class Initialized
INFO - 2021-06-15 17:38:16 --> Language Class Initialized
ERROR - 2021-06-15 17:38:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-06-15 17:38:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:38:25 --> Config Class Initialized
INFO - 2021-06-15 17:38:25 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:38:25 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:38:25 --> Utf8 Class Initialized
INFO - 2021-06-15 17:38:25 --> URI Class Initialized
INFO - 2021-06-15 17:38:25 --> Router Class Initialized
INFO - 2021-06-15 17:38:25 --> Output Class Initialized
INFO - 2021-06-15 17:38:25 --> Security Class Initialized
DEBUG - 2021-06-15 17:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:38:25 --> Input Class Initialized
INFO - 2021-06-15 17:38:25 --> Language Class Initialized
INFO - 2021-06-15 17:38:25 --> Loader Class Initialized
INFO - 2021-06-15 17:38:25 --> Helper loaded: url_helper
INFO - 2021-06-15 17:38:25 --> Helper loaded: form_helper
INFO - 2021-06-15 17:38:25 --> Helper loaded: common_helper
INFO - 2021-06-15 17:38:25 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:38:25 --> Controller Class Initialized
INFO - 2021-06-15 17:38:25 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:38:25 --> Encrypt Class Initialized
INFO - 2021-06-15 17:38:25 --> Model "Patient_model" initialized
INFO - 2021-06-15 17:38:25 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 17:38:25 --> Model "Referredby_model" initialized
INFO - 2021-06-15 17:38:25 --> Model "Prefix_master" initialized
INFO - 2021-06-15 17:38:25 --> Model "Hospital_model" initialized
INFO - 2021-06-15 17:38:25 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-06-15 17:38:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-06-15 17:38:30 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-06-15 17:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:38:31 --> Config Class Initialized
INFO - 2021-06-15 17:38:31 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:38:31 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:38:31 --> Utf8 Class Initialized
INFO - 2021-06-15 17:38:31 --> URI Class Initialized
INFO - 2021-06-15 17:38:31 --> Router Class Initialized
INFO - 2021-06-15 17:38:31 --> Output Class Initialized
INFO - 2021-06-15 17:38:31 --> Security Class Initialized
DEBUG - 2021-06-15 17:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:38:31 --> Input Class Initialized
INFO - 2021-06-15 17:38:31 --> Language Class Initialized
ERROR - 2021-06-15 17:38:31 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-06-15 17:38:34 --> Final output sent to browser
DEBUG - 2021-06-15 17:38:34 --> Total execution time: 4.9083
ERROR - 2021-06-15 17:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:39:00 --> Config Class Initialized
INFO - 2021-06-15 17:39:00 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:39:00 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:39:00 --> Utf8 Class Initialized
INFO - 2021-06-15 17:39:00 --> URI Class Initialized
INFO - 2021-06-15 17:39:00 --> Router Class Initialized
INFO - 2021-06-15 17:39:00 --> Output Class Initialized
INFO - 2021-06-15 17:39:00 --> Security Class Initialized
DEBUG - 2021-06-15 17:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:39:00 --> Input Class Initialized
INFO - 2021-06-15 17:39:00 --> Language Class Initialized
INFO - 2021-06-15 17:39:00 --> Loader Class Initialized
INFO - 2021-06-15 17:39:00 --> Helper loaded: url_helper
INFO - 2021-06-15 17:39:00 --> Helper loaded: form_helper
INFO - 2021-06-15 17:39:00 --> Helper loaded: common_helper
INFO - 2021-06-15 17:39:00 --> Database Driver Class Initialized
DEBUG - 2021-06-15 17:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-15 17:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-15 17:39:00 --> Controller Class Initialized
INFO - 2021-06-15 17:39:00 --> Form Validation Class Initialized
DEBUG - 2021-06-15 17:39:00 --> Encrypt Class Initialized
INFO - 2021-06-15 17:39:00 --> Model "Patient_model" initialized
INFO - 2021-06-15 17:39:00 --> Model "Patientcase_model" initialized
INFO - 2021-06-15 17:39:00 --> Model "Prefix_master" initialized
INFO - 2021-06-15 17:39:00 --> Model "Users_model" initialized
INFO - 2021-06-15 17:39:00 --> Model "Hospital_model" initialized
INFO - 2021-06-15 17:39:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views//patientcase/patient_pdf.php
ERROR - 2021-06-15 17:39:01 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found /home1/techywbu/karo.notioninfosoft.com/application/controllers/Patientcase.php 496
ERROR - 2021-06-15 17:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-06-15 17:39:02 --> Config Class Initialized
INFO - 2021-06-15 17:39:02 --> Hooks Class Initialized
DEBUG - 2021-06-15 17:39:02 --> UTF-8 Support Enabled
INFO - 2021-06-15 17:39:02 --> Utf8 Class Initialized
INFO - 2021-06-15 17:39:02 --> URI Class Initialized
INFO - 2021-06-15 17:39:02 --> Router Class Initialized
INFO - 2021-06-15 17:39:02 --> Output Class Initialized
INFO - 2021-06-15 17:39:02 --> Security Class Initialized
DEBUG - 2021-06-15 17:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-15 17:39:02 --> Input Class Initialized
INFO - 2021-06-15 17:39:02 --> Language Class Initialized
ERROR - 2021-06-15 17:39:02 --> 404 Page Not Found: Faviconico/index
