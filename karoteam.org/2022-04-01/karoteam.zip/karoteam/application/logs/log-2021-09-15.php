<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-15 06:41:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-15 06:41:49 --> Config Class Initialized
INFO - 2021-09-15 06:41:49 --> Hooks Class Initialized
DEBUG - 2021-09-15 06:41:49 --> UTF-8 Support Enabled
INFO - 2021-09-15 06:41:49 --> Utf8 Class Initialized
INFO - 2021-09-15 06:41:49 --> URI Class Initialized
DEBUG - 2021-09-15 06:41:49 --> No URI present. Default controller set.
INFO - 2021-09-15 06:41:49 --> Router Class Initialized
INFO - 2021-09-15 06:41:49 --> Output Class Initialized
INFO - 2021-09-15 06:41:49 --> Security Class Initialized
DEBUG - 2021-09-15 06:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-15 06:41:49 --> Input Class Initialized
INFO - 2021-09-15 06:41:49 --> Language Class Initialized
INFO - 2021-09-15 06:41:49 --> Loader Class Initialized
INFO - 2021-09-15 06:41:49 --> Helper loaded: url_helper
INFO - 2021-09-15 06:41:49 --> Helper loaded: form_helper
INFO - 2021-09-15 06:41:49 --> Helper loaded: common_helper
INFO - 2021-09-15 06:41:49 --> Database Driver Class Initialized
DEBUG - 2021-09-15 06:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-15 06:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-15 06:41:49 --> Controller Class Initialized
INFO - 2021-09-15 06:41:49 --> Form Validation Class Initialized
DEBUG - 2021-09-15 06:41:49 --> Encrypt Class Initialized
DEBUG - 2021-09-15 06:41:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-15 06:41:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-15 06:41:49 --> Email Class Initialized
INFO - 2021-09-15 06:41:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-15 06:41:49 --> Calendar Class Initialized
INFO - 2021-09-15 06:41:49 --> Model "Login_model" initialized
INFO - 2021-09-15 06:41:49 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-15 06:41:49 --> Final output sent to browser
DEBUG - 2021-09-15 06:41:49 --> Total execution time: 0.0415
ERROR - 2021-09-15 07:17:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-15 07:17:50 --> Config Class Initialized
INFO - 2021-09-15 07:17:50 --> Hooks Class Initialized
DEBUG - 2021-09-15 07:17:50 --> UTF-8 Support Enabled
INFO - 2021-09-15 07:17:50 --> Utf8 Class Initialized
INFO - 2021-09-15 07:17:50 --> URI Class Initialized
DEBUG - 2021-09-15 07:17:50 --> No URI present. Default controller set.
INFO - 2021-09-15 07:17:50 --> Router Class Initialized
INFO - 2021-09-15 07:17:50 --> Output Class Initialized
INFO - 2021-09-15 07:17:50 --> Security Class Initialized
DEBUG - 2021-09-15 07:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-15 07:17:50 --> Input Class Initialized
INFO - 2021-09-15 07:17:50 --> Language Class Initialized
INFO - 2021-09-15 07:17:50 --> Loader Class Initialized
INFO - 2021-09-15 07:17:50 --> Helper loaded: url_helper
INFO - 2021-09-15 07:17:50 --> Helper loaded: form_helper
INFO - 2021-09-15 07:17:50 --> Helper loaded: common_helper
INFO - 2021-09-15 07:17:50 --> Database Driver Class Initialized
DEBUG - 2021-09-15 07:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-15 07:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-15 07:17:50 --> Controller Class Initialized
INFO - 2021-09-15 07:17:50 --> Form Validation Class Initialized
DEBUG - 2021-09-15 07:17:50 --> Encrypt Class Initialized
DEBUG - 2021-09-15 07:17:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-15 07:17:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-15 07:17:50 --> Email Class Initialized
INFO - 2021-09-15 07:17:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-15 07:17:50 --> Calendar Class Initialized
INFO - 2021-09-15 07:17:50 --> Model "Login_model" initialized
INFO - 2021-09-15 07:17:50 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-15 07:17:50 --> Final output sent to browser
DEBUG - 2021-09-15 07:17:50 --> Total execution time: 0.0490
ERROR - 2021-09-15 07:27:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-15 07:27:33 --> Config Class Initialized
INFO - 2021-09-15 07:27:33 --> Hooks Class Initialized
DEBUG - 2021-09-15 07:27:33 --> UTF-8 Support Enabled
INFO - 2021-09-15 07:27:33 --> Utf8 Class Initialized
INFO - 2021-09-15 07:27:33 --> URI Class Initialized
DEBUG - 2021-09-15 07:27:33 --> No URI present. Default controller set.
INFO - 2021-09-15 07:27:33 --> Router Class Initialized
INFO - 2021-09-15 07:27:33 --> Output Class Initialized
INFO - 2021-09-15 07:27:33 --> Security Class Initialized
DEBUG - 2021-09-15 07:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-15 07:27:33 --> Input Class Initialized
INFO - 2021-09-15 07:27:33 --> Language Class Initialized
INFO - 2021-09-15 07:27:33 --> Loader Class Initialized
INFO - 2021-09-15 07:27:33 --> Helper loaded: url_helper
INFO - 2021-09-15 07:27:33 --> Helper loaded: form_helper
INFO - 2021-09-15 07:27:33 --> Helper loaded: common_helper
INFO - 2021-09-15 07:27:33 --> Database Driver Class Initialized
DEBUG - 2021-09-15 07:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-15 07:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-15 07:27:33 --> Controller Class Initialized
INFO - 2021-09-15 07:27:33 --> Form Validation Class Initialized
DEBUG - 2021-09-15 07:27:33 --> Encrypt Class Initialized
DEBUG - 2021-09-15 07:27:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-15 07:27:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-15 07:27:33 --> Email Class Initialized
INFO - 2021-09-15 07:27:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-15 07:27:33 --> Calendar Class Initialized
INFO - 2021-09-15 07:27:33 --> Model "Login_model" initialized
INFO - 2021-09-15 07:27:33 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-15 07:27:33 --> Final output sent to browser
DEBUG - 2021-09-15 07:27:33 --> Total execution time: 0.0676
ERROR - 2021-09-15 08:09:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-15 08:09:33 --> Config Class Initialized
INFO - 2021-09-15 08:09:33 --> Hooks Class Initialized
DEBUG - 2021-09-15 08:09:33 --> UTF-8 Support Enabled
INFO - 2021-09-15 08:09:33 --> Utf8 Class Initialized
INFO - 2021-09-15 08:09:33 --> URI Class Initialized
DEBUG - 2021-09-15 08:09:33 --> No URI present. Default controller set.
INFO - 2021-09-15 08:09:33 --> Router Class Initialized
INFO - 2021-09-15 08:09:33 --> Output Class Initialized
INFO - 2021-09-15 08:09:33 --> Security Class Initialized
DEBUG - 2021-09-15 08:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-15 08:09:33 --> Input Class Initialized
INFO - 2021-09-15 08:09:33 --> Language Class Initialized
INFO - 2021-09-15 08:09:33 --> Loader Class Initialized
INFO - 2021-09-15 08:09:33 --> Helper loaded: url_helper
INFO - 2021-09-15 08:09:33 --> Helper loaded: form_helper
INFO - 2021-09-15 08:09:33 --> Helper loaded: common_helper
INFO - 2021-09-15 08:09:33 --> Database Driver Class Initialized
DEBUG - 2021-09-15 08:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-15 08:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-15 08:09:33 --> Controller Class Initialized
INFO - 2021-09-15 08:09:33 --> Form Validation Class Initialized
DEBUG - 2021-09-15 08:09:33 --> Encrypt Class Initialized
DEBUG - 2021-09-15 08:09:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-15 08:09:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-15 08:09:33 --> Email Class Initialized
INFO - 2021-09-15 08:09:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-15 08:09:33 --> Calendar Class Initialized
INFO - 2021-09-15 08:09:33 --> Model "Login_model" initialized
INFO - 2021-09-15 08:09:33 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-15 08:09:33 --> Final output sent to browser
DEBUG - 2021-09-15 08:09:33 --> Total execution time: 0.0543
ERROR - 2021-09-15 08:12:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-15 08:12:10 --> Config Class Initialized
INFO - 2021-09-15 08:12:10 --> Hooks Class Initialized
DEBUG - 2021-09-15 08:12:10 --> UTF-8 Support Enabled
INFO - 2021-09-15 08:12:10 --> Utf8 Class Initialized
INFO - 2021-09-15 08:12:10 --> URI Class Initialized
DEBUG - 2021-09-15 08:12:10 --> No URI present. Default controller set.
INFO - 2021-09-15 08:12:10 --> Router Class Initialized
INFO - 2021-09-15 08:12:10 --> Output Class Initialized
INFO - 2021-09-15 08:12:10 --> Security Class Initialized
DEBUG - 2021-09-15 08:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-15 08:12:10 --> Input Class Initialized
INFO - 2021-09-15 08:12:10 --> Language Class Initialized
INFO - 2021-09-15 08:12:10 --> Loader Class Initialized
INFO - 2021-09-15 08:12:10 --> Helper loaded: url_helper
INFO - 2021-09-15 08:12:10 --> Helper loaded: form_helper
INFO - 2021-09-15 08:12:10 --> Helper loaded: common_helper
INFO - 2021-09-15 08:12:10 --> Database Driver Class Initialized
DEBUG - 2021-09-15 08:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-15 08:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-15 08:12:10 --> Controller Class Initialized
INFO - 2021-09-15 08:12:10 --> Form Validation Class Initialized
DEBUG - 2021-09-15 08:12:10 --> Encrypt Class Initialized
DEBUG - 2021-09-15 08:12:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-15 08:12:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-15 08:12:10 --> Email Class Initialized
INFO - 2021-09-15 08:12:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-15 08:12:10 --> Calendar Class Initialized
INFO - 2021-09-15 08:12:10 --> Model "Login_model" initialized
INFO - 2021-09-15 08:12:10 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-15 08:12:10 --> Final output sent to browser
DEBUG - 2021-09-15 08:12:10 --> Total execution time: 0.0300
ERROR - 2021-09-15 10:59:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-15 10:59:33 --> Config Class Initialized
INFO - 2021-09-15 10:59:33 --> Hooks Class Initialized
DEBUG - 2021-09-15 10:59:33 --> UTF-8 Support Enabled
INFO - 2021-09-15 10:59:33 --> Utf8 Class Initialized
INFO - 2021-09-15 10:59:33 --> URI Class Initialized
DEBUG - 2021-09-15 10:59:33 --> No URI present. Default controller set.
INFO - 2021-09-15 10:59:33 --> Router Class Initialized
INFO - 2021-09-15 10:59:33 --> Output Class Initialized
INFO - 2021-09-15 10:59:33 --> Security Class Initialized
DEBUG - 2021-09-15 10:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-15 10:59:33 --> Input Class Initialized
INFO - 2021-09-15 10:59:33 --> Language Class Initialized
INFO - 2021-09-15 10:59:33 --> Loader Class Initialized
INFO - 2021-09-15 10:59:33 --> Helper loaded: url_helper
INFO - 2021-09-15 10:59:33 --> Helper loaded: form_helper
INFO - 2021-09-15 10:59:33 --> Helper loaded: common_helper
INFO - 2021-09-15 10:59:33 --> Database Driver Class Initialized
DEBUG - 2021-09-15 10:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-15 10:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-15 10:59:33 --> Controller Class Initialized
INFO - 2021-09-15 10:59:33 --> Form Validation Class Initialized
DEBUG - 2021-09-15 10:59:33 --> Encrypt Class Initialized
DEBUG - 2021-09-15 10:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-15 10:59:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-15 10:59:33 --> Email Class Initialized
INFO - 2021-09-15 10:59:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-15 10:59:33 --> Calendar Class Initialized
INFO - 2021-09-15 10:59:33 --> Model "Login_model" initialized
INFO - 2021-09-15 10:59:33 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-15 10:59:33 --> Final output sent to browser
DEBUG - 2021-09-15 10:59:33 --> Total execution time: 0.2379
