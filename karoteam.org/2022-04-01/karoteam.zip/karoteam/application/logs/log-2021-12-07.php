<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-07 00:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 00:28:38 --> Config Class Initialized
INFO - 2021-12-07 00:28:38 --> Hooks Class Initialized
DEBUG - 2021-12-07 00:28:38 --> UTF-8 Support Enabled
INFO - 2021-12-07 00:28:38 --> Utf8 Class Initialized
INFO - 2021-12-07 00:28:38 --> URI Class Initialized
DEBUG - 2021-12-07 00:28:38 --> No URI present. Default controller set.
INFO - 2021-12-07 00:28:38 --> Router Class Initialized
INFO - 2021-12-07 00:28:38 --> Output Class Initialized
INFO - 2021-12-07 00:28:38 --> Security Class Initialized
DEBUG - 2021-12-07 00:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 00:28:38 --> Input Class Initialized
INFO - 2021-12-07 00:28:38 --> Language Class Initialized
INFO - 2021-12-07 00:28:38 --> Loader Class Initialized
INFO - 2021-12-07 00:28:38 --> Helper loaded: url_helper
INFO - 2021-12-07 00:28:38 --> Helper loaded: form_helper
INFO - 2021-12-07 00:28:38 --> Helper loaded: common_helper
INFO - 2021-12-07 00:28:38 --> Database Driver Class Initialized
DEBUG - 2021-12-07 00:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 00:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 00:28:38 --> Controller Class Initialized
INFO - 2021-12-07 00:28:38 --> Form Validation Class Initialized
DEBUG - 2021-12-07 00:28:38 --> Encrypt Class Initialized
DEBUG - 2021-12-07 00:28:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 00:28:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 00:28:38 --> Email Class Initialized
INFO - 2021-12-07 00:28:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 00:28:38 --> Calendar Class Initialized
INFO - 2021-12-07 00:28:38 --> Model "Login_model" initialized
INFO - 2021-12-07 00:28:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 00:28:38 --> Final output sent to browser
DEBUG - 2021-12-07 00:28:38 --> Total execution time: 0.0249
ERROR - 2021-12-07 02:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 02:44:26 --> Config Class Initialized
INFO - 2021-12-07 02:44:26 --> Hooks Class Initialized
DEBUG - 2021-12-07 02:44:26 --> UTF-8 Support Enabled
INFO - 2021-12-07 02:44:26 --> Utf8 Class Initialized
INFO - 2021-12-07 02:44:26 --> URI Class Initialized
DEBUG - 2021-12-07 02:44:26 --> No URI present. Default controller set.
INFO - 2021-12-07 02:44:26 --> Router Class Initialized
INFO - 2021-12-07 02:44:26 --> Output Class Initialized
INFO - 2021-12-07 02:44:26 --> Security Class Initialized
DEBUG - 2021-12-07 02:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 02:44:26 --> Input Class Initialized
INFO - 2021-12-07 02:44:26 --> Language Class Initialized
INFO - 2021-12-07 02:44:26 --> Loader Class Initialized
INFO - 2021-12-07 02:44:26 --> Helper loaded: url_helper
INFO - 2021-12-07 02:44:26 --> Helper loaded: form_helper
INFO - 2021-12-07 02:44:26 --> Helper loaded: common_helper
INFO - 2021-12-07 02:44:26 --> Database Driver Class Initialized
DEBUG - 2021-12-07 02:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 02:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 02:44:26 --> Controller Class Initialized
INFO - 2021-12-07 02:44:26 --> Form Validation Class Initialized
DEBUG - 2021-12-07 02:44:26 --> Encrypt Class Initialized
DEBUG - 2021-12-07 02:44:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 02:44:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 02:44:26 --> Email Class Initialized
INFO - 2021-12-07 02:44:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 02:44:26 --> Calendar Class Initialized
INFO - 2021-12-07 02:44:26 --> Model "Login_model" initialized
INFO - 2021-12-07 02:44:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 02:44:26 --> Final output sent to browser
DEBUG - 2021-12-07 02:44:26 --> Total execution time: 0.0231
ERROR - 2021-12-07 08:00:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 08:00:05 --> Config Class Initialized
INFO - 2021-12-07 08:00:05 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:00:05 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:00:05 --> Utf8 Class Initialized
INFO - 2021-12-07 08:00:05 --> URI Class Initialized
DEBUG - 2021-12-07 08:00:05 --> No URI present. Default controller set.
INFO - 2021-12-07 08:00:05 --> Router Class Initialized
INFO - 2021-12-07 08:00:05 --> Output Class Initialized
INFO - 2021-12-07 08:00:05 --> Security Class Initialized
DEBUG - 2021-12-07 08:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:00:05 --> Input Class Initialized
INFO - 2021-12-07 08:00:05 --> Language Class Initialized
INFO - 2021-12-07 08:00:05 --> Loader Class Initialized
INFO - 2021-12-07 08:00:05 --> Helper loaded: url_helper
INFO - 2021-12-07 08:00:05 --> Helper loaded: form_helper
INFO - 2021-12-07 08:00:05 --> Helper loaded: common_helper
INFO - 2021-12-07 08:00:05 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:00:05 --> Controller Class Initialized
INFO - 2021-12-07 08:00:05 --> Form Validation Class Initialized
DEBUG - 2021-12-07 08:00:05 --> Encrypt Class Initialized
DEBUG - 2021-12-07 08:00:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 08:00:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 08:00:05 --> Email Class Initialized
INFO - 2021-12-07 08:00:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 08:00:05 --> Calendar Class Initialized
INFO - 2021-12-07 08:00:05 --> Model "Login_model" initialized
INFO - 2021-12-07 08:00:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 08:00:05 --> Final output sent to browser
DEBUG - 2021-12-07 08:00:05 --> Total execution time: 0.0335
ERROR - 2021-12-07 08:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 08:46:30 --> Config Class Initialized
INFO - 2021-12-07 08:46:30 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:46:30 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:46:30 --> Utf8 Class Initialized
INFO - 2021-12-07 08:46:30 --> URI Class Initialized
DEBUG - 2021-12-07 08:46:30 --> No URI present. Default controller set.
INFO - 2021-12-07 08:46:30 --> Router Class Initialized
INFO - 2021-12-07 08:46:30 --> Output Class Initialized
INFO - 2021-12-07 08:46:30 --> Security Class Initialized
DEBUG - 2021-12-07 08:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:46:30 --> Input Class Initialized
INFO - 2021-12-07 08:46:30 --> Language Class Initialized
INFO - 2021-12-07 08:46:30 --> Loader Class Initialized
INFO - 2021-12-07 08:46:30 --> Helper loaded: url_helper
INFO - 2021-12-07 08:46:30 --> Helper loaded: form_helper
INFO - 2021-12-07 08:46:30 --> Helper loaded: common_helper
INFO - 2021-12-07 08:46:30 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:46:30 --> Controller Class Initialized
INFO - 2021-12-07 08:46:30 --> Form Validation Class Initialized
DEBUG - 2021-12-07 08:46:30 --> Encrypt Class Initialized
DEBUG - 2021-12-07 08:46:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 08:46:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 08:46:30 --> Email Class Initialized
INFO - 2021-12-07 08:46:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 08:46:30 --> Calendar Class Initialized
INFO - 2021-12-07 08:46:30 --> Model "Login_model" initialized
INFO - 2021-12-07 08:46:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 08:46:30 --> Final output sent to browser
DEBUG - 2021-12-07 08:46:30 --> Total execution time: 0.0249
ERROR - 2021-12-07 09:18:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 09:18:45 --> Config Class Initialized
INFO - 2021-12-07 09:18:45 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:18:45 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:18:45 --> Utf8 Class Initialized
INFO - 2021-12-07 09:18:45 --> URI Class Initialized
DEBUG - 2021-12-07 09:18:45 --> No URI present. Default controller set.
INFO - 2021-12-07 09:18:45 --> Router Class Initialized
INFO - 2021-12-07 09:18:45 --> Output Class Initialized
INFO - 2021-12-07 09:18:45 --> Security Class Initialized
DEBUG - 2021-12-07 09:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:18:45 --> Input Class Initialized
INFO - 2021-12-07 09:18:45 --> Language Class Initialized
INFO - 2021-12-07 09:18:45 --> Loader Class Initialized
INFO - 2021-12-07 09:18:45 --> Helper loaded: url_helper
INFO - 2021-12-07 09:18:45 --> Helper loaded: form_helper
INFO - 2021-12-07 09:18:45 --> Helper loaded: common_helper
INFO - 2021-12-07 09:18:45 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:18:45 --> Controller Class Initialized
INFO - 2021-12-07 09:18:45 --> Form Validation Class Initialized
DEBUG - 2021-12-07 09:18:45 --> Encrypt Class Initialized
DEBUG - 2021-12-07 09:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 09:18:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 09:18:45 --> Email Class Initialized
INFO - 2021-12-07 09:18:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 09:18:45 --> Calendar Class Initialized
INFO - 2021-12-07 09:18:45 --> Model "Login_model" initialized
INFO - 2021-12-07 09:18:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 09:18:45 --> Final output sent to browser
DEBUG - 2021-12-07 09:18:45 --> Total execution time: 0.0242
ERROR - 2021-12-07 09:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 09:24:17 --> Config Class Initialized
INFO - 2021-12-07 09:24:17 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:24:17 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:24:17 --> Utf8 Class Initialized
INFO - 2021-12-07 09:24:17 --> URI Class Initialized
DEBUG - 2021-12-07 09:24:17 --> No URI present. Default controller set.
INFO - 2021-12-07 09:24:17 --> Router Class Initialized
INFO - 2021-12-07 09:24:17 --> Output Class Initialized
INFO - 2021-12-07 09:24:17 --> Security Class Initialized
DEBUG - 2021-12-07 09:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:24:17 --> Input Class Initialized
INFO - 2021-12-07 09:24:17 --> Language Class Initialized
INFO - 2021-12-07 09:24:17 --> Loader Class Initialized
INFO - 2021-12-07 09:24:17 --> Helper loaded: url_helper
INFO - 2021-12-07 09:24:17 --> Helper loaded: form_helper
INFO - 2021-12-07 09:24:17 --> Helper loaded: common_helper
INFO - 2021-12-07 09:24:17 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:24:17 --> Controller Class Initialized
INFO - 2021-12-07 09:24:17 --> Form Validation Class Initialized
DEBUG - 2021-12-07 09:24:17 --> Encrypt Class Initialized
DEBUG - 2021-12-07 09:24:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 09:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 09:24:17 --> Email Class Initialized
INFO - 2021-12-07 09:24:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 09:24:17 --> Calendar Class Initialized
INFO - 2021-12-07 09:24:17 --> Model "Login_model" initialized
INFO - 2021-12-07 09:24:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 09:24:17 --> Final output sent to browser
DEBUG - 2021-12-07 09:24:17 --> Total execution time: 0.0376
ERROR - 2021-12-07 10:48:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 10:48:38 --> Config Class Initialized
INFO - 2021-12-07 10:48:38 --> Hooks Class Initialized
DEBUG - 2021-12-07 10:48:38 --> UTF-8 Support Enabled
INFO - 2021-12-07 10:48:38 --> Utf8 Class Initialized
INFO - 2021-12-07 10:48:38 --> URI Class Initialized
DEBUG - 2021-12-07 10:48:38 --> No URI present. Default controller set.
INFO - 2021-12-07 10:48:38 --> Router Class Initialized
INFO - 2021-12-07 10:48:38 --> Output Class Initialized
INFO - 2021-12-07 10:48:38 --> Security Class Initialized
DEBUG - 2021-12-07 10:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 10:48:38 --> Input Class Initialized
INFO - 2021-12-07 10:48:38 --> Language Class Initialized
INFO - 2021-12-07 10:48:38 --> Loader Class Initialized
INFO - 2021-12-07 10:48:38 --> Helper loaded: url_helper
INFO - 2021-12-07 10:48:38 --> Helper loaded: form_helper
INFO - 2021-12-07 10:48:38 --> Helper loaded: common_helper
INFO - 2021-12-07 10:48:38 --> Database Driver Class Initialized
DEBUG - 2021-12-07 10:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 10:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 10:48:38 --> Controller Class Initialized
INFO - 2021-12-07 10:48:38 --> Form Validation Class Initialized
DEBUG - 2021-12-07 10:48:38 --> Encrypt Class Initialized
DEBUG - 2021-12-07 10:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 10:48:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 10:48:38 --> Email Class Initialized
INFO - 2021-12-07 10:48:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 10:48:38 --> Calendar Class Initialized
INFO - 2021-12-07 10:48:38 --> Model "Login_model" initialized
INFO - 2021-12-07 10:48:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 10:48:38 --> Final output sent to browser
DEBUG - 2021-12-07 10:48:38 --> Total execution time: 0.0315
ERROR - 2021-12-07 10:52:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 10:52:51 --> Config Class Initialized
INFO - 2021-12-07 10:52:51 --> Hooks Class Initialized
DEBUG - 2021-12-07 10:52:51 --> UTF-8 Support Enabled
INFO - 2021-12-07 10:52:51 --> Utf8 Class Initialized
INFO - 2021-12-07 10:52:51 --> URI Class Initialized
DEBUG - 2021-12-07 10:52:51 --> No URI present. Default controller set.
INFO - 2021-12-07 10:52:51 --> Router Class Initialized
INFO - 2021-12-07 10:52:51 --> Output Class Initialized
INFO - 2021-12-07 10:52:51 --> Security Class Initialized
DEBUG - 2021-12-07 10:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 10:52:51 --> Input Class Initialized
INFO - 2021-12-07 10:52:51 --> Language Class Initialized
INFO - 2021-12-07 10:52:51 --> Loader Class Initialized
INFO - 2021-12-07 10:52:51 --> Helper loaded: url_helper
INFO - 2021-12-07 10:52:51 --> Helper loaded: form_helper
INFO - 2021-12-07 10:52:51 --> Helper loaded: common_helper
INFO - 2021-12-07 10:52:51 --> Database Driver Class Initialized
DEBUG - 2021-12-07 10:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 10:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 10:52:51 --> Controller Class Initialized
INFO - 2021-12-07 10:52:51 --> Form Validation Class Initialized
DEBUG - 2021-12-07 10:52:51 --> Encrypt Class Initialized
DEBUG - 2021-12-07 10:52:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 10:52:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 10:52:51 --> Email Class Initialized
INFO - 2021-12-07 10:52:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 10:52:51 --> Calendar Class Initialized
INFO - 2021-12-07 10:52:51 --> Model "Login_model" initialized
INFO - 2021-12-07 10:52:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 10:52:51 --> Final output sent to browser
DEBUG - 2021-12-07 10:52:51 --> Total execution time: 0.0242
ERROR - 2021-12-07 11:08:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 11:08:20 --> Config Class Initialized
INFO - 2021-12-07 11:08:20 --> Hooks Class Initialized
DEBUG - 2021-12-07 11:08:20 --> UTF-8 Support Enabled
INFO - 2021-12-07 11:08:20 --> Utf8 Class Initialized
INFO - 2021-12-07 11:08:20 --> URI Class Initialized
DEBUG - 2021-12-07 11:08:20 --> No URI present. Default controller set.
INFO - 2021-12-07 11:08:20 --> Router Class Initialized
INFO - 2021-12-07 11:08:20 --> Output Class Initialized
INFO - 2021-12-07 11:08:20 --> Security Class Initialized
DEBUG - 2021-12-07 11:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 11:08:20 --> Input Class Initialized
INFO - 2021-12-07 11:08:20 --> Language Class Initialized
INFO - 2021-12-07 11:08:20 --> Loader Class Initialized
INFO - 2021-12-07 11:08:20 --> Helper loaded: url_helper
INFO - 2021-12-07 11:08:20 --> Helper loaded: form_helper
INFO - 2021-12-07 11:08:20 --> Helper loaded: common_helper
INFO - 2021-12-07 11:08:20 --> Database Driver Class Initialized
DEBUG - 2021-12-07 11:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 11:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 11:08:20 --> Controller Class Initialized
INFO - 2021-12-07 11:08:20 --> Form Validation Class Initialized
DEBUG - 2021-12-07 11:08:20 --> Encrypt Class Initialized
DEBUG - 2021-12-07 11:08:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 11:08:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 11:08:20 --> Email Class Initialized
INFO - 2021-12-07 11:08:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 11:08:20 --> Calendar Class Initialized
INFO - 2021-12-07 11:08:20 --> Model "Login_model" initialized
INFO - 2021-12-07 11:08:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 11:08:20 --> Final output sent to browser
DEBUG - 2021-12-07 11:08:20 --> Total execution time: 0.0243
ERROR - 2021-12-07 11:32:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 11:32:14 --> Config Class Initialized
INFO - 2021-12-07 11:32:14 --> Hooks Class Initialized
DEBUG - 2021-12-07 11:32:14 --> UTF-8 Support Enabled
INFO - 2021-12-07 11:32:14 --> Utf8 Class Initialized
INFO - 2021-12-07 11:32:14 --> URI Class Initialized
DEBUG - 2021-12-07 11:32:14 --> No URI present. Default controller set.
INFO - 2021-12-07 11:32:14 --> Router Class Initialized
INFO - 2021-12-07 11:32:14 --> Output Class Initialized
INFO - 2021-12-07 11:32:14 --> Security Class Initialized
DEBUG - 2021-12-07 11:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 11:32:14 --> Input Class Initialized
INFO - 2021-12-07 11:32:14 --> Language Class Initialized
INFO - 2021-12-07 11:32:14 --> Loader Class Initialized
INFO - 2021-12-07 11:32:14 --> Helper loaded: url_helper
INFO - 2021-12-07 11:32:14 --> Helper loaded: form_helper
INFO - 2021-12-07 11:32:14 --> Helper loaded: common_helper
INFO - 2021-12-07 11:32:14 --> Database Driver Class Initialized
DEBUG - 2021-12-07 11:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 11:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 11:32:14 --> Controller Class Initialized
INFO - 2021-12-07 11:32:14 --> Form Validation Class Initialized
DEBUG - 2021-12-07 11:32:14 --> Encrypt Class Initialized
DEBUG - 2021-12-07 11:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 11:32:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 11:32:14 --> Email Class Initialized
INFO - 2021-12-07 11:32:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 11:32:14 --> Calendar Class Initialized
INFO - 2021-12-07 11:32:14 --> Model "Login_model" initialized
INFO - 2021-12-07 11:32:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 11:32:14 --> Final output sent to browser
DEBUG - 2021-12-07 11:32:14 --> Total execution time: 0.0289
ERROR - 2021-12-07 14:19:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 14:19:34 --> Config Class Initialized
INFO - 2021-12-07 14:19:34 --> Hooks Class Initialized
DEBUG - 2021-12-07 14:19:34 --> UTF-8 Support Enabled
INFO - 2021-12-07 14:19:34 --> Utf8 Class Initialized
INFO - 2021-12-07 14:19:34 --> URI Class Initialized
DEBUG - 2021-12-07 14:19:34 --> No URI present. Default controller set.
INFO - 2021-12-07 14:19:34 --> Router Class Initialized
INFO - 2021-12-07 14:19:34 --> Output Class Initialized
INFO - 2021-12-07 14:19:34 --> Security Class Initialized
DEBUG - 2021-12-07 14:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 14:19:34 --> Input Class Initialized
INFO - 2021-12-07 14:19:34 --> Language Class Initialized
INFO - 2021-12-07 14:19:34 --> Loader Class Initialized
INFO - 2021-12-07 14:19:34 --> Helper loaded: url_helper
INFO - 2021-12-07 14:19:34 --> Helper loaded: form_helper
INFO - 2021-12-07 14:19:34 --> Helper loaded: common_helper
INFO - 2021-12-07 14:19:34 --> Database Driver Class Initialized
DEBUG - 2021-12-07 14:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 14:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 14:19:34 --> Controller Class Initialized
INFO - 2021-12-07 14:19:34 --> Form Validation Class Initialized
DEBUG - 2021-12-07 14:19:34 --> Encrypt Class Initialized
DEBUG - 2021-12-07 14:19:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 14:19:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 14:19:34 --> Email Class Initialized
INFO - 2021-12-07 14:19:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 14:19:34 --> Calendar Class Initialized
INFO - 2021-12-07 14:19:34 --> Model "Login_model" initialized
INFO - 2021-12-07 14:19:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 14:19:34 --> Final output sent to browser
DEBUG - 2021-12-07 14:19:34 --> Total execution time: 0.0325
ERROR - 2021-12-07 14:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 14:19:36 --> Config Class Initialized
INFO - 2021-12-07 14:19:36 --> Hooks Class Initialized
DEBUG - 2021-12-07 14:19:36 --> UTF-8 Support Enabled
INFO - 2021-12-07 14:19:36 --> Utf8 Class Initialized
INFO - 2021-12-07 14:19:36 --> URI Class Initialized
INFO - 2021-12-07 14:19:36 --> Router Class Initialized
INFO - 2021-12-07 14:19:36 --> Output Class Initialized
INFO - 2021-12-07 14:19:36 --> Security Class Initialized
DEBUG - 2021-12-07 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 14:19:36 --> Input Class Initialized
INFO - 2021-12-07 14:19:36 --> Language Class Initialized
ERROR - 2021-12-07 14:19:36 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-07 14:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 14:19:50 --> Config Class Initialized
INFO - 2021-12-07 14:19:50 --> Hooks Class Initialized
DEBUG - 2021-12-07 14:19:50 --> UTF-8 Support Enabled
INFO - 2021-12-07 14:19:50 --> Utf8 Class Initialized
INFO - 2021-12-07 14:19:50 --> URI Class Initialized
INFO - 2021-12-07 14:19:50 --> Router Class Initialized
INFO - 2021-12-07 14:19:50 --> Output Class Initialized
INFO - 2021-12-07 14:19:50 --> Security Class Initialized
DEBUG - 2021-12-07 14:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 14:19:50 --> Input Class Initialized
INFO - 2021-12-07 14:19:50 --> Language Class Initialized
INFO - 2021-12-07 14:19:50 --> Loader Class Initialized
INFO - 2021-12-07 14:19:50 --> Helper loaded: url_helper
INFO - 2021-12-07 14:19:50 --> Helper loaded: form_helper
INFO - 2021-12-07 14:19:50 --> Helper loaded: common_helper
INFO - 2021-12-07 14:19:50 --> Database Driver Class Initialized
DEBUG - 2021-12-07 14:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 14:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 14:19:50 --> Controller Class Initialized
INFO - 2021-12-07 14:19:50 --> Form Validation Class Initialized
DEBUG - 2021-12-07 14:19:50 --> Encrypt Class Initialized
DEBUG - 2021-12-07 14:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 14:19:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 14:19:50 --> Email Class Initialized
INFO - 2021-12-07 14:19:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 14:19:50 --> Calendar Class Initialized
INFO - 2021-12-07 14:19:50 --> Model "Login_model" initialized
ERROR - 2021-12-07 14:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 14:19:50 --> Config Class Initialized
INFO - 2021-12-07 14:19:50 --> Hooks Class Initialized
DEBUG - 2021-12-07 14:19:50 --> UTF-8 Support Enabled
INFO - 2021-12-07 14:19:50 --> Utf8 Class Initialized
INFO - 2021-12-07 14:19:50 --> URI Class Initialized
INFO - 2021-12-07 14:19:50 --> Router Class Initialized
INFO - 2021-12-07 14:19:50 --> Output Class Initialized
INFO - 2021-12-07 14:19:50 --> Security Class Initialized
DEBUG - 2021-12-07 14:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 14:19:50 --> Input Class Initialized
INFO - 2021-12-07 14:19:50 --> Language Class Initialized
INFO - 2021-12-07 14:19:50 --> Loader Class Initialized
INFO - 2021-12-07 14:19:50 --> Helper loaded: url_helper
INFO - 2021-12-07 14:19:50 --> Helper loaded: form_helper
INFO - 2021-12-07 14:19:50 --> Helper loaded: common_helper
INFO - 2021-12-07 14:19:51 --> Database Driver Class Initialized
DEBUG - 2021-12-07 14:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 14:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 14:19:51 --> Controller Class Initialized
INFO - 2021-12-07 14:19:51 --> Form Validation Class Initialized
DEBUG - 2021-12-07 14:19:51 --> Encrypt Class Initialized
DEBUG - 2021-12-07 14:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 14:19:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 14:19:51 --> Email Class Initialized
INFO - 2021-12-07 14:19:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 14:19:51 --> Calendar Class Initialized
INFO - 2021-12-07 14:19:51 --> Model "Login_model" initialized
ERROR - 2021-12-07 14:19:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 14:19:51 --> Config Class Initialized
INFO - 2021-12-07 14:19:51 --> Hooks Class Initialized
DEBUG - 2021-12-07 14:19:51 --> UTF-8 Support Enabled
INFO - 2021-12-07 14:19:51 --> Utf8 Class Initialized
INFO - 2021-12-07 14:19:51 --> URI Class Initialized
DEBUG - 2021-12-07 14:19:51 --> No URI present. Default controller set.
INFO - 2021-12-07 14:19:51 --> Router Class Initialized
INFO - 2021-12-07 14:19:51 --> Output Class Initialized
INFO - 2021-12-07 14:19:51 --> Security Class Initialized
DEBUG - 2021-12-07 14:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 14:19:51 --> Input Class Initialized
INFO - 2021-12-07 14:19:51 --> Language Class Initialized
INFO - 2021-12-07 14:19:51 --> Loader Class Initialized
INFO - 2021-12-07 14:19:51 --> Helper loaded: url_helper
INFO - 2021-12-07 14:19:51 --> Helper loaded: form_helper
INFO - 2021-12-07 14:19:51 --> Helper loaded: common_helper
INFO - 2021-12-07 14:19:51 --> Database Driver Class Initialized
DEBUG - 2021-12-07 14:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 14:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 14:19:51 --> Controller Class Initialized
INFO - 2021-12-07 14:19:51 --> Form Validation Class Initialized
DEBUG - 2021-12-07 14:19:51 --> Encrypt Class Initialized
DEBUG - 2021-12-07 14:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 14:19:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 14:19:51 --> Email Class Initialized
INFO - 2021-12-07 14:19:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 14:19:51 --> Calendar Class Initialized
INFO - 2021-12-07 14:19:51 --> Model "Login_model" initialized
INFO - 2021-12-07 14:19:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 14:19:51 --> Final output sent to browser
DEBUG - 2021-12-07 14:19:51 --> Total execution time: 0.0226
ERROR - 2021-12-07 14:19:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 14:19:52 --> Config Class Initialized
INFO - 2021-12-07 14:19:52 --> Hooks Class Initialized
DEBUG - 2021-12-07 14:19:52 --> UTF-8 Support Enabled
INFO - 2021-12-07 14:19:52 --> Utf8 Class Initialized
INFO - 2021-12-07 14:19:52 --> URI Class Initialized
INFO - 2021-12-07 14:19:52 --> Router Class Initialized
INFO - 2021-12-07 14:19:52 --> Output Class Initialized
INFO - 2021-12-07 14:19:52 --> Security Class Initialized
DEBUG - 2021-12-07 14:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 14:19:52 --> Input Class Initialized
INFO - 2021-12-07 14:19:52 --> Language Class Initialized
INFO - 2021-12-07 14:19:52 --> Loader Class Initialized
INFO - 2021-12-07 14:19:52 --> Helper loaded: url_helper
INFO - 2021-12-07 14:19:52 --> Helper loaded: form_helper
INFO - 2021-12-07 14:19:52 --> Helper loaded: common_helper
INFO - 2021-12-07 14:19:52 --> Database Driver Class Initialized
DEBUG - 2021-12-07 14:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 14:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 14:19:52 --> Controller Class Initialized
INFO - 2021-12-07 14:19:52 --> Form Validation Class Initialized
DEBUG - 2021-12-07 14:19:52 --> Encrypt Class Initialized
DEBUG - 2021-12-07 14:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 14:19:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 14:19:52 --> Email Class Initialized
INFO - 2021-12-07 14:19:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 14:19:52 --> Calendar Class Initialized
INFO - 2021-12-07 14:19:52 --> Model "Login_model" initialized
INFO - 2021-12-07 14:19:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 14:19:52 --> Final output sent to browser
DEBUG - 2021-12-07 14:19:52 --> Total execution time: 0.0224
ERROR - 2021-12-07 15:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 15:32:36 --> Config Class Initialized
INFO - 2021-12-07 15:32:36 --> Hooks Class Initialized
DEBUG - 2021-12-07 15:32:36 --> UTF-8 Support Enabled
INFO - 2021-12-07 15:32:36 --> Utf8 Class Initialized
INFO - 2021-12-07 15:32:36 --> URI Class Initialized
DEBUG - 2021-12-07 15:32:36 --> No URI present. Default controller set.
INFO - 2021-12-07 15:32:36 --> Router Class Initialized
INFO - 2021-12-07 15:32:36 --> Output Class Initialized
INFO - 2021-12-07 15:32:36 --> Security Class Initialized
DEBUG - 2021-12-07 15:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 15:32:36 --> Input Class Initialized
INFO - 2021-12-07 15:32:36 --> Language Class Initialized
INFO - 2021-12-07 15:32:36 --> Loader Class Initialized
INFO - 2021-12-07 15:32:36 --> Helper loaded: url_helper
INFO - 2021-12-07 15:32:36 --> Helper loaded: form_helper
INFO - 2021-12-07 15:32:36 --> Helper loaded: common_helper
INFO - 2021-12-07 15:32:36 --> Database Driver Class Initialized
DEBUG - 2021-12-07 15:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 15:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 15:32:36 --> Controller Class Initialized
INFO - 2021-12-07 15:32:36 --> Form Validation Class Initialized
DEBUG - 2021-12-07 15:32:36 --> Encrypt Class Initialized
DEBUG - 2021-12-07 15:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 15:32:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 15:32:36 --> Email Class Initialized
INFO - 2021-12-07 15:32:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 15:32:36 --> Calendar Class Initialized
INFO - 2021-12-07 15:32:36 --> Model "Login_model" initialized
INFO - 2021-12-07 15:32:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 15:32:36 --> Final output sent to browser
DEBUG - 2021-12-07 15:32:36 --> Total execution time: 0.0244
ERROR - 2021-12-07 18:21:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 18:21:04 --> Config Class Initialized
INFO - 2021-12-07 18:21:04 --> Hooks Class Initialized
DEBUG - 2021-12-07 18:21:04 --> UTF-8 Support Enabled
INFO - 2021-12-07 18:21:04 --> Utf8 Class Initialized
INFO - 2021-12-07 18:21:04 --> URI Class Initialized
DEBUG - 2021-12-07 18:21:04 --> No URI present. Default controller set.
INFO - 2021-12-07 18:21:04 --> Router Class Initialized
INFO - 2021-12-07 18:21:04 --> Output Class Initialized
INFO - 2021-12-07 18:21:04 --> Security Class Initialized
DEBUG - 2021-12-07 18:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 18:21:04 --> Input Class Initialized
INFO - 2021-12-07 18:21:04 --> Language Class Initialized
INFO - 2021-12-07 18:21:04 --> Loader Class Initialized
INFO - 2021-12-07 18:21:04 --> Helper loaded: url_helper
INFO - 2021-12-07 18:21:04 --> Helper loaded: form_helper
INFO - 2021-12-07 18:21:04 --> Helper loaded: common_helper
INFO - 2021-12-07 18:21:04 --> Database Driver Class Initialized
DEBUG - 2021-12-07 18:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 18:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 18:21:04 --> Controller Class Initialized
INFO - 2021-12-07 18:21:04 --> Form Validation Class Initialized
DEBUG - 2021-12-07 18:21:04 --> Encrypt Class Initialized
DEBUG - 2021-12-07 18:21:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 18:21:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 18:21:04 --> Email Class Initialized
INFO - 2021-12-07 18:21:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 18:21:04 --> Calendar Class Initialized
INFO - 2021-12-07 18:21:04 --> Model "Login_model" initialized
INFO - 2021-12-07 18:21:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 18:21:04 --> Final output sent to browser
DEBUG - 2021-12-07 18:21:04 --> Total execution time: 0.0231
ERROR - 2021-12-07 22:44:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-07 22:44:20 --> Config Class Initialized
INFO - 2021-12-07 22:44:20 --> Hooks Class Initialized
DEBUG - 2021-12-07 22:44:20 --> UTF-8 Support Enabled
INFO - 2021-12-07 22:44:20 --> Utf8 Class Initialized
INFO - 2021-12-07 22:44:20 --> URI Class Initialized
DEBUG - 2021-12-07 22:44:20 --> No URI present. Default controller set.
INFO - 2021-12-07 22:44:20 --> Router Class Initialized
INFO - 2021-12-07 22:44:20 --> Output Class Initialized
INFO - 2021-12-07 22:44:20 --> Security Class Initialized
DEBUG - 2021-12-07 22:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 22:44:20 --> Input Class Initialized
INFO - 2021-12-07 22:44:20 --> Language Class Initialized
INFO - 2021-12-07 22:44:20 --> Loader Class Initialized
INFO - 2021-12-07 22:44:20 --> Helper loaded: url_helper
INFO - 2021-12-07 22:44:20 --> Helper loaded: form_helper
INFO - 2021-12-07 22:44:20 --> Helper loaded: common_helper
INFO - 2021-12-07 22:44:20 --> Database Driver Class Initialized
DEBUG - 2021-12-07 22:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 22:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 22:44:20 --> Controller Class Initialized
INFO - 2021-12-07 22:44:20 --> Form Validation Class Initialized
DEBUG - 2021-12-07 22:44:20 --> Encrypt Class Initialized
DEBUG - 2021-12-07 22:44:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-07 22:44:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-07 22:44:20 --> Email Class Initialized
INFO - 2021-12-07 22:44:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-07 22:44:20 --> Calendar Class Initialized
INFO - 2021-12-07 22:44:20 --> Model "Login_model" initialized
INFO - 2021-12-07 22:44:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-07 22:44:20 --> Final output sent to browser
DEBUG - 2021-12-07 22:44:20 --> Total execution time: 0.0268
