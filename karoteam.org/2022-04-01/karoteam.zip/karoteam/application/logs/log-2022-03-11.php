<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-11 00:00:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:00:16 --> Config Class Initialized
INFO - 2022-03-11 00:00:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:00:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:00:16 --> Utf8 Class Initialized
INFO - 2022-03-11 00:00:16 --> URI Class Initialized
INFO - 2022-03-11 00:00:16 --> Router Class Initialized
INFO - 2022-03-11 00:00:16 --> Output Class Initialized
INFO - 2022-03-11 00:00:16 --> Security Class Initialized
DEBUG - 2022-03-11 00:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:00:16 --> Input Class Initialized
INFO - 2022-03-11 00:00:16 --> Language Class Initialized
INFO - 2022-03-11 00:00:16 --> Loader Class Initialized
INFO - 2022-03-11 00:00:16 --> Helper loaded: url_helper
INFO - 2022-03-11 00:00:16 --> Helper loaded: form_helper
INFO - 2022-03-11 00:00:16 --> Helper loaded: common_helper
INFO - 2022-03-11 00:00:16 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:00:16 --> Controller Class Initialized
INFO - 2022-03-11 00:00:16 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:00:16 --> Encrypt Class Initialized
DEBUG - 2022-03-11 00:00:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 00:00:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 00:00:16 --> Email Class Initialized
INFO - 2022-03-11 00:00:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 00:00:16 --> Calendar Class Initialized
INFO - 2022-03-11 00:00:16 --> Model "Login_model" initialized
INFO - 2022-03-11 00:00:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-11 00:00:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:00:17 --> Config Class Initialized
INFO - 2022-03-11 00:00:17 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:00:17 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:00:17 --> Utf8 Class Initialized
INFO - 2022-03-11 00:00:17 --> URI Class Initialized
INFO - 2022-03-11 00:00:17 --> Router Class Initialized
INFO - 2022-03-11 00:00:17 --> Output Class Initialized
INFO - 2022-03-11 00:00:17 --> Security Class Initialized
DEBUG - 2022-03-11 00:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:00:17 --> Input Class Initialized
INFO - 2022-03-11 00:00:17 --> Language Class Initialized
INFO - 2022-03-11 00:00:17 --> Loader Class Initialized
INFO - 2022-03-11 00:00:17 --> Helper loaded: url_helper
INFO - 2022-03-11 00:00:17 --> Helper loaded: form_helper
INFO - 2022-03-11 00:00:17 --> Helper loaded: common_helper
INFO - 2022-03-11 00:00:17 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:00:17 --> Controller Class Initialized
INFO - 2022-03-11 00:00:17 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:00:17 --> Encrypt Class Initialized
INFO - 2022-03-11 00:00:17 --> Model "Login_model" initialized
INFO - 2022-03-11 00:00:17 --> Model "Dashboard_model" initialized
INFO - 2022-03-11 00:00:17 --> Model "Case_model" initialized
INFO - 2022-03-11 00:00:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:00:43 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-11 00:00:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:00:43 --> Final output sent to browser
DEBUG - 2022-03-11 00:00:43 --> Total execution time: 26.4413
ERROR - 2022-03-11 00:00:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:00:44 --> Config Class Initialized
INFO - 2022-03-11 00:00:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:00:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:00:44 --> Utf8 Class Initialized
INFO - 2022-03-11 00:00:44 --> URI Class Initialized
INFO - 2022-03-11 00:00:44 --> Router Class Initialized
INFO - 2022-03-11 00:00:44 --> Output Class Initialized
INFO - 2022-03-11 00:00:44 --> Security Class Initialized
DEBUG - 2022-03-11 00:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:00:44 --> Input Class Initialized
INFO - 2022-03-11 00:00:44 --> Language Class Initialized
ERROR - 2022-03-11 00:00:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:01:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:01:05 --> Config Class Initialized
INFO - 2022-03-11 00:01:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:01:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:01:05 --> Utf8 Class Initialized
INFO - 2022-03-11 00:01:05 --> URI Class Initialized
INFO - 2022-03-11 00:01:05 --> Router Class Initialized
INFO - 2022-03-11 00:01:05 --> Output Class Initialized
INFO - 2022-03-11 00:01:05 --> Security Class Initialized
DEBUG - 2022-03-11 00:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:01:05 --> Input Class Initialized
INFO - 2022-03-11 00:01:05 --> Language Class Initialized
INFO - 2022-03-11 00:01:05 --> Loader Class Initialized
INFO - 2022-03-11 00:01:05 --> Helper loaded: url_helper
INFO - 2022-03-11 00:01:05 --> Helper loaded: form_helper
INFO - 2022-03-11 00:01:05 --> Helper loaded: common_helper
INFO - 2022-03-11 00:01:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:01:05 --> Controller Class Initialized
INFO - 2022-03-11 00:01:05 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:01:05 --> Encrypt Class Initialized
INFO - 2022-03-11 00:01:05 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:01:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:01:05 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:01:05 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:01:05 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:01:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:01:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:01:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 00:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:01:15 --> Config Class Initialized
INFO - 2022-03-11 00:01:15 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:01:15 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:01:15 --> Utf8 Class Initialized
INFO - 2022-03-11 00:01:15 --> URI Class Initialized
INFO - 2022-03-11 00:01:15 --> Router Class Initialized
INFO - 2022-03-11 00:01:15 --> Output Class Initialized
INFO - 2022-03-11 00:01:15 --> Security Class Initialized
DEBUG - 2022-03-11 00:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:01:15 --> Input Class Initialized
INFO - 2022-03-11 00:01:15 --> Language Class Initialized
INFO - 2022-03-11 00:01:15 --> Loader Class Initialized
INFO - 2022-03-11 00:01:15 --> Helper loaded: url_helper
INFO - 2022-03-11 00:01:15 --> Helper loaded: form_helper
INFO - 2022-03-11 00:01:15 --> Helper loaded: common_helper
INFO - 2022-03-11 00:01:15 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:01:15 --> Controller Class Initialized
INFO - 2022-03-11 00:01:15 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:01:15 --> Encrypt Class Initialized
INFO - 2022-03-11 00:01:15 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:01:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:01:15 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:01:15 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:01:15 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:01:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-11 00:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:01:16 --> Config Class Initialized
INFO - 2022-03-11 00:01:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:01:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:01:16 --> Utf8 Class Initialized
INFO - 2022-03-11 00:01:16 --> URI Class Initialized
INFO - 2022-03-11 00:01:16 --> Router Class Initialized
INFO - 2022-03-11 00:01:16 --> Output Class Initialized
INFO - 2022-03-11 00:01:16 --> Security Class Initialized
DEBUG - 2022-03-11 00:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:01:16 --> Input Class Initialized
INFO - 2022-03-11 00:01:16 --> Language Class Initialized
ERROR - 2022-03-11 00:01:16 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 00:01:16 --> Final output sent to browser
DEBUG - 2022-03-11 00:01:16 --> Total execution time: 9.5836
INFO - 2022-03-11 00:01:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:01:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:01:25 --> Final output sent to browser
DEBUG - 2022-03-11 00:01:25 --> Total execution time: 8.2666
ERROR - 2022-03-11 00:02:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:00 --> Config Class Initialized
INFO - 2022-03-11 00:02:00 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:00 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:00 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:00 --> URI Class Initialized
INFO - 2022-03-11 00:02:00 --> Router Class Initialized
INFO - 2022-03-11 00:02:00 --> Output Class Initialized
INFO - 2022-03-11 00:02:00 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:00 --> Input Class Initialized
INFO - 2022-03-11 00:02:00 --> Language Class Initialized
INFO - 2022-03-11 00:02:00 --> Loader Class Initialized
INFO - 2022-03-11 00:02:00 --> Helper loaded: url_helper
INFO - 2022-03-11 00:02:00 --> Helper loaded: form_helper
INFO - 2022-03-11 00:02:00 --> Helper loaded: common_helper
INFO - 2022-03-11 00:02:00 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:02:00 --> Controller Class Initialized
INFO - 2022-03-11 00:02:00 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:02:00 --> Encrypt Class Initialized
INFO - 2022-03-11 00:02:00 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:02:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:02:00 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:02:00 --> Model "Users_model" initialized
INFO - 2022-03-11 00:02:00 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:02:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:02:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:02:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:02:00 --> Final output sent to browser
DEBUG - 2022-03-11 00:02:00 --> Total execution time: 0.0823
ERROR - 2022-03-11 00:02:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:04 --> Config Class Initialized
INFO - 2022-03-11 00:02:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:04 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:04 --> URI Class Initialized
INFO - 2022-03-11 00:02:04 --> Router Class Initialized
INFO - 2022-03-11 00:02:04 --> Output Class Initialized
INFO - 2022-03-11 00:02:04 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:04 --> Input Class Initialized
INFO - 2022-03-11 00:02:04 --> Language Class Initialized
INFO - 2022-03-11 00:02:04 --> Loader Class Initialized
INFO - 2022-03-11 00:02:04 --> Helper loaded: url_helper
INFO - 2022-03-11 00:02:04 --> Helper loaded: form_helper
INFO - 2022-03-11 00:02:04 --> Helper loaded: common_helper
INFO - 2022-03-11 00:02:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:02:04 --> Controller Class Initialized
INFO - 2022-03-11 00:02:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:02:04 --> Encrypt Class Initialized
INFO - 2022-03-11 00:02:04 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:02:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:02:04 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:02:04 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:02:04 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:02:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:02:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:02:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:02:04 --> Final output sent to browser
DEBUG - 2022-03-11 00:02:04 --> Total execution time: 0.0521
ERROR - 2022-03-11 00:02:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:05 --> Config Class Initialized
INFO - 2022-03-11 00:02:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:05 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:05 --> URI Class Initialized
INFO - 2022-03-11 00:02:05 --> Router Class Initialized
INFO - 2022-03-11 00:02:05 --> Output Class Initialized
INFO - 2022-03-11 00:02:05 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:05 --> Input Class Initialized
INFO - 2022-03-11 00:02:05 --> Language Class Initialized
ERROR - 2022-03-11 00:02:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:02:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:05 --> Config Class Initialized
INFO - 2022-03-11 00:02:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:05 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:05 --> URI Class Initialized
INFO - 2022-03-11 00:02:05 --> Router Class Initialized
INFO - 2022-03-11 00:02:05 --> Output Class Initialized
INFO - 2022-03-11 00:02:05 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:05 --> Input Class Initialized
INFO - 2022-03-11 00:02:05 --> Language Class Initialized
ERROR - 2022-03-11 00:02:05 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 00:02:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:09 --> Config Class Initialized
INFO - 2022-03-11 00:02:09 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:09 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:09 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:09 --> URI Class Initialized
INFO - 2022-03-11 00:02:09 --> Router Class Initialized
INFO - 2022-03-11 00:02:09 --> Output Class Initialized
INFO - 2022-03-11 00:02:09 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:09 --> Input Class Initialized
INFO - 2022-03-11 00:02:09 --> Language Class Initialized
ERROR - 2022-03-11 00:02:09 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 00:02:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:20 --> Config Class Initialized
INFO - 2022-03-11 00:02:20 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:20 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:20 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:20 --> URI Class Initialized
INFO - 2022-03-11 00:02:20 --> Router Class Initialized
INFO - 2022-03-11 00:02:20 --> Output Class Initialized
INFO - 2022-03-11 00:02:20 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:20 --> Input Class Initialized
INFO - 2022-03-11 00:02:20 --> Language Class Initialized
INFO - 2022-03-11 00:02:20 --> Loader Class Initialized
INFO - 2022-03-11 00:02:20 --> Helper loaded: url_helper
INFO - 2022-03-11 00:02:20 --> Helper loaded: form_helper
INFO - 2022-03-11 00:02:20 --> Helper loaded: common_helper
INFO - 2022-03-11 00:02:20 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:02:20 --> Controller Class Initialized
INFO - 2022-03-11 00:02:20 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:02:20 --> Encrypt Class Initialized
INFO - 2022-03-11 00:02:20 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:02:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:02:20 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:02:20 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:02:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 00:02:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:21 --> Config Class Initialized
INFO - 2022-03-11 00:02:21 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:21 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:21 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:21 --> URI Class Initialized
INFO - 2022-03-11 00:02:21 --> Router Class Initialized
INFO - 2022-03-11 00:02:21 --> Output Class Initialized
INFO - 2022-03-11 00:02:21 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:21 --> Input Class Initialized
INFO - 2022-03-11 00:02:21 --> Language Class Initialized
INFO - 2022-03-11 00:02:21 --> Loader Class Initialized
INFO - 2022-03-11 00:02:21 --> Helper loaded: url_helper
INFO - 2022-03-11 00:02:21 --> Helper loaded: form_helper
INFO - 2022-03-11 00:02:21 --> Helper loaded: common_helper
INFO - 2022-03-11 00:02:21 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:02:21 --> Controller Class Initialized
INFO - 2022-03-11 00:02:21 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:02:21 --> Encrypt Class Initialized
INFO - 2022-03-11 00:02:21 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:02:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:02:21 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:02:21 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:02:21 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:02:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:02:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:02:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:02:21 --> Final output sent to browser
DEBUG - 2022-03-11 00:02:21 --> Total execution time: 0.0568
ERROR - 2022-03-11 00:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:22 --> Config Class Initialized
INFO - 2022-03-11 00:02:22 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:22 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:22 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:22 --> URI Class Initialized
INFO - 2022-03-11 00:02:22 --> Router Class Initialized
INFO - 2022-03-11 00:02:22 --> Output Class Initialized
INFO - 2022-03-11 00:02:22 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:22 --> Input Class Initialized
INFO - 2022-03-11 00:02:22 --> Language Class Initialized
ERROR - 2022-03-11 00:02:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:22 --> Config Class Initialized
INFO - 2022-03-11 00:02:22 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:22 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:22 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:22 --> URI Class Initialized
INFO - 2022-03-11 00:02:22 --> Router Class Initialized
INFO - 2022-03-11 00:02:22 --> Output Class Initialized
INFO - 2022-03-11 00:02:22 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:22 --> Input Class Initialized
INFO - 2022-03-11 00:02:22 --> Language Class Initialized
ERROR - 2022-03-11 00:02:22 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 00:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:22 --> Config Class Initialized
INFO - 2022-03-11 00:02:22 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:22 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:22 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:22 --> URI Class Initialized
INFO - 2022-03-11 00:02:22 --> Router Class Initialized
INFO - 2022-03-11 00:02:22 --> Output Class Initialized
INFO - 2022-03-11 00:02:22 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:22 --> Input Class Initialized
INFO - 2022-03-11 00:02:22 --> Language Class Initialized
INFO - 2022-03-11 00:02:22 --> Loader Class Initialized
INFO - 2022-03-11 00:02:22 --> Helper loaded: url_helper
INFO - 2022-03-11 00:02:22 --> Helper loaded: form_helper
INFO - 2022-03-11 00:02:22 --> Helper loaded: common_helper
INFO - 2022-03-11 00:02:22 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:02:22 --> Controller Class Initialized
INFO - 2022-03-11 00:02:22 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:02:22 --> Encrypt Class Initialized
INFO - 2022-03-11 00:02:22 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:02:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:02:22 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:02:22 --> Model "Users_model" initialized
INFO - 2022-03-11 00:02:22 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:02:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:02:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:02:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:02:22 --> Final output sent to browser
DEBUG - 2022-03-11 00:02:22 --> Total execution time: 0.0890
ERROR - 2022-03-11 00:02:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:23 --> Config Class Initialized
INFO - 2022-03-11 00:02:23 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:23 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:23 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:23 --> URI Class Initialized
INFO - 2022-03-11 00:02:23 --> Router Class Initialized
INFO - 2022-03-11 00:02:23 --> Output Class Initialized
INFO - 2022-03-11 00:02:23 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:23 --> Input Class Initialized
INFO - 2022-03-11 00:02:23 --> Language Class Initialized
ERROR - 2022-03-11 00:02:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:02:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:02:33 --> Config Class Initialized
INFO - 2022-03-11 00:02:33 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:02:33 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:02:33 --> Utf8 Class Initialized
INFO - 2022-03-11 00:02:33 --> URI Class Initialized
INFO - 2022-03-11 00:02:33 --> Router Class Initialized
INFO - 2022-03-11 00:02:33 --> Output Class Initialized
INFO - 2022-03-11 00:02:33 --> Security Class Initialized
DEBUG - 2022-03-11 00:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:02:33 --> Input Class Initialized
INFO - 2022-03-11 00:02:33 --> Language Class Initialized
ERROR - 2022-03-11 00:02:33 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 00:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:03:59 --> Config Class Initialized
INFO - 2022-03-11 00:03:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:03:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:03:59 --> Utf8 Class Initialized
INFO - 2022-03-11 00:03:59 --> URI Class Initialized
INFO - 2022-03-11 00:03:59 --> Router Class Initialized
INFO - 2022-03-11 00:03:59 --> Output Class Initialized
INFO - 2022-03-11 00:03:59 --> Security Class Initialized
DEBUG - 2022-03-11 00:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:03:59 --> Input Class Initialized
INFO - 2022-03-11 00:03:59 --> Language Class Initialized
INFO - 2022-03-11 00:03:59 --> Loader Class Initialized
INFO - 2022-03-11 00:03:59 --> Helper loaded: url_helper
INFO - 2022-03-11 00:03:59 --> Helper loaded: form_helper
INFO - 2022-03-11 00:03:59 --> Helper loaded: common_helper
INFO - 2022-03-11 00:03:59 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:03:59 --> Controller Class Initialized
INFO - 2022-03-11 00:03:59 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:03:59 --> Encrypt Class Initialized
INFO - 2022-03-11 00:03:59 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:03:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:03:59 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:03:59 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:03:59 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:03:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:04:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:04:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:04:08 --> Final output sent to browser
DEBUG - 2022-03-11 00:04:08 --> Total execution time: 7.9239
ERROR - 2022-03-11 00:06:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:06:49 --> Config Class Initialized
INFO - 2022-03-11 00:06:49 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:06:49 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:06:49 --> Utf8 Class Initialized
INFO - 2022-03-11 00:06:49 --> URI Class Initialized
INFO - 2022-03-11 00:06:49 --> Router Class Initialized
INFO - 2022-03-11 00:06:49 --> Output Class Initialized
INFO - 2022-03-11 00:06:49 --> Security Class Initialized
DEBUG - 2022-03-11 00:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:06:49 --> Input Class Initialized
INFO - 2022-03-11 00:06:49 --> Language Class Initialized
INFO - 2022-03-11 00:06:49 --> Loader Class Initialized
INFO - 2022-03-11 00:06:49 --> Helper loaded: url_helper
INFO - 2022-03-11 00:06:49 --> Helper loaded: form_helper
INFO - 2022-03-11 00:06:49 --> Helper loaded: common_helper
INFO - 2022-03-11 00:06:49 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:06:49 --> Controller Class Initialized
INFO - 2022-03-11 00:06:49 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:06:49 --> Encrypt Class Initialized
INFO - 2022-03-11 00:06:49 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:06:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:06:49 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:06:49 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:06:49 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:06:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:06:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:06:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 00:06:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:06:59 --> Config Class Initialized
INFO - 2022-03-11 00:06:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:06:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:06:59 --> Utf8 Class Initialized
INFO - 2022-03-11 00:06:59 --> URI Class Initialized
INFO - 2022-03-11 00:06:59 --> Router Class Initialized
INFO - 2022-03-11 00:06:59 --> Output Class Initialized
INFO - 2022-03-11 00:06:59 --> Security Class Initialized
DEBUG - 2022-03-11 00:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:06:59 --> Input Class Initialized
INFO - 2022-03-11 00:06:59 --> Language Class Initialized
ERROR - 2022-03-11 00:06:59 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 00:06:59 --> Final output sent to browser
DEBUG - 2022-03-11 00:06:59 --> Total execution time: 8.7333
ERROR - 2022-03-11 00:07:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:07:26 --> Config Class Initialized
INFO - 2022-03-11 00:07:26 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:07:26 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:07:26 --> Utf8 Class Initialized
INFO - 2022-03-11 00:07:26 --> URI Class Initialized
INFO - 2022-03-11 00:07:26 --> Router Class Initialized
INFO - 2022-03-11 00:07:26 --> Output Class Initialized
INFO - 2022-03-11 00:07:26 --> Security Class Initialized
DEBUG - 2022-03-11 00:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:07:26 --> Input Class Initialized
INFO - 2022-03-11 00:07:26 --> Language Class Initialized
INFO - 2022-03-11 00:07:26 --> Loader Class Initialized
INFO - 2022-03-11 00:07:26 --> Helper loaded: url_helper
INFO - 2022-03-11 00:07:26 --> Helper loaded: form_helper
INFO - 2022-03-11 00:07:26 --> Helper loaded: common_helper
INFO - 2022-03-11 00:07:26 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:07:26 --> Controller Class Initialized
INFO - 2022-03-11 00:07:26 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:07:26 --> Encrypt Class Initialized
INFO - 2022-03-11 00:07:26 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:07:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:07:26 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:07:26 --> Model "Users_model" initialized
INFO - 2022-03-11 00:07:26 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:07:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:07:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:07:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:07:26 --> Final output sent to browser
DEBUG - 2022-03-11 00:07:26 --> Total execution time: 0.0737
ERROR - 2022-03-11 00:07:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:07:26 --> Config Class Initialized
INFO - 2022-03-11 00:07:26 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:07:26 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:07:26 --> Utf8 Class Initialized
INFO - 2022-03-11 00:07:26 --> URI Class Initialized
INFO - 2022-03-11 00:07:26 --> Router Class Initialized
INFO - 2022-03-11 00:07:26 --> Output Class Initialized
INFO - 2022-03-11 00:07:26 --> Security Class Initialized
DEBUG - 2022-03-11 00:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:07:26 --> Input Class Initialized
INFO - 2022-03-11 00:07:26 --> Language Class Initialized
ERROR - 2022-03-11 00:07:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:08:16 --> Config Class Initialized
INFO - 2022-03-11 00:08:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:08:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:08:16 --> Utf8 Class Initialized
INFO - 2022-03-11 00:08:16 --> URI Class Initialized
INFO - 2022-03-11 00:08:16 --> Router Class Initialized
INFO - 2022-03-11 00:08:16 --> Output Class Initialized
INFO - 2022-03-11 00:08:16 --> Security Class Initialized
DEBUG - 2022-03-11 00:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:08:16 --> Input Class Initialized
INFO - 2022-03-11 00:08:16 --> Language Class Initialized
INFO - 2022-03-11 00:08:16 --> Loader Class Initialized
INFO - 2022-03-11 00:08:16 --> Helper loaded: url_helper
INFO - 2022-03-11 00:08:16 --> Helper loaded: form_helper
INFO - 2022-03-11 00:08:16 --> Helper loaded: common_helper
INFO - 2022-03-11 00:08:16 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:08:16 --> Controller Class Initialized
INFO - 2022-03-11 00:08:16 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:08:16 --> Encrypt Class Initialized
INFO - 2022-03-11 00:08:16 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:08:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:08:16 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:08:16 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:08:16 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:08:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:08:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:08:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:08:28 --> Final output sent to browser
DEBUG - 2022-03-11 00:08:28 --> Total execution time: 9.5766
ERROR - 2022-03-11 00:09:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:09:04 --> Config Class Initialized
INFO - 2022-03-11 00:09:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:09:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:09:04 --> Utf8 Class Initialized
INFO - 2022-03-11 00:09:04 --> URI Class Initialized
INFO - 2022-03-11 00:09:04 --> Router Class Initialized
INFO - 2022-03-11 00:09:04 --> Output Class Initialized
INFO - 2022-03-11 00:09:04 --> Security Class Initialized
DEBUG - 2022-03-11 00:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:09:04 --> Input Class Initialized
INFO - 2022-03-11 00:09:04 --> Language Class Initialized
INFO - 2022-03-11 00:09:04 --> Loader Class Initialized
INFO - 2022-03-11 00:09:04 --> Helper loaded: url_helper
INFO - 2022-03-11 00:09:04 --> Helper loaded: form_helper
INFO - 2022-03-11 00:09:04 --> Helper loaded: common_helper
INFO - 2022-03-11 00:09:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:09:04 --> Controller Class Initialized
INFO - 2022-03-11 00:09:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:09:04 --> Encrypt Class Initialized
INFO - 2022-03-11 00:09:04 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:09:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:09:04 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:09:04 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:09:04 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:09:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:09:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:09:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:09:04 --> Final output sent to browser
DEBUG - 2022-03-11 00:09:04 --> Total execution time: 0.0554
ERROR - 2022-03-11 00:09:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:09:04 --> Config Class Initialized
INFO - 2022-03-11 00:09:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:09:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:09:04 --> Utf8 Class Initialized
INFO - 2022-03-11 00:09:04 --> URI Class Initialized
INFO - 2022-03-11 00:09:04 --> Router Class Initialized
INFO - 2022-03-11 00:09:04 --> Output Class Initialized
INFO - 2022-03-11 00:09:04 --> Security Class Initialized
DEBUG - 2022-03-11 00:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:09:04 --> Input Class Initialized
INFO - 2022-03-11 00:09:04 --> Language Class Initialized
ERROR - 2022-03-11 00:09:04 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 00:10:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:10:09 --> Config Class Initialized
INFO - 2022-03-11 00:10:09 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:10:09 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:10:09 --> Utf8 Class Initialized
INFO - 2022-03-11 00:10:09 --> URI Class Initialized
INFO - 2022-03-11 00:10:09 --> Router Class Initialized
INFO - 2022-03-11 00:10:09 --> Output Class Initialized
INFO - 2022-03-11 00:10:09 --> Security Class Initialized
DEBUG - 2022-03-11 00:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:10:09 --> Input Class Initialized
INFO - 2022-03-11 00:10:09 --> Language Class Initialized
INFO - 2022-03-11 00:10:09 --> Loader Class Initialized
INFO - 2022-03-11 00:10:09 --> Helper loaded: url_helper
INFO - 2022-03-11 00:10:09 --> Helper loaded: form_helper
INFO - 2022-03-11 00:10:09 --> Helper loaded: common_helper
INFO - 2022-03-11 00:10:09 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:10:09 --> Controller Class Initialized
INFO - 2022-03-11 00:10:09 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:10:09 --> Encrypt Class Initialized
INFO - 2022-03-11 00:10:09 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:10:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:10:09 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:10:09 --> Model "Users_model" initialized
INFO - 2022-03-11 00:10:09 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:10:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:10:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:10:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:10:09 --> Final output sent to browser
DEBUG - 2022-03-11 00:10:09 --> Total execution time: 0.0736
ERROR - 2022-03-11 00:10:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:10:09 --> Config Class Initialized
INFO - 2022-03-11 00:10:09 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:10:09 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:10:09 --> Utf8 Class Initialized
INFO - 2022-03-11 00:10:09 --> URI Class Initialized
INFO - 2022-03-11 00:10:09 --> Router Class Initialized
INFO - 2022-03-11 00:10:09 --> Output Class Initialized
INFO - 2022-03-11 00:10:09 --> Security Class Initialized
DEBUG - 2022-03-11 00:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:10:09 --> Input Class Initialized
INFO - 2022-03-11 00:10:09 --> Language Class Initialized
ERROR - 2022-03-11 00:10:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:10:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:10:35 --> Config Class Initialized
INFO - 2022-03-11 00:10:35 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:10:35 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:10:35 --> Utf8 Class Initialized
INFO - 2022-03-11 00:10:35 --> URI Class Initialized
INFO - 2022-03-11 00:10:35 --> Router Class Initialized
INFO - 2022-03-11 00:10:35 --> Output Class Initialized
INFO - 2022-03-11 00:10:35 --> Security Class Initialized
DEBUG - 2022-03-11 00:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:10:35 --> Input Class Initialized
INFO - 2022-03-11 00:10:35 --> Language Class Initialized
ERROR - 2022-03-11 00:10:35 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 00:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:12:53 --> Config Class Initialized
INFO - 2022-03-11 00:12:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:12:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:12:53 --> Utf8 Class Initialized
INFO - 2022-03-11 00:12:53 --> URI Class Initialized
INFO - 2022-03-11 00:12:53 --> Router Class Initialized
INFO - 2022-03-11 00:12:53 --> Output Class Initialized
INFO - 2022-03-11 00:12:53 --> Security Class Initialized
DEBUG - 2022-03-11 00:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:12:53 --> Input Class Initialized
INFO - 2022-03-11 00:12:53 --> Language Class Initialized
INFO - 2022-03-11 00:12:53 --> Loader Class Initialized
INFO - 2022-03-11 00:12:53 --> Helper loaded: url_helper
INFO - 2022-03-11 00:12:53 --> Helper loaded: form_helper
INFO - 2022-03-11 00:12:53 --> Helper loaded: common_helper
INFO - 2022-03-11 00:12:53 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:12:53 --> Controller Class Initialized
INFO - 2022-03-11 00:12:53 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:12:53 --> Encrypt Class Initialized
INFO - 2022-03-11 00:12:53 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:12:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:12:53 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:12:53 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:12:53 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:12:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:12:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:12:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:12:53 --> Final output sent to browser
DEBUG - 2022-03-11 00:12:53 --> Total execution time: 0.0602
ERROR - 2022-03-11 00:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:12:54 --> Config Class Initialized
INFO - 2022-03-11 00:12:54 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:12:54 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:12:54 --> Utf8 Class Initialized
INFO - 2022-03-11 00:12:54 --> URI Class Initialized
INFO - 2022-03-11 00:12:54 --> Router Class Initialized
INFO - 2022-03-11 00:12:54 --> Output Class Initialized
INFO - 2022-03-11 00:12:54 --> Security Class Initialized
DEBUG - 2022-03-11 00:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:12:54 --> Input Class Initialized
INFO - 2022-03-11 00:12:54 --> Language Class Initialized
ERROR - 2022-03-11 00:12:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:13:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:13:16 --> Config Class Initialized
INFO - 2022-03-11 00:13:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:13:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:13:16 --> Utf8 Class Initialized
INFO - 2022-03-11 00:13:16 --> URI Class Initialized
INFO - 2022-03-11 00:13:16 --> Router Class Initialized
INFO - 2022-03-11 00:13:16 --> Output Class Initialized
INFO - 2022-03-11 00:13:16 --> Security Class Initialized
DEBUG - 2022-03-11 00:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:13:16 --> Input Class Initialized
INFO - 2022-03-11 00:13:16 --> Language Class Initialized
INFO - 2022-03-11 00:13:16 --> Loader Class Initialized
INFO - 2022-03-11 00:13:16 --> Helper loaded: url_helper
INFO - 2022-03-11 00:13:16 --> Helper loaded: form_helper
INFO - 2022-03-11 00:13:16 --> Helper loaded: common_helper
INFO - 2022-03-11 00:13:16 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:13:16 --> Controller Class Initialized
INFO - 2022-03-11 00:13:16 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:13:16 --> Encrypt Class Initialized
INFO - 2022-03-11 00:13:16 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:13:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:13:16 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:13:16 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:13:16 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:13:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:13:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:13:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 00:13:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:13:24 --> Config Class Initialized
INFO - 2022-03-11 00:13:24 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:13:24 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:13:24 --> Utf8 Class Initialized
INFO - 2022-03-11 00:13:24 --> URI Class Initialized
INFO - 2022-03-11 00:13:24 --> Router Class Initialized
INFO - 2022-03-11 00:13:24 --> Output Class Initialized
INFO - 2022-03-11 00:13:24 --> Security Class Initialized
DEBUG - 2022-03-11 00:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:13:24 --> Input Class Initialized
INFO - 2022-03-11 00:13:24 --> Language Class Initialized
ERROR - 2022-03-11 00:13:24 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 00:13:26 --> Final output sent to browser
DEBUG - 2022-03-11 00:13:26 --> Total execution time: 7.0470
ERROR - 2022-03-11 00:14:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:01 --> Config Class Initialized
INFO - 2022-03-11 00:14:01 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:01 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:01 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:01 --> URI Class Initialized
INFO - 2022-03-11 00:14:01 --> Router Class Initialized
INFO - 2022-03-11 00:14:01 --> Output Class Initialized
INFO - 2022-03-11 00:14:01 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:01 --> Input Class Initialized
INFO - 2022-03-11 00:14:01 --> Language Class Initialized
INFO - 2022-03-11 00:14:02 --> Loader Class Initialized
INFO - 2022-03-11 00:14:02 --> Helper loaded: url_helper
INFO - 2022-03-11 00:14:02 --> Helper loaded: form_helper
INFO - 2022-03-11 00:14:02 --> Helper loaded: common_helper
INFO - 2022-03-11 00:14:02 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:14:02 --> Controller Class Initialized
INFO - 2022-03-11 00:14:02 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:14:02 --> Encrypt Class Initialized
INFO - 2022-03-11 00:14:02 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:14:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:14:02 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:14:02 --> Model "Users_model" initialized
INFO - 2022-03-11 00:14:02 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:14:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:14:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:14:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:14:02 --> Final output sent to browser
DEBUG - 2022-03-11 00:14:02 --> Total execution time: 0.0733
ERROR - 2022-03-11 00:14:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:02 --> Config Class Initialized
INFO - 2022-03-11 00:14:02 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:02 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:02 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:02 --> URI Class Initialized
INFO - 2022-03-11 00:14:02 --> Router Class Initialized
INFO - 2022-03-11 00:14:02 --> Output Class Initialized
INFO - 2022-03-11 00:14:02 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:02 --> Input Class Initialized
INFO - 2022-03-11 00:14:02 --> Language Class Initialized
ERROR - 2022-03-11 00:14:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:10 --> Config Class Initialized
INFO - 2022-03-11 00:14:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:10 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:10 --> URI Class Initialized
INFO - 2022-03-11 00:14:10 --> Router Class Initialized
INFO - 2022-03-11 00:14:10 --> Output Class Initialized
INFO - 2022-03-11 00:14:10 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:10 --> Input Class Initialized
INFO - 2022-03-11 00:14:10 --> Language Class Initialized
ERROR - 2022-03-11 00:14:10 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 00:14:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:27 --> Config Class Initialized
INFO - 2022-03-11 00:14:27 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:27 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:27 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:27 --> URI Class Initialized
INFO - 2022-03-11 00:14:27 --> Router Class Initialized
INFO - 2022-03-11 00:14:27 --> Output Class Initialized
INFO - 2022-03-11 00:14:27 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:27 --> Input Class Initialized
INFO - 2022-03-11 00:14:27 --> Language Class Initialized
INFO - 2022-03-11 00:14:27 --> Loader Class Initialized
INFO - 2022-03-11 00:14:27 --> Helper loaded: url_helper
INFO - 2022-03-11 00:14:27 --> Helper loaded: form_helper
INFO - 2022-03-11 00:14:27 --> Helper loaded: common_helper
INFO - 2022-03-11 00:14:27 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:14:27 --> Controller Class Initialized
INFO - 2022-03-11 00:14:27 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:14:27 --> Encrypt Class Initialized
INFO - 2022-03-11 00:14:27 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:14:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:14:27 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:14:27 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:14:27 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:14:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:14:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:14:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:14:27 --> Final output sent to browser
DEBUG - 2022-03-11 00:14:27 --> Total execution time: 0.0396
ERROR - 2022-03-11 00:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:28 --> Config Class Initialized
INFO - 2022-03-11 00:14:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:28 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:28 --> URI Class Initialized
INFO - 2022-03-11 00:14:28 --> Router Class Initialized
INFO - 2022-03-11 00:14:28 --> Output Class Initialized
INFO - 2022-03-11 00:14:28 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:28 --> Input Class Initialized
INFO - 2022-03-11 00:14:28 --> Language Class Initialized
ERROR - 2022-03-11 00:14:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:14:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:32 --> Config Class Initialized
INFO - 2022-03-11 00:14:32 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:32 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:32 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:32 --> URI Class Initialized
INFO - 2022-03-11 00:14:32 --> Router Class Initialized
INFO - 2022-03-11 00:14:32 --> Output Class Initialized
INFO - 2022-03-11 00:14:32 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:32 --> Input Class Initialized
INFO - 2022-03-11 00:14:32 --> Language Class Initialized
INFO - 2022-03-11 00:14:32 --> Loader Class Initialized
INFO - 2022-03-11 00:14:32 --> Helper loaded: url_helper
INFO - 2022-03-11 00:14:32 --> Helper loaded: form_helper
INFO - 2022-03-11 00:14:32 --> Helper loaded: common_helper
INFO - 2022-03-11 00:14:32 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:14:32 --> Controller Class Initialized
ERROR - 2022-03-11 00:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:33 --> Config Class Initialized
INFO - 2022-03-11 00:14:33 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:33 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:33 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:33 --> URI Class Initialized
INFO - 2022-03-11 00:14:33 --> Router Class Initialized
INFO - 2022-03-11 00:14:33 --> Output Class Initialized
INFO - 2022-03-11 00:14:33 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:33 --> Input Class Initialized
INFO - 2022-03-11 00:14:33 --> Language Class Initialized
INFO - 2022-03-11 00:14:33 --> Loader Class Initialized
INFO - 2022-03-11 00:14:33 --> Helper loaded: url_helper
INFO - 2022-03-11 00:14:33 --> Helper loaded: form_helper
INFO - 2022-03-11 00:14:33 --> Helper loaded: common_helper
INFO - 2022-03-11 00:14:33 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:14:33 --> Controller Class Initialized
INFO - 2022-03-11 00:14:33 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:14:33 --> Encrypt Class Initialized
DEBUG - 2022-03-11 00:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 00:14:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 00:14:33 --> Email Class Initialized
INFO - 2022-03-11 00:14:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 00:14:33 --> Calendar Class Initialized
INFO - 2022-03-11 00:14:33 --> Model "Login_model" initialized
INFO - 2022-03-11 00:14:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 00:14:33 --> Final output sent to browser
DEBUG - 2022-03-11 00:14:33 --> Total execution time: 0.0214
ERROR - 2022-03-11 00:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:51 --> Config Class Initialized
INFO - 2022-03-11 00:14:51 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:51 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:51 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:51 --> URI Class Initialized
INFO - 2022-03-11 00:14:51 --> Router Class Initialized
INFO - 2022-03-11 00:14:51 --> Output Class Initialized
INFO - 2022-03-11 00:14:51 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:51 --> Input Class Initialized
INFO - 2022-03-11 00:14:51 --> Language Class Initialized
INFO - 2022-03-11 00:14:51 --> Loader Class Initialized
INFO - 2022-03-11 00:14:51 --> Helper loaded: url_helper
INFO - 2022-03-11 00:14:51 --> Helper loaded: form_helper
INFO - 2022-03-11 00:14:51 --> Helper loaded: common_helper
INFO - 2022-03-11 00:14:51 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:14:51 --> Controller Class Initialized
INFO - 2022-03-11 00:14:51 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:14:51 --> Encrypt Class Initialized
INFO - 2022-03-11 00:14:51 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:14:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:14:51 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:14:51 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:14:51 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:14:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:14:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:14:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 00:14:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:58 --> Config Class Initialized
INFO - 2022-03-11 00:14:58 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:58 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:58 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:58 --> URI Class Initialized
INFO - 2022-03-11 00:14:58 --> Router Class Initialized
INFO - 2022-03-11 00:14:58 --> Output Class Initialized
INFO - 2022-03-11 00:14:58 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:58 --> Input Class Initialized
INFO - 2022-03-11 00:14:58 --> Language Class Initialized
ERROR - 2022-03-11 00:14:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:14:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:14:59 --> Config Class Initialized
INFO - 2022-03-11 00:14:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:14:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:14:59 --> Utf8 Class Initialized
INFO - 2022-03-11 00:14:59 --> URI Class Initialized
INFO - 2022-03-11 00:14:59 --> Router Class Initialized
INFO - 2022-03-11 00:14:59 --> Output Class Initialized
INFO - 2022-03-11 00:14:59 --> Security Class Initialized
DEBUG - 2022-03-11 00:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:14:59 --> Input Class Initialized
INFO - 2022-03-11 00:14:59 --> Language Class Initialized
INFO - 2022-03-11 00:14:59 --> Loader Class Initialized
INFO - 2022-03-11 00:14:59 --> Helper loaded: url_helper
INFO - 2022-03-11 00:14:59 --> Helper loaded: form_helper
INFO - 2022-03-11 00:14:59 --> Helper loaded: common_helper
INFO - 2022-03-11 00:14:59 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:15:00 --> Final output sent to browser
DEBUG - 2022-03-11 00:15:00 --> Total execution time: 5.7290
INFO - 2022-03-11 00:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:15:00 --> Controller Class Initialized
INFO - 2022-03-11 00:15:00 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:15:00 --> Encrypt Class Initialized
INFO - 2022-03-11 00:15:00 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:15:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:15:00 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:15:00 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:15:00 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:15:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:15:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:15:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 00:15:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:15:07 --> Config Class Initialized
INFO - 2022-03-11 00:15:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:15:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:15:07 --> Utf8 Class Initialized
INFO - 2022-03-11 00:15:07 --> URI Class Initialized
INFO - 2022-03-11 00:15:07 --> Router Class Initialized
INFO - 2022-03-11 00:15:07 --> Output Class Initialized
INFO - 2022-03-11 00:15:07 --> Security Class Initialized
DEBUG - 2022-03-11 00:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:15:07 --> Input Class Initialized
INFO - 2022-03-11 00:15:07 --> Language Class Initialized
ERROR - 2022-03-11 00:15:07 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 00:15:07 --> Final output sent to browser
DEBUG - 2022-03-11 00:15:07 --> Total execution time: 6.6921
ERROR - 2022-03-11 00:16:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:16:53 --> Config Class Initialized
INFO - 2022-03-11 00:16:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:16:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:16:53 --> Utf8 Class Initialized
INFO - 2022-03-11 00:16:53 --> URI Class Initialized
INFO - 2022-03-11 00:16:53 --> Router Class Initialized
INFO - 2022-03-11 00:16:53 --> Output Class Initialized
INFO - 2022-03-11 00:16:53 --> Security Class Initialized
DEBUG - 2022-03-11 00:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:16:53 --> Input Class Initialized
INFO - 2022-03-11 00:16:53 --> Language Class Initialized
INFO - 2022-03-11 00:16:53 --> Loader Class Initialized
INFO - 2022-03-11 00:16:53 --> Helper loaded: url_helper
INFO - 2022-03-11 00:16:53 --> Helper loaded: form_helper
INFO - 2022-03-11 00:16:53 --> Helper loaded: common_helper
INFO - 2022-03-11 00:16:53 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:16:53 --> Controller Class Initialized
INFO - 2022-03-11 00:16:53 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:16:53 --> Encrypt Class Initialized
INFO - 2022-03-11 00:16:53 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:16:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:16:53 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:16:53 --> Model "Users_model" initialized
INFO - 2022-03-11 00:16:53 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:16:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:16:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:16:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:16:53 --> Final output sent to browser
DEBUG - 2022-03-11 00:16:53 --> Total execution time: 0.0652
ERROR - 2022-03-11 00:16:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:16:54 --> Config Class Initialized
INFO - 2022-03-11 00:16:54 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:16:54 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:16:54 --> Utf8 Class Initialized
INFO - 2022-03-11 00:16:54 --> URI Class Initialized
INFO - 2022-03-11 00:16:54 --> Router Class Initialized
INFO - 2022-03-11 00:16:54 --> Output Class Initialized
INFO - 2022-03-11 00:16:54 --> Security Class Initialized
DEBUG - 2022-03-11 00:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:16:54 --> Input Class Initialized
INFO - 2022-03-11 00:16:54 --> Language Class Initialized
ERROR - 2022-03-11 00:16:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:17:44 --> Config Class Initialized
INFO - 2022-03-11 00:17:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:17:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:17:44 --> Utf8 Class Initialized
INFO - 2022-03-11 00:17:44 --> URI Class Initialized
INFO - 2022-03-11 00:17:44 --> Router Class Initialized
INFO - 2022-03-11 00:17:44 --> Output Class Initialized
INFO - 2022-03-11 00:17:44 --> Security Class Initialized
DEBUG - 2022-03-11 00:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:17:44 --> Input Class Initialized
INFO - 2022-03-11 00:17:44 --> Language Class Initialized
INFO - 2022-03-11 00:17:44 --> Loader Class Initialized
INFO - 2022-03-11 00:17:44 --> Helper loaded: url_helper
INFO - 2022-03-11 00:17:44 --> Helper loaded: form_helper
INFO - 2022-03-11 00:17:44 --> Helper loaded: common_helper
INFO - 2022-03-11 00:17:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:17:44 --> Controller Class Initialized
INFO - 2022-03-11 00:17:44 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:17:44 --> Encrypt Class Initialized
INFO - 2022-03-11 00:17:44 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:17:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:17:44 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:17:44 --> Model "Users_model" initialized
INFO - 2022-03-11 00:17:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 00:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:17:44 --> Config Class Initialized
INFO - 2022-03-11 00:17:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:17:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:17:44 --> Utf8 Class Initialized
INFO - 2022-03-11 00:17:44 --> URI Class Initialized
INFO - 2022-03-11 00:17:44 --> Router Class Initialized
INFO - 2022-03-11 00:17:44 --> Output Class Initialized
INFO - 2022-03-11 00:17:44 --> Security Class Initialized
DEBUG - 2022-03-11 00:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:17:44 --> Input Class Initialized
INFO - 2022-03-11 00:17:44 --> Language Class Initialized
INFO - 2022-03-11 00:17:44 --> Loader Class Initialized
INFO - 2022-03-11 00:17:44 --> Helper loaded: url_helper
INFO - 2022-03-11 00:17:44 --> Helper loaded: form_helper
INFO - 2022-03-11 00:17:44 --> Helper loaded: common_helper
INFO - 2022-03-11 00:17:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:17:44 --> Controller Class Initialized
INFO - 2022-03-11 00:17:44 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:17:44 --> Encrypt Class Initialized
INFO - 2022-03-11 00:17:44 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:17:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:17:44 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:17:44 --> Model "Users_model" initialized
INFO - 2022-03-11 00:17:44 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:17:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:17:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:17:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:17:44 --> Final output sent to browser
DEBUG - 2022-03-11 00:17:44 --> Total execution time: 0.0668
ERROR - 2022-03-11 00:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:17:45 --> Config Class Initialized
INFO - 2022-03-11 00:17:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:17:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:17:45 --> Utf8 Class Initialized
INFO - 2022-03-11 00:17:45 --> URI Class Initialized
INFO - 2022-03-11 00:17:45 --> Router Class Initialized
INFO - 2022-03-11 00:17:45 --> Output Class Initialized
INFO - 2022-03-11 00:17:45 --> Security Class Initialized
DEBUG - 2022-03-11 00:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:17:45 --> Input Class Initialized
INFO - 2022-03-11 00:17:45 --> Language Class Initialized
ERROR - 2022-03-11 00:17:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:17:51 --> Config Class Initialized
INFO - 2022-03-11 00:17:51 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:17:51 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:17:51 --> Utf8 Class Initialized
INFO - 2022-03-11 00:17:51 --> URI Class Initialized
INFO - 2022-03-11 00:17:51 --> Router Class Initialized
INFO - 2022-03-11 00:17:51 --> Output Class Initialized
INFO - 2022-03-11 00:17:51 --> Security Class Initialized
DEBUG - 2022-03-11 00:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:17:51 --> Input Class Initialized
INFO - 2022-03-11 00:17:51 --> Language Class Initialized
ERROR - 2022-03-11 00:17:51 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 00:18:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:18:09 --> Config Class Initialized
INFO - 2022-03-11 00:18:09 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:18:09 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:18:09 --> Utf8 Class Initialized
INFO - 2022-03-11 00:18:09 --> URI Class Initialized
INFO - 2022-03-11 00:18:09 --> Router Class Initialized
INFO - 2022-03-11 00:18:09 --> Output Class Initialized
INFO - 2022-03-11 00:18:09 --> Security Class Initialized
DEBUG - 2022-03-11 00:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:18:09 --> Input Class Initialized
INFO - 2022-03-11 00:18:09 --> Language Class Initialized
INFO - 2022-03-11 00:18:09 --> Loader Class Initialized
INFO - 2022-03-11 00:18:09 --> Helper loaded: url_helper
INFO - 2022-03-11 00:18:09 --> Helper loaded: form_helper
INFO - 2022-03-11 00:18:09 --> Helper loaded: common_helper
INFO - 2022-03-11 00:18:09 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:18:09 --> Controller Class Initialized
INFO - 2022-03-11 00:18:09 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:18:09 --> Encrypt Class Initialized
INFO - 2022-03-11 00:18:09 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:18:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:18:09 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:18:09 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:18:09 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:18:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:18:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:18:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:18:09 --> Final output sent to browser
DEBUG - 2022-03-11 00:18:09 --> Total execution time: 0.0678
ERROR - 2022-03-11 00:18:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:18:10 --> Config Class Initialized
INFO - 2022-03-11 00:18:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:18:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:18:10 --> Utf8 Class Initialized
INFO - 2022-03-11 00:18:10 --> URI Class Initialized
INFO - 2022-03-11 00:18:10 --> Router Class Initialized
INFO - 2022-03-11 00:18:10 --> Output Class Initialized
INFO - 2022-03-11 00:18:10 --> Security Class Initialized
DEBUG - 2022-03-11 00:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:18:10 --> Input Class Initialized
INFO - 2022-03-11 00:18:10 --> Language Class Initialized
ERROR - 2022-03-11 00:18:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:27:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:27:52 --> Config Class Initialized
INFO - 2022-03-11 00:27:52 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:27:52 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:27:52 --> Utf8 Class Initialized
INFO - 2022-03-11 00:27:52 --> URI Class Initialized
DEBUG - 2022-03-11 00:27:52 --> No URI present. Default controller set.
INFO - 2022-03-11 00:27:52 --> Router Class Initialized
INFO - 2022-03-11 00:27:52 --> Output Class Initialized
INFO - 2022-03-11 00:27:52 --> Security Class Initialized
DEBUG - 2022-03-11 00:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:27:52 --> Input Class Initialized
INFO - 2022-03-11 00:27:52 --> Language Class Initialized
INFO - 2022-03-11 00:27:52 --> Loader Class Initialized
INFO - 2022-03-11 00:27:52 --> Helper loaded: url_helper
INFO - 2022-03-11 00:27:52 --> Helper loaded: form_helper
INFO - 2022-03-11 00:27:52 --> Helper loaded: common_helper
INFO - 2022-03-11 00:27:52 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:27:52 --> Controller Class Initialized
INFO - 2022-03-11 00:27:52 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:27:52 --> Encrypt Class Initialized
DEBUG - 2022-03-11 00:27:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 00:27:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 00:27:52 --> Email Class Initialized
INFO - 2022-03-11 00:27:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 00:27:52 --> Calendar Class Initialized
INFO - 2022-03-11 00:27:52 --> Model "Login_model" initialized
ERROR - 2022-03-11 00:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:27:54 --> Config Class Initialized
INFO - 2022-03-11 00:27:54 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:27:54 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:27:54 --> Utf8 Class Initialized
INFO - 2022-03-11 00:27:54 --> URI Class Initialized
INFO - 2022-03-11 00:27:54 --> Router Class Initialized
INFO - 2022-03-11 00:27:54 --> Output Class Initialized
INFO - 2022-03-11 00:27:54 --> Security Class Initialized
DEBUG - 2022-03-11 00:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:27:54 --> Input Class Initialized
INFO - 2022-03-11 00:27:54 --> Language Class Initialized
INFO - 2022-03-11 00:27:54 --> Loader Class Initialized
INFO - 2022-03-11 00:27:54 --> Helper loaded: url_helper
INFO - 2022-03-11 00:27:54 --> Helper loaded: form_helper
INFO - 2022-03-11 00:27:54 --> Helper loaded: common_helper
INFO - 2022-03-11 00:27:54 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:27:54 --> Controller Class Initialized
INFO - 2022-03-11 00:27:54 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:27:54 --> Encrypt Class Initialized
INFO - 2022-03-11 00:27:54 --> Model "Diseases_model" initialized
INFO - 2022-03-11 00:27:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:27:54 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-11 00:27:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:27:54 --> Final output sent to browser
DEBUG - 2022-03-11 00:27:54 --> Total execution time: 0.0590
ERROR - 2022-03-11 00:27:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:27:55 --> Config Class Initialized
INFO - 2022-03-11 00:27:55 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:27:55 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:27:55 --> Utf8 Class Initialized
INFO - 2022-03-11 00:27:55 --> URI Class Initialized
INFO - 2022-03-11 00:27:55 --> Router Class Initialized
INFO - 2022-03-11 00:27:55 --> Output Class Initialized
INFO - 2022-03-11 00:27:55 --> Security Class Initialized
DEBUG - 2022-03-11 00:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:27:55 --> Input Class Initialized
INFO - 2022-03-11 00:27:55 --> Language Class Initialized
ERROR - 2022-03-11 00:27:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:34:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:34:07 --> Config Class Initialized
INFO - 2022-03-11 00:34:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:34:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:34:07 --> Utf8 Class Initialized
INFO - 2022-03-11 00:34:07 --> URI Class Initialized
INFO - 2022-03-11 00:34:07 --> Router Class Initialized
INFO - 2022-03-11 00:34:07 --> Output Class Initialized
INFO - 2022-03-11 00:34:07 --> Security Class Initialized
DEBUG - 2022-03-11 00:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:34:07 --> Input Class Initialized
INFO - 2022-03-11 00:34:07 --> Language Class Initialized
INFO - 2022-03-11 00:34:07 --> Loader Class Initialized
INFO - 2022-03-11 00:34:07 --> Helper loaded: url_helper
INFO - 2022-03-11 00:34:07 --> Helper loaded: form_helper
INFO - 2022-03-11 00:34:07 --> Helper loaded: common_helper
INFO - 2022-03-11 00:34:07 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:34:07 --> Controller Class Initialized
INFO - 2022-03-11 00:34:07 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:34:07 --> Encrypt Class Initialized
INFO - 2022-03-11 00:34:07 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:34:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:34:07 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:34:07 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:34:07 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:34:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:34:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:34:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 00:34:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:34:16 --> Config Class Initialized
INFO - 2022-03-11 00:34:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:34:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:34:16 --> Utf8 Class Initialized
INFO - 2022-03-11 00:34:16 --> URI Class Initialized
INFO - 2022-03-11 00:34:16 --> Router Class Initialized
INFO - 2022-03-11 00:34:16 --> Output Class Initialized
INFO - 2022-03-11 00:34:16 --> Security Class Initialized
DEBUG - 2022-03-11 00:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:34:16 --> Input Class Initialized
INFO - 2022-03-11 00:34:16 --> Language Class Initialized
ERROR - 2022-03-11 00:34:16 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 00:34:17 --> Final output sent to browser
DEBUG - 2022-03-11 00:34:17 --> Total execution time: 7.4159
ERROR - 2022-03-11 00:34:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:34:59 --> Config Class Initialized
INFO - 2022-03-11 00:34:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:34:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:34:59 --> Utf8 Class Initialized
INFO - 2022-03-11 00:34:59 --> URI Class Initialized
INFO - 2022-03-11 00:34:59 --> Router Class Initialized
INFO - 2022-03-11 00:34:59 --> Output Class Initialized
INFO - 2022-03-11 00:34:59 --> Security Class Initialized
DEBUG - 2022-03-11 00:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:34:59 --> Input Class Initialized
INFO - 2022-03-11 00:34:59 --> Language Class Initialized
INFO - 2022-03-11 00:34:59 --> Loader Class Initialized
INFO - 2022-03-11 00:34:59 --> Helper loaded: url_helper
INFO - 2022-03-11 00:34:59 --> Helper loaded: form_helper
INFO - 2022-03-11 00:34:59 --> Helper loaded: common_helper
INFO - 2022-03-11 00:34:59 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:34:59 --> Controller Class Initialized
INFO - 2022-03-11 00:34:59 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:34:59 --> Encrypt Class Initialized
INFO - 2022-03-11 00:34:59 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:34:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:34:59 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:34:59 --> Model "Users_model" initialized
INFO - 2022-03-11 00:34:59 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:34:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:34:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:34:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:34:59 --> Final output sent to browser
DEBUG - 2022-03-11 00:34:59 --> Total execution time: 0.0673
ERROR - 2022-03-11 00:35:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:35:00 --> Config Class Initialized
INFO - 2022-03-11 00:35:00 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:35:00 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:35:00 --> Utf8 Class Initialized
INFO - 2022-03-11 00:35:00 --> URI Class Initialized
INFO - 2022-03-11 00:35:00 --> Router Class Initialized
INFO - 2022-03-11 00:35:00 --> Output Class Initialized
INFO - 2022-03-11 00:35:00 --> Security Class Initialized
DEBUG - 2022-03-11 00:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:35:00 --> Input Class Initialized
INFO - 2022-03-11 00:35:00 --> Language Class Initialized
ERROR - 2022-03-11 00:35:00 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:35:13 --> Config Class Initialized
INFO - 2022-03-11 00:35:13 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:35:13 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:35:13 --> Utf8 Class Initialized
INFO - 2022-03-11 00:35:13 --> URI Class Initialized
INFO - 2022-03-11 00:35:13 --> Router Class Initialized
INFO - 2022-03-11 00:35:13 --> Output Class Initialized
INFO - 2022-03-11 00:35:13 --> Security Class Initialized
DEBUG - 2022-03-11 00:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:35:13 --> Input Class Initialized
INFO - 2022-03-11 00:35:13 --> Language Class Initialized
INFO - 2022-03-11 00:35:13 --> Loader Class Initialized
INFO - 2022-03-11 00:35:13 --> Helper loaded: url_helper
INFO - 2022-03-11 00:35:13 --> Helper loaded: form_helper
INFO - 2022-03-11 00:35:13 --> Helper loaded: common_helper
INFO - 2022-03-11 00:35:13 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:35:13 --> Controller Class Initialized
INFO - 2022-03-11 00:35:13 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:35:13 --> Encrypt Class Initialized
INFO - 2022-03-11 00:35:13 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:35:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:35:13 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:35:13 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:35:13 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:35:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:35:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:35:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:35:13 --> Final output sent to browser
DEBUG - 2022-03-11 00:35:13 --> Total execution time: 0.0484
ERROR - 2022-03-11 00:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:35:14 --> Config Class Initialized
INFO - 2022-03-11 00:35:14 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:35:14 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:35:14 --> Utf8 Class Initialized
INFO - 2022-03-11 00:35:14 --> URI Class Initialized
INFO - 2022-03-11 00:35:14 --> Router Class Initialized
INFO - 2022-03-11 00:35:14 --> Output Class Initialized
INFO - 2022-03-11 00:35:14 --> Security Class Initialized
DEBUG - 2022-03-11 00:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:35:14 --> Input Class Initialized
INFO - 2022-03-11 00:35:14 --> Language Class Initialized
ERROR - 2022-03-11 00:35:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:38:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:14 --> Config Class Initialized
INFO - 2022-03-11 00:38:14 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:14 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:14 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:14 --> URI Class Initialized
INFO - 2022-03-11 00:38:14 --> Router Class Initialized
INFO - 2022-03-11 00:38:14 --> Output Class Initialized
INFO - 2022-03-11 00:38:14 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:14 --> Input Class Initialized
INFO - 2022-03-11 00:38:14 --> Language Class Initialized
INFO - 2022-03-11 00:38:14 --> Loader Class Initialized
INFO - 2022-03-11 00:38:14 --> Helper loaded: url_helper
INFO - 2022-03-11 00:38:14 --> Helper loaded: form_helper
INFO - 2022-03-11 00:38:14 --> Helper loaded: common_helper
INFO - 2022-03-11 00:38:14 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:38:14 --> Controller Class Initialized
INFO - 2022-03-11 00:38:14 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:38:14 --> Encrypt Class Initialized
INFO - 2022-03-11 00:38:14 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:38:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:38:14 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:38:14 --> Model "Users_model" initialized
INFO - 2022-03-11 00:38:14 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:38:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:38:14 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:38:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:38:14 --> Final output sent to browser
DEBUG - 2022-03-11 00:38:14 --> Total execution time: 0.0935
ERROR - 2022-03-11 00:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:15 --> Config Class Initialized
INFO - 2022-03-11 00:38:15 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:15 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:15 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:15 --> URI Class Initialized
INFO - 2022-03-11 00:38:15 --> Router Class Initialized
INFO - 2022-03-11 00:38:15 --> Output Class Initialized
INFO - 2022-03-11 00:38:15 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:15 --> Input Class Initialized
INFO - 2022-03-11 00:38:15 --> Language Class Initialized
ERROR - 2022-03-11 00:38:15 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:38:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:22 --> Config Class Initialized
INFO - 2022-03-11 00:38:22 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:22 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:22 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:22 --> URI Class Initialized
INFO - 2022-03-11 00:38:22 --> Router Class Initialized
INFO - 2022-03-11 00:38:22 --> Output Class Initialized
INFO - 2022-03-11 00:38:22 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:22 --> Input Class Initialized
INFO - 2022-03-11 00:38:22 --> Language Class Initialized
INFO - 2022-03-11 00:38:22 --> Loader Class Initialized
INFO - 2022-03-11 00:38:22 --> Helper loaded: url_helper
INFO - 2022-03-11 00:38:22 --> Helper loaded: form_helper
INFO - 2022-03-11 00:38:22 --> Helper loaded: common_helper
INFO - 2022-03-11 00:38:22 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:38:22 --> Controller Class Initialized
INFO - 2022-03-11 00:38:22 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:38:22 --> Encrypt Class Initialized
INFO - 2022-03-11 00:38:22 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:38:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:38:22 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:38:22 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:38:22 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 00:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:23 --> Config Class Initialized
INFO - 2022-03-11 00:38:23 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:23 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:23 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:23 --> URI Class Initialized
INFO - 2022-03-11 00:38:23 --> Router Class Initialized
INFO - 2022-03-11 00:38:23 --> Output Class Initialized
INFO - 2022-03-11 00:38:23 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:23 --> Input Class Initialized
INFO - 2022-03-11 00:38:23 --> Language Class Initialized
INFO - 2022-03-11 00:38:23 --> Loader Class Initialized
INFO - 2022-03-11 00:38:23 --> Helper loaded: url_helper
INFO - 2022-03-11 00:38:23 --> Helper loaded: form_helper
INFO - 2022-03-11 00:38:23 --> Helper loaded: common_helper
INFO - 2022-03-11 00:38:23 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:38:23 --> Controller Class Initialized
INFO - 2022-03-11 00:38:23 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:38:23 --> Encrypt Class Initialized
INFO - 2022-03-11 00:38:23 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:38:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:38:23 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:38:23 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:38:23 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:38:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:38:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:38:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:38:23 --> Final output sent to browser
DEBUG - 2022-03-11 00:38:23 --> Total execution time: 0.0801
ERROR - 2022-03-11 00:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:24 --> Config Class Initialized
INFO - 2022-03-11 00:38:24 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:24 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:24 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:24 --> URI Class Initialized
INFO - 2022-03-11 00:38:24 --> Router Class Initialized
INFO - 2022-03-11 00:38:24 --> Output Class Initialized
INFO - 2022-03-11 00:38:24 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:24 --> Input Class Initialized
INFO - 2022-03-11 00:38:24 --> Language Class Initialized
ERROR - 2022-03-11 00:38:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:24 --> Config Class Initialized
INFO - 2022-03-11 00:38:24 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:24 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:24 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:24 --> URI Class Initialized
INFO - 2022-03-11 00:38:24 --> Router Class Initialized
INFO - 2022-03-11 00:38:24 --> Output Class Initialized
INFO - 2022-03-11 00:38:24 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:24 --> Input Class Initialized
INFO - 2022-03-11 00:38:24 --> Language Class Initialized
INFO - 2022-03-11 00:38:24 --> Loader Class Initialized
INFO - 2022-03-11 00:38:24 --> Helper loaded: url_helper
INFO - 2022-03-11 00:38:24 --> Helper loaded: form_helper
INFO - 2022-03-11 00:38:24 --> Helper loaded: common_helper
INFO - 2022-03-11 00:38:24 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:38:24 --> Controller Class Initialized
INFO - 2022-03-11 00:38:24 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:38:24 --> Encrypt Class Initialized
INFO - 2022-03-11 00:38:24 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:38:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:38:24 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:38:24 --> Model "Users_model" initialized
INFO - 2022-03-11 00:38:24 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:38:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:38:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:38:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:38:24 --> Final output sent to browser
DEBUG - 2022-03-11 00:38:24 --> Total execution time: 0.1266
ERROR - 2022-03-11 00:38:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:25 --> Config Class Initialized
INFO - 2022-03-11 00:38:25 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:25 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:25 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:25 --> URI Class Initialized
INFO - 2022-03-11 00:38:25 --> Router Class Initialized
INFO - 2022-03-11 00:38:25 --> Output Class Initialized
INFO - 2022-03-11 00:38:25 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:25 --> Input Class Initialized
INFO - 2022-03-11 00:38:25 --> Language Class Initialized
ERROR - 2022-03-11 00:38:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:38:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:39 --> Config Class Initialized
INFO - 2022-03-11 00:38:39 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:39 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:39 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:39 --> URI Class Initialized
INFO - 2022-03-11 00:38:39 --> Router Class Initialized
INFO - 2022-03-11 00:38:39 --> Output Class Initialized
INFO - 2022-03-11 00:38:39 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:39 --> Input Class Initialized
INFO - 2022-03-11 00:38:39 --> Language Class Initialized
ERROR - 2022-03-11 00:38:39 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 00:38:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:45 --> Config Class Initialized
INFO - 2022-03-11 00:38:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:45 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:45 --> URI Class Initialized
INFO - 2022-03-11 00:38:45 --> Router Class Initialized
INFO - 2022-03-11 00:38:45 --> Output Class Initialized
INFO - 2022-03-11 00:38:45 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:45 --> Input Class Initialized
INFO - 2022-03-11 00:38:45 --> Language Class Initialized
INFO - 2022-03-11 00:38:45 --> Loader Class Initialized
INFO - 2022-03-11 00:38:45 --> Helper loaded: url_helper
INFO - 2022-03-11 00:38:45 --> Helper loaded: form_helper
INFO - 2022-03-11 00:38:45 --> Helper loaded: common_helper
INFO - 2022-03-11 00:38:45 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:38:45 --> Controller Class Initialized
INFO - 2022-03-11 00:38:45 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:38:45 --> Encrypt Class Initialized
INFO - 2022-03-11 00:38:45 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:38:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:38:45 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:38:45 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:38:45 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:38:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:38:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:38:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:38:45 --> Final output sent to browser
DEBUG - 2022-03-11 00:38:45 --> Total execution time: 0.0756
ERROR - 2022-03-11 00:38:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:38:46 --> Config Class Initialized
INFO - 2022-03-11 00:38:46 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:38:46 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:38:46 --> Utf8 Class Initialized
INFO - 2022-03-11 00:38:46 --> URI Class Initialized
INFO - 2022-03-11 00:38:46 --> Router Class Initialized
INFO - 2022-03-11 00:38:46 --> Output Class Initialized
INFO - 2022-03-11 00:38:46 --> Security Class Initialized
DEBUG - 2022-03-11 00:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:38:46 --> Input Class Initialized
INFO - 2022-03-11 00:38:46 --> Language Class Initialized
ERROR - 2022-03-11 00:38:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:39:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:39:19 --> Config Class Initialized
INFO - 2022-03-11 00:39:19 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:39:19 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:39:19 --> Utf8 Class Initialized
INFO - 2022-03-11 00:39:19 --> URI Class Initialized
INFO - 2022-03-11 00:39:19 --> Router Class Initialized
INFO - 2022-03-11 00:39:19 --> Output Class Initialized
INFO - 2022-03-11 00:39:19 --> Security Class Initialized
DEBUG - 2022-03-11 00:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:39:19 --> Input Class Initialized
INFO - 2022-03-11 00:39:19 --> Language Class Initialized
INFO - 2022-03-11 00:39:19 --> Loader Class Initialized
INFO - 2022-03-11 00:39:19 --> Helper loaded: url_helper
INFO - 2022-03-11 00:39:19 --> Helper loaded: form_helper
INFO - 2022-03-11 00:39:19 --> Helper loaded: common_helper
INFO - 2022-03-11 00:39:19 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:39:19 --> Controller Class Initialized
INFO - 2022-03-11 00:39:19 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:39:19 --> Encrypt Class Initialized
DEBUG - 2022-03-11 00:39:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 00:39:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 00:39:19 --> Email Class Initialized
INFO - 2022-03-11 00:39:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 00:39:19 --> Calendar Class Initialized
INFO - 2022-03-11 00:39:19 --> Model "Login_model" initialized
ERROR - 2022-03-11 00:39:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:39:20 --> Config Class Initialized
INFO - 2022-03-11 00:39:20 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:39:20 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:39:20 --> Utf8 Class Initialized
INFO - 2022-03-11 00:39:20 --> URI Class Initialized
INFO - 2022-03-11 00:39:20 --> Router Class Initialized
INFO - 2022-03-11 00:39:20 --> Output Class Initialized
INFO - 2022-03-11 00:39:20 --> Security Class Initialized
DEBUG - 2022-03-11 00:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:39:20 --> Input Class Initialized
INFO - 2022-03-11 00:39:20 --> Language Class Initialized
INFO - 2022-03-11 00:39:20 --> Loader Class Initialized
INFO - 2022-03-11 00:39:20 --> Helper loaded: url_helper
INFO - 2022-03-11 00:39:20 --> Helper loaded: form_helper
INFO - 2022-03-11 00:39:20 --> Helper loaded: common_helper
INFO - 2022-03-11 00:39:20 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:39:20 --> Controller Class Initialized
INFO - 2022-03-11 00:39:20 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:39:20 --> Encrypt Class Initialized
DEBUG - 2022-03-11 00:39:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 00:39:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 00:39:20 --> Email Class Initialized
INFO - 2022-03-11 00:39:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 00:39:20 --> Calendar Class Initialized
INFO - 2022-03-11 00:39:20 --> Model "Login_model" initialized
INFO - 2022-03-11 00:39:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 00:39:20 --> Final output sent to browser
DEBUG - 2022-03-11 00:39:20 --> Total execution time: 0.0250
ERROR - 2022-03-11 00:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:03 --> Config Class Initialized
INFO - 2022-03-11 00:41:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:03 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:03 --> URI Class Initialized
INFO - 2022-03-11 00:41:03 --> Router Class Initialized
INFO - 2022-03-11 00:41:03 --> Output Class Initialized
INFO - 2022-03-11 00:41:03 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:03 --> Input Class Initialized
INFO - 2022-03-11 00:41:03 --> Language Class Initialized
INFO - 2022-03-11 00:41:03 --> Loader Class Initialized
INFO - 2022-03-11 00:41:03 --> Helper loaded: url_helper
INFO - 2022-03-11 00:41:03 --> Helper loaded: form_helper
INFO - 2022-03-11 00:41:03 --> Helper loaded: common_helper
INFO - 2022-03-11 00:41:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:41:03 --> Controller Class Initialized
INFO - 2022-03-11 00:41:03 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:41:03 --> Encrypt Class Initialized
INFO - 2022-03-11 00:41:03 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:41:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:41:03 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:41:03 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:41:03 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:41:03 --> Upload Class Initialized
INFO - 2022-03-11 00:41:03 --> Final output sent to browser
DEBUG - 2022-03-11 00:41:03 --> Total execution time: 0.0331
ERROR - 2022-03-11 00:41:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:10 --> Config Class Initialized
INFO - 2022-03-11 00:41:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:10 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:10 --> URI Class Initialized
INFO - 2022-03-11 00:41:10 --> Router Class Initialized
INFO - 2022-03-11 00:41:10 --> Output Class Initialized
INFO - 2022-03-11 00:41:10 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:10 --> Input Class Initialized
INFO - 2022-03-11 00:41:10 --> Language Class Initialized
INFO - 2022-03-11 00:41:10 --> Loader Class Initialized
INFO - 2022-03-11 00:41:10 --> Helper loaded: url_helper
INFO - 2022-03-11 00:41:10 --> Helper loaded: form_helper
INFO - 2022-03-11 00:41:10 --> Helper loaded: common_helper
INFO - 2022-03-11 00:41:10 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:41:10 --> Controller Class Initialized
INFO - 2022-03-11 00:41:10 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:41:10 --> Encrypt Class Initialized
INFO - 2022-03-11 00:41:10 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:41:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:41:10 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:41:10 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:41:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 00:41:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:10 --> Config Class Initialized
INFO - 2022-03-11 00:41:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:10 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:10 --> URI Class Initialized
INFO - 2022-03-11 00:41:10 --> Router Class Initialized
INFO - 2022-03-11 00:41:10 --> Output Class Initialized
INFO - 2022-03-11 00:41:10 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:10 --> Input Class Initialized
INFO - 2022-03-11 00:41:10 --> Language Class Initialized
INFO - 2022-03-11 00:41:10 --> Loader Class Initialized
INFO - 2022-03-11 00:41:10 --> Helper loaded: url_helper
INFO - 2022-03-11 00:41:10 --> Helper loaded: form_helper
INFO - 2022-03-11 00:41:10 --> Helper loaded: common_helper
INFO - 2022-03-11 00:41:10 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:41:10 --> Controller Class Initialized
INFO - 2022-03-11 00:41:10 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:41:10 --> Encrypt Class Initialized
INFO - 2022-03-11 00:41:10 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:41:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:41:10 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:41:10 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:41:10 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:41:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:41:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:41:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:41:11 --> Final output sent to browser
DEBUG - 2022-03-11 00:41:11 --> Total execution time: 0.0609
ERROR - 2022-03-11 00:41:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:11 --> Config Class Initialized
INFO - 2022-03-11 00:41:11 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:11 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:11 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:11 --> URI Class Initialized
INFO - 2022-03-11 00:41:11 --> Router Class Initialized
INFO - 2022-03-11 00:41:11 --> Output Class Initialized
INFO - 2022-03-11 00:41:11 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:11 --> Input Class Initialized
INFO - 2022-03-11 00:41:11 --> Language Class Initialized
ERROR - 2022-03-11 00:41:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:41:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:11 --> Config Class Initialized
INFO - 2022-03-11 00:41:11 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:11 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:11 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:11 --> URI Class Initialized
INFO - 2022-03-11 00:41:11 --> Router Class Initialized
INFO - 2022-03-11 00:41:11 --> Output Class Initialized
INFO - 2022-03-11 00:41:11 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:11 --> Input Class Initialized
INFO - 2022-03-11 00:41:11 --> Language Class Initialized
INFO - 2022-03-11 00:41:11 --> Loader Class Initialized
INFO - 2022-03-11 00:41:11 --> Helper loaded: url_helper
INFO - 2022-03-11 00:41:11 --> Helper loaded: form_helper
INFO - 2022-03-11 00:41:11 --> Helper loaded: common_helper
INFO - 2022-03-11 00:41:11 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:41:12 --> Controller Class Initialized
INFO - 2022-03-11 00:41:12 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:41:12 --> Encrypt Class Initialized
INFO - 2022-03-11 00:41:12 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:41:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:41:12 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:41:12 --> Model "Users_model" initialized
INFO - 2022-03-11 00:41:12 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:41:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:41:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:41:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:41:12 --> Final output sent to browser
DEBUG - 2022-03-11 00:41:12 --> Total execution time: 0.0632
ERROR - 2022-03-11 00:41:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:12 --> Config Class Initialized
INFO - 2022-03-11 00:41:12 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:12 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:12 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:12 --> URI Class Initialized
INFO - 2022-03-11 00:41:12 --> Router Class Initialized
INFO - 2022-03-11 00:41:12 --> Output Class Initialized
INFO - 2022-03-11 00:41:12 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:12 --> Input Class Initialized
INFO - 2022-03-11 00:41:12 --> Language Class Initialized
ERROR - 2022-03-11 00:41:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:41:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:40 --> Config Class Initialized
INFO - 2022-03-11 00:41:40 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:40 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:40 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:40 --> URI Class Initialized
INFO - 2022-03-11 00:41:40 --> Router Class Initialized
INFO - 2022-03-11 00:41:40 --> Output Class Initialized
INFO - 2022-03-11 00:41:40 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:40 --> Input Class Initialized
INFO - 2022-03-11 00:41:40 --> Language Class Initialized
INFO - 2022-03-11 00:41:40 --> Loader Class Initialized
INFO - 2022-03-11 00:41:40 --> Helper loaded: url_helper
INFO - 2022-03-11 00:41:40 --> Helper loaded: form_helper
INFO - 2022-03-11 00:41:40 --> Helper loaded: common_helper
INFO - 2022-03-11 00:41:40 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:41:40 --> Controller Class Initialized
INFO - 2022-03-11 00:41:40 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:41:40 --> Encrypt Class Initialized
INFO - 2022-03-11 00:41:40 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:41:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:41:40 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:41:40 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:41:40 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:41:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:41:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:41:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:41:40 --> Final output sent to browser
DEBUG - 2022-03-11 00:41:40 --> Total execution time: 0.0687
ERROR - 2022-03-11 00:41:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:41 --> Config Class Initialized
INFO - 2022-03-11 00:41:41 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:41 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:41 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:41 --> URI Class Initialized
INFO - 2022-03-11 00:41:41 --> Router Class Initialized
INFO - 2022-03-11 00:41:41 --> Output Class Initialized
INFO - 2022-03-11 00:41:41 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:41 --> Input Class Initialized
INFO - 2022-03-11 00:41:41 --> Language Class Initialized
ERROR - 2022-03-11 00:41:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:41:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:44 --> Config Class Initialized
INFO - 2022-03-11 00:41:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:44 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:44 --> URI Class Initialized
INFO - 2022-03-11 00:41:44 --> Router Class Initialized
INFO - 2022-03-11 00:41:44 --> Output Class Initialized
INFO - 2022-03-11 00:41:44 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:44 --> Input Class Initialized
INFO - 2022-03-11 00:41:44 --> Language Class Initialized
INFO - 2022-03-11 00:41:44 --> Loader Class Initialized
INFO - 2022-03-11 00:41:44 --> Helper loaded: url_helper
INFO - 2022-03-11 00:41:44 --> Helper loaded: form_helper
INFO - 2022-03-11 00:41:44 --> Helper loaded: common_helper
INFO - 2022-03-11 00:41:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:41:44 --> Controller Class Initialized
INFO - 2022-03-11 00:41:44 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:41:44 --> Encrypt Class Initialized
INFO - 2022-03-11 00:41:44 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:41:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:41:44 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:41:44 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:41:44 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:41:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:41:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:41:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 00:41:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:41:51 --> Config Class Initialized
INFO - 2022-03-11 00:41:51 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:41:51 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:41:51 --> Utf8 Class Initialized
INFO - 2022-03-11 00:41:51 --> URI Class Initialized
INFO - 2022-03-11 00:41:51 --> Router Class Initialized
INFO - 2022-03-11 00:41:51 --> Output Class Initialized
INFO - 2022-03-11 00:41:51 --> Security Class Initialized
DEBUG - 2022-03-11 00:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:41:51 --> Input Class Initialized
INFO - 2022-03-11 00:41:51 --> Language Class Initialized
ERROR - 2022-03-11 00:41:51 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 00:41:52 --> Final output sent to browser
DEBUG - 2022-03-11 00:41:52 --> Total execution time: 6.3112
ERROR - 2022-03-11 00:42:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:42:23 --> Config Class Initialized
INFO - 2022-03-11 00:42:23 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:42:23 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:42:23 --> Utf8 Class Initialized
INFO - 2022-03-11 00:42:23 --> URI Class Initialized
INFO - 2022-03-11 00:42:23 --> Router Class Initialized
INFO - 2022-03-11 00:42:23 --> Output Class Initialized
INFO - 2022-03-11 00:42:23 --> Security Class Initialized
DEBUG - 2022-03-11 00:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:42:23 --> Input Class Initialized
INFO - 2022-03-11 00:42:23 --> Language Class Initialized
INFO - 2022-03-11 00:42:23 --> Loader Class Initialized
INFO - 2022-03-11 00:42:23 --> Helper loaded: url_helper
INFO - 2022-03-11 00:42:23 --> Helper loaded: form_helper
INFO - 2022-03-11 00:42:23 --> Helper loaded: common_helper
INFO - 2022-03-11 00:42:23 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:42:23 --> Controller Class Initialized
INFO - 2022-03-11 00:42:23 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:42:23 --> Encrypt Class Initialized
INFO - 2022-03-11 00:42:23 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:42:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:42:23 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:42:23 --> Model "Users_model" initialized
INFO - 2022-03-11 00:42:23 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:42:24 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-11 00:42:24 --> Final output sent to browser
DEBUG - 2022-03-11 00:42:24 --> Total execution time: 1.1698
ERROR - 2022-03-11 00:43:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:43:37 --> Config Class Initialized
INFO - 2022-03-11 00:43:37 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:43:37 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:43:37 --> Utf8 Class Initialized
INFO - 2022-03-11 00:43:37 --> URI Class Initialized
INFO - 2022-03-11 00:43:37 --> Router Class Initialized
INFO - 2022-03-11 00:43:37 --> Output Class Initialized
INFO - 2022-03-11 00:43:37 --> Security Class Initialized
DEBUG - 2022-03-11 00:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:43:37 --> Input Class Initialized
INFO - 2022-03-11 00:43:37 --> Language Class Initialized
INFO - 2022-03-11 00:43:37 --> Loader Class Initialized
INFO - 2022-03-11 00:43:37 --> Helper loaded: url_helper
INFO - 2022-03-11 00:43:37 --> Helper loaded: form_helper
INFO - 2022-03-11 00:43:37 --> Helper loaded: common_helper
INFO - 2022-03-11 00:43:37 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:43:37 --> Controller Class Initialized
INFO - 2022-03-11 00:43:37 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:43:37 --> Encrypt Class Initialized
INFO - 2022-03-11 00:43:37 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:43:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:43:37 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:43:37 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:43:37 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:43:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:43:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:43:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:43:45 --> Final output sent to browser
DEBUG - 2022-03-11 00:43:45 --> Total execution time: 5.7821
ERROR - 2022-03-11 00:44:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:44:29 --> Config Class Initialized
INFO - 2022-03-11 00:44:29 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:44:29 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:44:29 --> Utf8 Class Initialized
INFO - 2022-03-11 00:44:29 --> URI Class Initialized
INFO - 2022-03-11 00:44:29 --> Router Class Initialized
INFO - 2022-03-11 00:44:29 --> Output Class Initialized
INFO - 2022-03-11 00:44:29 --> Security Class Initialized
DEBUG - 2022-03-11 00:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:44:29 --> Input Class Initialized
INFO - 2022-03-11 00:44:29 --> Language Class Initialized
INFO - 2022-03-11 00:44:29 --> Loader Class Initialized
INFO - 2022-03-11 00:44:29 --> Helper loaded: url_helper
INFO - 2022-03-11 00:44:29 --> Helper loaded: form_helper
INFO - 2022-03-11 00:44:29 --> Helper loaded: common_helper
INFO - 2022-03-11 00:44:29 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:44:29 --> Controller Class Initialized
INFO - 2022-03-11 00:44:29 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:44:29 --> Encrypt Class Initialized
INFO - 2022-03-11 00:44:29 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:44:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:44:29 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:44:29 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:44:29 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:44:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:44:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:44:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:44:29 --> Final output sent to browser
DEBUG - 2022-03-11 00:44:29 --> Total execution time: 0.0611
ERROR - 2022-03-11 00:44:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:44:30 --> Config Class Initialized
INFO - 2022-03-11 00:44:30 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:44:30 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:44:30 --> Utf8 Class Initialized
INFO - 2022-03-11 00:44:30 --> URI Class Initialized
INFO - 2022-03-11 00:44:30 --> Router Class Initialized
INFO - 2022-03-11 00:44:30 --> Output Class Initialized
INFO - 2022-03-11 00:44:30 --> Security Class Initialized
DEBUG - 2022-03-11 00:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:44:30 --> Input Class Initialized
INFO - 2022-03-11 00:44:30 --> Language Class Initialized
ERROR - 2022-03-11 00:44:30 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 00:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:53:26 --> Config Class Initialized
INFO - 2022-03-11 00:53:26 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:53:26 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:53:26 --> Utf8 Class Initialized
INFO - 2022-03-11 00:53:26 --> URI Class Initialized
INFO - 2022-03-11 00:53:26 --> Router Class Initialized
INFO - 2022-03-11 00:53:26 --> Output Class Initialized
INFO - 2022-03-11 00:53:26 --> Security Class Initialized
DEBUG - 2022-03-11 00:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:53:26 --> Input Class Initialized
INFO - 2022-03-11 00:53:26 --> Language Class Initialized
INFO - 2022-03-11 00:53:26 --> Loader Class Initialized
INFO - 2022-03-11 00:53:26 --> Helper loaded: url_helper
INFO - 2022-03-11 00:53:26 --> Helper loaded: form_helper
INFO - 2022-03-11 00:53:26 --> Helper loaded: common_helper
INFO - 2022-03-11 00:53:26 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:53:26 --> Controller Class Initialized
INFO - 2022-03-11 00:53:26 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:53:26 --> Encrypt Class Initialized
INFO - 2022-03-11 00:53:26 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:53:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:53:26 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:53:26 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:53:26 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:53:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:53:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:53:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:53:34 --> Final output sent to browser
DEBUG - 2022-03-11 00:53:34 --> Total execution time: 5.9217
ERROR - 2022-03-11 00:54:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:54:28 --> Config Class Initialized
INFO - 2022-03-11 00:54:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:54:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:54:28 --> Utf8 Class Initialized
INFO - 2022-03-11 00:54:28 --> URI Class Initialized
INFO - 2022-03-11 00:54:28 --> Router Class Initialized
INFO - 2022-03-11 00:54:28 --> Output Class Initialized
INFO - 2022-03-11 00:54:28 --> Security Class Initialized
DEBUG - 2022-03-11 00:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:54:28 --> Input Class Initialized
INFO - 2022-03-11 00:54:28 --> Language Class Initialized
INFO - 2022-03-11 00:54:28 --> Loader Class Initialized
INFO - 2022-03-11 00:54:28 --> Helper loaded: url_helper
INFO - 2022-03-11 00:54:28 --> Helper loaded: form_helper
INFO - 2022-03-11 00:54:28 --> Helper loaded: common_helper
INFO - 2022-03-11 00:54:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:54:28 --> Controller Class Initialized
INFO - 2022-03-11 00:54:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:54:28 --> Encrypt Class Initialized
INFO - 2022-03-11 00:54:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:54:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:54:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:54:28 --> Model "Users_model" initialized
INFO - 2022-03-11 00:54:28 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:54:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:54:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:54:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:54:29 --> Final output sent to browser
DEBUG - 2022-03-11 00:54:29 --> Total execution time: 0.0515
ERROR - 2022-03-11 00:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:54:35 --> Config Class Initialized
INFO - 2022-03-11 00:54:35 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:54:35 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:54:35 --> Utf8 Class Initialized
INFO - 2022-03-11 00:54:35 --> URI Class Initialized
INFO - 2022-03-11 00:54:35 --> Router Class Initialized
INFO - 2022-03-11 00:54:35 --> Output Class Initialized
INFO - 2022-03-11 00:54:35 --> Security Class Initialized
DEBUG - 2022-03-11 00:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:54:35 --> Input Class Initialized
INFO - 2022-03-11 00:54:35 --> Language Class Initialized
INFO - 2022-03-11 00:54:35 --> Loader Class Initialized
INFO - 2022-03-11 00:54:35 --> Helper loaded: url_helper
INFO - 2022-03-11 00:54:35 --> Helper loaded: form_helper
INFO - 2022-03-11 00:54:35 --> Helper loaded: common_helper
INFO - 2022-03-11 00:54:35 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:54:36 --> Controller Class Initialized
INFO - 2022-03-11 00:54:36 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:54:36 --> Encrypt Class Initialized
INFO - 2022-03-11 00:54:36 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:54:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:54:36 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:54:36 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:54:36 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:54:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-11 00:54:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:54:41 --> Config Class Initialized
INFO - 2022-03-11 00:54:41 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:54:41 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:54:41 --> Utf8 Class Initialized
INFO - 2022-03-11 00:54:41 --> URI Class Initialized
INFO - 2022-03-11 00:54:41 --> Router Class Initialized
INFO - 2022-03-11 00:54:41 --> Output Class Initialized
INFO - 2022-03-11 00:54:41 --> Security Class Initialized
DEBUG - 2022-03-11 00:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:54:41 --> Input Class Initialized
INFO - 2022-03-11 00:54:41 --> Language Class Initialized
INFO - 2022-03-11 00:54:41 --> Loader Class Initialized
INFO - 2022-03-11 00:54:41 --> Helper loaded: url_helper
INFO - 2022-03-11 00:54:41 --> Helper loaded: form_helper
INFO - 2022-03-11 00:54:41 --> Helper loaded: common_helper
INFO - 2022-03-11 00:54:41 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:54:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:54:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:54:43 --> Controller Class Initialized
INFO - 2022-03-11 00:54:43 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:54:43 --> Encrypt Class Initialized
INFO - 2022-03-11 00:54:43 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:54:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:54:43 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:54:43 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:54:43 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:54:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-11 00:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:54:44 --> Config Class Initialized
INFO - 2022-03-11 00:54:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:54:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:54:44 --> Utf8 Class Initialized
INFO - 2022-03-11 00:54:44 --> URI Class Initialized
INFO - 2022-03-11 00:54:44 --> Router Class Initialized
INFO - 2022-03-11 00:54:44 --> Output Class Initialized
INFO - 2022-03-11 00:54:44 --> Security Class Initialized
DEBUG - 2022-03-11 00:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:54:44 --> Input Class Initialized
INFO - 2022-03-11 00:54:44 --> Language Class Initialized
INFO - 2022-03-11 00:54:44 --> Loader Class Initialized
INFO - 2022-03-11 00:54:44 --> Helper loaded: url_helper
INFO - 2022-03-11 00:54:44 --> Helper loaded: form_helper
INFO - 2022-03-11 00:54:44 --> Helper loaded: common_helper
INFO - 2022-03-11 00:54:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:54:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:54:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:54:50 --> Controller Class Initialized
INFO - 2022-03-11 00:54:50 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:54:50 --> Encrypt Class Initialized
INFO - 2022-03-11 00:54:50 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:54:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:54:50 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:54:50 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:54:50 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:54:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:54:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:54:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:54:58 --> Final output sent to browser
DEBUG - 2022-03-11 00:54:58 --> Total execution time: 12.0511
ERROR - 2022-03-11 00:55:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:55:35 --> Config Class Initialized
INFO - 2022-03-11 00:55:35 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:55:35 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:55:35 --> Utf8 Class Initialized
INFO - 2022-03-11 00:55:35 --> URI Class Initialized
INFO - 2022-03-11 00:55:35 --> Router Class Initialized
INFO - 2022-03-11 00:55:35 --> Output Class Initialized
INFO - 2022-03-11 00:55:35 --> Security Class Initialized
DEBUG - 2022-03-11 00:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:55:35 --> Input Class Initialized
INFO - 2022-03-11 00:55:35 --> Language Class Initialized
INFO - 2022-03-11 00:55:35 --> Loader Class Initialized
INFO - 2022-03-11 00:55:35 --> Helper loaded: url_helper
INFO - 2022-03-11 00:55:35 --> Helper loaded: form_helper
INFO - 2022-03-11 00:55:35 --> Helper loaded: common_helper
INFO - 2022-03-11 00:55:35 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:55:35 --> Controller Class Initialized
INFO - 2022-03-11 00:55:35 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:55:35 --> Encrypt Class Initialized
INFO - 2022-03-11 00:55:35 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:55:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:55:35 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:55:35 --> Model "Users_model" initialized
INFO - 2022-03-11 00:55:35 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:55:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:55:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:55:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:55:35 --> Final output sent to browser
DEBUG - 2022-03-11 00:55:35 --> Total execution time: 0.0781
ERROR - 2022-03-11 00:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:55:36 --> Config Class Initialized
INFO - 2022-03-11 00:55:36 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:55:36 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:55:36 --> Utf8 Class Initialized
INFO - 2022-03-11 00:55:36 --> URI Class Initialized
INFO - 2022-03-11 00:55:36 --> Router Class Initialized
INFO - 2022-03-11 00:55:36 --> Output Class Initialized
INFO - 2022-03-11 00:55:36 --> Security Class Initialized
DEBUG - 2022-03-11 00:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:55:36 --> Input Class Initialized
INFO - 2022-03-11 00:55:36 --> Language Class Initialized
ERROR - 2022-03-11 00:55:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:55:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:55:42 --> Config Class Initialized
INFO - 2022-03-11 00:55:42 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:55:42 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:55:42 --> Utf8 Class Initialized
ERROR - 2022-03-11 00:56:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:56:36 --> Config Class Initialized
INFO - 2022-03-11 00:56:36 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:56:36 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:56:36 --> Utf8 Class Initialized
INFO - 2022-03-11 00:56:36 --> URI Class Initialized
INFO - 2022-03-11 00:56:36 --> Router Class Initialized
INFO - 2022-03-11 00:56:36 --> Output Class Initialized
INFO - 2022-03-11 00:56:36 --> Security Class Initialized
DEBUG - 2022-03-11 00:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:56:36 --> Input Class Initialized
INFO - 2022-03-11 00:56:36 --> Language Class Initialized
INFO - 2022-03-11 00:56:36 --> Loader Class Initialized
INFO - 2022-03-11 00:56:36 --> Helper loaded: url_helper
INFO - 2022-03-11 00:56:36 --> Helper loaded: form_helper
INFO - 2022-03-11 00:56:36 --> Helper loaded: common_helper
INFO - 2022-03-11 00:56:36 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:56:36 --> Controller Class Initialized
INFO - 2022-03-11 00:56:36 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:56:36 --> Encrypt Class Initialized
INFO - 2022-03-11 00:56:36 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:56:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:56:36 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:56:36 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:56:36 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:56:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:56:36 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 00:56:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:56:36 --> Final output sent to browser
DEBUG - 2022-03-11 00:56:36 --> Total execution time: 0.0464
ERROR - 2022-03-11 00:56:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:56:37 --> Config Class Initialized
INFO - 2022-03-11 00:56:37 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:56:37 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:56:37 --> Utf8 Class Initialized
INFO - 2022-03-11 00:56:37 --> URI Class Initialized
INFO - 2022-03-11 00:56:37 --> Router Class Initialized
INFO - 2022-03-11 00:56:37 --> Output Class Initialized
INFO - 2022-03-11 00:56:37 --> Security Class Initialized
DEBUG - 2022-03-11 00:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:56:37 --> Input Class Initialized
INFO - 2022-03-11 00:56:37 --> Language Class Initialized
ERROR - 2022-03-11 00:56:37 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:58:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:58:24 --> Config Class Initialized
INFO - 2022-03-11 00:58:24 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:58:24 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:58:24 --> Utf8 Class Initialized
INFO - 2022-03-11 00:58:24 --> URI Class Initialized
INFO - 2022-03-11 00:58:24 --> Router Class Initialized
INFO - 2022-03-11 00:58:24 --> Output Class Initialized
INFO - 2022-03-11 00:58:24 --> Security Class Initialized
DEBUG - 2022-03-11 00:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:58:24 --> Input Class Initialized
INFO - 2022-03-11 00:58:24 --> Language Class Initialized
INFO - 2022-03-11 00:58:24 --> Loader Class Initialized
INFO - 2022-03-11 00:58:24 --> Helper loaded: url_helper
INFO - 2022-03-11 00:58:24 --> Helper loaded: form_helper
INFO - 2022-03-11 00:58:24 --> Helper loaded: common_helper
INFO - 2022-03-11 00:58:24 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:58:24 --> Controller Class Initialized
INFO - 2022-03-11 00:58:24 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:58:24 --> Encrypt Class Initialized
INFO - 2022-03-11 00:58:24 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:58:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:58:24 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:58:24 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:58:24 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:58:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:58:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:58:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 00:58:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:58:30 --> Config Class Initialized
INFO - 2022-03-11 00:58:30 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:58:30 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:58:30 --> Utf8 Class Initialized
INFO - 2022-03-11 00:58:30 --> URI Class Initialized
INFO - 2022-03-11 00:58:30 --> Router Class Initialized
INFO - 2022-03-11 00:58:30 --> Output Class Initialized
INFO - 2022-03-11 00:58:30 --> Security Class Initialized
DEBUG - 2022-03-11 00:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:58:30 --> Input Class Initialized
INFO - 2022-03-11 00:58:30 --> Language Class Initialized
ERROR - 2022-03-11 00:58:30 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 00:58:32 --> Final output sent to browser
DEBUG - 2022-03-11 00:58:32 --> Total execution time: 5.4746
ERROR - 2022-03-11 00:59:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:59:15 --> Config Class Initialized
INFO - 2022-03-11 00:59:15 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:59:15 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:59:15 --> Utf8 Class Initialized
INFO - 2022-03-11 00:59:15 --> URI Class Initialized
INFO - 2022-03-11 00:59:15 --> Router Class Initialized
INFO - 2022-03-11 00:59:15 --> Output Class Initialized
INFO - 2022-03-11 00:59:15 --> Security Class Initialized
DEBUG - 2022-03-11 00:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:59:15 --> Input Class Initialized
INFO - 2022-03-11 00:59:15 --> Language Class Initialized
INFO - 2022-03-11 00:59:15 --> Loader Class Initialized
INFO - 2022-03-11 00:59:15 --> Helper loaded: url_helper
INFO - 2022-03-11 00:59:15 --> Helper loaded: form_helper
INFO - 2022-03-11 00:59:15 --> Helper loaded: common_helper
INFO - 2022-03-11 00:59:15 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:59:15 --> Controller Class Initialized
INFO - 2022-03-11 00:59:15 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:59:15 --> Encrypt Class Initialized
INFO - 2022-03-11 00:59:15 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:59:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:59:15 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:59:15 --> Model "Users_model" initialized
INFO - 2022-03-11 00:59:15 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:59:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:59:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 00:59:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 00:59:15 --> Final output sent to browser
DEBUG - 2022-03-11 00:59:15 --> Total execution time: 0.0616
ERROR - 2022-03-11 00:59:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:59:16 --> Config Class Initialized
INFO - 2022-03-11 00:59:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:59:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:59:16 --> Utf8 Class Initialized
INFO - 2022-03-11 00:59:16 --> URI Class Initialized
INFO - 2022-03-11 00:59:16 --> Router Class Initialized
INFO - 2022-03-11 00:59:16 --> Output Class Initialized
INFO - 2022-03-11 00:59:16 --> Security Class Initialized
DEBUG - 2022-03-11 00:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:59:16 --> Input Class Initialized
INFO - 2022-03-11 00:59:16 --> Language Class Initialized
ERROR - 2022-03-11 00:59:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 00:59:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:59:49 --> Config Class Initialized
INFO - 2022-03-11 00:59:49 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:59:49 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:59:49 --> Utf8 Class Initialized
INFO - 2022-03-11 00:59:49 --> URI Class Initialized
INFO - 2022-03-11 00:59:49 --> Router Class Initialized
INFO - 2022-03-11 00:59:49 --> Output Class Initialized
INFO - 2022-03-11 00:59:49 --> Security Class Initialized
DEBUG - 2022-03-11 00:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:59:49 --> Input Class Initialized
INFO - 2022-03-11 00:59:49 --> Language Class Initialized
INFO - 2022-03-11 00:59:49 --> Loader Class Initialized
INFO - 2022-03-11 00:59:49 --> Helper loaded: url_helper
INFO - 2022-03-11 00:59:49 --> Helper loaded: form_helper
INFO - 2022-03-11 00:59:49 --> Helper loaded: common_helper
INFO - 2022-03-11 00:59:49 --> Database Driver Class Initialized
DEBUG - 2022-03-11 00:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 00:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 00:59:49 --> Controller Class Initialized
INFO - 2022-03-11 00:59:49 --> Form Validation Class Initialized
DEBUG - 2022-03-11 00:59:49 --> Encrypt Class Initialized
INFO - 2022-03-11 00:59:49 --> Model "Patient_model" initialized
INFO - 2022-03-11 00:59:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 00:59:49 --> Model "Referredby_model" initialized
INFO - 2022-03-11 00:59:49 --> Model "Prefix_master" initialized
INFO - 2022-03-11 00:59:49 --> Model "Hospital_model" initialized
INFO - 2022-03-11 00:59:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 00:59:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 00:59:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 00:59:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 00:59:56 --> Config Class Initialized
INFO - 2022-03-11 00:59:56 --> Hooks Class Initialized
DEBUG - 2022-03-11 00:59:56 --> UTF-8 Support Enabled
INFO - 2022-03-11 00:59:56 --> Utf8 Class Initialized
INFO - 2022-03-11 00:59:56 --> URI Class Initialized
INFO - 2022-03-11 00:59:56 --> Router Class Initialized
INFO - 2022-03-11 00:59:56 --> Output Class Initialized
INFO - 2022-03-11 00:59:56 --> Security Class Initialized
DEBUG - 2022-03-11 00:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 00:59:56 --> Input Class Initialized
INFO - 2022-03-11 00:59:56 --> Language Class Initialized
ERROR - 2022-03-11 00:59:56 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 00:59:57 --> Final output sent to browser
DEBUG - 2022-03-11 00:59:57 --> Total execution time: 5.5291
ERROR - 2022-03-11 01:00:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:00:28 --> Config Class Initialized
INFO - 2022-03-11 01:00:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:00:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:00:28 --> Utf8 Class Initialized
INFO - 2022-03-11 01:00:28 --> URI Class Initialized
INFO - 2022-03-11 01:00:28 --> Router Class Initialized
INFO - 2022-03-11 01:00:28 --> Output Class Initialized
INFO - 2022-03-11 01:00:28 --> Security Class Initialized
DEBUG - 2022-03-11 01:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:00:28 --> Input Class Initialized
INFO - 2022-03-11 01:00:28 --> Language Class Initialized
INFO - 2022-03-11 01:00:28 --> Loader Class Initialized
INFO - 2022-03-11 01:00:28 --> Helper loaded: url_helper
INFO - 2022-03-11 01:00:28 --> Helper loaded: form_helper
INFO - 2022-03-11 01:00:28 --> Helper loaded: common_helper
INFO - 2022-03-11 01:00:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:00:28 --> Controller Class Initialized
INFO - 2022-03-11 01:00:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:00:28 --> Encrypt Class Initialized
INFO - 2022-03-11 01:00:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:00:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:00:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:00:28 --> Model "Users_model" initialized
INFO - 2022-03-11 01:00:28 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:00:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:00:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 01:00:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:00:28 --> Final output sent to browser
DEBUG - 2022-03-11 01:00:28 --> Total execution time: 0.0784
ERROR - 2022-03-11 01:00:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:00:29 --> Config Class Initialized
INFO - 2022-03-11 01:00:29 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:00:29 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:00:29 --> Utf8 Class Initialized
INFO - 2022-03-11 01:00:29 --> URI Class Initialized
INFO - 2022-03-11 01:00:29 --> Router Class Initialized
INFO - 2022-03-11 01:00:29 --> Output Class Initialized
INFO - 2022-03-11 01:00:29 --> Security Class Initialized
DEBUG - 2022-03-11 01:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:00:29 --> Input Class Initialized
INFO - 2022-03-11 01:00:29 --> Language Class Initialized
ERROR - 2022-03-11 01:00:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:00:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:00:36 --> Config Class Initialized
INFO - 2022-03-11 01:00:36 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:00:36 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:00:36 --> Utf8 Class Initialized
INFO - 2022-03-11 01:00:36 --> URI Class Initialized
INFO - 2022-03-11 01:00:36 --> Router Class Initialized
INFO - 2022-03-11 01:00:36 --> Output Class Initialized
INFO - 2022-03-11 01:00:36 --> Security Class Initialized
DEBUG - 2022-03-11 01:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:00:36 --> Input Class Initialized
INFO - 2022-03-11 01:00:36 --> Language Class Initialized
ERROR - 2022-03-11 01:00:36 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 01:01:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:01:03 --> Config Class Initialized
INFO - 2022-03-11 01:01:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:01:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:01:03 --> Utf8 Class Initialized
INFO - 2022-03-11 01:01:03 --> URI Class Initialized
INFO - 2022-03-11 01:01:03 --> Router Class Initialized
INFO - 2022-03-11 01:01:03 --> Output Class Initialized
INFO - 2022-03-11 01:01:03 --> Security Class Initialized
DEBUG - 2022-03-11 01:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:01:03 --> Input Class Initialized
INFO - 2022-03-11 01:01:03 --> Language Class Initialized
INFO - 2022-03-11 01:01:03 --> Loader Class Initialized
INFO - 2022-03-11 01:01:03 --> Helper loaded: url_helper
INFO - 2022-03-11 01:01:03 --> Helper loaded: form_helper
INFO - 2022-03-11 01:01:03 --> Helper loaded: common_helper
INFO - 2022-03-11 01:01:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:01:04 --> Controller Class Initialized
INFO - 2022-03-11 01:01:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:01:04 --> Encrypt Class Initialized
INFO - 2022-03-11 01:01:04 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:01:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:01:04 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:01:04 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:01:04 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:01:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:01:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:01:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:01:04 --> Final output sent to browser
DEBUG - 2022-03-11 01:01:04 --> Total execution time: 0.6299
ERROR - 2022-03-11 01:01:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:01:05 --> Config Class Initialized
INFO - 2022-03-11 01:01:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:01:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:01:05 --> Utf8 Class Initialized
INFO - 2022-03-11 01:01:05 --> URI Class Initialized
INFO - 2022-03-11 01:01:05 --> Router Class Initialized
INFO - 2022-03-11 01:01:05 --> Output Class Initialized
INFO - 2022-03-11 01:01:05 --> Security Class Initialized
DEBUG - 2022-03-11 01:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:01:05 --> Input Class Initialized
INFO - 2022-03-11 01:01:05 --> Language Class Initialized
ERROR - 2022-03-11 01:01:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:01:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:01:28 --> Config Class Initialized
INFO - 2022-03-11 01:01:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:01:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:01:28 --> Utf8 Class Initialized
INFO - 2022-03-11 01:01:28 --> URI Class Initialized
INFO - 2022-03-11 01:01:28 --> Router Class Initialized
INFO - 2022-03-11 01:01:28 --> Output Class Initialized
INFO - 2022-03-11 01:01:28 --> Security Class Initialized
DEBUG - 2022-03-11 01:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:01:28 --> Input Class Initialized
INFO - 2022-03-11 01:01:28 --> Language Class Initialized
INFO - 2022-03-11 01:01:28 --> Loader Class Initialized
INFO - 2022-03-11 01:01:28 --> Helper loaded: url_helper
INFO - 2022-03-11 01:01:28 --> Helper loaded: form_helper
INFO - 2022-03-11 01:01:28 --> Helper loaded: common_helper
INFO - 2022-03-11 01:01:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:01:28 --> Controller Class Initialized
INFO - 2022-03-11 01:01:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:01:28 --> Encrypt Class Initialized
INFO - 2022-03-11 01:01:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:01:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:01:28 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:01:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:01:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 01:01:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:01:29 --> Config Class Initialized
INFO - 2022-03-11 01:01:29 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:01:29 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:01:29 --> Utf8 Class Initialized
INFO - 2022-03-11 01:01:29 --> URI Class Initialized
INFO - 2022-03-11 01:01:29 --> Router Class Initialized
INFO - 2022-03-11 01:01:29 --> Output Class Initialized
INFO - 2022-03-11 01:01:29 --> Security Class Initialized
DEBUG - 2022-03-11 01:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:01:29 --> Input Class Initialized
INFO - 2022-03-11 01:01:29 --> Language Class Initialized
INFO - 2022-03-11 01:01:29 --> Loader Class Initialized
INFO - 2022-03-11 01:01:29 --> Helper loaded: url_helper
INFO - 2022-03-11 01:01:29 --> Helper loaded: form_helper
INFO - 2022-03-11 01:01:29 --> Helper loaded: common_helper
INFO - 2022-03-11 01:01:29 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:01:29 --> Controller Class Initialized
INFO - 2022-03-11 01:01:29 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:01:29 --> Encrypt Class Initialized
INFO - 2022-03-11 01:01:29 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:01:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:01:29 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:01:29 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:01:29 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:01:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:01:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:01:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:01:29 --> Final output sent to browser
DEBUG - 2022-03-11 01:01:29 --> Total execution time: 0.0691
ERROR - 2022-03-11 01:01:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:01:29 --> Config Class Initialized
INFO - 2022-03-11 01:01:29 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:01:29 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:01:29 --> Utf8 Class Initialized
INFO - 2022-03-11 01:01:29 --> URI Class Initialized
INFO - 2022-03-11 01:01:29 --> Router Class Initialized
INFO - 2022-03-11 01:01:29 --> Output Class Initialized
INFO - 2022-03-11 01:01:29 --> Security Class Initialized
DEBUG - 2022-03-11 01:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:01:29 --> Input Class Initialized
INFO - 2022-03-11 01:01:29 --> Language Class Initialized
INFO - 2022-03-11 01:01:29 --> Loader Class Initialized
INFO - 2022-03-11 01:01:29 --> Helper loaded: url_helper
INFO - 2022-03-11 01:01:29 --> Helper loaded: form_helper
INFO - 2022-03-11 01:01:29 --> Helper loaded: common_helper
INFO - 2022-03-11 01:01:29 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:01:29 --> Controller Class Initialized
INFO - 2022-03-11 01:01:29 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:01:29 --> Encrypt Class Initialized
INFO - 2022-03-11 01:01:29 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:01:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:01:29 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:01:29 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:01:29 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:01:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-11 01:01:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:01:32 --> Config Class Initialized
INFO - 2022-03-11 01:01:32 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:01:32 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:01:32 --> Utf8 Class Initialized
INFO - 2022-03-11 01:01:32 --> URI Class Initialized
INFO - 2022-03-11 01:01:32 --> Router Class Initialized
INFO - 2022-03-11 01:01:32 --> Output Class Initialized
INFO - 2022-03-11 01:01:32 --> Security Class Initialized
DEBUG - 2022-03-11 01:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:01:32 --> Input Class Initialized
INFO - 2022-03-11 01:01:32 --> Language Class Initialized
INFO - 2022-03-11 01:01:32 --> Loader Class Initialized
INFO - 2022-03-11 01:01:32 --> Helper loaded: url_helper
INFO - 2022-03-11 01:01:32 --> Helper loaded: form_helper
INFO - 2022-03-11 01:01:32 --> Helper loaded: common_helper
INFO - 2022-03-11 01:01:32 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:01:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:01:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:01:38 --> Controller Class Initialized
INFO - 2022-03-11 01:01:38 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:01:38 --> Encrypt Class Initialized
INFO - 2022-03-11 01:01:38 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:01:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:01:38 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:01:38 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:01:38 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:01:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-11 01:01:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:01:38 --> Config Class Initialized
INFO - 2022-03-11 01:01:38 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:01:38 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:01:38 --> Utf8 Class Initialized
INFO - 2022-03-11 01:01:38 --> URI Class Initialized
INFO - 2022-03-11 01:01:38 --> Router Class Initialized
INFO - 2022-03-11 01:01:38 --> Output Class Initialized
INFO - 2022-03-11 01:01:38 --> Security Class Initialized
DEBUG - 2022-03-11 01:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:01:38 --> Input Class Initialized
INFO - 2022-03-11 01:01:38 --> Language Class Initialized
INFO - 2022-03-11 01:01:38 --> Loader Class Initialized
INFO - 2022-03-11 01:01:38 --> Helper loaded: url_helper
INFO - 2022-03-11 01:01:38 --> Helper loaded: form_helper
INFO - 2022-03-11 01:01:38 --> Helper loaded: common_helper
INFO - 2022-03-11 01:01:38 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:01:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:01:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:01:45 --> Controller Class Initialized
INFO - 2022-03-11 01:01:45 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:01:45 --> Encrypt Class Initialized
INFO - 2022-03-11 01:01:45 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:01:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:01:45 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:01:45 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:01:45 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:01:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:01:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:01:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 01:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:01:54 --> Config Class Initialized
INFO - 2022-03-11 01:01:54 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:01:54 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:01:54 --> Utf8 Class Initialized
INFO - 2022-03-11 01:01:54 --> URI Class Initialized
INFO - 2022-03-11 01:01:54 --> Router Class Initialized
INFO - 2022-03-11 01:01:54 --> Output Class Initialized
INFO - 2022-03-11 01:01:54 --> Security Class Initialized
DEBUG - 2022-03-11 01:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:01:54 --> Input Class Initialized
INFO - 2022-03-11 01:01:54 --> Language Class Initialized
ERROR - 2022-03-11 01:01:54 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 01:01:56 --> Final output sent to browser
DEBUG - 2022-03-11 01:01:56 --> Total execution time: 15.3849
ERROR - 2022-03-11 01:02:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:02:26 --> Config Class Initialized
INFO - 2022-03-11 01:02:26 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:02:26 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:02:26 --> Utf8 Class Initialized
INFO - 2022-03-11 01:02:26 --> URI Class Initialized
INFO - 2022-03-11 01:02:26 --> Router Class Initialized
INFO - 2022-03-11 01:02:26 --> Output Class Initialized
INFO - 2022-03-11 01:02:26 --> Security Class Initialized
DEBUG - 2022-03-11 01:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:02:26 --> Input Class Initialized
INFO - 2022-03-11 01:02:26 --> Language Class Initialized
INFO - 2022-03-11 01:02:26 --> Loader Class Initialized
INFO - 2022-03-11 01:02:26 --> Helper loaded: url_helper
INFO - 2022-03-11 01:02:26 --> Helper loaded: form_helper
INFO - 2022-03-11 01:02:26 --> Helper loaded: common_helper
INFO - 2022-03-11 01:02:26 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:02:26 --> Controller Class Initialized
INFO - 2022-03-11 01:02:26 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:02:26 --> Encrypt Class Initialized
INFO - 2022-03-11 01:02:26 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:02:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:02:26 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:02:26 --> Model "Users_model" initialized
INFO - 2022-03-11 01:02:26 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:02:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:02:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 01:02:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:02:26 --> Final output sent to browser
DEBUG - 2022-03-11 01:02:26 --> Total execution time: 0.0673
ERROR - 2022-03-11 01:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:02:27 --> Config Class Initialized
INFO - 2022-03-11 01:02:27 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:02:27 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:02:27 --> Utf8 Class Initialized
INFO - 2022-03-11 01:02:27 --> URI Class Initialized
INFO - 2022-03-11 01:02:27 --> Router Class Initialized
INFO - 2022-03-11 01:02:27 --> Output Class Initialized
INFO - 2022-03-11 01:02:27 --> Security Class Initialized
DEBUG - 2022-03-11 01:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:02:27 --> Input Class Initialized
INFO - 2022-03-11 01:02:27 --> Language Class Initialized
ERROR - 2022-03-11 01:02:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:03:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:03:02 --> Config Class Initialized
INFO - 2022-03-11 01:03:02 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:03:02 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:03:02 --> Utf8 Class Initialized
INFO - 2022-03-11 01:03:02 --> URI Class Initialized
INFO - 2022-03-11 01:03:02 --> Router Class Initialized
INFO - 2022-03-11 01:03:02 --> Output Class Initialized
INFO - 2022-03-11 01:03:02 --> Security Class Initialized
DEBUG - 2022-03-11 01:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:03:02 --> Input Class Initialized
INFO - 2022-03-11 01:03:02 --> Language Class Initialized
INFO - 2022-03-11 01:03:02 --> Loader Class Initialized
INFO - 2022-03-11 01:03:02 --> Helper loaded: url_helper
INFO - 2022-03-11 01:03:02 --> Helper loaded: form_helper
INFO - 2022-03-11 01:03:02 --> Helper loaded: common_helper
INFO - 2022-03-11 01:03:02 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:03:02 --> Controller Class Initialized
INFO - 2022-03-11 01:03:02 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:03:02 --> Encrypt Class Initialized
INFO - 2022-03-11 01:03:02 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:03:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:03:02 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:03:02 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:03:02 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:03:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:03:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:03:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 01:03:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:03:11 --> Config Class Initialized
INFO - 2022-03-11 01:03:11 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:03:11 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:03:11 --> Utf8 Class Initialized
INFO - 2022-03-11 01:03:11 --> URI Class Initialized
INFO - 2022-03-11 01:03:11 --> Router Class Initialized
INFO - 2022-03-11 01:03:11 --> Output Class Initialized
INFO - 2022-03-11 01:03:11 --> Security Class Initialized
DEBUG - 2022-03-11 01:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:03:11 --> Input Class Initialized
INFO - 2022-03-11 01:03:11 --> Language Class Initialized
ERROR - 2022-03-11 01:03:11 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 01:03:12 --> Final output sent to browser
DEBUG - 2022-03-11 01:03:12 --> Total execution time: 7.3135
ERROR - 2022-03-11 01:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:05:02 --> Config Class Initialized
INFO - 2022-03-11 01:05:02 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:05:02 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:05:02 --> Utf8 Class Initialized
INFO - 2022-03-11 01:05:02 --> URI Class Initialized
INFO - 2022-03-11 01:05:02 --> Router Class Initialized
INFO - 2022-03-11 01:05:02 --> Output Class Initialized
INFO - 2022-03-11 01:05:02 --> Security Class Initialized
DEBUG - 2022-03-11 01:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:05:02 --> Input Class Initialized
INFO - 2022-03-11 01:05:02 --> Language Class Initialized
INFO - 2022-03-11 01:05:02 --> Loader Class Initialized
INFO - 2022-03-11 01:05:02 --> Helper loaded: url_helper
INFO - 2022-03-11 01:05:02 --> Helper loaded: form_helper
INFO - 2022-03-11 01:05:02 --> Helper loaded: common_helper
INFO - 2022-03-11 01:05:02 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:05:02 --> Controller Class Initialized
INFO - 2022-03-11 01:05:02 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:05:02 --> Encrypt Class Initialized
INFO - 2022-03-11 01:05:02 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:05:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:05:02 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:05:02 --> Model "Users_model" initialized
INFO - 2022-03-11 01:05:02 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:05:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:05:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 01:05:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:05:02 --> Final output sent to browser
DEBUG - 2022-03-11 01:05:02 --> Total execution time: 0.0762
ERROR - 2022-03-11 01:05:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:05:03 --> Config Class Initialized
INFO - 2022-03-11 01:05:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:05:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:05:03 --> Utf8 Class Initialized
INFO - 2022-03-11 01:05:03 --> URI Class Initialized
INFO - 2022-03-11 01:05:03 --> Router Class Initialized
INFO - 2022-03-11 01:05:03 --> Output Class Initialized
INFO - 2022-03-11 01:05:03 --> Security Class Initialized
DEBUG - 2022-03-11 01:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:05:03 --> Input Class Initialized
INFO - 2022-03-11 01:05:03 --> Language Class Initialized
ERROR - 2022-03-11 01:05:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:06:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:06:27 --> Config Class Initialized
INFO - 2022-03-11 01:06:27 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:06:27 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:06:27 --> Utf8 Class Initialized
INFO - 2022-03-11 01:06:27 --> URI Class Initialized
INFO - 2022-03-11 01:06:27 --> Router Class Initialized
INFO - 2022-03-11 01:06:27 --> Output Class Initialized
INFO - 2022-03-11 01:06:27 --> Security Class Initialized
DEBUG - 2022-03-11 01:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:06:27 --> Input Class Initialized
INFO - 2022-03-11 01:06:27 --> Language Class Initialized
INFO - 2022-03-11 01:06:27 --> Loader Class Initialized
INFO - 2022-03-11 01:06:27 --> Helper loaded: url_helper
INFO - 2022-03-11 01:06:27 --> Helper loaded: form_helper
INFO - 2022-03-11 01:06:27 --> Helper loaded: common_helper
INFO - 2022-03-11 01:06:27 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:06:27 --> Controller Class Initialized
INFO - 2022-03-11 01:06:27 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:06:27 --> Encrypt Class Initialized
INFO - 2022-03-11 01:06:27 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:06:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:06:27 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:06:27 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:06:27 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:06:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:06:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:06:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 01:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:06:34 --> Config Class Initialized
INFO - 2022-03-11 01:06:34 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:06:34 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:06:34 --> Utf8 Class Initialized
INFO - 2022-03-11 01:06:34 --> URI Class Initialized
INFO - 2022-03-11 01:06:34 --> Router Class Initialized
INFO - 2022-03-11 01:06:34 --> Output Class Initialized
INFO - 2022-03-11 01:06:34 --> Security Class Initialized
DEBUG - 2022-03-11 01:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:06:34 --> Input Class Initialized
INFO - 2022-03-11 01:06:34 --> Language Class Initialized
ERROR - 2022-03-11 01:06:34 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 01:06:35 --> Final output sent to browser
DEBUG - 2022-03-11 01:06:35 --> Total execution time: 6.3344
ERROR - 2022-03-11 01:06:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:06:50 --> Config Class Initialized
INFO - 2022-03-11 01:06:50 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:06:50 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:06:50 --> Utf8 Class Initialized
INFO - 2022-03-11 01:06:50 --> URI Class Initialized
INFO - 2022-03-11 01:06:50 --> Router Class Initialized
INFO - 2022-03-11 01:06:50 --> Output Class Initialized
INFO - 2022-03-11 01:06:50 --> Security Class Initialized
DEBUG - 2022-03-11 01:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:06:50 --> Input Class Initialized
INFO - 2022-03-11 01:06:50 --> Language Class Initialized
INFO - 2022-03-11 01:06:50 --> Loader Class Initialized
INFO - 2022-03-11 01:06:50 --> Helper loaded: url_helper
INFO - 2022-03-11 01:06:50 --> Helper loaded: form_helper
INFO - 2022-03-11 01:06:50 --> Helper loaded: common_helper
INFO - 2022-03-11 01:06:51 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:06:51 --> Controller Class Initialized
INFO - 2022-03-11 01:06:51 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:06:51 --> Encrypt Class Initialized
INFO - 2022-03-11 01:06:51 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:06:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:06:51 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:06:51 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:06:51 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:06:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:06:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:06:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:06:51 --> Final output sent to browser
DEBUG - 2022-03-11 01:06:51 --> Total execution time: 0.0742
ERROR - 2022-03-11 01:06:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:06:51 --> Config Class Initialized
INFO - 2022-03-11 01:06:51 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:06:51 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:06:51 --> Utf8 Class Initialized
INFO - 2022-03-11 01:06:51 --> URI Class Initialized
INFO - 2022-03-11 01:06:51 --> Router Class Initialized
INFO - 2022-03-11 01:06:51 --> Output Class Initialized
INFO - 2022-03-11 01:06:51 --> Security Class Initialized
DEBUG - 2022-03-11 01:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:06:51 --> Input Class Initialized
INFO - 2022-03-11 01:06:51 --> Language Class Initialized
ERROR - 2022-03-11 01:06:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:06:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:06:51 --> Config Class Initialized
INFO - 2022-03-11 01:06:51 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:06:51 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:06:51 --> Utf8 Class Initialized
INFO - 2022-03-11 01:06:51 --> URI Class Initialized
INFO - 2022-03-11 01:06:51 --> Router Class Initialized
INFO - 2022-03-11 01:06:51 --> Output Class Initialized
INFO - 2022-03-11 01:06:51 --> Security Class Initialized
DEBUG - 2022-03-11 01:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:06:51 --> Input Class Initialized
INFO - 2022-03-11 01:06:51 --> Language Class Initialized
ERROR - 2022-03-11 01:06:51 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 01:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:07:00 --> Config Class Initialized
INFO - 2022-03-11 01:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:07:00 --> Utf8 Class Initialized
INFO - 2022-03-11 01:07:00 --> URI Class Initialized
INFO - 2022-03-11 01:07:00 --> Router Class Initialized
INFO - 2022-03-11 01:07:00 --> Output Class Initialized
INFO - 2022-03-11 01:07:00 --> Security Class Initialized
DEBUG - 2022-03-11 01:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:07:00 --> Input Class Initialized
INFO - 2022-03-11 01:07:00 --> Language Class Initialized
INFO - 2022-03-11 01:07:00 --> Loader Class Initialized
INFO - 2022-03-11 01:07:00 --> Helper loaded: url_helper
INFO - 2022-03-11 01:07:00 --> Helper loaded: form_helper
INFO - 2022-03-11 01:07:00 --> Helper loaded: common_helper
INFO - 2022-03-11 01:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:07:00 --> Controller Class Initialized
INFO - 2022-03-11 01:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:07:00 --> Encrypt Class Initialized
INFO - 2022-03-11 01:07:00 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:07:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:07:00 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:07:00 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:07:00 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:07:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:07:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:07:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:07:00 --> Final output sent to browser
DEBUG - 2022-03-11 01:07:00 --> Total execution time: 0.0423
ERROR - 2022-03-11 01:07:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:07:04 --> Config Class Initialized
INFO - 2022-03-11 01:07:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:07:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:07:04 --> Utf8 Class Initialized
INFO - 2022-03-11 01:07:04 --> URI Class Initialized
INFO - 2022-03-11 01:07:04 --> Router Class Initialized
INFO - 2022-03-11 01:07:04 --> Output Class Initialized
INFO - 2022-03-11 01:07:04 --> Security Class Initialized
DEBUG - 2022-03-11 01:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:07:04 --> Input Class Initialized
INFO - 2022-03-11 01:07:04 --> Language Class Initialized
INFO - 2022-03-11 01:07:04 --> Loader Class Initialized
INFO - 2022-03-11 01:07:04 --> Helper loaded: url_helper
INFO - 2022-03-11 01:07:04 --> Helper loaded: form_helper
INFO - 2022-03-11 01:07:04 --> Helper loaded: common_helper
INFO - 2022-03-11 01:07:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:07:04 --> Controller Class Initialized
INFO - 2022-03-11 01:07:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:07:04 --> Encrypt Class Initialized
INFO - 2022-03-11 01:07:04 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:07:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:07:04 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:07:04 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:07:04 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:07:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-11 01:07:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:07:07 --> Config Class Initialized
INFO - 2022-03-11 01:07:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:07:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:07:07 --> Utf8 Class Initialized
INFO - 2022-03-11 01:07:07 --> URI Class Initialized
INFO - 2022-03-11 01:07:07 --> Router Class Initialized
INFO - 2022-03-11 01:07:07 --> Output Class Initialized
INFO - 2022-03-11 01:07:07 --> Security Class Initialized
DEBUG - 2022-03-11 01:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:07:07 --> Input Class Initialized
INFO - 2022-03-11 01:07:07 --> Language Class Initialized
INFO - 2022-03-11 01:07:07 --> Loader Class Initialized
INFO - 2022-03-11 01:07:07 --> Helper loaded: url_helper
INFO - 2022-03-11 01:07:07 --> Helper loaded: form_helper
INFO - 2022-03-11 01:07:07 --> Helper loaded: common_helper
INFO - 2022-03-11 01:07:07 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:07:07 --> Controller Class Initialized
INFO - 2022-03-11 01:07:07 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:07:07 --> Encrypt Class Initialized
INFO - 2022-03-11 01:07:07 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:07:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:07:07 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:07:07 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:07:07 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:07:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:07:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:07:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 01:07:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:07:13 --> Config Class Initialized
INFO - 2022-03-11 01:07:13 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:07:13 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:07:13 --> Utf8 Class Initialized
INFO - 2022-03-11 01:07:13 --> URI Class Initialized
INFO - 2022-03-11 01:07:13 --> Router Class Initialized
INFO - 2022-03-11 01:07:13 --> Output Class Initialized
INFO - 2022-03-11 01:07:13 --> Security Class Initialized
DEBUG - 2022-03-11 01:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:07:13 --> Input Class Initialized
INFO - 2022-03-11 01:07:13 --> Language Class Initialized
ERROR - 2022-03-11 01:07:13 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 01:07:14 --> Final output sent to browser
DEBUG - 2022-03-11 01:07:14 --> Total execution time: 7.5445
INFO - 2022-03-11 01:07:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:07:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:07:17 --> Final output sent to browser
DEBUG - 2022-03-11 01:07:17 --> Total execution time: 8.0003
ERROR - 2022-03-11 01:07:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:07:39 --> Config Class Initialized
INFO - 2022-03-11 01:07:39 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:07:39 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:07:39 --> Utf8 Class Initialized
INFO - 2022-03-11 01:07:39 --> URI Class Initialized
INFO - 2022-03-11 01:07:39 --> Router Class Initialized
INFO - 2022-03-11 01:07:39 --> Output Class Initialized
INFO - 2022-03-11 01:07:39 --> Security Class Initialized
DEBUG - 2022-03-11 01:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:07:39 --> Input Class Initialized
INFO - 2022-03-11 01:07:39 --> Language Class Initialized
INFO - 2022-03-11 01:07:39 --> Loader Class Initialized
INFO - 2022-03-11 01:07:39 --> Helper loaded: url_helper
INFO - 2022-03-11 01:07:39 --> Helper loaded: form_helper
INFO - 2022-03-11 01:07:39 --> Helper loaded: common_helper
INFO - 2022-03-11 01:07:39 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:07:39 --> Controller Class Initialized
INFO - 2022-03-11 01:07:39 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:07:39 --> Encrypt Class Initialized
INFO - 2022-03-11 01:07:39 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:07:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:07:39 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:07:39 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:07:39 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:07:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:07:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:07:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:07:39 --> Final output sent to browser
DEBUG - 2022-03-11 01:07:39 --> Total execution time: 0.0542
ERROR - 2022-03-11 01:07:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:07:39 --> Config Class Initialized
INFO - 2022-03-11 01:07:39 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:07:39 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:07:39 --> Utf8 Class Initialized
INFO - 2022-03-11 01:07:39 --> URI Class Initialized
INFO - 2022-03-11 01:07:39 --> Router Class Initialized
INFO - 2022-03-11 01:07:39 --> Output Class Initialized
INFO - 2022-03-11 01:07:39 --> Security Class Initialized
DEBUG - 2022-03-11 01:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:07:39 --> Input Class Initialized
INFO - 2022-03-11 01:07:39 --> Language Class Initialized
ERROR - 2022-03-11 01:07:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:07:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:07:39 --> Config Class Initialized
INFO - 2022-03-11 01:07:39 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:07:39 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:07:39 --> Utf8 Class Initialized
INFO - 2022-03-11 01:07:39 --> URI Class Initialized
INFO - 2022-03-11 01:07:39 --> Router Class Initialized
INFO - 2022-03-11 01:07:39 --> Output Class Initialized
INFO - 2022-03-11 01:07:39 --> Security Class Initialized
DEBUG - 2022-03-11 01:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:07:39 --> Input Class Initialized
INFO - 2022-03-11 01:07:39 --> Language Class Initialized
ERROR - 2022-03-11 01:07:39 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 01:07:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:07:44 --> Config Class Initialized
INFO - 2022-03-11 01:07:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:07:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:07:44 --> Utf8 Class Initialized
INFO - 2022-03-11 01:07:44 --> URI Class Initialized
INFO - 2022-03-11 01:07:44 --> Router Class Initialized
INFO - 2022-03-11 01:07:44 --> Output Class Initialized
INFO - 2022-03-11 01:07:44 --> Security Class Initialized
DEBUG - 2022-03-11 01:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:07:44 --> Input Class Initialized
INFO - 2022-03-11 01:07:44 --> Language Class Initialized
INFO - 2022-03-11 01:07:44 --> Loader Class Initialized
INFO - 2022-03-11 01:07:44 --> Helper loaded: url_helper
INFO - 2022-03-11 01:07:44 --> Helper loaded: form_helper
INFO - 2022-03-11 01:07:44 --> Helper loaded: common_helper
INFO - 2022-03-11 01:07:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:07:44 --> Controller Class Initialized
INFO - 2022-03-11 01:07:44 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:07:44 --> Encrypt Class Initialized
INFO - 2022-03-11 01:07:44 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:07:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:07:44 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:07:44 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:07:44 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:07:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:07:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:07:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:07:56 --> Final output sent to browser
DEBUG - 2022-03-11 01:07:56 --> Total execution time: 10.3541
ERROR - 2022-03-11 01:08:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:08:29 --> Config Class Initialized
INFO - 2022-03-11 01:08:29 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:08:29 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:08:29 --> Utf8 Class Initialized
INFO - 2022-03-11 01:08:29 --> URI Class Initialized
INFO - 2022-03-11 01:08:29 --> Router Class Initialized
INFO - 2022-03-11 01:08:29 --> Output Class Initialized
INFO - 2022-03-11 01:08:29 --> Security Class Initialized
DEBUG - 2022-03-11 01:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:08:29 --> Input Class Initialized
INFO - 2022-03-11 01:08:29 --> Language Class Initialized
INFO - 2022-03-11 01:08:29 --> Loader Class Initialized
INFO - 2022-03-11 01:08:29 --> Helper loaded: url_helper
INFO - 2022-03-11 01:08:29 --> Helper loaded: form_helper
INFO - 2022-03-11 01:08:29 --> Helper loaded: common_helper
INFO - 2022-03-11 01:08:29 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:08:29 --> Controller Class Initialized
INFO - 2022-03-11 01:08:29 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:08:29 --> Encrypt Class Initialized
INFO - 2022-03-11 01:08:29 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:08:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:08:29 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:08:29 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:08:29 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:08:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:08:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:08:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:08:29 --> Final output sent to browser
DEBUG - 2022-03-11 01:08:29 --> Total execution time: 0.0392
ERROR - 2022-03-11 01:08:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:08:30 --> Config Class Initialized
INFO - 2022-03-11 01:08:30 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:08:30 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:08:30 --> Utf8 Class Initialized
INFO - 2022-03-11 01:08:30 --> URI Class Initialized
INFO - 2022-03-11 01:08:30 --> Router Class Initialized
INFO - 2022-03-11 01:08:30 --> Output Class Initialized
INFO - 2022-03-11 01:08:30 --> Security Class Initialized
DEBUG - 2022-03-11 01:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:08:30 --> Input Class Initialized
INFO - 2022-03-11 01:08:30 --> Language Class Initialized
ERROR - 2022-03-11 01:08:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:08:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:08:30 --> Config Class Initialized
INFO - 2022-03-11 01:08:30 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:08:30 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:08:30 --> Utf8 Class Initialized
INFO - 2022-03-11 01:08:30 --> URI Class Initialized
INFO - 2022-03-11 01:08:30 --> Router Class Initialized
INFO - 2022-03-11 01:08:30 --> Output Class Initialized
INFO - 2022-03-11 01:08:30 --> Security Class Initialized
DEBUG - 2022-03-11 01:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:08:30 --> Input Class Initialized
INFO - 2022-03-11 01:08:30 --> Language Class Initialized
ERROR - 2022-03-11 01:08:30 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 01:08:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:08:57 --> Config Class Initialized
INFO - 2022-03-11 01:08:57 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:08:57 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:08:57 --> Utf8 Class Initialized
INFO - 2022-03-11 01:08:57 --> URI Class Initialized
INFO - 2022-03-11 01:08:57 --> Router Class Initialized
INFO - 2022-03-11 01:08:57 --> Output Class Initialized
INFO - 2022-03-11 01:08:57 --> Security Class Initialized
DEBUG - 2022-03-11 01:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:08:57 --> Input Class Initialized
INFO - 2022-03-11 01:08:57 --> Language Class Initialized
INFO - 2022-03-11 01:08:57 --> Loader Class Initialized
INFO - 2022-03-11 01:08:57 --> Helper loaded: url_helper
INFO - 2022-03-11 01:08:57 --> Helper loaded: form_helper
INFO - 2022-03-11 01:08:57 --> Helper loaded: common_helper
INFO - 2022-03-11 01:08:57 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:08:57 --> Controller Class Initialized
INFO - 2022-03-11 01:08:57 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:08:57 --> Encrypt Class Initialized
INFO - 2022-03-11 01:08:57 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:08:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:08:57 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:08:57 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:08:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 01:08:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:08:58 --> Config Class Initialized
INFO - 2022-03-11 01:08:58 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:08:58 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:08:58 --> Utf8 Class Initialized
INFO - 2022-03-11 01:08:58 --> URI Class Initialized
INFO - 2022-03-11 01:08:58 --> Router Class Initialized
INFO - 2022-03-11 01:08:58 --> Output Class Initialized
INFO - 2022-03-11 01:08:58 --> Security Class Initialized
DEBUG - 2022-03-11 01:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:08:58 --> Input Class Initialized
INFO - 2022-03-11 01:08:58 --> Language Class Initialized
INFO - 2022-03-11 01:08:58 --> Loader Class Initialized
INFO - 2022-03-11 01:08:58 --> Helper loaded: url_helper
INFO - 2022-03-11 01:08:58 --> Helper loaded: form_helper
INFO - 2022-03-11 01:08:58 --> Helper loaded: common_helper
INFO - 2022-03-11 01:08:58 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:08:58 --> Controller Class Initialized
INFO - 2022-03-11 01:08:58 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:08:58 --> Encrypt Class Initialized
INFO - 2022-03-11 01:08:58 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:08:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:08:58 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:08:58 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:08:58 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:08:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:08:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:08:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:08:58 --> Final output sent to browser
DEBUG - 2022-03-11 01:08:58 --> Total execution time: 0.0555
ERROR - 2022-03-11 01:08:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:08:58 --> Config Class Initialized
INFO - 2022-03-11 01:08:58 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:08:58 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:08:58 --> Utf8 Class Initialized
INFO - 2022-03-11 01:08:58 --> URI Class Initialized
INFO - 2022-03-11 01:08:58 --> Router Class Initialized
INFO - 2022-03-11 01:08:58 --> Output Class Initialized
INFO - 2022-03-11 01:08:58 --> Security Class Initialized
DEBUG - 2022-03-11 01:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:08:58 --> Input Class Initialized
INFO - 2022-03-11 01:08:58 --> Language Class Initialized
ERROR - 2022-03-11 01:08:58 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 01:08:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:08:58 --> Config Class Initialized
INFO - 2022-03-11 01:08:58 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:08:58 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:08:58 --> Utf8 Class Initialized
INFO - 2022-03-11 01:08:58 --> URI Class Initialized
INFO - 2022-03-11 01:08:58 --> Router Class Initialized
INFO - 2022-03-11 01:08:58 --> Output Class Initialized
INFO - 2022-03-11 01:08:58 --> Security Class Initialized
DEBUG - 2022-03-11 01:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:08:58 --> Input Class Initialized
INFO - 2022-03-11 01:08:58 --> Language Class Initialized
ERROR - 2022-03-11 01:08:58 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:08:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:08:59 --> Config Class Initialized
INFO - 2022-03-11 01:08:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:08:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:08:59 --> Utf8 Class Initialized
INFO - 2022-03-11 01:08:59 --> URI Class Initialized
INFO - 2022-03-11 01:08:59 --> Router Class Initialized
INFO - 2022-03-11 01:08:59 --> Output Class Initialized
INFO - 2022-03-11 01:08:59 --> Security Class Initialized
DEBUG - 2022-03-11 01:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:08:59 --> Input Class Initialized
INFO - 2022-03-11 01:08:59 --> Language Class Initialized
INFO - 2022-03-11 01:08:59 --> Loader Class Initialized
INFO - 2022-03-11 01:08:59 --> Helper loaded: url_helper
INFO - 2022-03-11 01:08:59 --> Helper loaded: form_helper
INFO - 2022-03-11 01:08:59 --> Helper loaded: common_helper
INFO - 2022-03-11 01:08:59 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:08:59 --> Controller Class Initialized
INFO - 2022-03-11 01:08:59 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:08:59 --> Encrypt Class Initialized
INFO - 2022-03-11 01:08:59 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:08:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:08:59 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:08:59 --> Model "Users_model" initialized
INFO - 2022-03-11 01:08:59 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:08:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:08:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 01:08:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:08:59 --> Final output sent to browser
DEBUG - 2022-03-11 01:08:59 --> Total execution time: 0.0585
ERROR - 2022-03-11 01:08:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:08:59 --> Config Class Initialized
INFO - 2022-03-11 01:08:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:08:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:08:59 --> Utf8 Class Initialized
INFO - 2022-03-11 01:08:59 --> URI Class Initialized
INFO - 2022-03-11 01:08:59 --> Router Class Initialized
INFO - 2022-03-11 01:08:59 --> Output Class Initialized
INFO - 2022-03-11 01:08:59 --> Security Class Initialized
DEBUG - 2022-03-11 01:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:08:59 --> Input Class Initialized
INFO - 2022-03-11 01:08:59 --> Language Class Initialized
ERROR - 2022-03-11 01:08:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:09:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:09:54 --> Config Class Initialized
INFO - 2022-03-11 01:09:54 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:09:54 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:09:54 --> Utf8 Class Initialized
INFO - 2022-03-11 01:09:54 --> URI Class Initialized
INFO - 2022-03-11 01:09:54 --> Router Class Initialized
INFO - 2022-03-11 01:09:54 --> Output Class Initialized
INFO - 2022-03-11 01:09:54 --> Security Class Initialized
DEBUG - 2022-03-11 01:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:09:54 --> Input Class Initialized
INFO - 2022-03-11 01:09:54 --> Language Class Initialized
INFO - 2022-03-11 01:09:54 --> Loader Class Initialized
INFO - 2022-03-11 01:09:54 --> Helper loaded: url_helper
INFO - 2022-03-11 01:09:54 --> Helper loaded: form_helper
INFO - 2022-03-11 01:09:54 --> Helper loaded: common_helper
INFO - 2022-03-11 01:09:54 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:09:54 --> Controller Class Initialized
INFO - 2022-03-11 01:09:54 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:09:54 --> Encrypt Class Initialized
INFO - 2022-03-11 01:09:54 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:09:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:09:54 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:09:54 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:09:54 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:09:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-11 01:09:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:09:59 --> Config Class Initialized
INFO - 2022-03-11 01:09:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:09:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:09:59 --> Utf8 Class Initialized
INFO - 2022-03-11 01:09:59 --> URI Class Initialized
INFO - 2022-03-11 01:09:59 --> Router Class Initialized
INFO - 2022-03-11 01:09:59 --> Output Class Initialized
INFO - 2022-03-11 01:09:59 --> Security Class Initialized
DEBUG - 2022-03-11 01:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:09:59 --> Input Class Initialized
INFO - 2022-03-11 01:09:59 --> Language Class Initialized
INFO - 2022-03-11 01:09:59 --> Loader Class Initialized
INFO - 2022-03-11 01:09:59 --> Helper loaded: url_helper
INFO - 2022-03-11 01:09:59 --> Helper loaded: form_helper
INFO - 2022-03-11 01:09:59 --> Helper loaded: common_helper
INFO - 2022-03-11 01:09:59 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:09:59 --> Controller Class Initialized
INFO - 2022-03-11 01:09:59 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:09:59 --> Encrypt Class Initialized
INFO - 2022-03-11 01:09:59 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:09:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:09:59 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:09:59 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:09:59 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:10:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:10:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:10:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:10:00 --> Final output sent to browser
DEBUG - 2022-03-11 01:10:00 --> Total execution time: 0.0892
ERROR - 2022-03-11 01:10:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:10:00 --> Config Class Initialized
INFO - 2022-03-11 01:10:00 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:10:00 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:10:00 --> Utf8 Class Initialized
INFO - 2022-03-11 01:10:00 --> URI Class Initialized
INFO - 2022-03-11 01:10:00 --> Router Class Initialized
INFO - 2022-03-11 01:10:00 --> Output Class Initialized
INFO - 2022-03-11 01:10:00 --> Security Class Initialized
DEBUG - 2022-03-11 01:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:10:00 --> Input Class Initialized
INFO - 2022-03-11 01:10:00 --> Language Class Initialized
ERROR - 2022-03-11 01:10:00 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-11 01:10:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:10:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 01:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:10:03 --> Config Class Initialized
INFO - 2022-03-11 01:10:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:10:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:10:03 --> Utf8 Class Initialized
INFO - 2022-03-11 01:10:03 --> URI Class Initialized
INFO - 2022-03-11 01:10:03 --> Router Class Initialized
INFO - 2022-03-11 01:10:03 --> Output Class Initialized
INFO - 2022-03-11 01:10:03 --> Security Class Initialized
DEBUG - 2022-03-11 01:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:10:03 --> Input Class Initialized
INFO - 2022-03-11 01:10:03 --> Language Class Initialized
ERROR - 2022-03-11 01:10:03 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 01:10:04 --> Final output sent to browser
DEBUG - 2022-03-11 01:10:04 --> Total execution time: 7.8335
ERROR - 2022-03-11 01:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:10:32 --> Config Class Initialized
INFO - 2022-03-11 01:10:32 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:10:32 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:10:32 --> Utf8 Class Initialized
INFO - 2022-03-11 01:10:32 --> URI Class Initialized
INFO - 2022-03-11 01:10:32 --> Router Class Initialized
INFO - 2022-03-11 01:10:32 --> Output Class Initialized
INFO - 2022-03-11 01:10:32 --> Security Class Initialized
DEBUG - 2022-03-11 01:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:10:32 --> Input Class Initialized
INFO - 2022-03-11 01:10:32 --> Language Class Initialized
INFO - 2022-03-11 01:10:32 --> Loader Class Initialized
INFO - 2022-03-11 01:10:32 --> Helper loaded: url_helper
INFO - 2022-03-11 01:10:32 --> Helper loaded: form_helper
INFO - 2022-03-11 01:10:32 --> Helper loaded: common_helper
INFO - 2022-03-11 01:10:32 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:10:32 --> Controller Class Initialized
INFO - 2022-03-11 01:10:32 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:10:32 --> Encrypt Class Initialized
INFO - 2022-03-11 01:10:32 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:10:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:10:32 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:10:32 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:10:32 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:10:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:10:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:10:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:10:41 --> Final output sent to browser
DEBUG - 2022-03-11 01:10:41 --> Total execution time: 5.8713
ERROR - 2022-03-11 01:10:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:10:58 --> Config Class Initialized
INFO - 2022-03-11 01:10:58 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:10:58 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:10:58 --> Utf8 Class Initialized
INFO - 2022-03-11 01:10:58 --> URI Class Initialized
INFO - 2022-03-11 01:10:58 --> Router Class Initialized
INFO - 2022-03-11 01:10:58 --> Output Class Initialized
INFO - 2022-03-11 01:10:58 --> Security Class Initialized
DEBUG - 2022-03-11 01:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:10:58 --> Input Class Initialized
INFO - 2022-03-11 01:10:58 --> Language Class Initialized
INFO - 2022-03-11 01:10:58 --> Loader Class Initialized
INFO - 2022-03-11 01:10:58 --> Helper loaded: url_helper
INFO - 2022-03-11 01:10:58 --> Helper loaded: form_helper
INFO - 2022-03-11 01:10:58 --> Helper loaded: common_helper
INFO - 2022-03-11 01:10:58 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:10:58 --> Controller Class Initialized
INFO - 2022-03-11 01:10:58 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:10:58 --> Encrypt Class Initialized
INFO - 2022-03-11 01:10:58 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:10:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:10:58 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:10:58 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:10:58 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:10:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:10:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:10:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:10:58 --> Final output sent to browser
DEBUG - 2022-03-11 01:10:58 --> Total execution time: 0.0514
ERROR - 2022-03-11 01:10:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:10:59 --> Config Class Initialized
INFO - 2022-03-11 01:10:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:10:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:10:59 --> Utf8 Class Initialized
INFO - 2022-03-11 01:10:59 --> URI Class Initialized
INFO - 2022-03-11 01:10:59 --> Router Class Initialized
INFO - 2022-03-11 01:10:59 --> Output Class Initialized
INFO - 2022-03-11 01:10:59 --> Security Class Initialized
DEBUG - 2022-03-11 01:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:10:59 --> Input Class Initialized
INFO - 2022-03-11 01:10:59 --> Language Class Initialized
ERROR - 2022-03-11 01:10:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:06 --> Config Class Initialized
INFO - 2022-03-11 01:11:06 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:06 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:06 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:06 --> URI Class Initialized
INFO - 2022-03-11 01:11:06 --> Router Class Initialized
INFO - 2022-03-11 01:11:06 --> Output Class Initialized
INFO - 2022-03-11 01:11:06 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:06 --> Input Class Initialized
INFO - 2022-03-11 01:11:06 --> Language Class Initialized
INFO - 2022-03-11 01:11:06 --> Loader Class Initialized
INFO - 2022-03-11 01:11:06 --> Helper loaded: url_helper
INFO - 2022-03-11 01:11:06 --> Helper loaded: form_helper
INFO - 2022-03-11 01:11:06 --> Helper loaded: common_helper
INFO - 2022-03-11 01:11:06 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:11:06 --> Controller Class Initialized
INFO - 2022-03-11 01:11:06 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:11:06 --> Encrypt Class Initialized
INFO - 2022-03-11 01:11:06 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:11:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:11:06 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:11:06 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:11:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 01:11:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:07 --> Config Class Initialized
INFO - 2022-03-11 01:11:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:07 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:07 --> URI Class Initialized
INFO - 2022-03-11 01:11:07 --> Router Class Initialized
INFO - 2022-03-11 01:11:07 --> Output Class Initialized
INFO - 2022-03-11 01:11:07 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:07 --> Input Class Initialized
INFO - 2022-03-11 01:11:07 --> Language Class Initialized
INFO - 2022-03-11 01:11:07 --> Loader Class Initialized
INFO - 2022-03-11 01:11:07 --> Helper loaded: url_helper
INFO - 2022-03-11 01:11:07 --> Helper loaded: form_helper
INFO - 2022-03-11 01:11:07 --> Helper loaded: common_helper
INFO - 2022-03-11 01:11:07 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:11:07 --> Controller Class Initialized
INFO - 2022-03-11 01:11:07 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:11:07 --> Encrypt Class Initialized
INFO - 2022-03-11 01:11:07 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:11:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:11:07 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:11:07 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:11:07 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:11:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:11:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:11:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:11:07 --> Final output sent to browser
DEBUG - 2022-03-11 01:11:07 --> Total execution time: 0.0648
ERROR - 2022-03-11 01:11:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:07 --> Config Class Initialized
INFO - 2022-03-11 01:11:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:07 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:07 --> URI Class Initialized
INFO - 2022-03-11 01:11:07 --> Router Class Initialized
INFO - 2022-03-11 01:11:07 --> Output Class Initialized
INFO - 2022-03-11 01:11:07 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:07 --> Input Class Initialized
INFO - 2022-03-11 01:11:07 --> Language Class Initialized
ERROR - 2022-03-11 01:11:07 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:08 --> Config Class Initialized
INFO - 2022-03-11 01:11:08 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:08 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:08 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:08 --> URI Class Initialized
INFO - 2022-03-11 01:11:08 --> Router Class Initialized
INFO - 2022-03-11 01:11:08 --> Output Class Initialized
INFO - 2022-03-11 01:11:08 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:08 --> Input Class Initialized
INFO - 2022-03-11 01:11:08 --> Language Class Initialized
INFO - 2022-03-11 01:11:08 --> Loader Class Initialized
INFO - 2022-03-11 01:11:08 --> Helper loaded: url_helper
INFO - 2022-03-11 01:11:08 --> Helper loaded: form_helper
INFO - 2022-03-11 01:11:08 --> Helper loaded: common_helper
INFO - 2022-03-11 01:11:08 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:11:08 --> Controller Class Initialized
INFO - 2022-03-11 01:11:08 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:11:08 --> Encrypt Class Initialized
INFO - 2022-03-11 01:11:08 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:11:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:11:08 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:11:08 --> Model "Users_model" initialized
INFO - 2022-03-11 01:11:08 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:11:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:11:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 01:11:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:11:08 --> Final output sent to browser
DEBUG - 2022-03-11 01:11:08 --> Total execution time: 0.0639
ERROR - 2022-03-11 01:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:09 --> Config Class Initialized
INFO - 2022-03-11 01:11:09 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:09 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:09 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:09 --> URI Class Initialized
INFO - 2022-03-11 01:11:09 --> Router Class Initialized
INFO - 2022-03-11 01:11:09 --> Output Class Initialized
INFO - 2022-03-11 01:11:09 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:09 --> Input Class Initialized
INFO - 2022-03-11 01:11:09 --> Language Class Initialized
ERROR - 2022-03-11 01:11:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:11 --> Config Class Initialized
INFO - 2022-03-11 01:11:11 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:11 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:11 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:11 --> URI Class Initialized
INFO - 2022-03-11 01:11:11 --> Router Class Initialized
INFO - 2022-03-11 01:11:11 --> Output Class Initialized
INFO - 2022-03-11 01:11:11 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:11 --> Input Class Initialized
INFO - 2022-03-11 01:11:11 --> Language Class Initialized
INFO - 2022-03-11 01:11:11 --> Loader Class Initialized
INFO - 2022-03-11 01:11:11 --> Helper loaded: url_helper
INFO - 2022-03-11 01:11:11 --> Helper loaded: form_helper
INFO - 2022-03-11 01:11:11 --> Helper loaded: common_helper
INFO - 2022-03-11 01:11:11 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:11:11 --> Controller Class Initialized
INFO - 2022-03-11 01:11:11 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:11:11 --> Encrypt Class Initialized
INFO - 2022-03-11 01:11:11 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:11:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:11:11 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:11:11 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:11:11 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:11:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:11:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:11:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:11:12 --> Final output sent to browser
DEBUG - 2022-03-11 01:11:12 --> Total execution time: 0.0556
ERROR - 2022-03-11 01:11:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:13 --> Config Class Initialized
INFO - 2022-03-11 01:11:13 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:13 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:13 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:13 --> URI Class Initialized
INFO - 2022-03-11 01:11:13 --> Router Class Initialized
INFO - 2022-03-11 01:11:13 --> Output Class Initialized
INFO - 2022-03-11 01:11:13 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:13 --> Input Class Initialized
INFO - 2022-03-11 01:11:13 --> Language Class Initialized
ERROR - 2022-03-11 01:11:13 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 01:11:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:17 --> Config Class Initialized
INFO - 2022-03-11 01:11:17 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:17 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:17 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:17 --> URI Class Initialized
INFO - 2022-03-11 01:11:17 --> Router Class Initialized
INFO - 2022-03-11 01:11:17 --> Output Class Initialized
INFO - 2022-03-11 01:11:17 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:17 --> Input Class Initialized
INFO - 2022-03-11 01:11:17 --> Language Class Initialized
INFO - 2022-03-11 01:11:17 --> Loader Class Initialized
INFO - 2022-03-11 01:11:17 --> Helper loaded: url_helper
INFO - 2022-03-11 01:11:17 --> Helper loaded: form_helper
INFO - 2022-03-11 01:11:17 --> Helper loaded: common_helper
INFO - 2022-03-11 01:11:17 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:11:17 --> Controller Class Initialized
INFO - 2022-03-11 01:11:17 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:11:17 --> Encrypt Class Initialized
INFO - 2022-03-11 01:11:17 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:11:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:11:17 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:11:17 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:11:17 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:11:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:11:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:11:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 01:11:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:25 --> Config Class Initialized
INFO - 2022-03-11 01:11:25 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:25 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:25 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:25 --> URI Class Initialized
INFO - 2022-03-11 01:11:25 --> Router Class Initialized
INFO - 2022-03-11 01:11:25 --> Output Class Initialized
INFO - 2022-03-11 01:11:25 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:25 --> Input Class Initialized
INFO - 2022-03-11 01:11:25 --> Language Class Initialized
INFO - 2022-03-11 01:11:25 --> Loader Class Initialized
INFO - 2022-03-11 01:11:25 --> Helper loaded: url_helper
INFO - 2022-03-11 01:11:25 --> Helper loaded: form_helper
INFO - 2022-03-11 01:11:25 --> Helper loaded: common_helper
INFO - 2022-03-11 01:11:25 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:11:25 --> Controller Class Initialized
INFO - 2022-03-11 01:11:25 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:11:25 --> Encrypt Class Initialized
INFO - 2022-03-11 01:11:25 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:11:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:11:25 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:11:25 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:11:25 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:11:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:11:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 01:11:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:11:25 --> Final output sent to browser
DEBUG - 2022-03-11 01:11:25 --> Total execution time: 0.0398
INFO - 2022-03-11 01:11:25 --> Final output sent to browser
DEBUG - 2022-03-11 01:11:25 --> Total execution time: 5.4849
ERROR - 2022-03-11 01:11:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:11:26 --> Config Class Initialized
INFO - 2022-03-11 01:11:26 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:11:26 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:11:26 --> Utf8 Class Initialized
INFO - 2022-03-11 01:11:26 --> URI Class Initialized
INFO - 2022-03-11 01:11:26 --> Router Class Initialized
INFO - 2022-03-11 01:11:26 --> Output Class Initialized
INFO - 2022-03-11 01:11:26 --> Security Class Initialized
DEBUG - 2022-03-11 01:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:11:26 --> Input Class Initialized
INFO - 2022-03-11 01:11:26 --> Language Class Initialized
ERROR - 2022-03-11 01:11:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 01:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:22:22 --> Config Class Initialized
INFO - 2022-03-11 01:22:22 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:22:22 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:22:22 --> Utf8 Class Initialized
INFO - 2022-03-11 01:22:22 --> URI Class Initialized
INFO - 2022-03-11 01:22:22 --> Router Class Initialized
INFO - 2022-03-11 01:22:22 --> Output Class Initialized
INFO - 2022-03-11 01:22:22 --> Security Class Initialized
DEBUG - 2022-03-11 01:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:22:22 --> Input Class Initialized
INFO - 2022-03-11 01:22:22 --> Language Class Initialized
INFO - 2022-03-11 01:22:22 --> Loader Class Initialized
INFO - 2022-03-11 01:22:22 --> Helper loaded: url_helper
INFO - 2022-03-11 01:22:22 --> Helper loaded: form_helper
INFO - 2022-03-11 01:22:22 --> Helper loaded: common_helper
INFO - 2022-03-11 01:22:22 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:22:22 --> Controller Class Initialized
INFO - 2022-03-11 01:22:22 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:22:22 --> Encrypt Class Initialized
INFO - 2022-03-11 01:22:22 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:22:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:22:22 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:22:22 --> Model "Users_model" initialized
INFO - 2022-03-11 01:22:22 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:22:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:22:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 01:22:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:22:22 --> Final output sent to browser
DEBUG - 2022-03-11 01:22:22 --> Total execution time: 0.0809
ERROR - 2022-03-11 01:22:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:22:44 --> Config Class Initialized
INFO - 2022-03-11 01:22:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:22:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:22:44 --> Utf8 Class Initialized
INFO - 2022-03-11 01:22:44 --> URI Class Initialized
INFO - 2022-03-11 01:22:44 --> Router Class Initialized
INFO - 2022-03-11 01:22:44 --> Output Class Initialized
INFO - 2022-03-11 01:22:44 --> Security Class Initialized
DEBUG - 2022-03-11 01:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:22:44 --> Input Class Initialized
INFO - 2022-03-11 01:22:44 --> Language Class Initialized
INFO - 2022-03-11 01:22:44 --> Loader Class Initialized
INFO - 2022-03-11 01:22:44 --> Helper loaded: url_helper
INFO - 2022-03-11 01:22:44 --> Helper loaded: form_helper
INFO - 2022-03-11 01:22:44 --> Helper loaded: common_helper
INFO - 2022-03-11 01:22:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:22:44 --> Controller Class Initialized
INFO - 2022-03-11 01:22:44 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:22:44 --> Encrypt Class Initialized
INFO - 2022-03-11 01:22:44 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:22:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:22:44 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:22:44 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:22:44 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:22:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:22:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:22:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:22:56 --> Final output sent to browser
DEBUG - 2022-03-11 01:22:56 --> Total execution time: 9.5022
ERROR - 2022-03-11 01:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:23:45 --> Config Class Initialized
INFO - 2022-03-11 01:23:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:23:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:23:45 --> Utf8 Class Initialized
INFO - 2022-03-11 01:23:45 --> URI Class Initialized
INFO - 2022-03-11 01:23:45 --> Router Class Initialized
INFO - 2022-03-11 01:23:45 --> Output Class Initialized
INFO - 2022-03-11 01:23:45 --> Security Class Initialized
DEBUG - 2022-03-11 01:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:23:45 --> Input Class Initialized
INFO - 2022-03-11 01:23:45 --> Language Class Initialized
INFO - 2022-03-11 01:23:45 --> Loader Class Initialized
INFO - 2022-03-11 01:23:45 --> Helper loaded: url_helper
INFO - 2022-03-11 01:23:45 --> Helper loaded: form_helper
INFO - 2022-03-11 01:23:45 --> Helper loaded: common_helper
INFO - 2022-03-11 01:23:45 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:23:45 --> Controller Class Initialized
INFO - 2022-03-11 01:23:45 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:23:45 --> Encrypt Class Initialized
INFO - 2022-03-11 01:23:45 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:23:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:23:45 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:23:45 --> Model "Users_model" initialized
INFO - 2022-03-11 01:23:45 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:23:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:23:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 01:23:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:23:45 --> Final output sent to browser
DEBUG - 2022-03-11 01:23:45 --> Total execution time: 0.0725
ERROR - 2022-03-11 01:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:23:53 --> Config Class Initialized
INFO - 2022-03-11 01:23:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:23:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:23:53 --> Utf8 Class Initialized
INFO - 2022-03-11 01:23:53 --> URI Class Initialized
INFO - 2022-03-11 01:23:53 --> Router Class Initialized
INFO - 2022-03-11 01:23:53 --> Output Class Initialized
INFO - 2022-03-11 01:23:53 --> Security Class Initialized
DEBUG - 2022-03-11 01:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:23:53 --> Input Class Initialized
INFO - 2022-03-11 01:23:53 --> Language Class Initialized
ERROR - 2022-03-11 01:23:53 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 01:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:24:14 --> Config Class Initialized
INFO - 2022-03-11 01:24:14 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:24:14 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:24:14 --> Utf8 Class Initialized
INFO - 2022-03-11 01:24:14 --> URI Class Initialized
INFO - 2022-03-11 01:24:14 --> Router Class Initialized
INFO - 2022-03-11 01:24:14 --> Output Class Initialized
INFO - 2022-03-11 01:24:14 --> Security Class Initialized
DEBUG - 2022-03-11 01:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:24:14 --> Input Class Initialized
INFO - 2022-03-11 01:24:14 --> Language Class Initialized
INFO - 2022-03-11 01:24:14 --> Loader Class Initialized
INFO - 2022-03-11 01:24:14 --> Helper loaded: url_helper
INFO - 2022-03-11 01:24:14 --> Helper loaded: form_helper
INFO - 2022-03-11 01:24:14 --> Helper loaded: common_helper
INFO - 2022-03-11 01:24:14 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:24:14 --> Controller Class Initialized
INFO - 2022-03-11 01:24:14 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:24:14 --> Encrypt Class Initialized
INFO - 2022-03-11 01:24:14 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:24:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:24:14 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:24:14 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:24:14 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:24:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:24:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:24:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:24:24 --> Final output sent to browser
DEBUG - 2022-03-11 01:24:24 --> Total execution time: 7.6413
ERROR - 2022-03-11 01:24:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:24:58 --> Config Class Initialized
INFO - 2022-03-11 01:24:58 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:24:58 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:24:58 --> Utf8 Class Initialized
INFO - 2022-03-11 01:24:58 --> URI Class Initialized
INFO - 2022-03-11 01:24:58 --> Router Class Initialized
INFO - 2022-03-11 01:24:58 --> Output Class Initialized
INFO - 2022-03-11 01:24:58 --> Security Class Initialized
DEBUG - 2022-03-11 01:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:24:58 --> Input Class Initialized
INFO - 2022-03-11 01:24:58 --> Language Class Initialized
INFO - 2022-03-11 01:24:58 --> Loader Class Initialized
INFO - 2022-03-11 01:24:58 --> Helper loaded: url_helper
INFO - 2022-03-11 01:24:58 --> Helper loaded: form_helper
INFO - 2022-03-11 01:24:58 --> Helper loaded: common_helper
INFO - 2022-03-11 01:24:58 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:24:58 --> Controller Class Initialized
INFO - 2022-03-11 01:24:58 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:24:58 --> Encrypt Class Initialized
INFO - 2022-03-11 01:24:58 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:24:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:24:58 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:24:58 --> Model "Users_model" initialized
INFO - 2022-03-11 01:24:58 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:24:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:24:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 01:24:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:24:58 --> Final output sent to browser
DEBUG - 2022-03-11 01:24:58 --> Total execution time: 0.1179
ERROR - 2022-03-11 01:25:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:25:11 --> Config Class Initialized
INFO - 2022-03-11 01:25:11 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:25:11 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:25:11 --> Utf8 Class Initialized
INFO - 2022-03-11 01:25:11 --> URI Class Initialized
INFO - 2022-03-11 01:25:11 --> Router Class Initialized
INFO - 2022-03-11 01:25:11 --> Output Class Initialized
INFO - 2022-03-11 01:25:11 --> Security Class Initialized
DEBUG - 2022-03-11 01:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:25:11 --> Input Class Initialized
INFO - 2022-03-11 01:25:11 --> Language Class Initialized
ERROR - 2022-03-11 01:25:11 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 01:25:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:25:37 --> Config Class Initialized
INFO - 2022-03-11 01:25:37 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:25:37 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:25:37 --> Utf8 Class Initialized
INFO - 2022-03-11 01:25:37 --> URI Class Initialized
INFO - 2022-03-11 01:25:37 --> Router Class Initialized
INFO - 2022-03-11 01:25:37 --> Output Class Initialized
INFO - 2022-03-11 01:25:37 --> Security Class Initialized
DEBUG - 2022-03-11 01:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:25:37 --> Input Class Initialized
INFO - 2022-03-11 01:25:37 --> Language Class Initialized
INFO - 2022-03-11 01:25:37 --> Loader Class Initialized
INFO - 2022-03-11 01:25:37 --> Helper loaded: url_helper
INFO - 2022-03-11 01:25:37 --> Helper loaded: form_helper
INFO - 2022-03-11 01:25:37 --> Helper loaded: common_helper
INFO - 2022-03-11 01:25:37 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:25:37 --> Controller Class Initialized
INFO - 2022-03-11 01:25:37 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:25:37 --> Encrypt Class Initialized
INFO - 2022-03-11 01:25:37 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:25:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:25:37 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:25:37 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:25:37 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:25:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:25:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:25:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:25:46 --> Final output sent to browser
DEBUG - 2022-03-11 01:25:46 --> Total execution time: 6.3991
ERROR - 2022-03-11 01:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:26:14 --> Config Class Initialized
INFO - 2022-03-11 01:26:14 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:26:14 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:26:14 --> Utf8 Class Initialized
INFO - 2022-03-11 01:26:14 --> URI Class Initialized
INFO - 2022-03-11 01:26:14 --> Router Class Initialized
INFO - 2022-03-11 01:26:14 --> Output Class Initialized
INFO - 2022-03-11 01:26:14 --> Security Class Initialized
DEBUG - 2022-03-11 01:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:26:14 --> Input Class Initialized
INFO - 2022-03-11 01:26:14 --> Language Class Initialized
INFO - 2022-03-11 01:26:14 --> Loader Class Initialized
INFO - 2022-03-11 01:26:14 --> Helper loaded: url_helper
INFO - 2022-03-11 01:26:14 --> Helper loaded: form_helper
INFO - 2022-03-11 01:26:14 --> Helper loaded: common_helper
INFO - 2022-03-11 01:26:14 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:26:14 --> Controller Class Initialized
INFO - 2022-03-11 01:26:14 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:26:14 --> Encrypt Class Initialized
INFO - 2022-03-11 01:26:14 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:26:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:26:14 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:26:14 --> Model "Users_model" initialized
INFO - 2022-03-11 01:26:14 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:26:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:26:14 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 01:26:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:26:14 --> Final output sent to browser
DEBUG - 2022-03-11 01:26:14 --> Total execution time: 0.0609
ERROR - 2022-03-11 01:26:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:26:21 --> Config Class Initialized
INFO - 2022-03-11 01:26:21 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:26:21 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:26:21 --> Utf8 Class Initialized
INFO - 2022-03-11 01:26:21 --> URI Class Initialized
INFO - 2022-03-11 01:26:21 --> Router Class Initialized
INFO - 2022-03-11 01:26:21 --> Output Class Initialized
INFO - 2022-03-11 01:26:21 --> Security Class Initialized
DEBUG - 2022-03-11 01:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:26:21 --> Input Class Initialized
INFO - 2022-03-11 01:26:21 --> Language Class Initialized
ERROR - 2022-03-11 01:26:21 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-11 01:26:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:26:42 --> Config Class Initialized
INFO - 2022-03-11 01:26:42 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:26:42 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:26:42 --> Utf8 Class Initialized
INFO - 2022-03-11 01:26:42 --> URI Class Initialized
INFO - 2022-03-11 01:26:42 --> Router Class Initialized
INFO - 2022-03-11 01:26:42 --> Output Class Initialized
INFO - 2022-03-11 01:26:42 --> Security Class Initialized
DEBUG - 2022-03-11 01:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:26:42 --> Input Class Initialized
INFO - 2022-03-11 01:26:42 --> Language Class Initialized
INFO - 2022-03-11 01:26:42 --> Loader Class Initialized
INFO - 2022-03-11 01:26:42 --> Helper loaded: url_helper
INFO - 2022-03-11 01:26:42 --> Helper loaded: form_helper
INFO - 2022-03-11 01:26:42 --> Helper loaded: common_helper
INFO - 2022-03-11 01:26:42 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:26:42 --> Controller Class Initialized
INFO - 2022-03-11 01:26:42 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:26:42 --> Encrypt Class Initialized
INFO - 2022-03-11 01:26:42 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:26:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:26:42 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:26:42 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:26:42 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:26:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-11 01:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:26:45 --> Config Class Initialized
INFO - 2022-03-11 01:26:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:26:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:26:45 --> Utf8 Class Initialized
INFO - 2022-03-11 01:26:45 --> URI Class Initialized
INFO - 2022-03-11 01:26:45 --> Router Class Initialized
INFO - 2022-03-11 01:26:45 --> Output Class Initialized
INFO - 2022-03-11 01:26:45 --> Security Class Initialized
DEBUG - 2022-03-11 01:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:26:45 --> Input Class Initialized
INFO - 2022-03-11 01:26:45 --> Language Class Initialized
INFO - 2022-03-11 01:26:45 --> Loader Class Initialized
INFO - 2022-03-11 01:26:45 --> Helper loaded: url_helper
INFO - 2022-03-11 01:26:45 --> Helper loaded: form_helper
INFO - 2022-03-11 01:26:45 --> Helper loaded: common_helper
INFO - 2022-03-11 01:26:45 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:26:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:26:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:26:48 --> Controller Class Initialized
INFO - 2022-03-11 01:26:48 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:26:48 --> Encrypt Class Initialized
INFO - 2022-03-11 01:26:48 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:26:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:26:48 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:26:48 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:26:48 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:26:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:26:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:26:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:26:57 --> Final output sent to browser
DEBUG - 2022-03-11 01:26:57 --> Total execution time: 9.5193
ERROR - 2022-03-11 01:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:30:58 --> Config Class Initialized
INFO - 2022-03-11 01:30:58 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:30:58 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:30:58 --> Utf8 Class Initialized
INFO - 2022-03-11 01:30:58 --> URI Class Initialized
INFO - 2022-03-11 01:30:58 --> Router Class Initialized
INFO - 2022-03-11 01:30:58 --> Output Class Initialized
INFO - 2022-03-11 01:30:58 --> Security Class Initialized
DEBUG - 2022-03-11 01:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:30:58 --> Input Class Initialized
INFO - 2022-03-11 01:30:58 --> Language Class Initialized
INFO - 2022-03-11 01:30:58 --> Loader Class Initialized
INFO - 2022-03-11 01:30:58 --> Helper loaded: url_helper
INFO - 2022-03-11 01:30:58 --> Helper loaded: form_helper
INFO - 2022-03-11 01:30:58 --> Helper loaded: common_helper
INFO - 2022-03-11 01:30:58 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:30:58 --> Controller Class Initialized
INFO - 2022-03-11 01:30:58 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:30:58 --> Encrypt Class Initialized
INFO - 2022-03-11 01:30:58 --> Model "Patient_model" initialized
INFO - 2022-03-11 01:30:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 01:30:58 --> Model "Referredby_model" initialized
INFO - 2022-03-11 01:30:58 --> Model "Prefix_master" initialized
INFO - 2022-03-11 01:30:58 --> Model "Hospital_model" initialized
INFO - 2022-03-11 01:30:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 01:30:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 01:30:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 01:30:58 --> Final output sent to browser
DEBUG - 2022-03-11 01:30:58 --> Total execution time: 0.0566
ERROR - 2022-03-11 01:42:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:42:57 --> Config Class Initialized
INFO - 2022-03-11 01:42:57 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:42:57 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:42:57 --> Utf8 Class Initialized
INFO - 2022-03-11 01:42:57 --> URI Class Initialized
INFO - 2022-03-11 01:42:57 --> Router Class Initialized
INFO - 2022-03-11 01:42:57 --> Output Class Initialized
INFO - 2022-03-11 01:42:57 --> Security Class Initialized
DEBUG - 2022-03-11 01:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:42:57 --> Input Class Initialized
INFO - 2022-03-11 01:42:57 --> Language Class Initialized
INFO - 2022-03-11 01:42:57 --> Loader Class Initialized
INFO - 2022-03-11 01:42:57 --> Helper loaded: url_helper
INFO - 2022-03-11 01:42:57 --> Helper loaded: form_helper
INFO - 2022-03-11 01:42:57 --> Helper loaded: common_helper
INFO - 2022-03-11 01:42:57 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:42:58 --> Controller Class Initialized
INFO - 2022-03-11 01:42:58 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:42:58 --> Encrypt Class Initialized
DEBUG - 2022-03-11 01:42:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 01:42:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 01:42:58 --> Email Class Initialized
INFO - 2022-03-11 01:42:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 01:42:58 --> Calendar Class Initialized
INFO - 2022-03-11 01:42:58 --> Model "Login_model" initialized
ERROR - 2022-03-11 01:42:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:42:58 --> Config Class Initialized
INFO - 2022-03-11 01:42:58 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:42:58 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:42:58 --> Utf8 Class Initialized
INFO - 2022-03-11 01:42:58 --> URI Class Initialized
INFO - 2022-03-11 01:42:58 --> Router Class Initialized
INFO - 2022-03-11 01:42:58 --> Output Class Initialized
INFO - 2022-03-11 01:42:58 --> Security Class Initialized
DEBUG - 2022-03-11 01:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:42:58 --> Input Class Initialized
INFO - 2022-03-11 01:42:58 --> Language Class Initialized
INFO - 2022-03-11 01:42:58 --> Loader Class Initialized
INFO - 2022-03-11 01:42:58 --> Helper loaded: url_helper
INFO - 2022-03-11 01:42:58 --> Helper loaded: form_helper
INFO - 2022-03-11 01:42:58 --> Helper loaded: common_helper
INFO - 2022-03-11 01:42:58 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:42:58 --> Controller Class Initialized
INFO - 2022-03-11 01:42:58 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:42:58 --> Encrypt Class Initialized
DEBUG - 2022-03-11 01:42:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 01:42:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 01:42:58 --> Email Class Initialized
INFO - 2022-03-11 01:42:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 01:42:58 --> Calendar Class Initialized
INFO - 2022-03-11 01:42:58 --> Model "Login_model" initialized
ERROR - 2022-03-11 01:42:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 01:42:59 --> Config Class Initialized
INFO - 2022-03-11 01:42:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 01:42:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 01:42:59 --> Utf8 Class Initialized
INFO - 2022-03-11 01:42:59 --> URI Class Initialized
INFO - 2022-03-11 01:42:59 --> Router Class Initialized
INFO - 2022-03-11 01:42:59 --> Output Class Initialized
INFO - 2022-03-11 01:42:59 --> Security Class Initialized
DEBUG - 2022-03-11 01:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 01:42:59 --> Input Class Initialized
INFO - 2022-03-11 01:42:59 --> Language Class Initialized
INFO - 2022-03-11 01:42:59 --> Loader Class Initialized
INFO - 2022-03-11 01:42:59 --> Helper loaded: url_helper
INFO - 2022-03-11 01:42:59 --> Helper loaded: form_helper
INFO - 2022-03-11 01:42:59 --> Helper loaded: common_helper
INFO - 2022-03-11 01:42:59 --> Database Driver Class Initialized
DEBUG - 2022-03-11 01:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 01:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 01:42:59 --> Controller Class Initialized
INFO - 2022-03-11 01:42:59 --> Form Validation Class Initialized
DEBUG - 2022-03-11 01:42:59 --> Encrypt Class Initialized
DEBUG - 2022-03-11 01:42:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 01:42:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 01:42:59 --> Email Class Initialized
INFO - 2022-03-11 01:42:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 01:42:59 --> Calendar Class Initialized
INFO - 2022-03-11 01:42:59 --> Model "Login_model" initialized
INFO - 2022-03-11 01:42:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 01:42:59 --> Final output sent to browser
DEBUG - 2022-03-11 01:42:59 --> Total execution time: 0.1574
ERROR - 2022-03-11 02:03:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:03:10 --> Config Class Initialized
INFO - 2022-03-11 02:03:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:03:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:03:10 --> Utf8 Class Initialized
INFO - 2022-03-11 02:03:10 --> URI Class Initialized
INFO - 2022-03-11 02:03:10 --> Router Class Initialized
INFO - 2022-03-11 02:03:10 --> Output Class Initialized
INFO - 2022-03-11 02:03:10 --> Security Class Initialized
DEBUG - 2022-03-11 02:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:03:10 --> Input Class Initialized
INFO - 2022-03-11 02:03:10 --> Language Class Initialized
ERROR - 2022-03-11 02:03:10 --> 404 Page Not Found: Aws/config
ERROR - 2022-03-11 02:03:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:03:10 --> Config Class Initialized
INFO - 2022-03-11 02:03:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:03:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:03:10 --> Utf8 Class Initialized
INFO - 2022-03-11 02:03:10 --> URI Class Initialized
INFO - 2022-03-11 02:03:10 --> Router Class Initialized
INFO - 2022-03-11 02:03:10 --> Output Class Initialized
INFO - 2022-03-11 02:03:10 --> Security Class Initialized
DEBUG - 2022-03-11 02:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:03:10 --> Input Class Initialized
INFO - 2022-03-11 02:03:10 --> Language Class Initialized
ERROR - 2022-03-11 02:03:10 --> 404 Page Not Found: Aws/config
ERROR - 2022-03-11 02:38:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:38:49 --> Config Class Initialized
INFO - 2022-03-11 02:38:49 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:38:49 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:38:49 --> Utf8 Class Initialized
INFO - 2022-03-11 02:38:49 --> URI Class Initialized
DEBUG - 2022-03-11 02:38:49 --> No URI present. Default controller set.
INFO - 2022-03-11 02:38:49 --> Router Class Initialized
INFO - 2022-03-11 02:38:49 --> Output Class Initialized
INFO - 2022-03-11 02:38:49 --> Security Class Initialized
DEBUG - 2022-03-11 02:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:38:49 --> Input Class Initialized
INFO - 2022-03-11 02:38:49 --> Language Class Initialized
INFO - 2022-03-11 02:38:49 --> Loader Class Initialized
INFO - 2022-03-11 02:38:49 --> Helper loaded: url_helper
INFO - 2022-03-11 02:38:49 --> Helper loaded: form_helper
INFO - 2022-03-11 02:38:49 --> Helper loaded: common_helper
INFO - 2022-03-11 02:38:49 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:38:49 --> Controller Class Initialized
INFO - 2022-03-11 02:38:49 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:38:49 --> Encrypt Class Initialized
DEBUG - 2022-03-11 02:38:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 02:38:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 02:38:49 --> Email Class Initialized
INFO - 2022-03-11 02:38:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 02:38:49 --> Calendar Class Initialized
INFO - 2022-03-11 02:38:49 --> Model "Login_model" initialized
INFO - 2022-03-11 02:38:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 02:38:49 --> Final output sent to browser
DEBUG - 2022-03-11 02:38:49 --> Total execution time: 0.0315
ERROR - 2022-03-11 02:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:38:50 --> Config Class Initialized
INFO - 2022-03-11 02:38:50 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:38:50 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:38:50 --> Utf8 Class Initialized
INFO - 2022-03-11 02:38:50 --> URI Class Initialized
DEBUG - 2022-03-11 02:38:50 --> No URI present. Default controller set.
INFO - 2022-03-11 02:38:50 --> Router Class Initialized
INFO - 2022-03-11 02:38:50 --> Output Class Initialized
INFO - 2022-03-11 02:38:50 --> Security Class Initialized
DEBUG - 2022-03-11 02:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:38:50 --> Input Class Initialized
INFO - 2022-03-11 02:38:50 --> Language Class Initialized
INFO - 2022-03-11 02:38:50 --> Loader Class Initialized
INFO - 2022-03-11 02:38:50 --> Helper loaded: url_helper
INFO - 2022-03-11 02:38:50 --> Helper loaded: form_helper
INFO - 2022-03-11 02:38:50 --> Helper loaded: common_helper
INFO - 2022-03-11 02:38:50 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:38:50 --> Controller Class Initialized
INFO - 2022-03-11 02:38:50 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:38:50 --> Encrypt Class Initialized
DEBUG - 2022-03-11 02:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 02:38:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 02:38:50 --> Email Class Initialized
INFO - 2022-03-11 02:38:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 02:38:50 --> Calendar Class Initialized
INFO - 2022-03-11 02:38:50 --> Model "Login_model" initialized
INFO - 2022-03-11 02:38:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 02:38:50 --> Final output sent to browser
DEBUG - 2022-03-11 02:38:50 --> Total execution time: 0.0220
ERROR - 2022-03-11 02:39:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:39:12 --> Config Class Initialized
INFO - 2022-03-11 02:39:12 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:39:12 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:39:12 --> Utf8 Class Initialized
INFO - 2022-03-11 02:39:12 --> URI Class Initialized
INFO - 2022-03-11 02:39:12 --> Router Class Initialized
INFO - 2022-03-11 02:39:12 --> Output Class Initialized
INFO - 2022-03-11 02:39:12 --> Security Class Initialized
DEBUG - 2022-03-11 02:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:39:12 --> Input Class Initialized
INFO - 2022-03-11 02:39:12 --> Language Class Initialized
INFO - 2022-03-11 02:39:12 --> Loader Class Initialized
INFO - 2022-03-11 02:39:12 --> Helper loaded: url_helper
INFO - 2022-03-11 02:39:12 --> Helper loaded: form_helper
INFO - 2022-03-11 02:39:12 --> Helper loaded: common_helper
INFO - 2022-03-11 02:39:12 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:39:12 --> Controller Class Initialized
INFO - 2022-03-11 02:39:12 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:39:12 --> Encrypt Class Initialized
DEBUG - 2022-03-11 02:39:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 02:39:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 02:39:13 --> Email Class Initialized
INFO - 2022-03-11 02:39:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 02:39:13 --> Calendar Class Initialized
INFO - 2022-03-11 02:39:13 --> Model "Login_model" initialized
INFO - 2022-03-11 02:39:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-11 02:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:39:13 --> Config Class Initialized
INFO - 2022-03-11 02:39:13 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:39:13 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:39:13 --> Utf8 Class Initialized
INFO - 2022-03-11 02:39:13 --> URI Class Initialized
INFO - 2022-03-11 02:39:13 --> Router Class Initialized
INFO - 2022-03-11 02:39:13 --> Output Class Initialized
INFO - 2022-03-11 02:39:13 --> Security Class Initialized
DEBUG - 2022-03-11 02:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:39:13 --> Input Class Initialized
INFO - 2022-03-11 02:39:13 --> Language Class Initialized
INFO - 2022-03-11 02:39:13 --> Loader Class Initialized
INFO - 2022-03-11 02:39:13 --> Helper loaded: url_helper
INFO - 2022-03-11 02:39:13 --> Helper loaded: form_helper
INFO - 2022-03-11 02:39:13 --> Helper loaded: common_helper
INFO - 2022-03-11 02:39:13 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:39:13 --> Controller Class Initialized
INFO - 2022-03-11 02:39:13 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:39:13 --> Encrypt Class Initialized
INFO - 2022-03-11 02:39:13 --> Model "Login_model" initialized
INFO - 2022-03-11 02:39:13 --> Model "Dashboard_model" initialized
INFO - 2022-03-11 02:39:13 --> Model "Case_model" initialized
INFO - 2022-03-11 02:39:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:39:14 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-11 02:39:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:39:14 --> Final output sent to browser
DEBUG - 2022-03-11 02:39:14 --> Total execution time: 0.3967
ERROR - 2022-03-11 02:39:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:39:28 --> Config Class Initialized
INFO - 2022-03-11 02:39:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:39:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:39:28 --> Utf8 Class Initialized
INFO - 2022-03-11 02:39:28 --> URI Class Initialized
INFO - 2022-03-11 02:39:28 --> Router Class Initialized
INFO - 2022-03-11 02:39:28 --> Output Class Initialized
INFO - 2022-03-11 02:39:28 --> Security Class Initialized
DEBUG - 2022-03-11 02:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:39:28 --> Input Class Initialized
INFO - 2022-03-11 02:39:28 --> Language Class Initialized
INFO - 2022-03-11 02:39:28 --> Loader Class Initialized
INFO - 2022-03-11 02:39:28 --> Helper loaded: url_helper
INFO - 2022-03-11 02:39:28 --> Helper loaded: form_helper
INFO - 2022-03-11 02:39:28 --> Helper loaded: common_helper
INFO - 2022-03-11 02:39:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:39:28 --> Controller Class Initialized
INFO - 2022-03-11 02:39:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:39:28 --> Encrypt Class Initialized
INFO - 2022-03-11 02:39:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:39:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:39:28 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:39:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:39:28 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:39:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:39:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 02:39:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:39:28 --> Final output sent to browser
DEBUG - 2022-03-11 02:39:28 --> Total execution time: 0.0530
ERROR - 2022-03-11 02:39:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:39:38 --> Config Class Initialized
INFO - 2022-03-11 02:39:38 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:39:38 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:39:38 --> Utf8 Class Initialized
INFO - 2022-03-11 02:39:38 --> URI Class Initialized
INFO - 2022-03-11 02:39:38 --> Router Class Initialized
INFO - 2022-03-11 02:39:38 --> Output Class Initialized
INFO - 2022-03-11 02:39:38 --> Security Class Initialized
DEBUG - 2022-03-11 02:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:39:38 --> Input Class Initialized
INFO - 2022-03-11 02:39:38 --> Language Class Initialized
INFO - 2022-03-11 02:39:38 --> Loader Class Initialized
INFO - 2022-03-11 02:39:38 --> Helper loaded: url_helper
INFO - 2022-03-11 02:39:38 --> Helper loaded: form_helper
INFO - 2022-03-11 02:39:38 --> Helper loaded: common_helper
INFO - 2022-03-11 02:39:38 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:39:38 --> Controller Class Initialized
INFO - 2022-03-11 02:39:38 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:39:38 --> Encrypt Class Initialized
INFO - 2022-03-11 02:39:38 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:39:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:39:38 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:39:38 --> Model "Users_model" initialized
INFO - 2022-03-11 02:39:38 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:39:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:39:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:39:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:39:38 --> Final output sent to browser
DEBUG - 2022-03-11 02:39:38 --> Total execution time: 0.0907
ERROR - 2022-03-11 02:39:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:39:48 --> Config Class Initialized
INFO - 2022-03-11 02:39:48 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:39:48 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:39:48 --> Utf8 Class Initialized
INFO - 2022-03-11 02:39:48 --> URI Class Initialized
INFO - 2022-03-11 02:39:48 --> Router Class Initialized
INFO - 2022-03-11 02:39:48 --> Output Class Initialized
INFO - 2022-03-11 02:39:48 --> Security Class Initialized
DEBUG - 2022-03-11 02:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:39:48 --> Input Class Initialized
INFO - 2022-03-11 02:39:48 --> Language Class Initialized
INFO - 2022-03-11 02:39:48 --> Loader Class Initialized
INFO - 2022-03-11 02:39:48 --> Helper loaded: url_helper
INFO - 2022-03-11 02:39:48 --> Helper loaded: form_helper
INFO - 2022-03-11 02:39:48 --> Helper loaded: common_helper
INFO - 2022-03-11 02:39:48 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:39:48 --> Controller Class Initialized
INFO - 2022-03-11 02:39:48 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:39:48 --> Encrypt Class Initialized
INFO - 2022-03-11 02:39:48 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:39:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:39:48 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:39:48 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:39:48 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:39:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:39:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 02:39:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:39:48 --> Final output sent to browser
DEBUG - 2022-03-11 02:39:48 --> Total execution time: 0.0860
ERROR - 2022-03-11 02:40:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:40:44 --> Config Class Initialized
INFO - 2022-03-11 02:40:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:40:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:40:44 --> Utf8 Class Initialized
INFO - 2022-03-11 02:40:44 --> URI Class Initialized
INFO - 2022-03-11 02:40:44 --> Router Class Initialized
INFO - 2022-03-11 02:40:44 --> Output Class Initialized
INFO - 2022-03-11 02:40:44 --> Security Class Initialized
DEBUG - 2022-03-11 02:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:40:44 --> Input Class Initialized
INFO - 2022-03-11 02:40:44 --> Language Class Initialized
INFO - 2022-03-11 02:40:44 --> Loader Class Initialized
INFO - 2022-03-11 02:40:44 --> Helper loaded: url_helper
INFO - 2022-03-11 02:40:44 --> Helper loaded: form_helper
INFO - 2022-03-11 02:40:44 --> Helper loaded: common_helper
INFO - 2022-03-11 02:40:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:40:44 --> Controller Class Initialized
INFO - 2022-03-11 02:40:44 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:40:44 --> Encrypt Class Initialized
INFO - 2022-03-11 02:40:44 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:40:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:40:44 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:40:44 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:40:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:40:45 --> Config Class Initialized
INFO - 2022-03-11 02:40:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:40:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:40:45 --> Utf8 Class Initialized
INFO - 2022-03-11 02:40:45 --> URI Class Initialized
INFO - 2022-03-11 02:40:45 --> Router Class Initialized
INFO - 2022-03-11 02:40:45 --> Output Class Initialized
INFO - 2022-03-11 02:40:45 --> Security Class Initialized
DEBUG - 2022-03-11 02:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:40:45 --> Input Class Initialized
INFO - 2022-03-11 02:40:45 --> Language Class Initialized
INFO - 2022-03-11 02:40:45 --> Loader Class Initialized
INFO - 2022-03-11 02:40:45 --> Helper loaded: url_helper
INFO - 2022-03-11 02:40:45 --> Helper loaded: form_helper
INFO - 2022-03-11 02:40:45 --> Helper loaded: common_helper
INFO - 2022-03-11 02:40:45 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:40:45 --> Controller Class Initialized
INFO - 2022-03-11 02:40:45 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:40:45 --> Encrypt Class Initialized
INFO - 2022-03-11 02:40:45 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:40:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:40:45 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:40:45 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:40:45 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:40:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:40:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 02:40:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:40:45 --> Final output sent to browser
DEBUG - 2022-03-11 02:40:45 --> Total execution time: 0.0522
ERROR - 2022-03-11 02:40:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:40:46 --> Config Class Initialized
INFO - 2022-03-11 02:40:46 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:40:46 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:40:46 --> Utf8 Class Initialized
INFO - 2022-03-11 02:40:46 --> URI Class Initialized
INFO - 2022-03-11 02:40:46 --> Router Class Initialized
INFO - 2022-03-11 02:40:46 --> Output Class Initialized
INFO - 2022-03-11 02:40:46 --> Security Class Initialized
DEBUG - 2022-03-11 02:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:40:46 --> Input Class Initialized
INFO - 2022-03-11 02:40:46 --> Language Class Initialized
INFO - 2022-03-11 02:40:46 --> Loader Class Initialized
INFO - 2022-03-11 02:40:46 --> Helper loaded: url_helper
INFO - 2022-03-11 02:40:46 --> Helper loaded: form_helper
INFO - 2022-03-11 02:40:46 --> Helper loaded: common_helper
INFO - 2022-03-11 02:40:46 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:40:46 --> Controller Class Initialized
INFO - 2022-03-11 02:40:46 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:40:46 --> Encrypt Class Initialized
INFO - 2022-03-11 02:40:46 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:40:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:40:46 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:40:46 --> Model "Users_model" initialized
INFO - 2022-03-11 02:40:46 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:40:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:40:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:40:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:40:46 --> Final output sent to browser
DEBUG - 2022-03-11 02:40:46 --> Total execution time: 0.0909
ERROR - 2022-03-11 02:41:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:41:17 --> Config Class Initialized
INFO - 2022-03-11 02:41:17 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:41:17 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:41:17 --> Utf8 Class Initialized
INFO - 2022-03-11 02:41:17 --> URI Class Initialized
INFO - 2022-03-11 02:41:17 --> Router Class Initialized
INFO - 2022-03-11 02:41:17 --> Output Class Initialized
INFO - 2022-03-11 02:41:17 --> Security Class Initialized
DEBUG - 2022-03-11 02:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:41:17 --> Input Class Initialized
INFO - 2022-03-11 02:41:17 --> Language Class Initialized
INFO - 2022-03-11 02:41:17 --> Loader Class Initialized
INFO - 2022-03-11 02:41:17 --> Helper loaded: url_helper
INFO - 2022-03-11 02:41:17 --> Helper loaded: form_helper
INFO - 2022-03-11 02:41:17 --> Helper loaded: common_helper
INFO - 2022-03-11 02:41:17 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:41:17 --> Controller Class Initialized
INFO - 2022-03-11 02:41:17 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:41:17 --> Encrypt Class Initialized
INFO - 2022-03-11 02:41:17 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:41:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:41:17 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:41:17 --> Model "Users_model" initialized
INFO - 2022-03-11 02:41:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:41:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:41:17 --> Config Class Initialized
INFO - 2022-03-11 02:41:17 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:41:17 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:41:17 --> Utf8 Class Initialized
INFO - 2022-03-11 02:41:17 --> URI Class Initialized
INFO - 2022-03-11 02:41:17 --> Router Class Initialized
INFO - 2022-03-11 02:41:17 --> Output Class Initialized
INFO - 2022-03-11 02:41:17 --> Security Class Initialized
DEBUG - 2022-03-11 02:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:41:17 --> Input Class Initialized
INFO - 2022-03-11 02:41:17 --> Language Class Initialized
INFO - 2022-03-11 02:41:17 --> Loader Class Initialized
INFO - 2022-03-11 02:41:17 --> Helper loaded: url_helper
INFO - 2022-03-11 02:41:17 --> Helper loaded: form_helper
INFO - 2022-03-11 02:41:17 --> Helper loaded: common_helper
INFO - 2022-03-11 02:41:17 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:41:17 --> Controller Class Initialized
INFO - 2022-03-11 02:41:17 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:41:17 --> Encrypt Class Initialized
INFO - 2022-03-11 02:41:17 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:41:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:41:17 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:41:17 --> Model "Users_model" initialized
INFO - 2022-03-11 02:41:17 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:41:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:41:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:41:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:41:17 --> Final output sent to browser
DEBUG - 2022-03-11 02:41:17 --> Total execution time: 0.0645
ERROR - 2022-03-11 02:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:42:24 --> Config Class Initialized
INFO - 2022-03-11 02:42:24 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:42:24 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:42:24 --> Utf8 Class Initialized
INFO - 2022-03-11 02:42:24 --> URI Class Initialized
INFO - 2022-03-11 02:42:24 --> Router Class Initialized
INFO - 2022-03-11 02:42:24 --> Output Class Initialized
INFO - 2022-03-11 02:42:24 --> Security Class Initialized
DEBUG - 2022-03-11 02:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:42:24 --> Input Class Initialized
INFO - 2022-03-11 02:42:24 --> Language Class Initialized
INFO - 2022-03-11 02:42:24 --> Loader Class Initialized
INFO - 2022-03-11 02:42:24 --> Helper loaded: url_helper
INFO - 2022-03-11 02:42:24 --> Helper loaded: form_helper
INFO - 2022-03-11 02:42:24 --> Helper loaded: common_helper
INFO - 2022-03-11 02:42:24 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:42:24 --> Controller Class Initialized
INFO - 2022-03-11 02:42:24 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:42:24 --> Encrypt Class Initialized
INFO - 2022-03-11 02:42:24 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:42:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:42:24 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:42:24 --> Model "Users_model" initialized
INFO - 2022-03-11 02:42:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:42:24 --> Config Class Initialized
INFO - 2022-03-11 02:42:24 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:42:24 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:42:24 --> Utf8 Class Initialized
INFO - 2022-03-11 02:42:24 --> URI Class Initialized
INFO - 2022-03-11 02:42:24 --> Router Class Initialized
INFO - 2022-03-11 02:42:24 --> Output Class Initialized
INFO - 2022-03-11 02:42:24 --> Security Class Initialized
DEBUG - 2022-03-11 02:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:42:24 --> Input Class Initialized
INFO - 2022-03-11 02:42:24 --> Language Class Initialized
INFO - 2022-03-11 02:42:24 --> Loader Class Initialized
INFO - 2022-03-11 02:42:24 --> Helper loaded: url_helper
INFO - 2022-03-11 02:42:24 --> Helper loaded: form_helper
INFO - 2022-03-11 02:42:24 --> Helper loaded: common_helper
INFO - 2022-03-11 02:42:24 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:42:24 --> Controller Class Initialized
INFO - 2022-03-11 02:42:24 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:42:24 --> Encrypt Class Initialized
INFO - 2022-03-11 02:42:24 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:42:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:42:24 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:42:24 --> Model "Users_model" initialized
INFO - 2022-03-11 02:42:24 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:42:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:42:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:42:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:42:24 --> Final output sent to browser
DEBUG - 2022-03-11 02:42:24 --> Total execution time: 0.0551
ERROR - 2022-03-11 02:42:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:42:44 --> Config Class Initialized
INFO - 2022-03-11 02:42:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:42:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:42:44 --> Utf8 Class Initialized
INFO - 2022-03-11 02:42:44 --> URI Class Initialized
INFO - 2022-03-11 02:42:44 --> Router Class Initialized
INFO - 2022-03-11 02:42:44 --> Output Class Initialized
INFO - 2022-03-11 02:42:44 --> Security Class Initialized
DEBUG - 2022-03-11 02:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:42:44 --> Input Class Initialized
INFO - 2022-03-11 02:42:44 --> Language Class Initialized
INFO - 2022-03-11 02:42:44 --> Loader Class Initialized
INFO - 2022-03-11 02:42:44 --> Helper loaded: url_helper
INFO - 2022-03-11 02:42:44 --> Helper loaded: form_helper
INFO - 2022-03-11 02:42:44 --> Helper loaded: common_helper
INFO - 2022-03-11 02:42:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:42:44 --> Controller Class Initialized
INFO - 2022-03-11 02:42:44 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:42:44 --> Encrypt Class Initialized
INFO - 2022-03-11 02:42:44 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:42:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:42:44 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:42:44 --> Model "Users_model" initialized
INFO - 2022-03-11 02:42:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:42:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:42:45 --> Config Class Initialized
INFO - 2022-03-11 02:42:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:42:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:42:45 --> Utf8 Class Initialized
INFO - 2022-03-11 02:42:45 --> URI Class Initialized
INFO - 2022-03-11 02:42:45 --> Router Class Initialized
INFO - 2022-03-11 02:42:45 --> Output Class Initialized
INFO - 2022-03-11 02:42:45 --> Security Class Initialized
DEBUG - 2022-03-11 02:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:42:45 --> Input Class Initialized
INFO - 2022-03-11 02:42:45 --> Language Class Initialized
INFO - 2022-03-11 02:42:45 --> Loader Class Initialized
INFO - 2022-03-11 02:42:45 --> Helper loaded: url_helper
INFO - 2022-03-11 02:42:45 --> Helper loaded: form_helper
INFO - 2022-03-11 02:42:45 --> Helper loaded: common_helper
INFO - 2022-03-11 02:42:45 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:42:45 --> Controller Class Initialized
INFO - 2022-03-11 02:42:45 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:42:45 --> Encrypt Class Initialized
INFO - 2022-03-11 02:42:45 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:42:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:42:45 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:42:45 --> Model "Users_model" initialized
INFO - 2022-03-11 02:42:45 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:42:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:42:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:42:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:42:45 --> Final output sent to browser
DEBUG - 2022-03-11 02:42:45 --> Total execution time: 0.0850
ERROR - 2022-03-11 02:43:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:43:05 --> Config Class Initialized
INFO - 2022-03-11 02:43:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:43:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:43:05 --> Utf8 Class Initialized
INFO - 2022-03-11 02:43:05 --> URI Class Initialized
INFO - 2022-03-11 02:43:05 --> Router Class Initialized
INFO - 2022-03-11 02:43:05 --> Output Class Initialized
INFO - 2022-03-11 02:43:05 --> Security Class Initialized
DEBUG - 2022-03-11 02:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:43:05 --> Input Class Initialized
INFO - 2022-03-11 02:43:05 --> Language Class Initialized
INFO - 2022-03-11 02:43:06 --> Loader Class Initialized
INFO - 2022-03-11 02:43:06 --> Helper loaded: url_helper
INFO - 2022-03-11 02:43:06 --> Helper loaded: form_helper
INFO - 2022-03-11 02:43:06 --> Helper loaded: common_helper
INFO - 2022-03-11 02:43:06 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:43:06 --> Controller Class Initialized
INFO - 2022-03-11 02:43:06 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:43:06 --> Encrypt Class Initialized
INFO - 2022-03-11 02:43:06 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:43:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:43:06 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:43:06 --> Model "Users_model" initialized
INFO - 2022-03-11 02:43:06 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:43:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:43:06 --> Config Class Initialized
INFO - 2022-03-11 02:43:06 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:43:06 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:43:06 --> Utf8 Class Initialized
INFO - 2022-03-11 02:43:06 --> URI Class Initialized
INFO - 2022-03-11 02:43:06 --> Router Class Initialized
INFO - 2022-03-11 02:43:06 --> Output Class Initialized
INFO - 2022-03-11 02:43:06 --> Security Class Initialized
DEBUG - 2022-03-11 02:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:43:06 --> Input Class Initialized
INFO - 2022-03-11 02:43:06 --> Language Class Initialized
INFO - 2022-03-11 02:43:06 --> Loader Class Initialized
INFO - 2022-03-11 02:43:06 --> Helper loaded: url_helper
INFO - 2022-03-11 02:43:06 --> Helper loaded: form_helper
INFO - 2022-03-11 02:43:06 --> Helper loaded: common_helper
INFO - 2022-03-11 02:43:06 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:43:06 --> Controller Class Initialized
INFO - 2022-03-11 02:43:06 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:43:06 --> Encrypt Class Initialized
INFO - 2022-03-11 02:43:06 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:43:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:43:06 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:43:06 --> Model "Users_model" initialized
INFO - 2022-03-11 02:43:06 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:43:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:43:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:43:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:43:06 --> Final output sent to browser
DEBUG - 2022-03-11 02:43:06 --> Total execution time: 0.0878
ERROR - 2022-03-11 02:43:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:43:43 --> Config Class Initialized
INFO - 2022-03-11 02:43:43 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:43:43 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:43:43 --> Utf8 Class Initialized
INFO - 2022-03-11 02:43:43 --> URI Class Initialized
INFO - 2022-03-11 02:43:43 --> Router Class Initialized
INFO - 2022-03-11 02:43:43 --> Output Class Initialized
INFO - 2022-03-11 02:43:43 --> Security Class Initialized
DEBUG - 2022-03-11 02:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:43:43 --> Input Class Initialized
INFO - 2022-03-11 02:43:43 --> Language Class Initialized
INFO - 2022-03-11 02:43:43 --> Loader Class Initialized
INFO - 2022-03-11 02:43:43 --> Helper loaded: url_helper
INFO - 2022-03-11 02:43:43 --> Helper loaded: form_helper
INFO - 2022-03-11 02:43:43 --> Helper loaded: common_helper
INFO - 2022-03-11 02:43:43 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:43:43 --> Controller Class Initialized
INFO - 2022-03-11 02:43:43 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:43:43 --> Encrypt Class Initialized
INFO - 2022-03-11 02:43:43 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:43:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:43:43 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:43:43 --> Model "Users_model" initialized
INFO - 2022-03-11 02:43:43 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:43:43 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-11 02:43:45 --> Final output sent to browser
DEBUG - 2022-03-11 02:43:45 --> Total execution time: 2.1860
ERROR - 2022-03-11 02:45:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:45:42 --> Config Class Initialized
INFO - 2022-03-11 02:45:42 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:45:42 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:45:42 --> Utf8 Class Initialized
INFO - 2022-03-11 02:45:42 --> URI Class Initialized
DEBUG - 2022-03-11 02:45:42 --> No URI present. Default controller set.
INFO - 2022-03-11 02:45:42 --> Router Class Initialized
INFO - 2022-03-11 02:45:42 --> Output Class Initialized
INFO - 2022-03-11 02:45:42 --> Security Class Initialized
DEBUG - 2022-03-11 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:45:42 --> Input Class Initialized
INFO - 2022-03-11 02:45:42 --> Language Class Initialized
INFO - 2022-03-11 02:45:42 --> Loader Class Initialized
INFO - 2022-03-11 02:45:42 --> Helper loaded: url_helper
INFO - 2022-03-11 02:45:42 --> Helper loaded: form_helper
INFO - 2022-03-11 02:45:42 --> Helper loaded: common_helper
INFO - 2022-03-11 02:45:42 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:45:42 --> Controller Class Initialized
INFO - 2022-03-11 02:45:42 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:45:42 --> Encrypt Class Initialized
DEBUG - 2022-03-11 02:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 02:45:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 02:45:42 --> Email Class Initialized
INFO - 2022-03-11 02:45:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 02:45:42 --> Calendar Class Initialized
INFO - 2022-03-11 02:45:42 --> Model "Login_model" initialized
INFO - 2022-03-11 02:45:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 02:45:42 --> Final output sent to browser
DEBUG - 2022-03-11 02:45:42 --> Total execution time: 0.0260
ERROR - 2022-03-11 02:46:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:46:54 --> Config Class Initialized
INFO - 2022-03-11 02:46:54 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:46:54 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:46:54 --> Utf8 Class Initialized
INFO - 2022-03-11 02:46:54 --> URI Class Initialized
INFO - 2022-03-11 02:46:54 --> Router Class Initialized
INFO - 2022-03-11 02:46:54 --> Output Class Initialized
INFO - 2022-03-11 02:46:54 --> Security Class Initialized
DEBUG - 2022-03-11 02:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:46:54 --> Input Class Initialized
INFO - 2022-03-11 02:46:54 --> Language Class Initialized
INFO - 2022-03-11 02:46:54 --> Loader Class Initialized
INFO - 2022-03-11 02:46:54 --> Helper loaded: url_helper
INFO - 2022-03-11 02:46:54 --> Helper loaded: form_helper
INFO - 2022-03-11 02:46:54 --> Helper loaded: common_helper
INFO - 2022-03-11 02:46:54 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:46:54 --> Controller Class Initialized
INFO - 2022-03-11 02:46:54 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:46:54 --> Encrypt Class Initialized
DEBUG - 2022-03-11 02:46:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 02:46:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 02:46:54 --> Email Class Initialized
INFO - 2022-03-11 02:46:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 02:46:54 --> Calendar Class Initialized
INFO - 2022-03-11 02:46:54 --> Model "Login_model" initialized
INFO - 2022-03-11 02:46:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 02:46:54 --> Final output sent to browser
DEBUG - 2022-03-11 02:46:54 --> Total execution time: 0.0238
ERROR - 2022-03-11 02:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:50:03 --> Config Class Initialized
INFO - 2022-03-11 02:50:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:50:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:50:03 --> Utf8 Class Initialized
INFO - 2022-03-11 02:50:03 --> URI Class Initialized
DEBUG - 2022-03-11 02:50:03 --> No URI present. Default controller set.
INFO - 2022-03-11 02:50:03 --> Router Class Initialized
INFO - 2022-03-11 02:50:03 --> Output Class Initialized
INFO - 2022-03-11 02:50:03 --> Security Class Initialized
DEBUG - 2022-03-11 02:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:50:03 --> Input Class Initialized
INFO - 2022-03-11 02:50:03 --> Language Class Initialized
INFO - 2022-03-11 02:50:03 --> Loader Class Initialized
INFO - 2022-03-11 02:50:03 --> Helper loaded: url_helper
INFO - 2022-03-11 02:50:03 --> Helper loaded: form_helper
INFO - 2022-03-11 02:50:03 --> Helper loaded: common_helper
INFO - 2022-03-11 02:50:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:50:03 --> Controller Class Initialized
INFO - 2022-03-11 02:50:03 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:50:03 --> Encrypt Class Initialized
DEBUG - 2022-03-11 02:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 02:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 02:50:03 --> Email Class Initialized
INFO - 2022-03-11 02:50:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 02:50:03 --> Calendar Class Initialized
INFO - 2022-03-11 02:50:03 --> Model "Login_model" initialized
ERROR - 2022-03-11 02:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:50:03 --> Config Class Initialized
INFO - 2022-03-11 02:50:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:50:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:50:03 --> Utf8 Class Initialized
INFO - 2022-03-11 02:50:03 --> URI Class Initialized
INFO - 2022-03-11 02:50:03 --> Router Class Initialized
INFO - 2022-03-11 02:50:03 --> Output Class Initialized
INFO - 2022-03-11 02:50:03 --> Security Class Initialized
DEBUG - 2022-03-11 02:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:50:03 --> Input Class Initialized
INFO - 2022-03-11 02:50:03 --> Language Class Initialized
INFO - 2022-03-11 02:50:03 --> Loader Class Initialized
INFO - 2022-03-11 02:50:03 --> Helper loaded: url_helper
INFO - 2022-03-11 02:50:03 --> Helper loaded: form_helper
INFO - 2022-03-11 02:50:03 --> Helper loaded: common_helper
INFO - 2022-03-11 02:50:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:50:04 --> Controller Class Initialized
INFO - 2022-03-11 02:50:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:50:04 --> Encrypt Class Initialized
INFO - 2022-03-11 02:50:04 --> Model "Diseases_model" initialized
INFO - 2022-03-11 02:50:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:50:04 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-11 02:50:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:50:04 --> Final output sent to browser
DEBUG - 2022-03-11 02:50:04 --> Total execution time: 0.0393
ERROR - 2022-03-11 02:50:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:50:04 --> Config Class Initialized
INFO - 2022-03-11 02:50:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:50:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:50:04 --> Utf8 Class Initialized
INFO - 2022-03-11 02:50:04 --> URI Class Initialized
DEBUG - 2022-03-11 02:50:04 --> No URI present. Default controller set.
INFO - 2022-03-11 02:50:04 --> Router Class Initialized
INFO - 2022-03-11 02:50:04 --> Output Class Initialized
INFO - 2022-03-11 02:50:04 --> Security Class Initialized
DEBUG - 2022-03-11 02:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:50:04 --> Input Class Initialized
INFO - 2022-03-11 02:50:04 --> Language Class Initialized
INFO - 2022-03-11 02:50:04 --> Loader Class Initialized
INFO - 2022-03-11 02:50:04 --> Helper loaded: url_helper
INFO - 2022-03-11 02:50:04 --> Helper loaded: form_helper
INFO - 2022-03-11 02:50:04 --> Helper loaded: common_helper
INFO - 2022-03-11 02:50:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:50:04 --> Controller Class Initialized
INFO - 2022-03-11 02:50:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:50:04 --> Encrypt Class Initialized
DEBUG - 2022-03-11 02:50:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 02:50:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 02:50:04 --> Email Class Initialized
INFO - 2022-03-11 02:50:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 02:50:04 --> Calendar Class Initialized
INFO - 2022-03-11 02:50:04 --> Model "Login_model" initialized
ERROR - 2022-03-11 02:50:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:50:05 --> Config Class Initialized
INFO - 2022-03-11 02:50:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:50:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:50:05 --> Utf8 Class Initialized
INFO - 2022-03-11 02:50:05 --> URI Class Initialized
INFO - 2022-03-11 02:50:05 --> Router Class Initialized
INFO - 2022-03-11 02:50:05 --> Output Class Initialized
INFO - 2022-03-11 02:50:05 --> Security Class Initialized
DEBUG - 2022-03-11 02:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:50:05 --> Input Class Initialized
INFO - 2022-03-11 02:50:05 --> Language Class Initialized
INFO - 2022-03-11 02:50:05 --> Loader Class Initialized
INFO - 2022-03-11 02:50:05 --> Helper loaded: url_helper
INFO - 2022-03-11 02:50:05 --> Helper loaded: form_helper
INFO - 2022-03-11 02:50:05 --> Helper loaded: common_helper
INFO - 2022-03-11 02:50:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:50:05 --> Controller Class Initialized
INFO - 2022-03-11 02:50:05 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:50:05 --> Encrypt Class Initialized
INFO - 2022-03-11 02:50:05 --> Model "Diseases_model" initialized
INFO - 2022-03-11 02:50:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:50:05 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-11 02:50:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:50:05 --> Final output sent to browser
DEBUG - 2022-03-11 02:50:05 --> Total execution time: 0.0257
ERROR - 2022-03-11 02:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:50:13 --> Config Class Initialized
INFO - 2022-03-11 02:50:13 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:50:13 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:50:13 --> Utf8 Class Initialized
INFO - 2022-03-11 02:50:13 --> URI Class Initialized
INFO - 2022-03-11 02:50:13 --> Router Class Initialized
INFO - 2022-03-11 02:50:13 --> Output Class Initialized
INFO - 2022-03-11 02:50:13 --> Security Class Initialized
DEBUG - 2022-03-11 02:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:50:13 --> Input Class Initialized
INFO - 2022-03-11 02:50:13 --> Language Class Initialized
INFO - 2022-03-11 02:50:13 --> Loader Class Initialized
INFO - 2022-03-11 02:50:13 --> Helper loaded: url_helper
INFO - 2022-03-11 02:50:13 --> Helper loaded: form_helper
INFO - 2022-03-11 02:50:13 --> Helper loaded: common_helper
INFO - 2022-03-11 02:50:13 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:50:13 --> Controller Class Initialized
INFO - 2022-03-11 02:50:13 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:50:13 --> Encrypt Class Initialized
INFO - 2022-03-11 02:50:13 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:50:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:50:13 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:50:13 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:50:13 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:50:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:50:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 02:50:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:50:13 --> Final output sent to browser
DEBUG - 2022-03-11 02:50:13 --> Total execution time: 0.0545
ERROR - 2022-03-11 02:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:50:26 --> Config Class Initialized
INFO - 2022-03-11 02:50:26 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:50:26 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:50:26 --> Utf8 Class Initialized
INFO - 2022-03-11 02:50:26 --> URI Class Initialized
INFO - 2022-03-11 02:50:26 --> Router Class Initialized
INFO - 2022-03-11 02:50:26 --> Output Class Initialized
INFO - 2022-03-11 02:50:26 --> Security Class Initialized
DEBUG - 2022-03-11 02:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:50:26 --> Input Class Initialized
INFO - 2022-03-11 02:50:26 --> Language Class Initialized
INFO - 2022-03-11 02:50:26 --> Loader Class Initialized
INFO - 2022-03-11 02:50:26 --> Helper loaded: url_helper
INFO - 2022-03-11 02:50:26 --> Helper loaded: form_helper
INFO - 2022-03-11 02:50:26 --> Helper loaded: common_helper
INFO - 2022-03-11 02:50:26 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:50:26 --> Controller Class Initialized
INFO - 2022-03-11 02:50:26 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:50:26 --> Encrypt Class Initialized
INFO - 2022-03-11 02:50:26 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:50:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:50:26 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:50:26 --> Model "Users_model" initialized
INFO - 2022-03-11 02:50:26 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:50:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:50:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:50:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:50:26 --> Final output sent to browser
DEBUG - 2022-03-11 02:50:26 --> Total execution time: 0.0591
ERROR - 2022-03-11 02:51:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:51:02 --> Config Class Initialized
INFO - 2022-03-11 02:51:02 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:51:02 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:51:02 --> Utf8 Class Initialized
INFO - 2022-03-11 02:51:02 --> URI Class Initialized
INFO - 2022-03-11 02:51:02 --> Router Class Initialized
INFO - 2022-03-11 02:51:02 --> Output Class Initialized
INFO - 2022-03-11 02:51:02 --> Security Class Initialized
DEBUG - 2022-03-11 02:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:51:02 --> Input Class Initialized
INFO - 2022-03-11 02:51:02 --> Language Class Initialized
INFO - 2022-03-11 02:51:02 --> Loader Class Initialized
INFO - 2022-03-11 02:51:02 --> Helper loaded: url_helper
INFO - 2022-03-11 02:51:02 --> Helper loaded: form_helper
INFO - 2022-03-11 02:51:02 --> Helper loaded: common_helper
INFO - 2022-03-11 02:51:02 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:51:02 --> Controller Class Initialized
INFO - 2022-03-11 02:51:02 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:51:02 --> Encrypt Class Initialized
INFO - 2022-03-11 02:51:02 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:51:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:51:02 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:51:02 --> Model "Users_model" initialized
INFO - 2022-03-11 02:51:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:51:03 --> Config Class Initialized
INFO - 2022-03-11 02:51:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:51:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:51:03 --> Utf8 Class Initialized
INFO - 2022-03-11 02:51:03 --> URI Class Initialized
INFO - 2022-03-11 02:51:03 --> Router Class Initialized
INFO - 2022-03-11 02:51:03 --> Output Class Initialized
INFO - 2022-03-11 02:51:03 --> Security Class Initialized
DEBUG - 2022-03-11 02:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:51:03 --> Input Class Initialized
INFO - 2022-03-11 02:51:03 --> Language Class Initialized
INFO - 2022-03-11 02:51:03 --> Loader Class Initialized
INFO - 2022-03-11 02:51:03 --> Helper loaded: url_helper
INFO - 2022-03-11 02:51:03 --> Helper loaded: form_helper
INFO - 2022-03-11 02:51:03 --> Helper loaded: common_helper
INFO - 2022-03-11 02:51:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:51:03 --> Controller Class Initialized
INFO - 2022-03-11 02:51:03 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:51:03 --> Encrypt Class Initialized
INFO - 2022-03-11 02:51:03 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:51:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:51:03 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:51:03 --> Model "Users_model" initialized
INFO - 2022-03-11 02:51:03 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:51:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:51:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:51:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:51:03 --> Final output sent to browser
DEBUG - 2022-03-11 02:51:03 --> Total execution time: 0.0523
ERROR - 2022-03-11 02:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:51:07 --> Config Class Initialized
INFO - 2022-03-11 02:51:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:51:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:51:07 --> Utf8 Class Initialized
INFO - 2022-03-11 02:51:07 --> URI Class Initialized
INFO - 2022-03-11 02:51:07 --> Router Class Initialized
INFO - 2022-03-11 02:51:07 --> Output Class Initialized
INFO - 2022-03-11 02:51:07 --> Security Class Initialized
DEBUG - 2022-03-11 02:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:51:07 --> Input Class Initialized
INFO - 2022-03-11 02:51:07 --> Language Class Initialized
INFO - 2022-03-11 02:51:07 --> Loader Class Initialized
INFO - 2022-03-11 02:51:07 --> Helper loaded: url_helper
INFO - 2022-03-11 02:51:07 --> Helper loaded: form_helper
INFO - 2022-03-11 02:51:07 --> Helper loaded: common_helper
INFO - 2022-03-11 02:51:07 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:51:07 --> Controller Class Initialized
INFO - 2022-03-11 02:51:07 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:51:07 --> Encrypt Class Initialized
INFO - 2022-03-11 02:51:07 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:51:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:51:07 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:51:07 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:51:07 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:51:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:51:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 02:51:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:51:07 --> Final output sent to browser
DEBUG - 2022-03-11 02:51:07 --> Total execution time: 0.0542
ERROR - 2022-03-11 02:51:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:51:23 --> Config Class Initialized
INFO - 2022-03-11 02:51:23 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:51:23 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:51:23 --> Utf8 Class Initialized
INFO - 2022-03-11 02:51:23 --> URI Class Initialized
INFO - 2022-03-11 02:51:23 --> Router Class Initialized
INFO - 2022-03-11 02:51:23 --> Output Class Initialized
INFO - 2022-03-11 02:51:23 --> Security Class Initialized
DEBUG - 2022-03-11 02:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:51:23 --> Input Class Initialized
INFO - 2022-03-11 02:51:23 --> Language Class Initialized
INFO - 2022-03-11 02:51:23 --> Loader Class Initialized
INFO - 2022-03-11 02:51:23 --> Helper loaded: url_helper
INFO - 2022-03-11 02:51:23 --> Helper loaded: form_helper
INFO - 2022-03-11 02:51:23 --> Helper loaded: common_helper
INFO - 2022-03-11 02:51:23 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:51:23 --> Controller Class Initialized
INFO - 2022-03-11 02:51:23 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:51:23 --> Encrypt Class Initialized
INFO - 2022-03-11 02:51:23 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:51:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:51:23 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:51:23 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:51:23 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:51:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:51:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 02:51:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:51:23 --> Final output sent to browser
DEBUG - 2022-03-11 02:51:23 --> Total execution time: 0.0577
ERROR - 2022-03-11 02:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:51:30 --> Config Class Initialized
INFO - 2022-03-11 02:51:30 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:51:30 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:51:30 --> Utf8 Class Initialized
INFO - 2022-03-11 02:51:30 --> URI Class Initialized
INFO - 2022-03-11 02:51:30 --> Router Class Initialized
INFO - 2022-03-11 02:51:30 --> Output Class Initialized
INFO - 2022-03-11 02:51:30 --> Security Class Initialized
DEBUG - 2022-03-11 02:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:51:30 --> Input Class Initialized
INFO - 2022-03-11 02:51:30 --> Language Class Initialized
INFO - 2022-03-11 02:51:30 --> Loader Class Initialized
INFO - 2022-03-11 02:51:30 --> Helper loaded: url_helper
INFO - 2022-03-11 02:51:30 --> Helper loaded: form_helper
INFO - 2022-03-11 02:51:30 --> Helper loaded: common_helper
INFO - 2022-03-11 02:51:30 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:51:30 --> Controller Class Initialized
INFO - 2022-03-11 02:51:30 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:51:30 --> Encrypt Class Initialized
INFO - 2022-03-11 02:51:30 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:51:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:51:30 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:51:30 --> Model "Users_model" initialized
INFO - 2022-03-11 02:51:30 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:51:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:51:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:51:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:51:30 --> Final output sent to browser
DEBUG - 2022-03-11 02:51:30 --> Total execution time: 0.1662
ERROR - 2022-03-11 02:51:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:51:41 --> Config Class Initialized
INFO - 2022-03-11 02:51:41 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:51:41 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:51:41 --> Utf8 Class Initialized
INFO - 2022-03-11 02:51:41 --> URI Class Initialized
INFO - 2022-03-11 02:51:41 --> Router Class Initialized
INFO - 2022-03-11 02:51:41 --> Output Class Initialized
INFO - 2022-03-11 02:51:41 --> Security Class Initialized
DEBUG - 2022-03-11 02:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:51:41 --> Input Class Initialized
INFO - 2022-03-11 02:51:41 --> Language Class Initialized
INFO - 2022-03-11 02:51:41 --> Loader Class Initialized
INFO - 2022-03-11 02:51:41 --> Helper loaded: url_helper
INFO - 2022-03-11 02:51:41 --> Helper loaded: form_helper
INFO - 2022-03-11 02:51:41 --> Helper loaded: common_helper
INFO - 2022-03-11 02:51:41 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:51:41 --> Controller Class Initialized
INFO - 2022-03-11 02:51:41 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:51:41 --> Encrypt Class Initialized
INFO - 2022-03-11 02:51:41 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:51:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:51:41 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:51:41 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:51:41 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:51:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:51:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 02:51:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:51:41 --> Final output sent to browser
DEBUG - 2022-03-11 02:51:41 --> Total execution time: 0.0505
ERROR - 2022-03-11 02:52:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:52:15 --> Config Class Initialized
INFO - 2022-03-11 02:52:15 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:52:15 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:52:15 --> Utf8 Class Initialized
INFO - 2022-03-11 02:52:15 --> URI Class Initialized
INFO - 2022-03-11 02:52:15 --> Router Class Initialized
INFO - 2022-03-11 02:52:15 --> Output Class Initialized
INFO - 2022-03-11 02:52:15 --> Security Class Initialized
DEBUG - 2022-03-11 02:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:52:15 --> Input Class Initialized
INFO - 2022-03-11 02:52:15 --> Language Class Initialized
INFO - 2022-03-11 02:52:15 --> Loader Class Initialized
INFO - 2022-03-11 02:52:15 --> Helper loaded: url_helper
INFO - 2022-03-11 02:52:15 --> Helper loaded: form_helper
INFO - 2022-03-11 02:52:15 --> Helper loaded: common_helper
INFO - 2022-03-11 02:52:15 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:52:15 --> Controller Class Initialized
ERROR - 2022-03-11 02:52:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:52:16 --> Config Class Initialized
INFO - 2022-03-11 02:52:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:52:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:52:16 --> Utf8 Class Initialized
INFO - 2022-03-11 02:52:16 --> URI Class Initialized
INFO - 2022-03-11 02:52:16 --> Router Class Initialized
INFO - 2022-03-11 02:52:16 --> Output Class Initialized
INFO - 2022-03-11 02:52:16 --> Security Class Initialized
DEBUG - 2022-03-11 02:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:52:16 --> Input Class Initialized
INFO - 2022-03-11 02:52:16 --> Language Class Initialized
INFO - 2022-03-11 02:52:16 --> Loader Class Initialized
INFO - 2022-03-11 02:52:16 --> Helper loaded: url_helper
INFO - 2022-03-11 02:52:16 --> Helper loaded: form_helper
INFO - 2022-03-11 02:52:16 --> Helper loaded: common_helper
INFO - 2022-03-11 02:52:16 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:52:16 --> Controller Class Initialized
INFO - 2022-03-11 02:52:16 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:52:16 --> Encrypt Class Initialized
DEBUG - 2022-03-11 02:52:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 02:52:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 02:52:16 --> Email Class Initialized
INFO - 2022-03-11 02:52:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 02:52:16 --> Calendar Class Initialized
INFO - 2022-03-11 02:52:16 --> Model "Login_model" initialized
INFO - 2022-03-11 02:52:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 02:52:16 --> Final output sent to browser
DEBUG - 2022-03-11 02:52:16 --> Total execution time: 0.0249
ERROR - 2022-03-11 02:53:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:53:19 --> Config Class Initialized
INFO - 2022-03-11 02:53:19 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:53:19 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:53:19 --> Utf8 Class Initialized
INFO - 2022-03-11 02:53:19 --> URI Class Initialized
INFO - 2022-03-11 02:53:19 --> Router Class Initialized
INFO - 2022-03-11 02:53:19 --> Output Class Initialized
INFO - 2022-03-11 02:53:19 --> Security Class Initialized
DEBUG - 2022-03-11 02:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:53:19 --> Input Class Initialized
INFO - 2022-03-11 02:53:19 --> Language Class Initialized
INFO - 2022-03-11 02:53:19 --> Loader Class Initialized
INFO - 2022-03-11 02:53:19 --> Helper loaded: url_helper
INFO - 2022-03-11 02:53:19 --> Helper loaded: form_helper
INFO - 2022-03-11 02:53:19 --> Helper loaded: common_helper
INFO - 2022-03-11 02:53:19 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:53:19 --> Controller Class Initialized
INFO - 2022-03-11 02:53:19 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:53:19 --> Encrypt Class Initialized
INFO - 2022-03-11 02:53:19 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:53:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:53:19 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:53:19 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:53:19 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:53:19 --> Final output sent to browser
DEBUG - 2022-03-11 02:53:19 --> Total execution time: 0.0234
ERROR - 2022-03-11 02:53:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:53:19 --> Config Class Initialized
INFO - 2022-03-11 02:53:19 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:53:19 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:53:19 --> Utf8 Class Initialized
INFO - 2022-03-11 02:53:19 --> URI Class Initialized
INFO - 2022-03-11 02:53:19 --> Router Class Initialized
INFO - 2022-03-11 02:53:19 --> Output Class Initialized
INFO - 2022-03-11 02:53:19 --> Security Class Initialized
DEBUG - 2022-03-11 02:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:53:19 --> Input Class Initialized
INFO - 2022-03-11 02:53:19 --> Language Class Initialized
INFO - 2022-03-11 02:53:19 --> Loader Class Initialized
INFO - 2022-03-11 02:53:19 --> Helper loaded: url_helper
INFO - 2022-03-11 02:53:19 --> Helper loaded: form_helper
INFO - 2022-03-11 02:53:19 --> Helper loaded: common_helper
INFO - 2022-03-11 02:53:19 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:53:19 --> Controller Class Initialized
INFO - 2022-03-11 02:53:19 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:53:19 --> Encrypt Class Initialized
INFO - 2022-03-11 02:53:19 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:53:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:53:19 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:53:19 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:53:19 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:53:19 --> Final output sent to browser
DEBUG - 2022-03-11 02:53:19 --> Total execution time: 0.0247
ERROR - 2022-03-11 02:53:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:53:19 --> Config Class Initialized
INFO - 2022-03-11 02:53:19 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:53:19 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:53:19 --> Utf8 Class Initialized
INFO - 2022-03-11 02:53:19 --> URI Class Initialized
INFO - 2022-03-11 02:53:19 --> Router Class Initialized
INFO - 2022-03-11 02:53:19 --> Output Class Initialized
INFO - 2022-03-11 02:53:19 --> Security Class Initialized
DEBUG - 2022-03-11 02:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:53:19 --> Input Class Initialized
INFO - 2022-03-11 02:53:19 --> Language Class Initialized
INFO - 2022-03-11 02:53:19 --> Loader Class Initialized
INFO - 2022-03-11 02:53:19 --> Helper loaded: url_helper
INFO - 2022-03-11 02:53:19 --> Helper loaded: form_helper
INFO - 2022-03-11 02:53:19 --> Helper loaded: common_helper
INFO - 2022-03-11 02:53:19 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:53:19 --> Controller Class Initialized
INFO - 2022-03-11 02:53:19 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:53:19 --> Encrypt Class Initialized
INFO - 2022-03-11 02:53:19 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:53:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:53:19 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:53:19 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:53:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:53:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:53:20 --> Config Class Initialized
INFO - 2022-03-11 02:53:20 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:53:20 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:53:20 --> Utf8 Class Initialized
INFO - 2022-03-11 02:53:20 --> URI Class Initialized
INFO - 2022-03-11 02:53:20 --> Router Class Initialized
INFO - 2022-03-11 02:53:20 --> Output Class Initialized
INFO - 2022-03-11 02:53:20 --> Security Class Initialized
DEBUG - 2022-03-11 02:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:53:20 --> Input Class Initialized
INFO - 2022-03-11 02:53:20 --> Language Class Initialized
INFO - 2022-03-11 02:53:20 --> Loader Class Initialized
INFO - 2022-03-11 02:53:20 --> Helper loaded: url_helper
INFO - 2022-03-11 02:53:20 --> Helper loaded: form_helper
INFO - 2022-03-11 02:53:20 --> Helper loaded: common_helper
INFO - 2022-03-11 02:53:20 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:53:20 --> Controller Class Initialized
INFO - 2022-03-11 02:53:20 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:53:20 --> Encrypt Class Initialized
INFO - 2022-03-11 02:53:20 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:53:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:53:20 --> Model "Referredby_model" initialized
INFO - 2022-03-11 02:53:20 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:53:20 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:53:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:53:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 02:53:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:53:20 --> Final output sent to browser
DEBUG - 2022-03-11 02:53:20 --> Total execution time: 0.0466
ERROR - 2022-03-11 02:53:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:53:21 --> Config Class Initialized
INFO - 2022-03-11 02:53:21 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:53:21 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:53:21 --> Utf8 Class Initialized
INFO - 2022-03-11 02:53:21 --> URI Class Initialized
INFO - 2022-03-11 02:53:21 --> Router Class Initialized
INFO - 2022-03-11 02:53:21 --> Output Class Initialized
INFO - 2022-03-11 02:53:21 --> Security Class Initialized
DEBUG - 2022-03-11 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:53:21 --> Input Class Initialized
INFO - 2022-03-11 02:53:21 --> Language Class Initialized
INFO - 2022-03-11 02:53:21 --> Loader Class Initialized
INFO - 2022-03-11 02:53:21 --> Helper loaded: url_helper
INFO - 2022-03-11 02:53:21 --> Helper loaded: form_helper
INFO - 2022-03-11 02:53:21 --> Helper loaded: common_helper
INFO - 2022-03-11 02:53:21 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:53:21 --> Controller Class Initialized
INFO - 2022-03-11 02:53:21 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:53:21 --> Encrypt Class Initialized
INFO - 2022-03-11 02:53:21 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:53:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:53:21 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:53:21 --> Model "Users_model" initialized
INFO - 2022-03-11 02:53:21 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:53:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:53:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:53:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:53:21 --> Final output sent to browser
DEBUG - 2022-03-11 02:53:21 --> Total execution time: 0.0633
ERROR - 2022-03-11 02:54:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:54:19 --> Config Class Initialized
INFO - 2022-03-11 02:54:19 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:54:19 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:54:19 --> Utf8 Class Initialized
INFO - 2022-03-11 02:54:19 --> URI Class Initialized
INFO - 2022-03-11 02:54:19 --> Router Class Initialized
INFO - 2022-03-11 02:54:19 --> Output Class Initialized
INFO - 2022-03-11 02:54:19 --> Security Class Initialized
DEBUG - 2022-03-11 02:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:54:19 --> Input Class Initialized
INFO - 2022-03-11 02:54:19 --> Language Class Initialized
INFO - 2022-03-11 02:54:19 --> Loader Class Initialized
INFO - 2022-03-11 02:54:19 --> Helper loaded: url_helper
INFO - 2022-03-11 02:54:19 --> Helper loaded: form_helper
INFO - 2022-03-11 02:54:19 --> Helper loaded: common_helper
INFO - 2022-03-11 02:54:19 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:54:19 --> Controller Class Initialized
INFO - 2022-03-11 02:54:19 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:54:19 --> Encrypt Class Initialized
INFO - 2022-03-11 02:54:19 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:54:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:54:19 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:54:19 --> Model "Users_model" initialized
INFO - 2022-03-11 02:54:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:54:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:54:19 --> Config Class Initialized
INFO - 2022-03-11 02:54:19 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:54:19 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:54:19 --> Utf8 Class Initialized
INFO - 2022-03-11 02:54:19 --> URI Class Initialized
INFO - 2022-03-11 02:54:19 --> Router Class Initialized
INFO - 2022-03-11 02:54:19 --> Output Class Initialized
INFO - 2022-03-11 02:54:19 --> Security Class Initialized
DEBUG - 2022-03-11 02:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:54:19 --> Input Class Initialized
INFO - 2022-03-11 02:54:19 --> Language Class Initialized
INFO - 2022-03-11 02:54:19 --> Loader Class Initialized
INFO - 2022-03-11 02:54:19 --> Helper loaded: url_helper
INFO - 2022-03-11 02:54:19 --> Helper loaded: form_helper
INFO - 2022-03-11 02:54:19 --> Helper loaded: common_helper
INFO - 2022-03-11 02:54:19 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:54:19 --> Controller Class Initialized
INFO - 2022-03-11 02:54:19 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:54:19 --> Encrypt Class Initialized
INFO - 2022-03-11 02:54:19 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:54:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:54:19 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:54:19 --> Model "Users_model" initialized
INFO - 2022-03-11 02:54:19 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:54:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:54:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:54:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:54:19 --> Final output sent to browser
DEBUG - 2022-03-11 02:54:19 --> Total execution time: 0.0576
ERROR - 2022-03-11 02:55:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:55:02 --> Config Class Initialized
INFO - 2022-03-11 02:55:02 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:55:02 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:55:02 --> Utf8 Class Initialized
INFO - 2022-03-11 02:55:02 --> URI Class Initialized
INFO - 2022-03-11 02:55:02 --> Router Class Initialized
INFO - 2022-03-11 02:55:02 --> Output Class Initialized
INFO - 2022-03-11 02:55:02 --> Security Class Initialized
DEBUG - 2022-03-11 02:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:55:02 --> Input Class Initialized
INFO - 2022-03-11 02:55:02 --> Language Class Initialized
INFO - 2022-03-11 02:55:02 --> Loader Class Initialized
INFO - 2022-03-11 02:55:02 --> Helper loaded: url_helper
INFO - 2022-03-11 02:55:02 --> Helper loaded: form_helper
INFO - 2022-03-11 02:55:02 --> Helper loaded: common_helper
INFO - 2022-03-11 02:55:02 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:55:02 --> Controller Class Initialized
INFO - 2022-03-11 02:55:02 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:55:02 --> Encrypt Class Initialized
INFO - 2022-03-11 02:55:02 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:55:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:55:02 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:55:02 --> Model "Users_model" initialized
INFO - 2022-03-11 02:55:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:55:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:55:03 --> Config Class Initialized
INFO - 2022-03-11 02:55:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:55:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:55:03 --> Utf8 Class Initialized
INFO - 2022-03-11 02:55:03 --> URI Class Initialized
INFO - 2022-03-11 02:55:03 --> Router Class Initialized
INFO - 2022-03-11 02:55:03 --> Output Class Initialized
INFO - 2022-03-11 02:55:03 --> Security Class Initialized
DEBUG - 2022-03-11 02:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:55:03 --> Input Class Initialized
INFO - 2022-03-11 02:55:03 --> Language Class Initialized
INFO - 2022-03-11 02:55:03 --> Loader Class Initialized
INFO - 2022-03-11 02:55:03 --> Helper loaded: url_helper
INFO - 2022-03-11 02:55:03 --> Helper loaded: form_helper
INFO - 2022-03-11 02:55:03 --> Helper loaded: common_helper
INFO - 2022-03-11 02:55:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:55:03 --> Controller Class Initialized
INFO - 2022-03-11 02:55:03 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:55:03 --> Encrypt Class Initialized
INFO - 2022-03-11 02:55:03 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:55:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:55:03 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:55:03 --> Model "Users_model" initialized
INFO - 2022-03-11 02:55:03 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:55:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:55:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:55:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:55:03 --> Final output sent to browser
DEBUG - 2022-03-11 02:55:03 --> Total execution time: 0.1206
ERROR - 2022-03-11 02:56:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:56:52 --> Config Class Initialized
INFO - 2022-03-11 02:56:52 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:56:52 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:56:52 --> Utf8 Class Initialized
INFO - 2022-03-11 02:56:52 --> URI Class Initialized
INFO - 2022-03-11 02:56:52 --> Router Class Initialized
INFO - 2022-03-11 02:56:52 --> Output Class Initialized
INFO - 2022-03-11 02:56:52 --> Security Class Initialized
DEBUG - 2022-03-11 02:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:56:52 --> Input Class Initialized
INFO - 2022-03-11 02:56:52 --> Language Class Initialized
INFO - 2022-03-11 02:56:52 --> Loader Class Initialized
INFO - 2022-03-11 02:56:52 --> Helper loaded: url_helper
INFO - 2022-03-11 02:56:52 --> Helper loaded: form_helper
INFO - 2022-03-11 02:56:52 --> Helper loaded: common_helper
INFO - 2022-03-11 02:56:52 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:56:52 --> Controller Class Initialized
INFO - 2022-03-11 02:56:52 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:56:52 --> Encrypt Class Initialized
INFO - 2022-03-11 02:56:52 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:56:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:56:52 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:56:52 --> Model "Users_model" initialized
INFO - 2022-03-11 02:56:52 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:56:52 --> Upload Class Initialized
INFO - 2022-03-11 02:56:52 --> Final output sent to browser
DEBUG - 2022-03-11 02:56:52 --> Total execution time: 0.0810
ERROR - 2022-03-11 02:57:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:57:12 --> Config Class Initialized
INFO - 2022-03-11 02:57:12 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:57:12 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:57:12 --> Utf8 Class Initialized
INFO - 2022-03-11 02:57:12 --> URI Class Initialized
INFO - 2022-03-11 02:57:12 --> Router Class Initialized
INFO - 2022-03-11 02:57:12 --> Output Class Initialized
INFO - 2022-03-11 02:57:12 --> Security Class Initialized
DEBUG - 2022-03-11 02:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:57:12 --> Input Class Initialized
INFO - 2022-03-11 02:57:12 --> Language Class Initialized
INFO - 2022-03-11 02:57:12 --> Loader Class Initialized
INFO - 2022-03-11 02:57:12 --> Helper loaded: url_helper
INFO - 2022-03-11 02:57:12 --> Helper loaded: form_helper
INFO - 2022-03-11 02:57:12 --> Helper loaded: common_helper
INFO - 2022-03-11 02:57:12 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:57:12 --> Controller Class Initialized
INFO - 2022-03-11 02:57:12 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:57:12 --> Encrypt Class Initialized
INFO - 2022-03-11 02:57:12 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:57:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:57:12 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:57:12 --> Model "Users_model" initialized
INFO - 2022-03-11 02:57:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:57:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:57:13 --> Config Class Initialized
INFO - 2022-03-11 02:57:13 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:57:13 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:57:13 --> Utf8 Class Initialized
INFO - 2022-03-11 02:57:13 --> URI Class Initialized
INFO - 2022-03-11 02:57:13 --> Router Class Initialized
INFO - 2022-03-11 02:57:13 --> Output Class Initialized
INFO - 2022-03-11 02:57:13 --> Security Class Initialized
DEBUG - 2022-03-11 02:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:57:13 --> Input Class Initialized
INFO - 2022-03-11 02:57:13 --> Language Class Initialized
INFO - 2022-03-11 02:57:13 --> Loader Class Initialized
INFO - 2022-03-11 02:57:13 --> Helper loaded: url_helper
INFO - 2022-03-11 02:57:13 --> Helper loaded: form_helper
INFO - 2022-03-11 02:57:13 --> Helper loaded: common_helper
INFO - 2022-03-11 02:57:13 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:57:13 --> Controller Class Initialized
INFO - 2022-03-11 02:57:13 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:57:13 --> Encrypt Class Initialized
INFO - 2022-03-11 02:57:13 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:57:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:57:13 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:57:13 --> Model "Users_model" initialized
INFO - 2022-03-11 02:57:13 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:57:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:57:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:57:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:57:13 --> Final output sent to browser
DEBUG - 2022-03-11 02:57:13 --> Total execution time: 0.0650
ERROR - 2022-03-11 02:57:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:57:34 --> Config Class Initialized
INFO - 2022-03-11 02:57:34 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:57:34 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:57:34 --> Utf8 Class Initialized
INFO - 2022-03-11 02:57:34 --> URI Class Initialized
INFO - 2022-03-11 02:57:34 --> Router Class Initialized
INFO - 2022-03-11 02:57:34 --> Output Class Initialized
INFO - 2022-03-11 02:57:34 --> Security Class Initialized
DEBUG - 2022-03-11 02:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:57:34 --> Input Class Initialized
INFO - 2022-03-11 02:57:34 --> Language Class Initialized
INFO - 2022-03-11 02:57:34 --> Loader Class Initialized
INFO - 2022-03-11 02:57:34 --> Helper loaded: url_helper
INFO - 2022-03-11 02:57:34 --> Helper loaded: form_helper
INFO - 2022-03-11 02:57:34 --> Helper loaded: common_helper
INFO - 2022-03-11 02:57:34 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:57:34 --> Controller Class Initialized
INFO - 2022-03-11 02:57:34 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:57:34 --> Encrypt Class Initialized
INFO - 2022-03-11 02:57:34 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:57:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:57:34 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:57:34 --> Model "Users_model" initialized
INFO - 2022-03-11 02:57:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 02:57:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:57:35 --> Config Class Initialized
INFO - 2022-03-11 02:57:35 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:57:35 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:57:35 --> Utf8 Class Initialized
INFO - 2022-03-11 02:57:35 --> URI Class Initialized
INFO - 2022-03-11 02:57:35 --> Router Class Initialized
INFO - 2022-03-11 02:57:35 --> Output Class Initialized
INFO - 2022-03-11 02:57:35 --> Security Class Initialized
DEBUG - 2022-03-11 02:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:57:35 --> Input Class Initialized
INFO - 2022-03-11 02:57:35 --> Language Class Initialized
INFO - 2022-03-11 02:57:35 --> Loader Class Initialized
INFO - 2022-03-11 02:57:35 --> Helper loaded: url_helper
INFO - 2022-03-11 02:57:35 --> Helper loaded: form_helper
INFO - 2022-03-11 02:57:35 --> Helper loaded: common_helper
INFO - 2022-03-11 02:57:35 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:57:35 --> Controller Class Initialized
INFO - 2022-03-11 02:57:35 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:57:35 --> Encrypt Class Initialized
INFO - 2022-03-11 02:57:35 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:57:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:57:35 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:57:35 --> Model "Users_model" initialized
INFO - 2022-03-11 02:57:35 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:57:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:57:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:57:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:57:35 --> Final output sent to browser
DEBUG - 2022-03-11 02:57:35 --> Total execution time: 0.0634
ERROR - 2022-03-11 02:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:57:48 --> Config Class Initialized
INFO - 2022-03-11 02:57:48 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:57:48 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:57:48 --> Utf8 Class Initialized
INFO - 2022-03-11 02:57:48 --> URI Class Initialized
INFO - 2022-03-11 02:57:48 --> Router Class Initialized
INFO - 2022-03-11 02:57:48 --> Output Class Initialized
INFO - 2022-03-11 02:57:48 --> Security Class Initialized
DEBUG - 2022-03-11 02:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:57:48 --> Input Class Initialized
INFO - 2022-03-11 02:57:48 --> Language Class Initialized
INFO - 2022-03-11 02:57:48 --> Loader Class Initialized
INFO - 2022-03-11 02:57:48 --> Helper loaded: url_helper
INFO - 2022-03-11 02:57:48 --> Helper loaded: form_helper
INFO - 2022-03-11 02:57:48 --> Helper loaded: common_helper
INFO - 2022-03-11 02:57:48 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:57:48 --> Controller Class Initialized
INFO - 2022-03-11 02:57:48 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:57:48 --> Encrypt Class Initialized
INFO - 2022-03-11 02:57:48 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:57:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:57:48 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:57:48 --> Model "Users_model" initialized
INFO - 2022-03-11 02:57:48 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:57:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 02:57:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 02:57:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 02:57:48 --> Final output sent to browser
DEBUG - 2022-03-11 02:57:48 --> Total execution time: 0.0564
ERROR - 2022-03-11 02:58:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 02:58:23 --> Config Class Initialized
INFO - 2022-03-11 02:58:23 --> Hooks Class Initialized
DEBUG - 2022-03-11 02:58:23 --> UTF-8 Support Enabled
INFO - 2022-03-11 02:58:23 --> Utf8 Class Initialized
INFO - 2022-03-11 02:58:23 --> URI Class Initialized
INFO - 2022-03-11 02:58:23 --> Router Class Initialized
INFO - 2022-03-11 02:58:23 --> Output Class Initialized
INFO - 2022-03-11 02:58:23 --> Security Class Initialized
DEBUG - 2022-03-11 02:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 02:58:23 --> Input Class Initialized
INFO - 2022-03-11 02:58:23 --> Language Class Initialized
INFO - 2022-03-11 02:58:23 --> Loader Class Initialized
INFO - 2022-03-11 02:58:23 --> Helper loaded: url_helper
INFO - 2022-03-11 02:58:24 --> Helper loaded: form_helper
INFO - 2022-03-11 02:58:24 --> Helper loaded: common_helper
INFO - 2022-03-11 02:58:24 --> Database Driver Class Initialized
DEBUG - 2022-03-11 02:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 02:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 02:58:24 --> Controller Class Initialized
INFO - 2022-03-11 02:58:24 --> Form Validation Class Initialized
DEBUG - 2022-03-11 02:58:24 --> Encrypt Class Initialized
INFO - 2022-03-11 02:58:24 --> Model "Patient_model" initialized
INFO - 2022-03-11 02:58:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 02:58:24 --> Model "Prefix_master" initialized
INFO - 2022-03-11 02:58:24 --> Model "Users_model" initialized
INFO - 2022-03-11 02:58:24 --> Model "Hospital_model" initialized
INFO - 2022-03-11 02:58:24 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-11 02:58:25 --> Final output sent to browser
DEBUG - 2022-03-11 02:58:25 --> Total execution time: 1.9110
ERROR - 2022-03-11 03:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:01:00 --> Config Class Initialized
INFO - 2022-03-11 03:01:00 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:01:00 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:01:00 --> Utf8 Class Initialized
INFO - 2022-03-11 03:01:00 --> URI Class Initialized
INFO - 2022-03-11 03:01:00 --> Router Class Initialized
INFO - 2022-03-11 03:01:00 --> Output Class Initialized
INFO - 2022-03-11 03:01:00 --> Security Class Initialized
DEBUG - 2022-03-11 03:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:01:00 --> Input Class Initialized
INFO - 2022-03-11 03:01:00 --> Language Class Initialized
ERROR - 2022-03-11 03:01:00 --> 404 Page Not Found: Git/config
ERROR - 2022-03-11 03:01:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:01:01 --> Config Class Initialized
INFO - 2022-03-11 03:01:01 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:01:01 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:01:01 --> Utf8 Class Initialized
INFO - 2022-03-11 03:01:01 --> URI Class Initialized
INFO - 2022-03-11 03:01:01 --> Router Class Initialized
INFO - 2022-03-11 03:01:01 --> Output Class Initialized
INFO - 2022-03-11 03:01:01 --> Security Class Initialized
DEBUG - 2022-03-11 03:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:01:01 --> Input Class Initialized
INFO - 2022-03-11 03:01:01 --> Language Class Initialized
ERROR - 2022-03-11 03:01:01 --> 404 Page Not Found: Git/config
ERROR - 2022-03-11 03:01:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:01:08 --> Config Class Initialized
INFO - 2022-03-11 03:01:08 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:01:08 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:01:08 --> Utf8 Class Initialized
INFO - 2022-03-11 03:01:08 --> URI Class Initialized
INFO - 2022-03-11 03:01:08 --> Router Class Initialized
INFO - 2022-03-11 03:01:08 --> Output Class Initialized
INFO - 2022-03-11 03:01:08 --> Security Class Initialized
DEBUG - 2022-03-11 03:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:01:08 --> Input Class Initialized
INFO - 2022-03-11 03:01:08 --> Language Class Initialized
INFO - 2022-03-11 03:01:08 --> Loader Class Initialized
INFO - 2022-03-11 03:01:08 --> Helper loaded: url_helper
INFO - 2022-03-11 03:01:08 --> Helper loaded: form_helper
INFO - 2022-03-11 03:01:08 --> Helper loaded: common_helper
INFO - 2022-03-11 03:01:08 --> Database Driver Class Initialized
DEBUG - 2022-03-11 03:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 03:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 03:01:08 --> Controller Class Initialized
INFO - 2022-03-11 03:01:08 --> Form Validation Class Initialized
DEBUG - 2022-03-11 03:01:08 --> Encrypt Class Initialized
INFO - 2022-03-11 03:01:08 --> Model "Patient_model" initialized
INFO - 2022-03-11 03:01:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 03:01:08 --> Model "Referredby_model" initialized
INFO - 2022-03-11 03:01:08 --> Model "Prefix_master" initialized
INFO - 2022-03-11 03:01:08 --> Model "Hospital_model" initialized
INFO - 2022-03-11 03:01:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 03:01:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 03:01:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 03:01:17 --> Final output sent to browser
DEBUG - 2022-03-11 03:01:17 --> Total execution time: 7.4182
ERROR - 2022-03-11 03:01:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:01:41 --> Config Class Initialized
INFO - 2022-03-11 03:01:41 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:01:41 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:01:41 --> Utf8 Class Initialized
INFO - 2022-03-11 03:01:41 --> URI Class Initialized
INFO - 2022-03-11 03:01:41 --> Router Class Initialized
INFO - 2022-03-11 03:01:41 --> Output Class Initialized
INFO - 2022-03-11 03:01:41 --> Security Class Initialized
DEBUG - 2022-03-11 03:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:01:41 --> Input Class Initialized
INFO - 2022-03-11 03:01:41 --> Language Class Initialized
ERROR - 2022-03-11 03:01:41 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-03-11 03:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:14:10 --> Config Class Initialized
INFO - 2022-03-11 03:14:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:14:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:14:10 --> Utf8 Class Initialized
INFO - 2022-03-11 03:14:10 --> URI Class Initialized
INFO - 2022-03-11 03:14:10 --> Router Class Initialized
INFO - 2022-03-11 03:14:10 --> Output Class Initialized
INFO - 2022-03-11 03:14:10 --> Security Class Initialized
DEBUG - 2022-03-11 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:14:10 --> Input Class Initialized
INFO - 2022-03-11 03:14:10 --> Language Class Initialized
INFO - 2022-03-11 03:14:10 --> Loader Class Initialized
INFO - 2022-03-11 03:14:10 --> Helper loaded: url_helper
INFO - 2022-03-11 03:14:10 --> Helper loaded: form_helper
INFO - 2022-03-11 03:14:10 --> Helper loaded: common_helper
INFO - 2022-03-11 03:14:10 --> Database Driver Class Initialized
DEBUG - 2022-03-11 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 03:14:10 --> Controller Class Initialized
INFO - 2022-03-11 03:14:10 --> Form Validation Class Initialized
DEBUG - 2022-03-11 03:14:10 --> Encrypt Class Initialized
INFO - 2022-03-11 03:14:10 --> Model "Patient_model" initialized
INFO - 2022-03-11 03:14:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 03:14:10 --> Model "Prefix_master" initialized
INFO - 2022-03-11 03:14:10 --> Model "Users_model" initialized
INFO - 2022-03-11 03:14:10 --> Model "Hospital_model" initialized
INFO - 2022-03-11 03:14:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 03:14:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 03:14:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 03:14:10 --> Final output sent to browser
DEBUG - 2022-03-11 03:14:10 --> Total execution time: 0.0839
ERROR - 2022-03-11 03:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:14:53 --> Config Class Initialized
INFO - 2022-03-11 03:14:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:14:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:14:53 --> Utf8 Class Initialized
INFO - 2022-03-11 03:14:53 --> URI Class Initialized
INFO - 2022-03-11 03:14:53 --> Router Class Initialized
INFO - 2022-03-11 03:14:53 --> Output Class Initialized
INFO - 2022-03-11 03:14:53 --> Security Class Initialized
DEBUG - 2022-03-11 03:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:14:53 --> Input Class Initialized
INFO - 2022-03-11 03:14:53 --> Language Class Initialized
INFO - 2022-03-11 03:14:53 --> Loader Class Initialized
INFO - 2022-03-11 03:14:53 --> Helper loaded: url_helper
INFO - 2022-03-11 03:14:53 --> Helper loaded: form_helper
INFO - 2022-03-11 03:14:53 --> Helper loaded: common_helper
INFO - 2022-03-11 03:14:53 --> Database Driver Class Initialized
DEBUG - 2022-03-11 03:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 03:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 03:14:53 --> Controller Class Initialized
INFO - 2022-03-11 03:14:53 --> Form Validation Class Initialized
DEBUG - 2022-03-11 03:14:53 --> Encrypt Class Initialized
INFO - 2022-03-11 03:14:53 --> Model "Patient_model" initialized
INFO - 2022-03-11 03:14:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 03:14:53 --> Model "Prefix_master" initialized
INFO - 2022-03-11 03:14:53 --> Model "Users_model" initialized
INFO - 2022-03-11 03:14:53 --> Model "Hospital_model" initialized
INFO - 2022-03-11 03:14:53 --> Upload Class Initialized
INFO - 2022-03-11 03:14:53 --> Final output sent to browser
DEBUG - 2022-03-11 03:14:53 --> Total execution time: 0.0704
ERROR - 2022-03-11 03:14:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:14:56 --> Config Class Initialized
INFO - 2022-03-11 03:14:56 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:14:56 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:14:56 --> Utf8 Class Initialized
INFO - 2022-03-11 03:14:56 --> URI Class Initialized
INFO - 2022-03-11 03:14:56 --> Router Class Initialized
INFO - 2022-03-11 03:14:56 --> Output Class Initialized
INFO - 2022-03-11 03:14:56 --> Security Class Initialized
DEBUG - 2022-03-11 03:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:14:56 --> Input Class Initialized
INFO - 2022-03-11 03:14:56 --> Language Class Initialized
INFO - 2022-03-11 03:14:56 --> Loader Class Initialized
INFO - 2022-03-11 03:14:56 --> Helper loaded: url_helper
INFO - 2022-03-11 03:14:56 --> Helper loaded: form_helper
INFO - 2022-03-11 03:14:56 --> Helper loaded: common_helper
INFO - 2022-03-11 03:14:56 --> Database Driver Class Initialized
DEBUG - 2022-03-11 03:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 03:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 03:14:56 --> Controller Class Initialized
INFO - 2022-03-11 03:14:56 --> Form Validation Class Initialized
DEBUG - 2022-03-11 03:14:56 --> Encrypt Class Initialized
INFO - 2022-03-11 03:14:56 --> Model "Patient_model" initialized
INFO - 2022-03-11 03:14:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 03:14:56 --> Model "Prefix_master" initialized
INFO - 2022-03-11 03:14:56 --> Model "Users_model" initialized
INFO - 2022-03-11 03:14:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 03:14:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:14:57 --> Config Class Initialized
INFO - 2022-03-11 03:14:57 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:14:57 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:14:57 --> Utf8 Class Initialized
INFO - 2022-03-11 03:14:57 --> URI Class Initialized
INFO - 2022-03-11 03:14:57 --> Router Class Initialized
INFO - 2022-03-11 03:14:57 --> Output Class Initialized
INFO - 2022-03-11 03:14:57 --> Security Class Initialized
DEBUG - 2022-03-11 03:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:14:57 --> Input Class Initialized
INFO - 2022-03-11 03:14:57 --> Language Class Initialized
INFO - 2022-03-11 03:14:57 --> Loader Class Initialized
INFO - 2022-03-11 03:14:57 --> Helper loaded: url_helper
INFO - 2022-03-11 03:14:57 --> Helper loaded: form_helper
INFO - 2022-03-11 03:14:57 --> Helper loaded: common_helper
INFO - 2022-03-11 03:14:57 --> Database Driver Class Initialized
DEBUG - 2022-03-11 03:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 03:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 03:14:57 --> Controller Class Initialized
INFO - 2022-03-11 03:14:57 --> Form Validation Class Initialized
DEBUG - 2022-03-11 03:14:57 --> Encrypt Class Initialized
INFO - 2022-03-11 03:14:57 --> Model "Patient_model" initialized
INFO - 2022-03-11 03:14:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 03:14:57 --> Model "Prefix_master" initialized
INFO - 2022-03-11 03:14:57 --> Model "Users_model" initialized
INFO - 2022-03-11 03:14:57 --> Model "Hospital_model" initialized
INFO - 2022-03-11 03:14:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 03:14:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 03:14:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 03:14:57 --> Final output sent to browser
DEBUG - 2022-03-11 03:14:57 --> Total execution time: 0.0593
ERROR - 2022-03-11 03:15:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:15:02 --> Config Class Initialized
INFO - 2022-03-11 03:15:02 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:15:02 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:15:02 --> Utf8 Class Initialized
INFO - 2022-03-11 03:15:02 --> URI Class Initialized
INFO - 2022-03-11 03:15:02 --> Router Class Initialized
INFO - 2022-03-11 03:15:02 --> Output Class Initialized
INFO - 2022-03-11 03:15:02 --> Security Class Initialized
DEBUG - 2022-03-11 03:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:15:02 --> Input Class Initialized
INFO - 2022-03-11 03:15:02 --> Language Class Initialized
INFO - 2022-03-11 03:15:02 --> Loader Class Initialized
INFO - 2022-03-11 03:15:02 --> Helper loaded: url_helper
INFO - 2022-03-11 03:15:02 --> Helper loaded: form_helper
INFO - 2022-03-11 03:15:02 --> Helper loaded: common_helper
INFO - 2022-03-11 03:15:02 --> Database Driver Class Initialized
DEBUG - 2022-03-11 03:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 03:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 03:15:02 --> Controller Class Initialized
INFO - 2022-03-11 03:15:02 --> Form Validation Class Initialized
DEBUG - 2022-03-11 03:15:02 --> Encrypt Class Initialized
INFO - 2022-03-11 03:15:02 --> Model "Patient_model" initialized
INFO - 2022-03-11 03:15:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 03:15:02 --> Model "Referredby_model" initialized
INFO - 2022-03-11 03:15:02 --> Model "Prefix_master" initialized
INFO - 2022-03-11 03:15:02 --> Model "Hospital_model" initialized
INFO - 2022-03-11 03:15:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 03:15:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 03:15:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 03:15:10 --> Final output sent to browser
DEBUG - 2022-03-11 03:15:10 --> Total execution time: 6.5124
ERROR - 2022-03-11 03:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:51:53 --> Config Class Initialized
INFO - 2022-03-11 03:51:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:51:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:51:53 --> Utf8 Class Initialized
INFO - 2022-03-11 03:51:53 --> URI Class Initialized
INFO - 2022-03-11 03:51:53 --> Router Class Initialized
INFO - 2022-03-11 03:51:53 --> Output Class Initialized
INFO - 2022-03-11 03:51:53 --> Security Class Initialized
DEBUG - 2022-03-11 03:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:51:53 --> Input Class Initialized
INFO - 2022-03-11 03:51:53 --> Language Class Initialized
INFO - 2022-03-11 03:51:53 --> Loader Class Initialized
INFO - 2022-03-11 03:51:53 --> Helper loaded: url_helper
INFO - 2022-03-11 03:51:53 --> Helper loaded: form_helper
INFO - 2022-03-11 03:51:53 --> Helper loaded: common_helper
INFO - 2022-03-11 03:51:53 --> Database Driver Class Initialized
DEBUG - 2022-03-11 03:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 03:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 03:51:53 --> Controller Class Initialized
INFO - 2022-03-11 03:51:53 --> Form Validation Class Initialized
DEBUG - 2022-03-11 03:51:53 --> Encrypt Class Initialized
INFO - 2022-03-11 03:51:53 --> Model "Patient_model" initialized
INFO - 2022-03-11 03:51:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 03:51:53 --> Model "Referredby_model" initialized
INFO - 2022-03-11 03:51:53 --> Model "Prefix_master" initialized
INFO - 2022-03-11 03:51:53 --> Model "Hospital_model" initialized
INFO - 2022-03-11 03:51:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 03:51:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 03:51:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 03:52:01 --> Final output sent to browser
DEBUG - 2022-03-11 03:52:01 --> Total execution time: 6.3161
ERROR - 2022-03-11 03:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:52:28 --> Config Class Initialized
INFO - 2022-03-11 03:52:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:52:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:52:28 --> Utf8 Class Initialized
INFO - 2022-03-11 03:52:28 --> URI Class Initialized
INFO - 2022-03-11 03:52:28 --> Router Class Initialized
INFO - 2022-03-11 03:52:28 --> Output Class Initialized
INFO - 2022-03-11 03:52:28 --> Security Class Initialized
DEBUG - 2022-03-11 03:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:52:28 --> Input Class Initialized
INFO - 2022-03-11 03:52:28 --> Language Class Initialized
INFO - 2022-03-11 03:52:28 --> Loader Class Initialized
INFO - 2022-03-11 03:52:28 --> Helper loaded: url_helper
INFO - 2022-03-11 03:52:28 --> Helper loaded: form_helper
INFO - 2022-03-11 03:52:28 --> Helper loaded: common_helper
INFO - 2022-03-11 03:52:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 03:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 03:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 03:52:28 --> Controller Class Initialized
INFO - 2022-03-11 03:52:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 03:52:28 --> Encrypt Class Initialized
INFO - 2022-03-11 03:52:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 03:52:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 03:52:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 03:52:28 --> Model "Users_model" initialized
INFO - 2022-03-11 03:52:28 --> Model "Hospital_model" initialized
INFO - 2022-03-11 03:52:28 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-11 03:52:28 --> Final output sent to browser
DEBUG - 2022-03-11 03:52:28 --> Total execution time: 0.8937
ERROR - 2022-03-11 03:56:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 03:56:42 --> Config Class Initialized
INFO - 2022-03-11 03:56:42 --> Hooks Class Initialized
DEBUG - 2022-03-11 03:56:42 --> UTF-8 Support Enabled
INFO - 2022-03-11 03:56:42 --> Utf8 Class Initialized
INFO - 2022-03-11 03:56:42 --> URI Class Initialized
INFO - 2022-03-11 03:56:42 --> Router Class Initialized
INFO - 2022-03-11 03:56:42 --> Output Class Initialized
INFO - 2022-03-11 03:56:42 --> Security Class Initialized
DEBUG - 2022-03-11 03:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 03:56:42 --> Input Class Initialized
INFO - 2022-03-11 03:56:42 --> Language Class Initialized
INFO - 2022-03-11 03:56:42 --> Loader Class Initialized
INFO - 2022-03-11 03:56:42 --> Helper loaded: url_helper
INFO - 2022-03-11 03:56:42 --> Helper loaded: form_helper
INFO - 2022-03-11 03:56:42 --> Helper loaded: common_helper
INFO - 2022-03-11 03:56:42 --> Database Driver Class Initialized
DEBUG - 2022-03-11 03:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 03:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 03:56:42 --> Controller Class Initialized
INFO - 2022-03-11 03:56:42 --> Form Validation Class Initialized
DEBUG - 2022-03-11 03:56:42 --> Encrypt Class Initialized
INFO - 2022-03-11 03:56:42 --> Model "Patient_model" initialized
INFO - 2022-03-11 03:56:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 03:56:42 --> Model "Prefix_master" initialized
INFO - 2022-03-11 03:56:42 --> Model "Users_model" initialized
INFO - 2022-03-11 03:56:42 --> Model "Hospital_model" initialized
INFO - 2022-03-11 03:56:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 03:56:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 03:56:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 03:56:42 --> Final output sent to browser
DEBUG - 2022-03-11 03:56:42 --> Total execution time: 0.0608
ERROR - 2022-03-11 04:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:02:46 --> Config Class Initialized
INFO - 2022-03-11 04:02:46 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:02:46 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:02:46 --> Utf8 Class Initialized
INFO - 2022-03-11 04:02:46 --> URI Class Initialized
INFO - 2022-03-11 04:02:46 --> Router Class Initialized
INFO - 2022-03-11 04:02:46 --> Output Class Initialized
INFO - 2022-03-11 04:02:46 --> Security Class Initialized
DEBUG - 2022-03-11 04:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:02:46 --> Input Class Initialized
INFO - 2022-03-11 04:02:46 --> Language Class Initialized
INFO - 2022-03-11 04:02:46 --> Loader Class Initialized
INFO - 2022-03-11 04:02:46 --> Helper loaded: url_helper
INFO - 2022-03-11 04:02:46 --> Helper loaded: form_helper
INFO - 2022-03-11 04:02:46 --> Helper loaded: common_helper
INFO - 2022-03-11 04:02:46 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:02:46 --> Controller Class Initialized
ERROR - 2022-03-11 04:02:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:02:47 --> Config Class Initialized
INFO - 2022-03-11 04:02:47 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:02:47 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:02:47 --> Utf8 Class Initialized
INFO - 2022-03-11 04:02:47 --> URI Class Initialized
INFO - 2022-03-11 04:02:47 --> Router Class Initialized
INFO - 2022-03-11 04:02:47 --> Output Class Initialized
INFO - 2022-03-11 04:02:47 --> Security Class Initialized
DEBUG - 2022-03-11 04:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:02:47 --> Input Class Initialized
INFO - 2022-03-11 04:02:47 --> Language Class Initialized
INFO - 2022-03-11 04:02:47 --> Loader Class Initialized
INFO - 2022-03-11 04:02:47 --> Helper loaded: url_helper
INFO - 2022-03-11 04:02:47 --> Helper loaded: form_helper
INFO - 2022-03-11 04:02:47 --> Helper loaded: common_helper
INFO - 2022-03-11 04:02:47 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:02:47 --> Controller Class Initialized
INFO - 2022-03-11 04:02:47 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:02:47 --> Encrypt Class Initialized
DEBUG - 2022-03-11 04:02:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 04:02:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 04:02:47 --> Email Class Initialized
INFO - 2022-03-11 04:02:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 04:02:47 --> Calendar Class Initialized
INFO - 2022-03-11 04:02:47 --> Model "Login_model" initialized
INFO - 2022-03-11 04:02:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 04:02:47 --> Final output sent to browser
DEBUG - 2022-03-11 04:02:47 --> Total execution time: 0.0372
ERROR - 2022-03-11 04:02:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:02:55 --> Config Class Initialized
INFO - 2022-03-11 04:02:55 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:02:55 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:02:55 --> Utf8 Class Initialized
INFO - 2022-03-11 04:02:55 --> URI Class Initialized
INFO - 2022-03-11 04:02:55 --> Router Class Initialized
INFO - 2022-03-11 04:02:55 --> Output Class Initialized
INFO - 2022-03-11 04:02:55 --> Security Class Initialized
DEBUG - 2022-03-11 04:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:02:55 --> Input Class Initialized
INFO - 2022-03-11 04:02:55 --> Language Class Initialized
INFO - 2022-03-11 04:02:55 --> Loader Class Initialized
INFO - 2022-03-11 04:02:55 --> Helper loaded: url_helper
INFO - 2022-03-11 04:02:55 --> Helper loaded: form_helper
INFO - 2022-03-11 04:02:55 --> Helper loaded: common_helper
INFO - 2022-03-11 04:02:55 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:02:55 --> Controller Class Initialized
ERROR - 2022-03-11 04:02:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:02:56 --> Config Class Initialized
INFO - 2022-03-11 04:02:56 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:02:56 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:02:56 --> Utf8 Class Initialized
INFO - 2022-03-11 04:02:56 --> URI Class Initialized
INFO - 2022-03-11 04:02:56 --> Router Class Initialized
INFO - 2022-03-11 04:02:56 --> Output Class Initialized
INFO - 2022-03-11 04:02:56 --> Security Class Initialized
DEBUG - 2022-03-11 04:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:02:56 --> Input Class Initialized
INFO - 2022-03-11 04:02:56 --> Language Class Initialized
INFO - 2022-03-11 04:02:56 --> Loader Class Initialized
INFO - 2022-03-11 04:02:56 --> Helper loaded: url_helper
INFO - 2022-03-11 04:02:56 --> Helper loaded: form_helper
INFO - 2022-03-11 04:02:56 --> Helper loaded: common_helper
INFO - 2022-03-11 04:02:56 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:02:56 --> Controller Class Initialized
INFO - 2022-03-11 04:02:56 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:02:56 --> Encrypt Class Initialized
DEBUG - 2022-03-11 04:02:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 04:02:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 04:02:56 --> Email Class Initialized
INFO - 2022-03-11 04:02:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 04:02:56 --> Calendar Class Initialized
INFO - 2022-03-11 04:02:56 --> Model "Login_model" initialized
INFO - 2022-03-11 04:02:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 04:02:56 --> Final output sent to browser
DEBUG - 2022-03-11 04:02:56 --> Total execution time: 0.0211
ERROR - 2022-03-11 04:03:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:03:05 --> Config Class Initialized
INFO - 2022-03-11 04:03:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:03:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:03:05 --> Utf8 Class Initialized
INFO - 2022-03-11 04:03:05 --> URI Class Initialized
INFO - 2022-03-11 04:03:05 --> Router Class Initialized
INFO - 2022-03-11 04:03:05 --> Output Class Initialized
INFO - 2022-03-11 04:03:05 --> Security Class Initialized
DEBUG - 2022-03-11 04:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:03:05 --> Input Class Initialized
INFO - 2022-03-11 04:03:05 --> Language Class Initialized
INFO - 2022-03-11 04:03:05 --> Loader Class Initialized
INFO - 2022-03-11 04:03:05 --> Helper loaded: url_helper
INFO - 2022-03-11 04:03:05 --> Helper loaded: form_helper
INFO - 2022-03-11 04:03:05 --> Helper loaded: common_helper
INFO - 2022-03-11 04:03:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:03:05 --> Controller Class Initialized
ERROR - 2022-03-11 04:03:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:03:05 --> Config Class Initialized
INFO - 2022-03-11 04:03:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:03:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:03:05 --> Utf8 Class Initialized
INFO - 2022-03-11 04:03:05 --> URI Class Initialized
INFO - 2022-03-11 04:03:05 --> Router Class Initialized
INFO - 2022-03-11 04:03:05 --> Output Class Initialized
INFO - 2022-03-11 04:03:05 --> Security Class Initialized
DEBUG - 2022-03-11 04:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:03:05 --> Input Class Initialized
INFO - 2022-03-11 04:03:05 --> Language Class Initialized
INFO - 2022-03-11 04:03:05 --> Loader Class Initialized
INFO - 2022-03-11 04:03:05 --> Helper loaded: url_helper
INFO - 2022-03-11 04:03:05 --> Helper loaded: form_helper
INFO - 2022-03-11 04:03:05 --> Helper loaded: common_helper
INFO - 2022-03-11 04:03:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:03:05 --> Controller Class Initialized
INFO - 2022-03-11 04:03:05 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:03:05 --> Encrypt Class Initialized
DEBUG - 2022-03-11 04:03:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 04:03:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 04:03:05 --> Email Class Initialized
INFO - 2022-03-11 04:03:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 04:03:05 --> Calendar Class Initialized
INFO - 2022-03-11 04:03:05 --> Model "Login_model" initialized
INFO - 2022-03-11 04:03:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 04:03:05 --> Final output sent to browser
DEBUG - 2022-03-11 04:03:05 --> Total execution time: 0.0231
ERROR - 2022-03-11 04:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:03:25 --> Config Class Initialized
INFO - 2022-03-11 04:03:25 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:03:25 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:03:25 --> Utf8 Class Initialized
INFO - 2022-03-11 04:03:25 --> URI Class Initialized
INFO - 2022-03-11 04:03:25 --> Router Class Initialized
INFO - 2022-03-11 04:03:25 --> Output Class Initialized
INFO - 2022-03-11 04:03:25 --> Security Class Initialized
DEBUG - 2022-03-11 04:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:03:25 --> Input Class Initialized
INFO - 2022-03-11 04:03:25 --> Language Class Initialized
INFO - 2022-03-11 04:03:25 --> Loader Class Initialized
INFO - 2022-03-11 04:03:25 --> Helper loaded: url_helper
INFO - 2022-03-11 04:03:25 --> Helper loaded: form_helper
INFO - 2022-03-11 04:03:25 --> Helper loaded: common_helper
INFO - 2022-03-11 04:03:25 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:03:25 --> Controller Class Initialized
INFO - 2022-03-11 04:03:25 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:03:25 --> Encrypt Class Initialized
DEBUG - 2022-03-11 04:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 04:03:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 04:03:25 --> Email Class Initialized
INFO - 2022-03-11 04:03:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 04:03:25 --> Calendar Class Initialized
INFO - 2022-03-11 04:03:25 --> Model "Login_model" initialized
INFO - 2022-03-11 04:03:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-11 04:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:03:26 --> Config Class Initialized
INFO - 2022-03-11 04:03:26 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:03:26 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:03:26 --> Utf8 Class Initialized
INFO - 2022-03-11 04:03:26 --> URI Class Initialized
INFO - 2022-03-11 04:03:26 --> Router Class Initialized
INFO - 2022-03-11 04:03:26 --> Output Class Initialized
INFO - 2022-03-11 04:03:26 --> Security Class Initialized
DEBUG - 2022-03-11 04:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:03:26 --> Input Class Initialized
INFO - 2022-03-11 04:03:26 --> Language Class Initialized
INFO - 2022-03-11 04:03:26 --> Loader Class Initialized
INFO - 2022-03-11 04:03:26 --> Helper loaded: url_helper
INFO - 2022-03-11 04:03:26 --> Helper loaded: form_helper
INFO - 2022-03-11 04:03:26 --> Helper loaded: common_helper
INFO - 2022-03-11 04:03:26 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:03:26 --> Controller Class Initialized
INFO - 2022-03-11 04:03:26 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:03:26 --> Encrypt Class Initialized
INFO - 2022-03-11 04:03:26 --> Model "Login_model" initialized
INFO - 2022-03-11 04:03:26 --> Model "Dashboard_model" initialized
INFO - 2022-03-11 04:03:26 --> Model "Case_model" initialized
INFO - 2022-03-11 04:03:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:03:26 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-11 04:03:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:03:26 --> Final output sent to browser
DEBUG - 2022-03-11 04:03:26 --> Total execution time: 0.1349
ERROR - 2022-03-11 04:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:03:38 --> Config Class Initialized
INFO - 2022-03-11 04:03:38 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:03:38 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:03:38 --> Utf8 Class Initialized
INFO - 2022-03-11 04:03:38 --> URI Class Initialized
INFO - 2022-03-11 04:03:38 --> Router Class Initialized
INFO - 2022-03-11 04:03:38 --> Output Class Initialized
INFO - 2022-03-11 04:03:38 --> Security Class Initialized
DEBUG - 2022-03-11 04:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:03:38 --> Input Class Initialized
INFO - 2022-03-11 04:03:38 --> Language Class Initialized
INFO - 2022-03-11 04:03:38 --> Loader Class Initialized
INFO - 2022-03-11 04:03:38 --> Helper loaded: url_helper
INFO - 2022-03-11 04:03:38 --> Helper loaded: form_helper
INFO - 2022-03-11 04:03:38 --> Helper loaded: common_helper
INFO - 2022-03-11 04:03:38 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:03:38 --> Controller Class Initialized
INFO - 2022-03-11 04:03:38 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:03:38 --> Encrypt Class Initialized
INFO - 2022-03-11 04:03:38 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:03:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:03:38 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:03:38 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:03:38 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:03:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:03:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 04:03:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:03:38 --> Final output sent to browser
DEBUG - 2022-03-11 04:03:38 --> Total execution time: 0.0824
ERROR - 2022-03-11 04:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:03:48 --> Config Class Initialized
INFO - 2022-03-11 04:03:48 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:03:48 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:03:48 --> Utf8 Class Initialized
INFO - 2022-03-11 04:03:48 --> URI Class Initialized
INFO - 2022-03-11 04:03:48 --> Router Class Initialized
INFO - 2022-03-11 04:03:48 --> Output Class Initialized
INFO - 2022-03-11 04:03:48 --> Security Class Initialized
DEBUG - 2022-03-11 04:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:03:48 --> Input Class Initialized
INFO - 2022-03-11 04:03:48 --> Language Class Initialized
INFO - 2022-03-11 04:03:48 --> Loader Class Initialized
INFO - 2022-03-11 04:03:48 --> Helper loaded: url_helper
INFO - 2022-03-11 04:03:48 --> Helper loaded: form_helper
INFO - 2022-03-11 04:03:48 --> Helper loaded: common_helper
INFO - 2022-03-11 04:03:48 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:03:48 --> Controller Class Initialized
INFO - 2022-03-11 04:03:48 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:03:48 --> Encrypt Class Initialized
INFO - 2022-03-11 04:03:48 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:03:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:03:48 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:03:48 --> Model "Users_model" initialized
INFO - 2022-03-11 04:03:48 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:03:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:03:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 04:03:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:03:48 --> Final output sent to browser
DEBUG - 2022-03-11 04:03:48 --> Total execution time: 0.0766
ERROR - 2022-03-11 04:04:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:04:03 --> Config Class Initialized
INFO - 2022-03-11 04:04:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:04:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:04:03 --> Utf8 Class Initialized
INFO - 2022-03-11 04:04:03 --> URI Class Initialized
INFO - 2022-03-11 04:04:03 --> Router Class Initialized
INFO - 2022-03-11 04:04:03 --> Output Class Initialized
INFO - 2022-03-11 04:04:03 --> Security Class Initialized
DEBUG - 2022-03-11 04:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:04:03 --> Input Class Initialized
INFO - 2022-03-11 04:04:03 --> Language Class Initialized
INFO - 2022-03-11 04:04:03 --> Loader Class Initialized
INFO - 2022-03-11 04:04:03 --> Helper loaded: url_helper
INFO - 2022-03-11 04:04:03 --> Helper loaded: form_helper
INFO - 2022-03-11 04:04:03 --> Helper loaded: common_helper
INFO - 2022-03-11 04:04:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:04:03 --> Controller Class Initialized
INFO - 2022-03-11 04:04:03 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:04:03 --> Encrypt Class Initialized
INFO - 2022-03-11 04:04:03 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:04:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:04:03 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:04:03 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:04:03 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:04:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:04:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 04:04:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:04:03 --> Final output sent to browser
DEBUG - 2022-03-11 04:04:03 --> Total execution time: 0.1040
ERROR - 2022-03-11 04:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:07:00 --> Config Class Initialized
INFO - 2022-03-11 04:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:07:00 --> Utf8 Class Initialized
INFO - 2022-03-11 04:07:00 --> URI Class Initialized
INFO - 2022-03-11 04:07:00 --> Router Class Initialized
INFO - 2022-03-11 04:07:00 --> Output Class Initialized
INFO - 2022-03-11 04:07:00 --> Security Class Initialized
DEBUG - 2022-03-11 04:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:07:00 --> Input Class Initialized
INFO - 2022-03-11 04:07:00 --> Language Class Initialized
INFO - 2022-03-11 04:07:00 --> Loader Class Initialized
INFO - 2022-03-11 04:07:00 --> Helper loaded: url_helper
INFO - 2022-03-11 04:07:00 --> Helper loaded: form_helper
INFO - 2022-03-11 04:07:00 --> Helper loaded: common_helper
INFO - 2022-03-11 04:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:07:00 --> Controller Class Initialized
INFO - 2022-03-11 04:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:07:00 --> Encrypt Class Initialized
INFO - 2022-03-11 04:07:00 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:07:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:07:00 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:07:00 --> Model "Users_model" initialized
INFO - 2022-03-11 04:07:00 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:07:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:07:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 04:07:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:07:00 --> Final output sent to browser
DEBUG - 2022-03-11 04:07:00 --> Total execution time: 0.0649
ERROR - 2022-03-11 04:07:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:07:13 --> Config Class Initialized
INFO - 2022-03-11 04:07:13 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:07:13 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:07:13 --> Utf8 Class Initialized
INFO - 2022-03-11 04:07:13 --> URI Class Initialized
INFO - 2022-03-11 04:07:13 --> Router Class Initialized
INFO - 2022-03-11 04:07:13 --> Output Class Initialized
INFO - 2022-03-11 04:07:13 --> Security Class Initialized
DEBUG - 2022-03-11 04:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:07:13 --> Input Class Initialized
INFO - 2022-03-11 04:07:13 --> Language Class Initialized
INFO - 2022-03-11 04:07:13 --> Loader Class Initialized
INFO - 2022-03-11 04:07:13 --> Helper loaded: url_helper
INFO - 2022-03-11 04:07:13 --> Helper loaded: form_helper
INFO - 2022-03-11 04:07:13 --> Helper loaded: common_helper
INFO - 2022-03-11 04:07:13 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:07:13 --> Controller Class Initialized
INFO - 2022-03-11 04:07:13 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:07:13 --> Encrypt Class Initialized
INFO - 2022-03-11 04:07:13 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:07:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:07:13 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:07:13 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:07:13 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:07:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:07:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 04:07:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:07:13 --> Final output sent to browser
DEBUG - 2022-03-11 04:07:13 --> Total execution time: 0.0455
ERROR - 2022-03-11 04:09:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:09:46 --> Config Class Initialized
INFO - 2022-03-11 04:09:46 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:09:46 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:09:46 --> Utf8 Class Initialized
INFO - 2022-03-11 04:09:46 --> URI Class Initialized
INFO - 2022-03-11 04:09:46 --> Router Class Initialized
INFO - 2022-03-11 04:09:46 --> Output Class Initialized
INFO - 2022-03-11 04:09:46 --> Security Class Initialized
DEBUG - 2022-03-11 04:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:09:46 --> Input Class Initialized
INFO - 2022-03-11 04:09:46 --> Language Class Initialized
INFO - 2022-03-11 04:09:46 --> Loader Class Initialized
INFO - 2022-03-11 04:09:46 --> Helper loaded: url_helper
INFO - 2022-03-11 04:09:46 --> Helper loaded: form_helper
INFO - 2022-03-11 04:09:46 --> Helper loaded: common_helper
INFO - 2022-03-11 04:09:46 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:09:46 --> Controller Class Initialized
INFO - 2022-03-11 04:09:46 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:09:46 --> Encrypt Class Initialized
INFO - 2022-03-11 04:09:46 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:09:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:09:46 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:09:46 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:09:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 04:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:09:47 --> Config Class Initialized
INFO - 2022-03-11 04:09:47 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:09:47 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:09:47 --> Utf8 Class Initialized
INFO - 2022-03-11 04:09:47 --> URI Class Initialized
INFO - 2022-03-11 04:09:47 --> Router Class Initialized
INFO - 2022-03-11 04:09:47 --> Output Class Initialized
INFO - 2022-03-11 04:09:47 --> Security Class Initialized
DEBUG - 2022-03-11 04:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:09:47 --> Input Class Initialized
INFO - 2022-03-11 04:09:47 --> Language Class Initialized
INFO - 2022-03-11 04:09:47 --> Loader Class Initialized
INFO - 2022-03-11 04:09:47 --> Helper loaded: url_helper
INFO - 2022-03-11 04:09:47 --> Helper loaded: form_helper
INFO - 2022-03-11 04:09:47 --> Helper loaded: common_helper
INFO - 2022-03-11 04:09:47 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:09:47 --> Controller Class Initialized
INFO - 2022-03-11 04:09:47 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:09:47 --> Encrypt Class Initialized
INFO - 2022-03-11 04:09:47 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:09:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:09:47 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:09:47 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:09:47 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:09:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:09:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 04:09:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:09:47 --> Final output sent to browser
DEBUG - 2022-03-11 04:09:47 --> Total execution time: 0.0467
ERROR - 2022-03-11 04:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:09:48 --> Config Class Initialized
INFO - 2022-03-11 04:09:48 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:09:48 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:09:48 --> Utf8 Class Initialized
INFO - 2022-03-11 04:09:48 --> URI Class Initialized
INFO - 2022-03-11 04:09:48 --> Router Class Initialized
INFO - 2022-03-11 04:09:48 --> Output Class Initialized
INFO - 2022-03-11 04:09:48 --> Security Class Initialized
DEBUG - 2022-03-11 04:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:09:48 --> Input Class Initialized
INFO - 2022-03-11 04:09:48 --> Language Class Initialized
INFO - 2022-03-11 04:09:48 --> Loader Class Initialized
INFO - 2022-03-11 04:09:48 --> Helper loaded: url_helper
INFO - 2022-03-11 04:09:48 --> Helper loaded: form_helper
INFO - 2022-03-11 04:09:48 --> Helper loaded: common_helper
INFO - 2022-03-11 04:09:48 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:09:48 --> Controller Class Initialized
INFO - 2022-03-11 04:09:48 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:09:48 --> Encrypt Class Initialized
INFO - 2022-03-11 04:09:48 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:09:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:09:48 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:09:48 --> Model "Users_model" initialized
INFO - 2022-03-11 04:09:48 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:09:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:09:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 04:09:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:09:48 --> Final output sent to browser
DEBUG - 2022-03-11 04:09:48 --> Total execution time: 0.0593
ERROR - 2022-03-11 04:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:10:17 --> Config Class Initialized
INFO - 2022-03-11 04:10:17 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:10:17 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:10:17 --> Utf8 Class Initialized
INFO - 2022-03-11 04:10:17 --> URI Class Initialized
INFO - 2022-03-11 04:10:17 --> Router Class Initialized
INFO - 2022-03-11 04:10:17 --> Output Class Initialized
INFO - 2022-03-11 04:10:17 --> Security Class Initialized
DEBUG - 2022-03-11 04:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:10:17 --> Input Class Initialized
INFO - 2022-03-11 04:10:17 --> Language Class Initialized
INFO - 2022-03-11 04:10:17 --> Loader Class Initialized
INFO - 2022-03-11 04:10:17 --> Helper loaded: url_helper
INFO - 2022-03-11 04:10:17 --> Helper loaded: form_helper
INFO - 2022-03-11 04:10:17 --> Helper loaded: common_helper
INFO - 2022-03-11 04:10:17 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:10:17 --> Controller Class Initialized
INFO - 2022-03-11 04:10:17 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:10:17 --> Encrypt Class Initialized
INFO - 2022-03-11 04:10:17 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:10:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:10:17 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:10:17 --> Model "Users_model" initialized
INFO - 2022-03-11 04:10:17 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:10:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:10:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 04:10:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:10:17 --> Final output sent to browser
DEBUG - 2022-03-11 04:10:17 --> Total execution time: 0.0614
ERROR - 2022-03-11 04:10:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:10:26 --> Config Class Initialized
INFO - 2022-03-11 04:10:26 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:10:26 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:10:26 --> Utf8 Class Initialized
INFO - 2022-03-11 04:10:26 --> URI Class Initialized
INFO - 2022-03-11 04:10:26 --> Router Class Initialized
INFO - 2022-03-11 04:10:26 --> Output Class Initialized
INFO - 2022-03-11 04:10:26 --> Security Class Initialized
DEBUG - 2022-03-11 04:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:10:26 --> Input Class Initialized
INFO - 2022-03-11 04:10:26 --> Language Class Initialized
INFO - 2022-03-11 04:10:26 --> Loader Class Initialized
INFO - 2022-03-11 04:10:26 --> Helper loaded: url_helper
INFO - 2022-03-11 04:10:26 --> Helper loaded: form_helper
INFO - 2022-03-11 04:10:26 --> Helper loaded: common_helper
INFO - 2022-03-11 04:10:26 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:10:26 --> Controller Class Initialized
INFO - 2022-03-11 04:10:26 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:10:26 --> Encrypt Class Initialized
INFO - 2022-03-11 04:10:26 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:10:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:10:26 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:10:26 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:10:26 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:10:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:10:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 04:10:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:10:26 --> Final output sent to browser
DEBUG - 2022-03-11 04:10:26 --> Total execution time: 0.0620
ERROR - 2022-03-11 04:11:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:11:05 --> Config Class Initialized
INFO - 2022-03-11 04:11:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:11:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:11:05 --> Utf8 Class Initialized
INFO - 2022-03-11 04:11:05 --> URI Class Initialized
INFO - 2022-03-11 04:11:05 --> Router Class Initialized
INFO - 2022-03-11 04:11:05 --> Output Class Initialized
INFO - 2022-03-11 04:11:05 --> Security Class Initialized
DEBUG - 2022-03-11 04:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:11:05 --> Input Class Initialized
INFO - 2022-03-11 04:11:05 --> Language Class Initialized
INFO - 2022-03-11 04:11:05 --> Loader Class Initialized
INFO - 2022-03-11 04:11:05 --> Helper loaded: url_helper
INFO - 2022-03-11 04:11:05 --> Helper loaded: form_helper
INFO - 2022-03-11 04:11:05 --> Helper loaded: common_helper
INFO - 2022-03-11 04:11:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:11:05 --> Controller Class Initialized
INFO - 2022-03-11 04:11:05 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:11:05 --> Encrypt Class Initialized
INFO - 2022-03-11 04:11:05 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:11:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:11:05 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:11:05 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:11:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 04:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:11:06 --> Config Class Initialized
INFO - 2022-03-11 04:11:06 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:11:06 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:11:06 --> Utf8 Class Initialized
INFO - 2022-03-11 04:11:06 --> URI Class Initialized
INFO - 2022-03-11 04:11:06 --> Router Class Initialized
INFO - 2022-03-11 04:11:06 --> Output Class Initialized
INFO - 2022-03-11 04:11:06 --> Security Class Initialized
DEBUG - 2022-03-11 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:11:06 --> Input Class Initialized
INFO - 2022-03-11 04:11:06 --> Language Class Initialized
INFO - 2022-03-11 04:11:06 --> Loader Class Initialized
INFO - 2022-03-11 04:11:06 --> Helper loaded: url_helper
INFO - 2022-03-11 04:11:06 --> Helper loaded: form_helper
INFO - 2022-03-11 04:11:06 --> Helper loaded: common_helper
INFO - 2022-03-11 04:11:06 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:11:06 --> Controller Class Initialized
INFO - 2022-03-11 04:11:06 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:11:06 --> Encrypt Class Initialized
INFO - 2022-03-11 04:11:06 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:11:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:11:06 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:11:06 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:11:06 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:11:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:11:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 04:11:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:11:06 --> Final output sent to browser
DEBUG - 2022-03-11 04:11:06 --> Total execution time: 0.0550
ERROR - 2022-03-11 04:11:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:11:07 --> Config Class Initialized
INFO - 2022-03-11 04:11:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:11:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:11:07 --> Utf8 Class Initialized
INFO - 2022-03-11 04:11:07 --> URI Class Initialized
INFO - 2022-03-11 04:11:07 --> Router Class Initialized
INFO - 2022-03-11 04:11:07 --> Output Class Initialized
INFO - 2022-03-11 04:11:07 --> Security Class Initialized
DEBUG - 2022-03-11 04:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:11:07 --> Input Class Initialized
INFO - 2022-03-11 04:11:07 --> Language Class Initialized
INFO - 2022-03-11 04:11:07 --> Loader Class Initialized
INFO - 2022-03-11 04:11:07 --> Helper loaded: url_helper
INFO - 2022-03-11 04:11:07 --> Helper loaded: form_helper
INFO - 2022-03-11 04:11:07 --> Helper loaded: common_helper
INFO - 2022-03-11 04:11:07 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:11:07 --> Controller Class Initialized
INFO - 2022-03-11 04:11:07 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:11:07 --> Encrypt Class Initialized
INFO - 2022-03-11 04:11:07 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:11:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:11:07 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:11:07 --> Model "Users_model" initialized
INFO - 2022-03-11 04:11:07 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:11:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:11:07 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 04:11:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:11:07 --> Final output sent to browser
DEBUG - 2022-03-11 04:11:07 --> Total execution time: 0.0614
ERROR - 2022-03-11 04:12:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:12:27 --> Config Class Initialized
INFO - 2022-03-11 04:12:27 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:12:27 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:12:27 --> Utf8 Class Initialized
INFO - 2022-03-11 04:12:27 --> URI Class Initialized
INFO - 2022-03-11 04:12:27 --> Router Class Initialized
INFO - 2022-03-11 04:12:27 --> Output Class Initialized
INFO - 2022-03-11 04:12:27 --> Security Class Initialized
DEBUG - 2022-03-11 04:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:12:27 --> Input Class Initialized
INFO - 2022-03-11 04:12:27 --> Language Class Initialized
INFO - 2022-03-11 04:12:27 --> Loader Class Initialized
INFO - 2022-03-11 04:12:27 --> Helper loaded: url_helper
INFO - 2022-03-11 04:12:27 --> Helper loaded: form_helper
INFO - 2022-03-11 04:12:27 --> Helper loaded: common_helper
INFO - 2022-03-11 04:12:27 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:12:27 --> Controller Class Initialized
INFO - 2022-03-11 04:12:27 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:12:27 --> Encrypt Class Initialized
INFO - 2022-03-11 04:12:27 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:12:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:12:27 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:12:27 --> Model "Users_model" initialized
INFO - 2022-03-11 04:12:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 04:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:12:28 --> Config Class Initialized
INFO - 2022-03-11 04:12:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:12:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:12:28 --> Utf8 Class Initialized
INFO - 2022-03-11 04:12:28 --> URI Class Initialized
INFO - 2022-03-11 04:12:28 --> Router Class Initialized
INFO - 2022-03-11 04:12:28 --> Output Class Initialized
INFO - 2022-03-11 04:12:28 --> Security Class Initialized
DEBUG - 2022-03-11 04:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:12:28 --> Input Class Initialized
INFO - 2022-03-11 04:12:28 --> Language Class Initialized
INFO - 2022-03-11 04:12:28 --> Loader Class Initialized
INFO - 2022-03-11 04:12:28 --> Helper loaded: url_helper
INFO - 2022-03-11 04:12:28 --> Helper loaded: form_helper
INFO - 2022-03-11 04:12:28 --> Helper loaded: common_helper
INFO - 2022-03-11 04:12:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:12:28 --> Controller Class Initialized
INFO - 2022-03-11 04:12:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:12:28 --> Encrypt Class Initialized
INFO - 2022-03-11 04:12:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:12:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:12:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:12:28 --> Model "Users_model" initialized
INFO - 2022-03-11 04:12:28 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:12:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:12:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 04:12:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:12:28 --> Final output sent to browser
DEBUG - 2022-03-11 04:12:28 --> Total execution time: 0.0803
ERROR - 2022-03-11 04:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:12:55 --> Config Class Initialized
INFO - 2022-03-11 04:12:55 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:12:55 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:12:55 --> Utf8 Class Initialized
INFO - 2022-03-11 04:12:55 --> URI Class Initialized
INFO - 2022-03-11 04:12:55 --> Router Class Initialized
INFO - 2022-03-11 04:12:55 --> Output Class Initialized
INFO - 2022-03-11 04:12:55 --> Security Class Initialized
DEBUG - 2022-03-11 04:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:12:55 --> Input Class Initialized
INFO - 2022-03-11 04:12:55 --> Language Class Initialized
INFO - 2022-03-11 04:12:55 --> Loader Class Initialized
INFO - 2022-03-11 04:12:55 --> Helper loaded: url_helper
INFO - 2022-03-11 04:12:55 --> Helper loaded: form_helper
INFO - 2022-03-11 04:12:55 --> Helper loaded: common_helper
INFO - 2022-03-11 04:12:55 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:12:55 --> Controller Class Initialized
INFO - 2022-03-11 04:12:55 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:12:55 --> Encrypt Class Initialized
INFO - 2022-03-11 04:12:55 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:12:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:12:55 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:12:55 --> Model "Users_model" initialized
INFO - 2022-03-11 04:12:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 04:12:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:12:56 --> Config Class Initialized
INFO - 2022-03-11 04:12:56 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:12:56 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:12:56 --> Utf8 Class Initialized
INFO - 2022-03-11 04:12:56 --> URI Class Initialized
INFO - 2022-03-11 04:12:56 --> Router Class Initialized
INFO - 2022-03-11 04:12:56 --> Output Class Initialized
INFO - 2022-03-11 04:12:56 --> Security Class Initialized
DEBUG - 2022-03-11 04:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:12:56 --> Input Class Initialized
INFO - 2022-03-11 04:12:56 --> Language Class Initialized
INFO - 2022-03-11 04:12:56 --> Loader Class Initialized
INFO - 2022-03-11 04:12:56 --> Helper loaded: url_helper
INFO - 2022-03-11 04:12:56 --> Helper loaded: form_helper
INFO - 2022-03-11 04:12:56 --> Helper loaded: common_helper
INFO - 2022-03-11 04:12:56 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:12:56 --> Controller Class Initialized
INFO - 2022-03-11 04:12:56 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:12:56 --> Encrypt Class Initialized
INFO - 2022-03-11 04:12:56 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:12:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:12:56 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:12:56 --> Model "Users_model" initialized
INFO - 2022-03-11 04:12:56 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:12:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:12:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 04:12:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:12:56 --> Final output sent to browser
DEBUG - 2022-03-11 04:12:56 --> Total execution time: 0.1296
ERROR - 2022-03-11 04:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:14:35 --> Config Class Initialized
INFO - 2022-03-11 04:14:35 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:14:35 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:14:35 --> Utf8 Class Initialized
INFO - 2022-03-11 04:14:35 --> URI Class Initialized
INFO - 2022-03-11 04:14:35 --> Router Class Initialized
INFO - 2022-03-11 04:14:35 --> Output Class Initialized
INFO - 2022-03-11 04:14:35 --> Security Class Initialized
DEBUG - 2022-03-11 04:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:14:35 --> Input Class Initialized
INFO - 2022-03-11 04:14:35 --> Language Class Initialized
INFO - 2022-03-11 04:14:35 --> Loader Class Initialized
INFO - 2022-03-11 04:14:35 --> Helper loaded: url_helper
INFO - 2022-03-11 04:14:35 --> Helper loaded: form_helper
INFO - 2022-03-11 04:14:35 --> Helper loaded: common_helper
INFO - 2022-03-11 04:14:35 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:14:35 --> Controller Class Initialized
INFO - 2022-03-11 04:14:35 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:14:35 --> Encrypt Class Initialized
INFO - 2022-03-11 04:14:35 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:14:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:14:35 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:14:35 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:14:35 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:14:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:14:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 04:14:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:14:44 --> Final output sent to browser
DEBUG - 2022-03-11 04:14:44 --> Total execution time: 5.8922
ERROR - 2022-03-11 04:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:24:21 --> Config Class Initialized
INFO - 2022-03-11 04:24:21 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:24:21 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:24:21 --> Utf8 Class Initialized
INFO - 2022-03-11 04:24:21 --> URI Class Initialized
DEBUG - 2022-03-11 04:24:21 --> No URI present. Default controller set.
INFO - 2022-03-11 04:24:21 --> Router Class Initialized
INFO - 2022-03-11 04:24:21 --> Output Class Initialized
INFO - 2022-03-11 04:24:21 --> Security Class Initialized
DEBUG - 2022-03-11 04:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:24:21 --> Input Class Initialized
INFO - 2022-03-11 04:24:21 --> Language Class Initialized
INFO - 2022-03-11 04:24:21 --> Loader Class Initialized
INFO - 2022-03-11 04:24:21 --> Helper loaded: url_helper
INFO - 2022-03-11 04:24:21 --> Helper loaded: form_helper
INFO - 2022-03-11 04:24:21 --> Helper loaded: common_helper
INFO - 2022-03-11 04:24:21 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:24:21 --> Controller Class Initialized
INFO - 2022-03-11 04:24:21 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:24:21 --> Encrypt Class Initialized
DEBUG - 2022-03-11 04:24:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 04:24:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 04:24:21 --> Email Class Initialized
INFO - 2022-03-11 04:24:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 04:24:21 --> Calendar Class Initialized
INFO - 2022-03-11 04:24:21 --> Model "Login_model" initialized
INFO - 2022-03-11 04:24:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 04:24:21 --> Final output sent to browser
DEBUG - 2022-03-11 04:24:21 --> Total execution time: 0.0490
ERROR - 2022-03-11 04:24:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:24:41 --> Config Class Initialized
INFO - 2022-03-11 04:24:41 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:24:41 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:24:41 --> Utf8 Class Initialized
INFO - 2022-03-11 04:24:41 --> URI Class Initialized
INFO - 2022-03-11 04:24:41 --> Router Class Initialized
INFO - 2022-03-11 04:24:41 --> Output Class Initialized
INFO - 2022-03-11 04:24:41 --> Security Class Initialized
DEBUG - 2022-03-11 04:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:24:41 --> Input Class Initialized
INFO - 2022-03-11 04:24:41 --> Language Class Initialized
INFO - 2022-03-11 04:24:41 --> Loader Class Initialized
INFO - 2022-03-11 04:24:41 --> Helper loaded: url_helper
INFO - 2022-03-11 04:24:41 --> Helper loaded: form_helper
INFO - 2022-03-11 04:24:41 --> Helper loaded: common_helper
INFO - 2022-03-11 04:24:41 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:24:41 --> Controller Class Initialized
INFO - 2022-03-11 04:24:41 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:24:41 --> Encrypt Class Initialized
DEBUG - 2022-03-11 04:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 04:24:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 04:24:41 --> Email Class Initialized
INFO - 2022-03-11 04:24:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 04:24:41 --> Calendar Class Initialized
INFO - 2022-03-11 04:24:41 --> Model "Login_model" initialized
INFO - 2022-03-11 04:24:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-11 04:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:24:42 --> Config Class Initialized
INFO - 2022-03-11 04:24:42 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:24:42 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:24:42 --> Utf8 Class Initialized
INFO - 2022-03-11 04:24:42 --> URI Class Initialized
INFO - 2022-03-11 04:24:42 --> Router Class Initialized
INFO - 2022-03-11 04:24:42 --> Output Class Initialized
INFO - 2022-03-11 04:24:42 --> Security Class Initialized
DEBUG - 2022-03-11 04:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:24:42 --> Input Class Initialized
INFO - 2022-03-11 04:24:42 --> Language Class Initialized
INFO - 2022-03-11 04:24:42 --> Loader Class Initialized
INFO - 2022-03-11 04:24:42 --> Helper loaded: url_helper
INFO - 2022-03-11 04:24:42 --> Helper loaded: form_helper
INFO - 2022-03-11 04:24:42 --> Helper loaded: common_helper
INFO - 2022-03-11 04:24:42 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:24:42 --> Controller Class Initialized
INFO - 2022-03-11 04:24:42 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:24:42 --> Encrypt Class Initialized
INFO - 2022-03-11 04:24:42 --> Model "Login_model" initialized
INFO - 2022-03-11 04:24:42 --> Model "Dashboard_model" initialized
INFO - 2022-03-11 04:24:42 --> Model "Case_model" initialized
INFO - 2022-03-11 04:24:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:25:06 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-11 04:25:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:25:06 --> Final output sent to browser
DEBUG - 2022-03-11 04:25:06 --> Total execution time: 23.5510
ERROR - 2022-03-11 04:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:25:09 --> Config Class Initialized
INFO - 2022-03-11 04:25:09 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:25:09 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:25:09 --> Utf8 Class Initialized
INFO - 2022-03-11 04:25:09 --> URI Class Initialized
INFO - 2022-03-11 04:25:09 --> Router Class Initialized
INFO - 2022-03-11 04:25:09 --> Output Class Initialized
INFO - 2022-03-11 04:25:09 --> Security Class Initialized
DEBUG - 2022-03-11 04:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:25:09 --> Input Class Initialized
INFO - 2022-03-11 04:25:09 --> Language Class Initialized
ERROR - 2022-03-11 04:25:09 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 04:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:26:28 --> Config Class Initialized
INFO - 2022-03-11 04:26:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:26:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:26:28 --> Utf8 Class Initialized
INFO - 2022-03-11 04:26:28 --> URI Class Initialized
INFO - 2022-03-11 04:26:28 --> Router Class Initialized
INFO - 2022-03-11 04:26:28 --> Output Class Initialized
INFO - 2022-03-11 04:26:28 --> Security Class Initialized
DEBUG - 2022-03-11 04:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:26:28 --> Input Class Initialized
INFO - 2022-03-11 04:26:28 --> Language Class Initialized
INFO - 2022-03-11 04:26:28 --> Loader Class Initialized
INFO - 2022-03-11 04:26:28 --> Helper loaded: url_helper
INFO - 2022-03-11 04:26:28 --> Helper loaded: form_helper
INFO - 2022-03-11 04:26:28 --> Helper loaded: common_helper
INFO - 2022-03-11 04:26:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:26:28 --> Controller Class Initialized
INFO - 2022-03-11 04:26:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:26:28 --> Encrypt Class Initialized
INFO - 2022-03-11 04:26:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:26:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:26:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:26:28 --> Model "Users_model" initialized
INFO - 2022-03-11 04:26:28 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:26:28 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-11 04:26:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:26:29 --> Config Class Initialized
INFO - 2022-03-11 04:26:29 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:26:29 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:26:29 --> Utf8 Class Initialized
INFO - 2022-03-11 04:26:29 --> URI Class Initialized
INFO - 2022-03-11 04:26:29 --> Router Class Initialized
INFO - 2022-03-11 04:26:29 --> Output Class Initialized
INFO - 2022-03-11 04:26:29 --> Security Class Initialized
DEBUG - 2022-03-11 04:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:26:29 --> Input Class Initialized
INFO - 2022-03-11 04:26:29 --> Language Class Initialized
ERROR - 2022-03-11 04:26:29 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 04:26:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:26:29 --> Config Class Initialized
INFO - 2022-03-11 04:26:29 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:26:29 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:26:29 --> Utf8 Class Initialized
INFO - 2022-03-11 04:26:29 --> URI Class Initialized
INFO - 2022-03-11 04:26:29 --> Router Class Initialized
INFO - 2022-03-11 04:26:29 --> Output Class Initialized
INFO - 2022-03-11 04:26:29 --> Security Class Initialized
DEBUG - 2022-03-11 04:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:26:29 --> Input Class Initialized
INFO - 2022-03-11 04:26:29 --> Language Class Initialized
ERROR - 2022-03-11 04:26:29 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 04:26:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:26:30 --> Config Class Initialized
INFO - 2022-03-11 04:26:30 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:26:30 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:26:30 --> Utf8 Class Initialized
INFO - 2022-03-11 04:26:30 --> URI Class Initialized
INFO - 2022-03-11 04:26:30 --> Router Class Initialized
INFO - 2022-03-11 04:26:30 --> Output Class Initialized
INFO - 2022-03-11 04:26:30 --> Security Class Initialized
DEBUG - 2022-03-11 04:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:26:30 --> Input Class Initialized
INFO - 2022-03-11 04:26:30 --> Language Class Initialized
ERROR - 2022-03-11 04:26:30 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-11 04:26:30 --> Final output sent to browser
DEBUG - 2022-03-11 04:26:30 --> Total execution time: 1.8157
ERROR - 2022-03-11 04:26:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:26:50 --> Config Class Initialized
INFO - 2022-03-11 04:26:50 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:26:50 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:26:50 --> Utf8 Class Initialized
INFO - 2022-03-11 04:26:50 --> URI Class Initialized
INFO - 2022-03-11 04:26:50 --> Router Class Initialized
INFO - 2022-03-11 04:26:50 --> Output Class Initialized
INFO - 2022-03-11 04:26:50 --> Security Class Initialized
DEBUG - 2022-03-11 04:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:26:50 --> Input Class Initialized
INFO - 2022-03-11 04:26:50 --> Language Class Initialized
INFO - 2022-03-11 04:26:50 --> Loader Class Initialized
INFO - 2022-03-11 04:26:50 --> Helper loaded: url_helper
INFO - 2022-03-11 04:26:50 --> Helper loaded: form_helper
INFO - 2022-03-11 04:26:50 --> Helper loaded: common_helper
INFO - 2022-03-11 04:26:50 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:26:50 --> Controller Class Initialized
INFO - 2022-03-11 04:26:50 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:26:50 --> Encrypt Class Initialized
INFO - 2022-03-11 04:26:50 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:26:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:26:51 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:26:51 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:26:51 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:26:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:26:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 04:26:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:26:51 --> Final output sent to browser
DEBUG - 2022-03-11 04:26:51 --> Total execution time: 0.0552
ERROR - 2022-03-11 04:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:26:51 --> Config Class Initialized
INFO - 2022-03-11 04:26:51 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:26:51 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:26:51 --> Utf8 Class Initialized
INFO - 2022-03-11 04:26:51 --> URI Class Initialized
INFO - 2022-03-11 04:26:51 --> Router Class Initialized
INFO - 2022-03-11 04:26:51 --> Output Class Initialized
INFO - 2022-03-11 04:26:51 --> Security Class Initialized
DEBUG - 2022-03-11 04:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:26:51 --> Input Class Initialized
INFO - 2022-03-11 04:26:51 --> Language Class Initialized
ERROR - 2022-03-11 04:26:51 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-11 04:27:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:27:20 --> Config Class Initialized
INFO - 2022-03-11 04:27:20 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:27:20 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:27:20 --> Utf8 Class Initialized
INFO - 2022-03-11 04:27:20 --> URI Class Initialized
INFO - 2022-03-11 04:27:20 --> Router Class Initialized
INFO - 2022-03-11 04:27:20 --> Output Class Initialized
INFO - 2022-03-11 04:27:20 --> Security Class Initialized
DEBUG - 2022-03-11 04:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:27:20 --> Input Class Initialized
INFO - 2022-03-11 04:27:20 --> Language Class Initialized
INFO - 2022-03-11 04:27:20 --> Loader Class Initialized
INFO - 2022-03-11 04:27:20 --> Helper loaded: url_helper
INFO - 2022-03-11 04:27:20 --> Helper loaded: form_helper
INFO - 2022-03-11 04:27:20 --> Helper loaded: common_helper
INFO - 2022-03-11 04:27:20 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:27:20 --> Controller Class Initialized
INFO - 2022-03-11 04:27:20 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:27:20 --> Encrypt Class Initialized
INFO - 2022-03-11 04:27:20 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:27:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:27:20 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:27:20 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:27:20 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:27:20 --> Upload Class Initialized
INFO - 2022-03-11 04:27:20 --> Final output sent to browser
DEBUG - 2022-03-11 04:27:20 --> Total execution time: 0.0366
ERROR - 2022-03-11 04:27:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:27:27 --> Config Class Initialized
INFO - 2022-03-11 04:27:27 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:27:27 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:27:27 --> Utf8 Class Initialized
INFO - 2022-03-11 04:27:27 --> URI Class Initialized
INFO - 2022-03-11 04:27:27 --> Router Class Initialized
INFO - 2022-03-11 04:27:27 --> Output Class Initialized
INFO - 2022-03-11 04:27:27 --> Security Class Initialized
DEBUG - 2022-03-11 04:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:27:27 --> Input Class Initialized
INFO - 2022-03-11 04:27:27 --> Language Class Initialized
INFO - 2022-03-11 04:27:27 --> Loader Class Initialized
INFO - 2022-03-11 04:27:27 --> Helper loaded: url_helper
INFO - 2022-03-11 04:27:27 --> Helper loaded: form_helper
INFO - 2022-03-11 04:27:27 --> Helper loaded: common_helper
INFO - 2022-03-11 04:27:27 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:27:27 --> Controller Class Initialized
INFO - 2022-03-11 04:27:27 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:27:27 --> Encrypt Class Initialized
INFO - 2022-03-11 04:27:27 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:27:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:27:27 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:27:27 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:27:27 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 04:27:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:27:28 --> Config Class Initialized
INFO - 2022-03-11 04:27:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:27:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:27:28 --> Utf8 Class Initialized
INFO - 2022-03-11 04:27:28 --> URI Class Initialized
INFO - 2022-03-11 04:27:28 --> Router Class Initialized
INFO - 2022-03-11 04:27:28 --> Output Class Initialized
INFO - 2022-03-11 04:27:28 --> Security Class Initialized
DEBUG - 2022-03-11 04:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:27:28 --> Input Class Initialized
INFO - 2022-03-11 04:27:28 --> Language Class Initialized
INFO - 2022-03-11 04:27:28 --> Loader Class Initialized
INFO - 2022-03-11 04:27:28 --> Helper loaded: url_helper
INFO - 2022-03-11 04:27:28 --> Helper loaded: form_helper
INFO - 2022-03-11 04:27:28 --> Helper loaded: common_helper
INFO - 2022-03-11 04:27:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:27:28 --> Controller Class Initialized
INFO - 2022-03-11 04:27:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:27:28 --> Encrypt Class Initialized
INFO - 2022-03-11 04:27:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:27:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:27:28 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:27:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:27:28 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:27:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:27:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 04:27:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:27:28 --> Final output sent to browser
DEBUG - 2022-03-11 04:27:28 --> Total execution time: 0.0529
ERROR - 2022-03-11 04:27:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:27:29 --> Config Class Initialized
INFO - 2022-03-11 04:27:29 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:27:29 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:27:29 --> Utf8 Class Initialized
INFO - 2022-03-11 04:27:29 --> URI Class Initialized
INFO - 2022-03-11 04:27:29 --> Router Class Initialized
INFO - 2022-03-11 04:27:29 --> Output Class Initialized
INFO - 2022-03-11 04:27:29 --> Security Class Initialized
DEBUG - 2022-03-11 04:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:27:29 --> Input Class Initialized
INFO - 2022-03-11 04:27:29 --> Language Class Initialized
INFO - 2022-03-11 04:27:29 --> Loader Class Initialized
INFO - 2022-03-11 04:27:29 --> Helper loaded: url_helper
INFO - 2022-03-11 04:27:29 --> Helper loaded: form_helper
INFO - 2022-03-11 04:27:29 --> Helper loaded: common_helper
INFO - 2022-03-11 04:27:29 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:27:29 --> Controller Class Initialized
INFO - 2022-03-11 04:27:29 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:27:29 --> Encrypt Class Initialized
INFO - 2022-03-11 04:27:29 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:27:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:27:29 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:27:29 --> Model "Users_model" initialized
INFO - 2022-03-11 04:27:29 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:27:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:27:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 04:27:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:27:29 --> Final output sent to browser
DEBUG - 2022-03-11 04:27:29 --> Total execution time: 0.0657
ERROR - 2022-03-11 04:27:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:27:36 --> Config Class Initialized
INFO - 2022-03-11 04:27:36 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:27:36 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:27:36 --> Utf8 Class Initialized
INFO - 2022-03-11 04:27:36 --> URI Class Initialized
INFO - 2022-03-11 04:27:36 --> Router Class Initialized
INFO - 2022-03-11 04:27:36 --> Output Class Initialized
INFO - 2022-03-11 04:27:36 --> Security Class Initialized
DEBUG - 2022-03-11 04:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:27:36 --> Input Class Initialized
INFO - 2022-03-11 04:27:36 --> Language Class Initialized
INFO - 2022-03-11 04:27:36 --> Loader Class Initialized
INFO - 2022-03-11 04:27:36 --> Helper loaded: url_helper
INFO - 2022-03-11 04:27:36 --> Helper loaded: form_helper
INFO - 2022-03-11 04:27:36 --> Helper loaded: common_helper
INFO - 2022-03-11 04:27:36 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:27:36 --> Controller Class Initialized
INFO - 2022-03-11 04:27:36 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:27:36 --> Encrypt Class Initialized
INFO - 2022-03-11 04:27:36 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:27:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:27:36 --> Model "Referredby_model" initialized
INFO - 2022-03-11 04:27:36 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:27:36 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:27:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:27:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 04:27:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:27:45 --> Final output sent to browser
DEBUG - 2022-03-11 04:27:45 --> Total execution time: 6.9067
ERROR - 2022-03-11 04:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:28:09 --> Config Class Initialized
INFO - 2022-03-11 04:28:09 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:28:09 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:28:09 --> Utf8 Class Initialized
INFO - 2022-03-11 04:28:09 --> URI Class Initialized
INFO - 2022-03-11 04:28:09 --> Router Class Initialized
INFO - 2022-03-11 04:28:09 --> Output Class Initialized
INFO - 2022-03-11 04:28:09 --> Security Class Initialized
DEBUG - 2022-03-11 04:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:28:09 --> Input Class Initialized
INFO - 2022-03-11 04:28:09 --> Language Class Initialized
INFO - 2022-03-11 04:28:09 --> Loader Class Initialized
INFO - 2022-03-11 04:28:09 --> Helper loaded: url_helper
INFO - 2022-03-11 04:28:09 --> Helper loaded: form_helper
INFO - 2022-03-11 04:28:09 --> Helper loaded: common_helper
INFO - 2022-03-11 04:28:09 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:28:09 --> Controller Class Initialized
INFO - 2022-03-11 04:28:09 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:28:09 --> Encrypt Class Initialized
INFO - 2022-03-11 04:28:09 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:28:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:28:09 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:28:09 --> Model "Users_model" initialized
INFO - 2022-03-11 04:28:09 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:28:09 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-11 04:28:10 --> Final output sent to browser
DEBUG - 2022-03-11 04:28:10 --> Total execution time: 0.8575
ERROR - 2022-03-11 04:30:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:30:32 --> Config Class Initialized
INFO - 2022-03-11 04:30:32 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:30:32 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:30:32 --> Utf8 Class Initialized
INFO - 2022-03-11 04:30:32 --> URI Class Initialized
INFO - 2022-03-11 04:30:32 --> Router Class Initialized
INFO - 2022-03-11 04:30:32 --> Output Class Initialized
INFO - 2022-03-11 04:30:32 --> Security Class Initialized
DEBUG - 2022-03-11 04:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:30:32 --> Input Class Initialized
INFO - 2022-03-11 04:30:32 --> Language Class Initialized
INFO - 2022-03-11 04:30:32 --> Loader Class Initialized
INFO - 2022-03-11 04:30:32 --> Helper loaded: url_helper
INFO - 2022-03-11 04:30:32 --> Helper loaded: form_helper
INFO - 2022-03-11 04:30:32 --> Helper loaded: common_helper
INFO - 2022-03-11 04:30:32 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:30:32 --> Controller Class Initialized
INFO - 2022-03-11 04:30:32 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:30:32 --> Encrypt Class Initialized
INFO - 2022-03-11 04:30:32 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:30:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:30:32 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:30:32 --> Model "Users_model" initialized
INFO - 2022-03-11 04:30:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 04:30:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 04:30:33 --> Config Class Initialized
INFO - 2022-03-11 04:30:33 --> Hooks Class Initialized
DEBUG - 2022-03-11 04:30:33 --> UTF-8 Support Enabled
INFO - 2022-03-11 04:30:33 --> Utf8 Class Initialized
INFO - 2022-03-11 04:30:33 --> URI Class Initialized
INFO - 2022-03-11 04:30:33 --> Router Class Initialized
INFO - 2022-03-11 04:30:33 --> Output Class Initialized
INFO - 2022-03-11 04:30:33 --> Security Class Initialized
DEBUG - 2022-03-11 04:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 04:30:33 --> Input Class Initialized
INFO - 2022-03-11 04:30:33 --> Language Class Initialized
INFO - 2022-03-11 04:30:33 --> Loader Class Initialized
INFO - 2022-03-11 04:30:33 --> Helper loaded: url_helper
INFO - 2022-03-11 04:30:33 --> Helper loaded: form_helper
INFO - 2022-03-11 04:30:33 --> Helper loaded: common_helper
INFO - 2022-03-11 04:30:33 --> Database Driver Class Initialized
DEBUG - 2022-03-11 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 04:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 04:30:33 --> Controller Class Initialized
INFO - 2022-03-11 04:30:33 --> Form Validation Class Initialized
DEBUG - 2022-03-11 04:30:33 --> Encrypt Class Initialized
INFO - 2022-03-11 04:30:33 --> Model "Patient_model" initialized
INFO - 2022-03-11 04:30:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 04:30:33 --> Model "Prefix_master" initialized
INFO - 2022-03-11 04:30:33 --> Model "Users_model" initialized
INFO - 2022-03-11 04:30:33 --> Model "Hospital_model" initialized
INFO - 2022-03-11 04:30:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 04:30:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 04:30:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 04:30:33 --> Final output sent to browser
DEBUG - 2022-03-11 04:30:33 --> Total execution time: 0.0625
ERROR - 2022-03-11 05:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:50:38 --> Config Class Initialized
INFO - 2022-03-11 05:50:38 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:50:38 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:50:38 --> Utf8 Class Initialized
INFO - 2022-03-11 05:50:38 --> URI Class Initialized
DEBUG - 2022-03-11 05:50:38 --> No URI present. Default controller set.
INFO - 2022-03-11 05:50:38 --> Router Class Initialized
INFO - 2022-03-11 05:50:38 --> Output Class Initialized
INFO - 2022-03-11 05:50:38 --> Security Class Initialized
DEBUG - 2022-03-11 05:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:50:38 --> Input Class Initialized
INFO - 2022-03-11 05:50:38 --> Language Class Initialized
INFO - 2022-03-11 05:50:38 --> Loader Class Initialized
INFO - 2022-03-11 05:50:38 --> Helper loaded: url_helper
INFO - 2022-03-11 05:50:38 --> Helper loaded: form_helper
INFO - 2022-03-11 05:50:38 --> Helper loaded: common_helper
INFO - 2022-03-11 05:50:38 --> Database Driver Class Initialized
DEBUG - 2022-03-11 05:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 05:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 05:50:38 --> Controller Class Initialized
INFO - 2022-03-11 05:50:38 --> Form Validation Class Initialized
DEBUG - 2022-03-11 05:50:38 --> Encrypt Class Initialized
DEBUG - 2022-03-11 05:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 05:50:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 05:50:38 --> Email Class Initialized
INFO - 2022-03-11 05:50:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 05:50:38 --> Calendar Class Initialized
INFO - 2022-03-11 05:50:38 --> Model "Login_model" initialized
ERROR - 2022-03-11 05:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:50:40 --> Config Class Initialized
INFO - 2022-03-11 05:50:40 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:50:40 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:50:40 --> Utf8 Class Initialized
INFO - 2022-03-11 05:50:40 --> URI Class Initialized
INFO - 2022-03-11 05:50:40 --> Router Class Initialized
INFO - 2022-03-11 05:50:40 --> Output Class Initialized
INFO - 2022-03-11 05:50:40 --> Security Class Initialized
DEBUG - 2022-03-11 05:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:50:40 --> Input Class Initialized
INFO - 2022-03-11 05:50:40 --> Language Class Initialized
INFO - 2022-03-11 05:50:40 --> Loader Class Initialized
INFO - 2022-03-11 05:50:40 --> Helper loaded: url_helper
INFO - 2022-03-11 05:50:40 --> Helper loaded: form_helper
INFO - 2022-03-11 05:50:40 --> Helper loaded: common_helper
INFO - 2022-03-11 05:50:40 --> Database Driver Class Initialized
DEBUG - 2022-03-11 05:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 05:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 05:50:40 --> Controller Class Initialized
INFO - 2022-03-11 05:50:40 --> Form Validation Class Initialized
DEBUG - 2022-03-11 05:50:40 --> Encrypt Class Initialized
INFO - 2022-03-11 05:50:40 --> Model "Diseases_model" initialized
INFO - 2022-03-11 05:50:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 05:50:40 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-11 05:50:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 05:50:40 --> Final output sent to browser
DEBUG - 2022-03-11 05:50:40 --> Total execution time: 0.1435
ERROR - 2022-03-11 05:50:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:50:41 --> Config Class Initialized
INFO - 2022-03-11 05:50:41 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:50:41 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:50:41 --> Utf8 Class Initialized
INFO - 2022-03-11 05:50:41 --> URI Class Initialized
INFO - 2022-03-11 05:50:41 --> Router Class Initialized
INFO - 2022-03-11 05:50:41 --> Output Class Initialized
INFO - 2022-03-11 05:50:41 --> Security Class Initialized
DEBUG - 2022-03-11 05:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:50:41 --> Input Class Initialized
INFO - 2022-03-11 05:50:41 --> Language Class Initialized
ERROR - 2022-03-11 05:50:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 05:51:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:51:19 --> Config Class Initialized
INFO - 2022-03-11 05:51:19 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:51:19 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:51:19 --> Utf8 Class Initialized
INFO - 2022-03-11 05:51:19 --> URI Class Initialized
INFO - 2022-03-11 05:51:19 --> Router Class Initialized
INFO - 2022-03-11 05:51:19 --> Output Class Initialized
INFO - 2022-03-11 05:51:19 --> Security Class Initialized
DEBUG - 2022-03-11 05:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:51:19 --> Input Class Initialized
INFO - 2022-03-11 05:51:19 --> Language Class Initialized
INFO - 2022-03-11 05:51:19 --> Loader Class Initialized
INFO - 2022-03-11 05:51:19 --> Helper loaded: url_helper
INFO - 2022-03-11 05:51:19 --> Helper loaded: form_helper
INFO - 2022-03-11 05:51:19 --> Helper loaded: common_helper
INFO - 2022-03-11 05:51:19 --> Database Driver Class Initialized
DEBUG - 2022-03-11 05:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 05:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 05:51:19 --> Controller Class Initialized
INFO - 2022-03-11 05:51:19 --> Form Validation Class Initialized
DEBUG - 2022-03-11 05:51:19 --> Encrypt Class Initialized
INFO - 2022-03-11 05:51:19 --> Model "Patient_model" initialized
INFO - 2022-03-11 05:51:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 05:51:19 --> Model "Referredby_model" initialized
INFO - 2022-03-11 05:51:19 --> Model "Prefix_master" initialized
INFO - 2022-03-11 05:51:19 --> Model "Hospital_model" initialized
INFO - 2022-03-11 05:51:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-11 05:51:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:51:22 --> Config Class Initialized
INFO - 2022-03-11 05:51:22 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:51:22 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:51:22 --> Utf8 Class Initialized
INFO - 2022-03-11 05:51:22 --> URI Class Initialized
INFO - 2022-03-11 05:51:22 --> Router Class Initialized
INFO - 2022-03-11 05:51:22 --> Output Class Initialized
INFO - 2022-03-11 05:51:22 --> Security Class Initialized
DEBUG - 2022-03-11 05:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:51:22 --> Input Class Initialized
INFO - 2022-03-11 05:51:22 --> Language Class Initialized
INFO - 2022-03-11 05:51:22 --> Loader Class Initialized
INFO - 2022-03-11 05:51:22 --> Helper loaded: url_helper
INFO - 2022-03-11 05:51:22 --> Helper loaded: form_helper
INFO - 2022-03-11 05:51:22 --> Helper loaded: common_helper
INFO - 2022-03-11 05:51:22 --> Database Driver Class Initialized
DEBUG - 2022-03-11 05:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 05:51:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 05:51:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 05:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 05:51:27 --> Controller Class Initialized
INFO - 2022-03-11 05:51:27 --> Form Validation Class Initialized
DEBUG - 2022-03-11 05:51:27 --> Encrypt Class Initialized
INFO - 2022-03-11 05:51:27 --> Model "Patient_model" initialized
INFO - 2022-03-11 05:51:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 05:51:27 --> Model "Referredby_model" initialized
INFO - 2022-03-11 05:51:27 --> Model "Prefix_master" initialized
INFO - 2022-03-11 05:51:27 --> Model "Hospital_model" initialized
INFO - 2022-03-11 05:51:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 05:51:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 05:51:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 05:51:27 --> Final output sent to browser
DEBUG - 2022-03-11 05:51:27 --> Total execution time: 5.6091
ERROR - 2022-03-11 05:51:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:51:28 --> Config Class Initialized
INFO - 2022-03-11 05:51:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:51:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:51:28 --> Utf8 Class Initialized
INFO - 2022-03-11 05:51:28 --> URI Class Initialized
INFO - 2022-03-11 05:51:28 --> Router Class Initialized
INFO - 2022-03-11 05:51:28 --> Output Class Initialized
INFO - 2022-03-11 05:51:28 --> Security Class Initialized
DEBUG - 2022-03-11 05:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:51:28 --> Input Class Initialized
INFO - 2022-03-11 05:51:28 --> Language Class Initialized
INFO - 2022-03-11 05:51:28 --> Loader Class Initialized
INFO - 2022-03-11 05:51:28 --> Helper loaded: url_helper
INFO - 2022-03-11 05:51:28 --> Helper loaded: form_helper
INFO - 2022-03-11 05:51:28 --> Helper loaded: common_helper
INFO - 2022-03-11 05:51:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 05:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 05:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 05:51:28 --> Controller Class Initialized
INFO - 2022-03-11 05:51:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 05:51:28 --> Encrypt Class Initialized
INFO - 2022-03-11 05:51:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 05:51:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 05:51:28 --> Model "Referredby_model" initialized
INFO - 2022-03-11 05:51:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 05:51:28 --> Model "Hospital_model" initialized
INFO - 2022-03-11 05:51:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 05:51:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 05:51:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 05:51:28 --> Final output sent to browser
DEBUG - 2022-03-11 05:51:28 --> Total execution time: 0.0534
ERROR - 2022-03-11 05:51:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:51:28 --> Config Class Initialized
INFO - 2022-03-11 05:51:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:51:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:51:28 --> Utf8 Class Initialized
INFO - 2022-03-11 05:51:28 --> URI Class Initialized
INFO - 2022-03-11 05:51:28 --> Router Class Initialized
INFO - 2022-03-11 05:51:28 --> Output Class Initialized
INFO - 2022-03-11 05:51:28 --> Security Class Initialized
DEBUG - 2022-03-11 05:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:51:28 --> Input Class Initialized
INFO - 2022-03-11 05:51:28 --> Language Class Initialized
ERROR - 2022-03-11 05:51:28 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 05:53:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:53:37 --> Config Class Initialized
INFO - 2022-03-11 05:53:37 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:53:37 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:53:37 --> Utf8 Class Initialized
INFO - 2022-03-11 05:53:37 --> URI Class Initialized
INFO - 2022-03-11 05:53:37 --> Router Class Initialized
INFO - 2022-03-11 05:53:37 --> Output Class Initialized
INFO - 2022-03-11 05:53:37 --> Security Class Initialized
DEBUG - 2022-03-11 05:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:53:37 --> Input Class Initialized
INFO - 2022-03-11 05:53:37 --> Language Class Initialized
INFO - 2022-03-11 05:53:37 --> Loader Class Initialized
INFO - 2022-03-11 05:53:37 --> Helper loaded: url_helper
INFO - 2022-03-11 05:53:37 --> Helper loaded: form_helper
INFO - 2022-03-11 05:53:37 --> Helper loaded: common_helper
INFO - 2022-03-11 05:53:37 --> Database Driver Class Initialized
DEBUG - 2022-03-11 05:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 05:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 05:53:37 --> Controller Class Initialized
INFO - 2022-03-11 05:53:37 --> Model "Referredby_model" initialized
INFO - 2022-03-11 05:53:37 --> Final output sent to browser
DEBUG - 2022-03-11 05:53:37 --> Total execution time: 0.0391
ERROR - 2022-03-11 05:53:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:53:53 --> Config Class Initialized
INFO - 2022-03-11 05:53:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:53:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:53:53 --> Utf8 Class Initialized
INFO - 2022-03-11 05:53:53 --> URI Class Initialized
INFO - 2022-03-11 05:53:53 --> Router Class Initialized
INFO - 2022-03-11 05:53:53 --> Output Class Initialized
INFO - 2022-03-11 05:53:53 --> Security Class Initialized
DEBUG - 2022-03-11 05:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:53:53 --> Input Class Initialized
INFO - 2022-03-11 05:53:53 --> Language Class Initialized
INFO - 2022-03-11 05:53:53 --> Loader Class Initialized
INFO - 2022-03-11 05:53:53 --> Helper loaded: url_helper
INFO - 2022-03-11 05:53:53 --> Helper loaded: form_helper
INFO - 2022-03-11 05:53:53 --> Helper loaded: common_helper
INFO - 2022-03-11 05:53:53 --> Database Driver Class Initialized
DEBUG - 2022-03-11 05:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 05:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 05:53:53 --> Controller Class Initialized
INFO - 2022-03-11 05:53:53 --> Model "Referredby_model" initialized
INFO - 2022-03-11 05:53:53 --> Final output sent to browser
DEBUG - 2022-03-11 05:53:53 --> Total execution time: 0.0391
ERROR - 2022-03-11 05:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:54:06 --> Config Class Initialized
INFO - 2022-03-11 05:54:06 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:54:06 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:54:06 --> Utf8 Class Initialized
INFO - 2022-03-11 05:54:06 --> URI Class Initialized
INFO - 2022-03-11 05:54:06 --> Router Class Initialized
INFO - 2022-03-11 05:54:06 --> Output Class Initialized
INFO - 2022-03-11 05:54:06 --> Security Class Initialized
DEBUG - 2022-03-11 05:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:54:06 --> Input Class Initialized
INFO - 2022-03-11 05:54:06 --> Language Class Initialized
INFO - 2022-03-11 05:54:06 --> Loader Class Initialized
INFO - 2022-03-11 05:54:06 --> Helper loaded: url_helper
INFO - 2022-03-11 05:54:06 --> Helper loaded: form_helper
INFO - 2022-03-11 05:54:06 --> Helper loaded: common_helper
INFO - 2022-03-11 05:54:06 --> Database Driver Class Initialized
DEBUG - 2022-03-11 05:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 05:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 05:54:06 --> Controller Class Initialized
INFO - 2022-03-11 05:54:06 --> Form Validation Class Initialized
DEBUG - 2022-03-11 05:54:06 --> Encrypt Class Initialized
INFO - 2022-03-11 05:54:06 --> Model "Patient_model" initialized
INFO - 2022-03-11 05:54:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 05:54:06 --> Model "Referredby_model" initialized
INFO - 2022-03-11 05:54:06 --> Model "Prefix_master" initialized
INFO - 2022-03-11 05:54:06 --> Model "Hospital_model" initialized
INFO - 2022-03-11 05:54:06 --> Final output sent to browser
DEBUG - 2022-03-11 05:54:06 --> Total execution time: 0.0381
ERROR - 2022-03-11 05:54:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 05:54:19 --> Config Class Initialized
INFO - 2022-03-11 05:54:19 --> Hooks Class Initialized
DEBUG - 2022-03-11 05:54:19 --> UTF-8 Support Enabled
INFO - 2022-03-11 05:54:19 --> Utf8 Class Initialized
INFO - 2022-03-11 05:54:19 --> URI Class Initialized
INFO - 2022-03-11 05:54:19 --> Router Class Initialized
INFO - 2022-03-11 05:54:19 --> Output Class Initialized
INFO - 2022-03-11 05:54:19 --> Security Class Initialized
DEBUG - 2022-03-11 05:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 05:54:19 --> Input Class Initialized
INFO - 2022-03-11 05:54:19 --> Language Class Initialized
INFO - 2022-03-11 05:54:19 --> Loader Class Initialized
INFO - 2022-03-11 05:54:19 --> Helper loaded: url_helper
INFO - 2022-03-11 05:54:19 --> Helper loaded: form_helper
INFO - 2022-03-11 05:54:19 --> Helper loaded: common_helper
INFO - 2022-03-11 05:54:19 --> Database Driver Class Initialized
DEBUG - 2022-03-11 05:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 05:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 05:54:19 --> Controller Class Initialized
INFO - 2022-03-11 05:54:19 --> Form Validation Class Initialized
DEBUG - 2022-03-11 05:54:19 --> Encrypt Class Initialized
INFO - 2022-03-11 05:54:19 --> Model "Patient_model" initialized
INFO - 2022-03-11 05:54:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 05:54:19 --> Model "Referredby_model" initialized
INFO - 2022-03-11 05:54:19 --> Model "Prefix_master" initialized
INFO - 2022-03-11 05:54:19 --> Model "Hospital_model" initialized
INFO - 2022-03-11 05:54:19 --> Final output sent to browser
DEBUG - 2022-03-11 05:54:19 --> Total execution time: 0.0449
ERROR - 2022-03-11 06:03:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:03:46 --> Config Class Initialized
INFO - 2022-03-11 06:03:46 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:03:46 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:03:46 --> Utf8 Class Initialized
INFO - 2022-03-11 06:03:46 --> URI Class Initialized
INFO - 2022-03-11 06:03:46 --> Router Class Initialized
INFO - 2022-03-11 06:03:46 --> Output Class Initialized
INFO - 2022-03-11 06:03:46 --> Security Class Initialized
DEBUG - 2022-03-11 06:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:03:46 --> Input Class Initialized
INFO - 2022-03-11 06:03:46 --> Language Class Initialized
INFO - 2022-03-11 06:03:46 --> Loader Class Initialized
INFO - 2022-03-11 06:03:46 --> Helper loaded: url_helper
INFO - 2022-03-11 06:03:46 --> Helper loaded: form_helper
INFO - 2022-03-11 06:03:46 --> Helper loaded: common_helper
INFO - 2022-03-11 06:03:46 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:03:46 --> Controller Class Initialized
INFO - 2022-03-11 06:03:46 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:03:46 --> Encrypt Class Initialized
INFO - 2022-03-11 06:03:46 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:03:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:03:46 --> Model "Referredby_model" initialized
INFO - 2022-03-11 06:03:46 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:03:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 06:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:03:47 --> Config Class Initialized
INFO - 2022-03-11 06:03:47 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:03:47 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:03:47 --> Utf8 Class Initialized
INFO - 2022-03-11 06:03:47 --> URI Class Initialized
INFO - 2022-03-11 06:03:47 --> Router Class Initialized
INFO - 2022-03-11 06:03:47 --> Output Class Initialized
INFO - 2022-03-11 06:03:47 --> Security Class Initialized
DEBUG - 2022-03-11 06:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:03:47 --> Input Class Initialized
INFO - 2022-03-11 06:03:47 --> Language Class Initialized
INFO - 2022-03-11 06:03:47 --> Loader Class Initialized
INFO - 2022-03-11 06:03:47 --> Helper loaded: url_helper
INFO - 2022-03-11 06:03:47 --> Helper loaded: form_helper
INFO - 2022-03-11 06:03:47 --> Helper loaded: common_helper
INFO - 2022-03-11 06:03:47 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:03:47 --> Controller Class Initialized
INFO - 2022-03-11 06:03:47 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:03:47 --> Encrypt Class Initialized
INFO - 2022-03-11 06:03:47 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:03:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:03:47 --> Model "Referredby_model" initialized
INFO - 2022-03-11 06:03:47 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:03:47 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:03:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:03:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 06:03:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:03:47 --> Final output sent to browser
DEBUG - 2022-03-11 06:03:47 --> Total execution time: 0.0752
ERROR - 2022-03-11 06:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:03:47 --> Config Class Initialized
INFO - 2022-03-11 06:03:47 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:03:47 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:03:47 --> Utf8 Class Initialized
INFO - 2022-03-11 06:03:47 --> URI Class Initialized
INFO - 2022-03-11 06:03:47 --> Router Class Initialized
INFO - 2022-03-11 06:03:47 --> Output Class Initialized
INFO - 2022-03-11 06:03:47 --> Security Class Initialized
DEBUG - 2022-03-11 06:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:03:47 --> Input Class Initialized
INFO - 2022-03-11 06:03:47 --> Language Class Initialized
ERROR - 2022-03-11 06:03:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 06:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:03:47 --> Config Class Initialized
INFO - 2022-03-11 06:03:47 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:03:47 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:03:47 --> Utf8 Class Initialized
INFO - 2022-03-11 06:03:47 --> URI Class Initialized
INFO - 2022-03-11 06:03:47 --> Router Class Initialized
INFO - 2022-03-11 06:03:47 --> Output Class Initialized
INFO - 2022-03-11 06:03:47 --> Security Class Initialized
DEBUG - 2022-03-11 06:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:03:47 --> Input Class Initialized
INFO - 2022-03-11 06:03:47 --> Language Class Initialized
INFO - 2022-03-11 06:03:47 --> Loader Class Initialized
INFO - 2022-03-11 06:03:47 --> Helper loaded: url_helper
INFO - 2022-03-11 06:03:47 --> Helper loaded: form_helper
INFO - 2022-03-11 06:03:47 --> Helper loaded: common_helper
INFO - 2022-03-11 06:03:47 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:03:47 --> Controller Class Initialized
INFO - 2022-03-11 06:03:47 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:03:47 --> Encrypt Class Initialized
INFO - 2022-03-11 06:03:47 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:03:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:03:47 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:03:47 --> Model "Users_model" initialized
INFO - 2022-03-11 06:03:47 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:03:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:03:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 06:03:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:03:48 --> Final output sent to browser
DEBUG - 2022-03-11 06:03:48 --> Total execution time: 0.0901
ERROR - 2022-03-11 06:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:03:48 --> Config Class Initialized
INFO - 2022-03-11 06:03:48 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:03:48 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:03:48 --> Utf8 Class Initialized
INFO - 2022-03-11 06:03:48 --> URI Class Initialized
INFO - 2022-03-11 06:03:48 --> Router Class Initialized
INFO - 2022-03-11 06:03:48 --> Output Class Initialized
INFO - 2022-03-11 06:03:48 --> Security Class Initialized
DEBUG - 2022-03-11 06:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:03:48 --> Input Class Initialized
INFO - 2022-03-11 06:03:48 --> Language Class Initialized
ERROR - 2022-03-11 06:03:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 06:06:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:06:04 --> Config Class Initialized
INFO - 2022-03-11 06:06:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:06:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:06:04 --> Utf8 Class Initialized
INFO - 2022-03-11 06:06:04 --> URI Class Initialized
INFO - 2022-03-11 06:06:04 --> Router Class Initialized
INFO - 2022-03-11 06:06:04 --> Output Class Initialized
INFO - 2022-03-11 06:06:04 --> Security Class Initialized
DEBUG - 2022-03-11 06:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:06:04 --> Input Class Initialized
INFO - 2022-03-11 06:06:04 --> Language Class Initialized
INFO - 2022-03-11 06:06:04 --> Loader Class Initialized
INFO - 2022-03-11 06:06:04 --> Helper loaded: url_helper
INFO - 2022-03-11 06:06:04 --> Helper loaded: form_helper
INFO - 2022-03-11 06:06:04 --> Helper loaded: common_helper
INFO - 2022-03-11 06:06:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:06:04 --> Controller Class Initialized
INFO - 2022-03-11 06:06:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:06:04 --> Encrypt Class Initialized
INFO - 2022-03-11 06:06:04 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:06:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:06:04 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:06:04 --> Model "Users_model" initialized
INFO - 2022-03-11 06:06:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 06:06:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:06:05 --> Config Class Initialized
INFO - 2022-03-11 06:06:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:06:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:06:05 --> Utf8 Class Initialized
INFO - 2022-03-11 06:06:05 --> URI Class Initialized
INFO - 2022-03-11 06:06:05 --> Router Class Initialized
INFO - 2022-03-11 06:06:05 --> Output Class Initialized
INFO - 2022-03-11 06:06:05 --> Security Class Initialized
DEBUG - 2022-03-11 06:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:06:05 --> Input Class Initialized
INFO - 2022-03-11 06:06:05 --> Language Class Initialized
INFO - 2022-03-11 06:06:05 --> Loader Class Initialized
INFO - 2022-03-11 06:06:05 --> Helper loaded: url_helper
INFO - 2022-03-11 06:06:05 --> Helper loaded: form_helper
INFO - 2022-03-11 06:06:05 --> Helper loaded: common_helper
INFO - 2022-03-11 06:06:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:06:05 --> Controller Class Initialized
INFO - 2022-03-11 06:06:05 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:06:05 --> Encrypt Class Initialized
INFO - 2022-03-11 06:06:05 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:06:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:06:05 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:06:05 --> Model "Users_model" initialized
INFO - 2022-03-11 06:06:05 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:06:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:06:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 06:06:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:06:05 --> Final output sent to browser
DEBUG - 2022-03-11 06:06:05 --> Total execution time: 0.1144
ERROR - 2022-03-11 06:06:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:06:05 --> Config Class Initialized
INFO - 2022-03-11 06:06:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:06:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:06:05 --> Utf8 Class Initialized
INFO - 2022-03-11 06:06:05 --> URI Class Initialized
INFO - 2022-03-11 06:06:05 --> Router Class Initialized
INFO - 2022-03-11 06:06:05 --> Output Class Initialized
INFO - 2022-03-11 06:06:05 --> Security Class Initialized
DEBUG - 2022-03-11 06:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:06:05 --> Input Class Initialized
INFO - 2022-03-11 06:06:05 --> Language Class Initialized
ERROR - 2022-03-11 06:06:05 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 06:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:07:00 --> Config Class Initialized
INFO - 2022-03-11 06:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:07:00 --> Utf8 Class Initialized
INFO - 2022-03-11 06:07:00 --> URI Class Initialized
INFO - 2022-03-11 06:07:00 --> Router Class Initialized
INFO - 2022-03-11 06:07:00 --> Output Class Initialized
INFO - 2022-03-11 06:07:00 --> Security Class Initialized
DEBUG - 2022-03-11 06:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:07:00 --> Input Class Initialized
INFO - 2022-03-11 06:07:00 --> Language Class Initialized
INFO - 2022-03-11 06:07:00 --> Loader Class Initialized
INFO - 2022-03-11 06:07:00 --> Helper loaded: url_helper
INFO - 2022-03-11 06:07:00 --> Helper loaded: form_helper
INFO - 2022-03-11 06:07:00 --> Helper loaded: common_helper
INFO - 2022-03-11 06:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:07:00 --> Controller Class Initialized
INFO - 2022-03-11 06:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:07:00 --> Encrypt Class Initialized
INFO - 2022-03-11 06:07:00 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:07:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:07:00 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:07:00 --> Model "Users_model" initialized
INFO - 2022-03-11 06:07:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 06:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:07:00 --> Config Class Initialized
INFO - 2022-03-11 06:07:00 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:07:00 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:07:00 --> Utf8 Class Initialized
INFO - 2022-03-11 06:07:00 --> URI Class Initialized
INFO - 2022-03-11 06:07:00 --> Router Class Initialized
INFO - 2022-03-11 06:07:00 --> Output Class Initialized
INFO - 2022-03-11 06:07:00 --> Security Class Initialized
DEBUG - 2022-03-11 06:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:07:00 --> Input Class Initialized
INFO - 2022-03-11 06:07:00 --> Language Class Initialized
INFO - 2022-03-11 06:07:00 --> Loader Class Initialized
INFO - 2022-03-11 06:07:00 --> Helper loaded: url_helper
INFO - 2022-03-11 06:07:00 --> Helper loaded: form_helper
INFO - 2022-03-11 06:07:00 --> Helper loaded: common_helper
INFO - 2022-03-11 06:07:00 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:07:00 --> Controller Class Initialized
INFO - 2022-03-11 06:07:00 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:07:00 --> Encrypt Class Initialized
INFO - 2022-03-11 06:07:00 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:07:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:07:00 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:07:00 --> Model "Users_model" initialized
INFO - 2022-03-11 06:07:00 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:07:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:07:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 06:07:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:07:00 --> Final output sent to browser
DEBUG - 2022-03-11 06:07:00 --> Total execution time: 0.1233
ERROR - 2022-03-11 06:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:07:01 --> Config Class Initialized
INFO - 2022-03-11 06:07:01 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:07:01 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:07:01 --> Utf8 Class Initialized
INFO - 2022-03-11 06:07:01 --> URI Class Initialized
INFO - 2022-03-11 06:07:01 --> Router Class Initialized
INFO - 2022-03-11 06:07:01 --> Output Class Initialized
INFO - 2022-03-11 06:07:01 --> Security Class Initialized
DEBUG - 2022-03-11 06:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:07:01 --> Input Class Initialized
INFO - 2022-03-11 06:07:01 --> Language Class Initialized
ERROR - 2022-03-11 06:07:01 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 06:07:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:07:37 --> Config Class Initialized
INFO - 2022-03-11 06:07:37 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:07:37 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:07:37 --> Utf8 Class Initialized
INFO - 2022-03-11 06:07:37 --> URI Class Initialized
INFO - 2022-03-11 06:07:37 --> Router Class Initialized
INFO - 2022-03-11 06:07:37 --> Output Class Initialized
INFO - 2022-03-11 06:07:37 --> Security Class Initialized
DEBUG - 2022-03-11 06:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:07:37 --> Input Class Initialized
INFO - 2022-03-11 06:07:37 --> Language Class Initialized
INFO - 2022-03-11 06:07:37 --> Loader Class Initialized
INFO - 2022-03-11 06:07:37 --> Helper loaded: url_helper
INFO - 2022-03-11 06:07:37 --> Helper loaded: form_helper
INFO - 2022-03-11 06:07:37 --> Helper loaded: common_helper
INFO - 2022-03-11 06:07:37 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:07:37 --> Controller Class Initialized
INFO - 2022-03-11 06:07:37 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:07:37 --> Encrypt Class Initialized
INFO - 2022-03-11 06:07:37 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:07:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:07:37 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:07:37 --> Model "Users_model" initialized
INFO - 2022-03-11 06:07:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 06:07:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:07:38 --> Config Class Initialized
INFO - 2022-03-11 06:07:38 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:07:38 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:07:38 --> Utf8 Class Initialized
INFO - 2022-03-11 06:07:38 --> URI Class Initialized
INFO - 2022-03-11 06:07:38 --> Router Class Initialized
INFO - 2022-03-11 06:07:38 --> Output Class Initialized
INFO - 2022-03-11 06:07:38 --> Security Class Initialized
DEBUG - 2022-03-11 06:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:07:38 --> Input Class Initialized
INFO - 2022-03-11 06:07:38 --> Language Class Initialized
INFO - 2022-03-11 06:07:38 --> Loader Class Initialized
INFO - 2022-03-11 06:07:38 --> Helper loaded: url_helper
INFO - 2022-03-11 06:07:38 --> Helper loaded: form_helper
INFO - 2022-03-11 06:07:38 --> Helper loaded: common_helper
INFO - 2022-03-11 06:07:38 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:07:38 --> Controller Class Initialized
INFO - 2022-03-11 06:07:38 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:07:38 --> Encrypt Class Initialized
INFO - 2022-03-11 06:07:38 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:07:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:07:38 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:07:38 --> Model "Users_model" initialized
INFO - 2022-03-11 06:07:38 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:07:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:07:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 06:07:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:07:38 --> Final output sent to browser
DEBUG - 2022-03-11 06:07:38 --> Total execution time: 0.1210
ERROR - 2022-03-11 06:07:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:07:39 --> Config Class Initialized
INFO - 2022-03-11 06:07:39 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:07:39 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:07:39 --> Utf8 Class Initialized
INFO - 2022-03-11 06:07:39 --> URI Class Initialized
INFO - 2022-03-11 06:07:39 --> Router Class Initialized
INFO - 2022-03-11 06:07:39 --> Output Class Initialized
INFO - 2022-03-11 06:07:39 --> Security Class Initialized
DEBUG - 2022-03-11 06:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:07:39 --> Input Class Initialized
INFO - 2022-03-11 06:07:39 --> Language Class Initialized
ERROR - 2022-03-11 06:07:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 06:07:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:07:53 --> Config Class Initialized
INFO - 2022-03-11 06:07:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:07:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:07:53 --> Utf8 Class Initialized
INFO - 2022-03-11 06:07:53 --> URI Class Initialized
INFO - 2022-03-11 06:07:53 --> Router Class Initialized
INFO - 2022-03-11 06:07:53 --> Output Class Initialized
INFO - 2022-03-11 06:07:53 --> Security Class Initialized
DEBUG - 2022-03-11 06:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:07:53 --> Input Class Initialized
INFO - 2022-03-11 06:07:53 --> Language Class Initialized
INFO - 2022-03-11 06:07:53 --> Loader Class Initialized
INFO - 2022-03-11 06:07:53 --> Helper loaded: url_helper
INFO - 2022-03-11 06:07:53 --> Helper loaded: form_helper
INFO - 2022-03-11 06:07:53 --> Helper loaded: common_helper
INFO - 2022-03-11 06:07:53 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:07:53 --> Controller Class Initialized
INFO - 2022-03-11 06:07:53 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:07:53 --> Encrypt Class Initialized
INFO - 2022-03-11 06:07:53 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:07:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:07:53 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:07:53 --> Model "Users_model" initialized
INFO - 2022-03-11 06:07:53 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 06:07:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:07:54 --> Config Class Initialized
INFO - 2022-03-11 06:07:54 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:07:54 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:07:54 --> Utf8 Class Initialized
INFO - 2022-03-11 06:07:54 --> URI Class Initialized
INFO - 2022-03-11 06:07:54 --> Router Class Initialized
INFO - 2022-03-11 06:07:54 --> Output Class Initialized
INFO - 2022-03-11 06:07:54 --> Security Class Initialized
DEBUG - 2022-03-11 06:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:07:54 --> Input Class Initialized
INFO - 2022-03-11 06:07:54 --> Language Class Initialized
INFO - 2022-03-11 06:07:54 --> Loader Class Initialized
INFO - 2022-03-11 06:07:54 --> Helper loaded: url_helper
INFO - 2022-03-11 06:07:54 --> Helper loaded: form_helper
INFO - 2022-03-11 06:07:54 --> Helper loaded: common_helper
INFO - 2022-03-11 06:07:54 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:07:54 --> Controller Class Initialized
INFO - 2022-03-11 06:07:54 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:07:54 --> Encrypt Class Initialized
INFO - 2022-03-11 06:07:54 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:07:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:07:54 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:07:54 --> Model "Users_model" initialized
INFO - 2022-03-11 06:07:54 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:07:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:07:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 06:07:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:07:54 --> Final output sent to browser
DEBUG - 2022-03-11 06:07:54 --> Total execution time: 0.0688
ERROR - 2022-03-11 06:07:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:07:55 --> Config Class Initialized
INFO - 2022-03-11 06:07:55 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:07:55 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:07:55 --> Utf8 Class Initialized
INFO - 2022-03-11 06:07:55 --> URI Class Initialized
INFO - 2022-03-11 06:07:55 --> Router Class Initialized
INFO - 2022-03-11 06:07:55 --> Output Class Initialized
INFO - 2022-03-11 06:07:55 --> Security Class Initialized
DEBUG - 2022-03-11 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:07:55 --> Input Class Initialized
INFO - 2022-03-11 06:07:55 --> Language Class Initialized
ERROR - 2022-03-11 06:07:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 06:10:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:10:44 --> Config Class Initialized
INFO - 2022-03-11 06:10:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:10:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:10:44 --> Utf8 Class Initialized
INFO - 2022-03-11 06:10:44 --> URI Class Initialized
DEBUG - 2022-03-11 06:10:44 --> No URI present. Default controller set.
INFO - 2022-03-11 06:10:44 --> Router Class Initialized
INFO - 2022-03-11 06:10:44 --> Output Class Initialized
INFO - 2022-03-11 06:10:44 --> Security Class Initialized
DEBUG - 2022-03-11 06:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:10:44 --> Input Class Initialized
INFO - 2022-03-11 06:10:44 --> Language Class Initialized
INFO - 2022-03-11 06:10:44 --> Loader Class Initialized
INFO - 2022-03-11 06:10:44 --> Helper loaded: url_helper
INFO - 2022-03-11 06:10:44 --> Helper loaded: form_helper
INFO - 2022-03-11 06:10:44 --> Helper loaded: common_helper
INFO - 2022-03-11 06:10:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:10:44 --> Controller Class Initialized
INFO - 2022-03-11 06:10:44 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:10:44 --> Encrypt Class Initialized
DEBUG - 2022-03-11 06:10:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 06:10:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 06:10:44 --> Email Class Initialized
INFO - 2022-03-11 06:10:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 06:10:44 --> Calendar Class Initialized
INFO - 2022-03-11 06:10:44 --> Model "Login_model" initialized
ERROR - 2022-03-11 06:10:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:10:44 --> Config Class Initialized
INFO - 2022-03-11 06:10:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:10:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:10:44 --> Utf8 Class Initialized
INFO - 2022-03-11 06:10:44 --> URI Class Initialized
DEBUG - 2022-03-11 06:10:44 --> No URI present. Default controller set.
INFO - 2022-03-11 06:10:44 --> Router Class Initialized
INFO - 2022-03-11 06:10:44 --> Output Class Initialized
INFO - 2022-03-11 06:10:44 --> Security Class Initialized
DEBUG - 2022-03-11 06:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:10:44 --> Input Class Initialized
INFO - 2022-03-11 06:10:44 --> Language Class Initialized
INFO - 2022-03-11 06:10:44 --> Loader Class Initialized
INFO - 2022-03-11 06:10:44 --> Helper loaded: url_helper
INFO - 2022-03-11 06:10:44 --> Helper loaded: form_helper
INFO - 2022-03-11 06:10:44 --> Helper loaded: common_helper
INFO - 2022-03-11 06:10:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:10:44 --> Controller Class Initialized
INFO - 2022-03-11 06:10:44 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:10:44 --> Encrypt Class Initialized
DEBUG - 2022-03-11 06:10:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 06:10:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 06:10:44 --> Email Class Initialized
INFO - 2022-03-11 06:10:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 06:10:44 --> Calendar Class Initialized
INFO - 2022-03-11 06:10:44 --> Model "Login_model" initialized
ERROR - 2022-03-11 06:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:10:45 --> Config Class Initialized
INFO - 2022-03-11 06:10:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:10:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:10:45 --> Utf8 Class Initialized
INFO - 2022-03-11 06:10:45 --> URI Class Initialized
INFO - 2022-03-11 06:10:45 --> Router Class Initialized
INFO - 2022-03-11 06:10:45 --> Output Class Initialized
INFO - 2022-03-11 06:10:45 --> Security Class Initialized
DEBUG - 2022-03-11 06:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:10:45 --> Input Class Initialized
INFO - 2022-03-11 06:10:45 --> Language Class Initialized
INFO - 2022-03-11 06:10:45 --> Loader Class Initialized
INFO - 2022-03-11 06:10:45 --> Helper loaded: url_helper
INFO - 2022-03-11 06:10:45 --> Helper loaded: form_helper
INFO - 2022-03-11 06:10:45 --> Helper loaded: common_helper
INFO - 2022-03-11 06:10:45 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:10:45 --> Controller Class Initialized
INFO - 2022-03-11 06:10:45 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:10:45 --> Encrypt Class Initialized
INFO - 2022-03-11 06:10:45 --> Model "Diseases_model" initialized
INFO - 2022-03-11 06:10:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:10:45 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-11 06:10:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:10:45 --> Final output sent to browser
DEBUG - 2022-03-11 06:10:45 --> Total execution time: 0.0280
ERROR - 2022-03-11 06:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:10:45 --> Config Class Initialized
INFO - 2022-03-11 06:10:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:10:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:10:45 --> Utf8 Class Initialized
INFO - 2022-03-11 06:10:45 --> URI Class Initialized
INFO - 2022-03-11 06:10:45 --> Router Class Initialized
INFO - 2022-03-11 06:10:45 --> Output Class Initialized
INFO - 2022-03-11 06:10:45 --> Security Class Initialized
DEBUG - 2022-03-11 06:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:10:45 --> Input Class Initialized
INFO - 2022-03-11 06:10:45 --> Language Class Initialized
INFO - 2022-03-11 06:10:45 --> Loader Class Initialized
INFO - 2022-03-11 06:10:45 --> Helper loaded: url_helper
INFO - 2022-03-11 06:10:45 --> Helper loaded: form_helper
INFO - 2022-03-11 06:10:45 --> Helper loaded: common_helper
INFO - 2022-03-11 06:10:45 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:10:45 --> Controller Class Initialized
INFO - 2022-03-11 06:10:45 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:10:45 --> Encrypt Class Initialized
INFO - 2022-03-11 06:10:45 --> Model "Diseases_model" initialized
INFO - 2022-03-11 06:10:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:10:45 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-11 06:10:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:10:45 --> Final output sent to browser
DEBUG - 2022-03-11 06:10:45 --> Total execution time: 0.0312
ERROR - 2022-03-11 06:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:10:52 --> Config Class Initialized
INFO - 2022-03-11 06:10:52 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:10:52 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:10:52 --> Utf8 Class Initialized
INFO - 2022-03-11 06:10:52 --> URI Class Initialized
INFO - 2022-03-11 06:10:52 --> Router Class Initialized
INFO - 2022-03-11 06:10:52 --> Output Class Initialized
INFO - 2022-03-11 06:10:52 --> Security Class Initialized
DEBUG - 2022-03-11 06:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:10:52 --> Input Class Initialized
INFO - 2022-03-11 06:10:52 --> Language Class Initialized
INFO - 2022-03-11 06:10:52 --> Loader Class Initialized
INFO - 2022-03-11 06:10:52 --> Helper loaded: url_helper
INFO - 2022-03-11 06:10:52 --> Helper loaded: form_helper
INFO - 2022-03-11 06:10:52 --> Helper loaded: common_helper
INFO - 2022-03-11 06:10:52 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:10:52 --> Controller Class Initialized
INFO - 2022-03-11 06:10:52 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:10:52 --> Encrypt Class Initialized
INFO - 2022-03-11 06:10:52 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:10:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:10:52 --> Model "Referredby_model" initialized
INFO - 2022-03-11 06:10:52 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:10:52 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:10:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:10:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 06:10:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:10:52 --> Final output sent to browser
DEBUG - 2022-03-11 06:10:52 --> Total execution time: 0.0663
ERROR - 2022-03-11 06:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:11:06 --> Config Class Initialized
INFO - 2022-03-11 06:11:06 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:11:06 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:11:06 --> Utf8 Class Initialized
INFO - 2022-03-11 06:11:06 --> URI Class Initialized
INFO - 2022-03-11 06:11:06 --> Router Class Initialized
INFO - 2022-03-11 06:11:06 --> Output Class Initialized
INFO - 2022-03-11 06:11:06 --> Security Class Initialized
DEBUG - 2022-03-11 06:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:11:06 --> Input Class Initialized
INFO - 2022-03-11 06:11:06 --> Language Class Initialized
INFO - 2022-03-11 06:11:06 --> Loader Class Initialized
INFO - 2022-03-11 06:11:06 --> Helper loaded: url_helper
INFO - 2022-03-11 06:11:06 --> Helper loaded: form_helper
INFO - 2022-03-11 06:11:06 --> Helper loaded: common_helper
INFO - 2022-03-11 06:11:06 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:11:06 --> Controller Class Initialized
INFO - 2022-03-11 06:11:06 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:11:06 --> Encrypt Class Initialized
INFO - 2022-03-11 06:11:06 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:11:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:11:06 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:11:06 --> Model "Users_model" initialized
INFO - 2022-03-11 06:11:06 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:11:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:11:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 06:11:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:11:06 --> Final output sent to browser
DEBUG - 2022-03-11 06:11:06 --> Total execution time: 0.1021
ERROR - 2022-03-11 06:11:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:11:18 --> Config Class Initialized
INFO - 2022-03-11 06:11:18 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:11:18 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:11:18 --> Utf8 Class Initialized
INFO - 2022-03-11 06:11:18 --> URI Class Initialized
INFO - 2022-03-11 06:11:18 --> Router Class Initialized
INFO - 2022-03-11 06:11:18 --> Output Class Initialized
INFO - 2022-03-11 06:11:18 --> Security Class Initialized
DEBUG - 2022-03-11 06:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:11:18 --> Input Class Initialized
INFO - 2022-03-11 06:11:18 --> Language Class Initialized
INFO - 2022-03-11 06:11:18 --> Loader Class Initialized
INFO - 2022-03-11 06:11:18 --> Helper loaded: url_helper
INFO - 2022-03-11 06:11:18 --> Helper loaded: form_helper
INFO - 2022-03-11 06:11:18 --> Helper loaded: common_helper
INFO - 2022-03-11 06:11:18 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:11:18 --> Controller Class Initialized
INFO - 2022-03-11 06:11:18 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:11:18 --> Encrypt Class Initialized
INFO - 2022-03-11 06:11:18 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:11:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:11:18 --> Model "Referredby_model" initialized
INFO - 2022-03-11 06:11:18 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:11:18 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:11:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:11:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 06:11:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:11:19 --> Final output sent to browser
DEBUG - 2022-03-11 06:11:19 --> Total execution time: 0.0420
ERROR - 2022-03-11 06:11:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:11:51 --> Config Class Initialized
INFO - 2022-03-11 06:11:51 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:11:51 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:11:51 --> Utf8 Class Initialized
INFO - 2022-03-11 06:11:51 --> URI Class Initialized
INFO - 2022-03-11 06:11:51 --> Router Class Initialized
INFO - 2022-03-11 06:11:51 --> Output Class Initialized
INFO - 2022-03-11 06:11:51 --> Security Class Initialized
DEBUG - 2022-03-11 06:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:11:51 --> Input Class Initialized
INFO - 2022-03-11 06:11:51 --> Language Class Initialized
INFO - 2022-03-11 06:11:51 --> Loader Class Initialized
INFO - 2022-03-11 06:11:51 --> Helper loaded: url_helper
INFO - 2022-03-11 06:11:51 --> Helper loaded: form_helper
INFO - 2022-03-11 06:11:51 --> Helper loaded: common_helper
INFO - 2022-03-11 06:11:51 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:11:51 --> Controller Class Initialized
INFO - 2022-03-11 06:11:51 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:11:51 --> Encrypt Class Initialized
INFO - 2022-03-11 06:11:51 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:11:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:11:51 --> Model "Referredby_model" initialized
INFO - 2022-03-11 06:11:51 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:11:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 06:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:11:52 --> Config Class Initialized
INFO - 2022-03-11 06:11:52 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:11:52 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:11:52 --> Utf8 Class Initialized
INFO - 2022-03-11 06:11:52 --> URI Class Initialized
INFO - 2022-03-11 06:11:52 --> Router Class Initialized
INFO - 2022-03-11 06:11:52 --> Output Class Initialized
INFO - 2022-03-11 06:11:52 --> Security Class Initialized
DEBUG - 2022-03-11 06:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:11:52 --> Input Class Initialized
INFO - 2022-03-11 06:11:52 --> Language Class Initialized
INFO - 2022-03-11 06:11:52 --> Loader Class Initialized
INFO - 2022-03-11 06:11:52 --> Helper loaded: url_helper
INFO - 2022-03-11 06:11:52 --> Helper loaded: form_helper
INFO - 2022-03-11 06:11:52 --> Helper loaded: common_helper
INFO - 2022-03-11 06:11:52 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:11:52 --> Controller Class Initialized
INFO - 2022-03-11 06:11:52 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:11:52 --> Encrypt Class Initialized
INFO - 2022-03-11 06:11:52 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:11:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:11:52 --> Model "Referredby_model" initialized
INFO - 2022-03-11 06:11:52 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:11:52 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:11:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:11:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 06:11:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:11:52 --> Final output sent to browser
DEBUG - 2022-03-11 06:11:52 --> Total execution time: 0.0479
ERROR - 2022-03-11 06:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:11:53 --> Config Class Initialized
INFO - 2022-03-11 06:11:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:11:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:11:53 --> Utf8 Class Initialized
INFO - 2022-03-11 06:11:53 --> URI Class Initialized
INFO - 2022-03-11 06:11:53 --> Router Class Initialized
INFO - 2022-03-11 06:11:53 --> Output Class Initialized
INFO - 2022-03-11 06:11:53 --> Security Class Initialized
DEBUG - 2022-03-11 06:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:11:53 --> Input Class Initialized
INFO - 2022-03-11 06:11:53 --> Language Class Initialized
INFO - 2022-03-11 06:11:53 --> Loader Class Initialized
INFO - 2022-03-11 06:11:53 --> Helper loaded: url_helper
INFO - 2022-03-11 06:11:53 --> Helper loaded: form_helper
INFO - 2022-03-11 06:11:53 --> Helper loaded: common_helper
INFO - 2022-03-11 06:11:53 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:11:53 --> Controller Class Initialized
INFO - 2022-03-11 06:11:53 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:11:53 --> Encrypt Class Initialized
INFO - 2022-03-11 06:11:53 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:11:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:11:53 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:11:53 --> Model "Users_model" initialized
INFO - 2022-03-11 06:11:53 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:11:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:11:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 06:11:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:11:53 --> Final output sent to browser
DEBUG - 2022-03-11 06:11:53 --> Total execution time: 0.0867
ERROR - 2022-03-11 06:13:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:13:17 --> Config Class Initialized
INFO - 2022-03-11 06:13:17 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:13:17 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:13:17 --> Utf8 Class Initialized
INFO - 2022-03-11 06:13:17 --> URI Class Initialized
INFO - 2022-03-11 06:13:17 --> Router Class Initialized
INFO - 2022-03-11 06:13:17 --> Output Class Initialized
INFO - 2022-03-11 06:13:17 --> Security Class Initialized
DEBUG - 2022-03-11 06:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:13:17 --> Input Class Initialized
INFO - 2022-03-11 06:13:17 --> Language Class Initialized
INFO - 2022-03-11 06:13:17 --> Loader Class Initialized
INFO - 2022-03-11 06:13:17 --> Helper loaded: url_helper
INFO - 2022-03-11 06:13:17 --> Helper loaded: form_helper
INFO - 2022-03-11 06:13:17 --> Helper loaded: common_helper
INFO - 2022-03-11 06:13:17 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:13:17 --> Controller Class Initialized
INFO - 2022-03-11 06:13:17 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:13:17 --> Encrypt Class Initialized
INFO - 2022-03-11 06:13:17 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:13:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:13:17 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:13:17 --> Model "Users_model" initialized
INFO - 2022-03-11 06:13:17 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:13:17 --> Upload Class Initialized
INFO - 2022-03-11 06:13:17 --> Final output sent to browser
DEBUG - 2022-03-11 06:13:17 --> Total execution time: 0.2792
ERROR - 2022-03-11 06:13:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:13:24 --> Config Class Initialized
INFO - 2022-03-11 06:13:24 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:13:24 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:13:24 --> Utf8 Class Initialized
INFO - 2022-03-11 06:13:24 --> URI Class Initialized
INFO - 2022-03-11 06:13:24 --> Router Class Initialized
INFO - 2022-03-11 06:13:24 --> Output Class Initialized
INFO - 2022-03-11 06:13:24 --> Security Class Initialized
DEBUG - 2022-03-11 06:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:13:24 --> Input Class Initialized
INFO - 2022-03-11 06:13:24 --> Language Class Initialized
INFO - 2022-03-11 06:13:24 --> Loader Class Initialized
INFO - 2022-03-11 06:13:24 --> Helper loaded: url_helper
INFO - 2022-03-11 06:13:24 --> Helper loaded: form_helper
INFO - 2022-03-11 06:13:24 --> Helper loaded: common_helper
INFO - 2022-03-11 06:13:24 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:13:24 --> Controller Class Initialized
INFO - 2022-03-11 06:13:24 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:13:24 --> Encrypt Class Initialized
INFO - 2022-03-11 06:13:24 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:13:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:13:24 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:13:24 --> Model "Users_model" initialized
INFO - 2022-03-11 06:13:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 06:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:13:25 --> Config Class Initialized
INFO - 2022-03-11 06:13:25 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:13:25 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:13:25 --> Utf8 Class Initialized
INFO - 2022-03-11 06:13:25 --> URI Class Initialized
INFO - 2022-03-11 06:13:25 --> Router Class Initialized
INFO - 2022-03-11 06:13:25 --> Output Class Initialized
INFO - 2022-03-11 06:13:25 --> Security Class Initialized
DEBUG - 2022-03-11 06:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:13:25 --> Input Class Initialized
INFO - 2022-03-11 06:13:25 --> Language Class Initialized
INFO - 2022-03-11 06:13:25 --> Loader Class Initialized
INFO - 2022-03-11 06:13:25 --> Helper loaded: url_helper
INFO - 2022-03-11 06:13:25 --> Helper loaded: form_helper
INFO - 2022-03-11 06:13:25 --> Helper loaded: common_helper
INFO - 2022-03-11 06:13:25 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:13:25 --> Controller Class Initialized
INFO - 2022-03-11 06:13:25 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:13:25 --> Encrypt Class Initialized
INFO - 2022-03-11 06:13:25 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:13:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:13:25 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:13:25 --> Model "Users_model" initialized
INFO - 2022-03-11 06:13:25 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:13:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:13:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 06:13:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:13:25 --> Final output sent to browser
DEBUG - 2022-03-11 06:13:25 --> Total execution time: 0.1334
ERROR - 2022-03-11 06:13:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:13:47 --> Config Class Initialized
INFO - 2022-03-11 06:13:47 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:13:47 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:13:47 --> Utf8 Class Initialized
INFO - 2022-03-11 06:13:47 --> URI Class Initialized
INFO - 2022-03-11 06:13:47 --> Router Class Initialized
INFO - 2022-03-11 06:13:47 --> Output Class Initialized
INFO - 2022-03-11 06:13:47 --> Security Class Initialized
DEBUG - 2022-03-11 06:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:13:47 --> Input Class Initialized
INFO - 2022-03-11 06:13:47 --> Language Class Initialized
INFO - 2022-03-11 06:13:47 --> Loader Class Initialized
INFO - 2022-03-11 06:13:47 --> Helper loaded: url_helper
INFO - 2022-03-11 06:13:47 --> Helper loaded: form_helper
INFO - 2022-03-11 06:13:47 --> Helper loaded: common_helper
INFO - 2022-03-11 06:13:47 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:13:47 --> Controller Class Initialized
INFO - 2022-03-11 06:13:47 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:13:47 --> Encrypt Class Initialized
INFO - 2022-03-11 06:13:47 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:13:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:13:47 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:13:47 --> Model "Users_model" initialized
INFO - 2022-03-11 06:13:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 06:13:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:13:47 --> Config Class Initialized
INFO - 2022-03-11 06:13:47 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:13:47 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:13:47 --> Utf8 Class Initialized
INFO - 2022-03-11 06:13:47 --> URI Class Initialized
INFO - 2022-03-11 06:13:47 --> Router Class Initialized
INFO - 2022-03-11 06:13:47 --> Output Class Initialized
INFO - 2022-03-11 06:13:47 --> Security Class Initialized
DEBUG - 2022-03-11 06:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:13:47 --> Input Class Initialized
INFO - 2022-03-11 06:13:47 --> Language Class Initialized
INFO - 2022-03-11 06:13:47 --> Loader Class Initialized
INFO - 2022-03-11 06:13:47 --> Helper loaded: url_helper
INFO - 2022-03-11 06:13:47 --> Helper loaded: form_helper
INFO - 2022-03-11 06:13:47 --> Helper loaded: common_helper
INFO - 2022-03-11 06:13:47 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:13:47 --> Controller Class Initialized
INFO - 2022-03-11 06:13:47 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:13:47 --> Encrypt Class Initialized
INFO - 2022-03-11 06:13:47 --> Model "Patient_model" initialized
INFO - 2022-03-11 06:13:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 06:13:47 --> Model "Prefix_master" initialized
INFO - 2022-03-11 06:13:47 --> Model "Users_model" initialized
INFO - 2022-03-11 06:13:47 --> Model "Hospital_model" initialized
INFO - 2022-03-11 06:13:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 06:13:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 06:13:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 06:13:47 --> Final output sent to browser
DEBUG - 2022-03-11 06:13:47 --> Total execution time: 0.0928
ERROR - 2022-03-11 06:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:25:09 --> Config Class Initialized
INFO - 2022-03-11 06:25:09 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:25:09 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:25:09 --> Utf8 Class Initialized
INFO - 2022-03-11 06:25:09 --> URI Class Initialized
INFO - 2022-03-11 06:25:09 --> Router Class Initialized
INFO - 2022-03-11 06:25:09 --> Output Class Initialized
INFO - 2022-03-11 06:25:09 --> Security Class Initialized
DEBUG - 2022-03-11 06:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:25:09 --> Input Class Initialized
INFO - 2022-03-11 06:25:09 --> Language Class Initialized
INFO - 2022-03-11 06:25:09 --> Loader Class Initialized
INFO - 2022-03-11 06:25:09 --> Helper loaded: url_helper
INFO - 2022-03-11 06:25:09 --> Helper loaded: form_helper
INFO - 2022-03-11 06:25:09 --> Helper loaded: common_helper
INFO - 2022-03-11 06:25:09 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:25:09 --> Controller Class Initialized
INFO - 2022-03-11 06:25:09 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:25:09 --> Encrypt Class Initialized
DEBUG - 2022-03-11 06:25:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 06:25:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 06:25:09 --> Email Class Initialized
INFO - 2022-03-11 06:25:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 06:25:09 --> Calendar Class Initialized
INFO - 2022-03-11 06:25:09 --> Model "Login_model" initialized
ERROR - 2022-03-11 06:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 06:25:10 --> Config Class Initialized
INFO - 2022-03-11 06:25:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 06:25:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 06:25:10 --> Utf8 Class Initialized
INFO - 2022-03-11 06:25:10 --> URI Class Initialized
INFO - 2022-03-11 06:25:10 --> Router Class Initialized
INFO - 2022-03-11 06:25:10 --> Output Class Initialized
INFO - 2022-03-11 06:25:10 --> Security Class Initialized
DEBUG - 2022-03-11 06:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 06:25:10 --> Input Class Initialized
INFO - 2022-03-11 06:25:10 --> Language Class Initialized
INFO - 2022-03-11 06:25:10 --> Loader Class Initialized
INFO - 2022-03-11 06:25:10 --> Helper loaded: url_helper
INFO - 2022-03-11 06:25:10 --> Helper loaded: form_helper
INFO - 2022-03-11 06:25:10 --> Helper loaded: common_helper
INFO - 2022-03-11 06:25:10 --> Database Driver Class Initialized
DEBUG - 2022-03-11 06:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 06:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 06:25:10 --> Controller Class Initialized
INFO - 2022-03-11 06:25:10 --> Form Validation Class Initialized
DEBUG - 2022-03-11 06:25:10 --> Encrypt Class Initialized
DEBUG - 2022-03-11 06:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 06:25:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 06:25:10 --> Email Class Initialized
INFO - 2022-03-11 06:25:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 06:25:10 --> Calendar Class Initialized
INFO - 2022-03-11 06:25:10 --> Model "Login_model" initialized
INFO - 2022-03-11 06:25:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 06:25:10 --> Final output sent to browser
DEBUG - 2022-03-11 06:25:10 --> Total execution time: 0.0347
ERROR - 2022-03-11 10:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 10:01:16 --> Config Class Initialized
INFO - 2022-03-11 10:01:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 10:01:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 10:01:16 --> Utf8 Class Initialized
INFO - 2022-03-11 10:01:16 --> URI Class Initialized
INFO - 2022-03-11 10:01:16 --> Router Class Initialized
INFO - 2022-03-11 10:01:16 --> Output Class Initialized
INFO - 2022-03-11 10:01:16 --> Security Class Initialized
DEBUG - 2022-03-11 10:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 10:01:16 --> Input Class Initialized
INFO - 2022-03-11 10:01:16 --> Language Class Initialized
ERROR - 2022-03-11 10:01:16 --> 404 Page Not Found: Ckfinder/core
ERROR - 2022-03-11 10:28:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 10:28:04 --> Config Class Initialized
INFO - 2022-03-11 10:28:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 10:28:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 10:28:04 --> Utf8 Class Initialized
INFO - 2022-03-11 10:28:04 --> URI Class Initialized
DEBUG - 2022-03-11 10:28:04 --> No URI present. Default controller set.
INFO - 2022-03-11 10:28:04 --> Router Class Initialized
INFO - 2022-03-11 10:28:04 --> Output Class Initialized
INFO - 2022-03-11 10:28:04 --> Security Class Initialized
DEBUG - 2022-03-11 10:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 10:28:04 --> Input Class Initialized
INFO - 2022-03-11 10:28:04 --> Language Class Initialized
INFO - 2022-03-11 10:28:04 --> Loader Class Initialized
INFO - 2022-03-11 10:28:04 --> Helper loaded: url_helper
INFO - 2022-03-11 10:28:04 --> Helper loaded: form_helper
INFO - 2022-03-11 10:28:04 --> Helper loaded: common_helper
INFO - 2022-03-11 10:28:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 10:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 10:28:04 --> Controller Class Initialized
INFO - 2022-03-11 10:28:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 10:28:04 --> Encrypt Class Initialized
DEBUG - 2022-03-11 10:28:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:28:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 10:28:04 --> Email Class Initialized
INFO - 2022-03-11 10:28:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 10:28:04 --> Calendar Class Initialized
INFO - 2022-03-11 10:28:04 --> Model "Login_model" initialized
INFO - 2022-03-11 10:28:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 10:28:04 --> Final output sent to browser
DEBUG - 2022-03-11 10:28:04 --> Total execution time: 0.0339
ERROR - 2022-03-11 10:28:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 10:28:04 --> Config Class Initialized
INFO - 2022-03-11 10:28:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 10:28:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 10:28:04 --> Utf8 Class Initialized
INFO - 2022-03-11 10:28:04 --> URI Class Initialized
DEBUG - 2022-03-11 10:28:04 --> No URI present. Default controller set.
INFO - 2022-03-11 10:28:04 --> Router Class Initialized
INFO - 2022-03-11 10:28:04 --> Output Class Initialized
INFO - 2022-03-11 10:28:04 --> Security Class Initialized
DEBUG - 2022-03-11 10:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 10:28:04 --> Input Class Initialized
INFO - 2022-03-11 10:28:04 --> Language Class Initialized
INFO - 2022-03-11 10:28:04 --> Loader Class Initialized
INFO - 2022-03-11 10:28:04 --> Helper loaded: url_helper
INFO - 2022-03-11 10:28:04 --> Helper loaded: form_helper
INFO - 2022-03-11 10:28:04 --> Helper loaded: common_helper
INFO - 2022-03-11 10:28:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 10:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 10:28:04 --> Controller Class Initialized
INFO - 2022-03-11 10:28:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 10:28:04 --> Encrypt Class Initialized
DEBUG - 2022-03-11 10:28:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:28:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 10:28:04 --> Email Class Initialized
INFO - 2022-03-11 10:28:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 10:28:04 --> Calendar Class Initialized
INFO - 2022-03-11 10:28:04 --> Model "Login_model" initialized
INFO - 2022-03-11 10:28:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 10:28:04 --> Final output sent to browser
DEBUG - 2022-03-11 10:28:04 --> Total execution time: 0.0225
ERROR - 2022-03-11 13:30:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 13:30:08 --> Config Class Initialized
INFO - 2022-03-11 13:30:08 --> Hooks Class Initialized
DEBUG - 2022-03-11 13:30:08 --> UTF-8 Support Enabled
INFO - 2022-03-11 13:30:08 --> Utf8 Class Initialized
INFO - 2022-03-11 13:30:08 --> URI Class Initialized
DEBUG - 2022-03-11 13:30:08 --> No URI present. Default controller set.
INFO - 2022-03-11 13:30:08 --> Router Class Initialized
INFO - 2022-03-11 13:30:08 --> Output Class Initialized
INFO - 2022-03-11 13:30:08 --> Security Class Initialized
DEBUG - 2022-03-11 13:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 13:30:08 --> Input Class Initialized
INFO - 2022-03-11 13:30:08 --> Language Class Initialized
INFO - 2022-03-11 13:30:08 --> Loader Class Initialized
INFO - 2022-03-11 13:30:08 --> Helper loaded: url_helper
INFO - 2022-03-11 13:30:08 --> Helper loaded: form_helper
INFO - 2022-03-11 13:30:08 --> Helper loaded: common_helper
INFO - 2022-03-11 13:30:08 --> Database Driver Class Initialized
DEBUG - 2022-03-11 13:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 13:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 13:30:08 --> Controller Class Initialized
INFO - 2022-03-11 13:30:08 --> Form Validation Class Initialized
DEBUG - 2022-03-11 13:30:08 --> Encrypt Class Initialized
DEBUG - 2022-03-11 13:30:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:30:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 13:30:08 --> Email Class Initialized
INFO - 2022-03-11 13:30:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 13:30:08 --> Calendar Class Initialized
INFO - 2022-03-11 13:30:08 --> Model "Login_model" initialized
INFO - 2022-03-11 13:30:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 13:30:08 --> Final output sent to browser
DEBUG - 2022-03-11 13:30:08 --> Total execution time: 0.0214
ERROR - 2022-03-11 14:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 14:18:57 --> Config Class Initialized
INFO - 2022-03-11 14:18:57 --> Hooks Class Initialized
DEBUG - 2022-03-11 14:18:57 --> UTF-8 Support Enabled
INFO - 2022-03-11 14:18:57 --> Utf8 Class Initialized
INFO - 2022-03-11 14:18:57 --> URI Class Initialized
DEBUG - 2022-03-11 14:18:57 --> No URI present. Default controller set.
INFO - 2022-03-11 14:18:57 --> Router Class Initialized
INFO - 2022-03-11 14:18:57 --> Output Class Initialized
INFO - 2022-03-11 14:18:57 --> Security Class Initialized
DEBUG - 2022-03-11 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 14:18:57 --> Input Class Initialized
INFO - 2022-03-11 14:18:57 --> Language Class Initialized
INFO - 2022-03-11 14:18:57 --> Loader Class Initialized
INFO - 2022-03-11 14:18:57 --> Helper loaded: url_helper
INFO - 2022-03-11 14:18:57 --> Helper loaded: form_helper
INFO - 2022-03-11 14:18:57 --> Helper loaded: common_helper
INFO - 2022-03-11 14:18:57 --> Database Driver Class Initialized
DEBUG - 2022-03-11 14:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 14:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 14:18:57 --> Controller Class Initialized
INFO - 2022-03-11 14:18:57 --> Form Validation Class Initialized
DEBUG - 2022-03-11 14:18:57 --> Encrypt Class Initialized
DEBUG - 2022-03-11 14:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 14:18:57 --> Email Class Initialized
INFO - 2022-03-11 14:18:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 14:18:57 --> Calendar Class Initialized
INFO - 2022-03-11 14:18:57 --> Model "Login_model" initialized
INFO - 2022-03-11 14:18:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 14:18:57 --> Final output sent to browser
DEBUG - 2022-03-11 14:18:57 --> Total execution time: 0.0858
ERROR - 2022-03-11 14:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 14:18:57 --> Config Class Initialized
INFO - 2022-03-11 14:18:57 --> Hooks Class Initialized
DEBUG - 2022-03-11 14:18:57 --> UTF-8 Support Enabled
INFO - 2022-03-11 14:18:57 --> Utf8 Class Initialized
INFO - 2022-03-11 14:18:57 --> URI Class Initialized
INFO - 2022-03-11 14:18:57 --> Router Class Initialized
INFO - 2022-03-11 14:18:57 --> Output Class Initialized
INFO - 2022-03-11 14:18:57 --> Security Class Initialized
DEBUG - 2022-03-11 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 14:18:57 --> Input Class Initialized
INFO - 2022-03-11 14:18:57 --> Language Class Initialized
ERROR - 2022-03-11 14:18:57 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-11 14:19:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 14:19:24 --> Config Class Initialized
INFO - 2022-03-11 14:19:24 --> Hooks Class Initialized
DEBUG - 2022-03-11 14:19:24 --> UTF-8 Support Enabled
INFO - 2022-03-11 14:19:24 --> Utf8 Class Initialized
INFO - 2022-03-11 14:19:24 --> URI Class Initialized
INFO - 2022-03-11 14:19:24 --> Router Class Initialized
INFO - 2022-03-11 14:19:24 --> Output Class Initialized
INFO - 2022-03-11 14:19:24 --> Security Class Initialized
DEBUG - 2022-03-11 14:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 14:19:24 --> Input Class Initialized
INFO - 2022-03-11 14:19:24 --> Language Class Initialized
INFO - 2022-03-11 14:19:24 --> Loader Class Initialized
INFO - 2022-03-11 14:19:24 --> Helper loaded: url_helper
INFO - 2022-03-11 14:19:24 --> Helper loaded: form_helper
INFO - 2022-03-11 14:19:24 --> Helper loaded: common_helper
INFO - 2022-03-11 14:19:24 --> Database Driver Class Initialized
DEBUG - 2022-03-11 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 14:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 14:19:24 --> Controller Class Initialized
INFO - 2022-03-11 14:19:24 --> Form Validation Class Initialized
DEBUG - 2022-03-11 14:19:24 --> Encrypt Class Initialized
DEBUG - 2022-03-11 14:19:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:19:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 14:19:24 --> Email Class Initialized
INFO - 2022-03-11 14:19:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 14:19:24 --> Calendar Class Initialized
INFO - 2022-03-11 14:19:24 --> Model "Login_model" initialized
INFO - 2022-03-11 14:19:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 14:19:24 --> Final output sent to browser
DEBUG - 2022-03-11 14:19:24 --> Total execution time: 0.0333
ERROR - 2022-03-11 14:19:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 14:19:25 --> Config Class Initialized
INFO - 2022-03-11 14:19:25 --> Hooks Class Initialized
DEBUG - 2022-03-11 14:19:25 --> UTF-8 Support Enabled
INFO - 2022-03-11 14:19:25 --> Utf8 Class Initialized
INFO - 2022-03-11 14:19:25 --> URI Class Initialized
INFO - 2022-03-11 14:19:25 --> Router Class Initialized
INFO - 2022-03-11 14:19:25 --> Output Class Initialized
INFO - 2022-03-11 14:19:25 --> Security Class Initialized
DEBUG - 2022-03-11 14:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 14:19:25 --> Input Class Initialized
INFO - 2022-03-11 14:19:25 --> Language Class Initialized
INFO - 2022-03-11 14:19:25 --> Loader Class Initialized
INFO - 2022-03-11 14:19:25 --> Helper loaded: url_helper
INFO - 2022-03-11 14:19:25 --> Helper loaded: form_helper
INFO - 2022-03-11 14:19:25 --> Helper loaded: common_helper
INFO - 2022-03-11 14:19:25 --> Database Driver Class Initialized
DEBUG - 2022-03-11 14:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 14:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 14:19:25 --> Controller Class Initialized
INFO - 2022-03-11 14:19:25 --> Form Validation Class Initialized
DEBUG - 2022-03-11 14:19:25 --> Encrypt Class Initialized
DEBUG - 2022-03-11 14:19:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:19:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 14:19:25 --> Email Class Initialized
INFO - 2022-03-11 14:19:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 14:19:25 --> Calendar Class Initialized
INFO - 2022-03-11 14:19:25 --> Model "Login_model" initialized
ERROR - 2022-03-11 14:19:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 14:19:25 --> Config Class Initialized
INFO - 2022-03-11 14:19:25 --> Hooks Class Initialized
DEBUG - 2022-03-11 14:19:25 --> UTF-8 Support Enabled
INFO - 2022-03-11 14:19:25 --> Utf8 Class Initialized
INFO - 2022-03-11 14:19:25 --> URI Class Initialized
INFO - 2022-03-11 14:19:25 --> Router Class Initialized
INFO - 2022-03-11 14:19:25 --> Output Class Initialized
INFO - 2022-03-11 14:19:25 --> Security Class Initialized
DEBUG - 2022-03-11 14:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 14:19:25 --> Input Class Initialized
INFO - 2022-03-11 14:19:25 --> Language Class Initialized
INFO - 2022-03-11 14:19:25 --> Loader Class Initialized
INFO - 2022-03-11 14:19:25 --> Helper loaded: url_helper
INFO - 2022-03-11 14:19:25 --> Helper loaded: form_helper
INFO - 2022-03-11 14:19:25 --> Helper loaded: common_helper
INFO - 2022-03-11 14:19:25 --> Database Driver Class Initialized
DEBUG - 2022-03-11 14:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 14:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 14:19:25 --> Controller Class Initialized
INFO - 2022-03-11 14:19:25 --> Form Validation Class Initialized
DEBUG - 2022-03-11 14:19:25 --> Encrypt Class Initialized
DEBUG - 2022-03-11 14:19:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:19:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 14:19:25 --> Email Class Initialized
INFO - 2022-03-11 14:19:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 14:19:25 --> Calendar Class Initialized
INFO - 2022-03-11 14:19:25 --> Model "Login_model" initialized
ERROR - 2022-03-11 14:19:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 14:19:26 --> Config Class Initialized
INFO - 2022-03-11 14:19:26 --> Hooks Class Initialized
DEBUG - 2022-03-11 14:19:26 --> UTF-8 Support Enabled
INFO - 2022-03-11 14:19:26 --> Utf8 Class Initialized
INFO - 2022-03-11 14:19:26 --> URI Class Initialized
DEBUG - 2022-03-11 14:19:26 --> No URI present. Default controller set.
INFO - 2022-03-11 14:19:26 --> Router Class Initialized
INFO - 2022-03-11 14:19:26 --> Output Class Initialized
INFO - 2022-03-11 14:19:26 --> Security Class Initialized
DEBUG - 2022-03-11 14:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 14:19:26 --> Input Class Initialized
INFO - 2022-03-11 14:19:26 --> Language Class Initialized
INFO - 2022-03-11 14:19:26 --> Loader Class Initialized
INFO - 2022-03-11 14:19:26 --> Helper loaded: url_helper
INFO - 2022-03-11 14:19:26 --> Helper loaded: form_helper
INFO - 2022-03-11 14:19:26 --> Helper loaded: common_helper
INFO - 2022-03-11 14:19:26 --> Database Driver Class Initialized
DEBUG - 2022-03-11 14:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 14:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 14:19:26 --> Controller Class Initialized
INFO - 2022-03-11 14:19:26 --> Form Validation Class Initialized
DEBUG - 2022-03-11 14:19:26 --> Encrypt Class Initialized
DEBUG - 2022-03-11 14:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:19:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 14:19:26 --> Email Class Initialized
INFO - 2022-03-11 14:19:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 14:19:26 --> Calendar Class Initialized
INFO - 2022-03-11 14:19:26 --> Model "Login_model" initialized
INFO - 2022-03-11 14:19:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 14:19:26 --> Final output sent to browser
DEBUG - 2022-03-11 14:19:26 --> Total execution time: 0.0295
ERROR - 2022-03-11 14:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 14:55:23 --> Config Class Initialized
INFO - 2022-03-11 14:55:23 --> Hooks Class Initialized
DEBUG - 2022-03-11 14:55:23 --> UTF-8 Support Enabled
INFO - 2022-03-11 14:55:23 --> Utf8 Class Initialized
INFO - 2022-03-11 14:55:23 --> URI Class Initialized
DEBUG - 2022-03-11 14:55:23 --> No URI present. Default controller set.
INFO - 2022-03-11 14:55:23 --> Router Class Initialized
INFO - 2022-03-11 14:55:23 --> Output Class Initialized
INFO - 2022-03-11 14:55:23 --> Security Class Initialized
DEBUG - 2022-03-11 14:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 14:55:23 --> Input Class Initialized
INFO - 2022-03-11 14:55:23 --> Language Class Initialized
INFO - 2022-03-11 14:55:23 --> Loader Class Initialized
INFO - 2022-03-11 14:55:23 --> Helper loaded: url_helper
INFO - 2022-03-11 14:55:23 --> Helper loaded: form_helper
INFO - 2022-03-11 14:55:23 --> Helper loaded: common_helper
INFO - 2022-03-11 14:55:23 --> Database Driver Class Initialized
DEBUG - 2022-03-11 14:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 14:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 14:55:23 --> Controller Class Initialized
INFO - 2022-03-11 14:55:23 --> Form Validation Class Initialized
DEBUG - 2022-03-11 14:55:23 --> Encrypt Class Initialized
DEBUG - 2022-03-11 14:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:55:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 14:55:23 --> Email Class Initialized
INFO - 2022-03-11 14:55:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 14:55:23 --> Calendar Class Initialized
INFO - 2022-03-11 14:55:23 --> Model "Login_model" initialized
INFO - 2022-03-11 14:55:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 14:55:23 --> Final output sent to browser
DEBUG - 2022-03-11 14:55:23 --> Total execution time: 0.0363
ERROR - 2022-03-11 15:14:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 15:14:06 --> Config Class Initialized
INFO - 2022-03-11 15:14:06 --> Hooks Class Initialized
DEBUG - 2022-03-11 15:14:06 --> UTF-8 Support Enabled
INFO - 2022-03-11 15:14:06 --> Utf8 Class Initialized
INFO - 2022-03-11 15:14:06 --> URI Class Initialized
DEBUG - 2022-03-11 15:14:06 --> No URI present. Default controller set.
INFO - 2022-03-11 15:14:06 --> Router Class Initialized
INFO - 2022-03-11 15:14:06 --> Output Class Initialized
INFO - 2022-03-11 15:14:06 --> Security Class Initialized
DEBUG - 2022-03-11 15:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 15:14:06 --> Input Class Initialized
INFO - 2022-03-11 15:14:06 --> Language Class Initialized
INFO - 2022-03-11 15:14:06 --> Loader Class Initialized
INFO - 2022-03-11 15:14:06 --> Helper loaded: url_helper
INFO - 2022-03-11 15:14:06 --> Helper loaded: form_helper
INFO - 2022-03-11 15:14:06 --> Helper loaded: common_helper
INFO - 2022-03-11 15:14:06 --> Database Driver Class Initialized
DEBUG - 2022-03-11 15:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 15:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 15:14:06 --> Controller Class Initialized
INFO - 2022-03-11 15:14:06 --> Form Validation Class Initialized
DEBUG - 2022-03-11 15:14:06 --> Encrypt Class Initialized
DEBUG - 2022-03-11 15:14:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 15:14:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 15:14:06 --> Email Class Initialized
INFO - 2022-03-11 15:14:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 15:14:06 --> Calendar Class Initialized
INFO - 2022-03-11 15:14:06 --> Model "Login_model" initialized
INFO - 2022-03-11 15:14:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 15:14:06 --> Final output sent to browser
DEBUG - 2022-03-11 15:14:06 --> Total execution time: 0.0391
ERROR - 2022-03-11 15:27:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 15:27:39 --> Config Class Initialized
INFO - 2022-03-11 15:27:39 --> Hooks Class Initialized
DEBUG - 2022-03-11 15:27:39 --> UTF-8 Support Enabled
INFO - 2022-03-11 15:27:39 --> Utf8 Class Initialized
INFO - 2022-03-11 15:27:39 --> URI Class Initialized
DEBUG - 2022-03-11 15:27:39 --> No URI present. Default controller set.
INFO - 2022-03-11 15:27:39 --> Router Class Initialized
INFO - 2022-03-11 15:27:39 --> Output Class Initialized
INFO - 2022-03-11 15:27:39 --> Security Class Initialized
DEBUG - 2022-03-11 15:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 15:27:39 --> Input Class Initialized
INFO - 2022-03-11 15:27:39 --> Language Class Initialized
INFO - 2022-03-11 15:27:39 --> Loader Class Initialized
INFO - 2022-03-11 15:27:39 --> Helper loaded: url_helper
INFO - 2022-03-11 15:27:39 --> Helper loaded: form_helper
INFO - 2022-03-11 15:27:39 --> Helper loaded: common_helper
INFO - 2022-03-11 15:27:39 --> Database Driver Class Initialized
DEBUG - 2022-03-11 15:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 15:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 15:27:40 --> Controller Class Initialized
INFO - 2022-03-11 15:27:40 --> Form Validation Class Initialized
DEBUG - 2022-03-11 15:27:40 --> Encrypt Class Initialized
DEBUG - 2022-03-11 15:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 15:27:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 15:27:40 --> Email Class Initialized
INFO - 2022-03-11 15:27:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 15:27:40 --> Calendar Class Initialized
INFO - 2022-03-11 15:27:40 --> Model "Login_model" initialized
INFO - 2022-03-11 15:27:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 15:27:40 --> Final output sent to browser
DEBUG - 2022-03-11 15:27:40 --> Total execution time: 0.0337
ERROR - 2022-03-11 19:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 19:40:55 --> Config Class Initialized
INFO - 2022-03-11 19:40:55 --> Hooks Class Initialized
DEBUG - 2022-03-11 19:40:55 --> UTF-8 Support Enabled
INFO - 2022-03-11 19:40:55 --> Utf8 Class Initialized
INFO - 2022-03-11 19:40:55 --> URI Class Initialized
DEBUG - 2022-03-11 19:40:55 --> No URI present. Default controller set.
INFO - 2022-03-11 19:40:55 --> Router Class Initialized
INFO - 2022-03-11 19:40:55 --> Output Class Initialized
INFO - 2022-03-11 19:40:55 --> Security Class Initialized
DEBUG - 2022-03-11 19:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 19:40:55 --> Input Class Initialized
INFO - 2022-03-11 19:40:55 --> Language Class Initialized
INFO - 2022-03-11 19:40:55 --> Loader Class Initialized
INFO - 2022-03-11 19:40:55 --> Helper loaded: url_helper
INFO - 2022-03-11 19:40:55 --> Helper loaded: form_helper
INFO - 2022-03-11 19:40:55 --> Helper loaded: common_helper
INFO - 2022-03-11 19:40:55 --> Database Driver Class Initialized
DEBUG - 2022-03-11 19:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 19:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 19:40:55 --> Controller Class Initialized
INFO - 2022-03-11 19:40:55 --> Form Validation Class Initialized
DEBUG - 2022-03-11 19:40:55 --> Encrypt Class Initialized
DEBUG - 2022-03-11 19:40:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 19:40:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 19:40:55 --> Email Class Initialized
INFO - 2022-03-11 19:40:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 19:40:55 --> Calendar Class Initialized
INFO - 2022-03-11 19:40:55 --> Model "Login_model" initialized
INFO - 2022-03-11 19:40:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 19:40:55 --> Final output sent to browser
DEBUG - 2022-03-11 19:40:55 --> Total execution time: 0.0229
ERROR - 2022-03-11 19:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 19:41:04 --> Config Class Initialized
INFO - 2022-03-11 19:41:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 19:41:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 19:41:04 --> Utf8 Class Initialized
INFO - 2022-03-11 19:41:04 --> URI Class Initialized
DEBUG - 2022-03-11 19:41:04 --> No URI present. Default controller set.
INFO - 2022-03-11 19:41:04 --> Router Class Initialized
INFO - 2022-03-11 19:41:04 --> Output Class Initialized
INFO - 2022-03-11 19:41:04 --> Security Class Initialized
DEBUG - 2022-03-11 19:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 19:41:04 --> Input Class Initialized
INFO - 2022-03-11 19:41:04 --> Language Class Initialized
INFO - 2022-03-11 19:41:04 --> Loader Class Initialized
INFO - 2022-03-11 19:41:04 --> Helper loaded: url_helper
INFO - 2022-03-11 19:41:04 --> Helper loaded: form_helper
INFO - 2022-03-11 19:41:04 --> Helper loaded: common_helper
INFO - 2022-03-11 19:41:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 19:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 19:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 19:41:04 --> Controller Class Initialized
INFO - 2022-03-11 19:41:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 19:41:04 --> Encrypt Class Initialized
DEBUG - 2022-03-11 19:41:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 19:41:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 19:41:04 --> Email Class Initialized
INFO - 2022-03-11 19:41:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 19:41:04 --> Calendar Class Initialized
INFO - 2022-03-11 19:41:04 --> Model "Login_model" initialized
INFO - 2022-03-11 19:41:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 19:41:04 --> Final output sent to browser
DEBUG - 2022-03-11 19:41:04 --> Total execution time: 0.0229
ERROR - 2022-03-11 19:53:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 19:53:32 --> Config Class Initialized
INFO - 2022-03-11 19:53:32 --> Hooks Class Initialized
DEBUG - 2022-03-11 19:53:32 --> UTF-8 Support Enabled
INFO - 2022-03-11 19:53:32 --> Utf8 Class Initialized
INFO - 2022-03-11 19:53:32 --> URI Class Initialized
DEBUG - 2022-03-11 19:53:32 --> No URI present. Default controller set.
INFO - 2022-03-11 19:53:32 --> Router Class Initialized
INFO - 2022-03-11 19:53:32 --> Output Class Initialized
INFO - 2022-03-11 19:53:32 --> Security Class Initialized
DEBUG - 2022-03-11 19:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 19:53:32 --> Input Class Initialized
INFO - 2022-03-11 19:53:32 --> Language Class Initialized
INFO - 2022-03-11 19:53:32 --> Loader Class Initialized
INFO - 2022-03-11 19:53:32 --> Helper loaded: url_helper
INFO - 2022-03-11 19:53:32 --> Helper loaded: form_helper
INFO - 2022-03-11 19:53:32 --> Helper loaded: common_helper
INFO - 2022-03-11 19:53:32 --> Database Driver Class Initialized
DEBUG - 2022-03-11 19:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 19:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 19:53:32 --> Controller Class Initialized
INFO - 2022-03-11 19:53:32 --> Form Validation Class Initialized
DEBUG - 2022-03-11 19:53:32 --> Encrypt Class Initialized
DEBUG - 2022-03-11 19:53:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 19:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 19:53:32 --> Email Class Initialized
INFO - 2022-03-11 19:53:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 19:53:32 --> Calendar Class Initialized
INFO - 2022-03-11 19:53:32 --> Model "Login_model" initialized
INFO - 2022-03-11 19:53:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 19:53:32 --> Final output sent to browser
DEBUG - 2022-03-11 19:53:32 --> Total execution time: 0.0345
ERROR - 2022-03-11 22:08:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:08:51 --> Config Class Initialized
INFO - 2022-03-11 22:08:51 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:08:51 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:08:51 --> Utf8 Class Initialized
INFO - 2022-03-11 22:08:51 --> URI Class Initialized
DEBUG - 2022-03-11 22:08:51 --> No URI present. Default controller set.
INFO - 2022-03-11 22:08:51 --> Router Class Initialized
INFO - 2022-03-11 22:08:51 --> Output Class Initialized
INFO - 2022-03-11 22:08:51 --> Security Class Initialized
DEBUG - 2022-03-11 22:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:08:51 --> Input Class Initialized
INFO - 2022-03-11 22:08:51 --> Language Class Initialized
INFO - 2022-03-11 22:08:51 --> Loader Class Initialized
INFO - 2022-03-11 22:08:51 --> Helper loaded: url_helper
INFO - 2022-03-11 22:08:51 --> Helper loaded: form_helper
INFO - 2022-03-11 22:08:51 --> Helper loaded: common_helper
INFO - 2022-03-11 22:08:52 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:08:52 --> Controller Class Initialized
INFO - 2022-03-11 22:08:52 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:08:52 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:08:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:08:52 --> Email Class Initialized
INFO - 2022-03-11 22:08:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:08:52 --> Calendar Class Initialized
INFO - 2022-03-11 22:08:52 --> Model "Login_model" initialized
INFO - 2022-03-11 22:08:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 22:08:52 --> Final output sent to browser
DEBUG - 2022-03-11 22:08:52 --> Total execution time: 0.0475
ERROR - 2022-03-11 22:08:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:08:53 --> Config Class Initialized
INFO - 2022-03-11 22:08:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:08:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:08:53 --> Utf8 Class Initialized
INFO - 2022-03-11 22:08:53 --> URI Class Initialized
DEBUG - 2022-03-11 22:08:53 --> No URI present. Default controller set.
INFO - 2022-03-11 22:08:53 --> Router Class Initialized
INFO - 2022-03-11 22:08:53 --> Output Class Initialized
INFO - 2022-03-11 22:08:53 --> Security Class Initialized
DEBUG - 2022-03-11 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:08:53 --> Input Class Initialized
INFO - 2022-03-11 22:08:53 --> Language Class Initialized
INFO - 2022-03-11 22:08:53 --> Loader Class Initialized
INFO - 2022-03-11 22:08:53 --> Helper loaded: url_helper
INFO - 2022-03-11 22:08:53 --> Helper loaded: form_helper
INFO - 2022-03-11 22:08:53 --> Helper loaded: common_helper
INFO - 2022-03-11 22:08:53 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:08:53 --> Controller Class Initialized
INFO - 2022-03-11 22:08:53 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:08:53 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:08:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:08:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:08:53 --> Email Class Initialized
INFO - 2022-03-11 22:08:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:08:53 --> Calendar Class Initialized
INFO - 2022-03-11 22:08:53 --> Model "Login_model" initialized
INFO - 2022-03-11 22:08:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 22:08:53 --> Final output sent to browser
DEBUG - 2022-03-11 22:08:53 --> Total execution time: 0.0548
ERROR - 2022-03-11 22:09:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:09:10 --> Config Class Initialized
INFO - 2022-03-11 22:09:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:09:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:09:10 --> Utf8 Class Initialized
INFO - 2022-03-11 22:09:10 --> URI Class Initialized
INFO - 2022-03-11 22:09:10 --> Router Class Initialized
INFO - 2022-03-11 22:09:10 --> Output Class Initialized
INFO - 2022-03-11 22:09:10 --> Security Class Initialized
DEBUG - 2022-03-11 22:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:09:10 --> Input Class Initialized
INFO - 2022-03-11 22:09:10 --> Language Class Initialized
INFO - 2022-03-11 22:09:10 --> Loader Class Initialized
INFO - 2022-03-11 22:09:10 --> Helper loaded: url_helper
INFO - 2022-03-11 22:09:10 --> Helper loaded: form_helper
INFO - 2022-03-11 22:09:10 --> Helper loaded: common_helper
INFO - 2022-03-11 22:09:10 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:09:10 --> Controller Class Initialized
INFO - 2022-03-11 22:09:10 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:09:10 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:09:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:09:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:09:10 --> Email Class Initialized
INFO - 2022-03-11 22:09:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:09:10 --> Calendar Class Initialized
INFO - 2022-03-11 22:09:10 --> Model "Login_model" initialized
INFO - 2022-03-11 22:09:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-11 22:09:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:09:11 --> Config Class Initialized
INFO - 2022-03-11 22:09:11 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:09:11 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:09:11 --> Utf8 Class Initialized
INFO - 2022-03-11 22:09:11 --> URI Class Initialized
INFO - 2022-03-11 22:09:11 --> Router Class Initialized
INFO - 2022-03-11 22:09:11 --> Output Class Initialized
INFO - 2022-03-11 22:09:11 --> Security Class Initialized
DEBUG - 2022-03-11 22:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:09:11 --> Input Class Initialized
INFO - 2022-03-11 22:09:11 --> Language Class Initialized
INFO - 2022-03-11 22:09:11 --> Loader Class Initialized
INFO - 2022-03-11 22:09:11 --> Helper loaded: url_helper
INFO - 2022-03-11 22:09:11 --> Helper loaded: form_helper
INFO - 2022-03-11 22:09:11 --> Helper loaded: common_helper
INFO - 2022-03-11 22:09:11 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:09:11 --> Controller Class Initialized
INFO - 2022-03-11 22:09:11 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:09:11 --> Encrypt Class Initialized
INFO - 2022-03-11 22:09:11 --> Model "Login_model" initialized
INFO - 2022-03-11 22:09:11 --> Model "Dashboard_model" initialized
INFO - 2022-03-11 22:09:11 --> Model "Case_model" initialized
INFO - 2022-03-11 22:09:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:09:13 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-11 22:09:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:09:13 --> Final output sent to browser
DEBUG - 2022-03-11 22:09:13 --> Total execution time: 2.2336
ERROR - 2022-03-11 22:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:16:17 --> Config Class Initialized
INFO - 2022-03-11 22:16:17 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:16:17 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:16:17 --> Utf8 Class Initialized
INFO - 2022-03-11 22:16:17 --> URI Class Initialized
DEBUG - 2022-03-11 22:16:17 --> No URI present. Default controller set.
INFO - 2022-03-11 22:16:17 --> Router Class Initialized
INFO - 2022-03-11 22:16:17 --> Output Class Initialized
INFO - 2022-03-11 22:16:17 --> Security Class Initialized
DEBUG - 2022-03-11 22:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:16:17 --> Input Class Initialized
INFO - 2022-03-11 22:16:17 --> Language Class Initialized
INFO - 2022-03-11 22:16:17 --> Loader Class Initialized
INFO - 2022-03-11 22:16:17 --> Helper loaded: url_helper
INFO - 2022-03-11 22:16:17 --> Helper loaded: form_helper
INFO - 2022-03-11 22:16:17 --> Helper loaded: common_helper
INFO - 2022-03-11 22:16:17 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:16:17 --> Controller Class Initialized
INFO - 2022-03-11 22:16:17 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:16:17 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:16:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:16:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:16:17 --> Email Class Initialized
INFO - 2022-03-11 22:16:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:16:17 --> Calendar Class Initialized
INFO - 2022-03-11 22:16:17 --> Model "Login_model" initialized
INFO - 2022-03-11 22:16:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 22:16:17 --> Final output sent to browser
DEBUG - 2022-03-11 22:16:17 --> Total execution time: 0.1799
ERROR - 2022-03-11 22:16:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:16:55 --> Config Class Initialized
INFO - 2022-03-11 22:16:55 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:16:55 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:16:55 --> Utf8 Class Initialized
INFO - 2022-03-11 22:16:55 --> URI Class Initialized
INFO - 2022-03-11 22:16:55 --> Router Class Initialized
INFO - 2022-03-11 22:16:55 --> Output Class Initialized
INFO - 2022-03-11 22:16:55 --> Security Class Initialized
DEBUG - 2022-03-11 22:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:16:55 --> Input Class Initialized
INFO - 2022-03-11 22:16:55 --> Language Class Initialized
INFO - 2022-03-11 22:16:55 --> Loader Class Initialized
INFO - 2022-03-11 22:16:55 --> Helper loaded: url_helper
INFO - 2022-03-11 22:16:55 --> Helper loaded: form_helper
INFO - 2022-03-11 22:16:55 --> Helper loaded: common_helper
INFO - 2022-03-11 22:16:55 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:16:55 --> Controller Class Initialized
INFO - 2022-03-11 22:16:55 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:16:55 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:16:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:16:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:16:55 --> Email Class Initialized
INFO - 2022-03-11 22:16:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:16:55 --> Calendar Class Initialized
INFO - 2022-03-11 22:16:55 --> Model "Login_model" initialized
INFO - 2022-03-11 22:16:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-11 22:16:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:16:56 --> Config Class Initialized
INFO - 2022-03-11 22:16:56 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:16:56 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:16:56 --> Utf8 Class Initialized
INFO - 2022-03-11 22:16:56 --> URI Class Initialized
INFO - 2022-03-11 22:16:56 --> Router Class Initialized
INFO - 2022-03-11 22:16:56 --> Output Class Initialized
INFO - 2022-03-11 22:16:56 --> Security Class Initialized
DEBUG - 2022-03-11 22:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:16:56 --> Input Class Initialized
INFO - 2022-03-11 22:16:56 --> Language Class Initialized
INFO - 2022-03-11 22:16:56 --> Loader Class Initialized
INFO - 2022-03-11 22:16:56 --> Helper loaded: url_helper
INFO - 2022-03-11 22:16:56 --> Helper loaded: form_helper
INFO - 2022-03-11 22:16:56 --> Helper loaded: common_helper
INFO - 2022-03-11 22:16:56 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:16:56 --> Controller Class Initialized
INFO - 2022-03-11 22:16:56 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:16:56 --> Encrypt Class Initialized
INFO - 2022-03-11 22:16:56 --> Model "Login_model" initialized
INFO - 2022-03-11 22:16:56 --> Model "Dashboard_model" initialized
INFO - 2022-03-11 22:16:56 --> Model "Case_model" initialized
INFO - 2022-03-11 22:17:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:17:18 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-11 22:17:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:17:18 --> Final output sent to browser
DEBUG - 2022-03-11 22:17:18 --> Total execution time: 21.8149
ERROR - 2022-03-11 22:17:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:17:18 --> Config Class Initialized
INFO - 2022-03-11 22:17:18 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:17:18 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:17:18 --> Utf8 Class Initialized
INFO - 2022-03-11 22:17:18 --> URI Class Initialized
INFO - 2022-03-11 22:17:18 --> Router Class Initialized
INFO - 2022-03-11 22:17:18 --> Output Class Initialized
INFO - 2022-03-11 22:17:18 --> Security Class Initialized
DEBUG - 2022-03-11 22:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:17:18 --> Input Class Initialized
INFO - 2022-03-11 22:17:18 --> Language Class Initialized
ERROR - 2022-03-11 22:17:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 22:17:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:17:50 --> Config Class Initialized
INFO - 2022-03-11 22:17:50 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:17:50 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:17:50 --> Utf8 Class Initialized
INFO - 2022-03-11 22:17:50 --> URI Class Initialized
INFO - 2022-03-11 22:17:50 --> Router Class Initialized
INFO - 2022-03-11 22:17:50 --> Output Class Initialized
INFO - 2022-03-11 22:17:50 --> Security Class Initialized
DEBUG - 2022-03-11 22:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:17:50 --> Input Class Initialized
INFO - 2022-03-11 22:17:50 --> Language Class Initialized
INFO - 2022-03-11 22:17:50 --> Loader Class Initialized
INFO - 2022-03-11 22:17:50 --> Helper loaded: url_helper
INFO - 2022-03-11 22:17:50 --> Helper loaded: form_helper
INFO - 2022-03-11 22:17:50 --> Helper loaded: common_helper
INFO - 2022-03-11 22:17:50 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:17:50 --> Controller Class Initialized
INFO - 2022-03-11 22:17:50 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:17:50 --> Encrypt Class Initialized
INFO - 2022-03-11 22:17:50 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:17:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:17:50 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:17:50 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:17:50 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:17:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:17:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 22:17:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-11 22:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:17:57 --> Config Class Initialized
INFO - 2022-03-11 22:17:57 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:17:57 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:17:57 --> Utf8 Class Initialized
INFO - 2022-03-11 22:17:57 --> URI Class Initialized
INFO - 2022-03-11 22:17:57 --> Router Class Initialized
INFO - 2022-03-11 22:17:57 --> Output Class Initialized
INFO - 2022-03-11 22:17:57 --> Security Class Initialized
DEBUG - 2022-03-11 22:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:17:57 --> Input Class Initialized
INFO - 2022-03-11 22:17:57 --> Language Class Initialized
ERROR - 2022-03-11 22:17:57 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-11 22:17:58 --> Final output sent to browser
DEBUG - 2022-03-11 22:17:58 --> Total execution time: 6.5650
ERROR - 2022-03-11 22:20:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:20:22 --> Config Class Initialized
INFO - 2022-03-11 22:20:22 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:20:22 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:20:22 --> Utf8 Class Initialized
INFO - 2022-03-11 22:20:22 --> URI Class Initialized
INFO - 2022-03-11 22:20:22 --> Router Class Initialized
INFO - 2022-03-11 22:20:22 --> Output Class Initialized
INFO - 2022-03-11 22:20:22 --> Security Class Initialized
DEBUG - 2022-03-11 22:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:20:22 --> Input Class Initialized
INFO - 2022-03-11 22:20:22 --> Language Class Initialized
INFO - 2022-03-11 22:20:22 --> Loader Class Initialized
INFO - 2022-03-11 22:20:22 --> Helper loaded: url_helper
INFO - 2022-03-11 22:20:22 --> Helper loaded: form_helper
INFO - 2022-03-11 22:20:22 --> Helper loaded: common_helper
INFO - 2022-03-11 22:20:22 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:20:22 --> Controller Class Initialized
INFO - 2022-03-11 22:20:22 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:20:22 --> Encrypt Class Initialized
INFO - 2022-03-11 22:20:22 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:20:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:20:22 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:20:22 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:20:22 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:20:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:20:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 22:20:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:20:22 --> Final output sent to browser
DEBUG - 2022-03-11 22:20:22 --> Total execution time: 0.0865
ERROR - 2022-03-11 22:22:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:22:42 --> Config Class Initialized
INFO - 2022-03-11 22:22:42 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:22:42 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:22:42 --> Utf8 Class Initialized
INFO - 2022-03-11 22:22:42 --> URI Class Initialized
DEBUG - 2022-03-11 22:22:42 --> No URI present. Default controller set.
INFO - 2022-03-11 22:22:42 --> Router Class Initialized
INFO - 2022-03-11 22:22:42 --> Output Class Initialized
INFO - 2022-03-11 22:22:42 --> Security Class Initialized
DEBUG - 2022-03-11 22:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:22:42 --> Input Class Initialized
INFO - 2022-03-11 22:22:42 --> Language Class Initialized
INFO - 2022-03-11 22:22:42 --> Loader Class Initialized
INFO - 2022-03-11 22:22:42 --> Helper loaded: url_helper
INFO - 2022-03-11 22:22:42 --> Helper loaded: form_helper
INFO - 2022-03-11 22:22:42 --> Helper loaded: common_helper
INFO - 2022-03-11 22:22:42 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:22:42 --> Controller Class Initialized
INFO - 2022-03-11 22:22:42 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:22:42 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:22:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:22:42 --> Email Class Initialized
INFO - 2022-03-11 22:22:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:22:42 --> Calendar Class Initialized
INFO - 2022-03-11 22:22:42 --> Model "Login_model" initialized
INFO - 2022-03-11 22:22:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 22:22:42 --> Final output sent to browser
DEBUG - 2022-03-11 22:22:42 --> Total execution time: 0.0285
ERROR - 2022-03-11 22:22:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:22:43 --> Config Class Initialized
INFO - 2022-03-11 22:22:43 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:22:43 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:22:43 --> Utf8 Class Initialized
INFO - 2022-03-11 22:22:43 --> URI Class Initialized
DEBUG - 2022-03-11 22:22:43 --> No URI present. Default controller set.
INFO - 2022-03-11 22:22:43 --> Router Class Initialized
INFO - 2022-03-11 22:22:43 --> Output Class Initialized
INFO - 2022-03-11 22:22:43 --> Security Class Initialized
DEBUG - 2022-03-11 22:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:22:43 --> Input Class Initialized
INFO - 2022-03-11 22:22:43 --> Language Class Initialized
INFO - 2022-03-11 22:22:43 --> Loader Class Initialized
INFO - 2022-03-11 22:22:43 --> Helper loaded: url_helper
INFO - 2022-03-11 22:22:43 --> Helper loaded: form_helper
INFO - 2022-03-11 22:22:43 --> Helper loaded: common_helper
INFO - 2022-03-11 22:22:43 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:22:43 --> Controller Class Initialized
INFO - 2022-03-11 22:22:43 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:22:43 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:22:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:22:43 --> Email Class Initialized
INFO - 2022-03-11 22:22:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:22:43 --> Calendar Class Initialized
INFO - 2022-03-11 22:22:43 --> Model "Login_model" initialized
INFO - 2022-03-11 22:22:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 22:22:43 --> Final output sent to browser
DEBUG - 2022-03-11 22:22:43 --> Total execution time: 0.0243
ERROR - 2022-03-11 22:33:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:33:40 --> Config Class Initialized
INFO - 2022-03-11 22:33:40 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:33:40 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:33:40 --> Utf8 Class Initialized
INFO - 2022-03-11 22:33:40 --> URI Class Initialized
INFO - 2022-03-11 22:33:40 --> Router Class Initialized
INFO - 2022-03-11 22:33:40 --> Output Class Initialized
INFO - 2022-03-11 22:33:40 --> Security Class Initialized
DEBUG - 2022-03-11 22:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:33:40 --> Input Class Initialized
INFO - 2022-03-11 22:33:40 --> Language Class Initialized
INFO - 2022-03-11 22:33:40 --> Loader Class Initialized
INFO - 2022-03-11 22:33:40 --> Helper loaded: url_helper
INFO - 2022-03-11 22:33:40 --> Helper loaded: form_helper
INFO - 2022-03-11 22:33:40 --> Helper loaded: common_helper
INFO - 2022-03-11 22:33:40 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:33:40 --> Controller Class Initialized
INFO - 2022-03-11 22:33:40 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:33:40 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:33:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:33:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:33:40 --> Email Class Initialized
INFO - 2022-03-11 22:33:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:33:40 --> Calendar Class Initialized
INFO - 2022-03-11 22:33:40 --> Model "Login_model" initialized
INFO - 2022-03-11 22:33:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 22:33:40 --> Final output sent to browser
DEBUG - 2022-03-11 22:33:40 --> Total execution time: 0.0253
ERROR - 2022-03-11 22:33:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:33:52 --> Config Class Initialized
INFO - 2022-03-11 22:33:52 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:33:52 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:33:52 --> Utf8 Class Initialized
INFO - 2022-03-11 22:33:52 --> URI Class Initialized
INFO - 2022-03-11 22:33:52 --> Router Class Initialized
INFO - 2022-03-11 22:33:52 --> Output Class Initialized
INFO - 2022-03-11 22:33:52 --> Security Class Initialized
DEBUG - 2022-03-11 22:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:33:52 --> Input Class Initialized
INFO - 2022-03-11 22:33:52 --> Language Class Initialized
INFO - 2022-03-11 22:33:52 --> Loader Class Initialized
INFO - 2022-03-11 22:33:52 --> Helper loaded: url_helper
INFO - 2022-03-11 22:33:52 --> Helper loaded: form_helper
INFO - 2022-03-11 22:33:52 --> Helper loaded: common_helper
INFO - 2022-03-11 22:33:52 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:33:52 --> Controller Class Initialized
INFO - 2022-03-11 22:33:52 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:33:52 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:33:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:33:52 --> Email Class Initialized
INFO - 2022-03-11 22:33:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:33:52 --> Calendar Class Initialized
INFO - 2022-03-11 22:33:52 --> Model "Login_model" initialized
INFO - 2022-03-11 22:33:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-11 22:33:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:33:53 --> Config Class Initialized
INFO - 2022-03-11 22:33:53 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:33:53 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:33:53 --> Utf8 Class Initialized
INFO - 2022-03-11 22:33:53 --> URI Class Initialized
INFO - 2022-03-11 22:33:53 --> Router Class Initialized
INFO - 2022-03-11 22:33:53 --> Output Class Initialized
INFO - 2022-03-11 22:33:53 --> Security Class Initialized
DEBUG - 2022-03-11 22:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:33:53 --> Input Class Initialized
INFO - 2022-03-11 22:33:53 --> Language Class Initialized
INFO - 2022-03-11 22:33:53 --> Loader Class Initialized
INFO - 2022-03-11 22:33:53 --> Helper loaded: url_helper
INFO - 2022-03-11 22:33:53 --> Helper loaded: form_helper
INFO - 2022-03-11 22:33:53 --> Helper loaded: common_helper
INFO - 2022-03-11 22:33:53 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:33:53 --> Controller Class Initialized
INFO - 2022-03-11 22:33:53 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:33:53 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:33:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:33:53 --> Email Class Initialized
INFO - 2022-03-11 22:33:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:33:53 --> Calendar Class Initialized
INFO - 2022-03-11 22:33:53 --> Model "Login_model" initialized
INFO - 2022-03-11 22:33:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-11 22:33:53 --> Final output sent to browser
DEBUG - 2022-03-11 22:33:53 --> Total execution time: 0.0225
ERROR - 2022-03-11 22:34:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:34:05 --> Config Class Initialized
INFO - 2022-03-11 22:34:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:34:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:34:05 --> Utf8 Class Initialized
INFO - 2022-03-11 22:34:05 --> URI Class Initialized
INFO - 2022-03-11 22:34:05 --> Router Class Initialized
INFO - 2022-03-11 22:34:05 --> Output Class Initialized
INFO - 2022-03-11 22:34:05 --> Security Class Initialized
DEBUG - 2022-03-11 22:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:34:05 --> Input Class Initialized
INFO - 2022-03-11 22:34:05 --> Language Class Initialized
INFO - 2022-03-11 22:34:05 --> Loader Class Initialized
INFO - 2022-03-11 22:34:05 --> Helper loaded: url_helper
INFO - 2022-03-11 22:34:05 --> Helper loaded: form_helper
INFO - 2022-03-11 22:34:05 --> Helper loaded: common_helper
INFO - 2022-03-11 22:34:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:34:05 --> Controller Class Initialized
INFO - 2022-03-11 22:34:05 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:34:05 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:34:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:34:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:34:05 --> Email Class Initialized
INFO - 2022-03-11 22:34:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:34:05 --> Calendar Class Initialized
INFO - 2022-03-11 22:34:05 --> Model "Login_model" initialized
INFO - 2022-03-11 22:34:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-11 22:34:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:34:05 --> Config Class Initialized
INFO - 2022-03-11 22:34:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:34:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:34:05 --> Utf8 Class Initialized
INFO - 2022-03-11 22:34:05 --> URI Class Initialized
INFO - 2022-03-11 22:34:05 --> Router Class Initialized
INFO - 2022-03-11 22:34:05 --> Output Class Initialized
INFO - 2022-03-11 22:34:05 --> Security Class Initialized
DEBUG - 2022-03-11 22:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:34:05 --> Input Class Initialized
INFO - 2022-03-11 22:34:05 --> Language Class Initialized
INFO - 2022-03-11 22:34:05 --> Loader Class Initialized
INFO - 2022-03-11 22:34:05 --> Helper loaded: url_helper
INFO - 2022-03-11 22:34:05 --> Helper loaded: form_helper
INFO - 2022-03-11 22:34:05 --> Helper loaded: common_helper
INFO - 2022-03-11 22:34:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:34:05 --> Controller Class Initialized
INFO - 2022-03-11 22:34:05 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:34:05 --> Encrypt Class Initialized
INFO - 2022-03-11 22:34:05 --> Model "Login_model" initialized
INFO - 2022-03-11 22:34:05 --> Model "Dashboard_model" initialized
INFO - 2022-03-11 22:34:05 --> Model "Case_model" initialized
INFO - 2022-03-11 22:34:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:34:06 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-11 22:34:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:34:06 --> Final output sent to browser
DEBUG - 2022-03-11 22:34:06 --> Total execution time: 0.1366
ERROR - 2022-03-11 22:34:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:34:16 --> Config Class Initialized
INFO - 2022-03-11 22:34:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:34:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:34:16 --> Utf8 Class Initialized
INFO - 2022-03-11 22:34:16 --> URI Class Initialized
INFO - 2022-03-11 22:34:16 --> Router Class Initialized
INFO - 2022-03-11 22:34:16 --> Output Class Initialized
INFO - 2022-03-11 22:34:16 --> Security Class Initialized
DEBUG - 2022-03-11 22:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:34:16 --> Input Class Initialized
INFO - 2022-03-11 22:34:16 --> Language Class Initialized
INFO - 2022-03-11 22:34:16 --> Loader Class Initialized
INFO - 2022-03-11 22:34:16 --> Helper loaded: url_helper
INFO - 2022-03-11 22:34:16 --> Helper loaded: form_helper
INFO - 2022-03-11 22:34:16 --> Helper loaded: common_helper
INFO - 2022-03-11 22:34:16 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:34:16 --> Controller Class Initialized
INFO - 2022-03-11 22:34:16 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:34:16 --> Encrypt Class Initialized
INFO - 2022-03-11 22:34:16 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:34:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:34:16 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:34:16 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:34:16 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:34:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:34:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 22:34:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:34:16 --> Final output sent to browser
DEBUG - 2022-03-11 22:34:16 --> Total execution time: 0.0595
ERROR - 2022-03-11 22:37:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:37:31 --> Config Class Initialized
INFO - 2022-03-11 22:37:31 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:37:31 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:37:31 --> Utf8 Class Initialized
INFO - 2022-03-11 22:37:31 --> URI Class Initialized
INFO - 2022-03-11 22:37:31 --> Router Class Initialized
INFO - 2022-03-11 22:37:31 --> Output Class Initialized
INFO - 2022-03-11 22:37:31 --> Security Class Initialized
DEBUG - 2022-03-11 22:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:37:31 --> Input Class Initialized
INFO - 2022-03-11 22:37:31 --> Language Class Initialized
INFO - 2022-03-11 22:37:31 --> Loader Class Initialized
INFO - 2022-03-11 22:37:31 --> Helper loaded: url_helper
INFO - 2022-03-11 22:37:31 --> Helper loaded: form_helper
INFO - 2022-03-11 22:37:31 --> Helper loaded: common_helper
INFO - 2022-03-11 22:37:31 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:37:31 --> Controller Class Initialized
INFO - 2022-03-11 22:37:31 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:37:31 --> Encrypt Class Initialized
INFO - 2022-03-11 22:37:31 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:37:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:37:31 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:37:31 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:37:31 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:37:31 --> Final output sent to browser
DEBUG - 2022-03-11 22:37:31 --> Total execution time: 0.0285
ERROR - 2022-03-11 22:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:42:40 --> Config Class Initialized
INFO - 2022-03-11 22:42:40 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:42:40 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:42:40 --> Utf8 Class Initialized
INFO - 2022-03-11 22:42:40 --> URI Class Initialized
INFO - 2022-03-11 22:42:40 --> Router Class Initialized
INFO - 2022-03-11 22:42:40 --> Output Class Initialized
INFO - 2022-03-11 22:42:40 --> Security Class Initialized
DEBUG - 2022-03-11 22:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:42:40 --> Input Class Initialized
INFO - 2022-03-11 22:42:40 --> Language Class Initialized
INFO - 2022-03-11 22:42:40 --> Loader Class Initialized
INFO - 2022-03-11 22:42:40 --> Helper loaded: url_helper
INFO - 2022-03-11 22:42:40 --> Helper loaded: form_helper
INFO - 2022-03-11 22:42:40 --> Helper loaded: common_helper
INFO - 2022-03-11 22:42:40 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:42:40 --> Controller Class Initialized
INFO - 2022-03-11 22:42:40 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:42:40 --> Final output sent to browser
DEBUG - 2022-03-11 22:42:40 --> Total execution time: 0.0189
ERROR - 2022-03-11 22:42:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:42:43 --> Config Class Initialized
INFO - 2022-03-11 22:42:43 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:42:43 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:42:43 --> Utf8 Class Initialized
INFO - 2022-03-11 22:42:43 --> URI Class Initialized
INFO - 2022-03-11 22:42:43 --> Router Class Initialized
INFO - 2022-03-11 22:42:43 --> Output Class Initialized
INFO - 2022-03-11 22:42:43 --> Security Class Initialized
DEBUG - 2022-03-11 22:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:42:43 --> Input Class Initialized
INFO - 2022-03-11 22:42:43 --> Language Class Initialized
INFO - 2022-03-11 22:42:43 --> Loader Class Initialized
INFO - 2022-03-11 22:42:43 --> Helper loaded: url_helper
INFO - 2022-03-11 22:42:43 --> Helper loaded: form_helper
INFO - 2022-03-11 22:42:43 --> Helper loaded: common_helper
INFO - 2022-03-11 22:42:43 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:42:43 --> Controller Class Initialized
INFO - 2022-03-11 22:42:43 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:42:43 --> Final output sent to browser
DEBUG - 2022-03-11 22:42:43 --> Total execution time: 0.0233
ERROR - 2022-03-11 22:50:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:50:44 --> Config Class Initialized
INFO - 2022-03-11 22:50:44 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:50:44 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:50:44 --> Utf8 Class Initialized
INFO - 2022-03-11 22:50:44 --> URI Class Initialized
INFO - 2022-03-11 22:50:44 --> Router Class Initialized
INFO - 2022-03-11 22:50:44 --> Output Class Initialized
INFO - 2022-03-11 22:50:44 --> Security Class Initialized
DEBUG - 2022-03-11 22:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:50:44 --> Input Class Initialized
INFO - 2022-03-11 22:50:44 --> Language Class Initialized
INFO - 2022-03-11 22:50:44 --> Loader Class Initialized
INFO - 2022-03-11 22:50:44 --> Helper loaded: url_helper
INFO - 2022-03-11 22:50:44 --> Helper loaded: form_helper
INFO - 2022-03-11 22:50:44 --> Helper loaded: common_helper
INFO - 2022-03-11 22:50:44 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:50:44 --> Controller Class Initialized
INFO - 2022-03-11 22:50:44 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:50:45 --> Final output sent to browser
DEBUG - 2022-03-11 22:50:45 --> Total execution time: 0.0200
ERROR - 2022-03-11 22:53:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:53:01 --> Config Class Initialized
INFO - 2022-03-11 22:53:01 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:53:01 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:53:01 --> Utf8 Class Initialized
INFO - 2022-03-11 22:53:01 --> URI Class Initialized
INFO - 2022-03-11 22:53:01 --> Router Class Initialized
INFO - 2022-03-11 22:53:01 --> Output Class Initialized
INFO - 2022-03-11 22:53:01 --> Security Class Initialized
DEBUG - 2022-03-11 22:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:53:01 --> Input Class Initialized
INFO - 2022-03-11 22:53:01 --> Language Class Initialized
INFO - 2022-03-11 22:53:01 --> Loader Class Initialized
INFO - 2022-03-11 22:53:01 --> Helper loaded: url_helper
INFO - 2022-03-11 22:53:01 --> Helper loaded: form_helper
INFO - 2022-03-11 22:53:01 --> Helper loaded: common_helper
INFO - 2022-03-11 22:53:01 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:53:01 --> Controller Class Initialized
INFO - 2022-03-11 22:53:01 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:53:01 --> Encrypt Class Initialized
INFO - 2022-03-11 22:53:01 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:53:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:53:01 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:53:01 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:53:01 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:53:01 --> Final output sent to browser
DEBUG - 2022-03-11 22:53:01 --> Total execution time: 0.0276
ERROR - 2022-03-11 22:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:57:33 --> Config Class Initialized
INFO - 2022-03-11 22:57:33 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:57:33 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:57:33 --> Utf8 Class Initialized
INFO - 2022-03-11 22:57:33 --> URI Class Initialized
DEBUG - 2022-03-11 22:57:33 --> No URI present. Default controller set.
INFO - 2022-03-11 22:57:33 --> Router Class Initialized
INFO - 2022-03-11 22:57:33 --> Output Class Initialized
INFO - 2022-03-11 22:57:33 --> Security Class Initialized
DEBUG - 2022-03-11 22:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:57:33 --> Input Class Initialized
INFO - 2022-03-11 22:57:33 --> Language Class Initialized
INFO - 2022-03-11 22:57:33 --> Loader Class Initialized
INFO - 2022-03-11 22:57:33 --> Helper loaded: url_helper
INFO - 2022-03-11 22:57:33 --> Helper loaded: form_helper
INFO - 2022-03-11 22:57:33 --> Helper loaded: common_helper
INFO - 2022-03-11 22:57:33 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:57:33 --> Controller Class Initialized
INFO - 2022-03-11 22:57:33 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:57:33 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:57:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:57:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:57:33 --> Email Class Initialized
INFO - 2022-03-11 22:57:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:57:33 --> Calendar Class Initialized
INFO - 2022-03-11 22:57:33 --> Model "Login_model" initialized
ERROR - 2022-03-11 22:57:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:57:34 --> Config Class Initialized
INFO - 2022-03-11 22:57:34 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:57:34 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:57:34 --> Utf8 Class Initialized
INFO - 2022-03-11 22:57:34 --> URI Class Initialized
INFO - 2022-03-11 22:57:34 --> Router Class Initialized
INFO - 2022-03-11 22:57:34 --> Output Class Initialized
INFO - 2022-03-11 22:57:34 --> Security Class Initialized
DEBUG - 2022-03-11 22:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:57:34 --> Input Class Initialized
INFO - 2022-03-11 22:57:34 --> Language Class Initialized
INFO - 2022-03-11 22:57:34 --> Loader Class Initialized
INFO - 2022-03-11 22:57:34 --> Helper loaded: url_helper
INFO - 2022-03-11 22:57:34 --> Helper loaded: form_helper
INFO - 2022-03-11 22:57:34 --> Helper loaded: common_helper
INFO - 2022-03-11 22:57:34 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:57:34 --> Controller Class Initialized
INFO - 2022-03-11 22:57:34 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:57:34 --> Encrypt Class Initialized
INFO - 2022-03-11 22:57:34 --> Model "Diseases_model" initialized
INFO - 2022-03-11 22:57:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:57:34 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-11 22:57:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:57:34 --> Final output sent to browser
DEBUG - 2022-03-11 22:57:34 --> Total execution time: 0.3286
ERROR - 2022-03-11 22:57:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:57:35 --> Config Class Initialized
INFO - 2022-03-11 22:57:35 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:57:35 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:57:35 --> Utf8 Class Initialized
INFO - 2022-03-11 22:57:35 --> URI Class Initialized
DEBUG - 2022-03-11 22:57:35 --> No URI present. Default controller set.
INFO - 2022-03-11 22:57:35 --> Router Class Initialized
INFO - 2022-03-11 22:57:35 --> Output Class Initialized
INFO - 2022-03-11 22:57:35 --> Security Class Initialized
DEBUG - 2022-03-11 22:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:57:35 --> Input Class Initialized
INFO - 2022-03-11 22:57:35 --> Language Class Initialized
INFO - 2022-03-11 22:57:35 --> Loader Class Initialized
INFO - 2022-03-11 22:57:35 --> Helper loaded: url_helper
INFO - 2022-03-11 22:57:35 --> Helper loaded: form_helper
INFO - 2022-03-11 22:57:35 --> Helper loaded: common_helper
INFO - 2022-03-11 22:57:35 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:57:35 --> Controller Class Initialized
INFO - 2022-03-11 22:57:35 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:57:35 --> Encrypt Class Initialized
DEBUG - 2022-03-11 22:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 22:57:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-11 22:57:35 --> Email Class Initialized
INFO - 2022-03-11 22:57:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-11 22:57:35 --> Calendar Class Initialized
INFO - 2022-03-11 22:57:35 --> Model "Login_model" initialized
ERROR - 2022-03-11 22:57:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:57:35 --> Config Class Initialized
INFO - 2022-03-11 22:57:35 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:57:35 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:57:35 --> Utf8 Class Initialized
INFO - 2022-03-11 22:57:35 --> URI Class Initialized
INFO - 2022-03-11 22:57:35 --> Router Class Initialized
INFO - 2022-03-11 22:57:35 --> Output Class Initialized
INFO - 2022-03-11 22:57:35 --> Security Class Initialized
DEBUG - 2022-03-11 22:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:57:35 --> Input Class Initialized
INFO - 2022-03-11 22:57:35 --> Language Class Initialized
INFO - 2022-03-11 22:57:35 --> Loader Class Initialized
INFO - 2022-03-11 22:57:35 --> Helper loaded: url_helper
INFO - 2022-03-11 22:57:35 --> Helper loaded: form_helper
INFO - 2022-03-11 22:57:35 --> Helper loaded: common_helper
INFO - 2022-03-11 22:57:35 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:57:35 --> Controller Class Initialized
INFO - 2022-03-11 22:57:35 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:57:35 --> Encrypt Class Initialized
INFO - 2022-03-11 22:57:35 --> Model "Diseases_model" initialized
INFO - 2022-03-11 22:57:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:57:35 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-11 22:57:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:57:35 --> Final output sent to browser
DEBUG - 2022-03-11 22:57:35 --> Total execution time: 0.0235
ERROR - 2022-03-11 22:57:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:57:40 --> Config Class Initialized
INFO - 2022-03-11 22:57:40 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:57:40 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:57:40 --> Utf8 Class Initialized
INFO - 2022-03-11 22:57:40 --> URI Class Initialized
INFO - 2022-03-11 22:57:40 --> Router Class Initialized
INFO - 2022-03-11 22:57:40 --> Output Class Initialized
INFO - 2022-03-11 22:57:40 --> Security Class Initialized
DEBUG - 2022-03-11 22:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:57:40 --> Input Class Initialized
INFO - 2022-03-11 22:57:40 --> Language Class Initialized
INFO - 2022-03-11 22:57:40 --> Loader Class Initialized
INFO - 2022-03-11 22:57:40 --> Helper loaded: url_helper
INFO - 2022-03-11 22:57:40 --> Helper loaded: form_helper
INFO - 2022-03-11 22:57:40 --> Helper loaded: common_helper
INFO - 2022-03-11 22:57:40 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:57:40 --> Controller Class Initialized
INFO - 2022-03-11 22:57:40 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:57:40 --> Encrypt Class Initialized
INFO - 2022-03-11 22:57:40 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:57:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:57:40 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:57:40 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:57:40 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:57:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:57:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 22:57:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:57:40 --> Final output sent to browser
DEBUG - 2022-03-11 22:57:40 --> Total execution time: 0.0691
ERROR - 2022-03-11 22:57:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:57:59 --> Config Class Initialized
INFO - 2022-03-11 22:57:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:57:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:57:59 --> Utf8 Class Initialized
INFO - 2022-03-11 22:57:59 --> URI Class Initialized
INFO - 2022-03-11 22:57:59 --> Router Class Initialized
INFO - 2022-03-11 22:57:59 --> Output Class Initialized
INFO - 2022-03-11 22:57:59 --> Security Class Initialized
DEBUG - 2022-03-11 22:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:57:59 --> Input Class Initialized
INFO - 2022-03-11 22:57:59 --> Language Class Initialized
INFO - 2022-03-11 22:57:59 --> Loader Class Initialized
INFO - 2022-03-11 22:57:59 --> Helper loaded: url_helper
INFO - 2022-03-11 22:57:59 --> Helper loaded: form_helper
INFO - 2022-03-11 22:57:59 --> Helper loaded: common_helper
INFO - 2022-03-11 22:57:59 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:57:59 --> Controller Class Initialized
INFO - 2022-03-11 22:57:59 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:57:59 --> Encrypt Class Initialized
INFO - 2022-03-11 22:57:59 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:57:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:57:59 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:57:59 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:57:59 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:57:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:57:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 22:57:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:57:59 --> Final output sent to browser
DEBUG - 2022-03-11 22:57:59 --> Total execution time: 0.0556
ERROR - 2022-03-11 22:58:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:58:12 --> Config Class Initialized
INFO - 2022-03-11 22:58:12 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:58:12 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:58:12 --> Utf8 Class Initialized
INFO - 2022-03-11 22:58:12 --> URI Class Initialized
INFO - 2022-03-11 22:58:12 --> Router Class Initialized
INFO - 2022-03-11 22:58:12 --> Output Class Initialized
INFO - 2022-03-11 22:58:12 --> Security Class Initialized
DEBUG - 2022-03-11 22:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:58:12 --> Input Class Initialized
INFO - 2022-03-11 22:58:12 --> Language Class Initialized
INFO - 2022-03-11 22:58:12 --> Loader Class Initialized
INFO - 2022-03-11 22:58:12 --> Helper loaded: url_helper
INFO - 2022-03-11 22:58:12 --> Helper loaded: form_helper
INFO - 2022-03-11 22:58:12 --> Helper loaded: common_helper
INFO - 2022-03-11 22:58:12 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:58:12 --> Controller Class Initialized
INFO - 2022-03-11 22:58:12 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:58:12 --> Encrypt Class Initialized
INFO - 2022-03-11 22:58:12 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:58:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:58:12 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:58:12 --> Model "Users_model" initialized
INFO - 2022-03-11 22:58:12 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:58:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:58:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 22:58:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:58:12 --> Final output sent to browser
DEBUG - 2022-03-11 22:58:12 --> Total execution time: 0.1814
ERROR - 2022-03-11 22:58:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:58:33 --> Config Class Initialized
INFO - 2022-03-11 22:58:33 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:58:33 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:58:33 --> Utf8 Class Initialized
INFO - 2022-03-11 22:58:33 --> URI Class Initialized
INFO - 2022-03-11 22:58:33 --> Router Class Initialized
INFO - 2022-03-11 22:58:33 --> Output Class Initialized
INFO - 2022-03-11 22:58:33 --> Security Class Initialized
DEBUG - 2022-03-11 22:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:58:33 --> Input Class Initialized
INFO - 2022-03-11 22:58:33 --> Language Class Initialized
INFO - 2022-03-11 22:58:33 --> Loader Class Initialized
INFO - 2022-03-11 22:58:33 --> Helper loaded: url_helper
INFO - 2022-03-11 22:58:33 --> Helper loaded: form_helper
INFO - 2022-03-11 22:58:33 --> Helper loaded: common_helper
INFO - 2022-03-11 22:58:33 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:58:33 --> Controller Class Initialized
INFO - 2022-03-11 22:58:33 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:58:33 --> Encrypt Class Initialized
INFO - 2022-03-11 22:58:33 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:58:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:58:33 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:58:33 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:58:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 22:58:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:58:33 --> Config Class Initialized
INFO - 2022-03-11 22:58:33 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:58:33 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:58:33 --> Utf8 Class Initialized
INFO - 2022-03-11 22:58:33 --> URI Class Initialized
INFO - 2022-03-11 22:58:33 --> Router Class Initialized
INFO - 2022-03-11 22:58:33 --> Output Class Initialized
INFO - 2022-03-11 22:58:33 --> Security Class Initialized
DEBUG - 2022-03-11 22:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:58:33 --> Input Class Initialized
INFO - 2022-03-11 22:58:33 --> Language Class Initialized
INFO - 2022-03-11 22:58:33 --> Loader Class Initialized
INFO - 2022-03-11 22:58:33 --> Helper loaded: url_helper
INFO - 2022-03-11 22:58:33 --> Helper loaded: form_helper
INFO - 2022-03-11 22:58:33 --> Helper loaded: common_helper
INFO - 2022-03-11 22:58:33 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:58:33 --> Controller Class Initialized
INFO - 2022-03-11 22:58:33 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:58:33 --> Encrypt Class Initialized
INFO - 2022-03-11 22:58:33 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:58:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:58:33 --> Model "Referredby_model" initialized
INFO - 2022-03-11 22:58:33 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:58:33 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:58:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:58:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 22:58:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:58:33 --> Final output sent to browser
DEBUG - 2022-03-11 22:58:33 --> Total execution time: 0.2326
ERROR - 2022-03-11 22:58:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 22:58:34 --> Config Class Initialized
INFO - 2022-03-11 22:58:34 --> Hooks Class Initialized
DEBUG - 2022-03-11 22:58:34 --> UTF-8 Support Enabled
INFO - 2022-03-11 22:58:34 --> Utf8 Class Initialized
INFO - 2022-03-11 22:58:34 --> URI Class Initialized
INFO - 2022-03-11 22:58:34 --> Router Class Initialized
INFO - 2022-03-11 22:58:34 --> Output Class Initialized
INFO - 2022-03-11 22:58:34 --> Security Class Initialized
DEBUG - 2022-03-11 22:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 22:58:34 --> Input Class Initialized
INFO - 2022-03-11 22:58:34 --> Language Class Initialized
INFO - 2022-03-11 22:58:34 --> Loader Class Initialized
INFO - 2022-03-11 22:58:34 --> Helper loaded: url_helper
INFO - 2022-03-11 22:58:34 --> Helper loaded: form_helper
INFO - 2022-03-11 22:58:34 --> Helper loaded: common_helper
INFO - 2022-03-11 22:58:34 --> Database Driver Class Initialized
DEBUG - 2022-03-11 22:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 22:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 22:58:34 --> Controller Class Initialized
INFO - 2022-03-11 22:58:34 --> Form Validation Class Initialized
DEBUG - 2022-03-11 22:58:34 --> Encrypt Class Initialized
INFO - 2022-03-11 22:58:34 --> Model "Patient_model" initialized
INFO - 2022-03-11 22:58:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 22:58:34 --> Model "Prefix_master" initialized
INFO - 2022-03-11 22:58:34 --> Model "Users_model" initialized
INFO - 2022-03-11 22:58:34 --> Model "Hospital_model" initialized
INFO - 2022-03-11 22:58:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 22:58:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 22:58:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 22:58:35 --> Final output sent to browser
DEBUG - 2022-03-11 22:58:35 --> Total execution time: 0.0597
ERROR - 2022-03-11 23:08:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:08:40 --> Config Class Initialized
INFO - 2022-03-11 23:08:40 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:08:40 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:08:40 --> Utf8 Class Initialized
INFO - 2022-03-11 23:08:40 --> URI Class Initialized
INFO - 2022-03-11 23:08:40 --> Router Class Initialized
INFO - 2022-03-11 23:08:40 --> Output Class Initialized
INFO - 2022-03-11 23:08:40 --> Security Class Initialized
DEBUG - 2022-03-11 23:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:08:40 --> Input Class Initialized
INFO - 2022-03-11 23:08:40 --> Language Class Initialized
INFO - 2022-03-11 23:08:40 --> Loader Class Initialized
INFO - 2022-03-11 23:08:40 --> Helper loaded: url_helper
INFO - 2022-03-11 23:08:40 --> Helper loaded: form_helper
INFO - 2022-03-11 23:08:40 --> Helper loaded: common_helper
INFO - 2022-03-11 23:08:40 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:08:40 --> Controller Class Initialized
INFO - 2022-03-11 23:08:40 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:08:40 --> Encrypt Class Initialized
INFO - 2022-03-11 23:08:40 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:08:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:08:40 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:08:40 --> Model "Users_model" initialized
INFO - 2022-03-11 23:08:40 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:08:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:08:41 --> Config Class Initialized
INFO - 2022-03-11 23:08:41 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:08:41 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:08:41 --> Utf8 Class Initialized
INFO - 2022-03-11 23:08:41 --> URI Class Initialized
INFO - 2022-03-11 23:08:41 --> Router Class Initialized
INFO - 2022-03-11 23:08:41 --> Output Class Initialized
INFO - 2022-03-11 23:08:41 --> Security Class Initialized
DEBUG - 2022-03-11 23:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:08:41 --> Input Class Initialized
INFO - 2022-03-11 23:08:41 --> Language Class Initialized
INFO - 2022-03-11 23:08:41 --> Loader Class Initialized
INFO - 2022-03-11 23:08:41 --> Helper loaded: url_helper
INFO - 2022-03-11 23:08:41 --> Helper loaded: form_helper
INFO - 2022-03-11 23:08:41 --> Helper loaded: common_helper
INFO - 2022-03-11 23:08:41 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:08:41 --> Controller Class Initialized
INFO - 2022-03-11 23:08:41 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:08:41 --> Encrypt Class Initialized
INFO - 2022-03-11 23:08:41 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:08:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:08:41 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:08:41 --> Model "Users_model" initialized
INFO - 2022-03-11 23:08:41 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:08:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:08:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:08:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:08:41 --> Final output sent to browser
DEBUG - 2022-03-11 23:08:41 --> Total execution time: 0.0553
ERROR - 2022-03-11 23:08:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:08:52 --> Config Class Initialized
INFO - 2022-03-11 23:08:52 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:08:52 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:08:52 --> Utf8 Class Initialized
INFO - 2022-03-11 23:08:52 --> URI Class Initialized
INFO - 2022-03-11 23:08:52 --> Router Class Initialized
INFO - 2022-03-11 23:08:52 --> Output Class Initialized
INFO - 2022-03-11 23:08:52 --> Security Class Initialized
DEBUG - 2022-03-11 23:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:08:52 --> Input Class Initialized
INFO - 2022-03-11 23:08:52 --> Language Class Initialized
INFO - 2022-03-11 23:08:52 --> Loader Class Initialized
INFO - 2022-03-11 23:08:52 --> Helper loaded: url_helper
INFO - 2022-03-11 23:08:52 --> Helper loaded: form_helper
INFO - 2022-03-11 23:08:52 --> Helper loaded: common_helper
INFO - 2022-03-11 23:08:52 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:08:52 --> Controller Class Initialized
INFO - 2022-03-11 23:08:52 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:08:52 --> Encrypt Class Initialized
INFO - 2022-03-11 23:08:52 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:08:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:08:52 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:08:52 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:08:52 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:08:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:08:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:08:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:08:52 --> Final output sent to browser
DEBUG - 2022-03-11 23:08:52 --> Total execution time: 0.0448
ERROR - 2022-03-11 23:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:11:03 --> Config Class Initialized
INFO - 2022-03-11 23:11:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:11:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:11:03 --> Utf8 Class Initialized
INFO - 2022-03-11 23:11:03 --> URI Class Initialized
INFO - 2022-03-11 23:11:03 --> Router Class Initialized
INFO - 2022-03-11 23:11:03 --> Output Class Initialized
INFO - 2022-03-11 23:11:03 --> Security Class Initialized
DEBUG - 2022-03-11 23:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:11:03 --> Input Class Initialized
INFO - 2022-03-11 23:11:03 --> Language Class Initialized
INFO - 2022-03-11 23:11:03 --> Loader Class Initialized
INFO - 2022-03-11 23:11:03 --> Helper loaded: url_helper
INFO - 2022-03-11 23:11:03 --> Helper loaded: form_helper
INFO - 2022-03-11 23:11:03 --> Helper loaded: common_helper
INFO - 2022-03-11 23:11:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:11:03 --> Controller Class Initialized
INFO - 2022-03-11 23:11:03 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:11:03 --> Encrypt Class Initialized
INFO - 2022-03-11 23:11:03 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:11:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:11:03 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:11:03 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:11:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:11:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:11:04 --> Config Class Initialized
INFO - 2022-03-11 23:11:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:11:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:11:04 --> Utf8 Class Initialized
INFO - 2022-03-11 23:11:04 --> URI Class Initialized
INFO - 2022-03-11 23:11:04 --> Router Class Initialized
INFO - 2022-03-11 23:11:04 --> Output Class Initialized
INFO - 2022-03-11 23:11:04 --> Security Class Initialized
DEBUG - 2022-03-11 23:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:11:04 --> Input Class Initialized
INFO - 2022-03-11 23:11:04 --> Language Class Initialized
INFO - 2022-03-11 23:11:04 --> Loader Class Initialized
INFO - 2022-03-11 23:11:04 --> Helper loaded: url_helper
INFO - 2022-03-11 23:11:04 --> Helper loaded: form_helper
INFO - 2022-03-11 23:11:04 --> Helper loaded: common_helper
INFO - 2022-03-11 23:11:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:11:04 --> Controller Class Initialized
INFO - 2022-03-11 23:11:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:11:04 --> Encrypt Class Initialized
INFO - 2022-03-11 23:11:04 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:11:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:11:04 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:11:04 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:11:04 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:11:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:11:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:11:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:11:04 --> Final output sent to browser
DEBUG - 2022-03-11 23:11:04 --> Total execution time: 0.0552
ERROR - 2022-03-11 23:11:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:11:05 --> Config Class Initialized
INFO - 2022-03-11 23:11:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:11:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:11:05 --> Utf8 Class Initialized
INFO - 2022-03-11 23:11:05 --> URI Class Initialized
INFO - 2022-03-11 23:11:05 --> Router Class Initialized
INFO - 2022-03-11 23:11:05 --> Output Class Initialized
INFO - 2022-03-11 23:11:05 --> Security Class Initialized
DEBUG - 2022-03-11 23:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:11:05 --> Input Class Initialized
INFO - 2022-03-11 23:11:05 --> Language Class Initialized
INFO - 2022-03-11 23:11:05 --> Loader Class Initialized
INFO - 2022-03-11 23:11:05 --> Helper loaded: url_helper
INFO - 2022-03-11 23:11:05 --> Helper loaded: form_helper
INFO - 2022-03-11 23:11:05 --> Helper loaded: common_helper
INFO - 2022-03-11 23:11:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:11:05 --> Controller Class Initialized
INFO - 2022-03-11 23:11:05 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:11:05 --> Encrypt Class Initialized
INFO - 2022-03-11 23:11:05 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:11:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:11:05 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:11:05 --> Model "Users_model" initialized
INFO - 2022-03-11 23:11:05 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:11:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:11:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:11:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:11:05 --> Final output sent to browser
DEBUG - 2022-03-11 23:11:05 --> Total execution time: 0.0580
ERROR - 2022-03-11 23:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:11:10 --> Config Class Initialized
INFO - 2022-03-11 23:11:10 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:11:10 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:11:10 --> Utf8 Class Initialized
INFO - 2022-03-11 23:11:10 --> URI Class Initialized
INFO - 2022-03-11 23:11:10 --> Router Class Initialized
INFO - 2022-03-11 23:11:10 --> Output Class Initialized
INFO - 2022-03-11 23:11:10 --> Security Class Initialized
DEBUG - 2022-03-11 23:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:11:10 --> Input Class Initialized
INFO - 2022-03-11 23:11:10 --> Language Class Initialized
INFO - 2022-03-11 23:11:10 --> Loader Class Initialized
INFO - 2022-03-11 23:11:10 --> Helper loaded: url_helper
INFO - 2022-03-11 23:11:10 --> Helper loaded: form_helper
INFO - 2022-03-11 23:11:10 --> Helper loaded: common_helper
INFO - 2022-03-11 23:11:10 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:11:10 --> Controller Class Initialized
INFO - 2022-03-11 23:11:10 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:11:10 --> Encrypt Class Initialized
INFO - 2022-03-11 23:11:10 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:11:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:11:10 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:11:10 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:11:10 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:11:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:11:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:11:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:11:10 --> Final output sent to browser
DEBUG - 2022-03-11 23:11:10 --> Total execution time: 0.0417
ERROR - 2022-03-11 23:11:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:11:43 --> Config Class Initialized
INFO - 2022-03-11 23:11:43 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:11:43 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:11:43 --> Utf8 Class Initialized
INFO - 2022-03-11 23:11:43 --> URI Class Initialized
INFO - 2022-03-11 23:11:43 --> Router Class Initialized
INFO - 2022-03-11 23:11:43 --> Output Class Initialized
INFO - 2022-03-11 23:11:43 --> Security Class Initialized
DEBUG - 2022-03-11 23:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:11:43 --> Input Class Initialized
INFO - 2022-03-11 23:11:43 --> Language Class Initialized
INFO - 2022-03-11 23:11:43 --> Loader Class Initialized
INFO - 2022-03-11 23:11:43 --> Helper loaded: url_helper
INFO - 2022-03-11 23:11:43 --> Helper loaded: form_helper
INFO - 2022-03-11 23:11:43 --> Helper loaded: common_helper
INFO - 2022-03-11 23:11:43 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:11:43 --> Controller Class Initialized
INFO - 2022-03-11 23:11:43 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:11:43 --> Encrypt Class Initialized
INFO - 2022-03-11 23:11:43 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:11:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:11:43 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:11:43 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:11:43 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:11:43 --> Upload Class Initialized
INFO - 2022-03-11 23:11:43 --> Final output sent to browser
DEBUG - 2022-03-11 23:11:43 --> Total execution time: 0.0391
ERROR - 2022-03-11 23:11:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:11:57 --> Config Class Initialized
INFO - 2022-03-11 23:11:57 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:11:57 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:11:57 --> Utf8 Class Initialized
INFO - 2022-03-11 23:11:57 --> URI Class Initialized
INFO - 2022-03-11 23:11:57 --> Router Class Initialized
INFO - 2022-03-11 23:11:57 --> Output Class Initialized
INFO - 2022-03-11 23:11:57 --> Security Class Initialized
DEBUG - 2022-03-11 23:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:11:57 --> Input Class Initialized
INFO - 2022-03-11 23:11:57 --> Language Class Initialized
INFO - 2022-03-11 23:11:57 --> Loader Class Initialized
INFO - 2022-03-11 23:11:57 --> Helper loaded: url_helper
INFO - 2022-03-11 23:11:57 --> Helper loaded: form_helper
INFO - 2022-03-11 23:11:57 --> Helper loaded: common_helper
INFO - 2022-03-11 23:11:57 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:11:57 --> Controller Class Initialized
INFO - 2022-03-11 23:11:57 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:11:57 --> Encrypt Class Initialized
INFO - 2022-03-11 23:11:57 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:11:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:11:57 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:11:57 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:11:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:11:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:11:57 --> Config Class Initialized
INFO - 2022-03-11 23:11:57 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:11:57 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:11:57 --> Utf8 Class Initialized
INFO - 2022-03-11 23:11:57 --> URI Class Initialized
INFO - 2022-03-11 23:11:57 --> Router Class Initialized
INFO - 2022-03-11 23:11:57 --> Output Class Initialized
INFO - 2022-03-11 23:11:57 --> Security Class Initialized
DEBUG - 2022-03-11 23:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:11:57 --> Input Class Initialized
INFO - 2022-03-11 23:11:57 --> Language Class Initialized
INFO - 2022-03-11 23:11:57 --> Loader Class Initialized
INFO - 2022-03-11 23:11:57 --> Helper loaded: url_helper
INFO - 2022-03-11 23:11:57 --> Helper loaded: form_helper
INFO - 2022-03-11 23:11:57 --> Helper loaded: common_helper
INFO - 2022-03-11 23:11:57 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:11:57 --> Controller Class Initialized
INFO - 2022-03-11 23:11:57 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:11:57 --> Encrypt Class Initialized
INFO - 2022-03-11 23:11:57 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:11:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:11:57 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:11:57 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:11:57 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:11:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:11:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:11:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:11:57 --> Final output sent to browser
DEBUG - 2022-03-11 23:11:57 --> Total execution time: 0.0989
ERROR - 2022-03-11 23:11:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:11:59 --> Config Class Initialized
INFO - 2022-03-11 23:11:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:11:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:11:59 --> Utf8 Class Initialized
INFO - 2022-03-11 23:11:59 --> URI Class Initialized
INFO - 2022-03-11 23:11:59 --> Router Class Initialized
INFO - 2022-03-11 23:11:59 --> Output Class Initialized
INFO - 2022-03-11 23:11:59 --> Security Class Initialized
DEBUG - 2022-03-11 23:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:11:59 --> Input Class Initialized
INFO - 2022-03-11 23:11:59 --> Language Class Initialized
INFO - 2022-03-11 23:11:59 --> Loader Class Initialized
INFO - 2022-03-11 23:11:59 --> Helper loaded: url_helper
INFO - 2022-03-11 23:11:59 --> Helper loaded: form_helper
INFO - 2022-03-11 23:11:59 --> Helper loaded: common_helper
INFO - 2022-03-11 23:11:59 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:11:59 --> Controller Class Initialized
INFO - 2022-03-11 23:11:59 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:11:59 --> Encrypt Class Initialized
INFO - 2022-03-11 23:11:59 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:11:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:11:59 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:11:59 --> Model "Users_model" initialized
INFO - 2022-03-11 23:11:59 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:11:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:11:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:11:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:11:59 --> Final output sent to browser
DEBUG - 2022-03-11 23:11:59 --> Total execution time: 0.1126
ERROR - 2022-03-11 23:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:12:28 --> Config Class Initialized
INFO - 2022-03-11 23:12:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:12:28 --> Utf8 Class Initialized
INFO - 2022-03-11 23:12:28 --> URI Class Initialized
INFO - 2022-03-11 23:12:28 --> Router Class Initialized
INFO - 2022-03-11 23:12:28 --> Output Class Initialized
INFO - 2022-03-11 23:12:28 --> Security Class Initialized
DEBUG - 2022-03-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:12:28 --> Input Class Initialized
INFO - 2022-03-11 23:12:28 --> Language Class Initialized
INFO - 2022-03-11 23:12:28 --> Loader Class Initialized
INFO - 2022-03-11 23:12:28 --> Helper loaded: url_helper
INFO - 2022-03-11 23:12:28 --> Helper loaded: form_helper
INFO - 2022-03-11 23:12:28 --> Helper loaded: common_helper
INFO - 2022-03-11 23:12:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:12:28 --> Controller Class Initialized
INFO - 2022-03-11 23:12:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:12:28 --> Encrypt Class Initialized
INFO - 2022-03-11 23:12:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:12:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:12:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:12:28 --> Model "Users_model" initialized
INFO - 2022-03-11 23:12:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:12:28 --> Config Class Initialized
INFO - 2022-03-11 23:12:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:12:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:12:28 --> Utf8 Class Initialized
INFO - 2022-03-11 23:12:28 --> URI Class Initialized
INFO - 2022-03-11 23:12:28 --> Router Class Initialized
INFO - 2022-03-11 23:12:28 --> Output Class Initialized
INFO - 2022-03-11 23:12:28 --> Security Class Initialized
DEBUG - 2022-03-11 23:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:12:28 --> Input Class Initialized
INFO - 2022-03-11 23:12:28 --> Language Class Initialized
INFO - 2022-03-11 23:12:28 --> Loader Class Initialized
INFO - 2022-03-11 23:12:28 --> Helper loaded: url_helper
INFO - 2022-03-11 23:12:28 --> Helper loaded: form_helper
INFO - 2022-03-11 23:12:28 --> Helper loaded: common_helper
INFO - 2022-03-11 23:12:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:12:28 --> Controller Class Initialized
INFO - 2022-03-11 23:12:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:12:28 --> Encrypt Class Initialized
INFO - 2022-03-11 23:12:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:12:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:12:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:12:28 --> Model "Users_model" initialized
INFO - 2022-03-11 23:12:28 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:12:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:12:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:12:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:12:28 --> Final output sent to browser
DEBUG - 2022-03-11 23:12:28 --> Total execution time: 0.0990
ERROR - 2022-03-11 23:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:16:23 --> Config Class Initialized
INFO - 2022-03-11 23:16:23 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:16:23 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:16:23 --> Utf8 Class Initialized
INFO - 2022-03-11 23:16:23 --> URI Class Initialized
INFO - 2022-03-11 23:16:23 --> Router Class Initialized
INFO - 2022-03-11 23:16:23 --> Output Class Initialized
INFO - 2022-03-11 23:16:23 --> Security Class Initialized
DEBUG - 2022-03-11 23:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:16:23 --> Input Class Initialized
INFO - 2022-03-11 23:16:23 --> Language Class Initialized
INFO - 2022-03-11 23:16:23 --> Loader Class Initialized
INFO - 2022-03-11 23:16:23 --> Helper loaded: url_helper
INFO - 2022-03-11 23:16:23 --> Helper loaded: form_helper
INFO - 2022-03-11 23:16:23 --> Helper loaded: common_helper
INFO - 2022-03-11 23:16:23 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:16:23 --> Controller Class Initialized
INFO - 2022-03-11 23:16:23 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:16:23 --> Encrypt Class Initialized
INFO - 2022-03-11 23:16:23 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:16:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:16:23 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:16:23 --> Model "Users_model" initialized
INFO - 2022-03-11 23:16:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:16:23 --> Config Class Initialized
INFO - 2022-03-11 23:16:23 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:16:23 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:16:23 --> Utf8 Class Initialized
INFO - 2022-03-11 23:16:23 --> URI Class Initialized
INFO - 2022-03-11 23:16:23 --> Router Class Initialized
INFO - 2022-03-11 23:16:23 --> Output Class Initialized
INFO - 2022-03-11 23:16:23 --> Security Class Initialized
DEBUG - 2022-03-11 23:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:16:23 --> Input Class Initialized
INFO - 2022-03-11 23:16:23 --> Language Class Initialized
INFO - 2022-03-11 23:16:23 --> Loader Class Initialized
INFO - 2022-03-11 23:16:23 --> Helper loaded: url_helper
INFO - 2022-03-11 23:16:23 --> Helper loaded: form_helper
INFO - 2022-03-11 23:16:23 --> Helper loaded: common_helper
INFO - 2022-03-11 23:16:23 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:16:23 --> Controller Class Initialized
INFO - 2022-03-11 23:16:23 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:16:23 --> Encrypt Class Initialized
INFO - 2022-03-11 23:16:23 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:16:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:16:23 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:16:23 --> Model "Users_model" initialized
INFO - 2022-03-11 23:16:23 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:16:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:16:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:16:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:16:23 --> Final output sent to browser
DEBUG - 2022-03-11 23:16:23 --> Total execution time: 0.1053
ERROR - 2022-03-11 23:17:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:17:52 --> Config Class Initialized
INFO - 2022-03-11 23:17:52 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:17:52 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:17:52 --> Utf8 Class Initialized
INFO - 2022-03-11 23:17:52 --> URI Class Initialized
INFO - 2022-03-11 23:17:52 --> Router Class Initialized
INFO - 2022-03-11 23:17:52 --> Output Class Initialized
INFO - 2022-03-11 23:17:52 --> Security Class Initialized
DEBUG - 2022-03-11 23:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:17:52 --> Input Class Initialized
INFO - 2022-03-11 23:17:52 --> Language Class Initialized
INFO - 2022-03-11 23:17:52 --> Loader Class Initialized
INFO - 2022-03-11 23:17:52 --> Helper loaded: url_helper
INFO - 2022-03-11 23:17:52 --> Helper loaded: form_helper
INFO - 2022-03-11 23:17:52 --> Helper loaded: common_helper
INFO - 2022-03-11 23:17:52 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:17:52 --> Controller Class Initialized
INFO - 2022-03-11 23:17:52 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:17:52 --> Encrypt Class Initialized
INFO - 2022-03-11 23:17:52 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:17:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:17:52 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:17:52 --> Model "Users_model" initialized
INFO - 2022-03-11 23:17:52 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:17:52 --> Upload Class Initialized
INFO - 2022-03-11 23:17:52 --> Final output sent to browser
DEBUG - 2022-03-11 23:17:52 --> Total execution time: 0.0940
ERROR - 2022-03-11 23:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:18:59 --> Config Class Initialized
INFO - 2022-03-11 23:18:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:18:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:18:59 --> Utf8 Class Initialized
INFO - 2022-03-11 23:18:59 --> URI Class Initialized
INFO - 2022-03-11 23:18:59 --> Router Class Initialized
INFO - 2022-03-11 23:18:59 --> Output Class Initialized
INFO - 2022-03-11 23:18:59 --> Security Class Initialized
DEBUG - 2022-03-11 23:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:18:59 --> Input Class Initialized
INFO - 2022-03-11 23:18:59 --> Language Class Initialized
INFO - 2022-03-11 23:18:59 --> Loader Class Initialized
INFO - 2022-03-11 23:18:59 --> Helper loaded: url_helper
INFO - 2022-03-11 23:18:59 --> Helper loaded: form_helper
INFO - 2022-03-11 23:18:59 --> Helper loaded: common_helper
INFO - 2022-03-11 23:18:59 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:18:59 --> Controller Class Initialized
INFO - 2022-03-11 23:18:59 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:18:59 --> Encrypt Class Initialized
INFO - 2022-03-11 23:18:59 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:18:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:18:59 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:18:59 --> Model "Users_model" initialized
INFO - 2022-03-11 23:18:59 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:18:59 --> Final output sent to browser
DEBUG - 2022-03-11 23:18:59 --> Total execution time: 0.0238
ERROR - 2022-03-11 23:19:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:19:20 --> Config Class Initialized
INFO - 2022-03-11 23:19:20 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:19:20 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:19:20 --> Utf8 Class Initialized
INFO - 2022-03-11 23:19:20 --> URI Class Initialized
INFO - 2022-03-11 23:19:20 --> Router Class Initialized
INFO - 2022-03-11 23:19:20 --> Output Class Initialized
INFO - 2022-03-11 23:19:20 --> Security Class Initialized
DEBUG - 2022-03-11 23:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:19:20 --> Input Class Initialized
INFO - 2022-03-11 23:19:20 --> Language Class Initialized
INFO - 2022-03-11 23:19:20 --> Loader Class Initialized
INFO - 2022-03-11 23:19:20 --> Helper loaded: url_helper
INFO - 2022-03-11 23:19:20 --> Helper loaded: form_helper
INFO - 2022-03-11 23:19:20 --> Helper loaded: common_helper
INFO - 2022-03-11 23:19:20 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:19:20 --> Controller Class Initialized
INFO - 2022-03-11 23:19:20 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:19:20 --> Encrypt Class Initialized
INFO - 2022-03-11 23:19:20 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:19:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:19:20 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:19:20 --> Model "Users_model" initialized
INFO - 2022-03-11 23:19:20 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:19:20 --> Upload Class Initialized
INFO - 2022-03-11 23:19:20 --> Final output sent to browser
DEBUG - 2022-03-11 23:19:20 --> Total execution time: 0.0467
ERROR - 2022-03-11 23:19:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:19:30 --> Config Class Initialized
INFO - 2022-03-11 23:19:30 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:19:30 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:19:30 --> Utf8 Class Initialized
INFO - 2022-03-11 23:19:30 --> URI Class Initialized
INFO - 2022-03-11 23:19:30 --> Router Class Initialized
INFO - 2022-03-11 23:19:30 --> Output Class Initialized
INFO - 2022-03-11 23:19:30 --> Security Class Initialized
DEBUG - 2022-03-11 23:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:19:30 --> Input Class Initialized
INFO - 2022-03-11 23:19:30 --> Language Class Initialized
INFO - 2022-03-11 23:19:30 --> Loader Class Initialized
INFO - 2022-03-11 23:19:30 --> Helper loaded: url_helper
INFO - 2022-03-11 23:19:30 --> Helper loaded: form_helper
INFO - 2022-03-11 23:19:30 --> Helper loaded: common_helper
INFO - 2022-03-11 23:19:30 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:19:30 --> Controller Class Initialized
INFO - 2022-03-11 23:19:30 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:19:30 --> Encrypt Class Initialized
INFO - 2022-03-11 23:19:30 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:19:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:19:30 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:19:30 --> Model "Users_model" initialized
INFO - 2022-03-11 23:19:30 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:19:30 --> Upload Class Initialized
INFO - 2022-03-11 23:19:30 --> Final output sent to browser
DEBUG - 2022-03-11 23:19:30 --> Total execution time: 0.1148
ERROR - 2022-03-11 23:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:19:37 --> Config Class Initialized
INFO - 2022-03-11 23:19:37 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:19:37 --> Utf8 Class Initialized
INFO - 2022-03-11 23:19:37 --> URI Class Initialized
INFO - 2022-03-11 23:19:37 --> Router Class Initialized
INFO - 2022-03-11 23:19:37 --> Output Class Initialized
INFO - 2022-03-11 23:19:37 --> Security Class Initialized
DEBUG - 2022-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:19:37 --> Input Class Initialized
INFO - 2022-03-11 23:19:37 --> Language Class Initialized
INFO - 2022-03-11 23:19:37 --> Loader Class Initialized
INFO - 2022-03-11 23:19:37 --> Helper loaded: url_helper
INFO - 2022-03-11 23:19:37 --> Helper loaded: form_helper
INFO - 2022-03-11 23:19:37 --> Helper loaded: common_helper
INFO - 2022-03-11 23:19:37 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:19:37 --> Controller Class Initialized
INFO - 2022-03-11 23:19:37 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:19:37 --> Encrypt Class Initialized
INFO - 2022-03-11 23:19:37 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:19:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:19:37 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:19:37 --> Model "Users_model" initialized
INFO - 2022-03-11 23:19:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:19:37 --> Config Class Initialized
INFO - 2022-03-11 23:19:37 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:19:37 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:19:37 --> Utf8 Class Initialized
INFO - 2022-03-11 23:19:37 --> URI Class Initialized
INFO - 2022-03-11 23:19:37 --> Router Class Initialized
INFO - 2022-03-11 23:19:37 --> Output Class Initialized
INFO - 2022-03-11 23:19:37 --> Security Class Initialized
DEBUG - 2022-03-11 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:19:37 --> Input Class Initialized
INFO - 2022-03-11 23:19:37 --> Language Class Initialized
INFO - 2022-03-11 23:19:37 --> Loader Class Initialized
INFO - 2022-03-11 23:19:37 --> Helper loaded: url_helper
INFO - 2022-03-11 23:19:37 --> Helper loaded: form_helper
INFO - 2022-03-11 23:19:37 --> Helper loaded: common_helper
INFO - 2022-03-11 23:19:37 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:19:37 --> Controller Class Initialized
INFO - 2022-03-11 23:19:37 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:19:37 --> Encrypt Class Initialized
INFO - 2022-03-11 23:19:37 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:19:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:19:37 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:19:37 --> Model "Users_model" initialized
INFO - 2022-03-11 23:19:37 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:19:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:19:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:19:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:19:37 --> Final output sent to browser
DEBUG - 2022-03-11 23:19:37 --> Total execution time: 0.1222
ERROR - 2022-03-11 23:20:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:20:05 --> Config Class Initialized
INFO - 2022-03-11 23:20:05 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:20:05 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:20:05 --> Utf8 Class Initialized
INFO - 2022-03-11 23:20:05 --> URI Class Initialized
INFO - 2022-03-11 23:20:05 --> Router Class Initialized
INFO - 2022-03-11 23:20:05 --> Output Class Initialized
INFO - 2022-03-11 23:20:05 --> Security Class Initialized
DEBUG - 2022-03-11 23:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:20:05 --> Input Class Initialized
INFO - 2022-03-11 23:20:05 --> Language Class Initialized
INFO - 2022-03-11 23:20:05 --> Loader Class Initialized
INFO - 2022-03-11 23:20:05 --> Helper loaded: url_helper
INFO - 2022-03-11 23:20:05 --> Helper loaded: form_helper
INFO - 2022-03-11 23:20:05 --> Helper loaded: common_helper
INFO - 2022-03-11 23:20:05 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:20:05 --> Controller Class Initialized
INFO - 2022-03-11 23:20:05 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:20:05 --> Encrypt Class Initialized
INFO - 2022-03-11 23:20:05 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:20:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:20:05 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:20:05 --> Model "Users_model" initialized
INFO - 2022-03-11 23:20:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:20:06 --> Config Class Initialized
INFO - 2022-03-11 23:20:06 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:20:06 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:20:06 --> Utf8 Class Initialized
INFO - 2022-03-11 23:20:06 --> URI Class Initialized
INFO - 2022-03-11 23:20:06 --> Router Class Initialized
INFO - 2022-03-11 23:20:06 --> Output Class Initialized
INFO - 2022-03-11 23:20:06 --> Security Class Initialized
DEBUG - 2022-03-11 23:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:20:06 --> Input Class Initialized
INFO - 2022-03-11 23:20:06 --> Language Class Initialized
INFO - 2022-03-11 23:20:06 --> Loader Class Initialized
INFO - 2022-03-11 23:20:06 --> Helper loaded: url_helper
INFO - 2022-03-11 23:20:06 --> Helper loaded: form_helper
INFO - 2022-03-11 23:20:06 --> Helper loaded: common_helper
INFO - 2022-03-11 23:20:06 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:20:06 --> Controller Class Initialized
INFO - 2022-03-11 23:20:06 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:20:06 --> Encrypt Class Initialized
INFO - 2022-03-11 23:20:06 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:20:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:20:06 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:20:06 --> Model "Users_model" initialized
INFO - 2022-03-11 23:20:06 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:20:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:20:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:20:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:20:06 --> Final output sent to browser
DEBUG - 2022-03-11 23:20:06 --> Total execution time: 0.0730
ERROR - 2022-03-11 23:20:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:20:21 --> Config Class Initialized
INFO - 2022-03-11 23:20:21 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:20:21 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:20:21 --> Utf8 Class Initialized
INFO - 2022-03-11 23:20:21 --> URI Class Initialized
INFO - 2022-03-11 23:20:21 --> Router Class Initialized
INFO - 2022-03-11 23:20:21 --> Output Class Initialized
INFO - 2022-03-11 23:20:21 --> Security Class Initialized
DEBUG - 2022-03-11 23:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:20:21 --> Input Class Initialized
INFO - 2022-03-11 23:20:21 --> Language Class Initialized
INFO - 2022-03-11 23:20:21 --> Loader Class Initialized
INFO - 2022-03-11 23:20:21 --> Helper loaded: url_helper
INFO - 2022-03-11 23:20:21 --> Helper loaded: form_helper
INFO - 2022-03-11 23:20:21 --> Helper loaded: common_helper
INFO - 2022-03-11 23:20:21 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:20:21 --> Controller Class Initialized
INFO - 2022-03-11 23:20:21 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:20:21 --> Encrypt Class Initialized
INFO - 2022-03-11 23:20:21 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:20:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:20:21 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:20:21 --> Model "Users_model" initialized
INFO - 2022-03-11 23:20:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:20:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:20:22 --> Config Class Initialized
INFO - 2022-03-11 23:20:22 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:20:22 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:20:22 --> Utf8 Class Initialized
INFO - 2022-03-11 23:20:22 --> URI Class Initialized
INFO - 2022-03-11 23:20:22 --> Router Class Initialized
INFO - 2022-03-11 23:20:22 --> Output Class Initialized
INFO - 2022-03-11 23:20:22 --> Security Class Initialized
DEBUG - 2022-03-11 23:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:20:22 --> Input Class Initialized
INFO - 2022-03-11 23:20:22 --> Language Class Initialized
INFO - 2022-03-11 23:20:22 --> Loader Class Initialized
INFO - 2022-03-11 23:20:22 --> Helper loaded: url_helper
INFO - 2022-03-11 23:20:22 --> Helper loaded: form_helper
INFO - 2022-03-11 23:20:22 --> Helper loaded: common_helper
INFO - 2022-03-11 23:20:22 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:20:22 --> Controller Class Initialized
INFO - 2022-03-11 23:20:22 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:20:22 --> Encrypt Class Initialized
INFO - 2022-03-11 23:20:22 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:20:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:20:22 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:20:22 --> Model "Users_model" initialized
INFO - 2022-03-11 23:20:22 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:20:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:20:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:20:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:20:22 --> Final output sent to browser
DEBUG - 2022-03-11 23:20:22 --> Total execution time: 0.0668
ERROR - 2022-03-11 23:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:35:45 --> Config Class Initialized
INFO - 2022-03-11 23:35:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:35:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:35:45 --> Utf8 Class Initialized
INFO - 2022-03-11 23:35:45 --> URI Class Initialized
INFO - 2022-03-11 23:35:45 --> Router Class Initialized
INFO - 2022-03-11 23:35:45 --> Output Class Initialized
INFO - 2022-03-11 23:35:45 --> Security Class Initialized
DEBUG - 2022-03-11 23:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:35:45 --> Input Class Initialized
INFO - 2022-03-11 23:35:45 --> Language Class Initialized
INFO - 2022-03-11 23:35:45 --> Loader Class Initialized
INFO - 2022-03-11 23:35:45 --> Helper loaded: url_helper
INFO - 2022-03-11 23:35:45 --> Helper loaded: form_helper
INFO - 2022-03-11 23:35:45 --> Helper loaded: common_helper
INFO - 2022-03-11 23:35:45 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:35:45 --> Controller Class Initialized
INFO - 2022-03-11 23:35:45 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:35:45 --> Encrypt Class Initialized
INFO - 2022-03-11 23:35:45 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:35:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:35:45 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:35:45 --> Model "Users_model" initialized
INFO - 2022-03-11 23:35:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:35:46 --> Config Class Initialized
INFO - 2022-03-11 23:35:46 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:35:46 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:35:46 --> Utf8 Class Initialized
INFO - 2022-03-11 23:35:46 --> URI Class Initialized
INFO - 2022-03-11 23:35:46 --> Router Class Initialized
INFO - 2022-03-11 23:35:46 --> Output Class Initialized
INFO - 2022-03-11 23:35:46 --> Security Class Initialized
DEBUG - 2022-03-11 23:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:35:46 --> Input Class Initialized
INFO - 2022-03-11 23:35:46 --> Language Class Initialized
INFO - 2022-03-11 23:35:46 --> Loader Class Initialized
INFO - 2022-03-11 23:35:46 --> Helper loaded: url_helper
INFO - 2022-03-11 23:35:46 --> Helper loaded: form_helper
INFO - 2022-03-11 23:35:46 --> Helper loaded: common_helper
INFO - 2022-03-11 23:35:46 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:35:46 --> Controller Class Initialized
INFO - 2022-03-11 23:35:46 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:35:46 --> Encrypt Class Initialized
INFO - 2022-03-11 23:35:46 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:35:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:35:46 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:35:46 --> Model "Users_model" initialized
INFO - 2022-03-11 23:35:46 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:35:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:35:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:35:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:35:46 --> Final output sent to browser
DEBUG - 2022-03-11 23:35:46 --> Total execution time: 0.0905
ERROR - 2022-03-11 23:35:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:35:54 --> Config Class Initialized
INFO - 2022-03-11 23:35:54 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:35:54 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:35:54 --> Utf8 Class Initialized
INFO - 2022-03-11 23:35:54 --> URI Class Initialized
INFO - 2022-03-11 23:35:54 --> Router Class Initialized
INFO - 2022-03-11 23:35:54 --> Output Class Initialized
INFO - 2022-03-11 23:35:54 --> Security Class Initialized
DEBUG - 2022-03-11 23:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:35:54 --> Input Class Initialized
INFO - 2022-03-11 23:35:54 --> Language Class Initialized
INFO - 2022-03-11 23:35:54 --> Loader Class Initialized
INFO - 2022-03-11 23:35:54 --> Helper loaded: url_helper
INFO - 2022-03-11 23:35:54 --> Helper loaded: form_helper
INFO - 2022-03-11 23:35:54 --> Helper loaded: common_helper
INFO - 2022-03-11 23:35:54 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:35:54 --> Controller Class Initialized
INFO - 2022-03-11 23:35:54 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:35:54 --> Encrypt Class Initialized
INFO - 2022-03-11 23:35:54 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:35:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:35:54 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:35:54 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:35:54 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:35:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:35:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:35:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:35:54 --> Final output sent to browser
DEBUG - 2022-03-11 23:35:54 --> Total execution time: 0.0613
ERROR - 2022-03-11 23:36:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:36:07 --> Config Class Initialized
INFO - 2022-03-11 23:36:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:36:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:36:07 --> Utf8 Class Initialized
INFO - 2022-03-11 23:36:07 --> URI Class Initialized
INFO - 2022-03-11 23:36:07 --> Router Class Initialized
INFO - 2022-03-11 23:36:07 --> Output Class Initialized
INFO - 2022-03-11 23:36:07 --> Security Class Initialized
DEBUG - 2022-03-11 23:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:36:07 --> Input Class Initialized
INFO - 2022-03-11 23:36:07 --> Language Class Initialized
INFO - 2022-03-11 23:36:07 --> Loader Class Initialized
INFO - 2022-03-11 23:36:07 --> Helper loaded: url_helper
INFO - 2022-03-11 23:36:07 --> Helper loaded: form_helper
INFO - 2022-03-11 23:36:07 --> Helper loaded: common_helper
INFO - 2022-03-11 23:36:07 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:36:07 --> Controller Class Initialized
INFO - 2022-03-11 23:36:07 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:36:07 --> Encrypt Class Initialized
INFO - 2022-03-11 23:36:07 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:36:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:36:07 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:36:07 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:36:07 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:36:07 --> Upload Class Initialized
INFO - 2022-03-11 23:36:07 --> Final output sent to browser
DEBUG - 2022-03-11 23:36:07 --> Total execution time: 0.0263
ERROR - 2022-03-11 23:36:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:36:18 --> Config Class Initialized
INFO - 2022-03-11 23:36:18 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:36:18 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:36:18 --> Utf8 Class Initialized
INFO - 2022-03-11 23:36:18 --> URI Class Initialized
INFO - 2022-03-11 23:36:18 --> Router Class Initialized
INFO - 2022-03-11 23:36:18 --> Output Class Initialized
INFO - 2022-03-11 23:36:18 --> Security Class Initialized
DEBUG - 2022-03-11 23:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:36:18 --> Input Class Initialized
INFO - 2022-03-11 23:36:18 --> Language Class Initialized
INFO - 2022-03-11 23:36:18 --> Loader Class Initialized
INFO - 2022-03-11 23:36:18 --> Helper loaded: url_helper
INFO - 2022-03-11 23:36:18 --> Helper loaded: form_helper
INFO - 2022-03-11 23:36:18 --> Helper loaded: common_helper
INFO - 2022-03-11 23:36:18 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:36:18 --> Controller Class Initialized
INFO - 2022-03-11 23:36:18 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:36:18 --> Encrypt Class Initialized
INFO - 2022-03-11 23:36:18 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:36:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:36:18 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:36:18 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:36:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:36:19 --> Config Class Initialized
INFO - 2022-03-11 23:36:19 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:36:19 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:36:19 --> Utf8 Class Initialized
INFO - 2022-03-11 23:36:19 --> URI Class Initialized
INFO - 2022-03-11 23:36:19 --> Router Class Initialized
INFO - 2022-03-11 23:36:19 --> Output Class Initialized
INFO - 2022-03-11 23:36:19 --> Security Class Initialized
DEBUG - 2022-03-11 23:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:36:19 --> Input Class Initialized
INFO - 2022-03-11 23:36:19 --> Language Class Initialized
INFO - 2022-03-11 23:36:19 --> Loader Class Initialized
INFO - 2022-03-11 23:36:19 --> Helper loaded: url_helper
INFO - 2022-03-11 23:36:19 --> Helper loaded: form_helper
INFO - 2022-03-11 23:36:19 --> Helper loaded: common_helper
INFO - 2022-03-11 23:36:19 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:36:19 --> Controller Class Initialized
INFO - 2022-03-11 23:36:19 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:36:19 --> Encrypt Class Initialized
INFO - 2022-03-11 23:36:19 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:36:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:36:19 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:36:19 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:36:19 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:36:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:36:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:36:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:36:19 --> Final output sent to browser
DEBUG - 2022-03-11 23:36:19 --> Total execution time: 0.0565
ERROR - 2022-03-11 23:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:36:20 --> Config Class Initialized
INFO - 2022-03-11 23:36:20 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:36:20 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:36:20 --> Utf8 Class Initialized
INFO - 2022-03-11 23:36:20 --> URI Class Initialized
INFO - 2022-03-11 23:36:20 --> Router Class Initialized
INFO - 2022-03-11 23:36:20 --> Output Class Initialized
INFO - 2022-03-11 23:36:20 --> Security Class Initialized
DEBUG - 2022-03-11 23:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:36:20 --> Input Class Initialized
INFO - 2022-03-11 23:36:20 --> Language Class Initialized
INFO - 2022-03-11 23:36:20 --> Loader Class Initialized
INFO - 2022-03-11 23:36:20 --> Helper loaded: url_helper
INFO - 2022-03-11 23:36:20 --> Helper loaded: form_helper
INFO - 2022-03-11 23:36:20 --> Helper loaded: common_helper
INFO - 2022-03-11 23:36:20 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:36:20 --> Controller Class Initialized
INFO - 2022-03-11 23:36:20 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:36:20 --> Encrypt Class Initialized
INFO - 2022-03-11 23:36:20 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:36:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:36:20 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:36:20 --> Model "Users_model" initialized
INFO - 2022-03-11 23:36:20 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:36:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:36:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:36:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:36:20 --> Final output sent to browser
DEBUG - 2022-03-11 23:36:20 --> Total execution time: 0.0618
ERROR - 2022-03-11 23:44:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:44:04 --> Config Class Initialized
INFO - 2022-03-11 23:44:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:44:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:44:04 --> Utf8 Class Initialized
INFO - 2022-03-11 23:44:04 --> URI Class Initialized
INFO - 2022-03-11 23:44:04 --> Router Class Initialized
INFO - 2022-03-11 23:44:04 --> Output Class Initialized
INFO - 2022-03-11 23:44:04 --> Security Class Initialized
DEBUG - 2022-03-11 23:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:44:04 --> Input Class Initialized
INFO - 2022-03-11 23:44:04 --> Language Class Initialized
INFO - 2022-03-11 23:44:04 --> Loader Class Initialized
INFO - 2022-03-11 23:44:04 --> Helper loaded: url_helper
INFO - 2022-03-11 23:44:04 --> Helper loaded: form_helper
INFO - 2022-03-11 23:44:04 --> Helper loaded: common_helper
INFO - 2022-03-11 23:44:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:44:04 --> Controller Class Initialized
INFO - 2022-03-11 23:44:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:44:04 --> Encrypt Class Initialized
INFO - 2022-03-11 23:44:04 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:44:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:44:04 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:44:04 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:44:04 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:44:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:44:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:44:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:44:04 --> Final output sent to browser
DEBUG - 2022-03-11 23:44:04 --> Total execution time: 0.0311
ERROR - 2022-03-11 23:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:44:57 --> Config Class Initialized
INFO - 2022-03-11 23:44:57 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:44:57 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:44:57 --> Utf8 Class Initialized
INFO - 2022-03-11 23:44:57 --> URI Class Initialized
INFO - 2022-03-11 23:44:57 --> Router Class Initialized
INFO - 2022-03-11 23:44:57 --> Output Class Initialized
INFO - 2022-03-11 23:44:57 --> Security Class Initialized
DEBUG - 2022-03-11 23:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:44:57 --> Input Class Initialized
INFO - 2022-03-11 23:44:57 --> Language Class Initialized
INFO - 2022-03-11 23:44:57 --> Loader Class Initialized
INFO - 2022-03-11 23:44:57 --> Helper loaded: url_helper
INFO - 2022-03-11 23:44:57 --> Helper loaded: form_helper
INFO - 2022-03-11 23:44:57 --> Helper loaded: common_helper
INFO - 2022-03-11 23:44:57 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:44:57 --> Controller Class Initialized
INFO - 2022-03-11 23:44:57 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:44:57 --> Encrypt Class Initialized
INFO - 2022-03-11 23:44:57 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:44:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:44:57 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:44:57 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:44:57 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:44:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:44:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:44:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:44:57 --> Final output sent to browser
DEBUG - 2022-03-11 23:44:57 --> Total execution time: 0.0451
ERROR - 2022-03-11 23:44:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:44:59 --> Config Class Initialized
INFO - 2022-03-11 23:44:59 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:44:59 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:44:59 --> Utf8 Class Initialized
INFO - 2022-03-11 23:44:59 --> URI Class Initialized
INFO - 2022-03-11 23:44:59 --> Router Class Initialized
INFO - 2022-03-11 23:44:59 --> Output Class Initialized
INFO - 2022-03-11 23:44:59 --> Security Class Initialized
DEBUG - 2022-03-11 23:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:44:59 --> Input Class Initialized
INFO - 2022-03-11 23:44:59 --> Language Class Initialized
ERROR - 2022-03-11 23:44:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-11 23:45:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:45:00 --> Config Class Initialized
INFO - 2022-03-11 23:45:00 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:45:00 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:45:00 --> Utf8 Class Initialized
INFO - 2022-03-11 23:45:00 --> URI Class Initialized
INFO - 2022-03-11 23:45:00 --> Router Class Initialized
INFO - 2022-03-11 23:45:00 --> Output Class Initialized
INFO - 2022-03-11 23:45:00 --> Security Class Initialized
DEBUG - 2022-03-11 23:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:45:00 --> Input Class Initialized
INFO - 2022-03-11 23:45:00 --> Language Class Initialized
INFO - 2022-03-11 23:45:00 --> Loader Class Initialized
INFO - 2022-03-11 23:45:00 --> Helper loaded: url_helper
INFO - 2022-03-11 23:45:00 --> Helper loaded: form_helper
INFO - 2022-03-11 23:45:00 --> Helper loaded: common_helper
INFO - 2022-03-11 23:45:00 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:45:00 --> Controller Class Initialized
INFO - 2022-03-11 23:45:00 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:45:00 --> Encrypt Class Initialized
INFO - 2022-03-11 23:45:00 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:45:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:45:00 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:45:00 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:45:00 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:45:00 --> Final output sent to browser
DEBUG - 2022-03-11 23:45:00 --> Total execution time: 0.0293
ERROR - 2022-03-11 23:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:48:16 --> Config Class Initialized
INFO - 2022-03-11 23:48:16 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:48:16 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:48:16 --> Utf8 Class Initialized
INFO - 2022-03-11 23:48:16 --> URI Class Initialized
INFO - 2022-03-11 23:48:16 --> Router Class Initialized
INFO - 2022-03-11 23:48:16 --> Output Class Initialized
INFO - 2022-03-11 23:48:16 --> Security Class Initialized
DEBUG - 2022-03-11 23:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:48:16 --> Input Class Initialized
INFO - 2022-03-11 23:48:16 --> Language Class Initialized
INFO - 2022-03-11 23:48:16 --> Loader Class Initialized
INFO - 2022-03-11 23:48:16 --> Helper loaded: url_helper
INFO - 2022-03-11 23:48:16 --> Helper loaded: form_helper
INFO - 2022-03-11 23:48:16 --> Helper loaded: common_helper
INFO - 2022-03-11 23:48:16 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:48:16 --> Controller Class Initialized
INFO - 2022-03-11 23:48:16 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:48:16 --> Encrypt Class Initialized
INFO - 2022-03-11 23:48:16 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:48:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:48:16 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:48:16 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:48:16 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:48:16 --> Final output sent to browser
DEBUG - 2022-03-11 23:48:16 --> Total execution time: 0.0241
ERROR - 2022-03-11 23:48:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:48:52 --> Config Class Initialized
INFO - 2022-03-11 23:48:52 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:48:52 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:48:52 --> Utf8 Class Initialized
INFO - 2022-03-11 23:48:52 --> URI Class Initialized
INFO - 2022-03-11 23:48:52 --> Router Class Initialized
INFO - 2022-03-11 23:48:52 --> Output Class Initialized
INFO - 2022-03-11 23:48:52 --> Security Class Initialized
DEBUG - 2022-03-11 23:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:48:52 --> Input Class Initialized
INFO - 2022-03-11 23:48:52 --> Language Class Initialized
ERROR - 2022-03-11 23:48:52 --> 404 Page Not Found: Karoclient/css
ERROR - 2022-03-11 23:50:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:50:48 --> Config Class Initialized
INFO - 2022-03-11 23:50:48 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:50:48 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:50:48 --> Utf8 Class Initialized
INFO - 2022-03-11 23:50:48 --> URI Class Initialized
INFO - 2022-03-11 23:50:48 --> Router Class Initialized
INFO - 2022-03-11 23:50:48 --> Output Class Initialized
INFO - 2022-03-11 23:50:48 --> Security Class Initialized
DEBUG - 2022-03-11 23:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:50:48 --> Input Class Initialized
INFO - 2022-03-11 23:50:48 --> Language Class Initialized
INFO - 2022-03-11 23:50:48 --> Loader Class Initialized
INFO - 2022-03-11 23:50:48 --> Helper loaded: url_helper
INFO - 2022-03-11 23:50:48 --> Helper loaded: form_helper
INFO - 2022-03-11 23:50:48 --> Helper loaded: common_helper
INFO - 2022-03-11 23:50:48 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:50:48 --> Controller Class Initialized
INFO - 2022-03-11 23:50:48 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:50:48 --> Encrypt Class Initialized
INFO - 2022-03-11 23:50:48 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:50:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:50:48 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:50:48 --> Model "Users_model" initialized
INFO - 2022-03-11 23:50:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:50:49 --> Config Class Initialized
INFO - 2022-03-11 23:50:49 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:50:49 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:50:49 --> Utf8 Class Initialized
INFO - 2022-03-11 23:50:49 --> URI Class Initialized
INFO - 2022-03-11 23:50:49 --> Router Class Initialized
INFO - 2022-03-11 23:50:49 --> Output Class Initialized
INFO - 2022-03-11 23:50:49 --> Security Class Initialized
DEBUG - 2022-03-11 23:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:50:49 --> Input Class Initialized
INFO - 2022-03-11 23:50:49 --> Language Class Initialized
INFO - 2022-03-11 23:50:49 --> Loader Class Initialized
INFO - 2022-03-11 23:50:49 --> Helper loaded: url_helper
INFO - 2022-03-11 23:50:49 --> Helper loaded: form_helper
INFO - 2022-03-11 23:50:49 --> Helper loaded: common_helper
INFO - 2022-03-11 23:50:49 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:50:49 --> Controller Class Initialized
INFO - 2022-03-11 23:50:49 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:50:49 --> Encrypt Class Initialized
INFO - 2022-03-11 23:50:49 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:50:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:50:49 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:50:49 --> Model "Users_model" initialized
INFO - 2022-03-11 23:50:49 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:50:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:50:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:50:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:50:49 --> Final output sent to browser
DEBUG - 2022-03-11 23:50:49 --> Total execution time: 0.0580
ERROR - 2022-03-11 23:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:50:56 --> Config Class Initialized
INFO - 2022-03-11 23:50:56 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:50:56 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:50:56 --> Utf8 Class Initialized
INFO - 2022-03-11 23:50:56 --> URI Class Initialized
INFO - 2022-03-11 23:50:56 --> Router Class Initialized
INFO - 2022-03-11 23:50:56 --> Output Class Initialized
INFO - 2022-03-11 23:50:56 --> Security Class Initialized
DEBUG - 2022-03-11 23:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:50:56 --> Input Class Initialized
INFO - 2022-03-11 23:50:56 --> Language Class Initialized
INFO - 2022-03-11 23:50:56 --> Loader Class Initialized
INFO - 2022-03-11 23:50:56 --> Helper loaded: url_helper
INFO - 2022-03-11 23:50:56 --> Helper loaded: form_helper
INFO - 2022-03-11 23:50:56 --> Helper loaded: common_helper
INFO - 2022-03-11 23:50:56 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:50:56 --> Controller Class Initialized
INFO - 2022-03-11 23:50:56 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:50:56 --> Encrypt Class Initialized
INFO - 2022-03-11 23:50:56 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:50:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:50:56 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:50:56 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:50:56 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:50:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:50:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:50:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:50:56 --> Final output sent to browser
DEBUG - 2022-03-11 23:50:56 --> Total execution time: 0.0557
ERROR - 2022-03-11 23:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:51:03 --> Config Class Initialized
INFO - 2022-03-11 23:51:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:51:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:51:03 --> Utf8 Class Initialized
INFO - 2022-03-11 23:51:03 --> URI Class Initialized
INFO - 2022-03-11 23:51:03 --> Router Class Initialized
INFO - 2022-03-11 23:51:03 --> Output Class Initialized
INFO - 2022-03-11 23:51:03 --> Security Class Initialized
DEBUG - 2022-03-11 23:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:51:03 --> Input Class Initialized
INFO - 2022-03-11 23:51:03 --> Language Class Initialized
INFO - 2022-03-11 23:51:03 --> Loader Class Initialized
INFO - 2022-03-11 23:51:03 --> Helper loaded: url_helper
INFO - 2022-03-11 23:51:03 --> Helper loaded: form_helper
INFO - 2022-03-11 23:51:03 --> Helper loaded: common_helper
INFO - 2022-03-11 23:51:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:51:03 --> Controller Class Initialized
INFO - 2022-03-11 23:51:03 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:51:03 --> Encrypt Class Initialized
INFO - 2022-03-11 23:51:03 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:51:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:51:03 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:51:03 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:51:03 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:51:03 --> Config Class Initialized
INFO - 2022-03-11 23:51:03 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:51:03 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:51:03 --> Utf8 Class Initialized
INFO - 2022-03-11 23:51:03 --> URI Class Initialized
INFO - 2022-03-11 23:51:03 --> Router Class Initialized
INFO - 2022-03-11 23:51:03 --> Output Class Initialized
INFO - 2022-03-11 23:51:03 --> Security Class Initialized
DEBUG - 2022-03-11 23:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:51:03 --> Input Class Initialized
INFO - 2022-03-11 23:51:03 --> Language Class Initialized
INFO - 2022-03-11 23:51:03 --> Loader Class Initialized
INFO - 2022-03-11 23:51:03 --> Helper loaded: url_helper
INFO - 2022-03-11 23:51:03 --> Helper loaded: form_helper
INFO - 2022-03-11 23:51:03 --> Helper loaded: common_helper
INFO - 2022-03-11 23:51:03 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:51:03 --> Controller Class Initialized
INFO - 2022-03-11 23:51:03 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:51:03 --> Encrypt Class Initialized
INFO - 2022-03-11 23:51:03 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:51:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:51:03 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:51:03 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:51:03 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:51:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:51:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-11 23:51:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:51:03 --> Final output sent to browser
DEBUG - 2022-03-11 23:51:03 --> Total execution time: 0.0434
ERROR - 2022-03-11 23:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:51:04 --> Config Class Initialized
INFO - 2022-03-11 23:51:04 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:51:04 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:51:04 --> Utf8 Class Initialized
INFO - 2022-03-11 23:51:04 --> URI Class Initialized
INFO - 2022-03-11 23:51:04 --> Router Class Initialized
INFO - 2022-03-11 23:51:04 --> Output Class Initialized
INFO - 2022-03-11 23:51:04 --> Security Class Initialized
DEBUG - 2022-03-11 23:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:51:04 --> Input Class Initialized
INFO - 2022-03-11 23:51:04 --> Language Class Initialized
INFO - 2022-03-11 23:51:04 --> Loader Class Initialized
INFO - 2022-03-11 23:51:04 --> Helper loaded: url_helper
INFO - 2022-03-11 23:51:04 --> Helper loaded: form_helper
INFO - 2022-03-11 23:51:04 --> Helper loaded: common_helper
INFO - 2022-03-11 23:51:04 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:51:04 --> Controller Class Initialized
INFO - 2022-03-11 23:51:04 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:51:04 --> Encrypt Class Initialized
INFO - 2022-03-11 23:51:04 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:51:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:51:04 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:51:04 --> Model "Users_model" initialized
INFO - 2022-03-11 23:51:04 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:51:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:51:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:51:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:51:04 --> Final output sent to browser
DEBUG - 2022-03-11 23:51:04 --> Total execution time: 0.0625
ERROR - 2022-03-11 23:51:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:51:42 --> Config Class Initialized
INFO - 2022-03-11 23:51:42 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:51:42 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:51:42 --> Utf8 Class Initialized
INFO - 2022-03-11 23:51:42 --> URI Class Initialized
INFO - 2022-03-11 23:51:42 --> Router Class Initialized
INFO - 2022-03-11 23:51:42 --> Output Class Initialized
INFO - 2022-03-11 23:51:42 --> Security Class Initialized
DEBUG - 2022-03-11 23:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:51:42 --> Input Class Initialized
INFO - 2022-03-11 23:51:42 --> Language Class Initialized
INFO - 2022-03-11 23:51:42 --> Loader Class Initialized
INFO - 2022-03-11 23:51:42 --> Helper loaded: url_helper
INFO - 2022-03-11 23:51:42 --> Helper loaded: form_helper
INFO - 2022-03-11 23:51:42 --> Helper loaded: common_helper
INFO - 2022-03-11 23:51:42 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:51:42 --> Controller Class Initialized
INFO - 2022-03-11 23:51:42 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:51:42 --> Encrypt Class Initialized
INFO - 2022-03-11 23:51:42 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:51:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:51:42 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:51:42 --> Model "Users_model" initialized
INFO - 2022-03-11 23:51:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:51:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:51:43 --> Config Class Initialized
INFO - 2022-03-11 23:51:43 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:51:43 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:51:43 --> Utf8 Class Initialized
INFO - 2022-03-11 23:51:43 --> URI Class Initialized
INFO - 2022-03-11 23:51:43 --> Router Class Initialized
INFO - 2022-03-11 23:51:43 --> Output Class Initialized
INFO - 2022-03-11 23:51:43 --> Security Class Initialized
DEBUG - 2022-03-11 23:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:51:43 --> Input Class Initialized
INFO - 2022-03-11 23:51:43 --> Language Class Initialized
INFO - 2022-03-11 23:51:43 --> Loader Class Initialized
INFO - 2022-03-11 23:51:43 --> Helper loaded: url_helper
INFO - 2022-03-11 23:51:43 --> Helper loaded: form_helper
INFO - 2022-03-11 23:51:43 --> Helper loaded: common_helper
INFO - 2022-03-11 23:51:43 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:51:43 --> Controller Class Initialized
INFO - 2022-03-11 23:51:43 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:51:43 --> Encrypt Class Initialized
INFO - 2022-03-11 23:51:43 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:51:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:51:43 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:51:43 --> Model "Users_model" initialized
INFO - 2022-03-11 23:51:43 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:51:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:51:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:51:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:51:43 --> Final output sent to browser
DEBUG - 2022-03-11 23:51:43 --> Total execution time: 0.0584
ERROR - 2022-03-11 23:52:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:52:07 --> Config Class Initialized
INFO - 2022-03-11 23:52:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:52:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:52:07 --> Utf8 Class Initialized
INFO - 2022-03-11 23:52:07 --> URI Class Initialized
INFO - 2022-03-11 23:52:07 --> Router Class Initialized
INFO - 2022-03-11 23:52:07 --> Output Class Initialized
INFO - 2022-03-11 23:52:07 --> Security Class Initialized
DEBUG - 2022-03-11 23:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:52:07 --> Input Class Initialized
INFO - 2022-03-11 23:52:07 --> Language Class Initialized
INFO - 2022-03-11 23:52:07 --> Loader Class Initialized
INFO - 2022-03-11 23:52:07 --> Helper loaded: url_helper
INFO - 2022-03-11 23:52:07 --> Helper loaded: form_helper
INFO - 2022-03-11 23:52:07 --> Helper loaded: common_helper
INFO - 2022-03-11 23:52:07 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:52:07 --> Controller Class Initialized
INFO - 2022-03-11 23:52:07 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:52:07 --> Encrypt Class Initialized
INFO - 2022-03-11 23:52:07 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:52:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:52:07 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:52:07 --> Model "Users_model" initialized
INFO - 2022-03-11 23:52:07 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:52:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:52:07 --> Config Class Initialized
INFO - 2022-03-11 23:52:07 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:52:07 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:52:07 --> Utf8 Class Initialized
INFO - 2022-03-11 23:52:07 --> URI Class Initialized
INFO - 2022-03-11 23:52:07 --> Router Class Initialized
INFO - 2022-03-11 23:52:07 --> Output Class Initialized
INFO - 2022-03-11 23:52:07 --> Security Class Initialized
DEBUG - 2022-03-11 23:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:52:07 --> Input Class Initialized
INFO - 2022-03-11 23:52:07 --> Language Class Initialized
INFO - 2022-03-11 23:52:07 --> Loader Class Initialized
INFO - 2022-03-11 23:52:07 --> Helper loaded: url_helper
INFO - 2022-03-11 23:52:07 --> Helper loaded: form_helper
INFO - 2022-03-11 23:52:07 --> Helper loaded: common_helper
INFO - 2022-03-11 23:52:07 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:52:07 --> Controller Class Initialized
INFO - 2022-03-11 23:52:07 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:52:07 --> Encrypt Class Initialized
INFO - 2022-03-11 23:52:07 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:52:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:52:07 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:52:07 --> Model "Users_model" initialized
INFO - 2022-03-11 23:52:07 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:52:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:52:07 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:52:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:52:07 --> Final output sent to browser
DEBUG - 2022-03-11 23:52:07 --> Total execution time: 0.0519
ERROR - 2022-03-11 23:52:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:52:30 --> Config Class Initialized
INFO - 2022-03-11 23:52:30 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:52:30 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:52:30 --> Utf8 Class Initialized
INFO - 2022-03-11 23:52:30 --> URI Class Initialized
INFO - 2022-03-11 23:52:30 --> Router Class Initialized
INFO - 2022-03-11 23:52:30 --> Output Class Initialized
INFO - 2022-03-11 23:52:30 --> Security Class Initialized
DEBUG - 2022-03-11 23:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:52:30 --> Input Class Initialized
INFO - 2022-03-11 23:52:30 --> Language Class Initialized
INFO - 2022-03-11 23:52:30 --> Loader Class Initialized
INFO - 2022-03-11 23:52:30 --> Helper loaded: url_helper
INFO - 2022-03-11 23:52:30 --> Helper loaded: form_helper
INFO - 2022-03-11 23:52:30 --> Helper loaded: common_helper
INFO - 2022-03-11 23:52:30 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:52:30 --> Controller Class Initialized
INFO - 2022-03-11 23:52:30 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:52:30 --> Encrypt Class Initialized
INFO - 2022-03-11 23:52:30 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:52:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:52:30 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:52:30 --> Model "Users_model" initialized
INFO - 2022-03-11 23:52:30 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:52:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:52:31 --> Config Class Initialized
INFO - 2022-03-11 23:52:31 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:52:31 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:52:31 --> Utf8 Class Initialized
INFO - 2022-03-11 23:52:31 --> URI Class Initialized
INFO - 2022-03-11 23:52:31 --> Router Class Initialized
INFO - 2022-03-11 23:52:31 --> Output Class Initialized
INFO - 2022-03-11 23:52:31 --> Security Class Initialized
DEBUG - 2022-03-11 23:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:52:31 --> Input Class Initialized
INFO - 2022-03-11 23:52:31 --> Language Class Initialized
INFO - 2022-03-11 23:52:31 --> Loader Class Initialized
INFO - 2022-03-11 23:52:31 --> Helper loaded: url_helper
INFO - 2022-03-11 23:52:31 --> Helper loaded: form_helper
INFO - 2022-03-11 23:52:31 --> Helper loaded: common_helper
INFO - 2022-03-11 23:52:31 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:52:31 --> Controller Class Initialized
INFO - 2022-03-11 23:52:31 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:52:31 --> Encrypt Class Initialized
INFO - 2022-03-11 23:52:31 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:52:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:52:31 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:52:31 --> Model "Users_model" initialized
INFO - 2022-03-11 23:52:31 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:52:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:52:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:52:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:52:31 --> Final output sent to browser
DEBUG - 2022-03-11 23:52:31 --> Total execution time: 0.0938
ERROR - 2022-03-11 23:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:54:45 --> Config Class Initialized
INFO - 2022-03-11 23:54:45 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:54:45 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:54:45 --> Utf8 Class Initialized
INFO - 2022-03-11 23:54:45 --> URI Class Initialized
INFO - 2022-03-11 23:54:45 --> Router Class Initialized
INFO - 2022-03-11 23:54:45 --> Output Class Initialized
INFO - 2022-03-11 23:54:45 --> Security Class Initialized
DEBUG - 2022-03-11 23:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:54:45 --> Input Class Initialized
INFO - 2022-03-11 23:54:45 --> Language Class Initialized
INFO - 2022-03-11 23:54:45 --> Loader Class Initialized
INFO - 2022-03-11 23:54:45 --> Helper loaded: url_helper
INFO - 2022-03-11 23:54:45 --> Helper loaded: form_helper
INFO - 2022-03-11 23:54:45 --> Helper loaded: common_helper
INFO - 2022-03-11 23:54:45 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:54:45 --> Controller Class Initialized
INFO - 2022-03-11 23:54:45 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:54:45 --> Encrypt Class Initialized
INFO - 2022-03-11 23:54:45 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:54:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:54:45 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:54:45 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:54:45 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:54:45 --> Upload Class Initialized
INFO - 2022-03-11 23:54:45 --> Final output sent to browser
DEBUG - 2022-03-11 23:54:45 --> Total execution time: 0.0330
ERROR - 2022-03-11 23:55:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:55:28 --> Config Class Initialized
INFO - 2022-03-11 23:55:28 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:55:28 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:55:28 --> Utf8 Class Initialized
INFO - 2022-03-11 23:55:28 --> URI Class Initialized
INFO - 2022-03-11 23:55:28 --> Router Class Initialized
INFO - 2022-03-11 23:55:28 --> Output Class Initialized
INFO - 2022-03-11 23:55:28 --> Security Class Initialized
DEBUG - 2022-03-11 23:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:55:28 --> Input Class Initialized
INFO - 2022-03-11 23:55:28 --> Language Class Initialized
INFO - 2022-03-11 23:55:28 --> Loader Class Initialized
INFO - 2022-03-11 23:55:28 --> Helper loaded: url_helper
INFO - 2022-03-11 23:55:28 --> Helper loaded: form_helper
INFO - 2022-03-11 23:55:28 --> Helper loaded: common_helper
INFO - 2022-03-11 23:55:28 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:55:28 --> Controller Class Initialized
INFO - 2022-03-11 23:55:28 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:55:28 --> Encrypt Class Initialized
INFO - 2022-03-11 23:55:28 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:55:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:55:28 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:55:28 --> Model "Users_model" initialized
INFO - 2022-03-11 23:55:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-11 23:55:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:55:29 --> Config Class Initialized
INFO - 2022-03-11 23:55:29 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:55:29 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:55:29 --> Utf8 Class Initialized
INFO - 2022-03-11 23:55:29 --> URI Class Initialized
INFO - 2022-03-11 23:55:29 --> Router Class Initialized
INFO - 2022-03-11 23:55:29 --> Output Class Initialized
INFO - 2022-03-11 23:55:29 --> Security Class Initialized
DEBUG - 2022-03-11 23:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:55:29 --> Input Class Initialized
INFO - 2022-03-11 23:55:29 --> Language Class Initialized
INFO - 2022-03-11 23:55:29 --> Loader Class Initialized
INFO - 2022-03-11 23:55:29 --> Helper loaded: url_helper
INFO - 2022-03-11 23:55:29 --> Helper loaded: form_helper
INFO - 2022-03-11 23:55:29 --> Helper loaded: common_helper
INFO - 2022-03-11 23:55:29 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:55:29 --> Controller Class Initialized
INFO - 2022-03-11 23:55:29 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:55:29 --> Encrypt Class Initialized
INFO - 2022-03-11 23:55:29 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:55:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:55:29 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:55:29 --> Model "Users_model" initialized
INFO - 2022-03-11 23:55:29 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:55:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:55:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-11 23:55:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:55:29 --> Final output sent to browser
DEBUG - 2022-03-11 23:55:29 --> Total execution time: 0.0548
ERROR - 2022-03-11 23:57:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:57:30 --> Config Class Initialized
INFO - 2022-03-11 23:57:30 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:57:30 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:57:30 --> Utf8 Class Initialized
INFO - 2022-03-11 23:57:30 --> URI Class Initialized
INFO - 2022-03-11 23:57:30 --> Router Class Initialized
INFO - 2022-03-11 23:57:30 --> Output Class Initialized
INFO - 2022-03-11 23:57:30 --> Security Class Initialized
DEBUG - 2022-03-11 23:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:57:30 --> Input Class Initialized
INFO - 2022-03-11 23:57:30 --> Language Class Initialized
INFO - 2022-03-11 23:57:30 --> Loader Class Initialized
INFO - 2022-03-11 23:57:30 --> Helper loaded: url_helper
INFO - 2022-03-11 23:57:30 --> Helper loaded: form_helper
INFO - 2022-03-11 23:57:30 --> Helper loaded: common_helper
INFO - 2022-03-11 23:57:30 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:57:30 --> Controller Class Initialized
INFO - 2022-03-11 23:57:30 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:57:30 --> Final output sent to browser
DEBUG - 2022-03-11 23:57:30 --> Total execution time: 0.0196
ERROR - 2022-03-11 23:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:57:47 --> Config Class Initialized
INFO - 2022-03-11 23:57:47 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:57:47 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:57:47 --> Utf8 Class Initialized
INFO - 2022-03-11 23:57:47 --> URI Class Initialized
INFO - 2022-03-11 23:57:47 --> Router Class Initialized
INFO - 2022-03-11 23:57:47 --> Output Class Initialized
INFO - 2022-03-11 23:57:47 --> Security Class Initialized
DEBUG - 2022-03-11 23:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:57:47 --> Input Class Initialized
INFO - 2022-03-11 23:57:47 --> Language Class Initialized
INFO - 2022-03-11 23:57:47 --> Loader Class Initialized
INFO - 2022-03-11 23:57:47 --> Helper loaded: url_helper
INFO - 2022-03-11 23:57:47 --> Helper loaded: form_helper
INFO - 2022-03-11 23:57:47 --> Helper loaded: common_helper
INFO - 2022-03-11 23:57:47 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:57:47 --> Controller Class Initialized
INFO - 2022-03-11 23:57:47 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:57:47 --> Final output sent to browser
DEBUG - 2022-03-11 23:57:47 --> Total execution time: 0.0198
ERROR - 2022-03-11 23:58:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:58:52 --> Config Class Initialized
INFO - 2022-03-11 23:58:52 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:58:52 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:58:52 --> Utf8 Class Initialized
INFO - 2022-03-11 23:58:52 --> URI Class Initialized
INFO - 2022-03-11 23:58:52 --> Router Class Initialized
INFO - 2022-03-11 23:58:52 --> Output Class Initialized
INFO - 2022-03-11 23:58:52 --> Security Class Initialized
DEBUG - 2022-03-11 23:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:58:52 --> Input Class Initialized
INFO - 2022-03-11 23:58:52 --> Language Class Initialized
INFO - 2022-03-11 23:58:52 --> Loader Class Initialized
INFO - 2022-03-11 23:58:52 --> Helper loaded: url_helper
INFO - 2022-03-11 23:58:52 --> Helper loaded: form_helper
INFO - 2022-03-11 23:58:52 --> Helper loaded: common_helper
INFO - 2022-03-11 23:58:52 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:58:52 --> Controller Class Initialized
INFO - 2022-03-11 23:58:52 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:58:52 --> Encrypt Class Initialized
INFO - 2022-03-11 23:58:52 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:58:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:58:52 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:58:52 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:58:52 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:58:52 --> Final output sent to browser
DEBUG - 2022-03-11 23:58:52 --> Total execution time: 0.0256
ERROR - 2022-03-11 23:59:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:59:21 --> Config Class Initialized
INFO - 2022-03-11 23:59:21 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:59:21 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:59:21 --> Utf8 Class Initialized
INFO - 2022-03-11 23:59:21 --> URI Class Initialized
INFO - 2022-03-11 23:59:21 --> Router Class Initialized
INFO - 2022-03-11 23:59:21 --> Output Class Initialized
INFO - 2022-03-11 23:59:21 --> Security Class Initialized
DEBUG - 2022-03-11 23:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:59:21 --> Input Class Initialized
INFO - 2022-03-11 23:59:21 --> Language Class Initialized
INFO - 2022-03-11 23:59:21 --> Loader Class Initialized
INFO - 2022-03-11 23:59:21 --> Helper loaded: url_helper
INFO - 2022-03-11 23:59:21 --> Helper loaded: form_helper
INFO - 2022-03-11 23:59:21 --> Helper loaded: common_helper
INFO - 2022-03-11 23:59:21 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:59:21 --> Controller Class Initialized
INFO - 2022-03-11 23:59:21 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:59:21 --> Encrypt Class Initialized
INFO - 2022-03-11 23:59:21 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:59:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:59:21 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:59:21 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:59:21 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:59:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:59:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 23:59:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:59:21 --> Final output sent to browser
DEBUG - 2022-03-11 23:59:21 --> Total execution time: 0.0505
ERROR - 2022-03-11 23:59:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:59:23 --> Config Class Initialized
INFO - 2022-03-11 23:59:23 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:59:23 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:59:23 --> Utf8 Class Initialized
INFO - 2022-03-11 23:59:23 --> URI Class Initialized
INFO - 2022-03-11 23:59:23 --> Router Class Initialized
INFO - 2022-03-11 23:59:23 --> Output Class Initialized
INFO - 2022-03-11 23:59:23 --> Security Class Initialized
DEBUG - 2022-03-11 23:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:59:23 --> Input Class Initialized
INFO - 2022-03-11 23:59:23 --> Language Class Initialized
INFO - 2022-03-11 23:59:23 --> Loader Class Initialized
INFO - 2022-03-11 23:59:23 --> Helper loaded: url_helper
INFO - 2022-03-11 23:59:23 --> Helper loaded: form_helper
INFO - 2022-03-11 23:59:23 --> Helper loaded: common_helper
INFO - 2022-03-11 23:59:23 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:59:23 --> Controller Class Initialized
INFO - 2022-03-11 23:59:23 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:59:23 --> Encrypt Class Initialized
INFO - 2022-03-11 23:59:23 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:59:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:59:23 --> Model "Referredby_model" initialized
INFO - 2022-03-11 23:59:23 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:59:23 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:59:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-11 23:59:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-11 23:59:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-11 23:59:23 --> Final output sent to browser
DEBUG - 2022-03-11 23:59:23 --> Total execution time: 0.0469
ERROR - 2022-03-11 23:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-11 23:59:35 --> Config Class Initialized
INFO - 2022-03-11 23:59:35 --> Hooks Class Initialized
DEBUG - 2022-03-11 23:59:35 --> UTF-8 Support Enabled
INFO - 2022-03-11 23:59:35 --> Utf8 Class Initialized
INFO - 2022-03-11 23:59:35 --> URI Class Initialized
INFO - 2022-03-11 23:59:35 --> Router Class Initialized
INFO - 2022-03-11 23:59:35 --> Output Class Initialized
INFO - 2022-03-11 23:59:35 --> Security Class Initialized
DEBUG - 2022-03-11 23:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-11 23:59:35 --> Input Class Initialized
INFO - 2022-03-11 23:59:35 --> Language Class Initialized
INFO - 2022-03-11 23:59:35 --> Loader Class Initialized
INFO - 2022-03-11 23:59:35 --> Helper loaded: url_helper
INFO - 2022-03-11 23:59:35 --> Helper loaded: form_helper
INFO - 2022-03-11 23:59:35 --> Helper loaded: common_helper
INFO - 2022-03-11 23:59:36 --> Database Driver Class Initialized
DEBUG - 2022-03-11 23:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-11 23:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-11 23:59:36 --> Controller Class Initialized
INFO - 2022-03-11 23:59:36 --> Form Validation Class Initialized
DEBUG - 2022-03-11 23:59:36 --> Encrypt Class Initialized
INFO - 2022-03-11 23:59:36 --> Model "Patient_model" initialized
INFO - 2022-03-11 23:59:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-11 23:59:36 --> Model "Prefix_master" initialized
INFO - 2022-03-11 23:59:36 --> Model "Users_model" initialized
INFO - 2022-03-11 23:59:36 --> Model "Hospital_model" initialized
INFO - 2022-03-11 23:59:36 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-11 23:59:37 --> Final output sent to browser
DEBUG - 2022-03-11 23:59:37 --> Total execution time: 1.1586
