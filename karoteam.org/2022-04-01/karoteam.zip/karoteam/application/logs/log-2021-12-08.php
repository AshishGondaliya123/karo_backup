<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-08 00:30:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 00:30:45 --> Config Class Initialized
INFO - 2021-12-08 00:30:45 --> Hooks Class Initialized
DEBUG - 2021-12-08 00:30:45 --> UTF-8 Support Enabled
INFO - 2021-12-08 00:30:45 --> Utf8 Class Initialized
INFO - 2021-12-08 00:30:45 --> URI Class Initialized
DEBUG - 2021-12-08 00:30:45 --> No URI present. Default controller set.
INFO - 2021-12-08 00:30:45 --> Router Class Initialized
INFO - 2021-12-08 00:30:45 --> Output Class Initialized
INFO - 2021-12-08 00:30:45 --> Security Class Initialized
DEBUG - 2021-12-08 00:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 00:30:45 --> Input Class Initialized
INFO - 2021-12-08 00:30:45 --> Language Class Initialized
INFO - 2021-12-08 00:30:45 --> Loader Class Initialized
INFO - 2021-12-08 00:30:45 --> Helper loaded: url_helper
INFO - 2021-12-08 00:30:45 --> Helper loaded: form_helper
INFO - 2021-12-08 00:30:45 --> Helper loaded: common_helper
INFO - 2021-12-08 00:30:45 --> Database Driver Class Initialized
DEBUG - 2021-12-08 00:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 00:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 00:30:45 --> Controller Class Initialized
INFO - 2021-12-08 00:30:45 --> Form Validation Class Initialized
DEBUG - 2021-12-08 00:30:45 --> Encrypt Class Initialized
DEBUG - 2021-12-08 00:30:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 00:30:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 00:30:45 --> Email Class Initialized
INFO - 2021-12-08 00:30:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 00:30:45 --> Calendar Class Initialized
INFO - 2021-12-08 00:30:45 --> Model "Login_model" initialized
INFO - 2021-12-08 00:30:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 00:30:45 --> Final output sent to browser
DEBUG - 2021-12-08 00:30:45 --> Total execution time: 0.0303
ERROR - 2021-12-08 08:28:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 08:28:24 --> Config Class Initialized
INFO - 2021-12-08 08:28:24 --> Hooks Class Initialized
DEBUG - 2021-12-08 08:28:24 --> UTF-8 Support Enabled
INFO - 2021-12-08 08:28:24 --> Utf8 Class Initialized
INFO - 2021-12-08 08:28:24 --> URI Class Initialized
DEBUG - 2021-12-08 08:28:24 --> No URI present. Default controller set.
INFO - 2021-12-08 08:28:24 --> Router Class Initialized
INFO - 2021-12-08 08:28:24 --> Output Class Initialized
INFO - 2021-12-08 08:28:24 --> Security Class Initialized
DEBUG - 2021-12-08 08:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 08:28:24 --> Input Class Initialized
INFO - 2021-12-08 08:28:24 --> Language Class Initialized
INFO - 2021-12-08 08:28:24 --> Loader Class Initialized
INFO - 2021-12-08 08:28:24 --> Helper loaded: url_helper
INFO - 2021-12-08 08:28:24 --> Helper loaded: form_helper
INFO - 2021-12-08 08:28:24 --> Helper loaded: common_helper
INFO - 2021-12-08 08:28:24 --> Database Driver Class Initialized
DEBUG - 2021-12-08 08:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 08:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 08:28:24 --> Controller Class Initialized
INFO - 2021-12-08 08:28:24 --> Form Validation Class Initialized
DEBUG - 2021-12-08 08:28:24 --> Encrypt Class Initialized
DEBUG - 2021-12-08 08:28:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 08:28:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 08:28:24 --> Email Class Initialized
INFO - 2021-12-08 08:28:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 08:28:24 --> Calendar Class Initialized
INFO - 2021-12-08 08:28:24 --> Model "Login_model" initialized
INFO - 2021-12-08 08:28:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 08:28:24 --> Final output sent to browser
DEBUG - 2021-12-08 08:28:24 --> Total execution time: 0.0264
ERROR - 2021-12-08 09:19:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 09:19:15 --> Config Class Initialized
INFO - 2021-12-08 09:19:15 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:19:15 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:19:15 --> Utf8 Class Initialized
INFO - 2021-12-08 09:19:15 --> URI Class Initialized
DEBUG - 2021-12-08 09:19:15 --> No URI present. Default controller set.
INFO - 2021-12-08 09:19:15 --> Router Class Initialized
INFO - 2021-12-08 09:19:15 --> Output Class Initialized
INFO - 2021-12-08 09:19:15 --> Security Class Initialized
DEBUG - 2021-12-08 09:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:19:15 --> Input Class Initialized
INFO - 2021-12-08 09:19:15 --> Language Class Initialized
INFO - 2021-12-08 09:19:15 --> Loader Class Initialized
INFO - 2021-12-08 09:19:15 --> Helper loaded: url_helper
INFO - 2021-12-08 09:19:15 --> Helper loaded: form_helper
INFO - 2021-12-08 09:19:15 --> Helper loaded: common_helper
INFO - 2021-12-08 09:19:15 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:19:15 --> Controller Class Initialized
INFO - 2021-12-08 09:19:15 --> Form Validation Class Initialized
DEBUG - 2021-12-08 09:19:15 --> Encrypt Class Initialized
DEBUG - 2021-12-08 09:19:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 09:19:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 09:19:15 --> Email Class Initialized
INFO - 2021-12-08 09:19:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 09:19:15 --> Calendar Class Initialized
INFO - 2021-12-08 09:19:15 --> Model "Login_model" initialized
INFO - 2021-12-08 09:19:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 09:19:15 --> Final output sent to browser
DEBUG - 2021-12-08 09:19:15 --> Total execution time: 0.0253
ERROR - 2021-12-08 09:22:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 09:22:28 --> Config Class Initialized
INFO - 2021-12-08 09:22:28 --> Hooks Class Initialized
DEBUG - 2021-12-08 09:22:28 --> UTF-8 Support Enabled
INFO - 2021-12-08 09:22:28 --> Utf8 Class Initialized
INFO - 2021-12-08 09:22:28 --> URI Class Initialized
DEBUG - 2021-12-08 09:22:28 --> No URI present. Default controller set.
INFO - 2021-12-08 09:22:28 --> Router Class Initialized
INFO - 2021-12-08 09:22:28 --> Output Class Initialized
INFO - 2021-12-08 09:22:28 --> Security Class Initialized
DEBUG - 2021-12-08 09:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 09:22:28 --> Input Class Initialized
INFO - 2021-12-08 09:22:28 --> Language Class Initialized
INFO - 2021-12-08 09:22:28 --> Loader Class Initialized
INFO - 2021-12-08 09:22:28 --> Helper loaded: url_helper
INFO - 2021-12-08 09:22:28 --> Helper loaded: form_helper
INFO - 2021-12-08 09:22:28 --> Helper loaded: common_helper
INFO - 2021-12-08 09:22:28 --> Database Driver Class Initialized
DEBUG - 2021-12-08 09:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 09:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 09:22:28 --> Controller Class Initialized
INFO - 2021-12-08 09:22:28 --> Form Validation Class Initialized
DEBUG - 2021-12-08 09:22:28 --> Encrypt Class Initialized
DEBUG - 2021-12-08 09:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 09:22:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 09:22:28 --> Email Class Initialized
INFO - 2021-12-08 09:22:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 09:22:28 --> Calendar Class Initialized
INFO - 2021-12-08 09:22:28 --> Model "Login_model" initialized
INFO - 2021-12-08 09:22:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 09:22:28 --> Final output sent to browser
DEBUG - 2021-12-08 09:22:28 --> Total execution time: 0.0331
ERROR - 2021-12-08 10:32:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 10:32:56 --> Config Class Initialized
INFO - 2021-12-08 10:32:56 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:32:56 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:32:56 --> Utf8 Class Initialized
INFO - 2021-12-08 10:32:56 --> URI Class Initialized
DEBUG - 2021-12-08 10:32:56 --> No URI present. Default controller set.
INFO - 2021-12-08 10:32:56 --> Router Class Initialized
INFO - 2021-12-08 10:32:56 --> Output Class Initialized
INFO - 2021-12-08 10:32:56 --> Security Class Initialized
DEBUG - 2021-12-08 10:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:32:56 --> Input Class Initialized
INFO - 2021-12-08 10:32:56 --> Language Class Initialized
INFO - 2021-12-08 10:32:56 --> Loader Class Initialized
INFO - 2021-12-08 10:32:56 --> Helper loaded: url_helper
INFO - 2021-12-08 10:32:56 --> Helper loaded: form_helper
INFO - 2021-12-08 10:32:56 --> Helper loaded: common_helper
INFO - 2021-12-08 10:32:56 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:32:56 --> Controller Class Initialized
INFO - 2021-12-08 10:32:56 --> Form Validation Class Initialized
DEBUG - 2021-12-08 10:32:56 --> Encrypt Class Initialized
DEBUG - 2021-12-08 10:32:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 10:32:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 10:32:56 --> Email Class Initialized
INFO - 2021-12-08 10:32:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 10:32:56 --> Calendar Class Initialized
INFO - 2021-12-08 10:32:56 --> Model "Login_model" initialized
INFO - 2021-12-08 10:32:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 10:32:56 --> Final output sent to browser
DEBUG - 2021-12-08 10:32:56 --> Total execution time: 0.0226
ERROR - 2021-12-08 10:34:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 10:34:03 --> Config Class Initialized
INFO - 2021-12-08 10:34:03 --> Hooks Class Initialized
DEBUG - 2021-12-08 10:34:03 --> UTF-8 Support Enabled
INFO - 2021-12-08 10:34:03 --> Utf8 Class Initialized
INFO - 2021-12-08 10:34:03 --> URI Class Initialized
DEBUG - 2021-12-08 10:34:03 --> No URI present. Default controller set.
INFO - 2021-12-08 10:34:03 --> Router Class Initialized
INFO - 2021-12-08 10:34:03 --> Output Class Initialized
INFO - 2021-12-08 10:34:03 --> Security Class Initialized
DEBUG - 2021-12-08 10:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 10:34:03 --> Input Class Initialized
INFO - 2021-12-08 10:34:03 --> Language Class Initialized
INFO - 2021-12-08 10:34:03 --> Loader Class Initialized
INFO - 2021-12-08 10:34:03 --> Helper loaded: url_helper
INFO - 2021-12-08 10:34:03 --> Helper loaded: form_helper
INFO - 2021-12-08 10:34:03 --> Helper loaded: common_helper
INFO - 2021-12-08 10:34:03 --> Database Driver Class Initialized
DEBUG - 2021-12-08 10:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 10:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 10:34:03 --> Controller Class Initialized
INFO - 2021-12-08 10:34:03 --> Form Validation Class Initialized
DEBUG - 2021-12-08 10:34:03 --> Encrypt Class Initialized
DEBUG - 2021-12-08 10:34:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 10:34:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 10:34:03 --> Email Class Initialized
INFO - 2021-12-08 10:34:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 10:34:03 --> Calendar Class Initialized
INFO - 2021-12-08 10:34:03 --> Model "Login_model" initialized
INFO - 2021-12-08 10:34:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 10:34:03 --> Final output sent to browser
DEBUG - 2021-12-08 10:34:03 --> Total execution time: 0.0349
ERROR - 2021-12-08 14:21:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 14:21:01 --> Config Class Initialized
INFO - 2021-12-08 14:21:01 --> Hooks Class Initialized
DEBUG - 2021-12-08 14:21:01 --> UTF-8 Support Enabled
INFO - 2021-12-08 14:21:01 --> Utf8 Class Initialized
INFO - 2021-12-08 14:21:01 --> URI Class Initialized
DEBUG - 2021-12-08 14:21:01 --> No URI present. Default controller set.
INFO - 2021-12-08 14:21:01 --> Router Class Initialized
INFO - 2021-12-08 14:21:01 --> Output Class Initialized
INFO - 2021-12-08 14:21:01 --> Security Class Initialized
DEBUG - 2021-12-08 14:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 14:21:01 --> Input Class Initialized
INFO - 2021-12-08 14:21:01 --> Language Class Initialized
INFO - 2021-12-08 14:21:01 --> Loader Class Initialized
INFO - 2021-12-08 14:21:01 --> Helper loaded: url_helper
INFO - 2021-12-08 14:21:01 --> Helper loaded: form_helper
INFO - 2021-12-08 14:21:01 --> Helper loaded: common_helper
INFO - 2021-12-08 14:21:01 --> Database Driver Class Initialized
DEBUG - 2021-12-08 14:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 14:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 14:21:01 --> Controller Class Initialized
INFO - 2021-12-08 14:21:01 --> Form Validation Class Initialized
DEBUG - 2021-12-08 14:21:01 --> Encrypt Class Initialized
DEBUG - 2021-12-08 14:21:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 14:21:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 14:21:01 --> Email Class Initialized
INFO - 2021-12-08 14:21:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 14:21:01 --> Calendar Class Initialized
INFO - 2021-12-08 14:21:01 --> Model "Login_model" initialized
INFO - 2021-12-08 14:21:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 14:21:01 --> Final output sent to browser
DEBUG - 2021-12-08 14:21:01 --> Total execution time: 0.0382
ERROR - 2021-12-08 14:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 14:21:03 --> Config Class Initialized
INFO - 2021-12-08 14:21:03 --> Hooks Class Initialized
DEBUG - 2021-12-08 14:21:03 --> UTF-8 Support Enabled
INFO - 2021-12-08 14:21:03 --> Utf8 Class Initialized
INFO - 2021-12-08 14:21:03 --> URI Class Initialized
INFO - 2021-12-08 14:21:03 --> Router Class Initialized
INFO - 2021-12-08 14:21:03 --> Output Class Initialized
INFO - 2021-12-08 14:21:03 --> Security Class Initialized
DEBUG - 2021-12-08 14:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 14:21:03 --> Input Class Initialized
INFO - 2021-12-08 14:21:03 --> Language Class Initialized
ERROR - 2021-12-08 14:21:03 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-08 14:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 14:21:09 --> Config Class Initialized
INFO - 2021-12-08 14:21:09 --> Hooks Class Initialized
DEBUG - 2021-12-08 14:21:09 --> UTF-8 Support Enabled
INFO - 2021-12-08 14:21:09 --> Utf8 Class Initialized
INFO - 2021-12-08 14:21:09 --> URI Class Initialized
DEBUG - 2021-12-08 14:21:09 --> No URI present. Default controller set.
INFO - 2021-12-08 14:21:09 --> Router Class Initialized
INFO - 2021-12-08 14:21:09 --> Output Class Initialized
INFO - 2021-12-08 14:21:09 --> Security Class Initialized
DEBUG - 2021-12-08 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 14:21:09 --> Input Class Initialized
INFO - 2021-12-08 14:21:09 --> Language Class Initialized
INFO - 2021-12-08 14:21:09 --> Loader Class Initialized
INFO - 2021-12-08 14:21:09 --> Helper loaded: url_helper
INFO - 2021-12-08 14:21:09 --> Helper loaded: form_helper
INFO - 2021-12-08 14:21:09 --> Helper loaded: common_helper
INFO - 2021-12-08 14:21:09 --> Database Driver Class Initialized
DEBUG - 2021-12-08 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 14:21:09 --> Controller Class Initialized
INFO - 2021-12-08 14:21:09 --> Form Validation Class Initialized
DEBUG - 2021-12-08 14:21:09 --> Encrypt Class Initialized
DEBUG - 2021-12-08 14:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 14:21:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 14:21:09 --> Email Class Initialized
INFO - 2021-12-08 14:21:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 14:21:09 --> Calendar Class Initialized
INFO - 2021-12-08 14:21:09 --> Model "Login_model" initialized
INFO - 2021-12-08 14:21:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 14:21:09 --> Final output sent to browser
DEBUG - 2021-12-08 14:21:09 --> Total execution time: 0.0229
ERROR - 2021-12-08 14:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 14:21:10 --> Config Class Initialized
INFO - 2021-12-08 14:21:10 --> Hooks Class Initialized
DEBUG - 2021-12-08 14:21:10 --> UTF-8 Support Enabled
INFO - 2021-12-08 14:21:10 --> Utf8 Class Initialized
INFO - 2021-12-08 14:21:10 --> URI Class Initialized
INFO - 2021-12-08 14:21:10 --> Router Class Initialized
INFO - 2021-12-08 14:21:10 --> Output Class Initialized
INFO - 2021-12-08 14:21:10 --> Security Class Initialized
DEBUG - 2021-12-08 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 14:21:10 --> Input Class Initialized
INFO - 2021-12-08 14:21:10 --> Language Class Initialized
INFO - 2021-12-08 14:21:10 --> Loader Class Initialized
INFO - 2021-12-08 14:21:10 --> Helper loaded: url_helper
INFO - 2021-12-08 14:21:10 --> Helper loaded: form_helper
INFO - 2021-12-08 14:21:10 --> Helper loaded: common_helper
INFO - 2021-12-08 14:21:10 --> Database Driver Class Initialized
DEBUG - 2021-12-08 14:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 14:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 14:21:10 --> Controller Class Initialized
INFO - 2021-12-08 14:21:10 --> Form Validation Class Initialized
DEBUG - 2021-12-08 14:21:10 --> Encrypt Class Initialized
DEBUG - 2021-12-08 14:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 14:21:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 14:21:10 --> Email Class Initialized
INFO - 2021-12-08 14:21:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 14:21:10 --> Calendar Class Initialized
INFO - 2021-12-08 14:21:10 --> Model "Login_model" initialized
INFO - 2021-12-08 14:21:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 14:21:10 --> Final output sent to browser
DEBUG - 2021-12-08 14:21:10 --> Total execution time: 0.0223
ERROR - 2021-12-08 14:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 14:21:10 --> Config Class Initialized
INFO - 2021-12-08 14:21:10 --> Hooks Class Initialized
DEBUG - 2021-12-08 14:21:10 --> UTF-8 Support Enabled
INFO - 2021-12-08 14:21:10 --> Utf8 Class Initialized
INFO - 2021-12-08 14:21:10 --> URI Class Initialized
INFO - 2021-12-08 14:21:10 --> Router Class Initialized
INFO - 2021-12-08 14:21:10 --> Output Class Initialized
INFO - 2021-12-08 14:21:10 --> Security Class Initialized
DEBUG - 2021-12-08 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 14:21:10 --> Input Class Initialized
INFO - 2021-12-08 14:21:10 --> Language Class Initialized
INFO - 2021-12-08 14:21:10 --> Loader Class Initialized
INFO - 2021-12-08 14:21:10 --> Helper loaded: url_helper
INFO - 2021-12-08 14:21:10 --> Helper loaded: form_helper
INFO - 2021-12-08 14:21:10 --> Helper loaded: common_helper
INFO - 2021-12-08 14:21:10 --> Database Driver Class Initialized
DEBUG - 2021-12-08 14:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 14:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 14:21:10 --> Controller Class Initialized
INFO - 2021-12-08 14:21:10 --> Form Validation Class Initialized
DEBUG - 2021-12-08 14:21:10 --> Encrypt Class Initialized
DEBUG - 2021-12-08 14:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 14:21:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 14:21:10 --> Email Class Initialized
INFO - 2021-12-08 14:21:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 14:21:10 --> Calendar Class Initialized
INFO - 2021-12-08 14:21:10 --> Model "Login_model" initialized
ERROR - 2021-12-08 14:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 14:21:11 --> Config Class Initialized
INFO - 2021-12-08 14:21:11 --> Hooks Class Initialized
DEBUG - 2021-12-08 14:21:11 --> UTF-8 Support Enabled
INFO - 2021-12-08 14:21:11 --> Utf8 Class Initialized
INFO - 2021-12-08 14:21:11 --> URI Class Initialized
INFO - 2021-12-08 14:21:11 --> Router Class Initialized
INFO - 2021-12-08 14:21:11 --> Output Class Initialized
INFO - 2021-12-08 14:21:11 --> Security Class Initialized
DEBUG - 2021-12-08 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 14:21:11 --> Input Class Initialized
INFO - 2021-12-08 14:21:11 --> Language Class Initialized
INFO - 2021-12-08 14:21:11 --> Loader Class Initialized
INFO - 2021-12-08 14:21:11 --> Helper loaded: url_helper
INFO - 2021-12-08 14:21:11 --> Helper loaded: form_helper
INFO - 2021-12-08 14:21:11 --> Helper loaded: common_helper
INFO - 2021-12-08 14:21:11 --> Database Driver Class Initialized
DEBUG - 2021-12-08 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 14:21:11 --> Controller Class Initialized
INFO - 2021-12-08 14:21:11 --> Form Validation Class Initialized
DEBUG - 2021-12-08 14:21:11 --> Encrypt Class Initialized
DEBUG - 2021-12-08 14:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 14:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 14:21:11 --> Email Class Initialized
INFO - 2021-12-08 14:21:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 14:21:11 --> Calendar Class Initialized
INFO - 2021-12-08 14:21:11 --> Model "Login_model" initialized
ERROR - 2021-12-08 19:42:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-08 19:42:09 --> Config Class Initialized
INFO - 2021-12-08 19:42:09 --> Hooks Class Initialized
DEBUG - 2021-12-08 19:42:09 --> UTF-8 Support Enabled
INFO - 2021-12-08 19:42:09 --> Utf8 Class Initialized
INFO - 2021-12-08 19:42:09 --> URI Class Initialized
DEBUG - 2021-12-08 19:42:09 --> No URI present. Default controller set.
INFO - 2021-12-08 19:42:09 --> Router Class Initialized
INFO - 2021-12-08 19:42:09 --> Output Class Initialized
INFO - 2021-12-08 19:42:09 --> Security Class Initialized
DEBUG - 2021-12-08 19:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-08 19:42:09 --> Input Class Initialized
INFO - 2021-12-08 19:42:09 --> Language Class Initialized
INFO - 2021-12-08 19:42:09 --> Loader Class Initialized
INFO - 2021-12-08 19:42:09 --> Helper loaded: url_helper
INFO - 2021-12-08 19:42:09 --> Helper loaded: form_helper
INFO - 2021-12-08 19:42:09 --> Helper loaded: common_helper
INFO - 2021-12-08 19:42:09 --> Database Driver Class Initialized
DEBUG - 2021-12-08 19:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-08 19:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-08 19:42:09 --> Controller Class Initialized
INFO - 2021-12-08 19:42:09 --> Form Validation Class Initialized
DEBUG - 2021-12-08 19:42:09 --> Encrypt Class Initialized
DEBUG - 2021-12-08 19:42:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-08 19:42:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-08 19:42:09 --> Email Class Initialized
INFO - 2021-12-08 19:42:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-08 19:42:09 --> Calendar Class Initialized
INFO - 2021-12-08 19:42:09 --> Model "Login_model" initialized
INFO - 2021-12-08 19:42:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-08 19:42:09 --> Final output sent to browser
DEBUG - 2021-12-08 19:42:09 --> Total execution time: 0.0230
