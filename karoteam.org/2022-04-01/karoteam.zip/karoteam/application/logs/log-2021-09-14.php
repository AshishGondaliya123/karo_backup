<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-14 08:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 08:02:27 --> Config Class Initialized
INFO - 2021-09-14 08:02:27 --> Hooks Class Initialized
DEBUG - 2021-09-14 08:02:27 --> UTF-8 Support Enabled
INFO - 2021-09-14 08:02:27 --> Utf8 Class Initialized
INFO - 2021-09-14 08:02:27 --> URI Class Initialized
DEBUG - 2021-09-14 08:02:27 --> No URI present. Default controller set.
INFO - 2021-09-14 08:02:27 --> Router Class Initialized
INFO - 2021-09-14 08:02:27 --> Output Class Initialized
INFO - 2021-09-14 08:02:27 --> Security Class Initialized
DEBUG - 2021-09-14 08:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 08:02:27 --> Input Class Initialized
INFO - 2021-09-14 08:02:27 --> Language Class Initialized
INFO - 2021-09-14 08:02:27 --> Loader Class Initialized
INFO - 2021-09-14 08:02:27 --> Helper loaded: url_helper
INFO - 2021-09-14 08:02:27 --> Helper loaded: form_helper
INFO - 2021-09-14 08:02:27 --> Helper loaded: common_helper
INFO - 2021-09-14 08:02:27 --> Database Driver Class Initialized
DEBUG - 2021-09-14 08:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-14 08:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-14 08:02:27 --> Controller Class Initialized
INFO - 2021-09-14 08:02:27 --> Form Validation Class Initialized
DEBUG - 2021-09-14 08:02:27 --> Encrypt Class Initialized
DEBUG - 2021-09-14 08:02:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-14 08:02:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-14 08:02:27 --> Email Class Initialized
INFO - 2021-09-14 08:02:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-14 08:02:27 --> Calendar Class Initialized
INFO - 2021-09-14 08:02:27 --> Model "Login_model" initialized
INFO - 2021-09-14 08:02:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-14 08:02:27 --> Final output sent to browser
DEBUG - 2021-09-14 08:02:27 --> Total execution time: 0.0620
ERROR - 2021-09-14 14:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:41 --> Config Class Initialized
INFO - 2021-09-14 14:02:41 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:41 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:41 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:41 --> URI Class Initialized
DEBUG - 2021-09-14 14:02:41 --> No URI present. Default controller set.
INFO - 2021-09-14 14:02:41 --> Router Class Initialized
INFO - 2021-09-14 14:02:41 --> Output Class Initialized
INFO - 2021-09-14 14:02:41 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:41 --> Input Class Initialized
INFO - 2021-09-14 14:02:41 --> Language Class Initialized
INFO - 2021-09-14 14:02:41 --> Loader Class Initialized
INFO - 2021-09-14 14:02:41 --> Helper loaded: url_helper
INFO - 2021-09-14 14:02:41 --> Helper loaded: form_helper
INFO - 2021-09-14 14:02:41 --> Helper loaded: common_helper
INFO - 2021-09-14 14:02:41 --> Database Driver Class Initialized
DEBUG - 2021-09-14 14:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-14 14:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-14 14:02:41 --> Controller Class Initialized
INFO - 2021-09-14 14:02:41 --> Form Validation Class Initialized
DEBUG - 2021-09-14 14:02:41 --> Encrypt Class Initialized
DEBUG - 2021-09-14 14:02:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-14 14:02:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-14 14:02:41 --> Email Class Initialized
INFO - 2021-09-14 14:02:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-14 14:02:41 --> Calendar Class Initialized
INFO - 2021-09-14 14:02:41 --> Model "Login_model" initialized
INFO - 2021-09-14 14:02:41 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-14 14:02:41 --> Final output sent to browser
DEBUG - 2021-09-14 14:02:41 --> Total execution time: 0.0831
ERROR - 2021-09-14 14:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:41 --> Config Class Initialized
INFO - 2021-09-14 14:02:41 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:41 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:41 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:41 --> URI Class Initialized
INFO - 2021-09-14 14:02:41 --> Router Class Initialized
INFO - 2021-09-14 14:02:41 --> Output Class Initialized
INFO - 2021-09-14 14:02:41 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:41 --> Input Class Initialized
INFO - 2021-09-14 14:02:41 --> Language Class Initialized
ERROR - 2021-09-14 14:02:41 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-09-14 14:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:43 --> Config Class Initialized
INFO - 2021-09-14 14:02:43 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:43 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:43 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:43 --> URI Class Initialized
INFO - 2021-09-14 14:02:43 --> Router Class Initialized
INFO - 2021-09-14 14:02:43 --> Output Class Initialized
INFO - 2021-09-14 14:02:43 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:43 --> Input Class Initialized
INFO - 2021-09-14 14:02:43 --> Language Class Initialized
ERROR - 2021-09-14 14:02:43 --> 404 Page Not Found: Plugins/system
ERROR - 2021-09-14 14:02:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:45 --> Config Class Initialized
INFO - 2021-09-14 14:02:45 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:45 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:45 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:45 --> URI Class Initialized
INFO - 2021-09-14 14:02:45 --> Router Class Initialized
INFO - 2021-09-14 14:02:45 --> Output Class Initialized
INFO - 2021-09-14 14:02:45 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:45 --> Input Class Initialized
INFO - 2021-09-14 14:02:45 --> Language Class Initialized
ERROR - 2021-09-14 14:02:45 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2021-09-14 14:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:46 --> Config Class Initialized
INFO - 2021-09-14 14:02:46 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:46 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:46 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:46 --> URI Class Initialized
DEBUG - 2021-09-14 14:02:46 --> No URI present. Default controller set.
INFO - 2021-09-14 14:02:46 --> Router Class Initialized
INFO - 2021-09-14 14:02:46 --> Output Class Initialized
INFO - 2021-09-14 14:02:46 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:46 --> Input Class Initialized
INFO - 2021-09-14 14:02:46 --> Language Class Initialized
INFO - 2021-09-14 14:02:46 --> Loader Class Initialized
INFO - 2021-09-14 14:02:46 --> Helper loaded: url_helper
INFO - 2021-09-14 14:02:46 --> Helper loaded: form_helper
INFO - 2021-09-14 14:02:46 --> Helper loaded: common_helper
INFO - 2021-09-14 14:02:46 --> Database Driver Class Initialized
DEBUG - 2021-09-14 14:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-14 14:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-14 14:02:46 --> Controller Class Initialized
INFO - 2021-09-14 14:02:46 --> Form Validation Class Initialized
DEBUG - 2021-09-14 14:02:46 --> Encrypt Class Initialized
DEBUG - 2021-09-14 14:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-14 14:02:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-14 14:02:46 --> Email Class Initialized
INFO - 2021-09-14 14:02:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-14 14:02:46 --> Calendar Class Initialized
INFO - 2021-09-14 14:02:46 --> Model "Login_model" initialized
INFO - 2021-09-14 14:02:46 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-14 14:02:46 --> Final output sent to browser
DEBUG - 2021-09-14 14:02:46 --> Total execution time: 0.0346
ERROR - 2021-09-14 14:02:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:47 --> Config Class Initialized
INFO - 2021-09-14 14:02:47 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:47 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:47 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:47 --> URI Class Initialized
INFO - 2021-09-14 14:02:47 --> Router Class Initialized
INFO - 2021-09-14 14:02:47 --> Output Class Initialized
INFO - 2021-09-14 14:02:47 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:47 --> Input Class Initialized
INFO - 2021-09-14 14:02:47 --> Language Class Initialized
ERROR - 2021-09-14 14:02:47 --> 404 Page Not Found: Admin/view
ERROR - 2021-09-14 14:02:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:47 --> Config Class Initialized
INFO - 2021-09-14 14:02:47 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:47 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:47 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:47 --> URI Class Initialized
INFO - 2021-09-14 14:02:47 --> Router Class Initialized
INFO - 2021-09-14 14:02:47 --> Output Class Initialized
INFO - 2021-09-14 14:02:47 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:47 --> Input Class Initialized
INFO - 2021-09-14 14:02:47 --> Language Class Initialized
ERROR - 2021-09-14 14:02:47 --> 404 Page Not Found: Admin/includes
ERROR - 2021-09-14 14:02:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:49 --> Config Class Initialized
INFO - 2021-09-14 14:02:49 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:49 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:49 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:49 --> URI Class Initialized
INFO - 2021-09-14 14:02:49 --> Router Class Initialized
INFO - 2021-09-14 14:02:49 --> Output Class Initialized
INFO - 2021-09-14 14:02:49 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:49 --> Input Class Initialized
INFO - 2021-09-14 14:02:49 --> Language Class Initialized
ERROR - 2021-09-14 14:02:49 --> 404 Page Not Found: Images/editor
ERROR - 2021-09-14 14:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:50 --> Config Class Initialized
INFO - 2021-09-14 14:02:50 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:50 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:50 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:50 --> URI Class Initialized
INFO - 2021-09-14 14:02:50 --> Router Class Initialized
INFO - 2021-09-14 14:02:50 --> Output Class Initialized
INFO - 2021-09-14 14:02:50 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:50 --> Input Class Initialized
INFO - 2021-09-14 14:02:50 --> Language Class Initialized
ERROR - 2021-09-14 14:02:50 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2021-09-14 14:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:50 --> Config Class Initialized
INFO - 2021-09-14 14:02:50 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:50 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:50 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:50 --> URI Class Initialized
INFO - 2021-09-14 14:02:50 --> Router Class Initialized
INFO - 2021-09-14 14:02:50 --> Output Class Initialized
INFO - 2021-09-14 14:02:50 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:50 --> Input Class Initialized
INFO - 2021-09-14 14:02:50 --> Language Class Initialized
ERROR - 2021-09-14 14:02:50 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-09-14 14:02:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 14:02:51 --> Config Class Initialized
INFO - 2021-09-14 14:02:51 --> Hooks Class Initialized
DEBUG - 2021-09-14 14:02:51 --> UTF-8 Support Enabled
INFO - 2021-09-14 14:02:51 --> Utf8 Class Initialized
INFO - 2021-09-14 14:02:51 --> URI Class Initialized
INFO - 2021-09-14 14:02:51 --> Router Class Initialized
INFO - 2021-09-14 14:02:51 --> Output Class Initialized
INFO - 2021-09-14 14:02:51 --> Security Class Initialized
DEBUG - 2021-09-14 14:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 14:02:51 --> Input Class Initialized
INFO - 2021-09-14 14:02:51 --> Language Class Initialized
ERROR - 2021-09-14 14:02:51 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-09-14 18:15:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 18:15:48 --> Config Class Initialized
INFO - 2021-09-14 18:15:48 --> Hooks Class Initialized
DEBUG - 2021-09-14 18:15:48 --> UTF-8 Support Enabled
INFO - 2021-09-14 18:15:48 --> Utf8 Class Initialized
INFO - 2021-09-14 18:15:48 --> URI Class Initialized
DEBUG - 2021-09-14 18:15:48 --> No URI present. Default controller set.
INFO - 2021-09-14 18:15:48 --> Router Class Initialized
INFO - 2021-09-14 18:15:48 --> Output Class Initialized
INFO - 2021-09-14 18:15:48 --> Security Class Initialized
DEBUG - 2021-09-14 18:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 18:15:48 --> Input Class Initialized
INFO - 2021-09-14 18:15:48 --> Language Class Initialized
INFO - 2021-09-14 18:15:48 --> Loader Class Initialized
INFO - 2021-09-14 18:15:48 --> Helper loaded: url_helper
INFO - 2021-09-14 18:15:48 --> Helper loaded: form_helper
INFO - 2021-09-14 18:15:48 --> Helper loaded: common_helper
INFO - 2021-09-14 18:15:48 --> Database Driver Class Initialized
DEBUG - 2021-09-14 18:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-14 18:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-14 18:15:48 --> Controller Class Initialized
INFO - 2021-09-14 18:15:48 --> Form Validation Class Initialized
DEBUG - 2021-09-14 18:15:48 --> Encrypt Class Initialized
DEBUG - 2021-09-14 18:15:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-14 18:15:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-14 18:15:48 --> Email Class Initialized
INFO - 2021-09-14 18:15:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-14 18:15:48 --> Calendar Class Initialized
INFO - 2021-09-14 18:15:48 --> Model "Login_model" initialized
INFO - 2021-09-14 18:15:48 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-14 18:15:48 --> Final output sent to browser
DEBUG - 2021-09-14 18:15:48 --> Total execution time: 0.7635
ERROR - 2021-09-14 18:16:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 18:16:46 --> Config Class Initialized
INFO - 2021-09-14 18:16:46 --> Hooks Class Initialized
DEBUG - 2021-09-14 18:16:46 --> UTF-8 Support Enabled
INFO - 2021-09-14 18:16:46 --> Utf8 Class Initialized
INFO - 2021-09-14 18:16:46 --> URI Class Initialized
DEBUG - 2021-09-14 18:16:46 --> No URI present. Default controller set.
INFO - 2021-09-14 18:16:46 --> Router Class Initialized
INFO - 2021-09-14 18:16:46 --> Output Class Initialized
INFO - 2021-09-14 18:16:46 --> Security Class Initialized
DEBUG - 2021-09-14 18:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 18:16:46 --> Input Class Initialized
INFO - 2021-09-14 18:16:46 --> Language Class Initialized
INFO - 2021-09-14 18:16:46 --> Loader Class Initialized
INFO - 2021-09-14 18:16:46 --> Helper loaded: url_helper
INFO - 2021-09-14 18:16:46 --> Helper loaded: form_helper
INFO - 2021-09-14 18:16:46 --> Helper loaded: common_helper
INFO - 2021-09-14 18:16:46 --> Database Driver Class Initialized
DEBUG - 2021-09-14 18:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-14 18:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-14 18:16:47 --> Controller Class Initialized
INFO - 2021-09-14 18:16:47 --> Form Validation Class Initialized
DEBUG - 2021-09-14 18:16:47 --> Encrypt Class Initialized
DEBUG - 2021-09-14 18:16:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-14 18:16:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-14 18:16:47 --> Email Class Initialized
INFO - 2021-09-14 18:16:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-14 18:16:47 --> Calendar Class Initialized
INFO - 2021-09-14 18:16:47 --> Model "Login_model" initialized
INFO - 2021-09-14 18:16:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-14 18:16:47 --> Final output sent to browser
DEBUG - 2021-09-14 18:16:47 --> Total execution time: 0.1995
ERROR - 2021-09-14 18:17:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 18:17:15 --> Config Class Initialized
INFO - 2021-09-14 18:17:15 --> Hooks Class Initialized
DEBUG - 2021-09-14 18:17:15 --> UTF-8 Support Enabled
INFO - 2021-09-14 18:17:15 --> Utf8 Class Initialized
INFO - 2021-09-14 18:17:15 --> URI Class Initialized
DEBUG - 2021-09-14 18:17:15 --> No URI present. Default controller set.
INFO - 2021-09-14 18:17:15 --> Router Class Initialized
INFO - 2021-09-14 18:17:15 --> Output Class Initialized
INFO - 2021-09-14 18:17:15 --> Security Class Initialized
DEBUG - 2021-09-14 18:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 18:17:15 --> Input Class Initialized
INFO - 2021-09-14 18:17:15 --> Language Class Initialized
INFO - 2021-09-14 18:17:15 --> Loader Class Initialized
INFO - 2021-09-14 18:17:15 --> Helper loaded: url_helper
INFO - 2021-09-14 18:17:15 --> Helper loaded: form_helper
INFO - 2021-09-14 18:17:15 --> Helper loaded: common_helper
INFO - 2021-09-14 18:17:15 --> Database Driver Class Initialized
DEBUG - 2021-09-14 18:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-14 18:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-14 18:17:15 --> Controller Class Initialized
INFO - 2021-09-14 18:17:15 --> Form Validation Class Initialized
DEBUG - 2021-09-14 18:17:15 --> Encrypt Class Initialized
DEBUG - 2021-09-14 18:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-14 18:17:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-14 18:17:15 --> Email Class Initialized
INFO - 2021-09-14 18:17:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-14 18:17:15 --> Calendar Class Initialized
INFO - 2021-09-14 18:17:15 --> Model "Login_model" initialized
INFO - 2021-09-14 18:17:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-14 18:17:15 --> Final output sent to browser
DEBUG - 2021-09-14 18:17:15 --> Total execution time: 0.1687
ERROR - 2021-09-14 19:05:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 19:05:06 --> Config Class Initialized
INFO - 2021-09-14 19:05:06 --> Hooks Class Initialized
DEBUG - 2021-09-14 19:05:06 --> UTF-8 Support Enabled
INFO - 2021-09-14 19:05:06 --> Utf8 Class Initialized
INFO - 2021-09-14 19:05:06 --> URI Class Initialized
DEBUG - 2021-09-14 19:05:06 --> No URI present. Default controller set.
INFO - 2021-09-14 19:05:06 --> Router Class Initialized
INFO - 2021-09-14 19:05:06 --> Output Class Initialized
INFO - 2021-09-14 19:05:06 --> Security Class Initialized
DEBUG - 2021-09-14 19:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 19:05:06 --> Input Class Initialized
INFO - 2021-09-14 19:05:06 --> Language Class Initialized
INFO - 2021-09-14 19:05:06 --> Loader Class Initialized
INFO - 2021-09-14 19:05:06 --> Helper loaded: url_helper
INFO - 2021-09-14 19:05:06 --> Helper loaded: form_helper
INFO - 2021-09-14 19:05:06 --> Helper loaded: common_helper
INFO - 2021-09-14 19:05:06 --> Database Driver Class Initialized
DEBUG - 2021-09-14 19:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-14 19:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-14 19:05:06 --> Controller Class Initialized
INFO - 2021-09-14 19:05:06 --> Form Validation Class Initialized
DEBUG - 2021-09-14 19:05:06 --> Encrypt Class Initialized
DEBUG - 2021-09-14 19:05:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-14 19:05:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-14 19:05:06 --> Email Class Initialized
INFO - 2021-09-14 19:05:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-14 19:05:06 --> Calendar Class Initialized
INFO - 2021-09-14 19:05:06 --> Model "Login_model" initialized
INFO - 2021-09-14 19:05:06 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-14 19:05:06 --> Final output sent to browser
DEBUG - 2021-09-14 19:05:06 --> Total execution time: 0.0499
ERROR - 2021-09-14 19:49:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 19:49:32 --> Config Class Initialized
INFO - 2021-09-14 19:49:32 --> Hooks Class Initialized
DEBUG - 2021-09-14 19:49:32 --> UTF-8 Support Enabled
INFO - 2021-09-14 19:49:32 --> Utf8 Class Initialized
INFO - 2021-09-14 19:49:32 --> URI Class Initialized
INFO - 2021-09-14 19:49:32 --> Router Class Initialized
INFO - 2021-09-14 19:49:32 --> Output Class Initialized
INFO - 2021-09-14 19:49:32 --> Security Class Initialized
DEBUG - 2021-09-14 19:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 19:49:32 --> Input Class Initialized
INFO - 2021-09-14 19:49:32 --> Language Class Initialized
ERROR - 2021-09-14 19:49:32 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-09-14 20:01:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 20:01:47 --> Config Class Initialized
INFO - 2021-09-14 20:01:47 --> Hooks Class Initialized
DEBUG - 2021-09-14 20:01:47 --> UTF-8 Support Enabled
INFO - 2021-09-14 20:01:47 --> Utf8 Class Initialized
INFO - 2021-09-14 20:01:47 --> URI Class Initialized
DEBUG - 2021-09-14 20:01:47 --> No URI present. Default controller set.
INFO - 2021-09-14 20:01:47 --> Router Class Initialized
INFO - 2021-09-14 20:01:47 --> Output Class Initialized
INFO - 2021-09-14 20:01:47 --> Security Class Initialized
DEBUG - 2021-09-14 20:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 20:01:47 --> Input Class Initialized
INFO - 2021-09-14 20:01:47 --> Language Class Initialized
INFO - 2021-09-14 20:01:47 --> Loader Class Initialized
INFO - 2021-09-14 20:01:47 --> Helper loaded: url_helper
INFO - 2021-09-14 20:01:47 --> Helper loaded: form_helper
INFO - 2021-09-14 20:01:47 --> Helper loaded: common_helper
INFO - 2021-09-14 20:01:47 --> Database Driver Class Initialized
DEBUG - 2021-09-14 20:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-14 20:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-14 20:01:47 --> Controller Class Initialized
INFO - 2021-09-14 20:01:47 --> Form Validation Class Initialized
DEBUG - 2021-09-14 20:01:47 --> Encrypt Class Initialized
DEBUG - 2021-09-14 20:01:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-14 20:01:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-14 20:01:47 --> Email Class Initialized
INFO - 2021-09-14 20:01:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-14 20:01:47 --> Calendar Class Initialized
INFO - 2021-09-14 20:01:47 --> Model "Login_model" initialized
INFO - 2021-09-14 20:01:47 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-14 20:01:47 --> Final output sent to browser
DEBUG - 2021-09-14 20:01:47 --> Total execution time: 0.0344
ERROR - 2021-09-14 22:08:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 22:08:29 --> Config Class Initialized
INFO - 2021-09-14 22:08:29 --> Hooks Class Initialized
DEBUG - 2021-09-14 22:08:29 --> UTF-8 Support Enabled
INFO - 2021-09-14 22:08:29 --> Utf8 Class Initialized
INFO - 2021-09-14 22:08:29 --> URI Class Initialized
INFO - 2021-09-14 22:08:29 --> Router Class Initialized
INFO - 2021-09-14 22:08:29 --> Output Class Initialized
INFO - 2021-09-14 22:08:29 --> Security Class Initialized
DEBUG - 2021-09-14 22:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 22:08:29 --> Input Class Initialized
INFO - 2021-09-14 22:08:29 --> Language Class Initialized
ERROR - 2021-09-14 22:08:29 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-14 22:08:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 22:08:39 --> Config Class Initialized
INFO - 2021-09-14 22:08:39 --> Hooks Class Initialized
DEBUG - 2021-09-14 22:08:39 --> UTF-8 Support Enabled
INFO - 2021-09-14 22:08:39 --> Utf8 Class Initialized
INFO - 2021-09-14 22:08:39 --> URI Class Initialized
INFO - 2021-09-14 22:08:39 --> Router Class Initialized
INFO - 2021-09-14 22:08:39 --> Output Class Initialized
INFO - 2021-09-14 22:08:39 --> Security Class Initialized
DEBUG - 2021-09-14 22:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 22:08:39 --> Input Class Initialized
INFO - 2021-09-14 22:08:39 --> Language Class Initialized
ERROR - 2021-09-14 22:08:39 --> 404 Page Not Found: Sites/default
ERROR - 2021-09-14 22:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 22:08:46 --> Config Class Initialized
INFO - 2021-09-14 22:08:46 --> Hooks Class Initialized
DEBUG - 2021-09-14 22:08:46 --> UTF-8 Support Enabled
INFO - 2021-09-14 22:08:46 --> Utf8 Class Initialized
INFO - 2021-09-14 22:08:46 --> URI Class Initialized
INFO - 2021-09-14 22:08:46 --> Router Class Initialized
INFO - 2021-09-14 22:08:46 --> Output Class Initialized
INFO - 2021-09-14 22:08:46 --> Security Class Initialized
DEBUG - 2021-09-14 22:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 22:08:46 --> Input Class Initialized
INFO - 2021-09-14 22:08:46 --> Language Class Initialized
ERROR - 2021-09-14 22:08:46 --> 404 Page Not Found: Admin/controller
ERROR - 2021-09-14 22:08:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 22:08:52 --> Config Class Initialized
INFO - 2021-09-14 22:08:52 --> Hooks Class Initialized
DEBUG - 2021-09-14 22:08:52 --> UTF-8 Support Enabled
INFO - 2021-09-14 22:08:52 --> Utf8 Class Initialized
INFO - 2021-09-14 22:08:52 --> URI Class Initialized
INFO - 2021-09-14 22:08:52 --> Router Class Initialized
INFO - 2021-09-14 22:08:52 --> Output Class Initialized
INFO - 2021-09-14 22:08:52 --> Security Class Initialized
DEBUG - 2021-09-14 22:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 22:08:52 --> Input Class Initialized
INFO - 2021-09-14 22:08:52 --> Language Class Initialized
ERROR - 2021-09-14 22:08:52 --> 404 Page Not Found: Uploads/index
ERROR - 2021-09-14 22:08:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 22:08:58 --> Config Class Initialized
INFO - 2021-09-14 22:08:58 --> Hooks Class Initialized
DEBUG - 2021-09-14 22:08:58 --> UTF-8 Support Enabled
INFO - 2021-09-14 22:08:58 --> Utf8 Class Initialized
INFO - 2021-09-14 22:08:58 --> URI Class Initialized
INFO - 2021-09-14 22:08:58 --> Router Class Initialized
INFO - 2021-09-14 22:08:58 --> Output Class Initialized
INFO - 2021-09-14 22:08:58 --> Security Class Initialized
DEBUG - 2021-09-14 22:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 22:08:58 --> Input Class Initialized
INFO - 2021-09-14 22:08:58 --> Language Class Initialized
ERROR - 2021-09-14 22:08:58 --> 404 Page Not Found: Images/index
ERROR - 2021-09-14 22:09:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-14 22:09:03 --> Config Class Initialized
INFO - 2021-09-14 22:09:03 --> Hooks Class Initialized
DEBUG - 2021-09-14 22:09:03 --> UTF-8 Support Enabled
INFO - 2021-09-14 22:09:03 --> Utf8 Class Initialized
INFO - 2021-09-14 22:09:03 --> URI Class Initialized
INFO - 2021-09-14 22:09:03 --> Router Class Initialized
INFO - 2021-09-14 22:09:03 --> Output Class Initialized
INFO - 2021-09-14 22:09:03 --> Security Class Initialized
DEBUG - 2021-09-14 22:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-14 22:09:03 --> Input Class Initialized
INFO - 2021-09-14 22:09:03 --> Language Class Initialized
ERROR - 2021-09-14 22:09:03 --> 404 Page Not Found: Files/index
