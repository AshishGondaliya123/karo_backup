<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-11 08:12:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 08:12:26 --> Config Class Initialized
INFO - 2022-02-11 08:12:26 --> Hooks Class Initialized
DEBUG - 2022-02-11 08:12:26 --> UTF-8 Support Enabled
INFO - 2022-02-11 08:12:26 --> Utf8 Class Initialized
INFO - 2022-02-11 08:12:26 --> URI Class Initialized
DEBUG - 2022-02-11 08:12:26 --> No URI present. Default controller set.
INFO - 2022-02-11 08:12:26 --> Router Class Initialized
INFO - 2022-02-11 08:12:26 --> Output Class Initialized
INFO - 2022-02-11 08:12:26 --> Security Class Initialized
DEBUG - 2022-02-11 08:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 08:12:26 --> Input Class Initialized
INFO - 2022-02-11 08:12:26 --> Language Class Initialized
INFO - 2022-02-11 08:12:26 --> Loader Class Initialized
INFO - 2022-02-11 08:12:26 --> Helper loaded: url_helper
INFO - 2022-02-11 08:12:26 --> Helper loaded: form_helper
INFO - 2022-02-11 08:12:26 --> Helper loaded: common_helper
INFO - 2022-02-11 08:12:26 --> Database Driver Class Initialized
DEBUG - 2022-02-11 08:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-11 08:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-11 08:12:26 --> Controller Class Initialized
INFO - 2022-02-11 08:12:26 --> Form Validation Class Initialized
DEBUG - 2022-02-11 08:12:26 --> Encrypt Class Initialized
DEBUG - 2022-02-11 08:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 08:12:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-11 08:12:26 --> Email Class Initialized
INFO - 2022-02-11 08:12:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-11 08:12:26 --> Calendar Class Initialized
INFO - 2022-02-11 08:12:26 --> Model "Login_model" initialized
INFO - 2022-02-11 08:12:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-11 08:12:26 --> Final output sent to browser
DEBUG - 2022-02-11 08:12:26 --> Total execution time: 0.0267
ERROR - 2022-02-11 10:14:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 10:14:01 --> Config Class Initialized
INFO - 2022-02-11 10:14:01 --> Hooks Class Initialized
DEBUG - 2022-02-11 10:14:01 --> UTF-8 Support Enabled
INFO - 2022-02-11 10:14:01 --> Utf8 Class Initialized
INFO - 2022-02-11 10:14:01 --> URI Class Initialized
DEBUG - 2022-02-11 10:14:01 --> No URI present. Default controller set.
INFO - 2022-02-11 10:14:01 --> Router Class Initialized
INFO - 2022-02-11 10:14:01 --> Output Class Initialized
INFO - 2022-02-11 10:14:01 --> Security Class Initialized
DEBUG - 2022-02-11 10:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 10:14:01 --> Input Class Initialized
INFO - 2022-02-11 10:14:01 --> Language Class Initialized
INFO - 2022-02-11 10:14:01 --> Loader Class Initialized
INFO - 2022-02-11 10:14:01 --> Helper loaded: url_helper
INFO - 2022-02-11 10:14:01 --> Helper loaded: form_helper
INFO - 2022-02-11 10:14:01 --> Helper loaded: common_helper
INFO - 2022-02-11 10:14:01 --> Database Driver Class Initialized
DEBUG - 2022-02-11 10:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-11 10:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-11 10:14:01 --> Controller Class Initialized
INFO - 2022-02-11 10:14:01 --> Form Validation Class Initialized
DEBUG - 2022-02-11 10:14:01 --> Encrypt Class Initialized
DEBUG - 2022-02-11 10:14:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:14:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-11 10:14:01 --> Email Class Initialized
INFO - 2022-02-11 10:14:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-11 10:14:01 --> Calendar Class Initialized
INFO - 2022-02-11 10:14:01 --> Model "Login_model" initialized
INFO - 2022-02-11 10:14:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-11 10:14:01 --> Final output sent to browser
DEBUG - 2022-02-11 10:14:01 --> Total execution time: 0.0590
ERROR - 2022-02-11 14:23:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 14:23:05 --> Config Class Initialized
INFO - 2022-02-11 14:23:05 --> Hooks Class Initialized
DEBUG - 2022-02-11 14:23:05 --> UTF-8 Support Enabled
INFO - 2022-02-11 14:23:05 --> Utf8 Class Initialized
INFO - 2022-02-11 14:23:05 --> URI Class Initialized
DEBUG - 2022-02-11 14:23:05 --> No URI present. Default controller set.
INFO - 2022-02-11 14:23:05 --> Router Class Initialized
INFO - 2022-02-11 14:23:05 --> Output Class Initialized
INFO - 2022-02-11 14:23:05 --> Security Class Initialized
DEBUG - 2022-02-11 14:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 14:23:05 --> Input Class Initialized
INFO - 2022-02-11 14:23:05 --> Language Class Initialized
INFO - 2022-02-11 14:23:05 --> Loader Class Initialized
INFO - 2022-02-11 14:23:05 --> Helper loaded: url_helper
INFO - 2022-02-11 14:23:05 --> Helper loaded: form_helper
INFO - 2022-02-11 14:23:05 --> Helper loaded: common_helper
INFO - 2022-02-11 14:23:05 --> Database Driver Class Initialized
DEBUG - 2022-02-11 14:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-11 14:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-11 14:23:05 --> Controller Class Initialized
INFO - 2022-02-11 14:23:05 --> Form Validation Class Initialized
DEBUG - 2022-02-11 14:23:05 --> Encrypt Class Initialized
DEBUG - 2022-02-11 14:23:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:23:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-11 14:23:05 --> Email Class Initialized
INFO - 2022-02-11 14:23:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-11 14:23:05 --> Calendar Class Initialized
INFO - 2022-02-11 14:23:05 --> Model "Login_model" initialized
INFO - 2022-02-11 14:23:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-11 14:23:05 --> Final output sent to browser
DEBUG - 2022-02-11 14:23:05 --> Total execution time: 0.0248
ERROR - 2022-02-11 14:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 14:23:06 --> Config Class Initialized
INFO - 2022-02-11 14:23:06 --> Hooks Class Initialized
DEBUG - 2022-02-11 14:23:06 --> UTF-8 Support Enabled
INFO - 2022-02-11 14:23:06 --> Utf8 Class Initialized
INFO - 2022-02-11 14:23:06 --> URI Class Initialized
INFO - 2022-02-11 14:23:06 --> Router Class Initialized
INFO - 2022-02-11 14:23:06 --> Output Class Initialized
INFO - 2022-02-11 14:23:06 --> Security Class Initialized
DEBUG - 2022-02-11 14:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 14:23:06 --> Input Class Initialized
INFO - 2022-02-11 14:23:06 --> Language Class Initialized
ERROR - 2022-02-11 14:23:06 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-11 14:23:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 14:23:51 --> Config Class Initialized
INFO - 2022-02-11 14:23:51 --> Hooks Class Initialized
DEBUG - 2022-02-11 14:23:51 --> UTF-8 Support Enabled
INFO - 2022-02-11 14:23:51 --> Utf8 Class Initialized
INFO - 2022-02-11 14:23:51 --> URI Class Initialized
INFO - 2022-02-11 14:23:51 --> Router Class Initialized
INFO - 2022-02-11 14:23:51 --> Output Class Initialized
INFO - 2022-02-11 14:23:51 --> Security Class Initialized
DEBUG - 2022-02-11 14:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 14:23:51 --> Input Class Initialized
INFO - 2022-02-11 14:23:51 --> Language Class Initialized
INFO - 2022-02-11 14:23:51 --> Loader Class Initialized
INFO - 2022-02-11 14:23:51 --> Helper loaded: url_helper
INFO - 2022-02-11 14:23:51 --> Helper loaded: form_helper
INFO - 2022-02-11 14:23:51 --> Helper loaded: common_helper
INFO - 2022-02-11 14:23:51 --> Database Driver Class Initialized
DEBUG - 2022-02-11 14:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-11 14:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-11 14:23:51 --> Controller Class Initialized
INFO - 2022-02-11 14:23:51 --> Form Validation Class Initialized
DEBUG - 2022-02-11 14:23:51 --> Encrypt Class Initialized
DEBUG - 2022-02-11 14:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:23:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-11 14:23:51 --> Email Class Initialized
INFO - 2022-02-11 14:23:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-11 14:23:51 --> Calendar Class Initialized
INFO - 2022-02-11 14:23:51 --> Model "Login_model" initialized
ERROR - 2022-02-11 14:23:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 14:23:52 --> Config Class Initialized
INFO - 2022-02-11 14:23:52 --> Hooks Class Initialized
DEBUG - 2022-02-11 14:23:52 --> UTF-8 Support Enabled
INFO - 2022-02-11 14:23:52 --> Utf8 Class Initialized
INFO - 2022-02-11 14:23:52 --> URI Class Initialized
INFO - 2022-02-11 14:23:52 --> Router Class Initialized
INFO - 2022-02-11 14:23:52 --> Output Class Initialized
INFO - 2022-02-11 14:23:52 --> Security Class Initialized
DEBUG - 2022-02-11 14:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 14:23:52 --> Input Class Initialized
INFO - 2022-02-11 14:23:52 --> Language Class Initialized
INFO - 2022-02-11 14:23:52 --> Loader Class Initialized
INFO - 2022-02-11 14:23:52 --> Helper loaded: url_helper
INFO - 2022-02-11 14:23:52 --> Helper loaded: form_helper
INFO - 2022-02-11 14:23:52 --> Helper loaded: common_helper
INFO - 2022-02-11 14:23:52 --> Database Driver Class Initialized
DEBUG - 2022-02-11 14:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-11 14:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-11 14:23:52 --> Controller Class Initialized
INFO - 2022-02-11 14:23:52 --> Form Validation Class Initialized
DEBUG - 2022-02-11 14:23:52 --> Encrypt Class Initialized
DEBUG - 2022-02-11 14:23:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-11 14:23:52 --> Email Class Initialized
INFO - 2022-02-11 14:23:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-11 14:23:52 --> Calendar Class Initialized
INFO - 2022-02-11 14:23:52 --> Model "Login_model" initialized
ERROR - 2022-02-11 14:23:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 14:23:52 --> Config Class Initialized
INFO - 2022-02-11 14:23:52 --> Hooks Class Initialized
DEBUG - 2022-02-11 14:23:52 --> UTF-8 Support Enabled
INFO - 2022-02-11 14:23:52 --> Utf8 Class Initialized
INFO - 2022-02-11 14:23:52 --> URI Class Initialized
INFO - 2022-02-11 14:23:52 --> Router Class Initialized
INFO - 2022-02-11 14:23:52 --> Output Class Initialized
INFO - 2022-02-11 14:23:52 --> Security Class Initialized
DEBUG - 2022-02-11 14:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 14:23:52 --> Input Class Initialized
INFO - 2022-02-11 14:23:52 --> Language Class Initialized
INFO - 2022-02-11 14:23:52 --> Loader Class Initialized
INFO - 2022-02-11 14:23:52 --> Helper loaded: url_helper
INFO - 2022-02-11 14:23:52 --> Helper loaded: form_helper
INFO - 2022-02-11 14:23:52 --> Helper loaded: common_helper
INFO - 2022-02-11 14:23:52 --> Database Driver Class Initialized
DEBUG - 2022-02-11 14:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-11 14:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-11 14:23:52 --> Controller Class Initialized
INFO - 2022-02-11 14:23:52 --> Form Validation Class Initialized
DEBUG - 2022-02-11 14:23:52 --> Encrypt Class Initialized
DEBUG - 2022-02-11 14:23:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-11 14:23:52 --> Email Class Initialized
INFO - 2022-02-11 14:23:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-11 14:23:52 --> Calendar Class Initialized
INFO - 2022-02-11 14:23:52 --> Model "Login_model" initialized
INFO - 2022-02-11 14:23:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-11 14:23:52 --> Final output sent to browser
DEBUG - 2022-02-11 14:23:52 --> Total execution time: 0.0466
ERROR - 2022-02-11 14:23:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 14:23:54 --> Config Class Initialized
INFO - 2022-02-11 14:23:54 --> Hooks Class Initialized
DEBUG - 2022-02-11 14:23:54 --> UTF-8 Support Enabled
INFO - 2022-02-11 14:23:54 --> Utf8 Class Initialized
INFO - 2022-02-11 14:23:54 --> URI Class Initialized
DEBUG - 2022-02-11 14:23:54 --> No URI present. Default controller set.
INFO - 2022-02-11 14:23:54 --> Router Class Initialized
INFO - 2022-02-11 14:23:54 --> Output Class Initialized
INFO - 2022-02-11 14:23:54 --> Security Class Initialized
DEBUG - 2022-02-11 14:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 14:23:54 --> Input Class Initialized
INFO - 2022-02-11 14:23:54 --> Language Class Initialized
INFO - 2022-02-11 14:23:54 --> Loader Class Initialized
INFO - 2022-02-11 14:23:54 --> Helper loaded: url_helper
INFO - 2022-02-11 14:23:54 --> Helper loaded: form_helper
INFO - 2022-02-11 14:23:54 --> Helper loaded: common_helper
INFO - 2022-02-11 14:23:54 --> Database Driver Class Initialized
DEBUG - 2022-02-11 14:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-11 14:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-11 14:23:54 --> Controller Class Initialized
INFO - 2022-02-11 14:23:54 --> Form Validation Class Initialized
DEBUG - 2022-02-11 14:23:54 --> Encrypt Class Initialized
DEBUG - 2022-02-11 14:23:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:23:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-11 14:23:54 --> Email Class Initialized
INFO - 2022-02-11 14:23:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-11 14:23:54 --> Calendar Class Initialized
INFO - 2022-02-11 14:23:54 --> Model "Login_model" initialized
INFO - 2022-02-11 14:23:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-11 14:23:54 --> Final output sent to browser
DEBUG - 2022-02-11 14:23:54 --> Total execution time: 0.0332
ERROR - 2022-02-11 15:37:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 15:37:52 --> Config Class Initialized
INFO - 2022-02-11 15:37:52 --> Hooks Class Initialized
DEBUG - 2022-02-11 15:37:52 --> UTF-8 Support Enabled
INFO - 2022-02-11 15:37:52 --> Utf8 Class Initialized
INFO - 2022-02-11 15:37:52 --> URI Class Initialized
DEBUG - 2022-02-11 15:37:52 --> No URI present. Default controller set.
INFO - 2022-02-11 15:37:52 --> Router Class Initialized
INFO - 2022-02-11 15:37:52 --> Output Class Initialized
INFO - 2022-02-11 15:37:52 --> Security Class Initialized
DEBUG - 2022-02-11 15:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 15:37:52 --> Input Class Initialized
INFO - 2022-02-11 15:37:52 --> Language Class Initialized
INFO - 2022-02-11 15:37:52 --> Loader Class Initialized
INFO - 2022-02-11 15:37:52 --> Helper loaded: url_helper
INFO - 2022-02-11 15:37:52 --> Helper loaded: form_helper
INFO - 2022-02-11 15:37:52 --> Helper loaded: common_helper
INFO - 2022-02-11 15:37:52 --> Database Driver Class Initialized
DEBUG - 2022-02-11 15:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-11 15:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-11 15:37:52 --> Controller Class Initialized
INFO - 2022-02-11 15:37:52 --> Form Validation Class Initialized
DEBUG - 2022-02-11 15:37:52 --> Encrypt Class Initialized
DEBUG - 2022-02-11 15:37:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:37:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-11 15:37:52 --> Email Class Initialized
INFO - 2022-02-11 15:37:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-11 15:37:52 --> Calendar Class Initialized
INFO - 2022-02-11 15:37:52 --> Model "Login_model" initialized
INFO - 2022-02-11 15:37:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-11 15:37:52 --> Final output sent to browser
DEBUG - 2022-02-11 15:37:52 --> Total execution time: 0.0249
ERROR - 2022-02-11 20:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 20:55:22 --> Config Class Initialized
INFO - 2022-02-11 20:55:22 --> Hooks Class Initialized
DEBUG - 2022-02-11 20:55:22 --> UTF-8 Support Enabled
INFO - 2022-02-11 20:55:22 --> Utf8 Class Initialized
INFO - 2022-02-11 20:55:22 --> URI Class Initialized
INFO - 2022-02-11 20:55:22 --> Router Class Initialized
INFO - 2022-02-11 20:55:22 --> Output Class Initialized
INFO - 2022-02-11 20:55:22 --> Security Class Initialized
DEBUG - 2022-02-11 20:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 20:55:22 --> Input Class Initialized
INFO - 2022-02-11 20:55:22 --> Language Class Initialized
ERROR - 2022-02-11 20:55:22 --> 404 Page Not Found: Humanstxt/index
ERROR - 2022-02-11 20:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 20:55:23 --> Config Class Initialized
INFO - 2022-02-11 20:55:23 --> Hooks Class Initialized
DEBUG - 2022-02-11 20:55:23 --> UTF-8 Support Enabled
INFO - 2022-02-11 20:55:23 --> Utf8 Class Initialized
INFO - 2022-02-11 20:55:23 --> URI Class Initialized
INFO - 2022-02-11 20:55:23 --> Router Class Initialized
INFO - 2022-02-11 20:55:23 --> Output Class Initialized
INFO - 2022-02-11 20:55:23 --> Security Class Initialized
DEBUG - 2022-02-11 20:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 20:55:23 --> Input Class Initialized
INFO - 2022-02-11 20:55:23 --> Language Class Initialized
ERROR - 2022-02-11 20:55:23 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-02-11 20:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-11 20:55:23 --> Config Class Initialized
INFO - 2022-02-11 20:55:23 --> Hooks Class Initialized
DEBUG - 2022-02-11 20:55:23 --> UTF-8 Support Enabled
INFO - 2022-02-11 20:55:23 --> Utf8 Class Initialized
INFO - 2022-02-11 20:55:23 --> URI Class Initialized
DEBUG - 2022-02-11 20:55:23 --> No URI present. Default controller set.
INFO - 2022-02-11 20:55:23 --> Router Class Initialized
INFO - 2022-02-11 20:55:23 --> Output Class Initialized
INFO - 2022-02-11 20:55:23 --> Security Class Initialized
DEBUG - 2022-02-11 20:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-11 20:55:23 --> Input Class Initialized
INFO - 2022-02-11 20:55:23 --> Language Class Initialized
INFO - 2022-02-11 20:55:23 --> Loader Class Initialized
INFO - 2022-02-11 20:55:23 --> Helper loaded: url_helper
INFO - 2022-02-11 20:55:23 --> Helper loaded: form_helper
INFO - 2022-02-11 20:55:23 --> Helper loaded: common_helper
INFO - 2022-02-11 20:55:24 --> Database Driver Class Initialized
DEBUG - 2022-02-11 20:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-11 20:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-11 20:55:24 --> Controller Class Initialized
INFO - 2022-02-11 20:55:24 --> Form Validation Class Initialized
DEBUG - 2022-02-11 20:55:24 --> Encrypt Class Initialized
DEBUG - 2022-02-11 20:55:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 20:55:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-11 20:55:24 --> Email Class Initialized
INFO - 2022-02-11 20:55:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-11 20:55:24 --> Calendar Class Initialized
INFO - 2022-02-11 20:55:24 --> Model "Login_model" initialized
INFO - 2022-02-11 20:55:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-11 20:55:24 --> Final output sent to browser
DEBUG - 2022-02-11 20:55:24 --> Total execution time: 0.0250
