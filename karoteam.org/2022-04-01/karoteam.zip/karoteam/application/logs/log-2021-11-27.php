<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-27 00:24:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 00:24:04 --> Config Class Initialized
INFO - 2021-11-27 00:24:04 --> Hooks Class Initialized
DEBUG - 2021-11-27 00:24:04 --> UTF-8 Support Enabled
INFO - 2021-11-27 00:24:04 --> Utf8 Class Initialized
INFO - 2021-11-27 00:24:04 --> URI Class Initialized
DEBUG - 2021-11-27 00:24:04 --> No URI present. Default controller set.
INFO - 2021-11-27 00:24:04 --> Router Class Initialized
INFO - 2021-11-27 00:24:04 --> Output Class Initialized
INFO - 2021-11-27 00:24:04 --> Security Class Initialized
DEBUG - 2021-11-27 00:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 00:24:04 --> Input Class Initialized
INFO - 2021-11-27 00:24:04 --> Language Class Initialized
INFO - 2021-11-27 00:24:04 --> Loader Class Initialized
INFO - 2021-11-27 00:24:04 --> Helper loaded: url_helper
INFO - 2021-11-27 00:24:04 --> Helper loaded: form_helper
INFO - 2021-11-27 00:24:04 --> Helper loaded: common_helper
INFO - 2021-11-27 00:24:04 --> Database Driver Class Initialized
DEBUG - 2021-11-27 00:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 00:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 00:24:04 --> Controller Class Initialized
INFO - 2021-11-27 00:24:04 --> Form Validation Class Initialized
DEBUG - 2021-11-27 00:24:04 --> Encrypt Class Initialized
DEBUG - 2021-11-27 00:24:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 00:24:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 00:24:04 --> Email Class Initialized
INFO - 2021-11-27 00:24:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 00:24:04 --> Calendar Class Initialized
INFO - 2021-11-27 00:24:04 --> Model "Login_model" initialized
INFO - 2021-11-27 00:24:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 00:24:04 --> Final output sent to browser
DEBUG - 2021-11-27 00:24:04 --> Total execution time: 0.0361
ERROR - 2021-11-27 01:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 01:57:03 --> Config Class Initialized
INFO - 2021-11-27 01:57:03 --> Hooks Class Initialized
DEBUG - 2021-11-27 01:57:03 --> UTF-8 Support Enabled
INFO - 2021-11-27 01:57:03 --> Utf8 Class Initialized
INFO - 2021-11-27 01:57:03 --> URI Class Initialized
DEBUG - 2021-11-27 01:57:03 --> No URI present. Default controller set.
INFO - 2021-11-27 01:57:03 --> Router Class Initialized
INFO - 2021-11-27 01:57:03 --> Output Class Initialized
INFO - 2021-11-27 01:57:03 --> Security Class Initialized
DEBUG - 2021-11-27 01:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 01:57:03 --> Input Class Initialized
INFO - 2021-11-27 01:57:03 --> Language Class Initialized
INFO - 2021-11-27 01:57:03 --> Loader Class Initialized
INFO - 2021-11-27 01:57:03 --> Helper loaded: url_helper
INFO - 2021-11-27 01:57:03 --> Helper loaded: form_helper
INFO - 2021-11-27 01:57:03 --> Helper loaded: common_helper
INFO - 2021-11-27 01:57:03 --> Database Driver Class Initialized
DEBUG - 2021-11-27 01:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 01:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 01:57:03 --> Controller Class Initialized
INFO - 2021-11-27 01:57:03 --> Form Validation Class Initialized
DEBUG - 2021-11-27 01:57:03 --> Encrypt Class Initialized
DEBUG - 2021-11-27 01:57:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 01:57:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 01:57:03 --> Email Class Initialized
INFO - 2021-11-27 01:57:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 01:57:03 --> Calendar Class Initialized
INFO - 2021-11-27 01:57:03 --> Model "Login_model" initialized
INFO - 2021-11-27 01:57:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 01:57:03 --> Final output sent to browser
DEBUG - 2021-11-27 01:57:03 --> Total execution time: 0.0296
ERROR - 2021-11-27 07:53:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 07:53:37 --> Config Class Initialized
INFO - 2021-11-27 07:53:37 --> Hooks Class Initialized
DEBUG - 2021-11-27 07:53:37 --> UTF-8 Support Enabled
INFO - 2021-11-27 07:53:37 --> Utf8 Class Initialized
INFO - 2021-11-27 07:53:37 --> URI Class Initialized
DEBUG - 2021-11-27 07:53:37 --> No URI present. Default controller set.
INFO - 2021-11-27 07:53:37 --> Router Class Initialized
INFO - 2021-11-27 07:53:37 --> Output Class Initialized
INFO - 2021-11-27 07:53:37 --> Security Class Initialized
DEBUG - 2021-11-27 07:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 07:53:37 --> Input Class Initialized
INFO - 2021-11-27 07:53:37 --> Language Class Initialized
INFO - 2021-11-27 07:53:37 --> Loader Class Initialized
INFO - 2021-11-27 07:53:37 --> Helper loaded: url_helper
INFO - 2021-11-27 07:53:37 --> Helper loaded: form_helper
INFO - 2021-11-27 07:53:37 --> Helper loaded: common_helper
INFO - 2021-11-27 07:53:37 --> Database Driver Class Initialized
DEBUG - 2021-11-27 07:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 07:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 07:53:37 --> Controller Class Initialized
INFO - 2021-11-27 07:53:37 --> Form Validation Class Initialized
DEBUG - 2021-11-27 07:53:37 --> Encrypt Class Initialized
DEBUG - 2021-11-27 07:53:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 07:53:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 07:53:37 --> Email Class Initialized
INFO - 2021-11-27 07:53:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 07:53:37 --> Calendar Class Initialized
INFO - 2021-11-27 07:53:37 --> Model "Login_model" initialized
INFO - 2021-11-27 07:53:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 07:53:37 --> Final output sent to browser
DEBUG - 2021-11-27 07:53:37 --> Total execution time: 0.0646
ERROR - 2021-11-27 08:41:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 08:41:50 --> Config Class Initialized
INFO - 2021-11-27 08:41:50 --> Hooks Class Initialized
DEBUG - 2021-11-27 08:41:50 --> UTF-8 Support Enabled
INFO - 2021-11-27 08:41:50 --> Utf8 Class Initialized
INFO - 2021-11-27 08:41:50 --> URI Class Initialized
DEBUG - 2021-11-27 08:41:50 --> No URI present. Default controller set.
INFO - 2021-11-27 08:41:50 --> Router Class Initialized
INFO - 2021-11-27 08:41:50 --> Output Class Initialized
INFO - 2021-11-27 08:41:50 --> Security Class Initialized
DEBUG - 2021-11-27 08:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 08:41:50 --> Input Class Initialized
INFO - 2021-11-27 08:41:50 --> Language Class Initialized
INFO - 2021-11-27 08:41:50 --> Loader Class Initialized
INFO - 2021-11-27 08:41:50 --> Helper loaded: url_helper
INFO - 2021-11-27 08:41:50 --> Helper loaded: form_helper
INFO - 2021-11-27 08:41:50 --> Helper loaded: common_helper
INFO - 2021-11-27 08:41:50 --> Database Driver Class Initialized
DEBUG - 2021-11-27 08:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 08:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 08:41:50 --> Controller Class Initialized
INFO - 2021-11-27 08:41:50 --> Form Validation Class Initialized
DEBUG - 2021-11-27 08:41:50 --> Encrypt Class Initialized
DEBUG - 2021-11-27 08:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 08:41:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 08:41:50 --> Email Class Initialized
INFO - 2021-11-27 08:41:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 08:41:50 --> Calendar Class Initialized
INFO - 2021-11-27 08:41:50 --> Model "Login_model" initialized
INFO - 2021-11-27 08:41:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 08:41:50 --> Final output sent to browser
DEBUG - 2021-11-27 08:41:50 --> Total execution time: 0.0381
ERROR - 2021-11-27 10:25:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 10:25:02 --> Config Class Initialized
INFO - 2021-11-27 10:25:02 --> Hooks Class Initialized
DEBUG - 2021-11-27 10:25:02 --> UTF-8 Support Enabled
INFO - 2021-11-27 10:25:02 --> Utf8 Class Initialized
INFO - 2021-11-27 10:25:02 --> URI Class Initialized
DEBUG - 2021-11-27 10:25:02 --> No URI present. Default controller set.
INFO - 2021-11-27 10:25:02 --> Router Class Initialized
INFO - 2021-11-27 10:25:02 --> Output Class Initialized
INFO - 2021-11-27 10:25:02 --> Security Class Initialized
DEBUG - 2021-11-27 10:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 10:25:02 --> Input Class Initialized
INFO - 2021-11-27 10:25:02 --> Language Class Initialized
INFO - 2021-11-27 10:25:02 --> Loader Class Initialized
INFO - 2021-11-27 10:25:02 --> Helper loaded: url_helper
INFO - 2021-11-27 10:25:02 --> Helper loaded: form_helper
INFO - 2021-11-27 10:25:02 --> Helper loaded: common_helper
INFO - 2021-11-27 10:25:02 --> Database Driver Class Initialized
DEBUG - 2021-11-27 10:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 10:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 10:25:02 --> Controller Class Initialized
INFO - 2021-11-27 10:25:02 --> Form Validation Class Initialized
DEBUG - 2021-11-27 10:25:02 --> Encrypt Class Initialized
DEBUG - 2021-11-27 10:25:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 10:25:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 10:25:02 --> Email Class Initialized
INFO - 2021-11-27 10:25:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 10:25:02 --> Calendar Class Initialized
INFO - 2021-11-27 10:25:02 --> Model "Login_model" initialized
INFO - 2021-11-27 10:25:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 10:25:02 --> Final output sent to browser
DEBUG - 2021-11-27 10:25:02 --> Total execution time: 0.0437
ERROR - 2021-11-27 10:25:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 10:25:04 --> Config Class Initialized
INFO - 2021-11-27 10:25:04 --> Hooks Class Initialized
DEBUG - 2021-11-27 10:25:04 --> UTF-8 Support Enabled
INFO - 2021-11-27 10:25:04 --> Utf8 Class Initialized
INFO - 2021-11-27 10:25:04 --> URI Class Initialized
DEBUG - 2021-11-27 10:25:04 --> No URI present. Default controller set.
INFO - 2021-11-27 10:25:04 --> Router Class Initialized
INFO - 2021-11-27 10:25:04 --> Output Class Initialized
INFO - 2021-11-27 10:25:04 --> Security Class Initialized
DEBUG - 2021-11-27 10:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 10:25:04 --> Input Class Initialized
INFO - 2021-11-27 10:25:04 --> Language Class Initialized
INFO - 2021-11-27 10:25:04 --> Loader Class Initialized
INFO - 2021-11-27 10:25:04 --> Helper loaded: url_helper
INFO - 2021-11-27 10:25:04 --> Helper loaded: form_helper
INFO - 2021-11-27 10:25:04 --> Helper loaded: common_helper
INFO - 2021-11-27 10:25:04 --> Database Driver Class Initialized
DEBUG - 2021-11-27 10:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 10:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 10:25:04 --> Controller Class Initialized
INFO - 2021-11-27 10:25:04 --> Form Validation Class Initialized
DEBUG - 2021-11-27 10:25:04 --> Encrypt Class Initialized
DEBUG - 2021-11-27 10:25:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 10:25:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 10:25:04 --> Email Class Initialized
INFO - 2021-11-27 10:25:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 10:25:04 --> Calendar Class Initialized
INFO - 2021-11-27 10:25:04 --> Model "Login_model" initialized
INFO - 2021-11-27 10:25:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 10:25:04 --> Final output sent to browser
DEBUG - 2021-11-27 10:25:04 --> Total execution time: 0.0223
ERROR - 2021-11-27 14:01:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 14:01:24 --> Config Class Initialized
INFO - 2021-11-27 14:01:24 --> Hooks Class Initialized
DEBUG - 2021-11-27 14:01:24 --> UTF-8 Support Enabled
INFO - 2021-11-27 14:01:24 --> Utf8 Class Initialized
INFO - 2021-11-27 14:01:24 --> URI Class Initialized
DEBUG - 2021-11-27 14:01:24 --> No URI present. Default controller set.
INFO - 2021-11-27 14:01:24 --> Router Class Initialized
INFO - 2021-11-27 14:01:24 --> Output Class Initialized
INFO - 2021-11-27 14:01:24 --> Security Class Initialized
DEBUG - 2021-11-27 14:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 14:01:24 --> Input Class Initialized
INFO - 2021-11-27 14:01:24 --> Language Class Initialized
INFO - 2021-11-27 14:01:24 --> Loader Class Initialized
INFO - 2021-11-27 14:01:24 --> Helper loaded: url_helper
INFO - 2021-11-27 14:01:24 --> Helper loaded: form_helper
INFO - 2021-11-27 14:01:24 --> Helper loaded: common_helper
INFO - 2021-11-27 14:01:24 --> Database Driver Class Initialized
DEBUG - 2021-11-27 14:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 14:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 14:01:24 --> Controller Class Initialized
INFO - 2021-11-27 14:01:24 --> Form Validation Class Initialized
DEBUG - 2021-11-27 14:01:24 --> Encrypt Class Initialized
DEBUG - 2021-11-27 14:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 14:01:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 14:01:24 --> Email Class Initialized
INFO - 2021-11-27 14:01:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 14:01:24 --> Calendar Class Initialized
INFO - 2021-11-27 14:01:24 --> Model "Login_model" initialized
INFO - 2021-11-27 14:01:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 14:01:24 --> Final output sent to browser
DEBUG - 2021-11-27 14:01:24 --> Total execution time: 0.0225
ERROR - 2021-11-27 14:01:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 14:01:25 --> Config Class Initialized
INFO - 2021-11-27 14:01:25 --> Hooks Class Initialized
DEBUG - 2021-11-27 14:01:25 --> UTF-8 Support Enabled
INFO - 2021-11-27 14:01:25 --> Utf8 Class Initialized
INFO - 2021-11-27 14:01:25 --> URI Class Initialized
DEBUG - 2021-11-27 14:01:25 --> No URI present. Default controller set.
INFO - 2021-11-27 14:01:25 --> Router Class Initialized
INFO - 2021-11-27 14:01:25 --> Output Class Initialized
INFO - 2021-11-27 14:01:25 --> Security Class Initialized
DEBUG - 2021-11-27 14:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 14:01:25 --> Input Class Initialized
INFO - 2021-11-27 14:01:25 --> Language Class Initialized
INFO - 2021-11-27 14:01:25 --> Loader Class Initialized
INFO - 2021-11-27 14:01:25 --> Helper loaded: url_helper
INFO - 2021-11-27 14:01:25 --> Helper loaded: form_helper
INFO - 2021-11-27 14:01:25 --> Helper loaded: common_helper
INFO - 2021-11-27 14:01:25 --> Database Driver Class Initialized
DEBUG - 2021-11-27 14:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 14:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 14:01:25 --> Controller Class Initialized
INFO - 2021-11-27 14:01:25 --> Form Validation Class Initialized
DEBUG - 2021-11-27 14:01:25 --> Encrypt Class Initialized
DEBUG - 2021-11-27 14:01:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 14:01:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 14:01:25 --> Email Class Initialized
INFO - 2021-11-27 14:01:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 14:01:25 --> Calendar Class Initialized
INFO - 2021-11-27 14:01:25 --> Model "Login_model" initialized
INFO - 2021-11-27 14:01:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 14:01:25 --> Final output sent to browser
DEBUG - 2021-11-27 14:01:25 --> Total execution time: 0.0240
ERROR - 2021-11-27 14:20:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 14:20:33 --> Config Class Initialized
INFO - 2021-11-27 14:20:33 --> Hooks Class Initialized
DEBUG - 2021-11-27 14:20:33 --> UTF-8 Support Enabled
INFO - 2021-11-27 14:20:33 --> Utf8 Class Initialized
INFO - 2021-11-27 14:20:33 --> URI Class Initialized
DEBUG - 2021-11-27 14:20:33 --> No URI present. Default controller set.
INFO - 2021-11-27 14:20:33 --> Router Class Initialized
INFO - 2021-11-27 14:20:33 --> Output Class Initialized
INFO - 2021-11-27 14:20:33 --> Security Class Initialized
DEBUG - 2021-11-27 14:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 14:20:33 --> Input Class Initialized
INFO - 2021-11-27 14:20:33 --> Language Class Initialized
INFO - 2021-11-27 14:20:33 --> Loader Class Initialized
INFO - 2021-11-27 14:20:33 --> Helper loaded: url_helper
INFO - 2021-11-27 14:20:33 --> Helper loaded: form_helper
INFO - 2021-11-27 14:20:33 --> Helper loaded: common_helper
INFO - 2021-11-27 14:20:33 --> Database Driver Class Initialized
DEBUG - 2021-11-27 14:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 14:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 14:20:33 --> Controller Class Initialized
INFO - 2021-11-27 14:20:33 --> Form Validation Class Initialized
DEBUG - 2021-11-27 14:20:33 --> Encrypt Class Initialized
DEBUG - 2021-11-27 14:20:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 14:20:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 14:20:33 --> Email Class Initialized
INFO - 2021-11-27 14:20:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 14:20:33 --> Calendar Class Initialized
INFO - 2021-11-27 14:20:33 --> Model "Login_model" initialized
INFO - 2021-11-27 14:20:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 14:20:33 --> Final output sent to browser
DEBUG - 2021-11-27 14:20:33 --> Total execution time: 0.0274
ERROR - 2021-11-27 15:48:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 15:48:19 --> Config Class Initialized
INFO - 2021-11-27 15:48:19 --> Hooks Class Initialized
DEBUG - 2021-11-27 15:48:19 --> UTF-8 Support Enabled
INFO - 2021-11-27 15:48:19 --> Utf8 Class Initialized
INFO - 2021-11-27 15:48:19 --> URI Class Initialized
DEBUG - 2021-11-27 15:48:19 --> No URI present. Default controller set.
INFO - 2021-11-27 15:48:19 --> Router Class Initialized
INFO - 2021-11-27 15:48:19 --> Output Class Initialized
INFO - 2021-11-27 15:48:19 --> Security Class Initialized
DEBUG - 2021-11-27 15:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 15:48:19 --> Input Class Initialized
INFO - 2021-11-27 15:48:19 --> Language Class Initialized
INFO - 2021-11-27 15:48:19 --> Loader Class Initialized
INFO - 2021-11-27 15:48:19 --> Helper loaded: url_helper
INFO - 2021-11-27 15:48:19 --> Helper loaded: form_helper
INFO - 2021-11-27 15:48:19 --> Helper loaded: common_helper
INFO - 2021-11-27 15:48:19 --> Database Driver Class Initialized
DEBUG - 2021-11-27 15:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 15:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 15:48:19 --> Controller Class Initialized
INFO - 2021-11-27 15:48:19 --> Form Validation Class Initialized
DEBUG - 2021-11-27 15:48:19 --> Encrypt Class Initialized
DEBUG - 2021-11-27 15:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 15:48:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 15:48:19 --> Email Class Initialized
INFO - 2021-11-27 15:48:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 15:48:19 --> Calendar Class Initialized
INFO - 2021-11-27 15:48:19 --> Model "Login_model" initialized
INFO - 2021-11-27 15:48:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 15:48:19 --> Final output sent to browser
DEBUG - 2021-11-27 15:48:19 --> Total execution time: 0.0272
ERROR - 2021-11-27 15:48:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 15:48:19 --> Config Class Initialized
INFO - 2021-11-27 15:48:19 --> Hooks Class Initialized
DEBUG - 2021-11-27 15:48:19 --> UTF-8 Support Enabled
INFO - 2021-11-27 15:48:19 --> Utf8 Class Initialized
INFO - 2021-11-27 15:48:19 --> URI Class Initialized
DEBUG - 2021-11-27 15:48:19 --> No URI present. Default controller set.
INFO - 2021-11-27 15:48:19 --> Router Class Initialized
INFO - 2021-11-27 15:48:19 --> Output Class Initialized
INFO - 2021-11-27 15:48:19 --> Security Class Initialized
DEBUG - 2021-11-27 15:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 15:48:19 --> Input Class Initialized
INFO - 2021-11-27 15:48:19 --> Language Class Initialized
INFO - 2021-11-27 15:48:19 --> Loader Class Initialized
INFO - 2021-11-27 15:48:19 --> Helper loaded: url_helper
INFO - 2021-11-27 15:48:19 --> Helper loaded: form_helper
INFO - 2021-11-27 15:48:19 --> Helper loaded: common_helper
INFO - 2021-11-27 15:48:19 --> Database Driver Class Initialized
DEBUG - 2021-11-27 15:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 15:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 15:48:19 --> Controller Class Initialized
INFO - 2021-11-27 15:48:19 --> Form Validation Class Initialized
DEBUG - 2021-11-27 15:48:19 --> Encrypt Class Initialized
DEBUG - 2021-11-27 15:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 15:48:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 15:48:20 --> Email Class Initialized
INFO - 2021-11-27 15:48:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 15:48:20 --> Calendar Class Initialized
INFO - 2021-11-27 15:48:20 --> Model "Login_model" initialized
INFO - 2021-11-27 15:48:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 15:48:20 --> Final output sent to browser
DEBUG - 2021-11-27 15:48:20 --> Total execution time: 0.0218
ERROR - 2021-11-27 15:48:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 15:48:20 --> Config Class Initialized
INFO - 2021-11-27 15:48:20 --> Hooks Class Initialized
DEBUG - 2021-11-27 15:48:20 --> UTF-8 Support Enabled
INFO - 2021-11-27 15:48:20 --> Utf8 Class Initialized
INFO - 2021-11-27 15:48:20 --> URI Class Initialized
DEBUG - 2021-11-27 15:48:20 --> No URI present. Default controller set.
INFO - 2021-11-27 15:48:20 --> Router Class Initialized
INFO - 2021-11-27 15:48:20 --> Output Class Initialized
INFO - 2021-11-27 15:48:20 --> Security Class Initialized
DEBUG - 2021-11-27 15:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 15:48:20 --> Input Class Initialized
INFO - 2021-11-27 15:48:20 --> Language Class Initialized
INFO - 2021-11-27 15:48:20 --> Loader Class Initialized
INFO - 2021-11-27 15:48:20 --> Helper loaded: url_helper
INFO - 2021-11-27 15:48:20 --> Helper loaded: form_helper
INFO - 2021-11-27 15:48:20 --> Helper loaded: common_helper
INFO - 2021-11-27 15:48:20 --> Database Driver Class Initialized
DEBUG - 2021-11-27 15:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 15:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 15:48:20 --> Controller Class Initialized
INFO - 2021-11-27 15:48:20 --> Form Validation Class Initialized
DEBUG - 2021-11-27 15:48:20 --> Encrypt Class Initialized
DEBUG - 2021-11-27 15:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 15:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 15:48:20 --> Email Class Initialized
INFO - 2021-11-27 15:48:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 15:48:20 --> Calendar Class Initialized
INFO - 2021-11-27 15:48:20 --> Model "Login_model" initialized
INFO - 2021-11-27 15:48:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 15:48:20 --> Final output sent to browser
DEBUG - 2021-11-27 15:48:20 --> Total execution time: 0.0295
ERROR - 2021-11-27 15:48:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-27 15:48:20 --> Config Class Initialized
INFO - 2021-11-27 15:48:20 --> Hooks Class Initialized
DEBUG - 2021-11-27 15:48:20 --> UTF-8 Support Enabled
INFO - 2021-11-27 15:48:20 --> Utf8 Class Initialized
INFO - 2021-11-27 15:48:20 --> URI Class Initialized
DEBUG - 2021-11-27 15:48:20 --> No URI present. Default controller set.
INFO - 2021-11-27 15:48:20 --> Router Class Initialized
INFO - 2021-11-27 15:48:20 --> Output Class Initialized
INFO - 2021-11-27 15:48:20 --> Security Class Initialized
DEBUG - 2021-11-27 15:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-27 15:48:20 --> Input Class Initialized
INFO - 2021-11-27 15:48:20 --> Language Class Initialized
INFO - 2021-11-27 15:48:20 --> Loader Class Initialized
INFO - 2021-11-27 15:48:20 --> Helper loaded: url_helper
INFO - 2021-11-27 15:48:20 --> Helper loaded: form_helper
INFO - 2021-11-27 15:48:20 --> Helper loaded: common_helper
INFO - 2021-11-27 15:48:20 --> Database Driver Class Initialized
DEBUG - 2021-11-27 15:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-27 15:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-27 15:48:20 --> Controller Class Initialized
INFO - 2021-11-27 15:48:20 --> Form Validation Class Initialized
DEBUG - 2021-11-27 15:48:20 --> Encrypt Class Initialized
DEBUG - 2021-11-27 15:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-27 15:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-27 15:48:20 --> Email Class Initialized
INFO - 2021-11-27 15:48:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-27 15:48:20 --> Calendar Class Initialized
INFO - 2021-11-27 15:48:20 --> Model "Login_model" initialized
INFO - 2021-11-27 15:48:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-27 15:48:20 --> Final output sent to browser
DEBUG - 2021-11-27 15:48:20 --> Total execution time: 0.0215
