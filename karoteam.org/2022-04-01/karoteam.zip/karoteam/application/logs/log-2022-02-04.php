<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-04 10:03:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 10:03:08 --> Config Class Initialized
INFO - 2022-02-04 10:03:08 --> Hooks Class Initialized
DEBUG - 2022-02-04 10:03:08 --> UTF-8 Support Enabled
INFO - 2022-02-04 10:03:08 --> Utf8 Class Initialized
INFO - 2022-02-04 10:03:08 --> URI Class Initialized
DEBUG - 2022-02-04 10:03:08 --> No URI present. Default controller set.
INFO - 2022-02-04 10:03:08 --> Router Class Initialized
INFO - 2022-02-04 10:03:08 --> Output Class Initialized
INFO - 2022-02-04 10:03:08 --> Security Class Initialized
DEBUG - 2022-02-04 10:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 10:03:08 --> Input Class Initialized
INFO - 2022-02-04 10:03:08 --> Language Class Initialized
INFO - 2022-02-04 10:03:08 --> Loader Class Initialized
INFO - 2022-02-04 10:03:08 --> Helper loaded: url_helper
INFO - 2022-02-04 10:03:08 --> Helper loaded: form_helper
INFO - 2022-02-04 10:03:08 --> Helper loaded: common_helper
INFO - 2022-02-04 10:03:08 --> Database Driver Class Initialized
DEBUG - 2022-02-04 10:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 10:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 10:03:08 --> Controller Class Initialized
INFO - 2022-02-04 10:03:08 --> Form Validation Class Initialized
DEBUG - 2022-02-04 10:03:08 --> Encrypt Class Initialized
DEBUG - 2022-02-04 10:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:03:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 10:03:08 --> Email Class Initialized
INFO - 2022-02-04 10:03:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 10:03:08 --> Calendar Class Initialized
INFO - 2022-02-04 10:03:08 --> Model "Login_model" initialized
INFO - 2022-02-04 10:03:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-04 10:03:08 --> Final output sent to browser
DEBUG - 2022-02-04 10:03:08 --> Total execution time: 0.0702
ERROR - 2022-02-04 14:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 14:18:27 --> Config Class Initialized
INFO - 2022-02-04 14:18:27 --> Hooks Class Initialized
DEBUG - 2022-02-04 14:18:27 --> UTF-8 Support Enabled
INFO - 2022-02-04 14:18:27 --> Utf8 Class Initialized
INFO - 2022-02-04 14:18:27 --> URI Class Initialized
DEBUG - 2022-02-04 14:18:27 --> No URI present. Default controller set.
INFO - 2022-02-04 14:18:27 --> Router Class Initialized
INFO - 2022-02-04 14:18:27 --> Output Class Initialized
INFO - 2022-02-04 14:18:27 --> Security Class Initialized
DEBUG - 2022-02-04 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 14:18:27 --> Input Class Initialized
INFO - 2022-02-04 14:18:27 --> Language Class Initialized
INFO - 2022-02-04 14:18:27 --> Loader Class Initialized
INFO - 2022-02-04 14:18:27 --> Helper loaded: url_helper
INFO - 2022-02-04 14:18:27 --> Helper loaded: form_helper
INFO - 2022-02-04 14:18:27 --> Helper loaded: common_helper
INFO - 2022-02-04 14:18:27 --> Database Driver Class Initialized
DEBUG - 2022-02-04 14:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 14:18:27 --> Controller Class Initialized
INFO - 2022-02-04 14:18:27 --> Form Validation Class Initialized
DEBUG - 2022-02-04 14:18:27 --> Encrypt Class Initialized
DEBUG - 2022-02-04 14:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:18:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 14:18:27 --> Email Class Initialized
INFO - 2022-02-04 14:18:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 14:18:27 --> Calendar Class Initialized
INFO - 2022-02-04 14:18:27 --> Model "Login_model" initialized
INFO - 2022-02-04 14:18:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-04 14:18:27 --> Final output sent to browser
DEBUG - 2022-02-04 14:18:27 --> Total execution time: 0.0237
ERROR - 2022-02-04 14:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 14:18:28 --> Config Class Initialized
INFO - 2022-02-04 14:18:28 --> Hooks Class Initialized
DEBUG - 2022-02-04 14:18:29 --> UTF-8 Support Enabled
INFO - 2022-02-04 14:18:29 --> Utf8 Class Initialized
INFO - 2022-02-04 14:18:29 --> URI Class Initialized
INFO - 2022-02-04 14:18:29 --> Router Class Initialized
INFO - 2022-02-04 14:18:29 --> Output Class Initialized
INFO - 2022-02-04 14:18:29 --> Security Class Initialized
DEBUG - 2022-02-04 14:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 14:18:29 --> Input Class Initialized
INFO - 2022-02-04 14:18:29 --> Language Class Initialized
ERROR - 2022-02-04 14:18:29 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-04 14:18:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 14:18:35 --> Config Class Initialized
INFO - 2022-02-04 14:18:35 --> Hooks Class Initialized
DEBUG - 2022-02-04 14:18:35 --> UTF-8 Support Enabled
INFO - 2022-02-04 14:18:35 --> Utf8 Class Initialized
INFO - 2022-02-04 14:18:35 --> URI Class Initialized
INFO - 2022-02-04 14:18:35 --> Router Class Initialized
INFO - 2022-02-04 14:18:35 --> Output Class Initialized
INFO - 2022-02-04 14:18:35 --> Security Class Initialized
DEBUG - 2022-02-04 14:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 14:18:35 --> Input Class Initialized
INFO - 2022-02-04 14:18:35 --> Language Class Initialized
INFO - 2022-02-04 14:18:35 --> Loader Class Initialized
INFO - 2022-02-04 14:18:35 --> Helper loaded: url_helper
INFO - 2022-02-04 14:18:35 --> Helper loaded: form_helper
INFO - 2022-02-04 14:18:35 --> Helper loaded: common_helper
INFO - 2022-02-04 14:18:35 --> Database Driver Class Initialized
DEBUG - 2022-02-04 14:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 14:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 14:18:35 --> Controller Class Initialized
INFO - 2022-02-04 14:18:35 --> Form Validation Class Initialized
DEBUG - 2022-02-04 14:18:35 --> Encrypt Class Initialized
DEBUG - 2022-02-04 14:18:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:18:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 14:18:35 --> Email Class Initialized
INFO - 2022-02-04 14:18:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 14:18:35 --> Calendar Class Initialized
INFO - 2022-02-04 14:18:35 --> Model "Login_model" initialized
INFO - 2022-02-04 14:18:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-04 14:18:35 --> Final output sent to browser
DEBUG - 2022-02-04 14:18:35 --> Total execution time: 0.1007
ERROR - 2022-02-04 14:18:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 14:18:36 --> Config Class Initialized
INFO - 2022-02-04 14:18:36 --> Hooks Class Initialized
DEBUG - 2022-02-04 14:18:36 --> UTF-8 Support Enabled
INFO - 2022-02-04 14:18:36 --> Utf8 Class Initialized
INFO - 2022-02-04 14:18:36 --> URI Class Initialized
DEBUG - 2022-02-04 14:18:36 --> No URI present. Default controller set.
INFO - 2022-02-04 14:18:36 --> Router Class Initialized
INFO - 2022-02-04 14:18:36 --> Output Class Initialized
INFO - 2022-02-04 14:18:36 --> Security Class Initialized
DEBUG - 2022-02-04 14:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 14:18:36 --> Input Class Initialized
INFO - 2022-02-04 14:18:36 --> Language Class Initialized
INFO - 2022-02-04 14:18:36 --> Loader Class Initialized
INFO - 2022-02-04 14:18:36 --> Helper loaded: url_helper
INFO - 2022-02-04 14:18:36 --> Helper loaded: form_helper
INFO - 2022-02-04 14:18:36 --> Helper loaded: common_helper
INFO - 2022-02-04 14:18:36 --> Database Driver Class Initialized
DEBUG - 2022-02-04 14:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 14:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 14:18:36 --> Controller Class Initialized
INFO - 2022-02-04 14:18:36 --> Form Validation Class Initialized
DEBUG - 2022-02-04 14:18:36 --> Encrypt Class Initialized
DEBUG - 2022-02-04 14:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:18:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 14:18:36 --> Email Class Initialized
INFO - 2022-02-04 14:18:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 14:18:36 --> Calendar Class Initialized
INFO - 2022-02-04 14:18:36 --> Model "Login_model" initialized
INFO - 2022-02-04 14:18:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-04 14:18:36 --> Final output sent to browser
DEBUG - 2022-02-04 14:18:36 --> Total execution time: 0.0507
ERROR - 2022-02-04 14:18:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 14:18:37 --> Config Class Initialized
INFO - 2022-02-04 14:18:37 --> Hooks Class Initialized
DEBUG - 2022-02-04 14:18:37 --> UTF-8 Support Enabled
INFO - 2022-02-04 14:18:37 --> Utf8 Class Initialized
INFO - 2022-02-04 14:18:37 --> URI Class Initialized
INFO - 2022-02-04 14:18:37 --> Router Class Initialized
INFO - 2022-02-04 14:18:37 --> Output Class Initialized
INFO - 2022-02-04 14:18:37 --> Security Class Initialized
DEBUG - 2022-02-04 14:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 14:18:37 --> Input Class Initialized
INFO - 2022-02-04 14:18:37 --> Language Class Initialized
INFO - 2022-02-04 14:18:37 --> Loader Class Initialized
INFO - 2022-02-04 14:18:37 --> Helper loaded: url_helper
INFO - 2022-02-04 14:18:37 --> Helper loaded: form_helper
INFO - 2022-02-04 14:18:37 --> Helper loaded: common_helper
INFO - 2022-02-04 14:18:37 --> Database Driver Class Initialized
DEBUG - 2022-02-04 14:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 14:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 14:18:37 --> Controller Class Initialized
INFO - 2022-02-04 14:18:37 --> Form Validation Class Initialized
DEBUG - 2022-02-04 14:18:37 --> Encrypt Class Initialized
DEBUG - 2022-02-04 14:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 14:18:37 --> Email Class Initialized
INFO - 2022-02-04 14:18:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 14:18:37 --> Calendar Class Initialized
INFO - 2022-02-04 14:18:37 --> Model "Login_model" initialized
ERROR - 2022-02-04 14:18:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 14:18:37 --> Config Class Initialized
INFO - 2022-02-04 14:18:37 --> Hooks Class Initialized
DEBUG - 2022-02-04 14:18:37 --> UTF-8 Support Enabled
INFO - 2022-02-04 14:18:37 --> Utf8 Class Initialized
INFO - 2022-02-04 14:18:37 --> URI Class Initialized
INFO - 2022-02-04 14:18:37 --> Router Class Initialized
INFO - 2022-02-04 14:18:37 --> Output Class Initialized
INFO - 2022-02-04 14:18:37 --> Security Class Initialized
DEBUG - 2022-02-04 14:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 14:18:37 --> Input Class Initialized
INFO - 2022-02-04 14:18:37 --> Language Class Initialized
INFO - 2022-02-04 14:18:37 --> Loader Class Initialized
INFO - 2022-02-04 14:18:37 --> Helper loaded: url_helper
INFO - 2022-02-04 14:18:37 --> Helper loaded: form_helper
INFO - 2022-02-04 14:18:37 --> Helper loaded: common_helper
INFO - 2022-02-04 14:18:37 --> Database Driver Class Initialized
DEBUG - 2022-02-04 14:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 14:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 14:18:37 --> Controller Class Initialized
INFO - 2022-02-04 14:18:37 --> Form Validation Class Initialized
DEBUG - 2022-02-04 14:18:37 --> Encrypt Class Initialized
DEBUG - 2022-02-04 14:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 14:18:37 --> Email Class Initialized
INFO - 2022-02-04 14:18:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 14:18:37 --> Calendar Class Initialized
INFO - 2022-02-04 14:18:37 --> Model "Login_model" initialized
ERROR - 2022-02-04 15:17:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 15:17:13 --> Config Class Initialized
INFO - 2022-02-04 15:17:13 --> Hooks Class Initialized
DEBUG - 2022-02-04 15:17:13 --> UTF-8 Support Enabled
INFO - 2022-02-04 15:17:13 --> Utf8 Class Initialized
INFO - 2022-02-04 15:17:13 --> URI Class Initialized
DEBUG - 2022-02-04 15:17:13 --> No URI present. Default controller set.
INFO - 2022-02-04 15:17:13 --> Router Class Initialized
INFO - 2022-02-04 15:17:13 --> Output Class Initialized
INFO - 2022-02-04 15:17:13 --> Security Class Initialized
DEBUG - 2022-02-04 15:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 15:17:13 --> Input Class Initialized
INFO - 2022-02-04 15:17:13 --> Language Class Initialized
INFO - 2022-02-04 15:17:13 --> Loader Class Initialized
INFO - 2022-02-04 15:17:13 --> Helper loaded: url_helper
INFO - 2022-02-04 15:17:13 --> Helper loaded: form_helper
INFO - 2022-02-04 15:17:13 --> Helper loaded: common_helper
INFO - 2022-02-04 15:17:13 --> Database Driver Class Initialized
DEBUG - 2022-02-04 15:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 15:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 15:17:13 --> Controller Class Initialized
INFO - 2022-02-04 15:17:13 --> Form Validation Class Initialized
DEBUG - 2022-02-04 15:17:13 --> Encrypt Class Initialized
DEBUG - 2022-02-04 15:17:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:17:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 15:17:13 --> Email Class Initialized
INFO - 2022-02-04 15:17:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 15:17:13 --> Calendar Class Initialized
INFO - 2022-02-04 15:17:13 --> Model "Login_model" initialized
INFO - 2022-02-04 15:17:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-04 15:17:13 --> Final output sent to browser
DEBUG - 2022-02-04 15:17:13 --> Total execution time: 0.0351
ERROR - 2022-02-04 19:43:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 19:43:40 --> Config Class Initialized
INFO - 2022-02-04 19:43:40 --> Hooks Class Initialized
DEBUG - 2022-02-04 19:43:40 --> UTF-8 Support Enabled
INFO - 2022-02-04 19:43:40 --> Utf8 Class Initialized
INFO - 2022-02-04 19:43:40 --> URI Class Initialized
DEBUG - 2022-02-04 19:43:40 --> No URI present. Default controller set.
INFO - 2022-02-04 19:43:40 --> Router Class Initialized
INFO - 2022-02-04 19:43:40 --> Output Class Initialized
INFO - 2022-02-04 19:43:40 --> Security Class Initialized
DEBUG - 2022-02-04 19:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 19:43:40 --> Input Class Initialized
INFO - 2022-02-04 19:43:40 --> Language Class Initialized
INFO - 2022-02-04 19:43:40 --> Loader Class Initialized
INFO - 2022-02-04 19:43:40 --> Helper loaded: url_helper
INFO - 2022-02-04 19:43:40 --> Helper loaded: form_helper
INFO - 2022-02-04 19:43:40 --> Helper loaded: common_helper
INFO - 2022-02-04 19:43:40 --> Database Driver Class Initialized
DEBUG - 2022-02-04 19:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 19:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 19:43:40 --> Controller Class Initialized
INFO - 2022-02-04 19:43:40 --> Form Validation Class Initialized
DEBUG - 2022-02-04 19:43:40 --> Encrypt Class Initialized
DEBUG - 2022-02-04 19:43:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 19:43:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 19:43:40 --> Email Class Initialized
INFO - 2022-02-04 19:43:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 19:43:40 --> Calendar Class Initialized
INFO - 2022-02-04 19:43:40 --> Model "Login_model" initialized
INFO - 2022-02-04 19:43:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-04 19:43:40 --> Final output sent to browser
DEBUG - 2022-02-04 19:43:40 --> Total execution time: 0.0419
ERROR - 2022-02-04 20:32:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 20:32:59 --> Config Class Initialized
INFO - 2022-02-04 20:32:59 --> Hooks Class Initialized
DEBUG - 2022-02-04 20:32:59 --> UTF-8 Support Enabled
INFO - 2022-02-04 20:32:59 --> Utf8 Class Initialized
INFO - 2022-02-04 20:32:59 --> URI Class Initialized
DEBUG - 2022-02-04 20:32:59 --> No URI present. Default controller set.
INFO - 2022-02-04 20:32:59 --> Router Class Initialized
INFO - 2022-02-04 20:32:59 --> Output Class Initialized
INFO - 2022-02-04 20:32:59 --> Security Class Initialized
DEBUG - 2022-02-04 20:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 20:32:59 --> Input Class Initialized
INFO - 2022-02-04 20:32:59 --> Language Class Initialized
INFO - 2022-02-04 20:32:59 --> Loader Class Initialized
INFO - 2022-02-04 20:32:59 --> Helper loaded: url_helper
INFO - 2022-02-04 20:32:59 --> Helper loaded: form_helper
INFO - 2022-02-04 20:32:59 --> Helper loaded: common_helper
INFO - 2022-02-04 20:32:59 --> Database Driver Class Initialized
DEBUG - 2022-02-04 20:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 20:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 20:32:59 --> Controller Class Initialized
INFO - 2022-02-04 20:32:59 --> Form Validation Class Initialized
DEBUG - 2022-02-04 20:32:59 --> Encrypt Class Initialized
DEBUG - 2022-02-04 20:32:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 20:32:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 20:32:59 --> Email Class Initialized
INFO - 2022-02-04 20:32:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 20:32:59 --> Calendar Class Initialized
INFO - 2022-02-04 20:32:59 --> Model "Login_model" initialized
INFO - 2022-02-04 20:32:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-04 20:32:59 --> Final output sent to browser
DEBUG - 2022-02-04 20:32:59 --> Total execution time: 0.0233
ERROR - 2022-02-04 22:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-04 22:20:10 --> Config Class Initialized
INFO - 2022-02-04 22:20:10 --> Hooks Class Initialized
DEBUG - 2022-02-04 22:20:10 --> UTF-8 Support Enabled
INFO - 2022-02-04 22:20:10 --> Utf8 Class Initialized
INFO - 2022-02-04 22:20:10 --> URI Class Initialized
DEBUG - 2022-02-04 22:20:10 --> No URI present. Default controller set.
INFO - 2022-02-04 22:20:10 --> Router Class Initialized
INFO - 2022-02-04 22:20:10 --> Output Class Initialized
INFO - 2022-02-04 22:20:10 --> Security Class Initialized
DEBUG - 2022-02-04 22:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-04 22:20:10 --> Input Class Initialized
INFO - 2022-02-04 22:20:10 --> Language Class Initialized
INFO - 2022-02-04 22:20:10 --> Loader Class Initialized
INFO - 2022-02-04 22:20:10 --> Helper loaded: url_helper
INFO - 2022-02-04 22:20:10 --> Helper loaded: form_helper
INFO - 2022-02-04 22:20:10 --> Helper loaded: common_helper
INFO - 2022-02-04 22:20:10 --> Database Driver Class Initialized
DEBUG - 2022-02-04 22:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-04 22:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-04 22:20:10 --> Controller Class Initialized
INFO - 2022-02-04 22:20:10 --> Form Validation Class Initialized
DEBUG - 2022-02-04 22:20:10 --> Encrypt Class Initialized
DEBUG - 2022-02-04 22:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 22:20:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-04 22:20:10 --> Email Class Initialized
INFO - 2022-02-04 22:20:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-04 22:20:10 --> Calendar Class Initialized
INFO - 2022-02-04 22:20:10 --> Model "Login_model" initialized
INFO - 2022-02-04 22:20:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-04 22:20:10 --> Final output sent to browser
DEBUG - 2022-02-04 22:20:10 --> Total execution time: 0.0362
