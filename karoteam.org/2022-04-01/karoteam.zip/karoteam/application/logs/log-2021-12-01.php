<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-01 00:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 00:29:07 --> Config Class Initialized
INFO - 2021-12-01 00:29:07 --> Hooks Class Initialized
DEBUG - 2021-12-01 00:29:07 --> UTF-8 Support Enabled
INFO - 2021-12-01 00:29:07 --> Utf8 Class Initialized
INFO - 2021-12-01 00:29:07 --> URI Class Initialized
DEBUG - 2021-12-01 00:29:07 --> No URI present. Default controller set.
INFO - 2021-12-01 00:29:07 --> Router Class Initialized
INFO - 2021-12-01 00:29:07 --> Output Class Initialized
INFO - 2021-12-01 00:29:07 --> Security Class Initialized
DEBUG - 2021-12-01 00:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 00:29:07 --> Input Class Initialized
INFO - 2021-12-01 00:29:07 --> Language Class Initialized
INFO - 2021-12-01 00:29:07 --> Loader Class Initialized
INFO - 2021-12-01 00:29:07 --> Helper loaded: url_helper
INFO - 2021-12-01 00:29:07 --> Helper loaded: form_helper
INFO - 2021-12-01 00:29:07 --> Helper loaded: common_helper
INFO - 2021-12-01 00:29:07 --> Database Driver Class Initialized
DEBUG - 2021-12-01 00:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 00:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 00:29:07 --> Controller Class Initialized
INFO - 2021-12-01 00:29:07 --> Form Validation Class Initialized
DEBUG - 2021-12-01 00:29:07 --> Encrypt Class Initialized
DEBUG - 2021-12-01 00:29:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 00:29:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 00:29:07 --> Email Class Initialized
INFO - 2021-12-01 00:29:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 00:29:07 --> Calendar Class Initialized
INFO - 2021-12-01 00:29:07 --> Model "Login_model" initialized
INFO - 2021-12-01 00:29:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 00:29:07 --> Final output sent to browser
DEBUG - 2021-12-01 00:29:07 --> Total execution time: 0.0298
ERROR - 2021-12-01 09:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 09:22:36 --> Config Class Initialized
INFO - 2021-12-01 09:22:36 --> Hooks Class Initialized
DEBUG - 2021-12-01 09:22:36 --> UTF-8 Support Enabled
INFO - 2021-12-01 09:22:36 --> Utf8 Class Initialized
INFO - 2021-12-01 09:22:36 --> URI Class Initialized
DEBUG - 2021-12-01 09:22:36 --> No URI present. Default controller set.
INFO - 2021-12-01 09:22:36 --> Router Class Initialized
INFO - 2021-12-01 09:22:36 --> Output Class Initialized
INFO - 2021-12-01 09:22:36 --> Security Class Initialized
DEBUG - 2021-12-01 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 09:22:36 --> Input Class Initialized
INFO - 2021-12-01 09:22:36 --> Language Class Initialized
INFO - 2021-12-01 09:22:36 --> Loader Class Initialized
INFO - 2021-12-01 09:22:36 --> Helper loaded: url_helper
INFO - 2021-12-01 09:22:36 --> Helper loaded: form_helper
INFO - 2021-12-01 09:22:36 --> Helper loaded: common_helper
INFO - 2021-12-01 09:22:36 --> Database Driver Class Initialized
DEBUG - 2021-12-01 09:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 09:22:36 --> Controller Class Initialized
INFO - 2021-12-01 09:22:36 --> Form Validation Class Initialized
DEBUG - 2021-12-01 09:22:36 --> Encrypt Class Initialized
DEBUG - 2021-12-01 09:22:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 09:22:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 09:22:36 --> Email Class Initialized
INFO - 2021-12-01 09:22:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 09:22:36 --> Calendar Class Initialized
INFO - 2021-12-01 09:22:36 --> Model "Login_model" initialized
INFO - 2021-12-01 09:22:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 09:22:36 --> Final output sent to browser
DEBUG - 2021-12-01 09:22:36 --> Total execution time: 0.0866
ERROR - 2021-12-01 10:00:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 10:00:14 --> Config Class Initialized
INFO - 2021-12-01 10:00:14 --> Hooks Class Initialized
DEBUG - 2021-12-01 10:00:14 --> UTF-8 Support Enabled
INFO - 2021-12-01 10:00:14 --> Utf8 Class Initialized
INFO - 2021-12-01 10:00:14 --> URI Class Initialized
DEBUG - 2021-12-01 10:00:14 --> No URI present. Default controller set.
INFO - 2021-12-01 10:00:14 --> Router Class Initialized
INFO - 2021-12-01 10:00:14 --> Output Class Initialized
INFO - 2021-12-01 10:00:14 --> Security Class Initialized
DEBUG - 2021-12-01 10:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 10:00:14 --> Input Class Initialized
INFO - 2021-12-01 10:00:14 --> Language Class Initialized
INFO - 2021-12-01 10:00:14 --> Loader Class Initialized
INFO - 2021-12-01 10:00:14 --> Helper loaded: url_helper
INFO - 2021-12-01 10:00:14 --> Helper loaded: form_helper
INFO - 2021-12-01 10:00:14 --> Helper loaded: common_helper
INFO - 2021-12-01 10:00:14 --> Database Driver Class Initialized
DEBUG - 2021-12-01 10:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 10:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 10:00:14 --> Controller Class Initialized
INFO - 2021-12-01 10:00:14 --> Form Validation Class Initialized
DEBUG - 2021-12-01 10:00:14 --> Encrypt Class Initialized
DEBUG - 2021-12-01 10:00:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 10:00:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 10:00:14 --> Email Class Initialized
INFO - 2021-12-01 10:00:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 10:00:14 --> Calendar Class Initialized
INFO - 2021-12-01 10:00:14 --> Model "Login_model" initialized
INFO - 2021-12-01 10:00:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 10:00:14 --> Final output sent to browser
DEBUG - 2021-12-01 10:00:14 --> Total execution time: 0.0263
ERROR - 2021-12-01 10:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 10:34:30 --> Config Class Initialized
INFO - 2021-12-01 10:34:30 --> Hooks Class Initialized
DEBUG - 2021-12-01 10:34:30 --> UTF-8 Support Enabled
INFO - 2021-12-01 10:34:30 --> Utf8 Class Initialized
INFO - 2021-12-01 10:34:30 --> URI Class Initialized
DEBUG - 2021-12-01 10:34:30 --> No URI present. Default controller set.
INFO - 2021-12-01 10:34:30 --> Router Class Initialized
INFO - 2021-12-01 10:34:30 --> Output Class Initialized
INFO - 2021-12-01 10:34:30 --> Security Class Initialized
DEBUG - 2021-12-01 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 10:34:30 --> Input Class Initialized
INFO - 2021-12-01 10:34:30 --> Language Class Initialized
INFO - 2021-12-01 10:34:30 --> Loader Class Initialized
INFO - 2021-12-01 10:34:30 --> Helper loaded: url_helper
INFO - 2021-12-01 10:34:30 --> Helper loaded: form_helper
INFO - 2021-12-01 10:34:30 --> Helper loaded: common_helper
INFO - 2021-12-01 10:34:30 --> Database Driver Class Initialized
DEBUG - 2021-12-01 10:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 10:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 10:34:30 --> Controller Class Initialized
INFO - 2021-12-01 10:34:30 --> Form Validation Class Initialized
DEBUG - 2021-12-01 10:34:30 --> Encrypt Class Initialized
DEBUG - 2021-12-01 10:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 10:34:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 10:34:30 --> Email Class Initialized
INFO - 2021-12-01 10:34:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 10:34:30 --> Calendar Class Initialized
INFO - 2021-12-01 10:34:30 --> Model "Login_model" initialized
INFO - 2021-12-01 10:34:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 10:34:30 --> Final output sent to browser
DEBUG - 2021-12-01 10:34:30 --> Total execution time: 0.0255
ERROR - 2021-12-01 10:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 10:34:30 --> Config Class Initialized
INFO - 2021-12-01 10:34:30 --> Hooks Class Initialized
DEBUG - 2021-12-01 10:34:30 --> UTF-8 Support Enabled
INFO - 2021-12-01 10:34:30 --> Utf8 Class Initialized
INFO - 2021-12-01 10:34:30 --> URI Class Initialized
DEBUG - 2021-12-01 10:34:30 --> No URI present. Default controller set.
INFO - 2021-12-01 10:34:30 --> Router Class Initialized
INFO - 2021-12-01 10:34:30 --> Output Class Initialized
INFO - 2021-12-01 10:34:30 --> Security Class Initialized
DEBUG - 2021-12-01 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 10:34:30 --> Input Class Initialized
INFO - 2021-12-01 10:34:30 --> Language Class Initialized
INFO - 2021-12-01 10:34:30 --> Loader Class Initialized
INFO - 2021-12-01 10:34:30 --> Helper loaded: url_helper
INFO - 2021-12-01 10:34:30 --> Helper loaded: form_helper
INFO - 2021-12-01 10:34:30 --> Helper loaded: common_helper
INFO - 2021-12-01 10:34:30 --> Database Driver Class Initialized
DEBUG - 2021-12-01 10:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 10:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 10:34:30 --> Controller Class Initialized
INFO - 2021-12-01 10:34:30 --> Form Validation Class Initialized
DEBUG - 2021-12-01 10:34:30 --> Encrypt Class Initialized
DEBUG - 2021-12-01 10:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 10:34:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 10:34:30 --> Email Class Initialized
INFO - 2021-12-01 10:34:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 10:34:30 --> Calendar Class Initialized
INFO - 2021-12-01 10:34:30 --> Model "Login_model" initialized
INFO - 2021-12-01 10:34:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 10:34:30 --> Final output sent to browser
DEBUG - 2021-12-01 10:34:30 --> Total execution time: 0.0226
ERROR - 2021-12-01 14:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:41 --> Config Class Initialized
INFO - 2021-12-01 14:17:41 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:41 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:41 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:41 --> URI Class Initialized
DEBUG - 2021-12-01 14:17:41 --> No URI present. Default controller set.
INFO - 2021-12-01 14:17:41 --> Router Class Initialized
INFO - 2021-12-01 14:17:41 --> Output Class Initialized
INFO - 2021-12-01 14:17:41 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:41 --> Input Class Initialized
INFO - 2021-12-01 14:17:41 --> Language Class Initialized
INFO - 2021-12-01 14:17:41 --> Loader Class Initialized
INFO - 2021-12-01 14:17:41 --> Helper loaded: url_helper
INFO - 2021-12-01 14:17:41 --> Helper loaded: form_helper
INFO - 2021-12-01 14:17:41 --> Helper loaded: common_helper
INFO - 2021-12-01 14:17:41 --> Database Driver Class Initialized
DEBUG - 2021-12-01 14:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 14:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 14:17:41 --> Controller Class Initialized
INFO - 2021-12-01 14:17:41 --> Form Validation Class Initialized
DEBUG - 2021-12-01 14:17:41 --> Encrypt Class Initialized
DEBUG - 2021-12-01 14:17:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 14:17:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 14:17:41 --> Email Class Initialized
INFO - 2021-12-01 14:17:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 14:17:41 --> Calendar Class Initialized
INFO - 2021-12-01 14:17:41 --> Model "Login_model" initialized
INFO - 2021-12-01 14:17:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 14:17:41 --> Final output sent to browser
DEBUG - 2021-12-01 14:17:41 --> Total execution time: 0.0239
ERROR - 2021-12-01 14:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:41 --> Config Class Initialized
INFO - 2021-12-01 14:17:41 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:41 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:41 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:41 --> URI Class Initialized
DEBUG - 2021-12-01 14:17:41 --> No URI present. Default controller set.
INFO - 2021-12-01 14:17:41 --> Router Class Initialized
INFO - 2021-12-01 14:17:41 --> Output Class Initialized
INFO - 2021-12-01 14:17:41 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:41 --> Input Class Initialized
INFO - 2021-12-01 14:17:41 --> Language Class Initialized
INFO - 2021-12-01 14:17:41 --> Loader Class Initialized
INFO - 2021-12-01 14:17:41 --> Helper loaded: url_helper
INFO - 2021-12-01 14:17:41 --> Helper loaded: form_helper
INFO - 2021-12-01 14:17:41 --> Helper loaded: common_helper
INFO - 2021-12-01 14:17:41 --> Database Driver Class Initialized
DEBUG - 2021-12-01 14:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 14:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 14:17:41 --> Controller Class Initialized
INFO - 2021-12-01 14:17:41 --> Form Validation Class Initialized
DEBUG - 2021-12-01 14:17:41 --> Encrypt Class Initialized
DEBUG - 2021-12-01 14:17:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 14:17:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 14:17:41 --> Email Class Initialized
INFO - 2021-12-01 14:17:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 14:17:41 --> Calendar Class Initialized
INFO - 2021-12-01 14:17:41 --> Model "Login_model" initialized
INFO - 2021-12-01 14:17:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 14:17:41 --> Final output sent to browser
DEBUG - 2021-12-01 14:17:41 --> Total execution time: 0.0301
ERROR - 2021-12-01 14:17:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:42 --> Config Class Initialized
INFO - 2021-12-01 14:17:42 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:42 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:42 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:42 --> URI Class Initialized
INFO - 2021-12-01 14:17:42 --> Router Class Initialized
INFO - 2021-12-01 14:17:42 --> Output Class Initialized
INFO - 2021-12-01 14:17:42 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:42 --> Input Class Initialized
INFO - 2021-12-01 14:17:42 --> Language Class Initialized
ERROR - 2021-12-01 14:17:42 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-01 14:17:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:42 --> Config Class Initialized
INFO - 2021-12-01 14:17:42 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:42 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:42 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:42 --> URI Class Initialized
INFO - 2021-12-01 14:17:42 --> Router Class Initialized
INFO - 2021-12-01 14:17:42 --> Output Class Initialized
INFO - 2021-12-01 14:17:42 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:42 --> Input Class Initialized
INFO - 2021-12-01 14:17:42 --> Language Class Initialized
ERROR - 2021-12-01 14:17:42 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-01 14:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:43 --> Config Class Initialized
INFO - 2021-12-01 14:17:43 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:43 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:43 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:43 --> URI Class Initialized
INFO - 2021-12-01 14:17:43 --> Router Class Initialized
INFO - 2021-12-01 14:17:43 --> Output Class Initialized
INFO - 2021-12-01 14:17:43 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:43 --> Input Class Initialized
INFO - 2021-12-01 14:17:43 --> Language Class Initialized
ERROR - 2021-12-01 14:17:43 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-01 14:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:43 --> Config Class Initialized
INFO - 2021-12-01 14:17:43 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:43 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:43 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:43 --> URI Class Initialized
INFO - 2021-12-01 14:17:43 --> Router Class Initialized
INFO - 2021-12-01 14:17:43 --> Output Class Initialized
INFO - 2021-12-01 14:17:43 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:43 --> Input Class Initialized
INFO - 2021-12-01 14:17:43 --> Language Class Initialized
ERROR - 2021-12-01 14:17:43 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-01 14:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:44 --> Config Class Initialized
INFO - 2021-12-01 14:17:44 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:44 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:44 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:44 --> URI Class Initialized
INFO - 2021-12-01 14:17:44 --> Router Class Initialized
INFO - 2021-12-01 14:17:44 --> Output Class Initialized
INFO - 2021-12-01 14:17:44 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:44 --> Input Class Initialized
INFO - 2021-12-01 14:17:44 --> Language Class Initialized
ERROR - 2021-12-01 14:17:44 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-01 14:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:44 --> Config Class Initialized
INFO - 2021-12-01 14:17:44 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:44 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:44 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:44 --> URI Class Initialized
INFO - 2021-12-01 14:17:44 --> Router Class Initialized
INFO - 2021-12-01 14:17:44 --> Output Class Initialized
INFO - 2021-12-01 14:17:44 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:44 --> Input Class Initialized
INFO - 2021-12-01 14:17:44 --> Language Class Initialized
ERROR - 2021-12-01 14:17:44 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-01 14:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:45 --> Config Class Initialized
INFO - 2021-12-01 14:17:45 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:45 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:45 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:45 --> URI Class Initialized
INFO - 2021-12-01 14:17:45 --> Router Class Initialized
INFO - 2021-12-01 14:17:45 --> Output Class Initialized
INFO - 2021-12-01 14:17:45 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:45 --> Input Class Initialized
INFO - 2021-12-01 14:17:45 --> Language Class Initialized
ERROR - 2021-12-01 14:17:45 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-01 14:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:45 --> Config Class Initialized
INFO - 2021-12-01 14:17:45 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:45 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:45 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:45 --> URI Class Initialized
INFO - 2021-12-01 14:17:45 --> Router Class Initialized
INFO - 2021-12-01 14:17:45 --> Output Class Initialized
INFO - 2021-12-01 14:17:45 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:45 --> Input Class Initialized
INFO - 2021-12-01 14:17:45 --> Language Class Initialized
ERROR - 2021-12-01 14:17:45 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-12-01 14:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:46 --> Config Class Initialized
INFO - 2021-12-01 14:17:46 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:46 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:46 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:46 --> URI Class Initialized
INFO - 2021-12-01 14:17:46 --> Router Class Initialized
INFO - 2021-12-01 14:17:46 --> Output Class Initialized
INFO - 2021-12-01 14:17:46 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:46 --> Input Class Initialized
INFO - 2021-12-01 14:17:46 --> Language Class Initialized
ERROR - 2021-12-01 14:17:46 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-01 14:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:46 --> Config Class Initialized
INFO - 2021-12-01 14:17:46 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:46 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:46 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:46 --> URI Class Initialized
INFO - 2021-12-01 14:17:46 --> Router Class Initialized
INFO - 2021-12-01 14:17:46 --> Output Class Initialized
INFO - 2021-12-01 14:17:46 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:46 --> Input Class Initialized
INFO - 2021-12-01 14:17:46 --> Language Class Initialized
ERROR - 2021-12-01 14:17:46 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-01 14:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:47 --> Config Class Initialized
INFO - 2021-12-01 14:17:47 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:47 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:47 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:47 --> URI Class Initialized
INFO - 2021-12-01 14:17:47 --> Router Class Initialized
INFO - 2021-12-01 14:17:47 --> Output Class Initialized
INFO - 2021-12-01 14:17:47 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:47 --> Input Class Initialized
INFO - 2021-12-01 14:17:47 --> Language Class Initialized
ERROR - 2021-12-01 14:17:47 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-01 14:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:47 --> Config Class Initialized
INFO - 2021-12-01 14:17:47 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:47 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:47 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:47 --> URI Class Initialized
INFO - 2021-12-01 14:17:47 --> Router Class Initialized
INFO - 2021-12-01 14:17:47 --> Output Class Initialized
INFO - 2021-12-01 14:17:47 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:47 --> Input Class Initialized
INFO - 2021-12-01 14:17:47 --> Language Class Initialized
ERROR - 2021-12-01 14:17:47 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-01 14:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:48 --> Config Class Initialized
INFO - 2021-12-01 14:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:48 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:48 --> URI Class Initialized
INFO - 2021-12-01 14:17:48 --> Router Class Initialized
INFO - 2021-12-01 14:17:48 --> Output Class Initialized
INFO - 2021-12-01 14:17:48 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:48 --> Input Class Initialized
INFO - 2021-12-01 14:17:48 --> Language Class Initialized
ERROR - 2021-12-01 14:17:48 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-01 14:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:48 --> Config Class Initialized
INFO - 2021-12-01 14:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:48 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:48 --> URI Class Initialized
INFO - 2021-12-01 14:17:48 --> Router Class Initialized
INFO - 2021-12-01 14:17:48 --> Output Class Initialized
INFO - 2021-12-01 14:17:48 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:48 --> Input Class Initialized
INFO - 2021-12-01 14:17:48 --> Language Class Initialized
ERROR - 2021-12-01 14:17:48 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-01 14:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:48 --> Config Class Initialized
INFO - 2021-12-01 14:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:48 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:48 --> URI Class Initialized
INFO - 2021-12-01 14:17:48 --> Router Class Initialized
INFO - 2021-12-01 14:17:48 --> Output Class Initialized
INFO - 2021-12-01 14:17:48 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:48 --> Input Class Initialized
INFO - 2021-12-01 14:17:48 --> Language Class Initialized
ERROR - 2021-12-01 14:17:48 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-01 14:17:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:17:49 --> Config Class Initialized
INFO - 2021-12-01 14:17:49 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:17:49 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:17:49 --> Utf8 Class Initialized
INFO - 2021-12-01 14:17:49 --> URI Class Initialized
INFO - 2021-12-01 14:17:49 --> Router Class Initialized
INFO - 2021-12-01 14:17:49 --> Output Class Initialized
INFO - 2021-12-01 14:17:49 --> Security Class Initialized
DEBUG - 2021-12-01 14:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:17:49 --> Input Class Initialized
INFO - 2021-12-01 14:17:49 --> Language Class Initialized
ERROR - 2021-12-01 14:17:49 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-01 14:18:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:18:53 --> Config Class Initialized
INFO - 2021-12-01 14:18:53 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:18:53 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:18:53 --> Utf8 Class Initialized
INFO - 2021-12-01 14:18:53 --> URI Class Initialized
DEBUG - 2021-12-01 14:18:53 --> No URI present. Default controller set.
INFO - 2021-12-01 14:18:53 --> Router Class Initialized
INFO - 2021-12-01 14:18:53 --> Output Class Initialized
INFO - 2021-12-01 14:18:53 --> Security Class Initialized
DEBUG - 2021-12-01 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:18:53 --> Input Class Initialized
INFO - 2021-12-01 14:18:53 --> Language Class Initialized
INFO - 2021-12-01 14:18:53 --> Loader Class Initialized
INFO - 2021-12-01 14:18:53 --> Helper loaded: url_helper
INFO - 2021-12-01 14:18:53 --> Helper loaded: form_helper
INFO - 2021-12-01 14:18:53 --> Helper loaded: common_helper
INFO - 2021-12-01 14:18:53 --> Database Driver Class Initialized
DEBUG - 2021-12-01 14:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 14:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 14:18:53 --> Controller Class Initialized
INFO - 2021-12-01 14:18:53 --> Form Validation Class Initialized
DEBUG - 2021-12-01 14:18:53 --> Encrypt Class Initialized
DEBUG - 2021-12-01 14:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 14:18:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 14:18:53 --> Email Class Initialized
INFO - 2021-12-01 14:18:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 14:18:53 --> Calendar Class Initialized
INFO - 2021-12-01 14:18:53 --> Model "Login_model" initialized
INFO - 2021-12-01 14:18:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 14:18:53 --> Final output sent to browser
DEBUG - 2021-12-01 14:18:53 --> Total execution time: 0.0252
ERROR - 2021-12-01 14:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:18:55 --> Config Class Initialized
INFO - 2021-12-01 14:18:55 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:18:55 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:18:55 --> Utf8 Class Initialized
INFO - 2021-12-01 14:18:55 --> URI Class Initialized
INFO - 2021-12-01 14:18:55 --> Router Class Initialized
INFO - 2021-12-01 14:18:55 --> Output Class Initialized
INFO - 2021-12-01 14:18:55 --> Security Class Initialized
DEBUG - 2021-12-01 14:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:18:55 --> Input Class Initialized
INFO - 2021-12-01 14:18:55 --> Language Class Initialized
ERROR - 2021-12-01 14:18:55 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-01 14:19:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:19:11 --> Config Class Initialized
INFO - 2021-12-01 14:19:11 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:19:11 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:19:11 --> Utf8 Class Initialized
INFO - 2021-12-01 14:19:11 --> URI Class Initialized
INFO - 2021-12-01 14:19:11 --> Router Class Initialized
INFO - 2021-12-01 14:19:11 --> Output Class Initialized
INFO - 2021-12-01 14:19:11 --> Security Class Initialized
DEBUG - 2021-12-01 14:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:19:11 --> Input Class Initialized
INFO - 2021-12-01 14:19:11 --> Language Class Initialized
INFO - 2021-12-01 14:19:11 --> Loader Class Initialized
INFO - 2021-12-01 14:19:11 --> Helper loaded: url_helper
INFO - 2021-12-01 14:19:11 --> Helper loaded: form_helper
INFO - 2021-12-01 14:19:11 --> Helper loaded: common_helper
INFO - 2021-12-01 14:19:11 --> Database Driver Class Initialized
DEBUG - 2021-12-01 14:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 14:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 14:19:11 --> Controller Class Initialized
INFO - 2021-12-01 14:19:11 --> Form Validation Class Initialized
DEBUG - 2021-12-01 14:19:11 --> Encrypt Class Initialized
DEBUG - 2021-12-01 14:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 14:19:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 14:19:11 --> Email Class Initialized
INFO - 2021-12-01 14:19:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 14:19:11 --> Calendar Class Initialized
INFO - 2021-12-01 14:19:11 --> Model "Login_model" initialized
ERROR - 2021-12-01 14:19:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:19:11 --> Config Class Initialized
INFO - 2021-12-01 14:19:11 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:19:11 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:19:11 --> Utf8 Class Initialized
INFO - 2021-12-01 14:19:11 --> URI Class Initialized
INFO - 2021-12-01 14:19:11 --> Router Class Initialized
INFO - 2021-12-01 14:19:11 --> Output Class Initialized
INFO - 2021-12-01 14:19:11 --> Security Class Initialized
DEBUG - 2021-12-01 14:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:19:11 --> Input Class Initialized
INFO - 2021-12-01 14:19:11 --> Language Class Initialized
INFO - 2021-12-01 14:19:11 --> Loader Class Initialized
INFO - 2021-12-01 14:19:11 --> Helper loaded: url_helper
INFO - 2021-12-01 14:19:11 --> Helper loaded: form_helper
INFO - 2021-12-01 14:19:11 --> Helper loaded: common_helper
INFO - 2021-12-01 14:19:11 --> Database Driver Class Initialized
DEBUG - 2021-12-01 14:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 14:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 14:19:11 --> Controller Class Initialized
INFO - 2021-12-01 14:19:11 --> Form Validation Class Initialized
DEBUG - 2021-12-01 14:19:11 --> Encrypt Class Initialized
DEBUG - 2021-12-01 14:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 14:19:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 14:19:11 --> Email Class Initialized
INFO - 2021-12-01 14:19:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 14:19:11 --> Calendar Class Initialized
INFO - 2021-12-01 14:19:11 --> Model "Login_model" initialized
ERROR - 2021-12-01 14:19:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:19:12 --> Config Class Initialized
INFO - 2021-12-01 14:19:12 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:19:12 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:19:12 --> Utf8 Class Initialized
INFO - 2021-12-01 14:19:12 --> URI Class Initialized
DEBUG - 2021-12-01 14:19:12 --> No URI present. Default controller set.
INFO - 2021-12-01 14:19:12 --> Router Class Initialized
INFO - 2021-12-01 14:19:12 --> Output Class Initialized
INFO - 2021-12-01 14:19:12 --> Security Class Initialized
DEBUG - 2021-12-01 14:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:19:12 --> Input Class Initialized
INFO - 2021-12-01 14:19:12 --> Language Class Initialized
INFO - 2021-12-01 14:19:12 --> Loader Class Initialized
INFO - 2021-12-01 14:19:12 --> Helper loaded: url_helper
INFO - 2021-12-01 14:19:12 --> Helper loaded: form_helper
INFO - 2021-12-01 14:19:12 --> Helper loaded: common_helper
INFO - 2021-12-01 14:19:12 --> Database Driver Class Initialized
DEBUG - 2021-12-01 14:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 14:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 14:19:12 --> Controller Class Initialized
INFO - 2021-12-01 14:19:12 --> Form Validation Class Initialized
DEBUG - 2021-12-01 14:19:12 --> Encrypt Class Initialized
DEBUG - 2021-12-01 14:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 14:19:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 14:19:12 --> Email Class Initialized
INFO - 2021-12-01 14:19:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 14:19:12 --> Calendar Class Initialized
INFO - 2021-12-01 14:19:12 --> Model "Login_model" initialized
INFO - 2021-12-01 14:19:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 14:19:12 --> Final output sent to browser
DEBUG - 2021-12-01 14:19:12 --> Total execution time: 0.0294
ERROR - 2021-12-01 14:19:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-01 14:19:13 --> Config Class Initialized
INFO - 2021-12-01 14:19:13 --> Hooks Class Initialized
DEBUG - 2021-12-01 14:19:13 --> UTF-8 Support Enabled
INFO - 2021-12-01 14:19:13 --> Utf8 Class Initialized
INFO - 2021-12-01 14:19:13 --> URI Class Initialized
INFO - 2021-12-01 14:19:13 --> Router Class Initialized
INFO - 2021-12-01 14:19:13 --> Output Class Initialized
INFO - 2021-12-01 14:19:13 --> Security Class Initialized
DEBUG - 2021-12-01 14:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-01 14:19:13 --> Input Class Initialized
INFO - 2021-12-01 14:19:13 --> Language Class Initialized
INFO - 2021-12-01 14:19:13 --> Loader Class Initialized
INFO - 2021-12-01 14:19:13 --> Helper loaded: url_helper
INFO - 2021-12-01 14:19:13 --> Helper loaded: form_helper
INFO - 2021-12-01 14:19:13 --> Helper loaded: common_helper
INFO - 2021-12-01 14:19:13 --> Database Driver Class Initialized
DEBUG - 2021-12-01 14:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-01 14:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-01 14:19:13 --> Controller Class Initialized
INFO - 2021-12-01 14:19:13 --> Form Validation Class Initialized
DEBUG - 2021-12-01 14:19:13 --> Encrypt Class Initialized
DEBUG - 2021-12-01 14:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-01 14:19:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-01 14:19:13 --> Email Class Initialized
INFO - 2021-12-01 14:19:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-01 14:19:13 --> Calendar Class Initialized
INFO - 2021-12-01 14:19:13 --> Model "Login_model" initialized
INFO - 2021-12-01 14:19:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-01 14:19:13 --> Final output sent to browser
DEBUG - 2021-12-01 14:19:13 --> Total execution time: 0.0217
