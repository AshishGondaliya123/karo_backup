<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-20 02:27:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-20 02:27:53 --> Config Class Initialized
INFO - 2021-10-20 02:27:53 --> Hooks Class Initialized
DEBUG - 2021-10-20 02:27:53 --> UTF-8 Support Enabled
INFO - 2021-10-20 02:27:53 --> Utf8 Class Initialized
INFO - 2021-10-20 02:27:53 --> URI Class Initialized
INFO - 2021-10-20 02:27:53 --> Router Class Initialized
INFO - 2021-10-20 02:27:53 --> Output Class Initialized
INFO - 2021-10-20 02:27:53 --> Security Class Initialized
DEBUG - 2021-10-20 02:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-20 02:27:53 --> Input Class Initialized
INFO - 2021-10-20 02:27:53 --> Language Class Initialized
ERROR - 2021-10-20 02:27:53 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-10-20 02:53:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-20 02:53:58 --> Config Class Initialized
INFO - 2021-10-20 02:53:58 --> Hooks Class Initialized
DEBUG - 2021-10-20 02:53:58 --> UTF-8 Support Enabled
INFO - 2021-10-20 02:53:58 --> Utf8 Class Initialized
INFO - 2021-10-20 02:53:58 --> URI Class Initialized
DEBUG - 2021-10-20 02:53:58 --> No URI present. Default controller set.
INFO - 2021-10-20 02:53:58 --> Router Class Initialized
INFO - 2021-10-20 02:53:58 --> Output Class Initialized
INFO - 2021-10-20 02:53:58 --> Security Class Initialized
DEBUG - 2021-10-20 02:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-20 02:53:58 --> Input Class Initialized
INFO - 2021-10-20 02:53:58 --> Language Class Initialized
INFO - 2021-10-20 02:53:58 --> Loader Class Initialized
INFO - 2021-10-20 02:53:58 --> Helper loaded: url_helper
INFO - 2021-10-20 02:53:58 --> Helper loaded: form_helper
INFO - 2021-10-20 02:53:58 --> Helper loaded: common_helper
INFO - 2021-10-20 02:53:58 --> Database Driver Class Initialized
DEBUG - 2021-10-20 02:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-20 02:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-20 02:53:58 --> Controller Class Initialized
INFO - 2021-10-20 02:53:58 --> Form Validation Class Initialized
DEBUG - 2021-10-20 02:53:58 --> Encrypt Class Initialized
DEBUG - 2021-10-20 02:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-20 02:53:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-20 02:53:58 --> Email Class Initialized
INFO - 2021-10-20 02:53:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-20 02:53:58 --> Calendar Class Initialized
INFO - 2021-10-20 02:53:58 --> Model "Login_model" initialized
INFO - 2021-10-20 02:53:58 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-20 02:53:58 --> Final output sent to browser
DEBUG - 2021-10-20 02:53:58 --> Total execution time: 0.1499
ERROR - 2021-10-20 02:53:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-20 02:53:59 --> Config Class Initialized
INFO - 2021-10-20 02:53:59 --> Hooks Class Initialized
DEBUG - 2021-10-20 02:53:59 --> UTF-8 Support Enabled
INFO - 2021-10-20 02:53:59 --> Utf8 Class Initialized
INFO - 2021-10-20 02:53:59 --> URI Class Initialized
DEBUG - 2021-10-20 02:53:59 --> No URI present. Default controller set.
INFO - 2021-10-20 02:53:59 --> Router Class Initialized
INFO - 2021-10-20 02:53:59 --> Output Class Initialized
INFO - 2021-10-20 02:53:59 --> Security Class Initialized
DEBUG - 2021-10-20 02:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-20 02:53:59 --> Input Class Initialized
INFO - 2021-10-20 02:53:59 --> Language Class Initialized
INFO - 2021-10-20 02:53:59 --> Loader Class Initialized
INFO - 2021-10-20 02:53:59 --> Helper loaded: url_helper
INFO - 2021-10-20 02:53:59 --> Helper loaded: form_helper
INFO - 2021-10-20 02:53:59 --> Helper loaded: common_helper
INFO - 2021-10-20 02:53:59 --> Database Driver Class Initialized
DEBUG - 2021-10-20 02:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-20 02:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-20 02:53:59 --> Controller Class Initialized
INFO - 2021-10-20 02:53:59 --> Form Validation Class Initialized
DEBUG - 2021-10-20 02:53:59 --> Encrypt Class Initialized
DEBUG - 2021-10-20 02:53:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-20 02:53:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-20 02:53:59 --> Email Class Initialized
INFO - 2021-10-20 02:53:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-20 02:53:59 --> Calendar Class Initialized
INFO - 2021-10-20 02:53:59 --> Model "Login_model" initialized
INFO - 2021-10-20 02:53:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-20 02:53:59 --> Final output sent to browser
DEBUG - 2021-10-20 02:53:59 --> Total execution time: 0.0554
ERROR - 2021-10-20 08:27:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-20 08:27:48 --> Config Class Initialized
INFO - 2021-10-20 08:27:48 --> Hooks Class Initialized
DEBUG - 2021-10-20 08:27:48 --> UTF-8 Support Enabled
INFO - 2021-10-20 08:27:48 --> Utf8 Class Initialized
INFO - 2021-10-20 08:27:48 --> URI Class Initialized
INFO - 2021-10-20 08:27:48 --> Router Class Initialized
INFO - 2021-10-20 08:27:48 --> Output Class Initialized
INFO - 2021-10-20 08:27:48 --> Security Class Initialized
DEBUG - 2021-10-20 08:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-20 08:27:48 --> Input Class Initialized
INFO - 2021-10-20 08:27:48 --> Language Class Initialized
ERROR - 2021-10-20 08:27:48 --> 404 Page Not Found: Old-indexphp/index
