<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-16 02:34:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 02:34:50 --> Config Class Initialized
INFO - 2022-02-16 02:34:50 --> Hooks Class Initialized
DEBUG - 2022-02-16 02:34:50 --> UTF-8 Support Enabled
INFO - 2022-02-16 02:34:50 --> Utf8 Class Initialized
INFO - 2022-02-16 02:34:50 --> URI Class Initialized
DEBUG - 2022-02-16 02:34:50 --> No URI present. Default controller set.
INFO - 2022-02-16 02:34:50 --> Router Class Initialized
INFO - 2022-02-16 02:34:50 --> Output Class Initialized
INFO - 2022-02-16 02:34:50 --> Security Class Initialized
DEBUG - 2022-02-16 02:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 02:34:50 --> Input Class Initialized
INFO - 2022-02-16 02:34:50 --> Language Class Initialized
INFO - 2022-02-16 02:34:50 --> Loader Class Initialized
INFO - 2022-02-16 02:34:50 --> Helper loaded: url_helper
INFO - 2022-02-16 02:34:50 --> Helper loaded: form_helper
INFO - 2022-02-16 02:34:50 --> Helper loaded: common_helper
INFO - 2022-02-16 02:34:50 --> Database Driver Class Initialized
DEBUG - 2022-02-16 02:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 02:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 02:34:50 --> Controller Class Initialized
INFO - 2022-02-16 02:34:50 --> Form Validation Class Initialized
DEBUG - 2022-02-16 02:34:50 --> Encrypt Class Initialized
DEBUG - 2022-02-16 02:34:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 02:34:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 02:34:50 --> Email Class Initialized
INFO - 2022-02-16 02:34:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 02:34:50 --> Calendar Class Initialized
INFO - 2022-02-16 02:34:50 --> Model "Login_model" initialized
INFO - 2022-02-16 02:34:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 02:34:50 --> Final output sent to browser
DEBUG - 2022-02-16 02:34:50 --> Total execution time: 0.0574
ERROR - 2022-02-16 03:28:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 03:28:41 --> Config Class Initialized
INFO - 2022-02-16 03:28:41 --> Hooks Class Initialized
DEBUG - 2022-02-16 03:28:41 --> UTF-8 Support Enabled
INFO - 2022-02-16 03:28:41 --> Utf8 Class Initialized
INFO - 2022-02-16 03:28:41 --> URI Class Initialized
DEBUG - 2022-02-16 03:28:41 --> No URI present. Default controller set.
INFO - 2022-02-16 03:28:41 --> Router Class Initialized
INFO - 2022-02-16 03:28:41 --> Output Class Initialized
INFO - 2022-02-16 03:28:41 --> Security Class Initialized
DEBUG - 2022-02-16 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 03:28:41 --> Input Class Initialized
INFO - 2022-02-16 03:28:41 --> Language Class Initialized
INFO - 2022-02-16 03:28:41 --> Loader Class Initialized
INFO - 2022-02-16 03:28:41 --> Helper loaded: url_helper
INFO - 2022-02-16 03:28:41 --> Helper loaded: form_helper
INFO - 2022-02-16 03:28:41 --> Helper loaded: common_helper
INFO - 2022-02-16 03:28:41 --> Database Driver Class Initialized
DEBUG - 2022-02-16 03:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 03:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 03:28:41 --> Controller Class Initialized
INFO - 2022-02-16 03:28:41 --> Form Validation Class Initialized
DEBUG - 2022-02-16 03:28:41 --> Encrypt Class Initialized
DEBUG - 2022-02-16 03:28:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 03:28:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 03:28:41 --> Email Class Initialized
INFO - 2022-02-16 03:28:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 03:28:41 --> Calendar Class Initialized
INFO - 2022-02-16 03:28:41 --> Model "Login_model" initialized
INFO - 2022-02-16 03:28:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 03:28:41 --> Final output sent to browser
DEBUG - 2022-02-16 03:28:41 --> Total execution time: 0.0255
ERROR - 2022-02-16 06:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 06:45:12 --> Config Class Initialized
INFO - 2022-02-16 06:45:12 --> Hooks Class Initialized
DEBUG - 2022-02-16 06:45:12 --> UTF-8 Support Enabled
INFO - 2022-02-16 06:45:12 --> Utf8 Class Initialized
INFO - 2022-02-16 06:45:12 --> URI Class Initialized
DEBUG - 2022-02-16 06:45:12 --> No URI present. Default controller set.
INFO - 2022-02-16 06:45:12 --> Router Class Initialized
INFO - 2022-02-16 06:45:12 --> Output Class Initialized
INFO - 2022-02-16 06:45:12 --> Security Class Initialized
DEBUG - 2022-02-16 06:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 06:45:12 --> Input Class Initialized
INFO - 2022-02-16 06:45:12 --> Language Class Initialized
INFO - 2022-02-16 06:45:12 --> Loader Class Initialized
INFO - 2022-02-16 06:45:12 --> Helper loaded: url_helper
INFO - 2022-02-16 06:45:12 --> Helper loaded: form_helper
INFO - 2022-02-16 06:45:12 --> Helper loaded: common_helper
INFO - 2022-02-16 06:45:12 --> Database Driver Class Initialized
DEBUG - 2022-02-16 06:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 06:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 06:45:12 --> Controller Class Initialized
INFO - 2022-02-16 06:45:12 --> Form Validation Class Initialized
DEBUG - 2022-02-16 06:45:12 --> Encrypt Class Initialized
DEBUG - 2022-02-16 06:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 06:45:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 06:45:12 --> Email Class Initialized
INFO - 2022-02-16 06:45:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 06:45:12 --> Calendar Class Initialized
INFO - 2022-02-16 06:45:12 --> Model "Login_model" initialized
INFO - 2022-02-16 06:45:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 06:45:12 --> Final output sent to browser
DEBUG - 2022-02-16 06:45:12 --> Total execution time: 0.0340
ERROR - 2022-02-16 07:16:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 07:16:41 --> Config Class Initialized
INFO - 2022-02-16 07:16:41 --> Hooks Class Initialized
DEBUG - 2022-02-16 07:16:41 --> UTF-8 Support Enabled
INFO - 2022-02-16 07:16:41 --> Utf8 Class Initialized
INFO - 2022-02-16 07:16:41 --> URI Class Initialized
DEBUG - 2022-02-16 07:16:41 --> No URI present. Default controller set.
INFO - 2022-02-16 07:16:41 --> Router Class Initialized
INFO - 2022-02-16 07:16:41 --> Output Class Initialized
INFO - 2022-02-16 07:16:41 --> Security Class Initialized
DEBUG - 2022-02-16 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 07:16:41 --> Input Class Initialized
INFO - 2022-02-16 07:16:41 --> Language Class Initialized
INFO - 2022-02-16 07:16:41 --> Loader Class Initialized
INFO - 2022-02-16 07:16:41 --> Helper loaded: url_helper
INFO - 2022-02-16 07:16:41 --> Helper loaded: form_helper
INFO - 2022-02-16 07:16:41 --> Helper loaded: common_helper
INFO - 2022-02-16 07:16:41 --> Database Driver Class Initialized
DEBUG - 2022-02-16 07:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 07:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 07:16:41 --> Controller Class Initialized
INFO - 2022-02-16 07:16:41 --> Form Validation Class Initialized
DEBUG - 2022-02-16 07:16:41 --> Encrypt Class Initialized
DEBUG - 2022-02-16 07:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 07:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 07:16:41 --> Email Class Initialized
INFO - 2022-02-16 07:16:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 07:16:41 --> Calendar Class Initialized
INFO - 2022-02-16 07:16:41 --> Model "Login_model" initialized
INFO - 2022-02-16 07:16:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 07:16:41 --> Final output sent to browser
DEBUG - 2022-02-16 07:16:41 --> Total execution time: 0.0340
ERROR - 2022-02-16 10:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 10:16:24 --> Config Class Initialized
INFO - 2022-02-16 10:16:24 --> Hooks Class Initialized
DEBUG - 2022-02-16 10:16:24 --> UTF-8 Support Enabled
INFO - 2022-02-16 10:16:24 --> Utf8 Class Initialized
INFO - 2022-02-16 10:16:24 --> URI Class Initialized
DEBUG - 2022-02-16 10:16:24 --> No URI present. Default controller set.
INFO - 2022-02-16 10:16:24 --> Router Class Initialized
INFO - 2022-02-16 10:16:24 --> Output Class Initialized
INFO - 2022-02-16 10:16:24 --> Security Class Initialized
DEBUG - 2022-02-16 10:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 10:16:24 --> Input Class Initialized
INFO - 2022-02-16 10:16:24 --> Language Class Initialized
INFO - 2022-02-16 10:16:24 --> Loader Class Initialized
INFO - 2022-02-16 10:16:24 --> Helper loaded: url_helper
INFO - 2022-02-16 10:16:24 --> Helper loaded: form_helper
INFO - 2022-02-16 10:16:24 --> Helper loaded: common_helper
INFO - 2022-02-16 10:16:24 --> Database Driver Class Initialized
DEBUG - 2022-02-16 10:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 10:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 10:16:24 --> Controller Class Initialized
INFO - 2022-02-16 10:16:24 --> Form Validation Class Initialized
DEBUG - 2022-02-16 10:16:24 --> Encrypt Class Initialized
DEBUG - 2022-02-16 10:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:16:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 10:16:24 --> Email Class Initialized
INFO - 2022-02-16 10:16:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 10:16:24 --> Calendar Class Initialized
INFO - 2022-02-16 10:16:24 --> Model "Login_model" initialized
INFO - 2022-02-16 10:16:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 10:16:24 --> Final output sent to browser
DEBUG - 2022-02-16 10:16:24 --> Total execution time: 0.0306
ERROR - 2022-02-16 10:30:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 10:30:46 --> Config Class Initialized
INFO - 2022-02-16 10:30:46 --> Hooks Class Initialized
DEBUG - 2022-02-16 10:30:46 --> UTF-8 Support Enabled
INFO - 2022-02-16 10:30:46 --> Utf8 Class Initialized
INFO - 2022-02-16 10:30:46 --> URI Class Initialized
DEBUG - 2022-02-16 10:30:46 --> No URI present. Default controller set.
INFO - 2022-02-16 10:30:46 --> Router Class Initialized
INFO - 2022-02-16 10:30:46 --> Output Class Initialized
INFO - 2022-02-16 10:30:46 --> Security Class Initialized
DEBUG - 2022-02-16 10:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 10:30:46 --> Input Class Initialized
INFO - 2022-02-16 10:30:46 --> Language Class Initialized
INFO - 2022-02-16 10:30:46 --> Loader Class Initialized
INFO - 2022-02-16 10:30:46 --> Helper loaded: url_helper
INFO - 2022-02-16 10:30:46 --> Helper loaded: form_helper
INFO - 2022-02-16 10:30:46 --> Helper loaded: common_helper
INFO - 2022-02-16 10:30:46 --> Database Driver Class Initialized
DEBUG - 2022-02-16 10:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 10:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 10:30:46 --> Controller Class Initialized
INFO - 2022-02-16 10:30:46 --> Form Validation Class Initialized
DEBUG - 2022-02-16 10:30:46 --> Encrypt Class Initialized
DEBUG - 2022-02-16 10:30:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:30:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 10:30:46 --> Email Class Initialized
INFO - 2022-02-16 10:30:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 10:30:46 --> Calendar Class Initialized
INFO - 2022-02-16 10:30:46 --> Model "Login_model" initialized
INFO - 2022-02-16 10:30:46 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 10:30:46 --> Final output sent to browser
DEBUG - 2022-02-16 10:30:46 --> Total execution time: 0.0231
ERROR - 2022-02-16 11:22:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 11:22:25 --> Config Class Initialized
INFO - 2022-02-16 11:22:25 --> Hooks Class Initialized
DEBUG - 2022-02-16 11:22:25 --> UTF-8 Support Enabled
INFO - 2022-02-16 11:22:25 --> Utf8 Class Initialized
INFO - 2022-02-16 11:22:25 --> URI Class Initialized
DEBUG - 2022-02-16 11:22:25 --> No URI present. Default controller set.
INFO - 2022-02-16 11:22:25 --> Router Class Initialized
INFO - 2022-02-16 11:22:25 --> Output Class Initialized
INFO - 2022-02-16 11:22:25 --> Security Class Initialized
DEBUG - 2022-02-16 11:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 11:22:25 --> Input Class Initialized
INFO - 2022-02-16 11:22:25 --> Language Class Initialized
INFO - 2022-02-16 11:22:25 --> Loader Class Initialized
INFO - 2022-02-16 11:22:25 --> Helper loaded: url_helper
INFO - 2022-02-16 11:22:25 --> Helper loaded: form_helper
INFO - 2022-02-16 11:22:25 --> Helper loaded: common_helper
INFO - 2022-02-16 11:22:25 --> Database Driver Class Initialized
DEBUG - 2022-02-16 11:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 11:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 11:22:25 --> Controller Class Initialized
INFO - 2022-02-16 11:22:25 --> Form Validation Class Initialized
DEBUG - 2022-02-16 11:22:25 --> Encrypt Class Initialized
DEBUG - 2022-02-16 11:22:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:22:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 11:22:25 --> Email Class Initialized
INFO - 2022-02-16 11:22:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 11:22:25 --> Calendar Class Initialized
INFO - 2022-02-16 11:22:25 --> Model "Login_model" initialized
INFO - 2022-02-16 11:22:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 11:22:25 --> Final output sent to browser
DEBUG - 2022-02-16 11:22:25 --> Total execution time: 0.0297
ERROR - 2022-02-16 14:22:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 14:22:40 --> Config Class Initialized
INFO - 2022-02-16 14:22:40 --> Hooks Class Initialized
DEBUG - 2022-02-16 14:22:40 --> UTF-8 Support Enabled
INFO - 2022-02-16 14:22:40 --> Utf8 Class Initialized
INFO - 2022-02-16 14:22:40 --> URI Class Initialized
DEBUG - 2022-02-16 14:22:40 --> No URI present. Default controller set.
INFO - 2022-02-16 14:22:40 --> Router Class Initialized
INFO - 2022-02-16 14:22:40 --> Output Class Initialized
INFO - 2022-02-16 14:22:40 --> Security Class Initialized
DEBUG - 2022-02-16 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 14:22:40 --> Input Class Initialized
INFO - 2022-02-16 14:22:40 --> Language Class Initialized
INFO - 2022-02-16 14:22:40 --> Loader Class Initialized
INFO - 2022-02-16 14:22:40 --> Helper loaded: url_helper
INFO - 2022-02-16 14:22:40 --> Helper loaded: form_helper
INFO - 2022-02-16 14:22:40 --> Helper loaded: common_helper
INFO - 2022-02-16 14:22:40 --> Database Driver Class Initialized
DEBUG - 2022-02-16 14:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 14:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 14:22:40 --> Controller Class Initialized
INFO - 2022-02-16 14:22:40 --> Form Validation Class Initialized
DEBUG - 2022-02-16 14:22:40 --> Encrypt Class Initialized
DEBUG - 2022-02-16 14:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:22:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 14:22:40 --> Email Class Initialized
INFO - 2022-02-16 14:22:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 14:22:40 --> Calendar Class Initialized
INFO - 2022-02-16 14:22:40 --> Model "Login_model" initialized
INFO - 2022-02-16 14:22:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 14:22:40 --> Final output sent to browser
DEBUG - 2022-02-16 14:22:40 --> Total execution time: 0.0296
ERROR - 2022-02-16 14:22:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 14:22:41 --> Config Class Initialized
INFO - 2022-02-16 14:22:41 --> Hooks Class Initialized
DEBUG - 2022-02-16 14:22:41 --> UTF-8 Support Enabled
INFO - 2022-02-16 14:22:41 --> Utf8 Class Initialized
INFO - 2022-02-16 14:22:41 --> URI Class Initialized
INFO - 2022-02-16 14:22:41 --> Router Class Initialized
INFO - 2022-02-16 14:22:41 --> Output Class Initialized
INFO - 2022-02-16 14:22:41 --> Security Class Initialized
DEBUG - 2022-02-16 14:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 14:22:41 --> Input Class Initialized
INFO - 2022-02-16 14:22:41 --> Language Class Initialized
ERROR - 2022-02-16 14:22:41 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-16 14:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 14:22:56 --> Config Class Initialized
INFO - 2022-02-16 14:22:56 --> Hooks Class Initialized
DEBUG - 2022-02-16 14:22:56 --> UTF-8 Support Enabled
INFO - 2022-02-16 14:22:56 --> Utf8 Class Initialized
INFO - 2022-02-16 14:22:56 --> URI Class Initialized
INFO - 2022-02-16 14:22:56 --> Router Class Initialized
INFO - 2022-02-16 14:22:56 --> Output Class Initialized
INFO - 2022-02-16 14:22:56 --> Security Class Initialized
DEBUG - 2022-02-16 14:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 14:22:56 --> Input Class Initialized
INFO - 2022-02-16 14:22:56 --> Language Class Initialized
INFO - 2022-02-16 14:22:56 --> Loader Class Initialized
INFO - 2022-02-16 14:22:56 --> Helper loaded: url_helper
INFO - 2022-02-16 14:22:56 --> Helper loaded: form_helper
INFO - 2022-02-16 14:22:56 --> Helper loaded: common_helper
INFO - 2022-02-16 14:22:56 --> Database Driver Class Initialized
DEBUG - 2022-02-16 14:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 14:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 14:22:56 --> Controller Class Initialized
INFO - 2022-02-16 14:22:56 --> Form Validation Class Initialized
DEBUG - 2022-02-16 14:22:56 --> Encrypt Class Initialized
DEBUG - 2022-02-16 14:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:22:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 14:22:56 --> Email Class Initialized
INFO - 2022-02-16 14:22:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 14:22:56 --> Calendar Class Initialized
INFO - 2022-02-16 14:22:56 --> Model "Login_model" initialized
ERROR - 2022-02-16 14:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 14:22:56 --> Config Class Initialized
INFO - 2022-02-16 14:22:56 --> Hooks Class Initialized
DEBUG - 2022-02-16 14:22:56 --> UTF-8 Support Enabled
INFO - 2022-02-16 14:22:56 --> Utf8 Class Initialized
INFO - 2022-02-16 14:22:56 --> URI Class Initialized
INFO - 2022-02-16 14:22:56 --> Router Class Initialized
INFO - 2022-02-16 14:22:56 --> Output Class Initialized
INFO - 2022-02-16 14:22:56 --> Security Class Initialized
DEBUG - 2022-02-16 14:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 14:22:56 --> Input Class Initialized
INFO - 2022-02-16 14:22:56 --> Language Class Initialized
INFO - 2022-02-16 14:22:56 --> Loader Class Initialized
INFO - 2022-02-16 14:22:56 --> Helper loaded: url_helper
INFO - 2022-02-16 14:22:56 --> Helper loaded: form_helper
INFO - 2022-02-16 14:22:56 --> Helper loaded: common_helper
INFO - 2022-02-16 14:22:56 --> Database Driver Class Initialized
DEBUG - 2022-02-16 14:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 14:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 14:22:56 --> Controller Class Initialized
INFO - 2022-02-16 14:22:56 --> Form Validation Class Initialized
DEBUG - 2022-02-16 14:22:56 --> Encrypt Class Initialized
DEBUG - 2022-02-16 14:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:22:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 14:22:56 --> Email Class Initialized
INFO - 2022-02-16 14:22:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 14:22:56 --> Calendar Class Initialized
INFO - 2022-02-16 14:22:56 --> Model "Login_model" initialized
ERROR - 2022-02-16 14:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 14:22:58 --> Config Class Initialized
INFO - 2022-02-16 14:22:58 --> Hooks Class Initialized
DEBUG - 2022-02-16 14:22:58 --> UTF-8 Support Enabled
INFO - 2022-02-16 14:22:58 --> Utf8 Class Initialized
INFO - 2022-02-16 14:22:58 --> URI Class Initialized
INFO - 2022-02-16 14:22:58 --> Router Class Initialized
INFO - 2022-02-16 14:22:58 --> Output Class Initialized
INFO - 2022-02-16 14:22:58 --> Security Class Initialized
DEBUG - 2022-02-16 14:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 14:22:58 --> Input Class Initialized
INFO - 2022-02-16 14:22:58 --> Language Class Initialized
INFO - 2022-02-16 14:22:58 --> Loader Class Initialized
INFO - 2022-02-16 14:22:58 --> Helper loaded: url_helper
INFO - 2022-02-16 14:22:58 --> Helper loaded: form_helper
INFO - 2022-02-16 14:22:58 --> Helper loaded: common_helper
INFO - 2022-02-16 14:22:58 --> Database Driver Class Initialized
DEBUG - 2022-02-16 14:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 14:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 14:22:58 --> Controller Class Initialized
INFO - 2022-02-16 14:22:58 --> Form Validation Class Initialized
DEBUG - 2022-02-16 14:22:58 --> Encrypt Class Initialized
DEBUG - 2022-02-16 14:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 14:22:58 --> Email Class Initialized
INFO - 2022-02-16 14:22:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 14:22:58 --> Calendar Class Initialized
INFO - 2022-02-16 14:22:58 --> Model "Login_model" initialized
INFO - 2022-02-16 14:22:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 14:22:58 --> Final output sent to browser
DEBUG - 2022-02-16 14:22:58 --> Total execution time: 0.0316
ERROR - 2022-02-16 14:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 14:22:58 --> Config Class Initialized
INFO - 2022-02-16 14:22:58 --> Hooks Class Initialized
DEBUG - 2022-02-16 14:22:58 --> UTF-8 Support Enabled
INFO - 2022-02-16 14:22:58 --> Utf8 Class Initialized
INFO - 2022-02-16 14:22:58 --> URI Class Initialized
DEBUG - 2022-02-16 14:22:58 --> No URI present. Default controller set.
INFO - 2022-02-16 14:22:58 --> Router Class Initialized
INFO - 2022-02-16 14:22:58 --> Output Class Initialized
INFO - 2022-02-16 14:22:58 --> Security Class Initialized
DEBUG - 2022-02-16 14:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 14:22:58 --> Input Class Initialized
INFO - 2022-02-16 14:22:58 --> Language Class Initialized
INFO - 2022-02-16 14:22:58 --> Loader Class Initialized
INFO - 2022-02-16 14:22:58 --> Helper loaded: url_helper
INFO - 2022-02-16 14:22:58 --> Helper loaded: form_helper
INFO - 2022-02-16 14:22:58 --> Helper loaded: common_helper
INFO - 2022-02-16 14:22:58 --> Database Driver Class Initialized
DEBUG - 2022-02-16 14:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 14:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 14:22:58 --> Controller Class Initialized
INFO - 2022-02-16 14:22:58 --> Form Validation Class Initialized
DEBUG - 2022-02-16 14:22:58 --> Encrypt Class Initialized
DEBUG - 2022-02-16 14:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 14:22:58 --> Email Class Initialized
INFO - 2022-02-16 14:22:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 14:22:58 --> Calendar Class Initialized
INFO - 2022-02-16 14:22:58 --> Model "Login_model" initialized
INFO - 2022-02-16 14:22:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 14:22:58 --> Final output sent to browser
DEBUG - 2022-02-16 14:22:58 --> Total execution time: 0.0375
ERROR - 2022-02-16 15:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 15:44:17 --> Config Class Initialized
INFO - 2022-02-16 15:44:17 --> Hooks Class Initialized
DEBUG - 2022-02-16 15:44:17 --> UTF-8 Support Enabled
INFO - 2022-02-16 15:44:17 --> Utf8 Class Initialized
INFO - 2022-02-16 15:44:17 --> URI Class Initialized
DEBUG - 2022-02-16 15:44:17 --> No URI present. Default controller set.
INFO - 2022-02-16 15:44:17 --> Router Class Initialized
INFO - 2022-02-16 15:44:17 --> Output Class Initialized
INFO - 2022-02-16 15:44:17 --> Security Class Initialized
DEBUG - 2022-02-16 15:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 15:44:17 --> Input Class Initialized
INFO - 2022-02-16 15:44:17 --> Language Class Initialized
INFO - 2022-02-16 15:44:17 --> Loader Class Initialized
INFO - 2022-02-16 15:44:17 --> Helper loaded: url_helper
INFO - 2022-02-16 15:44:17 --> Helper loaded: form_helper
INFO - 2022-02-16 15:44:17 --> Helper loaded: common_helper
INFO - 2022-02-16 15:44:17 --> Database Driver Class Initialized
DEBUG - 2022-02-16 15:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 15:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 15:44:17 --> Controller Class Initialized
INFO - 2022-02-16 15:44:17 --> Form Validation Class Initialized
DEBUG - 2022-02-16 15:44:17 --> Encrypt Class Initialized
DEBUG - 2022-02-16 15:44:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:44:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 15:44:17 --> Email Class Initialized
INFO - 2022-02-16 15:44:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 15:44:17 --> Calendar Class Initialized
INFO - 2022-02-16 15:44:17 --> Model "Login_model" initialized
INFO - 2022-02-16 15:44:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 15:44:17 --> Final output sent to browser
DEBUG - 2022-02-16 15:44:17 --> Total execution time: 0.0392
ERROR - 2022-02-16 20:20:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 20:20:55 --> Config Class Initialized
INFO - 2022-02-16 20:20:55 --> Hooks Class Initialized
DEBUG - 2022-02-16 20:20:55 --> UTF-8 Support Enabled
INFO - 2022-02-16 20:20:55 --> Utf8 Class Initialized
INFO - 2022-02-16 20:20:55 --> URI Class Initialized
DEBUG - 2022-02-16 20:20:55 --> No URI present. Default controller set.
INFO - 2022-02-16 20:20:55 --> Router Class Initialized
INFO - 2022-02-16 20:20:55 --> Output Class Initialized
INFO - 2022-02-16 20:20:55 --> Security Class Initialized
DEBUG - 2022-02-16 20:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 20:20:55 --> Input Class Initialized
INFO - 2022-02-16 20:20:55 --> Language Class Initialized
INFO - 2022-02-16 20:20:55 --> Loader Class Initialized
INFO - 2022-02-16 20:20:55 --> Helper loaded: url_helper
INFO - 2022-02-16 20:20:55 --> Helper loaded: form_helper
INFO - 2022-02-16 20:20:55 --> Helper loaded: common_helper
INFO - 2022-02-16 20:20:55 --> Database Driver Class Initialized
DEBUG - 2022-02-16 20:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 20:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 20:20:55 --> Controller Class Initialized
INFO - 2022-02-16 20:20:55 --> Form Validation Class Initialized
DEBUG - 2022-02-16 20:20:55 --> Encrypt Class Initialized
DEBUG - 2022-02-16 20:20:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 20:20:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 20:20:55 --> Email Class Initialized
INFO - 2022-02-16 20:20:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 20:20:55 --> Calendar Class Initialized
INFO - 2022-02-16 20:20:55 --> Model "Login_model" initialized
INFO - 2022-02-16 20:20:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 20:20:55 --> Final output sent to browser
DEBUG - 2022-02-16 20:20:55 --> Total execution time: 0.0218
ERROR - 2022-02-16 23:36:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-16 23:36:34 --> Config Class Initialized
INFO - 2022-02-16 23:36:34 --> Hooks Class Initialized
DEBUG - 2022-02-16 23:36:34 --> UTF-8 Support Enabled
INFO - 2022-02-16 23:36:34 --> Utf8 Class Initialized
INFO - 2022-02-16 23:36:34 --> URI Class Initialized
DEBUG - 2022-02-16 23:36:34 --> No URI present. Default controller set.
INFO - 2022-02-16 23:36:34 --> Router Class Initialized
INFO - 2022-02-16 23:36:34 --> Output Class Initialized
INFO - 2022-02-16 23:36:34 --> Security Class Initialized
DEBUG - 2022-02-16 23:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-16 23:36:34 --> Input Class Initialized
INFO - 2022-02-16 23:36:34 --> Language Class Initialized
INFO - 2022-02-16 23:36:34 --> Loader Class Initialized
INFO - 2022-02-16 23:36:34 --> Helper loaded: url_helper
INFO - 2022-02-16 23:36:34 --> Helper loaded: form_helper
INFO - 2022-02-16 23:36:34 --> Helper loaded: common_helper
INFO - 2022-02-16 23:36:34 --> Database Driver Class Initialized
DEBUG - 2022-02-16 23:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-16 23:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-16 23:36:34 --> Controller Class Initialized
INFO - 2022-02-16 23:36:34 --> Form Validation Class Initialized
DEBUG - 2022-02-16 23:36:34 --> Encrypt Class Initialized
DEBUG - 2022-02-16 23:36:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 23:36:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-16 23:36:34 --> Email Class Initialized
INFO - 2022-02-16 23:36:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-16 23:36:34 --> Calendar Class Initialized
INFO - 2022-02-16 23:36:34 --> Model "Login_model" initialized
INFO - 2022-02-16 23:36:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-16 23:36:34 --> Final output sent to browser
DEBUG - 2022-02-16 23:36:34 --> Total execution time: 0.0231
