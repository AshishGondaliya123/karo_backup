<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-18 06:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 06:22:15 --> Config Class Initialized
INFO - 2021-12-18 06:22:15 --> Hooks Class Initialized
DEBUG - 2021-12-18 06:22:15 --> UTF-8 Support Enabled
INFO - 2021-12-18 06:22:15 --> Utf8 Class Initialized
INFO - 2021-12-18 06:22:15 --> URI Class Initialized
DEBUG - 2021-12-18 06:22:15 --> No URI present. Default controller set.
INFO - 2021-12-18 06:22:15 --> Router Class Initialized
INFO - 2021-12-18 06:22:15 --> Output Class Initialized
INFO - 2021-12-18 06:22:15 --> Security Class Initialized
DEBUG - 2021-12-18 06:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 06:22:15 --> Input Class Initialized
INFO - 2021-12-18 06:22:15 --> Language Class Initialized
INFO - 2021-12-18 06:22:15 --> Loader Class Initialized
INFO - 2021-12-18 06:22:15 --> Helper loaded: url_helper
INFO - 2021-12-18 06:22:15 --> Helper loaded: form_helper
INFO - 2021-12-18 06:22:15 --> Helper loaded: common_helper
INFO - 2021-12-18 06:22:15 --> Database Driver Class Initialized
DEBUG - 2021-12-18 06:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 06:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 06:22:15 --> Controller Class Initialized
INFO - 2021-12-18 06:22:15 --> Form Validation Class Initialized
DEBUG - 2021-12-18 06:22:15 --> Encrypt Class Initialized
DEBUG - 2021-12-18 06:22:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 06:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 06:22:15 --> Email Class Initialized
INFO - 2021-12-18 06:22:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 06:22:15 --> Calendar Class Initialized
INFO - 2021-12-18 06:22:15 --> Model "Login_model" initialized
INFO - 2021-12-18 06:22:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-18 06:22:15 --> Final output sent to browser
DEBUG - 2021-12-18 06:22:15 --> Total execution time: 0.0228
ERROR - 2021-12-18 06:27:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 06:27:51 --> Config Class Initialized
INFO - 2021-12-18 06:27:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 06:27:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 06:27:51 --> Utf8 Class Initialized
INFO - 2021-12-18 06:27:51 --> URI Class Initialized
DEBUG - 2021-12-18 06:27:51 --> No URI present. Default controller set.
INFO - 2021-12-18 06:27:51 --> Router Class Initialized
INFO - 2021-12-18 06:27:51 --> Output Class Initialized
INFO - 2021-12-18 06:27:51 --> Security Class Initialized
DEBUG - 2021-12-18 06:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 06:27:51 --> Input Class Initialized
INFO - 2021-12-18 06:27:51 --> Language Class Initialized
INFO - 2021-12-18 06:27:51 --> Loader Class Initialized
INFO - 2021-12-18 06:27:51 --> Helper loaded: url_helper
INFO - 2021-12-18 06:27:51 --> Helper loaded: form_helper
INFO - 2021-12-18 06:27:51 --> Helper loaded: common_helper
INFO - 2021-12-18 06:27:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 06:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 06:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 06:27:51 --> Controller Class Initialized
INFO - 2021-12-18 06:27:51 --> Form Validation Class Initialized
DEBUG - 2021-12-18 06:27:51 --> Encrypt Class Initialized
DEBUG - 2021-12-18 06:27:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 06:27:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 06:27:51 --> Email Class Initialized
INFO - 2021-12-18 06:27:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 06:27:51 --> Calendar Class Initialized
INFO - 2021-12-18 06:27:51 --> Model "Login_model" initialized
INFO - 2021-12-18 06:27:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-18 06:27:51 --> Final output sent to browser
DEBUG - 2021-12-18 06:27:51 --> Total execution time: 0.0232
ERROR - 2021-12-18 14:21:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 14:21:51 --> Config Class Initialized
INFO - 2021-12-18 14:21:51 --> Hooks Class Initialized
DEBUG - 2021-12-18 14:21:51 --> UTF-8 Support Enabled
INFO - 2021-12-18 14:21:51 --> Utf8 Class Initialized
INFO - 2021-12-18 14:21:51 --> URI Class Initialized
DEBUG - 2021-12-18 14:21:51 --> No URI present. Default controller set.
INFO - 2021-12-18 14:21:51 --> Router Class Initialized
INFO - 2021-12-18 14:21:51 --> Output Class Initialized
INFO - 2021-12-18 14:21:51 --> Security Class Initialized
DEBUG - 2021-12-18 14:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 14:21:51 --> Input Class Initialized
INFO - 2021-12-18 14:21:51 --> Language Class Initialized
INFO - 2021-12-18 14:21:51 --> Loader Class Initialized
INFO - 2021-12-18 14:21:51 --> Helper loaded: url_helper
INFO - 2021-12-18 14:21:51 --> Helper loaded: form_helper
INFO - 2021-12-18 14:21:51 --> Helper loaded: common_helper
INFO - 2021-12-18 14:21:51 --> Database Driver Class Initialized
DEBUG - 2021-12-18 14:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 14:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 14:21:51 --> Controller Class Initialized
INFO - 2021-12-18 14:21:51 --> Form Validation Class Initialized
DEBUG - 2021-12-18 14:21:51 --> Encrypt Class Initialized
DEBUG - 2021-12-18 14:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 14:21:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 14:21:51 --> Email Class Initialized
INFO - 2021-12-18 14:21:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 14:21:51 --> Calendar Class Initialized
INFO - 2021-12-18 14:21:51 --> Model "Login_model" initialized
INFO - 2021-12-18 14:21:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-18 14:21:51 --> Final output sent to browser
DEBUG - 2021-12-18 14:21:51 --> Total execution time: 0.0236
ERROR - 2021-12-18 14:21:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 14:21:52 --> Config Class Initialized
INFO - 2021-12-18 14:21:52 --> Hooks Class Initialized
DEBUG - 2021-12-18 14:21:52 --> UTF-8 Support Enabled
INFO - 2021-12-18 14:21:52 --> Utf8 Class Initialized
INFO - 2021-12-18 14:21:52 --> URI Class Initialized
INFO - 2021-12-18 14:21:52 --> Router Class Initialized
INFO - 2021-12-18 14:21:52 --> Output Class Initialized
INFO - 2021-12-18 14:21:52 --> Security Class Initialized
DEBUG - 2021-12-18 14:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 14:21:52 --> Input Class Initialized
INFO - 2021-12-18 14:21:52 --> Language Class Initialized
ERROR - 2021-12-18 14:21:52 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-18 14:22:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 14:22:03 --> Config Class Initialized
INFO - 2021-12-18 14:22:03 --> Hooks Class Initialized
DEBUG - 2021-12-18 14:22:03 --> UTF-8 Support Enabled
INFO - 2021-12-18 14:22:03 --> Utf8 Class Initialized
INFO - 2021-12-18 14:22:03 --> URI Class Initialized
INFO - 2021-12-18 14:22:03 --> Router Class Initialized
INFO - 2021-12-18 14:22:03 --> Output Class Initialized
INFO - 2021-12-18 14:22:03 --> Security Class Initialized
DEBUG - 2021-12-18 14:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 14:22:03 --> Input Class Initialized
INFO - 2021-12-18 14:22:03 --> Language Class Initialized
INFO - 2021-12-18 14:22:03 --> Loader Class Initialized
INFO - 2021-12-18 14:22:03 --> Helper loaded: url_helper
INFO - 2021-12-18 14:22:03 --> Helper loaded: form_helper
INFO - 2021-12-18 14:22:03 --> Helper loaded: common_helper
INFO - 2021-12-18 14:22:03 --> Database Driver Class Initialized
DEBUG - 2021-12-18 14:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 14:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 14:22:03 --> Controller Class Initialized
INFO - 2021-12-18 14:22:03 --> Form Validation Class Initialized
DEBUG - 2021-12-18 14:22:03 --> Encrypt Class Initialized
DEBUG - 2021-12-18 14:22:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 14:22:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 14:22:03 --> Email Class Initialized
INFO - 2021-12-18 14:22:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 14:22:03 --> Calendar Class Initialized
INFO - 2021-12-18 14:22:03 --> Model "Login_model" initialized
ERROR - 2021-12-18 14:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 14:22:04 --> Config Class Initialized
INFO - 2021-12-18 14:22:04 --> Hooks Class Initialized
DEBUG - 2021-12-18 14:22:04 --> UTF-8 Support Enabled
INFO - 2021-12-18 14:22:04 --> Utf8 Class Initialized
INFO - 2021-12-18 14:22:04 --> URI Class Initialized
INFO - 2021-12-18 14:22:04 --> Router Class Initialized
INFO - 2021-12-18 14:22:04 --> Output Class Initialized
INFO - 2021-12-18 14:22:04 --> Security Class Initialized
DEBUG - 2021-12-18 14:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 14:22:04 --> Input Class Initialized
INFO - 2021-12-18 14:22:04 --> Language Class Initialized
INFO - 2021-12-18 14:22:04 --> Loader Class Initialized
INFO - 2021-12-18 14:22:04 --> Helper loaded: url_helper
INFO - 2021-12-18 14:22:04 --> Helper loaded: form_helper
INFO - 2021-12-18 14:22:04 --> Helper loaded: common_helper
INFO - 2021-12-18 14:22:04 --> Database Driver Class Initialized
DEBUG - 2021-12-18 14:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 14:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 14:22:04 --> Controller Class Initialized
INFO - 2021-12-18 14:22:04 --> Form Validation Class Initialized
DEBUG - 2021-12-18 14:22:04 --> Encrypt Class Initialized
DEBUG - 2021-12-18 14:22:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 14:22:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 14:22:04 --> Email Class Initialized
INFO - 2021-12-18 14:22:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 14:22:04 --> Calendar Class Initialized
INFO - 2021-12-18 14:22:04 --> Model "Login_model" initialized
ERROR - 2021-12-18 14:22:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 14:22:05 --> Config Class Initialized
INFO - 2021-12-18 14:22:05 --> Hooks Class Initialized
DEBUG - 2021-12-18 14:22:05 --> UTF-8 Support Enabled
INFO - 2021-12-18 14:22:05 --> Utf8 Class Initialized
INFO - 2021-12-18 14:22:05 --> URI Class Initialized
INFO - 2021-12-18 14:22:05 --> Router Class Initialized
INFO - 2021-12-18 14:22:05 --> Output Class Initialized
INFO - 2021-12-18 14:22:05 --> Security Class Initialized
DEBUG - 2021-12-18 14:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 14:22:05 --> Input Class Initialized
INFO - 2021-12-18 14:22:05 --> Language Class Initialized
INFO - 2021-12-18 14:22:05 --> Loader Class Initialized
INFO - 2021-12-18 14:22:05 --> Helper loaded: url_helper
INFO - 2021-12-18 14:22:05 --> Helper loaded: form_helper
INFO - 2021-12-18 14:22:05 --> Helper loaded: common_helper
INFO - 2021-12-18 14:22:05 --> Database Driver Class Initialized
DEBUG - 2021-12-18 14:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 14:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 14:22:05 --> Controller Class Initialized
INFO - 2021-12-18 14:22:05 --> Form Validation Class Initialized
DEBUG - 2021-12-18 14:22:05 --> Encrypt Class Initialized
DEBUG - 2021-12-18 14:22:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 14:22:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 14:22:05 --> Email Class Initialized
INFO - 2021-12-18 14:22:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 14:22:05 --> Calendar Class Initialized
INFO - 2021-12-18 14:22:05 --> Model "Login_model" initialized
INFO - 2021-12-18 14:22:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-18 14:22:05 --> Final output sent to browser
DEBUG - 2021-12-18 14:22:05 --> Total execution time: 0.0223
ERROR - 2021-12-18 14:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 14:22:06 --> Config Class Initialized
INFO - 2021-12-18 14:22:06 --> Hooks Class Initialized
DEBUG - 2021-12-18 14:22:06 --> UTF-8 Support Enabled
INFO - 2021-12-18 14:22:06 --> Utf8 Class Initialized
INFO - 2021-12-18 14:22:06 --> URI Class Initialized
DEBUG - 2021-12-18 14:22:06 --> No URI present. Default controller set.
INFO - 2021-12-18 14:22:06 --> Router Class Initialized
INFO - 2021-12-18 14:22:06 --> Output Class Initialized
INFO - 2021-12-18 14:22:06 --> Security Class Initialized
DEBUG - 2021-12-18 14:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 14:22:06 --> Input Class Initialized
INFO - 2021-12-18 14:22:06 --> Language Class Initialized
INFO - 2021-12-18 14:22:06 --> Loader Class Initialized
INFO - 2021-12-18 14:22:06 --> Helper loaded: url_helper
INFO - 2021-12-18 14:22:06 --> Helper loaded: form_helper
INFO - 2021-12-18 14:22:06 --> Helper loaded: common_helper
INFO - 2021-12-18 14:22:06 --> Database Driver Class Initialized
DEBUG - 2021-12-18 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 14:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 14:22:06 --> Controller Class Initialized
INFO - 2021-12-18 14:22:06 --> Form Validation Class Initialized
DEBUG - 2021-12-18 14:22:06 --> Encrypt Class Initialized
DEBUG - 2021-12-18 14:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 14:22:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 14:22:06 --> Email Class Initialized
INFO - 2021-12-18 14:22:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 14:22:06 --> Calendar Class Initialized
INFO - 2021-12-18 14:22:06 --> Model "Login_model" initialized
INFO - 2021-12-18 14:22:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-18 14:22:06 --> Final output sent to browser
DEBUG - 2021-12-18 14:22:06 --> Total execution time: 0.0227
ERROR - 2021-12-18 19:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 19:17:48 --> Config Class Initialized
INFO - 2021-12-18 19:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-18 19:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-18 19:17:48 --> Utf8 Class Initialized
INFO - 2021-12-18 19:17:48 --> URI Class Initialized
DEBUG - 2021-12-18 19:17:48 --> No URI present. Default controller set.
INFO - 2021-12-18 19:17:48 --> Router Class Initialized
INFO - 2021-12-18 19:17:48 --> Output Class Initialized
INFO - 2021-12-18 19:17:48 --> Security Class Initialized
DEBUG - 2021-12-18 19:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 19:17:48 --> Input Class Initialized
INFO - 2021-12-18 19:17:48 --> Language Class Initialized
INFO - 2021-12-18 19:17:48 --> Loader Class Initialized
INFO - 2021-12-18 19:17:48 --> Helper loaded: url_helper
INFO - 2021-12-18 19:17:48 --> Helper loaded: form_helper
INFO - 2021-12-18 19:17:48 --> Helper loaded: common_helper
INFO - 2021-12-18 19:17:48 --> Database Driver Class Initialized
DEBUG - 2021-12-18 19:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 19:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 19:17:48 --> Controller Class Initialized
INFO - 2021-12-18 19:17:48 --> Form Validation Class Initialized
DEBUG - 2021-12-18 19:17:48 --> Encrypt Class Initialized
DEBUG - 2021-12-18 19:17:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 19:17:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 19:17:48 --> Email Class Initialized
INFO - 2021-12-18 19:17:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 19:17:48 --> Calendar Class Initialized
INFO - 2021-12-18 19:17:48 --> Model "Login_model" initialized
INFO - 2021-12-18 19:17:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-18 19:17:48 --> Final output sent to browser
DEBUG - 2021-12-18 19:17:48 --> Total execution time: 0.0303
ERROR - 2021-12-18 20:44:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 20:44:25 --> Config Class Initialized
INFO - 2021-12-18 20:44:25 --> Hooks Class Initialized
DEBUG - 2021-12-18 20:44:25 --> UTF-8 Support Enabled
INFO - 2021-12-18 20:44:25 --> Utf8 Class Initialized
INFO - 2021-12-18 20:44:25 --> URI Class Initialized
DEBUG - 2021-12-18 20:44:25 --> No URI present. Default controller set.
INFO - 2021-12-18 20:44:25 --> Router Class Initialized
INFO - 2021-12-18 20:44:25 --> Output Class Initialized
INFO - 2021-12-18 20:44:25 --> Security Class Initialized
DEBUG - 2021-12-18 20:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 20:44:25 --> Input Class Initialized
INFO - 2021-12-18 20:44:25 --> Language Class Initialized
INFO - 2021-12-18 20:44:25 --> Loader Class Initialized
INFO - 2021-12-18 20:44:25 --> Helper loaded: url_helper
INFO - 2021-12-18 20:44:25 --> Helper loaded: form_helper
INFO - 2021-12-18 20:44:25 --> Helper loaded: common_helper
INFO - 2021-12-18 20:44:25 --> Database Driver Class Initialized
DEBUG - 2021-12-18 20:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 20:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 20:44:25 --> Controller Class Initialized
INFO - 2021-12-18 20:44:25 --> Form Validation Class Initialized
DEBUG - 2021-12-18 20:44:25 --> Encrypt Class Initialized
DEBUG - 2021-12-18 20:44:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 20:44:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 20:44:25 --> Email Class Initialized
INFO - 2021-12-18 20:44:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 20:44:25 --> Calendar Class Initialized
INFO - 2021-12-18 20:44:25 --> Model "Login_model" initialized
INFO - 2021-12-18 20:44:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-18 20:44:25 --> Final output sent to browser
DEBUG - 2021-12-18 20:44:25 --> Total execution time: 0.0320
ERROR - 2021-12-18 22:07:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 22:07:10 --> Config Class Initialized
INFO - 2021-12-18 22:07:10 --> Hooks Class Initialized
DEBUG - 2021-12-18 22:07:10 --> UTF-8 Support Enabled
INFO - 2021-12-18 22:07:10 --> Utf8 Class Initialized
INFO - 2021-12-18 22:07:10 --> URI Class Initialized
DEBUG - 2021-12-18 22:07:10 --> No URI present. Default controller set.
INFO - 2021-12-18 22:07:10 --> Router Class Initialized
INFO - 2021-12-18 22:07:10 --> Output Class Initialized
INFO - 2021-12-18 22:07:10 --> Security Class Initialized
DEBUG - 2021-12-18 22:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 22:07:10 --> Input Class Initialized
INFO - 2021-12-18 22:07:10 --> Language Class Initialized
INFO - 2021-12-18 22:07:10 --> Loader Class Initialized
INFO - 2021-12-18 22:07:10 --> Helper loaded: url_helper
INFO - 2021-12-18 22:07:10 --> Helper loaded: form_helper
INFO - 2021-12-18 22:07:10 --> Helper loaded: common_helper
INFO - 2021-12-18 22:07:10 --> Database Driver Class Initialized
DEBUG - 2021-12-18 22:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 22:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 22:07:10 --> Controller Class Initialized
INFO - 2021-12-18 22:07:10 --> Form Validation Class Initialized
DEBUG - 2021-12-18 22:07:10 --> Encrypt Class Initialized
DEBUG - 2021-12-18 22:07:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 22:07:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 22:07:10 --> Email Class Initialized
INFO - 2021-12-18 22:07:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 22:07:10 --> Calendar Class Initialized
INFO - 2021-12-18 22:07:10 --> Model "Login_model" initialized
INFO - 2021-12-18 22:07:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-18 22:07:10 --> Final output sent to browser
DEBUG - 2021-12-18 22:07:10 --> Total execution time: 0.0246
ERROR - 2021-12-18 22:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 22:26:06 --> Config Class Initialized
INFO - 2021-12-18 22:26:06 --> Hooks Class Initialized
DEBUG - 2021-12-18 22:26:06 --> UTF-8 Support Enabled
INFO - 2021-12-18 22:26:06 --> Utf8 Class Initialized
INFO - 2021-12-18 22:26:06 --> URI Class Initialized
DEBUG - 2021-12-18 22:26:06 --> No URI present. Default controller set.
INFO - 2021-12-18 22:26:06 --> Router Class Initialized
INFO - 2021-12-18 22:26:06 --> Output Class Initialized
INFO - 2021-12-18 22:26:06 --> Security Class Initialized
DEBUG - 2021-12-18 22:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 22:26:06 --> Input Class Initialized
INFO - 2021-12-18 22:26:06 --> Language Class Initialized
INFO - 2021-12-18 22:26:06 --> Loader Class Initialized
INFO - 2021-12-18 22:26:06 --> Helper loaded: url_helper
INFO - 2021-12-18 22:26:06 --> Helper loaded: form_helper
INFO - 2021-12-18 22:26:06 --> Helper loaded: common_helper
INFO - 2021-12-18 22:26:06 --> Database Driver Class Initialized
DEBUG - 2021-12-18 22:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-18 22:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-18 22:26:06 --> Controller Class Initialized
INFO - 2021-12-18 22:26:06 --> Form Validation Class Initialized
DEBUG - 2021-12-18 22:26:06 --> Encrypt Class Initialized
DEBUG - 2021-12-18 22:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-18 22:26:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-18 22:26:06 --> Email Class Initialized
INFO - 2021-12-18 22:26:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-18 22:26:06 --> Calendar Class Initialized
INFO - 2021-12-18 22:26:06 --> Model "Login_model" initialized
INFO - 2021-12-18 22:26:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-18 22:26:06 --> Final output sent to browser
DEBUG - 2021-12-18 22:26:06 --> Total execution time: 0.0384
ERROR - 2021-12-18 22:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-18 22:26:06 --> Config Class Initialized
INFO - 2021-12-18 22:26:06 --> Hooks Class Initialized
DEBUG - 2021-12-18 22:26:06 --> UTF-8 Support Enabled
INFO - 2021-12-18 22:26:06 --> Utf8 Class Initialized
INFO - 2021-12-18 22:26:06 --> URI Class Initialized
INFO - 2021-12-18 22:26:06 --> Router Class Initialized
INFO - 2021-12-18 22:26:06 --> Output Class Initialized
INFO - 2021-12-18 22:26:06 --> Security Class Initialized
DEBUG - 2021-12-18 22:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-18 22:26:06 --> Input Class Initialized
INFO - 2021-12-18 22:26:06 --> Language Class Initialized
ERROR - 2021-12-18 22:26:06 --> 404 Page Not Found: Adstxt/index
