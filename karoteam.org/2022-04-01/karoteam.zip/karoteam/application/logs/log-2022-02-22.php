<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-22 00:17:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 00:17:49 --> Config Class Initialized
INFO - 2022-02-22 00:17:49 --> Hooks Class Initialized
DEBUG - 2022-02-22 00:17:49 --> UTF-8 Support Enabled
INFO - 2022-02-22 00:17:49 --> Utf8 Class Initialized
INFO - 2022-02-22 00:17:49 --> URI Class Initialized
DEBUG - 2022-02-22 00:17:49 --> No URI present. Default controller set.
INFO - 2022-02-22 00:17:49 --> Router Class Initialized
INFO - 2022-02-22 00:17:49 --> Output Class Initialized
INFO - 2022-02-22 00:17:49 --> Security Class Initialized
DEBUG - 2022-02-22 00:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 00:17:49 --> Input Class Initialized
INFO - 2022-02-22 00:17:49 --> Language Class Initialized
INFO - 2022-02-22 00:17:49 --> Loader Class Initialized
INFO - 2022-02-22 00:17:49 --> Helper loaded: url_helper
INFO - 2022-02-22 00:17:49 --> Helper loaded: form_helper
INFO - 2022-02-22 00:17:49 --> Helper loaded: common_helper
INFO - 2022-02-22 00:17:49 --> Database Driver Class Initialized
DEBUG - 2022-02-22 00:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 00:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 00:17:49 --> Controller Class Initialized
INFO - 2022-02-22 00:17:49 --> Form Validation Class Initialized
DEBUG - 2022-02-22 00:17:49 --> Encrypt Class Initialized
DEBUG - 2022-02-22 00:17:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 00:17:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 00:17:49 --> Email Class Initialized
INFO - 2022-02-22 00:17:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 00:17:49 --> Calendar Class Initialized
INFO - 2022-02-22 00:17:49 --> Model "Login_model" initialized
INFO - 2022-02-22 00:17:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 00:17:49 --> Final output sent to browser
DEBUG - 2022-02-22 00:17:49 --> Total execution time: 0.0298
ERROR - 2022-02-22 01:04:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 01:04:41 --> Config Class Initialized
INFO - 2022-02-22 01:04:41 --> Hooks Class Initialized
DEBUG - 2022-02-22 01:04:41 --> UTF-8 Support Enabled
INFO - 2022-02-22 01:04:41 --> Utf8 Class Initialized
INFO - 2022-02-22 01:04:41 --> URI Class Initialized
DEBUG - 2022-02-22 01:04:41 --> No URI present. Default controller set.
INFO - 2022-02-22 01:04:41 --> Router Class Initialized
INFO - 2022-02-22 01:04:41 --> Output Class Initialized
INFO - 2022-02-22 01:04:41 --> Security Class Initialized
DEBUG - 2022-02-22 01:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 01:04:41 --> Input Class Initialized
INFO - 2022-02-22 01:04:41 --> Language Class Initialized
INFO - 2022-02-22 01:04:41 --> Loader Class Initialized
INFO - 2022-02-22 01:04:41 --> Helper loaded: url_helper
INFO - 2022-02-22 01:04:41 --> Helper loaded: form_helper
INFO - 2022-02-22 01:04:41 --> Helper loaded: common_helper
INFO - 2022-02-22 01:04:41 --> Database Driver Class Initialized
DEBUG - 2022-02-22 01:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 01:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 01:04:41 --> Controller Class Initialized
INFO - 2022-02-22 01:04:41 --> Form Validation Class Initialized
DEBUG - 2022-02-22 01:04:41 --> Encrypt Class Initialized
DEBUG - 2022-02-22 01:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 01:04:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 01:04:41 --> Email Class Initialized
INFO - 2022-02-22 01:04:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 01:04:41 --> Calendar Class Initialized
INFO - 2022-02-22 01:04:41 --> Model "Login_model" initialized
INFO - 2022-02-22 01:04:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 01:04:41 --> Final output sent to browser
DEBUG - 2022-02-22 01:04:41 --> Total execution time: 0.0228
ERROR - 2022-02-22 03:37:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 03:37:36 --> Config Class Initialized
INFO - 2022-02-22 03:37:36 --> Hooks Class Initialized
DEBUG - 2022-02-22 03:37:36 --> UTF-8 Support Enabled
INFO - 2022-02-22 03:37:36 --> Utf8 Class Initialized
INFO - 2022-02-22 03:37:36 --> URI Class Initialized
DEBUG - 2022-02-22 03:37:36 --> No URI present. Default controller set.
INFO - 2022-02-22 03:37:36 --> Router Class Initialized
INFO - 2022-02-22 03:37:36 --> Output Class Initialized
INFO - 2022-02-22 03:37:36 --> Security Class Initialized
DEBUG - 2022-02-22 03:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 03:37:36 --> Input Class Initialized
INFO - 2022-02-22 03:37:36 --> Language Class Initialized
INFO - 2022-02-22 03:37:36 --> Loader Class Initialized
INFO - 2022-02-22 03:37:36 --> Helper loaded: url_helper
INFO - 2022-02-22 03:37:36 --> Helper loaded: form_helper
INFO - 2022-02-22 03:37:36 --> Helper loaded: common_helper
INFO - 2022-02-22 03:37:36 --> Database Driver Class Initialized
DEBUG - 2022-02-22 03:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 03:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 03:37:36 --> Controller Class Initialized
INFO - 2022-02-22 03:37:36 --> Form Validation Class Initialized
DEBUG - 2022-02-22 03:37:36 --> Encrypt Class Initialized
DEBUG - 2022-02-22 03:37:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 03:37:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 03:37:36 --> Email Class Initialized
INFO - 2022-02-22 03:37:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 03:37:36 --> Calendar Class Initialized
INFO - 2022-02-22 03:37:36 --> Model "Login_model" initialized
INFO - 2022-02-22 03:37:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 03:37:36 --> Final output sent to browser
DEBUG - 2022-02-22 03:37:36 --> Total execution time: 0.0221
ERROR - 2022-02-22 03:42:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 03:42:35 --> Config Class Initialized
INFO - 2022-02-22 03:42:35 --> Hooks Class Initialized
DEBUG - 2022-02-22 03:42:35 --> UTF-8 Support Enabled
INFO - 2022-02-22 03:42:35 --> Utf8 Class Initialized
INFO - 2022-02-22 03:42:35 --> URI Class Initialized
DEBUG - 2022-02-22 03:42:35 --> No URI present. Default controller set.
INFO - 2022-02-22 03:42:35 --> Router Class Initialized
INFO - 2022-02-22 03:42:35 --> Output Class Initialized
INFO - 2022-02-22 03:42:35 --> Security Class Initialized
DEBUG - 2022-02-22 03:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 03:42:35 --> Input Class Initialized
INFO - 2022-02-22 03:42:35 --> Language Class Initialized
INFO - 2022-02-22 03:42:35 --> Loader Class Initialized
INFO - 2022-02-22 03:42:35 --> Helper loaded: url_helper
INFO - 2022-02-22 03:42:35 --> Helper loaded: form_helper
INFO - 2022-02-22 03:42:35 --> Helper loaded: common_helper
INFO - 2022-02-22 03:42:35 --> Database Driver Class Initialized
DEBUG - 2022-02-22 03:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 03:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 03:42:35 --> Controller Class Initialized
INFO - 2022-02-22 03:42:35 --> Form Validation Class Initialized
DEBUG - 2022-02-22 03:42:35 --> Encrypt Class Initialized
DEBUG - 2022-02-22 03:42:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 03:42:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 03:42:35 --> Email Class Initialized
INFO - 2022-02-22 03:42:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 03:42:35 --> Calendar Class Initialized
INFO - 2022-02-22 03:42:35 --> Model "Login_model" initialized
INFO - 2022-02-22 03:42:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 03:42:35 --> Final output sent to browser
DEBUG - 2022-02-22 03:42:35 --> Total execution time: 0.0318
ERROR - 2022-02-22 08:03:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 08:03:13 --> Config Class Initialized
INFO - 2022-02-22 08:03:13 --> Hooks Class Initialized
DEBUG - 2022-02-22 08:03:13 --> UTF-8 Support Enabled
INFO - 2022-02-22 08:03:13 --> Utf8 Class Initialized
INFO - 2022-02-22 08:03:13 --> URI Class Initialized
DEBUG - 2022-02-22 08:03:13 --> No URI present. Default controller set.
INFO - 2022-02-22 08:03:13 --> Router Class Initialized
INFO - 2022-02-22 08:03:13 --> Output Class Initialized
INFO - 2022-02-22 08:03:13 --> Security Class Initialized
DEBUG - 2022-02-22 08:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 08:03:13 --> Input Class Initialized
INFO - 2022-02-22 08:03:13 --> Language Class Initialized
INFO - 2022-02-22 08:03:13 --> Loader Class Initialized
INFO - 2022-02-22 08:03:13 --> Helper loaded: url_helper
INFO - 2022-02-22 08:03:13 --> Helper loaded: form_helper
INFO - 2022-02-22 08:03:13 --> Helper loaded: common_helper
INFO - 2022-02-22 08:03:13 --> Database Driver Class Initialized
DEBUG - 2022-02-22 08:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 08:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 08:03:13 --> Controller Class Initialized
INFO - 2022-02-22 08:03:13 --> Form Validation Class Initialized
DEBUG - 2022-02-22 08:03:13 --> Encrypt Class Initialized
DEBUG - 2022-02-22 08:03:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 08:03:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 08:03:13 --> Email Class Initialized
INFO - 2022-02-22 08:03:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 08:03:13 --> Calendar Class Initialized
INFO - 2022-02-22 08:03:13 --> Model "Login_model" initialized
INFO - 2022-02-22 08:03:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 08:03:13 --> Final output sent to browser
DEBUG - 2022-02-22 08:03:13 --> Total execution time: 0.0464
ERROR - 2022-02-22 14:18:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 14:18:24 --> Config Class Initialized
INFO - 2022-02-22 14:18:24 --> Hooks Class Initialized
DEBUG - 2022-02-22 14:18:24 --> UTF-8 Support Enabled
INFO - 2022-02-22 14:18:24 --> Utf8 Class Initialized
INFO - 2022-02-22 14:18:24 --> URI Class Initialized
DEBUG - 2022-02-22 14:18:24 --> No URI present. Default controller set.
INFO - 2022-02-22 14:18:24 --> Router Class Initialized
INFO - 2022-02-22 14:18:24 --> Output Class Initialized
INFO - 2022-02-22 14:18:24 --> Security Class Initialized
DEBUG - 2022-02-22 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 14:18:24 --> Input Class Initialized
INFO - 2022-02-22 14:18:24 --> Language Class Initialized
INFO - 2022-02-22 14:18:24 --> Loader Class Initialized
INFO - 2022-02-22 14:18:24 --> Helper loaded: url_helper
INFO - 2022-02-22 14:18:24 --> Helper loaded: form_helper
INFO - 2022-02-22 14:18:24 --> Helper loaded: common_helper
INFO - 2022-02-22 14:18:24 --> Database Driver Class Initialized
DEBUG - 2022-02-22 14:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 14:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 14:18:24 --> Controller Class Initialized
INFO - 2022-02-22 14:18:24 --> Form Validation Class Initialized
DEBUG - 2022-02-22 14:18:24 --> Encrypt Class Initialized
DEBUG - 2022-02-22 14:18:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:18:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 14:18:24 --> Email Class Initialized
INFO - 2022-02-22 14:18:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 14:18:24 --> Calendar Class Initialized
INFO - 2022-02-22 14:18:24 --> Model "Login_model" initialized
INFO - 2022-02-22 14:18:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 14:18:24 --> Final output sent to browser
DEBUG - 2022-02-22 14:18:24 --> Total execution time: 0.0329
ERROR - 2022-02-22 14:18:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 14:18:26 --> Config Class Initialized
INFO - 2022-02-22 14:18:26 --> Hooks Class Initialized
DEBUG - 2022-02-22 14:18:26 --> UTF-8 Support Enabled
INFO - 2022-02-22 14:18:26 --> Utf8 Class Initialized
INFO - 2022-02-22 14:18:26 --> URI Class Initialized
INFO - 2022-02-22 14:18:26 --> Router Class Initialized
INFO - 2022-02-22 14:18:26 --> Output Class Initialized
INFO - 2022-02-22 14:18:27 --> Security Class Initialized
DEBUG - 2022-02-22 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 14:18:27 --> Input Class Initialized
INFO - 2022-02-22 14:18:27 --> Language Class Initialized
ERROR - 2022-02-22 14:18:27 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-22 14:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 14:18:41 --> Config Class Initialized
INFO - 2022-02-22 14:18:41 --> Hooks Class Initialized
DEBUG - 2022-02-22 14:18:41 --> UTF-8 Support Enabled
INFO - 2022-02-22 14:18:41 --> Utf8 Class Initialized
INFO - 2022-02-22 14:18:41 --> URI Class Initialized
DEBUG - 2022-02-22 14:18:41 --> No URI present. Default controller set.
INFO - 2022-02-22 14:18:41 --> Router Class Initialized
INFO - 2022-02-22 14:18:41 --> Output Class Initialized
INFO - 2022-02-22 14:18:41 --> Security Class Initialized
DEBUG - 2022-02-22 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 14:18:41 --> Input Class Initialized
INFO - 2022-02-22 14:18:41 --> Language Class Initialized
INFO - 2022-02-22 14:18:41 --> Loader Class Initialized
INFO - 2022-02-22 14:18:41 --> Helper loaded: url_helper
INFO - 2022-02-22 14:18:41 --> Helper loaded: form_helper
INFO - 2022-02-22 14:18:41 --> Helper loaded: common_helper
INFO - 2022-02-22 14:18:41 --> Database Driver Class Initialized
DEBUG - 2022-02-22 14:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 14:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 14:18:41 --> Controller Class Initialized
INFO - 2022-02-22 14:18:41 --> Form Validation Class Initialized
DEBUG - 2022-02-22 14:18:41 --> Encrypt Class Initialized
DEBUG - 2022-02-22 14:18:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 14:18:41 --> Email Class Initialized
INFO - 2022-02-22 14:18:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 14:18:41 --> Calendar Class Initialized
INFO - 2022-02-22 14:18:41 --> Model "Login_model" initialized
INFO - 2022-02-22 14:18:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 14:18:41 --> Final output sent to browser
DEBUG - 2022-02-22 14:18:41 --> Total execution time: 0.0406
ERROR - 2022-02-22 14:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 14:18:42 --> Config Class Initialized
INFO - 2022-02-22 14:18:42 --> Hooks Class Initialized
DEBUG - 2022-02-22 14:18:42 --> UTF-8 Support Enabled
INFO - 2022-02-22 14:18:42 --> Utf8 Class Initialized
INFO - 2022-02-22 14:18:42 --> URI Class Initialized
INFO - 2022-02-22 14:18:42 --> Router Class Initialized
INFO - 2022-02-22 14:18:42 --> Output Class Initialized
INFO - 2022-02-22 14:18:42 --> Security Class Initialized
DEBUG - 2022-02-22 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 14:18:42 --> Input Class Initialized
INFO - 2022-02-22 14:18:42 --> Language Class Initialized
INFO - 2022-02-22 14:18:42 --> Loader Class Initialized
INFO - 2022-02-22 14:18:42 --> Helper loaded: url_helper
INFO - 2022-02-22 14:18:42 --> Helper loaded: form_helper
INFO - 2022-02-22 14:18:42 --> Helper loaded: common_helper
INFO - 2022-02-22 14:18:42 --> Database Driver Class Initialized
DEBUG - 2022-02-22 14:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 14:18:42 --> Controller Class Initialized
INFO - 2022-02-22 14:18:42 --> Form Validation Class Initialized
DEBUG - 2022-02-22 14:18:42 --> Encrypt Class Initialized
DEBUG - 2022-02-22 14:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 14:18:42 --> Email Class Initialized
INFO - 2022-02-22 14:18:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 14:18:42 --> Calendar Class Initialized
INFO - 2022-02-22 14:18:42 --> Model "Login_model" initialized
INFO - 2022-02-22 14:18:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 14:18:42 --> Final output sent to browser
DEBUG - 2022-02-22 14:18:42 --> Total execution time: 0.0488
ERROR - 2022-02-22 14:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 14:18:43 --> Config Class Initialized
INFO - 2022-02-22 14:18:43 --> Hooks Class Initialized
DEBUG - 2022-02-22 14:18:43 --> UTF-8 Support Enabled
INFO - 2022-02-22 14:18:43 --> Utf8 Class Initialized
INFO - 2022-02-22 14:18:43 --> URI Class Initialized
INFO - 2022-02-22 14:18:43 --> Router Class Initialized
INFO - 2022-02-22 14:18:43 --> Output Class Initialized
INFO - 2022-02-22 14:18:43 --> Security Class Initialized
DEBUG - 2022-02-22 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 14:18:43 --> Input Class Initialized
INFO - 2022-02-22 14:18:43 --> Language Class Initialized
INFO - 2022-02-22 14:18:43 --> Loader Class Initialized
INFO - 2022-02-22 14:18:43 --> Helper loaded: url_helper
INFO - 2022-02-22 14:18:43 --> Helper loaded: form_helper
INFO - 2022-02-22 14:18:43 --> Helper loaded: common_helper
INFO - 2022-02-22 14:18:43 --> Database Driver Class Initialized
DEBUG - 2022-02-22 14:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 14:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 14:18:43 --> Controller Class Initialized
INFO - 2022-02-22 14:18:43 --> Form Validation Class Initialized
DEBUG - 2022-02-22 14:18:43 --> Encrypt Class Initialized
DEBUG - 2022-02-22 14:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 14:18:43 --> Email Class Initialized
INFO - 2022-02-22 14:18:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 14:18:43 --> Calendar Class Initialized
INFO - 2022-02-22 14:18:43 --> Model "Login_model" initialized
ERROR - 2022-02-22 14:18:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 14:18:44 --> Config Class Initialized
INFO - 2022-02-22 14:18:44 --> Hooks Class Initialized
DEBUG - 2022-02-22 14:18:44 --> UTF-8 Support Enabled
INFO - 2022-02-22 14:18:44 --> Utf8 Class Initialized
INFO - 2022-02-22 14:18:44 --> URI Class Initialized
INFO - 2022-02-22 14:18:44 --> Router Class Initialized
INFO - 2022-02-22 14:18:44 --> Output Class Initialized
INFO - 2022-02-22 14:18:44 --> Security Class Initialized
DEBUG - 2022-02-22 14:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 14:18:44 --> Input Class Initialized
INFO - 2022-02-22 14:18:44 --> Language Class Initialized
INFO - 2022-02-22 14:18:44 --> Loader Class Initialized
INFO - 2022-02-22 14:18:44 --> Helper loaded: url_helper
INFO - 2022-02-22 14:18:44 --> Helper loaded: form_helper
INFO - 2022-02-22 14:18:44 --> Helper loaded: common_helper
INFO - 2022-02-22 14:18:44 --> Database Driver Class Initialized
DEBUG - 2022-02-22 14:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 14:18:44 --> Controller Class Initialized
INFO - 2022-02-22 14:18:44 --> Form Validation Class Initialized
DEBUG - 2022-02-22 14:18:44 --> Encrypt Class Initialized
DEBUG - 2022-02-22 14:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 14:18:44 --> Email Class Initialized
INFO - 2022-02-22 14:18:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 14:18:44 --> Calendar Class Initialized
INFO - 2022-02-22 14:18:44 --> Model "Login_model" initialized
ERROR - 2022-02-22 15:43:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 15:43:16 --> Config Class Initialized
INFO - 2022-02-22 15:43:16 --> Hooks Class Initialized
DEBUG - 2022-02-22 15:43:16 --> UTF-8 Support Enabled
INFO - 2022-02-22 15:43:16 --> Utf8 Class Initialized
INFO - 2022-02-22 15:43:16 --> URI Class Initialized
INFO - 2022-02-22 15:43:16 --> Router Class Initialized
INFO - 2022-02-22 15:43:16 --> Output Class Initialized
INFO - 2022-02-22 15:43:16 --> Security Class Initialized
DEBUG - 2022-02-22 15:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 15:43:16 --> Input Class Initialized
INFO - 2022-02-22 15:43:16 --> Language Class Initialized
ERROR - 2022-02-22 15:43:16 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-02-22 15:43:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 15:43:22 --> Config Class Initialized
INFO - 2022-02-22 15:43:22 --> Hooks Class Initialized
DEBUG - 2022-02-22 15:43:22 --> UTF-8 Support Enabled
INFO - 2022-02-22 15:43:22 --> Utf8 Class Initialized
INFO - 2022-02-22 15:43:22 --> URI Class Initialized
INFO - 2022-02-22 15:43:22 --> Router Class Initialized
INFO - 2022-02-22 15:43:22 --> Output Class Initialized
INFO - 2022-02-22 15:43:22 --> Security Class Initialized
DEBUG - 2022-02-22 15:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 15:43:22 --> Input Class Initialized
INFO - 2022-02-22 15:43:22 --> Language Class Initialized
ERROR - 2022-02-22 15:43:22 --> 404 Page Not Found: Securitytxt/index
ERROR - 2022-02-22 15:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 15:43:25 --> Config Class Initialized
INFO - 2022-02-22 15:43:25 --> Hooks Class Initialized
DEBUG - 2022-02-22 15:43:25 --> UTF-8 Support Enabled
INFO - 2022-02-22 15:43:25 --> Utf8 Class Initialized
INFO - 2022-02-22 15:43:25 --> URI Class Initialized
INFO - 2022-02-22 15:43:25 --> Router Class Initialized
INFO - 2022-02-22 15:43:25 --> Output Class Initialized
INFO - 2022-02-22 15:43:25 --> Security Class Initialized
DEBUG - 2022-02-22 15:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 15:43:25 --> Input Class Initialized
INFO - 2022-02-22 15:43:25 --> Language Class Initialized
ERROR - 2022-02-22 15:43:25 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-02-22 15:43:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 15:43:28 --> Config Class Initialized
INFO - 2022-02-22 15:43:28 --> Hooks Class Initialized
DEBUG - 2022-02-22 15:43:28 --> UTF-8 Support Enabled
INFO - 2022-02-22 15:43:28 --> Utf8 Class Initialized
INFO - 2022-02-22 15:43:28 --> URI Class Initialized
INFO - 2022-02-22 15:43:28 --> Router Class Initialized
INFO - 2022-02-22 15:43:28 --> Output Class Initialized
INFO - 2022-02-22 15:43:28 --> Security Class Initialized
DEBUG - 2022-02-22 15:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 15:43:28 --> Input Class Initialized
INFO - 2022-02-22 15:43:28 --> Language Class Initialized
ERROR - 2022-02-22 15:43:28 --> 404 Page Not Found: Securitytxt/index
ERROR - 2022-02-22 15:51:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 15:51:58 --> Config Class Initialized
INFO - 2022-02-22 15:51:58 --> Hooks Class Initialized
DEBUG - 2022-02-22 15:51:58 --> UTF-8 Support Enabled
INFO - 2022-02-22 15:51:58 --> Utf8 Class Initialized
INFO - 2022-02-22 15:51:58 --> URI Class Initialized
DEBUG - 2022-02-22 15:51:58 --> No URI present. Default controller set.
INFO - 2022-02-22 15:51:58 --> Router Class Initialized
INFO - 2022-02-22 15:51:58 --> Output Class Initialized
INFO - 2022-02-22 15:51:58 --> Security Class Initialized
DEBUG - 2022-02-22 15:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 15:51:58 --> Input Class Initialized
INFO - 2022-02-22 15:51:58 --> Language Class Initialized
INFO - 2022-02-22 15:51:58 --> Loader Class Initialized
INFO - 2022-02-22 15:51:58 --> Helper loaded: url_helper
INFO - 2022-02-22 15:51:58 --> Helper loaded: form_helper
INFO - 2022-02-22 15:51:58 --> Helper loaded: common_helper
INFO - 2022-02-22 15:51:58 --> Database Driver Class Initialized
DEBUG - 2022-02-22 15:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 15:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 15:51:58 --> Controller Class Initialized
INFO - 2022-02-22 15:51:58 --> Form Validation Class Initialized
DEBUG - 2022-02-22 15:51:58 --> Encrypt Class Initialized
DEBUG - 2022-02-22 15:51:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:51:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 15:51:58 --> Email Class Initialized
INFO - 2022-02-22 15:51:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 15:51:58 --> Calendar Class Initialized
INFO - 2022-02-22 15:51:58 --> Model "Login_model" initialized
INFO - 2022-02-22 15:51:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 15:51:58 --> Final output sent to browser
DEBUG - 2022-02-22 15:51:58 --> Total execution time: 0.0344
ERROR - 2022-02-22 15:59:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 15:59:14 --> Config Class Initialized
INFO - 2022-02-22 15:59:14 --> Hooks Class Initialized
DEBUG - 2022-02-22 15:59:14 --> UTF-8 Support Enabled
INFO - 2022-02-22 15:59:14 --> Utf8 Class Initialized
INFO - 2022-02-22 15:59:14 --> URI Class Initialized
DEBUG - 2022-02-22 15:59:14 --> No URI present. Default controller set.
INFO - 2022-02-22 15:59:14 --> Router Class Initialized
INFO - 2022-02-22 15:59:14 --> Output Class Initialized
INFO - 2022-02-22 15:59:14 --> Security Class Initialized
DEBUG - 2022-02-22 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 15:59:14 --> Input Class Initialized
INFO - 2022-02-22 15:59:14 --> Language Class Initialized
INFO - 2022-02-22 15:59:14 --> Loader Class Initialized
INFO - 2022-02-22 15:59:14 --> Helper loaded: url_helper
INFO - 2022-02-22 15:59:14 --> Helper loaded: form_helper
INFO - 2022-02-22 15:59:14 --> Helper loaded: common_helper
INFO - 2022-02-22 15:59:14 --> Database Driver Class Initialized
DEBUG - 2022-02-22 15:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 15:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 15:59:14 --> Controller Class Initialized
INFO - 2022-02-22 15:59:14 --> Form Validation Class Initialized
DEBUG - 2022-02-22 15:59:14 --> Encrypt Class Initialized
DEBUG - 2022-02-22 15:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:59:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 15:59:14 --> Email Class Initialized
INFO - 2022-02-22 15:59:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 15:59:14 --> Calendar Class Initialized
INFO - 2022-02-22 15:59:14 --> Model "Login_model" initialized
INFO - 2022-02-22 15:59:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 15:59:14 --> Final output sent to browser
DEBUG - 2022-02-22 15:59:14 --> Total execution time: 0.0390
ERROR - 2022-02-22 16:29:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 16:29:20 --> Config Class Initialized
INFO - 2022-02-22 16:29:20 --> Hooks Class Initialized
DEBUG - 2022-02-22 16:29:20 --> UTF-8 Support Enabled
INFO - 2022-02-22 16:29:20 --> Utf8 Class Initialized
INFO - 2022-02-22 16:29:20 --> URI Class Initialized
DEBUG - 2022-02-22 16:29:20 --> No URI present. Default controller set.
INFO - 2022-02-22 16:29:20 --> Router Class Initialized
INFO - 2022-02-22 16:29:20 --> Output Class Initialized
INFO - 2022-02-22 16:29:20 --> Security Class Initialized
DEBUG - 2022-02-22 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 16:29:20 --> Input Class Initialized
INFO - 2022-02-22 16:29:20 --> Language Class Initialized
INFO - 2022-02-22 16:29:20 --> Loader Class Initialized
INFO - 2022-02-22 16:29:20 --> Helper loaded: url_helper
INFO - 2022-02-22 16:29:20 --> Helper loaded: form_helper
INFO - 2022-02-22 16:29:20 --> Helper loaded: common_helper
INFO - 2022-02-22 16:29:20 --> Database Driver Class Initialized
DEBUG - 2022-02-22 16:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 16:29:20 --> Controller Class Initialized
INFO - 2022-02-22 16:29:20 --> Form Validation Class Initialized
DEBUG - 2022-02-22 16:29:20 --> Encrypt Class Initialized
DEBUG - 2022-02-22 16:29:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:29:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 16:29:20 --> Email Class Initialized
INFO - 2022-02-22 16:29:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 16:29:20 --> Calendar Class Initialized
INFO - 2022-02-22 16:29:20 --> Model "Login_model" initialized
INFO - 2022-02-22 16:29:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 16:29:20 --> Final output sent to browser
DEBUG - 2022-02-22 16:29:20 --> Total execution time: 0.0337
ERROR - 2022-02-22 22:35:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-22 22:35:06 --> Config Class Initialized
INFO - 2022-02-22 22:35:06 --> Hooks Class Initialized
DEBUG - 2022-02-22 22:35:06 --> UTF-8 Support Enabled
INFO - 2022-02-22 22:35:06 --> Utf8 Class Initialized
INFO - 2022-02-22 22:35:06 --> URI Class Initialized
DEBUG - 2022-02-22 22:35:06 --> No URI present. Default controller set.
INFO - 2022-02-22 22:35:06 --> Router Class Initialized
INFO - 2022-02-22 22:35:06 --> Output Class Initialized
INFO - 2022-02-22 22:35:06 --> Security Class Initialized
DEBUG - 2022-02-22 22:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-22 22:35:06 --> Input Class Initialized
INFO - 2022-02-22 22:35:06 --> Language Class Initialized
INFO - 2022-02-22 22:35:06 --> Loader Class Initialized
INFO - 2022-02-22 22:35:06 --> Helper loaded: url_helper
INFO - 2022-02-22 22:35:06 --> Helper loaded: form_helper
INFO - 2022-02-22 22:35:06 --> Helper loaded: common_helper
INFO - 2022-02-22 22:35:06 --> Database Driver Class Initialized
DEBUG - 2022-02-22 22:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-22 22:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-22 22:35:06 --> Controller Class Initialized
INFO - 2022-02-22 22:35:06 --> Form Validation Class Initialized
DEBUG - 2022-02-22 22:35:06 --> Encrypt Class Initialized
DEBUG - 2022-02-22 22:35:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 22:35:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-22 22:35:06 --> Email Class Initialized
INFO - 2022-02-22 22:35:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-22 22:35:06 --> Calendar Class Initialized
INFO - 2022-02-22 22:35:06 --> Model "Login_model" initialized
INFO - 2022-02-22 22:35:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-22 22:35:06 --> Final output sent to browser
DEBUG - 2022-02-22 22:35:06 --> Total execution time: 0.0375
