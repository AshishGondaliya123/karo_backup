<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-31 17:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-31 17:41:22 --> Config Class Initialized
INFO - 2021-05-31 17:41:22 --> Hooks Class Initialized
DEBUG - 2021-05-31 17:41:22 --> UTF-8 Support Enabled
INFO - 2021-05-31 17:41:22 --> Utf8 Class Initialized
INFO - 2021-05-31 17:41:22 --> URI Class Initialized
DEBUG - 2021-05-31 17:41:22 --> No URI present. Default controller set.
INFO - 2021-05-31 17:41:22 --> Router Class Initialized
INFO - 2021-05-31 17:41:22 --> Output Class Initialized
INFO - 2021-05-31 17:41:22 --> Security Class Initialized
DEBUG - 2021-05-31 17:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-31 17:41:22 --> Input Class Initialized
INFO - 2021-05-31 17:41:22 --> Language Class Initialized
INFO - 2021-05-31 17:41:22 --> Loader Class Initialized
INFO - 2021-05-31 17:41:22 --> Helper loaded: url_helper
INFO - 2021-05-31 17:41:22 --> Helper loaded: form_helper
INFO - 2021-05-31 17:41:22 --> Helper loaded: common_helper
INFO - 2021-05-31 17:41:22 --> Database Driver Class Initialized
DEBUG - 2021-05-31 17:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-31 17:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-31 17:41:22 --> Controller Class Initialized
INFO - 2021-05-31 17:41:22 --> Form Validation Class Initialized
DEBUG - 2021-05-31 17:41:22 --> Encrypt Class Initialized
DEBUG - 2021-05-31 17:41:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-31 17:41:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-31 17:41:22 --> Email Class Initialized
INFO - 2021-05-31 17:41:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-31 17:41:22 --> Calendar Class Initialized
INFO - 2021-05-31 17:41:22 --> Model "Login_model" initialized
INFO - 2021-05-31 17:41:22 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-31 17:41:22 --> Final output sent to browser
DEBUG - 2021-05-31 17:41:22 --> Total execution time: 0.0346
