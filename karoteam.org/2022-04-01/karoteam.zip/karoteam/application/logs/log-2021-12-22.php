<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-22 01:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 01:14:33 --> Config Class Initialized
INFO - 2021-12-22 01:14:33 --> Hooks Class Initialized
DEBUG - 2021-12-22 01:14:33 --> UTF-8 Support Enabled
INFO - 2021-12-22 01:14:33 --> Utf8 Class Initialized
INFO - 2021-12-22 01:14:33 --> URI Class Initialized
DEBUG - 2021-12-22 01:14:33 --> No URI present. Default controller set.
INFO - 2021-12-22 01:14:33 --> Router Class Initialized
INFO - 2021-12-22 01:14:33 --> Output Class Initialized
INFO - 2021-12-22 01:14:33 --> Security Class Initialized
DEBUG - 2021-12-22 01:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 01:14:33 --> Input Class Initialized
INFO - 2021-12-22 01:14:33 --> Language Class Initialized
INFO - 2021-12-22 01:14:33 --> Loader Class Initialized
INFO - 2021-12-22 01:14:33 --> Helper loaded: url_helper
INFO - 2021-12-22 01:14:33 --> Helper loaded: form_helper
INFO - 2021-12-22 01:14:33 --> Helper loaded: common_helper
INFO - 2021-12-22 01:14:33 --> Database Driver Class Initialized
DEBUG - 2021-12-22 01:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 01:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 01:14:33 --> Controller Class Initialized
INFO - 2021-12-22 01:14:33 --> Form Validation Class Initialized
DEBUG - 2021-12-22 01:14:33 --> Encrypt Class Initialized
DEBUG - 2021-12-22 01:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 01:14:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 01:14:33 --> Email Class Initialized
INFO - 2021-12-22 01:14:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 01:14:33 --> Calendar Class Initialized
INFO - 2021-12-22 01:14:33 --> Model "Login_model" initialized
INFO - 2021-12-22 01:14:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 01:14:33 --> Final output sent to browser
DEBUG - 2021-12-22 01:14:33 --> Total execution time: 0.0240
ERROR - 2021-12-22 01:14:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 01:14:41 --> Config Class Initialized
INFO - 2021-12-22 01:14:41 --> Hooks Class Initialized
DEBUG - 2021-12-22 01:14:41 --> UTF-8 Support Enabled
INFO - 2021-12-22 01:14:41 --> Utf8 Class Initialized
INFO - 2021-12-22 01:14:41 --> URI Class Initialized
DEBUG - 2021-12-22 01:14:41 --> No URI present. Default controller set.
INFO - 2021-12-22 01:14:41 --> Router Class Initialized
INFO - 2021-12-22 01:14:41 --> Output Class Initialized
INFO - 2021-12-22 01:14:41 --> Security Class Initialized
DEBUG - 2021-12-22 01:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 01:14:41 --> Input Class Initialized
INFO - 2021-12-22 01:14:41 --> Language Class Initialized
INFO - 2021-12-22 01:14:41 --> Loader Class Initialized
INFO - 2021-12-22 01:14:41 --> Helper loaded: url_helper
INFO - 2021-12-22 01:14:41 --> Helper loaded: form_helper
INFO - 2021-12-22 01:14:41 --> Helper loaded: common_helper
INFO - 2021-12-22 01:14:41 --> Database Driver Class Initialized
DEBUG - 2021-12-22 01:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 01:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 01:14:41 --> Controller Class Initialized
INFO - 2021-12-22 01:14:41 --> Form Validation Class Initialized
DEBUG - 2021-12-22 01:14:41 --> Encrypt Class Initialized
DEBUG - 2021-12-22 01:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 01:14:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 01:14:41 --> Email Class Initialized
INFO - 2021-12-22 01:14:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 01:14:41 --> Calendar Class Initialized
INFO - 2021-12-22 01:14:41 --> Model "Login_model" initialized
INFO - 2021-12-22 01:14:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 01:14:41 --> Final output sent to browser
DEBUG - 2021-12-22 01:14:41 --> Total execution time: 0.0225
ERROR - 2021-12-22 01:14:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 01:14:48 --> Config Class Initialized
INFO - 2021-12-22 01:14:48 --> Hooks Class Initialized
DEBUG - 2021-12-22 01:14:48 --> UTF-8 Support Enabled
INFO - 2021-12-22 01:14:48 --> Utf8 Class Initialized
INFO - 2021-12-22 01:14:48 --> URI Class Initialized
DEBUG - 2021-12-22 01:14:48 --> No URI present. Default controller set.
INFO - 2021-12-22 01:14:48 --> Router Class Initialized
INFO - 2021-12-22 01:14:48 --> Output Class Initialized
INFO - 2021-12-22 01:14:48 --> Security Class Initialized
DEBUG - 2021-12-22 01:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 01:14:48 --> Input Class Initialized
INFO - 2021-12-22 01:14:48 --> Language Class Initialized
INFO - 2021-12-22 01:14:48 --> Loader Class Initialized
INFO - 2021-12-22 01:14:48 --> Helper loaded: url_helper
INFO - 2021-12-22 01:14:48 --> Helper loaded: form_helper
INFO - 2021-12-22 01:14:48 --> Helper loaded: common_helper
INFO - 2021-12-22 01:14:48 --> Database Driver Class Initialized
DEBUG - 2021-12-22 01:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 01:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 01:14:48 --> Controller Class Initialized
INFO - 2021-12-22 01:14:48 --> Form Validation Class Initialized
DEBUG - 2021-12-22 01:14:48 --> Encrypt Class Initialized
DEBUG - 2021-12-22 01:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 01:14:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 01:14:48 --> Email Class Initialized
INFO - 2021-12-22 01:14:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 01:14:48 --> Calendar Class Initialized
INFO - 2021-12-22 01:14:48 --> Model "Login_model" initialized
INFO - 2021-12-22 01:14:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 01:14:48 --> Final output sent to browser
DEBUG - 2021-12-22 01:14:48 --> Total execution time: 0.0226
ERROR - 2021-12-22 01:14:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 01:14:56 --> Config Class Initialized
INFO - 2021-12-22 01:14:56 --> Hooks Class Initialized
DEBUG - 2021-12-22 01:14:56 --> UTF-8 Support Enabled
INFO - 2021-12-22 01:14:56 --> Utf8 Class Initialized
INFO - 2021-12-22 01:14:56 --> URI Class Initialized
INFO - 2021-12-22 01:14:56 --> Router Class Initialized
INFO - 2021-12-22 01:14:56 --> Output Class Initialized
INFO - 2021-12-22 01:14:56 --> Security Class Initialized
DEBUG - 2021-12-22 01:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 01:14:56 --> Input Class Initialized
INFO - 2021-12-22 01:14:56 --> Language Class Initialized
ERROR - 2021-12-22 01:14:56 --> 404 Page Not Found: Admin/index
ERROR - 2021-12-22 01:15:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 01:15:04 --> Config Class Initialized
INFO - 2021-12-22 01:15:04 --> Hooks Class Initialized
DEBUG - 2021-12-22 01:15:04 --> UTF-8 Support Enabled
INFO - 2021-12-22 01:15:04 --> Utf8 Class Initialized
INFO - 2021-12-22 01:15:04 --> URI Class Initialized
INFO - 2021-12-22 01:15:04 --> Router Class Initialized
INFO - 2021-12-22 01:15:04 --> Output Class Initialized
INFO - 2021-12-22 01:15:04 --> Security Class Initialized
DEBUG - 2021-12-22 01:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 01:15:04 --> Input Class Initialized
INFO - 2021-12-22 01:15:04 --> Language Class Initialized
ERROR - 2021-12-22 01:15:04 --> 404 Page Not Found: Manager/index
ERROR - 2021-12-22 01:15:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 01:15:12 --> Config Class Initialized
INFO - 2021-12-22 01:15:12 --> Hooks Class Initialized
DEBUG - 2021-12-22 01:15:12 --> UTF-8 Support Enabled
INFO - 2021-12-22 01:15:12 --> Utf8 Class Initialized
INFO - 2021-12-22 01:15:12 --> URI Class Initialized
INFO - 2021-12-22 01:15:12 --> Router Class Initialized
INFO - 2021-12-22 01:15:12 --> Output Class Initialized
INFO - 2021-12-22 01:15:12 --> Security Class Initialized
DEBUG - 2021-12-22 01:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 01:15:12 --> Input Class Initialized
INFO - 2021-12-22 01:15:12 --> Language Class Initialized
ERROR - 2021-12-22 01:15:12 --> 404 Page Not Found: Admin/content
ERROR - 2021-12-22 01:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 01:15:20 --> Config Class Initialized
INFO - 2021-12-22 01:15:20 --> Hooks Class Initialized
DEBUG - 2021-12-22 01:15:20 --> UTF-8 Support Enabled
INFO - 2021-12-22 01:15:20 --> Utf8 Class Initialized
INFO - 2021-12-22 01:15:20 --> URI Class Initialized
INFO - 2021-12-22 01:15:20 --> Router Class Initialized
INFO - 2021-12-22 01:15:20 --> Output Class Initialized
INFO - 2021-12-22 01:15:20 --> Security Class Initialized
DEBUG - 2021-12-22 01:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 01:15:20 --> Input Class Initialized
INFO - 2021-12-22 01:15:20 --> Language Class Initialized
ERROR - 2021-12-22 01:15:20 --> 404 Page Not Found: Simpla/index
ERROR - 2021-12-22 04:52:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 04:52:47 --> Config Class Initialized
INFO - 2021-12-22 04:52:47 --> Hooks Class Initialized
DEBUG - 2021-12-22 04:52:47 --> UTF-8 Support Enabled
INFO - 2021-12-22 04:52:47 --> Utf8 Class Initialized
INFO - 2021-12-22 04:52:47 --> URI Class Initialized
DEBUG - 2021-12-22 04:52:47 --> No URI present. Default controller set.
INFO - 2021-12-22 04:52:47 --> Router Class Initialized
INFO - 2021-12-22 04:52:47 --> Output Class Initialized
INFO - 2021-12-22 04:52:47 --> Security Class Initialized
DEBUG - 2021-12-22 04:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 04:52:47 --> Input Class Initialized
INFO - 2021-12-22 04:52:47 --> Language Class Initialized
INFO - 2021-12-22 04:52:47 --> Loader Class Initialized
INFO - 2021-12-22 04:52:47 --> Helper loaded: url_helper
INFO - 2021-12-22 04:52:47 --> Helper loaded: form_helper
INFO - 2021-12-22 04:52:47 --> Helper loaded: common_helper
INFO - 2021-12-22 04:52:47 --> Database Driver Class Initialized
DEBUG - 2021-12-22 04:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 04:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 04:52:47 --> Controller Class Initialized
INFO - 2021-12-22 04:52:47 --> Form Validation Class Initialized
DEBUG - 2021-12-22 04:52:47 --> Encrypt Class Initialized
DEBUG - 2021-12-22 04:52:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 04:52:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 04:52:47 --> Email Class Initialized
INFO - 2021-12-22 04:52:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 04:52:47 --> Calendar Class Initialized
INFO - 2021-12-22 04:52:47 --> Model "Login_model" initialized
INFO - 2021-12-22 04:52:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 04:52:47 --> Final output sent to browser
DEBUG - 2021-12-22 04:52:47 --> Total execution time: 0.0222
ERROR - 2021-12-22 04:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 04:57:41 --> Config Class Initialized
INFO - 2021-12-22 04:57:41 --> Hooks Class Initialized
DEBUG - 2021-12-22 04:57:41 --> UTF-8 Support Enabled
INFO - 2021-12-22 04:57:41 --> Utf8 Class Initialized
INFO - 2021-12-22 04:57:41 --> URI Class Initialized
DEBUG - 2021-12-22 04:57:41 --> No URI present. Default controller set.
INFO - 2021-12-22 04:57:41 --> Router Class Initialized
INFO - 2021-12-22 04:57:41 --> Output Class Initialized
INFO - 2021-12-22 04:57:41 --> Security Class Initialized
DEBUG - 2021-12-22 04:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 04:57:41 --> Input Class Initialized
INFO - 2021-12-22 04:57:41 --> Language Class Initialized
INFO - 2021-12-22 04:57:41 --> Loader Class Initialized
INFO - 2021-12-22 04:57:41 --> Helper loaded: url_helper
INFO - 2021-12-22 04:57:41 --> Helper loaded: form_helper
INFO - 2021-12-22 04:57:41 --> Helper loaded: common_helper
INFO - 2021-12-22 04:57:41 --> Database Driver Class Initialized
DEBUG - 2021-12-22 04:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 04:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 04:57:41 --> Controller Class Initialized
INFO - 2021-12-22 04:57:41 --> Form Validation Class Initialized
DEBUG - 2021-12-22 04:57:41 --> Encrypt Class Initialized
DEBUG - 2021-12-22 04:57:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 04:57:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 04:57:41 --> Email Class Initialized
INFO - 2021-12-22 04:57:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 04:57:41 --> Calendar Class Initialized
INFO - 2021-12-22 04:57:41 --> Model "Login_model" initialized
INFO - 2021-12-22 04:57:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 04:57:41 --> Final output sent to browser
DEBUG - 2021-12-22 04:57:41 --> Total execution time: 0.0290
ERROR - 2021-12-22 04:58:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 04:58:26 --> Config Class Initialized
INFO - 2021-12-22 04:58:26 --> Hooks Class Initialized
DEBUG - 2021-12-22 04:58:26 --> UTF-8 Support Enabled
INFO - 2021-12-22 04:58:26 --> Utf8 Class Initialized
INFO - 2021-12-22 04:58:26 --> URI Class Initialized
DEBUG - 2021-12-22 04:58:26 --> No URI present. Default controller set.
INFO - 2021-12-22 04:58:26 --> Router Class Initialized
INFO - 2021-12-22 04:58:26 --> Output Class Initialized
INFO - 2021-12-22 04:58:26 --> Security Class Initialized
DEBUG - 2021-12-22 04:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 04:58:26 --> Input Class Initialized
INFO - 2021-12-22 04:58:26 --> Language Class Initialized
INFO - 2021-12-22 04:58:26 --> Loader Class Initialized
INFO - 2021-12-22 04:58:26 --> Helper loaded: url_helper
INFO - 2021-12-22 04:58:26 --> Helper loaded: form_helper
INFO - 2021-12-22 04:58:26 --> Helper loaded: common_helper
INFO - 2021-12-22 04:58:26 --> Database Driver Class Initialized
DEBUG - 2021-12-22 04:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 04:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 04:58:26 --> Controller Class Initialized
INFO - 2021-12-22 04:58:26 --> Form Validation Class Initialized
DEBUG - 2021-12-22 04:58:26 --> Encrypt Class Initialized
DEBUG - 2021-12-22 04:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 04:58:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 04:58:26 --> Email Class Initialized
INFO - 2021-12-22 04:58:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 04:58:26 --> Calendar Class Initialized
INFO - 2021-12-22 04:58:26 --> Model "Login_model" initialized
INFO - 2021-12-22 04:58:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 04:58:26 --> Final output sent to browser
DEBUG - 2021-12-22 04:58:26 --> Total execution time: 0.0223
ERROR - 2021-12-22 05:02:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 05:02:26 --> Config Class Initialized
INFO - 2021-12-22 05:02:26 --> Hooks Class Initialized
DEBUG - 2021-12-22 05:02:26 --> UTF-8 Support Enabled
INFO - 2021-12-22 05:02:26 --> Utf8 Class Initialized
INFO - 2021-12-22 05:02:26 --> URI Class Initialized
DEBUG - 2021-12-22 05:02:26 --> No URI present. Default controller set.
INFO - 2021-12-22 05:02:26 --> Router Class Initialized
INFO - 2021-12-22 05:02:26 --> Output Class Initialized
INFO - 2021-12-22 05:02:26 --> Security Class Initialized
DEBUG - 2021-12-22 05:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 05:02:26 --> Input Class Initialized
INFO - 2021-12-22 05:02:26 --> Language Class Initialized
INFO - 2021-12-22 05:02:26 --> Loader Class Initialized
INFO - 2021-12-22 05:02:26 --> Helper loaded: url_helper
INFO - 2021-12-22 05:02:26 --> Helper loaded: form_helper
INFO - 2021-12-22 05:02:26 --> Helper loaded: common_helper
INFO - 2021-12-22 05:02:26 --> Database Driver Class Initialized
DEBUG - 2021-12-22 05:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 05:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 05:02:26 --> Controller Class Initialized
INFO - 2021-12-22 05:02:26 --> Form Validation Class Initialized
DEBUG - 2021-12-22 05:02:26 --> Encrypt Class Initialized
DEBUG - 2021-12-22 05:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 05:02:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 05:02:26 --> Email Class Initialized
INFO - 2021-12-22 05:02:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 05:02:26 --> Calendar Class Initialized
INFO - 2021-12-22 05:02:26 --> Model "Login_model" initialized
INFO - 2021-12-22 05:02:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 05:02:26 --> Final output sent to browser
DEBUG - 2021-12-22 05:02:26 --> Total execution time: 0.0260
ERROR - 2021-12-22 06:39:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:39:31 --> Config Class Initialized
INFO - 2021-12-22 06:39:31 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:39:31 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:39:31 --> Utf8 Class Initialized
INFO - 2021-12-22 06:39:31 --> URI Class Initialized
INFO - 2021-12-22 06:39:31 --> Router Class Initialized
INFO - 2021-12-22 06:39:31 --> Output Class Initialized
INFO - 2021-12-22 06:39:31 --> Security Class Initialized
DEBUG - 2021-12-22 06:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:39:31 --> Input Class Initialized
INFO - 2021-12-22 06:39:31 --> Language Class Initialized
ERROR - 2021-12-22 06:39:31 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2021-12-22 06:40:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:40:19 --> Config Class Initialized
INFO - 2021-12-22 06:40:19 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:40:19 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:40:19 --> Utf8 Class Initialized
INFO - 2021-12-22 06:40:19 --> URI Class Initialized
INFO - 2021-12-22 06:40:19 --> Router Class Initialized
INFO - 2021-12-22 06:40:19 --> Output Class Initialized
INFO - 2021-12-22 06:40:19 --> Security Class Initialized
DEBUG - 2021-12-22 06:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:40:19 --> Input Class Initialized
INFO - 2021-12-22 06:40:19 --> Language Class Initialized
ERROR - 2021-12-22 06:40:19 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2021-12-22 06:40:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:40:30 --> Config Class Initialized
INFO - 2021-12-22 06:40:30 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:40:30 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:40:30 --> Utf8 Class Initialized
INFO - 2021-12-22 06:40:30 --> URI Class Initialized
INFO - 2021-12-22 06:40:30 --> Router Class Initialized
INFO - 2021-12-22 06:40:30 --> Output Class Initialized
INFO - 2021-12-22 06:40:30 --> Security Class Initialized
DEBUG - 2021-12-22 06:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:40:30 --> Input Class Initialized
INFO - 2021-12-22 06:40:30 --> Language Class Initialized
ERROR - 2021-12-22 06:40:30 --> 404 Page Not Found: Phpinfo/index
ERROR - 2021-12-22 06:41:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:41:18 --> Config Class Initialized
INFO - 2021-12-22 06:41:18 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:41:18 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:41:18 --> Utf8 Class Initialized
INFO - 2021-12-22 06:41:18 --> URI Class Initialized
INFO - 2021-12-22 06:41:18 --> Router Class Initialized
INFO - 2021-12-22 06:41:18 --> Output Class Initialized
INFO - 2021-12-22 06:41:18 --> Security Class Initialized
DEBUG - 2021-12-22 06:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:41:18 --> Input Class Initialized
INFO - 2021-12-22 06:41:18 --> Language Class Initialized
ERROR - 2021-12-22 06:41:18 --> 404 Page Not Found: Awsyml/index
ERROR - 2021-12-22 06:41:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:41:53 --> Config Class Initialized
INFO - 2021-12-22 06:41:53 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:41:53 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:41:53 --> Utf8 Class Initialized
INFO - 2021-12-22 06:41:53 --> URI Class Initialized
INFO - 2021-12-22 06:41:53 --> Router Class Initialized
INFO - 2021-12-22 06:41:53 --> Output Class Initialized
INFO - 2021-12-22 06:41:53 --> Security Class Initialized
DEBUG - 2021-12-22 06:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:41:53 --> Input Class Initialized
INFO - 2021-12-22 06:41:53 --> Language Class Initialized
ERROR - 2021-12-22 06:41:53 --> 404 Page Not Found: Infophp/index
ERROR - 2021-12-22 06:42:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:42:05 --> Config Class Initialized
INFO - 2021-12-22 06:42:05 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:42:05 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:42:05 --> Utf8 Class Initialized
INFO - 2021-12-22 06:42:05 --> URI Class Initialized
INFO - 2021-12-22 06:42:05 --> Router Class Initialized
INFO - 2021-12-22 06:42:05 --> Output Class Initialized
INFO - 2021-12-22 06:42:05 --> Security Class Initialized
DEBUG - 2021-12-22 06:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:42:05 --> Input Class Initialized
INFO - 2021-12-22 06:42:05 --> Language Class Initialized
ERROR - 2021-12-22 06:42:05 --> 404 Page Not Found: Aws/credentials
ERROR - 2021-12-22 06:42:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:42:29 --> Config Class Initialized
INFO - 2021-12-22 06:42:29 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:42:29 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:42:29 --> Utf8 Class Initialized
INFO - 2021-12-22 06:42:29 --> URI Class Initialized
DEBUG - 2021-12-22 06:42:29 --> No URI present. Default controller set.
INFO - 2021-12-22 06:42:29 --> Router Class Initialized
INFO - 2021-12-22 06:42:29 --> Output Class Initialized
INFO - 2021-12-22 06:42:29 --> Security Class Initialized
DEBUG - 2021-12-22 06:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:42:29 --> Input Class Initialized
INFO - 2021-12-22 06:42:29 --> Language Class Initialized
INFO - 2021-12-22 06:42:29 --> Loader Class Initialized
INFO - 2021-12-22 06:42:29 --> Helper loaded: url_helper
INFO - 2021-12-22 06:42:29 --> Helper loaded: form_helper
INFO - 2021-12-22 06:42:29 --> Helper loaded: common_helper
INFO - 2021-12-22 06:42:29 --> Database Driver Class Initialized
DEBUG - 2021-12-22 06:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 06:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 06:42:29 --> Controller Class Initialized
INFO - 2021-12-22 06:42:29 --> Form Validation Class Initialized
DEBUG - 2021-12-22 06:42:29 --> Encrypt Class Initialized
DEBUG - 2021-12-22 06:42:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:42:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 06:42:29 --> Email Class Initialized
INFO - 2021-12-22 06:42:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 06:42:29 --> Calendar Class Initialized
INFO - 2021-12-22 06:42:29 --> Model "Login_model" initialized
INFO - 2021-12-22 06:42:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 06:42:29 --> Final output sent to browser
DEBUG - 2021-12-22 06:42:29 --> Total execution time: 0.0235
ERROR - 2021-12-22 06:42:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:42:45 --> Config Class Initialized
INFO - 2021-12-22 06:42:45 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:42:45 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:42:45 --> Utf8 Class Initialized
INFO - 2021-12-22 06:42:45 --> URI Class Initialized
INFO - 2021-12-22 06:42:45 --> Router Class Initialized
INFO - 2021-12-22 06:42:45 --> Output Class Initialized
INFO - 2021-12-22 06:42:45 --> Security Class Initialized
DEBUG - 2021-12-22 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:42:45 --> Input Class Initialized
INFO - 2021-12-22 06:42:45 --> Language Class Initialized
ERROR - 2021-12-22 06:42:45 --> 404 Page Not Found: Config/aws.yml
ERROR - 2021-12-22 06:43:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:43:31 --> Config Class Initialized
INFO - 2021-12-22 06:43:31 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:43:31 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:43:31 --> Utf8 Class Initialized
INFO - 2021-12-22 06:43:31 --> URI Class Initialized
DEBUG - 2021-12-22 06:43:31 --> No URI present. Default controller set.
INFO - 2021-12-22 06:43:31 --> Router Class Initialized
INFO - 2021-12-22 06:43:31 --> Output Class Initialized
INFO - 2021-12-22 06:43:31 --> Security Class Initialized
DEBUG - 2021-12-22 06:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:43:31 --> Input Class Initialized
INFO - 2021-12-22 06:43:31 --> Language Class Initialized
INFO - 2021-12-22 06:43:31 --> Loader Class Initialized
INFO - 2021-12-22 06:43:31 --> Helper loaded: url_helper
INFO - 2021-12-22 06:43:31 --> Helper loaded: form_helper
INFO - 2021-12-22 06:43:31 --> Helper loaded: common_helper
INFO - 2021-12-22 06:43:31 --> Database Driver Class Initialized
DEBUG - 2021-12-22 06:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 06:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 06:43:31 --> Controller Class Initialized
INFO - 2021-12-22 06:43:31 --> Form Validation Class Initialized
DEBUG - 2021-12-22 06:43:31 --> Encrypt Class Initialized
DEBUG - 2021-12-22 06:43:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 06:43:31 --> Email Class Initialized
INFO - 2021-12-22 06:43:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 06:43:31 --> Calendar Class Initialized
INFO - 2021-12-22 06:43:31 --> Model "Login_model" initialized
INFO - 2021-12-22 06:43:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 06:43:31 --> Final output sent to browser
DEBUG - 2021-12-22 06:43:31 --> Total execution time: 0.0226
ERROR - 2021-12-22 06:43:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 06:43:48 --> Config Class Initialized
INFO - 2021-12-22 06:43:48 --> Hooks Class Initialized
DEBUG - 2021-12-22 06:43:48 --> UTF-8 Support Enabled
INFO - 2021-12-22 06:43:48 --> Utf8 Class Initialized
INFO - 2021-12-22 06:43:48 --> URI Class Initialized
INFO - 2021-12-22 06:43:48 --> Router Class Initialized
INFO - 2021-12-22 06:43:48 --> Output Class Initialized
INFO - 2021-12-22 06:43:48 --> Security Class Initialized
DEBUG - 2021-12-22 06:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 06:43:48 --> Input Class Initialized
INFO - 2021-12-22 06:43:48 --> Language Class Initialized
ERROR - 2021-12-22 06:43:48 --> 404 Page Not Found: Configjs/index
ERROR - 2021-12-22 14:20:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 14:20:44 --> Config Class Initialized
INFO - 2021-12-22 14:20:44 --> Hooks Class Initialized
DEBUG - 2021-12-22 14:20:44 --> UTF-8 Support Enabled
INFO - 2021-12-22 14:20:44 --> Utf8 Class Initialized
INFO - 2021-12-22 14:20:44 --> URI Class Initialized
DEBUG - 2021-12-22 14:20:44 --> No URI present. Default controller set.
INFO - 2021-12-22 14:20:44 --> Router Class Initialized
INFO - 2021-12-22 14:20:44 --> Output Class Initialized
INFO - 2021-12-22 14:20:44 --> Security Class Initialized
DEBUG - 2021-12-22 14:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 14:20:44 --> Input Class Initialized
INFO - 2021-12-22 14:20:44 --> Language Class Initialized
INFO - 2021-12-22 14:20:44 --> Loader Class Initialized
INFO - 2021-12-22 14:20:44 --> Helper loaded: url_helper
INFO - 2021-12-22 14:20:44 --> Helper loaded: form_helper
INFO - 2021-12-22 14:20:44 --> Helper loaded: common_helper
INFO - 2021-12-22 14:20:44 --> Database Driver Class Initialized
DEBUG - 2021-12-22 14:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 14:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 14:20:44 --> Controller Class Initialized
INFO - 2021-12-22 14:20:44 --> Form Validation Class Initialized
DEBUG - 2021-12-22 14:20:44 --> Encrypt Class Initialized
DEBUG - 2021-12-22 14:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 14:20:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 14:20:44 --> Email Class Initialized
INFO - 2021-12-22 14:20:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 14:20:44 --> Calendar Class Initialized
INFO - 2021-12-22 14:20:44 --> Model "Login_model" initialized
INFO - 2021-12-22 14:20:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 14:20:44 --> Final output sent to browser
DEBUG - 2021-12-22 14:20:44 --> Total execution time: 0.0224
ERROR - 2021-12-22 14:20:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 14:20:45 --> Config Class Initialized
INFO - 2021-12-22 14:20:45 --> Hooks Class Initialized
DEBUG - 2021-12-22 14:20:45 --> UTF-8 Support Enabled
INFO - 2021-12-22 14:20:45 --> Utf8 Class Initialized
INFO - 2021-12-22 14:20:45 --> URI Class Initialized
INFO - 2021-12-22 14:20:45 --> Router Class Initialized
INFO - 2021-12-22 14:20:45 --> Output Class Initialized
INFO - 2021-12-22 14:20:45 --> Security Class Initialized
DEBUG - 2021-12-22 14:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 14:20:45 --> Input Class Initialized
INFO - 2021-12-22 14:20:45 --> Language Class Initialized
ERROR - 2021-12-22 14:20:45 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-22 14:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 14:20:51 --> Config Class Initialized
INFO - 2021-12-22 14:20:51 --> Hooks Class Initialized
DEBUG - 2021-12-22 14:20:51 --> UTF-8 Support Enabled
INFO - 2021-12-22 14:20:51 --> Utf8 Class Initialized
INFO - 2021-12-22 14:20:51 --> URI Class Initialized
DEBUG - 2021-12-22 14:20:51 --> No URI present. Default controller set.
INFO - 2021-12-22 14:20:51 --> Router Class Initialized
INFO - 2021-12-22 14:20:51 --> Output Class Initialized
INFO - 2021-12-22 14:20:51 --> Security Class Initialized
DEBUG - 2021-12-22 14:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 14:20:51 --> Input Class Initialized
INFO - 2021-12-22 14:20:51 --> Language Class Initialized
INFO - 2021-12-22 14:20:51 --> Loader Class Initialized
INFO - 2021-12-22 14:20:51 --> Helper loaded: url_helper
INFO - 2021-12-22 14:20:51 --> Helper loaded: form_helper
INFO - 2021-12-22 14:20:51 --> Helper loaded: common_helper
INFO - 2021-12-22 14:20:51 --> Database Driver Class Initialized
DEBUG - 2021-12-22 14:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 14:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 14:20:51 --> Controller Class Initialized
INFO - 2021-12-22 14:20:51 --> Form Validation Class Initialized
DEBUG - 2021-12-22 14:20:51 --> Encrypt Class Initialized
DEBUG - 2021-12-22 14:20:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 14:20:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 14:20:51 --> Email Class Initialized
INFO - 2021-12-22 14:20:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 14:20:51 --> Calendar Class Initialized
INFO - 2021-12-22 14:20:51 --> Model "Login_model" initialized
INFO - 2021-12-22 14:20:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 14:20:51 --> Final output sent to browser
DEBUG - 2021-12-22 14:20:51 --> Total execution time: 0.0280
ERROR - 2021-12-22 14:20:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 14:20:51 --> Config Class Initialized
INFO - 2021-12-22 14:20:51 --> Hooks Class Initialized
DEBUG - 2021-12-22 14:20:51 --> UTF-8 Support Enabled
INFO - 2021-12-22 14:20:51 --> Utf8 Class Initialized
INFO - 2021-12-22 14:20:51 --> URI Class Initialized
INFO - 2021-12-22 14:20:51 --> Router Class Initialized
INFO - 2021-12-22 14:20:51 --> Output Class Initialized
INFO - 2021-12-22 14:20:51 --> Security Class Initialized
DEBUG - 2021-12-22 14:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 14:20:51 --> Input Class Initialized
INFO - 2021-12-22 14:20:51 --> Language Class Initialized
INFO - 2021-12-22 14:20:51 --> Loader Class Initialized
INFO - 2021-12-22 14:20:51 --> Helper loaded: url_helper
INFO - 2021-12-22 14:20:51 --> Helper loaded: form_helper
INFO - 2021-12-22 14:20:51 --> Helper loaded: common_helper
INFO - 2021-12-22 14:20:51 --> Database Driver Class Initialized
DEBUG - 2021-12-22 14:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 14:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 14:20:51 --> Controller Class Initialized
INFO - 2021-12-22 14:20:51 --> Form Validation Class Initialized
DEBUG - 2021-12-22 14:20:51 --> Encrypt Class Initialized
DEBUG - 2021-12-22 14:20:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 14:20:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 14:20:51 --> Email Class Initialized
INFO - 2021-12-22 14:20:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 14:20:51 --> Calendar Class Initialized
INFO - 2021-12-22 14:20:51 --> Model "Login_model" initialized
INFO - 2021-12-22 14:20:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 14:20:51 --> Final output sent to browser
DEBUG - 2021-12-22 14:20:51 --> Total execution time: 0.0282
ERROR - 2021-12-22 14:20:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 14:20:52 --> Config Class Initialized
INFO - 2021-12-22 14:20:52 --> Hooks Class Initialized
DEBUG - 2021-12-22 14:20:52 --> UTF-8 Support Enabled
INFO - 2021-12-22 14:20:52 --> Utf8 Class Initialized
INFO - 2021-12-22 14:20:52 --> URI Class Initialized
INFO - 2021-12-22 14:20:52 --> Router Class Initialized
INFO - 2021-12-22 14:20:52 --> Output Class Initialized
INFO - 2021-12-22 14:20:52 --> Security Class Initialized
DEBUG - 2021-12-22 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 14:20:52 --> Input Class Initialized
INFO - 2021-12-22 14:20:52 --> Language Class Initialized
INFO - 2021-12-22 14:20:52 --> Loader Class Initialized
INFO - 2021-12-22 14:20:52 --> Helper loaded: url_helper
INFO - 2021-12-22 14:20:52 --> Helper loaded: form_helper
INFO - 2021-12-22 14:20:52 --> Helper loaded: common_helper
INFO - 2021-12-22 14:20:52 --> Database Driver Class Initialized
DEBUG - 2021-12-22 14:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 14:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 14:20:52 --> Controller Class Initialized
INFO - 2021-12-22 14:20:52 --> Form Validation Class Initialized
DEBUG - 2021-12-22 14:20:52 --> Encrypt Class Initialized
DEBUG - 2021-12-22 14:20:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 14:20:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 14:20:52 --> Email Class Initialized
INFO - 2021-12-22 14:20:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 14:20:52 --> Calendar Class Initialized
INFO - 2021-12-22 14:20:52 --> Model "Login_model" initialized
ERROR - 2021-12-22 14:20:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 14:20:53 --> Config Class Initialized
INFO - 2021-12-22 14:20:53 --> Hooks Class Initialized
DEBUG - 2021-12-22 14:20:53 --> UTF-8 Support Enabled
INFO - 2021-12-22 14:20:53 --> Utf8 Class Initialized
INFO - 2021-12-22 14:20:53 --> URI Class Initialized
INFO - 2021-12-22 14:20:53 --> Router Class Initialized
INFO - 2021-12-22 14:20:53 --> Output Class Initialized
INFO - 2021-12-22 14:20:53 --> Security Class Initialized
DEBUG - 2021-12-22 14:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 14:20:53 --> Input Class Initialized
INFO - 2021-12-22 14:20:53 --> Language Class Initialized
INFO - 2021-12-22 14:20:53 --> Loader Class Initialized
INFO - 2021-12-22 14:20:53 --> Helper loaded: url_helper
INFO - 2021-12-22 14:20:53 --> Helper loaded: form_helper
INFO - 2021-12-22 14:20:53 --> Helper loaded: common_helper
INFO - 2021-12-22 14:20:53 --> Database Driver Class Initialized
DEBUG - 2021-12-22 14:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 14:20:53 --> Controller Class Initialized
INFO - 2021-12-22 14:20:53 --> Form Validation Class Initialized
DEBUG - 2021-12-22 14:20:53 --> Encrypt Class Initialized
DEBUG - 2021-12-22 14:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 14:20:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 14:20:53 --> Email Class Initialized
INFO - 2021-12-22 14:20:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 14:20:53 --> Calendar Class Initialized
INFO - 2021-12-22 14:20:53 --> Model "Login_model" initialized
ERROR - 2021-12-22 15:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 15:22:49 --> Config Class Initialized
INFO - 2021-12-22 15:22:49 --> Hooks Class Initialized
DEBUG - 2021-12-22 15:22:49 --> UTF-8 Support Enabled
INFO - 2021-12-22 15:22:49 --> Utf8 Class Initialized
INFO - 2021-12-22 15:22:49 --> URI Class Initialized
DEBUG - 2021-12-22 15:22:49 --> No URI present. Default controller set.
INFO - 2021-12-22 15:22:49 --> Router Class Initialized
INFO - 2021-12-22 15:22:49 --> Output Class Initialized
INFO - 2021-12-22 15:22:49 --> Security Class Initialized
DEBUG - 2021-12-22 15:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 15:22:49 --> Input Class Initialized
INFO - 2021-12-22 15:22:49 --> Language Class Initialized
INFO - 2021-12-22 15:22:49 --> Loader Class Initialized
INFO - 2021-12-22 15:22:49 --> Helper loaded: url_helper
INFO - 2021-12-22 15:22:49 --> Helper loaded: form_helper
INFO - 2021-12-22 15:22:49 --> Helper loaded: common_helper
INFO - 2021-12-22 15:22:49 --> Database Driver Class Initialized
DEBUG - 2021-12-22 15:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 15:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 15:22:49 --> Controller Class Initialized
INFO - 2021-12-22 15:22:49 --> Form Validation Class Initialized
DEBUG - 2021-12-22 15:22:49 --> Encrypt Class Initialized
DEBUG - 2021-12-22 15:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 15:22:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 15:22:49 --> Email Class Initialized
INFO - 2021-12-22 15:22:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 15:22:49 --> Calendar Class Initialized
INFO - 2021-12-22 15:22:49 --> Model "Login_model" initialized
INFO - 2021-12-22 15:22:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 15:22:49 --> Final output sent to browser
DEBUG - 2021-12-22 15:22:49 --> Total execution time: 0.0313
ERROR - 2021-12-22 21:32:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-22 21:32:37 --> Config Class Initialized
INFO - 2021-12-22 21:32:37 --> Hooks Class Initialized
DEBUG - 2021-12-22 21:32:37 --> UTF-8 Support Enabled
INFO - 2021-12-22 21:32:37 --> Utf8 Class Initialized
INFO - 2021-12-22 21:32:37 --> URI Class Initialized
DEBUG - 2021-12-22 21:32:37 --> No URI present. Default controller set.
INFO - 2021-12-22 21:32:37 --> Router Class Initialized
INFO - 2021-12-22 21:32:37 --> Output Class Initialized
INFO - 2021-12-22 21:32:37 --> Security Class Initialized
DEBUG - 2021-12-22 21:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-22 21:32:37 --> Input Class Initialized
INFO - 2021-12-22 21:32:37 --> Language Class Initialized
INFO - 2021-12-22 21:32:37 --> Loader Class Initialized
INFO - 2021-12-22 21:32:37 --> Helper loaded: url_helper
INFO - 2021-12-22 21:32:37 --> Helper loaded: form_helper
INFO - 2021-12-22 21:32:37 --> Helper loaded: common_helper
INFO - 2021-12-22 21:32:37 --> Database Driver Class Initialized
DEBUG - 2021-12-22 21:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-22 21:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-22 21:32:37 --> Controller Class Initialized
INFO - 2021-12-22 21:32:37 --> Form Validation Class Initialized
DEBUG - 2021-12-22 21:32:37 --> Encrypt Class Initialized
DEBUG - 2021-12-22 21:32:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 21:32:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-22 21:32:37 --> Email Class Initialized
INFO - 2021-12-22 21:32:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-22 21:32:37 --> Calendar Class Initialized
INFO - 2021-12-22 21:32:37 --> Model "Login_model" initialized
INFO - 2021-12-22 21:32:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-22 21:32:37 --> Final output sent to browser
DEBUG - 2021-12-22 21:32:37 --> Total execution time: 0.2004
