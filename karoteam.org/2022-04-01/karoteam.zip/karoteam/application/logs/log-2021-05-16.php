<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-16 07:15:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-16 07:15:56 --> Config Class Initialized
INFO - 2021-05-16 07:15:56 --> Hooks Class Initialized
DEBUG - 2021-05-16 07:15:56 --> UTF-8 Support Enabled
INFO - 2021-05-16 07:15:56 --> Utf8 Class Initialized
INFO - 2021-05-16 07:15:56 --> URI Class Initialized
DEBUG - 2021-05-16 07:15:56 --> No URI present. Default controller set.
INFO - 2021-05-16 07:15:56 --> Router Class Initialized
INFO - 2021-05-16 07:15:56 --> Output Class Initialized
INFO - 2021-05-16 07:15:56 --> Security Class Initialized
DEBUG - 2021-05-16 07:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 07:15:56 --> Input Class Initialized
INFO - 2021-05-16 07:15:56 --> Language Class Initialized
INFO - 2021-05-16 07:15:56 --> Loader Class Initialized
INFO - 2021-05-16 07:15:56 --> Helper loaded: url_helper
INFO - 2021-05-16 07:15:56 --> Helper loaded: form_helper
INFO - 2021-05-16 07:15:56 --> Helper loaded: common_helper
INFO - 2021-05-16 07:15:57 --> Database Driver Class Initialized
DEBUG - 2021-05-16 07:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 07:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 07:15:57 --> Controller Class Initialized
INFO - 2021-05-16 07:15:57 --> Form Validation Class Initialized
DEBUG - 2021-05-16 07:15:57 --> Encrypt Class Initialized
DEBUG - 2021-05-16 07:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-16 07:15:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-16 07:15:57 --> Email Class Initialized
INFO - 2021-05-16 07:15:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-16 07:15:57 --> Calendar Class Initialized
INFO - 2021-05-16 07:15:57 --> Model "Login_model" initialized
INFO - 2021-05-16 07:15:57 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-16 07:15:57 --> Final output sent to browser
DEBUG - 2021-05-16 07:15:57 --> Total execution time: 0.1510
ERROR - 2021-05-16 07:50:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-16 07:50:46 --> Config Class Initialized
INFO - 2021-05-16 07:50:46 --> Hooks Class Initialized
DEBUG - 2021-05-16 07:50:46 --> UTF-8 Support Enabled
INFO - 2021-05-16 07:50:46 --> Utf8 Class Initialized
INFO - 2021-05-16 07:50:46 --> URI Class Initialized
DEBUG - 2021-05-16 07:50:46 --> No URI present. Default controller set.
INFO - 2021-05-16 07:50:46 --> Router Class Initialized
INFO - 2021-05-16 07:50:46 --> Output Class Initialized
INFO - 2021-05-16 07:50:46 --> Security Class Initialized
DEBUG - 2021-05-16 07:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-16 07:50:46 --> Input Class Initialized
INFO - 2021-05-16 07:50:46 --> Language Class Initialized
INFO - 2021-05-16 07:50:46 --> Loader Class Initialized
INFO - 2021-05-16 07:50:46 --> Helper loaded: url_helper
INFO - 2021-05-16 07:50:46 --> Helper loaded: form_helper
INFO - 2021-05-16 07:50:46 --> Helper loaded: common_helper
INFO - 2021-05-16 07:50:46 --> Database Driver Class Initialized
DEBUG - 2021-05-16 07:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-16 07:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-16 07:50:46 --> Controller Class Initialized
INFO - 2021-05-16 07:50:46 --> Form Validation Class Initialized
DEBUG - 2021-05-16 07:50:46 --> Encrypt Class Initialized
DEBUG - 2021-05-16 07:50:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-16 07:50:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-16 07:50:46 --> Email Class Initialized
INFO - 2021-05-16 07:50:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-16 07:50:46 --> Calendar Class Initialized
INFO - 2021-05-16 07:50:46 --> Model "Login_model" initialized
INFO - 2021-05-16 07:50:46 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-16 07:50:46 --> Final output sent to browser
DEBUG - 2021-05-16 07:50:46 --> Total execution time: 0.0206
