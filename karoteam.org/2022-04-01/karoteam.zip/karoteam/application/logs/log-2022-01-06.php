<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-06 01:47:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 01:47:03 --> Config Class Initialized
INFO - 2022-01-06 01:47:03 --> Hooks Class Initialized
DEBUG - 2022-01-06 01:47:03 --> UTF-8 Support Enabled
INFO - 2022-01-06 01:47:03 --> Utf8 Class Initialized
INFO - 2022-01-06 01:47:03 --> URI Class Initialized
DEBUG - 2022-01-06 01:47:03 --> No URI present. Default controller set.
INFO - 2022-01-06 01:47:03 --> Router Class Initialized
INFO - 2022-01-06 01:47:03 --> Output Class Initialized
INFO - 2022-01-06 01:47:03 --> Security Class Initialized
DEBUG - 2022-01-06 01:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 01:47:03 --> Input Class Initialized
INFO - 2022-01-06 01:47:03 --> Language Class Initialized
INFO - 2022-01-06 01:47:03 --> Loader Class Initialized
INFO - 2022-01-06 01:47:03 --> Helper loaded: url_helper
INFO - 2022-01-06 01:47:03 --> Helper loaded: form_helper
INFO - 2022-01-06 01:47:03 --> Helper loaded: common_helper
INFO - 2022-01-06 01:47:03 --> Database Driver Class Initialized
DEBUG - 2022-01-06 01:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 01:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 01:47:03 --> Controller Class Initialized
INFO - 2022-01-06 01:47:03 --> Form Validation Class Initialized
DEBUG - 2022-01-06 01:47:03 --> Encrypt Class Initialized
DEBUG - 2022-01-06 01:47:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 01:47:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 01:47:03 --> Email Class Initialized
INFO - 2022-01-06 01:47:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 01:47:03 --> Calendar Class Initialized
INFO - 2022-01-06 01:47:03 --> Model "Login_model" initialized
INFO - 2022-01-06 01:47:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-06 01:47:03 --> Final output sent to browser
DEBUG - 2022-01-06 01:47:03 --> Total execution time: 0.0330
ERROR - 2022-01-06 10:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 10:16:11 --> Config Class Initialized
INFO - 2022-01-06 10:16:11 --> Hooks Class Initialized
DEBUG - 2022-01-06 10:16:11 --> UTF-8 Support Enabled
INFO - 2022-01-06 10:16:11 --> Utf8 Class Initialized
INFO - 2022-01-06 10:16:11 --> URI Class Initialized
DEBUG - 2022-01-06 10:16:11 --> No URI present. Default controller set.
INFO - 2022-01-06 10:16:11 --> Router Class Initialized
INFO - 2022-01-06 10:16:11 --> Output Class Initialized
INFO - 2022-01-06 10:16:11 --> Security Class Initialized
DEBUG - 2022-01-06 10:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 10:16:11 --> Input Class Initialized
INFO - 2022-01-06 10:16:11 --> Language Class Initialized
INFO - 2022-01-06 10:16:11 --> Loader Class Initialized
INFO - 2022-01-06 10:16:11 --> Helper loaded: url_helper
INFO - 2022-01-06 10:16:11 --> Helper loaded: form_helper
INFO - 2022-01-06 10:16:11 --> Helper loaded: common_helper
INFO - 2022-01-06 10:16:11 --> Database Driver Class Initialized
DEBUG - 2022-01-06 10:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 10:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 10:16:11 --> Controller Class Initialized
INFO - 2022-01-06 10:16:11 --> Form Validation Class Initialized
DEBUG - 2022-01-06 10:16:11 --> Encrypt Class Initialized
DEBUG - 2022-01-06 10:16:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:16:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 10:16:11 --> Email Class Initialized
INFO - 2022-01-06 10:16:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 10:16:11 --> Calendar Class Initialized
INFO - 2022-01-06 10:16:11 --> Model "Login_model" initialized
INFO - 2022-01-06 10:16:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-06 10:16:11 --> Final output sent to browser
DEBUG - 2022-01-06 10:16:11 --> Total execution time: 0.0251
ERROR - 2022-01-06 14:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 14:19:47 --> Config Class Initialized
INFO - 2022-01-06 14:19:47 --> Hooks Class Initialized
DEBUG - 2022-01-06 14:19:47 --> UTF-8 Support Enabled
INFO - 2022-01-06 14:19:47 --> Utf8 Class Initialized
INFO - 2022-01-06 14:19:47 --> URI Class Initialized
DEBUG - 2022-01-06 14:19:47 --> No URI present. Default controller set.
INFO - 2022-01-06 14:19:47 --> Router Class Initialized
INFO - 2022-01-06 14:19:47 --> Output Class Initialized
INFO - 2022-01-06 14:19:47 --> Security Class Initialized
DEBUG - 2022-01-06 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 14:19:47 --> Input Class Initialized
INFO - 2022-01-06 14:19:47 --> Language Class Initialized
INFO - 2022-01-06 14:19:47 --> Loader Class Initialized
INFO - 2022-01-06 14:19:47 --> Helper loaded: url_helper
INFO - 2022-01-06 14:19:47 --> Helper loaded: form_helper
INFO - 2022-01-06 14:19:47 --> Helper loaded: common_helper
INFO - 2022-01-06 14:19:47 --> Database Driver Class Initialized
DEBUG - 2022-01-06 14:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 14:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 14:19:47 --> Controller Class Initialized
INFO - 2022-01-06 14:19:47 --> Form Validation Class Initialized
DEBUG - 2022-01-06 14:19:47 --> Encrypt Class Initialized
DEBUG - 2022-01-06 14:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:19:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 14:19:47 --> Email Class Initialized
INFO - 2022-01-06 14:19:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 14:19:47 --> Calendar Class Initialized
INFO - 2022-01-06 14:19:47 --> Model "Login_model" initialized
INFO - 2022-01-06 14:19:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-06 14:19:47 --> Final output sent to browser
DEBUG - 2022-01-06 14:19:47 --> Total execution time: 0.0226
ERROR - 2022-01-06 14:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 14:19:47 --> Config Class Initialized
INFO - 2022-01-06 14:19:47 --> Hooks Class Initialized
DEBUG - 2022-01-06 14:19:47 --> UTF-8 Support Enabled
INFO - 2022-01-06 14:19:47 --> Utf8 Class Initialized
INFO - 2022-01-06 14:19:47 --> URI Class Initialized
INFO - 2022-01-06 14:19:47 --> Router Class Initialized
INFO - 2022-01-06 14:19:47 --> Output Class Initialized
INFO - 2022-01-06 14:19:47 --> Security Class Initialized
DEBUG - 2022-01-06 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 14:19:47 --> Input Class Initialized
INFO - 2022-01-06 14:19:47 --> Language Class Initialized
ERROR - 2022-01-06 14:19:47 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-06 14:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 14:20:06 --> Config Class Initialized
INFO - 2022-01-06 14:20:06 --> Hooks Class Initialized
DEBUG - 2022-01-06 14:20:06 --> UTF-8 Support Enabled
INFO - 2022-01-06 14:20:06 --> Utf8 Class Initialized
INFO - 2022-01-06 14:20:06 --> URI Class Initialized
INFO - 2022-01-06 14:20:06 --> Router Class Initialized
INFO - 2022-01-06 14:20:06 --> Output Class Initialized
INFO - 2022-01-06 14:20:06 --> Security Class Initialized
DEBUG - 2022-01-06 14:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 14:20:06 --> Input Class Initialized
INFO - 2022-01-06 14:20:06 --> Language Class Initialized
INFO - 2022-01-06 14:20:06 --> Loader Class Initialized
INFO - 2022-01-06 14:20:06 --> Helper loaded: url_helper
INFO - 2022-01-06 14:20:06 --> Helper loaded: form_helper
INFO - 2022-01-06 14:20:06 --> Helper loaded: common_helper
INFO - 2022-01-06 14:20:06 --> Database Driver Class Initialized
DEBUG - 2022-01-06 14:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 14:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 14:20:06 --> Controller Class Initialized
INFO - 2022-01-06 14:20:06 --> Form Validation Class Initialized
DEBUG - 2022-01-06 14:20:06 --> Encrypt Class Initialized
DEBUG - 2022-01-06 14:20:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:20:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 14:20:06 --> Email Class Initialized
INFO - 2022-01-06 14:20:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 14:20:06 --> Calendar Class Initialized
INFO - 2022-01-06 14:20:06 --> Model "Login_model" initialized
INFO - 2022-01-06 14:20:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-06 14:20:06 --> Final output sent to browser
DEBUG - 2022-01-06 14:20:06 --> Total execution time: 0.0324
ERROR - 2022-01-06 14:20:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 14:20:07 --> Config Class Initialized
INFO - 2022-01-06 14:20:07 --> Hooks Class Initialized
DEBUG - 2022-01-06 14:20:07 --> UTF-8 Support Enabled
INFO - 2022-01-06 14:20:07 --> Utf8 Class Initialized
INFO - 2022-01-06 14:20:07 --> URI Class Initialized
INFO - 2022-01-06 14:20:07 --> Router Class Initialized
INFO - 2022-01-06 14:20:07 --> Output Class Initialized
INFO - 2022-01-06 14:20:07 --> Security Class Initialized
DEBUG - 2022-01-06 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 14:20:07 --> Input Class Initialized
INFO - 2022-01-06 14:20:07 --> Language Class Initialized
INFO - 2022-01-06 14:20:07 --> Loader Class Initialized
INFO - 2022-01-06 14:20:07 --> Helper loaded: url_helper
INFO - 2022-01-06 14:20:07 --> Helper loaded: form_helper
INFO - 2022-01-06 14:20:07 --> Helper loaded: common_helper
INFO - 2022-01-06 14:20:07 --> Database Driver Class Initialized
DEBUG - 2022-01-06 14:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 14:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 14:20:07 --> Controller Class Initialized
INFO - 2022-01-06 14:20:07 --> Form Validation Class Initialized
DEBUG - 2022-01-06 14:20:07 --> Encrypt Class Initialized
DEBUG - 2022-01-06 14:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 14:20:07 --> Email Class Initialized
INFO - 2022-01-06 14:20:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 14:20:07 --> Calendar Class Initialized
INFO - 2022-01-06 14:20:07 --> Model "Login_model" initialized
ERROR - 2022-01-06 14:20:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 14:20:07 --> Config Class Initialized
INFO - 2022-01-06 14:20:07 --> Hooks Class Initialized
DEBUG - 2022-01-06 14:20:07 --> UTF-8 Support Enabled
INFO - 2022-01-06 14:20:07 --> Utf8 Class Initialized
INFO - 2022-01-06 14:20:07 --> URI Class Initialized
INFO - 2022-01-06 14:20:07 --> Router Class Initialized
INFO - 2022-01-06 14:20:07 --> Output Class Initialized
INFO - 2022-01-06 14:20:07 --> Security Class Initialized
DEBUG - 2022-01-06 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 14:20:07 --> Input Class Initialized
INFO - 2022-01-06 14:20:07 --> Language Class Initialized
INFO - 2022-01-06 14:20:07 --> Loader Class Initialized
INFO - 2022-01-06 14:20:07 --> Helper loaded: url_helper
INFO - 2022-01-06 14:20:07 --> Helper loaded: form_helper
INFO - 2022-01-06 14:20:07 --> Helper loaded: common_helper
INFO - 2022-01-06 14:20:07 --> Database Driver Class Initialized
DEBUG - 2022-01-06 14:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 14:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 14:20:07 --> Controller Class Initialized
INFO - 2022-01-06 14:20:07 --> Form Validation Class Initialized
DEBUG - 2022-01-06 14:20:07 --> Encrypt Class Initialized
DEBUG - 2022-01-06 14:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 14:20:07 --> Email Class Initialized
INFO - 2022-01-06 14:20:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 14:20:07 --> Calendar Class Initialized
INFO - 2022-01-06 14:20:07 --> Model "Login_model" initialized
ERROR - 2022-01-06 14:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 14:20:08 --> Config Class Initialized
INFO - 2022-01-06 14:20:08 --> Hooks Class Initialized
DEBUG - 2022-01-06 14:20:08 --> UTF-8 Support Enabled
INFO - 2022-01-06 14:20:08 --> Utf8 Class Initialized
INFO - 2022-01-06 14:20:08 --> URI Class Initialized
DEBUG - 2022-01-06 14:20:08 --> No URI present. Default controller set.
INFO - 2022-01-06 14:20:08 --> Router Class Initialized
INFO - 2022-01-06 14:20:08 --> Output Class Initialized
INFO - 2022-01-06 14:20:08 --> Security Class Initialized
DEBUG - 2022-01-06 14:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 14:20:08 --> Input Class Initialized
INFO - 2022-01-06 14:20:08 --> Language Class Initialized
INFO - 2022-01-06 14:20:08 --> Loader Class Initialized
INFO - 2022-01-06 14:20:08 --> Helper loaded: url_helper
INFO - 2022-01-06 14:20:08 --> Helper loaded: form_helper
INFO - 2022-01-06 14:20:08 --> Helper loaded: common_helper
INFO - 2022-01-06 14:20:08 --> Database Driver Class Initialized
DEBUG - 2022-01-06 14:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 14:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 14:20:08 --> Controller Class Initialized
INFO - 2022-01-06 14:20:08 --> Form Validation Class Initialized
DEBUG - 2022-01-06 14:20:08 --> Encrypt Class Initialized
DEBUG - 2022-01-06 14:20:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:20:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 14:20:08 --> Email Class Initialized
INFO - 2022-01-06 14:20:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 14:20:08 --> Calendar Class Initialized
INFO - 2022-01-06 14:20:08 --> Model "Login_model" initialized
INFO - 2022-01-06 14:20:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-06 14:20:08 --> Final output sent to browser
DEBUG - 2022-01-06 14:20:08 --> Total execution time: 0.0395
ERROR - 2022-01-06 15:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 15:31:16 --> Config Class Initialized
INFO - 2022-01-06 15:31:16 --> Hooks Class Initialized
DEBUG - 2022-01-06 15:31:16 --> UTF-8 Support Enabled
INFO - 2022-01-06 15:31:16 --> Utf8 Class Initialized
INFO - 2022-01-06 15:31:16 --> URI Class Initialized
DEBUG - 2022-01-06 15:31:16 --> No URI present. Default controller set.
INFO - 2022-01-06 15:31:16 --> Router Class Initialized
INFO - 2022-01-06 15:31:16 --> Output Class Initialized
INFO - 2022-01-06 15:31:16 --> Security Class Initialized
DEBUG - 2022-01-06 15:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 15:31:16 --> Input Class Initialized
INFO - 2022-01-06 15:31:16 --> Language Class Initialized
INFO - 2022-01-06 15:31:16 --> Loader Class Initialized
INFO - 2022-01-06 15:31:16 --> Helper loaded: url_helper
INFO - 2022-01-06 15:31:17 --> Helper loaded: form_helper
INFO - 2022-01-06 15:31:17 --> Helper loaded: common_helper
INFO - 2022-01-06 15:31:17 --> Database Driver Class Initialized
DEBUG - 2022-01-06 15:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 15:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 15:31:17 --> Controller Class Initialized
INFO - 2022-01-06 15:31:17 --> Form Validation Class Initialized
DEBUG - 2022-01-06 15:31:17 --> Encrypt Class Initialized
DEBUG - 2022-01-06 15:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:31:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 15:31:17 --> Email Class Initialized
INFO - 2022-01-06 15:31:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 15:31:17 --> Calendar Class Initialized
INFO - 2022-01-06 15:31:17 --> Model "Login_model" initialized
INFO - 2022-01-06 15:31:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-06 15:31:17 --> Final output sent to browser
DEBUG - 2022-01-06 15:31:17 --> Total execution time: 0.0355
ERROR - 2022-01-06 17:53:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 17:53:54 --> Config Class Initialized
INFO - 2022-01-06 17:53:54 --> Hooks Class Initialized
DEBUG - 2022-01-06 17:53:54 --> UTF-8 Support Enabled
INFO - 2022-01-06 17:53:54 --> Utf8 Class Initialized
INFO - 2022-01-06 17:53:54 --> URI Class Initialized
DEBUG - 2022-01-06 17:53:54 --> No URI present. Default controller set.
INFO - 2022-01-06 17:53:54 --> Router Class Initialized
INFO - 2022-01-06 17:53:54 --> Output Class Initialized
INFO - 2022-01-06 17:53:54 --> Security Class Initialized
DEBUG - 2022-01-06 17:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 17:53:54 --> Input Class Initialized
INFO - 2022-01-06 17:53:54 --> Language Class Initialized
INFO - 2022-01-06 17:53:54 --> Loader Class Initialized
INFO - 2022-01-06 17:53:54 --> Helper loaded: url_helper
INFO - 2022-01-06 17:53:54 --> Helper loaded: form_helper
INFO - 2022-01-06 17:53:54 --> Helper loaded: common_helper
INFO - 2022-01-06 17:53:54 --> Database Driver Class Initialized
DEBUG - 2022-01-06 17:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 17:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 17:53:54 --> Controller Class Initialized
INFO - 2022-01-06 17:53:54 --> Form Validation Class Initialized
DEBUG - 2022-01-06 17:53:54 --> Encrypt Class Initialized
DEBUG - 2022-01-06 17:53:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 17:53:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 17:53:54 --> Email Class Initialized
INFO - 2022-01-06 17:53:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 17:53:54 --> Calendar Class Initialized
INFO - 2022-01-06 17:53:54 --> Model "Login_model" initialized
INFO - 2022-01-06 17:53:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-06 17:53:54 --> Final output sent to browser
DEBUG - 2022-01-06 17:53:54 --> Total execution time: 0.0243
ERROR - 2022-01-06 19:16:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 19:16:53 --> Config Class Initialized
INFO - 2022-01-06 19:16:53 --> Hooks Class Initialized
DEBUG - 2022-01-06 19:16:53 --> UTF-8 Support Enabled
INFO - 2022-01-06 19:16:53 --> Utf8 Class Initialized
INFO - 2022-01-06 19:16:53 --> URI Class Initialized
DEBUG - 2022-01-06 19:16:53 --> No URI present. Default controller set.
INFO - 2022-01-06 19:16:53 --> Router Class Initialized
INFO - 2022-01-06 19:16:53 --> Output Class Initialized
INFO - 2022-01-06 19:16:53 --> Security Class Initialized
DEBUG - 2022-01-06 19:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 19:16:53 --> Input Class Initialized
INFO - 2022-01-06 19:16:53 --> Language Class Initialized
INFO - 2022-01-06 19:16:53 --> Loader Class Initialized
INFO - 2022-01-06 19:16:53 --> Helper loaded: url_helper
INFO - 2022-01-06 19:16:53 --> Helper loaded: form_helper
INFO - 2022-01-06 19:16:53 --> Helper loaded: common_helper
INFO - 2022-01-06 19:16:53 --> Database Driver Class Initialized
DEBUG - 2022-01-06 19:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 19:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 19:16:53 --> Controller Class Initialized
INFO - 2022-01-06 19:16:53 --> Form Validation Class Initialized
DEBUG - 2022-01-06 19:16:53 --> Encrypt Class Initialized
DEBUG - 2022-01-06 19:16:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 19:16:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 19:16:53 --> Email Class Initialized
INFO - 2022-01-06 19:16:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 19:16:53 --> Calendar Class Initialized
INFO - 2022-01-06 19:16:53 --> Model "Login_model" initialized
INFO - 2022-01-06 19:16:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-06 19:16:53 --> Final output sent to browser
DEBUG - 2022-01-06 19:16:53 --> Total execution time: 0.0263
ERROR - 2022-01-06 19:38:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 19:38:49 --> Config Class Initialized
INFO - 2022-01-06 19:38:49 --> Hooks Class Initialized
DEBUG - 2022-01-06 19:38:49 --> UTF-8 Support Enabled
INFO - 2022-01-06 19:38:49 --> Utf8 Class Initialized
INFO - 2022-01-06 19:38:49 --> URI Class Initialized
DEBUG - 2022-01-06 19:38:49 --> No URI present. Default controller set.
INFO - 2022-01-06 19:38:49 --> Router Class Initialized
INFO - 2022-01-06 19:38:49 --> Output Class Initialized
INFO - 2022-01-06 19:38:49 --> Security Class Initialized
DEBUG - 2022-01-06 19:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 19:38:49 --> Input Class Initialized
INFO - 2022-01-06 19:38:49 --> Language Class Initialized
INFO - 2022-01-06 19:38:49 --> Loader Class Initialized
INFO - 2022-01-06 19:38:49 --> Helper loaded: url_helper
INFO - 2022-01-06 19:38:49 --> Helper loaded: form_helper
INFO - 2022-01-06 19:38:49 --> Helper loaded: common_helper
INFO - 2022-01-06 19:38:49 --> Database Driver Class Initialized
DEBUG - 2022-01-06 19:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-06 19:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-06 19:38:49 --> Controller Class Initialized
INFO - 2022-01-06 19:38:49 --> Form Validation Class Initialized
DEBUG - 2022-01-06 19:38:49 --> Encrypt Class Initialized
DEBUG - 2022-01-06 19:38:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 19:38:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-06 19:38:49 --> Email Class Initialized
INFO - 2022-01-06 19:38:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-06 19:38:49 --> Calendar Class Initialized
INFO - 2022-01-06 19:38:49 --> Model "Login_model" initialized
INFO - 2022-01-06 19:38:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-06 19:38:49 --> Final output sent to browser
DEBUG - 2022-01-06 19:38:49 --> Total execution time: 0.0261
ERROR - 2022-01-06 22:56:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 22:56:24 --> Config Class Initialized
INFO - 2022-01-06 22:56:24 --> Hooks Class Initialized
DEBUG - 2022-01-06 22:56:24 --> UTF-8 Support Enabled
INFO - 2022-01-06 22:56:24 --> Utf8 Class Initialized
INFO - 2022-01-06 22:56:24 --> URI Class Initialized
INFO - 2022-01-06 22:56:24 --> Router Class Initialized
INFO - 2022-01-06 22:56:24 --> Output Class Initialized
INFO - 2022-01-06 22:56:24 --> Security Class Initialized
DEBUG - 2022-01-06 22:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 22:56:24 --> Input Class Initialized
INFO - 2022-01-06 22:56:24 --> Language Class Initialized
ERROR - 2022-01-06 22:56:24 --> 404 Page Not Found: Resources/js
ERROR - 2022-01-06 22:56:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-06 22:56:25 --> Config Class Initialized
INFO - 2022-01-06 22:56:25 --> Hooks Class Initialized
DEBUG - 2022-01-06 22:56:25 --> UTF-8 Support Enabled
INFO - 2022-01-06 22:56:25 --> Utf8 Class Initialized
INFO - 2022-01-06 22:56:25 --> URI Class Initialized
INFO - 2022-01-06 22:56:25 --> Router Class Initialized
INFO - 2022-01-06 22:56:25 --> Output Class Initialized
INFO - 2022-01-06 22:56:25 --> Security Class Initialized
DEBUG - 2022-01-06 22:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-06 22:56:25 --> Input Class Initialized
INFO - 2022-01-06 22:56:25 --> Language Class Initialized
ERROR - 2022-01-06 22:56:25 --> 404 Page Not Found: Resources/js
