<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-16 14:01:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-16 14:01:03 --> Config Class Initialized
INFO - 2021-10-16 14:01:03 --> Hooks Class Initialized
DEBUG - 2021-10-16 14:01:03 --> UTF-8 Support Enabled
INFO - 2021-10-16 14:01:03 --> Utf8 Class Initialized
INFO - 2021-10-16 14:01:03 --> URI Class Initialized
DEBUG - 2021-10-16 14:01:03 --> No URI present. Default controller set.
INFO - 2021-10-16 14:01:03 --> Router Class Initialized
INFO - 2021-10-16 14:01:03 --> Output Class Initialized
INFO - 2021-10-16 14:01:03 --> Security Class Initialized
DEBUG - 2021-10-16 14:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-16 14:01:03 --> Input Class Initialized
INFO - 2021-10-16 14:01:03 --> Language Class Initialized
INFO - 2021-10-16 14:01:03 --> Loader Class Initialized
INFO - 2021-10-16 14:01:03 --> Helper loaded: url_helper
INFO - 2021-10-16 14:01:03 --> Helper loaded: form_helper
INFO - 2021-10-16 14:01:03 --> Helper loaded: common_helper
INFO - 2021-10-16 14:01:03 --> Database Driver Class Initialized
DEBUG - 2021-10-16 14:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-16 14:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-16 14:01:03 --> Controller Class Initialized
INFO - 2021-10-16 14:01:03 --> Form Validation Class Initialized
DEBUG - 2021-10-16 14:01:03 --> Encrypt Class Initialized
DEBUG - 2021-10-16 14:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-16 14:01:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-16 14:01:03 --> Email Class Initialized
INFO - 2021-10-16 14:01:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-16 14:01:03 --> Calendar Class Initialized
INFO - 2021-10-16 14:01:03 --> Model "Login_model" initialized
INFO - 2021-10-16 14:01:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-16 14:01:03 --> Final output sent to browser
DEBUG - 2021-10-16 14:01:03 --> Total execution time: 0.0823
ERROR - 2021-10-16 14:01:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-16 14:01:03 --> Config Class Initialized
INFO - 2021-10-16 14:01:03 --> Hooks Class Initialized
DEBUG - 2021-10-16 14:01:03 --> UTF-8 Support Enabled
INFO - 2021-10-16 14:01:03 --> Utf8 Class Initialized
INFO - 2021-10-16 14:01:03 --> URI Class Initialized
DEBUG - 2021-10-16 14:01:03 --> No URI present. Default controller set.
INFO - 2021-10-16 14:01:03 --> Router Class Initialized
INFO - 2021-10-16 14:01:03 --> Output Class Initialized
INFO - 2021-10-16 14:01:03 --> Security Class Initialized
DEBUG - 2021-10-16 14:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-16 14:01:03 --> Input Class Initialized
INFO - 2021-10-16 14:01:03 --> Language Class Initialized
INFO - 2021-10-16 14:01:03 --> Loader Class Initialized
INFO - 2021-10-16 14:01:03 --> Helper loaded: url_helper
INFO - 2021-10-16 14:01:03 --> Helper loaded: form_helper
INFO - 2021-10-16 14:01:03 --> Helper loaded: common_helper
INFO - 2021-10-16 14:01:03 --> Database Driver Class Initialized
DEBUG - 2021-10-16 14:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-16 14:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-16 14:01:03 --> Controller Class Initialized
INFO - 2021-10-16 14:01:03 --> Form Validation Class Initialized
DEBUG - 2021-10-16 14:01:03 --> Encrypt Class Initialized
DEBUG - 2021-10-16 14:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-16 14:01:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-16 14:01:03 --> Email Class Initialized
INFO - 2021-10-16 14:01:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-16 14:01:03 --> Calendar Class Initialized
INFO - 2021-10-16 14:01:03 --> Model "Login_model" initialized
INFO - 2021-10-16 14:01:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-16 14:01:03 --> Final output sent to browser
DEBUG - 2021-10-16 14:01:03 --> Total execution time: 0.0311
ERROR - 2021-10-16 17:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-16 17:27:08 --> Config Class Initialized
INFO - 2021-10-16 17:27:08 --> Hooks Class Initialized
DEBUG - 2021-10-16 17:27:08 --> UTF-8 Support Enabled
INFO - 2021-10-16 17:27:08 --> Utf8 Class Initialized
INFO - 2021-10-16 17:27:08 --> URI Class Initialized
DEBUG - 2021-10-16 17:27:08 --> No URI present. Default controller set.
INFO - 2021-10-16 17:27:08 --> Router Class Initialized
INFO - 2021-10-16 17:27:08 --> Output Class Initialized
INFO - 2021-10-16 17:27:08 --> Security Class Initialized
DEBUG - 2021-10-16 17:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-16 17:27:08 --> Input Class Initialized
INFO - 2021-10-16 17:27:08 --> Language Class Initialized
INFO - 2021-10-16 17:27:08 --> Loader Class Initialized
INFO - 2021-10-16 17:27:08 --> Helper loaded: url_helper
INFO - 2021-10-16 17:27:08 --> Helper loaded: form_helper
INFO - 2021-10-16 17:27:08 --> Helper loaded: common_helper
INFO - 2021-10-16 17:27:08 --> Database Driver Class Initialized
DEBUG - 2021-10-16 17:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-16 17:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-16 17:27:08 --> Controller Class Initialized
INFO - 2021-10-16 17:27:08 --> Form Validation Class Initialized
DEBUG - 2021-10-16 17:27:08 --> Encrypt Class Initialized
DEBUG - 2021-10-16 17:27:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-16 17:27:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-16 17:27:08 --> Email Class Initialized
INFO - 2021-10-16 17:27:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-16 17:27:08 --> Calendar Class Initialized
INFO - 2021-10-16 17:27:08 --> Model "Login_model" initialized
INFO - 2021-10-16 17:27:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-16 17:27:08 --> Final output sent to browser
DEBUG - 2021-10-16 17:27:08 --> Total execution time: 0.0419
ERROR - 2021-10-16 17:27:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-16 17:27:09 --> Config Class Initialized
INFO - 2021-10-16 17:27:09 --> Hooks Class Initialized
DEBUG - 2021-10-16 17:27:09 --> UTF-8 Support Enabled
INFO - 2021-10-16 17:27:09 --> Utf8 Class Initialized
INFO - 2021-10-16 17:27:09 --> URI Class Initialized
DEBUG - 2021-10-16 17:27:09 --> No URI present. Default controller set.
INFO - 2021-10-16 17:27:09 --> Router Class Initialized
INFO - 2021-10-16 17:27:09 --> Output Class Initialized
INFO - 2021-10-16 17:27:09 --> Security Class Initialized
DEBUG - 2021-10-16 17:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-16 17:27:09 --> Input Class Initialized
INFO - 2021-10-16 17:27:09 --> Language Class Initialized
INFO - 2021-10-16 17:27:09 --> Loader Class Initialized
INFO - 2021-10-16 17:27:09 --> Helper loaded: url_helper
INFO - 2021-10-16 17:27:09 --> Helper loaded: form_helper
INFO - 2021-10-16 17:27:09 --> Helper loaded: common_helper
INFO - 2021-10-16 17:27:09 --> Database Driver Class Initialized
DEBUG - 2021-10-16 17:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-16 17:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-16 17:27:09 --> Controller Class Initialized
INFO - 2021-10-16 17:27:09 --> Form Validation Class Initialized
DEBUG - 2021-10-16 17:27:09 --> Encrypt Class Initialized
DEBUG - 2021-10-16 17:27:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-16 17:27:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-16 17:27:09 --> Email Class Initialized
INFO - 2021-10-16 17:27:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-16 17:27:09 --> Calendar Class Initialized
INFO - 2021-10-16 17:27:09 --> Model "Login_model" initialized
INFO - 2021-10-16 17:27:09 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-16 17:27:09 --> Final output sent to browser
DEBUG - 2021-10-16 17:27:09 --> Total execution time: 0.0199
