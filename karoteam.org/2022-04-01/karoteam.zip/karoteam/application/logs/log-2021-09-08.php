<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-08 12:53:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 12:53:15 --> Config Class Initialized
INFO - 2021-09-08 12:53:15 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:53:15 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:53:15 --> Utf8 Class Initialized
INFO - 2021-09-08 12:53:15 --> URI Class Initialized
DEBUG - 2021-09-08 12:53:15 --> No URI present. Default controller set.
INFO - 2021-09-08 12:53:15 --> Router Class Initialized
INFO - 2021-09-08 12:53:15 --> Output Class Initialized
INFO - 2021-09-08 12:53:15 --> Security Class Initialized
DEBUG - 2021-09-08 12:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:53:15 --> Input Class Initialized
INFO - 2021-09-08 12:53:15 --> Language Class Initialized
INFO - 2021-09-08 12:53:15 --> Loader Class Initialized
INFO - 2021-09-08 12:53:15 --> Helper loaded: url_helper
INFO - 2021-09-08 12:53:15 --> Helper loaded: form_helper
INFO - 2021-09-08 12:53:15 --> Helper loaded: common_helper
INFO - 2021-09-08 12:53:15 --> Database Driver Class Initialized
DEBUG - 2021-09-08 12:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-08 12:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-08 12:53:15 --> Controller Class Initialized
INFO - 2021-09-08 12:53:15 --> Form Validation Class Initialized
DEBUG - 2021-09-08 12:53:15 --> Encrypt Class Initialized
DEBUG - 2021-09-08 12:53:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-08 12:53:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-08 12:53:15 --> Email Class Initialized
INFO - 2021-09-08 12:53:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-08 12:53:15 --> Calendar Class Initialized
INFO - 2021-09-08 12:53:15 --> Model "Login_model" initialized
INFO - 2021-09-08 12:53:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-08 12:53:15 --> Final output sent to browser
DEBUG - 2021-09-08 12:53:15 --> Total execution time: 0.0489
ERROR - 2021-09-08 12:53:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 12:53:17 --> Config Class Initialized
INFO - 2021-09-08 12:53:17 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:53:17 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:53:17 --> Utf8 Class Initialized
INFO - 2021-09-08 12:53:17 --> URI Class Initialized
INFO - 2021-09-08 12:53:17 --> Router Class Initialized
INFO - 2021-09-08 12:53:17 --> Output Class Initialized
INFO - 2021-09-08 12:53:17 --> Security Class Initialized
DEBUG - 2021-09-08 12:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:53:17 --> Input Class Initialized
INFO - 2021-09-08 12:53:17 --> Language Class Initialized
ERROR - 2021-09-08 12:53:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-08 12:53:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 12:53:21 --> Config Class Initialized
INFO - 2021-09-08 12:53:21 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:53:21 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:53:21 --> Utf8 Class Initialized
INFO - 2021-09-08 12:53:21 --> URI Class Initialized
INFO - 2021-09-08 12:53:21 --> Router Class Initialized
INFO - 2021-09-08 12:53:21 --> Output Class Initialized
INFO - 2021-09-08 12:53:21 --> Security Class Initialized
DEBUG - 2021-09-08 12:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:53:21 --> Input Class Initialized
INFO - 2021-09-08 12:53:21 --> Language Class Initialized
INFO - 2021-09-08 12:53:21 --> Loader Class Initialized
INFO - 2021-09-08 12:53:21 --> Helper loaded: url_helper
INFO - 2021-09-08 12:53:21 --> Helper loaded: form_helper
INFO - 2021-09-08 12:53:21 --> Helper loaded: common_helper
INFO - 2021-09-08 12:53:21 --> Database Driver Class Initialized
DEBUG - 2021-09-08 12:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-08 12:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-08 12:53:21 --> Controller Class Initialized
INFO - 2021-09-08 12:53:21 --> Form Validation Class Initialized
DEBUG - 2021-09-08 12:53:21 --> Encrypt Class Initialized
DEBUG - 2021-09-08 12:53:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-08 12:53:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-08 12:53:21 --> Email Class Initialized
INFO - 2021-09-08 12:53:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-08 12:53:21 --> Calendar Class Initialized
INFO - 2021-09-08 12:53:21 --> Model "Login_model" initialized
INFO - 2021-09-08 12:53:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-09-08 12:53:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 12:53:21 --> Config Class Initialized
INFO - 2021-09-08 12:53:21 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:53:21 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:53:21 --> Utf8 Class Initialized
INFO - 2021-09-08 12:53:21 --> URI Class Initialized
INFO - 2021-09-08 12:53:21 --> Router Class Initialized
INFO - 2021-09-08 12:53:21 --> Output Class Initialized
INFO - 2021-09-08 12:53:21 --> Security Class Initialized
DEBUG - 2021-09-08 12:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:53:21 --> Input Class Initialized
INFO - 2021-09-08 12:53:21 --> Language Class Initialized
INFO - 2021-09-08 12:53:21 --> Loader Class Initialized
INFO - 2021-09-08 12:53:21 --> Helper loaded: url_helper
INFO - 2021-09-08 12:53:21 --> Helper loaded: form_helper
INFO - 2021-09-08 12:53:21 --> Helper loaded: common_helper
INFO - 2021-09-08 12:53:21 --> Database Driver Class Initialized
DEBUG - 2021-09-08 12:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-08 12:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-08 12:53:21 --> Controller Class Initialized
INFO - 2021-09-08 12:53:21 --> Form Validation Class Initialized
DEBUG - 2021-09-08 12:53:21 --> Encrypt Class Initialized
INFO - 2021-09-08 12:53:21 --> Model "Login_model" initialized
INFO - 2021-09-08 12:53:21 --> Model "Dashboard_model" initialized
INFO - 2021-09-08 12:53:21 --> Model "Case_model" initialized
INFO - 2021-09-08 12:53:24 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-09-08 12:53:31 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-09-08 12:53:31 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-09-08 12:53:31 --> Final output sent to browser
DEBUG - 2021-09-08 12:53:31 --> Total execution time: 9.6932
ERROR - 2021-09-08 12:53:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 12:53:32 --> Config Class Initialized
INFO - 2021-09-08 12:53:32 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:53:32 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:53:32 --> Utf8 Class Initialized
INFO - 2021-09-08 12:53:32 --> URI Class Initialized
INFO - 2021-09-08 12:53:32 --> Router Class Initialized
INFO - 2021-09-08 12:53:32 --> Output Class Initialized
INFO - 2021-09-08 12:53:32 --> Security Class Initialized
DEBUG - 2021-09-08 12:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:53:32 --> Input Class Initialized
INFO - 2021-09-08 12:53:32 --> Language Class Initialized
ERROR - 2021-09-08 12:53:32 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-09-08 12:56:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 12:56:26 --> Config Class Initialized
INFO - 2021-09-08 12:56:26 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:56:26 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:56:26 --> Utf8 Class Initialized
INFO - 2021-09-08 12:56:26 --> URI Class Initialized
INFO - 2021-09-08 12:56:26 --> Router Class Initialized
INFO - 2021-09-08 12:56:26 --> Output Class Initialized
INFO - 2021-09-08 12:56:26 --> Security Class Initialized
DEBUG - 2021-09-08 12:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:56:26 --> Input Class Initialized
INFO - 2021-09-08 12:56:26 --> Language Class Initialized
INFO - 2021-09-08 12:56:26 --> Loader Class Initialized
INFO - 2021-09-08 12:56:26 --> Helper loaded: url_helper
INFO - 2021-09-08 12:56:26 --> Helper loaded: form_helper
INFO - 2021-09-08 12:56:26 --> Helper loaded: common_helper
INFO - 2021-09-08 12:56:26 --> Database Driver Class Initialized
DEBUG - 2021-09-08 12:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-08 12:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-08 12:56:26 --> Controller Class Initialized
INFO - 2021-09-08 12:56:26 --> Form Validation Class Initialized
DEBUG - 2021-09-08 12:56:26 --> Encrypt Class Initialized
INFO - 2021-09-08 12:56:26 --> Model "Login_model" initialized
INFO - 2021-09-08 12:56:26 --> Model "Dashboard_model" initialized
INFO - 2021-09-08 12:56:26 --> Model "Case_model" initialized
INFO - 2021-09-08 12:56:29 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-09-08 12:56:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-09-08 12:56:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-09-08 12:56:37 --> Final output sent to browser
DEBUG - 2021-09-08 12:56:37 --> Total execution time: 10.1730
ERROR - 2021-09-08 12:56:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 12:56:39 --> Config Class Initialized
INFO - 2021-09-08 12:56:39 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:56:39 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:56:39 --> Utf8 Class Initialized
INFO - 2021-09-08 12:56:39 --> URI Class Initialized
INFO - 2021-09-08 12:56:39 --> Router Class Initialized
INFO - 2021-09-08 12:56:39 --> Output Class Initialized
INFO - 2021-09-08 12:56:39 --> Security Class Initialized
DEBUG - 2021-09-08 12:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:56:39 --> Input Class Initialized
INFO - 2021-09-08 12:56:39 --> Language Class Initialized
ERROR - 2021-09-08 12:56:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-09-08 13:02:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:02:23 --> Config Class Initialized
INFO - 2021-09-08 13:02:23 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:02:23 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:02:23 --> Utf8 Class Initialized
INFO - 2021-09-08 13:02:23 --> URI Class Initialized
INFO - 2021-09-08 13:02:23 --> Router Class Initialized
INFO - 2021-09-08 13:02:23 --> Output Class Initialized
INFO - 2021-09-08 13:02:23 --> Security Class Initialized
DEBUG - 2021-09-08 13:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:02:23 --> Input Class Initialized
INFO - 2021-09-08 13:02:23 --> Language Class Initialized
INFO - 2021-09-08 13:02:23 --> Loader Class Initialized
INFO - 2021-09-08 13:02:23 --> Helper loaded: url_helper
INFO - 2021-09-08 13:02:23 --> Helper loaded: form_helper
INFO - 2021-09-08 13:02:23 --> Helper loaded: common_helper
INFO - 2021-09-08 13:02:23 --> Database Driver Class Initialized
DEBUG - 2021-09-08 13:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-08 13:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-08 13:02:23 --> Controller Class Initialized
INFO - 2021-09-08 13:02:23 --> Form Validation Class Initialized
INFO - 2021-09-08 13:02:23 --> Model "Case_model" initialized
INFO - 2021-09-08 13:02:23 --> Model "Hospital_model" initialized
INFO - 2021-09-08 13:02:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-09-08 13:02:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-09-08 13:02:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-09-08 13:02:23 --> Final output sent to browser
DEBUG - 2021-09-08 13:02:23 --> Total execution time: 0.0230
ERROR - 2021-09-08 13:02:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:02:24 --> Config Class Initialized
INFO - 2021-09-08 13:02:24 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:02:24 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:02:24 --> Utf8 Class Initialized
INFO - 2021-09-08 13:02:24 --> URI Class Initialized
INFO - 2021-09-08 13:02:24 --> Router Class Initialized
INFO - 2021-09-08 13:02:24 --> Output Class Initialized
INFO - 2021-09-08 13:02:24 --> Security Class Initialized
DEBUG - 2021-09-08 13:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:02:24 --> Input Class Initialized
INFO - 2021-09-08 13:02:24 --> Language Class Initialized
ERROR - 2021-09-08 13:02:24 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-09-08 13:02:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:02:28 --> Config Class Initialized
INFO - 2021-09-08 13:02:28 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:02:28 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:02:28 --> Utf8 Class Initialized
INFO - 2021-09-08 13:02:28 --> URI Class Initialized
INFO - 2021-09-08 13:02:28 --> Router Class Initialized
INFO - 2021-09-08 13:02:28 --> Output Class Initialized
INFO - 2021-09-08 13:02:28 --> Security Class Initialized
DEBUG - 2021-09-08 13:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:02:28 --> Input Class Initialized
INFO - 2021-09-08 13:02:28 --> Language Class Initialized
INFO - 2021-09-08 13:02:28 --> Loader Class Initialized
INFO - 2021-09-08 13:02:28 --> Helper loaded: url_helper
INFO - 2021-09-08 13:02:28 --> Helper loaded: form_helper
INFO - 2021-09-08 13:02:28 --> Helper loaded: common_helper
INFO - 2021-09-08 13:02:28 --> Database Driver Class Initialized
DEBUG - 2021-09-08 13:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-08 13:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-08 13:02:28 --> Controller Class Initialized
INFO - 2021-09-08 13:02:28 --> Form Validation Class Initialized
DEBUG - 2021-09-08 13:02:28 --> Encrypt Class Initialized
INFO - 2021-09-08 13:02:28 --> Model "Login_model" initialized
INFO - 2021-09-08 13:02:28 --> Model "Dashboard_model" initialized
INFO - 2021-09-08 13:02:28 --> Model "Case_model" initialized
INFO - 2021-09-08 13:02:31 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-09-08 13:02:38 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-09-08 13:02:38 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-09-08 13:02:38 --> Final output sent to browser
DEBUG - 2021-09-08 13:02:38 --> Total execution time: 9.8103
ERROR - 2021-09-08 13:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:02:39 --> Config Class Initialized
INFO - 2021-09-08 13:02:39 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:02:39 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:02:39 --> Utf8 Class Initialized
INFO - 2021-09-08 13:02:39 --> URI Class Initialized
INFO - 2021-09-08 13:02:39 --> Router Class Initialized
INFO - 2021-09-08 13:02:39 --> Output Class Initialized
INFO - 2021-09-08 13:02:39 --> Security Class Initialized
DEBUG - 2021-09-08 13:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:02:39 --> Input Class Initialized
INFO - 2021-09-08 13:02:39 --> Language Class Initialized
ERROR - 2021-09-08 13:02:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-09-08 13:09:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:09:25 --> Config Class Initialized
INFO - 2021-09-08 13:09:25 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:09:25 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:09:25 --> Utf8 Class Initialized
INFO - 2021-09-08 13:09:25 --> URI Class Initialized
INFO - 2021-09-08 13:09:25 --> Router Class Initialized
INFO - 2021-09-08 13:09:25 --> Output Class Initialized
INFO - 2021-09-08 13:09:25 --> Security Class Initialized
DEBUG - 2021-09-08 13:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:09:25 --> Input Class Initialized
INFO - 2021-09-08 13:09:25 --> Language Class Initialized
INFO - 2021-09-08 13:09:25 --> Loader Class Initialized
INFO - 2021-09-08 13:09:25 --> Helper loaded: url_helper
INFO - 2021-09-08 13:09:25 --> Helper loaded: form_helper
INFO - 2021-09-08 13:09:25 --> Helper loaded: common_helper
INFO - 2021-09-08 13:09:25 --> Database Driver Class Initialized
DEBUG - 2021-09-08 13:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-08 13:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-08 13:09:25 --> Controller Class Initialized
INFO - 2021-09-08 13:09:25 --> Form Validation Class Initialized
DEBUG - 2021-09-08 13:09:25 --> Encrypt Class Initialized
INFO - 2021-09-08 13:09:25 --> Model "Login_model" initialized
INFO - 2021-09-08 13:09:25 --> Model "Dashboard_model" initialized
INFO - 2021-09-08 13:09:25 --> Model "Case_model" initialized
INFO - 2021-09-08 13:09:29 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-09-08 13:09:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-09-08 13:09:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-09-08 13:09:37 --> Final output sent to browser
DEBUG - 2021-09-08 13:09:37 --> Total execution time: 12.5351
ERROR - 2021-09-08 13:09:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:09:41 --> Config Class Initialized
INFO - 2021-09-08 13:09:41 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:09:41 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:09:41 --> Utf8 Class Initialized
INFO - 2021-09-08 13:09:41 --> URI Class Initialized
INFO - 2021-09-08 13:09:41 --> Router Class Initialized
INFO - 2021-09-08 13:09:41 --> Output Class Initialized
INFO - 2021-09-08 13:09:41 --> Security Class Initialized
DEBUG - 2021-09-08 13:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:09:41 --> Input Class Initialized
INFO - 2021-09-08 13:09:41 --> Language Class Initialized
ERROR - 2021-09-08 13:09:41 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-09-08 13:15:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:15:55 --> Config Class Initialized
INFO - 2021-09-08 13:15:55 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:15:55 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:15:55 --> Utf8 Class Initialized
INFO - 2021-09-08 13:15:55 --> URI Class Initialized
INFO - 2021-09-08 13:15:55 --> Router Class Initialized
INFO - 2021-09-08 13:15:55 --> Output Class Initialized
INFO - 2021-09-08 13:15:55 --> Security Class Initialized
DEBUG - 2021-09-08 13:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:15:55 --> Input Class Initialized
INFO - 2021-09-08 13:15:55 --> Language Class Initialized
ERROR - 2021-09-08 13:15:55 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-09-08 13:26:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:26:57 --> Config Class Initialized
INFO - 2021-09-08 13:26:57 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:26:57 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:26:57 --> Utf8 Class Initialized
INFO - 2021-09-08 13:26:57 --> URI Class Initialized
INFO - 2021-09-08 13:26:57 --> Router Class Initialized
INFO - 2021-09-08 13:26:57 --> Output Class Initialized
INFO - 2021-09-08 13:26:57 --> Security Class Initialized
DEBUG - 2021-09-08 13:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:26:57 --> Input Class Initialized
INFO - 2021-09-08 13:26:57 --> Language Class Initialized
INFO - 2021-09-08 13:26:57 --> Loader Class Initialized
INFO - 2021-09-08 13:26:57 --> Helper loaded: url_helper
INFO - 2021-09-08 13:26:57 --> Helper loaded: form_helper
INFO - 2021-09-08 13:26:57 --> Helper loaded: common_helper
INFO - 2021-09-08 13:26:57 --> Database Driver Class Initialized
DEBUG - 2021-09-08 13:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-08 13:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-08 13:26:57 --> Controller Class Initialized
INFO - 2021-09-08 13:26:57 --> Form Validation Class Initialized
DEBUG - 2021-09-08 13:26:57 --> Encrypt Class Initialized
INFO - 2021-09-08 13:26:57 --> Model "Login_model" initialized
INFO - 2021-09-08 13:26:57 --> Model "Dashboard_model" initialized
INFO - 2021-09-08 13:26:57 --> Model "Case_model" initialized
INFO - 2021-09-08 13:27:00 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-09-08 13:27:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-09-08 13:27:08 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-09-08 13:27:08 --> Final output sent to browser
DEBUG - 2021-09-08 13:27:08 --> Total execution time: 11.2704
ERROR - 2021-09-08 13:27:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:27:17 --> Config Class Initialized
INFO - 2021-09-08 13:27:17 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:27:17 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:27:17 --> Utf8 Class Initialized
INFO - 2021-09-08 13:27:17 --> URI Class Initialized
INFO - 2021-09-08 13:27:17 --> Router Class Initialized
INFO - 2021-09-08 13:27:17 --> Output Class Initialized
INFO - 2021-09-08 13:27:17 --> Security Class Initialized
DEBUG - 2021-09-08 13:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:27:17 --> Input Class Initialized
INFO - 2021-09-08 13:27:17 --> Language Class Initialized
ERROR - 2021-09-08 13:27:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-09-08 13:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:37:50 --> Config Class Initialized
INFO - 2021-09-08 13:37:50 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:37:50 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:37:50 --> Utf8 Class Initialized
INFO - 2021-09-08 13:37:50 --> URI Class Initialized
INFO - 2021-09-08 13:37:50 --> Router Class Initialized
INFO - 2021-09-08 13:37:50 --> Output Class Initialized
INFO - 2021-09-08 13:37:50 --> Security Class Initialized
DEBUG - 2021-09-08 13:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:37:50 --> Input Class Initialized
INFO - 2021-09-08 13:37:50 --> Language Class Initialized
INFO - 2021-09-08 13:37:50 --> Loader Class Initialized
INFO - 2021-09-08 13:37:50 --> Helper loaded: url_helper
INFO - 2021-09-08 13:37:50 --> Helper loaded: form_helper
INFO - 2021-09-08 13:37:50 --> Helper loaded: common_helper
INFO - 2021-09-08 13:37:50 --> Database Driver Class Initialized
DEBUG - 2021-09-08 13:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-08 13:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-08 13:37:50 --> Controller Class Initialized
INFO - 2021-09-08 13:37:50 --> Form Validation Class Initialized
DEBUG - 2021-09-08 13:37:50 --> Encrypt Class Initialized
INFO - 2021-09-08 13:37:50 --> Model "Login_model" initialized
INFO - 2021-09-08 13:37:50 --> Model "Dashboard_model" initialized
INFO - 2021-09-08 13:37:50 --> Model "Case_model" initialized
INFO - 2021-09-08 13:37:53 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-09-08 13:38:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-09-08 13:38:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-09-08 13:38:01 --> Final output sent to browser
DEBUG - 2021-09-08 13:38:01 --> Total execution time: 11.3167
ERROR - 2021-09-08 13:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-08 13:38:02 --> Config Class Initialized
INFO - 2021-09-08 13:38:02 --> Hooks Class Initialized
DEBUG - 2021-09-08 13:38:02 --> UTF-8 Support Enabled
INFO - 2021-09-08 13:38:02 --> Utf8 Class Initialized
INFO - 2021-09-08 13:38:02 --> URI Class Initialized
INFO - 2021-09-08 13:38:02 --> Router Class Initialized
INFO - 2021-09-08 13:38:02 --> Output Class Initialized
INFO - 2021-09-08 13:38:02 --> Security Class Initialized
DEBUG - 2021-09-08 13:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 13:38:02 --> Input Class Initialized
INFO - 2021-09-08 13:38:02 --> Language Class Initialized
ERROR - 2021-09-08 13:38:02 --> 404 Page Not Found: Karoclient/usersprofile
