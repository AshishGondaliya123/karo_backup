<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-15 08:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-15 08:50:13 --> Config Class Initialized
INFO - 2022-01-15 08:50:13 --> Hooks Class Initialized
DEBUG - 2022-01-15 08:50:13 --> UTF-8 Support Enabled
INFO - 2022-01-15 08:50:13 --> Utf8 Class Initialized
INFO - 2022-01-15 08:50:13 --> URI Class Initialized
DEBUG - 2022-01-15 08:50:13 --> No URI present. Default controller set.
INFO - 2022-01-15 08:50:13 --> Router Class Initialized
INFO - 2022-01-15 08:50:13 --> Output Class Initialized
INFO - 2022-01-15 08:50:13 --> Security Class Initialized
DEBUG - 2022-01-15 08:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-15 08:50:13 --> Input Class Initialized
INFO - 2022-01-15 08:50:13 --> Language Class Initialized
INFO - 2022-01-15 08:50:13 --> Loader Class Initialized
INFO - 2022-01-15 08:50:13 --> Helper loaded: url_helper
INFO - 2022-01-15 08:50:13 --> Helper loaded: form_helper
INFO - 2022-01-15 08:50:13 --> Helper loaded: common_helper
INFO - 2022-01-15 08:50:13 --> Database Driver Class Initialized
DEBUG - 2022-01-15 08:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-15 08:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-15 08:50:13 --> Controller Class Initialized
INFO - 2022-01-15 08:50:13 --> Form Validation Class Initialized
DEBUG - 2022-01-15 08:50:13 --> Encrypt Class Initialized
DEBUG - 2022-01-15 08:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-15 08:50:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-15 08:50:13 --> Email Class Initialized
INFO - 2022-01-15 08:50:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-15 08:50:13 --> Calendar Class Initialized
INFO - 2022-01-15 08:50:13 --> Model "Login_model" initialized
INFO - 2022-01-15 08:50:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-15 08:50:13 --> Final output sent to browser
DEBUG - 2022-01-15 08:50:13 --> Total execution time: 0.0235
ERROR - 2022-01-15 09:19:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-15 09:19:55 --> Config Class Initialized
INFO - 2022-01-15 09:19:55 --> Hooks Class Initialized
DEBUG - 2022-01-15 09:19:55 --> UTF-8 Support Enabled
INFO - 2022-01-15 09:19:55 --> Utf8 Class Initialized
INFO - 2022-01-15 09:19:55 --> URI Class Initialized
DEBUG - 2022-01-15 09:19:55 --> No URI present. Default controller set.
INFO - 2022-01-15 09:19:55 --> Router Class Initialized
INFO - 2022-01-15 09:19:55 --> Output Class Initialized
INFO - 2022-01-15 09:19:55 --> Security Class Initialized
DEBUG - 2022-01-15 09:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-15 09:19:55 --> Input Class Initialized
INFO - 2022-01-15 09:19:55 --> Language Class Initialized
INFO - 2022-01-15 09:19:55 --> Loader Class Initialized
INFO - 2022-01-15 09:19:55 --> Helper loaded: url_helper
INFO - 2022-01-15 09:19:55 --> Helper loaded: form_helper
INFO - 2022-01-15 09:19:55 --> Helper loaded: common_helper
INFO - 2022-01-15 09:19:55 --> Database Driver Class Initialized
DEBUG - 2022-01-15 09:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-15 09:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-15 09:19:55 --> Controller Class Initialized
INFO - 2022-01-15 09:19:55 --> Form Validation Class Initialized
DEBUG - 2022-01-15 09:19:55 --> Encrypt Class Initialized
DEBUG - 2022-01-15 09:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-15 09:19:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-15 09:19:55 --> Email Class Initialized
INFO - 2022-01-15 09:19:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-15 09:19:55 --> Calendar Class Initialized
INFO - 2022-01-15 09:19:55 --> Model "Login_model" initialized
INFO - 2022-01-15 09:19:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-15 09:19:55 --> Final output sent to browser
DEBUG - 2022-01-15 09:19:55 --> Total execution time: 0.0372
ERROR - 2022-01-15 14:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-15 14:17:32 --> Config Class Initialized
INFO - 2022-01-15 14:17:32 --> Hooks Class Initialized
DEBUG - 2022-01-15 14:17:32 --> UTF-8 Support Enabled
INFO - 2022-01-15 14:17:32 --> Utf8 Class Initialized
INFO - 2022-01-15 14:17:32 --> URI Class Initialized
DEBUG - 2022-01-15 14:17:32 --> No URI present. Default controller set.
INFO - 2022-01-15 14:17:32 --> Router Class Initialized
INFO - 2022-01-15 14:17:32 --> Output Class Initialized
INFO - 2022-01-15 14:17:32 --> Security Class Initialized
DEBUG - 2022-01-15 14:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-15 14:17:32 --> Input Class Initialized
INFO - 2022-01-15 14:17:32 --> Language Class Initialized
INFO - 2022-01-15 14:17:32 --> Loader Class Initialized
INFO - 2022-01-15 14:17:32 --> Helper loaded: url_helper
INFO - 2022-01-15 14:17:32 --> Helper loaded: form_helper
INFO - 2022-01-15 14:17:32 --> Helper loaded: common_helper
INFO - 2022-01-15 14:17:32 --> Database Driver Class Initialized
DEBUG - 2022-01-15 14:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-15 14:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-15 14:17:32 --> Controller Class Initialized
INFO - 2022-01-15 14:17:32 --> Form Validation Class Initialized
DEBUG - 2022-01-15 14:17:32 --> Encrypt Class Initialized
DEBUG - 2022-01-15 14:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-15 14:17:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-15 14:17:32 --> Email Class Initialized
INFO - 2022-01-15 14:17:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-15 14:17:32 --> Calendar Class Initialized
INFO - 2022-01-15 14:17:32 --> Model "Login_model" initialized
INFO - 2022-01-15 14:17:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-15 14:17:32 --> Final output sent to browser
DEBUG - 2022-01-15 14:17:32 --> Total execution time: 0.0489
ERROR - 2022-01-15 14:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-15 14:17:32 --> Config Class Initialized
INFO - 2022-01-15 14:17:32 --> Hooks Class Initialized
DEBUG - 2022-01-15 14:17:32 --> UTF-8 Support Enabled
INFO - 2022-01-15 14:17:32 --> Utf8 Class Initialized
INFO - 2022-01-15 14:17:32 --> URI Class Initialized
INFO - 2022-01-15 14:17:32 --> Router Class Initialized
INFO - 2022-01-15 14:17:32 --> Output Class Initialized
INFO - 2022-01-15 14:17:32 --> Security Class Initialized
DEBUG - 2022-01-15 14:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-15 14:17:32 --> Input Class Initialized
INFO - 2022-01-15 14:17:32 --> Language Class Initialized
ERROR - 2022-01-15 14:17:32 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-15 14:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-15 14:17:43 --> Config Class Initialized
INFO - 2022-01-15 14:17:43 --> Hooks Class Initialized
DEBUG - 2022-01-15 14:17:43 --> UTF-8 Support Enabled
INFO - 2022-01-15 14:17:43 --> Utf8 Class Initialized
INFO - 2022-01-15 14:17:43 --> URI Class Initialized
INFO - 2022-01-15 14:17:43 --> Router Class Initialized
INFO - 2022-01-15 14:17:43 --> Output Class Initialized
INFO - 2022-01-15 14:17:43 --> Security Class Initialized
DEBUG - 2022-01-15 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-15 14:17:43 --> Input Class Initialized
INFO - 2022-01-15 14:17:43 --> Language Class Initialized
INFO - 2022-01-15 14:17:43 --> Loader Class Initialized
INFO - 2022-01-15 14:17:43 --> Helper loaded: url_helper
INFO - 2022-01-15 14:17:43 --> Helper loaded: form_helper
INFO - 2022-01-15 14:17:43 --> Helper loaded: common_helper
INFO - 2022-01-15 14:17:43 --> Database Driver Class Initialized
DEBUG - 2022-01-15 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-15 14:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-15 14:17:43 --> Controller Class Initialized
INFO - 2022-01-15 14:17:43 --> Form Validation Class Initialized
DEBUG - 2022-01-15 14:17:43 --> Encrypt Class Initialized
DEBUG - 2022-01-15 14:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-15 14:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-15 14:17:43 --> Email Class Initialized
INFO - 2022-01-15 14:17:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-15 14:17:43 --> Calendar Class Initialized
INFO - 2022-01-15 14:17:43 --> Model "Login_model" initialized
ERROR - 2022-01-15 14:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-15 14:17:44 --> Config Class Initialized
INFO - 2022-01-15 14:17:44 --> Hooks Class Initialized
DEBUG - 2022-01-15 14:17:44 --> UTF-8 Support Enabled
INFO - 2022-01-15 14:17:44 --> Utf8 Class Initialized
INFO - 2022-01-15 14:17:44 --> URI Class Initialized
INFO - 2022-01-15 14:17:44 --> Router Class Initialized
INFO - 2022-01-15 14:17:44 --> Output Class Initialized
INFO - 2022-01-15 14:17:44 --> Security Class Initialized
DEBUG - 2022-01-15 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-15 14:17:44 --> Input Class Initialized
INFO - 2022-01-15 14:17:44 --> Language Class Initialized
INFO - 2022-01-15 14:17:44 --> Loader Class Initialized
INFO - 2022-01-15 14:17:44 --> Helper loaded: url_helper
INFO - 2022-01-15 14:17:44 --> Helper loaded: form_helper
INFO - 2022-01-15 14:17:44 --> Helper loaded: common_helper
INFO - 2022-01-15 14:17:44 --> Database Driver Class Initialized
DEBUG - 2022-01-15 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-15 14:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-15 14:17:44 --> Controller Class Initialized
INFO - 2022-01-15 14:17:44 --> Form Validation Class Initialized
DEBUG - 2022-01-15 14:17:44 --> Encrypt Class Initialized
DEBUG - 2022-01-15 14:17:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-15 14:17:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-15 14:17:44 --> Email Class Initialized
INFO - 2022-01-15 14:17:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-15 14:17:44 --> Calendar Class Initialized
INFO - 2022-01-15 14:17:44 --> Model "Login_model" initialized
ERROR - 2022-01-15 14:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-15 14:17:44 --> Config Class Initialized
INFO - 2022-01-15 14:17:44 --> Hooks Class Initialized
DEBUG - 2022-01-15 14:17:44 --> UTF-8 Support Enabled
INFO - 2022-01-15 14:17:44 --> Utf8 Class Initialized
INFO - 2022-01-15 14:17:44 --> URI Class Initialized
DEBUG - 2022-01-15 14:17:44 --> No URI present. Default controller set.
INFO - 2022-01-15 14:17:44 --> Router Class Initialized
INFO - 2022-01-15 14:17:44 --> Output Class Initialized
INFO - 2022-01-15 14:17:44 --> Security Class Initialized
DEBUG - 2022-01-15 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-15 14:17:44 --> Input Class Initialized
INFO - 2022-01-15 14:17:44 --> Language Class Initialized
INFO - 2022-01-15 14:17:44 --> Loader Class Initialized
INFO - 2022-01-15 14:17:44 --> Helper loaded: url_helper
INFO - 2022-01-15 14:17:44 --> Helper loaded: form_helper
INFO - 2022-01-15 14:17:44 --> Helper loaded: common_helper
INFO - 2022-01-15 14:17:44 --> Database Driver Class Initialized
DEBUG - 2022-01-15 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-15 14:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-15 14:17:44 --> Controller Class Initialized
INFO - 2022-01-15 14:17:44 --> Form Validation Class Initialized
DEBUG - 2022-01-15 14:17:44 --> Encrypt Class Initialized
DEBUG - 2022-01-15 14:17:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-15 14:17:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-15 14:17:44 --> Email Class Initialized
INFO - 2022-01-15 14:17:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-15 14:17:44 --> Calendar Class Initialized
INFO - 2022-01-15 14:17:44 --> Model "Login_model" initialized
INFO - 2022-01-15 14:17:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-15 14:17:44 --> Final output sent to browser
DEBUG - 2022-01-15 14:17:44 --> Total execution time: 0.0238
ERROR - 2022-01-15 14:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-15 14:17:45 --> Config Class Initialized
INFO - 2022-01-15 14:17:45 --> Hooks Class Initialized
DEBUG - 2022-01-15 14:17:45 --> UTF-8 Support Enabled
INFO - 2022-01-15 14:17:45 --> Utf8 Class Initialized
INFO - 2022-01-15 14:17:45 --> URI Class Initialized
INFO - 2022-01-15 14:17:45 --> Router Class Initialized
INFO - 2022-01-15 14:17:45 --> Output Class Initialized
INFO - 2022-01-15 14:17:45 --> Security Class Initialized
DEBUG - 2022-01-15 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-15 14:17:45 --> Input Class Initialized
INFO - 2022-01-15 14:17:45 --> Language Class Initialized
INFO - 2022-01-15 14:17:45 --> Loader Class Initialized
INFO - 2022-01-15 14:17:45 --> Helper loaded: url_helper
INFO - 2022-01-15 14:17:45 --> Helper loaded: form_helper
INFO - 2022-01-15 14:17:45 --> Helper loaded: common_helper
INFO - 2022-01-15 14:17:45 --> Database Driver Class Initialized
DEBUG - 2022-01-15 14:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-15 14:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-15 14:17:45 --> Controller Class Initialized
INFO - 2022-01-15 14:17:45 --> Form Validation Class Initialized
DEBUG - 2022-01-15 14:17:45 --> Encrypt Class Initialized
DEBUG - 2022-01-15 14:17:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-15 14:17:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-15 14:17:45 --> Email Class Initialized
INFO - 2022-01-15 14:17:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-15 14:17:45 --> Calendar Class Initialized
INFO - 2022-01-15 14:17:45 --> Model "Login_model" initialized
INFO - 2022-01-15 14:17:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-15 14:17:45 --> Final output sent to browser
DEBUG - 2022-01-15 14:17:45 --> Total execution time: 0.0271
