<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-07 19:24:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-07 19:24:27 --> Config Class Initialized
INFO - 2021-10-07 19:24:27 --> Hooks Class Initialized
DEBUG - 2021-10-07 19:24:27 --> UTF-8 Support Enabled
INFO - 2021-10-07 19:24:27 --> Utf8 Class Initialized
INFO - 2021-10-07 19:24:27 --> URI Class Initialized
DEBUG - 2021-10-07 19:24:27 --> No URI present. Default controller set.
INFO - 2021-10-07 19:24:27 --> Router Class Initialized
INFO - 2021-10-07 19:24:27 --> Output Class Initialized
INFO - 2021-10-07 19:24:27 --> Security Class Initialized
DEBUG - 2021-10-07 19:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 19:24:27 --> Input Class Initialized
INFO - 2021-10-07 19:24:27 --> Language Class Initialized
INFO - 2021-10-07 19:24:27 --> Loader Class Initialized
INFO - 2021-10-07 19:24:27 --> Helper loaded: url_helper
INFO - 2021-10-07 19:24:27 --> Helper loaded: form_helper
INFO - 2021-10-07 19:24:27 --> Helper loaded: common_helper
INFO - 2021-10-07 19:24:27 --> Database Driver Class Initialized
DEBUG - 2021-10-07 19:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-07 19:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-07 19:24:27 --> Controller Class Initialized
INFO - 2021-10-07 19:24:27 --> Form Validation Class Initialized
DEBUG - 2021-10-07 19:24:27 --> Encrypt Class Initialized
DEBUG - 2021-10-07 19:24:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-07 19:24:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-07 19:24:27 --> Email Class Initialized
INFO - 2021-10-07 19:24:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-07 19:24:27 --> Calendar Class Initialized
INFO - 2021-10-07 19:24:27 --> Model "Login_model" initialized
INFO - 2021-10-07 19:24:27 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-07 19:24:27 --> Final output sent to browser
DEBUG - 2021-10-07 19:24:27 --> Total execution time: 0.0675
ERROR - 2021-10-07 19:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-07 19:24:32 --> Config Class Initialized
INFO - 2021-10-07 19:24:32 --> Hooks Class Initialized
DEBUG - 2021-10-07 19:24:32 --> UTF-8 Support Enabled
INFO - 2021-10-07 19:24:32 --> Utf8 Class Initialized
INFO - 2021-10-07 19:24:32 --> URI Class Initialized
INFO - 2021-10-07 19:24:32 --> Router Class Initialized
INFO - 2021-10-07 19:24:32 --> Output Class Initialized
INFO - 2021-10-07 19:24:32 --> Security Class Initialized
DEBUG - 2021-10-07 19:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 19:24:32 --> Input Class Initialized
INFO - 2021-10-07 19:24:32 --> Language Class Initialized
ERROR - 2021-10-07 19:24:32 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-10-07 19:24:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-07 19:24:41 --> Config Class Initialized
INFO - 2021-10-07 19:24:41 --> Hooks Class Initialized
DEBUG - 2021-10-07 19:24:41 --> UTF-8 Support Enabled
INFO - 2021-10-07 19:24:41 --> Utf8 Class Initialized
INFO - 2021-10-07 19:24:41 --> URI Class Initialized
INFO - 2021-10-07 19:24:41 --> Router Class Initialized
INFO - 2021-10-07 19:24:41 --> Output Class Initialized
INFO - 2021-10-07 19:24:41 --> Security Class Initialized
DEBUG - 2021-10-07 19:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 19:24:41 --> Input Class Initialized
INFO - 2021-10-07 19:24:41 --> Language Class Initialized
ERROR - 2021-10-07 19:24:41 --> 404 Page Not Found: Wp/index
ERROR - 2021-10-07 19:24:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-07 19:24:50 --> Config Class Initialized
INFO - 2021-10-07 19:24:50 --> Hooks Class Initialized
DEBUG - 2021-10-07 19:24:50 --> UTF-8 Support Enabled
INFO - 2021-10-07 19:24:50 --> Utf8 Class Initialized
INFO - 2021-10-07 19:24:50 --> URI Class Initialized
INFO - 2021-10-07 19:24:50 --> Router Class Initialized
INFO - 2021-10-07 19:24:50 --> Output Class Initialized
INFO - 2021-10-07 19:24:50 --> Security Class Initialized
DEBUG - 2021-10-07 19:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 19:24:50 --> Input Class Initialized
INFO - 2021-10-07 19:24:50 --> Language Class Initialized
ERROR - 2021-10-07 19:24:50 --> 404 Page Not Found: Blog/index
ERROR - 2021-10-07 19:24:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-07 19:24:55 --> Config Class Initialized
INFO - 2021-10-07 19:24:55 --> Hooks Class Initialized
DEBUG - 2021-10-07 19:24:55 --> UTF-8 Support Enabled
INFO - 2021-10-07 19:24:55 --> Utf8 Class Initialized
INFO - 2021-10-07 19:24:55 --> URI Class Initialized
INFO - 2021-10-07 19:24:55 --> Router Class Initialized
INFO - 2021-10-07 19:24:55 --> Output Class Initialized
INFO - 2021-10-07 19:24:55 --> Security Class Initialized
DEBUG - 2021-10-07 19:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 19:24:55 --> Input Class Initialized
INFO - 2021-10-07 19:24:55 --> Language Class Initialized
ERROR - 2021-10-07 19:24:55 --> 404 Page Not Found: New/index
ERROR - 2021-10-07 19:25:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-07 19:25:02 --> Config Class Initialized
INFO - 2021-10-07 19:25:02 --> Hooks Class Initialized
DEBUG - 2021-10-07 19:25:02 --> UTF-8 Support Enabled
INFO - 2021-10-07 19:25:02 --> Utf8 Class Initialized
INFO - 2021-10-07 19:25:02 --> URI Class Initialized
INFO - 2021-10-07 19:25:02 --> Router Class Initialized
INFO - 2021-10-07 19:25:02 --> Output Class Initialized
INFO - 2021-10-07 19:25:02 --> Security Class Initialized
DEBUG - 2021-10-07 19:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 19:25:02 --> Input Class Initialized
INFO - 2021-10-07 19:25:02 --> Language Class Initialized
ERROR - 2021-10-07 19:25:02 --> 404 Page Not Found: Old/index
ERROR - 2021-10-07 19:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-07 19:25:09 --> Config Class Initialized
INFO - 2021-10-07 19:25:09 --> Hooks Class Initialized
DEBUG - 2021-10-07 19:25:09 --> UTF-8 Support Enabled
INFO - 2021-10-07 19:25:09 --> Utf8 Class Initialized
INFO - 2021-10-07 19:25:09 --> URI Class Initialized
INFO - 2021-10-07 19:25:09 --> Router Class Initialized
INFO - 2021-10-07 19:25:09 --> Output Class Initialized
INFO - 2021-10-07 19:25:09 --> Security Class Initialized
DEBUG - 2021-10-07 19:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 19:25:09 --> Input Class Initialized
INFO - 2021-10-07 19:25:09 --> Language Class Initialized
ERROR - 2021-10-07 19:25:09 --> 404 Page Not Found: Backup/index
ERROR - 2021-10-07 19:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-07 19:25:15 --> Config Class Initialized
INFO - 2021-10-07 19:25:15 --> Hooks Class Initialized
DEBUG - 2021-10-07 19:25:15 --> UTF-8 Support Enabled
INFO - 2021-10-07 19:25:15 --> Utf8 Class Initialized
INFO - 2021-10-07 19:25:15 --> URI Class Initialized
INFO - 2021-10-07 19:25:15 --> Router Class Initialized
INFO - 2021-10-07 19:25:15 --> Output Class Initialized
INFO - 2021-10-07 19:25:15 --> Security Class Initialized
DEBUG - 2021-10-07 19:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 19:25:15 --> Input Class Initialized
INFO - 2021-10-07 19:25:15 --> Language Class Initialized
ERROR - 2021-10-07 19:25:15 --> 404 Page Not Found: Oldsite/index
ERROR - 2021-10-07 19:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-07 19:25:22 --> Config Class Initialized
INFO - 2021-10-07 19:25:22 --> Hooks Class Initialized
DEBUG - 2021-10-07 19:25:22 --> UTF-8 Support Enabled
INFO - 2021-10-07 19:25:22 --> Utf8 Class Initialized
INFO - 2021-10-07 19:25:22 --> URI Class Initialized
INFO - 2021-10-07 19:25:22 --> Router Class Initialized
INFO - 2021-10-07 19:25:22 --> Output Class Initialized
INFO - 2021-10-07 19:25:22 --> Security Class Initialized
DEBUG - 2021-10-07 19:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 19:25:22 --> Input Class Initialized
INFO - 2021-10-07 19:25:22 --> Language Class Initialized
ERROR - 2021-10-07 19:25:22 --> 404 Page Not Found: Back/index
