<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-29 05:49:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-29 05:49:59 --> Config Class Initialized
INFO - 2021-05-29 05:49:59 --> Hooks Class Initialized
DEBUG - 2021-05-29 05:49:59 --> UTF-8 Support Enabled
INFO - 2021-05-29 05:49:59 --> Utf8 Class Initialized
INFO - 2021-05-29 05:49:59 --> URI Class Initialized
DEBUG - 2021-05-29 05:49:59 --> No URI present. Default controller set.
INFO - 2021-05-29 05:49:59 --> Router Class Initialized
INFO - 2021-05-29 05:49:59 --> Output Class Initialized
INFO - 2021-05-29 05:49:59 --> Security Class Initialized
DEBUG - 2021-05-29 05:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-29 05:49:59 --> Input Class Initialized
INFO - 2021-05-29 05:49:59 --> Language Class Initialized
INFO - 2021-05-29 05:49:59 --> Loader Class Initialized
INFO - 2021-05-29 05:49:59 --> Helper loaded: url_helper
INFO - 2021-05-29 05:49:59 --> Helper loaded: form_helper
INFO - 2021-05-29 05:49:59 --> Helper loaded: common_helper
INFO - 2021-05-29 05:49:59 --> Database Driver Class Initialized
DEBUG - 2021-05-29 05:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-29 05:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-29 05:49:59 --> Controller Class Initialized
INFO - 2021-05-29 05:49:59 --> Form Validation Class Initialized
DEBUG - 2021-05-29 05:49:59 --> Encrypt Class Initialized
DEBUG - 2021-05-29 05:49:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-29 05:49:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-29 05:49:59 --> Email Class Initialized
INFO - 2021-05-29 05:49:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-29 05:49:59 --> Calendar Class Initialized
INFO - 2021-05-29 05:49:59 --> Model "Login_model" initialized
INFO - 2021-05-29 05:49:59 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-29 05:49:59 --> Final output sent to browser
DEBUG - 2021-05-29 05:49:59 --> Total execution time: 0.0448
