<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-02 03:37:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-02 03:37:34 --> Config Class Initialized
INFO - 2021-10-02 03:37:34 --> Hooks Class Initialized
DEBUG - 2021-10-02 03:37:34 --> UTF-8 Support Enabled
INFO - 2021-10-02 03:37:34 --> Utf8 Class Initialized
INFO - 2021-10-02 03:37:34 --> URI Class Initialized
DEBUG - 2021-10-02 03:37:34 --> No URI present. Default controller set.
INFO - 2021-10-02 03:37:34 --> Router Class Initialized
INFO - 2021-10-02 03:37:34 --> Output Class Initialized
INFO - 2021-10-02 03:37:34 --> Security Class Initialized
DEBUG - 2021-10-02 03:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-02 03:37:34 --> Input Class Initialized
INFO - 2021-10-02 03:37:34 --> Language Class Initialized
INFO - 2021-10-02 03:37:34 --> Loader Class Initialized
INFO - 2021-10-02 03:37:34 --> Helper loaded: url_helper
INFO - 2021-10-02 03:37:34 --> Helper loaded: form_helper
INFO - 2021-10-02 03:37:34 --> Helper loaded: common_helper
INFO - 2021-10-02 03:37:34 --> Database Driver Class Initialized
DEBUG - 2021-10-02 03:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-02 03:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-02 03:37:34 --> Controller Class Initialized
INFO - 2021-10-02 03:37:34 --> Form Validation Class Initialized
DEBUG - 2021-10-02 03:37:34 --> Encrypt Class Initialized
DEBUG - 2021-10-02 03:37:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-02 03:37:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-02 03:37:34 --> Email Class Initialized
INFO - 2021-10-02 03:37:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-02 03:37:34 --> Calendar Class Initialized
INFO - 2021-10-02 03:37:34 --> Model "Login_model" initialized
INFO - 2021-10-02 03:37:34 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-02 03:37:34 --> Final output sent to browser
DEBUG - 2021-10-02 03:37:34 --> Total execution time: 0.0400
ERROR - 2021-10-02 03:37:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-02 03:37:35 --> Config Class Initialized
INFO - 2021-10-02 03:37:35 --> Hooks Class Initialized
DEBUG - 2021-10-02 03:37:35 --> UTF-8 Support Enabled
INFO - 2021-10-02 03:37:35 --> Utf8 Class Initialized
INFO - 2021-10-02 03:37:35 --> URI Class Initialized
INFO - 2021-10-02 03:37:35 --> Router Class Initialized
INFO - 2021-10-02 03:37:35 --> Output Class Initialized
INFO - 2021-10-02 03:37:35 --> Security Class Initialized
DEBUG - 2021-10-02 03:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-02 03:37:35 --> Input Class Initialized
INFO - 2021-10-02 03:37:35 --> Language Class Initialized
ERROR - 2021-10-02 03:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-02 03:37:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-02 03:37:55 --> Config Class Initialized
INFO - 2021-10-02 03:37:55 --> Hooks Class Initialized
DEBUG - 2021-10-02 03:37:55 --> UTF-8 Support Enabled
INFO - 2021-10-02 03:37:55 --> Utf8 Class Initialized
INFO - 2021-10-02 03:37:55 --> URI Class Initialized
INFO - 2021-10-02 03:37:55 --> Router Class Initialized
INFO - 2021-10-02 03:37:55 --> Output Class Initialized
INFO - 2021-10-02 03:37:55 --> Security Class Initialized
DEBUG - 2021-10-02 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-02 03:37:55 --> Input Class Initialized
INFO - 2021-10-02 03:37:55 --> Language Class Initialized
ERROR - 2021-10-02 03:37:55 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-10-02 05:35:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-02 05:35:58 --> Config Class Initialized
INFO - 2021-10-02 05:35:58 --> Hooks Class Initialized
DEBUG - 2021-10-02 05:35:58 --> UTF-8 Support Enabled
INFO - 2021-10-02 05:35:58 --> Utf8 Class Initialized
INFO - 2021-10-02 05:35:58 --> URI Class Initialized
INFO - 2021-10-02 05:35:58 --> Router Class Initialized
INFO - 2021-10-02 05:35:58 --> Output Class Initialized
INFO - 2021-10-02 05:35:58 --> Security Class Initialized
DEBUG - 2021-10-02 05:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-02 05:35:58 --> Input Class Initialized
INFO - 2021-10-02 05:35:58 --> Language Class Initialized
ERROR - 2021-10-02 05:35:58 --> 404 Page Not Found: Wp-admin/css
