<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-23 04:55:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 04:55:59 --> Config Class Initialized
INFO - 2021-12-23 04:55:59 --> Hooks Class Initialized
DEBUG - 2021-12-23 04:55:59 --> UTF-8 Support Enabled
INFO - 2021-12-23 04:55:59 --> Utf8 Class Initialized
INFO - 2021-12-23 04:55:59 --> URI Class Initialized
DEBUG - 2021-12-23 04:55:59 --> No URI present. Default controller set.
INFO - 2021-12-23 04:55:59 --> Router Class Initialized
INFO - 2021-12-23 04:55:59 --> Output Class Initialized
INFO - 2021-12-23 04:55:59 --> Security Class Initialized
DEBUG - 2021-12-23 04:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 04:55:59 --> Input Class Initialized
INFO - 2021-12-23 04:55:59 --> Language Class Initialized
INFO - 2021-12-23 04:55:59 --> Loader Class Initialized
INFO - 2021-12-23 04:55:59 --> Helper loaded: url_helper
INFO - 2021-12-23 04:55:59 --> Helper loaded: form_helper
INFO - 2021-12-23 04:55:59 --> Helper loaded: common_helper
INFO - 2021-12-23 04:55:59 --> Database Driver Class Initialized
DEBUG - 2021-12-23 04:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 04:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 04:55:59 --> Controller Class Initialized
INFO - 2021-12-23 04:55:59 --> Form Validation Class Initialized
DEBUG - 2021-12-23 04:55:59 --> Encrypt Class Initialized
DEBUG - 2021-12-23 04:55:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 04:55:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-23 04:55:59 --> Email Class Initialized
INFO - 2021-12-23 04:55:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-23 04:55:59 --> Calendar Class Initialized
INFO - 2021-12-23 04:55:59 --> Model "Login_model" initialized
INFO - 2021-12-23 04:55:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-23 04:55:59 --> Final output sent to browser
DEBUG - 2021-12-23 04:55:59 --> Total execution time: 0.4761
ERROR - 2021-12-23 07:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 07:52:40 --> Config Class Initialized
INFO - 2021-12-23 07:52:40 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:52:40 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:52:40 --> Utf8 Class Initialized
INFO - 2021-12-23 07:52:40 --> URI Class Initialized
DEBUG - 2021-12-23 07:52:40 --> No URI present. Default controller set.
INFO - 2021-12-23 07:52:40 --> Router Class Initialized
INFO - 2021-12-23 07:52:40 --> Output Class Initialized
INFO - 2021-12-23 07:52:40 --> Security Class Initialized
DEBUG - 2021-12-23 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:52:40 --> Input Class Initialized
INFO - 2021-12-23 07:52:40 --> Language Class Initialized
INFO - 2021-12-23 07:52:40 --> Loader Class Initialized
INFO - 2021-12-23 07:52:40 --> Helper loaded: url_helper
INFO - 2021-12-23 07:52:40 --> Helper loaded: form_helper
INFO - 2021-12-23 07:52:40 --> Helper loaded: common_helper
INFO - 2021-12-23 07:52:40 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:52:40 --> Controller Class Initialized
INFO - 2021-12-23 07:52:40 --> Form Validation Class Initialized
DEBUG - 2021-12-23 07:52:40 --> Encrypt Class Initialized
DEBUG - 2021-12-23 07:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 07:52:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-23 07:52:40 --> Email Class Initialized
INFO - 2021-12-23 07:52:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-23 07:52:40 --> Calendar Class Initialized
INFO - 2021-12-23 07:52:40 --> Model "Login_model" initialized
INFO - 2021-12-23 07:52:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-23 07:52:40 --> Final output sent to browser
DEBUG - 2021-12-23 07:52:40 --> Total execution time: 0.0240
ERROR - 2021-12-23 14:17:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 14:17:52 --> Config Class Initialized
INFO - 2021-12-23 14:17:52 --> Hooks Class Initialized
DEBUG - 2021-12-23 14:17:52 --> UTF-8 Support Enabled
INFO - 2021-12-23 14:17:52 --> Utf8 Class Initialized
INFO - 2021-12-23 14:17:52 --> URI Class Initialized
DEBUG - 2021-12-23 14:17:52 --> No URI present. Default controller set.
INFO - 2021-12-23 14:17:52 --> Router Class Initialized
INFO - 2021-12-23 14:17:52 --> Output Class Initialized
INFO - 2021-12-23 14:17:52 --> Security Class Initialized
DEBUG - 2021-12-23 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 14:17:52 --> Input Class Initialized
INFO - 2021-12-23 14:17:52 --> Language Class Initialized
INFO - 2021-12-23 14:17:52 --> Loader Class Initialized
INFO - 2021-12-23 14:17:52 --> Helper loaded: url_helper
INFO - 2021-12-23 14:17:52 --> Helper loaded: form_helper
INFO - 2021-12-23 14:17:52 --> Helper loaded: common_helper
INFO - 2021-12-23 14:17:52 --> Database Driver Class Initialized
DEBUG - 2021-12-23 14:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 14:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 14:17:52 --> Controller Class Initialized
INFO - 2021-12-23 14:17:52 --> Form Validation Class Initialized
DEBUG - 2021-12-23 14:17:52 --> Encrypt Class Initialized
DEBUG - 2021-12-23 14:17:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-23 14:17:52 --> Email Class Initialized
INFO - 2021-12-23 14:17:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-23 14:17:52 --> Calendar Class Initialized
INFO - 2021-12-23 14:17:52 --> Model "Login_model" initialized
INFO - 2021-12-23 14:17:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-23 14:17:52 --> Final output sent to browser
DEBUG - 2021-12-23 14:17:52 --> Total execution time: 0.0270
ERROR - 2021-12-23 14:17:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 14:17:53 --> Config Class Initialized
INFO - 2021-12-23 14:17:53 --> Hooks Class Initialized
DEBUG - 2021-12-23 14:17:53 --> UTF-8 Support Enabled
INFO - 2021-12-23 14:17:53 --> Utf8 Class Initialized
INFO - 2021-12-23 14:17:53 --> URI Class Initialized
INFO - 2021-12-23 14:17:53 --> Router Class Initialized
INFO - 2021-12-23 14:17:53 --> Output Class Initialized
INFO - 2021-12-23 14:17:53 --> Security Class Initialized
DEBUG - 2021-12-23 14:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 14:17:53 --> Input Class Initialized
INFO - 2021-12-23 14:17:53 --> Language Class Initialized
ERROR - 2021-12-23 14:17:53 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-23 14:18:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 14:18:04 --> Config Class Initialized
INFO - 2021-12-23 14:18:04 --> Hooks Class Initialized
DEBUG - 2021-12-23 14:18:04 --> UTF-8 Support Enabled
INFO - 2021-12-23 14:18:04 --> Utf8 Class Initialized
INFO - 2021-12-23 14:18:04 --> URI Class Initialized
INFO - 2021-12-23 14:18:04 --> Router Class Initialized
INFO - 2021-12-23 14:18:04 --> Output Class Initialized
INFO - 2021-12-23 14:18:04 --> Security Class Initialized
DEBUG - 2021-12-23 14:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 14:18:04 --> Input Class Initialized
INFO - 2021-12-23 14:18:04 --> Language Class Initialized
INFO - 2021-12-23 14:18:04 --> Loader Class Initialized
INFO - 2021-12-23 14:18:04 --> Helper loaded: url_helper
INFO - 2021-12-23 14:18:04 --> Helper loaded: form_helper
INFO - 2021-12-23 14:18:04 --> Helper loaded: common_helper
INFO - 2021-12-23 14:18:04 --> Database Driver Class Initialized
DEBUG - 2021-12-23 14:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 14:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 14:18:04 --> Controller Class Initialized
INFO - 2021-12-23 14:18:04 --> Form Validation Class Initialized
DEBUG - 2021-12-23 14:18:04 --> Encrypt Class Initialized
DEBUG - 2021-12-23 14:18:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:18:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-23 14:18:04 --> Email Class Initialized
INFO - 2021-12-23 14:18:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-23 14:18:04 --> Calendar Class Initialized
INFO - 2021-12-23 14:18:04 --> Model "Login_model" initialized
INFO - 2021-12-23 14:18:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-23 14:18:04 --> Final output sent to browser
DEBUG - 2021-12-23 14:18:04 --> Total execution time: 0.0226
ERROR - 2021-12-23 14:18:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 14:18:04 --> Config Class Initialized
INFO - 2021-12-23 14:18:04 --> Hooks Class Initialized
DEBUG - 2021-12-23 14:18:04 --> UTF-8 Support Enabled
INFO - 2021-12-23 14:18:04 --> Utf8 Class Initialized
INFO - 2021-12-23 14:18:04 --> URI Class Initialized
DEBUG - 2021-12-23 14:18:04 --> No URI present. Default controller set.
INFO - 2021-12-23 14:18:04 --> Router Class Initialized
INFO - 2021-12-23 14:18:04 --> Output Class Initialized
INFO - 2021-12-23 14:18:04 --> Security Class Initialized
DEBUG - 2021-12-23 14:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 14:18:04 --> Input Class Initialized
INFO - 2021-12-23 14:18:04 --> Language Class Initialized
INFO - 2021-12-23 14:18:04 --> Loader Class Initialized
INFO - 2021-12-23 14:18:04 --> Helper loaded: url_helper
INFO - 2021-12-23 14:18:04 --> Helper loaded: form_helper
INFO - 2021-12-23 14:18:04 --> Helper loaded: common_helper
INFO - 2021-12-23 14:18:04 --> Database Driver Class Initialized
DEBUG - 2021-12-23 14:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 14:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 14:18:04 --> Controller Class Initialized
INFO - 2021-12-23 14:18:04 --> Form Validation Class Initialized
DEBUG - 2021-12-23 14:18:04 --> Encrypt Class Initialized
DEBUG - 2021-12-23 14:18:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:18:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-23 14:18:04 --> Email Class Initialized
INFO - 2021-12-23 14:18:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-23 14:18:04 --> Calendar Class Initialized
INFO - 2021-12-23 14:18:04 --> Model "Login_model" initialized
INFO - 2021-12-23 14:18:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-23 14:18:04 --> Final output sent to browser
DEBUG - 2021-12-23 14:18:04 --> Total execution time: 0.0240
ERROR - 2021-12-23 14:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 14:18:05 --> Config Class Initialized
INFO - 2021-12-23 14:18:05 --> Hooks Class Initialized
DEBUG - 2021-12-23 14:18:05 --> UTF-8 Support Enabled
INFO - 2021-12-23 14:18:05 --> Utf8 Class Initialized
INFO - 2021-12-23 14:18:05 --> URI Class Initialized
INFO - 2021-12-23 14:18:05 --> Router Class Initialized
INFO - 2021-12-23 14:18:05 --> Output Class Initialized
INFO - 2021-12-23 14:18:05 --> Security Class Initialized
DEBUG - 2021-12-23 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 14:18:05 --> Input Class Initialized
INFO - 2021-12-23 14:18:05 --> Language Class Initialized
INFO - 2021-12-23 14:18:05 --> Loader Class Initialized
INFO - 2021-12-23 14:18:05 --> Helper loaded: url_helper
INFO - 2021-12-23 14:18:05 --> Helper loaded: form_helper
INFO - 2021-12-23 14:18:05 --> Helper loaded: common_helper
INFO - 2021-12-23 14:18:05 --> Database Driver Class Initialized
DEBUG - 2021-12-23 14:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 14:18:05 --> Controller Class Initialized
INFO - 2021-12-23 14:18:05 --> Form Validation Class Initialized
DEBUG - 2021-12-23 14:18:05 --> Encrypt Class Initialized
DEBUG - 2021-12-23 14:18:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:18:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-23 14:18:05 --> Email Class Initialized
INFO - 2021-12-23 14:18:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-23 14:18:05 --> Calendar Class Initialized
INFO - 2021-12-23 14:18:05 --> Model "Login_model" initialized
ERROR - 2021-12-23 14:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 14:18:05 --> Config Class Initialized
INFO - 2021-12-23 14:18:05 --> Hooks Class Initialized
DEBUG - 2021-12-23 14:18:05 --> UTF-8 Support Enabled
INFO - 2021-12-23 14:18:05 --> Utf8 Class Initialized
INFO - 2021-12-23 14:18:05 --> URI Class Initialized
INFO - 2021-12-23 14:18:05 --> Router Class Initialized
INFO - 2021-12-23 14:18:05 --> Output Class Initialized
INFO - 2021-12-23 14:18:05 --> Security Class Initialized
DEBUG - 2021-12-23 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 14:18:05 --> Input Class Initialized
INFO - 2021-12-23 14:18:05 --> Language Class Initialized
INFO - 2021-12-23 14:18:05 --> Loader Class Initialized
INFO - 2021-12-23 14:18:05 --> Helper loaded: url_helper
INFO - 2021-12-23 14:18:05 --> Helper loaded: form_helper
INFO - 2021-12-23 14:18:05 --> Helper loaded: common_helper
INFO - 2021-12-23 14:18:05 --> Database Driver Class Initialized
DEBUG - 2021-12-23 14:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 14:18:05 --> Controller Class Initialized
INFO - 2021-12-23 14:18:05 --> Form Validation Class Initialized
DEBUG - 2021-12-23 14:18:05 --> Encrypt Class Initialized
DEBUG - 2021-12-23 14:18:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:18:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-23 14:18:05 --> Email Class Initialized
INFO - 2021-12-23 14:18:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-23 14:18:05 --> Calendar Class Initialized
INFO - 2021-12-23 14:18:05 --> Model "Login_model" initialized
ERROR - 2021-12-23 15:09:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 15:09:28 --> Config Class Initialized
INFO - 2021-12-23 15:09:28 --> Hooks Class Initialized
DEBUG - 2021-12-23 15:09:28 --> UTF-8 Support Enabled
INFO - 2021-12-23 15:09:28 --> Utf8 Class Initialized
INFO - 2021-12-23 15:09:28 --> URI Class Initialized
INFO - 2021-12-23 15:09:28 --> Router Class Initialized
INFO - 2021-12-23 15:09:28 --> Output Class Initialized
INFO - 2021-12-23 15:09:28 --> Security Class Initialized
DEBUG - 2021-12-23 15:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 15:09:28 --> Input Class Initialized
INFO - 2021-12-23 15:09:28 --> Language Class Initialized
ERROR - 2021-12-23 15:09:28 --> 404 Page Not Found: Wp-loadphp/index
ERROR - 2021-12-23 15:40:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-23 15:40:12 --> Config Class Initialized
INFO - 2021-12-23 15:40:12 --> Hooks Class Initialized
DEBUG - 2021-12-23 15:40:12 --> UTF-8 Support Enabled
INFO - 2021-12-23 15:40:12 --> Utf8 Class Initialized
INFO - 2021-12-23 15:40:12 --> URI Class Initialized
DEBUG - 2021-12-23 15:40:12 --> No URI present. Default controller set.
INFO - 2021-12-23 15:40:12 --> Router Class Initialized
INFO - 2021-12-23 15:40:12 --> Output Class Initialized
INFO - 2021-12-23 15:40:12 --> Security Class Initialized
DEBUG - 2021-12-23 15:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 15:40:12 --> Input Class Initialized
INFO - 2021-12-23 15:40:12 --> Language Class Initialized
INFO - 2021-12-23 15:40:12 --> Loader Class Initialized
INFO - 2021-12-23 15:40:12 --> Helper loaded: url_helper
INFO - 2021-12-23 15:40:12 --> Helper loaded: form_helper
INFO - 2021-12-23 15:40:12 --> Helper loaded: common_helper
INFO - 2021-12-23 15:40:12 --> Database Driver Class Initialized
DEBUG - 2021-12-23 15:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 15:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 15:40:12 --> Controller Class Initialized
INFO - 2021-12-23 15:40:12 --> Form Validation Class Initialized
DEBUG - 2021-12-23 15:40:12 --> Encrypt Class Initialized
DEBUG - 2021-12-23 15:40:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 15:40:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-23 15:40:12 --> Email Class Initialized
INFO - 2021-12-23 15:40:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-23 15:40:12 --> Calendar Class Initialized
INFO - 2021-12-23 15:40:12 --> Model "Login_model" initialized
INFO - 2021-12-23 15:40:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-23 15:40:12 --> Final output sent to browser
DEBUG - 2021-12-23 15:40:12 --> Total execution time: 0.0236
