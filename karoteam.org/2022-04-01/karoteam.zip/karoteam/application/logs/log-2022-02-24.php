<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-24 00:18:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 00:18:56 --> Config Class Initialized
INFO - 2022-02-24 00:18:56 --> Hooks Class Initialized
DEBUG - 2022-02-24 00:18:56 --> UTF-8 Support Enabled
INFO - 2022-02-24 00:18:56 --> Utf8 Class Initialized
INFO - 2022-02-24 00:18:56 --> URI Class Initialized
DEBUG - 2022-02-24 00:18:56 --> No URI present. Default controller set.
INFO - 2022-02-24 00:18:56 --> Router Class Initialized
INFO - 2022-02-24 00:18:56 --> Output Class Initialized
INFO - 2022-02-24 00:18:56 --> Security Class Initialized
DEBUG - 2022-02-24 00:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 00:18:56 --> Input Class Initialized
INFO - 2022-02-24 00:18:56 --> Language Class Initialized
INFO - 2022-02-24 00:18:56 --> Loader Class Initialized
INFO - 2022-02-24 00:18:56 --> Helper loaded: url_helper
INFO - 2022-02-24 00:18:56 --> Helper loaded: form_helper
INFO - 2022-02-24 00:18:56 --> Helper loaded: common_helper
INFO - 2022-02-24 00:18:56 --> Database Driver Class Initialized
DEBUG - 2022-02-24 00:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 00:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 00:18:56 --> Controller Class Initialized
INFO - 2022-02-24 00:18:56 --> Form Validation Class Initialized
DEBUG - 2022-02-24 00:18:56 --> Encrypt Class Initialized
DEBUG - 2022-02-24 00:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 00:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 00:18:56 --> Email Class Initialized
INFO - 2022-02-24 00:18:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 00:18:56 --> Calendar Class Initialized
INFO - 2022-02-24 00:18:56 --> Model "Login_model" initialized
INFO - 2022-02-24 00:18:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 00:18:56 --> Final output sent to browser
DEBUG - 2022-02-24 00:18:56 --> Total execution time: 0.0525
ERROR - 2022-02-24 00:19:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 00:19:21 --> Config Class Initialized
INFO - 2022-02-24 00:19:21 --> Hooks Class Initialized
DEBUG - 2022-02-24 00:19:21 --> UTF-8 Support Enabled
INFO - 2022-02-24 00:19:21 --> Utf8 Class Initialized
INFO - 2022-02-24 00:19:21 --> URI Class Initialized
DEBUG - 2022-02-24 00:19:21 --> No URI present. Default controller set.
INFO - 2022-02-24 00:19:21 --> Router Class Initialized
INFO - 2022-02-24 00:19:21 --> Output Class Initialized
INFO - 2022-02-24 00:19:21 --> Security Class Initialized
DEBUG - 2022-02-24 00:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 00:19:21 --> Input Class Initialized
INFO - 2022-02-24 00:19:21 --> Language Class Initialized
INFO - 2022-02-24 00:19:21 --> Loader Class Initialized
INFO - 2022-02-24 00:19:21 --> Helper loaded: url_helper
INFO - 2022-02-24 00:19:21 --> Helper loaded: form_helper
INFO - 2022-02-24 00:19:21 --> Helper loaded: common_helper
INFO - 2022-02-24 00:19:21 --> Database Driver Class Initialized
DEBUG - 2022-02-24 00:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 00:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 00:19:21 --> Controller Class Initialized
INFO - 2022-02-24 00:19:21 --> Form Validation Class Initialized
DEBUG - 2022-02-24 00:19:21 --> Encrypt Class Initialized
DEBUG - 2022-02-24 00:19:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 00:19:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 00:19:21 --> Email Class Initialized
INFO - 2022-02-24 00:19:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 00:19:21 --> Calendar Class Initialized
INFO - 2022-02-24 00:19:21 --> Model "Login_model" initialized
INFO - 2022-02-24 00:19:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 00:19:21 --> Final output sent to browser
DEBUG - 2022-02-24 00:19:21 --> Total execution time: 0.0383
ERROR - 2022-02-24 01:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 01:52:55 --> Config Class Initialized
INFO - 2022-02-24 01:52:55 --> Hooks Class Initialized
DEBUG - 2022-02-24 01:52:55 --> UTF-8 Support Enabled
INFO - 2022-02-24 01:52:55 --> Utf8 Class Initialized
INFO - 2022-02-24 01:52:55 --> URI Class Initialized
DEBUG - 2022-02-24 01:52:55 --> No URI present. Default controller set.
INFO - 2022-02-24 01:52:55 --> Router Class Initialized
INFO - 2022-02-24 01:52:55 --> Output Class Initialized
INFO - 2022-02-24 01:52:55 --> Security Class Initialized
DEBUG - 2022-02-24 01:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 01:52:55 --> Input Class Initialized
INFO - 2022-02-24 01:52:55 --> Language Class Initialized
INFO - 2022-02-24 01:52:55 --> Loader Class Initialized
INFO - 2022-02-24 01:52:55 --> Helper loaded: url_helper
INFO - 2022-02-24 01:52:55 --> Helper loaded: form_helper
INFO - 2022-02-24 01:52:55 --> Helper loaded: common_helper
INFO - 2022-02-24 01:52:55 --> Database Driver Class Initialized
DEBUG - 2022-02-24 01:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 01:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 01:52:55 --> Controller Class Initialized
INFO - 2022-02-24 01:52:55 --> Form Validation Class Initialized
DEBUG - 2022-02-24 01:52:55 --> Encrypt Class Initialized
DEBUG - 2022-02-24 01:52:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 01:52:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 01:52:55 --> Email Class Initialized
INFO - 2022-02-24 01:52:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 01:52:55 --> Calendar Class Initialized
INFO - 2022-02-24 01:52:55 --> Model "Login_model" initialized
INFO - 2022-02-24 01:52:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 01:52:55 --> Final output sent to browser
DEBUG - 2022-02-24 01:52:55 --> Total execution time: 0.0347
ERROR - 2022-02-24 04:58:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:50 --> Config Class Initialized
INFO - 2022-02-24 04:58:50 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:50 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:50 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:50 --> URI Class Initialized
DEBUG - 2022-02-24 04:58:50 --> No URI present. Default controller set.
INFO - 2022-02-24 04:58:50 --> Router Class Initialized
INFO - 2022-02-24 04:58:50 --> Output Class Initialized
INFO - 2022-02-24 04:58:50 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:50 --> Input Class Initialized
INFO - 2022-02-24 04:58:50 --> Language Class Initialized
INFO - 2022-02-24 04:58:50 --> Loader Class Initialized
INFO - 2022-02-24 04:58:50 --> Helper loaded: url_helper
INFO - 2022-02-24 04:58:50 --> Helper loaded: form_helper
INFO - 2022-02-24 04:58:50 --> Helper loaded: common_helper
INFO - 2022-02-24 04:58:50 --> Database Driver Class Initialized
DEBUG - 2022-02-24 04:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 04:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 04:58:50 --> Controller Class Initialized
INFO - 2022-02-24 04:58:50 --> Form Validation Class Initialized
DEBUG - 2022-02-24 04:58:50 --> Encrypt Class Initialized
DEBUG - 2022-02-24 04:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 04:58:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 04:58:50 --> Email Class Initialized
INFO - 2022-02-24 04:58:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 04:58:50 --> Calendar Class Initialized
INFO - 2022-02-24 04:58:50 --> Model "Login_model" initialized
INFO - 2022-02-24 04:58:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 04:58:50 --> Final output sent to browser
DEBUG - 2022-02-24 04:58:50 --> Total execution time: 0.0439
ERROR - 2022-02-24 04:58:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:51 --> Config Class Initialized
INFO - 2022-02-24 04:58:51 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:51 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:51 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:51 --> URI Class Initialized
DEBUG - 2022-02-24 04:58:51 --> No URI present. Default controller set.
INFO - 2022-02-24 04:58:51 --> Router Class Initialized
INFO - 2022-02-24 04:58:51 --> Output Class Initialized
INFO - 2022-02-24 04:58:51 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:51 --> Input Class Initialized
INFO - 2022-02-24 04:58:51 --> Language Class Initialized
INFO - 2022-02-24 04:58:51 --> Loader Class Initialized
INFO - 2022-02-24 04:58:51 --> Helper loaded: url_helper
INFO - 2022-02-24 04:58:51 --> Helper loaded: form_helper
INFO - 2022-02-24 04:58:51 --> Helper loaded: common_helper
INFO - 2022-02-24 04:58:51 --> Database Driver Class Initialized
DEBUG - 2022-02-24 04:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 04:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 04:58:51 --> Controller Class Initialized
INFO - 2022-02-24 04:58:51 --> Form Validation Class Initialized
DEBUG - 2022-02-24 04:58:51 --> Encrypt Class Initialized
DEBUG - 2022-02-24 04:58:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 04:58:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 04:58:51 --> Email Class Initialized
INFO - 2022-02-24 04:58:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 04:58:51 --> Calendar Class Initialized
INFO - 2022-02-24 04:58:51 --> Model "Login_model" initialized
INFO - 2022-02-24 04:58:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 04:58:51 --> Final output sent to browser
DEBUG - 2022-02-24 04:58:51 --> Total execution time: 0.0242
ERROR - 2022-02-24 04:58:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:51 --> Config Class Initialized
INFO - 2022-02-24 04:58:51 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:51 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:51 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:51 --> URI Class Initialized
INFO - 2022-02-24 04:58:51 --> Router Class Initialized
INFO - 2022-02-24 04:58:51 --> Output Class Initialized
INFO - 2022-02-24 04:58:51 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:51 --> Input Class Initialized
INFO - 2022-02-24 04:58:51 --> Language Class Initialized
ERROR - 2022-02-24 04:58:51 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-24 04:58:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:52 --> Config Class Initialized
INFO - 2022-02-24 04:58:52 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:52 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:52 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:52 --> URI Class Initialized
INFO - 2022-02-24 04:58:52 --> Router Class Initialized
INFO - 2022-02-24 04:58:52 --> Output Class Initialized
INFO - 2022-02-24 04:58:52 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:52 --> Input Class Initialized
INFO - 2022-02-24 04:58:52 --> Language Class Initialized
ERROR - 2022-02-24 04:58:52 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-24 04:58:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:52 --> Config Class Initialized
INFO - 2022-02-24 04:58:52 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:52 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:52 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:52 --> URI Class Initialized
INFO - 2022-02-24 04:58:52 --> Router Class Initialized
INFO - 2022-02-24 04:58:52 --> Output Class Initialized
INFO - 2022-02-24 04:58:52 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:52 --> Input Class Initialized
INFO - 2022-02-24 04:58:52 --> Language Class Initialized
ERROR - 2022-02-24 04:58:52 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-24 04:58:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:53 --> Config Class Initialized
INFO - 2022-02-24 04:58:53 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:53 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:53 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:53 --> URI Class Initialized
INFO - 2022-02-24 04:58:53 --> Router Class Initialized
INFO - 2022-02-24 04:58:53 --> Output Class Initialized
INFO - 2022-02-24 04:58:53 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:53 --> Input Class Initialized
INFO - 2022-02-24 04:58:53 --> Language Class Initialized
ERROR - 2022-02-24 04:58:53 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-24 04:58:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:53 --> Config Class Initialized
INFO - 2022-02-24 04:58:53 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:53 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:53 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:53 --> URI Class Initialized
INFO - 2022-02-24 04:58:53 --> Router Class Initialized
INFO - 2022-02-24 04:58:53 --> Output Class Initialized
INFO - 2022-02-24 04:58:53 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:53 --> Input Class Initialized
INFO - 2022-02-24 04:58:53 --> Language Class Initialized
ERROR - 2022-02-24 04:58:53 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-24 04:58:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:53 --> Config Class Initialized
INFO - 2022-02-24 04:58:53 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:53 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:53 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:53 --> URI Class Initialized
INFO - 2022-02-24 04:58:53 --> Router Class Initialized
INFO - 2022-02-24 04:58:53 --> Output Class Initialized
INFO - 2022-02-24 04:58:53 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:53 --> Input Class Initialized
INFO - 2022-02-24 04:58:53 --> Language Class Initialized
ERROR - 2022-02-24 04:58:53 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-24 04:58:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:54 --> Config Class Initialized
INFO - 2022-02-24 04:58:54 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:54 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:54 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:54 --> URI Class Initialized
INFO - 2022-02-24 04:58:54 --> Router Class Initialized
INFO - 2022-02-24 04:58:54 --> Output Class Initialized
INFO - 2022-02-24 04:58:54 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:54 --> Input Class Initialized
INFO - 2022-02-24 04:58:54 --> Language Class Initialized
ERROR - 2022-02-24 04:58:54 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-24 04:58:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:54 --> Config Class Initialized
INFO - 2022-02-24 04:58:54 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:54 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:54 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:54 --> URI Class Initialized
INFO - 2022-02-24 04:58:54 --> Router Class Initialized
INFO - 2022-02-24 04:58:54 --> Output Class Initialized
INFO - 2022-02-24 04:58:54 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:54 --> Input Class Initialized
INFO - 2022-02-24 04:58:54 --> Language Class Initialized
ERROR - 2022-02-24 04:58:54 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-24 04:58:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:55 --> Config Class Initialized
INFO - 2022-02-24 04:58:55 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:55 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:55 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:55 --> URI Class Initialized
INFO - 2022-02-24 04:58:55 --> Router Class Initialized
INFO - 2022-02-24 04:58:55 --> Output Class Initialized
INFO - 2022-02-24 04:58:55 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:55 --> Input Class Initialized
INFO - 2022-02-24 04:58:55 --> Language Class Initialized
ERROR - 2022-02-24 04:58:55 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-24 04:58:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:55 --> Config Class Initialized
INFO - 2022-02-24 04:58:55 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:55 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:55 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:55 --> URI Class Initialized
INFO - 2022-02-24 04:58:55 --> Router Class Initialized
INFO - 2022-02-24 04:58:55 --> Output Class Initialized
INFO - 2022-02-24 04:58:55 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:55 --> Input Class Initialized
INFO - 2022-02-24 04:58:55 --> Language Class Initialized
ERROR - 2022-02-24 04:58:55 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-24 04:58:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:55 --> Config Class Initialized
INFO - 2022-02-24 04:58:55 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:55 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:55 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:55 --> URI Class Initialized
INFO - 2022-02-24 04:58:55 --> Router Class Initialized
INFO - 2022-02-24 04:58:55 --> Output Class Initialized
INFO - 2022-02-24 04:58:55 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:55 --> Input Class Initialized
INFO - 2022-02-24 04:58:55 --> Language Class Initialized
ERROR - 2022-02-24 04:58:55 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-24 04:58:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:56 --> Config Class Initialized
INFO - 2022-02-24 04:58:56 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:56 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:56 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:56 --> URI Class Initialized
INFO - 2022-02-24 04:58:56 --> Router Class Initialized
INFO - 2022-02-24 04:58:56 --> Output Class Initialized
INFO - 2022-02-24 04:58:56 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:56 --> Input Class Initialized
INFO - 2022-02-24 04:58:56 --> Language Class Initialized
ERROR - 2022-02-24 04:58:56 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-24 04:58:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:56 --> Config Class Initialized
INFO - 2022-02-24 04:58:56 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:56 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:56 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:56 --> URI Class Initialized
INFO - 2022-02-24 04:58:56 --> Router Class Initialized
INFO - 2022-02-24 04:58:56 --> Output Class Initialized
INFO - 2022-02-24 04:58:56 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:56 --> Input Class Initialized
INFO - 2022-02-24 04:58:56 --> Language Class Initialized
ERROR - 2022-02-24 04:58:56 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-24 04:58:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:56 --> Config Class Initialized
INFO - 2022-02-24 04:58:56 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:56 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:56 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:56 --> URI Class Initialized
INFO - 2022-02-24 04:58:56 --> Router Class Initialized
INFO - 2022-02-24 04:58:56 --> Output Class Initialized
INFO - 2022-02-24 04:58:56 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:56 --> Input Class Initialized
INFO - 2022-02-24 04:58:56 --> Language Class Initialized
ERROR - 2022-02-24 04:58:56 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-24 04:58:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:57 --> Config Class Initialized
INFO - 2022-02-24 04:58:57 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:57 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:57 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:57 --> URI Class Initialized
INFO - 2022-02-24 04:58:57 --> Router Class Initialized
INFO - 2022-02-24 04:58:57 --> Output Class Initialized
INFO - 2022-02-24 04:58:57 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:57 --> Input Class Initialized
INFO - 2022-02-24 04:58:57 --> Language Class Initialized
ERROR - 2022-02-24 04:58:57 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-24 04:58:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 04:58:57 --> Config Class Initialized
INFO - 2022-02-24 04:58:57 --> Hooks Class Initialized
DEBUG - 2022-02-24 04:58:57 --> UTF-8 Support Enabled
INFO - 2022-02-24 04:58:57 --> Utf8 Class Initialized
INFO - 2022-02-24 04:58:57 --> URI Class Initialized
INFO - 2022-02-24 04:58:57 --> Router Class Initialized
INFO - 2022-02-24 04:58:57 --> Output Class Initialized
INFO - 2022-02-24 04:58:57 --> Security Class Initialized
DEBUG - 2022-02-24 04:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 04:58:57 --> Input Class Initialized
INFO - 2022-02-24 04:58:57 --> Language Class Initialized
ERROR - 2022-02-24 04:58:57 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-24 08:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:28:51 --> Config Class Initialized
INFO - 2022-02-24 08:28:51 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:28:51 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:28:51 --> Utf8 Class Initialized
INFO - 2022-02-24 08:28:51 --> URI Class Initialized
DEBUG - 2022-02-24 08:28:51 --> No URI present. Default controller set.
INFO - 2022-02-24 08:28:51 --> Router Class Initialized
INFO - 2022-02-24 08:28:51 --> Output Class Initialized
INFO - 2022-02-24 08:28:51 --> Security Class Initialized
DEBUG - 2022-02-24 08:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:28:51 --> Input Class Initialized
INFO - 2022-02-24 08:28:51 --> Language Class Initialized
INFO - 2022-02-24 08:28:51 --> Loader Class Initialized
INFO - 2022-02-24 08:28:51 --> Helper loaded: url_helper
INFO - 2022-02-24 08:28:51 --> Helper loaded: form_helper
INFO - 2022-02-24 08:28:51 --> Helper loaded: common_helper
INFO - 2022-02-24 08:28:51 --> Database Driver Class Initialized
DEBUG - 2022-02-24 08:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 08:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 08:28:51 --> Controller Class Initialized
INFO - 2022-02-24 08:28:51 --> Form Validation Class Initialized
DEBUG - 2022-02-24 08:28:51 --> Encrypt Class Initialized
DEBUG - 2022-02-24 08:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 08:28:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 08:28:51 --> Email Class Initialized
INFO - 2022-02-24 08:28:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 08:28:51 --> Calendar Class Initialized
INFO - 2022-02-24 08:28:51 --> Model "Login_model" initialized
INFO - 2022-02-24 08:28:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 08:28:51 --> Final output sent to browser
DEBUG - 2022-02-24 08:28:51 --> Total execution time: 0.0213
ERROR - 2022-02-24 08:35:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:24 --> Config Class Initialized
INFO - 2022-02-24 08:35:24 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:24 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:24 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:24 --> URI Class Initialized
DEBUG - 2022-02-24 08:35:24 --> No URI present. Default controller set.
INFO - 2022-02-24 08:35:24 --> Router Class Initialized
INFO - 2022-02-24 08:35:24 --> Output Class Initialized
INFO - 2022-02-24 08:35:24 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:24 --> Input Class Initialized
INFO - 2022-02-24 08:35:24 --> Language Class Initialized
INFO - 2022-02-24 08:35:24 --> Loader Class Initialized
INFO - 2022-02-24 08:35:24 --> Helper loaded: url_helper
INFO - 2022-02-24 08:35:24 --> Helper loaded: form_helper
INFO - 2022-02-24 08:35:24 --> Helper loaded: common_helper
INFO - 2022-02-24 08:35:24 --> Database Driver Class Initialized
DEBUG - 2022-02-24 08:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 08:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 08:35:24 --> Controller Class Initialized
INFO - 2022-02-24 08:35:24 --> Form Validation Class Initialized
DEBUG - 2022-02-24 08:35:24 --> Encrypt Class Initialized
DEBUG - 2022-02-24 08:35:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 08:35:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 08:35:24 --> Email Class Initialized
INFO - 2022-02-24 08:35:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 08:35:24 --> Calendar Class Initialized
INFO - 2022-02-24 08:35:24 --> Model "Login_model" initialized
INFO - 2022-02-24 08:35:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 08:35:24 --> Final output sent to browser
DEBUG - 2022-02-24 08:35:24 --> Total execution time: 0.0470
ERROR - 2022-02-24 08:35:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:24 --> Config Class Initialized
INFO - 2022-02-24 08:35:24 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:24 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:24 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:24 --> URI Class Initialized
DEBUG - 2022-02-24 08:35:24 --> No URI present. Default controller set.
INFO - 2022-02-24 08:35:24 --> Router Class Initialized
INFO - 2022-02-24 08:35:24 --> Output Class Initialized
INFO - 2022-02-24 08:35:24 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:24 --> Input Class Initialized
INFO - 2022-02-24 08:35:24 --> Language Class Initialized
INFO - 2022-02-24 08:35:24 --> Loader Class Initialized
INFO - 2022-02-24 08:35:24 --> Helper loaded: url_helper
INFO - 2022-02-24 08:35:24 --> Helper loaded: form_helper
INFO - 2022-02-24 08:35:24 --> Helper loaded: common_helper
INFO - 2022-02-24 08:35:24 --> Database Driver Class Initialized
DEBUG - 2022-02-24 08:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 08:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 08:35:24 --> Controller Class Initialized
INFO - 2022-02-24 08:35:24 --> Form Validation Class Initialized
DEBUG - 2022-02-24 08:35:24 --> Encrypt Class Initialized
DEBUG - 2022-02-24 08:35:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 08:35:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 08:35:24 --> Email Class Initialized
INFO - 2022-02-24 08:35:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 08:35:24 --> Calendar Class Initialized
INFO - 2022-02-24 08:35:24 --> Model "Login_model" initialized
INFO - 2022-02-24 08:35:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 08:35:24 --> Final output sent to browser
DEBUG - 2022-02-24 08:35:24 --> Total execution time: 0.0314
ERROR - 2022-02-24 08:35:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:25 --> Config Class Initialized
INFO - 2022-02-24 08:35:25 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:25 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:25 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:25 --> URI Class Initialized
DEBUG - 2022-02-24 08:35:25 --> No URI present. Default controller set.
INFO - 2022-02-24 08:35:25 --> Router Class Initialized
INFO - 2022-02-24 08:35:25 --> Output Class Initialized
INFO - 2022-02-24 08:35:25 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:25 --> Input Class Initialized
INFO - 2022-02-24 08:35:25 --> Language Class Initialized
INFO - 2022-02-24 08:35:25 --> Loader Class Initialized
INFO - 2022-02-24 08:35:25 --> Helper loaded: url_helper
INFO - 2022-02-24 08:35:25 --> Helper loaded: form_helper
INFO - 2022-02-24 08:35:25 --> Helper loaded: common_helper
INFO - 2022-02-24 08:35:25 --> Database Driver Class Initialized
DEBUG - 2022-02-24 08:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 08:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 08:35:25 --> Controller Class Initialized
INFO - 2022-02-24 08:35:25 --> Form Validation Class Initialized
DEBUG - 2022-02-24 08:35:25 --> Encrypt Class Initialized
DEBUG - 2022-02-24 08:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 08:35:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 08:35:25 --> Email Class Initialized
INFO - 2022-02-24 08:35:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 08:35:25 --> Calendar Class Initialized
INFO - 2022-02-24 08:35:25 --> Model "Login_model" initialized
INFO - 2022-02-24 08:35:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 08:35:25 --> Final output sent to browser
DEBUG - 2022-02-24 08:35:25 --> Total execution time: 0.0343
ERROR - 2022-02-24 08:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:26 --> Config Class Initialized
INFO - 2022-02-24 08:35:26 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:26 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:26 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:26 --> URI Class Initialized
INFO - 2022-02-24 08:35:26 --> Router Class Initialized
INFO - 2022-02-24 08:35:26 --> Output Class Initialized
INFO - 2022-02-24 08:35:26 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:26 --> Input Class Initialized
INFO - 2022-02-24 08:35:26 --> Language Class Initialized
ERROR - 2022-02-24 08:35:26 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-24 08:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:26 --> Config Class Initialized
INFO - 2022-02-24 08:35:26 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:26 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:26 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:26 --> URI Class Initialized
INFO - 2022-02-24 08:35:26 --> Router Class Initialized
INFO - 2022-02-24 08:35:26 --> Output Class Initialized
INFO - 2022-02-24 08:35:26 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:26 --> Input Class Initialized
INFO - 2022-02-24 08:35:26 --> Language Class Initialized
ERROR - 2022-02-24 08:35:26 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-24 08:35:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:27 --> Config Class Initialized
INFO - 2022-02-24 08:35:27 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:27 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:27 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:27 --> URI Class Initialized
INFO - 2022-02-24 08:35:27 --> Router Class Initialized
INFO - 2022-02-24 08:35:27 --> Output Class Initialized
INFO - 2022-02-24 08:35:27 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:27 --> Input Class Initialized
INFO - 2022-02-24 08:35:27 --> Language Class Initialized
ERROR - 2022-02-24 08:35:27 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-24 08:35:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:27 --> Config Class Initialized
INFO - 2022-02-24 08:35:27 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:27 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:27 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:27 --> URI Class Initialized
INFO - 2022-02-24 08:35:27 --> Router Class Initialized
INFO - 2022-02-24 08:35:27 --> Output Class Initialized
INFO - 2022-02-24 08:35:27 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:27 --> Input Class Initialized
INFO - 2022-02-24 08:35:27 --> Language Class Initialized
ERROR - 2022-02-24 08:35:27 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-24 08:35:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:28 --> Config Class Initialized
INFO - 2022-02-24 08:35:28 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:28 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:28 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:28 --> URI Class Initialized
INFO - 2022-02-24 08:35:28 --> Router Class Initialized
INFO - 2022-02-24 08:35:28 --> Output Class Initialized
INFO - 2022-02-24 08:35:28 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:28 --> Input Class Initialized
INFO - 2022-02-24 08:35:28 --> Language Class Initialized
ERROR - 2022-02-24 08:35:28 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-24 08:35:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:28 --> Config Class Initialized
INFO - 2022-02-24 08:35:28 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:28 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:28 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:28 --> URI Class Initialized
INFO - 2022-02-24 08:35:28 --> Router Class Initialized
INFO - 2022-02-24 08:35:28 --> Output Class Initialized
INFO - 2022-02-24 08:35:28 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:28 --> Input Class Initialized
INFO - 2022-02-24 08:35:28 --> Language Class Initialized
ERROR - 2022-02-24 08:35:28 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-24 08:35:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:29 --> Config Class Initialized
INFO - 2022-02-24 08:35:29 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:29 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:29 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:29 --> URI Class Initialized
INFO - 2022-02-24 08:35:29 --> Router Class Initialized
INFO - 2022-02-24 08:35:29 --> Output Class Initialized
INFO - 2022-02-24 08:35:29 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:29 --> Input Class Initialized
INFO - 2022-02-24 08:35:29 --> Language Class Initialized
ERROR - 2022-02-24 08:35:29 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-24 08:35:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:29 --> Config Class Initialized
INFO - 2022-02-24 08:35:29 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:29 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:29 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:29 --> URI Class Initialized
INFO - 2022-02-24 08:35:29 --> Router Class Initialized
INFO - 2022-02-24 08:35:29 --> Output Class Initialized
INFO - 2022-02-24 08:35:29 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:29 --> Input Class Initialized
INFO - 2022-02-24 08:35:29 --> Language Class Initialized
ERROR - 2022-02-24 08:35:29 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-24 08:35:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:30 --> Config Class Initialized
INFO - 2022-02-24 08:35:30 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:30 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:30 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:30 --> URI Class Initialized
INFO - 2022-02-24 08:35:30 --> Router Class Initialized
INFO - 2022-02-24 08:35:30 --> Output Class Initialized
INFO - 2022-02-24 08:35:30 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:30 --> Input Class Initialized
INFO - 2022-02-24 08:35:30 --> Language Class Initialized
ERROR - 2022-02-24 08:35:30 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-24 08:35:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:31 --> Config Class Initialized
INFO - 2022-02-24 08:35:31 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:31 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:31 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:31 --> URI Class Initialized
INFO - 2022-02-24 08:35:31 --> Router Class Initialized
INFO - 2022-02-24 08:35:31 --> Output Class Initialized
INFO - 2022-02-24 08:35:31 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:31 --> Input Class Initialized
INFO - 2022-02-24 08:35:31 --> Language Class Initialized
ERROR - 2022-02-24 08:35:31 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-24 08:35:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:31 --> Config Class Initialized
INFO - 2022-02-24 08:35:31 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:31 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:31 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:31 --> URI Class Initialized
INFO - 2022-02-24 08:35:31 --> Router Class Initialized
INFO - 2022-02-24 08:35:31 --> Output Class Initialized
INFO - 2022-02-24 08:35:31 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:31 --> Input Class Initialized
INFO - 2022-02-24 08:35:31 --> Language Class Initialized
ERROR - 2022-02-24 08:35:31 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-24 08:35:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:32 --> Config Class Initialized
INFO - 2022-02-24 08:35:32 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:32 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:32 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:32 --> URI Class Initialized
INFO - 2022-02-24 08:35:32 --> Router Class Initialized
INFO - 2022-02-24 08:35:32 --> Output Class Initialized
INFO - 2022-02-24 08:35:32 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:32 --> Input Class Initialized
INFO - 2022-02-24 08:35:32 --> Language Class Initialized
ERROR - 2022-02-24 08:35:32 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-24 08:35:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:32 --> Config Class Initialized
INFO - 2022-02-24 08:35:32 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:32 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:32 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:32 --> URI Class Initialized
INFO - 2022-02-24 08:35:32 --> Router Class Initialized
INFO - 2022-02-24 08:35:32 --> Output Class Initialized
INFO - 2022-02-24 08:35:32 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:32 --> Input Class Initialized
INFO - 2022-02-24 08:35:32 --> Language Class Initialized
ERROR - 2022-02-24 08:35:32 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-24 08:35:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:33 --> Config Class Initialized
INFO - 2022-02-24 08:35:33 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:33 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:33 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:33 --> URI Class Initialized
INFO - 2022-02-24 08:35:33 --> Router Class Initialized
INFO - 2022-02-24 08:35:33 --> Output Class Initialized
INFO - 2022-02-24 08:35:33 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:33 --> Input Class Initialized
INFO - 2022-02-24 08:35:33 --> Language Class Initialized
ERROR - 2022-02-24 08:35:33 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-24 08:35:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:33 --> Config Class Initialized
INFO - 2022-02-24 08:35:33 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:33 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:33 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:33 --> URI Class Initialized
INFO - 2022-02-24 08:35:33 --> Router Class Initialized
INFO - 2022-02-24 08:35:33 --> Output Class Initialized
INFO - 2022-02-24 08:35:33 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:33 --> Input Class Initialized
INFO - 2022-02-24 08:35:33 --> Language Class Initialized
ERROR - 2022-02-24 08:35:33 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-24 08:35:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 08:35:34 --> Config Class Initialized
INFO - 2022-02-24 08:35:34 --> Hooks Class Initialized
DEBUG - 2022-02-24 08:35:34 --> UTF-8 Support Enabled
INFO - 2022-02-24 08:35:34 --> Utf8 Class Initialized
INFO - 2022-02-24 08:35:34 --> URI Class Initialized
INFO - 2022-02-24 08:35:34 --> Router Class Initialized
INFO - 2022-02-24 08:35:34 --> Output Class Initialized
INFO - 2022-02-24 08:35:34 --> Security Class Initialized
DEBUG - 2022-02-24 08:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 08:35:34 --> Input Class Initialized
INFO - 2022-02-24 08:35:34 --> Language Class Initialized
ERROR - 2022-02-24 08:35:34 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-24 10:22:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 10:22:19 --> Config Class Initialized
INFO - 2022-02-24 10:22:19 --> Hooks Class Initialized
DEBUG - 2022-02-24 10:22:19 --> UTF-8 Support Enabled
INFO - 2022-02-24 10:22:19 --> Utf8 Class Initialized
INFO - 2022-02-24 10:22:19 --> URI Class Initialized
DEBUG - 2022-02-24 10:22:19 --> No URI present. Default controller set.
INFO - 2022-02-24 10:22:19 --> Router Class Initialized
INFO - 2022-02-24 10:22:19 --> Output Class Initialized
INFO - 2022-02-24 10:22:19 --> Security Class Initialized
DEBUG - 2022-02-24 10:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 10:22:19 --> Input Class Initialized
INFO - 2022-02-24 10:22:19 --> Language Class Initialized
INFO - 2022-02-24 10:22:19 --> Loader Class Initialized
INFO - 2022-02-24 10:22:19 --> Helper loaded: url_helper
INFO - 2022-02-24 10:22:19 --> Helper loaded: form_helper
INFO - 2022-02-24 10:22:19 --> Helper loaded: common_helper
INFO - 2022-02-24 10:22:19 --> Database Driver Class Initialized
DEBUG - 2022-02-24 10:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 10:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 10:22:19 --> Controller Class Initialized
INFO - 2022-02-24 10:22:19 --> Form Validation Class Initialized
DEBUG - 2022-02-24 10:22:19 --> Encrypt Class Initialized
DEBUG - 2022-02-24 10:22:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:22:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 10:22:19 --> Email Class Initialized
INFO - 2022-02-24 10:22:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 10:22:19 --> Calendar Class Initialized
INFO - 2022-02-24 10:22:19 --> Model "Login_model" initialized
INFO - 2022-02-24 10:22:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 10:22:19 --> Final output sent to browser
DEBUG - 2022-02-24 10:22:19 --> Total execution time: 0.0274
ERROR - 2022-02-24 10:42:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 10:42:04 --> Config Class Initialized
INFO - 2022-02-24 10:42:04 --> Hooks Class Initialized
DEBUG - 2022-02-24 10:42:04 --> UTF-8 Support Enabled
INFO - 2022-02-24 10:42:04 --> Utf8 Class Initialized
INFO - 2022-02-24 10:42:04 --> URI Class Initialized
DEBUG - 2022-02-24 10:42:04 --> No URI present. Default controller set.
INFO - 2022-02-24 10:42:04 --> Router Class Initialized
INFO - 2022-02-24 10:42:04 --> Output Class Initialized
INFO - 2022-02-24 10:42:04 --> Security Class Initialized
DEBUG - 2022-02-24 10:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 10:42:04 --> Input Class Initialized
INFO - 2022-02-24 10:42:04 --> Language Class Initialized
INFO - 2022-02-24 10:42:04 --> Loader Class Initialized
INFO - 2022-02-24 10:42:04 --> Helper loaded: url_helper
INFO - 2022-02-24 10:42:04 --> Helper loaded: form_helper
INFO - 2022-02-24 10:42:04 --> Helper loaded: common_helper
INFO - 2022-02-24 10:42:04 --> Database Driver Class Initialized
DEBUG - 2022-02-24 10:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 10:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 10:42:04 --> Controller Class Initialized
INFO - 2022-02-24 10:42:04 --> Form Validation Class Initialized
DEBUG - 2022-02-24 10:42:04 --> Encrypt Class Initialized
DEBUG - 2022-02-24 10:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:42:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 10:42:04 --> Email Class Initialized
INFO - 2022-02-24 10:42:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 10:42:04 --> Calendar Class Initialized
INFO - 2022-02-24 10:42:04 --> Model "Login_model" initialized
INFO - 2022-02-24 10:42:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 10:42:04 --> Final output sent to browser
DEBUG - 2022-02-24 10:42:04 --> Total execution time: 0.0226
ERROR - 2022-02-24 10:42:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 10:42:05 --> Config Class Initialized
INFO - 2022-02-24 10:42:05 --> Hooks Class Initialized
DEBUG - 2022-02-24 10:42:05 --> UTF-8 Support Enabled
INFO - 2022-02-24 10:42:05 --> Utf8 Class Initialized
INFO - 2022-02-24 10:42:05 --> URI Class Initialized
INFO - 2022-02-24 10:42:05 --> Router Class Initialized
INFO - 2022-02-24 10:42:05 --> Output Class Initialized
INFO - 2022-02-24 10:42:05 --> Security Class Initialized
DEBUG - 2022-02-24 10:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 10:42:05 --> Input Class Initialized
INFO - 2022-02-24 10:42:05 --> Language Class Initialized
ERROR - 2022-02-24 10:42:05 --> 404 Page Not Found: Register/index
ERROR - 2022-02-24 10:42:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 10:42:09 --> Config Class Initialized
INFO - 2022-02-24 10:42:09 --> Hooks Class Initialized
DEBUG - 2022-02-24 10:42:09 --> UTF-8 Support Enabled
INFO - 2022-02-24 10:42:09 --> Utf8 Class Initialized
INFO - 2022-02-24 10:42:09 --> URI Class Initialized
INFO - 2022-02-24 10:42:09 --> Router Class Initialized
INFO - 2022-02-24 10:42:09 --> Output Class Initialized
INFO - 2022-02-24 10:42:09 --> Security Class Initialized
DEBUG - 2022-02-24 10:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 10:42:09 --> Input Class Initialized
INFO - 2022-02-24 10:42:09 --> Language Class Initialized
INFO - 2022-02-24 10:42:09 --> Loader Class Initialized
INFO - 2022-02-24 10:42:09 --> Helper loaded: url_helper
INFO - 2022-02-24 10:42:09 --> Helper loaded: form_helper
INFO - 2022-02-24 10:42:09 --> Helper loaded: common_helper
INFO - 2022-02-24 10:42:09 --> Database Driver Class Initialized
DEBUG - 2022-02-24 10:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 10:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 10:42:09 --> Controller Class Initialized
INFO - 2022-02-24 10:42:09 --> Form Validation Class Initialized
DEBUG - 2022-02-24 10:42:09 --> Encrypt Class Initialized
DEBUG - 2022-02-24 10:42:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:42:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 10:42:09 --> Email Class Initialized
INFO - 2022-02-24 10:42:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 10:42:09 --> Calendar Class Initialized
INFO - 2022-02-24 10:42:09 --> Model "Login_model" initialized
INFO - 2022-02-24 10:42:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 10:42:09 --> Final output sent to browser
DEBUG - 2022-02-24 10:42:09 --> Total execution time: 0.0223
ERROR - 2022-02-24 10:42:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 10:42:09 --> Config Class Initialized
INFO - 2022-02-24 10:42:09 --> Hooks Class Initialized
DEBUG - 2022-02-24 10:42:09 --> UTF-8 Support Enabled
INFO - 2022-02-24 10:42:09 --> Utf8 Class Initialized
INFO - 2022-02-24 10:42:09 --> URI Class Initialized
DEBUG - 2022-02-24 10:42:09 --> No URI present. Default controller set.
INFO - 2022-02-24 10:42:09 --> Router Class Initialized
INFO - 2022-02-24 10:42:09 --> Output Class Initialized
INFO - 2022-02-24 10:42:09 --> Security Class Initialized
DEBUG - 2022-02-24 10:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 10:42:09 --> Input Class Initialized
INFO - 2022-02-24 10:42:09 --> Language Class Initialized
INFO - 2022-02-24 10:42:09 --> Loader Class Initialized
INFO - 2022-02-24 10:42:09 --> Helper loaded: url_helper
INFO - 2022-02-24 10:42:09 --> Helper loaded: form_helper
INFO - 2022-02-24 10:42:09 --> Helper loaded: common_helper
INFO - 2022-02-24 10:42:09 --> Database Driver Class Initialized
DEBUG - 2022-02-24 10:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 10:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 10:42:09 --> Controller Class Initialized
INFO - 2022-02-24 10:42:09 --> Form Validation Class Initialized
DEBUG - 2022-02-24 10:42:09 --> Encrypt Class Initialized
DEBUG - 2022-02-24 10:42:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:42:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 10:42:09 --> Email Class Initialized
INFO - 2022-02-24 10:42:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 10:42:09 --> Calendar Class Initialized
INFO - 2022-02-24 10:42:09 --> Model "Login_model" initialized
INFO - 2022-02-24 10:42:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 10:42:09 --> Final output sent to browser
DEBUG - 2022-02-24 10:42:09 --> Total execution time: 0.0369
ERROR - 2022-02-24 10:42:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 10:42:13 --> Config Class Initialized
INFO - 2022-02-24 10:42:13 --> Hooks Class Initialized
DEBUG - 2022-02-24 10:42:13 --> UTF-8 Support Enabled
INFO - 2022-02-24 10:42:13 --> Utf8 Class Initialized
INFO - 2022-02-24 10:42:13 --> URI Class Initialized
INFO - 2022-02-24 10:42:13 --> Router Class Initialized
INFO - 2022-02-24 10:42:13 --> Output Class Initialized
INFO - 2022-02-24 10:42:13 --> Security Class Initialized
DEBUG - 2022-02-24 10:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 10:42:13 --> Input Class Initialized
INFO - 2022-02-24 10:42:13 --> Language Class Initialized
INFO - 2022-02-24 10:42:13 --> Loader Class Initialized
INFO - 2022-02-24 10:42:13 --> Helper loaded: url_helper
INFO - 2022-02-24 10:42:13 --> Helper loaded: form_helper
INFO - 2022-02-24 10:42:13 --> Helper loaded: common_helper
INFO - 2022-02-24 10:42:13 --> Database Driver Class Initialized
DEBUG - 2022-02-24 10:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 10:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 10:42:13 --> Controller Class Initialized
INFO - 2022-02-24 10:42:13 --> Form Validation Class Initialized
DEBUG - 2022-02-24 10:42:13 --> Encrypt Class Initialized
DEBUG - 2022-02-24 10:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:42:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 10:42:13 --> Email Class Initialized
INFO - 2022-02-24 10:42:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 10:42:13 --> Calendar Class Initialized
INFO - 2022-02-24 10:42:13 --> Model "Login_model" initialized
ERROR - 2022-02-24 10:42:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 10:42:17 --> Config Class Initialized
INFO - 2022-02-24 10:42:17 --> Hooks Class Initialized
DEBUG - 2022-02-24 10:42:17 --> UTF-8 Support Enabled
INFO - 2022-02-24 10:42:17 --> Utf8 Class Initialized
INFO - 2022-02-24 10:42:17 --> URI Class Initialized
INFO - 2022-02-24 10:42:17 --> Router Class Initialized
INFO - 2022-02-24 10:42:17 --> Output Class Initialized
INFO - 2022-02-24 10:42:17 --> Security Class Initialized
DEBUG - 2022-02-24 10:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 10:42:17 --> Input Class Initialized
INFO - 2022-02-24 10:42:17 --> Language Class Initialized
INFO - 2022-02-24 10:42:17 --> Loader Class Initialized
INFO - 2022-02-24 10:42:17 --> Helper loaded: url_helper
INFO - 2022-02-24 10:42:17 --> Helper loaded: form_helper
INFO - 2022-02-24 10:42:17 --> Helper loaded: common_helper
INFO - 2022-02-24 10:42:17 --> Database Driver Class Initialized
DEBUG - 2022-02-24 10:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 10:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 10:42:17 --> Controller Class Initialized
INFO - 2022-02-24 10:42:17 --> Form Validation Class Initialized
DEBUG - 2022-02-24 10:42:17 --> Encrypt Class Initialized
DEBUG - 2022-02-24 10:42:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:42:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 10:42:17 --> Email Class Initialized
INFO - 2022-02-24 10:42:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 10:42:17 --> Calendar Class Initialized
INFO - 2022-02-24 10:42:17 --> Model "Login_model" initialized
INFO - 2022-02-24 10:42:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 10:42:17 --> Final output sent to browser
DEBUG - 2022-02-24 10:42:17 --> Total execution time: 0.0219
ERROR - 2022-02-24 11:40:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:27 --> Config Class Initialized
INFO - 2022-02-24 11:40:27 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:27 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:27 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:27 --> URI Class Initialized
DEBUG - 2022-02-24 11:40:27 --> No URI present. Default controller set.
INFO - 2022-02-24 11:40:27 --> Router Class Initialized
INFO - 2022-02-24 11:40:27 --> Output Class Initialized
INFO - 2022-02-24 11:40:27 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:27 --> Input Class Initialized
INFO - 2022-02-24 11:40:27 --> Language Class Initialized
INFO - 2022-02-24 11:40:27 --> Loader Class Initialized
INFO - 2022-02-24 11:40:27 --> Helper loaded: url_helper
INFO - 2022-02-24 11:40:27 --> Helper loaded: form_helper
INFO - 2022-02-24 11:40:27 --> Helper loaded: common_helper
INFO - 2022-02-24 11:40:27 --> Database Driver Class Initialized
DEBUG - 2022-02-24 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 11:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 11:40:27 --> Controller Class Initialized
INFO - 2022-02-24 11:40:27 --> Form Validation Class Initialized
DEBUG - 2022-02-24 11:40:27 --> Encrypt Class Initialized
DEBUG - 2022-02-24 11:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:40:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 11:40:27 --> Email Class Initialized
INFO - 2022-02-24 11:40:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 11:40:27 --> Calendar Class Initialized
INFO - 2022-02-24 11:40:27 --> Model "Login_model" initialized
INFO - 2022-02-24 11:40:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 11:40:27 --> Final output sent to browser
DEBUG - 2022-02-24 11:40:27 --> Total execution time: 0.0294
ERROR - 2022-02-24 11:40:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:28 --> Config Class Initialized
INFO - 2022-02-24 11:40:28 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:28 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:28 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:28 --> URI Class Initialized
DEBUG - 2022-02-24 11:40:28 --> No URI present. Default controller set.
INFO - 2022-02-24 11:40:28 --> Router Class Initialized
INFO - 2022-02-24 11:40:28 --> Output Class Initialized
INFO - 2022-02-24 11:40:28 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:28 --> Input Class Initialized
INFO - 2022-02-24 11:40:28 --> Language Class Initialized
INFO - 2022-02-24 11:40:28 --> Loader Class Initialized
INFO - 2022-02-24 11:40:28 --> Helper loaded: url_helper
INFO - 2022-02-24 11:40:28 --> Helper loaded: form_helper
INFO - 2022-02-24 11:40:28 --> Helper loaded: common_helper
INFO - 2022-02-24 11:40:28 --> Database Driver Class Initialized
DEBUG - 2022-02-24 11:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 11:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 11:40:28 --> Controller Class Initialized
INFO - 2022-02-24 11:40:28 --> Form Validation Class Initialized
DEBUG - 2022-02-24 11:40:28 --> Encrypt Class Initialized
DEBUG - 2022-02-24 11:40:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:40:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 11:40:28 --> Email Class Initialized
INFO - 2022-02-24 11:40:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 11:40:28 --> Calendar Class Initialized
INFO - 2022-02-24 11:40:28 --> Model "Login_model" initialized
INFO - 2022-02-24 11:40:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 11:40:28 --> Final output sent to browser
DEBUG - 2022-02-24 11:40:28 --> Total execution time: 0.0273
ERROR - 2022-02-24 11:40:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:28 --> Config Class Initialized
INFO - 2022-02-24 11:40:28 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:28 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:28 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:28 --> URI Class Initialized
INFO - 2022-02-24 11:40:28 --> Router Class Initialized
INFO - 2022-02-24 11:40:28 --> Output Class Initialized
INFO - 2022-02-24 11:40:28 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:28 --> Input Class Initialized
INFO - 2022-02-24 11:40:28 --> Language Class Initialized
ERROR - 2022-02-24 11:40:28 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-24 11:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:29 --> Config Class Initialized
INFO - 2022-02-24 11:40:29 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:29 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:29 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:29 --> URI Class Initialized
INFO - 2022-02-24 11:40:29 --> Router Class Initialized
INFO - 2022-02-24 11:40:29 --> Output Class Initialized
INFO - 2022-02-24 11:40:29 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:29 --> Input Class Initialized
INFO - 2022-02-24 11:40:29 --> Language Class Initialized
ERROR - 2022-02-24 11:40:29 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-24 11:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:29 --> Config Class Initialized
INFO - 2022-02-24 11:40:29 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:29 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:29 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:29 --> URI Class Initialized
INFO - 2022-02-24 11:40:29 --> Router Class Initialized
INFO - 2022-02-24 11:40:29 --> Output Class Initialized
INFO - 2022-02-24 11:40:29 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:29 --> Input Class Initialized
INFO - 2022-02-24 11:40:29 --> Language Class Initialized
ERROR - 2022-02-24 11:40:29 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-24 11:40:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:30 --> Config Class Initialized
INFO - 2022-02-24 11:40:30 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:30 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:30 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:30 --> URI Class Initialized
INFO - 2022-02-24 11:40:30 --> Router Class Initialized
INFO - 2022-02-24 11:40:30 --> Output Class Initialized
INFO - 2022-02-24 11:40:30 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:30 --> Input Class Initialized
INFO - 2022-02-24 11:40:30 --> Language Class Initialized
ERROR - 2022-02-24 11:40:30 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-24 11:40:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:30 --> Config Class Initialized
INFO - 2022-02-24 11:40:30 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:30 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:30 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:30 --> URI Class Initialized
INFO - 2022-02-24 11:40:30 --> Router Class Initialized
INFO - 2022-02-24 11:40:30 --> Output Class Initialized
INFO - 2022-02-24 11:40:30 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:30 --> Input Class Initialized
INFO - 2022-02-24 11:40:30 --> Language Class Initialized
ERROR - 2022-02-24 11:40:30 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-24 11:40:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:30 --> Config Class Initialized
INFO - 2022-02-24 11:40:30 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:30 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:30 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:30 --> URI Class Initialized
INFO - 2022-02-24 11:40:30 --> Router Class Initialized
INFO - 2022-02-24 11:40:30 --> Output Class Initialized
INFO - 2022-02-24 11:40:30 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:30 --> Input Class Initialized
INFO - 2022-02-24 11:40:30 --> Language Class Initialized
ERROR - 2022-02-24 11:40:30 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-24 11:40:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:31 --> Config Class Initialized
INFO - 2022-02-24 11:40:31 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:31 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:31 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:31 --> URI Class Initialized
INFO - 2022-02-24 11:40:31 --> Router Class Initialized
INFO - 2022-02-24 11:40:31 --> Output Class Initialized
INFO - 2022-02-24 11:40:31 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:31 --> Input Class Initialized
INFO - 2022-02-24 11:40:31 --> Language Class Initialized
ERROR - 2022-02-24 11:40:31 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-24 11:40:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:31 --> Config Class Initialized
INFO - 2022-02-24 11:40:31 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:31 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:31 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:31 --> URI Class Initialized
INFO - 2022-02-24 11:40:31 --> Router Class Initialized
INFO - 2022-02-24 11:40:31 --> Output Class Initialized
INFO - 2022-02-24 11:40:31 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:31 --> Input Class Initialized
INFO - 2022-02-24 11:40:31 --> Language Class Initialized
ERROR - 2022-02-24 11:40:31 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-24 11:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:32 --> Config Class Initialized
INFO - 2022-02-24 11:40:32 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:32 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:32 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:32 --> URI Class Initialized
INFO - 2022-02-24 11:40:32 --> Router Class Initialized
INFO - 2022-02-24 11:40:32 --> Output Class Initialized
INFO - 2022-02-24 11:40:32 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:32 --> Input Class Initialized
INFO - 2022-02-24 11:40:32 --> Language Class Initialized
ERROR - 2022-02-24 11:40:32 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-24 11:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:32 --> Config Class Initialized
INFO - 2022-02-24 11:40:32 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:32 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:32 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:32 --> URI Class Initialized
INFO - 2022-02-24 11:40:32 --> Router Class Initialized
INFO - 2022-02-24 11:40:32 --> Output Class Initialized
INFO - 2022-02-24 11:40:32 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:32 --> Input Class Initialized
INFO - 2022-02-24 11:40:32 --> Language Class Initialized
ERROR - 2022-02-24 11:40:32 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-24 11:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:32 --> Config Class Initialized
INFO - 2022-02-24 11:40:32 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:32 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:32 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:32 --> URI Class Initialized
INFO - 2022-02-24 11:40:32 --> Router Class Initialized
INFO - 2022-02-24 11:40:32 --> Output Class Initialized
INFO - 2022-02-24 11:40:32 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:32 --> Input Class Initialized
INFO - 2022-02-24 11:40:32 --> Language Class Initialized
ERROR - 2022-02-24 11:40:32 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-24 11:40:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:33 --> Config Class Initialized
INFO - 2022-02-24 11:40:33 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:33 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:33 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:33 --> URI Class Initialized
INFO - 2022-02-24 11:40:33 --> Router Class Initialized
INFO - 2022-02-24 11:40:33 --> Output Class Initialized
INFO - 2022-02-24 11:40:33 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:33 --> Input Class Initialized
INFO - 2022-02-24 11:40:33 --> Language Class Initialized
ERROR - 2022-02-24 11:40:33 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-24 11:40:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:33 --> Config Class Initialized
INFO - 2022-02-24 11:40:33 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:33 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:33 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:33 --> URI Class Initialized
INFO - 2022-02-24 11:40:33 --> Router Class Initialized
INFO - 2022-02-24 11:40:33 --> Output Class Initialized
INFO - 2022-02-24 11:40:33 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:33 --> Input Class Initialized
INFO - 2022-02-24 11:40:33 --> Language Class Initialized
ERROR - 2022-02-24 11:40:33 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-24 11:40:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:33 --> Config Class Initialized
INFO - 2022-02-24 11:40:33 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:33 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:33 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:33 --> URI Class Initialized
INFO - 2022-02-24 11:40:33 --> Router Class Initialized
INFO - 2022-02-24 11:40:33 --> Output Class Initialized
INFO - 2022-02-24 11:40:33 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:33 --> Input Class Initialized
INFO - 2022-02-24 11:40:33 --> Language Class Initialized
ERROR - 2022-02-24 11:40:33 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-24 11:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:34 --> Config Class Initialized
INFO - 2022-02-24 11:40:34 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:34 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:34 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:34 --> URI Class Initialized
INFO - 2022-02-24 11:40:34 --> Router Class Initialized
INFO - 2022-02-24 11:40:34 --> Output Class Initialized
INFO - 2022-02-24 11:40:34 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:34 --> Input Class Initialized
INFO - 2022-02-24 11:40:34 --> Language Class Initialized
ERROR - 2022-02-24 11:40:34 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-24 11:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 11:40:34 --> Config Class Initialized
INFO - 2022-02-24 11:40:34 --> Hooks Class Initialized
DEBUG - 2022-02-24 11:40:34 --> UTF-8 Support Enabled
INFO - 2022-02-24 11:40:34 --> Utf8 Class Initialized
INFO - 2022-02-24 11:40:34 --> URI Class Initialized
INFO - 2022-02-24 11:40:34 --> Router Class Initialized
INFO - 2022-02-24 11:40:34 --> Output Class Initialized
INFO - 2022-02-24 11:40:34 --> Security Class Initialized
DEBUG - 2022-02-24 11:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 11:40:34 --> Input Class Initialized
INFO - 2022-02-24 11:40:34 --> Language Class Initialized
ERROR - 2022-02-24 11:40:34 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-02-24 13:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 13:59:20 --> Config Class Initialized
INFO - 2022-02-24 13:59:20 --> Hooks Class Initialized
DEBUG - 2022-02-24 13:59:20 --> UTF-8 Support Enabled
INFO - 2022-02-24 13:59:20 --> Utf8 Class Initialized
INFO - 2022-02-24 13:59:20 --> URI Class Initialized
DEBUG - 2022-02-24 13:59:20 --> No URI present. Default controller set.
INFO - 2022-02-24 13:59:20 --> Router Class Initialized
INFO - 2022-02-24 13:59:20 --> Output Class Initialized
INFO - 2022-02-24 13:59:20 --> Security Class Initialized
DEBUG - 2022-02-24 13:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 13:59:20 --> Input Class Initialized
INFO - 2022-02-24 13:59:20 --> Language Class Initialized
INFO - 2022-02-24 13:59:20 --> Loader Class Initialized
INFO - 2022-02-24 13:59:20 --> Helper loaded: url_helper
INFO - 2022-02-24 13:59:20 --> Helper loaded: form_helper
INFO - 2022-02-24 13:59:20 --> Helper loaded: common_helper
INFO - 2022-02-24 13:59:20 --> Database Driver Class Initialized
DEBUG - 2022-02-24 13:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 13:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 13:59:20 --> Controller Class Initialized
INFO - 2022-02-24 13:59:20 --> Form Validation Class Initialized
DEBUG - 2022-02-24 13:59:20 --> Encrypt Class Initialized
DEBUG - 2022-02-24 13:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 13:59:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 13:59:20 --> Email Class Initialized
INFO - 2022-02-24 13:59:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 13:59:20 --> Calendar Class Initialized
INFO - 2022-02-24 13:59:20 --> Model "Login_model" initialized
INFO - 2022-02-24 13:59:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 13:59:20 --> Final output sent to browser
DEBUG - 2022-02-24 13:59:20 --> Total execution time: 0.0518
ERROR - 2022-02-24 14:21:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 14:21:35 --> Config Class Initialized
INFO - 2022-02-24 14:21:35 --> Hooks Class Initialized
DEBUG - 2022-02-24 14:21:35 --> UTF-8 Support Enabled
INFO - 2022-02-24 14:21:35 --> Utf8 Class Initialized
INFO - 2022-02-24 14:21:35 --> URI Class Initialized
DEBUG - 2022-02-24 14:21:35 --> No URI present. Default controller set.
INFO - 2022-02-24 14:21:35 --> Router Class Initialized
INFO - 2022-02-24 14:21:35 --> Output Class Initialized
INFO - 2022-02-24 14:21:35 --> Security Class Initialized
DEBUG - 2022-02-24 14:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 14:21:35 --> Input Class Initialized
INFO - 2022-02-24 14:21:35 --> Language Class Initialized
INFO - 2022-02-24 14:21:35 --> Loader Class Initialized
INFO - 2022-02-24 14:21:35 --> Helper loaded: url_helper
INFO - 2022-02-24 14:21:35 --> Helper loaded: form_helper
INFO - 2022-02-24 14:21:35 --> Helper loaded: common_helper
INFO - 2022-02-24 14:21:35 --> Database Driver Class Initialized
DEBUG - 2022-02-24 14:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 14:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 14:21:35 --> Controller Class Initialized
INFO - 2022-02-24 14:21:35 --> Form Validation Class Initialized
DEBUG - 2022-02-24 14:21:35 --> Encrypt Class Initialized
DEBUG - 2022-02-24 14:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:21:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 14:21:35 --> Email Class Initialized
INFO - 2022-02-24 14:21:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 14:21:35 --> Calendar Class Initialized
INFO - 2022-02-24 14:21:35 --> Model "Login_model" initialized
INFO - 2022-02-24 14:21:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 14:21:35 --> Final output sent to browser
DEBUG - 2022-02-24 14:21:35 --> Total execution time: 0.0318
ERROR - 2022-02-24 14:21:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 14:21:36 --> Config Class Initialized
INFO - 2022-02-24 14:21:36 --> Hooks Class Initialized
DEBUG - 2022-02-24 14:21:36 --> UTF-8 Support Enabled
INFO - 2022-02-24 14:21:36 --> Utf8 Class Initialized
INFO - 2022-02-24 14:21:36 --> URI Class Initialized
INFO - 2022-02-24 14:21:36 --> Router Class Initialized
INFO - 2022-02-24 14:21:36 --> Output Class Initialized
INFO - 2022-02-24 14:21:36 --> Security Class Initialized
DEBUG - 2022-02-24 14:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 14:21:36 --> Input Class Initialized
INFO - 2022-02-24 14:21:36 --> Language Class Initialized
ERROR - 2022-02-24 14:21:36 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-24 14:21:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 14:21:56 --> Config Class Initialized
INFO - 2022-02-24 14:21:56 --> Hooks Class Initialized
DEBUG - 2022-02-24 14:21:56 --> UTF-8 Support Enabled
INFO - 2022-02-24 14:21:56 --> Utf8 Class Initialized
INFO - 2022-02-24 14:21:56 --> URI Class Initialized
DEBUG - 2022-02-24 14:21:56 --> No URI present. Default controller set.
INFO - 2022-02-24 14:21:56 --> Router Class Initialized
INFO - 2022-02-24 14:21:56 --> Output Class Initialized
INFO - 2022-02-24 14:21:56 --> Security Class Initialized
DEBUG - 2022-02-24 14:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 14:21:56 --> Input Class Initialized
INFO - 2022-02-24 14:21:56 --> Language Class Initialized
INFO - 2022-02-24 14:21:56 --> Loader Class Initialized
INFO - 2022-02-24 14:21:56 --> Helper loaded: url_helper
INFO - 2022-02-24 14:21:56 --> Helper loaded: form_helper
INFO - 2022-02-24 14:21:56 --> Helper loaded: common_helper
INFO - 2022-02-24 14:21:56 --> Database Driver Class Initialized
DEBUG - 2022-02-24 14:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 14:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 14:21:56 --> Controller Class Initialized
INFO - 2022-02-24 14:21:56 --> Form Validation Class Initialized
DEBUG - 2022-02-24 14:21:56 --> Encrypt Class Initialized
DEBUG - 2022-02-24 14:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:21:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 14:21:56 --> Email Class Initialized
INFO - 2022-02-24 14:21:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 14:21:56 --> Calendar Class Initialized
INFO - 2022-02-24 14:21:56 --> Model "Login_model" initialized
INFO - 2022-02-24 14:21:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 14:21:56 --> Final output sent to browser
DEBUG - 2022-02-24 14:21:56 --> Total execution time: 0.0260
ERROR - 2022-02-24 14:21:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 14:21:56 --> Config Class Initialized
INFO - 2022-02-24 14:21:56 --> Hooks Class Initialized
DEBUG - 2022-02-24 14:21:56 --> UTF-8 Support Enabled
INFO - 2022-02-24 14:21:56 --> Utf8 Class Initialized
INFO - 2022-02-24 14:21:56 --> URI Class Initialized
INFO - 2022-02-24 14:21:56 --> Router Class Initialized
INFO - 2022-02-24 14:21:56 --> Output Class Initialized
INFO - 2022-02-24 14:21:56 --> Security Class Initialized
DEBUG - 2022-02-24 14:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 14:21:56 --> Input Class Initialized
INFO - 2022-02-24 14:21:56 --> Language Class Initialized
INFO - 2022-02-24 14:21:56 --> Loader Class Initialized
INFO - 2022-02-24 14:21:56 --> Helper loaded: url_helper
INFO - 2022-02-24 14:21:56 --> Helper loaded: form_helper
INFO - 2022-02-24 14:21:56 --> Helper loaded: common_helper
INFO - 2022-02-24 14:21:56 --> Database Driver Class Initialized
DEBUG - 2022-02-24 14:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 14:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 14:21:56 --> Controller Class Initialized
INFO - 2022-02-24 14:21:56 --> Form Validation Class Initialized
DEBUG - 2022-02-24 14:21:56 --> Encrypt Class Initialized
DEBUG - 2022-02-24 14:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:21:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 14:21:56 --> Email Class Initialized
INFO - 2022-02-24 14:21:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 14:21:56 --> Calendar Class Initialized
INFO - 2022-02-24 14:21:56 --> Model "Login_model" initialized
INFO - 2022-02-24 14:21:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 14:21:56 --> Final output sent to browser
DEBUG - 2022-02-24 14:21:56 --> Total execution time: 0.0264
ERROR - 2022-02-24 14:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 14:21:57 --> Config Class Initialized
INFO - 2022-02-24 14:21:57 --> Hooks Class Initialized
DEBUG - 2022-02-24 14:21:57 --> UTF-8 Support Enabled
INFO - 2022-02-24 14:21:57 --> Utf8 Class Initialized
INFO - 2022-02-24 14:21:57 --> URI Class Initialized
INFO - 2022-02-24 14:21:57 --> Router Class Initialized
INFO - 2022-02-24 14:21:57 --> Output Class Initialized
INFO - 2022-02-24 14:21:57 --> Security Class Initialized
DEBUG - 2022-02-24 14:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 14:21:57 --> Input Class Initialized
INFO - 2022-02-24 14:21:57 --> Language Class Initialized
INFO - 2022-02-24 14:21:57 --> Loader Class Initialized
INFO - 2022-02-24 14:21:57 --> Helper loaded: url_helper
INFO - 2022-02-24 14:21:57 --> Helper loaded: form_helper
INFO - 2022-02-24 14:21:57 --> Helper loaded: common_helper
INFO - 2022-02-24 14:21:57 --> Database Driver Class Initialized
DEBUG - 2022-02-24 14:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 14:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 14:21:57 --> Controller Class Initialized
INFO - 2022-02-24 14:21:57 --> Form Validation Class Initialized
DEBUG - 2022-02-24 14:21:57 --> Encrypt Class Initialized
DEBUG - 2022-02-24 14:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:21:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 14:21:57 --> Email Class Initialized
INFO - 2022-02-24 14:21:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 14:21:57 --> Calendar Class Initialized
INFO - 2022-02-24 14:21:57 --> Model "Login_model" initialized
ERROR - 2022-02-24 14:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 14:21:58 --> Config Class Initialized
INFO - 2022-02-24 14:21:58 --> Hooks Class Initialized
DEBUG - 2022-02-24 14:21:58 --> UTF-8 Support Enabled
INFO - 2022-02-24 14:21:58 --> Utf8 Class Initialized
INFO - 2022-02-24 14:21:58 --> URI Class Initialized
INFO - 2022-02-24 14:21:58 --> Router Class Initialized
INFO - 2022-02-24 14:21:58 --> Output Class Initialized
INFO - 2022-02-24 14:21:58 --> Security Class Initialized
DEBUG - 2022-02-24 14:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 14:21:58 --> Input Class Initialized
INFO - 2022-02-24 14:21:58 --> Language Class Initialized
INFO - 2022-02-24 14:21:58 --> Loader Class Initialized
INFO - 2022-02-24 14:21:58 --> Helper loaded: url_helper
INFO - 2022-02-24 14:21:58 --> Helper loaded: form_helper
INFO - 2022-02-24 14:21:58 --> Helper loaded: common_helper
INFO - 2022-02-24 14:21:58 --> Database Driver Class Initialized
DEBUG - 2022-02-24 14:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 14:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 14:21:58 --> Controller Class Initialized
INFO - 2022-02-24 14:21:58 --> Form Validation Class Initialized
DEBUG - 2022-02-24 14:21:58 --> Encrypt Class Initialized
DEBUG - 2022-02-24 14:21:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:21:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 14:21:58 --> Email Class Initialized
INFO - 2022-02-24 14:21:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 14:21:58 --> Calendar Class Initialized
INFO - 2022-02-24 14:21:58 --> Model "Login_model" initialized
ERROR - 2022-02-24 15:42:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 15:42:39 --> Config Class Initialized
INFO - 2022-02-24 15:42:39 --> Hooks Class Initialized
DEBUG - 2022-02-24 15:42:39 --> UTF-8 Support Enabled
INFO - 2022-02-24 15:42:39 --> Utf8 Class Initialized
INFO - 2022-02-24 15:42:39 --> URI Class Initialized
DEBUG - 2022-02-24 15:42:39 --> No URI present. Default controller set.
INFO - 2022-02-24 15:42:39 --> Router Class Initialized
INFO - 2022-02-24 15:42:39 --> Output Class Initialized
INFO - 2022-02-24 15:42:39 --> Security Class Initialized
DEBUG - 2022-02-24 15:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 15:42:39 --> Input Class Initialized
INFO - 2022-02-24 15:42:39 --> Language Class Initialized
INFO - 2022-02-24 15:42:39 --> Loader Class Initialized
INFO - 2022-02-24 15:42:39 --> Helper loaded: url_helper
INFO - 2022-02-24 15:42:39 --> Helper loaded: form_helper
INFO - 2022-02-24 15:42:39 --> Helper loaded: common_helper
INFO - 2022-02-24 15:42:39 --> Database Driver Class Initialized
DEBUG - 2022-02-24 15:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 15:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 15:42:39 --> Controller Class Initialized
INFO - 2022-02-24 15:42:39 --> Form Validation Class Initialized
DEBUG - 2022-02-24 15:42:39 --> Encrypt Class Initialized
DEBUG - 2022-02-24 15:42:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 15:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 15:42:39 --> Email Class Initialized
INFO - 2022-02-24 15:42:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 15:42:39 --> Calendar Class Initialized
INFO - 2022-02-24 15:42:39 --> Model "Login_model" initialized
INFO - 2022-02-24 15:42:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 15:42:39 --> Final output sent to browser
DEBUG - 2022-02-24 15:42:39 --> Total execution time: 0.0338
ERROR - 2022-02-24 16:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 16:18:58 --> Config Class Initialized
INFO - 2022-02-24 16:18:58 --> Hooks Class Initialized
DEBUG - 2022-02-24 16:18:58 --> UTF-8 Support Enabled
INFO - 2022-02-24 16:18:58 --> Utf8 Class Initialized
INFO - 2022-02-24 16:18:58 --> URI Class Initialized
DEBUG - 2022-02-24 16:18:58 --> No URI present. Default controller set.
INFO - 2022-02-24 16:18:58 --> Router Class Initialized
INFO - 2022-02-24 16:18:58 --> Output Class Initialized
INFO - 2022-02-24 16:18:58 --> Security Class Initialized
DEBUG - 2022-02-24 16:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 16:18:58 --> Input Class Initialized
INFO - 2022-02-24 16:18:58 --> Language Class Initialized
INFO - 2022-02-24 16:18:58 --> Loader Class Initialized
INFO - 2022-02-24 16:18:58 --> Helper loaded: url_helper
INFO - 2022-02-24 16:18:58 --> Helper loaded: form_helper
INFO - 2022-02-24 16:18:58 --> Helper loaded: common_helper
INFO - 2022-02-24 16:18:58 --> Database Driver Class Initialized
DEBUG - 2022-02-24 16:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 16:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 16:18:58 --> Controller Class Initialized
INFO - 2022-02-24 16:18:58 --> Form Validation Class Initialized
DEBUG - 2022-02-24 16:18:58 --> Encrypt Class Initialized
DEBUG - 2022-02-24 16:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 16:18:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 16:18:58 --> Email Class Initialized
INFO - 2022-02-24 16:18:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 16:18:58 --> Calendar Class Initialized
INFO - 2022-02-24 16:18:58 --> Model "Login_model" initialized
INFO - 2022-02-24 16:18:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 16:18:58 --> Final output sent to browser
DEBUG - 2022-02-24 16:18:58 --> Total execution time: 0.0283
ERROR - 2022-02-24 18:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:52 --> Config Class Initialized
INFO - 2022-02-24 18:30:52 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:52 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:52 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:52 --> URI Class Initialized
DEBUG - 2022-02-24 18:30:52 --> No URI present. Default controller set.
INFO - 2022-02-24 18:30:52 --> Router Class Initialized
INFO - 2022-02-24 18:30:52 --> Output Class Initialized
INFO - 2022-02-24 18:30:52 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:52 --> Input Class Initialized
INFO - 2022-02-24 18:30:52 --> Language Class Initialized
INFO - 2022-02-24 18:30:52 --> Loader Class Initialized
INFO - 2022-02-24 18:30:52 --> Helper loaded: url_helper
INFO - 2022-02-24 18:30:52 --> Helper loaded: form_helper
INFO - 2022-02-24 18:30:52 --> Helper loaded: common_helper
INFO - 2022-02-24 18:30:52 --> Database Driver Class Initialized
DEBUG - 2022-02-24 18:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 18:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 18:30:52 --> Controller Class Initialized
INFO - 2022-02-24 18:30:52 --> Form Validation Class Initialized
DEBUG - 2022-02-24 18:30:52 --> Encrypt Class Initialized
DEBUG - 2022-02-24 18:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 18:30:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 18:30:52 --> Email Class Initialized
INFO - 2022-02-24 18:30:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 18:30:52 --> Calendar Class Initialized
INFO - 2022-02-24 18:30:52 --> Model "Login_model" initialized
INFO - 2022-02-24 18:30:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 18:30:52 --> Final output sent to browser
DEBUG - 2022-02-24 18:30:52 --> Total execution time: 0.0232
ERROR - 2022-02-24 18:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:52 --> Config Class Initialized
INFO - 2022-02-24 18:30:52 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:52 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:52 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:52 --> URI Class Initialized
DEBUG - 2022-02-24 18:30:52 --> No URI present. Default controller set.
INFO - 2022-02-24 18:30:52 --> Router Class Initialized
INFO - 2022-02-24 18:30:52 --> Output Class Initialized
INFO - 2022-02-24 18:30:52 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:52 --> Input Class Initialized
INFO - 2022-02-24 18:30:52 --> Language Class Initialized
INFO - 2022-02-24 18:30:52 --> Loader Class Initialized
INFO - 2022-02-24 18:30:52 --> Helper loaded: url_helper
INFO - 2022-02-24 18:30:52 --> Helper loaded: form_helper
INFO - 2022-02-24 18:30:52 --> Helper loaded: common_helper
INFO - 2022-02-24 18:30:52 --> Database Driver Class Initialized
DEBUG - 2022-02-24 18:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-24 18:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-24 18:30:52 --> Controller Class Initialized
INFO - 2022-02-24 18:30:52 --> Form Validation Class Initialized
DEBUG - 2022-02-24 18:30:52 --> Encrypt Class Initialized
DEBUG - 2022-02-24 18:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 18:30:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-24 18:30:52 --> Email Class Initialized
INFO - 2022-02-24 18:30:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-24 18:30:52 --> Calendar Class Initialized
INFO - 2022-02-24 18:30:52 --> Model "Login_model" initialized
INFO - 2022-02-24 18:30:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-24 18:30:52 --> Final output sent to browser
DEBUG - 2022-02-24 18:30:52 --> Total execution time: 0.0234
ERROR - 2022-02-24 18:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:53 --> Config Class Initialized
INFO - 2022-02-24 18:30:53 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:53 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:53 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:53 --> URI Class Initialized
INFO - 2022-02-24 18:30:53 --> Router Class Initialized
INFO - 2022-02-24 18:30:53 --> Output Class Initialized
INFO - 2022-02-24 18:30:53 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:53 --> Input Class Initialized
INFO - 2022-02-24 18:30:53 --> Language Class Initialized
ERROR - 2022-02-24 18:30:53 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-02-24 18:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:53 --> Config Class Initialized
INFO - 2022-02-24 18:30:53 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:53 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:53 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:53 --> URI Class Initialized
INFO - 2022-02-24 18:30:53 --> Router Class Initialized
INFO - 2022-02-24 18:30:53 --> Output Class Initialized
INFO - 2022-02-24 18:30:53 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:53 --> Input Class Initialized
INFO - 2022-02-24 18:30:53 --> Language Class Initialized
ERROR - 2022-02-24 18:30:53 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-02-24 18:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:53 --> Config Class Initialized
INFO - 2022-02-24 18:30:53 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:53 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:53 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:53 --> URI Class Initialized
INFO - 2022-02-24 18:30:53 --> Router Class Initialized
INFO - 2022-02-24 18:30:53 --> Output Class Initialized
INFO - 2022-02-24 18:30:53 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:53 --> Input Class Initialized
INFO - 2022-02-24 18:30:53 --> Language Class Initialized
ERROR - 2022-02-24 18:30:53 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-02-24 18:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:54 --> Config Class Initialized
INFO - 2022-02-24 18:30:54 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:54 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:54 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:54 --> URI Class Initialized
INFO - 2022-02-24 18:30:54 --> Router Class Initialized
INFO - 2022-02-24 18:30:54 --> Output Class Initialized
INFO - 2022-02-24 18:30:54 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:54 --> Input Class Initialized
INFO - 2022-02-24 18:30:54 --> Language Class Initialized
ERROR - 2022-02-24 18:30:54 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-02-24 18:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:54 --> Config Class Initialized
INFO - 2022-02-24 18:30:54 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:54 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:54 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:54 --> URI Class Initialized
INFO - 2022-02-24 18:30:54 --> Router Class Initialized
INFO - 2022-02-24 18:30:54 --> Output Class Initialized
INFO - 2022-02-24 18:30:54 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:54 --> Input Class Initialized
INFO - 2022-02-24 18:30:54 --> Language Class Initialized
ERROR - 2022-02-24 18:30:54 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-02-24 18:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:54 --> Config Class Initialized
INFO - 2022-02-24 18:30:54 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:54 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:54 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:54 --> URI Class Initialized
INFO - 2022-02-24 18:30:54 --> Router Class Initialized
INFO - 2022-02-24 18:30:54 --> Output Class Initialized
INFO - 2022-02-24 18:30:54 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:54 --> Input Class Initialized
INFO - 2022-02-24 18:30:54 --> Language Class Initialized
ERROR - 2022-02-24 18:30:54 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-02-24 18:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:55 --> Config Class Initialized
INFO - 2022-02-24 18:30:55 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:55 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:55 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:55 --> URI Class Initialized
INFO - 2022-02-24 18:30:55 --> Router Class Initialized
INFO - 2022-02-24 18:30:55 --> Output Class Initialized
INFO - 2022-02-24 18:30:55 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:55 --> Input Class Initialized
INFO - 2022-02-24 18:30:55 --> Language Class Initialized
ERROR - 2022-02-24 18:30:55 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2022-02-24 18:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:55 --> Config Class Initialized
INFO - 2022-02-24 18:30:55 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:55 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:55 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:55 --> URI Class Initialized
INFO - 2022-02-24 18:30:55 --> Router Class Initialized
INFO - 2022-02-24 18:30:55 --> Output Class Initialized
INFO - 2022-02-24 18:30:55 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:55 --> Input Class Initialized
INFO - 2022-02-24 18:30:55 --> Language Class Initialized
ERROR - 2022-02-24 18:30:55 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-02-24 18:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:55 --> Config Class Initialized
INFO - 2022-02-24 18:30:55 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:55 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:55 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:55 --> URI Class Initialized
INFO - 2022-02-24 18:30:55 --> Router Class Initialized
INFO - 2022-02-24 18:30:55 --> Output Class Initialized
INFO - 2022-02-24 18:30:55 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:55 --> Input Class Initialized
INFO - 2022-02-24 18:30:55 --> Language Class Initialized
ERROR - 2022-02-24 18:30:55 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-02-24 18:30:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:56 --> Config Class Initialized
INFO - 2022-02-24 18:30:56 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:56 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:56 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:56 --> URI Class Initialized
INFO - 2022-02-24 18:30:56 --> Router Class Initialized
INFO - 2022-02-24 18:30:56 --> Output Class Initialized
INFO - 2022-02-24 18:30:56 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:56 --> Input Class Initialized
INFO - 2022-02-24 18:30:56 --> Language Class Initialized
ERROR - 2022-02-24 18:30:56 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-02-24 18:30:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:56 --> Config Class Initialized
INFO - 2022-02-24 18:30:56 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:56 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:56 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:56 --> URI Class Initialized
INFO - 2022-02-24 18:30:56 --> Router Class Initialized
INFO - 2022-02-24 18:30:56 --> Output Class Initialized
INFO - 2022-02-24 18:30:56 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:56 --> Input Class Initialized
INFO - 2022-02-24 18:30:56 --> Language Class Initialized
ERROR - 2022-02-24 18:30:56 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-02-24 18:30:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:56 --> Config Class Initialized
INFO - 2022-02-24 18:30:56 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:56 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:56 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:56 --> URI Class Initialized
INFO - 2022-02-24 18:30:56 --> Router Class Initialized
INFO - 2022-02-24 18:30:56 --> Output Class Initialized
INFO - 2022-02-24 18:30:56 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:56 --> Input Class Initialized
INFO - 2022-02-24 18:30:56 --> Language Class Initialized
ERROR - 2022-02-24 18:30:56 --> 404 Page Not Found: Media/wp-includes
ERROR - 2022-02-24 18:30:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:57 --> Config Class Initialized
INFO - 2022-02-24 18:30:57 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:57 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:57 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:57 --> URI Class Initialized
INFO - 2022-02-24 18:30:57 --> Router Class Initialized
INFO - 2022-02-24 18:30:57 --> Output Class Initialized
INFO - 2022-02-24 18:30:57 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:57 --> Input Class Initialized
INFO - 2022-02-24 18:30:57 --> Language Class Initialized
ERROR - 2022-02-24 18:30:57 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-02-24 18:30:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:57 --> Config Class Initialized
INFO - 2022-02-24 18:30:57 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:57 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:57 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:57 --> URI Class Initialized
INFO - 2022-02-24 18:30:57 --> Router Class Initialized
INFO - 2022-02-24 18:30:57 --> Output Class Initialized
INFO - 2022-02-24 18:30:57 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:57 --> Input Class Initialized
INFO - 2022-02-24 18:30:57 --> Language Class Initialized
ERROR - 2022-02-24 18:30:57 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-02-24 18:30:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:57 --> Config Class Initialized
INFO - 2022-02-24 18:30:57 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:57 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:57 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:57 --> URI Class Initialized
INFO - 2022-02-24 18:30:57 --> Router Class Initialized
INFO - 2022-02-24 18:30:57 --> Output Class Initialized
INFO - 2022-02-24 18:30:57 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:57 --> Input Class Initialized
INFO - 2022-02-24 18:30:57 --> Language Class Initialized
ERROR - 2022-02-24 18:30:57 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-02-24 18:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-24 18:30:58 --> Config Class Initialized
INFO - 2022-02-24 18:30:58 --> Hooks Class Initialized
DEBUG - 2022-02-24 18:30:58 --> UTF-8 Support Enabled
INFO - 2022-02-24 18:30:58 --> Utf8 Class Initialized
INFO - 2022-02-24 18:30:58 --> URI Class Initialized
INFO - 2022-02-24 18:30:58 --> Router Class Initialized
INFO - 2022-02-24 18:30:58 --> Output Class Initialized
INFO - 2022-02-24 18:30:58 --> Security Class Initialized
DEBUG - 2022-02-24 18:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-24 18:30:58 --> Input Class Initialized
INFO - 2022-02-24 18:30:58 --> Language Class Initialized
ERROR - 2022-02-24 18:30:58 --> 404 Page Not Found: Sito/wp-includes
