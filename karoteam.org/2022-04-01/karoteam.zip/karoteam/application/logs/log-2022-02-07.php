<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-07 09:22:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 09:22:19 --> Config Class Initialized
INFO - 2022-02-07 09:22:19 --> Hooks Class Initialized
DEBUG - 2022-02-07 09:22:19 --> UTF-8 Support Enabled
INFO - 2022-02-07 09:22:19 --> Utf8 Class Initialized
INFO - 2022-02-07 09:22:19 --> URI Class Initialized
DEBUG - 2022-02-07 09:22:19 --> No URI present. Default controller set.
INFO - 2022-02-07 09:22:19 --> Router Class Initialized
INFO - 2022-02-07 09:22:19 --> Output Class Initialized
INFO - 2022-02-07 09:22:19 --> Security Class Initialized
DEBUG - 2022-02-07 09:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 09:22:19 --> Input Class Initialized
INFO - 2022-02-07 09:22:19 --> Language Class Initialized
INFO - 2022-02-07 09:22:19 --> Loader Class Initialized
INFO - 2022-02-07 09:22:19 --> Helper loaded: url_helper
INFO - 2022-02-07 09:22:19 --> Helper loaded: form_helper
INFO - 2022-02-07 09:22:19 --> Helper loaded: common_helper
INFO - 2022-02-07 09:22:19 --> Database Driver Class Initialized
DEBUG - 2022-02-07 09:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 09:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 09:22:19 --> Controller Class Initialized
INFO - 2022-02-07 09:22:19 --> Form Validation Class Initialized
DEBUG - 2022-02-07 09:22:19 --> Encrypt Class Initialized
DEBUG - 2022-02-07 09:22:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 09:22:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 09:22:19 --> Email Class Initialized
INFO - 2022-02-07 09:22:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 09:22:19 --> Calendar Class Initialized
INFO - 2022-02-07 09:22:19 --> Model "Login_model" initialized
INFO - 2022-02-07 09:22:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-07 09:22:19 --> Final output sent to browser
DEBUG - 2022-02-07 09:22:19 --> Total execution time: 0.0415
ERROR - 2022-02-07 10:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 10:40:38 --> Config Class Initialized
INFO - 2022-02-07 10:40:38 --> Hooks Class Initialized
DEBUG - 2022-02-07 10:40:38 --> UTF-8 Support Enabled
INFO - 2022-02-07 10:40:38 --> Utf8 Class Initialized
INFO - 2022-02-07 10:40:38 --> URI Class Initialized
DEBUG - 2022-02-07 10:40:38 --> No URI present. Default controller set.
INFO - 2022-02-07 10:40:38 --> Router Class Initialized
INFO - 2022-02-07 10:40:38 --> Output Class Initialized
INFO - 2022-02-07 10:40:38 --> Security Class Initialized
DEBUG - 2022-02-07 10:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 10:40:38 --> Input Class Initialized
INFO - 2022-02-07 10:40:38 --> Language Class Initialized
INFO - 2022-02-07 10:40:38 --> Loader Class Initialized
INFO - 2022-02-07 10:40:38 --> Helper loaded: url_helper
INFO - 2022-02-07 10:40:38 --> Helper loaded: form_helper
INFO - 2022-02-07 10:40:38 --> Helper loaded: common_helper
INFO - 2022-02-07 10:40:38 --> Database Driver Class Initialized
DEBUG - 2022-02-07 10:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 10:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 10:40:38 --> Controller Class Initialized
INFO - 2022-02-07 10:40:38 --> Form Validation Class Initialized
DEBUG - 2022-02-07 10:40:38 --> Encrypt Class Initialized
DEBUG - 2022-02-07 10:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:40:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 10:40:38 --> Email Class Initialized
INFO - 2022-02-07 10:40:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 10:40:38 --> Calendar Class Initialized
INFO - 2022-02-07 10:40:38 --> Model "Login_model" initialized
INFO - 2022-02-07 10:40:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-07 10:40:38 --> Final output sent to browser
DEBUG - 2022-02-07 10:40:38 --> Total execution time: 0.0366
ERROR - 2022-02-07 10:41:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 10:41:33 --> Config Class Initialized
INFO - 2022-02-07 10:41:33 --> Hooks Class Initialized
DEBUG - 2022-02-07 10:41:33 --> UTF-8 Support Enabled
INFO - 2022-02-07 10:41:33 --> Utf8 Class Initialized
INFO - 2022-02-07 10:41:33 --> URI Class Initialized
DEBUG - 2022-02-07 10:41:33 --> No URI present. Default controller set.
INFO - 2022-02-07 10:41:33 --> Router Class Initialized
INFO - 2022-02-07 10:41:33 --> Output Class Initialized
INFO - 2022-02-07 10:41:33 --> Security Class Initialized
DEBUG - 2022-02-07 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 10:41:33 --> Input Class Initialized
INFO - 2022-02-07 10:41:33 --> Language Class Initialized
INFO - 2022-02-07 10:41:33 --> Loader Class Initialized
INFO - 2022-02-07 10:41:33 --> Helper loaded: url_helper
INFO - 2022-02-07 10:41:33 --> Helper loaded: form_helper
INFO - 2022-02-07 10:41:33 --> Helper loaded: common_helper
INFO - 2022-02-07 10:41:33 --> Database Driver Class Initialized
DEBUG - 2022-02-07 10:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 10:41:33 --> Controller Class Initialized
INFO - 2022-02-07 10:41:33 --> Form Validation Class Initialized
DEBUG - 2022-02-07 10:41:33 --> Encrypt Class Initialized
DEBUG - 2022-02-07 10:41:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 10:41:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 10:41:33 --> Email Class Initialized
INFO - 2022-02-07 10:41:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 10:41:33 --> Calendar Class Initialized
INFO - 2022-02-07 10:41:33 --> Model "Login_model" initialized
INFO - 2022-02-07 10:41:33 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-07 10:41:33 --> Final output sent to browser
DEBUG - 2022-02-07 10:41:33 --> Total execution time: 0.0283
ERROR - 2022-02-07 14:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 14:03:54 --> Config Class Initialized
INFO - 2022-02-07 14:03:54 --> Hooks Class Initialized
DEBUG - 2022-02-07 14:03:54 --> UTF-8 Support Enabled
INFO - 2022-02-07 14:03:54 --> Utf8 Class Initialized
INFO - 2022-02-07 14:03:54 --> URI Class Initialized
DEBUG - 2022-02-07 14:03:54 --> No URI present. Default controller set.
INFO - 2022-02-07 14:03:54 --> Router Class Initialized
INFO - 2022-02-07 14:03:54 --> Output Class Initialized
INFO - 2022-02-07 14:03:54 --> Security Class Initialized
DEBUG - 2022-02-07 14:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 14:03:54 --> Input Class Initialized
INFO - 2022-02-07 14:03:54 --> Language Class Initialized
INFO - 2022-02-07 14:03:54 --> Loader Class Initialized
INFO - 2022-02-07 14:03:54 --> Helper loaded: url_helper
INFO - 2022-02-07 14:03:54 --> Helper loaded: form_helper
INFO - 2022-02-07 14:03:54 --> Helper loaded: common_helper
INFO - 2022-02-07 14:03:54 --> Database Driver Class Initialized
DEBUG - 2022-02-07 14:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 14:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 14:03:54 --> Controller Class Initialized
INFO - 2022-02-07 14:03:54 --> Form Validation Class Initialized
DEBUG - 2022-02-07 14:03:54 --> Encrypt Class Initialized
DEBUG - 2022-02-07 14:03:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:03:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 14:03:54 --> Email Class Initialized
INFO - 2022-02-07 14:03:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 14:03:54 --> Calendar Class Initialized
INFO - 2022-02-07 14:03:54 --> Model "Login_model" initialized
INFO - 2022-02-07 14:03:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-07 14:03:54 --> Final output sent to browser
DEBUG - 2022-02-07 14:03:54 --> Total execution time: 0.0411
ERROR - 2022-02-07 14:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 14:20:57 --> Config Class Initialized
INFO - 2022-02-07 14:20:57 --> Hooks Class Initialized
DEBUG - 2022-02-07 14:20:57 --> UTF-8 Support Enabled
INFO - 2022-02-07 14:20:57 --> Utf8 Class Initialized
INFO - 2022-02-07 14:20:57 --> URI Class Initialized
DEBUG - 2022-02-07 14:20:57 --> No URI present. Default controller set.
INFO - 2022-02-07 14:20:57 --> Router Class Initialized
INFO - 2022-02-07 14:20:57 --> Output Class Initialized
INFO - 2022-02-07 14:20:57 --> Security Class Initialized
DEBUG - 2022-02-07 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 14:20:57 --> Input Class Initialized
INFO - 2022-02-07 14:20:57 --> Language Class Initialized
INFO - 2022-02-07 14:20:57 --> Loader Class Initialized
INFO - 2022-02-07 14:20:57 --> Helper loaded: url_helper
INFO - 2022-02-07 14:20:57 --> Helper loaded: form_helper
INFO - 2022-02-07 14:20:57 --> Helper loaded: common_helper
INFO - 2022-02-07 14:20:57 --> Database Driver Class Initialized
DEBUG - 2022-02-07 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 14:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 14:20:57 --> Controller Class Initialized
INFO - 2022-02-07 14:20:57 --> Form Validation Class Initialized
DEBUG - 2022-02-07 14:20:57 --> Encrypt Class Initialized
DEBUG - 2022-02-07 14:20:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:20:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 14:20:57 --> Email Class Initialized
INFO - 2022-02-07 14:20:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 14:20:57 --> Calendar Class Initialized
INFO - 2022-02-07 14:20:57 --> Model "Login_model" initialized
INFO - 2022-02-07 14:20:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-07 14:20:57 --> Final output sent to browser
DEBUG - 2022-02-07 14:20:57 --> Total execution time: 0.0390
ERROR - 2022-02-07 14:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 14:20:57 --> Config Class Initialized
INFO - 2022-02-07 14:20:57 --> Hooks Class Initialized
DEBUG - 2022-02-07 14:20:57 --> UTF-8 Support Enabled
INFO - 2022-02-07 14:20:57 --> Utf8 Class Initialized
INFO - 2022-02-07 14:20:57 --> URI Class Initialized
INFO - 2022-02-07 14:20:57 --> Router Class Initialized
INFO - 2022-02-07 14:20:57 --> Output Class Initialized
INFO - 2022-02-07 14:20:57 --> Security Class Initialized
DEBUG - 2022-02-07 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 14:20:57 --> Input Class Initialized
INFO - 2022-02-07 14:20:57 --> Language Class Initialized
ERROR - 2022-02-07 14:20:57 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-07 14:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 14:21:07 --> Config Class Initialized
INFO - 2022-02-07 14:21:07 --> Hooks Class Initialized
DEBUG - 2022-02-07 14:21:07 --> UTF-8 Support Enabled
INFO - 2022-02-07 14:21:07 --> Utf8 Class Initialized
INFO - 2022-02-07 14:21:07 --> URI Class Initialized
DEBUG - 2022-02-07 14:21:07 --> No URI present. Default controller set.
INFO - 2022-02-07 14:21:07 --> Router Class Initialized
INFO - 2022-02-07 14:21:07 --> Output Class Initialized
INFO - 2022-02-07 14:21:07 --> Security Class Initialized
DEBUG - 2022-02-07 14:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 14:21:07 --> Input Class Initialized
INFO - 2022-02-07 14:21:07 --> Language Class Initialized
INFO - 2022-02-07 14:21:07 --> Loader Class Initialized
INFO - 2022-02-07 14:21:07 --> Helper loaded: url_helper
INFO - 2022-02-07 14:21:07 --> Helper loaded: form_helper
INFO - 2022-02-07 14:21:07 --> Helper loaded: common_helper
INFO - 2022-02-07 14:21:07 --> Database Driver Class Initialized
DEBUG - 2022-02-07 14:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 14:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 14:21:07 --> Controller Class Initialized
INFO - 2022-02-07 14:21:07 --> Form Validation Class Initialized
DEBUG - 2022-02-07 14:21:07 --> Encrypt Class Initialized
DEBUG - 2022-02-07 14:21:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:21:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 14:21:07 --> Email Class Initialized
INFO - 2022-02-07 14:21:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 14:21:07 --> Calendar Class Initialized
INFO - 2022-02-07 14:21:07 --> Model "Login_model" initialized
INFO - 2022-02-07 14:21:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-07 14:21:07 --> Final output sent to browser
DEBUG - 2022-02-07 14:21:07 --> Total execution time: 0.0356
ERROR - 2022-02-07 14:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 14:21:07 --> Config Class Initialized
INFO - 2022-02-07 14:21:07 --> Hooks Class Initialized
DEBUG - 2022-02-07 14:21:07 --> UTF-8 Support Enabled
INFO - 2022-02-07 14:21:07 --> Utf8 Class Initialized
INFO - 2022-02-07 14:21:07 --> URI Class Initialized
INFO - 2022-02-07 14:21:07 --> Router Class Initialized
INFO - 2022-02-07 14:21:07 --> Output Class Initialized
INFO - 2022-02-07 14:21:07 --> Security Class Initialized
DEBUG - 2022-02-07 14:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 14:21:07 --> Input Class Initialized
INFO - 2022-02-07 14:21:07 --> Language Class Initialized
INFO - 2022-02-07 14:21:07 --> Loader Class Initialized
INFO - 2022-02-07 14:21:08 --> Helper loaded: url_helper
INFO - 2022-02-07 14:21:08 --> Helper loaded: form_helper
INFO - 2022-02-07 14:21:08 --> Helper loaded: common_helper
INFO - 2022-02-07 14:21:08 --> Database Driver Class Initialized
DEBUG - 2022-02-07 14:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 14:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 14:21:08 --> Controller Class Initialized
INFO - 2022-02-07 14:21:08 --> Form Validation Class Initialized
DEBUG - 2022-02-07 14:21:08 --> Encrypt Class Initialized
DEBUG - 2022-02-07 14:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:21:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 14:21:08 --> Email Class Initialized
INFO - 2022-02-07 14:21:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 14:21:08 --> Calendar Class Initialized
INFO - 2022-02-07 14:21:08 --> Model "Login_model" initialized
INFO - 2022-02-07 14:21:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-07 14:21:08 --> Final output sent to browser
DEBUG - 2022-02-07 14:21:08 --> Total execution time: 0.0571
ERROR - 2022-02-07 14:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 14:21:09 --> Config Class Initialized
INFO - 2022-02-07 14:21:09 --> Hooks Class Initialized
DEBUG - 2022-02-07 14:21:09 --> UTF-8 Support Enabled
INFO - 2022-02-07 14:21:09 --> Utf8 Class Initialized
INFO - 2022-02-07 14:21:09 --> URI Class Initialized
INFO - 2022-02-07 14:21:09 --> Router Class Initialized
INFO - 2022-02-07 14:21:09 --> Output Class Initialized
INFO - 2022-02-07 14:21:09 --> Security Class Initialized
DEBUG - 2022-02-07 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 14:21:09 --> Input Class Initialized
INFO - 2022-02-07 14:21:09 --> Language Class Initialized
INFO - 2022-02-07 14:21:09 --> Loader Class Initialized
INFO - 2022-02-07 14:21:09 --> Helper loaded: url_helper
INFO - 2022-02-07 14:21:09 --> Helper loaded: form_helper
INFO - 2022-02-07 14:21:09 --> Helper loaded: common_helper
INFO - 2022-02-07 14:21:09 --> Database Driver Class Initialized
DEBUG - 2022-02-07 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 14:21:09 --> Controller Class Initialized
INFO - 2022-02-07 14:21:09 --> Form Validation Class Initialized
DEBUG - 2022-02-07 14:21:09 --> Encrypt Class Initialized
DEBUG - 2022-02-07 14:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:21:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 14:21:09 --> Email Class Initialized
INFO - 2022-02-07 14:21:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 14:21:09 --> Calendar Class Initialized
INFO - 2022-02-07 14:21:09 --> Model "Login_model" initialized
ERROR - 2022-02-07 14:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 14:21:10 --> Config Class Initialized
INFO - 2022-02-07 14:21:10 --> Hooks Class Initialized
DEBUG - 2022-02-07 14:21:10 --> UTF-8 Support Enabled
INFO - 2022-02-07 14:21:10 --> Utf8 Class Initialized
INFO - 2022-02-07 14:21:10 --> URI Class Initialized
INFO - 2022-02-07 14:21:10 --> Router Class Initialized
INFO - 2022-02-07 14:21:10 --> Output Class Initialized
INFO - 2022-02-07 14:21:10 --> Security Class Initialized
DEBUG - 2022-02-07 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 14:21:10 --> Input Class Initialized
INFO - 2022-02-07 14:21:10 --> Language Class Initialized
INFO - 2022-02-07 14:21:10 --> Loader Class Initialized
INFO - 2022-02-07 14:21:10 --> Helper loaded: url_helper
INFO - 2022-02-07 14:21:10 --> Helper loaded: form_helper
INFO - 2022-02-07 14:21:10 --> Helper loaded: common_helper
INFO - 2022-02-07 14:21:10 --> Database Driver Class Initialized
DEBUG - 2022-02-07 14:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 14:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 14:21:10 --> Controller Class Initialized
INFO - 2022-02-07 14:21:10 --> Form Validation Class Initialized
DEBUG - 2022-02-07 14:21:10 --> Encrypt Class Initialized
DEBUG - 2022-02-07 14:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 14:21:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 14:21:10 --> Email Class Initialized
INFO - 2022-02-07 14:21:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 14:21:10 --> Calendar Class Initialized
INFO - 2022-02-07 14:21:10 --> Model "Login_model" initialized
ERROR - 2022-02-07 15:39:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-07 15:39:39 --> Config Class Initialized
INFO - 2022-02-07 15:39:39 --> Hooks Class Initialized
DEBUG - 2022-02-07 15:39:39 --> UTF-8 Support Enabled
INFO - 2022-02-07 15:39:39 --> Utf8 Class Initialized
INFO - 2022-02-07 15:39:39 --> URI Class Initialized
DEBUG - 2022-02-07 15:39:39 --> No URI present. Default controller set.
INFO - 2022-02-07 15:39:39 --> Router Class Initialized
INFO - 2022-02-07 15:39:39 --> Output Class Initialized
INFO - 2022-02-07 15:39:39 --> Security Class Initialized
DEBUG - 2022-02-07 15:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-07 15:39:39 --> Input Class Initialized
INFO - 2022-02-07 15:39:39 --> Language Class Initialized
INFO - 2022-02-07 15:39:39 --> Loader Class Initialized
INFO - 2022-02-07 15:39:39 --> Helper loaded: url_helper
INFO - 2022-02-07 15:39:39 --> Helper loaded: form_helper
INFO - 2022-02-07 15:39:39 --> Helper loaded: common_helper
INFO - 2022-02-07 15:39:39 --> Database Driver Class Initialized
DEBUG - 2022-02-07 15:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-07 15:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-07 15:39:39 --> Controller Class Initialized
INFO - 2022-02-07 15:39:39 --> Form Validation Class Initialized
DEBUG - 2022-02-07 15:39:39 --> Encrypt Class Initialized
DEBUG - 2022-02-07 15:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-07 15:39:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-07 15:39:39 --> Email Class Initialized
INFO - 2022-02-07 15:39:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-07 15:39:39 --> Calendar Class Initialized
INFO - 2022-02-07 15:39:39 --> Model "Login_model" initialized
INFO - 2022-02-07 15:39:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-07 15:39:39 --> Final output sent to browser
DEBUG - 2022-02-07 15:39:39 --> Total execution time: 0.0578
