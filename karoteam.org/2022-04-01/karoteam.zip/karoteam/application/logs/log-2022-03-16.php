<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-16 00:24:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:24:34 --> Config Class Initialized
INFO - 2022-03-16 00:24:34 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:24:34 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:24:34 --> Utf8 Class Initialized
INFO - 2022-03-16 00:24:34 --> URI Class Initialized
DEBUG - 2022-03-16 00:24:34 --> No URI present. Default controller set.
INFO - 2022-03-16 00:24:34 --> Router Class Initialized
INFO - 2022-03-16 00:24:34 --> Output Class Initialized
INFO - 2022-03-16 00:24:34 --> Security Class Initialized
DEBUG - 2022-03-16 00:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:24:34 --> Input Class Initialized
INFO - 2022-03-16 00:24:34 --> Language Class Initialized
INFO - 2022-03-16 00:24:34 --> Loader Class Initialized
INFO - 2022-03-16 00:24:34 --> Helper loaded: url_helper
INFO - 2022-03-16 00:24:34 --> Helper loaded: form_helper
INFO - 2022-03-16 00:24:34 --> Helper loaded: common_helper
INFO - 2022-03-16 00:24:34 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:24:34 --> Controller Class Initialized
INFO - 2022-03-16 00:24:34 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:24:34 --> Encrypt Class Initialized
DEBUG - 2022-03-16 00:24:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 00:24:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 00:24:34 --> Email Class Initialized
INFO - 2022-03-16 00:24:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 00:24:34 --> Calendar Class Initialized
INFO - 2022-03-16 00:24:34 --> Model "Login_model" initialized
INFO - 2022-03-16 00:24:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 00:24:34 --> Final output sent to browser
DEBUG - 2022-03-16 00:24:34 --> Total execution time: 0.0308
ERROR - 2022-03-16 00:24:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:24:51 --> Config Class Initialized
INFO - 2022-03-16 00:24:51 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:24:51 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:24:51 --> Utf8 Class Initialized
INFO - 2022-03-16 00:24:51 --> URI Class Initialized
INFO - 2022-03-16 00:24:51 --> Router Class Initialized
INFO - 2022-03-16 00:24:51 --> Output Class Initialized
INFO - 2022-03-16 00:24:51 --> Security Class Initialized
DEBUG - 2022-03-16 00:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:24:51 --> Input Class Initialized
INFO - 2022-03-16 00:24:51 --> Language Class Initialized
INFO - 2022-03-16 00:24:51 --> Loader Class Initialized
INFO - 2022-03-16 00:24:51 --> Helper loaded: url_helper
INFO - 2022-03-16 00:24:51 --> Helper loaded: form_helper
INFO - 2022-03-16 00:24:51 --> Helper loaded: common_helper
INFO - 2022-03-16 00:24:51 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:24:51 --> Controller Class Initialized
INFO - 2022-03-16 00:24:51 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:24:51 --> Encrypt Class Initialized
DEBUG - 2022-03-16 00:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 00:24:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 00:24:51 --> Email Class Initialized
INFO - 2022-03-16 00:24:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 00:24:51 --> Calendar Class Initialized
INFO - 2022-03-16 00:24:51 --> Model "Login_model" initialized
INFO - 2022-03-16 00:24:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-16 00:24:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:24:52 --> Config Class Initialized
INFO - 2022-03-16 00:24:52 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:24:52 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:24:52 --> Utf8 Class Initialized
INFO - 2022-03-16 00:24:52 --> URI Class Initialized
INFO - 2022-03-16 00:24:52 --> Router Class Initialized
INFO - 2022-03-16 00:24:52 --> Output Class Initialized
INFO - 2022-03-16 00:24:52 --> Security Class Initialized
DEBUG - 2022-03-16 00:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:24:52 --> Input Class Initialized
INFO - 2022-03-16 00:24:52 --> Language Class Initialized
INFO - 2022-03-16 00:24:52 --> Loader Class Initialized
INFO - 2022-03-16 00:24:52 --> Helper loaded: url_helper
INFO - 2022-03-16 00:24:52 --> Helper loaded: form_helper
INFO - 2022-03-16 00:24:52 --> Helper loaded: common_helper
INFO - 2022-03-16 00:24:52 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:24:52 --> Controller Class Initialized
INFO - 2022-03-16 00:24:52 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:24:52 --> Encrypt Class Initialized
INFO - 2022-03-16 00:24:52 --> Model "Login_model" initialized
INFO - 2022-03-16 00:24:52 --> Model "Dashboard_model" initialized
INFO - 2022-03-16 00:24:52 --> Model "Case_model" initialized
INFO - 2022-03-16 00:25:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 00:25:28 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-16 00:25:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 00:25:28 --> Final output sent to browser
DEBUG - 2022-03-16 00:25:28 --> Total execution time: 35.8655
ERROR - 2022-03-16 00:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:25:29 --> Config Class Initialized
INFO - 2022-03-16 00:25:29 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:25:29 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:25:29 --> Utf8 Class Initialized
INFO - 2022-03-16 00:25:29 --> URI Class Initialized
INFO - 2022-03-16 00:25:29 --> Router Class Initialized
INFO - 2022-03-16 00:25:29 --> Output Class Initialized
INFO - 2022-03-16 00:25:29 --> Security Class Initialized
DEBUG - 2022-03-16 00:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:25:29 --> Input Class Initialized
INFO - 2022-03-16 00:25:29 --> Language Class Initialized
ERROR - 2022-03-16 00:25:29 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 00:25:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:25:35 --> Config Class Initialized
INFO - 2022-03-16 00:25:35 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:25:35 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:25:35 --> Utf8 Class Initialized
INFO - 2022-03-16 00:25:35 --> URI Class Initialized
INFO - 2022-03-16 00:25:35 --> Router Class Initialized
INFO - 2022-03-16 00:25:35 --> Output Class Initialized
INFO - 2022-03-16 00:25:35 --> Security Class Initialized
DEBUG - 2022-03-16 00:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:25:35 --> Input Class Initialized
INFO - 2022-03-16 00:25:35 --> Language Class Initialized
INFO - 2022-03-16 00:25:35 --> Loader Class Initialized
INFO - 2022-03-16 00:25:35 --> Helper loaded: url_helper
INFO - 2022-03-16 00:25:35 --> Helper loaded: form_helper
INFO - 2022-03-16 00:25:35 --> Helper loaded: common_helper
INFO - 2022-03-16 00:25:35 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:25:35 --> Controller Class Initialized
INFO - 2022-03-16 00:25:35 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:25:35 --> Encrypt Class Initialized
INFO - 2022-03-16 00:25:35 --> Model "Patient_model" initialized
INFO - 2022-03-16 00:25:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 00:25:35 --> Model "Referredby_model" initialized
INFO - 2022-03-16 00:25:35 --> Model "Prefix_master" initialized
INFO - 2022-03-16 00:25:35 --> Model "Hospital_model" initialized
INFO - 2022-03-16 00:25:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 00:25:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 00:25:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-16 00:25:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:25:51 --> Config Class Initialized
INFO - 2022-03-16 00:25:51 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:25:51 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:25:51 --> Utf8 Class Initialized
INFO - 2022-03-16 00:25:51 --> URI Class Initialized
INFO - 2022-03-16 00:25:51 --> Router Class Initialized
INFO - 2022-03-16 00:25:51 --> Output Class Initialized
INFO - 2022-03-16 00:25:51 --> Security Class Initialized
DEBUG - 2022-03-16 00:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:25:51 --> Input Class Initialized
INFO - 2022-03-16 00:25:51 --> Language Class Initialized
ERROR - 2022-03-16 00:25:51 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-16 00:25:54 --> Final output sent to browser
DEBUG - 2022-03-16 00:25:54 --> Total execution time: 13.4581
ERROR - 2022-03-16 00:26:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:26:33 --> Config Class Initialized
INFO - 2022-03-16 00:26:33 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:26:33 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:26:33 --> Utf8 Class Initialized
INFO - 2022-03-16 00:26:33 --> URI Class Initialized
INFO - 2022-03-16 00:26:33 --> Router Class Initialized
INFO - 2022-03-16 00:26:33 --> Output Class Initialized
INFO - 2022-03-16 00:26:33 --> Security Class Initialized
DEBUG - 2022-03-16 00:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:26:33 --> Input Class Initialized
INFO - 2022-03-16 00:26:33 --> Language Class Initialized
INFO - 2022-03-16 00:26:33 --> Loader Class Initialized
INFO - 2022-03-16 00:26:33 --> Helper loaded: url_helper
INFO - 2022-03-16 00:26:33 --> Helper loaded: form_helper
INFO - 2022-03-16 00:26:33 --> Helper loaded: common_helper
INFO - 2022-03-16 00:26:33 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:26:33 --> Controller Class Initialized
INFO - 2022-03-16 00:26:33 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:26:33 --> Encrypt Class Initialized
INFO - 2022-03-16 00:26:33 --> Model "Patient_model" initialized
INFO - 2022-03-16 00:26:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 00:26:33 --> Model "Prefix_master" initialized
INFO - 2022-03-16 00:26:33 --> Model "Users_model" initialized
INFO - 2022-03-16 00:26:33 --> Model "Hospital_model" initialized
INFO - 2022-03-16 00:26:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 00:26:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 00:26:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 00:26:34 --> Final output sent to browser
DEBUG - 2022-03-16 00:26:34 --> Total execution time: 0.5539
ERROR - 2022-03-16 00:26:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:26:35 --> Config Class Initialized
INFO - 2022-03-16 00:26:35 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:26:35 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:26:35 --> Utf8 Class Initialized
INFO - 2022-03-16 00:26:35 --> URI Class Initialized
INFO - 2022-03-16 00:26:35 --> Router Class Initialized
INFO - 2022-03-16 00:26:35 --> Output Class Initialized
INFO - 2022-03-16 00:26:35 --> Security Class Initialized
DEBUG - 2022-03-16 00:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:26:35 --> Input Class Initialized
INFO - 2022-03-16 00:26:35 --> Language Class Initialized
ERROR - 2022-03-16 00:26:35 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 00:30:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:30:28 --> Config Class Initialized
INFO - 2022-03-16 00:30:28 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:30:28 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:30:28 --> Utf8 Class Initialized
INFO - 2022-03-16 00:30:28 --> URI Class Initialized
DEBUG - 2022-03-16 00:30:28 --> No URI present. Default controller set.
INFO - 2022-03-16 00:30:28 --> Router Class Initialized
INFO - 2022-03-16 00:30:28 --> Output Class Initialized
INFO - 2022-03-16 00:30:28 --> Security Class Initialized
DEBUG - 2022-03-16 00:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:30:28 --> Input Class Initialized
INFO - 2022-03-16 00:30:28 --> Language Class Initialized
INFO - 2022-03-16 00:30:28 --> Loader Class Initialized
INFO - 2022-03-16 00:30:28 --> Helper loaded: url_helper
INFO - 2022-03-16 00:30:28 --> Helper loaded: form_helper
INFO - 2022-03-16 00:30:28 --> Helper loaded: common_helper
INFO - 2022-03-16 00:30:28 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:30:28 --> Controller Class Initialized
INFO - 2022-03-16 00:30:28 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:30:28 --> Encrypt Class Initialized
DEBUG - 2022-03-16 00:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 00:30:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 00:30:28 --> Email Class Initialized
INFO - 2022-03-16 00:30:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 00:30:28 --> Calendar Class Initialized
INFO - 2022-03-16 00:30:28 --> Model "Login_model" initialized
INFO - 2022-03-16 00:30:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 00:30:28 --> Final output sent to browser
DEBUG - 2022-03-16 00:30:28 --> Total execution time: 0.0345
ERROR - 2022-03-16 00:33:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:33:52 --> Config Class Initialized
INFO - 2022-03-16 00:33:52 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:33:52 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:33:52 --> Utf8 Class Initialized
INFO - 2022-03-16 00:33:52 --> URI Class Initialized
INFO - 2022-03-16 00:33:52 --> Router Class Initialized
INFO - 2022-03-16 00:33:52 --> Output Class Initialized
INFO - 2022-03-16 00:33:52 --> Security Class Initialized
DEBUG - 2022-03-16 00:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:33:52 --> Input Class Initialized
INFO - 2022-03-16 00:33:52 --> Language Class Initialized
INFO - 2022-03-16 00:33:52 --> Loader Class Initialized
INFO - 2022-03-16 00:33:52 --> Helper loaded: url_helper
INFO - 2022-03-16 00:33:52 --> Helper loaded: form_helper
INFO - 2022-03-16 00:33:52 --> Helper loaded: common_helper
INFO - 2022-03-16 00:33:52 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:33:52 --> Controller Class Initialized
INFO - 2022-03-16 00:33:52 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:33:52 --> Encrypt Class Initialized
INFO - 2022-03-16 00:33:52 --> Model "Patient_model" initialized
INFO - 2022-03-16 00:33:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 00:33:52 --> Model "Referredby_model" initialized
INFO - 2022-03-16 00:33:52 --> Model "Prefix_master" initialized
INFO - 2022-03-16 00:33:52 --> Model "Hospital_model" initialized
INFO - 2022-03-16 00:33:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 00:34:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 00:34:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-16 00:34:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:34:00 --> Config Class Initialized
INFO - 2022-03-16 00:34:00 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:34:00 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:34:00 --> Utf8 Class Initialized
INFO - 2022-03-16 00:34:00 --> URI Class Initialized
INFO - 2022-03-16 00:34:00 --> Router Class Initialized
INFO - 2022-03-16 00:34:00 --> Output Class Initialized
INFO - 2022-03-16 00:34:00 --> Security Class Initialized
DEBUG - 2022-03-16 00:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:34:00 --> Input Class Initialized
INFO - 2022-03-16 00:34:00 --> Language Class Initialized
ERROR - 2022-03-16 00:34:00 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:34:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:34:01 --> Config Class Initialized
INFO - 2022-03-16 00:34:01 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:34:01 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:34:01 --> Utf8 Class Initialized
INFO - 2022-03-16 00:34:01 --> URI Class Initialized
INFO - 2022-03-16 00:34:01 --> Router Class Initialized
INFO - 2022-03-16 00:34:01 --> Output Class Initialized
INFO - 2022-03-16 00:34:01 --> Security Class Initialized
DEBUG - 2022-03-16 00:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:34:01 --> Input Class Initialized
INFO - 2022-03-16 00:34:01 --> Language Class Initialized
ERROR - 2022-03-16 00:34:01 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-16 00:34:07 --> Final output sent to browser
DEBUG - 2022-03-16 00:34:07 --> Total execution time: 7.7925
ERROR - 2022-03-16 00:35:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:35:37 --> Config Class Initialized
INFO - 2022-03-16 00:35:37 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:35:37 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:35:37 --> Utf8 Class Initialized
INFO - 2022-03-16 00:35:37 --> URI Class Initialized
INFO - 2022-03-16 00:35:37 --> Router Class Initialized
INFO - 2022-03-16 00:35:37 --> Output Class Initialized
INFO - 2022-03-16 00:35:37 --> Security Class Initialized
DEBUG - 2022-03-16 00:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:35:37 --> Input Class Initialized
INFO - 2022-03-16 00:35:37 --> Language Class Initialized
ERROR - 2022-03-16 00:35:37 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:35:49 --> Config Class Initialized
INFO - 2022-03-16 00:35:49 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:35:49 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:35:49 --> Utf8 Class Initialized
INFO - 2022-03-16 00:35:49 --> URI Class Initialized
INFO - 2022-03-16 00:35:49 --> Router Class Initialized
INFO - 2022-03-16 00:35:49 --> Output Class Initialized
INFO - 2022-03-16 00:35:49 --> Security Class Initialized
DEBUG - 2022-03-16 00:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:35:49 --> Input Class Initialized
INFO - 2022-03-16 00:35:49 --> Language Class Initialized
ERROR - 2022-03-16 00:35:49 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:37:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:37:52 --> Config Class Initialized
INFO - 2022-03-16 00:37:52 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:37:52 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:37:52 --> Utf8 Class Initialized
INFO - 2022-03-16 00:37:52 --> URI Class Initialized
INFO - 2022-03-16 00:37:52 --> Router Class Initialized
INFO - 2022-03-16 00:37:52 --> Output Class Initialized
INFO - 2022-03-16 00:37:52 --> Security Class Initialized
DEBUG - 2022-03-16 00:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:37:52 --> Input Class Initialized
INFO - 2022-03-16 00:37:52 --> Language Class Initialized
INFO - 2022-03-16 00:37:52 --> Loader Class Initialized
INFO - 2022-03-16 00:37:52 --> Helper loaded: url_helper
INFO - 2022-03-16 00:37:52 --> Helper loaded: form_helper
INFO - 2022-03-16 00:37:52 --> Helper loaded: common_helper
INFO - 2022-03-16 00:37:52 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:37:52 --> Controller Class Initialized
INFO - 2022-03-16 00:37:52 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:37:52 --> Encrypt Class Initialized
INFO - 2022-03-16 00:37:52 --> Model "Patient_model" initialized
INFO - 2022-03-16 00:37:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 00:37:52 --> Model "Prefix_master" initialized
INFO - 2022-03-16 00:37:52 --> Model "Users_model" initialized
INFO - 2022-03-16 00:37:52 --> Model "Hospital_model" initialized
INFO - 2022-03-16 00:37:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 00:37:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 00:37:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 00:37:52 --> Final output sent to browser
DEBUG - 2022-03-16 00:37:52 --> Total execution time: 0.0874
ERROR - 2022-03-16 00:37:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:37:53 --> Config Class Initialized
INFO - 2022-03-16 00:37:53 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:37:53 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:37:53 --> Utf8 Class Initialized
INFO - 2022-03-16 00:37:53 --> URI Class Initialized
INFO - 2022-03-16 00:37:53 --> Router Class Initialized
INFO - 2022-03-16 00:37:53 --> Output Class Initialized
INFO - 2022-03-16 00:37:53 --> Security Class Initialized
DEBUG - 2022-03-16 00:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:37:53 --> Input Class Initialized
INFO - 2022-03-16 00:37:53 --> Language Class Initialized
ERROR - 2022-03-16 00:37:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 00:38:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:38:01 --> Config Class Initialized
INFO - 2022-03-16 00:38:01 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:38:01 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:38:01 --> Utf8 Class Initialized
INFO - 2022-03-16 00:38:01 --> URI Class Initialized
INFO - 2022-03-16 00:38:01 --> Router Class Initialized
INFO - 2022-03-16 00:38:01 --> Output Class Initialized
INFO - 2022-03-16 00:38:01 --> Security Class Initialized
DEBUG - 2022-03-16 00:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:38:01 --> Input Class Initialized
INFO - 2022-03-16 00:38:01 --> Language Class Initialized
ERROR - 2022-03-16 00:38:01 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:38:04 --> Config Class Initialized
INFO - 2022-03-16 00:38:04 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:38:04 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:38:04 --> Utf8 Class Initialized
INFO - 2022-03-16 00:38:04 --> URI Class Initialized
INFO - 2022-03-16 00:38:04 --> Router Class Initialized
INFO - 2022-03-16 00:38:04 --> Output Class Initialized
INFO - 2022-03-16 00:38:04 --> Security Class Initialized
DEBUG - 2022-03-16 00:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:38:04 --> Input Class Initialized
INFO - 2022-03-16 00:38:04 --> Language Class Initialized
ERROR - 2022-03-16 00:38:04 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:38:07 --> Config Class Initialized
INFO - 2022-03-16 00:38:07 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:38:07 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:38:07 --> Utf8 Class Initialized
INFO - 2022-03-16 00:38:07 --> URI Class Initialized
INFO - 2022-03-16 00:38:07 --> Router Class Initialized
INFO - 2022-03-16 00:38:07 --> Output Class Initialized
INFO - 2022-03-16 00:38:07 --> Security Class Initialized
DEBUG - 2022-03-16 00:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:38:07 --> Input Class Initialized
INFO - 2022-03-16 00:38:07 --> Language Class Initialized
ERROR - 2022-03-16 00:38:07 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:38:09 --> Config Class Initialized
INFO - 2022-03-16 00:38:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:38:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:38:09 --> Utf8 Class Initialized
INFO - 2022-03-16 00:38:09 --> URI Class Initialized
INFO - 2022-03-16 00:38:09 --> Router Class Initialized
INFO - 2022-03-16 00:38:09 --> Output Class Initialized
INFO - 2022-03-16 00:38:09 --> Security Class Initialized
DEBUG - 2022-03-16 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:38:09 --> Input Class Initialized
INFO - 2022-03-16 00:38:09 --> Language Class Initialized
ERROR - 2022-03-16 00:38:09 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:39:02 --> Config Class Initialized
INFO - 2022-03-16 00:39:02 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:39:02 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:39:02 --> Utf8 Class Initialized
INFO - 2022-03-16 00:39:02 --> URI Class Initialized
INFO - 2022-03-16 00:39:02 --> Router Class Initialized
INFO - 2022-03-16 00:39:02 --> Output Class Initialized
INFO - 2022-03-16 00:39:02 --> Security Class Initialized
DEBUG - 2022-03-16 00:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:39:02 --> Input Class Initialized
INFO - 2022-03-16 00:39:02 --> Language Class Initialized
INFO - 2022-03-16 00:39:02 --> Loader Class Initialized
INFO - 2022-03-16 00:39:02 --> Helper loaded: url_helper
INFO - 2022-03-16 00:39:02 --> Helper loaded: form_helper
INFO - 2022-03-16 00:39:02 --> Helper loaded: common_helper
INFO - 2022-03-16 00:39:02 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:39:02 --> Controller Class Initialized
INFO - 2022-03-16 00:39:02 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:39:02 --> Encrypt Class Initialized
INFO - 2022-03-16 00:39:02 --> Model "Patient_model" initialized
INFO - 2022-03-16 00:39:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 00:39:02 --> Model "Prefix_master" initialized
INFO - 2022-03-16 00:39:02 --> Model "Users_model" initialized
INFO - 2022-03-16 00:39:02 --> Model "Hospital_model" initialized
INFO - 2022-03-16 00:39:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 00:39:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 00:39:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 00:39:02 --> Final output sent to browser
DEBUG - 2022-03-16 00:39:02 --> Total execution time: 0.1021
ERROR - 2022-03-16 00:39:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:39:03 --> Config Class Initialized
INFO - 2022-03-16 00:39:03 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:39:03 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:39:03 --> Utf8 Class Initialized
INFO - 2022-03-16 00:39:03 --> URI Class Initialized
INFO - 2022-03-16 00:39:03 --> Router Class Initialized
INFO - 2022-03-16 00:39:03 --> Output Class Initialized
INFO - 2022-03-16 00:39:03 --> Security Class Initialized
DEBUG - 2022-03-16 00:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:39:03 --> Input Class Initialized
INFO - 2022-03-16 00:39:03 --> Language Class Initialized
ERROR - 2022-03-16 00:39:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 00:39:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:39:09 --> Config Class Initialized
INFO - 2022-03-16 00:39:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:39:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:39:09 --> Utf8 Class Initialized
INFO - 2022-03-16 00:39:09 --> URI Class Initialized
INFO - 2022-03-16 00:39:09 --> Router Class Initialized
INFO - 2022-03-16 00:39:09 --> Output Class Initialized
INFO - 2022-03-16 00:39:09 --> Security Class Initialized
DEBUG - 2022-03-16 00:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:39:09 --> Input Class Initialized
INFO - 2022-03-16 00:39:09 --> Language Class Initialized
ERROR - 2022-03-16 00:39:09 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:39:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:39:36 --> Config Class Initialized
INFO - 2022-03-16 00:39:36 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:39:36 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:39:36 --> Utf8 Class Initialized
INFO - 2022-03-16 00:39:36 --> URI Class Initialized
INFO - 2022-03-16 00:39:36 --> Router Class Initialized
INFO - 2022-03-16 00:39:36 --> Output Class Initialized
INFO - 2022-03-16 00:39:36 --> Security Class Initialized
DEBUG - 2022-03-16 00:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:39:36 --> Input Class Initialized
INFO - 2022-03-16 00:39:36 --> Language Class Initialized
INFO - 2022-03-16 00:39:36 --> Loader Class Initialized
INFO - 2022-03-16 00:39:36 --> Helper loaded: url_helper
INFO - 2022-03-16 00:39:36 --> Helper loaded: form_helper
INFO - 2022-03-16 00:39:36 --> Helper loaded: common_helper
INFO - 2022-03-16 00:39:36 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:39:36 --> Controller Class Initialized
INFO - 2022-03-16 00:39:36 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:39:36 --> Encrypt Class Initialized
INFO - 2022-03-16 00:39:36 --> Model "Patient_model" initialized
INFO - 2022-03-16 00:39:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 00:39:36 --> Model "Prefix_master" initialized
INFO - 2022-03-16 00:39:36 --> Model "Users_model" initialized
INFO - 2022-03-16 00:39:36 --> Model "Hospital_model" initialized
INFO - 2022-03-16 00:39:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 00:39:36 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 00:39:36 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 00:39:36 --> Final output sent to browser
DEBUG - 2022-03-16 00:39:36 --> Total execution time: 0.0772
ERROR - 2022-03-16 00:39:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:39:36 --> Config Class Initialized
INFO - 2022-03-16 00:39:36 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:39:36 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:39:36 --> Utf8 Class Initialized
INFO - 2022-03-16 00:39:36 --> URI Class Initialized
INFO - 2022-03-16 00:39:36 --> Router Class Initialized
INFO - 2022-03-16 00:39:36 --> Output Class Initialized
INFO - 2022-03-16 00:39:36 --> Security Class Initialized
DEBUG - 2022-03-16 00:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:39:36 --> Input Class Initialized
INFO - 2022-03-16 00:39:36 --> Language Class Initialized
ERROR - 2022-03-16 00:39:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 00:44:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:44:09 --> Config Class Initialized
INFO - 2022-03-16 00:44:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:44:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:44:09 --> Utf8 Class Initialized
INFO - 2022-03-16 00:44:09 --> URI Class Initialized
INFO - 2022-03-16 00:44:09 --> Router Class Initialized
INFO - 2022-03-16 00:44:09 --> Output Class Initialized
INFO - 2022-03-16 00:44:09 --> Security Class Initialized
DEBUG - 2022-03-16 00:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:44:09 --> Input Class Initialized
INFO - 2022-03-16 00:44:09 --> Language Class Initialized
INFO - 2022-03-16 00:44:09 --> Loader Class Initialized
INFO - 2022-03-16 00:44:09 --> Helper loaded: url_helper
INFO - 2022-03-16 00:44:09 --> Helper loaded: form_helper
INFO - 2022-03-16 00:44:09 --> Helper loaded: common_helper
INFO - 2022-03-16 00:44:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 00:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 00:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 00:44:09 --> Controller Class Initialized
INFO - 2022-03-16 00:44:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 00:44:09 --> Encrypt Class Initialized
INFO - 2022-03-16 00:44:09 --> Model "Patient_model" initialized
INFO - 2022-03-16 00:44:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 00:44:09 --> Model "Prefix_master" initialized
INFO - 2022-03-16 00:44:09 --> Model "Users_model" initialized
INFO - 2022-03-16 00:44:09 --> Model "Hospital_model" initialized
INFO - 2022-03-16 00:44:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 00:44:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 00:44:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 00:44:09 --> Final output sent to browser
DEBUG - 2022-03-16 00:44:09 --> Total execution time: 0.1091
ERROR - 2022-03-16 00:44:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:44:10 --> Config Class Initialized
INFO - 2022-03-16 00:44:10 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:44:10 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:44:10 --> Utf8 Class Initialized
INFO - 2022-03-16 00:44:10 --> URI Class Initialized
INFO - 2022-03-16 00:44:10 --> Router Class Initialized
INFO - 2022-03-16 00:44:10 --> Output Class Initialized
INFO - 2022-03-16 00:44:10 --> Security Class Initialized
DEBUG - 2022-03-16 00:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:44:10 --> Input Class Initialized
INFO - 2022-03-16 00:44:10 --> Language Class Initialized
ERROR - 2022-03-16 00:44:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 00:44:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:44:19 --> Config Class Initialized
INFO - 2022-03-16 00:44:19 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:44:19 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:44:19 --> Utf8 Class Initialized
INFO - 2022-03-16 00:44:19 --> URI Class Initialized
INFO - 2022-03-16 00:44:19 --> Router Class Initialized
INFO - 2022-03-16 00:44:19 --> Output Class Initialized
INFO - 2022-03-16 00:44:19 --> Security Class Initialized
DEBUG - 2022-03-16 00:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:44:19 --> Input Class Initialized
INFO - 2022-03-16 00:44:19 --> Language Class Initialized
ERROR - 2022-03-16 00:44:19 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:44:26 --> Config Class Initialized
INFO - 2022-03-16 00:44:26 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:44:26 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:44:26 --> Utf8 Class Initialized
INFO - 2022-03-16 00:44:26 --> URI Class Initialized
INFO - 2022-03-16 00:44:26 --> Router Class Initialized
INFO - 2022-03-16 00:44:26 --> Output Class Initialized
INFO - 2022-03-16 00:44:26 --> Security Class Initialized
DEBUG - 2022-03-16 00:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:44:26 --> Input Class Initialized
INFO - 2022-03-16 00:44:26 --> Language Class Initialized
ERROR - 2022-03-16 00:44:26 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:46:26 --> Config Class Initialized
INFO - 2022-03-16 00:46:26 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:46:26 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:46:26 --> Utf8 Class Initialized
INFO - 2022-03-16 00:46:26 --> URI Class Initialized
INFO - 2022-03-16 00:46:26 --> Router Class Initialized
INFO - 2022-03-16 00:46:26 --> Output Class Initialized
INFO - 2022-03-16 00:46:26 --> Security Class Initialized
DEBUG - 2022-03-16 00:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:46:26 --> Input Class Initialized
INFO - 2022-03-16 00:46:26 --> Language Class Initialized
ERROR - 2022-03-16 00:46:26 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 00:46:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 00:46:33 --> Config Class Initialized
INFO - 2022-03-16 00:46:33 --> Hooks Class Initialized
DEBUG - 2022-03-16 00:46:33 --> UTF-8 Support Enabled
INFO - 2022-03-16 00:46:33 --> Utf8 Class Initialized
INFO - 2022-03-16 00:46:33 --> URI Class Initialized
INFO - 2022-03-16 00:46:33 --> Router Class Initialized
INFO - 2022-03-16 00:46:33 --> Output Class Initialized
INFO - 2022-03-16 00:46:33 --> Security Class Initialized
DEBUG - 2022-03-16 00:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 00:46:33 --> Input Class Initialized
INFO - 2022-03-16 00:46:33 --> Language Class Initialized
ERROR - 2022-03-16 00:46:33 --> 404 Page Not Found: Karoclient/file_uploads
ERROR - 2022-03-16 01:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:01:04 --> Config Class Initialized
INFO - 2022-03-16 01:01:04 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:01:04 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:01:04 --> Utf8 Class Initialized
INFO - 2022-03-16 01:01:04 --> URI Class Initialized
DEBUG - 2022-03-16 01:01:04 --> No URI present. Default controller set.
INFO - 2022-03-16 01:01:04 --> Router Class Initialized
INFO - 2022-03-16 01:01:04 --> Output Class Initialized
INFO - 2022-03-16 01:01:04 --> Security Class Initialized
DEBUG - 2022-03-16 01:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:01:04 --> Input Class Initialized
INFO - 2022-03-16 01:01:04 --> Language Class Initialized
INFO - 2022-03-16 01:01:04 --> Loader Class Initialized
INFO - 2022-03-16 01:01:04 --> Helper loaded: url_helper
INFO - 2022-03-16 01:01:04 --> Helper loaded: form_helper
INFO - 2022-03-16 01:01:04 --> Helper loaded: common_helper
INFO - 2022-03-16 01:01:04 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:01:04 --> Controller Class Initialized
INFO - 2022-03-16 01:01:04 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:01:04 --> Encrypt Class Initialized
DEBUG - 2022-03-16 01:01:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 01:01:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 01:01:04 --> Email Class Initialized
INFO - 2022-03-16 01:01:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 01:01:04 --> Calendar Class Initialized
INFO - 2022-03-16 01:01:04 --> Model "Login_model" initialized
INFO - 2022-03-16 01:01:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 01:01:04 --> Final output sent to browser
DEBUG - 2022-03-16 01:01:04 --> Total execution time: 0.0269
ERROR - 2022-03-16 01:01:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:01:09 --> Config Class Initialized
INFO - 2022-03-16 01:01:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:01:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:01:09 --> Utf8 Class Initialized
INFO - 2022-03-16 01:01:09 --> URI Class Initialized
DEBUG - 2022-03-16 01:01:09 --> No URI present. Default controller set.
INFO - 2022-03-16 01:01:09 --> Router Class Initialized
INFO - 2022-03-16 01:01:09 --> Output Class Initialized
INFO - 2022-03-16 01:01:09 --> Security Class Initialized
DEBUG - 2022-03-16 01:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:01:09 --> Input Class Initialized
INFO - 2022-03-16 01:01:09 --> Language Class Initialized
INFO - 2022-03-16 01:01:09 --> Loader Class Initialized
INFO - 2022-03-16 01:01:09 --> Helper loaded: url_helper
INFO - 2022-03-16 01:01:09 --> Helper loaded: form_helper
INFO - 2022-03-16 01:01:09 --> Helper loaded: common_helper
INFO - 2022-03-16 01:01:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:01:09 --> Controller Class Initialized
INFO - 2022-03-16 01:01:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:01:09 --> Encrypt Class Initialized
DEBUG - 2022-03-16 01:01:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 01:01:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 01:01:09 --> Email Class Initialized
INFO - 2022-03-16 01:01:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 01:01:09 --> Calendar Class Initialized
INFO - 2022-03-16 01:01:09 --> Model "Login_model" initialized
INFO - 2022-03-16 01:01:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 01:01:09 --> Final output sent to browser
DEBUG - 2022-03-16 01:01:09 --> Total execution time: 0.0316
ERROR - 2022-03-16 01:01:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:01:19 --> Config Class Initialized
INFO - 2022-03-16 01:01:19 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:01:19 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:01:19 --> Utf8 Class Initialized
INFO - 2022-03-16 01:01:19 --> URI Class Initialized
INFO - 2022-03-16 01:01:19 --> Router Class Initialized
INFO - 2022-03-16 01:01:19 --> Output Class Initialized
INFO - 2022-03-16 01:01:19 --> Security Class Initialized
DEBUG - 2022-03-16 01:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:01:19 --> Input Class Initialized
INFO - 2022-03-16 01:01:19 --> Language Class Initialized
INFO - 2022-03-16 01:01:19 --> Loader Class Initialized
INFO - 2022-03-16 01:01:19 --> Helper loaded: url_helper
INFO - 2022-03-16 01:01:19 --> Helper loaded: form_helper
INFO - 2022-03-16 01:01:19 --> Helper loaded: common_helper
INFO - 2022-03-16 01:01:19 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:01:19 --> Controller Class Initialized
INFO - 2022-03-16 01:01:19 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:01:19 --> Encrypt Class Initialized
DEBUG - 2022-03-16 01:01:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 01:01:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 01:01:19 --> Email Class Initialized
INFO - 2022-03-16 01:01:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 01:01:19 --> Calendar Class Initialized
INFO - 2022-03-16 01:01:19 --> Model "Login_model" initialized
INFO - 2022-03-16 01:01:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-16 01:01:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:01:19 --> Config Class Initialized
INFO - 2022-03-16 01:01:19 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:01:19 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:01:19 --> Utf8 Class Initialized
INFO - 2022-03-16 01:01:19 --> URI Class Initialized
INFO - 2022-03-16 01:01:19 --> Router Class Initialized
INFO - 2022-03-16 01:01:19 --> Output Class Initialized
INFO - 2022-03-16 01:01:19 --> Security Class Initialized
DEBUG - 2022-03-16 01:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:01:19 --> Input Class Initialized
INFO - 2022-03-16 01:01:19 --> Language Class Initialized
INFO - 2022-03-16 01:01:19 --> Loader Class Initialized
INFO - 2022-03-16 01:01:19 --> Helper loaded: url_helper
INFO - 2022-03-16 01:01:19 --> Helper loaded: form_helper
INFO - 2022-03-16 01:01:19 --> Helper loaded: common_helper
INFO - 2022-03-16 01:01:19 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:01:19 --> Controller Class Initialized
INFO - 2022-03-16 01:01:19 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:01:19 --> Encrypt Class Initialized
INFO - 2022-03-16 01:01:19 --> Model "Login_model" initialized
INFO - 2022-03-16 01:01:19 --> Model "Dashboard_model" initialized
INFO - 2022-03-16 01:01:19 --> Model "Case_model" initialized
INFO - 2022-03-16 01:01:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-16 01:01:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:01:40 --> Config Class Initialized
INFO - 2022-03-16 01:01:40 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:01:40 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:01:40 --> Utf8 Class Initialized
INFO - 2022-03-16 01:01:40 --> URI Class Initialized
INFO - 2022-03-16 01:01:40 --> Router Class Initialized
INFO - 2022-03-16 01:01:40 --> Output Class Initialized
INFO - 2022-03-16 01:01:40 --> Security Class Initialized
DEBUG - 2022-03-16 01:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:01:40 --> Input Class Initialized
INFO - 2022-03-16 01:01:40 --> Language Class Initialized
INFO - 2022-03-16 01:01:40 --> Loader Class Initialized
INFO - 2022-03-16 01:01:40 --> Helper loaded: url_helper
INFO - 2022-03-16 01:01:40 --> Helper loaded: form_helper
INFO - 2022-03-16 01:01:40 --> Helper loaded: common_helper
INFO - 2022-03-16 01:01:40 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-16 01:01:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:01:40 --> Config Class Initialized
INFO - 2022-03-16 01:01:40 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:01:40 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:01:40 --> Utf8 Class Initialized
INFO - 2022-03-16 01:01:40 --> URI Class Initialized
INFO - 2022-03-16 01:01:40 --> Router Class Initialized
INFO - 2022-03-16 01:01:40 --> Output Class Initialized
INFO - 2022-03-16 01:01:40 --> Security Class Initialized
DEBUG - 2022-03-16 01:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:01:40 --> Input Class Initialized
INFO - 2022-03-16 01:01:40 --> Language Class Initialized
INFO - 2022-03-16 01:01:40 --> Loader Class Initialized
INFO - 2022-03-16 01:01:40 --> Helper loaded: url_helper
INFO - 2022-03-16 01:01:40 --> Helper loaded: form_helper
INFO - 2022-03-16 01:01:40 --> Helper loaded: common_helper
INFO - 2022-03-16 01:01:40 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-16 01:01:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:01:41 --> Config Class Initialized
INFO - 2022-03-16 01:01:41 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:01:41 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:01:41 --> Utf8 Class Initialized
INFO - 2022-03-16 01:01:41 --> URI Class Initialized
INFO - 2022-03-16 01:01:41 --> Router Class Initialized
INFO - 2022-03-16 01:01:41 --> Output Class Initialized
INFO - 2022-03-16 01:01:41 --> Security Class Initialized
DEBUG - 2022-03-16 01:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:01:41 --> Input Class Initialized
INFO - 2022-03-16 01:01:41 --> Language Class Initialized
INFO - 2022-03-16 01:01:41 --> Loader Class Initialized
INFO - 2022-03-16 01:01:41 --> Helper loaded: url_helper
INFO - 2022-03-16 01:01:41 --> Helper loaded: form_helper
INFO - 2022-03-16 01:01:41 --> Helper loaded: common_helper
INFO - 2022-03-16 01:01:41 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:01:47 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-16 01:01:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:01:47 --> Final output sent to browser
DEBUG - 2022-03-16 01:01:47 --> Total execution time: 27.8084
INFO - 2022-03-16 01:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:01:47 --> Controller Class Initialized
INFO - 2022-03-16 01:01:47 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:01:47 --> Encrypt Class Initialized
DEBUG - 2022-03-16 01:01:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 01:01:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 01:01:47 --> Email Class Initialized
INFO - 2022-03-16 01:01:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 01:01:47 --> Calendar Class Initialized
INFO - 2022-03-16 01:01:47 --> Model "Login_model" initialized
INFO - 2022-03-16 01:01:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-16 01:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:01:47 --> Controller Class Initialized
INFO - 2022-03-16 01:01:47 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:01:47 --> Encrypt Class Initialized
DEBUG - 2022-03-16 01:01:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 01:01:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 01:01:47 --> Email Class Initialized
INFO - 2022-03-16 01:01:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 01:01:47 --> Calendar Class Initialized
INFO - 2022-03-16 01:01:47 --> Model "Login_model" initialized
INFO - 2022-03-16 01:01:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-16 01:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:01:47 --> Controller Class Initialized
INFO - 2022-03-16 01:01:47 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:01:47 --> Encrypt Class Initialized
DEBUG - 2022-03-16 01:01:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 01:01:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 01:01:47 --> Email Class Initialized
INFO - 2022-03-16 01:01:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 01:01:47 --> Calendar Class Initialized
INFO - 2022-03-16 01:01:47 --> Model "Login_model" initialized
INFO - 2022-03-16 01:01:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-16 01:01:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:01:48 --> Config Class Initialized
INFO - 2022-03-16 01:01:48 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:01:48 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:01:48 --> Utf8 Class Initialized
INFO - 2022-03-16 01:01:48 --> URI Class Initialized
INFO - 2022-03-16 01:01:48 --> Router Class Initialized
INFO - 2022-03-16 01:01:48 --> Output Class Initialized
INFO - 2022-03-16 01:01:48 --> Security Class Initialized
DEBUG - 2022-03-16 01:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:01:48 --> Input Class Initialized
INFO - 2022-03-16 01:01:48 --> Language Class Initialized
INFO - 2022-03-16 01:01:48 --> Loader Class Initialized
INFO - 2022-03-16 01:01:48 --> Helper loaded: url_helper
INFO - 2022-03-16 01:01:48 --> Helper loaded: form_helper
INFO - 2022-03-16 01:01:48 --> Helper loaded: common_helper
INFO - 2022-03-16 01:01:48 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:01:48 --> Controller Class Initialized
INFO - 2022-03-16 01:01:48 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:01:48 --> Encrypt Class Initialized
INFO - 2022-03-16 01:01:48 --> Model "Login_model" initialized
INFO - 2022-03-16 01:01:48 --> Model "Dashboard_model" initialized
INFO - 2022-03-16 01:01:48 --> Model "Case_model" initialized
INFO - 2022-03-16 01:02:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:02:20 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-16 01:02:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:02:20 --> Final output sent to browser
DEBUG - 2022-03-16 01:02:20 --> Total execution time: 31.7228
ERROR - 2022-03-16 01:02:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:02:28 --> Config Class Initialized
INFO - 2022-03-16 01:02:28 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:02:28 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:02:28 --> Utf8 Class Initialized
INFO - 2022-03-16 01:02:28 --> URI Class Initialized
INFO - 2022-03-16 01:02:28 --> Router Class Initialized
INFO - 2022-03-16 01:02:28 --> Output Class Initialized
INFO - 2022-03-16 01:02:28 --> Security Class Initialized
DEBUG - 2022-03-16 01:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:02:28 --> Input Class Initialized
INFO - 2022-03-16 01:02:28 --> Language Class Initialized
INFO - 2022-03-16 01:02:28 --> Loader Class Initialized
INFO - 2022-03-16 01:02:28 --> Helper loaded: url_helper
INFO - 2022-03-16 01:02:28 --> Helper loaded: form_helper
INFO - 2022-03-16 01:02:28 --> Helper loaded: common_helper
INFO - 2022-03-16 01:02:28 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:02:28 --> Controller Class Initialized
INFO - 2022-03-16 01:02:28 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:02:28 --> Encrypt Class Initialized
INFO - 2022-03-16 01:02:28 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:02:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:02:28 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:02:28 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:02:28 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:02:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:02:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 01:02:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:02:28 --> Final output sent to browser
DEBUG - 2022-03-16 01:02:28 --> Total execution time: 0.1204
ERROR - 2022-03-16 01:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:03:36 --> Config Class Initialized
INFO - 2022-03-16 01:03:36 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:03:36 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:03:36 --> Utf8 Class Initialized
INFO - 2022-03-16 01:03:36 --> URI Class Initialized
INFO - 2022-03-16 01:03:36 --> Router Class Initialized
INFO - 2022-03-16 01:03:36 --> Output Class Initialized
INFO - 2022-03-16 01:03:36 --> Security Class Initialized
DEBUG - 2022-03-16 01:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:03:36 --> Input Class Initialized
INFO - 2022-03-16 01:03:36 --> Language Class Initialized
INFO - 2022-03-16 01:03:36 --> Loader Class Initialized
INFO - 2022-03-16 01:03:36 --> Helper loaded: url_helper
INFO - 2022-03-16 01:03:36 --> Helper loaded: form_helper
INFO - 2022-03-16 01:03:36 --> Helper loaded: common_helper
INFO - 2022-03-16 01:03:36 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:03:36 --> Controller Class Initialized
INFO - 2022-03-16 01:03:36 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:03:36 --> Encrypt Class Initialized
INFO - 2022-03-16 01:03:36 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:03:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:03:36 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:03:36 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:03:36 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:03:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:03:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 01:03:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:03:49 --> Final output sent to browser
DEBUG - 2022-03-16 01:03:49 --> Total execution time: 11.4722
ERROR - 2022-03-16 01:04:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:04:19 --> Config Class Initialized
INFO - 2022-03-16 01:04:19 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:04:19 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:04:19 --> Utf8 Class Initialized
INFO - 2022-03-16 01:04:19 --> URI Class Initialized
INFO - 2022-03-16 01:04:19 --> Router Class Initialized
INFO - 2022-03-16 01:04:19 --> Output Class Initialized
INFO - 2022-03-16 01:04:19 --> Security Class Initialized
DEBUG - 2022-03-16 01:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:04:19 --> Input Class Initialized
INFO - 2022-03-16 01:04:19 --> Language Class Initialized
INFO - 2022-03-16 01:04:19 --> Loader Class Initialized
INFO - 2022-03-16 01:04:19 --> Helper loaded: url_helper
INFO - 2022-03-16 01:04:19 --> Helper loaded: form_helper
INFO - 2022-03-16 01:04:19 --> Helper loaded: common_helper
INFO - 2022-03-16 01:04:19 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:04:19 --> Controller Class Initialized
INFO - 2022-03-16 01:04:19 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:04:19 --> Encrypt Class Initialized
INFO - 2022-03-16 01:04:19 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:04:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:04:19 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:04:19 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:04:19 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:04:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:04:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 01:04:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:04:19 --> Final output sent to browser
DEBUG - 2022-03-16 01:04:19 --> Total execution time: 0.0329
ERROR - 2022-03-16 01:08:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:08:32 --> Config Class Initialized
INFO - 2022-03-16 01:08:32 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:08:32 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:08:32 --> Utf8 Class Initialized
INFO - 2022-03-16 01:08:32 --> URI Class Initialized
INFO - 2022-03-16 01:08:32 --> Router Class Initialized
INFO - 2022-03-16 01:08:32 --> Output Class Initialized
INFO - 2022-03-16 01:08:32 --> Security Class Initialized
DEBUG - 2022-03-16 01:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:08:32 --> Input Class Initialized
INFO - 2022-03-16 01:08:32 --> Language Class Initialized
INFO - 2022-03-16 01:08:32 --> Loader Class Initialized
INFO - 2022-03-16 01:08:32 --> Helper loaded: url_helper
INFO - 2022-03-16 01:08:32 --> Helper loaded: form_helper
INFO - 2022-03-16 01:08:32 --> Helper loaded: common_helper
INFO - 2022-03-16 01:08:32 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:08:32 --> Controller Class Initialized
INFO - 2022-03-16 01:08:32 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:08:32 --> Final output sent to browser
DEBUG - 2022-03-16 01:08:32 --> Total execution time: 0.0392
ERROR - 2022-03-16 01:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:08:56 --> Config Class Initialized
INFO - 2022-03-16 01:08:56 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:08:56 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:08:56 --> Utf8 Class Initialized
INFO - 2022-03-16 01:08:56 --> URI Class Initialized
INFO - 2022-03-16 01:08:56 --> Router Class Initialized
INFO - 2022-03-16 01:08:56 --> Output Class Initialized
INFO - 2022-03-16 01:08:56 --> Security Class Initialized
DEBUG - 2022-03-16 01:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:08:56 --> Input Class Initialized
INFO - 2022-03-16 01:08:56 --> Language Class Initialized
INFO - 2022-03-16 01:08:56 --> Loader Class Initialized
INFO - 2022-03-16 01:08:56 --> Helper loaded: url_helper
INFO - 2022-03-16 01:08:56 --> Helper loaded: form_helper
INFO - 2022-03-16 01:08:56 --> Helper loaded: common_helper
INFO - 2022-03-16 01:08:56 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:08:56 --> Controller Class Initialized
INFO - 2022-03-16 01:08:56 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:08:56 --> Final output sent to browser
DEBUG - 2022-03-16 01:08:56 --> Total execution time: 0.0206
ERROR - 2022-03-16 01:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:09:21 --> Config Class Initialized
INFO - 2022-03-16 01:09:21 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:09:21 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:09:21 --> Utf8 Class Initialized
INFO - 2022-03-16 01:09:21 --> URI Class Initialized
INFO - 2022-03-16 01:09:21 --> Router Class Initialized
INFO - 2022-03-16 01:09:21 --> Output Class Initialized
INFO - 2022-03-16 01:09:21 --> Security Class Initialized
DEBUG - 2022-03-16 01:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:09:21 --> Input Class Initialized
INFO - 2022-03-16 01:09:21 --> Language Class Initialized
INFO - 2022-03-16 01:09:21 --> Loader Class Initialized
INFO - 2022-03-16 01:09:21 --> Helper loaded: url_helper
INFO - 2022-03-16 01:09:21 --> Helper loaded: form_helper
INFO - 2022-03-16 01:09:21 --> Helper loaded: common_helper
INFO - 2022-03-16 01:09:21 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:09:21 --> Controller Class Initialized
INFO - 2022-03-16 01:09:21 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:09:21 --> Encrypt Class Initialized
INFO - 2022-03-16 01:09:21 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:09:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:09:21 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:09:21 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:09:21 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:09:21 --> Final output sent to browser
DEBUG - 2022-03-16 01:09:21 --> Total execution time: 0.0388
ERROR - 2022-03-16 01:09:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:09:32 --> Config Class Initialized
INFO - 2022-03-16 01:09:32 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:09:32 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:09:32 --> Utf8 Class Initialized
INFO - 2022-03-16 01:09:32 --> URI Class Initialized
INFO - 2022-03-16 01:09:32 --> Router Class Initialized
INFO - 2022-03-16 01:09:32 --> Output Class Initialized
INFO - 2022-03-16 01:09:32 --> Security Class Initialized
DEBUG - 2022-03-16 01:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:09:32 --> Input Class Initialized
INFO - 2022-03-16 01:09:32 --> Language Class Initialized
INFO - 2022-03-16 01:09:32 --> Loader Class Initialized
INFO - 2022-03-16 01:09:32 --> Helper loaded: url_helper
INFO - 2022-03-16 01:09:32 --> Helper loaded: form_helper
INFO - 2022-03-16 01:09:32 --> Helper loaded: common_helper
INFO - 2022-03-16 01:09:32 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:09:32 --> Controller Class Initialized
INFO - 2022-03-16 01:09:32 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:09:32 --> Encrypt Class Initialized
INFO - 2022-03-16 01:09:32 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:09:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:09:32 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:09:32 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:09:32 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:09:32 --> Final output sent to browser
DEBUG - 2022-03-16 01:09:32 --> Total execution time: 0.0374
ERROR - 2022-03-16 01:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:09:44 --> Config Class Initialized
INFO - 2022-03-16 01:09:44 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:09:44 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:09:44 --> Utf8 Class Initialized
INFO - 2022-03-16 01:09:44 --> URI Class Initialized
INFO - 2022-03-16 01:09:44 --> Router Class Initialized
INFO - 2022-03-16 01:09:44 --> Output Class Initialized
INFO - 2022-03-16 01:09:44 --> Security Class Initialized
DEBUG - 2022-03-16 01:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:09:44 --> Input Class Initialized
INFO - 2022-03-16 01:09:44 --> Language Class Initialized
INFO - 2022-03-16 01:09:44 --> Loader Class Initialized
INFO - 2022-03-16 01:09:44 --> Helper loaded: url_helper
INFO - 2022-03-16 01:09:44 --> Helper loaded: form_helper
INFO - 2022-03-16 01:09:44 --> Helper loaded: common_helper
INFO - 2022-03-16 01:09:44 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:09:44 --> Controller Class Initialized
INFO - 2022-03-16 01:09:44 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:09:44 --> Encrypt Class Initialized
INFO - 2022-03-16 01:09:44 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:09:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:09:44 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:09:44 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:09:44 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:09:44 --> Final output sent to browser
DEBUG - 2022-03-16 01:09:44 --> Total execution time: 0.0345
ERROR - 2022-03-16 01:17:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:17:52 --> Config Class Initialized
INFO - 2022-03-16 01:17:52 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:17:52 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:17:52 --> Utf8 Class Initialized
INFO - 2022-03-16 01:17:52 --> URI Class Initialized
INFO - 2022-03-16 01:17:52 --> Router Class Initialized
INFO - 2022-03-16 01:17:52 --> Output Class Initialized
INFO - 2022-03-16 01:17:52 --> Security Class Initialized
DEBUG - 2022-03-16 01:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:17:52 --> Input Class Initialized
INFO - 2022-03-16 01:17:52 --> Language Class Initialized
INFO - 2022-03-16 01:17:52 --> Loader Class Initialized
INFO - 2022-03-16 01:17:52 --> Helper loaded: url_helper
INFO - 2022-03-16 01:17:52 --> Helper loaded: form_helper
INFO - 2022-03-16 01:17:52 --> Helper loaded: common_helper
INFO - 2022-03-16 01:17:52 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:17:52 --> Controller Class Initialized
INFO - 2022-03-16 01:17:52 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:17:52 --> Final output sent to browser
DEBUG - 2022-03-16 01:17:52 --> Total execution time: 0.0331
ERROR - 2022-03-16 01:37:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:37:07 --> Config Class Initialized
INFO - 2022-03-16 01:37:07 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:37:07 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:37:07 --> Utf8 Class Initialized
INFO - 2022-03-16 01:37:07 --> URI Class Initialized
INFO - 2022-03-16 01:37:07 --> Router Class Initialized
INFO - 2022-03-16 01:37:07 --> Output Class Initialized
INFO - 2022-03-16 01:37:07 --> Security Class Initialized
DEBUG - 2022-03-16 01:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:37:07 --> Input Class Initialized
INFO - 2022-03-16 01:37:07 --> Language Class Initialized
INFO - 2022-03-16 01:37:07 --> Loader Class Initialized
INFO - 2022-03-16 01:37:07 --> Helper loaded: url_helper
INFO - 2022-03-16 01:37:07 --> Helper loaded: form_helper
INFO - 2022-03-16 01:37:07 --> Helper loaded: common_helper
INFO - 2022-03-16 01:37:07 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:37:08 --> Controller Class Initialized
INFO - 2022-03-16 01:37:08 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:37:08 --> Encrypt Class Initialized
INFO - 2022-03-16 01:37:08 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:37:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:37:08 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:37:08 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:37:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 01:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:37:08 --> Config Class Initialized
INFO - 2022-03-16 01:37:08 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:37:08 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:37:08 --> Utf8 Class Initialized
INFO - 2022-03-16 01:37:08 --> URI Class Initialized
INFO - 2022-03-16 01:37:08 --> Router Class Initialized
INFO - 2022-03-16 01:37:08 --> Output Class Initialized
INFO - 2022-03-16 01:37:08 --> Security Class Initialized
DEBUG - 2022-03-16 01:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:37:08 --> Input Class Initialized
INFO - 2022-03-16 01:37:08 --> Language Class Initialized
INFO - 2022-03-16 01:37:08 --> Loader Class Initialized
INFO - 2022-03-16 01:37:08 --> Helper loaded: url_helper
INFO - 2022-03-16 01:37:08 --> Helper loaded: form_helper
INFO - 2022-03-16 01:37:08 --> Helper loaded: common_helper
INFO - 2022-03-16 01:37:08 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:37:08 --> Controller Class Initialized
INFO - 2022-03-16 01:37:08 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:37:08 --> Encrypt Class Initialized
INFO - 2022-03-16 01:37:08 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:37:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:37:08 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:37:08 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:37:08 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:37:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:37:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 01:37:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:37:09 --> Final output sent to browser
DEBUG - 2022-03-16 01:37:09 --> Total execution time: 0.3632
ERROR - 2022-03-16 01:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:37:10 --> Config Class Initialized
INFO - 2022-03-16 01:37:10 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:37:10 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:37:10 --> Utf8 Class Initialized
INFO - 2022-03-16 01:37:10 --> URI Class Initialized
INFO - 2022-03-16 01:37:10 --> Router Class Initialized
INFO - 2022-03-16 01:37:10 --> Output Class Initialized
INFO - 2022-03-16 01:37:10 --> Security Class Initialized
DEBUG - 2022-03-16 01:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:37:10 --> Input Class Initialized
INFO - 2022-03-16 01:37:10 --> Language Class Initialized
INFO - 2022-03-16 01:37:10 --> Loader Class Initialized
INFO - 2022-03-16 01:37:10 --> Helper loaded: url_helper
INFO - 2022-03-16 01:37:10 --> Helper loaded: form_helper
INFO - 2022-03-16 01:37:10 --> Helper loaded: common_helper
INFO - 2022-03-16 01:37:10 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:37:10 --> Controller Class Initialized
INFO - 2022-03-16 01:37:10 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:37:10 --> Encrypt Class Initialized
INFO - 2022-03-16 01:37:10 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:37:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:37:10 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:37:10 --> Model "Users_model" initialized
INFO - 2022-03-16 01:37:10 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:37:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:37:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 01:37:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:37:10 --> Final output sent to browser
DEBUG - 2022-03-16 01:37:10 --> Total execution time: 0.2162
ERROR - 2022-03-16 01:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:40:55 --> Config Class Initialized
INFO - 2022-03-16 01:40:55 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:40:55 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:40:55 --> Utf8 Class Initialized
INFO - 2022-03-16 01:40:55 --> URI Class Initialized
INFO - 2022-03-16 01:40:55 --> Router Class Initialized
INFO - 2022-03-16 01:40:55 --> Output Class Initialized
INFO - 2022-03-16 01:40:55 --> Security Class Initialized
DEBUG - 2022-03-16 01:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:40:55 --> Input Class Initialized
INFO - 2022-03-16 01:40:55 --> Language Class Initialized
INFO - 2022-03-16 01:40:55 --> Loader Class Initialized
INFO - 2022-03-16 01:40:55 --> Helper loaded: url_helper
INFO - 2022-03-16 01:40:55 --> Helper loaded: form_helper
INFO - 2022-03-16 01:40:55 --> Helper loaded: common_helper
INFO - 2022-03-16 01:40:55 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:40:55 --> Controller Class Initialized
INFO - 2022-03-16 01:40:55 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:40:55 --> Encrypt Class Initialized
INFO - 2022-03-16 01:40:55 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:40:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:40:55 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:40:55 --> Model "Users_model" initialized
INFO - 2022-03-16 01:40:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 01:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:40:56 --> Config Class Initialized
INFO - 2022-03-16 01:40:56 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:40:56 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:40:56 --> Utf8 Class Initialized
INFO - 2022-03-16 01:40:56 --> URI Class Initialized
INFO - 2022-03-16 01:40:56 --> Router Class Initialized
INFO - 2022-03-16 01:40:56 --> Output Class Initialized
INFO - 2022-03-16 01:40:56 --> Security Class Initialized
DEBUG - 2022-03-16 01:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:40:56 --> Input Class Initialized
INFO - 2022-03-16 01:40:56 --> Language Class Initialized
INFO - 2022-03-16 01:40:56 --> Loader Class Initialized
INFO - 2022-03-16 01:40:56 --> Helper loaded: url_helper
INFO - 2022-03-16 01:40:56 --> Helper loaded: form_helper
INFO - 2022-03-16 01:40:56 --> Helper loaded: common_helper
INFO - 2022-03-16 01:40:56 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:40:56 --> Controller Class Initialized
INFO - 2022-03-16 01:40:56 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:40:56 --> Encrypt Class Initialized
INFO - 2022-03-16 01:40:56 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:40:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:40:56 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:40:56 --> Model "Users_model" initialized
INFO - 2022-03-16 01:40:56 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:40:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:40:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 01:40:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:40:56 --> Final output sent to browser
DEBUG - 2022-03-16 01:40:56 --> Total execution time: 0.0565
ERROR - 2022-03-16 01:43:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:43:20 --> Config Class Initialized
INFO - 2022-03-16 01:43:20 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:43:20 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:43:20 --> Utf8 Class Initialized
INFO - 2022-03-16 01:43:20 --> URI Class Initialized
INFO - 2022-03-16 01:43:20 --> Router Class Initialized
INFO - 2022-03-16 01:43:20 --> Output Class Initialized
INFO - 2022-03-16 01:43:20 --> Security Class Initialized
DEBUG - 2022-03-16 01:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:43:20 --> Input Class Initialized
INFO - 2022-03-16 01:43:20 --> Language Class Initialized
INFO - 2022-03-16 01:43:20 --> Loader Class Initialized
INFO - 2022-03-16 01:43:20 --> Helper loaded: url_helper
INFO - 2022-03-16 01:43:20 --> Helper loaded: form_helper
INFO - 2022-03-16 01:43:20 --> Helper loaded: common_helper
INFO - 2022-03-16 01:43:20 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:43:20 --> Controller Class Initialized
INFO - 2022-03-16 01:43:20 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:43:20 --> Encrypt Class Initialized
INFO - 2022-03-16 01:43:20 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:43:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:43:20 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:43:20 --> Model "Users_model" initialized
INFO - 2022-03-16 01:43:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 01:43:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:43:20 --> Config Class Initialized
INFO - 2022-03-16 01:43:20 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:43:20 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:43:20 --> Utf8 Class Initialized
INFO - 2022-03-16 01:43:20 --> URI Class Initialized
INFO - 2022-03-16 01:43:20 --> Router Class Initialized
INFO - 2022-03-16 01:43:20 --> Output Class Initialized
INFO - 2022-03-16 01:43:20 --> Security Class Initialized
DEBUG - 2022-03-16 01:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:43:20 --> Input Class Initialized
INFO - 2022-03-16 01:43:20 --> Language Class Initialized
INFO - 2022-03-16 01:43:20 --> Loader Class Initialized
INFO - 2022-03-16 01:43:20 --> Helper loaded: url_helper
INFO - 2022-03-16 01:43:20 --> Helper loaded: form_helper
INFO - 2022-03-16 01:43:20 --> Helper loaded: common_helper
INFO - 2022-03-16 01:43:20 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:43:20 --> Controller Class Initialized
INFO - 2022-03-16 01:43:20 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:43:20 --> Encrypt Class Initialized
INFO - 2022-03-16 01:43:20 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:43:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:43:20 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:43:20 --> Model "Users_model" initialized
INFO - 2022-03-16 01:43:20 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:43:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:43:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 01:43:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:43:20 --> Final output sent to browser
DEBUG - 2022-03-16 01:43:20 --> Total execution time: 0.0541
ERROR - 2022-03-16 01:44:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:44:16 --> Config Class Initialized
INFO - 2022-03-16 01:44:16 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:44:16 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:44:16 --> Utf8 Class Initialized
INFO - 2022-03-16 01:44:16 --> URI Class Initialized
INFO - 2022-03-16 01:44:16 --> Router Class Initialized
INFO - 2022-03-16 01:44:16 --> Output Class Initialized
INFO - 2022-03-16 01:44:16 --> Security Class Initialized
DEBUG - 2022-03-16 01:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:44:16 --> Input Class Initialized
INFO - 2022-03-16 01:44:16 --> Language Class Initialized
INFO - 2022-03-16 01:44:16 --> Loader Class Initialized
INFO - 2022-03-16 01:44:16 --> Helper loaded: url_helper
INFO - 2022-03-16 01:44:16 --> Helper loaded: form_helper
INFO - 2022-03-16 01:44:16 --> Helper loaded: common_helper
INFO - 2022-03-16 01:44:16 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:44:16 --> Controller Class Initialized
INFO - 2022-03-16 01:44:16 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:44:16 --> Encrypt Class Initialized
INFO - 2022-03-16 01:44:16 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:44:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:44:16 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:44:16 --> Model "Users_model" initialized
INFO - 2022-03-16 01:44:16 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:44:16 --> Upload Class Initialized
INFO - 2022-03-16 01:44:16 --> Final output sent to browser
DEBUG - 2022-03-16 01:44:16 --> Total execution time: 0.0559
ERROR - 2022-03-16 01:44:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:44:38 --> Config Class Initialized
INFO - 2022-03-16 01:44:38 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:44:38 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:44:38 --> Utf8 Class Initialized
INFO - 2022-03-16 01:44:38 --> URI Class Initialized
INFO - 2022-03-16 01:44:38 --> Router Class Initialized
INFO - 2022-03-16 01:44:38 --> Output Class Initialized
INFO - 2022-03-16 01:44:38 --> Security Class Initialized
DEBUG - 2022-03-16 01:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:44:38 --> Input Class Initialized
INFO - 2022-03-16 01:44:38 --> Language Class Initialized
INFO - 2022-03-16 01:44:38 --> Loader Class Initialized
INFO - 2022-03-16 01:44:38 --> Helper loaded: url_helper
INFO - 2022-03-16 01:44:38 --> Helper loaded: form_helper
INFO - 2022-03-16 01:44:38 --> Helper loaded: common_helper
INFO - 2022-03-16 01:44:38 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:44:38 --> Controller Class Initialized
INFO - 2022-03-16 01:44:38 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:44:38 --> Encrypt Class Initialized
INFO - 2022-03-16 01:44:38 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:44:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:44:38 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:44:38 --> Model "Users_model" initialized
INFO - 2022-03-16 01:44:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 01:44:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:44:38 --> Config Class Initialized
INFO - 2022-03-16 01:44:38 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:44:38 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:44:38 --> Utf8 Class Initialized
INFO - 2022-03-16 01:44:38 --> URI Class Initialized
INFO - 2022-03-16 01:44:38 --> Router Class Initialized
INFO - 2022-03-16 01:44:38 --> Output Class Initialized
INFO - 2022-03-16 01:44:38 --> Security Class Initialized
DEBUG - 2022-03-16 01:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:44:38 --> Input Class Initialized
INFO - 2022-03-16 01:44:38 --> Language Class Initialized
INFO - 2022-03-16 01:44:38 --> Loader Class Initialized
INFO - 2022-03-16 01:44:38 --> Helper loaded: url_helper
INFO - 2022-03-16 01:44:38 --> Helper loaded: form_helper
INFO - 2022-03-16 01:44:38 --> Helper loaded: common_helper
INFO - 2022-03-16 01:44:38 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:44:38 --> Controller Class Initialized
INFO - 2022-03-16 01:44:38 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:44:38 --> Encrypt Class Initialized
INFO - 2022-03-16 01:44:38 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:44:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:44:38 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:44:38 --> Model "Users_model" initialized
INFO - 2022-03-16 01:44:38 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:44:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:44:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 01:44:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:44:39 --> Final output sent to browser
DEBUG - 2022-03-16 01:44:39 --> Total execution time: 0.0849
ERROR - 2022-03-16 01:50:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:50:48 --> Config Class Initialized
INFO - 2022-03-16 01:50:48 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:50:48 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:50:48 --> Utf8 Class Initialized
INFO - 2022-03-16 01:50:48 --> URI Class Initialized
INFO - 2022-03-16 01:50:48 --> Router Class Initialized
INFO - 2022-03-16 01:50:48 --> Output Class Initialized
INFO - 2022-03-16 01:50:48 --> Security Class Initialized
DEBUG - 2022-03-16 01:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:50:48 --> Input Class Initialized
INFO - 2022-03-16 01:50:48 --> Language Class Initialized
INFO - 2022-03-16 01:50:48 --> Loader Class Initialized
INFO - 2022-03-16 01:50:48 --> Helper loaded: url_helper
INFO - 2022-03-16 01:50:48 --> Helper loaded: form_helper
INFO - 2022-03-16 01:50:48 --> Helper loaded: common_helper
INFO - 2022-03-16 01:50:48 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:50:48 --> Controller Class Initialized
INFO - 2022-03-16 01:50:48 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:50:48 --> Encrypt Class Initialized
INFO - 2022-03-16 01:50:48 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:50:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:50:48 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:50:48 --> Model "Users_model" initialized
INFO - 2022-03-16 01:50:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 01:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:50:49 --> Config Class Initialized
INFO - 2022-03-16 01:50:49 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:50:49 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:50:49 --> Utf8 Class Initialized
INFO - 2022-03-16 01:50:49 --> URI Class Initialized
INFO - 2022-03-16 01:50:49 --> Router Class Initialized
INFO - 2022-03-16 01:50:49 --> Output Class Initialized
INFO - 2022-03-16 01:50:49 --> Security Class Initialized
DEBUG - 2022-03-16 01:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:50:49 --> Input Class Initialized
INFO - 2022-03-16 01:50:49 --> Language Class Initialized
INFO - 2022-03-16 01:50:49 --> Loader Class Initialized
INFO - 2022-03-16 01:50:49 --> Helper loaded: url_helper
INFO - 2022-03-16 01:50:49 --> Helper loaded: form_helper
INFO - 2022-03-16 01:50:49 --> Helper loaded: common_helper
INFO - 2022-03-16 01:50:49 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:50:49 --> Controller Class Initialized
INFO - 2022-03-16 01:50:49 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:50:49 --> Encrypt Class Initialized
INFO - 2022-03-16 01:50:49 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:50:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:50:49 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:50:49 --> Model "Users_model" initialized
INFO - 2022-03-16 01:50:49 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:50:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:50:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 01:50:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:50:49 --> Final output sent to browser
DEBUG - 2022-03-16 01:50:49 --> Total execution time: 0.0521
ERROR - 2022-03-16 01:55:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 01:55:31 --> Config Class Initialized
INFO - 2022-03-16 01:55:31 --> Hooks Class Initialized
DEBUG - 2022-03-16 01:55:31 --> UTF-8 Support Enabled
INFO - 2022-03-16 01:55:31 --> Utf8 Class Initialized
INFO - 2022-03-16 01:55:31 --> URI Class Initialized
INFO - 2022-03-16 01:55:31 --> Router Class Initialized
INFO - 2022-03-16 01:55:31 --> Output Class Initialized
INFO - 2022-03-16 01:55:31 --> Security Class Initialized
DEBUG - 2022-03-16 01:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 01:55:31 --> Input Class Initialized
INFO - 2022-03-16 01:55:31 --> Language Class Initialized
INFO - 2022-03-16 01:55:31 --> Loader Class Initialized
INFO - 2022-03-16 01:55:31 --> Helper loaded: url_helper
INFO - 2022-03-16 01:55:31 --> Helper loaded: form_helper
INFO - 2022-03-16 01:55:31 --> Helper loaded: common_helper
INFO - 2022-03-16 01:55:31 --> Database Driver Class Initialized
DEBUG - 2022-03-16 01:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 01:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 01:55:31 --> Controller Class Initialized
INFO - 2022-03-16 01:55:31 --> Form Validation Class Initialized
DEBUG - 2022-03-16 01:55:31 --> Encrypt Class Initialized
INFO - 2022-03-16 01:55:31 --> Model "Patient_model" initialized
INFO - 2022-03-16 01:55:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 01:55:31 --> Model "Referredby_model" initialized
INFO - 2022-03-16 01:55:31 --> Model "Prefix_master" initialized
INFO - 2022-03-16 01:55:32 --> Model "Hospital_model" initialized
INFO - 2022-03-16 01:55:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 01:55:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 01:55:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 01:55:32 --> Final output sent to browser
DEBUG - 2022-03-16 01:55:32 --> Total execution time: 0.0336
ERROR - 2022-03-16 02:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:24:42 --> Config Class Initialized
INFO - 2022-03-16 02:24:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:24:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:24:42 --> Utf8 Class Initialized
INFO - 2022-03-16 02:24:42 --> URI Class Initialized
INFO - 2022-03-16 02:24:42 --> Router Class Initialized
INFO - 2022-03-16 02:24:42 --> Output Class Initialized
INFO - 2022-03-16 02:24:42 --> Security Class Initialized
DEBUG - 2022-03-16 02:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:24:42 --> Input Class Initialized
INFO - 2022-03-16 02:24:42 --> Language Class Initialized
INFO - 2022-03-16 02:24:42 --> Loader Class Initialized
INFO - 2022-03-16 02:24:42 --> Helper loaded: url_helper
INFO - 2022-03-16 02:24:42 --> Helper loaded: form_helper
INFO - 2022-03-16 02:24:42 --> Helper loaded: common_helper
INFO - 2022-03-16 02:24:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:24:42 --> Controller Class Initialized
INFO - 2022-03-16 02:24:42 --> Model "Referredby_model" initialized
INFO - 2022-03-16 02:24:42 --> Final output sent to browser
DEBUG - 2022-03-16 02:24:42 --> Total execution time: 0.0226
ERROR - 2022-03-16 02:25:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:25:34 --> Config Class Initialized
INFO - 2022-03-16 02:25:34 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:25:34 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:25:34 --> Utf8 Class Initialized
INFO - 2022-03-16 02:25:34 --> URI Class Initialized
INFO - 2022-03-16 02:25:34 --> Router Class Initialized
INFO - 2022-03-16 02:25:34 --> Output Class Initialized
INFO - 2022-03-16 02:25:34 --> Security Class Initialized
DEBUG - 2022-03-16 02:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:25:34 --> Input Class Initialized
INFO - 2022-03-16 02:25:34 --> Language Class Initialized
INFO - 2022-03-16 02:25:34 --> Loader Class Initialized
INFO - 2022-03-16 02:25:34 --> Helper loaded: url_helper
INFO - 2022-03-16 02:25:34 --> Helper loaded: form_helper
INFO - 2022-03-16 02:25:34 --> Helper loaded: common_helper
INFO - 2022-03-16 02:25:34 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:25:34 --> Controller Class Initialized
INFO - 2022-03-16 02:25:34 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:25:34 --> Encrypt Class Initialized
INFO - 2022-03-16 02:25:34 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:25:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:25:34 --> Model "Referredby_model" initialized
INFO - 2022-03-16 02:25:34 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:25:34 --> Model "Hospital_model" initialized
INFO - 2022-03-16 02:25:34 --> Final output sent to browser
DEBUG - 2022-03-16 02:25:34 --> Total execution time: 0.0389
ERROR - 2022-03-16 02:25:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:25:46 --> Config Class Initialized
INFO - 2022-03-16 02:25:46 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:25:46 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:25:46 --> Utf8 Class Initialized
INFO - 2022-03-16 02:25:46 --> URI Class Initialized
INFO - 2022-03-16 02:25:46 --> Router Class Initialized
INFO - 2022-03-16 02:25:46 --> Output Class Initialized
INFO - 2022-03-16 02:25:46 --> Security Class Initialized
DEBUG - 2022-03-16 02:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:25:46 --> Input Class Initialized
INFO - 2022-03-16 02:25:46 --> Language Class Initialized
INFO - 2022-03-16 02:25:46 --> Loader Class Initialized
INFO - 2022-03-16 02:25:46 --> Helper loaded: url_helper
INFO - 2022-03-16 02:25:46 --> Helper loaded: form_helper
INFO - 2022-03-16 02:25:46 --> Helper loaded: common_helper
INFO - 2022-03-16 02:25:46 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:25:46 --> Controller Class Initialized
INFO - 2022-03-16 02:25:46 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:25:46 --> Encrypt Class Initialized
INFO - 2022-03-16 02:25:46 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:25:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:25:46 --> Model "Referredby_model" initialized
INFO - 2022-03-16 02:25:46 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:25:46 --> Model "Hospital_model" initialized
INFO - 2022-03-16 02:25:46 --> Final output sent to browser
DEBUG - 2022-03-16 02:25:46 --> Total execution time: 0.0296
ERROR - 2022-03-16 02:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:38:19 --> Config Class Initialized
INFO - 2022-03-16 02:38:19 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:38:19 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:38:19 --> Utf8 Class Initialized
INFO - 2022-03-16 02:38:19 --> URI Class Initialized
INFO - 2022-03-16 02:38:19 --> Router Class Initialized
INFO - 2022-03-16 02:38:19 --> Output Class Initialized
INFO - 2022-03-16 02:38:19 --> Security Class Initialized
DEBUG - 2022-03-16 02:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:38:19 --> Input Class Initialized
INFO - 2022-03-16 02:38:19 --> Language Class Initialized
INFO - 2022-03-16 02:38:19 --> Loader Class Initialized
INFO - 2022-03-16 02:38:19 --> Helper loaded: url_helper
INFO - 2022-03-16 02:38:19 --> Helper loaded: form_helper
INFO - 2022-03-16 02:38:19 --> Helper loaded: common_helper
INFO - 2022-03-16 02:38:19 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:38:19 --> Controller Class Initialized
INFO - 2022-03-16 02:38:19 --> Model "Referredby_model" initialized
INFO - 2022-03-16 02:38:19 --> Final output sent to browser
DEBUG - 2022-03-16 02:38:19 --> Total execution time: 0.0350
ERROR - 2022-03-16 02:41:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:41:42 --> Config Class Initialized
INFO - 2022-03-16 02:41:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:41:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:41:42 --> Utf8 Class Initialized
INFO - 2022-03-16 02:41:42 --> URI Class Initialized
INFO - 2022-03-16 02:41:42 --> Router Class Initialized
INFO - 2022-03-16 02:41:42 --> Output Class Initialized
INFO - 2022-03-16 02:41:42 --> Security Class Initialized
DEBUG - 2022-03-16 02:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:41:42 --> Input Class Initialized
INFO - 2022-03-16 02:41:42 --> Language Class Initialized
INFO - 2022-03-16 02:41:42 --> Loader Class Initialized
INFO - 2022-03-16 02:41:42 --> Helper loaded: url_helper
INFO - 2022-03-16 02:41:42 --> Helper loaded: form_helper
INFO - 2022-03-16 02:41:42 --> Helper loaded: common_helper
INFO - 2022-03-16 02:41:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:41:42 --> Controller Class Initialized
INFO - 2022-03-16 02:41:42 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:41:42 --> Encrypt Class Initialized
INFO - 2022-03-16 02:41:42 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:41:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:41:42 --> Model "Referredby_model" initialized
INFO - 2022-03-16 02:41:42 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:41:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 02:41:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:41:42 --> Config Class Initialized
INFO - 2022-03-16 02:41:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:41:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:41:42 --> Utf8 Class Initialized
INFO - 2022-03-16 02:41:42 --> URI Class Initialized
INFO - 2022-03-16 02:41:42 --> Router Class Initialized
INFO - 2022-03-16 02:41:42 --> Output Class Initialized
INFO - 2022-03-16 02:41:42 --> Security Class Initialized
DEBUG - 2022-03-16 02:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:41:42 --> Input Class Initialized
INFO - 2022-03-16 02:41:42 --> Language Class Initialized
INFO - 2022-03-16 02:41:42 --> Loader Class Initialized
INFO - 2022-03-16 02:41:42 --> Helper loaded: url_helper
INFO - 2022-03-16 02:41:42 --> Helper loaded: form_helper
INFO - 2022-03-16 02:41:42 --> Helper loaded: common_helper
INFO - 2022-03-16 02:41:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:41:42 --> Controller Class Initialized
INFO - 2022-03-16 02:41:42 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:41:42 --> Encrypt Class Initialized
INFO - 2022-03-16 02:41:42 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:41:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:41:42 --> Model "Referredby_model" initialized
INFO - 2022-03-16 02:41:42 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:41:42 --> Model "Hospital_model" initialized
INFO - 2022-03-16 02:41:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 02:41:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 02:41:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 02:41:43 --> Final output sent to browser
DEBUG - 2022-03-16 02:41:43 --> Total execution time: 0.1120
ERROR - 2022-03-16 02:41:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:41:43 --> Config Class Initialized
INFO - 2022-03-16 02:41:43 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:41:43 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:41:43 --> Utf8 Class Initialized
INFO - 2022-03-16 02:41:43 --> URI Class Initialized
INFO - 2022-03-16 02:41:43 --> Router Class Initialized
INFO - 2022-03-16 02:41:43 --> Output Class Initialized
INFO - 2022-03-16 02:41:43 --> Security Class Initialized
DEBUG - 2022-03-16 02:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:41:43 --> Input Class Initialized
INFO - 2022-03-16 02:41:43 --> Language Class Initialized
INFO - 2022-03-16 02:41:43 --> Loader Class Initialized
INFO - 2022-03-16 02:41:43 --> Helper loaded: url_helper
INFO - 2022-03-16 02:41:43 --> Helper loaded: form_helper
INFO - 2022-03-16 02:41:43 --> Helper loaded: common_helper
INFO - 2022-03-16 02:41:43 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:41:43 --> Controller Class Initialized
INFO - 2022-03-16 02:41:43 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:41:43 --> Encrypt Class Initialized
INFO - 2022-03-16 02:41:43 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:41:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:41:43 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:41:43 --> Model "Users_model" initialized
INFO - 2022-03-16 02:41:43 --> Model "Hospital_model" initialized
INFO - 2022-03-16 02:41:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 02:41:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 02:41:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 02:41:44 --> Final output sent to browser
DEBUG - 2022-03-16 02:41:44 --> Total execution time: 0.1231
ERROR - 2022-03-16 02:44:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:44:41 --> Config Class Initialized
INFO - 2022-03-16 02:44:41 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:44:41 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:44:41 --> Utf8 Class Initialized
INFO - 2022-03-16 02:44:41 --> URI Class Initialized
INFO - 2022-03-16 02:44:41 --> Router Class Initialized
INFO - 2022-03-16 02:44:41 --> Output Class Initialized
INFO - 2022-03-16 02:44:41 --> Security Class Initialized
DEBUG - 2022-03-16 02:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:44:41 --> Input Class Initialized
INFO - 2022-03-16 02:44:41 --> Language Class Initialized
INFO - 2022-03-16 02:44:41 --> Loader Class Initialized
INFO - 2022-03-16 02:44:41 --> Helper loaded: url_helper
INFO - 2022-03-16 02:44:41 --> Helper loaded: form_helper
INFO - 2022-03-16 02:44:41 --> Helper loaded: common_helper
INFO - 2022-03-16 02:44:41 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:44:41 --> Controller Class Initialized
INFO - 2022-03-16 02:44:41 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:44:41 --> Encrypt Class Initialized
INFO - 2022-03-16 02:44:41 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:44:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:44:41 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:44:41 --> Model "Users_model" initialized
INFO - 2022-03-16 02:44:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 02:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:44:42 --> Config Class Initialized
INFO - 2022-03-16 02:44:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:44:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:44:42 --> Utf8 Class Initialized
INFO - 2022-03-16 02:44:42 --> URI Class Initialized
INFO - 2022-03-16 02:44:42 --> Router Class Initialized
INFO - 2022-03-16 02:44:42 --> Output Class Initialized
INFO - 2022-03-16 02:44:42 --> Security Class Initialized
DEBUG - 2022-03-16 02:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:44:42 --> Input Class Initialized
INFO - 2022-03-16 02:44:42 --> Language Class Initialized
INFO - 2022-03-16 02:44:42 --> Loader Class Initialized
INFO - 2022-03-16 02:44:42 --> Helper loaded: url_helper
INFO - 2022-03-16 02:44:42 --> Helper loaded: form_helper
INFO - 2022-03-16 02:44:42 --> Helper loaded: common_helper
INFO - 2022-03-16 02:44:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:44:42 --> Controller Class Initialized
INFO - 2022-03-16 02:44:42 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:44:42 --> Encrypt Class Initialized
INFO - 2022-03-16 02:44:42 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:44:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:44:42 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:44:42 --> Model "Users_model" initialized
INFO - 2022-03-16 02:44:42 --> Model "Hospital_model" initialized
INFO - 2022-03-16 02:44:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 02:44:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 02:44:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 02:44:42 --> Final output sent to browser
DEBUG - 2022-03-16 02:44:42 --> Total execution time: 0.0821
ERROR - 2022-03-16 02:46:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:46:48 --> Config Class Initialized
INFO - 2022-03-16 02:46:48 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:46:48 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:46:48 --> Utf8 Class Initialized
INFO - 2022-03-16 02:46:48 --> URI Class Initialized
INFO - 2022-03-16 02:46:48 --> Router Class Initialized
INFO - 2022-03-16 02:46:48 --> Output Class Initialized
INFO - 2022-03-16 02:46:48 --> Security Class Initialized
DEBUG - 2022-03-16 02:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:46:48 --> Input Class Initialized
INFO - 2022-03-16 02:46:48 --> Language Class Initialized
INFO - 2022-03-16 02:46:48 --> Loader Class Initialized
INFO - 2022-03-16 02:46:48 --> Helper loaded: url_helper
INFO - 2022-03-16 02:46:48 --> Helper loaded: form_helper
INFO - 2022-03-16 02:46:48 --> Helper loaded: common_helper
INFO - 2022-03-16 02:46:48 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:46:48 --> Controller Class Initialized
INFO - 2022-03-16 02:46:48 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:46:48 --> Encrypt Class Initialized
INFO - 2022-03-16 02:46:48 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:46:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:46:48 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:46:48 --> Model "Users_model" initialized
INFO - 2022-03-16 02:46:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 02:46:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:46:49 --> Config Class Initialized
INFO - 2022-03-16 02:46:49 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:46:49 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:46:49 --> Utf8 Class Initialized
INFO - 2022-03-16 02:46:49 --> URI Class Initialized
INFO - 2022-03-16 02:46:49 --> Router Class Initialized
INFO - 2022-03-16 02:46:49 --> Output Class Initialized
INFO - 2022-03-16 02:46:49 --> Security Class Initialized
DEBUG - 2022-03-16 02:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:46:49 --> Input Class Initialized
INFO - 2022-03-16 02:46:49 --> Language Class Initialized
INFO - 2022-03-16 02:46:49 --> Loader Class Initialized
INFO - 2022-03-16 02:46:49 --> Helper loaded: url_helper
INFO - 2022-03-16 02:46:49 --> Helper loaded: form_helper
INFO - 2022-03-16 02:46:49 --> Helper loaded: common_helper
INFO - 2022-03-16 02:46:49 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:46:49 --> Controller Class Initialized
INFO - 2022-03-16 02:46:49 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:46:49 --> Encrypt Class Initialized
INFO - 2022-03-16 02:46:49 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:46:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:46:49 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:46:49 --> Model "Users_model" initialized
INFO - 2022-03-16 02:46:49 --> Model "Hospital_model" initialized
INFO - 2022-03-16 02:46:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 02:46:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 02:46:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 02:46:49 --> Final output sent to browser
DEBUG - 2022-03-16 02:46:49 --> Total execution time: 0.1442
ERROR - 2022-03-16 02:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:48:04 --> Config Class Initialized
INFO - 2022-03-16 02:48:04 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:48:04 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:48:04 --> Utf8 Class Initialized
INFO - 2022-03-16 02:48:04 --> URI Class Initialized
INFO - 2022-03-16 02:48:04 --> Router Class Initialized
INFO - 2022-03-16 02:48:04 --> Output Class Initialized
INFO - 2022-03-16 02:48:04 --> Security Class Initialized
DEBUG - 2022-03-16 02:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:48:04 --> Input Class Initialized
INFO - 2022-03-16 02:48:04 --> Language Class Initialized
INFO - 2022-03-16 02:48:04 --> Loader Class Initialized
INFO - 2022-03-16 02:48:04 --> Helper loaded: url_helper
INFO - 2022-03-16 02:48:04 --> Helper loaded: form_helper
INFO - 2022-03-16 02:48:04 --> Helper loaded: common_helper
INFO - 2022-03-16 02:48:04 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:48:04 --> Controller Class Initialized
INFO - 2022-03-16 02:48:04 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:48:04 --> Encrypt Class Initialized
INFO - 2022-03-16 02:48:04 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:48:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:48:04 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:48:04 --> Model "Users_model" initialized
INFO - 2022-03-16 02:48:04 --> Model "Hospital_model" initialized
INFO - 2022-03-16 02:48:04 --> Upload Class Initialized
INFO - 2022-03-16 02:48:04 --> Final output sent to browser
DEBUG - 2022-03-16 02:48:04 --> Total execution time: 0.0622
ERROR - 2022-03-16 02:48:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:48:15 --> Config Class Initialized
INFO - 2022-03-16 02:48:15 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:48:15 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:48:15 --> Utf8 Class Initialized
INFO - 2022-03-16 02:48:15 --> URI Class Initialized
INFO - 2022-03-16 02:48:15 --> Router Class Initialized
INFO - 2022-03-16 02:48:15 --> Output Class Initialized
INFO - 2022-03-16 02:48:15 --> Security Class Initialized
DEBUG - 2022-03-16 02:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:48:15 --> Input Class Initialized
INFO - 2022-03-16 02:48:15 --> Language Class Initialized
INFO - 2022-03-16 02:48:15 --> Loader Class Initialized
INFO - 2022-03-16 02:48:15 --> Helper loaded: url_helper
INFO - 2022-03-16 02:48:15 --> Helper loaded: form_helper
INFO - 2022-03-16 02:48:15 --> Helper loaded: common_helper
INFO - 2022-03-16 02:48:15 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:48:15 --> Controller Class Initialized
INFO - 2022-03-16 02:48:15 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:48:15 --> Encrypt Class Initialized
INFO - 2022-03-16 02:48:15 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:48:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:48:15 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:48:15 --> Model "Users_model" initialized
INFO - 2022-03-16 02:48:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 02:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:48:16 --> Config Class Initialized
INFO - 2022-03-16 02:48:16 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:48:16 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:48:16 --> Utf8 Class Initialized
INFO - 2022-03-16 02:48:16 --> URI Class Initialized
INFO - 2022-03-16 02:48:16 --> Router Class Initialized
INFO - 2022-03-16 02:48:16 --> Output Class Initialized
INFO - 2022-03-16 02:48:16 --> Security Class Initialized
DEBUG - 2022-03-16 02:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:48:16 --> Input Class Initialized
INFO - 2022-03-16 02:48:16 --> Language Class Initialized
INFO - 2022-03-16 02:48:16 --> Loader Class Initialized
INFO - 2022-03-16 02:48:16 --> Helper loaded: url_helper
INFO - 2022-03-16 02:48:16 --> Helper loaded: form_helper
INFO - 2022-03-16 02:48:16 --> Helper loaded: common_helper
INFO - 2022-03-16 02:48:16 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:48:16 --> Controller Class Initialized
INFO - 2022-03-16 02:48:16 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:48:16 --> Encrypt Class Initialized
INFO - 2022-03-16 02:48:16 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:48:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:48:16 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:48:16 --> Model "Users_model" initialized
INFO - 2022-03-16 02:48:16 --> Model "Hospital_model" initialized
INFO - 2022-03-16 02:48:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 02:48:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 02:48:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 02:48:16 --> Final output sent to browser
DEBUG - 2022-03-16 02:48:16 --> Total execution time: 0.1406
ERROR - 2022-03-16 02:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:55:38 --> Config Class Initialized
INFO - 2022-03-16 02:55:38 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:55:38 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:55:38 --> Utf8 Class Initialized
INFO - 2022-03-16 02:55:38 --> URI Class Initialized
INFO - 2022-03-16 02:55:38 --> Router Class Initialized
INFO - 2022-03-16 02:55:38 --> Output Class Initialized
INFO - 2022-03-16 02:55:38 --> Security Class Initialized
DEBUG - 2022-03-16 02:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:55:38 --> Input Class Initialized
INFO - 2022-03-16 02:55:38 --> Language Class Initialized
INFO - 2022-03-16 02:55:38 --> Loader Class Initialized
INFO - 2022-03-16 02:55:38 --> Helper loaded: url_helper
INFO - 2022-03-16 02:55:38 --> Helper loaded: form_helper
INFO - 2022-03-16 02:55:38 --> Helper loaded: common_helper
INFO - 2022-03-16 02:55:38 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:55:38 --> Controller Class Initialized
INFO - 2022-03-16 02:55:38 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:55:38 --> Encrypt Class Initialized
INFO - 2022-03-16 02:55:38 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:55:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:55:38 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:55:38 --> Model "Users_model" initialized
INFO - 2022-03-16 02:55:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 02:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 02:55:38 --> Config Class Initialized
INFO - 2022-03-16 02:55:38 --> Hooks Class Initialized
DEBUG - 2022-03-16 02:55:38 --> UTF-8 Support Enabled
INFO - 2022-03-16 02:55:38 --> Utf8 Class Initialized
INFO - 2022-03-16 02:55:38 --> URI Class Initialized
INFO - 2022-03-16 02:55:38 --> Router Class Initialized
INFO - 2022-03-16 02:55:38 --> Output Class Initialized
INFO - 2022-03-16 02:55:38 --> Security Class Initialized
DEBUG - 2022-03-16 02:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 02:55:38 --> Input Class Initialized
INFO - 2022-03-16 02:55:38 --> Language Class Initialized
INFO - 2022-03-16 02:55:38 --> Loader Class Initialized
INFO - 2022-03-16 02:55:38 --> Helper loaded: url_helper
INFO - 2022-03-16 02:55:38 --> Helper loaded: form_helper
INFO - 2022-03-16 02:55:38 --> Helper loaded: common_helper
INFO - 2022-03-16 02:55:38 --> Database Driver Class Initialized
DEBUG - 2022-03-16 02:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 02:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 02:55:38 --> Controller Class Initialized
INFO - 2022-03-16 02:55:38 --> Form Validation Class Initialized
DEBUG - 2022-03-16 02:55:38 --> Encrypt Class Initialized
INFO - 2022-03-16 02:55:38 --> Model "Patient_model" initialized
INFO - 2022-03-16 02:55:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 02:55:38 --> Model "Prefix_master" initialized
INFO - 2022-03-16 02:55:38 --> Model "Users_model" initialized
INFO - 2022-03-16 02:55:38 --> Model "Hospital_model" initialized
INFO - 2022-03-16 02:55:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 02:55:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 02:55:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 02:55:38 --> Final output sent to browser
DEBUG - 2022-03-16 02:55:38 --> Total execution time: 0.0661
ERROR - 2022-03-16 03:00:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:00:52 --> Config Class Initialized
INFO - 2022-03-16 03:00:52 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:00:52 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:00:52 --> Utf8 Class Initialized
INFO - 2022-03-16 03:00:52 --> URI Class Initialized
INFO - 2022-03-16 03:00:52 --> Router Class Initialized
INFO - 2022-03-16 03:00:52 --> Output Class Initialized
INFO - 2022-03-16 03:00:52 --> Security Class Initialized
DEBUG - 2022-03-16 03:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:00:52 --> Input Class Initialized
INFO - 2022-03-16 03:00:52 --> Language Class Initialized
INFO - 2022-03-16 03:00:52 --> Loader Class Initialized
INFO - 2022-03-16 03:00:52 --> Helper loaded: url_helper
INFO - 2022-03-16 03:00:52 --> Helper loaded: form_helper
INFO - 2022-03-16 03:00:52 --> Helper loaded: common_helper
INFO - 2022-03-16 03:00:52 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:00:52 --> Controller Class Initialized
INFO - 2022-03-16 03:00:52 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:00:52 --> Encrypt Class Initialized
INFO - 2022-03-16 03:00:52 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:00:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:00:52 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:00:52 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:00:52 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:00:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:00:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 03:00:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:00:52 --> Final output sent to browser
DEBUG - 2022-03-16 03:00:52 --> Total execution time: 0.9170
ERROR - 2022-03-16 03:01:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:01:03 --> Config Class Initialized
INFO - 2022-03-16 03:01:03 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:01:03 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:01:03 --> Utf8 Class Initialized
INFO - 2022-03-16 03:01:03 --> URI Class Initialized
INFO - 2022-03-16 03:01:03 --> Router Class Initialized
INFO - 2022-03-16 03:01:03 --> Output Class Initialized
INFO - 2022-03-16 03:01:03 --> Security Class Initialized
DEBUG - 2022-03-16 03:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:01:03 --> Input Class Initialized
INFO - 2022-03-16 03:01:03 --> Language Class Initialized
INFO - 2022-03-16 03:01:03 --> Loader Class Initialized
INFO - 2022-03-16 03:01:03 --> Helper loaded: url_helper
INFO - 2022-03-16 03:01:03 --> Helper loaded: form_helper
INFO - 2022-03-16 03:01:03 --> Helper loaded: common_helper
INFO - 2022-03-16 03:01:03 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:01:04 --> Controller Class Initialized
INFO - 2022-03-16 03:01:04 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:01:04 --> Encrypt Class Initialized
INFO - 2022-03-16 03:01:04 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:01:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:01:04 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:01:04 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:01:04 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:01:04 --> Upload Class Initialized
INFO - 2022-03-16 03:01:04 --> Final output sent to browser
DEBUG - 2022-03-16 03:01:04 --> Total execution time: 0.1880
ERROR - 2022-03-16 03:01:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:01:09 --> Config Class Initialized
INFO - 2022-03-16 03:01:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:01:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:01:09 --> Utf8 Class Initialized
INFO - 2022-03-16 03:01:09 --> URI Class Initialized
INFO - 2022-03-16 03:01:09 --> Router Class Initialized
INFO - 2022-03-16 03:01:09 --> Output Class Initialized
INFO - 2022-03-16 03:01:09 --> Security Class Initialized
DEBUG - 2022-03-16 03:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:01:09 --> Input Class Initialized
INFO - 2022-03-16 03:01:09 --> Language Class Initialized
INFO - 2022-03-16 03:01:09 --> Loader Class Initialized
INFO - 2022-03-16 03:01:09 --> Helper loaded: url_helper
INFO - 2022-03-16 03:01:09 --> Helper loaded: form_helper
INFO - 2022-03-16 03:01:09 --> Helper loaded: common_helper
INFO - 2022-03-16 03:01:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:01:09 --> Controller Class Initialized
INFO - 2022-03-16 03:01:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:01:09 --> Encrypt Class Initialized
INFO - 2022-03-16 03:01:09 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:01:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:01:09 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:01:09 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:01:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 03:01:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:01:10 --> Config Class Initialized
INFO - 2022-03-16 03:01:10 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:01:10 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:01:10 --> Utf8 Class Initialized
INFO - 2022-03-16 03:01:10 --> URI Class Initialized
INFO - 2022-03-16 03:01:10 --> Router Class Initialized
INFO - 2022-03-16 03:01:10 --> Output Class Initialized
INFO - 2022-03-16 03:01:10 --> Security Class Initialized
DEBUG - 2022-03-16 03:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:01:10 --> Input Class Initialized
INFO - 2022-03-16 03:01:10 --> Language Class Initialized
INFO - 2022-03-16 03:01:10 --> Loader Class Initialized
INFO - 2022-03-16 03:01:10 --> Helper loaded: url_helper
INFO - 2022-03-16 03:01:10 --> Helper loaded: form_helper
INFO - 2022-03-16 03:01:10 --> Helper loaded: common_helper
INFO - 2022-03-16 03:01:10 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:01:10 --> Controller Class Initialized
INFO - 2022-03-16 03:01:10 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:01:10 --> Encrypt Class Initialized
INFO - 2022-03-16 03:01:10 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:01:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:01:10 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:01:10 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:01:10 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:01:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:01:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 03:01:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:01:10 --> Final output sent to browser
DEBUG - 2022-03-16 03:01:10 --> Total execution time: 0.0820
ERROR - 2022-03-16 03:01:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:01:11 --> Config Class Initialized
INFO - 2022-03-16 03:01:11 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:01:11 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:01:11 --> Utf8 Class Initialized
INFO - 2022-03-16 03:01:11 --> URI Class Initialized
INFO - 2022-03-16 03:01:11 --> Router Class Initialized
INFO - 2022-03-16 03:01:11 --> Output Class Initialized
INFO - 2022-03-16 03:01:11 --> Security Class Initialized
DEBUG - 2022-03-16 03:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:01:11 --> Input Class Initialized
INFO - 2022-03-16 03:01:11 --> Language Class Initialized
INFO - 2022-03-16 03:01:11 --> Loader Class Initialized
INFO - 2022-03-16 03:01:11 --> Helper loaded: url_helper
INFO - 2022-03-16 03:01:11 --> Helper loaded: form_helper
INFO - 2022-03-16 03:01:11 --> Helper loaded: common_helper
INFO - 2022-03-16 03:01:11 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:01:11 --> Controller Class Initialized
INFO - 2022-03-16 03:01:11 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:01:11 --> Encrypt Class Initialized
INFO - 2022-03-16 03:01:11 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:01:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:01:11 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:01:11 --> Model "Users_model" initialized
INFO - 2022-03-16 03:01:11 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:01:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:01:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 03:01:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:01:11 --> Final output sent to browser
DEBUG - 2022-03-16 03:01:11 --> Total execution time: 0.0726
ERROR - 2022-03-16 03:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:01:16 --> Config Class Initialized
INFO - 2022-03-16 03:01:16 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:01:16 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:01:16 --> Utf8 Class Initialized
INFO - 2022-03-16 03:01:16 --> URI Class Initialized
INFO - 2022-03-16 03:01:16 --> Router Class Initialized
INFO - 2022-03-16 03:01:16 --> Output Class Initialized
INFO - 2022-03-16 03:01:16 --> Security Class Initialized
DEBUG - 2022-03-16 03:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:01:16 --> Input Class Initialized
INFO - 2022-03-16 03:01:16 --> Language Class Initialized
INFO - 2022-03-16 03:01:16 --> Loader Class Initialized
INFO - 2022-03-16 03:01:16 --> Helper loaded: url_helper
INFO - 2022-03-16 03:01:16 --> Helper loaded: form_helper
INFO - 2022-03-16 03:01:16 --> Helper loaded: common_helper
INFO - 2022-03-16 03:01:16 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:01:16 --> Controller Class Initialized
INFO - 2022-03-16 03:01:16 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:01:16 --> Encrypt Class Initialized
INFO - 2022-03-16 03:01:16 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:01:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:01:16 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:01:16 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:01:16 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:01:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:01:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 03:01:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:01:29 --> Final output sent to browser
DEBUG - 2022-03-16 03:01:29 --> Total execution time: 10.9191
ERROR - 2022-03-16 03:04:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:04:25 --> Config Class Initialized
INFO - 2022-03-16 03:04:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:04:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:04:25 --> Utf8 Class Initialized
INFO - 2022-03-16 03:04:25 --> URI Class Initialized
INFO - 2022-03-16 03:04:25 --> Router Class Initialized
INFO - 2022-03-16 03:04:25 --> Output Class Initialized
INFO - 2022-03-16 03:04:25 --> Security Class Initialized
DEBUG - 2022-03-16 03:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:04:25 --> Input Class Initialized
INFO - 2022-03-16 03:04:25 --> Language Class Initialized
INFO - 2022-03-16 03:04:25 --> Loader Class Initialized
INFO - 2022-03-16 03:04:25 --> Helper loaded: url_helper
INFO - 2022-03-16 03:04:25 --> Helper loaded: form_helper
INFO - 2022-03-16 03:04:25 --> Helper loaded: common_helper
INFO - 2022-03-16 03:04:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:04:25 --> Controller Class Initialized
INFO - 2022-03-16 03:04:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:04:25 --> Encrypt Class Initialized
INFO - 2022-03-16 03:04:25 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:04:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:04:25 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:04:25 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:04:25 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:04:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:04:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 03:04:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:04:25 --> Final output sent to browser
DEBUG - 2022-03-16 03:04:25 --> Total execution time: 0.0808
ERROR - 2022-03-16 03:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:04:56 --> Config Class Initialized
INFO - 2022-03-16 03:04:56 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:04:56 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:04:56 --> Utf8 Class Initialized
INFO - 2022-03-16 03:04:56 --> URI Class Initialized
INFO - 2022-03-16 03:04:56 --> Router Class Initialized
INFO - 2022-03-16 03:04:56 --> Output Class Initialized
INFO - 2022-03-16 03:04:56 --> Security Class Initialized
DEBUG - 2022-03-16 03:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:04:56 --> Input Class Initialized
INFO - 2022-03-16 03:04:56 --> Language Class Initialized
INFO - 2022-03-16 03:04:56 --> Loader Class Initialized
INFO - 2022-03-16 03:04:56 --> Helper loaded: url_helper
INFO - 2022-03-16 03:04:56 --> Helper loaded: form_helper
INFO - 2022-03-16 03:04:56 --> Helper loaded: common_helper
INFO - 2022-03-16 03:04:56 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:04:56 --> Controller Class Initialized
INFO - 2022-03-16 03:04:56 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:04:56 --> Encrypt Class Initialized
INFO - 2022-03-16 03:04:56 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:04:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:04:56 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:04:56 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:04:56 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:04:56 --> Upload Class Initialized
INFO - 2022-03-16 03:04:56 --> Final output sent to browser
DEBUG - 2022-03-16 03:04:56 --> Total execution time: 0.0360
ERROR - 2022-03-16 03:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:05:04 --> Config Class Initialized
INFO - 2022-03-16 03:05:04 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:05:04 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:05:04 --> Utf8 Class Initialized
INFO - 2022-03-16 03:05:04 --> URI Class Initialized
INFO - 2022-03-16 03:05:04 --> Router Class Initialized
INFO - 2022-03-16 03:05:04 --> Output Class Initialized
INFO - 2022-03-16 03:05:04 --> Security Class Initialized
DEBUG - 2022-03-16 03:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:05:04 --> Input Class Initialized
INFO - 2022-03-16 03:05:04 --> Language Class Initialized
INFO - 2022-03-16 03:05:04 --> Loader Class Initialized
INFO - 2022-03-16 03:05:04 --> Helper loaded: url_helper
INFO - 2022-03-16 03:05:04 --> Helper loaded: form_helper
INFO - 2022-03-16 03:05:04 --> Helper loaded: common_helper
INFO - 2022-03-16 03:05:04 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:05:04 --> Controller Class Initialized
INFO - 2022-03-16 03:05:04 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:05:04 --> Encrypt Class Initialized
INFO - 2022-03-16 03:05:04 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:05:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:05:04 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:05:04 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:05:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 03:05:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:05:05 --> Config Class Initialized
INFO - 2022-03-16 03:05:05 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:05:05 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:05:05 --> Utf8 Class Initialized
INFO - 2022-03-16 03:05:05 --> URI Class Initialized
INFO - 2022-03-16 03:05:05 --> Router Class Initialized
INFO - 2022-03-16 03:05:05 --> Output Class Initialized
INFO - 2022-03-16 03:05:05 --> Security Class Initialized
DEBUG - 2022-03-16 03:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:05:05 --> Input Class Initialized
INFO - 2022-03-16 03:05:05 --> Language Class Initialized
INFO - 2022-03-16 03:05:05 --> Loader Class Initialized
INFO - 2022-03-16 03:05:05 --> Helper loaded: url_helper
INFO - 2022-03-16 03:05:05 --> Helper loaded: form_helper
INFO - 2022-03-16 03:05:05 --> Helper loaded: common_helper
INFO - 2022-03-16 03:05:05 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:05:05 --> Controller Class Initialized
INFO - 2022-03-16 03:05:05 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:05:05 --> Encrypt Class Initialized
INFO - 2022-03-16 03:05:05 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:05:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:05:05 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:05:05 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:05:05 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:05:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:05:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 03:05:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:05:05 --> Final output sent to browser
DEBUG - 2022-03-16 03:05:05 --> Total execution time: 0.0577
ERROR - 2022-03-16 03:05:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:05:06 --> Config Class Initialized
INFO - 2022-03-16 03:05:06 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:05:06 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:05:06 --> Utf8 Class Initialized
INFO - 2022-03-16 03:05:06 --> URI Class Initialized
INFO - 2022-03-16 03:05:06 --> Router Class Initialized
INFO - 2022-03-16 03:05:06 --> Output Class Initialized
INFO - 2022-03-16 03:05:06 --> Security Class Initialized
DEBUG - 2022-03-16 03:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:05:06 --> Input Class Initialized
INFO - 2022-03-16 03:05:06 --> Language Class Initialized
INFO - 2022-03-16 03:05:06 --> Loader Class Initialized
INFO - 2022-03-16 03:05:06 --> Helper loaded: url_helper
INFO - 2022-03-16 03:05:06 --> Helper loaded: form_helper
INFO - 2022-03-16 03:05:06 --> Helper loaded: common_helper
INFO - 2022-03-16 03:05:06 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:05:06 --> Controller Class Initialized
INFO - 2022-03-16 03:05:06 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:05:06 --> Encrypt Class Initialized
INFO - 2022-03-16 03:05:06 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:05:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:05:06 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:05:06 --> Model "Users_model" initialized
INFO - 2022-03-16 03:05:06 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:05:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:05:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 03:05:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:05:06 --> Final output sent to browser
DEBUG - 2022-03-16 03:05:06 --> Total execution time: 0.0734
ERROR - 2022-03-16 03:23:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:23:43 --> Config Class Initialized
INFO - 2022-03-16 03:23:43 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:23:43 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:23:43 --> Utf8 Class Initialized
INFO - 2022-03-16 03:23:43 --> URI Class Initialized
DEBUG - 2022-03-16 03:23:43 --> No URI present. Default controller set.
INFO - 2022-03-16 03:23:43 --> Router Class Initialized
INFO - 2022-03-16 03:23:43 --> Output Class Initialized
INFO - 2022-03-16 03:23:43 --> Security Class Initialized
DEBUG - 2022-03-16 03:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:23:43 --> Input Class Initialized
INFO - 2022-03-16 03:23:43 --> Language Class Initialized
INFO - 2022-03-16 03:23:43 --> Loader Class Initialized
INFO - 2022-03-16 03:23:43 --> Helper loaded: url_helper
INFO - 2022-03-16 03:23:43 --> Helper loaded: form_helper
INFO - 2022-03-16 03:23:43 --> Helper loaded: common_helper
INFO - 2022-03-16 03:23:43 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:23:43 --> Controller Class Initialized
INFO - 2022-03-16 03:23:43 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:23:43 --> Encrypt Class Initialized
DEBUG - 2022-03-16 03:23:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 03:23:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 03:23:43 --> Email Class Initialized
INFO - 2022-03-16 03:23:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 03:23:43 --> Calendar Class Initialized
INFO - 2022-03-16 03:23:43 --> Model "Login_model" initialized
INFO - 2022-03-16 03:23:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 03:23:44 --> Final output sent to browser
DEBUG - 2022-03-16 03:23:44 --> Total execution time: 0.1376
ERROR - 2022-03-16 03:23:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:23:47 --> Config Class Initialized
INFO - 2022-03-16 03:23:47 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:23:47 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:23:47 --> Utf8 Class Initialized
INFO - 2022-03-16 03:23:47 --> URI Class Initialized
DEBUG - 2022-03-16 03:23:47 --> No URI present. Default controller set.
INFO - 2022-03-16 03:23:47 --> Router Class Initialized
INFO - 2022-03-16 03:23:47 --> Output Class Initialized
INFO - 2022-03-16 03:23:47 --> Security Class Initialized
DEBUG - 2022-03-16 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:23:47 --> Input Class Initialized
INFO - 2022-03-16 03:23:47 --> Language Class Initialized
INFO - 2022-03-16 03:23:47 --> Loader Class Initialized
INFO - 2022-03-16 03:23:47 --> Helper loaded: url_helper
INFO - 2022-03-16 03:23:47 --> Helper loaded: form_helper
INFO - 2022-03-16 03:23:47 --> Helper loaded: common_helper
INFO - 2022-03-16 03:23:47 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:23:47 --> Controller Class Initialized
INFO - 2022-03-16 03:23:47 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:23:47 --> Encrypt Class Initialized
DEBUG - 2022-03-16 03:23:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 03:23:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 03:23:47 --> Email Class Initialized
INFO - 2022-03-16 03:23:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 03:23:47 --> Calendar Class Initialized
INFO - 2022-03-16 03:23:47 --> Model "Login_model" initialized
INFO - 2022-03-16 03:23:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 03:23:47 --> Final output sent to browser
DEBUG - 2022-03-16 03:23:47 --> Total execution time: 0.0259
ERROR - 2022-03-16 03:24:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:24:05 --> Config Class Initialized
INFO - 2022-03-16 03:24:05 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:24:05 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:24:05 --> Utf8 Class Initialized
INFO - 2022-03-16 03:24:05 --> URI Class Initialized
INFO - 2022-03-16 03:24:05 --> Router Class Initialized
INFO - 2022-03-16 03:24:05 --> Output Class Initialized
INFO - 2022-03-16 03:24:05 --> Security Class Initialized
DEBUG - 2022-03-16 03:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:24:05 --> Input Class Initialized
INFO - 2022-03-16 03:24:05 --> Language Class Initialized
INFO - 2022-03-16 03:24:05 --> Loader Class Initialized
INFO - 2022-03-16 03:24:05 --> Helper loaded: url_helper
INFO - 2022-03-16 03:24:05 --> Helper loaded: form_helper
INFO - 2022-03-16 03:24:05 --> Helper loaded: common_helper
INFO - 2022-03-16 03:24:05 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:24:05 --> Controller Class Initialized
INFO - 2022-03-16 03:24:05 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:24:05 --> Encrypt Class Initialized
DEBUG - 2022-03-16 03:24:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 03:24:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 03:24:05 --> Email Class Initialized
INFO - 2022-03-16 03:24:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 03:24:05 --> Calendar Class Initialized
INFO - 2022-03-16 03:24:05 --> Model "Login_model" initialized
INFO - 2022-03-16 03:24:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-16 03:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:24:06 --> Config Class Initialized
INFO - 2022-03-16 03:24:06 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:24:06 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:24:06 --> Utf8 Class Initialized
INFO - 2022-03-16 03:24:06 --> URI Class Initialized
INFO - 2022-03-16 03:24:06 --> Router Class Initialized
INFO - 2022-03-16 03:24:06 --> Output Class Initialized
INFO - 2022-03-16 03:24:06 --> Security Class Initialized
DEBUG - 2022-03-16 03:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:24:06 --> Input Class Initialized
INFO - 2022-03-16 03:24:06 --> Language Class Initialized
INFO - 2022-03-16 03:24:06 --> Loader Class Initialized
INFO - 2022-03-16 03:24:06 --> Helper loaded: url_helper
INFO - 2022-03-16 03:24:06 --> Helper loaded: form_helper
INFO - 2022-03-16 03:24:06 --> Helper loaded: common_helper
INFO - 2022-03-16 03:24:06 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:24:06 --> Controller Class Initialized
INFO - 2022-03-16 03:24:06 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:24:06 --> Encrypt Class Initialized
INFO - 2022-03-16 03:24:06 --> Model "Login_model" initialized
INFO - 2022-03-16 03:24:06 --> Model "Dashboard_model" initialized
INFO - 2022-03-16 03:24:06 --> Model "Case_model" initialized
INFO - 2022-03-16 03:24:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:24:06 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-16 03:24:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:24:06 --> Final output sent to browser
DEBUG - 2022-03-16 03:24:06 --> Total execution time: 0.3456
ERROR - 2022-03-16 03:24:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:24:09 --> Config Class Initialized
INFO - 2022-03-16 03:24:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:24:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:24:09 --> Utf8 Class Initialized
INFO - 2022-03-16 03:24:09 --> URI Class Initialized
DEBUG - 2022-03-16 03:24:09 --> No URI present. Default controller set.
INFO - 2022-03-16 03:24:09 --> Router Class Initialized
INFO - 2022-03-16 03:24:09 --> Output Class Initialized
INFO - 2022-03-16 03:24:09 --> Security Class Initialized
DEBUG - 2022-03-16 03:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:24:09 --> Input Class Initialized
INFO - 2022-03-16 03:24:09 --> Language Class Initialized
INFO - 2022-03-16 03:24:09 --> Loader Class Initialized
INFO - 2022-03-16 03:24:09 --> Helper loaded: url_helper
INFO - 2022-03-16 03:24:09 --> Helper loaded: form_helper
INFO - 2022-03-16 03:24:09 --> Helper loaded: common_helper
INFO - 2022-03-16 03:24:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:24:09 --> Controller Class Initialized
INFO - 2022-03-16 03:24:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:24:09 --> Encrypt Class Initialized
DEBUG - 2022-03-16 03:24:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 03:24:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 03:24:09 --> Email Class Initialized
INFO - 2022-03-16 03:24:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 03:24:09 --> Calendar Class Initialized
INFO - 2022-03-16 03:24:09 --> Model "Login_model" initialized
INFO - 2022-03-16 03:24:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 03:24:09 --> Final output sent to browser
DEBUG - 2022-03-16 03:24:09 --> Total execution time: 0.0319
ERROR - 2022-03-16 03:24:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:24:16 --> Config Class Initialized
INFO - 2022-03-16 03:24:16 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:24:16 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:24:16 --> Utf8 Class Initialized
INFO - 2022-03-16 03:24:16 --> URI Class Initialized
INFO - 2022-03-16 03:24:16 --> Router Class Initialized
INFO - 2022-03-16 03:24:16 --> Output Class Initialized
INFO - 2022-03-16 03:24:16 --> Security Class Initialized
DEBUG - 2022-03-16 03:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:24:16 --> Input Class Initialized
INFO - 2022-03-16 03:24:16 --> Language Class Initialized
INFO - 2022-03-16 03:24:16 --> Loader Class Initialized
INFO - 2022-03-16 03:24:16 --> Helper loaded: url_helper
INFO - 2022-03-16 03:24:16 --> Helper loaded: form_helper
INFO - 2022-03-16 03:24:16 --> Helper loaded: common_helper
INFO - 2022-03-16 03:24:16 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:24:16 --> Controller Class Initialized
INFO - 2022-03-16 03:24:16 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:24:16 --> Encrypt Class Initialized
INFO - 2022-03-16 03:24:16 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:24:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:24:16 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:24:16 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:24:16 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:24:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:24:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 03:24:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:24:16 --> Final output sent to browser
DEBUG - 2022-03-16 03:24:16 --> Total execution time: 0.2205
ERROR - 2022-03-16 03:24:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:24:46 --> Config Class Initialized
INFO - 2022-03-16 03:24:46 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:24:46 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:24:46 --> Utf8 Class Initialized
INFO - 2022-03-16 03:24:46 --> URI Class Initialized
INFO - 2022-03-16 03:24:46 --> Router Class Initialized
INFO - 2022-03-16 03:24:46 --> Output Class Initialized
INFO - 2022-03-16 03:24:46 --> Security Class Initialized
DEBUG - 2022-03-16 03:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:24:46 --> Input Class Initialized
INFO - 2022-03-16 03:24:46 --> Language Class Initialized
INFO - 2022-03-16 03:24:46 --> Loader Class Initialized
INFO - 2022-03-16 03:24:46 --> Helper loaded: url_helper
INFO - 2022-03-16 03:24:46 --> Helper loaded: form_helper
INFO - 2022-03-16 03:24:46 --> Helper loaded: common_helper
INFO - 2022-03-16 03:24:46 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:24:46 --> Controller Class Initialized
INFO - 2022-03-16 03:24:46 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:24:46 --> Encrypt Class Initialized
INFO - 2022-03-16 03:24:46 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:24:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:24:46 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:24:46 --> Model "Users_model" initialized
INFO - 2022-03-16 03:24:46 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:24:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:24:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 03:24:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:24:47 --> Final output sent to browser
DEBUG - 2022-03-16 03:24:47 --> Total execution time: 0.0838
ERROR - 2022-03-16 03:25:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:25:02 --> Config Class Initialized
INFO - 2022-03-16 03:25:02 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:25:02 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:25:02 --> Utf8 Class Initialized
INFO - 2022-03-16 03:25:02 --> URI Class Initialized
INFO - 2022-03-16 03:25:02 --> Router Class Initialized
INFO - 2022-03-16 03:25:02 --> Output Class Initialized
INFO - 2022-03-16 03:25:02 --> Security Class Initialized
DEBUG - 2022-03-16 03:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:25:02 --> Input Class Initialized
INFO - 2022-03-16 03:25:02 --> Language Class Initialized
INFO - 2022-03-16 03:25:02 --> Loader Class Initialized
INFO - 2022-03-16 03:25:02 --> Helper loaded: url_helper
INFO - 2022-03-16 03:25:02 --> Helper loaded: form_helper
INFO - 2022-03-16 03:25:02 --> Helper loaded: common_helper
INFO - 2022-03-16 03:25:02 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:25:02 --> Controller Class Initialized
INFO - 2022-03-16 03:25:02 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:25:02 --> Encrypt Class Initialized
INFO - 2022-03-16 03:25:02 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:25:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:25:02 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:25:02 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:25:02 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:25:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:25:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 03:25:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:25:02 --> Final output sent to browser
DEBUG - 2022-03-16 03:25:02 --> Total execution time: 0.0691
ERROR - 2022-03-16 03:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:26:51 --> Config Class Initialized
INFO - 2022-03-16 03:26:51 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:26:51 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:26:51 --> Utf8 Class Initialized
INFO - 2022-03-16 03:26:51 --> URI Class Initialized
INFO - 2022-03-16 03:26:51 --> Router Class Initialized
INFO - 2022-03-16 03:26:51 --> Output Class Initialized
INFO - 2022-03-16 03:26:51 --> Security Class Initialized
DEBUG - 2022-03-16 03:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:26:51 --> Input Class Initialized
INFO - 2022-03-16 03:26:51 --> Language Class Initialized
INFO - 2022-03-16 03:26:51 --> Loader Class Initialized
INFO - 2022-03-16 03:26:51 --> Helper loaded: url_helper
INFO - 2022-03-16 03:26:51 --> Helper loaded: form_helper
INFO - 2022-03-16 03:26:51 --> Helper loaded: common_helper
INFO - 2022-03-16 03:26:51 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:26:51 --> Controller Class Initialized
INFO - 2022-03-16 03:26:51 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:26:51 --> Encrypt Class Initialized
INFO - 2022-03-16 03:26:51 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:26:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:26:51 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:26:51 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:26:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 03:26:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:26:52 --> Config Class Initialized
INFO - 2022-03-16 03:26:52 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:26:52 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:26:52 --> Utf8 Class Initialized
INFO - 2022-03-16 03:26:52 --> URI Class Initialized
INFO - 2022-03-16 03:26:52 --> Router Class Initialized
INFO - 2022-03-16 03:26:52 --> Output Class Initialized
INFO - 2022-03-16 03:26:52 --> Security Class Initialized
DEBUG - 2022-03-16 03:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:26:52 --> Input Class Initialized
INFO - 2022-03-16 03:26:52 --> Language Class Initialized
INFO - 2022-03-16 03:26:52 --> Loader Class Initialized
INFO - 2022-03-16 03:26:52 --> Helper loaded: url_helper
INFO - 2022-03-16 03:26:52 --> Helper loaded: form_helper
INFO - 2022-03-16 03:26:52 --> Helper loaded: common_helper
INFO - 2022-03-16 03:26:52 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:26:52 --> Controller Class Initialized
INFO - 2022-03-16 03:26:52 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:26:52 --> Encrypt Class Initialized
INFO - 2022-03-16 03:26:52 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:26:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:26:52 --> Model "Referredby_model" initialized
INFO - 2022-03-16 03:26:52 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:26:52 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:26:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:26:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 03:26:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:26:53 --> Final output sent to browser
DEBUG - 2022-03-16 03:26:53 --> Total execution time: 0.2545
ERROR - 2022-03-16 03:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:26:54 --> Config Class Initialized
INFO - 2022-03-16 03:26:54 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:26:54 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:26:54 --> Utf8 Class Initialized
INFO - 2022-03-16 03:26:54 --> URI Class Initialized
INFO - 2022-03-16 03:26:54 --> Router Class Initialized
INFO - 2022-03-16 03:26:54 --> Output Class Initialized
INFO - 2022-03-16 03:26:54 --> Security Class Initialized
DEBUG - 2022-03-16 03:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:26:54 --> Input Class Initialized
INFO - 2022-03-16 03:26:54 --> Language Class Initialized
INFO - 2022-03-16 03:26:54 --> Loader Class Initialized
INFO - 2022-03-16 03:26:54 --> Helper loaded: url_helper
INFO - 2022-03-16 03:26:54 --> Helper loaded: form_helper
INFO - 2022-03-16 03:26:54 --> Helper loaded: common_helper
INFO - 2022-03-16 03:26:54 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:26:54 --> Controller Class Initialized
INFO - 2022-03-16 03:26:54 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:26:54 --> Encrypt Class Initialized
INFO - 2022-03-16 03:26:54 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:26:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:26:54 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:26:54 --> Model "Users_model" initialized
INFO - 2022-03-16 03:26:54 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:26:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:26:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 03:26:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:26:54 --> Final output sent to browser
DEBUG - 2022-03-16 03:26:54 --> Total execution time: 0.0911
ERROR - 2022-03-16 03:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:53:25 --> Config Class Initialized
INFO - 2022-03-16 03:53:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:53:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:53:25 --> Utf8 Class Initialized
INFO - 2022-03-16 03:53:25 --> URI Class Initialized
INFO - 2022-03-16 03:53:25 --> Router Class Initialized
INFO - 2022-03-16 03:53:25 --> Output Class Initialized
INFO - 2022-03-16 03:53:25 --> Security Class Initialized
DEBUG - 2022-03-16 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:53:25 --> Input Class Initialized
INFO - 2022-03-16 03:53:25 --> Language Class Initialized
INFO - 2022-03-16 03:53:25 --> Loader Class Initialized
INFO - 2022-03-16 03:53:25 --> Helper loaded: url_helper
INFO - 2022-03-16 03:53:25 --> Helper loaded: form_helper
INFO - 2022-03-16 03:53:25 --> Helper loaded: common_helper
INFO - 2022-03-16 03:53:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:53:25 --> Controller Class Initialized
INFO - 2022-03-16 03:53:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:53:25 --> Encrypt Class Initialized
INFO - 2022-03-16 03:53:25 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:53:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:53:25 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:53:25 --> Model "Users_model" initialized
INFO - 2022-03-16 03:53:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 03:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 03:53:25 --> Config Class Initialized
INFO - 2022-03-16 03:53:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 03:53:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 03:53:25 --> Utf8 Class Initialized
INFO - 2022-03-16 03:53:25 --> URI Class Initialized
INFO - 2022-03-16 03:53:25 --> Router Class Initialized
INFO - 2022-03-16 03:53:25 --> Output Class Initialized
INFO - 2022-03-16 03:53:25 --> Security Class Initialized
DEBUG - 2022-03-16 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 03:53:25 --> Input Class Initialized
INFO - 2022-03-16 03:53:25 --> Language Class Initialized
INFO - 2022-03-16 03:53:25 --> Loader Class Initialized
INFO - 2022-03-16 03:53:25 --> Helper loaded: url_helper
INFO - 2022-03-16 03:53:25 --> Helper loaded: form_helper
INFO - 2022-03-16 03:53:25 --> Helper loaded: common_helper
INFO - 2022-03-16 03:53:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 03:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 03:53:25 --> Controller Class Initialized
INFO - 2022-03-16 03:53:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 03:53:25 --> Encrypt Class Initialized
INFO - 2022-03-16 03:53:25 --> Model "Patient_model" initialized
INFO - 2022-03-16 03:53:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 03:53:25 --> Model "Prefix_master" initialized
INFO - 2022-03-16 03:53:25 --> Model "Users_model" initialized
INFO - 2022-03-16 03:53:25 --> Model "Hospital_model" initialized
INFO - 2022-03-16 03:53:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 03:53:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 03:53:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 03:53:25 --> Final output sent to browser
DEBUG - 2022-03-16 03:53:25 --> Total execution time: 0.0728
ERROR - 2022-03-16 04:11:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:11:28 --> Config Class Initialized
INFO - 2022-03-16 04:11:28 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:11:28 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:11:28 --> Utf8 Class Initialized
INFO - 2022-03-16 04:11:28 --> URI Class Initialized
INFO - 2022-03-16 04:11:28 --> Router Class Initialized
INFO - 2022-03-16 04:11:28 --> Output Class Initialized
INFO - 2022-03-16 04:11:28 --> Security Class Initialized
DEBUG - 2022-03-16 04:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:11:28 --> Input Class Initialized
INFO - 2022-03-16 04:11:28 --> Language Class Initialized
INFO - 2022-03-16 04:11:28 --> Loader Class Initialized
INFO - 2022-03-16 04:11:28 --> Helper loaded: url_helper
INFO - 2022-03-16 04:11:28 --> Helper loaded: form_helper
INFO - 2022-03-16 04:11:28 --> Helper loaded: common_helper
INFO - 2022-03-16 04:11:28 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:11:28 --> Controller Class Initialized
INFO - 2022-03-16 04:11:28 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:11:28 --> Encrypt Class Initialized
DEBUG - 2022-03-16 04:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 04:11:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 04:11:28 --> Email Class Initialized
INFO - 2022-03-16 04:11:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 04:11:28 --> Calendar Class Initialized
INFO - 2022-03-16 04:11:28 --> Model "Login_model" initialized
INFO - 2022-03-16 04:11:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 04:11:28 --> Final output sent to browser
DEBUG - 2022-03-16 04:11:28 --> Total execution time: 0.0437
ERROR - 2022-03-16 04:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:11:41 --> Config Class Initialized
INFO - 2022-03-16 04:11:41 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:11:41 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:11:41 --> Utf8 Class Initialized
INFO - 2022-03-16 04:11:41 --> URI Class Initialized
INFO - 2022-03-16 04:11:41 --> Router Class Initialized
INFO - 2022-03-16 04:11:41 --> Output Class Initialized
INFO - 2022-03-16 04:11:41 --> Security Class Initialized
DEBUG - 2022-03-16 04:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:11:41 --> Input Class Initialized
INFO - 2022-03-16 04:11:41 --> Language Class Initialized
INFO - 2022-03-16 04:11:41 --> Loader Class Initialized
INFO - 2022-03-16 04:11:41 --> Helper loaded: url_helper
INFO - 2022-03-16 04:11:41 --> Helper loaded: form_helper
INFO - 2022-03-16 04:11:41 --> Helper loaded: common_helper
INFO - 2022-03-16 04:11:41 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:11:41 --> Controller Class Initialized
INFO - 2022-03-16 04:11:41 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:11:41 --> Encrypt Class Initialized
DEBUG - 2022-03-16 04:11:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 04:11:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 04:11:41 --> Email Class Initialized
INFO - 2022-03-16 04:11:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 04:11:41 --> Calendar Class Initialized
INFO - 2022-03-16 04:11:41 --> Model "Login_model" initialized
INFO - 2022-03-16 04:11:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-16 04:11:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:11:42 --> Config Class Initialized
INFO - 2022-03-16 04:11:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:11:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:11:42 --> Utf8 Class Initialized
INFO - 2022-03-16 04:11:42 --> URI Class Initialized
INFO - 2022-03-16 04:11:42 --> Router Class Initialized
INFO - 2022-03-16 04:11:42 --> Output Class Initialized
INFO - 2022-03-16 04:11:42 --> Security Class Initialized
DEBUG - 2022-03-16 04:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:11:42 --> Input Class Initialized
INFO - 2022-03-16 04:11:42 --> Language Class Initialized
INFO - 2022-03-16 04:11:42 --> Loader Class Initialized
INFO - 2022-03-16 04:11:42 --> Helper loaded: url_helper
INFO - 2022-03-16 04:11:42 --> Helper loaded: form_helper
INFO - 2022-03-16 04:11:42 --> Helper loaded: common_helper
INFO - 2022-03-16 04:11:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:11:42 --> Controller Class Initialized
INFO - 2022-03-16 04:11:42 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:11:42 --> Encrypt Class Initialized
INFO - 2022-03-16 04:11:42 --> Model "Login_model" initialized
INFO - 2022-03-16 04:11:42 --> Model "Dashboard_model" initialized
INFO - 2022-03-16 04:11:42 --> Model "Case_model" initialized
INFO - 2022-03-16 04:11:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:11:42 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-16 04:11:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:11:42 --> Final output sent to browser
DEBUG - 2022-03-16 04:11:42 --> Total execution time: 0.7186
ERROR - 2022-03-16 04:11:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:11:54 --> Config Class Initialized
INFO - 2022-03-16 04:11:54 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:11:54 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:11:54 --> Utf8 Class Initialized
INFO - 2022-03-16 04:11:54 --> URI Class Initialized
INFO - 2022-03-16 04:11:54 --> Router Class Initialized
INFO - 2022-03-16 04:11:54 --> Output Class Initialized
INFO - 2022-03-16 04:11:54 --> Security Class Initialized
DEBUG - 2022-03-16 04:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:11:54 --> Input Class Initialized
INFO - 2022-03-16 04:11:54 --> Language Class Initialized
INFO - 2022-03-16 04:11:54 --> Loader Class Initialized
INFO - 2022-03-16 04:11:54 --> Helper loaded: url_helper
INFO - 2022-03-16 04:11:54 --> Helper loaded: form_helper
INFO - 2022-03-16 04:11:54 --> Helper loaded: common_helper
INFO - 2022-03-16 04:11:54 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:11:54 --> Controller Class Initialized
INFO - 2022-03-16 04:11:54 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:11:54 --> Encrypt Class Initialized
INFO - 2022-03-16 04:11:54 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:11:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:11:54 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:11:54 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:11:54 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:11:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:11:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 04:11:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:11:54 --> Final output sent to browser
DEBUG - 2022-03-16 04:11:54 --> Total execution time: 0.0832
ERROR - 2022-03-16 04:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:12:02 --> Config Class Initialized
INFO - 2022-03-16 04:12:02 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:12:02 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:12:02 --> Utf8 Class Initialized
INFO - 2022-03-16 04:12:02 --> URI Class Initialized
INFO - 2022-03-16 04:12:02 --> Router Class Initialized
INFO - 2022-03-16 04:12:02 --> Output Class Initialized
INFO - 2022-03-16 04:12:02 --> Security Class Initialized
DEBUG - 2022-03-16 04:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:12:02 --> Input Class Initialized
INFO - 2022-03-16 04:12:02 --> Language Class Initialized
INFO - 2022-03-16 04:12:02 --> Loader Class Initialized
INFO - 2022-03-16 04:12:02 --> Helper loaded: url_helper
INFO - 2022-03-16 04:12:02 --> Helper loaded: form_helper
INFO - 2022-03-16 04:12:02 --> Helper loaded: common_helper
INFO - 2022-03-16 04:12:02 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:12:02 --> Controller Class Initialized
INFO - 2022-03-16 04:12:02 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:12:02 --> Encrypt Class Initialized
INFO - 2022-03-16 04:12:02 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:12:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:12:02 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:12:02 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:12:02 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:12:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:12:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:12:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:12:02 --> Final output sent to browser
DEBUG - 2022-03-16 04:12:02 --> Total execution time: 0.0987
ERROR - 2022-03-16 04:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:16:29 --> Config Class Initialized
INFO - 2022-03-16 04:16:29 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:16:29 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:16:29 --> Utf8 Class Initialized
INFO - 2022-03-16 04:16:29 --> URI Class Initialized
INFO - 2022-03-16 04:16:29 --> Router Class Initialized
INFO - 2022-03-16 04:16:29 --> Output Class Initialized
INFO - 2022-03-16 04:16:29 --> Security Class Initialized
DEBUG - 2022-03-16 04:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:16:29 --> Input Class Initialized
INFO - 2022-03-16 04:16:29 --> Language Class Initialized
INFO - 2022-03-16 04:16:29 --> Loader Class Initialized
INFO - 2022-03-16 04:16:29 --> Helper loaded: url_helper
INFO - 2022-03-16 04:16:29 --> Helper loaded: form_helper
INFO - 2022-03-16 04:16:29 --> Helper loaded: common_helper
INFO - 2022-03-16 04:16:29 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:16:29 --> Controller Class Initialized
ERROR - 2022-03-16 04:16:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:16:30 --> Config Class Initialized
INFO - 2022-03-16 04:16:30 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:16:30 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:16:30 --> Utf8 Class Initialized
INFO - 2022-03-16 04:16:30 --> URI Class Initialized
INFO - 2022-03-16 04:16:30 --> Router Class Initialized
INFO - 2022-03-16 04:16:30 --> Output Class Initialized
INFO - 2022-03-16 04:16:30 --> Security Class Initialized
DEBUG - 2022-03-16 04:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:16:30 --> Input Class Initialized
INFO - 2022-03-16 04:16:30 --> Language Class Initialized
INFO - 2022-03-16 04:16:30 --> Loader Class Initialized
INFO - 2022-03-16 04:16:30 --> Helper loaded: url_helper
INFO - 2022-03-16 04:16:30 --> Helper loaded: form_helper
INFO - 2022-03-16 04:16:30 --> Helper loaded: common_helper
INFO - 2022-03-16 04:16:30 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:16:30 --> Controller Class Initialized
INFO - 2022-03-16 04:16:30 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:16:30 --> Encrypt Class Initialized
DEBUG - 2022-03-16 04:16:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 04:16:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 04:16:30 --> Email Class Initialized
INFO - 2022-03-16 04:16:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 04:16:30 --> Calendar Class Initialized
INFO - 2022-03-16 04:16:30 --> Model "Login_model" initialized
INFO - 2022-03-16 04:16:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 04:16:30 --> Final output sent to browser
DEBUG - 2022-03-16 04:16:30 --> Total execution time: 0.0243
ERROR - 2022-03-16 04:16:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:16:35 --> Config Class Initialized
INFO - 2022-03-16 04:16:35 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:16:35 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:16:35 --> Utf8 Class Initialized
INFO - 2022-03-16 04:16:35 --> URI Class Initialized
INFO - 2022-03-16 04:16:35 --> Router Class Initialized
INFO - 2022-03-16 04:16:35 --> Output Class Initialized
INFO - 2022-03-16 04:16:35 --> Security Class Initialized
DEBUG - 2022-03-16 04:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:16:35 --> Input Class Initialized
INFO - 2022-03-16 04:16:35 --> Language Class Initialized
INFO - 2022-03-16 04:16:35 --> Loader Class Initialized
INFO - 2022-03-16 04:16:35 --> Helper loaded: url_helper
INFO - 2022-03-16 04:16:35 --> Helper loaded: form_helper
INFO - 2022-03-16 04:16:35 --> Helper loaded: common_helper
INFO - 2022-03-16 04:16:35 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:16:35 --> Controller Class Initialized
INFO - 2022-03-16 04:16:35 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:16:35 --> Encrypt Class Initialized
DEBUG - 2022-03-16 04:16:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 04:16:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 04:16:35 --> Email Class Initialized
INFO - 2022-03-16 04:16:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 04:16:35 --> Calendar Class Initialized
INFO - 2022-03-16 04:16:35 --> Model "Login_model" initialized
INFO - 2022-03-16 04:16:35 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-16 04:16:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:16:36 --> Config Class Initialized
INFO - 2022-03-16 04:16:36 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:16:36 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:16:36 --> Utf8 Class Initialized
INFO - 2022-03-16 04:16:36 --> URI Class Initialized
INFO - 2022-03-16 04:16:36 --> Router Class Initialized
INFO - 2022-03-16 04:16:36 --> Output Class Initialized
INFO - 2022-03-16 04:16:36 --> Security Class Initialized
DEBUG - 2022-03-16 04:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:16:36 --> Input Class Initialized
INFO - 2022-03-16 04:16:36 --> Language Class Initialized
INFO - 2022-03-16 04:16:36 --> Loader Class Initialized
INFO - 2022-03-16 04:16:36 --> Helper loaded: url_helper
INFO - 2022-03-16 04:16:36 --> Helper loaded: form_helper
INFO - 2022-03-16 04:16:36 --> Helper loaded: common_helper
INFO - 2022-03-16 04:16:36 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:16:36 --> Controller Class Initialized
INFO - 2022-03-16 04:16:36 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:16:36 --> Encrypt Class Initialized
INFO - 2022-03-16 04:16:36 --> Model "Login_model" initialized
INFO - 2022-03-16 04:16:36 --> Model "Dashboard_model" initialized
INFO - 2022-03-16 04:16:36 --> Model "Case_model" initialized
INFO - 2022-03-16 04:16:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-16 04:16:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:16:49 --> Config Class Initialized
INFO - 2022-03-16 04:16:49 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:16:49 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:16:49 --> Utf8 Class Initialized
INFO - 2022-03-16 04:16:49 --> URI Class Initialized
INFO - 2022-03-16 04:16:49 --> Router Class Initialized
INFO - 2022-03-16 04:16:49 --> Output Class Initialized
INFO - 2022-03-16 04:16:49 --> Security Class Initialized
DEBUG - 2022-03-16 04:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:16:49 --> Input Class Initialized
INFO - 2022-03-16 04:16:49 --> Language Class Initialized
INFO - 2022-03-16 04:16:49 --> Loader Class Initialized
INFO - 2022-03-16 04:16:49 --> Helper loaded: url_helper
INFO - 2022-03-16 04:16:49 --> Helper loaded: form_helper
INFO - 2022-03-16 04:16:49 --> Helper loaded: common_helper
INFO - 2022-03-16 04:16:49 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:16:49 --> Controller Class Initialized
INFO - 2022-03-16 04:16:49 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:16:49 --> Encrypt Class Initialized
INFO - 2022-03-16 04:16:49 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:16:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:16:49 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:16:49 --> Model "Users_model" initialized
INFO - 2022-03-16 04:16:49 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:16:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:16:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:16:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:16:49 --> Final output sent to browser
DEBUG - 2022-03-16 04:16:49 --> Total execution time: 0.2156
ERROR - 2022-03-16 04:16:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:16:53 --> Config Class Initialized
INFO - 2022-03-16 04:16:53 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:16:53 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:16:53 --> Utf8 Class Initialized
INFO - 2022-03-16 04:16:53 --> URI Class Initialized
INFO - 2022-03-16 04:16:53 --> Router Class Initialized
INFO - 2022-03-16 04:16:53 --> Output Class Initialized
INFO - 2022-03-16 04:16:53 --> Security Class Initialized
DEBUG - 2022-03-16 04:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:16:53 --> Input Class Initialized
INFO - 2022-03-16 04:16:53 --> Language Class Initialized
INFO - 2022-03-16 04:16:53 --> Loader Class Initialized
INFO - 2022-03-16 04:16:53 --> Helper loaded: url_helper
INFO - 2022-03-16 04:16:53 --> Helper loaded: form_helper
INFO - 2022-03-16 04:16:53 --> Helper loaded: common_helper
INFO - 2022-03-16 04:16:53 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:16:53 --> Controller Class Initialized
INFO - 2022-03-16 04:16:53 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:16:53 --> Encrypt Class Initialized
INFO - 2022-03-16 04:16:53 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:16:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:16:53 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:16:53 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:16:53 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:16:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:16:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:16:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:16:53 --> Final output sent to browser
DEBUG - 2022-03-16 04:16:53 --> Total execution time: 0.0862
ERROR - 2022-03-16 04:16:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:16:59 --> Config Class Initialized
INFO - 2022-03-16 04:16:59 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:16:59 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:16:59 --> Utf8 Class Initialized
INFO - 2022-03-16 04:16:59 --> URI Class Initialized
INFO - 2022-03-16 04:16:59 --> Router Class Initialized
INFO - 2022-03-16 04:16:59 --> Output Class Initialized
INFO - 2022-03-16 04:16:59 --> Security Class Initialized
DEBUG - 2022-03-16 04:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:16:59 --> Input Class Initialized
INFO - 2022-03-16 04:16:59 --> Language Class Initialized
INFO - 2022-03-16 04:16:59 --> Loader Class Initialized
INFO - 2022-03-16 04:16:59 --> Helper loaded: url_helper
INFO - 2022-03-16 04:16:59 --> Helper loaded: form_helper
INFO - 2022-03-16 04:16:59 --> Helper loaded: common_helper
INFO - 2022-03-16 04:16:59 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:16:59 --> Controller Class Initialized
INFO - 2022-03-16 04:16:59 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:16:59 --> Encrypt Class Initialized
INFO - 2022-03-16 04:16:59 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:16:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:16:59 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:16:59 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:16:59 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:16:59 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-16 04:16:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:16:59 --> Final output sent to browser
DEBUG - 2022-03-16 04:16:59 --> Total execution time: 22.7094
ERROR - 2022-03-16 04:16:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:16:59 --> Config Class Initialized
INFO - 2022-03-16 04:16:59 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:16:59 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:16:59 --> Utf8 Class Initialized
INFO - 2022-03-16 04:16:59 --> URI Class Initialized
INFO - 2022-03-16 04:16:59 --> Router Class Initialized
INFO - 2022-03-16 04:16:59 --> Output Class Initialized
INFO - 2022-03-16 04:16:59 --> Security Class Initialized
DEBUG - 2022-03-16 04:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:16:59 --> Input Class Initialized
INFO - 2022-03-16 04:16:59 --> Language Class Initialized
INFO - 2022-03-16 04:16:59 --> Loader Class Initialized
INFO - 2022-03-16 04:16:59 --> Helper loaded: url_helper
INFO - 2022-03-16 04:16:59 --> Helper loaded: form_helper
INFO - 2022-03-16 04:16:59 --> Helper loaded: common_helper
INFO - 2022-03-16 04:16:59 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:16:59 --> Controller Class Initialized
INFO - 2022-03-16 04:16:59 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:16:59 --> Encrypt Class Initialized
INFO - 2022-03-16 04:16:59 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:16:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:16:59 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:16:59 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:16:59 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:17:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:17:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:17:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:17:00 --> Final output sent to browser
DEBUG - 2022-03-16 04:17:00 --> Total execution time: 0.0689
ERROR - 2022-03-16 04:17:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:17:01 --> Config Class Initialized
INFO - 2022-03-16 04:17:01 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:17:01 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:17:01 --> Utf8 Class Initialized
INFO - 2022-03-16 04:17:01 --> URI Class Initialized
INFO - 2022-03-16 04:17:01 --> Router Class Initialized
INFO - 2022-03-16 04:17:01 --> Output Class Initialized
INFO - 2022-03-16 04:17:01 --> Security Class Initialized
DEBUG - 2022-03-16 04:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:17:01 --> Input Class Initialized
INFO - 2022-03-16 04:17:01 --> Language Class Initialized
INFO - 2022-03-16 04:17:01 --> Loader Class Initialized
INFO - 2022-03-16 04:17:01 --> Helper loaded: url_helper
INFO - 2022-03-16 04:17:01 --> Helper loaded: form_helper
INFO - 2022-03-16 04:17:01 --> Helper loaded: common_helper
INFO - 2022-03-16 04:17:01 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:17:01 --> Controller Class Initialized
INFO - 2022-03-16 04:17:01 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:17:01 --> Encrypt Class Initialized
INFO - 2022-03-16 04:17:01 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:17:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:17:01 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:17:01 --> Model "Users_model" initialized
INFO - 2022-03-16 04:17:01 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:17:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:17:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:17:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:17:01 --> Final output sent to browser
DEBUG - 2022-03-16 04:17:01 --> Total execution time: 0.0995
ERROR - 2022-03-16 04:17:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:17:08 --> Config Class Initialized
INFO - 2022-03-16 04:17:08 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:17:08 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:17:08 --> Utf8 Class Initialized
INFO - 2022-03-16 04:17:08 --> URI Class Initialized
INFO - 2022-03-16 04:17:08 --> Router Class Initialized
INFO - 2022-03-16 04:17:08 --> Output Class Initialized
INFO - 2022-03-16 04:17:08 --> Security Class Initialized
DEBUG - 2022-03-16 04:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:17:08 --> Input Class Initialized
INFO - 2022-03-16 04:17:08 --> Language Class Initialized
INFO - 2022-03-16 04:17:08 --> Loader Class Initialized
INFO - 2022-03-16 04:17:08 --> Helper loaded: url_helper
INFO - 2022-03-16 04:17:08 --> Helper loaded: form_helper
INFO - 2022-03-16 04:17:08 --> Helper loaded: common_helper
INFO - 2022-03-16 04:17:08 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:17:08 --> Controller Class Initialized
INFO - 2022-03-16 04:17:08 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:17:08 --> Encrypt Class Initialized
INFO - 2022-03-16 04:17:08 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:17:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:17:08 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:17:08 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:17:08 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:17:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:17:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 04:17:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:17:18 --> Final output sent to browser
DEBUG - 2022-03-16 04:17:18 --> Total execution time: 7.6515
ERROR - 2022-03-16 04:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:17:25 --> Config Class Initialized
INFO - 2022-03-16 04:17:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:17:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:17:25 --> Utf8 Class Initialized
INFO - 2022-03-16 04:17:25 --> URI Class Initialized
INFO - 2022-03-16 04:17:25 --> Router Class Initialized
INFO - 2022-03-16 04:17:25 --> Output Class Initialized
INFO - 2022-03-16 04:17:25 --> Security Class Initialized
DEBUG - 2022-03-16 04:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:17:25 --> Input Class Initialized
INFO - 2022-03-16 04:17:25 --> Language Class Initialized
INFO - 2022-03-16 04:17:25 --> Loader Class Initialized
INFO - 2022-03-16 04:17:25 --> Helper loaded: url_helper
INFO - 2022-03-16 04:17:25 --> Helper loaded: form_helper
INFO - 2022-03-16 04:17:25 --> Helper loaded: common_helper
INFO - 2022-03-16 04:17:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:17:25 --> Controller Class Initialized
INFO - 2022-03-16 04:17:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:17:25 --> Encrypt Class Initialized
INFO - 2022-03-16 04:17:25 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:17:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:17:25 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:17:25 --> Model "Users_model" initialized
INFO - 2022-03-16 04:17:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:17:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:17:26 --> Config Class Initialized
INFO - 2022-03-16 04:17:26 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:17:26 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:17:26 --> Utf8 Class Initialized
INFO - 2022-03-16 04:17:26 --> URI Class Initialized
INFO - 2022-03-16 04:17:26 --> Router Class Initialized
INFO - 2022-03-16 04:17:26 --> Output Class Initialized
INFO - 2022-03-16 04:17:26 --> Security Class Initialized
DEBUG - 2022-03-16 04:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:17:26 --> Input Class Initialized
INFO - 2022-03-16 04:17:26 --> Language Class Initialized
INFO - 2022-03-16 04:17:26 --> Loader Class Initialized
INFO - 2022-03-16 04:17:26 --> Helper loaded: url_helper
INFO - 2022-03-16 04:17:26 --> Helper loaded: form_helper
INFO - 2022-03-16 04:17:26 --> Helper loaded: common_helper
INFO - 2022-03-16 04:17:26 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:17:26 --> Controller Class Initialized
INFO - 2022-03-16 04:17:26 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:17:26 --> Encrypt Class Initialized
INFO - 2022-03-16 04:17:26 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:17:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:17:26 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:17:26 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:17:26 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:17:26 --> Final output sent to browser
DEBUG - 2022-03-16 04:17:26 --> Total execution time: 0.0345
ERROR - 2022-03-16 04:17:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:17:26 --> Config Class Initialized
INFO - 2022-03-16 04:17:26 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:17:26 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:17:26 --> Utf8 Class Initialized
INFO - 2022-03-16 04:17:26 --> URI Class Initialized
INFO - 2022-03-16 04:17:26 --> Router Class Initialized
INFO - 2022-03-16 04:17:26 --> Output Class Initialized
INFO - 2022-03-16 04:17:26 --> Security Class Initialized
DEBUG - 2022-03-16 04:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:17:26 --> Input Class Initialized
INFO - 2022-03-16 04:17:26 --> Language Class Initialized
INFO - 2022-03-16 04:17:26 --> Loader Class Initialized
INFO - 2022-03-16 04:17:26 --> Helper loaded: url_helper
INFO - 2022-03-16 04:17:26 --> Helper loaded: form_helper
INFO - 2022-03-16 04:17:26 --> Helper loaded: common_helper
INFO - 2022-03-16 04:17:26 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:17:26 --> Controller Class Initialized
INFO - 2022-03-16 04:17:26 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:17:26 --> Encrypt Class Initialized
INFO - 2022-03-16 04:17:26 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:17:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:17:26 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:17:26 --> Model "Users_model" initialized
INFO - 2022-03-16 04:17:26 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:17:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:17:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:17:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:17:26 --> Final output sent to browser
DEBUG - 2022-03-16 04:17:26 --> Total execution time: 0.1218
ERROR - 2022-03-16 04:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:17:32 --> Config Class Initialized
INFO - 2022-03-16 04:17:32 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:17:32 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:17:32 --> Utf8 Class Initialized
INFO - 2022-03-16 04:17:32 --> URI Class Initialized
INFO - 2022-03-16 04:17:32 --> Router Class Initialized
INFO - 2022-03-16 04:17:32 --> Output Class Initialized
INFO - 2022-03-16 04:17:32 --> Security Class Initialized
DEBUG - 2022-03-16 04:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:17:32 --> Input Class Initialized
INFO - 2022-03-16 04:17:32 --> Language Class Initialized
INFO - 2022-03-16 04:17:32 --> Loader Class Initialized
INFO - 2022-03-16 04:17:32 --> Helper loaded: url_helper
INFO - 2022-03-16 04:17:32 --> Helper loaded: form_helper
INFO - 2022-03-16 04:17:32 --> Helper loaded: common_helper
INFO - 2022-03-16 04:17:32 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:17:32 --> Controller Class Initialized
INFO - 2022-03-16 04:17:32 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:17:32 --> Encrypt Class Initialized
INFO - 2022-03-16 04:17:32 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:17:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:17:32 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:17:32 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:17:32 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:17:32 --> Final output sent to browser
DEBUG - 2022-03-16 04:17:32 --> Total execution time: 0.3012
ERROR - 2022-03-16 04:17:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:17:49 --> Config Class Initialized
INFO - 2022-03-16 04:17:49 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:17:49 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:17:49 --> Utf8 Class Initialized
INFO - 2022-03-16 04:17:49 --> URI Class Initialized
INFO - 2022-03-16 04:17:49 --> Router Class Initialized
INFO - 2022-03-16 04:17:49 --> Output Class Initialized
INFO - 2022-03-16 04:17:49 --> Security Class Initialized
DEBUG - 2022-03-16 04:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:17:49 --> Input Class Initialized
INFO - 2022-03-16 04:17:49 --> Language Class Initialized
INFO - 2022-03-16 04:17:49 --> Loader Class Initialized
INFO - 2022-03-16 04:17:49 --> Helper loaded: url_helper
INFO - 2022-03-16 04:17:49 --> Helper loaded: form_helper
INFO - 2022-03-16 04:17:49 --> Helper loaded: common_helper
INFO - 2022-03-16 04:17:49 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:17:49 --> Controller Class Initialized
INFO - 2022-03-16 04:17:49 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:17:49 --> Encrypt Class Initialized
INFO - 2022-03-16 04:17:49 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:17:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:17:49 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:17:49 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:17:49 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:17:49 --> Final output sent to browser
DEBUG - 2022-03-16 04:17:49 --> Total execution time: 0.0240
ERROR - 2022-03-16 04:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:18:08 --> Config Class Initialized
INFO - 2022-03-16 04:18:08 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:18:08 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:18:08 --> Utf8 Class Initialized
INFO - 2022-03-16 04:18:08 --> URI Class Initialized
INFO - 2022-03-16 04:18:08 --> Router Class Initialized
INFO - 2022-03-16 04:18:08 --> Output Class Initialized
INFO - 2022-03-16 04:18:08 --> Security Class Initialized
DEBUG - 2022-03-16 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:18:08 --> Input Class Initialized
INFO - 2022-03-16 04:18:08 --> Language Class Initialized
INFO - 2022-03-16 04:18:08 --> Loader Class Initialized
INFO - 2022-03-16 04:18:08 --> Helper loaded: url_helper
INFO - 2022-03-16 04:18:08 --> Helper loaded: form_helper
INFO - 2022-03-16 04:18:08 --> Helper loaded: common_helper
INFO - 2022-03-16 04:18:08 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:18:08 --> Controller Class Initialized
INFO - 2022-03-16 04:18:08 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:18:08 --> Encrypt Class Initialized
INFO - 2022-03-16 04:18:08 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:18:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:18:08 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:18:08 --> Model "Users_model" initialized
INFO - 2022-03-16 04:18:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:18:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:18:09 --> Config Class Initialized
INFO - 2022-03-16 04:18:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:18:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:18:09 --> Utf8 Class Initialized
INFO - 2022-03-16 04:18:09 --> URI Class Initialized
INFO - 2022-03-16 04:18:09 --> Router Class Initialized
INFO - 2022-03-16 04:18:09 --> Output Class Initialized
INFO - 2022-03-16 04:18:09 --> Security Class Initialized
DEBUG - 2022-03-16 04:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:18:09 --> Input Class Initialized
INFO - 2022-03-16 04:18:09 --> Language Class Initialized
INFO - 2022-03-16 04:18:09 --> Loader Class Initialized
INFO - 2022-03-16 04:18:09 --> Helper loaded: url_helper
INFO - 2022-03-16 04:18:09 --> Helper loaded: form_helper
INFO - 2022-03-16 04:18:09 --> Helper loaded: common_helper
INFO - 2022-03-16 04:18:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:18:09 --> Controller Class Initialized
INFO - 2022-03-16 04:18:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:18:09 --> Encrypt Class Initialized
INFO - 2022-03-16 04:18:09 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:18:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:18:09 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:18:09 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:18:09 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:18:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:18:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:18:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-16 04:18:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:18:09 --> Config Class Initialized
INFO - 2022-03-16 04:18:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:18:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:18:09 --> Utf8 Class Initialized
INFO - 2022-03-16 04:18:09 --> Final output sent to browser
DEBUG - 2022-03-16 04:18:09 --> Total execution time: 0.0578
INFO - 2022-03-16 04:18:09 --> URI Class Initialized
INFO - 2022-03-16 04:18:09 --> Router Class Initialized
INFO - 2022-03-16 04:18:09 --> Output Class Initialized
INFO - 2022-03-16 04:18:09 --> Security Class Initialized
DEBUG - 2022-03-16 04:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:18:09 --> Input Class Initialized
INFO - 2022-03-16 04:18:09 --> Language Class Initialized
INFO - 2022-03-16 04:18:09 --> Loader Class Initialized
INFO - 2022-03-16 04:18:09 --> Helper loaded: url_helper
INFO - 2022-03-16 04:18:09 --> Helper loaded: form_helper
INFO - 2022-03-16 04:18:09 --> Helper loaded: common_helper
INFO - 2022-03-16 04:18:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:18:09 --> Controller Class Initialized
INFO - 2022-03-16 04:18:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:18:09 --> Encrypt Class Initialized
INFO - 2022-03-16 04:18:09 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:18:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:18:09 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:18:09 --> Model "Users_model" initialized
INFO - 2022-03-16 04:18:09 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:18:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:18:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:18:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:18:09 --> Final output sent to browser
DEBUG - 2022-03-16 04:18:09 --> Total execution time: 0.0801
ERROR - 2022-03-16 04:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:18:23 --> Config Class Initialized
INFO - 2022-03-16 04:18:23 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:18:23 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:18:23 --> Utf8 Class Initialized
INFO - 2022-03-16 04:18:23 --> URI Class Initialized
INFO - 2022-03-16 04:18:23 --> Router Class Initialized
INFO - 2022-03-16 04:18:23 --> Output Class Initialized
INFO - 2022-03-16 04:18:23 --> Security Class Initialized
DEBUG - 2022-03-16 04:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:18:23 --> Input Class Initialized
INFO - 2022-03-16 04:18:23 --> Language Class Initialized
INFO - 2022-03-16 04:18:23 --> Loader Class Initialized
INFO - 2022-03-16 04:18:23 --> Helper loaded: url_helper
INFO - 2022-03-16 04:18:23 --> Helper loaded: form_helper
INFO - 2022-03-16 04:18:23 --> Helper loaded: common_helper
INFO - 2022-03-16 04:18:23 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:18:23 --> Controller Class Initialized
INFO - 2022-03-16 04:18:23 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:18:23 --> Encrypt Class Initialized
INFO - 2022-03-16 04:18:23 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:18:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:18:23 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:18:23 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:18:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:18:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:18:24 --> Config Class Initialized
INFO - 2022-03-16 04:18:24 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:18:24 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:18:24 --> Utf8 Class Initialized
INFO - 2022-03-16 04:18:24 --> URI Class Initialized
INFO - 2022-03-16 04:18:24 --> Router Class Initialized
INFO - 2022-03-16 04:18:24 --> Output Class Initialized
INFO - 2022-03-16 04:18:24 --> Security Class Initialized
DEBUG - 2022-03-16 04:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:18:24 --> Input Class Initialized
INFO - 2022-03-16 04:18:24 --> Language Class Initialized
INFO - 2022-03-16 04:18:24 --> Loader Class Initialized
INFO - 2022-03-16 04:18:24 --> Helper loaded: url_helper
INFO - 2022-03-16 04:18:24 --> Helper loaded: form_helper
INFO - 2022-03-16 04:18:24 --> Helper loaded: common_helper
INFO - 2022-03-16 04:18:24 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:18:24 --> Controller Class Initialized
INFO - 2022-03-16 04:18:24 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:18:24 --> Encrypt Class Initialized
INFO - 2022-03-16 04:18:24 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:18:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:18:24 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:18:24 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:18:24 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:18:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:18:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:18:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:18:24 --> Final output sent to browser
DEBUG - 2022-03-16 04:18:24 --> Total execution time: 0.0596
ERROR - 2022-03-16 04:18:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:18:25 --> Config Class Initialized
INFO - 2022-03-16 04:18:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:18:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:18:25 --> Utf8 Class Initialized
INFO - 2022-03-16 04:18:25 --> URI Class Initialized
INFO - 2022-03-16 04:18:25 --> Router Class Initialized
INFO - 2022-03-16 04:18:25 --> Output Class Initialized
INFO - 2022-03-16 04:18:25 --> Security Class Initialized
DEBUG - 2022-03-16 04:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:18:25 --> Input Class Initialized
INFO - 2022-03-16 04:18:25 --> Language Class Initialized
INFO - 2022-03-16 04:18:25 --> Loader Class Initialized
INFO - 2022-03-16 04:18:25 --> Helper loaded: url_helper
INFO - 2022-03-16 04:18:25 --> Helper loaded: form_helper
INFO - 2022-03-16 04:18:25 --> Helper loaded: common_helper
INFO - 2022-03-16 04:18:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:18:25 --> Controller Class Initialized
INFO - 2022-03-16 04:18:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:18:25 --> Encrypt Class Initialized
INFO - 2022-03-16 04:18:25 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:18:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:18:25 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:18:25 --> Model "Users_model" initialized
INFO - 2022-03-16 04:18:25 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:18:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:18:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:18:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:18:25 --> Final output sent to browser
DEBUG - 2022-03-16 04:18:25 --> Total execution time: 0.1054
ERROR - 2022-03-16 04:18:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:18:32 --> Config Class Initialized
INFO - 2022-03-16 04:18:32 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:18:32 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:18:32 --> Utf8 Class Initialized
INFO - 2022-03-16 04:18:32 --> URI Class Initialized
INFO - 2022-03-16 04:18:32 --> Router Class Initialized
INFO - 2022-03-16 04:18:32 --> Output Class Initialized
INFO - 2022-03-16 04:18:32 --> Security Class Initialized
DEBUG - 2022-03-16 04:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:18:32 --> Input Class Initialized
INFO - 2022-03-16 04:18:32 --> Language Class Initialized
INFO - 2022-03-16 04:18:32 --> Loader Class Initialized
INFO - 2022-03-16 04:18:32 --> Helper loaded: url_helper
INFO - 2022-03-16 04:18:32 --> Helper loaded: form_helper
INFO - 2022-03-16 04:18:32 --> Helper loaded: common_helper
INFO - 2022-03-16 04:18:32 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:18:32 --> Controller Class Initialized
INFO - 2022-03-16 04:18:32 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:18:32 --> Encrypt Class Initialized
INFO - 2022-03-16 04:18:32 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:18:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:18:32 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:18:32 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:18:32 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:18:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:18:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 04:18:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:18:44 --> Final output sent to browser
DEBUG - 2022-03-16 04:18:44 --> Total execution time: 9.7519
ERROR - 2022-03-16 04:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:19:42 --> Config Class Initialized
INFO - 2022-03-16 04:19:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:19:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:19:42 --> Utf8 Class Initialized
INFO - 2022-03-16 04:19:42 --> URI Class Initialized
INFO - 2022-03-16 04:19:42 --> Router Class Initialized
INFO - 2022-03-16 04:19:42 --> Output Class Initialized
INFO - 2022-03-16 04:19:42 --> Security Class Initialized
DEBUG - 2022-03-16 04:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:19:42 --> Input Class Initialized
INFO - 2022-03-16 04:19:42 --> Language Class Initialized
INFO - 2022-03-16 04:19:42 --> Loader Class Initialized
INFO - 2022-03-16 04:19:42 --> Helper loaded: url_helper
INFO - 2022-03-16 04:19:42 --> Helper loaded: form_helper
INFO - 2022-03-16 04:19:42 --> Helper loaded: common_helper
INFO - 2022-03-16 04:19:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:19:42 --> Controller Class Initialized
INFO - 2022-03-16 04:19:42 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:19:42 --> Encrypt Class Initialized
INFO - 2022-03-16 04:19:42 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:19:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:19:42 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:19:42 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:19:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:19:43 --> Config Class Initialized
INFO - 2022-03-16 04:19:43 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:19:43 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:19:43 --> Utf8 Class Initialized
INFO - 2022-03-16 04:19:43 --> URI Class Initialized
INFO - 2022-03-16 04:19:43 --> Router Class Initialized
INFO - 2022-03-16 04:19:43 --> Output Class Initialized
INFO - 2022-03-16 04:19:43 --> Security Class Initialized
DEBUG - 2022-03-16 04:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:19:43 --> Input Class Initialized
INFO - 2022-03-16 04:19:43 --> Language Class Initialized
INFO - 2022-03-16 04:19:43 --> Loader Class Initialized
INFO - 2022-03-16 04:19:43 --> Helper loaded: url_helper
INFO - 2022-03-16 04:19:43 --> Helper loaded: form_helper
INFO - 2022-03-16 04:19:43 --> Helper loaded: common_helper
INFO - 2022-03-16 04:19:43 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:19:43 --> Controller Class Initialized
INFO - 2022-03-16 04:19:43 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:19:43 --> Encrypt Class Initialized
INFO - 2022-03-16 04:19:43 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:19:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:19:43 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:19:43 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:19:43 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:19:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:19:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:19:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:19:43 --> Final output sent to browser
DEBUG - 2022-03-16 04:19:43 --> Total execution time: 0.0893
ERROR - 2022-03-16 04:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:19:44 --> Config Class Initialized
INFO - 2022-03-16 04:19:44 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:19:44 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:19:44 --> Utf8 Class Initialized
INFO - 2022-03-16 04:19:44 --> URI Class Initialized
INFO - 2022-03-16 04:19:44 --> Router Class Initialized
INFO - 2022-03-16 04:19:44 --> Output Class Initialized
INFO - 2022-03-16 04:19:44 --> Security Class Initialized
DEBUG - 2022-03-16 04:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:19:44 --> Input Class Initialized
INFO - 2022-03-16 04:19:44 --> Language Class Initialized
INFO - 2022-03-16 04:19:44 --> Loader Class Initialized
INFO - 2022-03-16 04:19:44 --> Helper loaded: url_helper
INFO - 2022-03-16 04:19:44 --> Helper loaded: form_helper
INFO - 2022-03-16 04:19:44 --> Helper loaded: common_helper
INFO - 2022-03-16 04:19:44 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:19:44 --> Controller Class Initialized
INFO - 2022-03-16 04:19:44 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:19:44 --> Encrypt Class Initialized
INFO - 2022-03-16 04:19:44 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:19:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:19:44 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:19:44 --> Model "Users_model" initialized
INFO - 2022-03-16 04:19:44 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:19:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:19:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:19:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:19:44 --> Final output sent to browser
DEBUG - 2022-03-16 04:19:44 --> Total execution time: 0.1323
ERROR - 2022-03-16 04:20:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:20:01 --> Config Class Initialized
INFO - 2022-03-16 04:20:01 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:20:01 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:20:01 --> Utf8 Class Initialized
INFO - 2022-03-16 04:20:01 --> URI Class Initialized
INFO - 2022-03-16 04:20:01 --> Router Class Initialized
INFO - 2022-03-16 04:20:01 --> Output Class Initialized
INFO - 2022-03-16 04:20:01 --> Security Class Initialized
DEBUG - 2022-03-16 04:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:20:01 --> Input Class Initialized
INFO - 2022-03-16 04:20:01 --> Language Class Initialized
INFO - 2022-03-16 04:20:01 --> Loader Class Initialized
INFO - 2022-03-16 04:20:01 --> Helper loaded: url_helper
INFO - 2022-03-16 04:20:01 --> Helper loaded: form_helper
INFO - 2022-03-16 04:20:01 --> Helper loaded: common_helper
INFO - 2022-03-16 04:20:01 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:20:01 --> Controller Class Initialized
INFO - 2022-03-16 04:20:01 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:20:01 --> Encrypt Class Initialized
INFO - 2022-03-16 04:20:01 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:20:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:20:01 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:20:01 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:20:01 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:20:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:20:01 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:20:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:20:01 --> Final output sent to browser
DEBUG - 2022-03-16 04:20:01 --> Total execution time: 0.0940
ERROR - 2022-03-16 04:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:20:41 --> Config Class Initialized
INFO - 2022-03-16 04:20:41 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:20:41 --> Utf8 Class Initialized
INFO - 2022-03-16 04:20:41 --> URI Class Initialized
INFO - 2022-03-16 04:20:41 --> Router Class Initialized
INFO - 2022-03-16 04:20:41 --> Output Class Initialized
INFO - 2022-03-16 04:20:41 --> Security Class Initialized
DEBUG - 2022-03-16 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:20:41 --> Input Class Initialized
INFO - 2022-03-16 04:20:41 --> Language Class Initialized
INFO - 2022-03-16 04:20:41 --> Loader Class Initialized
INFO - 2022-03-16 04:20:41 --> Helper loaded: url_helper
INFO - 2022-03-16 04:20:41 --> Helper loaded: form_helper
INFO - 2022-03-16 04:20:41 --> Helper loaded: common_helper
INFO - 2022-03-16 04:20:41 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:20:41 --> Controller Class Initialized
INFO - 2022-03-16 04:20:41 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:20:41 --> Encrypt Class Initialized
INFO - 2022-03-16 04:20:41 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:20:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:20:41 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:20:41 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:20:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:20:41 --> Config Class Initialized
INFO - 2022-03-16 04:20:41 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:20:41 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:20:41 --> Utf8 Class Initialized
INFO - 2022-03-16 04:20:41 --> URI Class Initialized
INFO - 2022-03-16 04:20:41 --> Router Class Initialized
INFO - 2022-03-16 04:20:41 --> Output Class Initialized
INFO - 2022-03-16 04:20:41 --> Security Class Initialized
DEBUG - 2022-03-16 04:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:20:41 --> Input Class Initialized
INFO - 2022-03-16 04:20:41 --> Language Class Initialized
INFO - 2022-03-16 04:20:41 --> Loader Class Initialized
INFO - 2022-03-16 04:20:41 --> Helper loaded: url_helper
INFO - 2022-03-16 04:20:41 --> Helper loaded: form_helper
INFO - 2022-03-16 04:20:41 --> Helper loaded: common_helper
INFO - 2022-03-16 04:20:41 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:20:41 --> Controller Class Initialized
INFO - 2022-03-16 04:20:41 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:20:41 --> Encrypt Class Initialized
INFO - 2022-03-16 04:20:41 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:20:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:20:41 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:20:41 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:20:41 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:20:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:20:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:20:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:20:41 --> Final output sent to browser
DEBUG - 2022-03-16 04:20:41 --> Total execution time: 0.0478
ERROR - 2022-03-16 04:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:20:42 --> Config Class Initialized
INFO - 2022-03-16 04:20:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:20:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:20:42 --> Utf8 Class Initialized
INFO - 2022-03-16 04:20:42 --> URI Class Initialized
INFO - 2022-03-16 04:20:42 --> Router Class Initialized
INFO - 2022-03-16 04:20:42 --> Output Class Initialized
INFO - 2022-03-16 04:20:42 --> Security Class Initialized
DEBUG - 2022-03-16 04:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:20:42 --> Input Class Initialized
INFO - 2022-03-16 04:20:42 --> Language Class Initialized
INFO - 2022-03-16 04:20:42 --> Loader Class Initialized
INFO - 2022-03-16 04:20:42 --> Helper loaded: url_helper
INFO - 2022-03-16 04:20:42 --> Helper loaded: form_helper
INFO - 2022-03-16 04:20:42 --> Helper loaded: common_helper
INFO - 2022-03-16 04:20:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:20:42 --> Controller Class Initialized
INFO - 2022-03-16 04:20:42 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:20:42 --> Encrypt Class Initialized
INFO - 2022-03-16 04:20:42 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:20:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:20:42 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:20:42 --> Model "Users_model" initialized
INFO - 2022-03-16 04:20:42 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:20:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:20:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:20:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:20:42 --> Final output sent to browser
DEBUG - 2022-03-16 04:20:42 --> Total execution time: 0.0683
ERROR - 2022-03-16 04:21:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:21:41 --> Config Class Initialized
INFO - 2022-03-16 04:21:41 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:21:41 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:21:41 --> Utf8 Class Initialized
INFO - 2022-03-16 04:21:41 --> URI Class Initialized
INFO - 2022-03-16 04:21:41 --> Router Class Initialized
INFO - 2022-03-16 04:21:41 --> Output Class Initialized
INFO - 2022-03-16 04:21:41 --> Security Class Initialized
DEBUG - 2022-03-16 04:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:21:41 --> Input Class Initialized
INFO - 2022-03-16 04:21:41 --> Language Class Initialized
INFO - 2022-03-16 04:21:41 --> Loader Class Initialized
INFO - 2022-03-16 04:21:41 --> Helper loaded: url_helper
INFO - 2022-03-16 04:21:41 --> Helper loaded: form_helper
INFO - 2022-03-16 04:21:41 --> Helper loaded: common_helper
INFO - 2022-03-16 04:21:41 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:21:41 --> Controller Class Initialized
INFO - 2022-03-16 04:21:41 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:21:41 --> Encrypt Class Initialized
INFO - 2022-03-16 04:21:41 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:21:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:21:41 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:21:41 --> Model "Users_model" initialized
INFO - 2022-03-16 04:21:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:21:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:21:42 --> Config Class Initialized
INFO - 2022-03-16 04:21:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:21:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:21:42 --> Utf8 Class Initialized
INFO - 2022-03-16 04:21:42 --> URI Class Initialized
INFO - 2022-03-16 04:21:42 --> Router Class Initialized
INFO - 2022-03-16 04:21:42 --> Output Class Initialized
INFO - 2022-03-16 04:21:42 --> Security Class Initialized
DEBUG - 2022-03-16 04:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:21:42 --> Input Class Initialized
INFO - 2022-03-16 04:21:42 --> Language Class Initialized
INFO - 2022-03-16 04:21:42 --> Loader Class Initialized
INFO - 2022-03-16 04:21:42 --> Helper loaded: url_helper
INFO - 2022-03-16 04:21:42 --> Helper loaded: form_helper
INFO - 2022-03-16 04:21:42 --> Helper loaded: common_helper
INFO - 2022-03-16 04:21:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:21:42 --> Controller Class Initialized
INFO - 2022-03-16 04:21:42 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:21:42 --> Encrypt Class Initialized
INFO - 2022-03-16 04:21:42 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:21:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:21:42 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:21:42 --> Model "Users_model" initialized
INFO - 2022-03-16 04:21:42 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:21:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:21:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:21:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:21:42 --> Final output sent to browser
DEBUG - 2022-03-16 04:21:42 --> Total execution time: 0.0694
ERROR - 2022-03-16 04:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:21:48 --> Config Class Initialized
INFO - 2022-03-16 04:21:48 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:21:48 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:21:48 --> Utf8 Class Initialized
INFO - 2022-03-16 04:21:48 --> URI Class Initialized
INFO - 2022-03-16 04:21:48 --> Router Class Initialized
INFO - 2022-03-16 04:21:48 --> Output Class Initialized
INFO - 2022-03-16 04:21:48 --> Security Class Initialized
DEBUG - 2022-03-16 04:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:21:48 --> Input Class Initialized
INFO - 2022-03-16 04:21:48 --> Language Class Initialized
INFO - 2022-03-16 04:21:48 --> Loader Class Initialized
INFO - 2022-03-16 04:21:48 --> Helper loaded: url_helper
INFO - 2022-03-16 04:21:48 --> Helper loaded: form_helper
INFO - 2022-03-16 04:21:48 --> Helper loaded: common_helper
INFO - 2022-03-16 04:21:48 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:21:48 --> Controller Class Initialized
INFO - 2022-03-16 04:21:48 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:21:48 --> Encrypt Class Initialized
INFO - 2022-03-16 04:21:48 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:21:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:21:48 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:21:48 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:21:48 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:21:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:21:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 04:21:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:21:48 --> Final output sent to browser
DEBUG - 2022-03-16 04:21:48 --> Total execution time: 0.0664
ERROR - 2022-03-16 04:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:21:55 --> Config Class Initialized
INFO - 2022-03-16 04:21:55 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:21:55 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:21:55 --> Utf8 Class Initialized
INFO - 2022-03-16 04:21:55 --> URI Class Initialized
INFO - 2022-03-16 04:21:55 --> Router Class Initialized
INFO - 2022-03-16 04:21:55 --> Output Class Initialized
INFO - 2022-03-16 04:21:55 --> Security Class Initialized
DEBUG - 2022-03-16 04:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:21:55 --> Input Class Initialized
INFO - 2022-03-16 04:21:55 --> Language Class Initialized
INFO - 2022-03-16 04:21:55 --> Loader Class Initialized
INFO - 2022-03-16 04:21:55 --> Helper loaded: url_helper
INFO - 2022-03-16 04:21:55 --> Helper loaded: form_helper
INFO - 2022-03-16 04:21:55 --> Helper loaded: common_helper
INFO - 2022-03-16 04:21:55 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:21:55 --> Controller Class Initialized
INFO - 2022-03-16 04:21:55 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:21:55 --> Encrypt Class Initialized
INFO - 2022-03-16 04:21:55 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:21:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:21:55 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:21:55 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:21:55 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:21:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:21:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:21:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:21:55 --> Final output sent to browser
DEBUG - 2022-03-16 04:21:55 --> Total execution time: 0.0456
ERROR - 2022-03-16 04:22:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:22:21 --> Config Class Initialized
INFO - 2022-03-16 04:22:21 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:22:21 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:22:21 --> Utf8 Class Initialized
INFO - 2022-03-16 04:22:21 --> URI Class Initialized
INFO - 2022-03-16 04:22:21 --> Router Class Initialized
INFO - 2022-03-16 04:22:21 --> Output Class Initialized
INFO - 2022-03-16 04:22:21 --> Security Class Initialized
DEBUG - 2022-03-16 04:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:22:21 --> Input Class Initialized
INFO - 2022-03-16 04:22:21 --> Language Class Initialized
INFO - 2022-03-16 04:22:21 --> Loader Class Initialized
INFO - 2022-03-16 04:22:21 --> Helper loaded: url_helper
INFO - 2022-03-16 04:22:21 --> Helper loaded: form_helper
INFO - 2022-03-16 04:22:21 --> Helper loaded: common_helper
INFO - 2022-03-16 04:22:21 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:22:21 --> Controller Class Initialized
INFO - 2022-03-16 04:22:21 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:22:21 --> Encrypt Class Initialized
INFO - 2022-03-16 04:22:21 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:22:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:22:21 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:22:21 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:22:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:22:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:22:21 --> Config Class Initialized
INFO - 2022-03-16 04:22:21 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:22:21 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:22:21 --> Utf8 Class Initialized
INFO - 2022-03-16 04:22:21 --> URI Class Initialized
INFO - 2022-03-16 04:22:21 --> Router Class Initialized
INFO - 2022-03-16 04:22:21 --> Output Class Initialized
INFO - 2022-03-16 04:22:21 --> Security Class Initialized
DEBUG - 2022-03-16 04:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:22:21 --> Input Class Initialized
INFO - 2022-03-16 04:22:21 --> Language Class Initialized
INFO - 2022-03-16 04:22:21 --> Loader Class Initialized
INFO - 2022-03-16 04:22:21 --> Helper loaded: url_helper
INFO - 2022-03-16 04:22:21 --> Helper loaded: form_helper
INFO - 2022-03-16 04:22:21 --> Helper loaded: common_helper
INFO - 2022-03-16 04:22:21 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:22:21 --> Controller Class Initialized
INFO - 2022-03-16 04:22:21 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:22:21 --> Encrypt Class Initialized
INFO - 2022-03-16 04:22:21 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:22:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:22:21 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:22:21 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:22:21 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:22:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:22:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:22:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:22:21 --> Final output sent to browser
DEBUG - 2022-03-16 04:22:21 --> Total execution time: 0.0488
ERROR - 2022-03-16 04:22:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:22:23 --> Config Class Initialized
INFO - 2022-03-16 04:22:23 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:22:23 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:22:23 --> Utf8 Class Initialized
INFO - 2022-03-16 04:22:23 --> URI Class Initialized
INFO - 2022-03-16 04:22:23 --> Router Class Initialized
INFO - 2022-03-16 04:22:23 --> Output Class Initialized
INFO - 2022-03-16 04:22:23 --> Security Class Initialized
DEBUG - 2022-03-16 04:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:22:23 --> Input Class Initialized
INFO - 2022-03-16 04:22:23 --> Language Class Initialized
INFO - 2022-03-16 04:22:23 --> Loader Class Initialized
INFO - 2022-03-16 04:22:23 --> Helper loaded: url_helper
INFO - 2022-03-16 04:22:23 --> Helper loaded: form_helper
INFO - 2022-03-16 04:22:23 --> Helper loaded: common_helper
INFO - 2022-03-16 04:22:23 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:22:23 --> Controller Class Initialized
INFO - 2022-03-16 04:22:23 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:22:23 --> Encrypt Class Initialized
INFO - 2022-03-16 04:22:23 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:22:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:22:23 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:22:23 --> Model "Users_model" initialized
INFO - 2022-03-16 04:22:23 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:22:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:22:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:22:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:22:23 --> Final output sent to browser
DEBUG - 2022-03-16 04:22:23 --> Total execution time: 0.0740
ERROR - 2022-03-16 04:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:22:55 --> Config Class Initialized
INFO - 2022-03-16 04:22:55 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:22:55 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:22:55 --> Utf8 Class Initialized
INFO - 2022-03-16 04:22:55 --> URI Class Initialized
INFO - 2022-03-16 04:22:55 --> Router Class Initialized
INFO - 2022-03-16 04:22:55 --> Output Class Initialized
INFO - 2022-03-16 04:22:55 --> Security Class Initialized
DEBUG - 2022-03-16 04:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:22:55 --> Input Class Initialized
INFO - 2022-03-16 04:22:55 --> Language Class Initialized
INFO - 2022-03-16 04:22:55 --> Loader Class Initialized
INFO - 2022-03-16 04:22:55 --> Helper loaded: url_helper
INFO - 2022-03-16 04:22:55 --> Helper loaded: form_helper
INFO - 2022-03-16 04:22:55 --> Helper loaded: common_helper
INFO - 2022-03-16 04:22:55 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:22:55 --> Controller Class Initialized
INFO - 2022-03-16 04:22:55 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:22:55 --> Encrypt Class Initialized
INFO - 2022-03-16 04:22:55 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:22:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:22:55 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:22:55 --> Model "Users_model" initialized
INFO - 2022-03-16 04:22:55 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:22:56 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-16 04:22:57 --> Final output sent to browser
DEBUG - 2022-03-16 04:22:57 --> Total execution time: 2.3652
ERROR - 2022-03-16 04:22:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:22:59 --> Config Class Initialized
INFO - 2022-03-16 04:22:59 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:22:59 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:22:59 --> Utf8 Class Initialized
INFO - 2022-03-16 04:22:59 --> URI Class Initialized
INFO - 2022-03-16 04:22:59 --> Router Class Initialized
INFO - 2022-03-16 04:22:59 --> Output Class Initialized
INFO - 2022-03-16 04:22:59 --> Security Class Initialized
DEBUG - 2022-03-16 04:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:22:59 --> Input Class Initialized
INFO - 2022-03-16 04:22:59 --> Language Class Initialized
INFO - 2022-03-16 04:22:59 --> Loader Class Initialized
INFO - 2022-03-16 04:22:59 --> Helper loaded: url_helper
INFO - 2022-03-16 04:22:59 --> Helper loaded: form_helper
INFO - 2022-03-16 04:22:59 --> Helper loaded: common_helper
INFO - 2022-03-16 04:22:59 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:22:59 --> Controller Class Initialized
INFO - 2022-03-16 04:22:59 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:22:59 --> Encrypt Class Initialized
INFO - 2022-03-16 04:22:59 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:22:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:22:59 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:22:59 --> Model "Users_model" initialized
INFO - 2022-03-16 04:22:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:23:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:23:00 --> Config Class Initialized
INFO - 2022-03-16 04:23:00 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:23:00 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:23:00 --> Utf8 Class Initialized
INFO - 2022-03-16 04:23:00 --> URI Class Initialized
INFO - 2022-03-16 04:23:00 --> Router Class Initialized
INFO - 2022-03-16 04:23:00 --> Output Class Initialized
INFO - 2022-03-16 04:23:00 --> Security Class Initialized
DEBUG - 2022-03-16 04:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:23:00 --> Input Class Initialized
INFO - 2022-03-16 04:23:00 --> Language Class Initialized
INFO - 2022-03-16 04:23:00 --> Loader Class Initialized
INFO - 2022-03-16 04:23:00 --> Helper loaded: url_helper
INFO - 2022-03-16 04:23:00 --> Helper loaded: form_helper
INFO - 2022-03-16 04:23:00 --> Helper loaded: common_helper
INFO - 2022-03-16 04:23:00 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:23:00 --> Controller Class Initialized
INFO - 2022-03-16 04:23:00 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:23:00 --> Encrypt Class Initialized
INFO - 2022-03-16 04:23:00 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:23:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:23:00 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:23:00 --> Model "Users_model" initialized
INFO - 2022-03-16 04:23:00 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:23:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:23:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:23:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:23:00 --> Final output sent to browser
DEBUG - 2022-03-16 04:23:00 --> Total execution time: 0.0728
ERROR - 2022-03-16 04:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:23:29 --> Config Class Initialized
INFO - 2022-03-16 04:23:29 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:23:29 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:23:29 --> Utf8 Class Initialized
INFO - 2022-03-16 04:23:29 --> URI Class Initialized
INFO - 2022-03-16 04:23:29 --> Router Class Initialized
INFO - 2022-03-16 04:23:29 --> Output Class Initialized
INFO - 2022-03-16 04:23:29 --> Security Class Initialized
DEBUG - 2022-03-16 04:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:23:29 --> Input Class Initialized
INFO - 2022-03-16 04:23:29 --> Language Class Initialized
INFO - 2022-03-16 04:23:29 --> Loader Class Initialized
INFO - 2022-03-16 04:23:29 --> Helper loaded: url_helper
INFO - 2022-03-16 04:23:29 --> Helper loaded: form_helper
INFO - 2022-03-16 04:23:29 --> Helper loaded: common_helper
INFO - 2022-03-16 04:23:29 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:23:29 --> Controller Class Initialized
INFO - 2022-03-16 04:23:29 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:23:29 --> Encrypt Class Initialized
INFO - 2022-03-16 04:23:29 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:23:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:23:29 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:23:29 --> Model "Users_model" initialized
INFO - 2022-03-16 04:23:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:23:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:23:30 --> Config Class Initialized
INFO - 2022-03-16 04:23:30 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:23:30 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:23:30 --> Utf8 Class Initialized
INFO - 2022-03-16 04:23:30 --> URI Class Initialized
INFO - 2022-03-16 04:23:30 --> Router Class Initialized
INFO - 2022-03-16 04:23:30 --> Output Class Initialized
INFO - 2022-03-16 04:23:30 --> Security Class Initialized
DEBUG - 2022-03-16 04:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:23:30 --> Input Class Initialized
INFO - 2022-03-16 04:23:30 --> Language Class Initialized
INFO - 2022-03-16 04:23:30 --> Loader Class Initialized
INFO - 2022-03-16 04:23:30 --> Helper loaded: url_helper
INFO - 2022-03-16 04:23:30 --> Helper loaded: form_helper
INFO - 2022-03-16 04:23:30 --> Helper loaded: common_helper
INFO - 2022-03-16 04:23:30 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:23:30 --> Controller Class Initialized
INFO - 2022-03-16 04:23:30 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:23:30 --> Encrypt Class Initialized
INFO - 2022-03-16 04:23:30 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:23:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:23:30 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:23:30 --> Model "Users_model" initialized
INFO - 2022-03-16 04:23:30 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:23:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:23:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:23:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:23:30 --> Final output sent to browser
DEBUG - 2022-03-16 04:23:30 --> Total execution time: 0.0910
ERROR - 2022-03-16 04:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:26:46 --> Config Class Initialized
INFO - 2022-03-16 04:26:46 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:26:46 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:26:46 --> Utf8 Class Initialized
INFO - 2022-03-16 04:26:46 --> URI Class Initialized
INFO - 2022-03-16 04:26:46 --> Router Class Initialized
INFO - 2022-03-16 04:26:46 --> Output Class Initialized
INFO - 2022-03-16 04:26:46 --> Security Class Initialized
DEBUG - 2022-03-16 04:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:26:46 --> Input Class Initialized
INFO - 2022-03-16 04:26:46 --> Language Class Initialized
INFO - 2022-03-16 04:26:46 --> Loader Class Initialized
INFO - 2022-03-16 04:26:46 --> Helper loaded: url_helper
INFO - 2022-03-16 04:26:46 --> Helper loaded: form_helper
INFO - 2022-03-16 04:26:46 --> Helper loaded: common_helper
INFO - 2022-03-16 04:26:46 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:26:46 --> Controller Class Initialized
INFO - 2022-03-16 04:26:46 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:26:46 --> Encrypt Class Initialized
INFO - 2022-03-16 04:26:46 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:26:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:26:46 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:26:46 --> Model "Users_model" initialized
INFO - 2022-03-16 04:26:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:26:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:26:47 --> Config Class Initialized
INFO - 2022-03-16 04:26:47 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:26:47 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:26:47 --> Utf8 Class Initialized
INFO - 2022-03-16 04:26:47 --> URI Class Initialized
INFO - 2022-03-16 04:26:47 --> Router Class Initialized
INFO - 2022-03-16 04:26:47 --> Output Class Initialized
INFO - 2022-03-16 04:26:47 --> Security Class Initialized
DEBUG - 2022-03-16 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:26:47 --> Input Class Initialized
INFO - 2022-03-16 04:26:47 --> Language Class Initialized
INFO - 2022-03-16 04:26:47 --> Loader Class Initialized
INFO - 2022-03-16 04:26:47 --> Helper loaded: url_helper
INFO - 2022-03-16 04:26:47 --> Helper loaded: form_helper
INFO - 2022-03-16 04:26:47 --> Helper loaded: common_helper
INFO - 2022-03-16 04:26:47 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:26:47 --> Controller Class Initialized
INFO - 2022-03-16 04:26:47 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:26:47 --> Encrypt Class Initialized
INFO - 2022-03-16 04:26:47 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:26:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:26:47 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:26:47 --> Model "Users_model" initialized
INFO - 2022-03-16 04:26:47 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:26:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:26:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:26:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:26:47 --> Final output sent to browser
DEBUG - 2022-03-16 04:26:47 --> Total execution time: 0.0886
ERROR - 2022-03-16 04:26:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:26:55 --> Config Class Initialized
INFO - 2022-03-16 04:26:55 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:26:55 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:26:55 --> Utf8 Class Initialized
INFO - 2022-03-16 04:26:55 --> URI Class Initialized
INFO - 2022-03-16 04:26:55 --> Router Class Initialized
INFO - 2022-03-16 04:26:55 --> Output Class Initialized
INFO - 2022-03-16 04:26:55 --> Security Class Initialized
DEBUG - 2022-03-16 04:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:26:55 --> Input Class Initialized
INFO - 2022-03-16 04:26:55 --> Language Class Initialized
INFO - 2022-03-16 04:26:55 --> Loader Class Initialized
INFO - 2022-03-16 04:26:55 --> Helper loaded: url_helper
INFO - 2022-03-16 04:26:55 --> Helper loaded: form_helper
INFO - 2022-03-16 04:26:55 --> Helper loaded: common_helper
INFO - 2022-03-16 04:26:55 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:26:55 --> Controller Class Initialized
INFO - 2022-03-16 04:26:55 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:26:55 --> Encrypt Class Initialized
INFO - 2022-03-16 04:26:55 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:26:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:26:55 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:26:55 --> Model "Users_model" initialized
INFO - 2022-03-16 04:26:55 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:26:55 --> Upload Class Initialized
INFO - 2022-03-16 04:26:55 --> Final output sent to browser
DEBUG - 2022-03-16 04:26:55 --> Total execution time: 0.1375
ERROR - 2022-03-16 04:27:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:27:05 --> Config Class Initialized
INFO - 2022-03-16 04:27:05 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:27:05 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:27:05 --> Utf8 Class Initialized
INFO - 2022-03-16 04:27:05 --> URI Class Initialized
INFO - 2022-03-16 04:27:05 --> Router Class Initialized
INFO - 2022-03-16 04:27:05 --> Output Class Initialized
INFO - 2022-03-16 04:27:05 --> Security Class Initialized
DEBUG - 2022-03-16 04:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:27:05 --> Input Class Initialized
INFO - 2022-03-16 04:27:05 --> Language Class Initialized
INFO - 2022-03-16 04:27:05 --> Loader Class Initialized
INFO - 2022-03-16 04:27:05 --> Helper loaded: url_helper
INFO - 2022-03-16 04:27:05 --> Helper loaded: form_helper
INFO - 2022-03-16 04:27:05 --> Helper loaded: common_helper
INFO - 2022-03-16 04:27:05 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:27:05 --> Controller Class Initialized
INFO - 2022-03-16 04:27:05 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:27:05 --> Encrypt Class Initialized
INFO - 2022-03-16 04:27:05 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:27:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:27:05 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:27:05 --> Model "Users_model" initialized
INFO - 2022-03-16 04:27:05 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:27:05 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-16 04:27:06 --> Final output sent to browser
DEBUG - 2022-03-16 04:27:06 --> Total execution time: 0.8824
ERROR - 2022-03-16 04:27:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:27:21 --> Config Class Initialized
INFO - 2022-03-16 04:27:21 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:27:21 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:27:21 --> Utf8 Class Initialized
INFO - 2022-03-16 04:27:21 --> URI Class Initialized
INFO - 2022-03-16 04:27:21 --> Router Class Initialized
INFO - 2022-03-16 04:27:21 --> Output Class Initialized
INFO - 2022-03-16 04:27:21 --> Security Class Initialized
DEBUG - 2022-03-16 04:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:27:21 --> Input Class Initialized
INFO - 2022-03-16 04:27:21 --> Language Class Initialized
INFO - 2022-03-16 04:27:21 --> Loader Class Initialized
INFO - 2022-03-16 04:27:21 --> Helper loaded: url_helper
INFO - 2022-03-16 04:27:21 --> Helper loaded: form_helper
INFO - 2022-03-16 04:27:21 --> Helper loaded: common_helper
INFO - 2022-03-16 04:27:21 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:27:21 --> Controller Class Initialized
INFO - 2022-03-16 04:27:21 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:27:21 --> Encrypt Class Initialized
INFO - 2022-03-16 04:27:21 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:27:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:27:21 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:27:21 --> Model "Users_model" initialized
INFO - 2022-03-16 04:27:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:27:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:27:21 --> Config Class Initialized
INFO - 2022-03-16 04:27:21 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:27:21 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:27:21 --> Utf8 Class Initialized
INFO - 2022-03-16 04:27:21 --> URI Class Initialized
INFO - 2022-03-16 04:27:21 --> Router Class Initialized
INFO - 2022-03-16 04:27:21 --> Output Class Initialized
INFO - 2022-03-16 04:27:21 --> Security Class Initialized
DEBUG - 2022-03-16 04:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:27:21 --> Input Class Initialized
INFO - 2022-03-16 04:27:21 --> Language Class Initialized
INFO - 2022-03-16 04:27:21 --> Loader Class Initialized
INFO - 2022-03-16 04:27:21 --> Helper loaded: url_helper
INFO - 2022-03-16 04:27:21 --> Helper loaded: form_helper
INFO - 2022-03-16 04:27:21 --> Helper loaded: common_helper
INFO - 2022-03-16 04:27:21 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:27:21 --> Controller Class Initialized
INFO - 2022-03-16 04:27:21 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:27:21 --> Encrypt Class Initialized
INFO - 2022-03-16 04:27:21 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:27:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:27:21 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:27:21 --> Model "Users_model" initialized
INFO - 2022-03-16 04:27:21 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:27:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:27:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:27:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:27:21 --> Final output sent to browser
DEBUG - 2022-03-16 04:27:21 --> Total execution time: 0.0789
ERROR - 2022-03-16 04:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:30:18 --> Config Class Initialized
INFO - 2022-03-16 04:30:18 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:30:18 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:30:18 --> Utf8 Class Initialized
INFO - 2022-03-16 04:30:18 --> URI Class Initialized
INFO - 2022-03-16 04:30:18 --> Router Class Initialized
INFO - 2022-03-16 04:30:18 --> Output Class Initialized
INFO - 2022-03-16 04:30:18 --> Security Class Initialized
DEBUG - 2022-03-16 04:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:30:18 --> Input Class Initialized
INFO - 2022-03-16 04:30:18 --> Language Class Initialized
INFO - 2022-03-16 04:30:18 --> Loader Class Initialized
INFO - 2022-03-16 04:30:18 --> Helper loaded: url_helper
INFO - 2022-03-16 04:30:18 --> Helper loaded: form_helper
INFO - 2022-03-16 04:30:18 --> Helper loaded: common_helper
INFO - 2022-03-16 04:30:18 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:30:18 --> Controller Class Initialized
INFO - 2022-03-16 04:30:18 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:30:18 --> Encrypt Class Initialized
INFO - 2022-03-16 04:30:18 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:30:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:30:18 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:30:18 --> Model "Users_model" initialized
INFO - 2022-03-16 04:30:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:30:19 --> Config Class Initialized
INFO - 2022-03-16 04:30:19 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:30:19 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:30:19 --> Utf8 Class Initialized
INFO - 2022-03-16 04:30:19 --> URI Class Initialized
INFO - 2022-03-16 04:30:19 --> Router Class Initialized
INFO - 2022-03-16 04:30:19 --> Output Class Initialized
INFO - 2022-03-16 04:30:19 --> Security Class Initialized
DEBUG - 2022-03-16 04:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:30:19 --> Input Class Initialized
INFO - 2022-03-16 04:30:19 --> Language Class Initialized
INFO - 2022-03-16 04:30:19 --> Loader Class Initialized
INFO - 2022-03-16 04:30:19 --> Helper loaded: url_helper
INFO - 2022-03-16 04:30:19 --> Helper loaded: form_helper
INFO - 2022-03-16 04:30:19 --> Helper loaded: common_helper
INFO - 2022-03-16 04:30:19 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:30:19 --> Controller Class Initialized
INFO - 2022-03-16 04:30:19 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:30:19 --> Encrypt Class Initialized
INFO - 2022-03-16 04:30:19 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:30:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:30:19 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:30:19 --> Model "Users_model" initialized
INFO - 2022-03-16 04:30:19 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:30:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:30:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:30:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:30:19 --> Final output sent to browser
DEBUG - 2022-03-16 04:30:19 --> Total execution time: 0.0736
ERROR - 2022-03-16 04:30:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:30:26 --> Config Class Initialized
INFO - 2022-03-16 04:30:26 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:30:26 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:30:26 --> Utf8 Class Initialized
INFO - 2022-03-16 04:30:26 --> URI Class Initialized
INFO - 2022-03-16 04:30:26 --> Router Class Initialized
INFO - 2022-03-16 04:30:26 --> Output Class Initialized
INFO - 2022-03-16 04:30:26 --> Security Class Initialized
DEBUG - 2022-03-16 04:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:30:26 --> Input Class Initialized
INFO - 2022-03-16 04:30:26 --> Language Class Initialized
INFO - 2022-03-16 04:30:26 --> Loader Class Initialized
INFO - 2022-03-16 04:30:26 --> Helper loaded: url_helper
INFO - 2022-03-16 04:30:26 --> Helper loaded: form_helper
INFO - 2022-03-16 04:30:26 --> Helper loaded: common_helper
INFO - 2022-03-16 04:30:26 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:30:26 --> Controller Class Initialized
INFO - 2022-03-16 04:30:26 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:30:26 --> Encrypt Class Initialized
INFO - 2022-03-16 04:30:26 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:30:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:30:26 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:30:26 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:30:26 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:30:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:30:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:30:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:30:26 --> Final output sent to browser
DEBUG - 2022-03-16 04:30:26 --> Total execution time: 0.0875
ERROR - 2022-03-16 04:30:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:30:44 --> Config Class Initialized
INFO - 2022-03-16 04:30:44 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:30:44 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:30:44 --> Utf8 Class Initialized
INFO - 2022-03-16 04:30:44 --> URI Class Initialized
INFO - 2022-03-16 04:30:44 --> Router Class Initialized
INFO - 2022-03-16 04:30:44 --> Output Class Initialized
INFO - 2022-03-16 04:30:44 --> Security Class Initialized
DEBUG - 2022-03-16 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:30:45 --> Input Class Initialized
INFO - 2022-03-16 04:30:45 --> Language Class Initialized
INFO - 2022-03-16 04:30:45 --> Loader Class Initialized
INFO - 2022-03-16 04:30:45 --> Helper loaded: url_helper
INFO - 2022-03-16 04:30:45 --> Helper loaded: form_helper
INFO - 2022-03-16 04:30:45 --> Helper loaded: common_helper
INFO - 2022-03-16 04:30:45 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:30:45 --> Controller Class Initialized
INFO - 2022-03-16 04:30:45 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:30:45 --> Encrypt Class Initialized
INFO - 2022-03-16 04:30:45 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:30:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:30:45 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:30:45 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:30:45 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:30:45 --> Upload Class Initialized
INFO - 2022-03-16 04:30:45 --> Final output sent to browser
DEBUG - 2022-03-16 04:30:45 --> Total execution time: 0.1175
ERROR - 2022-03-16 04:30:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:30:56 --> Config Class Initialized
INFO - 2022-03-16 04:30:56 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:30:56 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:30:56 --> Utf8 Class Initialized
INFO - 2022-03-16 04:30:56 --> URI Class Initialized
INFO - 2022-03-16 04:30:56 --> Router Class Initialized
INFO - 2022-03-16 04:30:56 --> Output Class Initialized
INFO - 2022-03-16 04:30:56 --> Security Class Initialized
DEBUG - 2022-03-16 04:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:30:56 --> Input Class Initialized
INFO - 2022-03-16 04:30:56 --> Language Class Initialized
INFO - 2022-03-16 04:30:56 --> Loader Class Initialized
INFO - 2022-03-16 04:30:56 --> Helper loaded: url_helper
INFO - 2022-03-16 04:30:56 --> Helper loaded: form_helper
INFO - 2022-03-16 04:30:56 --> Helper loaded: common_helper
INFO - 2022-03-16 04:30:56 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:30:56 --> Controller Class Initialized
INFO - 2022-03-16 04:30:56 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:30:56 --> Encrypt Class Initialized
INFO - 2022-03-16 04:30:56 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:30:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:30:56 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:30:56 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:30:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:30:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:30:57 --> Config Class Initialized
INFO - 2022-03-16 04:30:57 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:30:57 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:30:57 --> Utf8 Class Initialized
INFO - 2022-03-16 04:30:57 --> URI Class Initialized
INFO - 2022-03-16 04:30:57 --> Router Class Initialized
INFO - 2022-03-16 04:30:57 --> Output Class Initialized
INFO - 2022-03-16 04:30:57 --> Security Class Initialized
DEBUG - 2022-03-16 04:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:30:57 --> Input Class Initialized
INFO - 2022-03-16 04:30:57 --> Language Class Initialized
INFO - 2022-03-16 04:30:57 --> Loader Class Initialized
INFO - 2022-03-16 04:30:57 --> Helper loaded: url_helper
INFO - 2022-03-16 04:30:57 --> Helper loaded: form_helper
INFO - 2022-03-16 04:30:57 --> Helper loaded: common_helper
INFO - 2022-03-16 04:30:57 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:30:57 --> Controller Class Initialized
INFO - 2022-03-16 04:30:57 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:30:57 --> Encrypt Class Initialized
INFO - 2022-03-16 04:30:57 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:30:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:30:57 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:30:57 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:30:57 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:30:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:30:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:30:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:30:57 --> Final output sent to browser
DEBUG - 2022-03-16 04:30:57 --> Total execution time: 0.1102
ERROR - 2022-03-16 04:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:30:58 --> Config Class Initialized
INFO - 2022-03-16 04:30:58 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:30:58 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:30:58 --> Utf8 Class Initialized
INFO - 2022-03-16 04:30:58 --> URI Class Initialized
INFO - 2022-03-16 04:30:58 --> Router Class Initialized
INFO - 2022-03-16 04:30:58 --> Output Class Initialized
INFO - 2022-03-16 04:30:58 --> Security Class Initialized
DEBUG - 2022-03-16 04:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:30:58 --> Input Class Initialized
INFO - 2022-03-16 04:30:58 --> Language Class Initialized
INFO - 2022-03-16 04:30:58 --> Loader Class Initialized
INFO - 2022-03-16 04:30:58 --> Helper loaded: url_helper
INFO - 2022-03-16 04:30:58 --> Helper loaded: form_helper
INFO - 2022-03-16 04:30:58 --> Helper loaded: common_helper
INFO - 2022-03-16 04:30:58 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:30:58 --> Controller Class Initialized
INFO - 2022-03-16 04:30:58 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:30:58 --> Encrypt Class Initialized
INFO - 2022-03-16 04:30:58 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:30:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:30:58 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:30:58 --> Model "Users_model" initialized
INFO - 2022-03-16 04:30:58 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:30:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:30:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:30:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:30:58 --> Final output sent to browser
DEBUG - 2022-03-16 04:30:58 --> Total execution time: 0.0916
ERROR - 2022-03-16 04:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:31:10 --> Config Class Initialized
INFO - 2022-03-16 04:31:10 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:31:10 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:31:10 --> Utf8 Class Initialized
INFO - 2022-03-16 04:31:10 --> URI Class Initialized
INFO - 2022-03-16 04:31:10 --> Router Class Initialized
INFO - 2022-03-16 04:31:10 --> Output Class Initialized
INFO - 2022-03-16 04:31:10 --> Security Class Initialized
DEBUG - 2022-03-16 04:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:31:10 --> Input Class Initialized
INFO - 2022-03-16 04:31:10 --> Language Class Initialized
INFO - 2022-03-16 04:31:10 --> Loader Class Initialized
INFO - 2022-03-16 04:31:10 --> Helper loaded: url_helper
INFO - 2022-03-16 04:31:10 --> Helper loaded: form_helper
INFO - 2022-03-16 04:31:10 --> Helper loaded: common_helper
INFO - 2022-03-16 04:31:10 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:31:10 --> Controller Class Initialized
INFO - 2022-03-16 04:31:10 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:31:10 --> Encrypt Class Initialized
INFO - 2022-03-16 04:31:10 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:31:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:31:10 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:31:10 --> Model "Users_model" initialized
INFO - 2022-03-16 04:31:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:31:10 --> Config Class Initialized
INFO - 2022-03-16 04:31:10 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:31:10 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:31:10 --> Utf8 Class Initialized
INFO - 2022-03-16 04:31:10 --> URI Class Initialized
INFO - 2022-03-16 04:31:10 --> Router Class Initialized
INFO - 2022-03-16 04:31:10 --> Output Class Initialized
INFO - 2022-03-16 04:31:10 --> Security Class Initialized
DEBUG - 2022-03-16 04:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:31:10 --> Input Class Initialized
INFO - 2022-03-16 04:31:10 --> Language Class Initialized
INFO - 2022-03-16 04:31:10 --> Loader Class Initialized
INFO - 2022-03-16 04:31:10 --> Helper loaded: url_helper
INFO - 2022-03-16 04:31:10 --> Helper loaded: form_helper
INFO - 2022-03-16 04:31:10 --> Helper loaded: common_helper
INFO - 2022-03-16 04:31:10 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:31:10 --> Controller Class Initialized
INFO - 2022-03-16 04:31:10 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:31:10 --> Encrypt Class Initialized
INFO - 2022-03-16 04:31:10 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:31:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:31:10 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:31:10 --> Model "Users_model" initialized
INFO - 2022-03-16 04:31:10 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:31:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:31:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:31:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:31:10 --> Final output sent to browser
DEBUG - 2022-03-16 04:31:10 --> Total execution time: 0.1014
ERROR - 2022-03-16 04:31:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:31:25 --> Config Class Initialized
INFO - 2022-03-16 04:31:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:31:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:31:25 --> Utf8 Class Initialized
INFO - 2022-03-16 04:31:25 --> URI Class Initialized
INFO - 2022-03-16 04:31:25 --> Router Class Initialized
INFO - 2022-03-16 04:31:25 --> Output Class Initialized
INFO - 2022-03-16 04:31:25 --> Security Class Initialized
DEBUG - 2022-03-16 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:31:25 --> Input Class Initialized
INFO - 2022-03-16 04:31:25 --> Language Class Initialized
INFO - 2022-03-16 04:31:25 --> Loader Class Initialized
INFO - 2022-03-16 04:31:25 --> Helper loaded: url_helper
INFO - 2022-03-16 04:31:25 --> Helper loaded: form_helper
INFO - 2022-03-16 04:31:25 --> Helper loaded: common_helper
INFO - 2022-03-16 04:31:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:31:25 --> Controller Class Initialized
INFO - 2022-03-16 04:31:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:31:25 --> Encrypt Class Initialized
INFO - 2022-03-16 04:31:25 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:31:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:31:25 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:31:25 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:31:25 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:31:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:31:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:31:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:31:25 --> Final output sent to browser
DEBUG - 2022-03-16 04:31:25 --> Total execution time: 0.4191
ERROR - 2022-03-16 04:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:31:54 --> Config Class Initialized
INFO - 2022-03-16 04:31:54 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:31:54 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:31:54 --> Utf8 Class Initialized
INFO - 2022-03-16 04:31:54 --> URI Class Initialized
INFO - 2022-03-16 04:31:54 --> Router Class Initialized
INFO - 2022-03-16 04:31:54 --> Output Class Initialized
INFO - 2022-03-16 04:31:54 --> Security Class Initialized
DEBUG - 2022-03-16 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:31:54 --> Input Class Initialized
INFO - 2022-03-16 04:31:54 --> Language Class Initialized
INFO - 2022-03-16 04:31:54 --> Loader Class Initialized
INFO - 2022-03-16 04:31:54 --> Helper loaded: url_helper
INFO - 2022-03-16 04:31:54 --> Helper loaded: form_helper
INFO - 2022-03-16 04:31:54 --> Helper loaded: common_helper
INFO - 2022-03-16 04:31:54 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:31:54 --> Controller Class Initialized
INFO - 2022-03-16 04:31:54 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:31:54 --> Encrypt Class Initialized
INFO - 2022-03-16 04:31:54 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:31:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:31:54 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:31:54 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:31:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:31:55 --> Config Class Initialized
INFO - 2022-03-16 04:31:55 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:31:55 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:31:55 --> Utf8 Class Initialized
INFO - 2022-03-16 04:31:55 --> URI Class Initialized
INFO - 2022-03-16 04:31:55 --> Router Class Initialized
INFO - 2022-03-16 04:31:55 --> Output Class Initialized
INFO - 2022-03-16 04:31:55 --> Security Class Initialized
DEBUG - 2022-03-16 04:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:31:55 --> Input Class Initialized
INFO - 2022-03-16 04:31:55 --> Language Class Initialized
INFO - 2022-03-16 04:31:55 --> Loader Class Initialized
INFO - 2022-03-16 04:31:55 --> Helper loaded: url_helper
INFO - 2022-03-16 04:31:55 --> Helper loaded: form_helper
INFO - 2022-03-16 04:31:55 --> Helper loaded: common_helper
INFO - 2022-03-16 04:31:55 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:31:55 --> Controller Class Initialized
INFO - 2022-03-16 04:31:55 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:31:55 --> Encrypt Class Initialized
INFO - 2022-03-16 04:31:55 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:31:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:31:55 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:31:55 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:31:55 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:31:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:31:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:31:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:31:55 --> Final output sent to browser
DEBUG - 2022-03-16 04:31:55 --> Total execution time: 0.1489
ERROR - 2022-03-16 04:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:31:56 --> Config Class Initialized
INFO - 2022-03-16 04:31:56 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:31:56 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:31:56 --> Utf8 Class Initialized
INFO - 2022-03-16 04:31:56 --> URI Class Initialized
INFO - 2022-03-16 04:31:56 --> Router Class Initialized
INFO - 2022-03-16 04:31:56 --> Output Class Initialized
INFO - 2022-03-16 04:31:56 --> Security Class Initialized
DEBUG - 2022-03-16 04:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:31:56 --> Input Class Initialized
INFO - 2022-03-16 04:31:56 --> Language Class Initialized
INFO - 2022-03-16 04:31:56 --> Loader Class Initialized
INFO - 2022-03-16 04:31:56 --> Helper loaded: url_helper
INFO - 2022-03-16 04:31:56 --> Helper loaded: form_helper
INFO - 2022-03-16 04:31:56 --> Helper loaded: common_helper
INFO - 2022-03-16 04:31:56 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:31:56 --> Controller Class Initialized
INFO - 2022-03-16 04:31:56 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:31:56 --> Encrypt Class Initialized
INFO - 2022-03-16 04:31:56 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:31:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:31:56 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:31:56 --> Model "Users_model" initialized
INFO - 2022-03-16 04:31:56 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:31:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:31:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:31:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:31:56 --> Final output sent to browser
DEBUG - 2022-03-16 04:31:56 --> Total execution time: 0.0932
ERROR - 2022-03-16 04:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:32:26 --> Config Class Initialized
INFO - 2022-03-16 04:32:26 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:32:26 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:32:26 --> Utf8 Class Initialized
INFO - 2022-03-16 04:32:26 --> URI Class Initialized
INFO - 2022-03-16 04:32:26 --> Router Class Initialized
INFO - 2022-03-16 04:32:26 --> Output Class Initialized
INFO - 2022-03-16 04:32:26 --> Security Class Initialized
DEBUG - 2022-03-16 04:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:32:26 --> Input Class Initialized
INFO - 2022-03-16 04:32:26 --> Language Class Initialized
INFO - 2022-03-16 04:32:26 --> Loader Class Initialized
INFO - 2022-03-16 04:32:26 --> Helper loaded: url_helper
INFO - 2022-03-16 04:32:26 --> Helper loaded: form_helper
INFO - 2022-03-16 04:32:26 --> Helper loaded: common_helper
INFO - 2022-03-16 04:32:26 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:32:26 --> Controller Class Initialized
INFO - 2022-03-16 04:32:26 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:32:26 --> Encrypt Class Initialized
INFO - 2022-03-16 04:32:26 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:32:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:32:26 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:32:26 --> Model "Users_model" initialized
INFO - 2022-03-16 04:32:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:32:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:32:27 --> Config Class Initialized
INFO - 2022-03-16 04:32:27 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:32:27 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:32:27 --> Utf8 Class Initialized
INFO - 2022-03-16 04:32:27 --> URI Class Initialized
INFO - 2022-03-16 04:32:27 --> Router Class Initialized
INFO - 2022-03-16 04:32:27 --> Output Class Initialized
INFO - 2022-03-16 04:32:27 --> Security Class Initialized
DEBUG - 2022-03-16 04:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:32:27 --> Input Class Initialized
INFO - 2022-03-16 04:32:27 --> Language Class Initialized
INFO - 2022-03-16 04:32:27 --> Loader Class Initialized
INFO - 2022-03-16 04:32:27 --> Helper loaded: url_helper
INFO - 2022-03-16 04:32:27 --> Helper loaded: form_helper
INFO - 2022-03-16 04:32:27 --> Helper loaded: common_helper
INFO - 2022-03-16 04:32:27 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-16 04:32:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:32:27 --> Config Class Initialized
INFO - 2022-03-16 04:32:27 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:32:27 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:32:27 --> Utf8 Class Initialized
INFO - 2022-03-16 04:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:32:27 --> Controller Class Initialized
INFO - 2022-03-16 04:32:27 --> URI Class Initialized
INFO - 2022-03-16 04:32:27 --> Router Class Initialized
INFO - 2022-03-16 04:32:27 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:32:27 --> Encrypt Class Initialized
INFO - 2022-03-16 04:32:27 --> Output Class Initialized
INFO - 2022-03-16 04:32:27 --> Security Class Initialized
INFO - 2022-03-16 04:32:27 --> Model "Patient_model" initialized
DEBUG - 2022-03-16 04:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:32:27 --> Input Class Initialized
INFO - 2022-03-16 04:32:27 --> Language Class Initialized
INFO - 2022-03-16 04:32:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:32:27 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:32:27 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:32:27 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:32:27 --> Loader Class Initialized
INFO - 2022-03-16 04:32:27 --> Helper loaded: url_helper
INFO - 2022-03-16 04:32:27 --> Helper loaded: form_helper
INFO - 2022-03-16 04:32:27 --> Helper loaded: common_helper
INFO - 2022-03-16 04:32:27 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:32:27 --> Controller Class Initialized
INFO - 2022-03-16 04:32:27 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:32:27 --> Encrypt Class Initialized
INFO - 2022-03-16 04:32:27 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:32:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:32:27 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:32:27 --> Model "Users_model" initialized
INFO - 2022-03-16 04:32:27 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:32:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:32:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:32:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:32:27 --> Final output sent to browser
DEBUG - 2022-03-16 04:32:27 --> Total execution time: 0.3588
INFO - 2022-03-16 04:32:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:32:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:32:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:32:27 --> Final output sent to browser
DEBUG - 2022-03-16 04:32:27 --> Total execution time: 0.2976
ERROR - 2022-03-16 04:32:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:32:44 --> Config Class Initialized
INFO - 2022-03-16 04:32:44 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:32:44 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:32:44 --> Utf8 Class Initialized
INFO - 2022-03-16 04:32:44 --> URI Class Initialized
INFO - 2022-03-16 04:32:44 --> Router Class Initialized
INFO - 2022-03-16 04:32:44 --> Output Class Initialized
INFO - 2022-03-16 04:32:44 --> Security Class Initialized
DEBUG - 2022-03-16 04:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:32:44 --> Input Class Initialized
INFO - 2022-03-16 04:32:44 --> Language Class Initialized
INFO - 2022-03-16 04:32:44 --> Loader Class Initialized
INFO - 2022-03-16 04:32:44 --> Helper loaded: url_helper
INFO - 2022-03-16 04:32:44 --> Helper loaded: form_helper
INFO - 2022-03-16 04:32:44 --> Helper loaded: common_helper
INFO - 2022-03-16 04:32:44 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:32:44 --> Controller Class Initialized
INFO - 2022-03-16 04:32:44 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:32:44 --> Encrypt Class Initialized
INFO - 2022-03-16 04:32:44 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:32:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:32:44 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:32:44 --> Model "Users_model" initialized
INFO - 2022-03-16 04:32:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:32:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:32:45 --> Config Class Initialized
INFO - 2022-03-16 04:32:45 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:32:45 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:32:45 --> Utf8 Class Initialized
INFO - 2022-03-16 04:32:45 --> URI Class Initialized
INFO - 2022-03-16 04:32:45 --> Router Class Initialized
INFO - 2022-03-16 04:32:45 --> Output Class Initialized
INFO - 2022-03-16 04:32:45 --> Security Class Initialized
DEBUG - 2022-03-16 04:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:32:45 --> Input Class Initialized
INFO - 2022-03-16 04:32:45 --> Language Class Initialized
INFO - 2022-03-16 04:32:45 --> Loader Class Initialized
INFO - 2022-03-16 04:32:45 --> Helper loaded: url_helper
INFO - 2022-03-16 04:32:45 --> Helper loaded: form_helper
INFO - 2022-03-16 04:32:45 --> Helper loaded: common_helper
INFO - 2022-03-16 04:32:45 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:32:46 --> Controller Class Initialized
INFO - 2022-03-16 04:32:46 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:32:46 --> Encrypt Class Initialized
INFO - 2022-03-16 04:32:46 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:32:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:32:46 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:32:46 --> Model "Users_model" initialized
INFO - 2022-03-16 04:32:46 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:32:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:32:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:32:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:32:46 --> Final output sent to browser
DEBUG - 2022-03-16 04:32:46 --> Total execution time: 0.1522
ERROR - 2022-03-16 04:32:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:32:58 --> Config Class Initialized
INFO - 2022-03-16 04:32:58 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:32:58 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:32:58 --> Utf8 Class Initialized
INFO - 2022-03-16 04:32:58 --> URI Class Initialized
INFO - 2022-03-16 04:32:58 --> Router Class Initialized
INFO - 2022-03-16 04:32:58 --> Output Class Initialized
INFO - 2022-03-16 04:32:58 --> Security Class Initialized
DEBUG - 2022-03-16 04:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:32:58 --> Input Class Initialized
INFO - 2022-03-16 04:32:58 --> Language Class Initialized
INFO - 2022-03-16 04:32:58 --> Loader Class Initialized
INFO - 2022-03-16 04:32:58 --> Helper loaded: url_helper
INFO - 2022-03-16 04:32:58 --> Helper loaded: form_helper
INFO - 2022-03-16 04:32:58 --> Helper loaded: common_helper
INFO - 2022-03-16 04:32:58 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:32:58 --> Controller Class Initialized
INFO - 2022-03-16 04:32:58 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:32:58 --> Encrypt Class Initialized
INFO - 2022-03-16 04:32:58 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:32:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:32:58 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:32:58 --> Model "Users_model" initialized
INFO - 2022-03-16 04:32:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:32:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:32:58 --> Config Class Initialized
INFO - 2022-03-16 04:32:58 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:32:58 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:32:58 --> Utf8 Class Initialized
INFO - 2022-03-16 04:32:58 --> URI Class Initialized
INFO - 2022-03-16 04:32:58 --> Router Class Initialized
INFO - 2022-03-16 04:32:58 --> Output Class Initialized
INFO - 2022-03-16 04:32:58 --> Security Class Initialized
DEBUG - 2022-03-16 04:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:32:58 --> Input Class Initialized
INFO - 2022-03-16 04:32:58 --> Language Class Initialized
INFO - 2022-03-16 04:32:58 --> Loader Class Initialized
INFO - 2022-03-16 04:32:58 --> Helper loaded: url_helper
INFO - 2022-03-16 04:32:58 --> Helper loaded: form_helper
INFO - 2022-03-16 04:32:58 --> Helper loaded: common_helper
INFO - 2022-03-16 04:32:58 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:32:58 --> Controller Class Initialized
INFO - 2022-03-16 04:32:58 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:32:58 --> Encrypt Class Initialized
INFO - 2022-03-16 04:32:58 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:32:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:32:58 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:32:58 --> Model "Users_model" initialized
INFO - 2022-03-16 04:32:58 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:32:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:32:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:32:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:32:59 --> Final output sent to browser
DEBUG - 2022-03-16 04:32:59 --> Total execution time: 0.0891
ERROR - 2022-03-16 04:33:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:33:02 --> Config Class Initialized
INFO - 2022-03-16 04:33:02 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:33:02 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:33:02 --> Utf8 Class Initialized
INFO - 2022-03-16 04:33:02 --> URI Class Initialized
INFO - 2022-03-16 04:33:02 --> Router Class Initialized
INFO - 2022-03-16 04:33:02 --> Output Class Initialized
INFO - 2022-03-16 04:33:02 --> Security Class Initialized
DEBUG - 2022-03-16 04:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:33:02 --> Input Class Initialized
INFO - 2022-03-16 04:33:02 --> Language Class Initialized
INFO - 2022-03-16 04:33:02 --> Loader Class Initialized
INFO - 2022-03-16 04:33:02 --> Helper loaded: url_helper
INFO - 2022-03-16 04:33:02 --> Helper loaded: form_helper
INFO - 2022-03-16 04:33:02 --> Helper loaded: common_helper
INFO - 2022-03-16 04:33:02 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:33:02 --> Controller Class Initialized
INFO - 2022-03-16 04:33:02 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:33:02 --> Encrypt Class Initialized
INFO - 2022-03-16 04:33:02 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:33:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:33:02 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:33:02 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:33:02 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:33:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:33:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:33:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:33:02 --> Final output sent to browser
DEBUG - 2022-03-16 04:33:02 --> Total execution time: 0.0909
ERROR - 2022-03-16 04:33:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:33:15 --> Config Class Initialized
INFO - 2022-03-16 04:33:15 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:33:15 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:33:15 --> Utf8 Class Initialized
INFO - 2022-03-16 04:33:15 --> URI Class Initialized
INFO - 2022-03-16 04:33:15 --> Router Class Initialized
INFO - 2022-03-16 04:33:15 --> Output Class Initialized
INFO - 2022-03-16 04:33:15 --> Security Class Initialized
DEBUG - 2022-03-16 04:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:33:15 --> Input Class Initialized
INFO - 2022-03-16 04:33:15 --> Language Class Initialized
INFO - 2022-03-16 04:33:15 --> Loader Class Initialized
INFO - 2022-03-16 04:33:15 --> Helper loaded: url_helper
INFO - 2022-03-16 04:33:15 --> Helper loaded: form_helper
INFO - 2022-03-16 04:33:15 --> Helper loaded: common_helper
INFO - 2022-03-16 04:33:15 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:33:15 --> Controller Class Initialized
INFO - 2022-03-16 04:33:15 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:33:15 --> Encrypt Class Initialized
INFO - 2022-03-16 04:33:15 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:33:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:33:15 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:33:15 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:33:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:33:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:33:16 --> Config Class Initialized
INFO - 2022-03-16 04:33:16 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:33:16 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:33:16 --> Utf8 Class Initialized
INFO - 2022-03-16 04:33:16 --> URI Class Initialized
INFO - 2022-03-16 04:33:16 --> Router Class Initialized
INFO - 2022-03-16 04:33:16 --> Output Class Initialized
INFO - 2022-03-16 04:33:16 --> Security Class Initialized
DEBUG - 2022-03-16 04:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:33:16 --> Input Class Initialized
INFO - 2022-03-16 04:33:16 --> Language Class Initialized
INFO - 2022-03-16 04:33:16 --> Loader Class Initialized
INFO - 2022-03-16 04:33:16 --> Helper loaded: url_helper
INFO - 2022-03-16 04:33:16 --> Helper loaded: form_helper
INFO - 2022-03-16 04:33:16 --> Helper loaded: common_helper
INFO - 2022-03-16 04:33:16 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:33:16 --> Controller Class Initialized
INFO - 2022-03-16 04:33:16 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:33:16 --> Encrypt Class Initialized
INFO - 2022-03-16 04:33:16 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:33:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:33:16 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:33:16 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:33:16 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:33:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:33:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:33:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:33:16 --> Final output sent to browser
DEBUG - 2022-03-16 04:33:16 --> Total execution time: 0.1092
ERROR - 2022-03-16 04:33:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:33:17 --> Config Class Initialized
INFO - 2022-03-16 04:33:17 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:33:17 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:33:17 --> Utf8 Class Initialized
INFO - 2022-03-16 04:33:17 --> URI Class Initialized
INFO - 2022-03-16 04:33:17 --> Router Class Initialized
INFO - 2022-03-16 04:33:17 --> Output Class Initialized
INFO - 2022-03-16 04:33:17 --> Security Class Initialized
DEBUG - 2022-03-16 04:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:33:17 --> Input Class Initialized
INFO - 2022-03-16 04:33:17 --> Language Class Initialized
INFO - 2022-03-16 04:33:17 --> Loader Class Initialized
INFO - 2022-03-16 04:33:17 --> Helper loaded: url_helper
INFO - 2022-03-16 04:33:17 --> Helper loaded: form_helper
INFO - 2022-03-16 04:33:17 --> Helper loaded: common_helper
INFO - 2022-03-16 04:33:17 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:33:17 --> Controller Class Initialized
INFO - 2022-03-16 04:33:17 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:33:17 --> Encrypt Class Initialized
INFO - 2022-03-16 04:33:17 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:33:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:33:17 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:33:17 --> Model "Users_model" initialized
INFO - 2022-03-16 04:33:17 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:33:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:33:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:33:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:33:17 --> Final output sent to browser
DEBUG - 2022-03-16 04:33:17 --> Total execution time: 0.1060
ERROR - 2022-03-16 04:33:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:33:29 --> Config Class Initialized
INFO - 2022-03-16 04:33:29 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:33:29 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:33:29 --> Utf8 Class Initialized
INFO - 2022-03-16 04:33:29 --> URI Class Initialized
INFO - 2022-03-16 04:33:29 --> Router Class Initialized
INFO - 2022-03-16 04:33:29 --> Output Class Initialized
INFO - 2022-03-16 04:33:29 --> Security Class Initialized
DEBUG - 2022-03-16 04:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:33:29 --> Input Class Initialized
INFO - 2022-03-16 04:33:29 --> Language Class Initialized
INFO - 2022-03-16 04:33:29 --> Loader Class Initialized
INFO - 2022-03-16 04:33:29 --> Helper loaded: url_helper
INFO - 2022-03-16 04:33:29 --> Helper loaded: form_helper
INFO - 2022-03-16 04:33:29 --> Helper loaded: common_helper
INFO - 2022-03-16 04:33:29 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:33:29 --> Controller Class Initialized
INFO - 2022-03-16 04:33:29 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:33:29 --> Encrypt Class Initialized
INFO - 2022-03-16 04:33:29 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:33:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:33:29 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:33:29 --> Model "Users_model" initialized
INFO - 2022-03-16 04:33:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:33:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:33:30 --> Config Class Initialized
INFO - 2022-03-16 04:33:30 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:33:30 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:33:30 --> Utf8 Class Initialized
INFO - 2022-03-16 04:33:30 --> URI Class Initialized
INFO - 2022-03-16 04:33:30 --> Router Class Initialized
INFO - 2022-03-16 04:33:30 --> Output Class Initialized
INFO - 2022-03-16 04:33:30 --> Security Class Initialized
DEBUG - 2022-03-16 04:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:33:30 --> Input Class Initialized
INFO - 2022-03-16 04:33:30 --> Language Class Initialized
INFO - 2022-03-16 04:33:30 --> Loader Class Initialized
INFO - 2022-03-16 04:33:30 --> Helper loaded: url_helper
INFO - 2022-03-16 04:33:30 --> Helper loaded: form_helper
INFO - 2022-03-16 04:33:30 --> Helper loaded: common_helper
INFO - 2022-03-16 04:33:30 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:33:30 --> Controller Class Initialized
INFO - 2022-03-16 04:33:30 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:33:30 --> Encrypt Class Initialized
INFO - 2022-03-16 04:33:30 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:33:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:33:30 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:33:30 --> Model "Users_model" initialized
INFO - 2022-03-16 04:33:30 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:33:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:33:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:33:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:33:30 --> Final output sent to browser
DEBUG - 2022-03-16 04:33:30 --> Total execution time: 0.0924
ERROR - 2022-03-16 04:33:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:33:46 --> Config Class Initialized
INFO - 2022-03-16 04:33:46 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:33:46 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:33:46 --> Utf8 Class Initialized
INFO - 2022-03-16 04:33:46 --> URI Class Initialized
INFO - 2022-03-16 04:33:46 --> Router Class Initialized
INFO - 2022-03-16 04:33:46 --> Output Class Initialized
INFO - 2022-03-16 04:33:46 --> Security Class Initialized
DEBUG - 2022-03-16 04:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:33:46 --> Input Class Initialized
INFO - 2022-03-16 04:33:46 --> Language Class Initialized
INFO - 2022-03-16 04:33:46 --> Loader Class Initialized
INFO - 2022-03-16 04:33:46 --> Helper loaded: url_helper
INFO - 2022-03-16 04:33:46 --> Helper loaded: form_helper
INFO - 2022-03-16 04:33:46 --> Helper loaded: common_helper
INFO - 2022-03-16 04:33:46 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:33:46 --> Controller Class Initialized
INFO - 2022-03-16 04:33:46 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:33:46 --> Encrypt Class Initialized
INFO - 2022-03-16 04:33:46 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:33:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:33:46 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:33:46 --> Model "Users_model" initialized
INFO - 2022-03-16 04:33:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:33:48 --> Config Class Initialized
INFO - 2022-03-16 04:33:48 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:33:48 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:33:48 --> Utf8 Class Initialized
INFO - 2022-03-16 04:33:48 --> URI Class Initialized
INFO - 2022-03-16 04:33:48 --> Router Class Initialized
INFO - 2022-03-16 04:33:48 --> Output Class Initialized
INFO - 2022-03-16 04:33:48 --> Security Class Initialized
DEBUG - 2022-03-16 04:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:33:48 --> Input Class Initialized
INFO - 2022-03-16 04:33:48 --> Language Class Initialized
INFO - 2022-03-16 04:33:48 --> Loader Class Initialized
INFO - 2022-03-16 04:33:48 --> Helper loaded: url_helper
INFO - 2022-03-16 04:33:48 --> Helper loaded: form_helper
INFO - 2022-03-16 04:33:48 --> Helper loaded: common_helper
INFO - 2022-03-16 04:33:48 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:33:48 --> Controller Class Initialized
INFO - 2022-03-16 04:33:48 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:33:48 --> Encrypt Class Initialized
INFO - 2022-03-16 04:33:48 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:33:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:33:48 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:33:48 --> Model "Users_model" initialized
INFO - 2022-03-16 04:33:48 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:33:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:33:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:33:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:33:48 --> Final output sent to browser
DEBUG - 2022-03-16 04:33:48 --> Total execution time: 0.0750
ERROR - 2022-03-16 04:34:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:34:01 --> Config Class Initialized
INFO - 2022-03-16 04:34:01 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:34:01 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:34:01 --> Utf8 Class Initialized
INFO - 2022-03-16 04:34:01 --> URI Class Initialized
INFO - 2022-03-16 04:34:01 --> Router Class Initialized
INFO - 2022-03-16 04:34:01 --> Output Class Initialized
INFO - 2022-03-16 04:34:01 --> Security Class Initialized
DEBUG - 2022-03-16 04:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:34:01 --> Input Class Initialized
INFO - 2022-03-16 04:34:01 --> Language Class Initialized
INFO - 2022-03-16 04:34:01 --> Loader Class Initialized
INFO - 2022-03-16 04:34:01 --> Helper loaded: url_helper
INFO - 2022-03-16 04:34:01 --> Helper loaded: form_helper
INFO - 2022-03-16 04:34:01 --> Helper loaded: common_helper
INFO - 2022-03-16 04:34:01 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:34:01 --> Controller Class Initialized
INFO - 2022-03-16 04:34:01 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:34:01 --> Encrypt Class Initialized
INFO - 2022-03-16 04:34:01 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:34:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:34:01 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:34:01 --> Model "Users_model" initialized
INFO - 2022-03-16 04:34:01 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:34:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:34:04 --> Config Class Initialized
INFO - 2022-03-16 04:34:04 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:34:04 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:34:04 --> Utf8 Class Initialized
INFO - 2022-03-16 04:34:04 --> URI Class Initialized
INFO - 2022-03-16 04:34:04 --> Router Class Initialized
INFO - 2022-03-16 04:34:04 --> Output Class Initialized
INFO - 2022-03-16 04:34:04 --> Security Class Initialized
DEBUG - 2022-03-16 04:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:34:04 --> Input Class Initialized
INFO - 2022-03-16 04:34:04 --> Language Class Initialized
INFO - 2022-03-16 04:34:04 --> Loader Class Initialized
INFO - 2022-03-16 04:34:04 --> Helper loaded: url_helper
INFO - 2022-03-16 04:34:04 --> Helper loaded: form_helper
INFO - 2022-03-16 04:34:04 --> Helper loaded: common_helper
INFO - 2022-03-16 04:34:04 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:34:04 --> Controller Class Initialized
INFO - 2022-03-16 04:34:04 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:34:04 --> Encrypt Class Initialized
INFO - 2022-03-16 04:34:04 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:34:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:34:04 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:34:04 --> Model "Users_model" initialized
INFO - 2022-03-16 04:34:04 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:34:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:34:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:34:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:34:04 --> Final output sent to browser
DEBUG - 2022-03-16 04:34:04 --> Total execution time: 0.1037
ERROR - 2022-03-16 04:46:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:46:56 --> Config Class Initialized
INFO - 2022-03-16 04:46:56 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:46:56 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:46:56 --> Utf8 Class Initialized
INFO - 2022-03-16 04:46:56 --> URI Class Initialized
INFO - 2022-03-16 04:46:56 --> Router Class Initialized
INFO - 2022-03-16 04:46:56 --> Output Class Initialized
INFO - 2022-03-16 04:46:56 --> Security Class Initialized
DEBUG - 2022-03-16 04:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:46:56 --> Input Class Initialized
INFO - 2022-03-16 04:46:56 --> Language Class Initialized
INFO - 2022-03-16 04:46:56 --> Loader Class Initialized
INFO - 2022-03-16 04:46:56 --> Helper loaded: url_helper
INFO - 2022-03-16 04:46:56 --> Helper loaded: form_helper
INFO - 2022-03-16 04:46:56 --> Helper loaded: common_helper
INFO - 2022-03-16 04:46:56 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:46:56 --> Controller Class Initialized
INFO - 2022-03-16 04:46:56 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:46:56 --> Encrypt Class Initialized
INFO - 2022-03-16 04:46:56 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:46:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:46:56 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:46:56 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:46:56 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:46:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:46:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 04:46:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:46:56 --> Final output sent to browser
DEBUG - 2022-03-16 04:46:56 --> Total execution time: 0.0958
ERROR - 2022-03-16 04:47:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:47:04 --> Config Class Initialized
INFO - 2022-03-16 04:47:04 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:47:04 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:47:04 --> Utf8 Class Initialized
INFO - 2022-03-16 04:47:04 --> URI Class Initialized
INFO - 2022-03-16 04:47:04 --> Router Class Initialized
INFO - 2022-03-16 04:47:04 --> Output Class Initialized
INFO - 2022-03-16 04:47:04 --> Security Class Initialized
DEBUG - 2022-03-16 04:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:47:04 --> Input Class Initialized
INFO - 2022-03-16 04:47:04 --> Language Class Initialized
INFO - 2022-03-16 04:47:04 --> Loader Class Initialized
INFO - 2022-03-16 04:47:04 --> Helper loaded: url_helper
INFO - 2022-03-16 04:47:04 --> Helper loaded: form_helper
INFO - 2022-03-16 04:47:04 --> Helper loaded: common_helper
INFO - 2022-03-16 04:47:04 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:47:04 --> Controller Class Initialized
INFO - 2022-03-16 04:47:04 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:47:04 --> Encrypt Class Initialized
INFO - 2022-03-16 04:47:04 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:47:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:47:04 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:47:04 --> Model "Users_model" initialized
INFO - 2022-03-16 04:47:04 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:47:04 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-16 04:47:06 --> Final output sent to browser
DEBUG - 2022-03-16 04:47:06 --> Total execution time: 1.8104
ERROR - 2022-03-16 04:51:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:51:06 --> Config Class Initialized
INFO - 2022-03-16 04:51:06 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:51:06 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:51:06 --> Utf8 Class Initialized
INFO - 2022-03-16 04:51:06 --> URI Class Initialized
INFO - 2022-03-16 04:51:06 --> Router Class Initialized
INFO - 2022-03-16 04:51:06 --> Output Class Initialized
INFO - 2022-03-16 04:51:06 --> Security Class Initialized
DEBUG - 2022-03-16 04:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:51:06 --> Input Class Initialized
INFO - 2022-03-16 04:51:06 --> Language Class Initialized
INFO - 2022-03-16 04:51:06 --> Loader Class Initialized
INFO - 2022-03-16 04:51:06 --> Helper loaded: url_helper
INFO - 2022-03-16 04:51:06 --> Helper loaded: form_helper
INFO - 2022-03-16 04:51:06 --> Helper loaded: common_helper
INFO - 2022-03-16 04:51:06 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:51:06 --> Controller Class Initialized
INFO - 2022-03-16 04:51:06 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:51:06 --> Encrypt Class Initialized
INFO - 2022-03-16 04:51:06 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:51:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:51:06 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:51:06 --> Model "Users_model" initialized
INFO - 2022-03-16 04:51:06 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:51:06 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-16 04:51:07 --> Final output sent to browser
DEBUG - 2022-03-16 04:51:07 --> Total execution time: 1.1622
ERROR - 2022-03-16 04:54:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:54:43 --> Config Class Initialized
INFO - 2022-03-16 04:54:43 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:54:43 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:54:43 --> Utf8 Class Initialized
INFO - 2022-03-16 04:54:43 --> URI Class Initialized
INFO - 2022-03-16 04:54:43 --> Router Class Initialized
INFO - 2022-03-16 04:54:43 --> Output Class Initialized
INFO - 2022-03-16 04:54:43 --> Security Class Initialized
DEBUG - 2022-03-16 04:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:54:43 --> Input Class Initialized
INFO - 2022-03-16 04:54:43 --> Language Class Initialized
INFO - 2022-03-16 04:54:43 --> Loader Class Initialized
INFO - 2022-03-16 04:54:43 --> Helper loaded: url_helper
INFO - 2022-03-16 04:54:43 --> Helper loaded: form_helper
INFO - 2022-03-16 04:54:43 --> Helper loaded: common_helper
INFO - 2022-03-16 04:54:43 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:54:43 --> Controller Class Initialized
INFO - 2022-03-16 04:54:43 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:54:43 --> Encrypt Class Initialized
INFO - 2022-03-16 04:54:43 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:54:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:54:43 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:54:43 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:54:43 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:54:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:54:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:54:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:54:43 --> Final output sent to browser
DEBUG - 2022-03-16 04:54:43 --> Total execution time: 0.0523
ERROR - 2022-03-16 04:54:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:54:59 --> Config Class Initialized
INFO - 2022-03-16 04:54:59 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:54:59 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:54:59 --> Utf8 Class Initialized
INFO - 2022-03-16 04:54:59 --> URI Class Initialized
INFO - 2022-03-16 04:54:59 --> Router Class Initialized
INFO - 2022-03-16 04:54:59 --> Output Class Initialized
INFO - 2022-03-16 04:54:59 --> Security Class Initialized
DEBUG - 2022-03-16 04:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:54:59 --> Input Class Initialized
INFO - 2022-03-16 04:54:59 --> Language Class Initialized
INFO - 2022-03-16 04:54:59 --> Loader Class Initialized
INFO - 2022-03-16 04:54:59 --> Helper loaded: url_helper
INFO - 2022-03-16 04:54:59 --> Helper loaded: form_helper
INFO - 2022-03-16 04:54:59 --> Helper loaded: common_helper
INFO - 2022-03-16 04:54:59 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:54:59 --> Controller Class Initialized
INFO - 2022-03-16 04:54:59 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:54:59 --> Encrypt Class Initialized
INFO - 2022-03-16 04:54:59 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:54:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:54:59 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:54:59 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:54:59 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:54:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:54:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 04:54:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:54:59 --> Final output sent to browser
DEBUG - 2022-03-16 04:54:59 --> Total execution time: 0.1167
ERROR - 2022-03-16 04:55:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:55:09 --> Config Class Initialized
INFO - 2022-03-16 04:55:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:55:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:55:09 --> Utf8 Class Initialized
INFO - 2022-03-16 04:55:09 --> URI Class Initialized
INFO - 2022-03-16 04:55:09 --> Router Class Initialized
INFO - 2022-03-16 04:55:09 --> Output Class Initialized
INFO - 2022-03-16 04:55:09 --> Security Class Initialized
DEBUG - 2022-03-16 04:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:55:09 --> Input Class Initialized
INFO - 2022-03-16 04:55:09 --> Language Class Initialized
INFO - 2022-03-16 04:55:09 --> Loader Class Initialized
INFO - 2022-03-16 04:55:09 --> Helper loaded: url_helper
INFO - 2022-03-16 04:55:09 --> Helper loaded: form_helper
INFO - 2022-03-16 04:55:09 --> Helper loaded: common_helper
INFO - 2022-03-16 04:55:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:55:09 --> Controller Class Initialized
INFO - 2022-03-16 04:55:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:55:09 --> Encrypt Class Initialized
INFO - 2022-03-16 04:55:09 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:55:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:55:09 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:55:09 --> Model "Users_model" initialized
INFO - 2022-03-16 04:55:09 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:55:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:55:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:55:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:55:09 --> Final output sent to browser
DEBUG - 2022-03-16 04:55:09 --> Total execution time: 0.1364
ERROR - 2022-03-16 04:55:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:55:17 --> Config Class Initialized
INFO - 2022-03-16 04:55:17 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:55:17 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:55:17 --> Utf8 Class Initialized
INFO - 2022-03-16 04:55:17 --> URI Class Initialized
INFO - 2022-03-16 04:55:17 --> Router Class Initialized
INFO - 2022-03-16 04:55:17 --> Output Class Initialized
INFO - 2022-03-16 04:55:17 --> Security Class Initialized
DEBUG - 2022-03-16 04:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:55:17 --> Input Class Initialized
INFO - 2022-03-16 04:55:17 --> Language Class Initialized
INFO - 2022-03-16 04:55:17 --> Loader Class Initialized
INFO - 2022-03-16 04:55:17 --> Helper loaded: url_helper
INFO - 2022-03-16 04:55:17 --> Helper loaded: form_helper
INFO - 2022-03-16 04:55:17 --> Helper loaded: common_helper
INFO - 2022-03-16 04:55:17 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:55:17 --> Controller Class Initialized
INFO - 2022-03-16 04:55:17 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:55:17 --> Encrypt Class Initialized
INFO - 2022-03-16 04:55:17 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:55:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:55:17 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:55:17 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:55:17 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:55:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:55:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:55:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:55:17 --> Final output sent to browser
DEBUG - 2022-03-16 04:55:17 --> Total execution time: 0.0541
ERROR - 2022-03-16 04:55:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:55:55 --> Config Class Initialized
INFO - 2022-03-16 04:55:55 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:55:55 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:55:55 --> Utf8 Class Initialized
INFO - 2022-03-16 04:55:55 --> URI Class Initialized
INFO - 2022-03-16 04:55:55 --> Router Class Initialized
INFO - 2022-03-16 04:55:55 --> Output Class Initialized
INFO - 2022-03-16 04:55:55 --> Security Class Initialized
DEBUG - 2022-03-16 04:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:55:55 --> Input Class Initialized
INFO - 2022-03-16 04:55:55 --> Language Class Initialized
INFO - 2022-03-16 04:55:55 --> Loader Class Initialized
INFO - 2022-03-16 04:55:55 --> Helper loaded: url_helper
INFO - 2022-03-16 04:55:55 --> Helper loaded: form_helper
INFO - 2022-03-16 04:55:55 --> Helper loaded: common_helper
INFO - 2022-03-16 04:55:55 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:55:55 --> Controller Class Initialized
INFO - 2022-03-16 04:55:55 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:55:55 --> Encrypt Class Initialized
INFO - 2022-03-16 04:55:55 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:55:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:55:55 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:55:55 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:55:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 04:55:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:55:56 --> Config Class Initialized
INFO - 2022-03-16 04:55:56 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:55:56 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:55:56 --> Utf8 Class Initialized
INFO - 2022-03-16 04:55:56 --> URI Class Initialized
INFO - 2022-03-16 04:55:56 --> Router Class Initialized
INFO - 2022-03-16 04:55:56 --> Output Class Initialized
INFO - 2022-03-16 04:55:56 --> Security Class Initialized
DEBUG - 2022-03-16 04:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:55:56 --> Input Class Initialized
INFO - 2022-03-16 04:55:56 --> Language Class Initialized
INFO - 2022-03-16 04:55:56 --> Loader Class Initialized
INFO - 2022-03-16 04:55:56 --> Helper loaded: url_helper
INFO - 2022-03-16 04:55:56 --> Helper loaded: form_helper
INFO - 2022-03-16 04:55:56 --> Helper loaded: common_helper
INFO - 2022-03-16 04:55:56 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:55:56 --> Controller Class Initialized
INFO - 2022-03-16 04:55:56 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:55:56 --> Encrypt Class Initialized
INFO - 2022-03-16 04:55:56 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:55:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:55:56 --> Model "Referredby_model" initialized
INFO - 2022-03-16 04:55:56 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:55:56 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:55:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:55:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 04:55:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:55:57 --> Final output sent to browser
DEBUG - 2022-03-16 04:55:57 --> Total execution time: 0.0707
ERROR - 2022-03-16 04:55:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 04:55:58 --> Config Class Initialized
INFO - 2022-03-16 04:55:58 --> Hooks Class Initialized
DEBUG - 2022-03-16 04:55:58 --> UTF-8 Support Enabled
INFO - 2022-03-16 04:55:58 --> Utf8 Class Initialized
INFO - 2022-03-16 04:55:58 --> URI Class Initialized
INFO - 2022-03-16 04:55:58 --> Router Class Initialized
INFO - 2022-03-16 04:55:58 --> Output Class Initialized
INFO - 2022-03-16 04:55:58 --> Security Class Initialized
DEBUG - 2022-03-16 04:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 04:55:58 --> Input Class Initialized
INFO - 2022-03-16 04:55:58 --> Language Class Initialized
INFO - 2022-03-16 04:55:58 --> Loader Class Initialized
INFO - 2022-03-16 04:55:58 --> Helper loaded: url_helper
INFO - 2022-03-16 04:55:58 --> Helper loaded: form_helper
INFO - 2022-03-16 04:55:58 --> Helper loaded: common_helper
INFO - 2022-03-16 04:55:58 --> Database Driver Class Initialized
DEBUG - 2022-03-16 04:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 04:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 04:55:58 --> Controller Class Initialized
INFO - 2022-03-16 04:55:58 --> Form Validation Class Initialized
DEBUG - 2022-03-16 04:55:58 --> Encrypt Class Initialized
INFO - 2022-03-16 04:55:58 --> Model "Patient_model" initialized
INFO - 2022-03-16 04:55:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 04:55:58 --> Model "Prefix_master" initialized
INFO - 2022-03-16 04:55:58 --> Model "Users_model" initialized
INFO - 2022-03-16 04:55:58 --> Model "Hospital_model" initialized
INFO - 2022-03-16 04:55:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 04:55:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 04:55:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 04:55:58 --> Final output sent to browser
DEBUG - 2022-03-16 04:55:58 --> Total execution time: 0.0634
ERROR - 2022-03-16 05:04:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:04:24 --> Config Class Initialized
INFO - 2022-03-16 05:04:24 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:04:24 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:04:24 --> Utf8 Class Initialized
INFO - 2022-03-16 05:04:24 --> URI Class Initialized
INFO - 2022-03-16 05:04:24 --> Router Class Initialized
INFO - 2022-03-16 05:04:24 --> Output Class Initialized
INFO - 2022-03-16 05:04:24 --> Security Class Initialized
DEBUG - 2022-03-16 05:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:04:24 --> Input Class Initialized
INFO - 2022-03-16 05:04:24 --> Language Class Initialized
INFO - 2022-03-16 05:04:24 --> Loader Class Initialized
INFO - 2022-03-16 05:04:24 --> Helper loaded: url_helper
INFO - 2022-03-16 05:04:24 --> Helper loaded: form_helper
INFO - 2022-03-16 05:04:24 --> Helper loaded: common_helper
INFO - 2022-03-16 05:04:24 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:04:24 --> Controller Class Initialized
INFO - 2022-03-16 05:04:24 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:04:24 --> Encrypt Class Initialized
INFO - 2022-03-16 05:04:24 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:04:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:04:24 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:04:24 --> Model "Users_model" initialized
INFO - 2022-03-16 05:04:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 05:04:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:04:24 --> Config Class Initialized
INFO - 2022-03-16 05:04:24 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:04:24 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:04:24 --> Utf8 Class Initialized
INFO - 2022-03-16 05:04:24 --> URI Class Initialized
INFO - 2022-03-16 05:04:24 --> Router Class Initialized
INFO - 2022-03-16 05:04:24 --> Output Class Initialized
INFO - 2022-03-16 05:04:24 --> Security Class Initialized
DEBUG - 2022-03-16 05:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:04:24 --> Input Class Initialized
INFO - 2022-03-16 05:04:24 --> Language Class Initialized
INFO - 2022-03-16 05:04:24 --> Loader Class Initialized
INFO - 2022-03-16 05:04:24 --> Helper loaded: url_helper
INFO - 2022-03-16 05:04:24 --> Helper loaded: form_helper
INFO - 2022-03-16 05:04:24 --> Helper loaded: common_helper
INFO - 2022-03-16 05:04:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:04:25 --> Controller Class Initialized
INFO - 2022-03-16 05:04:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:04:25 --> Encrypt Class Initialized
INFO - 2022-03-16 05:04:25 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:04:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:04:25 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:04:25 --> Model "Users_model" initialized
INFO - 2022-03-16 05:04:25 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:04:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:04:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 05:04:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:04:25 --> Final output sent to browser
DEBUG - 2022-03-16 05:04:25 --> Total execution time: 0.2553
ERROR - 2022-03-16 05:04:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:04:49 --> Config Class Initialized
INFO - 2022-03-16 05:04:49 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:04:49 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:04:49 --> Utf8 Class Initialized
INFO - 2022-03-16 05:04:49 --> URI Class Initialized
INFO - 2022-03-16 05:04:49 --> Router Class Initialized
INFO - 2022-03-16 05:04:49 --> Output Class Initialized
INFO - 2022-03-16 05:04:49 --> Security Class Initialized
DEBUG - 2022-03-16 05:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:04:49 --> Input Class Initialized
INFO - 2022-03-16 05:04:49 --> Language Class Initialized
INFO - 2022-03-16 05:04:49 --> Loader Class Initialized
INFO - 2022-03-16 05:04:49 --> Helper loaded: url_helper
INFO - 2022-03-16 05:04:49 --> Helper loaded: form_helper
INFO - 2022-03-16 05:04:49 --> Helper loaded: common_helper
INFO - 2022-03-16 05:04:49 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:04:49 --> Controller Class Initialized
INFO - 2022-03-16 05:04:49 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:04:49 --> Encrypt Class Initialized
INFO - 2022-03-16 05:04:49 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:04:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:04:49 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:04:49 --> Model "Users_model" initialized
INFO - 2022-03-16 05:04:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 05:04:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:04:50 --> Config Class Initialized
INFO - 2022-03-16 05:04:50 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:04:50 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:04:50 --> Utf8 Class Initialized
INFO - 2022-03-16 05:04:50 --> URI Class Initialized
INFO - 2022-03-16 05:04:50 --> Router Class Initialized
INFO - 2022-03-16 05:04:50 --> Output Class Initialized
INFO - 2022-03-16 05:04:50 --> Security Class Initialized
DEBUG - 2022-03-16 05:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:04:50 --> Input Class Initialized
INFO - 2022-03-16 05:04:50 --> Language Class Initialized
INFO - 2022-03-16 05:04:50 --> Loader Class Initialized
INFO - 2022-03-16 05:04:50 --> Helper loaded: url_helper
INFO - 2022-03-16 05:04:50 --> Helper loaded: form_helper
INFO - 2022-03-16 05:04:50 --> Helper loaded: common_helper
INFO - 2022-03-16 05:04:50 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:04:50 --> Controller Class Initialized
INFO - 2022-03-16 05:04:50 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:04:50 --> Encrypt Class Initialized
INFO - 2022-03-16 05:04:50 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:04:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:04:50 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:04:50 --> Model "Users_model" initialized
INFO - 2022-03-16 05:04:50 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:04:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:04:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 05:04:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:04:50 --> Final output sent to browser
DEBUG - 2022-03-16 05:04:50 --> Total execution time: 0.1023
ERROR - 2022-03-16 05:05:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:05:08 --> Config Class Initialized
INFO - 2022-03-16 05:05:08 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:05:08 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:05:08 --> Utf8 Class Initialized
INFO - 2022-03-16 05:05:08 --> URI Class Initialized
INFO - 2022-03-16 05:05:08 --> Router Class Initialized
INFO - 2022-03-16 05:05:08 --> Output Class Initialized
INFO - 2022-03-16 05:05:08 --> Security Class Initialized
DEBUG - 2022-03-16 05:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:05:08 --> Input Class Initialized
INFO - 2022-03-16 05:05:08 --> Language Class Initialized
INFO - 2022-03-16 05:05:08 --> Loader Class Initialized
INFO - 2022-03-16 05:05:08 --> Helper loaded: url_helper
INFO - 2022-03-16 05:05:08 --> Helper loaded: form_helper
INFO - 2022-03-16 05:05:08 --> Helper loaded: common_helper
INFO - 2022-03-16 05:05:08 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:05:08 --> Controller Class Initialized
INFO - 2022-03-16 05:05:08 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:05:08 --> Encrypt Class Initialized
INFO - 2022-03-16 05:05:08 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:05:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:05:08 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:05:08 --> Model "Users_model" initialized
INFO - 2022-03-16 05:05:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 05:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:05:09 --> Config Class Initialized
INFO - 2022-03-16 05:05:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:05:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:05:09 --> Utf8 Class Initialized
INFO - 2022-03-16 05:05:09 --> URI Class Initialized
INFO - 2022-03-16 05:05:09 --> Router Class Initialized
INFO - 2022-03-16 05:05:09 --> Output Class Initialized
INFO - 2022-03-16 05:05:09 --> Security Class Initialized
DEBUG - 2022-03-16 05:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:05:09 --> Input Class Initialized
INFO - 2022-03-16 05:05:09 --> Language Class Initialized
INFO - 2022-03-16 05:05:09 --> Loader Class Initialized
INFO - 2022-03-16 05:05:09 --> Helper loaded: url_helper
INFO - 2022-03-16 05:05:09 --> Helper loaded: form_helper
INFO - 2022-03-16 05:05:09 --> Helper loaded: common_helper
INFO - 2022-03-16 05:05:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:05:09 --> Controller Class Initialized
INFO - 2022-03-16 05:05:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:05:09 --> Encrypt Class Initialized
INFO - 2022-03-16 05:05:09 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:05:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:05:09 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:05:09 --> Model "Users_model" initialized
INFO - 2022-03-16 05:05:09 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:05:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:05:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 05:05:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:05:09 --> Final output sent to browser
DEBUG - 2022-03-16 05:05:09 --> Total execution time: 0.1600
ERROR - 2022-03-16 05:08:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:08:34 --> Config Class Initialized
INFO - 2022-03-16 05:08:34 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:08:34 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:08:34 --> Utf8 Class Initialized
INFO - 2022-03-16 05:08:34 --> URI Class Initialized
INFO - 2022-03-16 05:08:34 --> Router Class Initialized
INFO - 2022-03-16 05:08:34 --> Output Class Initialized
INFO - 2022-03-16 05:08:34 --> Security Class Initialized
DEBUG - 2022-03-16 05:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:08:34 --> Input Class Initialized
INFO - 2022-03-16 05:08:34 --> Language Class Initialized
INFO - 2022-03-16 05:08:34 --> Loader Class Initialized
INFO - 2022-03-16 05:08:34 --> Helper loaded: url_helper
INFO - 2022-03-16 05:08:34 --> Helper loaded: form_helper
INFO - 2022-03-16 05:08:34 --> Helper loaded: common_helper
INFO - 2022-03-16 05:08:34 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:08:34 --> Controller Class Initialized
INFO - 2022-03-16 05:08:34 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:08:34 --> Encrypt Class Initialized
INFO - 2022-03-16 05:08:34 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:08:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:08:34 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:08:34 --> Model "Users_model" initialized
INFO - 2022-03-16 05:08:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 05:08:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:08:36 --> Config Class Initialized
INFO - 2022-03-16 05:08:36 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:08:36 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:08:36 --> Utf8 Class Initialized
INFO - 2022-03-16 05:08:36 --> URI Class Initialized
INFO - 2022-03-16 05:08:36 --> Router Class Initialized
INFO - 2022-03-16 05:08:36 --> Output Class Initialized
INFO - 2022-03-16 05:08:36 --> Security Class Initialized
DEBUG - 2022-03-16 05:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:08:36 --> Input Class Initialized
INFO - 2022-03-16 05:08:36 --> Language Class Initialized
INFO - 2022-03-16 05:08:36 --> Loader Class Initialized
INFO - 2022-03-16 05:08:36 --> Helper loaded: url_helper
INFO - 2022-03-16 05:08:36 --> Helper loaded: form_helper
INFO - 2022-03-16 05:08:36 --> Helper loaded: common_helper
INFO - 2022-03-16 05:08:36 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:08:36 --> Controller Class Initialized
INFO - 2022-03-16 05:08:36 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:08:36 --> Encrypt Class Initialized
INFO - 2022-03-16 05:08:36 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:08:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:08:36 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:08:36 --> Model "Users_model" initialized
INFO - 2022-03-16 05:08:36 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:08:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:08:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 05:08:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:08:37 --> Final output sent to browser
DEBUG - 2022-03-16 05:08:37 --> Total execution time: 0.0857
ERROR - 2022-03-16 05:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:17:37 --> Config Class Initialized
INFO - 2022-03-16 05:17:37 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:17:37 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:17:37 --> Utf8 Class Initialized
INFO - 2022-03-16 05:17:37 --> URI Class Initialized
INFO - 2022-03-16 05:17:37 --> Router Class Initialized
INFO - 2022-03-16 05:17:37 --> Output Class Initialized
INFO - 2022-03-16 05:17:37 --> Security Class Initialized
DEBUG - 2022-03-16 05:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:17:37 --> Input Class Initialized
INFO - 2022-03-16 05:17:37 --> Language Class Initialized
INFO - 2022-03-16 05:17:37 --> Loader Class Initialized
INFO - 2022-03-16 05:17:37 --> Helper loaded: url_helper
INFO - 2022-03-16 05:17:37 --> Helper loaded: form_helper
INFO - 2022-03-16 05:17:37 --> Helper loaded: common_helper
INFO - 2022-03-16 05:17:37 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:17:37 --> Controller Class Initialized
INFO - 2022-03-16 05:17:37 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:17:37 --> Encrypt Class Initialized
INFO - 2022-03-16 05:17:37 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:17:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:17:37 --> Model "Referredby_model" initialized
INFO - 2022-03-16 05:17:37 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:17:37 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:17:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:17:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 05:17:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:17:37 --> Final output sent to browser
DEBUG - 2022-03-16 05:17:37 --> Total execution time: 0.0722
ERROR - 2022-03-16 05:40:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:40:07 --> Config Class Initialized
INFO - 2022-03-16 05:40:07 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:40:07 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:40:07 --> Utf8 Class Initialized
INFO - 2022-03-16 05:40:07 --> URI Class Initialized
DEBUG - 2022-03-16 05:40:07 --> No URI present. Default controller set.
INFO - 2022-03-16 05:40:07 --> Router Class Initialized
INFO - 2022-03-16 05:40:07 --> Output Class Initialized
INFO - 2022-03-16 05:40:07 --> Security Class Initialized
DEBUG - 2022-03-16 05:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:40:07 --> Input Class Initialized
INFO - 2022-03-16 05:40:07 --> Language Class Initialized
INFO - 2022-03-16 05:40:07 --> Loader Class Initialized
INFO - 2022-03-16 05:40:07 --> Helper loaded: url_helper
INFO - 2022-03-16 05:40:07 --> Helper loaded: form_helper
INFO - 2022-03-16 05:40:07 --> Helper loaded: common_helper
INFO - 2022-03-16 05:40:07 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:40:07 --> Controller Class Initialized
INFO - 2022-03-16 05:40:07 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:40:07 --> Encrypt Class Initialized
DEBUG - 2022-03-16 05:40:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 05:40:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 05:40:07 --> Email Class Initialized
INFO - 2022-03-16 05:40:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 05:40:07 --> Calendar Class Initialized
INFO - 2022-03-16 05:40:07 --> Model "Login_model" initialized
INFO - 2022-03-16 05:40:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 05:40:07 --> Final output sent to browser
DEBUG - 2022-03-16 05:40:07 --> Total execution time: 0.0392
ERROR - 2022-03-16 05:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:40:32 --> Config Class Initialized
INFO - 2022-03-16 05:40:32 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:40:32 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:40:32 --> Utf8 Class Initialized
INFO - 2022-03-16 05:40:32 --> URI Class Initialized
INFO - 2022-03-16 05:40:32 --> Router Class Initialized
INFO - 2022-03-16 05:40:32 --> Output Class Initialized
INFO - 2022-03-16 05:40:32 --> Security Class Initialized
DEBUG - 2022-03-16 05:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:40:32 --> Input Class Initialized
INFO - 2022-03-16 05:40:32 --> Language Class Initialized
INFO - 2022-03-16 05:40:32 --> Loader Class Initialized
INFO - 2022-03-16 05:40:32 --> Helper loaded: url_helper
INFO - 2022-03-16 05:40:32 --> Helper loaded: form_helper
INFO - 2022-03-16 05:40:32 --> Helper loaded: common_helper
INFO - 2022-03-16 05:40:32 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:40:32 --> Controller Class Initialized
INFO - 2022-03-16 05:40:32 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:40:32 --> Encrypt Class Initialized
DEBUG - 2022-03-16 05:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 05:40:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 05:40:32 --> Email Class Initialized
INFO - 2022-03-16 05:40:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 05:40:32 --> Calendar Class Initialized
INFO - 2022-03-16 05:40:32 --> Model "Login_model" initialized
INFO - 2022-03-16 05:40:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-16 05:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:40:32 --> Config Class Initialized
INFO - 2022-03-16 05:40:32 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:40:32 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:40:32 --> Utf8 Class Initialized
INFO - 2022-03-16 05:40:32 --> URI Class Initialized
INFO - 2022-03-16 05:40:32 --> Router Class Initialized
INFO - 2022-03-16 05:40:32 --> Output Class Initialized
INFO - 2022-03-16 05:40:32 --> Security Class Initialized
DEBUG - 2022-03-16 05:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:40:32 --> Input Class Initialized
INFO - 2022-03-16 05:40:32 --> Language Class Initialized
INFO - 2022-03-16 05:40:32 --> Loader Class Initialized
INFO - 2022-03-16 05:40:32 --> Helper loaded: url_helper
INFO - 2022-03-16 05:40:32 --> Helper loaded: form_helper
INFO - 2022-03-16 05:40:32 --> Helper loaded: common_helper
INFO - 2022-03-16 05:40:32 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:40:32 --> Controller Class Initialized
INFO - 2022-03-16 05:40:32 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:40:32 --> Encrypt Class Initialized
INFO - 2022-03-16 05:40:32 --> Model "Login_model" initialized
INFO - 2022-03-16 05:40:32 --> Model "Dashboard_model" initialized
INFO - 2022-03-16 05:40:32 --> Model "Case_model" initialized
INFO - 2022-03-16 05:40:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-16 05:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:40:56 --> Config Class Initialized
INFO - 2022-03-16 05:40:56 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:40:56 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:40:56 --> Utf8 Class Initialized
INFO - 2022-03-16 05:40:56 --> URI Class Initialized
INFO - 2022-03-16 05:40:56 --> Router Class Initialized
INFO - 2022-03-16 05:40:56 --> Output Class Initialized
INFO - 2022-03-16 05:40:56 --> Security Class Initialized
DEBUG - 2022-03-16 05:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:40:56 --> Input Class Initialized
INFO - 2022-03-16 05:40:56 --> Language Class Initialized
INFO - 2022-03-16 05:40:56 --> Loader Class Initialized
INFO - 2022-03-16 05:40:56 --> Helper loaded: url_helper
INFO - 2022-03-16 05:40:56 --> Helper loaded: form_helper
INFO - 2022-03-16 05:40:56 --> Helper loaded: common_helper
INFO - 2022-03-16 05:40:56 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:40:57 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-16 05:40:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:40:57 --> Final output sent to browser
DEBUG - 2022-03-16 05:40:57 --> Total execution time: 24.2147
INFO - 2022-03-16 05:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:40:57 --> Controller Class Initialized
INFO - 2022-03-16 05:40:57 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:40:57 --> Encrypt Class Initialized
DEBUG - 2022-03-16 05:40:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 05:40:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 05:40:57 --> Email Class Initialized
INFO - 2022-03-16 05:40:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 05:40:57 --> Calendar Class Initialized
INFO - 2022-03-16 05:40:57 --> Model "Login_model" initialized
INFO - 2022-03-16 05:40:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-16 05:40:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:40:57 --> Config Class Initialized
INFO - 2022-03-16 05:40:57 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:40:57 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:40:57 --> Utf8 Class Initialized
INFO - 2022-03-16 05:40:57 --> URI Class Initialized
INFO - 2022-03-16 05:40:57 --> Router Class Initialized
INFO - 2022-03-16 05:40:57 --> Output Class Initialized
INFO - 2022-03-16 05:40:57 --> Security Class Initialized
DEBUG - 2022-03-16 05:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:40:57 --> Input Class Initialized
INFO - 2022-03-16 05:40:57 --> Language Class Initialized
INFO - 2022-03-16 05:40:57 --> Loader Class Initialized
INFO - 2022-03-16 05:40:57 --> Helper loaded: url_helper
INFO - 2022-03-16 05:40:57 --> Helper loaded: form_helper
INFO - 2022-03-16 05:40:57 --> Helper loaded: common_helper
INFO - 2022-03-16 05:40:57 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:40:57 --> Controller Class Initialized
INFO - 2022-03-16 05:40:57 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:40:57 --> Encrypt Class Initialized
INFO - 2022-03-16 05:40:57 --> Model "Login_model" initialized
INFO - 2022-03-16 05:40:57 --> Model "Dashboard_model" initialized
INFO - 2022-03-16 05:40:57 --> Model "Case_model" initialized
ERROR - 2022-03-16 05:40:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:40:58 --> Config Class Initialized
INFO - 2022-03-16 05:40:58 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:40:58 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:40:58 --> Utf8 Class Initialized
INFO - 2022-03-16 05:40:58 --> URI Class Initialized
INFO - 2022-03-16 05:40:58 --> Router Class Initialized
INFO - 2022-03-16 05:40:58 --> Output Class Initialized
INFO - 2022-03-16 05:40:58 --> Security Class Initialized
DEBUG - 2022-03-16 05:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:40:58 --> Input Class Initialized
INFO - 2022-03-16 05:40:58 --> Language Class Initialized
INFO - 2022-03-16 05:40:58 --> Loader Class Initialized
INFO - 2022-03-16 05:40:58 --> Helper loaded: url_helper
INFO - 2022-03-16 05:40:58 --> Helper loaded: form_helper
INFO - 2022-03-16 05:40:58 --> Helper loaded: common_helper
INFO - 2022-03-16 05:40:58 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:41:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:41:23 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-16 05:41:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:41:23 --> Final output sent to browser
DEBUG - 2022-03-16 05:41:23 --> Total execution time: 25.7213
INFO - 2022-03-16 05:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:41:23 --> Controller Class Initialized
INFO - 2022-03-16 05:41:23 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:41:23 --> Encrypt Class Initialized
DEBUG - 2022-03-16 05:41:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 05:41:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 05:41:23 --> Email Class Initialized
INFO - 2022-03-16 05:41:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 05:41:23 --> Calendar Class Initialized
INFO - 2022-03-16 05:41:23 --> Model "Login_model" initialized
INFO - 2022-03-16 05:41:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-16 05:41:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:41:24 --> Config Class Initialized
INFO - 2022-03-16 05:41:24 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:41:24 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:41:24 --> Utf8 Class Initialized
INFO - 2022-03-16 05:41:24 --> URI Class Initialized
INFO - 2022-03-16 05:41:24 --> Router Class Initialized
INFO - 2022-03-16 05:41:24 --> Output Class Initialized
INFO - 2022-03-16 05:41:24 --> Security Class Initialized
DEBUG - 2022-03-16 05:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:41:24 --> Input Class Initialized
INFO - 2022-03-16 05:41:24 --> Language Class Initialized
INFO - 2022-03-16 05:41:24 --> Loader Class Initialized
INFO - 2022-03-16 05:41:24 --> Helper loaded: url_helper
INFO - 2022-03-16 05:41:24 --> Helper loaded: form_helper
INFO - 2022-03-16 05:41:24 --> Helper loaded: common_helper
INFO - 2022-03-16 05:41:24 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:41:24 --> Controller Class Initialized
INFO - 2022-03-16 05:41:24 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:41:24 --> Encrypt Class Initialized
INFO - 2022-03-16 05:41:24 --> Model "Login_model" initialized
INFO - 2022-03-16 05:41:24 --> Model "Dashboard_model" initialized
INFO - 2022-03-16 05:41:24 --> Model "Case_model" initialized
INFO - 2022-03-16 05:41:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:41:53 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-16 05:41:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:41:53 --> Final output sent to browser
DEBUG - 2022-03-16 05:41:53 --> Total execution time: 29.7187
ERROR - 2022-03-16 05:41:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:41:55 --> Config Class Initialized
INFO - 2022-03-16 05:41:55 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:41:55 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:41:55 --> Utf8 Class Initialized
INFO - 2022-03-16 05:41:55 --> URI Class Initialized
INFO - 2022-03-16 05:41:55 --> Router Class Initialized
INFO - 2022-03-16 05:41:55 --> Output Class Initialized
INFO - 2022-03-16 05:41:55 --> Security Class Initialized
DEBUG - 2022-03-16 05:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:41:55 --> Input Class Initialized
INFO - 2022-03-16 05:41:55 --> Language Class Initialized
ERROR - 2022-03-16 05:41:55 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 05:42:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:42:49 --> Config Class Initialized
INFO - 2022-03-16 05:42:49 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:42:49 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:42:49 --> Utf8 Class Initialized
INFO - 2022-03-16 05:42:49 --> URI Class Initialized
INFO - 2022-03-16 05:42:49 --> Router Class Initialized
INFO - 2022-03-16 05:42:49 --> Output Class Initialized
INFO - 2022-03-16 05:42:49 --> Security Class Initialized
DEBUG - 2022-03-16 05:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:42:49 --> Input Class Initialized
INFO - 2022-03-16 05:42:49 --> Language Class Initialized
INFO - 2022-03-16 05:42:49 --> Loader Class Initialized
INFO - 2022-03-16 05:42:49 --> Helper loaded: url_helper
INFO - 2022-03-16 05:42:49 --> Helper loaded: form_helper
INFO - 2022-03-16 05:42:49 --> Helper loaded: common_helper
INFO - 2022-03-16 05:42:49 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:42:49 --> Controller Class Initialized
INFO - 2022-03-16 05:42:49 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:42:49 --> Encrypt Class Initialized
INFO - 2022-03-16 05:42:49 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:42:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:42:49 --> Model "Referredby_model" initialized
INFO - 2022-03-16 05:42:49 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:42:49 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:42:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:43:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 05:43:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-16 05:43:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:43:01 --> Config Class Initialized
INFO - 2022-03-16 05:43:01 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:43:01 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:43:01 --> Utf8 Class Initialized
INFO - 2022-03-16 05:43:01 --> URI Class Initialized
INFO - 2022-03-16 05:43:01 --> Router Class Initialized
INFO - 2022-03-16 05:43:01 --> Output Class Initialized
INFO - 2022-03-16 05:43:01 --> Security Class Initialized
DEBUG - 2022-03-16 05:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:43:01 --> Input Class Initialized
INFO - 2022-03-16 05:43:01 --> Language Class Initialized
ERROR - 2022-03-16 05:43:01 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-16 05:43:02 --> Final output sent to browser
DEBUG - 2022-03-16 05:43:02 --> Total execution time: 10.9664
ERROR - 2022-03-16 05:43:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:43:45 --> Config Class Initialized
INFO - 2022-03-16 05:43:45 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:43:45 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:43:45 --> Utf8 Class Initialized
INFO - 2022-03-16 05:43:45 --> URI Class Initialized
INFO - 2022-03-16 05:43:45 --> Router Class Initialized
INFO - 2022-03-16 05:43:45 --> Output Class Initialized
INFO - 2022-03-16 05:43:45 --> Security Class Initialized
DEBUG - 2022-03-16 05:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:43:45 --> Input Class Initialized
INFO - 2022-03-16 05:43:45 --> Language Class Initialized
INFO - 2022-03-16 05:43:45 --> Loader Class Initialized
INFO - 2022-03-16 05:43:45 --> Helper loaded: url_helper
INFO - 2022-03-16 05:43:45 --> Helper loaded: form_helper
INFO - 2022-03-16 05:43:45 --> Helper loaded: common_helper
INFO - 2022-03-16 05:43:45 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:43:45 --> Controller Class Initialized
INFO - 2022-03-16 05:43:45 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:43:45 --> Encrypt Class Initialized
INFO - 2022-03-16 05:43:45 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:43:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:43:45 --> Model "Referredby_model" initialized
INFO - 2022-03-16 05:43:45 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:43:45 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:43:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:43:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 05:43:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:43:45 --> Final output sent to browser
DEBUG - 2022-03-16 05:43:45 --> Total execution time: 0.0704
ERROR - 2022-03-16 05:43:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:43:45 --> Config Class Initialized
INFO - 2022-03-16 05:43:45 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:43:45 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:43:45 --> Utf8 Class Initialized
INFO - 2022-03-16 05:43:45 --> URI Class Initialized
INFO - 2022-03-16 05:43:45 --> Router Class Initialized
INFO - 2022-03-16 05:43:45 --> Output Class Initialized
INFO - 2022-03-16 05:43:45 --> Security Class Initialized
DEBUG - 2022-03-16 05:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:43:45 --> Input Class Initialized
INFO - 2022-03-16 05:43:45 --> Language Class Initialized
ERROR - 2022-03-16 05:43:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 05:48:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:48:29 --> Config Class Initialized
INFO - 2022-03-16 05:48:29 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:48:29 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:48:29 --> Utf8 Class Initialized
INFO - 2022-03-16 05:48:29 --> URI Class Initialized
INFO - 2022-03-16 05:48:29 --> Router Class Initialized
INFO - 2022-03-16 05:48:29 --> Output Class Initialized
INFO - 2022-03-16 05:48:29 --> Security Class Initialized
DEBUG - 2022-03-16 05:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:48:29 --> Input Class Initialized
INFO - 2022-03-16 05:48:29 --> Language Class Initialized
INFO - 2022-03-16 05:48:29 --> Loader Class Initialized
INFO - 2022-03-16 05:48:29 --> Helper loaded: url_helper
INFO - 2022-03-16 05:48:29 --> Helper loaded: form_helper
INFO - 2022-03-16 05:48:29 --> Helper loaded: common_helper
INFO - 2022-03-16 05:48:29 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:48:29 --> Controller Class Initialized
INFO - 2022-03-16 05:48:29 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:48:29 --> Encrypt Class Initialized
INFO - 2022-03-16 05:48:29 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:48:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:48:29 --> Model "Referredby_model" initialized
INFO - 2022-03-16 05:48:29 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:48:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 05:48:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:48:30 --> Config Class Initialized
INFO - 2022-03-16 05:48:30 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:48:30 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:48:30 --> Utf8 Class Initialized
INFO - 2022-03-16 05:48:30 --> URI Class Initialized
INFO - 2022-03-16 05:48:30 --> Router Class Initialized
INFO - 2022-03-16 05:48:30 --> Output Class Initialized
INFO - 2022-03-16 05:48:30 --> Security Class Initialized
DEBUG - 2022-03-16 05:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:48:30 --> Input Class Initialized
INFO - 2022-03-16 05:48:30 --> Language Class Initialized
INFO - 2022-03-16 05:48:30 --> Loader Class Initialized
INFO - 2022-03-16 05:48:30 --> Helper loaded: url_helper
INFO - 2022-03-16 05:48:30 --> Helper loaded: form_helper
INFO - 2022-03-16 05:48:30 --> Helper loaded: common_helper
INFO - 2022-03-16 05:48:30 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:48:30 --> Controller Class Initialized
INFO - 2022-03-16 05:48:30 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:48:30 --> Encrypt Class Initialized
INFO - 2022-03-16 05:48:30 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:48:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:48:30 --> Model "Referredby_model" initialized
INFO - 2022-03-16 05:48:30 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:48:30 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:48:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:48:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 05:48:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:48:30 --> Final output sent to browser
DEBUG - 2022-03-16 05:48:30 --> Total execution time: 0.0672
ERROR - 2022-03-16 05:48:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:48:30 --> Config Class Initialized
INFO - 2022-03-16 05:48:30 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:48:30 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:48:30 --> Utf8 Class Initialized
INFO - 2022-03-16 05:48:30 --> URI Class Initialized
INFO - 2022-03-16 05:48:30 --> Router Class Initialized
INFO - 2022-03-16 05:48:30 --> Output Class Initialized
INFO - 2022-03-16 05:48:30 --> Security Class Initialized
DEBUG - 2022-03-16 05:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:48:30 --> Input Class Initialized
INFO - 2022-03-16 05:48:30 --> Language Class Initialized
ERROR - 2022-03-16 05:48:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 05:48:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:48:31 --> Config Class Initialized
INFO - 2022-03-16 05:48:31 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:48:31 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:48:31 --> Utf8 Class Initialized
INFO - 2022-03-16 05:48:31 --> URI Class Initialized
INFO - 2022-03-16 05:48:31 --> Router Class Initialized
INFO - 2022-03-16 05:48:31 --> Output Class Initialized
INFO - 2022-03-16 05:48:31 --> Security Class Initialized
DEBUG - 2022-03-16 05:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:48:31 --> Input Class Initialized
INFO - 2022-03-16 05:48:31 --> Language Class Initialized
INFO - 2022-03-16 05:48:31 --> Loader Class Initialized
INFO - 2022-03-16 05:48:31 --> Helper loaded: url_helper
INFO - 2022-03-16 05:48:31 --> Helper loaded: form_helper
INFO - 2022-03-16 05:48:31 --> Helper loaded: common_helper
INFO - 2022-03-16 05:48:31 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:48:31 --> Controller Class Initialized
INFO - 2022-03-16 05:48:31 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:48:31 --> Encrypt Class Initialized
INFO - 2022-03-16 05:48:31 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:48:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:48:31 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:48:31 --> Model "Users_model" initialized
INFO - 2022-03-16 05:48:31 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:48:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:48:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 05:48:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:48:31 --> Final output sent to browser
DEBUG - 2022-03-16 05:48:31 --> Total execution time: 0.0675
ERROR - 2022-03-16 05:48:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:48:31 --> Config Class Initialized
INFO - 2022-03-16 05:48:31 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:48:31 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:48:31 --> Utf8 Class Initialized
INFO - 2022-03-16 05:48:31 --> URI Class Initialized
INFO - 2022-03-16 05:48:31 --> Router Class Initialized
INFO - 2022-03-16 05:48:31 --> Output Class Initialized
INFO - 2022-03-16 05:48:31 --> Security Class Initialized
DEBUG - 2022-03-16 05:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:48:31 --> Input Class Initialized
INFO - 2022-03-16 05:48:31 --> Language Class Initialized
ERROR - 2022-03-16 05:48:31 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 05:49:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:49:46 --> Config Class Initialized
INFO - 2022-03-16 05:49:46 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:49:46 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:49:46 --> Utf8 Class Initialized
INFO - 2022-03-16 05:49:46 --> URI Class Initialized
INFO - 2022-03-16 05:49:46 --> Router Class Initialized
INFO - 2022-03-16 05:49:46 --> Output Class Initialized
INFO - 2022-03-16 05:49:46 --> Security Class Initialized
DEBUG - 2022-03-16 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:49:46 --> Input Class Initialized
INFO - 2022-03-16 05:49:46 --> Language Class Initialized
INFO - 2022-03-16 05:49:46 --> Loader Class Initialized
INFO - 2022-03-16 05:49:46 --> Helper loaded: url_helper
INFO - 2022-03-16 05:49:46 --> Helper loaded: form_helper
INFO - 2022-03-16 05:49:46 --> Helper loaded: common_helper
INFO - 2022-03-16 05:49:46 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:49:46 --> Controller Class Initialized
INFO - 2022-03-16 05:49:46 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:49:46 --> Encrypt Class Initialized
INFO - 2022-03-16 05:49:46 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:49:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:49:46 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:49:46 --> Model "Users_model" initialized
INFO - 2022-03-16 05:49:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 05:49:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:49:46 --> Config Class Initialized
INFO - 2022-03-16 05:49:46 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:49:46 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:49:46 --> Utf8 Class Initialized
INFO - 2022-03-16 05:49:46 --> URI Class Initialized
INFO - 2022-03-16 05:49:46 --> Router Class Initialized
INFO - 2022-03-16 05:49:46 --> Output Class Initialized
INFO - 2022-03-16 05:49:46 --> Security Class Initialized
DEBUG - 2022-03-16 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:49:46 --> Input Class Initialized
INFO - 2022-03-16 05:49:46 --> Language Class Initialized
INFO - 2022-03-16 05:49:46 --> Loader Class Initialized
INFO - 2022-03-16 05:49:46 --> Helper loaded: url_helper
INFO - 2022-03-16 05:49:46 --> Helper loaded: form_helper
INFO - 2022-03-16 05:49:46 --> Helper loaded: common_helper
INFO - 2022-03-16 05:49:46 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:49:46 --> Controller Class Initialized
INFO - 2022-03-16 05:49:46 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:49:46 --> Encrypt Class Initialized
INFO - 2022-03-16 05:49:46 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:49:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:49:46 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:49:46 --> Model "Users_model" initialized
INFO - 2022-03-16 05:49:46 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:49:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:49:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 05:49:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:49:47 --> Final output sent to browser
DEBUG - 2022-03-16 05:49:47 --> Total execution time: 0.0989
ERROR - 2022-03-16 05:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:49:47 --> Config Class Initialized
INFO - 2022-03-16 05:49:47 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:49:47 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:49:47 --> Utf8 Class Initialized
INFO - 2022-03-16 05:49:47 --> URI Class Initialized
INFO - 2022-03-16 05:49:47 --> Router Class Initialized
INFO - 2022-03-16 05:49:47 --> Output Class Initialized
INFO - 2022-03-16 05:49:47 --> Security Class Initialized
DEBUG - 2022-03-16 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:49:47 --> Input Class Initialized
INFO - 2022-03-16 05:49:47 --> Language Class Initialized
ERROR - 2022-03-16 05:49:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 05:50:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:50:12 --> Config Class Initialized
INFO - 2022-03-16 05:50:12 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:50:12 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:50:12 --> Utf8 Class Initialized
INFO - 2022-03-16 05:50:12 --> URI Class Initialized
INFO - 2022-03-16 05:50:12 --> Router Class Initialized
INFO - 2022-03-16 05:50:12 --> Output Class Initialized
INFO - 2022-03-16 05:50:12 --> Security Class Initialized
DEBUG - 2022-03-16 05:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:50:12 --> Input Class Initialized
INFO - 2022-03-16 05:50:12 --> Language Class Initialized
INFO - 2022-03-16 05:50:12 --> Loader Class Initialized
INFO - 2022-03-16 05:50:12 --> Helper loaded: url_helper
INFO - 2022-03-16 05:50:12 --> Helper loaded: form_helper
INFO - 2022-03-16 05:50:12 --> Helper loaded: common_helper
INFO - 2022-03-16 05:50:12 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:50:12 --> Controller Class Initialized
INFO - 2022-03-16 05:50:12 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:50:12 --> Encrypt Class Initialized
INFO - 2022-03-16 05:50:12 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:50:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:50:12 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:50:12 --> Model "Users_model" initialized
INFO - 2022-03-16 05:50:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 05:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:50:13 --> Config Class Initialized
INFO - 2022-03-16 05:50:13 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:50:13 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:50:13 --> Utf8 Class Initialized
INFO - 2022-03-16 05:50:13 --> URI Class Initialized
INFO - 2022-03-16 05:50:13 --> Router Class Initialized
INFO - 2022-03-16 05:50:13 --> Output Class Initialized
INFO - 2022-03-16 05:50:13 --> Security Class Initialized
DEBUG - 2022-03-16 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:50:13 --> Input Class Initialized
INFO - 2022-03-16 05:50:13 --> Language Class Initialized
INFO - 2022-03-16 05:50:13 --> Loader Class Initialized
INFO - 2022-03-16 05:50:13 --> Helper loaded: url_helper
INFO - 2022-03-16 05:50:13 --> Helper loaded: form_helper
INFO - 2022-03-16 05:50:13 --> Helper loaded: common_helper
INFO - 2022-03-16 05:50:13 --> Database Driver Class Initialized
DEBUG - 2022-03-16 05:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 05:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 05:50:13 --> Controller Class Initialized
INFO - 2022-03-16 05:50:13 --> Form Validation Class Initialized
DEBUG - 2022-03-16 05:50:13 --> Encrypt Class Initialized
INFO - 2022-03-16 05:50:13 --> Model "Patient_model" initialized
INFO - 2022-03-16 05:50:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 05:50:13 --> Model "Prefix_master" initialized
INFO - 2022-03-16 05:50:13 --> Model "Users_model" initialized
INFO - 2022-03-16 05:50:13 --> Model "Hospital_model" initialized
INFO - 2022-03-16 05:50:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 05:50:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 05:50:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 05:50:13 --> Final output sent to browser
DEBUG - 2022-03-16 05:50:13 --> Total execution time: 0.1026
ERROR - 2022-03-16 05:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 05:50:14 --> Config Class Initialized
INFO - 2022-03-16 05:50:14 --> Hooks Class Initialized
DEBUG - 2022-03-16 05:50:14 --> UTF-8 Support Enabled
INFO - 2022-03-16 05:50:14 --> Utf8 Class Initialized
INFO - 2022-03-16 05:50:14 --> URI Class Initialized
INFO - 2022-03-16 05:50:14 --> Router Class Initialized
INFO - 2022-03-16 05:50:14 --> Output Class Initialized
INFO - 2022-03-16 05:50:14 --> Security Class Initialized
DEBUG - 2022-03-16 05:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 05:50:14 --> Input Class Initialized
INFO - 2022-03-16 05:50:14 --> Language Class Initialized
ERROR - 2022-03-16 05:50:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:02:41 --> Config Class Initialized
INFO - 2022-03-16 06:02:41 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:02:41 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:02:41 --> Utf8 Class Initialized
INFO - 2022-03-16 06:02:41 --> URI Class Initialized
INFO - 2022-03-16 06:02:41 --> Router Class Initialized
INFO - 2022-03-16 06:02:41 --> Output Class Initialized
INFO - 2022-03-16 06:02:41 --> Security Class Initialized
DEBUG - 2022-03-16 06:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:02:41 --> Input Class Initialized
INFO - 2022-03-16 06:02:41 --> Language Class Initialized
INFO - 2022-03-16 06:02:41 --> Loader Class Initialized
INFO - 2022-03-16 06:02:41 --> Helper loaded: url_helper
INFO - 2022-03-16 06:02:41 --> Helper loaded: form_helper
INFO - 2022-03-16 06:02:41 --> Helper loaded: common_helper
INFO - 2022-03-16 06:02:41 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:02:41 --> Controller Class Initialized
INFO - 2022-03-16 06:02:41 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:02:41 --> Encrypt Class Initialized
INFO - 2022-03-16 06:02:41 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:02:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:02:41 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:02:41 --> Model "Users_model" initialized
INFO - 2022-03-16 06:02:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:02:42 --> Config Class Initialized
INFO - 2022-03-16 06:02:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:02:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:02:42 --> Utf8 Class Initialized
INFO - 2022-03-16 06:02:42 --> URI Class Initialized
INFO - 2022-03-16 06:02:42 --> Router Class Initialized
INFO - 2022-03-16 06:02:42 --> Output Class Initialized
INFO - 2022-03-16 06:02:42 --> Security Class Initialized
DEBUG - 2022-03-16 06:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:02:42 --> Input Class Initialized
INFO - 2022-03-16 06:02:42 --> Language Class Initialized
INFO - 2022-03-16 06:02:42 --> Loader Class Initialized
INFO - 2022-03-16 06:02:42 --> Helper loaded: url_helper
INFO - 2022-03-16 06:02:42 --> Helper loaded: form_helper
INFO - 2022-03-16 06:02:42 --> Helper loaded: common_helper
INFO - 2022-03-16 06:02:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:02:42 --> Controller Class Initialized
INFO - 2022-03-16 06:02:42 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:02:42 --> Encrypt Class Initialized
INFO - 2022-03-16 06:02:42 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:02:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:02:42 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:02:42 --> Model "Users_model" initialized
INFO - 2022-03-16 06:02:42 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:02:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:02:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:02:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:02:42 --> Final output sent to browser
DEBUG - 2022-03-16 06:02:42 --> Total execution time: 0.0608
ERROR - 2022-03-16 06:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:02:43 --> Config Class Initialized
INFO - 2022-03-16 06:02:43 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:02:43 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:02:43 --> Utf8 Class Initialized
INFO - 2022-03-16 06:02:43 --> URI Class Initialized
INFO - 2022-03-16 06:02:43 --> Router Class Initialized
INFO - 2022-03-16 06:02:43 --> Output Class Initialized
INFO - 2022-03-16 06:02:43 --> Security Class Initialized
DEBUG - 2022-03-16 06:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:02:43 --> Input Class Initialized
INFO - 2022-03-16 06:02:43 --> Language Class Initialized
ERROR - 2022-03-16 06:02:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:02:50 --> Config Class Initialized
INFO - 2022-03-16 06:02:50 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:02:50 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:02:50 --> Utf8 Class Initialized
INFO - 2022-03-16 06:02:50 --> URI Class Initialized
INFO - 2022-03-16 06:02:50 --> Router Class Initialized
INFO - 2022-03-16 06:02:50 --> Output Class Initialized
INFO - 2022-03-16 06:02:50 --> Security Class Initialized
DEBUG - 2022-03-16 06:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:02:50 --> Input Class Initialized
INFO - 2022-03-16 06:02:50 --> Language Class Initialized
INFO - 2022-03-16 06:02:50 --> Loader Class Initialized
INFO - 2022-03-16 06:02:50 --> Helper loaded: url_helper
INFO - 2022-03-16 06:02:50 --> Helper loaded: form_helper
INFO - 2022-03-16 06:02:50 --> Helper loaded: common_helper
INFO - 2022-03-16 06:02:50 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:02:50 --> Controller Class Initialized
INFO - 2022-03-16 06:02:50 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:02:50 --> Encrypt Class Initialized
INFO - 2022-03-16 06:02:50 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:02:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:02:50 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:02:50 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:02:50 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:02:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:02:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 06:02:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-16 06:03:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:03:01 --> Config Class Initialized
INFO - 2022-03-16 06:03:01 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:03:01 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:03:01 --> Utf8 Class Initialized
INFO - 2022-03-16 06:03:01 --> URI Class Initialized
INFO - 2022-03-16 06:03:01 --> Router Class Initialized
INFO - 2022-03-16 06:03:01 --> Output Class Initialized
INFO - 2022-03-16 06:03:01 --> Security Class Initialized
DEBUG - 2022-03-16 06:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:03:01 --> Input Class Initialized
INFO - 2022-03-16 06:03:01 --> Language Class Initialized
ERROR - 2022-03-16 06:03:01 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-16 06:03:01 --> Final output sent to browser
DEBUG - 2022-03-16 06:03:01 --> Total execution time: 9.2736
ERROR - 2022-03-16 06:03:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:03:32 --> Config Class Initialized
INFO - 2022-03-16 06:03:32 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:03:32 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:03:32 --> Utf8 Class Initialized
INFO - 2022-03-16 06:03:32 --> URI Class Initialized
INFO - 2022-03-16 06:03:32 --> Router Class Initialized
INFO - 2022-03-16 06:03:32 --> Output Class Initialized
INFO - 2022-03-16 06:03:32 --> Security Class Initialized
DEBUG - 2022-03-16 06:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:03:32 --> Input Class Initialized
INFO - 2022-03-16 06:03:32 --> Language Class Initialized
INFO - 2022-03-16 06:03:32 --> Loader Class Initialized
INFO - 2022-03-16 06:03:32 --> Helper loaded: url_helper
INFO - 2022-03-16 06:03:32 --> Helper loaded: form_helper
INFO - 2022-03-16 06:03:32 --> Helper loaded: common_helper
INFO - 2022-03-16 06:03:32 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:03:32 --> Controller Class Initialized
INFO - 2022-03-16 06:03:32 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:03:32 --> Encrypt Class Initialized
INFO - 2022-03-16 06:03:32 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:03:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:03:32 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:03:32 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:03:32 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:03:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:03:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 06:03:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-16 06:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:03:47 --> Config Class Initialized
INFO - 2022-03-16 06:03:47 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:03:47 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:03:47 --> Utf8 Class Initialized
INFO - 2022-03-16 06:03:47 --> URI Class Initialized
INFO - 2022-03-16 06:03:47 --> Router Class Initialized
INFO - 2022-03-16 06:03:47 --> Output Class Initialized
INFO - 2022-03-16 06:03:47 --> Security Class Initialized
DEBUG - 2022-03-16 06:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:03:47 --> Input Class Initialized
INFO - 2022-03-16 06:03:47 --> Language Class Initialized
ERROR - 2022-03-16 06:03:47 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-16 06:03:47 --> Final output sent to browser
DEBUG - 2022-03-16 06:03:47 --> Total execution time: 13.4748
ERROR - 2022-03-16 06:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:04:32 --> Config Class Initialized
INFO - 2022-03-16 06:04:32 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:04:32 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:04:32 --> Utf8 Class Initialized
INFO - 2022-03-16 06:04:32 --> URI Class Initialized
INFO - 2022-03-16 06:04:32 --> Router Class Initialized
INFO - 2022-03-16 06:04:32 --> Output Class Initialized
INFO - 2022-03-16 06:04:32 --> Security Class Initialized
DEBUG - 2022-03-16 06:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:04:32 --> Input Class Initialized
INFO - 2022-03-16 06:04:32 --> Language Class Initialized
INFO - 2022-03-16 06:04:32 --> Loader Class Initialized
INFO - 2022-03-16 06:04:32 --> Helper loaded: url_helper
INFO - 2022-03-16 06:04:32 --> Helper loaded: form_helper
INFO - 2022-03-16 06:04:32 --> Helper loaded: common_helper
INFO - 2022-03-16 06:04:32 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:04:32 --> Controller Class Initialized
INFO - 2022-03-16 06:04:32 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:04:32 --> Encrypt Class Initialized
INFO - 2022-03-16 06:04:32 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:04:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:04:32 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:04:32 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:04:32 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:04:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:04:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 06:04:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:04:32 --> Final output sent to browser
DEBUG - 2022-03-16 06:04:32 --> Total execution time: 0.0562
ERROR - 2022-03-16 06:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:04:32 --> Config Class Initialized
INFO - 2022-03-16 06:04:32 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:04:32 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:04:32 --> Utf8 Class Initialized
INFO - 2022-03-16 06:04:32 --> URI Class Initialized
INFO - 2022-03-16 06:04:32 --> Router Class Initialized
INFO - 2022-03-16 06:04:32 --> Output Class Initialized
INFO - 2022-03-16 06:04:32 --> Security Class Initialized
DEBUG - 2022-03-16 06:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:04:32 --> Input Class Initialized
INFO - 2022-03-16 06:04:32 --> Language Class Initialized
ERROR - 2022-03-16 06:04:32 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:07:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:07:15 --> Config Class Initialized
INFO - 2022-03-16 06:07:15 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:07:15 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:07:15 --> Utf8 Class Initialized
INFO - 2022-03-16 06:07:15 --> URI Class Initialized
INFO - 2022-03-16 06:07:15 --> Router Class Initialized
INFO - 2022-03-16 06:07:15 --> Output Class Initialized
INFO - 2022-03-16 06:07:15 --> Security Class Initialized
DEBUG - 2022-03-16 06:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:07:15 --> Input Class Initialized
INFO - 2022-03-16 06:07:15 --> Language Class Initialized
INFO - 2022-03-16 06:07:16 --> Loader Class Initialized
INFO - 2022-03-16 06:07:16 --> Helper loaded: url_helper
INFO - 2022-03-16 06:07:16 --> Helper loaded: form_helper
INFO - 2022-03-16 06:07:16 --> Helper loaded: common_helper
INFO - 2022-03-16 06:07:16 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:07:16 --> Controller Class Initialized
INFO - 2022-03-16 06:07:16 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:07:16 --> Final output sent to browser
DEBUG - 2022-03-16 06:07:16 --> Total execution time: 0.1020
ERROR - 2022-03-16 06:09:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:09:02 --> Config Class Initialized
INFO - 2022-03-16 06:09:02 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:09:02 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:09:02 --> Utf8 Class Initialized
INFO - 2022-03-16 06:09:02 --> URI Class Initialized
INFO - 2022-03-16 06:09:02 --> Router Class Initialized
INFO - 2022-03-16 06:09:02 --> Output Class Initialized
INFO - 2022-03-16 06:09:02 --> Security Class Initialized
DEBUG - 2022-03-16 06:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:09:02 --> Input Class Initialized
INFO - 2022-03-16 06:09:02 --> Language Class Initialized
INFO - 2022-03-16 06:09:02 --> Loader Class Initialized
INFO - 2022-03-16 06:09:02 --> Helper loaded: url_helper
INFO - 2022-03-16 06:09:02 --> Helper loaded: form_helper
INFO - 2022-03-16 06:09:02 --> Helper loaded: common_helper
INFO - 2022-03-16 06:09:02 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:09:02 --> Controller Class Initialized
INFO - 2022-03-16 06:09:02 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:09:02 --> Encrypt Class Initialized
INFO - 2022-03-16 06:09:02 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:09:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:09:02 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:09:02 --> Model "Users_model" initialized
INFO - 2022-03-16 06:09:02 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:09:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:09:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:09:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:09:02 --> Final output sent to browser
DEBUG - 2022-03-16 06:09:02 --> Total execution time: 0.0953
ERROR - 2022-03-16 06:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:09:07 --> Config Class Initialized
INFO - 2022-03-16 06:09:07 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:09:07 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:09:07 --> Utf8 Class Initialized
INFO - 2022-03-16 06:09:07 --> URI Class Initialized
INFO - 2022-03-16 06:09:07 --> Router Class Initialized
INFO - 2022-03-16 06:09:07 --> Output Class Initialized
INFO - 2022-03-16 06:09:07 --> Security Class Initialized
DEBUG - 2022-03-16 06:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:09:07 --> Input Class Initialized
INFO - 2022-03-16 06:09:07 --> Language Class Initialized
INFO - 2022-03-16 06:09:07 --> Loader Class Initialized
INFO - 2022-03-16 06:09:07 --> Helper loaded: url_helper
INFO - 2022-03-16 06:09:07 --> Helper loaded: form_helper
INFO - 2022-03-16 06:09:07 --> Helper loaded: common_helper
INFO - 2022-03-16 06:09:07 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:09:07 --> Controller Class Initialized
INFO - 2022-03-16 06:09:07 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:09:07 --> Encrypt Class Initialized
INFO - 2022-03-16 06:09:07 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:09:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:09:07 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:09:07 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:09:07 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:09:07 --> Final output sent to browser
DEBUG - 2022-03-16 06:09:07 --> Total execution time: 0.0628
ERROR - 2022-03-16 06:09:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:09:08 --> Config Class Initialized
INFO - 2022-03-16 06:09:08 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:09:08 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:09:08 --> Utf8 Class Initialized
INFO - 2022-03-16 06:09:08 --> URI Class Initialized
INFO - 2022-03-16 06:09:08 --> Router Class Initialized
INFO - 2022-03-16 06:09:08 --> Output Class Initialized
INFO - 2022-03-16 06:09:08 --> Security Class Initialized
DEBUG - 2022-03-16 06:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:09:08 --> Input Class Initialized
INFO - 2022-03-16 06:09:08 --> Language Class Initialized
INFO - 2022-03-16 06:09:08 --> Loader Class Initialized
INFO - 2022-03-16 06:09:08 --> Helper loaded: url_helper
INFO - 2022-03-16 06:09:08 --> Helper loaded: form_helper
INFO - 2022-03-16 06:09:08 --> Helper loaded: common_helper
INFO - 2022-03-16 06:09:08 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:09:08 --> Controller Class Initialized
INFO - 2022-03-16 06:09:08 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:09:08 --> Encrypt Class Initialized
INFO - 2022-03-16 06:09:08 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:09:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:09:08 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:09:08 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:09:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:09:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:09:08 --> Config Class Initialized
INFO - 2022-03-16 06:09:08 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:09:08 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:09:08 --> Utf8 Class Initialized
INFO - 2022-03-16 06:09:08 --> URI Class Initialized
INFO - 2022-03-16 06:09:09 --> Router Class Initialized
INFO - 2022-03-16 06:09:09 --> Output Class Initialized
INFO - 2022-03-16 06:09:09 --> Security Class Initialized
DEBUG - 2022-03-16 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:09:09 --> Input Class Initialized
INFO - 2022-03-16 06:09:09 --> Language Class Initialized
INFO - 2022-03-16 06:09:09 --> Loader Class Initialized
INFO - 2022-03-16 06:09:09 --> Helper loaded: url_helper
INFO - 2022-03-16 06:09:09 --> Helper loaded: form_helper
INFO - 2022-03-16 06:09:09 --> Helper loaded: common_helper
INFO - 2022-03-16 06:09:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:09:09 --> Controller Class Initialized
INFO - 2022-03-16 06:09:09 --> Form Validation Class Initialized
INFO - 2022-03-16 06:09:09 --> Model "Case_model" initialized
INFO - 2022-03-16 06:09:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:09:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:09:09 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2022-03-16 06:09:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:09:09 --> Final output sent to browser
DEBUG - 2022-03-16 06:09:09 --> Total execution time: 0.0790
ERROR - 2022-03-16 06:09:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:09:09 --> Config Class Initialized
INFO - 2022-03-16 06:09:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:09:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:09:09 --> Utf8 Class Initialized
INFO - 2022-03-16 06:09:09 --> URI Class Initialized
INFO - 2022-03-16 06:09:09 --> Router Class Initialized
INFO - 2022-03-16 06:09:09 --> Output Class Initialized
INFO - 2022-03-16 06:09:09 --> Security Class Initialized
DEBUG - 2022-03-16 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:09:09 --> Input Class Initialized
INFO - 2022-03-16 06:09:09 --> Language Class Initialized
INFO - 2022-03-16 06:09:09 --> Loader Class Initialized
INFO - 2022-03-16 06:09:09 --> Helper loaded: url_helper
INFO - 2022-03-16 06:09:09 --> Helper loaded: form_helper
INFO - 2022-03-16 06:09:09 --> Helper loaded: common_helper
INFO - 2022-03-16 06:09:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:09:09 --> Controller Class Initialized
INFO - 2022-03-16 06:09:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:09:09 --> Encrypt Class Initialized
INFO - 2022-03-16 06:09:09 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:09:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:09:09 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:09:09 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:09:09 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:09:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:09:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 06:09:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:09:09 --> Final output sent to browser
DEBUG - 2022-03-16 06:09:09 --> Total execution time: 0.0798
ERROR - 2022-03-16 06:09:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:09:10 --> Config Class Initialized
INFO - 2022-03-16 06:09:10 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:09:10 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:09:10 --> Utf8 Class Initialized
INFO - 2022-03-16 06:09:10 --> URI Class Initialized
INFO - 2022-03-16 06:09:10 --> Router Class Initialized
INFO - 2022-03-16 06:09:10 --> Output Class Initialized
INFO - 2022-03-16 06:09:10 --> Security Class Initialized
DEBUG - 2022-03-16 06:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:09:10 --> Input Class Initialized
INFO - 2022-03-16 06:09:10 --> Language Class Initialized
ERROR - 2022-03-16 06:09:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:09:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:09:10 --> Config Class Initialized
INFO - 2022-03-16 06:09:10 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:09:10 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:09:10 --> Utf8 Class Initialized
INFO - 2022-03-16 06:09:10 --> URI Class Initialized
INFO - 2022-03-16 06:09:10 --> Router Class Initialized
INFO - 2022-03-16 06:09:10 --> Output Class Initialized
INFO - 2022-03-16 06:09:10 --> Security Class Initialized
DEBUG - 2022-03-16 06:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:09:10 --> Input Class Initialized
INFO - 2022-03-16 06:09:10 --> Language Class Initialized
INFO - 2022-03-16 06:09:10 --> Loader Class Initialized
INFO - 2022-03-16 06:09:10 --> Helper loaded: url_helper
INFO - 2022-03-16 06:09:10 --> Helper loaded: form_helper
INFO - 2022-03-16 06:09:10 --> Helper loaded: common_helper
INFO - 2022-03-16 06:09:10 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:09:10 --> Controller Class Initialized
INFO - 2022-03-16 06:09:10 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:09:10 --> Encrypt Class Initialized
INFO - 2022-03-16 06:09:10 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:09:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:09:10 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:09:10 --> Model "Users_model" initialized
INFO - 2022-03-16 06:09:10 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:09:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:09:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:09:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:09:10 --> Final output sent to browser
DEBUG - 2022-03-16 06:09:10 --> Total execution time: 0.0930
ERROR - 2022-03-16 06:09:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:09:11 --> Config Class Initialized
INFO - 2022-03-16 06:09:11 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:09:11 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:09:11 --> Utf8 Class Initialized
INFO - 2022-03-16 06:09:11 --> URI Class Initialized
INFO - 2022-03-16 06:09:11 --> Router Class Initialized
INFO - 2022-03-16 06:09:11 --> Output Class Initialized
INFO - 2022-03-16 06:09:11 --> Security Class Initialized
DEBUG - 2022-03-16 06:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:09:11 --> Input Class Initialized
INFO - 2022-03-16 06:09:11 --> Language Class Initialized
ERROR - 2022-03-16 06:09:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:10:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:10:59 --> Config Class Initialized
INFO - 2022-03-16 06:10:59 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:10:59 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:10:59 --> Utf8 Class Initialized
INFO - 2022-03-16 06:10:59 --> URI Class Initialized
INFO - 2022-03-16 06:10:59 --> Router Class Initialized
INFO - 2022-03-16 06:10:59 --> Output Class Initialized
INFO - 2022-03-16 06:10:59 --> Security Class Initialized
DEBUG - 2022-03-16 06:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:10:59 --> Input Class Initialized
INFO - 2022-03-16 06:10:59 --> Language Class Initialized
INFO - 2022-03-16 06:10:59 --> Loader Class Initialized
INFO - 2022-03-16 06:10:59 --> Helper loaded: url_helper
INFO - 2022-03-16 06:10:59 --> Helper loaded: form_helper
INFO - 2022-03-16 06:10:59 --> Helper loaded: common_helper
INFO - 2022-03-16 06:10:59 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:10:59 --> Controller Class Initialized
INFO - 2022-03-16 06:10:59 --> Form Validation Class Initialized
INFO - 2022-03-16 06:10:59 --> Model "Case_model" initialized
INFO - 2022-03-16 06:10:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:10:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:10:59 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2022-03-16 06:10:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:10:59 --> Final output sent to browser
DEBUG - 2022-03-16 06:10:59 --> Total execution time: 0.0449
ERROR - 2022-03-16 06:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:11:03 --> Config Class Initialized
INFO - 2022-03-16 06:11:03 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:11:03 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:11:03 --> Utf8 Class Initialized
INFO - 2022-03-16 06:11:03 --> URI Class Initialized
INFO - 2022-03-16 06:11:03 --> Router Class Initialized
INFO - 2022-03-16 06:11:03 --> Output Class Initialized
INFO - 2022-03-16 06:11:03 --> Security Class Initialized
DEBUG - 2022-03-16 06:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:11:03 --> Input Class Initialized
INFO - 2022-03-16 06:11:03 --> Language Class Initialized
INFO - 2022-03-16 06:11:03 --> Loader Class Initialized
INFO - 2022-03-16 06:11:03 --> Helper loaded: url_helper
INFO - 2022-03-16 06:11:03 --> Helper loaded: form_helper
INFO - 2022-03-16 06:11:03 --> Helper loaded: common_helper
INFO - 2022-03-16 06:11:03 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:11:03 --> Controller Class Initialized
INFO - 2022-03-16 06:11:03 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:11:03 --> Encrypt Class Initialized
INFO - 2022-03-16 06:11:03 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:11:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:11:03 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:11:03 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:11:03 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:11:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:11:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 06:11:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:11:03 --> Final output sent to browser
DEBUG - 2022-03-16 06:11:03 --> Total execution time: 0.0980
ERROR - 2022-03-16 06:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:12:28 --> Config Class Initialized
INFO - 2022-03-16 06:12:28 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:12:28 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:12:28 --> Utf8 Class Initialized
INFO - 2022-03-16 06:12:28 --> URI Class Initialized
INFO - 2022-03-16 06:12:28 --> Router Class Initialized
INFO - 2022-03-16 06:12:28 --> Output Class Initialized
INFO - 2022-03-16 06:12:28 --> Security Class Initialized
DEBUG - 2022-03-16 06:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:12:28 --> Input Class Initialized
INFO - 2022-03-16 06:12:28 --> Language Class Initialized
INFO - 2022-03-16 06:12:28 --> Loader Class Initialized
INFO - 2022-03-16 06:12:28 --> Helper loaded: url_helper
INFO - 2022-03-16 06:12:28 --> Helper loaded: form_helper
INFO - 2022-03-16 06:12:28 --> Helper loaded: common_helper
INFO - 2022-03-16 06:12:28 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:12:28 --> Controller Class Initialized
INFO - 2022-03-16 06:12:28 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:12:28 --> Encrypt Class Initialized
INFO - 2022-03-16 06:12:28 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:12:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:12:28 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:12:28 --> Model "Users_model" initialized
INFO - 2022-03-16 06:12:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:12:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:12:29 --> Config Class Initialized
INFO - 2022-03-16 06:12:29 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:12:29 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:12:29 --> Utf8 Class Initialized
INFO - 2022-03-16 06:12:29 --> URI Class Initialized
INFO - 2022-03-16 06:12:29 --> Router Class Initialized
INFO - 2022-03-16 06:12:29 --> Output Class Initialized
INFO - 2022-03-16 06:12:29 --> Security Class Initialized
DEBUG - 2022-03-16 06:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:12:29 --> Input Class Initialized
INFO - 2022-03-16 06:12:29 --> Language Class Initialized
INFO - 2022-03-16 06:12:29 --> Loader Class Initialized
INFO - 2022-03-16 06:12:29 --> Helper loaded: url_helper
INFO - 2022-03-16 06:12:29 --> Helper loaded: form_helper
INFO - 2022-03-16 06:12:29 --> Helper loaded: common_helper
INFO - 2022-03-16 06:12:29 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:12:29 --> Controller Class Initialized
INFO - 2022-03-16 06:12:29 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:12:29 --> Encrypt Class Initialized
INFO - 2022-03-16 06:12:29 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:12:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:12:29 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:12:29 --> Model "Users_model" initialized
INFO - 2022-03-16 06:12:29 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:12:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:12:29 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:12:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:12:29 --> Final output sent to browser
DEBUG - 2022-03-16 06:12:29 --> Total execution time: 0.0847
ERROR - 2022-03-16 06:12:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:12:30 --> Config Class Initialized
INFO - 2022-03-16 06:12:30 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:12:30 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:12:30 --> Utf8 Class Initialized
INFO - 2022-03-16 06:12:30 --> URI Class Initialized
INFO - 2022-03-16 06:12:30 --> Router Class Initialized
INFO - 2022-03-16 06:12:30 --> Output Class Initialized
INFO - 2022-03-16 06:12:30 --> Security Class Initialized
DEBUG - 2022-03-16 06:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:12:30 --> Input Class Initialized
INFO - 2022-03-16 06:12:30 --> Language Class Initialized
ERROR - 2022-03-16 06:12:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:13:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:13:24 --> Config Class Initialized
INFO - 2022-03-16 06:13:24 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:13:24 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:13:24 --> Utf8 Class Initialized
INFO - 2022-03-16 06:13:24 --> URI Class Initialized
INFO - 2022-03-16 06:13:24 --> Router Class Initialized
INFO - 2022-03-16 06:13:24 --> Output Class Initialized
INFO - 2022-03-16 06:13:24 --> Security Class Initialized
DEBUG - 2022-03-16 06:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:13:24 --> Input Class Initialized
INFO - 2022-03-16 06:13:24 --> Language Class Initialized
INFO - 2022-03-16 06:13:24 --> Loader Class Initialized
INFO - 2022-03-16 06:13:24 --> Helper loaded: url_helper
INFO - 2022-03-16 06:13:24 --> Helper loaded: form_helper
INFO - 2022-03-16 06:13:24 --> Helper loaded: common_helper
INFO - 2022-03-16 06:13:24 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:13:24 --> Controller Class Initialized
INFO - 2022-03-16 06:13:24 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:13:24 --> Encrypt Class Initialized
INFO - 2022-03-16 06:13:24 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:13:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:13:24 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:13:24 --> Model "Users_model" initialized
INFO - 2022-03-16 06:13:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:13:25 --> Config Class Initialized
INFO - 2022-03-16 06:13:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:13:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:13:25 --> Utf8 Class Initialized
INFO - 2022-03-16 06:13:25 --> URI Class Initialized
INFO - 2022-03-16 06:13:25 --> Router Class Initialized
INFO - 2022-03-16 06:13:25 --> Output Class Initialized
INFO - 2022-03-16 06:13:25 --> Security Class Initialized
DEBUG - 2022-03-16 06:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:13:25 --> Input Class Initialized
INFO - 2022-03-16 06:13:25 --> Language Class Initialized
INFO - 2022-03-16 06:13:25 --> Loader Class Initialized
INFO - 2022-03-16 06:13:25 --> Helper loaded: url_helper
INFO - 2022-03-16 06:13:25 --> Helper loaded: form_helper
INFO - 2022-03-16 06:13:25 --> Helper loaded: common_helper
INFO - 2022-03-16 06:13:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:13:25 --> Controller Class Initialized
INFO - 2022-03-16 06:13:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:13:25 --> Encrypt Class Initialized
INFO - 2022-03-16 06:13:25 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:13:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:13:25 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:13:25 --> Model "Users_model" initialized
INFO - 2022-03-16 06:13:25 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:13:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:13:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:13:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:13:25 --> Final output sent to browser
DEBUG - 2022-03-16 06:13:25 --> Total execution time: 0.0740
ERROR - 2022-03-16 06:13:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:13:26 --> Config Class Initialized
INFO - 2022-03-16 06:13:26 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:13:26 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:13:26 --> Utf8 Class Initialized
INFO - 2022-03-16 06:13:26 --> URI Class Initialized
INFO - 2022-03-16 06:13:26 --> Router Class Initialized
INFO - 2022-03-16 06:13:26 --> Output Class Initialized
INFO - 2022-03-16 06:13:26 --> Security Class Initialized
DEBUG - 2022-03-16 06:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:13:26 --> Input Class Initialized
INFO - 2022-03-16 06:13:26 --> Language Class Initialized
ERROR - 2022-03-16 06:13:26 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:14:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:14:24 --> Config Class Initialized
INFO - 2022-03-16 06:14:24 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:14:24 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:14:24 --> Utf8 Class Initialized
INFO - 2022-03-16 06:14:24 --> URI Class Initialized
INFO - 2022-03-16 06:14:24 --> Router Class Initialized
INFO - 2022-03-16 06:14:24 --> Output Class Initialized
INFO - 2022-03-16 06:14:24 --> Security Class Initialized
DEBUG - 2022-03-16 06:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:14:24 --> Input Class Initialized
INFO - 2022-03-16 06:14:24 --> Language Class Initialized
INFO - 2022-03-16 06:14:24 --> Loader Class Initialized
INFO - 2022-03-16 06:14:24 --> Helper loaded: url_helper
INFO - 2022-03-16 06:14:24 --> Helper loaded: form_helper
INFO - 2022-03-16 06:14:24 --> Helper loaded: common_helper
INFO - 2022-03-16 06:14:24 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:14:24 --> Controller Class Initialized
INFO - 2022-03-16 06:14:24 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:14:24 --> Final output sent to browser
DEBUG - 2022-03-16 06:14:24 --> Total execution time: 0.0335
ERROR - 2022-03-16 06:14:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:14:41 --> Config Class Initialized
INFO - 2022-03-16 06:14:41 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:14:41 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:14:41 --> Utf8 Class Initialized
INFO - 2022-03-16 06:14:41 --> URI Class Initialized
INFO - 2022-03-16 06:14:41 --> Router Class Initialized
INFO - 2022-03-16 06:14:41 --> Output Class Initialized
INFO - 2022-03-16 06:14:41 --> Security Class Initialized
DEBUG - 2022-03-16 06:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:14:41 --> Input Class Initialized
INFO - 2022-03-16 06:14:41 --> Language Class Initialized
INFO - 2022-03-16 06:14:41 --> Loader Class Initialized
INFO - 2022-03-16 06:14:41 --> Helper loaded: url_helper
INFO - 2022-03-16 06:14:41 --> Helper loaded: form_helper
INFO - 2022-03-16 06:14:41 --> Helper loaded: common_helper
INFO - 2022-03-16 06:14:41 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:14:41 --> Controller Class Initialized
INFO - 2022-03-16 06:14:41 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:14:41 --> Final output sent to browser
DEBUG - 2022-03-16 06:14:41 --> Total execution time: 0.0338
ERROR - 2022-03-16 06:15:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:15:03 --> Config Class Initialized
INFO - 2022-03-16 06:15:03 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:15:03 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:15:03 --> Utf8 Class Initialized
INFO - 2022-03-16 06:15:03 --> URI Class Initialized
INFO - 2022-03-16 06:15:03 --> Router Class Initialized
INFO - 2022-03-16 06:15:03 --> Output Class Initialized
INFO - 2022-03-16 06:15:03 --> Security Class Initialized
DEBUG - 2022-03-16 06:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:15:03 --> Input Class Initialized
INFO - 2022-03-16 06:15:03 --> Language Class Initialized
INFO - 2022-03-16 06:15:03 --> Loader Class Initialized
INFO - 2022-03-16 06:15:03 --> Helper loaded: url_helper
INFO - 2022-03-16 06:15:03 --> Helper loaded: form_helper
INFO - 2022-03-16 06:15:03 --> Helper loaded: common_helper
INFO - 2022-03-16 06:15:03 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:15:03 --> Controller Class Initialized
INFO - 2022-03-16 06:15:03 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:15:03 --> Encrypt Class Initialized
INFO - 2022-03-16 06:15:03 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:15:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:15:03 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:15:03 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:15:03 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:15:03 --> Final output sent to browser
DEBUG - 2022-03-16 06:15:03 --> Total execution time: 0.0494
ERROR - 2022-03-16 06:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:18:23 --> Config Class Initialized
INFO - 2022-03-16 06:18:23 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:18:23 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:18:23 --> Utf8 Class Initialized
INFO - 2022-03-16 06:18:23 --> URI Class Initialized
INFO - 2022-03-16 06:18:23 --> Router Class Initialized
INFO - 2022-03-16 06:18:23 --> Output Class Initialized
INFO - 2022-03-16 06:18:23 --> Security Class Initialized
DEBUG - 2022-03-16 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:18:23 --> Input Class Initialized
INFO - 2022-03-16 06:18:23 --> Language Class Initialized
INFO - 2022-03-16 06:18:23 --> Loader Class Initialized
INFO - 2022-03-16 06:18:23 --> Helper loaded: url_helper
INFO - 2022-03-16 06:18:23 --> Helper loaded: form_helper
INFO - 2022-03-16 06:18:23 --> Helper loaded: common_helper
INFO - 2022-03-16 06:18:23 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:18:23 --> Controller Class Initialized
INFO - 2022-03-16 06:18:23 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:18:23 --> Encrypt Class Initialized
INFO - 2022-03-16 06:18:23 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:18:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:18:23 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:18:23 --> Model "Users_model" initialized
INFO - 2022-03-16 06:18:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:18:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:18:24 --> Config Class Initialized
INFO - 2022-03-16 06:18:24 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:18:24 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:18:24 --> Utf8 Class Initialized
INFO - 2022-03-16 06:18:24 --> URI Class Initialized
INFO - 2022-03-16 06:18:24 --> Router Class Initialized
INFO - 2022-03-16 06:18:24 --> Output Class Initialized
INFO - 2022-03-16 06:18:24 --> Security Class Initialized
DEBUG - 2022-03-16 06:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:18:24 --> Input Class Initialized
INFO - 2022-03-16 06:18:24 --> Language Class Initialized
INFO - 2022-03-16 06:18:24 --> Loader Class Initialized
INFO - 2022-03-16 06:18:24 --> Helper loaded: url_helper
INFO - 2022-03-16 06:18:24 --> Helper loaded: form_helper
INFO - 2022-03-16 06:18:24 --> Helper loaded: common_helper
INFO - 2022-03-16 06:18:24 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:18:24 --> Controller Class Initialized
INFO - 2022-03-16 06:18:24 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:18:24 --> Encrypt Class Initialized
INFO - 2022-03-16 06:18:24 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:18:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:18:24 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:18:24 --> Model "Users_model" initialized
INFO - 2022-03-16 06:18:24 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:18:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:18:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:18:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:18:24 --> Final output sent to browser
DEBUG - 2022-03-16 06:18:24 --> Total execution time: 0.1090
ERROR - 2022-03-16 06:18:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:18:25 --> Config Class Initialized
INFO - 2022-03-16 06:18:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:18:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:18:25 --> Utf8 Class Initialized
INFO - 2022-03-16 06:18:25 --> URI Class Initialized
INFO - 2022-03-16 06:18:25 --> Router Class Initialized
INFO - 2022-03-16 06:18:25 --> Output Class Initialized
INFO - 2022-03-16 06:18:25 --> Security Class Initialized
DEBUG - 2022-03-16 06:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:18:25 --> Input Class Initialized
INFO - 2022-03-16 06:18:25 --> Language Class Initialized
ERROR - 2022-03-16 06:18:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:21:08 --> Config Class Initialized
INFO - 2022-03-16 06:21:08 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:21:08 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:21:08 --> Utf8 Class Initialized
INFO - 2022-03-16 06:21:08 --> URI Class Initialized
INFO - 2022-03-16 06:21:08 --> Router Class Initialized
INFO - 2022-03-16 06:21:08 --> Output Class Initialized
INFO - 2022-03-16 06:21:08 --> Security Class Initialized
DEBUG - 2022-03-16 06:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:21:08 --> Input Class Initialized
INFO - 2022-03-16 06:21:08 --> Language Class Initialized
INFO - 2022-03-16 06:21:08 --> Loader Class Initialized
INFO - 2022-03-16 06:21:08 --> Helper loaded: url_helper
INFO - 2022-03-16 06:21:08 --> Helper loaded: form_helper
INFO - 2022-03-16 06:21:08 --> Helper loaded: common_helper
INFO - 2022-03-16 06:21:08 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:21:08 --> Controller Class Initialized
INFO - 2022-03-16 06:21:08 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:21:08 --> Encrypt Class Initialized
INFO - 2022-03-16 06:21:08 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:21:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:21:08 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:21:08 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:21:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:21:08 --> Config Class Initialized
INFO - 2022-03-16 06:21:08 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:21:08 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:21:08 --> Utf8 Class Initialized
INFO - 2022-03-16 06:21:08 --> URI Class Initialized
INFO - 2022-03-16 06:21:08 --> Router Class Initialized
INFO - 2022-03-16 06:21:08 --> Output Class Initialized
INFO - 2022-03-16 06:21:08 --> Security Class Initialized
DEBUG - 2022-03-16 06:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:21:08 --> Input Class Initialized
INFO - 2022-03-16 06:21:08 --> Language Class Initialized
INFO - 2022-03-16 06:21:08 --> Loader Class Initialized
INFO - 2022-03-16 06:21:08 --> Helper loaded: url_helper
INFO - 2022-03-16 06:21:08 --> Helper loaded: form_helper
INFO - 2022-03-16 06:21:08 --> Helper loaded: common_helper
INFO - 2022-03-16 06:21:08 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:21:08 --> Controller Class Initialized
INFO - 2022-03-16 06:21:08 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:21:08 --> Encrypt Class Initialized
INFO - 2022-03-16 06:21:08 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:21:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:21:08 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:21:08 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:21:08 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:21:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:21:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 06:21:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:21:08 --> Final output sent to browser
DEBUG - 2022-03-16 06:21:08 --> Total execution time: 0.0543
ERROR - 2022-03-16 06:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:21:09 --> Config Class Initialized
INFO - 2022-03-16 06:21:09 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:21:09 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:21:09 --> Utf8 Class Initialized
INFO - 2022-03-16 06:21:09 --> URI Class Initialized
INFO - 2022-03-16 06:21:09 --> Router Class Initialized
INFO - 2022-03-16 06:21:09 --> Output Class Initialized
INFO - 2022-03-16 06:21:09 --> Security Class Initialized
DEBUG - 2022-03-16 06:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:21:09 --> Input Class Initialized
INFO - 2022-03-16 06:21:09 --> Language Class Initialized
INFO - 2022-03-16 06:21:09 --> Loader Class Initialized
INFO - 2022-03-16 06:21:09 --> Helper loaded: url_helper
INFO - 2022-03-16 06:21:09 --> Helper loaded: form_helper
INFO - 2022-03-16 06:21:09 --> Helper loaded: common_helper
INFO - 2022-03-16 06:21:09 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:21:09 --> Controller Class Initialized
INFO - 2022-03-16 06:21:09 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:21:09 --> Encrypt Class Initialized
INFO - 2022-03-16 06:21:09 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:21:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:21:09 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:21:09 --> Model "Users_model" initialized
INFO - 2022-03-16 06:21:09 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:21:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:21:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:21:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:21:10 --> Final output sent to browser
DEBUG - 2022-03-16 06:21:10 --> Total execution time: 0.0618
ERROR - 2022-03-16 06:25:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:25:31 --> Config Class Initialized
INFO - 2022-03-16 06:25:31 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:25:31 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:25:31 --> Utf8 Class Initialized
INFO - 2022-03-16 06:25:31 --> URI Class Initialized
INFO - 2022-03-16 06:25:31 --> Router Class Initialized
INFO - 2022-03-16 06:25:31 --> Output Class Initialized
INFO - 2022-03-16 06:25:31 --> Security Class Initialized
DEBUG - 2022-03-16 06:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:25:31 --> Input Class Initialized
INFO - 2022-03-16 06:25:31 --> Language Class Initialized
INFO - 2022-03-16 06:25:31 --> Loader Class Initialized
INFO - 2022-03-16 06:25:31 --> Helper loaded: url_helper
INFO - 2022-03-16 06:25:31 --> Helper loaded: form_helper
INFO - 2022-03-16 06:25:31 --> Helper loaded: common_helper
INFO - 2022-03-16 06:25:31 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:25:31 --> Controller Class Initialized
INFO - 2022-03-16 06:25:31 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:25:31 --> Encrypt Class Initialized
INFO - 2022-03-16 06:25:31 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:25:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:25:31 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:25:31 --> Model "Users_model" initialized
INFO - 2022-03-16 06:25:31 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:25:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:25:31 --> Config Class Initialized
INFO - 2022-03-16 06:25:31 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:25:31 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:25:31 --> Utf8 Class Initialized
INFO - 2022-03-16 06:25:31 --> URI Class Initialized
INFO - 2022-03-16 06:25:31 --> Router Class Initialized
INFO - 2022-03-16 06:25:31 --> Output Class Initialized
INFO - 2022-03-16 06:25:31 --> Security Class Initialized
DEBUG - 2022-03-16 06:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:25:31 --> Input Class Initialized
INFO - 2022-03-16 06:25:31 --> Language Class Initialized
INFO - 2022-03-16 06:25:31 --> Loader Class Initialized
INFO - 2022-03-16 06:25:31 --> Helper loaded: url_helper
INFO - 2022-03-16 06:25:31 --> Helper loaded: form_helper
INFO - 2022-03-16 06:25:31 --> Helper loaded: common_helper
INFO - 2022-03-16 06:25:31 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:25:31 --> Controller Class Initialized
INFO - 2022-03-16 06:25:31 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:25:31 --> Encrypt Class Initialized
INFO - 2022-03-16 06:25:31 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:25:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:25:31 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:25:31 --> Model "Users_model" initialized
INFO - 2022-03-16 06:25:31 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:25:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:25:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:25:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:25:32 --> Final output sent to browser
DEBUG - 2022-03-16 06:25:32 --> Total execution time: 0.0566
ERROR - 2022-03-16 06:28:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:28:53 --> Config Class Initialized
INFO - 2022-03-16 06:28:53 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:28:53 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:28:53 --> Utf8 Class Initialized
INFO - 2022-03-16 06:28:53 --> URI Class Initialized
INFO - 2022-03-16 06:28:53 --> Router Class Initialized
INFO - 2022-03-16 06:28:53 --> Output Class Initialized
INFO - 2022-03-16 06:28:53 --> Security Class Initialized
DEBUG - 2022-03-16 06:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:28:53 --> Input Class Initialized
INFO - 2022-03-16 06:28:53 --> Language Class Initialized
INFO - 2022-03-16 06:28:54 --> Loader Class Initialized
INFO - 2022-03-16 06:28:54 --> Helper loaded: url_helper
INFO - 2022-03-16 06:28:54 --> Helper loaded: form_helper
INFO - 2022-03-16 06:28:54 --> Helper loaded: common_helper
INFO - 2022-03-16 06:28:54 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:28:54 --> Controller Class Initialized
INFO - 2022-03-16 06:28:54 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:28:54 --> Encrypt Class Initialized
INFO - 2022-03-16 06:28:54 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:28:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:28:54 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:28:54 --> Model "Users_model" initialized
INFO - 2022-03-16 06:28:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:28:55 --> Config Class Initialized
INFO - 2022-03-16 06:28:55 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:28:55 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:28:55 --> Utf8 Class Initialized
INFO - 2022-03-16 06:28:55 --> URI Class Initialized
INFO - 2022-03-16 06:28:55 --> Router Class Initialized
INFO - 2022-03-16 06:28:55 --> Output Class Initialized
INFO - 2022-03-16 06:28:55 --> Security Class Initialized
DEBUG - 2022-03-16 06:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:28:55 --> Input Class Initialized
INFO - 2022-03-16 06:28:55 --> Language Class Initialized
INFO - 2022-03-16 06:28:55 --> Loader Class Initialized
INFO - 2022-03-16 06:28:55 --> Helper loaded: url_helper
INFO - 2022-03-16 06:28:55 --> Helper loaded: form_helper
INFO - 2022-03-16 06:28:55 --> Helper loaded: common_helper
INFO - 2022-03-16 06:28:55 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:28:55 --> Controller Class Initialized
INFO - 2022-03-16 06:28:55 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:28:55 --> Encrypt Class Initialized
INFO - 2022-03-16 06:28:55 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:28:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:28:55 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:28:55 --> Model "Users_model" initialized
INFO - 2022-03-16 06:28:55 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:28:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:28:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:28:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:28:55 --> Final output sent to browser
DEBUG - 2022-03-16 06:28:55 --> Total execution time: 0.1759
ERROR - 2022-03-16 06:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:28:56 --> Config Class Initialized
INFO - 2022-03-16 06:28:56 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:28:56 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:28:56 --> Utf8 Class Initialized
INFO - 2022-03-16 06:28:56 --> URI Class Initialized
INFO - 2022-03-16 06:28:56 --> Router Class Initialized
INFO - 2022-03-16 06:28:56 --> Output Class Initialized
INFO - 2022-03-16 06:28:56 --> Security Class Initialized
DEBUG - 2022-03-16 06:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:28:56 --> Input Class Initialized
INFO - 2022-03-16 06:28:56 --> Language Class Initialized
ERROR - 2022-03-16 06:28:56 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:28:59 --> Config Class Initialized
INFO - 2022-03-16 06:28:59 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:28:59 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:28:59 --> Utf8 Class Initialized
INFO - 2022-03-16 06:28:59 --> URI Class Initialized
INFO - 2022-03-16 06:28:59 --> Router Class Initialized
INFO - 2022-03-16 06:28:59 --> Output Class Initialized
INFO - 2022-03-16 06:28:59 --> Security Class Initialized
DEBUG - 2022-03-16 06:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:28:59 --> Input Class Initialized
INFO - 2022-03-16 06:28:59 --> Language Class Initialized
INFO - 2022-03-16 06:28:59 --> Loader Class Initialized
INFO - 2022-03-16 06:28:59 --> Helper loaded: url_helper
INFO - 2022-03-16 06:28:59 --> Helper loaded: form_helper
INFO - 2022-03-16 06:28:59 --> Helper loaded: common_helper
INFO - 2022-03-16 06:28:59 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:28:59 --> Controller Class Initialized
INFO - 2022-03-16 06:28:59 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:28:59 --> Encrypt Class Initialized
INFO - 2022-03-16 06:28:59 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:28:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:28:59 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:28:59 --> Model "Users_model" initialized
INFO - 2022-03-16 06:28:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:29:00 --> Config Class Initialized
INFO - 2022-03-16 06:29:00 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:29:00 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:29:00 --> Utf8 Class Initialized
INFO - 2022-03-16 06:29:00 --> URI Class Initialized
INFO - 2022-03-16 06:29:00 --> Router Class Initialized
INFO - 2022-03-16 06:29:00 --> Output Class Initialized
INFO - 2022-03-16 06:29:00 --> Security Class Initialized
DEBUG - 2022-03-16 06:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:29:00 --> Input Class Initialized
INFO - 2022-03-16 06:29:00 --> Language Class Initialized
INFO - 2022-03-16 06:29:00 --> Loader Class Initialized
INFO - 2022-03-16 06:29:00 --> Helper loaded: url_helper
INFO - 2022-03-16 06:29:00 --> Helper loaded: form_helper
INFO - 2022-03-16 06:29:00 --> Helper loaded: common_helper
INFO - 2022-03-16 06:29:00 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:29:00 --> Controller Class Initialized
INFO - 2022-03-16 06:29:00 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:29:00 --> Encrypt Class Initialized
INFO - 2022-03-16 06:29:00 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:29:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:29:00 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:29:00 --> Model "Users_model" initialized
INFO - 2022-03-16 06:29:00 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:29:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:29:00 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:29:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:29:00 --> Final output sent to browser
DEBUG - 2022-03-16 06:29:00 --> Total execution time: 0.1952
ERROR - 2022-03-16 06:32:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:32:54 --> Config Class Initialized
INFO - 2022-03-16 06:32:54 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:32:54 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:32:54 --> Utf8 Class Initialized
INFO - 2022-03-16 06:32:54 --> URI Class Initialized
INFO - 2022-03-16 06:32:54 --> Router Class Initialized
INFO - 2022-03-16 06:32:54 --> Output Class Initialized
INFO - 2022-03-16 06:32:54 --> Security Class Initialized
DEBUG - 2022-03-16 06:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:32:54 --> Input Class Initialized
INFO - 2022-03-16 06:32:54 --> Language Class Initialized
INFO - 2022-03-16 06:32:54 --> Loader Class Initialized
INFO - 2022-03-16 06:32:54 --> Helper loaded: url_helper
INFO - 2022-03-16 06:32:54 --> Helper loaded: form_helper
INFO - 2022-03-16 06:32:54 --> Helper loaded: common_helper
INFO - 2022-03-16 06:32:54 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:32:54 --> Controller Class Initialized
INFO - 2022-03-16 06:32:54 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:32:54 --> Encrypt Class Initialized
INFO - 2022-03-16 06:32:54 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:32:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:32:54 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:32:54 --> Model "Users_model" initialized
INFO - 2022-03-16 06:32:54 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:32:54 --> Upload Class Initialized
INFO - 2022-03-16 06:32:54 --> Final output sent to browser
DEBUG - 2022-03-16 06:32:54 --> Total execution time: 0.2697
ERROR - 2022-03-16 06:34:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:34:37 --> Config Class Initialized
INFO - 2022-03-16 06:34:37 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:34:37 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:34:37 --> Utf8 Class Initialized
INFO - 2022-03-16 06:34:37 --> URI Class Initialized
INFO - 2022-03-16 06:34:37 --> Router Class Initialized
INFO - 2022-03-16 06:34:37 --> Output Class Initialized
INFO - 2022-03-16 06:34:37 --> Security Class Initialized
DEBUG - 2022-03-16 06:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:34:37 --> Input Class Initialized
INFO - 2022-03-16 06:34:37 --> Language Class Initialized
INFO - 2022-03-16 06:34:37 --> Loader Class Initialized
INFO - 2022-03-16 06:34:37 --> Helper loaded: url_helper
INFO - 2022-03-16 06:34:37 --> Helper loaded: form_helper
INFO - 2022-03-16 06:34:37 --> Helper loaded: common_helper
INFO - 2022-03-16 06:34:37 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:34:37 --> Controller Class Initialized
INFO - 2022-03-16 06:34:37 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:34:37 --> Encrypt Class Initialized
INFO - 2022-03-16 06:34:37 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:34:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:34:37 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:34:37 --> Model "Users_model" initialized
INFO - 2022-03-16 06:34:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:34:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:34:37 --> Config Class Initialized
INFO - 2022-03-16 06:34:37 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:34:37 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:34:37 --> Utf8 Class Initialized
INFO - 2022-03-16 06:34:37 --> URI Class Initialized
INFO - 2022-03-16 06:34:37 --> Router Class Initialized
INFO - 2022-03-16 06:34:37 --> Output Class Initialized
INFO - 2022-03-16 06:34:37 --> Security Class Initialized
DEBUG - 2022-03-16 06:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:34:37 --> Input Class Initialized
INFO - 2022-03-16 06:34:37 --> Language Class Initialized
INFO - 2022-03-16 06:34:37 --> Loader Class Initialized
INFO - 2022-03-16 06:34:37 --> Helper loaded: url_helper
INFO - 2022-03-16 06:34:37 --> Helper loaded: form_helper
INFO - 2022-03-16 06:34:37 --> Helper loaded: common_helper
INFO - 2022-03-16 06:34:37 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:34:37 --> Controller Class Initialized
INFO - 2022-03-16 06:34:37 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:34:37 --> Encrypt Class Initialized
INFO - 2022-03-16 06:34:37 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:34:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:34:37 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:34:37 --> Model "Users_model" initialized
INFO - 2022-03-16 06:34:37 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:34:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:34:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:34:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:34:37 --> Final output sent to browser
DEBUG - 2022-03-16 06:34:37 --> Total execution time: 0.0861
ERROR - 2022-03-16 06:42:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:42:33 --> Config Class Initialized
INFO - 2022-03-16 06:42:33 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:42:33 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:42:33 --> Utf8 Class Initialized
INFO - 2022-03-16 06:42:33 --> URI Class Initialized
INFO - 2022-03-16 06:42:33 --> Router Class Initialized
INFO - 2022-03-16 06:42:33 --> Output Class Initialized
INFO - 2022-03-16 06:42:33 --> Security Class Initialized
DEBUG - 2022-03-16 06:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:42:33 --> Input Class Initialized
INFO - 2022-03-16 06:42:33 --> Language Class Initialized
INFO - 2022-03-16 06:42:33 --> Loader Class Initialized
INFO - 2022-03-16 06:42:33 --> Helper loaded: url_helper
INFO - 2022-03-16 06:42:33 --> Helper loaded: form_helper
INFO - 2022-03-16 06:42:33 --> Helper loaded: common_helper
INFO - 2022-03-16 06:42:33 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:42:33 --> Controller Class Initialized
INFO - 2022-03-16 06:42:33 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:42:33 --> Encrypt Class Initialized
INFO - 2022-03-16 06:42:33 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:42:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:42:33 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:42:33 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:42:33 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:42:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:42:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 06:42:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-16 06:42:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:42:42 --> Config Class Initialized
INFO - 2022-03-16 06:42:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:42:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:42:42 --> Utf8 Class Initialized
INFO - 2022-03-16 06:42:42 --> URI Class Initialized
INFO - 2022-03-16 06:42:42 --> Router Class Initialized
INFO - 2022-03-16 06:42:42 --> Output Class Initialized
INFO - 2022-03-16 06:42:42 --> Security Class Initialized
DEBUG - 2022-03-16 06:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:42:42 --> Input Class Initialized
INFO - 2022-03-16 06:42:42 --> Language Class Initialized
ERROR - 2022-03-16 06:42:42 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-16 06:42:42 --> Final output sent to browser
DEBUG - 2022-03-16 06:42:42 --> Total execution time: 8.1380
ERROR - 2022-03-16 06:43:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:43:26 --> Config Class Initialized
INFO - 2022-03-16 06:43:26 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:43:26 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:43:26 --> Utf8 Class Initialized
INFO - 2022-03-16 06:43:26 --> URI Class Initialized
INFO - 2022-03-16 06:43:26 --> Router Class Initialized
INFO - 2022-03-16 06:43:26 --> Output Class Initialized
INFO - 2022-03-16 06:43:26 --> Security Class Initialized
DEBUG - 2022-03-16 06:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:43:26 --> Input Class Initialized
INFO - 2022-03-16 06:43:26 --> Language Class Initialized
INFO - 2022-03-16 06:43:26 --> Loader Class Initialized
INFO - 2022-03-16 06:43:26 --> Helper loaded: url_helper
INFO - 2022-03-16 06:43:26 --> Helper loaded: form_helper
INFO - 2022-03-16 06:43:26 --> Helper loaded: common_helper
INFO - 2022-03-16 06:43:26 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:43:26 --> Controller Class Initialized
INFO - 2022-03-16 06:43:26 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:43:26 --> Encrypt Class Initialized
INFO - 2022-03-16 06:43:26 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:43:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:43:26 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:43:26 --> Model "Users_model" initialized
INFO - 2022-03-16 06:43:26 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:43:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:43:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:43:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:43:26 --> Final output sent to browser
DEBUG - 2022-03-16 06:43:26 --> Total execution time: 0.0814
ERROR - 2022-03-16 06:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:43:27 --> Config Class Initialized
INFO - 2022-03-16 06:43:27 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:43:27 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:43:27 --> Utf8 Class Initialized
INFO - 2022-03-16 06:43:27 --> URI Class Initialized
INFO - 2022-03-16 06:43:27 --> Router Class Initialized
INFO - 2022-03-16 06:43:27 --> Output Class Initialized
INFO - 2022-03-16 06:43:27 --> Security Class Initialized
DEBUG - 2022-03-16 06:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:43:27 --> Input Class Initialized
INFO - 2022-03-16 06:43:27 --> Language Class Initialized
ERROR - 2022-03-16 06:43:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:44:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:44:37 --> Config Class Initialized
INFO - 2022-03-16 06:44:37 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:44:37 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:44:37 --> Utf8 Class Initialized
INFO - 2022-03-16 06:44:37 --> URI Class Initialized
INFO - 2022-03-16 06:44:37 --> Router Class Initialized
INFO - 2022-03-16 06:44:37 --> Output Class Initialized
INFO - 2022-03-16 06:44:37 --> Security Class Initialized
DEBUG - 2022-03-16 06:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:44:37 --> Input Class Initialized
INFO - 2022-03-16 06:44:37 --> Language Class Initialized
INFO - 2022-03-16 06:44:37 --> Loader Class Initialized
INFO - 2022-03-16 06:44:37 --> Helper loaded: url_helper
INFO - 2022-03-16 06:44:37 --> Helper loaded: form_helper
INFO - 2022-03-16 06:44:37 --> Helper loaded: common_helper
INFO - 2022-03-16 06:44:37 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:44:37 --> Controller Class Initialized
INFO - 2022-03-16 06:44:37 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:44:37 --> Encrypt Class Initialized
INFO - 2022-03-16 06:44:37 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:44:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:44:37 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:44:37 --> Model "Users_model" initialized
INFO - 2022-03-16 06:44:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:44:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:44:38 --> Config Class Initialized
INFO - 2022-03-16 06:44:38 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:44:38 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:44:38 --> Utf8 Class Initialized
INFO - 2022-03-16 06:44:38 --> URI Class Initialized
INFO - 2022-03-16 06:44:38 --> Router Class Initialized
INFO - 2022-03-16 06:44:38 --> Output Class Initialized
INFO - 2022-03-16 06:44:38 --> Security Class Initialized
DEBUG - 2022-03-16 06:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:44:38 --> Input Class Initialized
INFO - 2022-03-16 06:44:38 --> Language Class Initialized
INFO - 2022-03-16 06:44:38 --> Loader Class Initialized
INFO - 2022-03-16 06:44:38 --> Helper loaded: url_helper
INFO - 2022-03-16 06:44:38 --> Helper loaded: form_helper
INFO - 2022-03-16 06:44:38 --> Helper loaded: common_helper
INFO - 2022-03-16 06:44:38 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:44:38 --> Controller Class Initialized
INFO - 2022-03-16 06:44:38 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:44:38 --> Encrypt Class Initialized
INFO - 2022-03-16 06:44:38 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:44:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:44:38 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:44:38 --> Model "Users_model" initialized
INFO - 2022-03-16 06:44:38 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:44:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:44:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:44:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:44:38 --> Final output sent to browser
DEBUG - 2022-03-16 06:44:38 --> Total execution time: 0.0788
ERROR - 2022-03-16 06:44:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:44:38 --> Config Class Initialized
INFO - 2022-03-16 06:44:38 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:44:38 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:44:38 --> Utf8 Class Initialized
INFO - 2022-03-16 06:44:38 --> URI Class Initialized
INFO - 2022-03-16 06:44:38 --> Router Class Initialized
INFO - 2022-03-16 06:44:38 --> Output Class Initialized
INFO - 2022-03-16 06:44:38 --> Security Class Initialized
DEBUG - 2022-03-16 06:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:44:38 --> Input Class Initialized
INFO - 2022-03-16 06:44:38 --> Language Class Initialized
ERROR - 2022-03-16 06:44:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-16 06:45:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:45:30 --> Config Class Initialized
INFO - 2022-03-16 06:45:30 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:45:30 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:45:30 --> Utf8 Class Initialized
INFO - 2022-03-16 06:45:30 --> URI Class Initialized
INFO - 2022-03-16 06:45:30 --> Router Class Initialized
INFO - 2022-03-16 06:45:30 --> Output Class Initialized
INFO - 2022-03-16 06:45:30 --> Security Class Initialized
DEBUG - 2022-03-16 06:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:45:30 --> Input Class Initialized
INFO - 2022-03-16 06:45:30 --> Language Class Initialized
INFO - 2022-03-16 06:45:30 --> Loader Class Initialized
INFO - 2022-03-16 06:45:30 --> Helper loaded: url_helper
INFO - 2022-03-16 06:45:30 --> Helper loaded: form_helper
INFO - 2022-03-16 06:45:30 --> Helper loaded: common_helper
INFO - 2022-03-16 06:45:30 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:45:30 --> Controller Class Initialized
INFO - 2022-03-16 06:45:30 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:45:30 --> Encrypt Class Initialized
INFO - 2022-03-16 06:45:30 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:45:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:45:30 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:45:30 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:45:30 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:45:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:45:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-16 06:45:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-16 06:45:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:45:41 --> Config Class Initialized
INFO - 2022-03-16 06:45:41 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:45:41 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:45:41 --> Utf8 Class Initialized
INFO - 2022-03-16 06:45:41 --> URI Class Initialized
INFO - 2022-03-16 06:45:41 --> Router Class Initialized
INFO - 2022-03-16 06:45:41 --> Output Class Initialized
INFO - 2022-03-16 06:45:41 --> Security Class Initialized
DEBUG - 2022-03-16 06:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:45:41 --> Input Class Initialized
INFO - 2022-03-16 06:45:41 --> Language Class Initialized
ERROR - 2022-03-16 06:45:41 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-16 06:45:41 --> Final output sent to browser
DEBUG - 2022-03-16 06:45:41 --> Total execution time: 9.8766
ERROR - 2022-03-16 06:46:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:46:02 --> Config Class Initialized
INFO - 2022-03-16 06:46:02 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:46:02 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:46:02 --> Utf8 Class Initialized
INFO - 2022-03-16 06:46:02 --> URI Class Initialized
INFO - 2022-03-16 06:46:02 --> Router Class Initialized
INFO - 2022-03-16 06:46:02 --> Output Class Initialized
INFO - 2022-03-16 06:46:02 --> Security Class Initialized
DEBUG - 2022-03-16 06:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:46:02 --> Input Class Initialized
INFO - 2022-03-16 06:46:02 --> Language Class Initialized
INFO - 2022-03-16 06:46:02 --> Loader Class Initialized
INFO - 2022-03-16 06:46:02 --> Helper loaded: url_helper
INFO - 2022-03-16 06:46:02 --> Helper loaded: form_helper
INFO - 2022-03-16 06:46:02 --> Helper loaded: common_helper
INFO - 2022-03-16 06:46:02 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:46:02 --> Controller Class Initialized
INFO - 2022-03-16 06:46:02 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:46:02 --> Encrypt Class Initialized
INFO - 2022-03-16 06:46:02 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:46:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:46:02 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:46:02 --> Model "Users_model" initialized
INFO - 2022-03-16 06:46:02 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:46:02 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-16 06:46:03 --> Final output sent to browser
DEBUG - 2022-03-16 06:46:03 --> Total execution time: 1.2726
ERROR - 2022-03-16 06:48:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:48:43 --> Config Class Initialized
INFO - 2022-03-16 06:48:43 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:48:43 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:48:43 --> Utf8 Class Initialized
INFO - 2022-03-16 06:48:43 --> URI Class Initialized
INFO - 2022-03-16 06:48:43 --> Router Class Initialized
INFO - 2022-03-16 06:48:43 --> Output Class Initialized
INFO - 2022-03-16 06:48:43 --> Security Class Initialized
DEBUG - 2022-03-16 06:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:48:43 --> Input Class Initialized
INFO - 2022-03-16 06:48:43 --> Language Class Initialized
INFO - 2022-03-16 06:48:43 --> Loader Class Initialized
INFO - 2022-03-16 06:48:43 --> Helper loaded: url_helper
INFO - 2022-03-16 06:48:43 --> Helper loaded: form_helper
INFO - 2022-03-16 06:48:43 --> Helper loaded: common_helper
INFO - 2022-03-16 06:48:43 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:48:43 --> Controller Class Initialized
INFO - 2022-03-16 06:48:43 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:48:43 --> Encrypt Class Initialized
INFO - 2022-03-16 06:48:43 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:48:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:48:43 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:48:43 --> Model "Users_model" initialized
INFO - 2022-03-16 06:48:43 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:48:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:48:43 --> Config Class Initialized
INFO - 2022-03-16 06:48:43 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:48:43 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:48:43 --> Utf8 Class Initialized
INFO - 2022-03-16 06:48:43 --> URI Class Initialized
INFO - 2022-03-16 06:48:43 --> Router Class Initialized
INFO - 2022-03-16 06:48:43 --> Output Class Initialized
INFO - 2022-03-16 06:48:43 --> Security Class Initialized
DEBUG - 2022-03-16 06:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:48:43 --> Input Class Initialized
INFO - 2022-03-16 06:48:43 --> Language Class Initialized
INFO - 2022-03-16 06:48:43 --> Loader Class Initialized
INFO - 2022-03-16 06:48:43 --> Helper loaded: url_helper
INFO - 2022-03-16 06:48:43 --> Helper loaded: form_helper
INFO - 2022-03-16 06:48:43 --> Helper loaded: common_helper
INFO - 2022-03-16 06:48:43 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:48:43 --> Controller Class Initialized
INFO - 2022-03-16 06:48:43 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:48:43 --> Encrypt Class Initialized
INFO - 2022-03-16 06:48:43 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:48:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:48:44 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:48:44 --> Model "Users_model" initialized
INFO - 2022-03-16 06:48:44 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:48:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:48:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:48:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:48:44 --> Final output sent to browser
DEBUG - 2022-03-16 06:48:44 --> Total execution time: 0.0988
ERROR - 2022-03-16 06:48:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:48:47 --> Config Class Initialized
INFO - 2022-03-16 06:48:47 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:48:47 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:48:47 --> Utf8 Class Initialized
INFO - 2022-03-16 06:48:47 --> URI Class Initialized
INFO - 2022-03-16 06:48:47 --> Router Class Initialized
INFO - 2022-03-16 06:48:47 --> Output Class Initialized
INFO - 2022-03-16 06:48:47 --> Security Class Initialized
DEBUG - 2022-03-16 06:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:48:47 --> Input Class Initialized
INFO - 2022-03-16 06:48:47 --> Language Class Initialized
INFO - 2022-03-16 06:48:47 --> Loader Class Initialized
INFO - 2022-03-16 06:48:47 --> Helper loaded: url_helper
INFO - 2022-03-16 06:48:47 --> Helper loaded: form_helper
INFO - 2022-03-16 06:48:47 --> Helper loaded: common_helper
INFO - 2022-03-16 06:48:47 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:48:47 --> Controller Class Initialized
INFO - 2022-03-16 06:48:47 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:48:47 --> Encrypt Class Initialized
INFO - 2022-03-16 06:48:47 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:48:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:48:47 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:48:47 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:48:47 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:48:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:48:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 06:48:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:48:47 --> Final output sent to browser
DEBUG - 2022-03-16 06:48:47 --> Total execution time: 0.0917
ERROR - 2022-03-16 06:49:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:49:03 --> Config Class Initialized
INFO - 2022-03-16 06:49:03 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:49:03 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:49:03 --> Utf8 Class Initialized
INFO - 2022-03-16 06:49:03 --> URI Class Initialized
INFO - 2022-03-16 06:49:03 --> Router Class Initialized
INFO - 2022-03-16 06:49:03 --> Output Class Initialized
INFO - 2022-03-16 06:49:03 --> Security Class Initialized
DEBUG - 2022-03-16 06:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:49:03 --> Input Class Initialized
INFO - 2022-03-16 06:49:03 --> Language Class Initialized
INFO - 2022-03-16 06:49:03 --> Loader Class Initialized
INFO - 2022-03-16 06:49:03 --> Helper loaded: url_helper
INFO - 2022-03-16 06:49:03 --> Helper loaded: form_helper
INFO - 2022-03-16 06:49:03 --> Helper loaded: common_helper
INFO - 2022-03-16 06:49:03 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:49:03 --> Controller Class Initialized
INFO - 2022-03-16 06:49:03 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:49:03 --> Encrypt Class Initialized
INFO - 2022-03-16 06:49:03 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:49:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:49:03 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:49:03 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:49:03 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:49:03 --> Upload Class Initialized
INFO - 2022-03-16 06:49:04 --> Final output sent to browser
DEBUG - 2022-03-16 06:49:04 --> Total execution time: 0.6952
ERROR - 2022-03-16 06:49:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:49:16 --> Config Class Initialized
INFO - 2022-03-16 06:49:16 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:49:16 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:49:16 --> Utf8 Class Initialized
INFO - 2022-03-16 06:49:16 --> URI Class Initialized
INFO - 2022-03-16 06:49:16 --> Router Class Initialized
INFO - 2022-03-16 06:49:16 --> Output Class Initialized
INFO - 2022-03-16 06:49:16 --> Security Class Initialized
DEBUG - 2022-03-16 06:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:49:16 --> Input Class Initialized
INFO - 2022-03-16 06:49:16 --> Language Class Initialized
INFO - 2022-03-16 06:49:16 --> Loader Class Initialized
INFO - 2022-03-16 06:49:16 --> Helper loaded: url_helper
INFO - 2022-03-16 06:49:16 --> Helper loaded: form_helper
INFO - 2022-03-16 06:49:16 --> Helper loaded: common_helper
INFO - 2022-03-16 06:49:16 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:49:16 --> Controller Class Initialized
INFO - 2022-03-16 06:49:16 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:49:16 --> Encrypt Class Initialized
INFO - 2022-03-16 06:49:16 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:49:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:49:16 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:49:16 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:49:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-16 06:49:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:49:16 --> Config Class Initialized
INFO - 2022-03-16 06:49:16 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:49:16 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:49:16 --> Utf8 Class Initialized
INFO - 2022-03-16 06:49:16 --> URI Class Initialized
INFO - 2022-03-16 06:49:16 --> Router Class Initialized
INFO - 2022-03-16 06:49:16 --> Output Class Initialized
INFO - 2022-03-16 06:49:16 --> Security Class Initialized
DEBUG - 2022-03-16 06:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:49:16 --> Input Class Initialized
INFO - 2022-03-16 06:49:16 --> Language Class Initialized
INFO - 2022-03-16 06:49:16 --> Loader Class Initialized
INFO - 2022-03-16 06:49:16 --> Helper loaded: url_helper
INFO - 2022-03-16 06:49:16 --> Helper loaded: form_helper
INFO - 2022-03-16 06:49:16 --> Helper loaded: common_helper
INFO - 2022-03-16 06:49:16 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:49:16 --> Controller Class Initialized
INFO - 2022-03-16 06:49:16 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:49:16 --> Encrypt Class Initialized
INFO - 2022-03-16 06:49:16 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:49:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:49:16 --> Model "Referredby_model" initialized
INFO - 2022-03-16 06:49:16 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:49:16 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:49:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:49:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-16 06:49:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:49:17 --> Final output sent to browser
DEBUG - 2022-03-16 06:49:17 --> Total execution time: 0.0505
ERROR - 2022-03-16 06:49:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 06:49:18 --> Config Class Initialized
INFO - 2022-03-16 06:49:18 --> Hooks Class Initialized
DEBUG - 2022-03-16 06:49:18 --> UTF-8 Support Enabled
INFO - 2022-03-16 06:49:18 --> Utf8 Class Initialized
INFO - 2022-03-16 06:49:18 --> URI Class Initialized
INFO - 2022-03-16 06:49:18 --> Router Class Initialized
INFO - 2022-03-16 06:49:18 --> Output Class Initialized
INFO - 2022-03-16 06:49:18 --> Security Class Initialized
DEBUG - 2022-03-16 06:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 06:49:18 --> Input Class Initialized
INFO - 2022-03-16 06:49:18 --> Language Class Initialized
INFO - 2022-03-16 06:49:18 --> Loader Class Initialized
INFO - 2022-03-16 06:49:18 --> Helper loaded: url_helper
INFO - 2022-03-16 06:49:18 --> Helper loaded: form_helper
INFO - 2022-03-16 06:49:18 --> Helper loaded: common_helper
INFO - 2022-03-16 06:49:18 --> Database Driver Class Initialized
DEBUG - 2022-03-16 06:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 06:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 06:49:18 --> Controller Class Initialized
INFO - 2022-03-16 06:49:18 --> Form Validation Class Initialized
DEBUG - 2022-03-16 06:49:18 --> Encrypt Class Initialized
INFO - 2022-03-16 06:49:18 --> Model "Patient_model" initialized
INFO - 2022-03-16 06:49:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 06:49:18 --> Model "Prefix_master" initialized
INFO - 2022-03-16 06:49:18 --> Model "Users_model" initialized
INFO - 2022-03-16 06:49:18 --> Model "Hospital_model" initialized
INFO - 2022-03-16 06:49:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 06:49:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 06:49:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 06:49:18 --> Final output sent to browser
DEBUG - 2022-03-16 06:49:18 --> Total execution time: 0.0847
ERROR - 2022-03-16 07:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 07:20:25 --> Config Class Initialized
INFO - 2022-03-16 07:20:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 07:20:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 07:20:25 --> Utf8 Class Initialized
INFO - 2022-03-16 07:20:25 --> URI Class Initialized
INFO - 2022-03-16 07:20:25 --> Router Class Initialized
INFO - 2022-03-16 07:20:25 --> Output Class Initialized
INFO - 2022-03-16 07:20:25 --> Security Class Initialized
DEBUG - 2022-03-16 07:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 07:20:25 --> Input Class Initialized
INFO - 2022-03-16 07:20:25 --> Language Class Initialized
INFO - 2022-03-16 07:20:25 --> Loader Class Initialized
INFO - 2022-03-16 07:20:25 --> Helper loaded: url_helper
INFO - 2022-03-16 07:20:25 --> Helper loaded: form_helper
INFO - 2022-03-16 07:20:25 --> Helper loaded: common_helper
INFO - 2022-03-16 07:20:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 07:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 07:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 07:20:25 --> Controller Class Initialized
INFO - 2022-03-16 07:20:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 07:20:25 --> Encrypt Class Initialized
DEBUG - 2022-03-16 07:20:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 07:20:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 07:20:25 --> Email Class Initialized
INFO - 2022-03-16 07:20:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 07:20:25 --> Calendar Class Initialized
INFO - 2022-03-16 07:20:25 --> Model "Login_model" initialized
ERROR - 2022-03-16 07:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 07:20:25 --> Config Class Initialized
INFO - 2022-03-16 07:20:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 07:20:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 07:20:25 --> Utf8 Class Initialized
INFO - 2022-03-16 07:20:25 --> URI Class Initialized
INFO - 2022-03-16 07:20:25 --> Router Class Initialized
INFO - 2022-03-16 07:20:25 --> Output Class Initialized
INFO - 2022-03-16 07:20:25 --> Security Class Initialized
DEBUG - 2022-03-16 07:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 07:20:25 --> Input Class Initialized
INFO - 2022-03-16 07:20:25 --> Language Class Initialized
INFO - 2022-03-16 07:20:25 --> Loader Class Initialized
INFO - 2022-03-16 07:20:25 --> Helper loaded: url_helper
INFO - 2022-03-16 07:20:25 --> Helper loaded: form_helper
INFO - 2022-03-16 07:20:25 --> Helper loaded: common_helper
INFO - 2022-03-16 07:20:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 07:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 07:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 07:20:25 --> Controller Class Initialized
INFO - 2022-03-16 07:20:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 07:20:25 --> Encrypt Class Initialized
DEBUG - 2022-03-16 07:20:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 07:20:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 07:20:25 --> Email Class Initialized
INFO - 2022-03-16 07:20:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 07:20:25 --> Calendar Class Initialized
INFO - 2022-03-16 07:20:25 --> Model "Login_model" initialized
INFO - 2022-03-16 07:20:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 07:20:25 --> Final output sent to browser
DEBUG - 2022-03-16 07:20:25 --> Total execution time: 0.0259
ERROR - 2022-03-16 07:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 07:28:20 --> Config Class Initialized
INFO - 2022-03-16 07:28:20 --> Hooks Class Initialized
DEBUG - 2022-03-16 07:28:20 --> UTF-8 Support Enabled
INFO - 2022-03-16 07:28:20 --> Utf8 Class Initialized
INFO - 2022-03-16 07:28:20 --> URI Class Initialized
INFO - 2022-03-16 07:28:20 --> Router Class Initialized
INFO - 2022-03-16 07:28:20 --> Output Class Initialized
INFO - 2022-03-16 07:28:20 --> Security Class Initialized
DEBUG - 2022-03-16 07:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 07:28:20 --> Input Class Initialized
INFO - 2022-03-16 07:28:20 --> Language Class Initialized
INFO - 2022-03-16 07:28:20 --> Loader Class Initialized
INFO - 2022-03-16 07:28:20 --> Helper loaded: url_helper
INFO - 2022-03-16 07:28:20 --> Helper loaded: form_helper
INFO - 2022-03-16 07:28:20 --> Helper loaded: common_helper
INFO - 2022-03-16 07:28:20 --> Database Driver Class Initialized
DEBUG - 2022-03-16 07:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 07:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 07:28:20 --> Controller Class Initialized
INFO - 2022-03-16 07:28:20 --> Form Validation Class Initialized
DEBUG - 2022-03-16 07:28:20 --> Encrypt Class Initialized
INFO - 2022-03-16 07:28:20 --> Model "Patient_model" initialized
INFO - 2022-03-16 07:28:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-16 07:28:20 --> Model "Prefix_master" initialized
INFO - 2022-03-16 07:28:20 --> Model "Users_model" initialized
INFO - 2022-03-16 07:28:20 --> Model "Hospital_model" initialized
INFO - 2022-03-16 07:28:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-16 07:28:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-16 07:28:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-16 07:28:20 --> Final output sent to browser
DEBUG - 2022-03-16 07:28:20 --> Total execution time: 0.0887
ERROR - 2022-03-16 11:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 11:00:00 --> Config Class Initialized
INFO - 2022-03-16 11:00:00 --> Hooks Class Initialized
DEBUG - 2022-03-16 11:00:00 --> UTF-8 Support Enabled
INFO - 2022-03-16 11:00:00 --> Utf8 Class Initialized
INFO - 2022-03-16 11:00:00 --> URI Class Initialized
DEBUG - 2022-03-16 11:00:00 --> No URI present. Default controller set.
INFO - 2022-03-16 11:00:00 --> Router Class Initialized
INFO - 2022-03-16 11:00:00 --> Output Class Initialized
INFO - 2022-03-16 11:00:00 --> Security Class Initialized
DEBUG - 2022-03-16 11:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 11:00:00 --> Input Class Initialized
INFO - 2022-03-16 11:00:00 --> Language Class Initialized
INFO - 2022-03-16 11:00:00 --> Loader Class Initialized
INFO - 2022-03-16 11:00:00 --> Helper loaded: url_helper
INFO - 2022-03-16 11:00:00 --> Helper loaded: form_helper
INFO - 2022-03-16 11:00:00 --> Helper loaded: common_helper
INFO - 2022-03-16 11:00:00 --> Database Driver Class Initialized
DEBUG - 2022-03-16 11:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 11:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 11:00:00 --> Controller Class Initialized
INFO - 2022-03-16 11:00:00 --> Form Validation Class Initialized
DEBUG - 2022-03-16 11:00:00 --> Encrypt Class Initialized
DEBUG - 2022-03-16 11:00:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 11:00:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 11:00:00 --> Email Class Initialized
INFO - 2022-03-16 11:00:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 11:00:00 --> Calendar Class Initialized
INFO - 2022-03-16 11:00:00 --> Model "Login_model" initialized
INFO - 2022-03-16 11:00:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 11:00:00 --> Final output sent to browser
DEBUG - 2022-03-16 11:00:00 --> Total execution time: 0.0362
ERROR - 2022-03-16 11:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 11:24:39 --> Config Class Initialized
INFO - 2022-03-16 11:24:39 --> Hooks Class Initialized
DEBUG - 2022-03-16 11:24:39 --> UTF-8 Support Enabled
INFO - 2022-03-16 11:24:39 --> Utf8 Class Initialized
INFO - 2022-03-16 11:24:39 --> URI Class Initialized
DEBUG - 2022-03-16 11:24:39 --> No URI present. Default controller set.
INFO - 2022-03-16 11:24:39 --> Router Class Initialized
INFO - 2022-03-16 11:24:39 --> Output Class Initialized
INFO - 2022-03-16 11:24:39 --> Security Class Initialized
DEBUG - 2022-03-16 11:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 11:24:39 --> Input Class Initialized
INFO - 2022-03-16 11:24:39 --> Language Class Initialized
INFO - 2022-03-16 11:24:39 --> Loader Class Initialized
INFO - 2022-03-16 11:24:39 --> Helper loaded: url_helper
INFO - 2022-03-16 11:24:39 --> Helper loaded: form_helper
INFO - 2022-03-16 11:24:39 --> Helper loaded: common_helper
INFO - 2022-03-16 11:24:39 --> Database Driver Class Initialized
DEBUG - 2022-03-16 11:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 11:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 11:24:39 --> Controller Class Initialized
INFO - 2022-03-16 11:24:39 --> Form Validation Class Initialized
DEBUG - 2022-03-16 11:24:39 --> Encrypt Class Initialized
DEBUG - 2022-03-16 11:24:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 11:24:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 11:24:39 --> Email Class Initialized
INFO - 2022-03-16 11:24:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 11:24:39 --> Calendar Class Initialized
INFO - 2022-03-16 11:24:39 --> Model "Login_model" initialized
INFO - 2022-03-16 11:24:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 11:24:39 --> Final output sent to browser
DEBUG - 2022-03-16 11:24:39 --> Total execution time: 0.0505
ERROR - 2022-03-16 11:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 11:24:42 --> Config Class Initialized
INFO - 2022-03-16 11:24:42 --> Hooks Class Initialized
DEBUG - 2022-03-16 11:24:42 --> UTF-8 Support Enabled
INFO - 2022-03-16 11:24:42 --> Utf8 Class Initialized
INFO - 2022-03-16 11:24:42 --> URI Class Initialized
DEBUG - 2022-03-16 11:24:42 --> No URI present. Default controller set.
INFO - 2022-03-16 11:24:42 --> Router Class Initialized
INFO - 2022-03-16 11:24:42 --> Output Class Initialized
INFO - 2022-03-16 11:24:42 --> Security Class Initialized
DEBUG - 2022-03-16 11:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 11:24:42 --> Input Class Initialized
INFO - 2022-03-16 11:24:42 --> Language Class Initialized
INFO - 2022-03-16 11:24:42 --> Loader Class Initialized
INFO - 2022-03-16 11:24:42 --> Helper loaded: url_helper
INFO - 2022-03-16 11:24:42 --> Helper loaded: form_helper
INFO - 2022-03-16 11:24:42 --> Helper loaded: common_helper
INFO - 2022-03-16 11:24:42 --> Database Driver Class Initialized
DEBUG - 2022-03-16 11:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 11:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 11:24:42 --> Controller Class Initialized
INFO - 2022-03-16 11:24:42 --> Form Validation Class Initialized
DEBUG - 2022-03-16 11:24:42 --> Encrypt Class Initialized
DEBUG - 2022-03-16 11:24:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 11:24:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 11:24:42 --> Email Class Initialized
INFO - 2022-03-16 11:24:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 11:24:42 --> Calendar Class Initialized
INFO - 2022-03-16 11:24:42 --> Model "Login_model" initialized
INFO - 2022-03-16 11:24:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 11:24:42 --> Final output sent to browser
DEBUG - 2022-03-16 11:24:42 --> Total execution time: 0.0758
ERROR - 2022-03-16 11:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 11:24:59 --> Config Class Initialized
INFO - 2022-03-16 11:24:59 --> Hooks Class Initialized
DEBUG - 2022-03-16 11:24:59 --> UTF-8 Support Enabled
INFO - 2022-03-16 11:24:59 --> Utf8 Class Initialized
INFO - 2022-03-16 11:24:59 --> URI Class Initialized
DEBUG - 2022-03-16 11:24:59 --> No URI present. Default controller set.
INFO - 2022-03-16 11:24:59 --> Router Class Initialized
INFO - 2022-03-16 11:24:59 --> Output Class Initialized
INFO - 2022-03-16 11:24:59 --> Security Class Initialized
DEBUG - 2022-03-16 11:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 11:24:59 --> Input Class Initialized
INFO - 2022-03-16 11:24:59 --> Language Class Initialized
INFO - 2022-03-16 11:24:59 --> Loader Class Initialized
INFO - 2022-03-16 11:24:59 --> Helper loaded: url_helper
INFO - 2022-03-16 11:24:59 --> Helper loaded: form_helper
INFO - 2022-03-16 11:24:59 --> Helper loaded: common_helper
INFO - 2022-03-16 11:24:59 --> Database Driver Class Initialized
DEBUG - 2022-03-16 11:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 11:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 11:24:59 --> Controller Class Initialized
INFO - 2022-03-16 11:24:59 --> Form Validation Class Initialized
DEBUG - 2022-03-16 11:24:59 --> Encrypt Class Initialized
DEBUG - 2022-03-16 11:24:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 11:24:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 11:24:59 --> Email Class Initialized
INFO - 2022-03-16 11:24:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 11:24:59 --> Calendar Class Initialized
INFO - 2022-03-16 11:24:59 --> Model "Login_model" initialized
INFO - 2022-03-16 11:24:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 11:24:59 --> Final output sent to browser
DEBUG - 2022-03-16 11:24:59 --> Total execution time: 0.0549
ERROR - 2022-03-16 14:17:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 14:17:10 --> Config Class Initialized
INFO - 2022-03-16 14:17:10 --> Hooks Class Initialized
DEBUG - 2022-03-16 14:17:10 --> UTF-8 Support Enabled
INFO - 2022-03-16 14:17:10 --> Utf8 Class Initialized
INFO - 2022-03-16 14:17:10 --> URI Class Initialized
DEBUG - 2022-03-16 14:17:10 --> No URI present. Default controller set.
INFO - 2022-03-16 14:17:10 --> Router Class Initialized
INFO - 2022-03-16 14:17:10 --> Output Class Initialized
INFO - 2022-03-16 14:17:10 --> Security Class Initialized
DEBUG - 2022-03-16 14:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 14:17:10 --> Input Class Initialized
INFO - 2022-03-16 14:17:10 --> Language Class Initialized
INFO - 2022-03-16 14:17:10 --> Loader Class Initialized
INFO - 2022-03-16 14:17:10 --> Helper loaded: url_helper
INFO - 2022-03-16 14:17:10 --> Helper loaded: form_helper
INFO - 2022-03-16 14:17:10 --> Helper loaded: common_helper
INFO - 2022-03-16 14:17:10 --> Database Driver Class Initialized
DEBUG - 2022-03-16 14:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 14:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 14:17:10 --> Controller Class Initialized
INFO - 2022-03-16 14:17:10 --> Form Validation Class Initialized
DEBUG - 2022-03-16 14:17:10 --> Encrypt Class Initialized
DEBUG - 2022-03-16 14:17:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:17:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 14:17:10 --> Email Class Initialized
INFO - 2022-03-16 14:17:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 14:17:10 --> Calendar Class Initialized
INFO - 2022-03-16 14:17:10 --> Model "Login_model" initialized
INFO - 2022-03-16 14:17:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 14:17:10 --> Final output sent to browser
DEBUG - 2022-03-16 14:17:10 --> Total execution time: 0.0445
ERROR - 2022-03-16 14:17:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 14:17:11 --> Config Class Initialized
INFO - 2022-03-16 14:17:11 --> Hooks Class Initialized
DEBUG - 2022-03-16 14:17:11 --> UTF-8 Support Enabled
INFO - 2022-03-16 14:17:11 --> Utf8 Class Initialized
INFO - 2022-03-16 14:17:11 --> URI Class Initialized
INFO - 2022-03-16 14:17:11 --> Router Class Initialized
INFO - 2022-03-16 14:17:11 --> Output Class Initialized
INFO - 2022-03-16 14:17:11 --> Security Class Initialized
DEBUG - 2022-03-16 14:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 14:17:11 --> Input Class Initialized
INFO - 2022-03-16 14:17:11 --> Language Class Initialized
ERROR - 2022-03-16 14:17:11 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-16 14:17:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 14:17:24 --> Config Class Initialized
INFO - 2022-03-16 14:17:24 --> Hooks Class Initialized
DEBUG - 2022-03-16 14:17:24 --> UTF-8 Support Enabled
INFO - 2022-03-16 14:17:24 --> Utf8 Class Initialized
INFO - 2022-03-16 14:17:24 --> URI Class Initialized
INFO - 2022-03-16 14:17:24 --> Router Class Initialized
INFO - 2022-03-16 14:17:24 --> Output Class Initialized
INFO - 2022-03-16 14:17:24 --> Security Class Initialized
DEBUG - 2022-03-16 14:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 14:17:24 --> Input Class Initialized
INFO - 2022-03-16 14:17:24 --> Language Class Initialized
INFO - 2022-03-16 14:17:24 --> Loader Class Initialized
INFO - 2022-03-16 14:17:24 --> Helper loaded: url_helper
INFO - 2022-03-16 14:17:24 --> Helper loaded: form_helper
INFO - 2022-03-16 14:17:24 --> Helper loaded: common_helper
INFO - 2022-03-16 14:17:24 --> Database Driver Class Initialized
DEBUG - 2022-03-16 14:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 14:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 14:17:24 --> Controller Class Initialized
INFO - 2022-03-16 14:17:24 --> Form Validation Class Initialized
DEBUG - 2022-03-16 14:17:24 --> Encrypt Class Initialized
DEBUG - 2022-03-16 14:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 14:17:24 --> Email Class Initialized
INFO - 2022-03-16 14:17:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 14:17:24 --> Calendar Class Initialized
INFO - 2022-03-16 14:17:24 --> Model "Login_model" initialized
INFO - 2022-03-16 14:17:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 14:17:24 --> Final output sent to browser
DEBUG - 2022-03-16 14:17:24 --> Total execution time: 0.0365
ERROR - 2022-03-16 14:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 14:17:25 --> Config Class Initialized
INFO - 2022-03-16 14:17:25 --> Hooks Class Initialized
DEBUG - 2022-03-16 14:17:25 --> UTF-8 Support Enabled
INFO - 2022-03-16 14:17:25 --> Utf8 Class Initialized
INFO - 2022-03-16 14:17:25 --> URI Class Initialized
INFO - 2022-03-16 14:17:25 --> Router Class Initialized
INFO - 2022-03-16 14:17:25 --> Output Class Initialized
INFO - 2022-03-16 14:17:25 --> Security Class Initialized
DEBUG - 2022-03-16 14:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 14:17:25 --> Input Class Initialized
INFO - 2022-03-16 14:17:25 --> Language Class Initialized
INFO - 2022-03-16 14:17:25 --> Loader Class Initialized
INFO - 2022-03-16 14:17:25 --> Helper loaded: url_helper
INFO - 2022-03-16 14:17:25 --> Helper loaded: form_helper
INFO - 2022-03-16 14:17:25 --> Helper loaded: common_helper
INFO - 2022-03-16 14:17:25 --> Database Driver Class Initialized
DEBUG - 2022-03-16 14:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 14:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 14:17:25 --> Controller Class Initialized
INFO - 2022-03-16 14:17:25 --> Form Validation Class Initialized
DEBUG - 2022-03-16 14:17:25 --> Encrypt Class Initialized
DEBUG - 2022-03-16 14:17:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:17:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 14:17:25 --> Email Class Initialized
INFO - 2022-03-16 14:17:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 14:17:25 --> Calendar Class Initialized
INFO - 2022-03-16 14:17:25 --> Model "Login_model" initialized
ERROR - 2022-03-16 14:17:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 14:17:26 --> Config Class Initialized
INFO - 2022-03-16 14:17:26 --> Hooks Class Initialized
DEBUG - 2022-03-16 14:17:26 --> UTF-8 Support Enabled
INFO - 2022-03-16 14:17:26 --> Utf8 Class Initialized
INFO - 2022-03-16 14:17:26 --> URI Class Initialized
INFO - 2022-03-16 14:17:26 --> Router Class Initialized
INFO - 2022-03-16 14:17:26 --> Output Class Initialized
INFO - 2022-03-16 14:17:26 --> Security Class Initialized
DEBUG - 2022-03-16 14:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 14:17:26 --> Input Class Initialized
INFO - 2022-03-16 14:17:26 --> Language Class Initialized
INFO - 2022-03-16 14:17:26 --> Loader Class Initialized
INFO - 2022-03-16 14:17:26 --> Helper loaded: url_helper
INFO - 2022-03-16 14:17:26 --> Helper loaded: form_helper
INFO - 2022-03-16 14:17:26 --> Helper loaded: common_helper
INFO - 2022-03-16 14:17:26 --> Database Driver Class Initialized
DEBUG - 2022-03-16 14:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 14:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 14:17:26 --> Controller Class Initialized
INFO - 2022-03-16 14:17:26 --> Form Validation Class Initialized
DEBUG - 2022-03-16 14:17:26 --> Encrypt Class Initialized
DEBUG - 2022-03-16 14:17:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:17:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 14:17:26 --> Email Class Initialized
INFO - 2022-03-16 14:17:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 14:17:26 --> Calendar Class Initialized
INFO - 2022-03-16 14:17:26 --> Model "Login_model" initialized
ERROR - 2022-03-16 14:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 14:17:27 --> Config Class Initialized
INFO - 2022-03-16 14:17:27 --> Hooks Class Initialized
DEBUG - 2022-03-16 14:17:27 --> UTF-8 Support Enabled
INFO - 2022-03-16 14:17:27 --> Utf8 Class Initialized
INFO - 2022-03-16 14:17:27 --> URI Class Initialized
DEBUG - 2022-03-16 14:17:27 --> No URI present. Default controller set.
INFO - 2022-03-16 14:17:27 --> Router Class Initialized
INFO - 2022-03-16 14:17:27 --> Output Class Initialized
INFO - 2022-03-16 14:17:27 --> Security Class Initialized
DEBUG - 2022-03-16 14:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 14:17:27 --> Input Class Initialized
INFO - 2022-03-16 14:17:27 --> Language Class Initialized
INFO - 2022-03-16 14:17:27 --> Loader Class Initialized
INFO - 2022-03-16 14:17:27 --> Helper loaded: url_helper
INFO - 2022-03-16 14:17:27 --> Helper loaded: form_helper
INFO - 2022-03-16 14:17:27 --> Helper loaded: common_helper
INFO - 2022-03-16 14:17:27 --> Database Driver Class Initialized
DEBUG - 2022-03-16 14:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 14:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 14:17:27 --> Controller Class Initialized
INFO - 2022-03-16 14:17:27 --> Form Validation Class Initialized
DEBUG - 2022-03-16 14:17:27 --> Encrypt Class Initialized
DEBUG - 2022-03-16 14:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:17:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 14:17:27 --> Email Class Initialized
INFO - 2022-03-16 14:17:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 14:17:27 --> Calendar Class Initialized
INFO - 2022-03-16 14:17:27 --> Model "Login_model" initialized
INFO - 2022-03-16 14:17:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 14:17:27 --> Final output sent to browser
DEBUG - 2022-03-16 14:17:27 --> Total execution time: 0.0339
ERROR - 2022-03-16 16:37:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 16:37:21 --> Config Class Initialized
INFO - 2022-03-16 16:37:21 --> Hooks Class Initialized
DEBUG - 2022-03-16 16:37:21 --> UTF-8 Support Enabled
INFO - 2022-03-16 16:37:21 --> Utf8 Class Initialized
INFO - 2022-03-16 16:37:21 --> URI Class Initialized
DEBUG - 2022-03-16 16:37:21 --> No URI present. Default controller set.
INFO - 2022-03-16 16:37:21 --> Router Class Initialized
INFO - 2022-03-16 16:37:21 --> Output Class Initialized
INFO - 2022-03-16 16:37:21 --> Security Class Initialized
DEBUG - 2022-03-16 16:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 16:37:21 --> Input Class Initialized
INFO - 2022-03-16 16:37:21 --> Language Class Initialized
INFO - 2022-03-16 16:37:21 --> Loader Class Initialized
INFO - 2022-03-16 16:37:21 --> Helper loaded: url_helper
INFO - 2022-03-16 16:37:21 --> Helper loaded: form_helper
INFO - 2022-03-16 16:37:21 --> Helper loaded: common_helper
INFO - 2022-03-16 16:37:21 --> Database Driver Class Initialized
DEBUG - 2022-03-16 16:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 16:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 16:37:21 --> Controller Class Initialized
INFO - 2022-03-16 16:37:21 --> Form Validation Class Initialized
DEBUG - 2022-03-16 16:37:21 --> Encrypt Class Initialized
DEBUG - 2022-03-16 16:37:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:37:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 16:37:21 --> Email Class Initialized
INFO - 2022-03-16 16:37:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 16:37:21 --> Calendar Class Initialized
INFO - 2022-03-16 16:37:21 --> Model "Login_model" initialized
INFO - 2022-03-16 16:37:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 16:37:21 --> Final output sent to browser
DEBUG - 2022-03-16 16:37:21 --> Total execution time: 0.0502
ERROR - 2022-03-16 17:26:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 17:26:16 --> Config Class Initialized
INFO - 2022-03-16 17:26:16 --> Hooks Class Initialized
DEBUG - 2022-03-16 17:26:16 --> UTF-8 Support Enabled
INFO - 2022-03-16 17:26:16 --> Utf8 Class Initialized
INFO - 2022-03-16 17:26:16 --> URI Class Initialized
DEBUG - 2022-03-16 17:26:16 --> No URI present. Default controller set.
INFO - 2022-03-16 17:26:16 --> Router Class Initialized
INFO - 2022-03-16 17:26:16 --> Output Class Initialized
INFO - 2022-03-16 17:26:16 --> Security Class Initialized
DEBUG - 2022-03-16 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 17:26:16 --> Input Class Initialized
INFO - 2022-03-16 17:26:16 --> Language Class Initialized
INFO - 2022-03-16 17:26:16 --> Loader Class Initialized
INFO - 2022-03-16 17:26:16 --> Helper loaded: url_helper
INFO - 2022-03-16 17:26:16 --> Helper loaded: form_helper
INFO - 2022-03-16 17:26:16 --> Helper loaded: common_helper
INFO - 2022-03-16 17:26:16 --> Database Driver Class Initialized
DEBUG - 2022-03-16 17:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 17:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 17:26:16 --> Controller Class Initialized
INFO - 2022-03-16 17:26:16 --> Form Validation Class Initialized
DEBUG - 2022-03-16 17:26:16 --> Encrypt Class Initialized
DEBUG - 2022-03-16 17:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 17:26:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 17:26:16 --> Email Class Initialized
INFO - 2022-03-16 17:26:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 17:26:16 --> Calendar Class Initialized
INFO - 2022-03-16 17:26:16 --> Model "Login_model" initialized
INFO - 2022-03-16 17:26:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 17:26:16 --> Final output sent to browser
DEBUG - 2022-03-16 17:26:16 --> Total execution time: 0.0353
ERROR - 2022-03-16 18:33:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 18:33:23 --> Config Class Initialized
INFO - 2022-03-16 18:33:23 --> Hooks Class Initialized
DEBUG - 2022-03-16 18:33:23 --> UTF-8 Support Enabled
INFO - 2022-03-16 18:33:23 --> Utf8 Class Initialized
INFO - 2022-03-16 18:33:23 --> URI Class Initialized
DEBUG - 2022-03-16 18:33:23 --> No URI present. Default controller set.
INFO - 2022-03-16 18:33:23 --> Router Class Initialized
INFO - 2022-03-16 18:33:23 --> Output Class Initialized
INFO - 2022-03-16 18:33:23 --> Security Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 18:33:23 --> Input Class Initialized
INFO - 2022-03-16 18:33:23 --> Language Class Initialized
INFO - 2022-03-16 18:33:23 --> Loader Class Initialized
INFO - 2022-03-16 18:33:23 --> Helper loaded: url_helper
INFO - 2022-03-16 18:33:23 --> Helper loaded: form_helper
INFO - 2022-03-16 18:33:23 --> Helper loaded: common_helper
INFO - 2022-03-16 18:33:23 --> Database Driver Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 18:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 18:33:23 --> Controller Class Initialized
INFO - 2022-03-16 18:33:23 --> Form Validation Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Encrypt Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 18:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 18:33:23 --> Email Class Initialized
INFO - 2022-03-16 18:33:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 18:33:23 --> Calendar Class Initialized
INFO - 2022-03-16 18:33:23 --> Model "Login_model" initialized
INFO - 2022-03-16 18:33:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 18:33:23 --> Final output sent to browser
DEBUG - 2022-03-16 18:33:23 --> Total execution time: 0.0269
ERROR - 2022-03-16 18:33:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 18:33:23 --> Config Class Initialized
INFO - 2022-03-16 18:33:23 --> Hooks Class Initialized
DEBUG - 2022-03-16 18:33:23 --> UTF-8 Support Enabled
INFO - 2022-03-16 18:33:23 --> Utf8 Class Initialized
INFO - 2022-03-16 18:33:23 --> URI Class Initialized
DEBUG - 2022-03-16 18:33:23 --> No URI present. Default controller set.
INFO - 2022-03-16 18:33:23 --> Router Class Initialized
INFO - 2022-03-16 18:33:23 --> Output Class Initialized
INFO - 2022-03-16 18:33:23 --> Security Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 18:33:23 --> Input Class Initialized
INFO - 2022-03-16 18:33:23 --> Language Class Initialized
INFO - 2022-03-16 18:33:23 --> Loader Class Initialized
INFO - 2022-03-16 18:33:23 --> Helper loaded: url_helper
INFO - 2022-03-16 18:33:23 --> Helper loaded: form_helper
INFO - 2022-03-16 18:33:23 --> Helper loaded: common_helper
INFO - 2022-03-16 18:33:23 --> Database Driver Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 18:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 18:33:23 --> Controller Class Initialized
INFO - 2022-03-16 18:33:23 --> Form Validation Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Encrypt Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 18:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 18:33:23 --> Email Class Initialized
INFO - 2022-03-16 18:33:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 18:33:23 --> Calendar Class Initialized
INFO - 2022-03-16 18:33:23 --> Model "Login_model" initialized
INFO - 2022-03-16 18:33:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 18:33:23 --> Final output sent to browser
DEBUG - 2022-03-16 18:33:23 --> Total execution time: 0.0243
ERROR - 2022-03-16 18:33:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 18:33:23 --> Config Class Initialized
INFO - 2022-03-16 18:33:23 --> Hooks Class Initialized
DEBUG - 2022-03-16 18:33:23 --> UTF-8 Support Enabled
INFO - 2022-03-16 18:33:23 --> Utf8 Class Initialized
INFO - 2022-03-16 18:33:23 --> URI Class Initialized
DEBUG - 2022-03-16 18:33:23 --> No URI present. Default controller set.
INFO - 2022-03-16 18:33:23 --> Router Class Initialized
INFO - 2022-03-16 18:33:23 --> Output Class Initialized
INFO - 2022-03-16 18:33:23 --> Security Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 18:33:23 --> Input Class Initialized
INFO - 2022-03-16 18:33:23 --> Language Class Initialized
INFO - 2022-03-16 18:33:23 --> Loader Class Initialized
INFO - 2022-03-16 18:33:23 --> Helper loaded: url_helper
INFO - 2022-03-16 18:33:23 --> Helper loaded: form_helper
INFO - 2022-03-16 18:33:23 --> Helper loaded: common_helper
INFO - 2022-03-16 18:33:23 --> Database Driver Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 18:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 18:33:23 --> Controller Class Initialized
INFO - 2022-03-16 18:33:23 --> Form Validation Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Encrypt Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 18:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 18:33:23 --> Email Class Initialized
INFO - 2022-03-16 18:33:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 18:33:23 --> Calendar Class Initialized
INFO - 2022-03-16 18:33:23 --> Model "Login_model" initialized
INFO - 2022-03-16 18:33:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 18:33:23 --> Final output sent to browser
DEBUG - 2022-03-16 18:33:23 --> Total execution time: 0.0264
ERROR - 2022-03-16 18:33:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 18:33:23 --> Config Class Initialized
INFO - 2022-03-16 18:33:23 --> Hooks Class Initialized
DEBUG - 2022-03-16 18:33:23 --> UTF-8 Support Enabled
INFO - 2022-03-16 18:33:23 --> Utf8 Class Initialized
INFO - 2022-03-16 18:33:23 --> URI Class Initialized
DEBUG - 2022-03-16 18:33:23 --> No URI present. Default controller set.
INFO - 2022-03-16 18:33:23 --> Router Class Initialized
INFO - 2022-03-16 18:33:23 --> Output Class Initialized
INFO - 2022-03-16 18:33:23 --> Security Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 18:33:23 --> Input Class Initialized
INFO - 2022-03-16 18:33:23 --> Language Class Initialized
INFO - 2022-03-16 18:33:23 --> Loader Class Initialized
INFO - 2022-03-16 18:33:23 --> Helper loaded: url_helper
INFO - 2022-03-16 18:33:23 --> Helper loaded: form_helper
INFO - 2022-03-16 18:33:23 --> Helper loaded: common_helper
INFO - 2022-03-16 18:33:23 --> Database Driver Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 18:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 18:33:23 --> Controller Class Initialized
INFO - 2022-03-16 18:33:23 --> Form Validation Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Encrypt Class Initialized
DEBUG - 2022-03-16 18:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 18:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 18:33:23 --> Email Class Initialized
INFO - 2022-03-16 18:33:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 18:33:23 --> Calendar Class Initialized
INFO - 2022-03-16 18:33:23 --> Model "Login_model" initialized
INFO - 2022-03-16 18:33:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 18:33:23 --> Final output sent to browser
DEBUG - 2022-03-16 18:33:23 --> Total execution time: 0.0247
ERROR - 2022-03-16 18:33:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 18:33:24 --> Config Class Initialized
INFO - 2022-03-16 18:33:24 --> Hooks Class Initialized
DEBUG - 2022-03-16 18:33:24 --> UTF-8 Support Enabled
INFO - 2022-03-16 18:33:24 --> Utf8 Class Initialized
INFO - 2022-03-16 18:33:24 --> URI Class Initialized
DEBUG - 2022-03-16 18:33:24 --> No URI present. Default controller set.
INFO - 2022-03-16 18:33:24 --> Router Class Initialized
INFO - 2022-03-16 18:33:24 --> Output Class Initialized
INFO - 2022-03-16 18:33:24 --> Security Class Initialized
DEBUG - 2022-03-16 18:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 18:33:24 --> Input Class Initialized
INFO - 2022-03-16 18:33:24 --> Language Class Initialized
INFO - 2022-03-16 18:33:24 --> Loader Class Initialized
INFO - 2022-03-16 18:33:24 --> Helper loaded: url_helper
INFO - 2022-03-16 18:33:24 --> Helper loaded: form_helper
INFO - 2022-03-16 18:33:24 --> Helper loaded: common_helper
INFO - 2022-03-16 18:33:24 --> Database Driver Class Initialized
DEBUG - 2022-03-16 18:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 18:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 18:33:24 --> Controller Class Initialized
INFO - 2022-03-16 18:33:24 --> Form Validation Class Initialized
DEBUG - 2022-03-16 18:33:24 --> Encrypt Class Initialized
DEBUG - 2022-03-16 18:33:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 18:33:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 18:33:24 --> Email Class Initialized
INFO - 2022-03-16 18:33:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 18:33:24 --> Calendar Class Initialized
INFO - 2022-03-16 18:33:24 --> Model "Login_model" initialized
INFO - 2022-03-16 18:33:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 18:33:24 --> Final output sent to browser
DEBUG - 2022-03-16 18:33:24 --> Total execution time: 0.0349
ERROR - 2022-03-16 19:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 19:37:05 --> Config Class Initialized
INFO - 2022-03-16 19:37:05 --> Hooks Class Initialized
DEBUG - 2022-03-16 19:37:05 --> UTF-8 Support Enabled
INFO - 2022-03-16 19:37:05 --> Utf8 Class Initialized
INFO - 2022-03-16 19:37:05 --> URI Class Initialized
DEBUG - 2022-03-16 19:37:05 --> No URI present. Default controller set.
INFO - 2022-03-16 19:37:05 --> Router Class Initialized
INFO - 2022-03-16 19:37:05 --> Output Class Initialized
INFO - 2022-03-16 19:37:05 --> Security Class Initialized
DEBUG - 2022-03-16 19:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 19:37:05 --> Input Class Initialized
INFO - 2022-03-16 19:37:05 --> Language Class Initialized
INFO - 2022-03-16 19:37:05 --> Loader Class Initialized
INFO - 2022-03-16 19:37:05 --> Helper loaded: url_helper
INFO - 2022-03-16 19:37:05 --> Helper loaded: form_helper
INFO - 2022-03-16 19:37:05 --> Helper loaded: common_helper
INFO - 2022-03-16 19:37:05 --> Database Driver Class Initialized
DEBUG - 2022-03-16 19:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 19:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 19:37:05 --> Controller Class Initialized
INFO - 2022-03-16 19:37:05 --> Form Validation Class Initialized
DEBUG - 2022-03-16 19:37:05 --> Encrypt Class Initialized
DEBUG - 2022-03-16 19:37:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 19:37:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 19:37:05 --> Email Class Initialized
INFO - 2022-03-16 19:37:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 19:37:05 --> Calendar Class Initialized
INFO - 2022-03-16 19:37:05 --> Model "Login_model" initialized
INFO - 2022-03-16 19:37:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 19:37:05 --> Final output sent to browser
DEBUG - 2022-03-16 19:37:05 --> Total execution time: 0.0328
ERROR - 2022-03-16 19:37:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-16 19:37:06 --> Config Class Initialized
INFO - 2022-03-16 19:37:06 --> Hooks Class Initialized
DEBUG - 2022-03-16 19:37:06 --> UTF-8 Support Enabled
INFO - 2022-03-16 19:37:06 --> Utf8 Class Initialized
INFO - 2022-03-16 19:37:06 --> URI Class Initialized
DEBUG - 2022-03-16 19:37:06 --> No URI present. Default controller set.
INFO - 2022-03-16 19:37:06 --> Router Class Initialized
INFO - 2022-03-16 19:37:06 --> Output Class Initialized
INFO - 2022-03-16 19:37:06 --> Security Class Initialized
DEBUG - 2022-03-16 19:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-16 19:37:06 --> Input Class Initialized
INFO - 2022-03-16 19:37:06 --> Language Class Initialized
INFO - 2022-03-16 19:37:06 --> Loader Class Initialized
INFO - 2022-03-16 19:37:06 --> Helper loaded: url_helper
INFO - 2022-03-16 19:37:06 --> Helper loaded: form_helper
INFO - 2022-03-16 19:37:06 --> Helper loaded: common_helper
INFO - 2022-03-16 19:37:06 --> Database Driver Class Initialized
DEBUG - 2022-03-16 19:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-16 19:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-16 19:37:06 --> Controller Class Initialized
INFO - 2022-03-16 19:37:06 --> Form Validation Class Initialized
DEBUG - 2022-03-16 19:37:06 --> Encrypt Class Initialized
DEBUG - 2022-03-16 19:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 19:37:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-16 19:37:06 --> Email Class Initialized
INFO - 2022-03-16 19:37:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-16 19:37:06 --> Calendar Class Initialized
INFO - 2022-03-16 19:37:06 --> Model "Login_model" initialized
INFO - 2022-03-16 19:37:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-16 19:37:06 --> Final output sent to browser
DEBUG - 2022-03-16 19:37:06 --> Total execution time: 0.0251
