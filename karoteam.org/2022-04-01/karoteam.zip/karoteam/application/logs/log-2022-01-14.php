<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-14 01:28:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 01:28:32 --> Config Class Initialized
INFO - 2022-01-14 01:28:32 --> Hooks Class Initialized
DEBUG - 2022-01-14 01:28:32 --> UTF-8 Support Enabled
INFO - 2022-01-14 01:28:32 --> Utf8 Class Initialized
INFO - 2022-01-14 01:28:32 --> URI Class Initialized
DEBUG - 2022-01-14 01:28:32 --> No URI present. Default controller set.
INFO - 2022-01-14 01:28:32 --> Router Class Initialized
INFO - 2022-01-14 01:28:32 --> Output Class Initialized
INFO - 2022-01-14 01:28:32 --> Security Class Initialized
DEBUG - 2022-01-14 01:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 01:28:32 --> Input Class Initialized
INFO - 2022-01-14 01:28:32 --> Language Class Initialized
INFO - 2022-01-14 01:28:32 --> Loader Class Initialized
INFO - 2022-01-14 01:28:32 --> Helper loaded: url_helper
INFO - 2022-01-14 01:28:32 --> Helper loaded: form_helper
INFO - 2022-01-14 01:28:32 --> Helper loaded: common_helper
INFO - 2022-01-14 01:28:32 --> Database Driver Class Initialized
DEBUG - 2022-01-14 01:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 01:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 01:28:32 --> Controller Class Initialized
INFO - 2022-01-14 01:28:32 --> Form Validation Class Initialized
DEBUG - 2022-01-14 01:28:32 --> Encrypt Class Initialized
DEBUG - 2022-01-14 01:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 01:28:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 01:28:32 --> Email Class Initialized
INFO - 2022-01-14 01:28:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 01:28:32 --> Calendar Class Initialized
INFO - 2022-01-14 01:28:32 --> Model "Login_model" initialized
INFO - 2022-01-14 01:28:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-14 01:28:32 --> Final output sent to browser
DEBUG - 2022-01-14 01:28:32 --> Total execution time: 0.0317
ERROR - 2022-01-14 08:15:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 08:15:12 --> Config Class Initialized
INFO - 2022-01-14 08:15:12 --> Hooks Class Initialized
DEBUG - 2022-01-14 08:15:12 --> UTF-8 Support Enabled
INFO - 2022-01-14 08:15:12 --> Utf8 Class Initialized
INFO - 2022-01-14 08:15:12 --> URI Class Initialized
DEBUG - 2022-01-14 08:15:12 --> No URI present. Default controller set.
INFO - 2022-01-14 08:15:12 --> Router Class Initialized
INFO - 2022-01-14 08:15:12 --> Output Class Initialized
INFO - 2022-01-14 08:15:12 --> Security Class Initialized
DEBUG - 2022-01-14 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 08:15:12 --> Input Class Initialized
INFO - 2022-01-14 08:15:12 --> Language Class Initialized
INFO - 2022-01-14 08:15:12 --> Loader Class Initialized
INFO - 2022-01-14 08:15:12 --> Helper loaded: url_helper
INFO - 2022-01-14 08:15:12 --> Helper loaded: form_helper
INFO - 2022-01-14 08:15:12 --> Helper loaded: common_helper
INFO - 2022-01-14 08:15:12 --> Database Driver Class Initialized
DEBUG - 2022-01-14 08:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 08:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 08:15:12 --> Controller Class Initialized
INFO - 2022-01-14 08:15:12 --> Form Validation Class Initialized
DEBUG - 2022-01-14 08:15:12 --> Encrypt Class Initialized
DEBUG - 2022-01-14 08:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 08:15:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 08:15:12 --> Email Class Initialized
INFO - 2022-01-14 08:15:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 08:15:12 --> Calendar Class Initialized
INFO - 2022-01-14 08:15:12 --> Model "Login_model" initialized
INFO - 2022-01-14 08:15:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-14 08:15:12 --> Final output sent to browser
DEBUG - 2022-01-14 08:15:12 --> Total execution time: 0.0387
ERROR - 2022-01-14 14:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 14:22:37 --> Config Class Initialized
INFO - 2022-01-14 14:22:37 --> Hooks Class Initialized
DEBUG - 2022-01-14 14:22:37 --> UTF-8 Support Enabled
INFO - 2022-01-14 14:22:37 --> Utf8 Class Initialized
INFO - 2022-01-14 14:22:37 --> URI Class Initialized
DEBUG - 2022-01-14 14:22:37 --> No URI present. Default controller set.
INFO - 2022-01-14 14:22:37 --> Router Class Initialized
INFO - 2022-01-14 14:22:37 --> Output Class Initialized
INFO - 2022-01-14 14:22:37 --> Security Class Initialized
DEBUG - 2022-01-14 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 14:22:37 --> Input Class Initialized
INFO - 2022-01-14 14:22:37 --> Language Class Initialized
INFO - 2022-01-14 14:22:38 --> Loader Class Initialized
INFO - 2022-01-14 14:22:38 --> Helper loaded: url_helper
INFO - 2022-01-14 14:22:38 --> Helper loaded: form_helper
INFO - 2022-01-14 14:22:38 --> Helper loaded: common_helper
INFO - 2022-01-14 14:22:38 --> Database Driver Class Initialized
DEBUG - 2022-01-14 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 14:22:38 --> Controller Class Initialized
INFO - 2022-01-14 14:22:38 --> Form Validation Class Initialized
DEBUG - 2022-01-14 14:22:38 --> Encrypt Class Initialized
DEBUG - 2022-01-14 14:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 14:22:38 --> Email Class Initialized
INFO - 2022-01-14 14:22:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 14:22:38 --> Calendar Class Initialized
INFO - 2022-01-14 14:22:38 --> Model "Login_model" initialized
INFO - 2022-01-14 14:22:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-14 14:22:38 --> Final output sent to browser
DEBUG - 2022-01-14 14:22:38 --> Total execution time: 0.0252
ERROR - 2022-01-14 14:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 14:22:38 --> Config Class Initialized
INFO - 2022-01-14 14:22:38 --> Hooks Class Initialized
DEBUG - 2022-01-14 14:22:38 --> UTF-8 Support Enabled
INFO - 2022-01-14 14:22:38 --> Utf8 Class Initialized
INFO - 2022-01-14 14:22:38 --> URI Class Initialized
INFO - 2022-01-14 14:22:38 --> Router Class Initialized
INFO - 2022-01-14 14:22:38 --> Output Class Initialized
INFO - 2022-01-14 14:22:38 --> Security Class Initialized
DEBUG - 2022-01-14 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 14:22:38 --> Input Class Initialized
INFO - 2022-01-14 14:22:38 --> Language Class Initialized
ERROR - 2022-01-14 14:22:38 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-01-14 14:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 14:22:49 --> Config Class Initialized
INFO - 2022-01-14 14:22:49 --> Hooks Class Initialized
DEBUG - 2022-01-14 14:22:49 --> UTF-8 Support Enabled
INFO - 2022-01-14 14:22:49 --> Utf8 Class Initialized
INFO - 2022-01-14 14:22:49 --> URI Class Initialized
INFO - 2022-01-14 14:22:49 --> Router Class Initialized
INFO - 2022-01-14 14:22:49 --> Output Class Initialized
INFO - 2022-01-14 14:22:49 --> Security Class Initialized
DEBUG - 2022-01-14 14:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 14:22:49 --> Input Class Initialized
INFO - 2022-01-14 14:22:49 --> Language Class Initialized
INFO - 2022-01-14 14:22:49 --> Loader Class Initialized
INFO - 2022-01-14 14:22:49 --> Helper loaded: url_helper
INFO - 2022-01-14 14:22:49 --> Helper loaded: form_helper
INFO - 2022-01-14 14:22:49 --> Helper loaded: common_helper
INFO - 2022-01-14 14:22:49 --> Database Driver Class Initialized
DEBUG - 2022-01-14 14:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 14:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 14:22:49 --> Controller Class Initialized
INFO - 2022-01-14 14:22:49 --> Form Validation Class Initialized
DEBUG - 2022-01-14 14:22:49 --> Encrypt Class Initialized
DEBUG - 2022-01-14 14:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:22:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 14:22:49 --> Email Class Initialized
INFO - 2022-01-14 14:22:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 14:22:49 --> Calendar Class Initialized
INFO - 2022-01-14 14:22:49 --> Model "Login_model" initialized
ERROR - 2022-01-14 14:22:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 14:22:50 --> Config Class Initialized
INFO - 2022-01-14 14:22:50 --> Hooks Class Initialized
DEBUG - 2022-01-14 14:22:50 --> UTF-8 Support Enabled
INFO - 2022-01-14 14:22:50 --> Utf8 Class Initialized
INFO - 2022-01-14 14:22:50 --> URI Class Initialized
INFO - 2022-01-14 14:22:50 --> Router Class Initialized
INFO - 2022-01-14 14:22:50 --> Output Class Initialized
INFO - 2022-01-14 14:22:50 --> Security Class Initialized
DEBUG - 2022-01-14 14:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 14:22:50 --> Input Class Initialized
INFO - 2022-01-14 14:22:50 --> Language Class Initialized
INFO - 2022-01-14 14:22:50 --> Loader Class Initialized
INFO - 2022-01-14 14:22:50 --> Helper loaded: url_helper
INFO - 2022-01-14 14:22:50 --> Helper loaded: form_helper
INFO - 2022-01-14 14:22:50 --> Helper loaded: common_helper
INFO - 2022-01-14 14:22:50 --> Database Driver Class Initialized
DEBUG - 2022-01-14 14:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 14:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 14:22:50 --> Controller Class Initialized
INFO - 2022-01-14 14:22:50 --> Form Validation Class Initialized
DEBUG - 2022-01-14 14:22:50 --> Encrypt Class Initialized
DEBUG - 2022-01-14 14:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:22:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 14:22:50 --> Email Class Initialized
INFO - 2022-01-14 14:22:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 14:22:50 --> Calendar Class Initialized
INFO - 2022-01-14 14:22:50 --> Model "Login_model" initialized
ERROR - 2022-01-14 14:22:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 14:22:50 --> Config Class Initialized
INFO - 2022-01-14 14:22:50 --> Hooks Class Initialized
DEBUG - 2022-01-14 14:22:50 --> UTF-8 Support Enabled
INFO - 2022-01-14 14:22:50 --> Utf8 Class Initialized
INFO - 2022-01-14 14:22:50 --> URI Class Initialized
DEBUG - 2022-01-14 14:22:50 --> No URI present. Default controller set.
INFO - 2022-01-14 14:22:50 --> Router Class Initialized
INFO - 2022-01-14 14:22:50 --> Output Class Initialized
INFO - 2022-01-14 14:22:50 --> Security Class Initialized
DEBUG - 2022-01-14 14:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 14:22:50 --> Input Class Initialized
INFO - 2022-01-14 14:22:50 --> Language Class Initialized
INFO - 2022-01-14 14:22:50 --> Loader Class Initialized
INFO - 2022-01-14 14:22:50 --> Helper loaded: url_helper
INFO - 2022-01-14 14:22:50 --> Helper loaded: form_helper
INFO - 2022-01-14 14:22:50 --> Helper loaded: common_helper
INFO - 2022-01-14 14:22:50 --> Database Driver Class Initialized
DEBUG - 2022-01-14 14:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 14:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 14:22:50 --> Controller Class Initialized
INFO - 2022-01-14 14:22:50 --> Form Validation Class Initialized
DEBUG - 2022-01-14 14:22:50 --> Encrypt Class Initialized
DEBUG - 2022-01-14 14:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:22:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 14:22:50 --> Email Class Initialized
INFO - 2022-01-14 14:22:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 14:22:50 --> Calendar Class Initialized
INFO - 2022-01-14 14:22:50 --> Model "Login_model" initialized
INFO - 2022-01-14 14:22:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-14 14:22:50 --> Final output sent to browser
DEBUG - 2022-01-14 14:22:50 --> Total execution time: 0.0262
ERROR - 2022-01-14 14:22:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 14:22:51 --> Config Class Initialized
INFO - 2022-01-14 14:22:51 --> Hooks Class Initialized
DEBUG - 2022-01-14 14:22:51 --> UTF-8 Support Enabled
INFO - 2022-01-14 14:22:51 --> Utf8 Class Initialized
INFO - 2022-01-14 14:22:51 --> URI Class Initialized
INFO - 2022-01-14 14:22:51 --> Router Class Initialized
INFO - 2022-01-14 14:22:51 --> Output Class Initialized
INFO - 2022-01-14 14:22:51 --> Security Class Initialized
DEBUG - 2022-01-14 14:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 14:22:51 --> Input Class Initialized
INFO - 2022-01-14 14:22:51 --> Language Class Initialized
INFO - 2022-01-14 14:22:51 --> Loader Class Initialized
INFO - 2022-01-14 14:22:51 --> Helper loaded: url_helper
INFO - 2022-01-14 14:22:51 --> Helper loaded: form_helper
INFO - 2022-01-14 14:22:51 --> Helper loaded: common_helper
INFO - 2022-01-14 14:22:51 --> Database Driver Class Initialized
DEBUG - 2022-01-14 14:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 14:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 14:22:51 --> Controller Class Initialized
INFO - 2022-01-14 14:22:51 --> Form Validation Class Initialized
DEBUG - 2022-01-14 14:22:51 --> Encrypt Class Initialized
DEBUG - 2022-01-14 14:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:22:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 14:22:51 --> Email Class Initialized
INFO - 2022-01-14 14:22:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 14:22:51 --> Calendar Class Initialized
INFO - 2022-01-14 14:22:51 --> Model "Login_model" initialized
INFO - 2022-01-14 14:22:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-14 14:22:51 --> Final output sent to browser
DEBUG - 2022-01-14 14:22:51 --> Total execution time: 0.0279
ERROR - 2022-01-14 15:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 15:23:38 --> Config Class Initialized
INFO - 2022-01-14 15:23:38 --> Hooks Class Initialized
DEBUG - 2022-01-14 15:23:38 --> UTF-8 Support Enabled
INFO - 2022-01-14 15:23:38 --> Utf8 Class Initialized
INFO - 2022-01-14 15:23:38 --> URI Class Initialized
DEBUG - 2022-01-14 15:23:38 --> No URI present. Default controller set.
INFO - 2022-01-14 15:23:38 --> Router Class Initialized
INFO - 2022-01-14 15:23:38 --> Output Class Initialized
INFO - 2022-01-14 15:23:38 --> Security Class Initialized
DEBUG - 2022-01-14 15:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 15:23:38 --> Input Class Initialized
INFO - 2022-01-14 15:23:38 --> Language Class Initialized
INFO - 2022-01-14 15:23:38 --> Loader Class Initialized
INFO - 2022-01-14 15:23:38 --> Helper loaded: url_helper
INFO - 2022-01-14 15:23:38 --> Helper loaded: form_helper
INFO - 2022-01-14 15:23:38 --> Helper loaded: common_helper
INFO - 2022-01-14 15:23:38 --> Database Driver Class Initialized
DEBUG - 2022-01-14 15:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 15:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 15:23:38 --> Controller Class Initialized
INFO - 2022-01-14 15:23:38 --> Form Validation Class Initialized
DEBUG - 2022-01-14 15:23:38 --> Encrypt Class Initialized
DEBUG - 2022-01-14 15:23:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:23:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 15:23:38 --> Email Class Initialized
INFO - 2022-01-14 15:23:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 15:23:38 --> Calendar Class Initialized
INFO - 2022-01-14 15:23:38 --> Model "Login_model" initialized
INFO - 2022-01-14 15:23:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-14 15:23:38 --> Final output sent to browser
DEBUG - 2022-01-14 15:23:38 --> Total execution time: 0.0288
ERROR - 2022-01-14 16:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 16:12:19 --> Config Class Initialized
INFO - 2022-01-14 16:12:19 --> Hooks Class Initialized
DEBUG - 2022-01-14 16:12:19 --> UTF-8 Support Enabled
INFO - 2022-01-14 16:12:19 --> Utf8 Class Initialized
INFO - 2022-01-14 16:12:19 --> URI Class Initialized
DEBUG - 2022-01-14 16:12:19 --> No URI present. Default controller set.
INFO - 2022-01-14 16:12:19 --> Router Class Initialized
INFO - 2022-01-14 16:12:19 --> Output Class Initialized
INFO - 2022-01-14 16:12:19 --> Security Class Initialized
DEBUG - 2022-01-14 16:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 16:12:19 --> Input Class Initialized
INFO - 2022-01-14 16:12:19 --> Language Class Initialized
INFO - 2022-01-14 16:12:19 --> Loader Class Initialized
INFO - 2022-01-14 16:12:19 --> Helper loaded: url_helper
INFO - 2022-01-14 16:12:19 --> Helper loaded: form_helper
INFO - 2022-01-14 16:12:19 --> Helper loaded: common_helper
INFO - 2022-01-14 16:12:19 --> Database Driver Class Initialized
DEBUG - 2022-01-14 16:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 16:12:19 --> Controller Class Initialized
INFO - 2022-01-14 16:12:19 --> Form Validation Class Initialized
DEBUG - 2022-01-14 16:12:19 --> Encrypt Class Initialized
DEBUG - 2022-01-14 16:12:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:12:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 16:12:19 --> Email Class Initialized
INFO - 2022-01-14 16:12:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 16:12:19 --> Calendar Class Initialized
INFO - 2022-01-14 16:12:19 --> Model "Login_model" initialized
INFO - 2022-01-14 16:12:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-14 16:12:19 --> Final output sent to browser
DEBUG - 2022-01-14 16:12:19 --> Total execution time: 0.0242
ERROR - 2022-01-14 22:22:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-01-14 22:22:44 --> Config Class Initialized
INFO - 2022-01-14 22:22:44 --> Hooks Class Initialized
DEBUG - 2022-01-14 22:22:44 --> UTF-8 Support Enabled
INFO - 2022-01-14 22:22:44 --> Utf8 Class Initialized
INFO - 2022-01-14 22:22:44 --> URI Class Initialized
DEBUG - 2022-01-14 22:22:44 --> No URI present. Default controller set.
INFO - 2022-01-14 22:22:44 --> Router Class Initialized
INFO - 2022-01-14 22:22:44 --> Output Class Initialized
INFO - 2022-01-14 22:22:44 --> Security Class Initialized
DEBUG - 2022-01-14 22:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-14 22:22:44 --> Input Class Initialized
INFO - 2022-01-14 22:22:44 --> Language Class Initialized
INFO - 2022-01-14 22:22:44 --> Loader Class Initialized
INFO - 2022-01-14 22:22:44 --> Helper loaded: url_helper
INFO - 2022-01-14 22:22:44 --> Helper loaded: form_helper
INFO - 2022-01-14 22:22:44 --> Helper loaded: common_helper
INFO - 2022-01-14 22:22:44 --> Database Driver Class Initialized
DEBUG - 2022-01-14 22:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-14 22:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-14 22:22:44 --> Controller Class Initialized
INFO - 2022-01-14 22:22:44 --> Form Validation Class Initialized
DEBUG - 2022-01-14 22:22:44 --> Encrypt Class Initialized
DEBUG - 2022-01-14 22:22:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 22:22:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-01-14 22:22:44 --> Email Class Initialized
INFO - 2022-01-14 22:22:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-01-14 22:22:44 --> Calendar Class Initialized
INFO - 2022-01-14 22:22:44 --> Model "Login_model" initialized
INFO - 2022-01-14 22:22:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-01-14 22:22:44 --> Final output sent to browser
DEBUG - 2022-01-14 22:22:44 --> Total execution time: 0.0352
