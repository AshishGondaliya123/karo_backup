<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-28 05:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 05:34:28 --> Config Class Initialized
INFO - 2021-12-28 05:34:28 --> Hooks Class Initialized
DEBUG - 2021-12-28 05:34:28 --> UTF-8 Support Enabled
INFO - 2021-12-28 05:34:28 --> Utf8 Class Initialized
INFO - 2021-12-28 05:34:28 --> URI Class Initialized
INFO - 2021-12-28 05:34:28 --> Router Class Initialized
INFO - 2021-12-28 05:34:28 --> Output Class Initialized
INFO - 2021-12-28 05:34:28 --> Security Class Initialized
DEBUG - 2021-12-28 05:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 05:34:28 --> Input Class Initialized
INFO - 2021-12-28 05:34:28 --> Language Class Initialized
ERROR - 2021-12-28 05:34:28 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-12-28 05:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 05:34:29 --> Config Class Initialized
INFO - 2021-12-28 05:34:29 --> Hooks Class Initialized
DEBUG - 2021-12-28 05:34:29 --> UTF-8 Support Enabled
INFO - 2021-12-28 05:34:29 --> Utf8 Class Initialized
INFO - 2021-12-28 05:34:29 --> URI Class Initialized
INFO - 2021-12-28 05:34:29 --> Router Class Initialized
INFO - 2021-12-28 05:34:29 --> Output Class Initialized
INFO - 2021-12-28 05:34:29 --> Security Class Initialized
DEBUG - 2021-12-28 05:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 05:34:29 --> Input Class Initialized
INFO - 2021-12-28 05:34:29 --> Language Class Initialized
ERROR - 2021-12-28 05:34:29 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-12-28 05:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 05:34:29 --> Config Class Initialized
INFO - 2021-12-28 05:34:29 --> Hooks Class Initialized
DEBUG - 2021-12-28 05:34:29 --> UTF-8 Support Enabled
INFO - 2021-12-28 05:34:29 --> Utf8 Class Initialized
INFO - 2021-12-28 05:34:29 --> URI Class Initialized
DEBUG - 2021-12-28 05:34:29 --> No URI present. Default controller set.
INFO - 2021-12-28 05:34:29 --> Router Class Initialized
INFO - 2021-12-28 05:34:29 --> Output Class Initialized
INFO - 2021-12-28 05:34:29 --> Security Class Initialized
DEBUG - 2021-12-28 05:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 05:34:29 --> Input Class Initialized
INFO - 2021-12-28 05:34:29 --> Language Class Initialized
INFO - 2021-12-28 05:34:29 --> Loader Class Initialized
INFO - 2021-12-28 05:34:29 --> Helper loaded: url_helper
INFO - 2021-12-28 05:34:29 --> Helper loaded: form_helper
INFO - 2021-12-28 05:34:29 --> Helper loaded: common_helper
INFO - 2021-12-28 05:34:29 --> Database Driver Class Initialized
DEBUG - 2021-12-28 05:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 05:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 05:34:29 --> Controller Class Initialized
INFO - 2021-12-28 05:34:29 --> Form Validation Class Initialized
DEBUG - 2021-12-28 05:34:29 --> Encrypt Class Initialized
DEBUG - 2021-12-28 05:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 05:34:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 05:34:29 --> Email Class Initialized
INFO - 2021-12-28 05:34:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 05:34:29 --> Calendar Class Initialized
INFO - 2021-12-28 05:34:29 --> Model "Login_model" initialized
INFO - 2021-12-28 05:34:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-28 05:34:29 --> Final output sent to browser
DEBUG - 2021-12-28 05:34:29 --> Total execution time: 0.0248
ERROR - 2021-12-28 05:46:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 05:46:38 --> Config Class Initialized
INFO - 2021-12-28 05:46:38 --> Hooks Class Initialized
DEBUG - 2021-12-28 05:46:38 --> UTF-8 Support Enabled
INFO - 2021-12-28 05:46:38 --> Utf8 Class Initialized
INFO - 2021-12-28 05:46:38 --> URI Class Initialized
DEBUG - 2021-12-28 05:46:38 --> No URI present. Default controller set.
INFO - 2021-12-28 05:46:38 --> Router Class Initialized
INFO - 2021-12-28 05:46:38 --> Output Class Initialized
INFO - 2021-12-28 05:46:38 --> Security Class Initialized
DEBUG - 2021-12-28 05:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 05:46:38 --> Input Class Initialized
INFO - 2021-12-28 05:46:38 --> Language Class Initialized
INFO - 2021-12-28 05:46:38 --> Loader Class Initialized
INFO - 2021-12-28 05:46:38 --> Helper loaded: url_helper
INFO - 2021-12-28 05:46:38 --> Helper loaded: form_helper
INFO - 2021-12-28 05:46:38 --> Helper loaded: common_helper
INFO - 2021-12-28 05:46:38 --> Database Driver Class Initialized
DEBUG - 2021-12-28 05:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 05:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 05:46:38 --> Controller Class Initialized
INFO - 2021-12-28 05:46:38 --> Form Validation Class Initialized
DEBUG - 2021-12-28 05:46:38 --> Encrypt Class Initialized
DEBUG - 2021-12-28 05:46:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 05:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 05:46:38 --> Email Class Initialized
INFO - 2021-12-28 05:46:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 05:46:38 --> Calendar Class Initialized
INFO - 2021-12-28 05:46:38 --> Model "Login_model" initialized
INFO - 2021-12-28 05:46:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-28 05:46:38 --> Final output sent to browser
DEBUG - 2021-12-28 05:46:38 --> Total execution time: 0.0364
ERROR - 2021-12-28 13:21:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 13:21:17 --> Config Class Initialized
INFO - 2021-12-28 13:21:17 --> Hooks Class Initialized
DEBUG - 2021-12-28 13:21:17 --> UTF-8 Support Enabled
INFO - 2021-12-28 13:21:17 --> Utf8 Class Initialized
INFO - 2021-12-28 13:21:17 --> URI Class Initialized
DEBUG - 2021-12-28 13:21:17 --> No URI present. Default controller set.
INFO - 2021-12-28 13:21:17 --> Router Class Initialized
INFO - 2021-12-28 13:21:17 --> Output Class Initialized
INFO - 2021-12-28 13:21:17 --> Security Class Initialized
DEBUG - 2021-12-28 13:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 13:21:17 --> Input Class Initialized
INFO - 2021-12-28 13:21:17 --> Language Class Initialized
INFO - 2021-12-28 13:21:17 --> Loader Class Initialized
INFO - 2021-12-28 13:21:17 --> Helper loaded: url_helper
INFO - 2021-12-28 13:21:17 --> Helper loaded: form_helper
INFO - 2021-12-28 13:21:17 --> Helper loaded: common_helper
INFO - 2021-12-28 13:21:17 --> Database Driver Class Initialized
DEBUG - 2021-12-28 13:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 13:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 13:21:17 --> Controller Class Initialized
INFO - 2021-12-28 13:21:17 --> Form Validation Class Initialized
DEBUG - 2021-12-28 13:21:17 --> Encrypt Class Initialized
DEBUG - 2021-12-28 13:21:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:21:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 13:21:17 --> Email Class Initialized
INFO - 2021-12-28 13:21:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 13:21:17 --> Calendar Class Initialized
INFO - 2021-12-28 13:21:17 --> Model "Login_model" initialized
INFO - 2021-12-28 13:21:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-28 13:21:17 --> Final output sent to browser
DEBUG - 2021-12-28 13:21:17 --> Total execution time: 0.0264
ERROR - 2021-12-28 13:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 13:59:11 --> Config Class Initialized
INFO - 2021-12-28 13:59:11 --> Hooks Class Initialized
DEBUG - 2021-12-28 13:59:11 --> UTF-8 Support Enabled
INFO - 2021-12-28 13:59:11 --> Utf8 Class Initialized
INFO - 2021-12-28 13:59:11 --> URI Class Initialized
DEBUG - 2021-12-28 13:59:11 --> No URI present. Default controller set.
INFO - 2021-12-28 13:59:11 --> Router Class Initialized
INFO - 2021-12-28 13:59:11 --> Output Class Initialized
INFO - 2021-12-28 13:59:11 --> Security Class Initialized
DEBUG - 2021-12-28 13:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 13:59:11 --> Input Class Initialized
INFO - 2021-12-28 13:59:11 --> Language Class Initialized
INFO - 2021-12-28 13:59:11 --> Loader Class Initialized
INFO - 2021-12-28 13:59:11 --> Helper loaded: url_helper
INFO - 2021-12-28 13:59:11 --> Helper loaded: form_helper
INFO - 2021-12-28 13:59:11 --> Helper loaded: common_helper
INFO - 2021-12-28 13:59:11 --> Database Driver Class Initialized
DEBUG - 2021-12-28 13:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 13:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 13:59:11 --> Controller Class Initialized
INFO - 2021-12-28 13:59:11 --> Form Validation Class Initialized
DEBUG - 2021-12-28 13:59:11 --> Encrypt Class Initialized
DEBUG - 2021-12-28 13:59:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:59:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 13:59:11 --> Email Class Initialized
INFO - 2021-12-28 13:59:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 13:59:11 --> Calendar Class Initialized
INFO - 2021-12-28 13:59:11 --> Model "Login_model" initialized
INFO - 2021-12-28 13:59:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-28 13:59:11 --> Final output sent to browser
DEBUG - 2021-12-28 13:59:11 --> Total execution time: 0.0236
ERROR - 2021-12-28 14:16:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 14:16:52 --> Config Class Initialized
INFO - 2021-12-28 14:16:52 --> Hooks Class Initialized
DEBUG - 2021-12-28 14:16:52 --> UTF-8 Support Enabled
INFO - 2021-12-28 14:16:52 --> Utf8 Class Initialized
INFO - 2021-12-28 14:16:52 --> URI Class Initialized
DEBUG - 2021-12-28 14:16:52 --> No URI present. Default controller set.
INFO - 2021-12-28 14:16:52 --> Router Class Initialized
INFO - 2021-12-28 14:16:52 --> Output Class Initialized
INFO - 2021-12-28 14:16:52 --> Security Class Initialized
DEBUG - 2021-12-28 14:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 14:16:52 --> Input Class Initialized
INFO - 2021-12-28 14:16:52 --> Language Class Initialized
INFO - 2021-12-28 14:16:52 --> Loader Class Initialized
INFO - 2021-12-28 14:16:52 --> Helper loaded: url_helper
INFO - 2021-12-28 14:16:52 --> Helper loaded: form_helper
INFO - 2021-12-28 14:16:52 --> Helper loaded: common_helper
INFO - 2021-12-28 14:16:52 --> Database Driver Class Initialized
DEBUG - 2021-12-28 14:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 14:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 14:16:52 --> Controller Class Initialized
INFO - 2021-12-28 14:16:52 --> Form Validation Class Initialized
DEBUG - 2021-12-28 14:16:52 --> Encrypt Class Initialized
DEBUG - 2021-12-28 14:16:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:16:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 14:16:52 --> Email Class Initialized
INFO - 2021-12-28 14:16:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 14:16:52 --> Calendar Class Initialized
INFO - 2021-12-28 14:16:52 --> Model "Login_model" initialized
INFO - 2021-12-28 14:16:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-28 14:16:52 --> Final output sent to browser
DEBUG - 2021-12-28 14:16:52 --> Total execution time: 0.0260
ERROR - 2021-12-28 14:16:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 14:16:53 --> Config Class Initialized
INFO - 2021-12-28 14:16:53 --> Hooks Class Initialized
DEBUG - 2021-12-28 14:16:53 --> UTF-8 Support Enabled
INFO - 2021-12-28 14:16:53 --> Utf8 Class Initialized
INFO - 2021-12-28 14:16:53 --> URI Class Initialized
INFO - 2021-12-28 14:16:53 --> Router Class Initialized
INFO - 2021-12-28 14:16:53 --> Output Class Initialized
INFO - 2021-12-28 14:16:53 --> Security Class Initialized
DEBUG - 2021-12-28 14:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 14:16:53 --> Input Class Initialized
INFO - 2021-12-28 14:16:53 --> Language Class Initialized
ERROR - 2021-12-28 14:16:53 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-28 14:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 14:17:47 --> Config Class Initialized
INFO - 2021-12-28 14:17:47 --> Hooks Class Initialized
DEBUG - 2021-12-28 14:17:47 --> UTF-8 Support Enabled
INFO - 2021-12-28 14:17:47 --> Utf8 Class Initialized
INFO - 2021-12-28 14:17:47 --> URI Class Initialized
INFO - 2021-12-28 14:17:47 --> Router Class Initialized
INFO - 2021-12-28 14:17:47 --> Output Class Initialized
INFO - 2021-12-28 14:17:47 --> Security Class Initialized
DEBUG - 2021-12-28 14:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 14:17:47 --> Input Class Initialized
INFO - 2021-12-28 14:17:47 --> Language Class Initialized
INFO - 2021-12-28 14:17:47 --> Loader Class Initialized
INFO - 2021-12-28 14:17:47 --> Helper loaded: url_helper
INFO - 2021-12-28 14:17:47 --> Helper loaded: form_helper
INFO - 2021-12-28 14:17:47 --> Helper loaded: common_helper
INFO - 2021-12-28 14:17:47 --> Database Driver Class Initialized
DEBUG - 2021-12-28 14:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 14:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 14:17:47 --> Controller Class Initialized
INFO - 2021-12-28 14:17:47 --> Form Validation Class Initialized
DEBUG - 2021-12-28 14:17:47 --> Encrypt Class Initialized
DEBUG - 2021-12-28 14:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:17:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 14:17:47 --> Email Class Initialized
INFO - 2021-12-28 14:17:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 14:17:47 --> Calendar Class Initialized
INFO - 2021-12-28 14:17:47 --> Model "Login_model" initialized
ERROR - 2021-12-28 14:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 14:17:47 --> Config Class Initialized
INFO - 2021-12-28 14:17:47 --> Hooks Class Initialized
DEBUG - 2021-12-28 14:17:47 --> UTF-8 Support Enabled
INFO - 2021-12-28 14:17:47 --> Utf8 Class Initialized
INFO - 2021-12-28 14:17:47 --> URI Class Initialized
INFO - 2021-12-28 14:17:47 --> Router Class Initialized
INFO - 2021-12-28 14:17:47 --> Output Class Initialized
INFO - 2021-12-28 14:17:47 --> Security Class Initialized
DEBUG - 2021-12-28 14:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 14:17:47 --> Input Class Initialized
INFO - 2021-12-28 14:17:47 --> Language Class Initialized
INFO - 2021-12-28 14:17:47 --> Loader Class Initialized
INFO - 2021-12-28 14:17:47 --> Helper loaded: url_helper
INFO - 2021-12-28 14:17:47 --> Helper loaded: form_helper
INFO - 2021-12-28 14:17:47 --> Helper loaded: common_helper
INFO - 2021-12-28 14:17:47 --> Database Driver Class Initialized
DEBUG - 2021-12-28 14:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 14:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 14:17:47 --> Controller Class Initialized
INFO - 2021-12-28 14:17:47 --> Form Validation Class Initialized
DEBUG - 2021-12-28 14:17:47 --> Encrypt Class Initialized
DEBUG - 2021-12-28 14:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:17:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 14:17:47 --> Email Class Initialized
INFO - 2021-12-28 14:17:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 14:17:47 --> Calendar Class Initialized
INFO - 2021-12-28 14:17:47 --> Model "Login_model" initialized
ERROR - 2021-12-28 14:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 14:17:48 --> Config Class Initialized
INFO - 2021-12-28 14:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-28 14:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-28 14:17:48 --> Utf8 Class Initialized
INFO - 2021-12-28 14:17:48 --> URI Class Initialized
INFO - 2021-12-28 14:17:48 --> Router Class Initialized
INFO - 2021-12-28 14:17:48 --> Output Class Initialized
INFO - 2021-12-28 14:17:48 --> Security Class Initialized
DEBUG - 2021-12-28 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 14:17:48 --> Input Class Initialized
INFO - 2021-12-28 14:17:48 --> Language Class Initialized
INFO - 2021-12-28 14:17:48 --> Loader Class Initialized
INFO - 2021-12-28 14:17:48 --> Helper loaded: url_helper
INFO - 2021-12-28 14:17:48 --> Helper loaded: form_helper
INFO - 2021-12-28 14:17:48 --> Helper loaded: common_helper
INFO - 2021-12-28 14:17:48 --> Database Driver Class Initialized
DEBUG - 2021-12-28 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 14:17:48 --> Controller Class Initialized
INFO - 2021-12-28 14:17:48 --> Form Validation Class Initialized
DEBUG - 2021-12-28 14:17:48 --> Encrypt Class Initialized
DEBUG - 2021-12-28 14:17:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:17:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 14:17:48 --> Email Class Initialized
INFO - 2021-12-28 14:17:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 14:17:48 --> Calendar Class Initialized
INFO - 2021-12-28 14:17:48 --> Model "Login_model" initialized
INFO - 2021-12-28 14:17:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-28 14:17:48 --> Final output sent to browser
DEBUG - 2021-12-28 14:17:48 --> Total execution time: 0.0250
ERROR - 2021-12-28 14:17:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 14:17:49 --> Config Class Initialized
INFO - 2021-12-28 14:17:49 --> Hooks Class Initialized
DEBUG - 2021-12-28 14:17:49 --> UTF-8 Support Enabled
INFO - 2021-12-28 14:17:49 --> Utf8 Class Initialized
INFO - 2021-12-28 14:17:49 --> URI Class Initialized
DEBUG - 2021-12-28 14:17:49 --> No URI present. Default controller set.
INFO - 2021-12-28 14:17:49 --> Router Class Initialized
INFO - 2021-12-28 14:17:49 --> Output Class Initialized
INFO - 2021-12-28 14:17:49 --> Security Class Initialized
DEBUG - 2021-12-28 14:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 14:17:49 --> Input Class Initialized
INFO - 2021-12-28 14:17:49 --> Language Class Initialized
INFO - 2021-12-28 14:17:49 --> Loader Class Initialized
INFO - 2021-12-28 14:17:49 --> Helper loaded: url_helper
INFO - 2021-12-28 14:17:49 --> Helper loaded: form_helper
INFO - 2021-12-28 14:17:49 --> Helper loaded: common_helper
INFO - 2021-12-28 14:17:49 --> Database Driver Class Initialized
DEBUG - 2021-12-28 14:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 14:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 14:17:49 --> Controller Class Initialized
INFO - 2021-12-28 14:17:49 --> Form Validation Class Initialized
DEBUG - 2021-12-28 14:17:49 --> Encrypt Class Initialized
DEBUG - 2021-12-28 14:17:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:17:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 14:17:49 --> Email Class Initialized
INFO - 2021-12-28 14:17:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 14:17:49 --> Calendar Class Initialized
INFO - 2021-12-28 14:17:49 --> Model "Login_model" initialized
INFO - 2021-12-28 14:17:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-28 14:17:49 --> Final output sent to browser
DEBUG - 2021-12-28 14:17:49 --> Total execution time: 0.0235
ERROR - 2021-12-28 15:22:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-28 15:22:23 --> Config Class Initialized
INFO - 2021-12-28 15:22:23 --> Hooks Class Initialized
DEBUG - 2021-12-28 15:22:23 --> UTF-8 Support Enabled
INFO - 2021-12-28 15:22:23 --> Utf8 Class Initialized
INFO - 2021-12-28 15:22:23 --> URI Class Initialized
DEBUG - 2021-12-28 15:22:23 --> No URI present. Default controller set.
INFO - 2021-12-28 15:22:23 --> Router Class Initialized
INFO - 2021-12-28 15:22:23 --> Output Class Initialized
INFO - 2021-12-28 15:22:23 --> Security Class Initialized
DEBUG - 2021-12-28 15:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-28 15:22:23 --> Input Class Initialized
INFO - 2021-12-28 15:22:23 --> Language Class Initialized
INFO - 2021-12-28 15:22:23 --> Loader Class Initialized
INFO - 2021-12-28 15:22:23 --> Helper loaded: url_helper
INFO - 2021-12-28 15:22:23 --> Helper loaded: form_helper
INFO - 2021-12-28 15:22:23 --> Helper loaded: common_helper
INFO - 2021-12-28 15:22:23 --> Database Driver Class Initialized
DEBUG - 2021-12-28 15:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-28 15:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-28 15:22:23 --> Controller Class Initialized
INFO - 2021-12-28 15:22:23 --> Form Validation Class Initialized
DEBUG - 2021-12-28 15:22:23 --> Encrypt Class Initialized
DEBUG - 2021-12-28 15:22:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:22:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-28 15:22:23 --> Email Class Initialized
INFO - 2021-12-28 15:22:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-28 15:22:23 --> Calendar Class Initialized
INFO - 2021-12-28 15:22:23 --> Model "Login_model" initialized
INFO - 2021-12-28 15:22:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-28 15:22:23 --> Final output sent to browser
DEBUG - 2021-12-28 15:22:23 --> Total execution time: 0.0253
