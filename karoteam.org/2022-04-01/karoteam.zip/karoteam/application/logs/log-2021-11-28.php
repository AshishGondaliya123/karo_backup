<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-28 00:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 00:24:59 --> Config Class Initialized
INFO - 2021-11-28 00:24:59 --> Hooks Class Initialized
DEBUG - 2021-11-28 00:24:59 --> UTF-8 Support Enabled
INFO - 2021-11-28 00:24:59 --> Utf8 Class Initialized
INFO - 2021-11-28 00:24:59 --> URI Class Initialized
DEBUG - 2021-11-28 00:24:59 --> No URI present. Default controller set.
INFO - 2021-11-28 00:24:59 --> Router Class Initialized
INFO - 2021-11-28 00:24:59 --> Output Class Initialized
INFO - 2021-11-28 00:24:59 --> Security Class Initialized
DEBUG - 2021-11-28 00:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 00:24:59 --> Input Class Initialized
INFO - 2021-11-28 00:24:59 --> Language Class Initialized
INFO - 2021-11-28 00:24:59 --> Loader Class Initialized
INFO - 2021-11-28 00:24:59 --> Helper loaded: url_helper
INFO - 2021-11-28 00:24:59 --> Helper loaded: form_helper
INFO - 2021-11-28 00:24:59 --> Helper loaded: common_helper
INFO - 2021-11-28 00:24:59 --> Database Driver Class Initialized
DEBUG - 2021-11-28 00:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 00:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 00:24:59 --> Controller Class Initialized
INFO - 2021-11-28 00:24:59 --> Form Validation Class Initialized
DEBUG - 2021-11-28 00:24:59 --> Encrypt Class Initialized
DEBUG - 2021-11-28 00:24:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 00:24:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 00:24:59 --> Email Class Initialized
INFO - 2021-11-28 00:24:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 00:24:59 --> Calendar Class Initialized
INFO - 2021-11-28 00:24:59 --> Model "Login_model" initialized
INFO - 2021-11-28 00:24:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 00:24:59 --> Final output sent to browser
DEBUG - 2021-11-28 00:24:59 --> Total execution time: 0.0303
ERROR - 2021-11-28 01:56:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 01:56:55 --> Config Class Initialized
INFO - 2021-11-28 01:56:55 --> Hooks Class Initialized
DEBUG - 2021-11-28 01:56:55 --> UTF-8 Support Enabled
INFO - 2021-11-28 01:56:55 --> Utf8 Class Initialized
INFO - 2021-11-28 01:56:55 --> URI Class Initialized
DEBUG - 2021-11-28 01:56:55 --> No URI present. Default controller set.
INFO - 2021-11-28 01:56:55 --> Router Class Initialized
INFO - 2021-11-28 01:56:55 --> Output Class Initialized
INFO - 2021-11-28 01:56:55 --> Security Class Initialized
DEBUG - 2021-11-28 01:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 01:56:55 --> Input Class Initialized
INFO - 2021-11-28 01:56:55 --> Language Class Initialized
INFO - 2021-11-28 01:56:55 --> Loader Class Initialized
INFO - 2021-11-28 01:56:55 --> Helper loaded: url_helper
INFO - 2021-11-28 01:56:55 --> Helper loaded: form_helper
INFO - 2021-11-28 01:56:55 --> Helper loaded: common_helper
INFO - 2021-11-28 01:56:55 --> Database Driver Class Initialized
DEBUG - 2021-11-28 01:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 01:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 01:56:55 --> Controller Class Initialized
INFO - 2021-11-28 01:56:55 --> Form Validation Class Initialized
DEBUG - 2021-11-28 01:56:55 --> Encrypt Class Initialized
DEBUG - 2021-11-28 01:56:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 01:56:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 01:56:55 --> Email Class Initialized
INFO - 2021-11-28 01:56:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 01:56:55 --> Calendar Class Initialized
INFO - 2021-11-28 01:56:55 --> Model "Login_model" initialized
INFO - 2021-11-28 01:56:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 01:56:55 --> Final output sent to browser
DEBUG - 2021-11-28 01:56:55 --> Total execution time: 0.0233
ERROR - 2021-11-28 05:16:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 05:16:13 --> Config Class Initialized
INFO - 2021-11-28 05:16:13 --> Hooks Class Initialized
DEBUG - 2021-11-28 05:16:13 --> UTF-8 Support Enabled
INFO - 2021-11-28 05:16:13 --> Utf8 Class Initialized
INFO - 2021-11-28 05:16:13 --> URI Class Initialized
DEBUG - 2021-11-28 05:16:13 --> No URI present. Default controller set.
INFO - 2021-11-28 05:16:13 --> Router Class Initialized
INFO - 2021-11-28 05:16:13 --> Output Class Initialized
INFO - 2021-11-28 05:16:13 --> Security Class Initialized
DEBUG - 2021-11-28 05:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 05:16:13 --> Input Class Initialized
INFO - 2021-11-28 05:16:13 --> Language Class Initialized
INFO - 2021-11-28 05:16:13 --> Loader Class Initialized
INFO - 2021-11-28 05:16:13 --> Helper loaded: url_helper
INFO - 2021-11-28 05:16:13 --> Helper loaded: form_helper
INFO - 2021-11-28 05:16:13 --> Helper loaded: common_helper
INFO - 2021-11-28 05:16:13 --> Database Driver Class Initialized
DEBUG - 2021-11-28 05:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 05:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 05:16:13 --> Controller Class Initialized
INFO - 2021-11-28 05:16:13 --> Form Validation Class Initialized
DEBUG - 2021-11-28 05:16:13 --> Encrypt Class Initialized
DEBUG - 2021-11-28 05:16:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 05:16:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 05:16:13 --> Email Class Initialized
INFO - 2021-11-28 05:16:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 05:16:13 --> Calendar Class Initialized
INFO - 2021-11-28 05:16:13 --> Model "Login_model" initialized
INFO - 2021-11-28 05:16:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 05:16:13 --> Final output sent to browser
DEBUG - 2021-11-28 05:16:13 --> Total execution time: 0.0280
ERROR - 2021-11-28 10:12:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 10:12:50 --> Config Class Initialized
INFO - 2021-11-28 10:12:50 --> Hooks Class Initialized
DEBUG - 2021-11-28 10:12:50 --> UTF-8 Support Enabled
INFO - 2021-11-28 10:12:50 --> Utf8 Class Initialized
INFO - 2021-11-28 10:12:50 --> URI Class Initialized
DEBUG - 2021-11-28 10:12:50 --> No URI present. Default controller set.
INFO - 2021-11-28 10:12:50 --> Router Class Initialized
INFO - 2021-11-28 10:12:50 --> Output Class Initialized
INFO - 2021-11-28 10:12:50 --> Security Class Initialized
DEBUG - 2021-11-28 10:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 10:12:50 --> Input Class Initialized
INFO - 2021-11-28 10:12:50 --> Language Class Initialized
INFO - 2021-11-28 10:12:50 --> Loader Class Initialized
INFO - 2021-11-28 10:12:50 --> Helper loaded: url_helper
INFO - 2021-11-28 10:12:50 --> Helper loaded: form_helper
INFO - 2021-11-28 10:12:50 --> Helper loaded: common_helper
INFO - 2021-11-28 10:12:50 --> Database Driver Class Initialized
DEBUG - 2021-11-28 10:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 10:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 10:12:50 --> Controller Class Initialized
INFO - 2021-11-28 10:12:50 --> Form Validation Class Initialized
DEBUG - 2021-11-28 10:12:50 --> Encrypt Class Initialized
DEBUG - 2021-11-28 10:12:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 10:12:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 10:12:50 --> Email Class Initialized
INFO - 2021-11-28 10:12:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 10:12:50 --> Calendar Class Initialized
INFO - 2021-11-28 10:12:50 --> Model "Login_model" initialized
INFO - 2021-11-28 10:12:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 10:12:50 --> Final output sent to browser
DEBUG - 2021-11-28 10:12:50 --> Total execution time: 0.0236
ERROR - 2021-11-28 10:12:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 10:12:51 --> Config Class Initialized
INFO - 2021-11-28 10:12:51 --> Hooks Class Initialized
DEBUG - 2021-11-28 10:12:51 --> UTF-8 Support Enabled
INFO - 2021-11-28 10:12:51 --> Utf8 Class Initialized
INFO - 2021-11-28 10:12:51 --> URI Class Initialized
DEBUG - 2021-11-28 10:12:51 --> No URI present. Default controller set.
INFO - 2021-11-28 10:12:51 --> Router Class Initialized
INFO - 2021-11-28 10:12:51 --> Output Class Initialized
INFO - 2021-11-28 10:12:51 --> Security Class Initialized
DEBUG - 2021-11-28 10:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 10:12:51 --> Input Class Initialized
INFO - 2021-11-28 10:12:51 --> Language Class Initialized
INFO - 2021-11-28 10:12:51 --> Loader Class Initialized
INFO - 2021-11-28 10:12:51 --> Helper loaded: url_helper
INFO - 2021-11-28 10:12:51 --> Helper loaded: form_helper
INFO - 2021-11-28 10:12:51 --> Helper loaded: common_helper
INFO - 2021-11-28 10:12:51 --> Database Driver Class Initialized
DEBUG - 2021-11-28 10:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 10:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 10:12:51 --> Controller Class Initialized
INFO - 2021-11-28 10:12:51 --> Form Validation Class Initialized
DEBUG - 2021-11-28 10:12:51 --> Encrypt Class Initialized
DEBUG - 2021-11-28 10:12:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 10:12:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 10:12:51 --> Email Class Initialized
INFO - 2021-11-28 10:12:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 10:12:51 --> Calendar Class Initialized
INFO - 2021-11-28 10:12:51 --> Model "Login_model" initialized
INFO - 2021-11-28 10:12:51 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 10:12:51 --> Final output sent to browser
DEBUG - 2021-11-28 10:12:51 --> Total execution time: 0.0339
ERROR - 2021-11-28 10:22:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 10:22:58 --> Config Class Initialized
INFO - 2021-11-28 10:22:58 --> Hooks Class Initialized
DEBUG - 2021-11-28 10:22:58 --> UTF-8 Support Enabled
INFO - 2021-11-28 10:22:58 --> Utf8 Class Initialized
INFO - 2021-11-28 10:22:58 --> URI Class Initialized
DEBUG - 2021-11-28 10:22:58 --> No URI present. Default controller set.
INFO - 2021-11-28 10:22:58 --> Router Class Initialized
INFO - 2021-11-28 10:22:58 --> Output Class Initialized
INFO - 2021-11-28 10:22:58 --> Security Class Initialized
DEBUG - 2021-11-28 10:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 10:22:58 --> Input Class Initialized
INFO - 2021-11-28 10:22:58 --> Language Class Initialized
INFO - 2021-11-28 10:22:58 --> Loader Class Initialized
INFO - 2021-11-28 10:22:58 --> Helper loaded: url_helper
INFO - 2021-11-28 10:22:58 --> Helper loaded: form_helper
INFO - 2021-11-28 10:22:58 --> Helper loaded: common_helper
INFO - 2021-11-28 10:22:58 --> Database Driver Class Initialized
DEBUG - 2021-11-28 10:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 10:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 10:22:58 --> Controller Class Initialized
INFO - 2021-11-28 10:22:58 --> Form Validation Class Initialized
DEBUG - 2021-11-28 10:22:58 --> Encrypt Class Initialized
DEBUG - 2021-11-28 10:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 10:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 10:22:58 --> Email Class Initialized
INFO - 2021-11-28 10:22:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 10:22:58 --> Calendar Class Initialized
INFO - 2021-11-28 10:22:58 --> Model "Login_model" initialized
INFO - 2021-11-28 10:22:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 10:22:58 --> Final output sent to browser
DEBUG - 2021-11-28 10:22:58 --> Total execution time: 0.0223
ERROR - 2021-11-28 10:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 10:27:12 --> Config Class Initialized
INFO - 2021-11-28 10:27:12 --> Hooks Class Initialized
DEBUG - 2021-11-28 10:27:12 --> UTF-8 Support Enabled
INFO - 2021-11-28 10:27:12 --> Utf8 Class Initialized
INFO - 2021-11-28 10:27:12 --> URI Class Initialized
DEBUG - 2021-11-28 10:27:12 --> No URI present. Default controller set.
INFO - 2021-11-28 10:27:12 --> Router Class Initialized
INFO - 2021-11-28 10:27:12 --> Output Class Initialized
INFO - 2021-11-28 10:27:12 --> Security Class Initialized
DEBUG - 2021-11-28 10:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 10:27:12 --> Input Class Initialized
INFO - 2021-11-28 10:27:12 --> Language Class Initialized
INFO - 2021-11-28 10:27:12 --> Loader Class Initialized
INFO - 2021-11-28 10:27:12 --> Helper loaded: url_helper
INFO - 2021-11-28 10:27:12 --> Helper loaded: form_helper
INFO - 2021-11-28 10:27:12 --> Helper loaded: common_helper
INFO - 2021-11-28 10:27:12 --> Database Driver Class Initialized
DEBUG - 2021-11-28 10:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 10:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 10:27:12 --> Controller Class Initialized
INFO - 2021-11-28 10:27:12 --> Form Validation Class Initialized
DEBUG - 2021-11-28 10:27:12 --> Encrypt Class Initialized
DEBUG - 2021-11-28 10:27:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 10:27:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 10:27:12 --> Email Class Initialized
INFO - 2021-11-28 10:27:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 10:27:12 --> Calendar Class Initialized
INFO - 2021-11-28 10:27:12 --> Model "Login_model" initialized
INFO - 2021-11-28 10:27:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 10:27:12 --> Final output sent to browser
DEBUG - 2021-11-28 10:27:12 --> Total execution time: 0.0224
ERROR - 2021-11-28 10:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 10:30:17 --> Config Class Initialized
INFO - 2021-11-28 10:30:17 --> Hooks Class Initialized
DEBUG - 2021-11-28 10:30:17 --> UTF-8 Support Enabled
INFO - 2021-11-28 10:30:17 --> Utf8 Class Initialized
INFO - 2021-11-28 10:30:17 --> URI Class Initialized
DEBUG - 2021-11-28 10:30:17 --> No URI present. Default controller set.
INFO - 2021-11-28 10:30:17 --> Router Class Initialized
INFO - 2021-11-28 10:30:17 --> Output Class Initialized
INFO - 2021-11-28 10:30:17 --> Security Class Initialized
DEBUG - 2021-11-28 10:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 10:30:17 --> Input Class Initialized
INFO - 2021-11-28 10:30:17 --> Language Class Initialized
INFO - 2021-11-28 10:30:17 --> Loader Class Initialized
INFO - 2021-11-28 10:30:17 --> Helper loaded: url_helper
INFO - 2021-11-28 10:30:17 --> Helper loaded: form_helper
INFO - 2021-11-28 10:30:17 --> Helper loaded: common_helper
INFO - 2021-11-28 10:30:17 --> Database Driver Class Initialized
DEBUG - 2021-11-28 10:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 10:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 10:30:17 --> Controller Class Initialized
INFO - 2021-11-28 10:30:17 --> Form Validation Class Initialized
DEBUG - 2021-11-28 10:30:17 --> Encrypt Class Initialized
DEBUG - 2021-11-28 10:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 10:30:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 10:30:17 --> Email Class Initialized
INFO - 2021-11-28 10:30:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 10:30:17 --> Calendar Class Initialized
INFO - 2021-11-28 10:30:17 --> Model "Login_model" initialized
INFO - 2021-11-28 10:30:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 10:30:17 --> Final output sent to browser
DEBUG - 2021-11-28 10:30:17 --> Total execution time: 0.0228
ERROR - 2021-11-28 12:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 12:16:25 --> Config Class Initialized
INFO - 2021-11-28 12:16:25 --> Hooks Class Initialized
DEBUG - 2021-11-28 12:16:25 --> UTF-8 Support Enabled
INFO - 2021-11-28 12:16:25 --> Utf8 Class Initialized
INFO - 2021-11-28 12:16:25 --> URI Class Initialized
DEBUG - 2021-11-28 12:16:25 --> No URI present. Default controller set.
INFO - 2021-11-28 12:16:25 --> Router Class Initialized
INFO - 2021-11-28 12:16:25 --> Output Class Initialized
INFO - 2021-11-28 12:16:25 --> Security Class Initialized
DEBUG - 2021-11-28 12:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 12:16:25 --> Input Class Initialized
INFO - 2021-11-28 12:16:25 --> Language Class Initialized
INFO - 2021-11-28 12:16:25 --> Loader Class Initialized
INFO - 2021-11-28 12:16:25 --> Helper loaded: url_helper
INFO - 2021-11-28 12:16:25 --> Helper loaded: form_helper
INFO - 2021-11-28 12:16:25 --> Helper loaded: common_helper
INFO - 2021-11-28 12:16:25 --> Database Driver Class Initialized
DEBUG - 2021-11-28 12:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 12:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 12:16:25 --> Controller Class Initialized
INFO - 2021-11-28 12:16:25 --> Form Validation Class Initialized
DEBUG - 2021-11-28 12:16:25 --> Encrypt Class Initialized
DEBUG - 2021-11-28 12:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 12:16:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 12:16:25 --> Email Class Initialized
INFO - 2021-11-28 12:16:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 12:16:25 --> Calendar Class Initialized
INFO - 2021-11-28 12:16:25 --> Model "Login_model" initialized
INFO - 2021-11-28 12:16:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 12:16:25 --> Final output sent to browser
DEBUG - 2021-11-28 12:16:25 --> Total execution time: 0.0239
ERROR - 2021-11-28 14:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 14:17:41 --> Config Class Initialized
INFO - 2021-11-28 14:17:41 --> Hooks Class Initialized
DEBUG - 2021-11-28 14:17:41 --> UTF-8 Support Enabled
INFO - 2021-11-28 14:17:41 --> Utf8 Class Initialized
INFO - 2021-11-28 14:17:41 --> URI Class Initialized
DEBUG - 2021-11-28 14:17:41 --> No URI present. Default controller set.
INFO - 2021-11-28 14:17:41 --> Router Class Initialized
INFO - 2021-11-28 14:17:41 --> Output Class Initialized
INFO - 2021-11-28 14:17:41 --> Security Class Initialized
DEBUG - 2021-11-28 14:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 14:17:41 --> Input Class Initialized
INFO - 2021-11-28 14:17:41 --> Language Class Initialized
INFO - 2021-11-28 14:17:41 --> Loader Class Initialized
INFO - 2021-11-28 14:17:41 --> Helper loaded: url_helper
INFO - 2021-11-28 14:17:41 --> Helper loaded: form_helper
INFO - 2021-11-28 14:17:41 --> Helper loaded: common_helper
INFO - 2021-11-28 14:17:41 --> Database Driver Class Initialized
DEBUG - 2021-11-28 14:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 14:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 14:17:41 --> Controller Class Initialized
INFO - 2021-11-28 14:17:41 --> Form Validation Class Initialized
DEBUG - 2021-11-28 14:17:41 --> Encrypt Class Initialized
DEBUG - 2021-11-28 14:17:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 14:17:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 14:17:41 --> Email Class Initialized
INFO - 2021-11-28 14:17:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 14:17:41 --> Calendar Class Initialized
INFO - 2021-11-28 14:17:41 --> Model "Login_model" initialized
INFO - 2021-11-28 14:17:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 14:17:41 --> Final output sent to browser
DEBUG - 2021-11-28 14:17:41 --> Total execution time: 0.0265
ERROR - 2021-11-28 20:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 20:58:05 --> Config Class Initialized
INFO - 2021-11-28 20:58:05 --> Hooks Class Initialized
DEBUG - 2021-11-28 20:58:05 --> UTF-8 Support Enabled
INFO - 2021-11-28 20:58:05 --> Utf8 Class Initialized
INFO - 2021-11-28 20:58:05 --> URI Class Initialized
DEBUG - 2021-11-28 20:58:05 --> No URI present. Default controller set.
INFO - 2021-11-28 20:58:05 --> Router Class Initialized
INFO - 2021-11-28 20:58:05 --> Output Class Initialized
INFO - 2021-11-28 20:58:05 --> Security Class Initialized
DEBUG - 2021-11-28 20:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 20:58:05 --> Input Class Initialized
INFO - 2021-11-28 20:58:05 --> Language Class Initialized
INFO - 2021-11-28 20:58:05 --> Loader Class Initialized
INFO - 2021-11-28 20:58:05 --> Helper loaded: url_helper
INFO - 2021-11-28 20:58:05 --> Helper loaded: form_helper
INFO - 2021-11-28 20:58:05 --> Helper loaded: common_helper
INFO - 2021-11-28 20:58:05 --> Database Driver Class Initialized
DEBUG - 2021-11-28 20:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 20:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 20:58:05 --> Controller Class Initialized
INFO - 2021-11-28 20:58:05 --> Form Validation Class Initialized
DEBUG - 2021-11-28 20:58:05 --> Encrypt Class Initialized
DEBUG - 2021-11-28 20:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 20:58:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 20:58:05 --> Email Class Initialized
INFO - 2021-11-28 20:58:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 20:58:05 --> Calendar Class Initialized
INFO - 2021-11-28 20:58:05 --> Model "Login_model" initialized
INFO - 2021-11-28 20:58:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 20:58:05 --> Final output sent to browser
DEBUG - 2021-11-28 20:58:05 --> Total execution time: 0.0234
ERROR - 2021-11-28 22:57:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-28 22:57:24 --> Config Class Initialized
INFO - 2021-11-28 22:57:24 --> Hooks Class Initialized
DEBUG - 2021-11-28 22:57:24 --> UTF-8 Support Enabled
INFO - 2021-11-28 22:57:24 --> Utf8 Class Initialized
INFO - 2021-11-28 22:57:24 --> URI Class Initialized
DEBUG - 2021-11-28 22:57:24 --> No URI present. Default controller set.
INFO - 2021-11-28 22:57:24 --> Router Class Initialized
INFO - 2021-11-28 22:57:24 --> Output Class Initialized
INFO - 2021-11-28 22:57:24 --> Security Class Initialized
DEBUG - 2021-11-28 22:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-28 22:57:24 --> Input Class Initialized
INFO - 2021-11-28 22:57:24 --> Language Class Initialized
INFO - 2021-11-28 22:57:24 --> Loader Class Initialized
INFO - 2021-11-28 22:57:24 --> Helper loaded: url_helper
INFO - 2021-11-28 22:57:24 --> Helper loaded: form_helper
INFO - 2021-11-28 22:57:24 --> Helper loaded: common_helper
INFO - 2021-11-28 22:57:24 --> Database Driver Class Initialized
DEBUG - 2021-11-28 22:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-28 22:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-28 22:57:25 --> Controller Class Initialized
INFO - 2021-11-28 22:57:25 --> Form Validation Class Initialized
DEBUG - 2021-11-28 22:57:25 --> Encrypt Class Initialized
DEBUG - 2021-11-28 22:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-28 22:57:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-28 22:57:25 --> Email Class Initialized
INFO - 2021-11-28 22:57:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-28 22:57:25 --> Calendar Class Initialized
INFO - 2021-11-28 22:57:25 --> Model "Login_model" initialized
INFO - 2021-11-28 22:57:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-28 22:57:25 --> Final output sent to browser
DEBUG - 2021-11-28 22:57:25 --> Total execution time: 0.7007
