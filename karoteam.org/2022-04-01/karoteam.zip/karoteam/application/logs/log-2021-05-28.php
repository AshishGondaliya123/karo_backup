<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 17:04:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-28 17:04:01 --> Config Class Initialized
INFO - 2021-05-28 17:04:01 --> Hooks Class Initialized
DEBUG - 2021-05-28 17:04:01 --> UTF-8 Support Enabled
INFO - 2021-05-28 17:04:01 --> Utf8 Class Initialized
INFO - 2021-05-28 17:04:01 --> URI Class Initialized
DEBUG - 2021-05-28 17:04:01 --> No URI present. Default controller set.
INFO - 2021-05-28 17:04:01 --> Router Class Initialized
INFO - 2021-05-28 17:04:01 --> Output Class Initialized
INFO - 2021-05-28 17:04:01 --> Security Class Initialized
DEBUG - 2021-05-28 17:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-28 17:04:01 --> Input Class Initialized
INFO - 2021-05-28 17:04:01 --> Language Class Initialized
INFO - 2021-05-28 17:04:01 --> Loader Class Initialized
INFO - 2021-05-28 17:04:01 --> Helper loaded: url_helper
INFO - 2021-05-28 17:04:01 --> Helper loaded: form_helper
INFO - 2021-05-28 17:04:01 --> Helper loaded: common_helper
INFO - 2021-05-28 17:04:01 --> Database Driver Class Initialized
DEBUG - 2021-05-28 17:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-28 17:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-28 17:04:01 --> Controller Class Initialized
INFO - 2021-05-28 17:04:01 --> Form Validation Class Initialized
DEBUG - 2021-05-28 17:04:01 --> Encrypt Class Initialized
DEBUG - 2021-05-28 17:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-28 17:04:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-28 17:04:01 --> Email Class Initialized
INFO - 2021-05-28 17:04:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-28 17:04:01 --> Calendar Class Initialized
INFO - 2021-05-28 17:04:01 --> Model "Login_model" initialized
INFO - 2021-05-28 17:04:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-28 17:04:01 --> Final output sent to browser
DEBUG - 2021-05-28 17:04:01 --> Total execution time: 0.0505
ERROR - 2021-05-28 20:46:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-28 20:46:01 --> Config Class Initialized
INFO - 2021-05-28 20:46:01 --> Hooks Class Initialized
DEBUG - 2021-05-28 20:46:01 --> UTF-8 Support Enabled
INFO - 2021-05-28 20:46:01 --> Utf8 Class Initialized
INFO - 2021-05-28 20:46:01 --> URI Class Initialized
DEBUG - 2021-05-28 20:46:01 --> No URI present. Default controller set.
INFO - 2021-05-28 20:46:01 --> Router Class Initialized
INFO - 2021-05-28 20:46:01 --> Output Class Initialized
INFO - 2021-05-28 20:46:01 --> Security Class Initialized
DEBUG - 2021-05-28 20:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-28 20:46:01 --> Input Class Initialized
INFO - 2021-05-28 20:46:01 --> Language Class Initialized
INFO - 2021-05-28 20:46:01 --> Loader Class Initialized
INFO - 2021-05-28 20:46:01 --> Helper loaded: url_helper
INFO - 2021-05-28 20:46:01 --> Helper loaded: form_helper
INFO - 2021-05-28 20:46:01 --> Helper loaded: common_helper
INFO - 2021-05-28 20:46:01 --> Database Driver Class Initialized
DEBUG - 2021-05-28 20:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-28 20:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-28 20:46:01 --> Controller Class Initialized
INFO - 2021-05-28 20:46:01 --> Form Validation Class Initialized
DEBUG - 2021-05-28 20:46:01 --> Encrypt Class Initialized
DEBUG - 2021-05-28 20:46:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-28 20:46:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-28 20:46:01 --> Email Class Initialized
INFO - 2021-05-28 20:46:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-28 20:46:01 --> Calendar Class Initialized
INFO - 2021-05-28 20:46:01 --> Model "Login_model" initialized
INFO - 2021-05-28 20:46:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-28 20:46:01 --> Final output sent to browser
DEBUG - 2021-05-28 20:46:01 --> Total execution time: 0.0378
ERROR - 2021-05-28 23:59:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-28 23:59:39 --> Config Class Initialized
INFO - 2021-05-28 23:59:39 --> Hooks Class Initialized
DEBUG - 2021-05-28 23:59:39 --> UTF-8 Support Enabled
INFO - 2021-05-28 23:59:39 --> Utf8 Class Initialized
INFO - 2021-05-28 23:59:39 --> URI Class Initialized
DEBUG - 2021-05-28 23:59:39 --> No URI present. Default controller set.
INFO - 2021-05-28 23:59:39 --> Router Class Initialized
INFO - 2021-05-28 23:59:39 --> Output Class Initialized
INFO - 2021-05-28 23:59:39 --> Security Class Initialized
DEBUG - 2021-05-28 23:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-28 23:59:39 --> Input Class Initialized
INFO - 2021-05-28 23:59:39 --> Language Class Initialized
INFO - 2021-05-28 23:59:39 --> Loader Class Initialized
INFO - 2021-05-28 23:59:39 --> Helper loaded: url_helper
INFO - 2021-05-28 23:59:39 --> Helper loaded: form_helper
INFO - 2021-05-28 23:59:39 --> Helper loaded: common_helper
INFO - 2021-05-28 23:59:39 --> Database Driver Class Initialized
DEBUG - 2021-05-28 23:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-28 23:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-28 23:59:39 --> Controller Class Initialized
INFO - 2021-05-28 23:59:39 --> Form Validation Class Initialized
DEBUG - 2021-05-28 23:59:39 --> Encrypt Class Initialized
DEBUG - 2021-05-28 23:59:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-28 23:59:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-28 23:59:39 --> Email Class Initialized
INFO - 2021-05-28 23:59:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-28 23:59:39 --> Calendar Class Initialized
INFO - 2021-05-28 23:59:39 --> Model "Login_model" initialized
INFO - 2021-05-28 23:59:39 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-28 23:59:39 --> Final output sent to browser
DEBUG - 2021-05-28 23:59:39 --> Total execution time: 0.0523
