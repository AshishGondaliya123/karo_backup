<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-27 17:58:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-27 17:58:23 --> Config Class Initialized
INFO - 2021-05-27 17:58:23 --> Hooks Class Initialized
DEBUG - 2021-05-27 17:58:23 --> UTF-8 Support Enabled
INFO - 2021-05-27 17:58:23 --> Utf8 Class Initialized
INFO - 2021-05-27 17:58:23 --> URI Class Initialized
DEBUG - 2021-05-27 17:58:23 --> No URI present. Default controller set.
INFO - 2021-05-27 17:58:23 --> Router Class Initialized
INFO - 2021-05-27 17:58:23 --> Output Class Initialized
INFO - 2021-05-27 17:58:23 --> Security Class Initialized
DEBUG - 2021-05-27 17:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-27 17:58:23 --> Input Class Initialized
INFO - 2021-05-27 17:58:23 --> Language Class Initialized
INFO - 2021-05-27 17:58:23 --> Loader Class Initialized
INFO - 2021-05-27 17:58:23 --> Helper loaded: url_helper
INFO - 2021-05-27 17:58:23 --> Helper loaded: form_helper
INFO - 2021-05-27 17:58:23 --> Helper loaded: common_helper
INFO - 2021-05-27 17:58:23 --> Database Driver Class Initialized
DEBUG - 2021-05-27 17:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-27 17:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-27 17:58:23 --> Controller Class Initialized
INFO - 2021-05-27 17:58:23 --> Form Validation Class Initialized
DEBUG - 2021-05-27 17:58:23 --> Encrypt Class Initialized
DEBUG - 2021-05-27 17:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-27 17:58:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-27 17:58:23 --> Email Class Initialized
INFO - 2021-05-27 17:58:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-27 17:58:23 --> Calendar Class Initialized
INFO - 2021-05-27 17:58:23 --> Model "Login_model" initialized
INFO - 2021-05-27 17:58:23 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-27 17:58:23 --> Final output sent to browser
DEBUG - 2021-05-27 17:58:23 --> Total execution time: 0.0380
ERROR - 2021-05-27 17:58:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-27 17:58:23 --> Config Class Initialized
INFO - 2021-05-27 17:58:23 --> Hooks Class Initialized
DEBUG - 2021-05-27 17:58:23 --> UTF-8 Support Enabled
INFO - 2021-05-27 17:58:23 --> Utf8 Class Initialized
INFO - 2021-05-27 17:58:23 --> URI Class Initialized
INFO - 2021-05-27 17:58:23 --> Router Class Initialized
INFO - 2021-05-27 17:58:23 --> Output Class Initialized
INFO - 2021-05-27 17:58:23 --> Security Class Initialized
DEBUG - 2021-05-27 17:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-27 17:58:23 --> Input Class Initialized
INFO - 2021-05-27 17:58:23 --> Language Class Initialized
ERROR - 2021-05-27 17:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-27 17:59:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-27 17:59:00 --> Config Class Initialized
INFO - 2021-05-27 17:59:00 --> Hooks Class Initialized
DEBUG - 2021-05-27 17:59:00 --> UTF-8 Support Enabled
INFO - 2021-05-27 17:59:00 --> Utf8 Class Initialized
INFO - 2021-05-27 17:59:00 --> URI Class Initialized
INFO - 2021-05-27 17:59:00 --> Router Class Initialized
INFO - 2021-05-27 17:59:00 --> Output Class Initialized
INFO - 2021-05-27 17:59:00 --> Security Class Initialized
DEBUG - 2021-05-27 17:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-27 17:59:00 --> Input Class Initialized
INFO - 2021-05-27 17:59:00 --> Language Class Initialized
ERROR - 2021-05-27 17:59:00 --> 404 Page Not Found: Adstxt/index
