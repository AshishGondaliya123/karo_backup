<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-16 12:34:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-16 12:34:50 --> Config Class Initialized
INFO - 2021-09-16 12:34:50 --> Hooks Class Initialized
DEBUG - 2021-09-16 12:34:50 --> UTF-8 Support Enabled
INFO - 2021-09-16 12:34:50 --> Utf8 Class Initialized
INFO - 2021-09-16 12:34:50 --> URI Class Initialized
DEBUG - 2021-09-16 12:34:50 --> No URI present. Default controller set.
INFO - 2021-09-16 12:34:50 --> Router Class Initialized
INFO - 2021-09-16 12:34:50 --> Output Class Initialized
INFO - 2021-09-16 12:34:50 --> Security Class Initialized
DEBUG - 2021-09-16 12:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-16 12:34:50 --> Input Class Initialized
INFO - 2021-09-16 12:34:50 --> Language Class Initialized
INFO - 2021-09-16 12:34:50 --> Loader Class Initialized
INFO - 2021-09-16 12:34:51 --> Helper loaded: url_helper
INFO - 2021-09-16 12:34:51 --> Helper loaded: form_helper
INFO - 2021-09-16 12:34:51 --> Helper loaded: common_helper
INFO - 2021-09-16 12:34:51 --> Database Driver Class Initialized
DEBUG - 2021-09-16 12:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-16 12:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-16 12:34:51 --> Controller Class Initialized
INFO - 2021-09-16 12:34:51 --> Form Validation Class Initialized
DEBUG - 2021-09-16 12:34:51 --> Encrypt Class Initialized
DEBUG - 2021-09-16 12:34:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-09-16 12:34:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-09-16 12:34:51 --> Email Class Initialized
INFO - 2021-09-16 12:34:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-09-16 12:34:51 --> Calendar Class Initialized
INFO - 2021-09-16 12:34:51 --> Model "Login_model" initialized
INFO - 2021-09-16 12:34:51 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-09-16 12:34:51 --> Final output sent to browser
DEBUG - 2021-09-16 12:34:51 --> Total execution time: 0.1869
ERROR - 2021-09-16 23:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-16 23:51:57 --> Config Class Initialized
INFO - 2021-09-16 23:51:57 --> Hooks Class Initialized
DEBUG - 2021-09-16 23:51:57 --> UTF-8 Support Enabled
INFO - 2021-09-16 23:51:57 --> Utf8 Class Initialized
INFO - 2021-09-16 23:51:57 --> URI Class Initialized
INFO - 2021-09-16 23:51:57 --> Router Class Initialized
INFO - 2021-09-16 23:51:57 --> Output Class Initialized
INFO - 2021-09-16 23:51:57 --> Security Class Initialized
DEBUG - 2021-09-16 23:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-16 23:51:57 --> Input Class Initialized
INFO - 2021-09-16 23:51:57 --> Language Class Initialized
ERROR - 2021-09-16 23:51:57 --> 404 Page Not Found: Wp-content/index
