<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-19 06:22:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 06:22:30 --> Config Class Initialized
INFO - 2021-12-19 06:22:30 --> Hooks Class Initialized
DEBUG - 2021-12-19 06:22:30 --> UTF-8 Support Enabled
INFO - 2021-12-19 06:22:30 --> Utf8 Class Initialized
INFO - 2021-12-19 06:22:30 --> URI Class Initialized
DEBUG - 2021-12-19 06:22:30 --> No URI present. Default controller set.
INFO - 2021-12-19 06:22:30 --> Router Class Initialized
INFO - 2021-12-19 06:22:30 --> Output Class Initialized
INFO - 2021-12-19 06:22:30 --> Security Class Initialized
DEBUG - 2021-12-19 06:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 06:22:30 --> Input Class Initialized
INFO - 2021-12-19 06:22:30 --> Language Class Initialized
INFO - 2021-12-19 06:22:30 --> Loader Class Initialized
INFO - 2021-12-19 06:22:30 --> Helper loaded: url_helper
INFO - 2021-12-19 06:22:30 --> Helper loaded: form_helper
INFO - 2021-12-19 06:22:30 --> Helper loaded: common_helper
INFO - 2021-12-19 06:22:30 --> Database Driver Class Initialized
DEBUG - 2021-12-19 06:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 06:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 06:22:30 --> Controller Class Initialized
INFO - 2021-12-19 06:22:30 --> Form Validation Class Initialized
DEBUG - 2021-12-19 06:22:30 --> Encrypt Class Initialized
DEBUG - 2021-12-19 06:22:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 06:22:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 06:22:30 --> Email Class Initialized
INFO - 2021-12-19 06:22:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 06:22:30 --> Calendar Class Initialized
INFO - 2021-12-19 06:22:30 --> Model "Login_model" initialized
INFO - 2021-12-19 06:22:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-19 06:22:30 --> Final output sent to browser
DEBUG - 2021-12-19 06:22:30 --> Total execution time: 0.0227
ERROR - 2021-12-19 06:27:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 06:27:20 --> Config Class Initialized
INFO - 2021-12-19 06:27:20 --> Hooks Class Initialized
DEBUG - 2021-12-19 06:27:20 --> UTF-8 Support Enabled
INFO - 2021-12-19 06:27:20 --> Utf8 Class Initialized
INFO - 2021-12-19 06:27:20 --> URI Class Initialized
DEBUG - 2021-12-19 06:27:20 --> No URI present. Default controller set.
INFO - 2021-12-19 06:27:20 --> Router Class Initialized
INFO - 2021-12-19 06:27:20 --> Output Class Initialized
INFO - 2021-12-19 06:27:20 --> Security Class Initialized
DEBUG - 2021-12-19 06:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 06:27:20 --> Input Class Initialized
INFO - 2021-12-19 06:27:20 --> Language Class Initialized
INFO - 2021-12-19 06:27:20 --> Loader Class Initialized
INFO - 2021-12-19 06:27:20 --> Helper loaded: url_helper
INFO - 2021-12-19 06:27:20 --> Helper loaded: form_helper
INFO - 2021-12-19 06:27:20 --> Helper loaded: common_helper
INFO - 2021-12-19 06:27:20 --> Database Driver Class Initialized
DEBUG - 2021-12-19 06:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 06:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 06:27:20 --> Controller Class Initialized
INFO - 2021-12-19 06:27:20 --> Form Validation Class Initialized
DEBUG - 2021-12-19 06:27:20 --> Encrypt Class Initialized
DEBUG - 2021-12-19 06:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 06:27:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 06:27:20 --> Email Class Initialized
INFO - 2021-12-19 06:27:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 06:27:20 --> Calendar Class Initialized
INFO - 2021-12-19 06:27:20 --> Model "Login_model" initialized
INFO - 2021-12-19 06:27:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-19 06:27:20 --> Final output sent to browser
DEBUG - 2021-12-19 06:27:20 --> Total execution time: 0.0262
ERROR - 2021-12-19 07:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 07:43:27 --> Config Class Initialized
INFO - 2021-12-19 07:43:27 --> Hooks Class Initialized
DEBUG - 2021-12-19 07:43:27 --> UTF-8 Support Enabled
INFO - 2021-12-19 07:43:27 --> Utf8 Class Initialized
INFO - 2021-12-19 07:43:27 --> URI Class Initialized
INFO - 2021-12-19 07:43:27 --> Router Class Initialized
INFO - 2021-12-19 07:43:27 --> Output Class Initialized
INFO - 2021-12-19 07:43:27 --> Security Class Initialized
DEBUG - 2021-12-19 07:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 07:43:27 --> Input Class Initialized
INFO - 2021-12-19 07:43:27 --> Language Class Initialized
ERROR - 2021-12-19 07:43:27 --> 404 Page Not Found: Wp-includes/wp-atom.php
ERROR - 2021-12-19 07:43:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 07:43:42 --> Config Class Initialized
INFO - 2021-12-19 07:43:42 --> Hooks Class Initialized
DEBUG - 2021-12-19 07:43:42 --> UTF-8 Support Enabled
INFO - 2021-12-19 07:43:42 --> Utf8 Class Initialized
INFO - 2021-12-19 07:43:42 --> URI Class Initialized
INFO - 2021-12-19 07:43:42 --> Router Class Initialized
INFO - 2021-12-19 07:43:42 --> Output Class Initialized
INFO - 2021-12-19 07:43:42 --> Security Class Initialized
DEBUG - 2021-12-19 07:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 07:43:42 --> Input Class Initialized
INFO - 2021-12-19 07:43:42 --> Language Class Initialized
ERROR - 2021-12-19 07:43:42 --> 404 Page Not Found: Wp-includes/wp-atom.php
ERROR - 2021-12-19 14:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 14:17:02 --> Config Class Initialized
INFO - 2021-12-19 14:17:02 --> Hooks Class Initialized
DEBUG - 2021-12-19 14:17:02 --> UTF-8 Support Enabled
INFO - 2021-12-19 14:17:02 --> Utf8 Class Initialized
INFO - 2021-12-19 14:17:02 --> URI Class Initialized
DEBUG - 2021-12-19 14:17:02 --> No URI present. Default controller set.
INFO - 2021-12-19 14:17:02 --> Router Class Initialized
INFO - 2021-12-19 14:17:02 --> Output Class Initialized
INFO - 2021-12-19 14:17:02 --> Security Class Initialized
DEBUG - 2021-12-19 14:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 14:17:02 --> Input Class Initialized
INFO - 2021-12-19 14:17:02 --> Language Class Initialized
INFO - 2021-12-19 14:17:02 --> Loader Class Initialized
INFO - 2021-12-19 14:17:02 --> Helper loaded: url_helper
INFO - 2021-12-19 14:17:02 --> Helper loaded: form_helper
INFO - 2021-12-19 14:17:02 --> Helper loaded: common_helper
INFO - 2021-12-19 14:17:02 --> Database Driver Class Initialized
DEBUG - 2021-12-19 14:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 14:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 14:17:02 --> Controller Class Initialized
INFO - 2021-12-19 14:17:02 --> Form Validation Class Initialized
DEBUG - 2021-12-19 14:17:02 --> Encrypt Class Initialized
DEBUG - 2021-12-19 14:17:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 14:17:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 14:17:02 --> Email Class Initialized
INFO - 2021-12-19 14:17:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 14:17:02 --> Calendar Class Initialized
INFO - 2021-12-19 14:17:02 --> Model "Login_model" initialized
INFO - 2021-12-19 14:17:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-19 14:17:02 --> Final output sent to browser
DEBUG - 2021-12-19 14:17:02 --> Total execution time: 0.0289
ERROR - 2021-12-19 14:17:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 14:17:04 --> Config Class Initialized
INFO - 2021-12-19 14:17:04 --> Hooks Class Initialized
DEBUG - 2021-12-19 14:17:04 --> UTF-8 Support Enabled
INFO - 2021-12-19 14:17:04 --> Utf8 Class Initialized
INFO - 2021-12-19 14:17:04 --> URI Class Initialized
INFO - 2021-12-19 14:17:04 --> Router Class Initialized
INFO - 2021-12-19 14:17:04 --> Output Class Initialized
INFO - 2021-12-19 14:17:04 --> Security Class Initialized
DEBUG - 2021-12-19 14:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 14:17:04 --> Input Class Initialized
INFO - 2021-12-19 14:17:04 --> Language Class Initialized
ERROR - 2021-12-19 14:17:04 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-19 14:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 14:17:21 --> Config Class Initialized
INFO - 2021-12-19 14:17:21 --> Hooks Class Initialized
DEBUG - 2021-12-19 14:17:21 --> UTF-8 Support Enabled
INFO - 2021-12-19 14:17:21 --> Utf8 Class Initialized
INFO - 2021-12-19 14:17:21 --> URI Class Initialized
INFO - 2021-12-19 14:17:21 --> Router Class Initialized
INFO - 2021-12-19 14:17:21 --> Output Class Initialized
INFO - 2021-12-19 14:17:21 --> Security Class Initialized
DEBUG - 2021-12-19 14:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 14:17:21 --> Input Class Initialized
INFO - 2021-12-19 14:17:21 --> Language Class Initialized
INFO - 2021-12-19 14:17:21 --> Loader Class Initialized
INFO - 2021-12-19 14:17:21 --> Helper loaded: url_helper
INFO - 2021-12-19 14:17:21 --> Helper loaded: form_helper
INFO - 2021-12-19 14:17:21 --> Helper loaded: common_helper
INFO - 2021-12-19 14:17:21 --> Database Driver Class Initialized
DEBUG - 2021-12-19 14:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 14:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 14:17:21 --> Controller Class Initialized
INFO - 2021-12-19 14:17:21 --> Form Validation Class Initialized
DEBUG - 2021-12-19 14:17:21 --> Encrypt Class Initialized
DEBUG - 2021-12-19 14:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 14:17:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 14:17:21 --> Email Class Initialized
INFO - 2021-12-19 14:17:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 14:17:21 --> Calendar Class Initialized
INFO - 2021-12-19 14:17:21 --> Model "Login_model" initialized
ERROR - 2021-12-19 14:17:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 14:17:22 --> Config Class Initialized
INFO - 2021-12-19 14:17:22 --> Hooks Class Initialized
DEBUG - 2021-12-19 14:17:22 --> UTF-8 Support Enabled
INFO - 2021-12-19 14:17:22 --> Utf8 Class Initialized
INFO - 2021-12-19 14:17:22 --> URI Class Initialized
INFO - 2021-12-19 14:17:22 --> Router Class Initialized
INFO - 2021-12-19 14:17:22 --> Output Class Initialized
INFO - 2021-12-19 14:17:22 --> Security Class Initialized
DEBUG - 2021-12-19 14:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 14:17:22 --> Input Class Initialized
INFO - 2021-12-19 14:17:22 --> Language Class Initialized
INFO - 2021-12-19 14:17:22 --> Loader Class Initialized
INFO - 2021-12-19 14:17:22 --> Helper loaded: url_helper
INFO - 2021-12-19 14:17:22 --> Helper loaded: form_helper
INFO - 2021-12-19 14:17:22 --> Helper loaded: common_helper
INFO - 2021-12-19 14:17:22 --> Database Driver Class Initialized
DEBUG - 2021-12-19 14:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 14:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 14:17:22 --> Controller Class Initialized
INFO - 2021-12-19 14:17:22 --> Form Validation Class Initialized
DEBUG - 2021-12-19 14:17:22 --> Encrypt Class Initialized
DEBUG - 2021-12-19 14:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 14:17:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 14:17:22 --> Email Class Initialized
INFO - 2021-12-19 14:17:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 14:17:22 --> Calendar Class Initialized
INFO - 2021-12-19 14:17:22 --> Model "Login_model" initialized
ERROR - 2021-12-19 14:17:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 14:17:22 --> Config Class Initialized
INFO - 2021-12-19 14:17:22 --> Hooks Class Initialized
DEBUG - 2021-12-19 14:17:22 --> UTF-8 Support Enabled
INFO - 2021-12-19 14:17:22 --> Utf8 Class Initialized
INFO - 2021-12-19 14:17:22 --> URI Class Initialized
INFO - 2021-12-19 14:17:22 --> Router Class Initialized
INFO - 2021-12-19 14:17:22 --> Output Class Initialized
INFO - 2021-12-19 14:17:22 --> Security Class Initialized
DEBUG - 2021-12-19 14:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 14:17:22 --> Input Class Initialized
INFO - 2021-12-19 14:17:22 --> Language Class Initialized
INFO - 2021-12-19 14:17:22 --> Loader Class Initialized
INFO - 2021-12-19 14:17:22 --> Helper loaded: url_helper
INFO - 2021-12-19 14:17:22 --> Helper loaded: form_helper
INFO - 2021-12-19 14:17:22 --> Helper loaded: common_helper
INFO - 2021-12-19 14:17:22 --> Database Driver Class Initialized
DEBUG - 2021-12-19 14:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 14:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 14:17:22 --> Controller Class Initialized
INFO - 2021-12-19 14:17:22 --> Form Validation Class Initialized
DEBUG - 2021-12-19 14:17:22 --> Encrypt Class Initialized
DEBUG - 2021-12-19 14:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 14:17:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 14:17:22 --> Email Class Initialized
INFO - 2021-12-19 14:17:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 14:17:22 --> Calendar Class Initialized
INFO - 2021-12-19 14:17:22 --> Model "Login_model" initialized
INFO - 2021-12-19 14:17:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-19 14:17:22 --> Final output sent to browser
DEBUG - 2021-12-19 14:17:22 --> Total execution time: 0.0231
ERROR - 2021-12-19 14:17:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 14:17:23 --> Config Class Initialized
INFO - 2021-12-19 14:17:23 --> Hooks Class Initialized
DEBUG - 2021-12-19 14:17:23 --> UTF-8 Support Enabled
INFO - 2021-12-19 14:17:23 --> Utf8 Class Initialized
INFO - 2021-12-19 14:17:23 --> URI Class Initialized
DEBUG - 2021-12-19 14:17:23 --> No URI present. Default controller set.
INFO - 2021-12-19 14:17:23 --> Router Class Initialized
INFO - 2021-12-19 14:17:23 --> Output Class Initialized
INFO - 2021-12-19 14:17:23 --> Security Class Initialized
DEBUG - 2021-12-19 14:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 14:17:23 --> Input Class Initialized
INFO - 2021-12-19 14:17:23 --> Language Class Initialized
INFO - 2021-12-19 14:17:23 --> Loader Class Initialized
INFO - 2021-12-19 14:17:23 --> Helper loaded: url_helper
INFO - 2021-12-19 14:17:23 --> Helper loaded: form_helper
INFO - 2021-12-19 14:17:23 --> Helper loaded: common_helper
INFO - 2021-12-19 14:17:23 --> Database Driver Class Initialized
DEBUG - 2021-12-19 14:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 14:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 14:17:23 --> Controller Class Initialized
INFO - 2021-12-19 14:17:23 --> Form Validation Class Initialized
DEBUG - 2021-12-19 14:17:23 --> Encrypt Class Initialized
DEBUG - 2021-12-19 14:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 14:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 14:17:23 --> Email Class Initialized
INFO - 2021-12-19 14:17:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 14:17:23 --> Calendar Class Initialized
INFO - 2021-12-19 14:17:23 --> Model "Login_model" initialized
INFO - 2021-12-19 14:17:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-19 14:17:23 --> Final output sent to browser
DEBUG - 2021-12-19 14:17:23 --> Total execution time: 0.4361
ERROR - 2021-12-19 19:18:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 19:18:20 --> Config Class Initialized
INFO - 2021-12-19 19:18:20 --> Hooks Class Initialized
DEBUG - 2021-12-19 19:18:20 --> UTF-8 Support Enabled
INFO - 2021-12-19 19:18:20 --> Utf8 Class Initialized
INFO - 2021-12-19 19:18:20 --> URI Class Initialized
DEBUG - 2021-12-19 19:18:20 --> No URI present. Default controller set.
INFO - 2021-12-19 19:18:20 --> Router Class Initialized
INFO - 2021-12-19 19:18:20 --> Output Class Initialized
INFO - 2021-12-19 19:18:20 --> Security Class Initialized
DEBUG - 2021-12-19 19:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 19:18:20 --> Input Class Initialized
INFO - 2021-12-19 19:18:20 --> Language Class Initialized
INFO - 2021-12-19 19:18:20 --> Loader Class Initialized
INFO - 2021-12-19 19:18:20 --> Helper loaded: url_helper
INFO - 2021-12-19 19:18:20 --> Helper loaded: form_helper
INFO - 2021-12-19 19:18:20 --> Helper loaded: common_helper
INFO - 2021-12-19 19:18:20 --> Database Driver Class Initialized
DEBUG - 2021-12-19 19:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 19:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 19:18:20 --> Controller Class Initialized
INFO - 2021-12-19 19:18:20 --> Form Validation Class Initialized
DEBUG - 2021-12-19 19:18:20 --> Encrypt Class Initialized
DEBUG - 2021-12-19 19:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 19:18:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 19:18:20 --> Email Class Initialized
INFO - 2021-12-19 19:18:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 19:18:20 --> Calendar Class Initialized
INFO - 2021-12-19 19:18:20 --> Model "Login_model" initialized
INFO - 2021-12-19 19:18:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-19 19:18:20 --> Final output sent to browser
DEBUG - 2021-12-19 19:18:20 --> Total execution time: 0.0316
ERROR - 2021-12-19 19:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 19:18:21 --> Config Class Initialized
INFO - 2021-12-19 19:18:21 --> Hooks Class Initialized
DEBUG - 2021-12-19 19:18:21 --> UTF-8 Support Enabled
INFO - 2021-12-19 19:18:21 --> Utf8 Class Initialized
INFO - 2021-12-19 19:18:21 --> URI Class Initialized
DEBUG - 2021-12-19 19:18:21 --> No URI present. Default controller set.
INFO - 2021-12-19 19:18:21 --> Router Class Initialized
INFO - 2021-12-19 19:18:21 --> Output Class Initialized
INFO - 2021-12-19 19:18:21 --> Security Class Initialized
DEBUG - 2021-12-19 19:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 19:18:21 --> Input Class Initialized
INFO - 2021-12-19 19:18:21 --> Language Class Initialized
INFO - 2021-12-19 19:18:21 --> Loader Class Initialized
INFO - 2021-12-19 19:18:21 --> Helper loaded: url_helper
INFO - 2021-12-19 19:18:21 --> Helper loaded: form_helper
INFO - 2021-12-19 19:18:21 --> Helper loaded: common_helper
INFO - 2021-12-19 19:18:21 --> Database Driver Class Initialized
DEBUG - 2021-12-19 19:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 19:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 19:18:21 --> Controller Class Initialized
INFO - 2021-12-19 19:18:21 --> Form Validation Class Initialized
DEBUG - 2021-12-19 19:18:21 --> Encrypt Class Initialized
DEBUG - 2021-12-19 19:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 19:18:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 19:18:21 --> Email Class Initialized
INFO - 2021-12-19 19:18:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 19:18:21 --> Calendar Class Initialized
INFO - 2021-12-19 19:18:21 --> Model "Login_model" initialized
INFO - 2021-12-19 19:18:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-19 19:18:21 --> Final output sent to browser
DEBUG - 2021-12-19 19:18:21 --> Total execution time: 0.0345
ERROR - 2021-12-19 23:47:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 23:47:42 --> Config Class Initialized
INFO - 2021-12-19 23:47:42 --> Hooks Class Initialized
DEBUG - 2021-12-19 23:47:42 --> UTF-8 Support Enabled
INFO - 2021-12-19 23:47:42 --> Utf8 Class Initialized
INFO - 2021-12-19 23:47:42 --> URI Class Initialized
DEBUG - 2021-12-19 23:47:42 --> No URI present. Default controller set.
INFO - 2021-12-19 23:47:42 --> Router Class Initialized
INFO - 2021-12-19 23:47:42 --> Output Class Initialized
INFO - 2021-12-19 23:47:42 --> Security Class Initialized
DEBUG - 2021-12-19 23:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 23:47:42 --> Input Class Initialized
INFO - 2021-12-19 23:47:42 --> Language Class Initialized
INFO - 2021-12-19 23:47:42 --> Loader Class Initialized
INFO - 2021-12-19 23:47:42 --> Helper loaded: url_helper
INFO - 2021-12-19 23:47:42 --> Helper loaded: form_helper
INFO - 2021-12-19 23:47:42 --> Helper loaded: common_helper
INFO - 2021-12-19 23:47:42 --> Database Driver Class Initialized
DEBUG - 2021-12-19 23:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 23:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 23:47:42 --> Controller Class Initialized
INFO - 2021-12-19 23:47:42 --> Form Validation Class Initialized
DEBUG - 2021-12-19 23:47:42 --> Encrypt Class Initialized
DEBUG - 2021-12-19 23:47:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 23:47:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 23:47:42 --> Email Class Initialized
INFO - 2021-12-19 23:47:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 23:47:42 --> Calendar Class Initialized
INFO - 2021-12-19 23:47:42 --> Model "Login_model" initialized
INFO - 2021-12-19 23:47:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-19 23:47:42 --> Final output sent to browser
DEBUG - 2021-12-19 23:47:42 --> Total execution time: 0.0288
ERROR - 2021-12-19 23:52:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-19 23:52:11 --> Config Class Initialized
INFO - 2021-12-19 23:52:11 --> Hooks Class Initialized
DEBUG - 2021-12-19 23:52:11 --> UTF-8 Support Enabled
INFO - 2021-12-19 23:52:11 --> Utf8 Class Initialized
INFO - 2021-12-19 23:52:11 --> URI Class Initialized
DEBUG - 2021-12-19 23:52:11 --> No URI present. Default controller set.
INFO - 2021-12-19 23:52:11 --> Router Class Initialized
INFO - 2021-12-19 23:52:11 --> Output Class Initialized
INFO - 2021-12-19 23:52:11 --> Security Class Initialized
DEBUG - 2021-12-19 23:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-19 23:52:11 --> Input Class Initialized
INFO - 2021-12-19 23:52:11 --> Language Class Initialized
INFO - 2021-12-19 23:52:11 --> Loader Class Initialized
INFO - 2021-12-19 23:52:11 --> Helper loaded: url_helper
INFO - 2021-12-19 23:52:11 --> Helper loaded: form_helper
INFO - 2021-12-19 23:52:11 --> Helper loaded: common_helper
INFO - 2021-12-19 23:52:11 --> Database Driver Class Initialized
DEBUG - 2021-12-19 23:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-19 23:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-19 23:52:11 --> Controller Class Initialized
INFO - 2021-12-19 23:52:11 --> Form Validation Class Initialized
DEBUG - 2021-12-19 23:52:11 --> Encrypt Class Initialized
DEBUG - 2021-12-19 23:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-19 23:52:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-19 23:52:11 --> Email Class Initialized
INFO - 2021-12-19 23:52:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-19 23:52:11 --> Calendar Class Initialized
INFO - 2021-12-19 23:52:11 --> Model "Login_model" initialized
INFO - 2021-12-19 23:52:11 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-19 23:52:11 --> Final output sent to browser
DEBUG - 2021-12-19 23:52:11 --> Total execution time: 0.0221
