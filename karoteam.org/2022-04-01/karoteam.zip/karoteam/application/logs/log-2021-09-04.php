<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-04 02:37:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-09-04 02:37:09 --> Config Class Initialized
INFO - 2021-09-04 02:37:09 --> Hooks Class Initialized
DEBUG - 2021-09-04 02:37:09 --> UTF-8 Support Enabled
INFO - 2021-09-04 02:37:09 --> Utf8 Class Initialized
INFO - 2021-09-04 02:37:09 --> URI Class Initialized
INFO - 2021-09-04 02:37:09 --> Router Class Initialized
INFO - 2021-09-04 02:37:09 --> Output Class Initialized
INFO - 2021-09-04 02:37:09 --> Security Class Initialized
DEBUG - 2021-09-04 02:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-04 02:37:09 --> Input Class Initialized
INFO - 2021-09-04 02:37:09 --> Language Class Initialized
ERROR - 2021-09-04 02:37:09 --> 404 Page Not Found: Faviconico/index
