<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-13 04:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-13 04:19:43 --> Config Class Initialized
INFO - 2021-10-13 04:19:43 --> Hooks Class Initialized
DEBUG - 2021-10-13 04:19:43 --> UTF-8 Support Enabled
INFO - 2021-10-13 04:19:43 --> Utf8 Class Initialized
INFO - 2021-10-13 04:19:43 --> URI Class Initialized
DEBUG - 2021-10-13 04:19:43 --> No URI present. Default controller set.
INFO - 2021-10-13 04:19:43 --> Router Class Initialized
INFO - 2021-10-13 04:19:43 --> Output Class Initialized
INFO - 2021-10-13 04:19:43 --> Security Class Initialized
DEBUG - 2021-10-13 04:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 04:19:43 --> Input Class Initialized
INFO - 2021-10-13 04:19:43 --> Language Class Initialized
INFO - 2021-10-13 04:19:43 --> Loader Class Initialized
INFO - 2021-10-13 04:19:43 --> Helper loaded: url_helper
INFO - 2021-10-13 04:19:43 --> Helper loaded: form_helper
INFO - 2021-10-13 04:19:43 --> Helper loaded: common_helper
INFO - 2021-10-13 04:19:43 --> Database Driver Class Initialized
DEBUG - 2021-10-13 04:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-13 04:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-13 04:19:43 --> Controller Class Initialized
INFO - 2021-10-13 04:19:43 --> Form Validation Class Initialized
DEBUG - 2021-10-13 04:19:43 --> Encrypt Class Initialized
DEBUG - 2021-10-13 04:19:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-13 04:19:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-13 04:19:43 --> Email Class Initialized
INFO - 2021-10-13 04:19:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-13 04:19:43 --> Calendar Class Initialized
INFO - 2021-10-13 04:19:43 --> Model "Login_model" initialized
INFO - 2021-10-13 04:19:43 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-13 04:19:43 --> Final output sent to browser
DEBUG - 2021-10-13 04:19:43 --> Total execution time: 0.0450
ERROR - 2021-10-13 04:52:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-13 04:52:00 --> Config Class Initialized
INFO - 2021-10-13 04:52:00 --> Hooks Class Initialized
DEBUG - 2021-10-13 04:52:00 --> UTF-8 Support Enabled
INFO - 2021-10-13 04:52:00 --> Utf8 Class Initialized
INFO - 2021-10-13 04:52:00 --> URI Class Initialized
DEBUG - 2021-10-13 04:52:00 --> No URI present. Default controller set.
INFO - 2021-10-13 04:52:00 --> Router Class Initialized
INFO - 2021-10-13 04:52:00 --> Output Class Initialized
INFO - 2021-10-13 04:52:00 --> Security Class Initialized
DEBUG - 2021-10-13 04:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 04:52:00 --> Input Class Initialized
INFO - 2021-10-13 04:52:00 --> Language Class Initialized
INFO - 2021-10-13 04:52:00 --> Loader Class Initialized
INFO - 2021-10-13 04:52:00 --> Helper loaded: url_helper
INFO - 2021-10-13 04:52:00 --> Helper loaded: form_helper
INFO - 2021-10-13 04:52:00 --> Helper loaded: common_helper
INFO - 2021-10-13 04:52:00 --> Database Driver Class Initialized
DEBUG - 2021-10-13 04:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-13 04:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-13 04:52:00 --> Controller Class Initialized
INFO - 2021-10-13 04:52:00 --> Form Validation Class Initialized
DEBUG - 2021-10-13 04:52:00 --> Encrypt Class Initialized
DEBUG - 2021-10-13 04:52:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-13 04:52:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-13 04:52:00 --> Email Class Initialized
INFO - 2021-10-13 04:52:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-13 04:52:00 --> Calendar Class Initialized
INFO - 2021-10-13 04:52:00 --> Model "Login_model" initialized
INFO - 2021-10-13 04:52:00 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-13 04:52:00 --> Final output sent to browser
DEBUG - 2021-10-13 04:52:00 --> Total execution time: 0.0507
ERROR - 2021-10-13 10:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-13 10:59:52 --> Config Class Initialized
INFO - 2021-10-13 10:59:52 --> Hooks Class Initialized
DEBUG - 2021-10-13 10:59:52 --> UTF-8 Support Enabled
INFO - 2021-10-13 10:59:52 --> Utf8 Class Initialized
INFO - 2021-10-13 10:59:52 --> URI Class Initialized
DEBUG - 2021-10-13 10:59:52 --> No URI present. Default controller set.
INFO - 2021-10-13 10:59:52 --> Router Class Initialized
INFO - 2021-10-13 10:59:52 --> Output Class Initialized
INFO - 2021-10-13 10:59:52 --> Security Class Initialized
DEBUG - 2021-10-13 10:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 10:59:52 --> Input Class Initialized
INFO - 2021-10-13 10:59:52 --> Language Class Initialized
INFO - 2021-10-13 10:59:52 --> Loader Class Initialized
INFO - 2021-10-13 10:59:52 --> Helper loaded: url_helper
INFO - 2021-10-13 10:59:52 --> Helper loaded: form_helper
INFO - 2021-10-13 10:59:52 --> Helper loaded: common_helper
INFO - 2021-10-13 10:59:52 --> Database Driver Class Initialized
DEBUG - 2021-10-13 10:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-13 10:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-13 10:59:52 --> Controller Class Initialized
INFO - 2021-10-13 10:59:52 --> Form Validation Class Initialized
DEBUG - 2021-10-13 10:59:52 --> Encrypt Class Initialized
DEBUG - 2021-10-13 10:59:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-13 10:59:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-13 10:59:52 --> Email Class Initialized
INFO - 2021-10-13 10:59:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-13 10:59:52 --> Calendar Class Initialized
INFO - 2021-10-13 10:59:52 --> Model "Login_model" initialized
INFO - 2021-10-13 10:59:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-13 10:59:52 --> Final output sent to browser
DEBUG - 2021-10-13 10:59:52 --> Total execution time: 0.0429
ERROR - 2021-10-13 10:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-13 10:59:52 --> Config Class Initialized
INFO - 2021-10-13 10:59:52 --> Hooks Class Initialized
DEBUG - 2021-10-13 10:59:52 --> UTF-8 Support Enabled
INFO - 2021-10-13 10:59:52 --> Utf8 Class Initialized
INFO - 2021-10-13 10:59:52 --> URI Class Initialized
DEBUG - 2021-10-13 10:59:52 --> No URI present. Default controller set.
INFO - 2021-10-13 10:59:52 --> Router Class Initialized
INFO - 2021-10-13 10:59:52 --> Output Class Initialized
INFO - 2021-10-13 10:59:52 --> Security Class Initialized
DEBUG - 2021-10-13 10:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 10:59:52 --> Input Class Initialized
INFO - 2021-10-13 10:59:52 --> Language Class Initialized
INFO - 2021-10-13 10:59:52 --> Loader Class Initialized
INFO - 2021-10-13 10:59:52 --> Helper loaded: url_helper
INFO - 2021-10-13 10:59:52 --> Helper loaded: form_helper
INFO - 2021-10-13 10:59:52 --> Helper loaded: common_helper
INFO - 2021-10-13 10:59:52 --> Database Driver Class Initialized
DEBUG - 2021-10-13 10:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-13 10:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-13 10:59:52 --> Controller Class Initialized
INFO - 2021-10-13 10:59:52 --> Form Validation Class Initialized
DEBUG - 2021-10-13 10:59:52 --> Encrypt Class Initialized
DEBUG - 2021-10-13 10:59:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-13 10:59:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-13 10:59:52 --> Email Class Initialized
INFO - 2021-10-13 10:59:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-13 10:59:52 --> Calendar Class Initialized
INFO - 2021-10-13 10:59:52 --> Model "Login_model" initialized
INFO - 2021-10-13 10:59:52 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-13 10:59:52 --> Final output sent to browser
DEBUG - 2021-10-13 10:59:52 --> Total execution time: 0.0325
ERROR - 2021-10-13 10:59:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-13 10:59:54 --> Config Class Initialized
INFO - 2021-10-13 10:59:54 --> Hooks Class Initialized
DEBUG - 2021-10-13 10:59:54 --> UTF-8 Support Enabled
INFO - 2021-10-13 10:59:54 --> Utf8 Class Initialized
INFO - 2021-10-13 10:59:54 --> URI Class Initialized
DEBUG - 2021-10-13 10:59:54 --> No URI present. Default controller set.
INFO - 2021-10-13 10:59:54 --> Router Class Initialized
INFO - 2021-10-13 10:59:54 --> Output Class Initialized
INFO - 2021-10-13 10:59:54 --> Security Class Initialized
DEBUG - 2021-10-13 10:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 10:59:54 --> Input Class Initialized
INFO - 2021-10-13 10:59:54 --> Language Class Initialized
INFO - 2021-10-13 10:59:54 --> Loader Class Initialized
INFO - 2021-10-13 10:59:54 --> Helper loaded: url_helper
INFO - 2021-10-13 10:59:54 --> Helper loaded: form_helper
INFO - 2021-10-13 10:59:54 --> Helper loaded: common_helper
INFO - 2021-10-13 10:59:54 --> Database Driver Class Initialized
DEBUG - 2021-10-13 10:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-13 10:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-13 10:59:54 --> Controller Class Initialized
INFO - 2021-10-13 10:59:54 --> Form Validation Class Initialized
DEBUG - 2021-10-13 10:59:54 --> Encrypt Class Initialized
DEBUG - 2021-10-13 10:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-13 10:59:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-13 10:59:54 --> Email Class Initialized
INFO - 2021-10-13 10:59:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-13 10:59:54 --> Calendar Class Initialized
INFO - 2021-10-13 10:59:54 --> Model "Login_model" initialized
INFO - 2021-10-13 10:59:54 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-13 10:59:54 --> Final output sent to browser
DEBUG - 2021-10-13 10:59:54 --> Total execution time: 0.0236
ERROR - 2021-10-13 15:06:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-13 15:06:54 --> Config Class Initialized
INFO - 2021-10-13 15:06:54 --> Hooks Class Initialized
DEBUG - 2021-10-13 15:06:54 --> UTF-8 Support Enabled
INFO - 2021-10-13 15:06:54 --> Utf8 Class Initialized
INFO - 2021-10-13 15:06:54 --> URI Class Initialized
DEBUG - 2021-10-13 15:06:54 --> No URI present. Default controller set.
INFO - 2021-10-13 15:06:54 --> Router Class Initialized
INFO - 2021-10-13 15:06:54 --> Output Class Initialized
INFO - 2021-10-13 15:06:54 --> Security Class Initialized
DEBUG - 2021-10-13 15:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 15:06:54 --> Input Class Initialized
INFO - 2021-10-13 15:06:54 --> Language Class Initialized
INFO - 2021-10-13 15:06:54 --> Loader Class Initialized
INFO - 2021-10-13 15:06:54 --> Helper loaded: url_helper
INFO - 2021-10-13 15:06:54 --> Helper loaded: form_helper
INFO - 2021-10-13 15:06:54 --> Helper loaded: common_helper
INFO - 2021-10-13 15:06:54 --> Database Driver Class Initialized
DEBUG - 2021-10-13 15:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-13 15:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-13 15:06:54 --> Controller Class Initialized
INFO - 2021-10-13 15:06:54 --> Form Validation Class Initialized
DEBUG - 2021-10-13 15:06:54 --> Encrypt Class Initialized
DEBUG - 2021-10-13 15:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-13 15:06:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-13 15:06:54 --> Email Class Initialized
INFO - 2021-10-13 15:06:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-13 15:06:54 --> Calendar Class Initialized
INFO - 2021-10-13 15:06:55 --> Model "Login_model" initialized
INFO - 2021-10-13 15:06:55 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-13 15:06:55 --> Final output sent to browser
DEBUG - 2021-10-13 15:06:55 --> Total execution time: 0.0448
ERROR - 2021-10-13 15:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-13 15:08:46 --> Config Class Initialized
INFO - 2021-10-13 15:08:46 --> Hooks Class Initialized
DEBUG - 2021-10-13 15:08:46 --> UTF-8 Support Enabled
INFO - 2021-10-13 15:08:46 --> Utf8 Class Initialized
INFO - 2021-10-13 15:08:46 --> URI Class Initialized
DEBUG - 2021-10-13 15:08:46 --> No URI present. Default controller set.
INFO - 2021-10-13 15:08:46 --> Router Class Initialized
INFO - 2021-10-13 15:08:46 --> Output Class Initialized
INFO - 2021-10-13 15:08:46 --> Security Class Initialized
DEBUG - 2021-10-13 15:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 15:08:46 --> Input Class Initialized
INFO - 2021-10-13 15:08:46 --> Language Class Initialized
INFO - 2021-10-13 15:08:46 --> Loader Class Initialized
INFO - 2021-10-13 15:08:46 --> Helper loaded: url_helper
INFO - 2021-10-13 15:08:46 --> Helper loaded: form_helper
INFO - 2021-10-13 15:08:46 --> Helper loaded: common_helper
INFO - 2021-10-13 15:08:46 --> Database Driver Class Initialized
DEBUG - 2021-10-13 15:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-13 15:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-13 15:08:46 --> Controller Class Initialized
INFO - 2021-10-13 15:08:46 --> Form Validation Class Initialized
DEBUG - 2021-10-13 15:08:46 --> Encrypt Class Initialized
DEBUG - 2021-10-13 15:08:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-13 15:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-13 15:08:46 --> Email Class Initialized
INFO - 2021-10-13 15:08:46 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-13 15:08:46 --> Calendar Class Initialized
INFO - 2021-10-13 15:08:46 --> Model "Login_model" initialized
INFO - 2021-10-13 15:08:46 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-13 15:08:46 --> Final output sent to browser
DEBUG - 2021-10-13 15:08:46 --> Total execution time: 0.0819
ERROR - 2021-10-13 15:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-13 15:29:01 --> Config Class Initialized
INFO - 2021-10-13 15:29:01 --> Hooks Class Initialized
DEBUG - 2021-10-13 15:29:01 --> UTF-8 Support Enabled
INFO - 2021-10-13 15:29:01 --> Utf8 Class Initialized
INFO - 2021-10-13 15:29:01 --> URI Class Initialized
DEBUG - 2021-10-13 15:29:01 --> No URI present. Default controller set.
INFO - 2021-10-13 15:29:01 --> Router Class Initialized
INFO - 2021-10-13 15:29:01 --> Output Class Initialized
INFO - 2021-10-13 15:29:01 --> Security Class Initialized
DEBUG - 2021-10-13 15:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 15:29:01 --> Input Class Initialized
INFO - 2021-10-13 15:29:01 --> Language Class Initialized
INFO - 2021-10-13 15:29:01 --> Loader Class Initialized
INFO - 2021-10-13 15:29:01 --> Helper loaded: url_helper
INFO - 2021-10-13 15:29:01 --> Helper loaded: form_helper
INFO - 2021-10-13 15:29:01 --> Helper loaded: common_helper
INFO - 2021-10-13 15:29:01 --> Database Driver Class Initialized
DEBUG - 2021-10-13 15:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-13 15:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-13 15:29:01 --> Controller Class Initialized
INFO - 2021-10-13 15:29:01 --> Form Validation Class Initialized
DEBUG - 2021-10-13 15:29:01 --> Encrypt Class Initialized
DEBUG - 2021-10-13 15:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-13 15:29:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-13 15:29:01 --> Email Class Initialized
INFO - 2021-10-13 15:29:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-13 15:29:01 --> Calendar Class Initialized
INFO - 2021-10-13 15:29:01 --> Model "Login_model" initialized
INFO - 2021-10-13 15:29:01 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-13 15:29:01 --> Final output sent to browser
DEBUG - 2021-10-13 15:29:01 --> Total execution time: 0.0479
ERROR - 2021-10-13 15:29:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-13 15:29:28 --> Config Class Initialized
INFO - 2021-10-13 15:29:28 --> Hooks Class Initialized
DEBUG - 2021-10-13 15:29:28 --> UTF-8 Support Enabled
INFO - 2021-10-13 15:29:28 --> Utf8 Class Initialized
INFO - 2021-10-13 15:29:28 --> URI Class Initialized
DEBUG - 2021-10-13 15:29:28 --> No URI present. Default controller set.
INFO - 2021-10-13 15:29:28 --> Router Class Initialized
INFO - 2021-10-13 15:29:28 --> Output Class Initialized
INFO - 2021-10-13 15:29:28 --> Security Class Initialized
DEBUG - 2021-10-13 15:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-13 15:29:28 --> Input Class Initialized
INFO - 2021-10-13 15:29:28 --> Language Class Initialized
INFO - 2021-10-13 15:29:28 --> Loader Class Initialized
INFO - 2021-10-13 15:29:28 --> Helper loaded: url_helper
INFO - 2021-10-13 15:29:28 --> Helper loaded: form_helper
INFO - 2021-10-13 15:29:28 --> Helper loaded: common_helper
INFO - 2021-10-13 15:29:28 --> Database Driver Class Initialized
DEBUG - 2021-10-13 15:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-13 15:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-13 15:29:28 --> Controller Class Initialized
INFO - 2021-10-13 15:29:28 --> Form Validation Class Initialized
DEBUG - 2021-10-13 15:29:28 --> Encrypt Class Initialized
DEBUG - 2021-10-13 15:29:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-10-13 15:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-10-13 15:29:28 --> Email Class Initialized
INFO - 2021-10-13 15:29:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-10-13 15:29:28 --> Calendar Class Initialized
INFO - 2021-10-13 15:29:28 --> Model "Login_model" initialized
INFO - 2021-10-13 15:29:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-10-13 15:29:28 --> Final output sent to browser
DEBUG - 2021-10-13 15:29:28 --> Total execution time: 0.0232
