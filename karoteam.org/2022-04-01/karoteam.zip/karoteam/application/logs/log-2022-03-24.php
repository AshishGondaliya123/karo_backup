<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-24 00:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 00:42:21 --> Config Class Initialized
INFO - 2022-03-24 00:42:21 --> Hooks Class Initialized
DEBUG - 2022-03-24 00:42:21 --> UTF-8 Support Enabled
INFO - 2022-03-24 00:42:21 --> Utf8 Class Initialized
INFO - 2022-03-24 00:42:21 --> URI Class Initialized
DEBUG - 2022-03-24 00:42:21 --> No URI present. Default controller set.
INFO - 2022-03-24 00:42:21 --> Router Class Initialized
INFO - 2022-03-24 00:42:21 --> Output Class Initialized
INFO - 2022-03-24 00:42:21 --> Security Class Initialized
DEBUG - 2022-03-24 00:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 00:42:21 --> Input Class Initialized
INFO - 2022-03-24 00:42:21 --> Language Class Initialized
INFO - 2022-03-24 00:42:21 --> Loader Class Initialized
INFO - 2022-03-24 00:42:21 --> Helper loaded: url_helper
INFO - 2022-03-24 00:42:21 --> Helper loaded: form_helper
INFO - 2022-03-24 00:42:21 --> Helper loaded: common_helper
INFO - 2022-03-24 00:42:21 --> Database Driver Class Initialized
DEBUG - 2022-03-24 00:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 00:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 00:42:21 --> Controller Class Initialized
INFO - 2022-03-24 00:42:21 --> Form Validation Class Initialized
DEBUG - 2022-03-24 00:42:21 --> Encrypt Class Initialized
DEBUG - 2022-03-24 00:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 00:42:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 00:42:21 --> Email Class Initialized
INFO - 2022-03-24 00:42:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 00:42:21 --> Calendar Class Initialized
INFO - 2022-03-24 00:42:21 --> Model "Login_model" initialized
INFO - 2022-03-24 00:42:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 00:42:21 --> Final output sent to browser
DEBUG - 2022-03-24 00:42:21 --> Total execution time: 0.0573
ERROR - 2022-03-24 00:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 00:42:24 --> Config Class Initialized
INFO - 2022-03-24 00:42:24 --> Hooks Class Initialized
DEBUG - 2022-03-24 00:42:24 --> UTF-8 Support Enabled
INFO - 2022-03-24 00:42:24 --> Utf8 Class Initialized
INFO - 2022-03-24 00:42:24 --> URI Class Initialized
INFO - 2022-03-24 00:42:24 --> Router Class Initialized
INFO - 2022-03-24 00:42:24 --> Output Class Initialized
INFO - 2022-03-24 00:42:24 --> Security Class Initialized
DEBUG - 2022-03-24 00:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 00:42:24 --> Input Class Initialized
INFO - 2022-03-24 00:42:24 --> Language Class Initialized
INFO - 2022-03-24 00:42:24 --> Loader Class Initialized
INFO - 2022-03-24 00:42:24 --> Helper loaded: url_helper
INFO - 2022-03-24 00:42:24 --> Helper loaded: form_helper
INFO - 2022-03-24 00:42:24 --> Helper loaded: common_helper
INFO - 2022-03-24 00:42:24 --> Database Driver Class Initialized
DEBUG - 2022-03-24 00:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 00:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 00:42:24 --> Controller Class Initialized
INFO - 2022-03-24 00:42:24 --> Form Validation Class Initialized
DEBUG - 2022-03-24 00:42:24 --> Encrypt Class Initialized
DEBUG - 2022-03-24 00:42:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 00:42:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 00:42:24 --> Email Class Initialized
INFO - 2022-03-24 00:42:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 00:42:24 --> Calendar Class Initialized
INFO - 2022-03-24 00:42:24 --> Model "Login_model" initialized
INFO - 2022-03-24 00:42:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-24 00:42:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 00:42:25 --> Config Class Initialized
INFO - 2022-03-24 00:42:25 --> Hooks Class Initialized
DEBUG - 2022-03-24 00:42:25 --> UTF-8 Support Enabled
INFO - 2022-03-24 00:42:25 --> Utf8 Class Initialized
INFO - 2022-03-24 00:42:25 --> URI Class Initialized
INFO - 2022-03-24 00:42:25 --> Router Class Initialized
INFO - 2022-03-24 00:42:25 --> Output Class Initialized
INFO - 2022-03-24 00:42:25 --> Security Class Initialized
DEBUG - 2022-03-24 00:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 00:42:25 --> Input Class Initialized
INFO - 2022-03-24 00:42:25 --> Language Class Initialized
INFO - 2022-03-24 00:42:25 --> Loader Class Initialized
INFO - 2022-03-24 00:42:25 --> Helper loaded: url_helper
INFO - 2022-03-24 00:42:25 --> Helper loaded: form_helper
INFO - 2022-03-24 00:42:25 --> Helper loaded: common_helper
INFO - 2022-03-24 00:42:25 --> Database Driver Class Initialized
DEBUG - 2022-03-24 00:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 00:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 00:42:25 --> Controller Class Initialized
INFO - 2022-03-24 00:42:25 --> Form Validation Class Initialized
DEBUG - 2022-03-24 00:42:25 --> Encrypt Class Initialized
INFO - 2022-03-24 00:42:25 --> Model "Login_model" initialized
INFO - 2022-03-24 00:42:25 --> Model "Dashboard_model" initialized
INFO - 2022-03-24 00:42:25 --> Model "Case_model" initialized
INFO - 2022-03-24 00:42:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 00:42:51 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-24 00:42:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 00:42:51 --> Final output sent to browser
DEBUG - 2022-03-24 00:42:51 --> Total execution time: 25.4350
ERROR - 2022-03-24 00:43:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 00:43:06 --> Config Class Initialized
INFO - 2022-03-24 00:43:06 --> Hooks Class Initialized
DEBUG - 2022-03-24 00:43:06 --> UTF-8 Support Enabled
INFO - 2022-03-24 00:43:06 --> Utf8 Class Initialized
INFO - 2022-03-24 00:43:06 --> URI Class Initialized
INFO - 2022-03-24 00:43:06 --> Router Class Initialized
INFO - 2022-03-24 00:43:06 --> Output Class Initialized
INFO - 2022-03-24 00:43:06 --> Security Class Initialized
DEBUG - 2022-03-24 00:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 00:43:06 --> Input Class Initialized
INFO - 2022-03-24 00:43:06 --> Language Class Initialized
INFO - 2022-03-24 00:43:06 --> Loader Class Initialized
INFO - 2022-03-24 00:43:06 --> Helper loaded: url_helper
INFO - 2022-03-24 00:43:06 --> Helper loaded: form_helper
INFO - 2022-03-24 00:43:06 --> Helper loaded: common_helper
INFO - 2022-03-24 00:43:06 --> Database Driver Class Initialized
DEBUG - 2022-03-24 00:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 00:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 00:43:06 --> Controller Class Initialized
INFO - 2022-03-24 00:43:06 --> Form Validation Class Initialized
DEBUG - 2022-03-24 00:43:06 --> Encrypt Class Initialized
INFO - 2022-03-24 00:43:06 --> Model "Patient_model" initialized
INFO - 2022-03-24 00:43:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 00:43:06 --> Model "Referredby_model" initialized
INFO - 2022-03-24 00:43:06 --> Model "Prefix_master" initialized
INFO - 2022-03-24 00:43:06 --> Model "Hospital_model" initialized
INFO - 2022-03-24 00:43:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 00:43:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-24 00:43:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 00:43:14 --> Final output sent to browser
DEBUG - 2022-03-24 00:43:14 --> Total execution time: 5.9932
ERROR - 2022-03-24 00:44:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 00:44:33 --> Config Class Initialized
INFO - 2022-03-24 00:44:33 --> Hooks Class Initialized
DEBUG - 2022-03-24 00:44:33 --> UTF-8 Support Enabled
INFO - 2022-03-24 00:44:33 --> Utf8 Class Initialized
INFO - 2022-03-24 00:44:33 --> URI Class Initialized
INFO - 2022-03-24 00:44:33 --> Router Class Initialized
INFO - 2022-03-24 00:44:33 --> Output Class Initialized
INFO - 2022-03-24 00:44:33 --> Security Class Initialized
DEBUG - 2022-03-24 00:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 00:44:33 --> Input Class Initialized
INFO - 2022-03-24 00:44:33 --> Language Class Initialized
INFO - 2022-03-24 00:44:34 --> Loader Class Initialized
INFO - 2022-03-24 00:44:34 --> Helper loaded: url_helper
INFO - 2022-03-24 00:44:34 --> Helper loaded: form_helper
INFO - 2022-03-24 00:44:34 --> Helper loaded: common_helper
INFO - 2022-03-24 00:44:34 --> Database Driver Class Initialized
DEBUG - 2022-03-24 00:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 00:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 00:44:34 --> Controller Class Initialized
INFO - 2022-03-24 00:44:34 --> Form Validation Class Initialized
DEBUG - 2022-03-24 00:44:34 --> Encrypt Class Initialized
INFO - 2022-03-24 00:44:34 --> Model "Patient_model" initialized
INFO - 2022-03-24 00:44:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 00:44:34 --> Model "Prefix_master" initialized
INFO - 2022-03-24 00:44:34 --> Model "Users_model" initialized
INFO - 2022-03-24 00:44:34 --> Model "Hospital_model" initialized
INFO - 2022-03-24 00:44:36 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-24 00:44:38 --> Final output sent to browser
DEBUG - 2022-03-24 00:44:38 --> Total execution time: 4.1536
ERROR - 2022-03-24 03:35:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 03:35:20 --> Config Class Initialized
INFO - 2022-03-24 03:35:20 --> Hooks Class Initialized
DEBUG - 2022-03-24 03:35:20 --> UTF-8 Support Enabled
INFO - 2022-03-24 03:35:20 --> Utf8 Class Initialized
INFO - 2022-03-24 03:35:20 --> URI Class Initialized
INFO - 2022-03-24 03:35:20 --> Router Class Initialized
INFO - 2022-03-24 03:35:20 --> Output Class Initialized
INFO - 2022-03-24 03:35:20 --> Security Class Initialized
DEBUG - 2022-03-24 03:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 03:35:20 --> Input Class Initialized
INFO - 2022-03-24 03:35:20 --> Language Class Initialized
INFO - 2022-03-24 03:35:20 --> Loader Class Initialized
INFO - 2022-03-24 03:35:20 --> Helper loaded: url_helper
INFO - 2022-03-24 03:35:20 --> Helper loaded: form_helper
INFO - 2022-03-24 03:35:20 --> Helper loaded: common_helper
INFO - 2022-03-24 03:35:20 --> Database Driver Class Initialized
DEBUG - 2022-03-24 03:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 03:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 03:35:20 --> Controller Class Initialized
ERROR - 2022-03-24 03:35:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 03:35:21 --> Config Class Initialized
INFO - 2022-03-24 03:35:21 --> Hooks Class Initialized
DEBUG - 2022-03-24 03:35:21 --> UTF-8 Support Enabled
INFO - 2022-03-24 03:35:21 --> Utf8 Class Initialized
INFO - 2022-03-24 03:35:21 --> URI Class Initialized
INFO - 2022-03-24 03:35:21 --> Router Class Initialized
INFO - 2022-03-24 03:35:21 --> Output Class Initialized
INFO - 2022-03-24 03:35:21 --> Security Class Initialized
DEBUG - 2022-03-24 03:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 03:35:21 --> Input Class Initialized
INFO - 2022-03-24 03:35:21 --> Language Class Initialized
INFO - 2022-03-24 03:35:21 --> Loader Class Initialized
INFO - 2022-03-24 03:35:21 --> Helper loaded: url_helper
INFO - 2022-03-24 03:35:21 --> Helper loaded: form_helper
INFO - 2022-03-24 03:35:21 --> Helper loaded: common_helper
INFO - 2022-03-24 03:35:21 --> Database Driver Class Initialized
DEBUG - 2022-03-24 03:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 03:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 03:35:21 --> Controller Class Initialized
INFO - 2022-03-24 03:35:21 --> Form Validation Class Initialized
DEBUG - 2022-03-24 03:35:21 --> Encrypt Class Initialized
DEBUG - 2022-03-24 03:35:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 03:35:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 03:35:21 --> Email Class Initialized
INFO - 2022-03-24 03:35:21 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 03:35:21 --> Calendar Class Initialized
INFO - 2022-03-24 03:35:21 --> Model "Login_model" initialized
INFO - 2022-03-24 03:35:21 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 03:35:21 --> Final output sent to browser
DEBUG - 2022-03-24 03:35:21 --> Total execution time: 0.0338
ERROR - 2022-03-24 04:17:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:17:09 --> Config Class Initialized
INFO - 2022-03-24 04:17:09 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:17:09 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:17:09 --> Utf8 Class Initialized
INFO - 2022-03-24 04:17:09 --> URI Class Initialized
DEBUG - 2022-03-24 04:17:09 --> No URI present. Default controller set.
INFO - 2022-03-24 04:17:09 --> Router Class Initialized
INFO - 2022-03-24 04:17:09 --> Output Class Initialized
INFO - 2022-03-24 04:17:09 --> Security Class Initialized
DEBUG - 2022-03-24 04:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:17:09 --> Input Class Initialized
INFO - 2022-03-24 04:17:09 --> Language Class Initialized
INFO - 2022-03-24 04:17:09 --> Loader Class Initialized
INFO - 2022-03-24 04:17:09 --> Helper loaded: url_helper
INFO - 2022-03-24 04:17:09 --> Helper loaded: form_helper
INFO - 2022-03-24 04:17:09 --> Helper loaded: common_helper
INFO - 2022-03-24 04:17:09 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:17:09 --> Controller Class Initialized
INFO - 2022-03-24 04:17:09 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:17:09 --> Encrypt Class Initialized
DEBUG - 2022-03-24 04:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 04:17:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 04:17:09 --> Email Class Initialized
INFO - 2022-03-24 04:17:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 04:17:09 --> Calendar Class Initialized
INFO - 2022-03-24 04:17:09 --> Model "Login_model" initialized
INFO - 2022-03-24 04:17:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 04:17:09 --> Final output sent to browser
DEBUG - 2022-03-24 04:17:09 --> Total execution time: 0.0581
ERROR - 2022-03-24 04:39:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:39:52 --> Config Class Initialized
INFO - 2022-03-24 04:39:52 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:39:52 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:39:52 --> Utf8 Class Initialized
INFO - 2022-03-24 04:39:52 --> URI Class Initialized
INFO - 2022-03-24 04:39:52 --> Router Class Initialized
INFO - 2022-03-24 04:39:52 --> Output Class Initialized
INFO - 2022-03-24 04:39:52 --> Security Class Initialized
DEBUG - 2022-03-24 04:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:39:52 --> Input Class Initialized
INFO - 2022-03-24 04:39:52 --> Language Class Initialized
INFO - 2022-03-24 04:39:52 --> Loader Class Initialized
INFO - 2022-03-24 04:39:52 --> Helper loaded: url_helper
INFO - 2022-03-24 04:39:52 --> Helper loaded: form_helper
INFO - 2022-03-24 04:39:52 --> Helper loaded: common_helper
INFO - 2022-03-24 04:39:52 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:39:52 --> Controller Class Initialized
ERROR - 2022-03-24 04:39:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:39:53 --> Config Class Initialized
INFO - 2022-03-24 04:39:53 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:39:53 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:39:53 --> Utf8 Class Initialized
INFO - 2022-03-24 04:39:53 --> URI Class Initialized
INFO - 2022-03-24 04:39:53 --> Router Class Initialized
INFO - 2022-03-24 04:39:53 --> Output Class Initialized
INFO - 2022-03-24 04:39:53 --> Security Class Initialized
DEBUG - 2022-03-24 04:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:39:53 --> Input Class Initialized
INFO - 2022-03-24 04:39:53 --> Language Class Initialized
INFO - 2022-03-24 04:39:53 --> Loader Class Initialized
INFO - 2022-03-24 04:39:53 --> Helper loaded: url_helper
INFO - 2022-03-24 04:39:53 --> Helper loaded: form_helper
INFO - 2022-03-24 04:39:53 --> Helper loaded: common_helper
INFO - 2022-03-24 04:39:53 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:39:53 --> Controller Class Initialized
INFO - 2022-03-24 04:39:53 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:39:53 --> Encrypt Class Initialized
DEBUG - 2022-03-24 04:39:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 04:39:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 04:39:53 --> Email Class Initialized
INFO - 2022-03-24 04:39:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 04:39:53 --> Calendar Class Initialized
INFO - 2022-03-24 04:39:53 --> Model "Login_model" initialized
INFO - 2022-03-24 04:39:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 04:39:53 --> Final output sent to browser
DEBUG - 2022-03-24 04:39:53 --> Total execution time: 0.0258
ERROR - 2022-03-24 04:40:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:40:07 --> Config Class Initialized
INFO - 2022-03-24 04:40:07 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:40:07 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:40:07 --> Utf8 Class Initialized
INFO - 2022-03-24 04:40:07 --> URI Class Initialized
INFO - 2022-03-24 04:40:07 --> Router Class Initialized
INFO - 2022-03-24 04:40:07 --> Output Class Initialized
INFO - 2022-03-24 04:40:07 --> Security Class Initialized
DEBUG - 2022-03-24 04:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:40:07 --> Input Class Initialized
INFO - 2022-03-24 04:40:07 --> Language Class Initialized
INFO - 2022-03-24 04:40:07 --> Loader Class Initialized
INFO - 2022-03-24 04:40:07 --> Helper loaded: url_helper
INFO - 2022-03-24 04:40:07 --> Helper loaded: form_helper
INFO - 2022-03-24 04:40:07 --> Helper loaded: common_helper
INFO - 2022-03-24 04:40:07 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:40:07 --> Controller Class Initialized
INFO - 2022-03-24 04:40:07 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:40:07 --> Encrypt Class Initialized
DEBUG - 2022-03-24 04:40:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 04:40:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 04:40:07 --> Email Class Initialized
INFO - 2022-03-24 04:40:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 04:40:07 --> Calendar Class Initialized
INFO - 2022-03-24 04:40:07 --> Model "Login_model" initialized
INFO - 2022-03-24 04:40:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-24 04:40:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:40:07 --> Config Class Initialized
INFO - 2022-03-24 04:40:07 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:40:07 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:40:07 --> Utf8 Class Initialized
INFO - 2022-03-24 04:40:07 --> URI Class Initialized
INFO - 2022-03-24 04:40:07 --> Router Class Initialized
INFO - 2022-03-24 04:40:07 --> Output Class Initialized
INFO - 2022-03-24 04:40:07 --> Security Class Initialized
DEBUG - 2022-03-24 04:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:40:07 --> Input Class Initialized
INFO - 2022-03-24 04:40:07 --> Language Class Initialized
INFO - 2022-03-24 04:40:07 --> Loader Class Initialized
INFO - 2022-03-24 04:40:07 --> Helper loaded: url_helper
INFO - 2022-03-24 04:40:07 --> Helper loaded: form_helper
INFO - 2022-03-24 04:40:07 --> Helper loaded: common_helper
INFO - 2022-03-24 04:40:07 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:40:07 --> Controller Class Initialized
INFO - 2022-03-24 04:40:07 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:40:07 --> Encrypt Class Initialized
DEBUG - 2022-03-24 04:40:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 04:40:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 04:40:07 --> Email Class Initialized
INFO - 2022-03-24 04:40:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 04:40:07 --> Calendar Class Initialized
INFO - 2022-03-24 04:40:07 --> Model "Login_model" initialized
INFO - 2022-03-24 04:40:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 04:40:07 --> Final output sent to browser
DEBUG - 2022-03-24 04:40:07 --> Total execution time: 0.0086
ERROR - 2022-03-24 04:41:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:41:59 --> Config Class Initialized
INFO - 2022-03-24 04:41:59 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:41:59 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:41:59 --> Utf8 Class Initialized
INFO - 2022-03-24 04:41:59 --> URI Class Initialized
INFO - 2022-03-24 04:41:59 --> Router Class Initialized
INFO - 2022-03-24 04:41:59 --> Output Class Initialized
INFO - 2022-03-24 04:41:59 --> Security Class Initialized
DEBUG - 2022-03-24 04:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:41:59 --> Input Class Initialized
INFO - 2022-03-24 04:41:59 --> Language Class Initialized
INFO - 2022-03-24 04:41:59 --> Loader Class Initialized
INFO - 2022-03-24 04:41:59 --> Helper loaded: url_helper
INFO - 2022-03-24 04:41:59 --> Helper loaded: form_helper
INFO - 2022-03-24 04:41:59 --> Helper loaded: common_helper
INFO - 2022-03-24 04:41:59 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:41:59 --> Controller Class Initialized
INFO - 2022-03-24 04:41:59 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:41:59 --> Encrypt Class Initialized
DEBUG - 2022-03-24 04:41:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 04:41:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 04:41:59 --> Email Class Initialized
INFO - 2022-03-24 04:41:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 04:41:59 --> Calendar Class Initialized
INFO - 2022-03-24 04:41:59 --> Model "Login_model" initialized
INFO - 2022-03-24 04:41:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-24 04:41:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:41:59 --> Config Class Initialized
INFO - 2022-03-24 04:41:59 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:41:59 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:41:59 --> Utf8 Class Initialized
INFO - 2022-03-24 04:41:59 --> URI Class Initialized
INFO - 2022-03-24 04:41:59 --> Router Class Initialized
INFO - 2022-03-24 04:41:59 --> Output Class Initialized
INFO - 2022-03-24 04:41:59 --> Security Class Initialized
DEBUG - 2022-03-24 04:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:41:59 --> Input Class Initialized
INFO - 2022-03-24 04:41:59 --> Language Class Initialized
INFO - 2022-03-24 04:41:59 --> Loader Class Initialized
INFO - 2022-03-24 04:41:59 --> Helper loaded: url_helper
INFO - 2022-03-24 04:41:59 --> Helper loaded: form_helper
INFO - 2022-03-24 04:41:59 --> Helper loaded: common_helper
INFO - 2022-03-24 04:41:59 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:41:59 --> Controller Class Initialized
INFO - 2022-03-24 04:41:59 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:41:59 --> Encrypt Class Initialized
INFO - 2022-03-24 04:41:59 --> Model "Login_model" initialized
INFO - 2022-03-24 04:41:59 --> Model "Dashboard_model" initialized
INFO - 2022-03-24 04:41:59 --> Model "Case_model" initialized
INFO - 2022-03-24 04:42:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 04:42:00 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-24 04:42:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 04:42:00 --> Final output sent to browser
DEBUG - 2022-03-24 04:42:00 --> Total execution time: 0.5805
ERROR - 2022-03-24 04:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:44:22 --> Config Class Initialized
INFO - 2022-03-24 04:44:22 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:44:22 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:44:22 --> Utf8 Class Initialized
INFO - 2022-03-24 04:44:22 --> URI Class Initialized
INFO - 2022-03-24 04:44:22 --> Router Class Initialized
INFO - 2022-03-24 04:44:22 --> Output Class Initialized
INFO - 2022-03-24 04:44:22 --> Security Class Initialized
DEBUG - 2022-03-24 04:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:44:22 --> Input Class Initialized
INFO - 2022-03-24 04:44:22 --> Language Class Initialized
INFO - 2022-03-24 04:44:22 --> Loader Class Initialized
INFO - 2022-03-24 04:44:22 --> Helper loaded: url_helper
INFO - 2022-03-24 04:44:22 --> Helper loaded: form_helper
INFO - 2022-03-24 04:44:22 --> Helper loaded: common_helper
INFO - 2022-03-24 04:44:22 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:44:22 --> Controller Class Initialized
INFO - 2022-03-24 04:44:22 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:44:22 --> Encrypt Class Initialized
INFO - 2022-03-24 04:44:22 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:44:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:44:22 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:44:22 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:44:22 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:44:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 04:44:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-24 04:44:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 04:44:22 --> Final output sent to browser
DEBUG - 2022-03-24 04:44:22 --> Total execution time: 0.1055
ERROR - 2022-03-24 04:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:44:26 --> Config Class Initialized
INFO - 2022-03-24 04:44:26 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:44:26 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:44:26 --> Utf8 Class Initialized
INFO - 2022-03-24 04:44:26 --> URI Class Initialized
INFO - 2022-03-24 04:44:26 --> Router Class Initialized
INFO - 2022-03-24 04:44:26 --> Output Class Initialized
INFO - 2022-03-24 04:44:26 --> Security Class Initialized
DEBUG - 2022-03-24 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:44:26 --> Input Class Initialized
INFO - 2022-03-24 04:44:26 --> Language Class Initialized
INFO - 2022-03-24 04:44:26 --> Loader Class Initialized
INFO - 2022-03-24 04:44:26 --> Helper loaded: url_helper
INFO - 2022-03-24 04:44:26 --> Helper loaded: form_helper
INFO - 2022-03-24 04:44:26 --> Helper loaded: common_helper
INFO - 2022-03-24 04:44:26 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:44:26 --> Controller Class Initialized
ERROR - 2022-03-24 04:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:44:26 --> Config Class Initialized
INFO - 2022-03-24 04:44:26 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:44:26 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:44:26 --> Utf8 Class Initialized
INFO - 2022-03-24 04:44:26 --> URI Class Initialized
INFO - 2022-03-24 04:44:26 --> Router Class Initialized
INFO - 2022-03-24 04:44:26 --> Output Class Initialized
INFO - 2022-03-24 04:44:26 --> Security Class Initialized
DEBUG - 2022-03-24 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:44:26 --> Input Class Initialized
INFO - 2022-03-24 04:44:26 --> Language Class Initialized
INFO - 2022-03-24 04:44:26 --> Loader Class Initialized
INFO - 2022-03-24 04:44:26 --> Helper loaded: url_helper
INFO - 2022-03-24 04:44:26 --> Helper loaded: form_helper
INFO - 2022-03-24 04:44:26 --> Helper loaded: common_helper
INFO - 2022-03-24 04:44:26 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:44:26 --> Controller Class Initialized
INFO - 2022-03-24 04:44:26 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:44:26 --> Encrypt Class Initialized
DEBUG - 2022-03-24 04:44:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 04:44:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 04:44:26 --> Email Class Initialized
INFO - 2022-03-24 04:44:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 04:44:26 --> Calendar Class Initialized
INFO - 2022-03-24 04:44:26 --> Model "Login_model" initialized
INFO - 2022-03-24 04:44:26 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 04:44:26 --> Final output sent to browser
DEBUG - 2022-03-24 04:44:26 --> Total execution time: 0.0264
ERROR - 2022-03-24 04:44:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:44:30 --> Config Class Initialized
INFO - 2022-03-24 04:44:30 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:44:30 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:44:30 --> Utf8 Class Initialized
INFO - 2022-03-24 04:44:30 --> URI Class Initialized
INFO - 2022-03-24 04:44:30 --> Router Class Initialized
INFO - 2022-03-24 04:44:30 --> Output Class Initialized
INFO - 2022-03-24 04:44:30 --> Security Class Initialized
DEBUG - 2022-03-24 04:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:44:30 --> Input Class Initialized
INFO - 2022-03-24 04:44:30 --> Language Class Initialized
INFO - 2022-03-24 04:44:30 --> Loader Class Initialized
INFO - 2022-03-24 04:44:30 --> Helper loaded: url_helper
INFO - 2022-03-24 04:44:30 --> Helper loaded: form_helper
INFO - 2022-03-24 04:44:30 --> Helper loaded: common_helper
INFO - 2022-03-24 04:44:30 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:44:30 --> Controller Class Initialized
INFO - 2022-03-24 04:44:30 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:44:30 --> Encrypt Class Initialized
DEBUG - 2022-03-24 04:44:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 04:44:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 04:44:30 --> Email Class Initialized
INFO - 2022-03-24 04:44:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 04:44:30 --> Calendar Class Initialized
INFO - 2022-03-24 04:44:30 --> Model "Login_model" initialized
INFO - 2022-03-24 04:44:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-24 04:44:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:44:30 --> Config Class Initialized
INFO - 2022-03-24 04:44:30 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:44:30 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:44:30 --> Utf8 Class Initialized
INFO - 2022-03-24 04:44:30 --> URI Class Initialized
INFO - 2022-03-24 04:44:30 --> Router Class Initialized
INFO - 2022-03-24 04:44:30 --> Output Class Initialized
INFO - 2022-03-24 04:44:30 --> Security Class Initialized
DEBUG - 2022-03-24 04:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:44:30 --> Input Class Initialized
INFO - 2022-03-24 04:44:30 --> Language Class Initialized
INFO - 2022-03-24 04:44:30 --> Loader Class Initialized
INFO - 2022-03-24 04:44:30 --> Helper loaded: url_helper
INFO - 2022-03-24 04:44:30 --> Helper loaded: form_helper
INFO - 2022-03-24 04:44:30 --> Helper loaded: common_helper
INFO - 2022-03-24 04:44:30 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:44:30 --> Controller Class Initialized
INFO - 2022-03-24 04:44:30 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:44:30 --> Encrypt Class Initialized
INFO - 2022-03-24 04:44:30 --> Model "Login_model" initialized
INFO - 2022-03-24 04:44:30 --> Model "Dashboard_model" initialized
INFO - 2022-03-24 04:44:30 --> Model "Case_model" initialized
INFO - 2022-03-24 04:44:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 04:44:49 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-24 04:44:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 04:44:49 --> Final output sent to browser
DEBUG - 2022-03-24 04:44:49 --> Total execution time: 18.9937
ERROR - 2022-03-24 04:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:44:57 --> Config Class Initialized
INFO - 2022-03-24 04:44:57 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:44:57 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:44:57 --> Utf8 Class Initialized
INFO - 2022-03-24 04:44:57 --> URI Class Initialized
INFO - 2022-03-24 04:44:57 --> Router Class Initialized
INFO - 2022-03-24 04:44:57 --> Output Class Initialized
INFO - 2022-03-24 04:44:57 --> Security Class Initialized
DEBUG - 2022-03-24 04:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:44:57 --> Input Class Initialized
INFO - 2022-03-24 04:44:57 --> Language Class Initialized
INFO - 2022-03-24 04:44:57 --> Loader Class Initialized
INFO - 2022-03-24 04:44:57 --> Helper loaded: url_helper
INFO - 2022-03-24 04:44:57 --> Helper loaded: form_helper
INFO - 2022-03-24 04:44:57 --> Helper loaded: common_helper
INFO - 2022-03-24 04:44:57 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:44:57 --> Controller Class Initialized
INFO - 2022-03-24 04:44:57 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:44:57 --> Encrypt Class Initialized
INFO - 2022-03-24 04:44:57 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:44:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:44:57 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:44:57 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:44:57 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:44:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 04:44:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 04:44:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 04:44:57 --> Final output sent to browser
DEBUG - 2022-03-24 04:44:57 --> Total execution time: 0.0273
ERROR - 2022-03-24 04:44:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:44:58 --> Config Class Initialized
INFO - 2022-03-24 04:44:58 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:44:58 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:44:58 --> Utf8 Class Initialized
INFO - 2022-03-24 04:44:58 --> URI Class Initialized
INFO - 2022-03-24 04:44:58 --> Router Class Initialized
INFO - 2022-03-24 04:44:58 --> Output Class Initialized
INFO - 2022-03-24 04:44:58 --> Security Class Initialized
DEBUG - 2022-03-24 04:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:44:58 --> Input Class Initialized
INFO - 2022-03-24 04:44:58 --> Language Class Initialized
INFO - 2022-03-24 04:44:58 --> Loader Class Initialized
INFO - 2022-03-24 04:44:58 --> Helper loaded: url_helper
INFO - 2022-03-24 04:44:58 --> Helper loaded: form_helper
INFO - 2022-03-24 04:44:58 --> Helper loaded: common_helper
INFO - 2022-03-24 04:44:58 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:44:58 --> Controller Class Initialized
INFO - 2022-03-24 04:44:58 --> Form Validation Class Initialized
INFO - 2022-03-24 04:44:58 --> Model "Case_model" initialized
INFO - 2022-03-24 04:44:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:44:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 04:44:58 --> File loaded: /home3/karoteam/public_html/application/views/cases/closed_case.php
INFO - 2022-03-24 04:44:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 04:44:58 --> Final output sent to browser
DEBUG - 2022-03-24 04:44:58 --> Total execution time: 0.0408
ERROR - 2022-03-24 04:45:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:45:38 --> Config Class Initialized
INFO - 2022-03-24 04:45:38 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:45:38 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:45:38 --> Utf8 Class Initialized
INFO - 2022-03-24 04:45:38 --> URI Class Initialized
INFO - 2022-03-24 04:45:38 --> Router Class Initialized
INFO - 2022-03-24 04:45:38 --> Output Class Initialized
INFO - 2022-03-24 04:45:38 --> Security Class Initialized
DEBUG - 2022-03-24 04:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:45:38 --> Input Class Initialized
INFO - 2022-03-24 04:45:38 --> Language Class Initialized
INFO - 2022-03-24 04:45:38 --> Loader Class Initialized
INFO - 2022-03-24 04:45:38 --> Helper loaded: url_helper
INFO - 2022-03-24 04:45:38 --> Helper loaded: form_helper
INFO - 2022-03-24 04:45:38 --> Helper loaded: common_helper
INFO - 2022-03-24 04:45:38 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:45:38 --> Controller Class Initialized
INFO - 2022-03-24 04:45:38 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:45:38 --> Encrypt Class Initialized
INFO - 2022-03-24 04:45:38 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:45:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:45:38 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:45:38 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:45:38 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:45:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 04:45:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 04:45:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 04:45:38 --> Final output sent to browser
DEBUG - 2022-03-24 04:45:38 --> Total execution time: 0.0125
ERROR - 2022-03-24 04:47:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:47:08 --> Config Class Initialized
INFO - 2022-03-24 04:47:08 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:47:08 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:47:08 --> Utf8 Class Initialized
INFO - 2022-03-24 04:47:08 --> URI Class Initialized
INFO - 2022-03-24 04:47:08 --> Router Class Initialized
INFO - 2022-03-24 04:47:08 --> Output Class Initialized
INFO - 2022-03-24 04:47:08 --> Security Class Initialized
DEBUG - 2022-03-24 04:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:47:08 --> Input Class Initialized
INFO - 2022-03-24 04:47:08 --> Language Class Initialized
INFO - 2022-03-24 04:47:08 --> Loader Class Initialized
INFO - 2022-03-24 04:47:08 --> Helper loaded: url_helper
INFO - 2022-03-24 04:47:08 --> Helper loaded: form_helper
INFO - 2022-03-24 04:47:08 --> Helper loaded: common_helper
INFO - 2022-03-24 04:47:08 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:47:08 --> Controller Class Initialized
INFO - 2022-03-24 04:47:08 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:47:08 --> Final output sent to browser
DEBUG - 2022-03-24 04:47:08 --> Total execution time: 0.0100
ERROR - 2022-03-24 04:47:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:47:54 --> Config Class Initialized
INFO - 2022-03-24 04:47:54 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:47:54 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:47:54 --> Utf8 Class Initialized
INFO - 2022-03-24 04:47:54 --> URI Class Initialized
INFO - 2022-03-24 04:47:54 --> Router Class Initialized
INFO - 2022-03-24 04:47:54 --> Output Class Initialized
INFO - 2022-03-24 04:47:54 --> Security Class Initialized
DEBUG - 2022-03-24 04:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:47:54 --> Input Class Initialized
INFO - 2022-03-24 04:47:54 --> Language Class Initialized
INFO - 2022-03-24 04:47:54 --> Loader Class Initialized
INFO - 2022-03-24 04:47:54 --> Helper loaded: url_helper
INFO - 2022-03-24 04:47:54 --> Helper loaded: form_helper
INFO - 2022-03-24 04:47:54 --> Helper loaded: common_helper
INFO - 2022-03-24 04:47:54 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:47:54 --> Controller Class Initialized
INFO - 2022-03-24 04:47:54 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:47:54 --> Encrypt Class Initialized
INFO - 2022-03-24 04:47:54 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:47:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:47:54 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:47:54 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:47:54 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:47:54 --> Final output sent to browser
DEBUG - 2022-03-24 04:47:54 --> Total execution time: 0.0124
ERROR - 2022-03-24 04:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:48:04 --> Config Class Initialized
INFO - 2022-03-24 04:48:04 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:48:04 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:48:04 --> Utf8 Class Initialized
INFO - 2022-03-24 04:48:04 --> URI Class Initialized
INFO - 2022-03-24 04:48:04 --> Router Class Initialized
INFO - 2022-03-24 04:48:04 --> Output Class Initialized
INFO - 2022-03-24 04:48:04 --> Security Class Initialized
DEBUG - 2022-03-24 04:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:48:04 --> Input Class Initialized
INFO - 2022-03-24 04:48:04 --> Language Class Initialized
INFO - 2022-03-24 04:48:04 --> Loader Class Initialized
INFO - 2022-03-24 04:48:04 --> Helper loaded: url_helper
INFO - 2022-03-24 04:48:04 --> Helper loaded: form_helper
INFO - 2022-03-24 04:48:04 --> Helper loaded: common_helper
INFO - 2022-03-24 04:48:04 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:48:04 --> Controller Class Initialized
INFO - 2022-03-24 04:48:04 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:48:04 --> Encrypt Class Initialized
INFO - 2022-03-24 04:48:04 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:48:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:48:04 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:48:04 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:48:04 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:48:04 --> Final output sent to browser
DEBUG - 2022-03-24 04:48:04 --> Total execution time: 0.0118
ERROR - 2022-03-24 04:48:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:48:11 --> Config Class Initialized
INFO - 2022-03-24 04:48:11 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:48:11 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:48:11 --> Utf8 Class Initialized
INFO - 2022-03-24 04:48:11 --> URI Class Initialized
INFO - 2022-03-24 04:48:11 --> Router Class Initialized
INFO - 2022-03-24 04:48:11 --> Output Class Initialized
INFO - 2022-03-24 04:48:11 --> Security Class Initialized
DEBUG - 2022-03-24 04:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:48:11 --> Input Class Initialized
INFO - 2022-03-24 04:48:11 --> Language Class Initialized
INFO - 2022-03-24 04:48:11 --> Loader Class Initialized
INFO - 2022-03-24 04:48:11 --> Helper loaded: url_helper
INFO - 2022-03-24 04:48:11 --> Helper loaded: form_helper
INFO - 2022-03-24 04:48:11 --> Helper loaded: common_helper
INFO - 2022-03-24 04:48:11 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:48:11 --> Controller Class Initialized
INFO - 2022-03-24 04:48:11 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:48:11 --> Encrypt Class Initialized
INFO - 2022-03-24 04:48:11 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:48:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:48:11 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:48:11 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:48:11 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:48:11 --> Final output sent to browser
DEBUG - 2022-03-24 04:48:11 --> Total execution time: 0.0158
ERROR - 2022-03-24 04:51:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:51:44 --> Config Class Initialized
INFO - 2022-03-24 04:51:44 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:51:44 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:51:44 --> Utf8 Class Initialized
INFO - 2022-03-24 04:51:44 --> URI Class Initialized
INFO - 2022-03-24 04:51:44 --> Router Class Initialized
INFO - 2022-03-24 04:51:44 --> Output Class Initialized
INFO - 2022-03-24 04:51:44 --> Security Class Initialized
DEBUG - 2022-03-24 04:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:51:44 --> Input Class Initialized
INFO - 2022-03-24 04:51:44 --> Language Class Initialized
INFO - 2022-03-24 04:51:44 --> Loader Class Initialized
INFO - 2022-03-24 04:51:44 --> Helper loaded: url_helper
INFO - 2022-03-24 04:51:44 --> Helper loaded: form_helper
INFO - 2022-03-24 04:51:44 --> Helper loaded: common_helper
INFO - 2022-03-24 04:51:44 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:51:44 --> Controller Class Initialized
INFO - 2022-03-24 04:51:44 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:51:44 --> Encrypt Class Initialized
INFO - 2022-03-24 04:51:44 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:51:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:51:44 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:51:44 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:51:44 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:51:44 --> Upload Class Initialized
INFO - 2022-03-24 04:51:44 --> Final output sent to browser
DEBUG - 2022-03-24 04:51:44 --> Total execution time: 0.0559
ERROR - 2022-03-24 04:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:54:05 --> Config Class Initialized
INFO - 2022-03-24 04:54:05 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:54:05 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:54:05 --> Utf8 Class Initialized
INFO - 2022-03-24 04:54:05 --> URI Class Initialized
INFO - 2022-03-24 04:54:05 --> Router Class Initialized
INFO - 2022-03-24 04:54:05 --> Output Class Initialized
INFO - 2022-03-24 04:54:05 --> Security Class Initialized
DEBUG - 2022-03-24 04:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:54:05 --> Input Class Initialized
INFO - 2022-03-24 04:54:05 --> Language Class Initialized
INFO - 2022-03-24 04:54:05 --> Loader Class Initialized
INFO - 2022-03-24 04:54:05 --> Helper loaded: url_helper
INFO - 2022-03-24 04:54:05 --> Helper loaded: form_helper
INFO - 2022-03-24 04:54:05 --> Helper loaded: common_helper
INFO - 2022-03-24 04:54:05 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:54:05 --> Controller Class Initialized
INFO - 2022-03-24 04:54:05 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:54:05 --> Final output sent to browser
DEBUG - 2022-03-24 04:54:05 --> Total execution time: 0.0644
ERROR - 2022-03-24 04:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:55:13 --> Config Class Initialized
INFO - 2022-03-24 04:55:13 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:55:13 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:55:13 --> Utf8 Class Initialized
INFO - 2022-03-24 04:55:13 --> URI Class Initialized
INFO - 2022-03-24 04:55:13 --> Router Class Initialized
INFO - 2022-03-24 04:55:13 --> Output Class Initialized
INFO - 2022-03-24 04:55:13 --> Security Class Initialized
DEBUG - 2022-03-24 04:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:55:13 --> Input Class Initialized
INFO - 2022-03-24 04:55:13 --> Language Class Initialized
INFO - 2022-03-24 04:55:13 --> Loader Class Initialized
INFO - 2022-03-24 04:55:13 --> Helper loaded: url_helper
INFO - 2022-03-24 04:55:13 --> Helper loaded: form_helper
INFO - 2022-03-24 04:55:13 --> Helper loaded: common_helper
INFO - 2022-03-24 04:55:13 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:55:13 --> Controller Class Initialized
INFO - 2022-03-24 04:55:13 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:55:13 --> Final output sent to browser
DEBUG - 2022-03-24 04:55:13 --> Total execution time: 0.0089
ERROR - 2022-03-24 04:55:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:55:21 --> Config Class Initialized
INFO - 2022-03-24 04:55:21 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:55:21 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:55:21 --> Utf8 Class Initialized
INFO - 2022-03-24 04:55:21 --> URI Class Initialized
INFO - 2022-03-24 04:55:21 --> Router Class Initialized
INFO - 2022-03-24 04:55:21 --> Output Class Initialized
INFO - 2022-03-24 04:55:21 --> Security Class Initialized
DEBUG - 2022-03-24 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:55:21 --> Input Class Initialized
INFO - 2022-03-24 04:55:21 --> Language Class Initialized
INFO - 2022-03-24 04:55:21 --> Loader Class Initialized
INFO - 2022-03-24 04:55:21 --> Helper loaded: url_helper
INFO - 2022-03-24 04:55:21 --> Helper loaded: form_helper
INFO - 2022-03-24 04:55:21 --> Helper loaded: common_helper
INFO - 2022-03-24 04:55:21 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:55:21 --> Controller Class Initialized
INFO - 2022-03-24 04:55:21 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:55:21 --> Final output sent to browser
DEBUG - 2022-03-24 04:55:21 --> Total execution time: 0.0083
ERROR - 2022-03-24 04:56:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:56:21 --> Config Class Initialized
INFO - 2022-03-24 04:56:21 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:56:21 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:56:21 --> Utf8 Class Initialized
INFO - 2022-03-24 04:56:21 --> URI Class Initialized
INFO - 2022-03-24 04:56:21 --> Router Class Initialized
INFO - 2022-03-24 04:56:21 --> Output Class Initialized
INFO - 2022-03-24 04:56:21 --> Security Class Initialized
DEBUG - 2022-03-24 04:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:56:21 --> Input Class Initialized
INFO - 2022-03-24 04:56:21 --> Language Class Initialized
INFO - 2022-03-24 04:56:21 --> Loader Class Initialized
INFO - 2022-03-24 04:56:21 --> Helper loaded: url_helper
INFO - 2022-03-24 04:56:21 --> Helper loaded: form_helper
INFO - 2022-03-24 04:56:21 --> Helper loaded: common_helper
INFO - 2022-03-24 04:56:21 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:56:21 --> Controller Class Initialized
INFO - 2022-03-24 04:56:21 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:56:21 --> Final output sent to browser
DEBUG - 2022-03-24 04:56:21 --> Total execution time: 0.0080
ERROR - 2022-03-24 04:56:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:56:44 --> Config Class Initialized
INFO - 2022-03-24 04:56:44 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:56:44 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:56:44 --> Utf8 Class Initialized
INFO - 2022-03-24 04:56:44 --> URI Class Initialized
INFO - 2022-03-24 04:56:44 --> Router Class Initialized
INFO - 2022-03-24 04:56:44 --> Output Class Initialized
INFO - 2022-03-24 04:56:44 --> Security Class Initialized
DEBUG - 2022-03-24 04:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:56:44 --> Input Class Initialized
INFO - 2022-03-24 04:56:44 --> Language Class Initialized
INFO - 2022-03-24 04:56:44 --> Loader Class Initialized
INFO - 2022-03-24 04:56:44 --> Helper loaded: url_helper
INFO - 2022-03-24 04:56:44 --> Helper loaded: form_helper
INFO - 2022-03-24 04:56:44 --> Helper loaded: common_helper
INFO - 2022-03-24 04:56:44 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:56:44 --> Controller Class Initialized
INFO - 2022-03-24 04:56:44 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:56:44 --> Encrypt Class Initialized
INFO - 2022-03-24 04:56:44 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:56:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:56:44 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:56:44 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:56:44 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:56:44 --> Final output sent to browser
DEBUG - 2022-03-24 04:56:44 --> Total execution time: 0.0283
ERROR - 2022-03-24 04:57:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:57:20 --> Config Class Initialized
INFO - 2022-03-24 04:57:20 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:57:20 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:57:20 --> Utf8 Class Initialized
INFO - 2022-03-24 04:57:20 --> URI Class Initialized
INFO - 2022-03-24 04:57:20 --> Router Class Initialized
INFO - 2022-03-24 04:57:20 --> Output Class Initialized
INFO - 2022-03-24 04:57:20 --> Security Class Initialized
DEBUG - 2022-03-24 04:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:57:20 --> Input Class Initialized
INFO - 2022-03-24 04:57:20 --> Language Class Initialized
INFO - 2022-03-24 04:57:20 --> Loader Class Initialized
INFO - 2022-03-24 04:57:20 --> Helper loaded: url_helper
INFO - 2022-03-24 04:57:20 --> Helper loaded: form_helper
INFO - 2022-03-24 04:57:20 --> Helper loaded: common_helper
INFO - 2022-03-24 04:57:20 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:57:20 --> Controller Class Initialized
INFO - 2022-03-24 04:57:20 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:57:20 --> Encrypt Class Initialized
INFO - 2022-03-24 04:57:20 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:57:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:57:20 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:57:20 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:57:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 04:57:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:57:20 --> Config Class Initialized
INFO - 2022-03-24 04:57:20 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:57:20 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:57:20 --> Utf8 Class Initialized
INFO - 2022-03-24 04:57:20 --> URI Class Initialized
INFO - 2022-03-24 04:57:20 --> Router Class Initialized
INFO - 2022-03-24 04:57:20 --> Output Class Initialized
INFO - 2022-03-24 04:57:20 --> Security Class Initialized
DEBUG - 2022-03-24 04:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:57:20 --> Input Class Initialized
INFO - 2022-03-24 04:57:20 --> Language Class Initialized
INFO - 2022-03-24 04:57:20 --> Loader Class Initialized
INFO - 2022-03-24 04:57:20 --> Helper loaded: url_helper
INFO - 2022-03-24 04:57:20 --> Helper loaded: form_helper
INFO - 2022-03-24 04:57:20 --> Helper loaded: common_helper
INFO - 2022-03-24 04:57:20 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:57:20 --> Controller Class Initialized
INFO - 2022-03-24 04:57:20 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:57:20 --> Encrypt Class Initialized
INFO - 2022-03-24 04:57:20 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:57:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:57:20 --> Model "Referredby_model" initialized
INFO - 2022-03-24 04:57:20 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:57:20 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:57:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 04:57:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 04:57:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 04:57:20 --> Final output sent to browser
DEBUG - 2022-03-24 04:57:20 --> Total execution time: 0.1265
ERROR - 2022-03-24 04:57:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 04:57:21 --> Config Class Initialized
INFO - 2022-03-24 04:57:21 --> Hooks Class Initialized
DEBUG - 2022-03-24 04:57:21 --> UTF-8 Support Enabled
INFO - 2022-03-24 04:57:21 --> Utf8 Class Initialized
INFO - 2022-03-24 04:57:21 --> URI Class Initialized
INFO - 2022-03-24 04:57:21 --> Router Class Initialized
INFO - 2022-03-24 04:57:21 --> Output Class Initialized
INFO - 2022-03-24 04:57:21 --> Security Class Initialized
DEBUG - 2022-03-24 04:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 04:57:21 --> Input Class Initialized
INFO - 2022-03-24 04:57:21 --> Language Class Initialized
INFO - 2022-03-24 04:57:21 --> Loader Class Initialized
INFO - 2022-03-24 04:57:21 --> Helper loaded: url_helper
INFO - 2022-03-24 04:57:21 --> Helper loaded: form_helper
INFO - 2022-03-24 04:57:21 --> Helper loaded: common_helper
INFO - 2022-03-24 04:57:21 --> Database Driver Class Initialized
DEBUG - 2022-03-24 04:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 04:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 04:57:21 --> Controller Class Initialized
INFO - 2022-03-24 04:57:21 --> Form Validation Class Initialized
DEBUG - 2022-03-24 04:57:21 --> Encrypt Class Initialized
INFO - 2022-03-24 04:57:21 --> Model "Patient_model" initialized
INFO - 2022-03-24 04:57:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 04:57:21 --> Model "Prefix_master" initialized
INFO - 2022-03-24 04:57:21 --> Model "Users_model" initialized
INFO - 2022-03-24 04:57:21 --> Model "Hospital_model" initialized
INFO - 2022-03-24 04:57:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 04:57:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 04:57:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 04:57:21 --> Final output sent to browser
DEBUG - 2022-03-24 04:57:21 --> Total execution time: 0.2524
ERROR - 2022-03-24 05:00:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:00:26 --> Config Class Initialized
INFO - 2022-03-24 05:00:26 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:00:26 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:00:26 --> Utf8 Class Initialized
INFO - 2022-03-24 05:00:26 --> URI Class Initialized
INFO - 2022-03-24 05:00:26 --> Router Class Initialized
INFO - 2022-03-24 05:00:26 --> Output Class Initialized
INFO - 2022-03-24 05:00:26 --> Security Class Initialized
DEBUG - 2022-03-24 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:00:26 --> Input Class Initialized
INFO - 2022-03-24 05:00:26 --> Language Class Initialized
INFO - 2022-03-24 05:00:26 --> Loader Class Initialized
INFO - 2022-03-24 05:00:26 --> Helper loaded: url_helper
INFO - 2022-03-24 05:00:26 --> Helper loaded: form_helper
INFO - 2022-03-24 05:00:26 --> Helper loaded: common_helper
INFO - 2022-03-24 05:00:26 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:00:26 --> Controller Class Initialized
INFO - 2022-03-24 05:00:26 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:00:26 --> Encrypt Class Initialized
INFO - 2022-03-24 05:00:26 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:00:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:00:26 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:00:26 --> Model "Users_model" initialized
INFO - 2022-03-24 05:00:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:00:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:00:27 --> Config Class Initialized
INFO - 2022-03-24 05:00:27 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:00:27 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:00:27 --> Utf8 Class Initialized
INFO - 2022-03-24 05:00:27 --> URI Class Initialized
INFO - 2022-03-24 05:00:27 --> Router Class Initialized
INFO - 2022-03-24 05:00:27 --> Output Class Initialized
INFO - 2022-03-24 05:00:27 --> Security Class Initialized
DEBUG - 2022-03-24 05:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:00:27 --> Input Class Initialized
INFO - 2022-03-24 05:00:27 --> Language Class Initialized
INFO - 2022-03-24 05:00:27 --> Loader Class Initialized
INFO - 2022-03-24 05:00:27 --> Helper loaded: url_helper
INFO - 2022-03-24 05:00:27 --> Helper loaded: form_helper
INFO - 2022-03-24 05:00:27 --> Helper loaded: common_helper
INFO - 2022-03-24 05:00:27 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:00:27 --> Controller Class Initialized
INFO - 2022-03-24 05:00:27 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:00:27 --> Encrypt Class Initialized
INFO - 2022-03-24 05:00:27 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:00:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:00:27 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:00:27 --> Model "Users_model" initialized
INFO - 2022-03-24 05:00:27 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:00:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:00:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:00:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:00:27 --> Final output sent to browser
DEBUG - 2022-03-24 05:00:27 --> Total execution time: 0.2053
ERROR - 2022-03-24 05:01:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:01:12 --> Config Class Initialized
INFO - 2022-03-24 05:01:12 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:01:12 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:01:12 --> Utf8 Class Initialized
INFO - 2022-03-24 05:01:12 --> URI Class Initialized
DEBUG - 2022-03-24 05:01:12 --> No URI present. Default controller set.
INFO - 2022-03-24 05:01:12 --> Router Class Initialized
INFO - 2022-03-24 05:01:12 --> Output Class Initialized
INFO - 2022-03-24 05:01:12 --> Security Class Initialized
DEBUG - 2022-03-24 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:01:12 --> Input Class Initialized
INFO - 2022-03-24 05:01:12 --> Language Class Initialized
INFO - 2022-03-24 05:01:12 --> Loader Class Initialized
INFO - 2022-03-24 05:01:12 --> Helper loaded: url_helper
INFO - 2022-03-24 05:01:12 --> Helper loaded: form_helper
INFO - 2022-03-24 05:01:12 --> Helper loaded: common_helper
INFO - 2022-03-24 05:01:12 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:01:12 --> Controller Class Initialized
INFO - 2022-03-24 05:01:12 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:01:12 --> Encrypt Class Initialized
DEBUG - 2022-03-24 05:01:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 05:01:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 05:01:12 --> Email Class Initialized
INFO - 2022-03-24 05:01:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 05:01:12 --> Calendar Class Initialized
INFO - 2022-03-24 05:01:12 --> Model "Login_model" initialized
INFO - 2022-03-24 05:01:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 05:01:12 --> Final output sent to browser
DEBUG - 2022-03-24 05:01:12 --> Total execution time: 0.1269
ERROR - 2022-03-24 05:01:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:01:13 --> Config Class Initialized
INFO - 2022-03-24 05:01:13 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:01:13 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:01:13 --> Utf8 Class Initialized
INFO - 2022-03-24 05:01:13 --> URI Class Initialized
INFO - 2022-03-24 05:01:13 --> Router Class Initialized
INFO - 2022-03-24 05:01:13 --> Output Class Initialized
INFO - 2022-03-24 05:01:13 --> Security Class Initialized
DEBUG - 2022-03-24 05:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:01:13 --> Input Class Initialized
INFO - 2022-03-24 05:01:13 --> Language Class Initialized
ERROR - 2022-03-24 05:01:13 --> 404 Page Not Found: Register/index
ERROR - 2022-03-24 05:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:01:15 --> Config Class Initialized
INFO - 2022-03-24 05:01:15 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:01:15 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:01:15 --> Utf8 Class Initialized
INFO - 2022-03-24 05:01:15 --> URI Class Initialized
INFO - 2022-03-24 05:01:15 --> Router Class Initialized
INFO - 2022-03-24 05:01:15 --> Output Class Initialized
INFO - 2022-03-24 05:01:15 --> Security Class Initialized
DEBUG - 2022-03-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:01:15 --> Input Class Initialized
INFO - 2022-03-24 05:01:15 --> Language Class Initialized
INFO - 2022-03-24 05:01:15 --> Loader Class Initialized
INFO - 2022-03-24 05:01:15 --> Helper loaded: url_helper
INFO - 2022-03-24 05:01:15 --> Helper loaded: form_helper
INFO - 2022-03-24 05:01:15 --> Helper loaded: common_helper
INFO - 2022-03-24 05:01:15 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:01:16 --> Controller Class Initialized
INFO - 2022-03-24 05:01:16 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:01:16 --> Encrypt Class Initialized
DEBUG - 2022-03-24 05:01:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 05:01:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 05:01:16 --> Email Class Initialized
INFO - 2022-03-24 05:01:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 05:01:16 --> Calendar Class Initialized
INFO - 2022-03-24 05:01:16 --> Model "Login_model" initialized
INFO - 2022-03-24 05:01:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 05:01:16 --> Final output sent to browser
DEBUG - 2022-03-24 05:01:16 --> Total execution time: 0.5564
ERROR - 2022-03-24 05:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:01:16 --> Config Class Initialized
INFO - 2022-03-24 05:01:16 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:01:16 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:01:16 --> Utf8 Class Initialized
INFO - 2022-03-24 05:01:16 --> URI Class Initialized
DEBUG - 2022-03-24 05:01:16 --> No URI present. Default controller set.
INFO - 2022-03-24 05:01:16 --> Router Class Initialized
INFO - 2022-03-24 05:01:16 --> Output Class Initialized
INFO - 2022-03-24 05:01:16 --> Security Class Initialized
DEBUG - 2022-03-24 05:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:01:16 --> Input Class Initialized
INFO - 2022-03-24 05:01:16 --> Language Class Initialized
INFO - 2022-03-24 05:01:16 --> Loader Class Initialized
INFO - 2022-03-24 05:01:16 --> Helper loaded: url_helper
INFO - 2022-03-24 05:01:16 --> Helper loaded: form_helper
INFO - 2022-03-24 05:01:16 --> Helper loaded: common_helper
INFO - 2022-03-24 05:01:16 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:01:17 --> Controller Class Initialized
INFO - 2022-03-24 05:01:17 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:01:17 --> Encrypt Class Initialized
DEBUG - 2022-03-24 05:01:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 05:01:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 05:01:17 --> Email Class Initialized
INFO - 2022-03-24 05:01:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 05:01:17 --> Calendar Class Initialized
INFO - 2022-03-24 05:01:17 --> Model "Login_model" initialized
INFO - 2022-03-24 05:01:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 05:01:17 --> Final output sent to browser
DEBUG - 2022-03-24 05:01:17 --> Total execution time: 0.2494
ERROR - 2022-03-24 05:01:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:01:20 --> Config Class Initialized
INFO - 2022-03-24 05:01:20 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:01:20 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:01:20 --> Utf8 Class Initialized
INFO - 2022-03-24 05:01:20 --> URI Class Initialized
INFO - 2022-03-24 05:01:20 --> Router Class Initialized
INFO - 2022-03-24 05:01:20 --> Output Class Initialized
INFO - 2022-03-24 05:01:20 --> Security Class Initialized
DEBUG - 2022-03-24 05:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:01:20 --> Input Class Initialized
INFO - 2022-03-24 05:01:20 --> Language Class Initialized
INFO - 2022-03-24 05:01:20 --> Loader Class Initialized
INFO - 2022-03-24 05:01:20 --> Helper loaded: url_helper
INFO - 2022-03-24 05:01:20 --> Helper loaded: form_helper
INFO - 2022-03-24 05:01:20 --> Helper loaded: common_helper
INFO - 2022-03-24 05:01:20 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:01:20 --> Controller Class Initialized
INFO - 2022-03-24 05:01:20 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:01:20 --> Encrypt Class Initialized
DEBUG - 2022-03-24 05:01:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 05:01:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 05:01:20 --> Email Class Initialized
INFO - 2022-03-24 05:01:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 05:01:20 --> Calendar Class Initialized
INFO - 2022-03-24 05:01:20 --> Model "Login_model" initialized
ERROR - 2022-03-24 05:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:01:22 --> Config Class Initialized
INFO - 2022-03-24 05:01:22 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:01:22 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:01:22 --> Utf8 Class Initialized
INFO - 2022-03-24 05:01:22 --> URI Class Initialized
INFO - 2022-03-24 05:01:22 --> Router Class Initialized
INFO - 2022-03-24 05:01:22 --> Output Class Initialized
INFO - 2022-03-24 05:01:22 --> Security Class Initialized
DEBUG - 2022-03-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:01:22 --> Input Class Initialized
INFO - 2022-03-24 05:01:22 --> Language Class Initialized
INFO - 2022-03-24 05:01:22 --> Loader Class Initialized
INFO - 2022-03-24 05:01:22 --> Helper loaded: url_helper
INFO - 2022-03-24 05:01:22 --> Helper loaded: form_helper
INFO - 2022-03-24 05:01:22 --> Helper loaded: common_helper
INFO - 2022-03-24 05:01:22 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:01:22 --> Controller Class Initialized
INFO - 2022-03-24 05:01:22 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:01:22 --> Encrypt Class Initialized
DEBUG - 2022-03-24 05:01:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 05:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 05:01:22 --> Email Class Initialized
INFO - 2022-03-24 05:01:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 05:01:22 --> Calendar Class Initialized
INFO - 2022-03-24 05:01:22 --> Model "Login_model" initialized
INFO - 2022-03-24 05:01:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 05:01:22 --> Final output sent to browser
DEBUG - 2022-03-24 05:01:22 --> Total execution time: 0.1661
ERROR - 2022-03-24 05:01:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:01:57 --> Config Class Initialized
INFO - 2022-03-24 05:01:57 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:01:57 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:01:57 --> Utf8 Class Initialized
INFO - 2022-03-24 05:01:57 --> URI Class Initialized
INFO - 2022-03-24 05:01:57 --> Router Class Initialized
INFO - 2022-03-24 05:01:57 --> Output Class Initialized
INFO - 2022-03-24 05:01:57 --> Security Class Initialized
DEBUG - 2022-03-24 05:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:01:57 --> Input Class Initialized
INFO - 2022-03-24 05:01:57 --> Language Class Initialized
INFO - 2022-03-24 05:01:57 --> Loader Class Initialized
INFO - 2022-03-24 05:01:57 --> Helper loaded: url_helper
INFO - 2022-03-24 05:01:57 --> Helper loaded: form_helper
INFO - 2022-03-24 05:01:57 --> Helper loaded: common_helper
INFO - 2022-03-24 05:01:57 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:01:57 --> Controller Class Initialized
INFO - 2022-03-24 05:01:57 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:01:57 --> Encrypt Class Initialized
INFO - 2022-03-24 05:01:57 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:01:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:01:57 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:01:57 --> Model "Users_model" initialized
INFO - 2022-03-24 05:01:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:01:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:01:58 --> Config Class Initialized
INFO - 2022-03-24 05:01:58 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:01:58 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:01:58 --> Utf8 Class Initialized
INFO - 2022-03-24 05:01:58 --> URI Class Initialized
INFO - 2022-03-24 05:01:58 --> Router Class Initialized
INFO - 2022-03-24 05:01:58 --> Output Class Initialized
INFO - 2022-03-24 05:01:58 --> Security Class Initialized
DEBUG - 2022-03-24 05:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:01:58 --> Input Class Initialized
INFO - 2022-03-24 05:01:58 --> Language Class Initialized
INFO - 2022-03-24 05:01:58 --> Loader Class Initialized
INFO - 2022-03-24 05:01:58 --> Helper loaded: url_helper
INFO - 2022-03-24 05:01:58 --> Helper loaded: form_helper
INFO - 2022-03-24 05:01:58 --> Helper loaded: common_helper
INFO - 2022-03-24 05:01:58 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:01:58 --> Controller Class Initialized
INFO - 2022-03-24 05:01:58 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:01:58 --> Encrypt Class Initialized
INFO - 2022-03-24 05:01:58 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:01:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:01:58 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:01:58 --> Model "Users_model" initialized
INFO - 2022-03-24 05:01:58 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:01:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:01:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:01:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:01:58 --> Final output sent to browser
DEBUG - 2022-03-24 05:01:58 --> Total execution time: 0.0416
ERROR - 2022-03-24 05:02:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:02:47 --> Config Class Initialized
INFO - 2022-03-24 05:02:47 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:02:47 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:02:47 --> Utf8 Class Initialized
INFO - 2022-03-24 05:02:47 --> URI Class Initialized
INFO - 2022-03-24 05:02:47 --> Router Class Initialized
INFO - 2022-03-24 05:02:47 --> Output Class Initialized
INFO - 2022-03-24 05:02:47 --> Security Class Initialized
DEBUG - 2022-03-24 05:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:02:47 --> Input Class Initialized
INFO - 2022-03-24 05:02:47 --> Language Class Initialized
INFO - 2022-03-24 05:02:47 --> Loader Class Initialized
INFO - 2022-03-24 05:02:47 --> Helper loaded: url_helper
INFO - 2022-03-24 05:02:47 --> Helper loaded: form_helper
INFO - 2022-03-24 05:02:47 --> Helper loaded: common_helper
INFO - 2022-03-24 05:02:47 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:02:47 --> Controller Class Initialized
INFO - 2022-03-24 05:02:47 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:02:47 --> Encrypt Class Initialized
INFO - 2022-03-24 05:02:47 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:02:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:02:47 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:02:47 --> Model "Users_model" initialized
INFO - 2022-03-24 05:02:47 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:02:47 --> Upload Class Initialized
INFO - 2022-03-24 05:02:47 --> Final output sent to browser
DEBUG - 2022-03-24 05:02:47 --> Total execution time: 0.0334
ERROR - 2022-03-24 05:02:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:02:51 --> Config Class Initialized
INFO - 2022-03-24 05:02:51 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:02:51 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:02:51 --> Utf8 Class Initialized
INFO - 2022-03-24 05:02:51 --> URI Class Initialized
INFO - 2022-03-24 05:02:51 --> Router Class Initialized
INFO - 2022-03-24 05:02:51 --> Output Class Initialized
INFO - 2022-03-24 05:02:51 --> Security Class Initialized
DEBUG - 2022-03-24 05:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:02:51 --> Input Class Initialized
INFO - 2022-03-24 05:02:51 --> Language Class Initialized
INFO - 2022-03-24 05:02:51 --> Loader Class Initialized
INFO - 2022-03-24 05:02:51 --> Helper loaded: url_helper
INFO - 2022-03-24 05:02:51 --> Helper loaded: form_helper
INFO - 2022-03-24 05:02:51 --> Helper loaded: common_helper
INFO - 2022-03-24 05:02:51 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:02:51 --> Controller Class Initialized
INFO - 2022-03-24 05:02:51 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:02:51 --> Encrypt Class Initialized
INFO - 2022-03-24 05:02:51 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:02:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:02:51 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:02:51 --> Model "Users_model" initialized
INFO - 2022-03-24 05:02:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:02:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:02:51 --> Config Class Initialized
INFO - 2022-03-24 05:02:51 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:02:51 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:02:51 --> Utf8 Class Initialized
INFO - 2022-03-24 05:02:51 --> URI Class Initialized
INFO - 2022-03-24 05:02:51 --> Router Class Initialized
INFO - 2022-03-24 05:02:51 --> Output Class Initialized
INFO - 2022-03-24 05:02:51 --> Security Class Initialized
DEBUG - 2022-03-24 05:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:02:51 --> Input Class Initialized
INFO - 2022-03-24 05:02:51 --> Language Class Initialized
INFO - 2022-03-24 05:02:51 --> Loader Class Initialized
INFO - 2022-03-24 05:02:51 --> Helper loaded: url_helper
INFO - 2022-03-24 05:02:51 --> Helper loaded: form_helper
INFO - 2022-03-24 05:02:51 --> Helper loaded: common_helper
INFO - 2022-03-24 05:02:51 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:02:51 --> Controller Class Initialized
INFO - 2022-03-24 05:02:51 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:02:51 --> Encrypt Class Initialized
INFO - 2022-03-24 05:02:51 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:02:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:02:51 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:02:51 --> Model "Users_model" initialized
INFO - 2022-03-24 05:02:51 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:02:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:02:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:02:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:02:51 --> Final output sent to browser
DEBUG - 2022-03-24 05:02:51 --> Total execution time: 0.0394
ERROR - 2022-03-24 05:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:03:48 --> Config Class Initialized
INFO - 2022-03-24 05:03:48 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:03:48 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:03:48 --> Utf8 Class Initialized
INFO - 2022-03-24 05:03:48 --> URI Class Initialized
INFO - 2022-03-24 05:03:48 --> Router Class Initialized
INFO - 2022-03-24 05:03:48 --> Output Class Initialized
INFO - 2022-03-24 05:03:48 --> Security Class Initialized
DEBUG - 2022-03-24 05:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:03:48 --> Input Class Initialized
INFO - 2022-03-24 05:03:48 --> Language Class Initialized
INFO - 2022-03-24 05:03:48 --> Loader Class Initialized
INFO - 2022-03-24 05:03:48 --> Helper loaded: url_helper
INFO - 2022-03-24 05:03:48 --> Helper loaded: form_helper
INFO - 2022-03-24 05:03:48 --> Helper loaded: common_helper
INFO - 2022-03-24 05:03:48 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:03:48 --> Controller Class Initialized
INFO - 2022-03-24 05:03:48 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:03:48 --> Encrypt Class Initialized
INFO - 2022-03-24 05:03:48 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:03:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:03:48 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:03:48 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:03:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:03:48 --> Config Class Initialized
INFO - 2022-03-24 05:03:48 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:03:48 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:03:48 --> Utf8 Class Initialized
INFO - 2022-03-24 05:03:48 --> URI Class Initialized
INFO - 2022-03-24 05:03:48 --> Router Class Initialized
INFO - 2022-03-24 05:03:48 --> Output Class Initialized
INFO - 2022-03-24 05:03:48 --> Security Class Initialized
DEBUG - 2022-03-24 05:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:03:48 --> Input Class Initialized
INFO - 2022-03-24 05:03:48 --> Language Class Initialized
INFO - 2022-03-24 05:03:48 --> Loader Class Initialized
INFO - 2022-03-24 05:03:48 --> Helper loaded: url_helper
INFO - 2022-03-24 05:03:48 --> Helper loaded: form_helper
INFO - 2022-03-24 05:03:48 --> Helper loaded: common_helper
INFO - 2022-03-24 05:03:48 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:03:48 --> Controller Class Initialized
INFO - 2022-03-24 05:03:48 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:03:48 --> Encrypt Class Initialized
INFO - 2022-03-24 05:03:48 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:03:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:03:48 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:03:48 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:03:48 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:03:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:03:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 05:03:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:03:49 --> Final output sent to browser
DEBUG - 2022-03-24 05:03:49 --> Total execution time: 0.0518
ERROR - 2022-03-24 05:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:03:49 --> Config Class Initialized
INFO - 2022-03-24 05:03:49 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:03:49 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:03:49 --> Utf8 Class Initialized
INFO - 2022-03-24 05:03:49 --> URI Class Initialized
INFO - 2022-03-24 05:03:49 --> Router Class Initialized
INFO - 2022-03-24 05:03:49 --> Output Class Initialized
INFO - 2022-03-24 05:03:49 --> Security Class Initialized
DEBUG - 2022-03-24 05:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:03:49 --> Input Class Initialized
INFO - 2022-03-24 05:03:49 --> Language Class Initialized
INFO - 2022-03-24 05:03:49 --> Loader Class Initialized
INFO - 2022-03-24 05:03:49 --> Helper loaded: url_helper
INFO - 2022-03-24 05:03:49 --> Helper loaded: form_helper
INFO - 2022-03-24 05:03:49 --> Helper loaded: common_helper
INFO - 2022-03-24 05:03:49 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:03:49 --> Controller Class Initialized
INFO - 2022-03-24 05:03:49 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:03:49 --> Encrypt Class Initialized
INFO - 2022-03-24 05:03:49 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:03:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:03:49 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:03:49 --> Model "Users_model" initialized
INFO - 2022-03-24 05:03:49 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:03:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:03:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:03:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:03:49 --> Final output sent to browser
DEBUG - 2022-03-24 05:03:49 --> Total execution time: 0.0557
ERROR - 2022-03-24 05:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:09:45 --> Config Class Initialized
INFO - 2022-03-24 05:09:45 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:09:45 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:09:45 --> Utf8 Class Initialized
INFO - 2022-03-24 05:09:45 --> URI Class Initialized
INFO - 2022-03-24 05:09:45 --> Router Class Initialized
INFO - 2022-03-24 05:09:45 --> Output Class Initialized
INFO - 2022-03-24 05:09:45 --> Security Class Initialized
DEBUG - 2022-03-24 05:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:09:45 --> Input Class Initialized
INFO - 2022-03-24 05:09:45 --> Language Class Initialized
INFO - 2022-03-24 05:09:45 --> Loader Class Initialized
INFO - 2022-03-24 05:09:45 --> Helper loaded: url_helper
INFO - 2022-03-24 05:09:45 --> Helper loaded: form_helper
INFO - 2022-03-24 05:09:45 --> Helper loaded: common_helper
INFO - 2022-03-24 05:09:45 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:09:45 --> Controller Class Initialized
INFO - 2022-03-24 05:09:45 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:09:45 --> Encrypt Class Initialized
INFO - 2022-03-24 05:09:45 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:09:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:09:45 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:09:45 --> Model "Users_model" initialized
INFO - 2022-03-24 05:09:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:09:45 --> Config Class Initialized
INFO - 2022-03-24 05:09:45 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:09:45 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:09:45 --> Utf8 Class Initialized
INFO - 2022-03-24 05:09:45 --> URI Class Initialized
INFO - 2022-03-24 05:09:45 --> Router Class Initialized
INFO - 2022-03-24 05:09:45 --> Output Class Initialized
INFO - 2022-03-24 05:09:45 --> Security Class Initialized
DEBUG - 2022-03-24 05:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:09:45 --> Input Class Initialized
INFO - 2022-03-24 05:09:45 --> Language Class Initialized
INFO - 2022-03-24 05:09:45 --> Loader Class Initialized
INFO - 2022-03-24 05:09:45 --> Helper loaded: url_helper
INFO - 2022-03-24 05:09:45 --> Helper loaded: form_helper
INFO - 2022-03-24 05:09:45 --> Helper loaded: common_helper
INFO - 2022-03-24 05:09:45 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:09:45 --> Controller Class Initialized
INFO - 2022-03-24 05:09:45 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:09:45 --> Encrypt Class Initialized
INFO - 2022-03-24 05:09:45 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:09:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:09:45 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:09:45 --> Model "Users_model" initialized
INFO - 2022-03-24 05:09:45 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:09:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:09:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:09:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:09:45 --> Final output sent to browser
DEBUG - 2022-03-24 05:09:45 --> Total execution time: 0.0410
ERROR - 2022-03-24 05:11:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:11:02 --> Config Class Initialized
INFO - 2022-03-24 05:11:02 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:11:02 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:11:02 --> Utf8 Class Initialized
INFO - 2022-03-24 05:11:02 --> URI Class Initialized
INFO - 2022-03-24 05:11:02 --> Router Class Initialized
INFO - 2022-03-24 05:11:02 --> Output Class Initialized
INFO - 2022-03-24 05:11:02 --> Security Class Initialized
DEBUG - 2022-03-24 05:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:11:02 --> Input Class Initialized
INFO - 2022-03-24 05:11:02 --> Language Class Initialized
INFO - 2022-03-24 05:11:02 --> Loader Class Initialized
INFO - 2022-03-24 05:11:02 --> Helper loaded: url_helper
INFO - 2022-03-24 05:11:02 --> Helper loaded: form_helper
INFO - 2022-03-24 05:11:02 --> Helper loaded: common_helper
INFO - 2022-03-24 05:11:02 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:11:02 --> Controller Class Initialized
INFO - 2022-03-24 05:11:02 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:11:02 --> Encrypt Class Initialized
INFO - 2022-03-24 05:11:02 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:11:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:11:02 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:11:02 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:11:02 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:11:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:11:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 05:11:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:11:02 --> Final output sent to browser
DEBUG - 2022-03-24 05:11:02 --> Total execution time: 0.0400
ERROR - 2022-03-24 05:11:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:11:13 --> Config Class Initialized
INFO - 2022-03-24 05:11:13 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:11:13 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:11:13 --> Utf8 Class Initialized
INFO - 2022-03-24 05:11:13 --> URI Class Initialized
INFO - 2022-03-24 05:11:13 --> Router Class Initialized
INFO - 2022-03-24 05:11:13 --> Output Class Initialized
INFO - 2022-03-24 05:11:13 --> Security Class Initialized
DEBUG - 2022-03-24 05:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:11:13 --> Input Class Initialized
INFO - 2022-03-24 05:11:13 --> Language Class Initialized
INFO - 2022-03-24 05:11:13 --> Loader Class Initialized
INFO - 2022-03-24 05:11:13 --> Helper loaded: url_helper
INFO - 2022-03-24 05:11:13 --> Helper loaded: form_helper
INFO - 2022-03-24 05:11:13 --> Helper loaded: common_helper
INFO - 2022-03-24 05:11:13 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:11:13 --> Controller Class Initialized
INFO - 2022-03-24 05:11:13 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:11:13 --> Encrypt Class Initialized
INFO - 2022-03-24 05:11:13 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:11:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:11:13 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:11:13 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:11:13 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:11:13 --> Upload Class Initialized
INFO - 2022-03-24 05:11:13 --> Final output sent to browser
DEBUG - 2022-03-24 05:11:13 --> Total execution time: 0.0233
ERROR - 2022-03-24 05:11:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:11:19 --> Config Class Initialized
INFO - 2022-03-24 05:11:19 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:11:19 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:11:19 --> Utf8 Class Initialized
INFO - 2022-03-24 05:11:19 --> URI Class Initialized
INFO - 2022-03-24 05:11:19 --> Router Class Initialized
INFO - 2022-03-24 05:11:19 --> Output Class Initialized
INFO - 2022-03-24 05:11:19 --> Security Class Initialized
DEBUG - 2022-03-24 05:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:11:19 --> Input Class Initialized
INFO - 2022-03-24 05:11:19 --> Language Class Initialized
INFO - 2022-03-24 05:11:19 --> Loader Class Initialized
INFO - 2022-03-24 05:11:19 --> Helper loaded: url_helper
INFO - 2022-03-24 05:11:19 --> Helper loaded: form_helper
INFO - 2022-03-24 05:11:19 --> Helper loaded: common_helper
INFO - 2022-03-24 05:11:19 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:11:19 --> Controller Class Initialized
INFO - 2022-03-24 05:11:19 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:11:19 --> Encrypt Class Initialized
INFO - 2022-03-24 05:11:19 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:11:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:11:19 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:11:19 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:11:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:11:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:11:20 --> Config Class Initialized
INFO - 2022-03-24 05:11:20 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:11:20 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:11:20 --> Utf8 Class Initialized
INFO - 2022-03-24 05:11:20 --> URI Class Initialized
INFO - 2022-03-24 05:11:20 --> Router Class Initialized
INFO - 2022-03-24 05:11:20 --> Output Class Initialized
INFO - 2022-03-24 05:11:20 --> Security Class Initialized
DEBUG - 2022-03-24 05:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:11:20 --> Input Class Initialized
INFO - 2022-03-24 05:11:20 --> Language Class Initialized
INFO - 2022-03-24 05:11:20 --> Loader Class Initialized
INFO - 2022-03-24 05:11:20 --> Helper loaded: url_helper
INFO - 2022-03-24 05:11:20 --> Helper loaded: form_helper
INFO - 2022-03-24 05:11:20 --> Helper loaded: common_helper
INFO - 2022-03-24 05:11:20 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:11:20 --> Controller Class Initialized
INFO - 2022-03-24 05:11:20 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:11:20 --> Encrypt Class Initialized
INFO - 2022-03-24 05:11:20 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:11:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:11:20 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:11:20 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:11:20 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:11:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:11:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 05:11:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:11:20 --> Final output sent to browser
DEBUG - 2022-03-24 05:11:20 --> Total execution time: 0.0293
ERROR - 2022-03-24 05:11:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:11:21 --> Config Class Initialized
INFO - 2022-03-24 05:11:21 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:11:21 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:11:21 --> Utf8 Class Initialized
INFO - 2022-03-24 05:11:21 --> URI Class Initialized
INFO - 2022-03-24 05:11:21 --> Router Class Initialized
INFO - 2022-03-24 05:11:21 --> Output Class Initialized
INFO - 2022-03-24 05:11:21 --> Security Class Initialized
DEBUG - 2022-03-24 05:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:11:21 --> Input Class Initialized
INFO - 2022-03-24 05:11:21 --> Language Class Initialized
INFO - 2022-03-24 05:11:21 --> Loader Class Initialized
INFO - 2022-03-24 05:11:21 --> Helper loaded: url_helper
INFO - 2022-03-24 05:11:21 --> Helper loaded: form_helper
INFO - 2022-03-24 05:11:21 --> Helper loaded: common_helper
INFO - 2022-03-24 05:11:21 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:11:21 --> Controller Class Initialized
INFO - 2022-03-24 05:11:21 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:11:21 --> Encrypt Class Initialized
INFO - 2022-03-24 05:11:21 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:11:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:11:21 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:11:21 --> Model "Users_model" initialized
INFO - 2022-03-24 05:11:21 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:11:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:11:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:11:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:11:21 --> Final output sent to browser
DEBUG - 2022-03-24 05:11:21 --> Total execution time: 0.0369
ERROR - 2022-03-24 05:11:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:11:28 --> Config Class Initialized
INFO - 2022-03-24 05:11:28 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:11:28 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:11:28 --> Utf8 Class Initialized
INFO - 2022-03-24 05:11:28 --> URI Class Initialized
INFO - 2022-03-24 05:11:28 --> Router Class Initialized
INFO - 2022-03-24 05:11:28 --> Output Class Initialized
INFO - 2022-03-24 05:11:28 --> Security Class Initialized
DEBUG - 2022-03-24 05:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:11:28 --> Input Class Initialized
INFO - 2022-03-24 05:11:28 --> Language Class Initialized
INFO - 2022-03-24 05:11:28 --> Loader Class Initialized
INFO - 2022-03-24 05:11:28 --> Helper loaded: url_helper
INFO - 2022-03-24 05:11:28 --> Helper loaded: form_helper
INFO - 2022-03-24 05:11:28 --> Helper loaded: common_helper
INFO - 2022-03-24 05:11:28 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:11:28 --> Controller Class Initialized
INFO - 2022-03-24 05:11:28 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:11:28 --> Encrypt Class Initialized
INFO - 2022-03-24 05:11:28 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:11:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:11:28 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:11:28 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:11:28 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:11:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:11:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 05:11:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:11:28 --> Final output sent to browser
DEBUG - 2022-03-24 05:11:28 --> Total execution time: 0.0199
ERROR - 2022-03-24 05:20:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:20:41 --> Config Class Initialized
INFO - 2022-03-24 05:20:41 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:20:41 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:20:41 --> Utf8 Class Initialized
INFO - 2022-03-24 05:20:41 --> URI Class Initialized
INFO - 2022-03-24 05:20:41 --> Router Class Initialized
INFO - 2022-03-24 05:20:41 --> Output Class Initialized
INFO - 2022-03-24 05:20:41 --> Security Class Initialized
DEBUG - 2022-03-24 05:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:20:41 --> Input Class Initialized
INFO - 2022-03-24 05:20:41 --> Language Class Initialized
INFO - 2022-03-24 05:20:41 --> Loader Class Initialized
INFO - 2022-03-24 05:20:41 --> Helper loaded: url_helper
INFO - 2022-03-24 05:20:41 --> Helper loaded: form_helper
INFO - 2022-03-24 05:20:41 --> Helper loaded: common_helper
INFO - 2022-03-24 05:20:41 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:20:41 --> Controller Class Initialized
INFO - 2022-03-24 05:20:41 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:20:41 --> Final output sent to browser
DEBUG - 2022-03-24 05:20:41 --> Total execution time: 0.0543
ERROR - 2022-03-24 05:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:21:21 --> Config Class Initialized
INFO - 2022-03-24 05:21:21 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:21:21 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:21:21 --> Utf8 Class Initialized
INFO - 2022-03-24 05:21:21 --> URI Class Initialized
INFO - 2022-03-24 05:21:21 --> Router Class Initialized
INFO - 2022-03-24 05:21:21 --> Output Class Initialized
INFO - 2022-03-24 05:21:21 --> Security Class Initialized
DEBUG - 2022-03-24 05:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:21:21 --> Input Class Initialized
INFO - 2022-03-24 05:21:21 --> Language Class Initialized
INFO - 2022-03-24 05:21:21 --> Loader Class Initialized
INFO - 2022-03-24 05:21:21 --> Helper loaded: url_helper
INFO - 2022-03-24 05:21:21 --> Helper loaded: form_helper
INFO - 2022-03-24 05:21:21 --> Helper loaded: common_helper
INFO - 2022-03-24 05:21:21 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:21:21 --> Controller Class Initialized
INFO - 2022-03-24 05:21:21 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:21:21 --> Encrypt Class Initialized
INFO - 2022-03-24 05:21:21 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:21:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:21:21 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:21:21 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:21:21 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:21:21 --> Final output sent to browser
DEBUG - 2022-03-24 05:21:21 --> Total execution time: 0.0206
ERROR - 2022-03-24 05:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:22:01 --> Config Class Initialized
INFO - 2022-03-24 05:22:01 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:22:01 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:22:01 --> Utf8 Class Initialized
INFO - 2022-03-24 05:22:01 --> URI Class Initialized
INFO - 2022-03-24 05:22:01 --> Router Class Initialized
INFO - 2022-03-24 05:22:01 --> Output Class Initialized
INFO - 2022-03-24 05:22:01 --> Security Class Initialized
DEBUG - 2022-03-24 05:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:22:01 --> Input Class Initialized
INFO - 2022-03-24 05:22:01 --> Language Class Initialized
INFO - 2022-03-24 05:22:01 --> Loader Class Initialized
INFO - 2022-03-24 05:22:01 --> Helper loaded: url_helper
INFO - 2022-03-24 05:22:01 --> Helper loaded: form_helper
INFO - 2022-03-24 05:22:01 --> Helper loaded: common_helper
INFO - 2022-03-24 05:22:01 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:22:01 --> Controller Class Initialized
INFO - 2022-03-24 05:22:01 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:22:01 --> Encrypt Class Initialized
INFO - 2022-03-24 05:22:01 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:22:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:22:01 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:22:01 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:22:01 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:22:01 --> Final output sent to browser
DEBUG - 2022-03-24 05:22:01 --> Total execution time: 0.0119
ERROR - 2022-03-24 05:22:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:22:26 --> Config Class Initialized
INFO - 2022-03-24 05:22:26 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:22:26 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:22:26 --> Utf8 Class Initialized
INFO - 2022-03-24 05:22:26 --> URI Class Initialized
INFO - 2022-03-24 05:22:26 --> Router Class Initialized
INFO - 2022-03-24 05:22:26 --> Output Class Initialized
INFO - 2022-03-24 05:22:26 --> Security Class Initialized
DEBUG - 2022-03-24 05:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:22:26 --> Input Class Initialized
INFO - 2022-03-24 05:22:26 --> Language Class Initialized
INFO - 2022-03-24 05:22:26 --> Loader Class Initialized
INFO - 2022-03-24 05:22:26 --> Helper loaded: url_helper
INFO - 2022-03-24 05:22:26 --> Helper loaded: form_helper
INFO - 2022-03-24 05:22:26 --> Helper loaded: common_helper
INFO - 2022-03-24 05:22:26 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:22:26 --> Controller Class Initialized
INFO - 2022-03-24 05:22:26 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:22:26 --> Encrypt Class Initialized
INFO - 2022-03-24 05:22:26 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:22:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:22:26 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:22:26 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:22:26 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:22:26 --> Final output sent to browser
DEBUG - 2022-03-24 05:22:26 --> Total execution time: 0.0100
ERROR - 2022-03-24 05:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:24:26 --> Config Class Initialized
INFO - 2022-03-24 05:24:26 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:24:26 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:24:26 --> Utf8 Class Initialized
INFO - 2022-03-24 05:24:26 --> URI Class Initialized
INFO - 2022-03-24 05:24:26 --> Router Class Initialized
INFO - 2022-03-24 05:24:26 --> Output Class Initialized
INFO - 2022-03-24 05:24:26 --> Security Class Initialized
DEBUG - 2022-03-24 05:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:24:26 --> Input Class Initialized
INFO - 2022-03-24 05:24:26 --> Language Class Initialized
INFO - 2022-03-24 05:24:26 --> Loader Class Initialized
INFO - 2022-03-24 05:24:26 --> Helper loaded: url_helper
INFO - 2022-03-24 05:24:26 --> Helper loaded: form_helper
INFO - 2022-03-24 05:24:26 --> Helper loaded: common_helper
INFO - 2022-03-24 05:24:26 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:24:26 --> Controller Class Initialized
INFO - 2022-03-24 05:24:26 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:24:26 --> Final output sent to browser
DEBUG - 2022-03-24 05:24:26 --> Total execution time: 0.0080
ERROR - 2022-03-24 05:28:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:28:29 --> Config Class Initialized
INFO - 2022-03-24 05:28:29 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:28:29 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:28:29 --> Utf8 Class Initialized
INFO - 2022-03-24 05:28:29 --> URI Class Initialized
INFO - 2022-03-24 05:28:29 --> Router Class Initialized
INFO - 2022-03-24 05:28:29 --> Output Class Initialized
INFO - 2022-03-24 05:28:29 --> Security Class Initialized
DEBUG - 2022-03-24 05:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:28:29 --> Input Class Initialized
INFO - 2022-03-24 05:28:29 --> Language Class Initialized
INFO - 2022-03-24 05:28:29 --> Loader Class Initialized
INFO - 2022-03-24 05:28:29 --> Helper loaded: url_helper
INFO - 2022-03-24 05:28:29 --> Helper loaded: form_helper
INFO - 2022-03-24 05:28:29 --> Helper loaded: common_helper
INFO - 2022-03-24 05:28:29 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:28:29 --> Controller Class Initialized
INFO - 2022-03-24 05:28:29 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:28:29 --> Encrypt Class Initialized
INFO - 2022-03-24 05:28:29 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:28:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:28:29 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:28:29 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:28:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:28:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:28:29 --> Config Class Initialized
INFO - 2022-03-24 05:28:29 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:28:29 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:28:29 --> Utf8 Class Initialized
INFO - 2022-03-24 05:28:29 --> URI Class Initialized
INFO - 2022-03-24 05:28:29 --> Router Class Initialized
INFO - 2022-03-24 05:28:29 --> Output Class Initialized
INFO - 2022-03-24 05:28:29 --> Security Class Initialized
DEBUG - 2022-03-24 05:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:28:29 --> Input Class Initialized
INFO - 2022-03-24 05:28:29 --> Language Class Initialized
INFO - 2022-03-24 05:28:29 --> Loader Class Initialized
INFO - 2022-03-24 05:28:29 --> Helper loaded: url_helper
INFO - 2022-03-24 05:28:29 --> Helper loaded: form_helper
INFO - 2022-03-24 05:28:29 --> Helper loaded: common_helper
INFO - 2022-03-24 05:28:29 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:28:29 --> Controller Class Initialized
INFO - 2022-03-24 05:28:29 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:28:29 --> Encrypt Class Initialized
INFO - 2022-03-24 05:28:29 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:28:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:28:29 --> Model "Referredby_model" initialized
INFO - 2022-03-24 05:28:29 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:28:29 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:28:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:28:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 05:28:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:28:29 --> Final output sent to browser
DEBUG - 2022-03-24 05:28:29 --> Total execution time: 0.0344
ERROR - 2022-03-24 05:28:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:28:30 --> Config Class Initialized
INFO - 2022-03-24 05:28:30 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:28:30 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:28:30 --> Utf8 Class Initialized
INFO - 2022-03-24 05:28:30 --> URI Class Initialized
INFO - 2022-03-24 05:28:30 --> Router Class Initialized
INFO - 2022-03-24 05:28:30 --> Output Class Initialized
INFO - 2022-03-24 05:28:30 --> Security Class Initialized
DEBUG - 2022-03-24 05:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:28:30 --> Input Class Initialized
INFO - 2022-03-24 05:28:30 --> Language Class Initialized
INFO - 2022-03-24 05:28:30 --> Loader Class Initialized
INFO - 2022-03-24 05:28:30 --> Helper loaded: url_helper
INFO - 2022-03-24 05:28:30 --> Helper loaded: form_helper
INFO - 2022-03-24 05:28:30 --> Helper loaded: common_helper
INFO - 2022-03-24 05:28:30 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:28:30 --> Controller Class Initialized
INFO - 2022-03-24 05:28:30 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:28:30 --> Encrypt Class Initialized
INFO - 2022-03-24 05:28:30 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:28:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:28:30 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:28:30 --> Model "Users_model" initialized
INFO - 2022-03-24 05:28:30 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:28:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:28:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:28:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:28:30 --> Final output sent to browser
DEBUG - 2022-03-24 05:28:30 --> Total execution time: 0.0425
ERROR - 2022-03-24 05:36:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:36:14 --> Config Class Initialized
INFO - 2022-03-24 05:36:14 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:36:14 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:36:14 --> Utf8 Class Initialized
INFO - 2022-03-24 05:36:14 --> URI Class Initialized
INFO - 2022-03-24 05:36:14 --> Router Class Initialized
INFO - 2022-03-24 05:36:14 --> Output Class Initialized
INFO - 2022-03-24 05:36:14 --> Security Class Initialized
DEBUG - 2022-03-24 05:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:36:14 --> Input Class Initialized
INFO - 2022-03-24 05:36:14 --> Language Class Initialized
INFO - 2022-03-24 05:36:14 --> Loader Class Initialized
INFO - 2022-03-24 05:36:14 --> Helper loaded: url_helper
INFO - 2022-03-24 05:36:14 --> Helper loaded: form_helper
INFO - 2022-03-24 05:36:14 --> Helper loaded: common_helper
INFO - 2022-03-24 05:36:14 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:36:14 --> Controller Class Initialized
INFO - 2022-03-24 05:36:14 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:36:14 --> Encrypt Class Initialized
INFO - 2022-03-24 05:36:14 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:36:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:36:14 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:36:14 --> Model "Users_model" initialized
INFO - 2022-03-24 05:36:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:36:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:36:15 --> Config Class Initialized
INFO - 2022-03-24 05:36:15 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:36:15 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:36:15 --> Utf8 Class Initialized
INFO - 2022-03-24 05:36:15 --> URI Class Initialized
INFO - 2022-03-24 05:36:15 --> Router Class Initialized
INFO - 2022-03-24 05:36:15 --> Output Class Initialized
INFO - 2022-03-24 05:36:15 --> Security Class Initialized
DEBUG - 2022-03-24 05:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:36:15 --> Input Class Initialized
INFO - 2022-03-24 05:36:15 --> Language Class Initialized
INFO - 2022-03-24 05:36:15 --> Loader Class Initialized
INFO - 2022-03-24 05:36:15 --> Helper loaded: url_helper
INFO - 2022-03-24 05:36:15 --> Helper loaded: form_helper
INFO - 2022-03-24 05:36:15 --> Helper loaded: common_helper
INFO - 2022-03-24 05:36:15 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:36:15 --> Controller Class Initialized
INFO - 2022-03-24 05:36:15 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:36:15 --> Encrypt Class Initialized
INFO - 2022-03-24 05:36:15 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:36:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:36:15 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:36:15 --> Model "Users_model" initialized
INFO - 2022-03-24 05:36:15 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:36:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:36:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:36:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:36:15 --> Final output sent to browser
DEBUG - 2022-03-24 05:36:15 --> Total execution time: 0.0419
ERROR - 2022-03-24 05:37:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:37:57 --> Config Class Initialized
INFO - 2022-03-24 05:37:57 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:37:57 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:37:57 --> Utf8 Class Initialized
INFO - 2022-03-24 05:37:57 --> URI Class Initialized
INFO - 2022-03-24 05:37:57 --> Router Class Initialized
INFO - 2022-03-24 05:37:57 --> Output Class Initialized
INFO - 2022-03-24 05:37:57 --> Security Class Initialized
DEBUG - 2022-03-24 05:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:37:57 --> Input Class Initialized
INFO - 2022-03-24 05:37:57 --> Language Class Initialized
INFO - 2022-03-24 05:37:57 --> Loader Class Initialized
INFO - 2022-03-24 05:37:57 --> Helper loaded: url_helper
INFO - 2022-03-24 05:37:57 --> Helper loaded: form_helper
INFO - 2022-03-24 05:37:57 --> Helper loaded: common_helper
INFO - 2022-03-24 05:37:57 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:37:57 --> Controller Class Initialized
INFO - 2022-03-24 05:37:57 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:37:57 --> Encrypt Class Initialized
INFO - 2022-03-24 05:37:57 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:37:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:37:57 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:37:57 --> Model "Users_model" initialized
INFO - 2022-03-24 05:37:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:37:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:37:58 --> Config Class Initialized
INFO - 2022-03-24 05:37:58 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:37:58 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:37:58 --> Utf8 Class Initialized
INFO - 2022-03-24 05:37:58 --> URI Class Initialized
INFO - 2022-03-24 05:37:58 --> Router Class Initialized
INFO - 2022-03-24 05:37:58 --> Output Class Initialized
INFO - 2022-03-24 05:37:58 --> Security Class Initialized
DEBUG - 2022-03-24 05:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:37:58 --> Input Class Initialized
INFO - 2022-03-24 05:37:58 --> Language Class Initialized
INFO - 2022-03-24 05:37:58 --> Loader Class Initialized
INFO - 2022-03-24 05:37:58 --> Helper loaded: url_helper
INFO - 2022-03-24 05:37:58 --> Helper loaded: form_helper
INFO - 2022-03-24 05:37:58 --> Helper loaded: common_helper
INFO - 2022-03-24 05:37:58 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:37:58 --> Controller Class Initialized
INFO - 2022-03-24 05:37:58 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:37:58 --> Encrypt Class Initialized
INFO - 2022-03-24 05:37:58 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:37:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:37:58 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:37:58 --> Model "Users_model" initialized
INFO - 2022-03-24 05:37:58 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:37:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:37:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:37:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:37:58 --> Final output sent to browser
DEBUG - 2022-03-24 05:37:58 --> Total execution time: 0.0459
ERROR - 2022-03-24 05:40:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:40:51 --> Config Class Initialized
INFO - 2022-03-24 05:40:51 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:40:51 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:40:51 --> Utf8 Class Initialized
INFO - 2022-03-24 05:40:51 --> URI Class Initialized
INFO - 2022-03-24 05:40:51 --> Router Class Initialized
INFO - 2022-03-24 05:40:51 --> Output Class Initialized
INFO - 2022-03-24 05:40:51 --> Security Class Initialized
DEBUG - 2022-03-24 05:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:40:51 --> Input Class Initialized
INFO - 2022-03-24 05:40:51 --> Language Class Initialized
INFO - 2022-03-24 05:40:51 --> Loader Class Initialized
INFO - 2022-03-24 05:40:51 --> Helper loaded: url_helper
INFO - 2022-03-24 05:40:51 --> Helper loaded: form_helper
INFO - 2022-03-24 05:40:51 --> Helper loaded: common_helper
INFO - 2022-03-24 05:40:51 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:40:51 --> Controller Class Initialized
INFO - 2022-03-24 05:40:51 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:40:51 --> Encrypt Class Initialized
INFO - 2022-03-24 05:40:51 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:40:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:40:51 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:40:51 --> Model "Users_model" initialized
INFO - 2022-03-24 05:40:51 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:40:51 --> Upload Class Initialized
INFO - 2022-03-24 05:40:51 --> Final output sent to browser
DEBUG - 2022-03-24 05:40:51 --> Total execution time: 0.1021
ERROR - 2022-03-24 05:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:40:54 --> Config Class Initialized
INFO - 2022-03-24 05:40:54 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:40:54 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:40:54 --> Utf8 Class Initialized
INFO - 2022-03-24 05:40:54 --> URI Class Initialized
INFO - 2022-03-24 05:40:54 --> Router Class Initialized
INFO - 2022-03-24 05:40:54 --> Output Class Initialized
INFO - 2022-03-24 05:40:54 --> Security Class Initialized
DEBUG - 2022-03-24 05:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:40:54 --> Input Class Initialized
INFO - 2022-03-24 05:40:54 --> Language Class Initialized
INFO - 2022-03-24 05:40:54 --> Loader Class Initialized
INFO - 2022-03-24 05:40:54 --> Helper loaded: url_helper
INFO - 2022-03-24 05:40:54 --> Helper loaded: form_helper
INFO - 2022-03-24 05:40:54 --> Helper loaded: common_helper
INFO - 2022-03-24 05:40:54 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:40:54 --> Controller Class Initialized
INFO - 2022-03-24 05:40:54 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:40:54 --> Encrypt Class Initialized
INFO - 2022-03-24 05:40:54 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:40:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:40:54 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:40:54 --> Model "Users_model" initialized
INFO - 2022-03-24 05:40:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:40:54 --> Config Class Initialized
INFO - 2022-03-24 05:40:54 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:40:54 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:40:54 --> Utf8 Class Initialized
INFO - 2022-03-24 05:40:54 --> URI Class Initialized
INFO - 2022-03-24 05:40:54 --> Router Class Initialized
INFO - 2022-03-24 05:40:54 --> Output Class Initialized
INFO - 2022-03-24 05:40:54 --> Security Class Initialized
DEBUG - 2022-03-24 05:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:40:54 --> Input Class Initialized
INFO - 2022-03-24 05:40:54 --> Language Class Initialized
INFO - 2022-03-24 05:40:54 --> Loader Class Initialized
INFO - 2022-03-24 05:40:54 --> Helper loaded: url_helper
INFO - 2022-03-24 05:40:54 --> Helper loaded: form_helper
INFO - 2022-03-24 05:40:54 --> Helper loaded: common_helper
INFO - 2022-03-24 05:40:54 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:40:54 --> Controller Class Initialized
INFO - 2022-03-24 05:40:54 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:40:54 --> Encrypt Class Initialized
INFO - 2022-03-24 05:40:54 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:40:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:40:54 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:40:54 --> Model "Users_model" initialized
INFO - 2022-03-24 05:40:54 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:40:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:40:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:40:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:40:54 --> Final output sent to browser
DEBUG - 2022-03-24 05:40:54 --> Total execution time: 0.0461
ERROR - 2022-03-24 05:46:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:46:37 --> Config Class Initialized
INFO - 2022-03-24 05:46:37 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:46:37 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:46:37 --> Utf8 Class Initialized
INFO - 2022-03-24 05:46:37 --> URI Class Initialized
INFO - 2022-03-24 05:46:37 --> Router Class Initialized
INFO - 2022-03-24 05:46:37 --> Output Class Initialized
INFO - 2022-03-24 05:46:37 --> Security Class Initialized
DEBUG - 2022-03-24 05:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:46:37 --> Input Class Initialized
INFO - 2022-03-24 05:46:37 --> Language Class Initialized
INFO - 2022-03-24 05:46:37 --> Loader Class Initialized
INFO - 2022-03-24 05:46:37 --> Helper loaded: url_helper
INFO - 2022-03-24 05:46:37 --> Helper loaded: form_helper
INFO - 2022-03-24 05:46:37 --> Helper loaded: common_helper
INFO - 2022-03-24 05:46:37 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:46:37 --> Controller Class Initialized
INFO - 2022-03-24 05:46:37 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:46:37 --> Encrypt Class Initialized
INFO - 2022-03-24 05:46:37 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:46:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:46:37 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:46:37 --> Model "Users_model" initialized
INFO - 2022-03-24 05:46:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:46:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:46:37 --> Config Class Initialized
INFO - 2022-03-24 05:46:37 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:46:37 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:46:37 --> Utf8 Class Initialized
INFO - 2022-03-24 05:46:37 --> URI Class Initialized
INFO - 2022-03-24 05:46:37 --> Router Class Initialized
INFO - 2022-03-24 05:46:37 --> Output Class Initialized
INFO - 2022-03-24 05:46:37 --> Security Class Initialized
DEBUG - 2022-03-24 05:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:46:37 --> Input Class Initialized
INFO - 2022-03-24 05:46:37 --> Language Class Initialized
INFO - 2022-03-24 05:46:37 --> Loader Class Initialized
INFO - 2022-03-24 05:46:37 --> Helper loaded: url_helper
INFO - 2022-03-24 05:46:37 --> Helper loaded: form_helper
INFO - 2022-03-24 05:46:37 --> Helper loaded: common_helper
INFO - 2022-03-24 05:46:37 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:46:37 --> Controller Class Initialized
INFO - 2022-03-24 05:46:37 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:46:37 --> Encrypt Class Initialized
INFO - 2022-03-24 05:46:37 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:46:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:46:37 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:46:37 --> Model "Users_model" initialized
INFO - 2022-03-24 05:46:37 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:46:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:46:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:46:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:46:37 --> Final output sent to browser
DEBUG - 2022-03-24 05:46:37 --> Total execution time: 0.0993
ERROR - 2022-03-24 05:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:51:33 --> Config Class Initialized
INFO - 2022-03-24 05:51:33 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:51:33 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:51:33 --> Utf8 Class Initialized
INFO - 2022-03-24 05:51:33 --> URI Class Initialized
INFO - 2022-03-24 05:51:33 --> Router Class Initialized
INFO - 2022-03-24 05:51:33 --> Output Class Initialized
INFO - 2022-03-24 05:51:33 --> Security Class Initialized
DEBUG - 2022-03-24 05:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:51:33 --> Input Class Initialized
INFO - 2022-03-24 05:51:33 --> Language Class Initialized
INFO - 2022-03-24 05:51:33 --> Loader Class Initialized
INFO - 2022-03-24 05:51:33 --> Helper loaded: url_helper
INFO - 2022-03-24 05:51:33 --> Helper loaded: form_helper
INFO - 2022-03-24 05:51:33 --> Helper loaded: common_helper
INFO - 2022-03-24 05:51:33 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:51:33 --> Controller Class Initialized
INFO - 2022-03-24 05:51:33 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:51:33 --> Encrypt Class Initialized
INFO - 2022-03-24 05:51:33 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:51:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:51:33 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:51:33 --> Model "Users_model" initialized
INFO - 2022-03-24 05:51:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:51:33 --> Config Class Initialized
INFO - 2022-03-24 05:51:33 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:51:33 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:51:33 --> Utf8 Class Initialized
INFO - 2022-03-24 05:51:33 --> URI Class Initialized
INFO - 2022-03-24 05:51:33 --> Router Class Initialized
INFO - 2022-03-24 05:51:33 --> Output Class Initialized
INFO - 2022-03-24 05:51:33 --> Security Class Initialized
DEBUG - 2022-03-24 05:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:51:33 --> Input Class Initialized
INFO - 2022-03-24 05:51:33 --> Language Class Initialized
INFO - 2022-03-24 05:51:33 --> Loader Class Initialized
INFO - 2022-03-24 05:51:33 --> Helper loaded: url_helper
INFO - 2022-03-24 05:51:33 --> Helper loaded: form_helper
INFO - 2022-03-24 05:51:33 --> Helper loaded: common_helper
INFO - 2022-03-24 05:51:33 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:51:33 --> Controller Class Initialized
INFO - 2022-03-24 05:51:33 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:51:33 --> Encrypt Class Initialized
INFO - 2022-03-24 05:51:33 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:51:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:51:33 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:51:33 --> Model "Users_model" initialized
INFO - 2022-03-24 05:51:33 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:51:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:51:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:51:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:51:33 --> Final output sent to browser
DEBUG - 2022-03-24 05:51:33 --> Total execution time: 0.0468
ERROR - 2022-03-24 05:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:55:38 --> Config Class Initialized
INFO - 2022-03-24 05:55:38 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:55:38 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:55:38 --> Utf8 Class Initialized
INFO - 2022-03-24 05:55:38 --> URI Class Initialized
INFO - 2022-03-24 05:55:38 --> Router Class Initialized
INFO - 2022-03-24 05:55:38 --> Output Class Initialized
INFO - 2022-03-24 05:55:38 --> Security Class Initialized
DEBUG - 2022-03-24 05:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:55:38 --> Input Class Initialized
INFO - 2022-03-24 05:55:38 --> Language Class Initialized
INFO - 2022-03-24 05:55:38 --> Loader Class Initialized
INFO - 2022-03-24 05:55:38 --> Helper loaded: url_helper
INFO - 2022-03-24 05:55:38 --> Helper loaded: form_helper
INFO - 2022-03-24 05:55:38 --> Helper loaded: common_helper
INFO - 2022-03-24 05:55:38 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:55:38 --> Controller Class Initialized
INFO - 2022-03-24 05:55:39 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:55:39 --> Encrypt Class Initialized
INFO - 2022-03-24 05:55:39 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:55:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:55:39 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:55:39 --> Model "Users_model" initialized
INFO - 2022-03-24 05:55:39 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:55:39 --> Upload Class Initialized
INFO - 2022-03-24 05:55:39 --> Final output sent to browser
DEBUG - 2022-03-24 05:55:39 --> Total execution time: 0.1017
ERROR - 2022-03-24 05:55:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:55:44 --> Config Class Initialized
INFO - 2022-03-24 05:55:44 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:55:44 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:55:44 --> Utf8 Class Initialized
INFO - 2022-03-24 05:55:44 --> URI Class Initialized
INFO - 2022-03-24 05:55:44 --> Router Class Initialized
INFO - 2022-03-24 05:55:44 --> Output Class Initialized
INFO - 2022-03-24 05:55:44 --> Security Class Initialized
DEBUG - 2022-03-24 05:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:55:44 --> Input Class Initialized
INFO - 2022-03-24 05:55:44 --> Language Class Initialized
INFO - 2022-03-24 05:55:44 --> Loader Class Initialized
INFO - 2022-03-24 05:55:44 --> Helper loaded: url_helper
INFO - 2022-03-24 05:55:44 --> Helper loaded: form_helper
INFO - 2022-03-24 05:55:44 --> Helper loaded: common_helper
INFO - 2022-03-24 05:55:44 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:55:44 --> Controller Class Initialized
INFO - 2022-03-24 05:55:44 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:55:44 --> Encrypt Class Initialized
INFO - 2022-03-24 05:55:44 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:55:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:55:44 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:55:44 --> Model "Users_model" initialized
INFO - 2022-03-24 05:55:44 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 05:55:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 05:55:44 --> Config Class Initialized
INFO - 2022-03-24 05:55:44 --> Hooks Class Initialized
DEBUG - 2022-03-24 05:55:44 --> UTF-8 Support Enabled
INFO - 2022-03-24 05:55:44 --> Utf8 Class Initialized
INFO - 2022-03-24 05:55:44 --> URI Class Initialized
INFO - 2022-03-24 05:55:44 --> Router Class Initialized
INFO - 2022-03-24 05:55:44 --> Output Class Initialized
INFO - 2022-03-24 05:55:44 --> Security Class Initialized
DEBUG - 2022-03-24 05:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 05:55:44 --> Input Class Initialized
INFO - 2022-03-24 05:55:44 --> Language Class Initialized
INFO - 2022-03-24 05:55:44 --> Loader Class Initialized
INFO - 2022-03-24 05:55:44 --> Helper loaded: url_helper
INFO - 2022-03-24 05:55:44 --> Helper loaded: form_helper
INFO - 2022-03-24 05:55:44 --> Helper loaded: common_helper
INFO - 2022-03-24 05:55:44 --> Database Driver Class Initialized
DEBUG - 2022-03-24 05:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 05:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 05:55:44 --> Controller Class Initialized
INFO - 2022-03-24 05:55:44 --> Form Validation Class Initialized
DEBUG - 2022-03-24 05:55:44 --> Encrypt Class Initialized
INFO - 2022-03-24 05:55:44 --> Model "Patient_model" initialized
INFO - 2022-03-24 05:55:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 05:55:44 --> Model "Prefix_master" initialized
INFO - 2022-03-24 05:55:44 --> Model "Users_model" initialized
INFO - 2022-03-24 05:55:44 --> Model "Hospital_model" initialized
INFO - 2022-03-24 05:55:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 05:55:44 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 05:55:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 05:55:44 --> Final output sent to browser
DEBUG - 2022-03-24 05:55:44 --> Total execution time: 0.0457
ERROR - 2022-03-24 06:09:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:09:11 --> Config Class Initialized
INFO - 2022-03-24 06:09:11 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:09:11 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:09:11 --> Utf8 Class Initialized
INFO - 2022-03-24 06:09:11 --> URI Class Initialized
INFO - 2022-03-24 06:09:11 --> Router Class Initialized
INFO - 2022-03-24 06:09:11 --> Output Class Initialized
INFO - 2022-03-24 06:09:11 --> Security Class Initialized
DEBUG - 2022-03-24 06:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:09:11 --> Input Class Initialized
INFO - 2022-03-24 06:09:11 --> Language Class Initialized
INFO - 2022-03-24 06:09:11 --> Loader Class Initialized
INFO - 2022-03-24 06:09:11 --> Helper loaded: url_helper
INFO - 2022-03-24 06:09:11 --> Helper loaded: form_helper
INFO - 2022-03-24 06:09:11 --> Helper loaded: common_helper
INFO - 2022-03-24 06:09:11 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:09:11 --> Controller Class Initialized
INFO - 2022-03-24 06:09:11 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:09:11 --> Encrypt Class Initialized
INFO - 2022-03-24 06:09:11 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:09:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:09:11 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:09:11 --> Model "Users_model" initialized
INFO - 2022-03-24 06:09:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 06:09:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:09:12 --> Config Class Initialized
INFO - 2022-03-24 06:09:12 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:09:12 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:09:12 --> Utf8 Class Initialized
INFO - 2022-03-24 06:09:12 --> URI Class Initialized
INFO - 2022-03-24 06:09:12 --> Router Class Initialized
INFO - 2022-03-24 06:09:12 --> Output Class Initialized
INFO - 2022-03-24 06:09:12 --> Security Class Initialized
DEBUG - 2022-03-24 06:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:09:12 --> Input Class Initialized
INFO - 2022-03-24 06:09:12 --> Language Class Initialized
INFO - 2022-03-24 06:09:12 --> Loader Class Initialized
INFO - 2022-03-24 06:09:12 --> Helper loaded: url_helper
INFO - 2022-03-24 06:09:12 --> Helper loaded: form_helper
INFO - 2022-03-24 06:09:12 --> Helper loaded: common_helper
INFO - 2022-03-24 06:09:12 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:09:12 --> Controller Class Initialized
INFO - 2022-03-24 06:09:12 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:09:12 --> Encrypt Class Initialized
INFO - 2022-03-24 06:09:12 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:09:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:09:12 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:09:12 --> Model "Users_model" initialized
INFO - 2022-03-24 06:09:12 --> Model "Hospital_model" initialized
INFO - 2022-03-24 06:09:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 06:09:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 06:09:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 06:09:12 --> Final output sent to browser
DEBUG - 2022-03-24 06:09:12 --> Total execution time: 0.0498
ERROR - 2022-03-24 06:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:09:48 --> Config Class Initialized
INFO - 2022-03-24 06:09:48 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:09:48 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:09:48 --> Utf8 Class Initialized
INFO - 2022-03-24 06:09:48 --> URI Class Initialized
INFO - 2022-03-24 06:09:48 --> Router Class Initialized
INFO - 2022-03-24 06:09:48 --> Output Class Initialized
INFO - 2022-03-24 06:09:48 --> Security Class Initialized
DEBUG - 2022-03-24 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:09:48 --> Input Class Initialized
INFO - 2022-03-24 06:09:48 --> Language Class Initialized
INFO - 2022-03-24 06:09:48 --> Loader Class Initialized
INFO - 2022-03-24 06:09:48 --> Helper loaded: url_helper
INFO - 2022-03-24 06:09:48 --> Helper loaded: form_helper
INFO - 2022-03-24 06:09:48 --> Helper loaded: common_helper
INFO - 2022-03-24 06:09:48 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:09:48 --> Controller Class Initialized
INFO - 2022-03-24 06:09:48 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:09:48 --> Encrypt Class Initialized
INFO - 2022-03-24 06:09:48 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:09:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:09:48 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:09:48 --> Model "Users_model" initialized
INFO - 2022-03-24 06:09:48 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 06:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:09:48 --> Config Class Initialized
INFO - 2022-03-24 06:09:48 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:09:48 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:09:48 --> Utf8 Class Initialized
INFO - 2022-03-24 06:09:48 --> URI Class Initialized
INFO - 2022-03-24 06:09:48 --> Router Class Initialized
INFO - 2022-03-24 06:09:48 --> Output Class Initialized
INFO - 2022-03-24 06:09:48 --> Security Class Initialized
DEBUG - 2022-03-24 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:09:48 --> Input Class Initialized
INFO - 2022-03-24 06:09:48 --> Language Class Initialized
INFO - 2022-03-24 06:09:48 --> Loader Class Initialized
INFO - 2022-03-24 06:09:48 --> Helper loaded: url_helper
INFO - 2022-03-24 06:09:48 --> Helper loaded: form_helper
INFO - 2022-03-24 06:09:48 --> Helper loaded: common_helper
INFO - 2022-03-24 06:09:48 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:09:48 --> Controller Class Initialized
INFO - 2022-03-24 06:09:48 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:09:48 --> Encrypt Class Initialized
INFO - 2022-03-24 06:09:48 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:09:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:09:48 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:09:48 --> Model "Users_model" initialized
INFO - 2022-03-24 06:09:48 --> Model "Hospital_model" initialized
INFO - 2022-03-24 06:09:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 06:09:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 06:09:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 06:09:49 --> Final output sent to browser
DEBUG - 2022-03-24 06:09:49 --> Total execution time: 0.0570
ERROR - 2022-03-24 06:12:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:12:05 --> Config Class Initialized
INFO - 2022-03-24 06:12:05 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:12:05 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:12:05 --> Utf8 Class Initialized
INFO - 2022-03-24 06:12:05 --> URI Class Initialized
INFO - 2022-03-24 06:12:05 --> Router Class Initialized
INFO - 2022-03-24 06:12:05 --> Output Class Initialized
INFO - 2022-03-24 06:12:05 --> Security Class Initialized
DEBUG - 2022-03-24 06:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:12:05 --> Input Class Initialized
INFO - 2022-03-24 06:12:05 --> Language Class Initialized
INFO - 2022-03-24 06:12:05 --> Loader Class Initialized
INFO - 2022-03-24 06:12:05 --> Helper loaded: url_helper
INFO - 2022-03-24 06:12:05 --> Helper loaded: form_helper
INFO - 2022-03-24 06:12:05 --> Helper loaded: common_helper
INFO - 2022-03-24 06:12:05 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:12:05 --> Controller Class Initialized
INFO - 2022-03-24 06:12:05 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:12:05 --> Encrypt Class Initialized
INFO - 2022-03-24 06:12:05 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:12:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:12:05 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:12:05 --> Model "Users_model" initialized
INFO - 2022-03-24 06:12:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 06:12:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:12:05 --> Config Class Initialized
INFO - 2022-03-24 06:12:05 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:12:05 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:12:05 --> Utf8 Class Initialized
INFO - 2022-03-24 06:12:05 --> URI Class Initialized
INFO - 2022-03-24 06:12:05 --> Router Class Initialized
INFO - 2022-03-24 06:12:05 --> Output Class Initialized
INFO - 2022-03-24 06:12:05 --> Security Class Initialized
DEBUG - 2022-03-24 06:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:12:05 --> Input Class Initialized
INFO - 2022-03-24 06:12:05 --> Language Class Initialized
INFO - 2022-03-24 06:12:05 --> Loader Class Initialized
INFO - 2022-03-24 06:12:05 --> Helper loaded: url_helper
INFO - 2022-03-24 06:12:05 --> Helper loaded: form_helper
INFO - 2022-03-24 06:12:05 --> Helper loaded: common_helper
INFO - 2022-03-24 06:12:05 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:12:05 --> Controller Class Initialized
INFO - 2022-03-24 06:12:05 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:12:05 --> Encrypt Class Initialized
INFO - 2022-03-24 06:12:05 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:12:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:12:05 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:12:05 --> Model "Users_model" initialized
INFO - 2022-03-24 06:12:05 --> Model "Hospital_model" initialized
INFO - 2022-03-24 06:12:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 06:12:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 06:12:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 06:12:05 --> Final output sent to browser
DEBUG - 2022-03-24 06:12:05 --> Total execution time: 0.1010
ERROR - 2022-03-24 06:14:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:14:19 --> Config Class Initialized
INFO - 2022-03-24 06:14:19 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:14:19 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:14:19 --> Utf8 Class Initialized
INFO - 2022-03-24 06:14:19 --> URI Class Initialized
INFO - 2022-03-24 06:14:19 --> Router Class Initialized
INFO - 2022-03-24 06:14:19 --> Output Class Initialized
INFO - 2022-03-24 06:14:19 --> Security Class Initialized
DEBUG - 2022-03-24 06:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:14:19 --> Input Class Initialized
INFO - 2022-03-24 06:14:19 --> Language Class Initialized
INFO - 2022-03-24 06:14:19 --> Loader Class Initialized
INFO - 2022-03-24 06:14:19 --> Helper loaded: url_helper
INFO - 2022-03-24 06:14:19 --> Helper loaded: form_helper
INFO - 2022-03-24 06:14:19 --> Helper loaded: common_helper
INFO - 2022-03-24 06:14:19 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:14:19 --> Controller Class Initialized
INFO - 2022-03-24 06:14:19 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:14:19 --> Encrypt Class Initialized
INFO - 2022-03-24 06:14:19 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:14:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:14:19 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:14:19 --> Model "Users_model" initialized
INFO - 2022-03-24 06:14:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 06:14:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:14:19 --> Config Class Initialized
INFO - 2022-03-24 06:14:19 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:14:19 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:14:19 --> Utf8 Class Initialized
INFO - 2022-03-24 06:14:19 --> URI Class Initialized
INFO - 2022-03-24 06:14:19 --> Router Class Initialized
INFO - 2022-03-24 06:14:19 --> Output Class Initialized
INFO - 2022-03-24 06:14:19 --> Security Class Initialized
DEBUG - 2022-03-24 06:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:14:19 --> Input Class Initialized
INFO - 2022-03-24 06:14:19 --> Language Class Initialized
INFO - 2022-03-24 06:14:19 --> Loader Class Initialized
INFO - 2022-03-24 06:14:19 --> Helper loaded: url_helper
INFO - 2022-03-24 06:14:19 --> Helper loaded: form_helper
INFO - 2022-03-24 06:14:19 --> Helper loaded: common_helper
INFO - 2022-03-24 06:14:19 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:14:19 --> Controller Class Initialized
INFO - 2022-03-24 06:14:19 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:14:19 --> Encrypt Class Initialized
INFO - 2022-03-24 06:14:19 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:14:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:14:19 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:14:19 --> Model "Users_model" initialized
INFO - 2022-03-24 06:14:19 --> Model "Hospital_model" initialized
INFO - 2022-03-24 06:14:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 06:14:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 06:14:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 06:14:19 --> Final output sent to browser
DEBUG - 2022-03-24 06:14:19 --> Total execution time: 0.0760
ERROR - 2022-03-24 06:18:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:18:50 --> Config Class Initialized
INFO - 2022-03-24 06:18:50 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:18:50 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:18:50 --> Utf8 Class Initialized
INFO - 2022-03-24 06:18:50 --> URI Class Initialized
INFO - 2022-03-24 06:18:50 --> Router Class Initialized
INFO - 2022-03-24 06:18:50 --> Output Class Initialized
INFO - 2022-03-24 06:18:50 --> Security Class Initialized
DEBUG - 2022-03-24 06:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:18:50 --> Input Class Initialized
INFO - 2022-03-24 06:18:50 --> Language Class Initialized
INFO - 2022-03-24 06:18:50 --> Loader Class Initialized
INFO - 2022-03-24 06:18:50 --> Helper loaded: url_helper
INFO - 2022-03-24 06:18:50 --> Helper loaded: form_helper
INFO - 2022-03-24 06:18:50 --> Helper loaded: common_helper
INFO - 2022-03-24 06:18:50 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:18:50 --> Controller Class Initialized
INFO - 2022-03-24 06:18:50 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:18:50 --> Encrypt Class Initialized
INFO - 2022-03-24 06:18:50 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:18:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:18:50 --> Model "Referredby_model" initialized
INFO - 2022-03-24 06:18:50 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:18:50 --> Model "Hospital_model" initialized
INFO - 2022-03-24 06:18:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 06:18:50 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 06:18:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 06:18:50 --> Final output sent to browser
DEBUG - 2022-03-24 06:18:50 --> Total execution time: 0.2253
ERROR - 2022-03-24 06:19:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:19:07 --> Config Class Initialized
INFO - 2022-03-24 06:19:07 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:19:07 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:19:07 --> Utf8 Class Initialized
INFO - 2022-03-24 06:19:07 --> URI Class Initialized
INFO - 2022-03-24 06:19:07 --> Router Class Initialized
INFO - 2022-03-24 06:19:07 --> Output Class Initialized
INFO - 2022-03-24 06:19:07 --> Security Class Initialized
DEBUG - 2022-03-24 06:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:19:07 --> Input Class Initialized
INFO - 2022-03-24 06:19:07 --> Language Class Initialized
INFO - 2022-03-24 06:19:07 --> Loader Class Initialized
INFO - 2022-03-24 06:19:07 --> Helper loaded: url_helper
INFO - 2022-03-24 06:19:07 --> Helper loaded: form_helper
INFO - 2022-03-24 06:19:07 --> Helper loaded: common_helper
INFO - 2022-03-24 06:19:07 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:19:07 --> Controller Class Initialized
INFO - 2022-03-24 06:19:07 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:19:07 --> Encrypt Class Initialized
INFO - 2022-03-24 06:19:07 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:19:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:19:07 --> Model "Referredby_model" initialized
INFO - 2022-03-24 06:19:07 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:19:07 --> Model "Hospital_model" initialized
INFO - 2022-03-24 06:19:07 --> Upload Class Initialized
INFO - 2022-03-24 06:19:07 --> Final output sent to browser
DEBUG - 2022-03-24 06:19:07 --> Total execution time: 0.0182
ERROR - 2022-03-24 06:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:19:16 --> Config Class Initialized
INFO - 2022-03-24 06:19:16 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:19:16 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:19:16 --> Utf8 Class Initialized
INFO - 2022-03-24 06:19:16 --> URI Class Initialized
INFO - 2022-03-24 06:19:16 --> Router Class Initialized
INFO - 2022-03-24 06:19:16 --> Output Class Initialized
INFO - 2022-03-24 06:19:16 --> Security Class Initialized
DEBUG - 2022-03-24 06:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:19:16 --> Input Class Initialized
INFO - 2022-03-24 06:19:16 --> Language Class Initialized
INFO - 2022-03-24 06:19:16 --> Loader Class Initialized
INFO - 2022-03-24 06:19:16 --> Helper loaded: url_helper
INFO - 2022-03-24 06:19:16 --> Helper loaded: form_helper
INFO - 2022-03-24 06:19:16 --> Helper loaded: common_helper
INFO - 2022-03-24 06:19:16 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:19:16 --> Controller Class Initialized
INFO - 2022-03-24 06:19:16 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:19:16 --> Encrypt Class Initialized
INFO - 2022-03-24 06:19:16 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:19:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:19:16 --> Model "Referredby_model" initialized
INFO - 2022-03-24 06:19:16 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:19:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 06:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:19:16 --> Config Class Initialized
INFO - 2022-03-24 06:19:16 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:19:16 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:19:16 --> Utf8 Class Initialized
INFO - 2022-03-24 06:19:16 --> URI Class Initialized
INFO - 2022-03-24 06:19:16 --> Router Class Initialized
INFO - 2022-03-24 06:19:16 --> Output Class Initialized
INFO - 2022-03-24 06:19:16 --> Security Class Initialized
DEBUG - 2022-03-24 06:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:19:16 --> Input Class Initialized
INFO - 2022-03-24 06:19:16 --> Language Class Initialized
INFO - 2022-03-24 06:19:16 --> Loader Class Initialized
INFO - 2022-03-24 06:19:16 --> Helper loaded: url_helper
INFO - 2022-03-24 06:19:16 --> Helper loaded: form_helper
INFO - 2022-03-24 06:19:16 --> Helper loaded: common_helper
INFO - 2022-03-24 06:19:16 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:19:16 --> Controller Class Initialized
INFO - 2022-03-24 06:19:16 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:19:16 --> Encrypt Class Initialized
INFO - 2022-03-24 06:19:16 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:19:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:19:16 --> Model "Referredby_model" initialized
INFO - 2022-03-24 06:19:16 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:19:16 --> Model "Hospital_model" initialized
INFO - 2022-03-24 06:19:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 06:19:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 06:19:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 06:19:16 --> Final output sent to browser
DEBUG - 2022-03-24 06:19:16 --> Total execution time: 0.0351
ERROR - 2022-03-24 06:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:19:17 --> Config Class Initialized
INFO - 2022-03-24 06:19:17 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:19:17 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:19:17 --> Utf8 Class Initialized
INFO - 2022-03-24 06:19:17 --> URI Class Initialized
INFO - 2022-03-24 06:19:17 --> Router Class Initialized
INFO - 2022-03-24 06:19:17 --> Output Class Initialized
INFO - 2022-03-24 06:19:17 --> Security Class Initialized
DEBUG - 2022-03-24 06:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:19:17 --> Input Class Initialized
INFO - 2022-03-24 06:19:17 --> Language Class Initialized
INFO - 2022-03-24 06:19:17 --> Loader Class Initialized
INFO - 2022-03-24 06:19:17 --> Helper loaded: url_helper
INFO - 2022-03-24 06:19:17 --> Helper loaded: form_helper
INFO - 2022-03-24 06:19:17 --> Helper loaded: common_helper
INFO - 2022-03-24 06:19:17 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:19:17 --> Controller Class Initialized
INFO - 2022-03-24 06:19:17 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:19:17 --> Encrypt Class Initialized
INFO - 2022-03-24 06:19:17 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:19:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:19:17 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:19:17 --> Model "Users_model" initialized
INFO - 2022-03-24 06:19:17 --> Model "Hospital_model" initialized
INFO - 2022-03-24 06:19:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 06:19:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 06:19:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 06:19:17 --> Final output sent to browser
DEBUG - 2022-03-24 06:19:17 --> Total execution time: 0.0675
ERROR - 2022-03-24 06:43:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:43:23 --> Config Class Initialized
INFO - 2022-03-24 06:43:23 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:43:23 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:43:23 --> Utf8 Class Initialized
INFO - 2022-03-24 06:43:23 --> URI Class Initialized
DEBUG - 2022-03-24 06:43:23 --> No URI present. Default controller set.
INFO - 2022-03-24 06:43:23 --> Router Class Initialized
INFO - 2022-03-24 06:43:23 --> Output Class Initialized
INFO - 2022-03-24 06:43:23 --> Security Class Initialized
DEBUG - 2022-03-24 06:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:43:23 --> Input Class Initialized
INFO - 2022-03-24 06:43:23 --> Language Class Initialized
INFO - 2022-03-24 06:43:23 --> Loader Class Initialized
INFO - 2022-03-24 06:43:23 --> Helper loaded: url_helper
INFO - 2022-03-24 06:43:23 --> Helper loaded: form_helper
INFO - 2022-03-24 06:43:23 --> Helper loaded: common_helper
INFO - 2022-03-24 06:43:23 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:43:23 --> Controller Class Initialized
INFO - 2022-03-24 06:43:23 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:43:23 --> Encrypt Class Initialized
DEBUG - 2022-03-24 06:43:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 06:43:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 06:43:23 --> Email Class Initialized
INFO - 2022-03-24 06:43:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 06:43:23 --> Calendar Class Initialized
INFO - 2022-03-24 06:43:23 --> Model "Login_model" initialized
INFO - 2022-03-24 06:43:23 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 06:43:23 --> Final output sent to browser
DEBUG - 2022-03-24 06:43:23 --> Total execution time: 0.0838
ERROR - 2022-03-24 06:44:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 06:44:53 --> Config Class Initialized
INFO - 2022-03-24 06:44:53 --> Hooks Class Initialized
DEBUG - 2022-03-24 06:44:53 --> UTF-8 Support Enabled
INFO - 2022-03-24 06:44:53 --> Utf8 Class Initialized
INFO - 2022-03-24 06:44:53 --> URI Class Initialized
INFO - 2022-03-24 06:44:53 --> Router Class Initialized
INFO - 2022-03-24 06:44:53 --> Output Class Initialized
INFO - 2022-03-24 06:44:53 --> Security Class Initialized
DEBUG - 2022-03-24 06:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 06:44:53 --> Input Class Initialized
INFO - 2022-03-24 06:44:53 --> Language Class Initialized
INFO - 2022-03-24 06:44:53 --> Loader Class Initialized
INFO - 2022-03-24 06:44:53 --> Helper loaded: url_helper
INFO - 2022-03-24 06:44:53 --> Helper loaded: form_helper
INFO - 2022-03-24 06:44:53 --> Helper loaded: common_helper
INFO - 2022-03-24 06:44:53 --> Database Driver Class Initialized
DEBUG - 2022-03-24 06:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 06:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 06:44:53 --> Controller Class Initialized
INFO - 2022-03-24 06:44:53 --> Form Validation Class Initialized
DEBUG - 2022-03-24 06:44:53 --> Encrypt Class Initialized
INFO - 2022-03-24 06:44:53 --> Model "Patient_model" initialized
INFO - 2022-03-24 06:44:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 06:44:53 --> Model "Referredby_model" initialized
INFO - 2022-03-24 06:44:53 --> Model "Prefix_master" initialized
INFO - 2022-03-24 06:44:53 --> Model "Hospital_model" initialized
INFO - 2022-03-24 06:44:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 06:44:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 06:44:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 06:44:53 --> Final output sent to browser
DEBUG - 2022-03-24 06:44:53 --> Total execution time: 0.0430
ERROR - 2022-03-24 11:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 11:11:45 --> Config Class Initialized
INFO - 2022-03-24 11:11:45 --> Hooks Class Initialized
DEBUG - 2022-03-24 11:11:45 --> UTF-8 Support Enabled
INFO - 2022-03-24 11:11:45 --> Utf8 Class Initialized
INFO - 2022-03-24 11:11:45 --> URI Class Initialized
DEBUG - 2022-03-24 11:11:45 --> No URI present. Default controller set.
INFO - 2022-03-24 11:11:45 --> Router Class Initialized
INFO - 2022-03-24 11:11:45 --> Output Class Initialized
INFO - 2022-03-24 11:11:45 --> Security Class Initialized
DEBUG - 2022-03-24 11:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 11:11:45 --> Input Class Initialized
INFO - 2022-03-24 11:11:45 --> Language Class Initialized
INFO - 2022-03-24 11:11:45 --> Loader Class Initialized
INFO - 2022-03-24 11:11:45 --> Helper loaded: url_helper
INFO - 2022-03-24 11:11:45 --> Helper loaded: form_helper
INFO - 2022-03-24 11:11:45 --> Helper loaded: common_helper
INFO - 2022-03-24 11:11:45 --> Database Driver Class Initialized
DEBUG - 2022-03-24 11:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 11:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 11:11:45 --> Controller Class Initialized
INFO - 2022-03-24 11:11:45 --> Form Validation Class Initialized
DEBUG - 2022-03-24 11:11:45 --> Encrypt Class Initialized
DEBUG - 2022-03-24 11:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:11:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 11:11:45 --> Email Class Initialized
INFO - 2022-03-24 11:11:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 11:11:45 --> Calendar Class Initialized
INFO - 2022-03-24 11:11:45 --> Model "Login_model" initialized
INFO - 2022-03-24 11:11:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 11:11:45 --> Final output sent to browser
DEBUG - 2022-03-24 11:11:45 --> Total execution time: 0.0670
ERROR - 2022-03-24 11:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 11:12:22 --> Config Class Initialized
INFO - 2022-03-24 11:12:22 --> Hooks Class Initialized
DEBUG - 2022-03-24 11:12:22 --> UTF-8 Support Enabled
INFO - 2022-03-24 11:12:22 --> Utf8 Class Initialized
INFO - 2022-03-24 11:12:22 --> URI Class Initialized
DEBUG - 2022-03-24 11:12:22 --> No URI present. Default controller set.
INFO - 2022-03-24 11:12:22 --> Router Class Initialized
INFO - 2022-03-24 11:12:22 --> Output Class Initialized
INFO - 2022-03-24 11:12:22 --> Security Class Initialized
DEBUG - 2022-03-24 11:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 11:12:22 --> Input Class Initialized
INFO - 2022-03-24 11:12:22 --> Language Class Initialized
INFO - 2022-03-24 11:12:22 --> Loader Class Initialized
INFO - 2022-03-24 11:12:22 --> Helper loaded: url_helper
INFO - 2022-03-24 11:12:22 --> Helper loaded: form_helper
INFO - 2022-03-24 11:12:22 --> Helper loaded: common_helper
INFO - 2022-03-24 11:12:22 --> Database Driver Class Initialized
DEBUG - 2022-03-24 11:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 11:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 11:12:22 --> Controller Class Initialized
INFO - 2022-03-24 11:12:22 --> Form Validation Class Initialized
DEBUG - 2022-03-24 11:12:22 --> Encrypt Class Initialized
DEBUG - 2022-03-24 11:12:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:12:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 11:12:22 --> Email Class Initialized
INFO - 2022-03-24 11:12:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 11:12:22 --> Calendar Class Initialized
INFO - 2022-03-24 11:12:22 --> Model "Login_model" initialized
INFO - 2022-03-24 11:12:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 11:12:22 --> Final output sent to browser
DEBUG - 2022-03-24 11:12:22 --> Total execution time: 0.0074
ERROR - 2022-03-24 11:12:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 11:12:41 --> Config Class Initialized
INFO - 2022-03-24 11:12:41 --> Hooks Class Initialized
DEBUG - 2022-03-24 11:12:41 --> UTF-8 Support Enabled
INFO - 2022-03-24 11:12:41 --> Utf8 Class Initialized
INFO - 2022-03-24 11:12:41 --> URI Class Initialized
DEBUG - 2022-03-24 11:12:41 --> No URI present. Default controller set.
INFO - 2022-03-24 11:12:41 --> Router Class Initialized
INFO - 2022-03-24 11:12:41 --> Output Class Initialized
INFO - 2022-03-24 11:12:41 --> Security Class Initialized
DEBUG - 2022-03-24 11:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 11:12:41 --> Input Class Initialized
INFO - 2022-03-24 11:12:41 --> Language Class Initialized
INFO - 2022-03-24 11:12:41 --> Loader Class Initialized
INFO - 2022-03-24 11:12:41 --> Helper loaded: url_helper
INFO - 2022-03-24 11:12:41 --> Helper loaded: form_helper
INFO - 2022-03-24 11:12:41 --> Helper loaded: common_helper
INFO - 2022-03-24 11:12:41 --> Database Driver Class Initialized
DEBUG - 2022-03-24 11:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 11:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 11:12:41 --> Controller Class Initialized
INFO - 2022-03-24 11:12:41 --> Form Validation Class Initialized
DEBUG - 2022-03-24 11:12:41 --> Encrypt Class Initialized
DEBUG - 2022-03-24 11:12:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:12:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 11:12:41 --> Email Class Initialized
INFO - 2022-03-24 11:12:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 11:12:41 --> Calendar Class Initialized
INFO - 2022-03-24 11:12:41 --> Model "Login_model" initialized
INFO - 2022-03-24 11:12:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 11:12:41 --> Final output sent to browser
DEBUG - 2022-03-24 11:12:41 --> Total execution time: 0.0085
ERROR - 2022-03-24 13:39:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 13:39:40 --> Config Class Initialized
INFO - 2022-03-24 13:39:40 --> Hooks Class Initialized
DEBUG - 2022-03-24 13:39:40 --> UTF-8 Support Enabled
INFO - 2022-03-24 13:39:40 --> Utf8 Class Initialized
INFO - 2022-03-24 13:39:40 --> URI Class Initialized
DEBUG - 2022-03-24 13:39:40 --> No URI present. Default controller set.
INFO - 2022-03-24 13:39:40 --> Router Class Initialized
INFO - 2022-03-24 13:39:40 --> Output Class Initialized
INFO - 2022-03-24 13:39:40 --> Security Class Initialized
DEBUG - 2022-03-24 13:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 13:39:40 --> Input Class Initialized
INFO - 2022-03-24 13:39:40 --> Language Class Initialized
INFO - 2022-03-24 13:39:40 --> Loader Class Initialized
INFO - 2022-03-24 13:39:40 --> Helper loaded: url_helper
INFO - 2022-03-24 13:39:40 --> Helper loaded: form_helper
INFO - 2022-03-24 13:39:40 --> Helper loaded: common_helper
INFO - 2022-03-24 13:39:40 --> Database Driver Class Initialized
DEBUG - 2022-03-24 13:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 13:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 13:39:40 --> Controller Class Initialized
INFO - 2022-03-24 13:39:40 --> Form Validation Class Initialized
DEBUG - 2022-03-24 13:39:40 --> Encrypt Class Initialized
DEBUG - 2022-03-24 13:39:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:39:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 13:39:40 --> Email Class Initialized
INFO - 2022-03-24 13:39:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 13:39:40 --> Calendar Class Initialized
INFO - 2022-03-24 13:39:40 --> Model "Login_model" initialized
INFO - 2022-03-24 13:39:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 13:39:40 --> Final output sent to browser
DEBUG - 2022-03-24 13:39:40 --> Total execution time: 0.0618
ERROR - 2022-03-24 14:19:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 14:19:05 --> Config Class Initialized
INFO - 2022-03-24 14:19:05 --> Hooks Class Initialized
DEBUG - 2022-03-24 14:19:05 --> UTF-8 Support Enabled
INFO - 2022-03-24 14:19:05 --> Utf8 Class Initialized
INFO - 2022-03-24 14:19:05 --> URI Class Initialized
DEBUG - 2022-03-24 14:19:05 --> No URI present. Default controller set.
INFO - 2022-03-24 14:19:05 --> Router Class Initialized
INFO - 2022-03-24 14:19:05 --> Output Class Initialized
INFO - 2022-03-24 14:19:05 --> Security Class Initialized
DEBUG - 2022-03-24 14:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 14:19:05 --> Input Class Initialized
INFO - 2022-03-24 14:19:05 --> Language Class Initialized
INFO - 2022-03-24 14:19:05 --> Loader Class Initialized
INFO - 2022-03-24 14:19:05 --> Helper loaded: url_helper
INFO - 2022-03-24 14:19:05 --> Helper loaded: form_helper
INFO - 2022-03-24 14:19:05 --> Helper loaded: common_helper
INFO - 2022-03-24 14:19:05 --> Database Driver Class Initialized
DEBUG - 2022-03-24 14:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 14:19:06 --> Controller Class Initialized
INFO - 2022-03-24 14:19:06 --> Form Validation Class Initialized
DEBUG - 2022-03-24 14:19:06 --> Encrypt Class Initialized
DEBUG - 2022-03-24 14:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:19:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 14:19:06 --> Email Class Initialized
INFO - 2022-03-24 14:19:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 14:19:06 --> Calendar Class Initialized
INFO - 2022-03-24 14:19:06 --> Model "Login_model" initialized
INFO - 2022-03-24 14:19:06 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 14:19:06 --> Final output sent to browser
DEBUG - 2022-03-24 14:19:06 --> Total execution time: 0.4740
ERROR - 2022-03-24 14:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 14:19:06 --> Config Class Initialized
INFO - 2022-03-24 14:19:06 --> Hooks Class Initialized
DEBUG - 2022-03-24 14:19:06 --> UTF-8 Support Enabled
INFO - 2022-03-24 14:19:06 --> Utf8 Class Initialized
INFO - 2022-03-24 14:19:06 --> URI Class Initialized
INFO - 2022-03-24 14:19:06 --> Router Class Initialized
INFO - 2022-03-24 14:19:06 --> Output Class Initialized
INFO - 2022-03-24 14:19:06 --> Security Class Initialized
DEBUG - 2022-03-24 14:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 14:19:06 --> Input Class Initialized
INFO - 2022-03-24 14:19:06 --> Language Class Initialized
ERROR - 2022-03-24 14:19:06 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-24 14:19:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 14:19:53 --> Config Class Initialized
INFO - 2022-03-24 14:19:53 --> Hooks Class Initialized
DEBUG - 2022-03-24 14:19:53 --> UTF-8 Support Enabled
INFO - 2022-03-24 14:19:53 --> Utf8 Class Initialized
INFO - 2022-03-24 14:19:53 --> URI Class Initialized
INFO - 2022-03-24 14:19:53 --> Router Class Initialized
INFO - 2022-03-24 14:19:53 --> Output Class Initialized
INFO - 2022-03-24 14:19:53 --> Security Class Initialized
DEBUG - 2022-03-24 14:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 14:19:53 --> Input Class Initialized
INFO - 2022-03-24 14:19:53 --> Language Class Initialized
INFO - 2022-03-24 14:19:53 --> Loader Class Initialized
INFO - 2022-03-24 14:19:53 --> Helper loaded: url_helper
INFO - 2022-03-24 14:19:53 --> Helper loaded: form_helper
INFO - 2022-03-24 14:19:53 --> Helper loaded: common_helper
INFO - 2022-03-24 14:19:53 --> Database Driver Class Initialized
DEBUG - 2022-03-24 14:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 14:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 14:19:53 --> Controller Class Initialized
INFO - 2022-03-24 14:19:53 --> Form Validation Class Initialized
DEBUG - 2022-03-24 14:19:53 --> Encrypt Class Initialized
DEBUG - 2022-03-24 14:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:19:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 14:19:53 --> Email Class Initialized
INFO - 2022-03-24 14:19:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 14:19:53 --> Calendar Class Initialized
INFO - 2022-03-24 14:19:53 --> Model "Login_model" initialized
ERROR - 2022-03-24 14:19:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 14:19:53 --> Config Class Initialized
INFO - 2022-03-24 14:19:53 --> Hooks Class Initialized
DEBUG - 2022-03-24 14:19:53 --> UTF-8 Support Enabled
INFO - 2022-03-24 14:19:53 --> Utf8 Class Initialized
INFO - 2022-03-24 14:19:53 --> URI Class Initialized
INFO - 2022-03-24 14:19:53 --> Router Class Initialized
INFO - 2022-03-24 14:19:53 --> Output Class Initialized
INFO - 2022-03-24 14:19:53 --> Security Class Initialized
DEBUG - 2022-03-24 14:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 14:19:53 --> Input Class Initialized
INFO - 2022-03-24 14:19:53 --> Language Class Initialized
INFO - 2022-03-24 14:19:53 --> Loader Class Initialized
INFO - 2022-03-24 14:19:54 --> Helper loaded: url_helper
INFO - 2022-03-24 14:19:54 --> Helper loaded: form_helper
INFO - 2022-03-24 14:19:54 --> Helper loaded: common_helper
INFO - 2022-03-24 14:19:54 --> Database Driver Class Initialized
DEBUG - 2022-03-24 14:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 14:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 14:19:54 --> Controller Class Initialized
INFO - 2022-03-24 14:19:54 --> Form Validation Class Initialized
DEBUG - 2022-03-24 14:19:54 --> Encrypt Class Initialized
DEBUG - 2022-03-24 14:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:19:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 14:19:54 --> Email Class Initialized
INFO - 2022-03-24 14:19:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 14:19:54 --> Calendar Class Initialized
INFO - 2022-03-24 14:19:54 --> Model "Login_model" initialized
ERROR - 2022-03-24 14:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 14:19:54 --> Config Class Initialized
INFO - 2022-03-24 14:19:54 --> Hooks Class Initialized
DEBUG - 2022-03-24 14:19:54 --> UTF-8 Support Enabled
INFO - 2022-03-24 14:19:54 --> Utf8 Class Initialized
INFO - 2022-03-24 14:19:54 --> URI Class Initialized
DEBUG - 2022-03-24 14:19:54 --> No URI present. Default controller set.
INFO - 2022-03-24 14:19:54 --> Router Class Initialized
INFO - 2022-03-24 14:19:54 --> Output Class Initialized
INFO - 2022-03-24 14:19:54 --> Security Class Initialized
DEBUG - 2022-03-24 14:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 14:19:54 --> Input Class Initialized
INFO - 2022-03-24 14:19:54 --> Language Class Initialized
INFO - 2022-03-24 14:19:54 --> Loader Class Initialized
INFO - 2022-03-24 14:19:54 --> Helper loaded: url_helper
INFO - 2022-03-24 14:19:54 --> Helper loaded: form_helper
INFO - 2022-03-24 14:19:54 --> Helper loaded: common_helper
INFO - 2022-03-24 14:19:54 --> Database Driver Class Initialized
DEBUG - 2022-03-24 14:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 14:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 14:19:54 --> Controller Class Initialized
INFO - 2022-03-24 14:19:54 --> Form Validation Class Initialized
DEBUG - 2022-03-24 14:19:54 --> Encrypt Class Initialized
DEBUG - 2022-03-24 14:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:19:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 14:19:54 --> Email Class Initialized
INFO - 2022-03-24 14:19:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 14:19:54 --> Calendar Class Initialized
INFO - 2022-03-24 14:19:54 --> Model "Login_model" initialized
INFO - 2022-03-24 14:19:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 14:19:54 --> Final output sent to browser
DEBUG - 2022-03-24 14:19:54 --> Total execution time: 0.0129
ERROR - 2022-03-24 14:19:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 14:19:55 --> Config Class Initialized
INFO - 2022-03-24 14:19:55 --> Hooks Class Initialized
DEBUG - 2022-03-24 14:19:55 --> UTF-8 Support Enabled
INFO - 2022-03-24 14:19:55 --> Utf8 Class Initialized
INFO - 2022-03-24 14:19:55 --> URI Class Initialized
INFO - 2022-03-24 14:19:55 --> Router Class Initialized
INFO - 2022-03-24 14:19:55 --> Output Class Initialized
INFO - 2022-03-24 14:19:55 --> Security Class Initialized
DEBUG - 2022-03-24 14:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 14:19:55 --> Input Class Initialized
INFO - 2022-03-24 14:19:55 --> Language Class Initialized
INFO - 2022-03-24 14:19:55 --> Loader Class Initialized
INFO - 2022-03-24 14:19:55 --> Helper loaded: url_helper
INFO - 2022-03-24 14:19:55 --> Helper loaded: form_helper
INFO - 2022-03-24 14:19:55 --> Helper loaded: common_helper
INFO - 2022-03-24 14:19:55 --> Database Driver Class Initialized
DEBUG - 2022-03-24 14:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 14:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 14:19:55 --> Controller Class Initialized
INFO - 2022-03-24 14:19:55 --> Form Validation Class Initialized
DEBUG - 2022-03-24 14:19:55 --> Encrypt Class Initialized
DEBUG - 2022-03-24 14:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:19:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 14:19:55 --> Email Class Initialized
INFO - 2022-03-24 14:19:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 14:19:55 --> Calendar Class Initialized
INFO - 2022-03-24 14:19:55 --> Model "Login_model" initialized
INFO - 2022-03-24 14:19:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 14:19:55 --> Final output sent to browser
DEBUG - 2022-03-24 14:19:55 --> Total execution time: 0.0250
ERROR - 2022-03-24 22:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 22:57:32 --> Config Class Initialized
INFO - 2022-03-24 22:57:32 --> Hooks Class Initialized
DEBUG - 2022-03-24 22:57:32 --> UTF-8 Support Enabled
INFO - 2022-03-24 22:57:32 --> Utf8 Class Initialized
INFO - 2022-03-24 22:57:32 --> URI Class Initialized
DEBUG - 2022-03-24 22:57:32 --> No URI present. Default controller set.
INFO - 2022-03-24 22:57:32 --> Router Class Initialized
INFO - 2022-03-24 22:57:32 --> Output Class Initialized
INFO - 2022-03-24 22:57:32 --> Security Class Initialized
DEBUG - 2022-03-24 22:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 22:57:32 --> Input Class Initialized
INFO - 2022-03-24 22:57:32 --> Language Class Initialized
INFO - 2022-03-24 22:57:32 --> Loader Class Initialized
INFO - 2022-03-24 22:57:32 --> Helper loaded: url_helper
INFO - 2022-03-24 22:57:32 --> Helper loaded: form_helper
INFO - 2022-03-24 22:57:32 --> Helper loaded: common_helper
INFO - 2022-03-24 22:57:32 --> Database Driver Class Initialized
DEBUG - 2022-03-24 22:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 22:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 22:57:32 --> Controller Class Initialized
INFO - 2022-03-24 22:57:32 --> Form Validation Class Initialized
DEBUG - 2022-03-24 22:57:32 --> Encrypt Class Initialized
DEBUG - 2022-03-24 22:57:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 22:57:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 22:57:32 --> Email Class Initialized
INFO - 2022-03-24 22:57:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 22:57:32 --> Calendar Class Initialized
INFO - 2022-03-24 22:57:32 --> Model "Login_model" initialized
INFO - 2022-03-24 22:57:32 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 22:57:32 --> Final output sent to browser
DEBUG - 2022-03-24 22:57:32 --> Total execution time: 0.0768
ERROR - 2022-03-24 23:06:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:06:18 --> Config Class Initialized
INFO - 2022-03-24 23:06:18 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:06:18 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:06:18 --> Utf8 Class Initialized
INFO - 2022-03-24 23:06:18 --> URI Class Initialized
DEBUG - 2022-03-24 23:06:18 --> No URI present. Default controller set.
INFO - 2022-03-24 23:06:18 --> Router Class Initialized
INFO - 2022-03-24 23:06:18 --> Output Class Initialized
INFO - 2022-03-24 23:06:18 --> Security Class Initialized
DEBUG - 2022-03-24 23:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:06:18 --> Input Class Initialized
INFO - 2022-03-24 23:06:18 --> Language Class Initialized
INFO - 2022-03-24 23:06:18 --> Loader Class Initialized
INFO - 2022-03-24 23:06:18 --> Helper loaded: url_helper
INFO - 2022-03-24 23:06:18 --> Helper loaded: form_helper
INFO - 2022-03-24 23:06:18 --> Helper loaded: common_helper
INFO - 2022-03-24 23:06:18 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:06:18 --> Controller Class Initialized
INFO - 2022-03-24 23:06:18 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:06:18 --> Encrypt Class Initialized
DEBUG - 2022-03-24 23:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 23:06:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 23:06:18 --> Email Class Initialized
INFO - 2022-03-24 23:06:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 23:06:18 --> Calendar Class Initialized
INFO - 2022-03-24 23:06:18 --> Model "Login_model" initialized
INFO - 2022-03-24 23:06:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 23:06:18 --> Final output sent to browser
DEBUG - 2022-03-24 23:06:18 --> Total execution time: 0.0745
ERROR - 2022-03-24 23:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:06:19 --> Config Class Initialized
INFO - 2022-03-24 23:06:19 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:06:19 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:06:19 --> Utf8 Class Initialized
INFO - 2022-03-24 23:06:19 --> URI Class Initialized
DEBUG - 2022-03-24 23:06:19 --> No URI present. Default controller set.
INFO - 2022-03-24 23:06:19 --> Router Class Initialized
INFO - 2022-03-24 23:06:19 --> Output Class Initialized
INFO - 2022-03-24 23:06:19 --> Security Class Initialized
DEBUG - 2022-03-24 23:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:06:19 --> Input Class Initialized
INFO - 2022-03-24 23:06:19 --> Language Class Initialized
INFO - 2022-03-24 23:06:19 --> Loader Class Initialized
INFO - 2022-03-24 23:06:19 --> Helper loaded: url_helper
INFO - 2022-03-24 23:06:19 --> Helper loaded: form_helper
INFO - 2022-03-24 23:06:19 --> Helper loaded: common_helper
INFO - 2022-03-24 23:06:19 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:06:19 --> Controller Class Initialized
INFO - 2022-03-24 23:06:19 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:06:19 --> Encrypt Class Initialized
DEBUG - 2022-03-24 23:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 23:06:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 23:06:19 --> Email Class Initialized
INFO - 2022-03-24 23:06:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 23:06:19 --> Calendar Class Initialized
INFO - 2022-03-24 23:06:19 --> Model "Login_model" initialized
INFO - 2022-03-24 23:06:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 23:06:19 --> Final output sent to browser
DEBUG - 2022-03-24 23:06:19 --> Total execution time: 0.0137
ERROR - 2022-03-24 23:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:06:34 --> Config Class Initialized
INFO - 2022-03-24 23:06:34 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:06:34 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:06:34 --> Utf8 Class Initialized
INFO - 2022-03-24 23:06:34 --> URI Class Initialized
INFO - 2022-03-24 23:06:34 --> Router Class Initialized
INFO - 2022-03-24 23:06:34 --> Output Class Initialized
INFO - 2022-03-24 23:06:34 --> Security Class Initialized
DEBUG - 2022-03-24 23:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:06:34 --> Input Class Initialized
INFO - 2022-03-24 23:06:34 --> Language Class Initialized
INFO - 2022-03-24 23:06:34 --> Loader Class Initialized
INFO - 2022-03-24 23:06:34 --> Helper loaded: url_helper
INFO - 2022-03-24 23:06:34 --> Helper loaded: form_helper
INFO - 2022-03-24 23:06:34 --> Helper loaded: common_helper
INFO - 2022-03-24 23:06:34 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:06:34 --> Controller Class Initialized
INFO - 2022-03-24 23:06:34 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:06:34 --> Encrypt Class Initialized
DEBUG - 2022-03-24 23:06:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 23:06:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 23:06:34 --> Email Class Initialized
INFO - 2022-03-24 23:06:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 23:06:34 --> Calendar Class Initialized
INFO - 2022-03-24 23:06:34 --> Model "Login_model" initialized
INFO - 2022-03-24 23:06:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-24 23:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:06:34 --> Config Class Initialized
INFO - 2022-03-24 23:06:34 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:06:34 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:06:34 --> Utf8 Class Initialized
INFO - 2022-03-24 23:06:34 --> URI Class Initialized
INFO - 2022-03-24 23:06:34 --> Router Class Initialized
INFO - 2022-03-24 23:06:34 --> Output Class Initialized
INFO - 2022-03-24 23:06:34 --> Security Class Initialized
DEBUG - 2022-03-24 23:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:06:34 --> Input Class Initialized
INFO - 2022-03-24 23:06:34 --> Language Class Initialized
INFO - 2022-03-24 23:06:34 --> Loader Class Initialized
INFO - 2022-03-24 23:06:34 --> Helper loaded: url_helper
INFO - 2022-03-24 23:06:34 --> Helper loaded: form_helper
INFO - 2022-03-24 23:06:34 --> Helper loaded: common_helper
INFO - 2022-03-24 23:06:34 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:06:34 --> Controller Class Initialized
INFO - 2022-03-24 23:06:34 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:06:34 --> Encrypt Class Initialized
INFO - 2022-03-24 23:06:34 --> Model "Login_model" initialized
INFO - 2022-03-24 23:06:34 --> Model "Dashboard_model" initialized
INFO - 2022-03-24 23:06:34 --> Model "Case_model" initialized
INFO - 2022-03-24 23:06:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:06:35 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-24 23:06:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:06:35 --> Final output sent to browser
DEBUG - 2022-03-24 23:06:35 --> Total execution time: 0.4226
ERROR - 2022-03-24 23:12:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:12:33 --> Config Class Initialized
INFO - 2022-03-24 23:12:33 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:12:33 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:12:33 --> Utf8 Class Initialized
INFO - 2022-03-24 23:12:33 --> URI Class Initialized
INFO - 2022-03-24 23:12:33 --> Router Class Initialized
INFO - 2022-03-24 23:12:33 --> Output Class Initialized
INFO - 2022-03-24 23:12:33 --> Security Class Initialized
DEBUG - 2022-03-24 23:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:12:33 --> Input Class Initialized
INFO - 2022-03-24 23:12:33 --> Language Class Initialized
INFO - 2022-03-24 23:12:33 --> Loader Class Initialized
INFO - 2022-03-24 23:12:33 --> Helper loaded: url_helper
INFO - 2022-03-24 23:12:33 --> Helper loaded: form_helper
INFO - 2022-03-24 23:12:33 --> Helper loaded: common_helper
INFO - 2022-03-24 23:12:33 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:12:33 --> Controller Class Initialized
INFO - 2022-03-24 23:12:33 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:12:33 --> Encrypt Class Initialized
INFO - 2022-03-24 23:12:33 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:12:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:12:33 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:12:33 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:12:33 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:12:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:12:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-24 23:12:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:12:33 --> Final output sent to browser
DEBUG - 2022-03-24 23:12:33 --> Total execution time: 0.1242
ERROR - 2022-03-24 23:12:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:12:46 --> Config Class Initialized
INFO - 2022-03-24 23:12:46 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:12:46 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:12:46 --> Utf8 Class Initialized
INFO - 2022-03-24 23:12:46 --> URI Class Initialized
INFO - 2022-03-24 23:12:46 --> Router Class Initialized
INFO - 2022-03-24 23:12:46 --> Output Class Initialized
INFO - 2022-03-24 23:12:46 --> Security Class Initialized
DEBUG - 2022-03-24 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:12:46 --> Input Class Initialized
INFO - 2022-03-24 23:12:46 --> Language Class Initialized
INFO - 2022-03-24 23:12:46 --> Loader Class Initialized
INFO - 2022-03-24 23:12:46 --> Helper loaded: url_helper
INFO - 2022-03-24 23:12:46 --> Helper loaded: form_helper
INFO - 2022-03-24 23:12:46 --> Helper loaded: common_helper
INFO - 2022-03-24 23:12:46 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:12:46 --> Controller Class Initialized
INFO - 2022-03-24 23:12:46 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:12:46 --> Encrypt Class Initialized
INFO - 2022-03-24 23:12:46 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:12:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:12:46 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:12:46 --> Model "Users_model" initialized
INFO - 2022-03-24 23:12:46 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:12:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:12:46 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 23:12:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:12:46 --> Final output sent to browser
DEBUG - 2022-03-24 23:12:46 --> Total execution time: 0.2724
ERROR - 2022-03-24 23:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:12:55 --> Config Class Initialized
INFO - 2022-03-24 23:12:55 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:12:55 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:12:55 --> Utf8 Class Initialized
INFO - 2022-03-24 23:12:55 --> URI Class Initialized
INFO - 2022-03-24 23:12:55 --> Router Class Initialized
INFO - 2022-03-24 23:12:55 --> Output Class Initialized
INFO - 2022-03-24 23:12:55 --> Security Class Initialized
DEBUG - 2022-03-24 23:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:12:55 --> Input Class Initialized
INFO - 2022-03-24 23:12:55 --> Language Class Initialized
INFO - 2022-03-24 23:12:55 --> Loader Class Initialized
INFO - 2022-03-24 23:12:55 --> Helper loaded: url_helper
INFO - 2022-03-24 23:12:55 --> Helper loaded: form_helper
INFO - 2022-03-24 23:12:55 --> Helper loaded: common_helper
INFO - 2022-03-24 23:12:55 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:12:55 --> Controller Class Initialized
INFO - 2022-03-24 23:12:55 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:12:55 --> Encrypt Class Initialized
INFO - 2022-03-24 23:12:55 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:12:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:12:55 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:12:55 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:12:55 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:12:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:12:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 23:12:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:12:55 --> Final output sent to browser
DEBUG - 2022-03-24 23:12:55 --> Total execution time: 0.1572
ERROR - 2022-03-24 23:15:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:15:01 --> Config Class Initialized
INFO - 2022-03-24 23:15:01 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:15:01 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:15:01 --> Utf8 Class Initialized
INFO - 2022-03-24 23:15:01 --> URI Class Initialized
INFO - 2022-03-24 23:15:01 --> Router Class Initialized
INFO - 2022-03-24 23:15:01 --> Output Class Initialized
INFO - 2022-03-24 23:15:01 --> Security Class Initialized
DEBUG - 2022-03-24 23:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:15:01 --> Input Class Initialized
INFO - 2022-03-24 23:15:01 --> Language Class Initialized
INFO - 2022-03-24 23:15:01 --> Loader Class Initialized
INFO - 2022-03-24 23:15:01 --> Helper loaded: url_helper
INFO - 2022-03-24 23:15:01 --> Helper loaded: form_helper
INFO - 2022-03-24 23:15:01 --> Helper loaded: common_helper
INFO - 2022-03-24 23:15:01 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:15:01 --> Controller Class Initialized
INFO - 2022-03-24 23:15:01 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:15:01 --> Encrypt Class Initialized
INFO - 2022-03-24 23:15:01 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:15:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:15:01 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:15:01 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:15:01 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 23:15:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:15:01 --> Config Class Initialized
INFO - 2022-03-24 23:15:01 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:15:01 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:15:01 --> Utf8 Class Initialized
INFO - 2022-03-24 23:15:01 --> URI Class Initialized
INFO - 2022-03-24 23:15:01 --> Router Class Initialized
INFO - 2022-03-24 23:15:01 --> Output Class Initialized
INFO - 2022-03-24 23:15:01 --> Security Class Initialized
DEBUG - 2022-03-24 23:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:15:01 --> Input Class Initialized
INFO - 2022-03-24 23:15:01 --> Language Class Initialized
INFO - 2022-03-24 23:15:01 --> Loader Class Initialized
INFO - 2022-03-24 23:15:01 --> Helper loaded: url_helper
INFO - 2022-03-24 23:15:01 --> Helper loaded: form_helper
INFO - 2022-03-24 23:15:01 --> Helper loaded: common_helper
INFO - 2022-03-24 23:15:01 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:15:01 --> Controller Class Initialized
INFO - 2022-03-24 23:15:01 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:15:01 --> Encrypt Class Initialized
INFO - 2022-03-24 23:15:01 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:15:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:15:01 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:15:01 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:15:01 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:15:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:15:01 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 23:15:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:15:01 --> Final output sent to browser
DEBUG - 2022-03-24 23:15:01 --> Total execution time: 0.0477
ERROR - 2022-03-24 23:15:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:15:02 --> Config Class Initialized
INFO - 2022-03-24 23:15:02 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:15:02 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:15:02 --> Utf8 Class Initialized
INFO - 2022-03-24 23:15:02 --> URI Class Initialized
INFO - 2022-03-24 23:15:02 --> Router Class Initialized
INFO - 2022-03-24 23:15:02 --> Output Class Initialized
INFO - 2022-03-24 23:15:02 --> Security Class Initialized
DEBUG - 2022-03-24 23:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:15:02 --> Input Class Initialized
INFO - 2022-03-24 23:15:02 --> Language Class Initialized
INFO - 2022-03-24 23:15:02 --> Loader Class Initialized
INFO - 2022-03-24 23:15:02 --> Helper loaded: url_helper
INFO - 2022-03-24 23:15:02 --> Helper loaded: form_helper
INFO - 2022-03-24 23:15:02 --> Helper loaded: common_helper
INFO - 2022-03-24 23:15:02 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:15:02 --> Controller Class Initialized
INFO - 2022-03-24 23:15:02 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:15:02 --> Encrypt Class Initialized
INFO - 2022-03-24 23:15:02 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:15:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:15:02 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:15:02 --> Model "Users_model" initialized
INFO - 2022-03-24 23:15:02 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:15:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:15:02 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 23:15:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:15:02 --> Final output sent to browser
DEBUG - 2022-03-24 23:15:02 --> Total execution time: 0.1905
ERROR - 2022-03-24 23:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:18:43 --> Config Class Initialized
INFO - 2022-03-24 23:18:43 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:18:43 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:18:43 --> Utf8 Class Initialized
INFO - 2022-03-24 23:18:43 --> URI Class Initialized
INFO - 2022-03-24 23:18:43 --> Router Class Initialized
INFO - 2022-03-24 23:18:43 --> Output Class Initialized
INFO - 2022-03-24 23:18:43 --> Security Class Initialized
DEBUG - 2022-03-24 23:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:18:43 --> Input Class Initialized
INFO - 2022-03-24 23:18:43 --> Language Class Initialized
INFO - 2022-03-24 23:18:43 --> Loader Class Initialized
INFO - 2022-03-24 23:18:43 --> Helper loaded: url_helper
INFO - 2022-03-24 23:18:43 --> Helper loaded: form_helper
INFO - 2022-03-24 23:18:43 --> Helper loaded: common_helper
INFO - 2022-03-24 23:18:44 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:18:44 --> Controller Class Initialized
INFO - 2022-03-24 23:18:44 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:18:44 --> Encrypt Class Initialized
INFO - 2022-03-24 23:18:44 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:18:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:18:44 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:18:44 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:18:44 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:18:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:18:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 23:18:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:18:44 --> Final output sent to browser
DEBUG - 2022-03-24 23:18:44 --> Total execution time: 0.0753
ERROR - 2022-03-24 23:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:18:58 --> Config Class Initialized
INFO - 2022-03-24 23:18:58 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:18:58 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:18:58 --> Utf8 Class Initialized
INFO - 2022-03-24 23:18:58 --> URI Class Initialized
INFO - 2022-03-24 23:18:58 --> Router Class Initialized
INFO - 2022-03-24 23:18:58 --> Output Class Initialized
INFO - 2022-03-24 23:18:58 --> Security Class Initialized
DEBUG - 2022-03-24 23:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:18:58 --> Input Class Initialized
INFO - 2022-03-24 23:18:58 --> Language Class Initialized
INFO - 2022-03-24 23:18:58 --> Loader Class Initialized
INFO - 2022-03-24 23:18:58 --> Helper loaded: url_helper
INFO - 2022-03-24 23:18:58 --> Helper loaded: form_helper
INFO - 2022-03-24 23:18:58 --> Helper loaded: common_helper
INFO - 2022-03-24 23:18:58 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:18:58 --> Controller Class Initialized
ERROR - 2022-03-24 23:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:18:58 --> Config Class Initialized
INFO - 2022-03-24 23:18:58 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:18:58 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:18:58 --> Utf8 Class Initialized
INFO - 2022-03-24 23:18:58 --> URI Class Initialized
INFO - 2022-03-24 23:18:58 --> Router Class Initialized
INFO - 2022-03-24 23:18:58 --> Output Class Initialized
INFO - 2022-03-24 23:18:58 --> Security Class Initialized
DEBUG - 2022-03-24 23:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:18:58 --> Input Class Initialized
INFO - 2022-03-24 23:18:58 --> Language Class Initialized
INFO - 2022-03-24 23:18:58 --> Loader Class Initialized
INFO - 2022-03-24 23:18:58 --> Helper loaded: url_helper
INFO - 2022-03-24 23:18:58 --> Helper loaded: form_helper
INFO - 2022-03-24 23:18:58 --> Helper loaded: common_helper
INFO - 2022-03-24 23:18:58 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:18:58 --> Controller Class Initialized
INFO - 2022-03-24 23:18:58 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:18:58 --> Encrypt Class Initialized
DEBUG - 2022-03-24 23:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 23:18:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 23:18:58 --> Email Class Initialized
INFO - 2022-03-24 23:18:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 23:18:58 --> Calendar Class Initialized
INFO - 2022-03-24 23:18:58 --> Model "Login_model" initialized
INFO - 2022-03-24 23:18:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 23:18:58 --> Final output sent to browser
DEBUG - 2022-03-24 23:18:58 --> Total execution time: 0.0173
ERROR - 2022-03-24 23:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:21:33 --> Config Class Initialized
INFO - 2022-03-24 23:21:33 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:21:33 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:21:33 --> Utf8 Class Initialized
INFO - 2022-03-24 23:21:33 --> URI Class Initialized
DEBUG - 2022-03-24 23:21:33 --> No URI present. Default controller set.
INFO - 2022-03-24 23:21:33 --> Router Class Initialized
INFO - 2022-03-24 23:21:33 --> Output Class Initialized
INFO - 2022-03-24 23:21:33 --> Security Class Initialized
DEBUG - 2022-03-24 23:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:21:33 --> Input Class Initialized
INFO - 2022-03-24 23:21:33 --> Language Class Initialized
INFO - 2022-03-24 23:21:33 --> Loader Class Initialized
INFO - 2022-03-24 23:21:33 --> Helper loaded: url_helper
INFO - 2022-03-24 23:21:33 --> Helper loaded: form_helper
INFO - 2022-03-24 23:21:33 --> Helper loaded: common_helper
INFO - 2022-03-24 23:21:33 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:21:33 --> Controller Class Initialized
INFO - 2022-03-24 23:21:33 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:21:33 --> Encrypt Class Initialized
DEBUG - 2022-03-24 23:21:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 23:21:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 23:21:33 --> Email Class Initialized
INFO - 2022-03-24 23:21:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 23:21:33 --> Calendar Class Initialized
INFO - 2022-03-24 23:21:33 --> Model "Login_model" initialized
ERROR - 2022-03-24 23:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:21:33 --> Config Class Initialized
INFO - 2022-03-24 23:21:33 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:21:33 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:21:33 --> Utf8 Class Initialized
INFO - 2022-03-24 23:21:33 --> URI Class Initialized
INFO - 2022-03-24 23:21:33 --> Router Class Initialized
INFO - 2022-03-24 23:21:33 --> Output Class Initialized
INFO - 2022-03-24 23:21:33 --> Security Class Initialized
DEBUG - 2022-03-24 23:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:21:33 --> Input Class Initialized
INFO - 2022-03-24 23:21:33 --> Language Class Initialized
INFO - 2022-03-24 23:21:33 --> Loader Class Initialized
INFO - 2022-03-24 23:21:33 --> Helper loaded: url_helper
INFO - 2022-03-24 23:21:33 --> Helper loaded: form_helper
INFO - 2022-03-24 23:21:33 --> Helper loaded: common_helper
INFO - 2022-03-24 23:21:33 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:21:33 --> Controller Class Initialized
INFO - 2022-03-24 23:21:33 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:21:33 --> Encrypt Class Initialized
INFO - 2022-03-24 23:21:33 --> Model "Diseases_model" initialized
INFO - 2022-03-24 23:21:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:21:33 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-24 23:21:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:21:33 --> Final output sent to browser
DEBUG - 2022-03-24 23:21:33 --> Total execution time: 0.1329
ERROR - 2022-03-24 23:50:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:50:58 --> Config Class Initialized
INFO - 2022-03-24 23:50:58 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:50:58 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:50:58 --> Utf8 Class Initialized
INFO - 2022-03-24 23:50:58 --> URI Class Initialized
INFO - 2022-03-24 23:50:58 --> Router Class Initialized
INFO - 2022-03-24 23:50:58 --> Output Class Initialized
INFO - 2022-03-24 23:50:58 --> Security Class Initialized
DEBUG - 2022-03-24 23:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:50:58 --> Input Class Initialized
INFO - 2022-03-24 23:50:58 --> Language Class Initialized
INFO - 2022-03-24 23:50:58 --> Loader Class Initialized
INFO - 2022-03-24 23:50:58 --> Helper loaded: url_helper
INFO - 2022-03-24 23:50:58 --> Helper loaded: form_helper
INFO - 2022-03-24 23:50:58 --> Helper loaded: common_helper
INFO - 2022-03-24 23:50:58 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:50:58 --> Controller Class Initialized
INFO - 2022-03-24 23:50:58 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:50:58 --> Encrypt Class Initialized
INFO - 2022-03-24 23:50:58 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:50:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:50:58 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:50:58 --> Model "Users_model" initialized
INFO - 2022-03-24 23:50:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 23:50:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:50:59 --> Config Class Initialized
INFO - 2022-03-24 23:50:59 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:50:59 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:50:59 --> Utf8 Class Initialized
INFO - 2022-03-24 23:50:59 --> URI Class Initialized
INFO - 2022-03-24 23:50:59 --> Router Class Initialized
INFO - 2022-03-24 23:50:59 --> Output Class Initialized
INFO - 2022-03-24 23:50:59 --> Security Class Initialized
DEBUG - 2022-03-24 23:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:50:59 --> Input Class Initialized
INFO - 2022-03-24 23:50:59 --> Language Class Initialized
INFO - 2022-03-24 23:50:59 --> Loader Class Initialized
INFO - 2022-03-24 23:50:59 --> Helper loaded: url_helper
INFO - 2022-03-24 23:50:59 --> Helper loaded: form_helper
INFO - 2022-03-24 23:50:59 --> Helper loaded: common_helper
INFO - 2022-03-24 23:50:59 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:50:59 --> Controller Class Initialized
INFO - 2022-03-24 23:50:59 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:50:59 --> Encrypt Class Initialized
INFO - 2022-03-24 23:50:59 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:50:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:50:59 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:50:59 --> Model "Users_model" initialized
INFO - 2022-03-24 23:50:59 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:50:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:50:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 23:50:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:50:59 --> Final output sent to browser
DEBUG - 2022-03-24 23:50:59 --> Total execution time: 0.0635
ERROR - 2022-03-24 23:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:51:03 --> Config Class Initialized
INFO - 2022-03-24 23:51:03 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:51:03 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:51:03 --> Utf8 Class Initialized
INFO - 2022-03-24 23:51:03 --> URI Class Initialized
INFO - 2022-03-24 23:51:03 --> Router Class Initialized
INFO - 2022-03-24 23:51:03 --> Output Class Initialized
INFO - 2022-03-24 23:51:03 --> Security Class Initialized
DEBUG - 2022-03-24 23:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:51:03 --> Input Class Initialized
INFO - 2022-03-24 23:51:03 --> Language Class Initialized
INFO - 2022-03-24 23:51:03 --> Loader Class Initialized
INFO - 2022-03-24 23:51:03 --> Helper loaded: url_helper
INFO - 2022-03-24 23:51:03 --> Helper loaded: form_helper
INFO - 2022-03-24 23:51:03 --> Helper loaded: common_helper
INFO - 2022-03-24 23:51:03 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:51:03 --> Controller Class Initialized
INFO - 2022-03-24 23:51:03 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:51:03 --> Encrypt Class Initialized
INFO - 2022-03-24 23:51:03 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:51:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:51:03 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:51:03 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:51:03 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:51:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:51:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 23:51:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:51:03 --> Final output sent to browser
DEBUG - 2022-03-24 23:51:03 --> Total execution time: 0.0387
ERROR - 2022-03-24 23:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:51:25 --> Config Class Initialized
INFO - 2022-03-24 23:51:25 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:51:25 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:51:25 --> Utf8 Class Initialized
INFO - 2022-03-24 23:51:25 --> URI Class Initialized
INFO - 2022-03-24 23:51:25 --> Router Class Initialized
INFO - 2022-03-24 23:51:25 --> Output Class Initialized
INFO - 2022-03-24 23:51:25 --> Security Class Initialized
DEBUG - 2022-03-24 23:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:51:25 --> Input Class Initialized
INFO - 2022-03-24 23:51:25 --> Language Class Initialized
INFO - 2022-03-24 23:51:25 --> Loader Class Initialized
INFO - 2022-03-24 23:51:25 --> Helper loaded: url_helper
INFO - 2022-03-24 23:51:25 --> Helper loaded: form_helper
INFO - 2022-03-24 23:51:25 --> Helper loaded: common_helper
INFO - 2022-03-24 23:51:25 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:51:25 --> Controller Class Initialized
INFO - 2022-03-24 23:51:25 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:51:25 --> Encrypt Class Initialized
INFO - 2022-03-24 23:51:25 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:51:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:51:25 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:51:25 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:51:25 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:51:25 --> Upload Class Initialized
INFO - 2022-03-24 23:51:25 --> Final output sent to browser
DEBUG - 2022-03-24 23:51:25 --> Total execution time: 0.0164
ERROR - 2022-03-24 23:51:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:51:27 --> Config Class Initialized
INFO - 2022-03-24 23:51:27 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:51:27 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:51:27 --> Utf8 Class Initialized
INFO - 2022-03-24 23:51:27 --> URI Class Initialized
INFO - 2022-03-24 23:51:27 --> Router Class Initialized
INFO - 2022-03-24 23:51:27 --> Output Class Initialized
INFO - 2022-03-24 23:51:27 --> Security Class Initialized
DEBUG - 2022-03-24 23:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:51:27 --> Input Class Initialized
INFO - 2022-03-24 23:51:27 --> Language Class Initialized
INFO - 2022-03-24 23:51:27 --> Loader Class Initialized
INFO - 2022-03-24 23:51:27 --> Helper loaded: url_helper
INFO - 2022-03-24 23:51:27 --> Helper loaded: form_helper
INFO - 2022-03-24 23:51:27 --> Helper loaded: common_helper
INFO - 2022-03-24 23:51:27 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:51:27 --> Controller Class Initialized
INFO - 2022-03-24 23:51:27 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:51:27 --> Encrypt Class Initialized
INFO - 2022-03-24 23:51:27 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:51:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:51:27 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:51:27 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:51:27 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:51:27 --> Upload Class Initialized
INFO - 2022-03-24 23:51:27 --> Final output sent to browser
DEBUG - 2022-03-24 23:51:27 --> Total execution time: 0.0092
ERROR - 2022-03-24 23:51:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:51:50 --> Config Class Initialized
INFO - 2022-03-24 23:51:50 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:51:50 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:51:50 --> Utf8 Class Initialized
INFO - 2022-03-24 23:51:50 --> URI Class Initialized
INFO - 2022-03-24 23:51:50 --> Router Class Initialized
INFO - 2022-03-24 23:51:50 --> Output Class Initialized
INFO - 2022-03-24 23:51:50 --> Security Class Initialized
DEBUG - 2022-03-24 23:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:51:50 --> Input Class Initialized
INFO - 2022-03-24 23:51:50 --> Language Class Initialized
INFO - 2022-03-24 23:51:50 --> Loader Class Initialized
INFO - 2022-03-24 23:51:50 --> Helper loaded: url_helper
INFO - 2022-03-24 23:51:50 --> Helper loaded: form_helper
INFO - 2022-03-24 23:51:50 --> Helper loaded: common_helper
INFO - 2022-03-24 23:51:50 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:51:50 --> Controller Class Initialized
INFO - 2022-03-24 23:51:50 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:51:50 --> Encrypt Class Initialized
INFO - 2022-03-24 23:51:50 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:51:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:51:50 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:51:50 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:51:50 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 23:51:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:51:52 --> Config Class Initialized
INFO - 2022-03-24 23:51:52 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:51:52 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:51:52 --> Utf8 Class Initialized
INFO - 2022-03-24 23:51:52 --> URI Class Initialized
INFO - 2022-03-24 23:51:52 --> Router Class Initialized
INFO - 2022-03-24 23:51:52 --> Output Class Initialized
INFO - 2022-03-24 23:51:52 --> Security Class Initialized
DEBUG - 2022-03-24 23:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:51:52 --> Input Class Initialized
INFO - 2022-03-24 23:51:52 --> Language Class Initialized
INFO - 2022-03-24 23:51:52 --> Loader Class Initialized
INFO - 2022-03-24 23:51:52 --> Helper loaded: url_helper
INFO - 2022-03-24 23:51:52 --> Helper loaded: form_helper
INFO - 2022-03-24 23:51:52 --> Helper loaded: common_helper
INFO - 2022-03-24 23:51:52 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:51:52 --> Controller Class Initialized
INFO - 2022-03-24 23:51:52 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:51:52 --> Encrypt Class Initialized
INFO - 2022-03-24 23:51:52 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:51:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:51:52 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:51:52 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:51:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 23:51:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:51:52 --> Config Class Initialized
INFO - 2022-03-24 23:51:52 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:51:52 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:51:52 --> Utf8 Class Initialized
INFO - 2022-03-24 23:51:52 --> URI Class Initialized
INFO - 2022-03-24 23:51:52 --> Router Class Initialized
INFO - 2022-03-24 23:51:52 --> Output Class Initialized
INFO - 2022-03-24 23:51:52 --> Security Class Initialized
DEBUG - 2022-03-24 23:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:51:52 --> Input Class Initialized
INFO - 2022-03-24 23:51:52 --> Language Class Initialized
INFO - 2022-03-24 23:51:52 --> Loader Class Initialized
INFO - 2022-03-24 23:51:52 --> Helper loaded: url_helper
INFO - 2022-03-24 23:51:52 --> Helper loaded: form_helper
INFO - 2022-03-24 23:51:52 --> Helper loaded: common_helper
INFO - 2022-03-24 23:51:52 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:51:52 --> Controller Class Initialized
INFO - 2022-03-24 23:51:52 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:51:52 --> Encrypt Class Initialized
INFO - 2022-03-24 23:51:52 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:51:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:51:52 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:51:52 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:51:52 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:51:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:51:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 23:51:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:51:52 --> Final output sent to browser
DEBUG - 2022-03-24 23:51:52 --> Total execution time: 0.0273
ERROR - 2022-03-24 23:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:51:53 --> Config Class Initialized
INFO - 2022-03-24 23:51:53 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:51:53 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:51:53 --> Utf8 Class Initialized
INFO - 2022-03-24 23:51:53 --> URI Class Initialized
INFO - 2022-03-24 23:51:53 --> Router Class Initialized
INFO - 2022-03-24 23:51:53 --> Output Class Initialized
INFO - 2022-03-24 23:51:53 --> Security Class Initialized
DEBUG - 2022-03-24 23:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:51:53 --> Input Class Initialized
INFO - 2022-03-24 23:51:53 --> Language Class Initialized
INFO - 2022-03-24 23:51:53 --> Loader Class Initialized
INFO - 2022-03-24 23:51:53 --> Helper loaded: url_helper
INFO - 2022-03-24 23:51:53 --> Helper loaded: form_helper
INFO - 2022-03-24 23:51:53 --> Helper loaded: common_helper
INFO - 2022-03-24 23:51:53 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:51:53 --> Controller Class Initialized
INFO - 2022-03-24 23:51:53 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:51:53 --> Encrypt Class Initialized
INFO - 2022-03-24 23:51:53 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:51:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:51:53 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:51:53 --> Model "Users_model" initialized
INFO - 2022-03-24 23:51:53 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:51:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:51:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 23:51:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:51:53 --> Final output sent to browser
DEBUG - 2022-03-24 23:51:53 --> Total execution time: 0.0463
ERROR - 2022-03-24 23:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:51:57 --> Config Class Initialized
INFO - 2022-03-24 23:51:57 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:51:57 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:51:57 --> Utf8 Class Initialized
INFO - 2022-03-24 23:51:57 --> URI Class Initialized
INFO - 2022-03-24 23:51:57 --> Router Class Initialized
INFO - 2022-03-24 23:51:57 --> Output Class Initialized
INFO - 2022-03-24 23:51:57 --> Security Class Initialized
DEBUG - 2022-03-24 23:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:51:57 --> Input Class Initialized
INFO - 2022-03-24 23:51:57 --> Language Class Initialized
INFO - 2022-03-24 23:51:57 --> Loader Class Initialized
INFO - 2022-03-24 23:51:57 --> Helper loaded: url_helper
INFO - 2022-03-24 23:51:57 --> Helper loaded: form_helper
INFO - 2022-03-24 23:51:57 --> Helper loaded: common_helper
INFO - 2022-03-24 23:51:57 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:51:57 --> Controller Class Initialized
INFO - 2022-03-24 23:51:57 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:51:57 --> Encrypt Class Initialized
INFO - 2022-03-24 23:51:57 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:51:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:51:57 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:51:57 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:51:57 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:51:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:51:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-24 23:51:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:51:57 --> Final output sent to browser
DEBUG - 2022-03-24 23:51:57 --> Total execution time: 0.0564
ERROR - 2022-03-24 23:52:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:52:12 --> Config Class Initialized
INFO - 2022-03-24 23:52:12 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:52:12 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:52:12 --> Utf8 Class Initialized
INFO - 2022-03-24 23:52:12 --> URI Class Initialized
INFO - 2022-03-24 23:52:12 --> Router Class Initialized
INFO - 2022-03-24 23:52:12 --> Output Class Initialized
INFO - 2022-03-24 23:52:12 --> Security Class Initialized
DEBUG - 2022-03-24 23:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:52:12 --> Input Class Initialized
INFO - 2022-03-24 23:52:12 --> Language Class Initialized
INFO - 2022-03-24 23:52:12 --> Loader Class Initialized
INFO - 2022-03-24 23:52:12 --> Helper loaded: url_helper
INFO - 2022-03-24 23:52:12 --> Helper loaded: form_helper
INFO - 2022-03-24 23:52:12 --> Helper loaded: common_helper
INFO - 2022-03-24 23:52:12 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:52:12 --> Controller Class Initialized
INFO - 2022-03-24 23:52:12 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:52:12 --> Encrypt Class Initialized
INFO - 2022-03-24 23:52:12 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:52:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:52:12 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:52:12 --> Model "Users_model" initialized
INFO - 2022-03-24 23:52:12 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:52:12 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-24 23:52:13 --> Final output sent to browser
DEBUG - 2022-03-24 23:52:13 --> Total execution time: 1.2851
ERROR - 2022-03-24 23:57:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:57:08 --> Config Class Initialized
INFO - 2022-03-24 23:57:08 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:57:08 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:57:08 --> Utf8 Class Initialized
INFO - 2022-03-24 23:57:08 --> URI Class Initialized
INFO - 2022-03-24 23:57:08 --> Router Class Initialized
INFO - 2022-03-24 23:57:08 --> Output Class Initialized
INFO - 2022-03-24 23:57:08 --> Security Class Initialized
DEBUG - 2022-03-24 23:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:57:08 --> Input Class Initialized
INFO - 2022-03-24 23:57:08 --> Language Class Initialized
INFO - 2022-03-24 23:57:08 --> Loader Class Initialized
INFO - 2022-03-24 23:57:08 --> Helper loaded: url_helper
INFO - 2022-03-24 23:57:08 --> Helper loaded: form_helper
INFO - 2022-03-24 23:57:08 --> Helper loaded: common_helper
INFO - 2022-03-24 23:57:08 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:57:08 --> Controller Class Initialized
INFO - 2022-03-24 23:57:08 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:57:08 --> Encrypt Class Initialized
INFO - 2022-03-24 23:57:08 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:57:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:57:08 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:57:08 --> Model "Users_model" initialized
INFO - 2022-03-24 23:57:08 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:57:08 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-24 23:57:09 --> Final output sent to browser
DEBUG - 2022-03-24 23:57:09 --> Total execution time: 1.1341
ERROR - 2022-03-24 23:58:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:58:43 --> Config Class Initialized
INFO - 2022-03-24 23:58:43 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:58:43 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:58:43 --> Utf8 Class Initialized
INFO - 2022-03-24 23:58:43 --> URI Class Initialized
INFO - 2022-03-24 23:58:43 --> Router Class Initialized
INFO - 2022-03-24 23:58:43 --> Output Class Initialized
INFO - 2022-03-24 23:58:43 --> Security Class Initialized
DEBUG - 2022-03-24 23:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:58:43 --> Input Class Initialized
INFO - 2022-03-24 23:58:43 --> Language Class Initialized
INFO - 2022-03-24 23:58:43 --> Loader Class Initialized
INFO - 2022-03-24 23:58:43 --> Helper loaded: url_helper
INFO - 2022-03-24 23:58:43 --> Helper loaded: form_helper
INFO - 2022-03-24 23:58:43 --> Helper loaded: common_helper
INFO - 2022-03-24 23:58:43 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:58:43 --> Controller Class Initialized
INFO - 2022-03-24 23:58:43 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:58:43 --> Encrypt Class Initialized
INFO - 2022-03-24 23:58:43 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:58:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:58:43 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:58:43 --> Model "Users_model" initialized
INFO - 2022-03-24 23:58:43 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:58:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:58:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 23:58:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:58:43 --> Final output sent to browser
DEBUG - 2022-03-24 23:58:43 --> Total execution time: 0.0488
ERROR - 2022-03-24 23:58:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:58:45 --> Config Class Initialized
INFO - 2022-03-24 23:58:45 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:58:45 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:58:45 --> Utf8 Class Initialized
INFO - 2022-03-24 23:58:45 --> URI Class Initialized
INFO - 2022-03-24 23:58:45 --> Router Class Initialized
INFO - 2022-03-24 23:58:45 --> Output Class Initialized
INFO - 2022-03-24 23:58:45 --> Security Class Initialized
DEBUG - 2022-03-24 23:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:58:45 --> Input Class Initialized
INFO - 2022-03-24 23:58:45 --> Language Class Initialized
INFO - 2022-03-24 23:58:45 --> Loader Class Initialized
INFO - 2022-03-24 23:58:45 --> Helper loaded: url_helper
INFO - 2022-03-24 23:58:45 --> Helper loaded: form_helper
INFO - 2022-03-24 23:58:45 --> Helper loaded: common_helper
INFO - 2022-03-24 23:58:45 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:58:45 --> Controller Class Initialized
INFO - 2022-03-24 23:58:45 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:58:45 --> Encrypt Class Initialized
INFO - 2022-03-24 23:58:45 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:58:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:58:45 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:58:45 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:58:45 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:58:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:58:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 23:58:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:58:45 --> Final output sent to browser
DEBUG - 2022-03-24 23:58:45 --> Total execution time: 0.0433
ERROR - 2022-03-24 23:58:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:58:52 --> Config Class Initialized
INFO - 2022-03-24 23:58:52 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:58:52 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:58:52 --> Utf8 Class Initialized
INFO - 2022-03-24 23:58:52 --> URI Class Initialized
INFO - 2022-03-24 23:58:52 --> Router Class Initialized
INFO - 2022-03-24 23:58:52 --> Output Class Initialized
INFO - 2022-03-24 23:58:52 --> Security Class Initialized
DEBUG - 2022-03-24 23:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:58:52 --> Input Class Initialized
INFO - 2022-03-24 23:58:52 --> Language Class Initialized
INFO - 2022-03-24 23:58:52 --> Loader Class Initialized
INFO - 2022-03-24 23:58:52 --> Helper loaded: url_helper
INFO - 2022-03-24 23:58:52 --> Helper loaded: form_helper
INFO - 2022-03-24 23:58:52 --> Helper loaded: common_helper
INFO - 2022-03-24 23:58:52 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:58:52 --> Controller Class Initialized
INFO - 2022-03-24 23:58:52 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:58:52 --> Encrypt Class Initialized
INFO - 2022-03-24 23:58:52 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:58:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:58:52 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:58:52 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:58:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 23:58:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:58:52 --> Config Class Initialized
INFO - 2022-03-24 23:58:52 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:58:52 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:58:52 --> Utf8 Class Initialized
INFO - 2022-03-24 23:58:52 --> URI Class Initialized
INFO - 2022-03-24 23:58:52 --> Router Class Initialized
INFO - 2022-03-24 23:58:52 --> Output Class Initialized
INFO - 2022-03-24 23:58:52 --> Security Class Initialized
DEBUG - 2022-03-24 23:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:58:52 --> Input Class Initialized
INFO - 2022-03-24 23:58:52 --> Language Class Initialized
INFO - 2022-03-24 23:58:52 --> Loader Class Initialized
INFO - 2022-03-24 23:58:52 --> Helper loaded: url_helper
INFO - 2022-03-24 23:58:52 --> Helper loaded: form_helper
INFO - 2022-03-24 23:58:52 --> Helper loaded: common_helper
INFO - 2022-03-24 23:58:52 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:58:52 --> Controller Class Initialized
INFO - 2022-03-24 23:58:52 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:58:52 --> Encrypt Class Initialized
INFO - 2022-03-24 23:58:52 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:58:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:58:52 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:58:52 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:58:52 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:58:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:58:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 23:58:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:58:52 --> Final output sent to browser
DEBUG - 2022-03-24 23:58:52 --> Total execution time: 0.0375
ERROR - 2022-03-24 23:58:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:58:53 --> Config Class Initialized
INFO - 2022-03-24 23:58:53 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:58:53 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:58:53 --> Utf8 Class Initialized
INFO - 2022-03-24 23:58:53 --> URI Class Initialized
INFO - 2022-03-24 23:58:53 --> Router Class Initialized
INFO - 2022-03-24 23:58:53 --> Output Class Initialized
INFO - 2022-03-24 23:58:53 --> Security Class Initialized
DEBUG - 2022-03-24 23:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:58:53 --> Input Class Initialized
INFO - 2022-03-24 23:58:53 --> Language Class Initialized
INFO - 2022-03-24 23:58:53 --> Loader Class Initialized
INFO - 2022-03-24 23:58:53 --> Helper loaded: url_helper
INFO - 2022-03-24 23:58:53 --> Helper loaded: form_helper
INFO - 2022-03-24 23:58:53 --> Helper loaded: common_helper
INFO - 2022-03-24 23:58:53 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:58:53 --> Controller Class Initialized
INFO - 2022-03-24 23:58:53 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:58:53 --> Encrypt Class Initialized
INFO - 2022-03-24 23:58:53 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:58:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:58:53 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:58:53 --> Model "Users_model" initialized
INFO - 2022-03-24 23:58:53 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:58:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:58:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 23:58:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:58:53 --> Final output sent to browser
DEBUG - 2022-03-24 23:58:53 --> Total execution time: 0.0336
ERROR - 2022-03-24 23:59:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:59:09 --> Config Class Initialized
INFO - 2022-03-24 23:59:09 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:59:09 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:59:09 --> Utf8 Class Initialized
INFO - 2022-03-24 23:59:09 --> URI Class Initialized
DEBUG - 2022-03-24 23:59:09 --> No URI present. Default controller set.
INFO - 2022-03-24 23:59:09 --> Router Class Initialized
INFO - 2022-03-24 23:59:09 --> Output Class Initialized
INFO - 2022-03-24 23:59:09 --> Security Class Initialized
DEBUG - 2022-03-24 23:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:59:09 --> Input Class Initialized
INFO - 2022-03-24 23:59:09 --> Language Class Initialized
INFO - 2022-03-24 23:59:09 --> Loader Class Initialized
INFO - 2022-03-24 23:59:09 --> Helper loaded: url_helper
INFO - 2022-03-24 23:59:09 --> Helper loaded: form_helper
INFO - 2022-03-24 23:59:09 --> Helper loaded: common_helper
INFO - 2022-03-24 23:59:09 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:59:09 --> Controller Class Initialized
INFO - 2022-03-24 23:59:09 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:59:09 --> Encrypt Class Initialized
DEBUG - 2022-03-24 23:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 23:59:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 23:59:09 --> Email Class Initialized
INFO - 2022-03-24 23:59:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 23:59:09 --> Calendar Class Initialized
INFO - 2022-03-24 23:59:09 --> Model "Login_model" initialized
INFO - 2022-03-24 23:59:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-24 23:59:09 --> Final output sent to browser
DEBUG - 2022-03-24 23:59:09 --> Total execution time: 0.0227
ERROR - 2022-03-24 23:59:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:59:32 --> Config Class Initialized
INFO - 2022-03-24 23:59:32 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:59:32 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:59:32 --> Utf8 Class Initialized
INFO - 2022-03-24 23:59:32 --> URI Class Initialized
INFO - 2022-03-24 23:59:32 --> Router Class Initialized
INFO - 2022-03-24 23:59:32 --> Output Class Initialized
INFO - 2022-03-24 23:59:32 --> Security Class Initialized
DEBUG - 2022-03-24 23:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:59:32 --> Input Class Initialized
INFO - 2022-03-24 23:59:32 --> Language Class Initialized
INFO - 2022-03-24 23:59:32 --> Loader Class Initialized
INFO - 2022-03-24 23:59:32 --> Helper loaded: url_helper
INFO - 2022-03-24 23:59:32 --> Helper loaded: form_helper
INFO - 2022-03-24 23:59:32 --> Helper loaded: common_helper
INFO - 2022-03-24 23:59:32 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:59:32 --> Controller Class Initialized
INFO - 2022-03-24 23:59:32 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:59:32 --> Encrypt Class Initialized
DEBUG - 2022-03-24 23:59:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 23:59:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-24 23:59:32 --> Email Class Initialized
INFO - 2022-03-24 23:59:32 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-24 23:59:32 --> Calendar Class Initialized
INFO - 2022-03-24 23:59:32 --> Model "Login_model" initialized
INFO - 2022-03-24 23:59:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-24 23:59:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:59:32 --> Config Class Initialized
INFO - 2022-03-24 23:59:32 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:59:32 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:59:32 --> Utf8 Class Initialized
INFO - 2022-03-24 23:59:32 --> URI Class Initialized
INFO - 2022-03-24 23:59:32 --> Router Class Initialized
INFO - 2022-03-24 23:59:32 --> Output Class Initialized
INFO - 2022-03-24 23:59:32 --> Security Class Initialized
DEBUG - 2022-03-24 23:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:59:32 --> Input Class Initialized
INFO - 2022-03-24 23:59:32 --> Language Class Initialized
INFO - 2022-03-24 23:59:32 --> Loader Class Initialized
INFO - 2022-03-24 23:59:32 --> Helper loaded: url_helper
INFO - 2022-03-24 23:59:32 --> Helper loaded: form_helper
INFO - 2022-03-24 23:59:32 --> Helper loaded: common_helper
INFO - 2022-03-24 23:59:32 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:59:32 --> Controller Class Initialized
INFO - 2022-03-24 23:59:32 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:59:32 --> Encrypt Class Initialized
INFO - 2022-03-24 23:59:32 --> Model "Login_model" initialized
INFO - 2022-03-24 23:59:32 --> Model "Dashboard_model" initialized
INFO - 2022-03-24 23:59:32 --> Model "Case_model" initialized
ERROR - 2022-03-24 23:59:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:59:34 --> Config Class Initialized
INFO - 2022-03-24 23:59:34 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:59:34 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:59:34 --> Utf8 Class Initialized
INFO - 2022-03-24 23:59:34 --> URI Class Initialized
INFO - 2022-03-24 23:59:34 --> Router Class Initialized
INFO - 2022-03-24 23:59:34 --> Output Class Initialized
INFO - 2022-03-24 23:59:34 --> Security Class Initialized
DEBUG - 2022-03-24 23:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:59:34 --> Input Class Initialized
INFO - 2022-03-24 23:59:34 --> Language Class Initialized
INFO - 2022-03-24 23:59:34 --> Loader Class Initialized
INFO - 2022-03-24 23:59:34 --> Helper loaded: url_helper
INFO - 2022-03-24 23:59:34 --> Helper loaded: form_helper
INFO - 2022-03-24 23:59:34 --> Helper loaded: common_helper
INFO - 2022-03-24 23:59:34 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:59:34 --> Controller Class Initialized
INFO - 2022-03-24 23:59:34 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:59:34 --> Encrypt Class Initialized
INFO - 2022-03-24 23:59:34 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:59:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:59:34 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:59:34 --> Model "Users_model" initialized
INFO - 2022-03-24 23:59:34 --> Model "Hospital_model" initialized
ERROR - 2022-03-24 23:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:59:35 --> Config Class Initialized
INFO - 2022-03-24 23:59:35 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:59:35 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:59:35 --> Utf8 Class Initialized
INFO - 2022-03-24 23:59:35 --> URI Class Initialized
INFO - 2022-03-24 23:59:35 --> Router Class Initialized
INFO - 2022-03-24 23:59:35 --> Output Class Initialized
INFO - 2022-03-24 23:59:35 --> Security Class Initialized
DEBUG - 2022-03-24 23:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:59:35 --> Input Class Initialized
INFO - 2022-03-24 23:59:35 --> Language Class Initialized
INFO - 2022-03-24 23:59:35 --> Loader Class Initialized
INFO - 2022-03-24 23:59:35 --> Helper loaded: url_helper
INFO - 2022-03-24 23:59:35 --> Helper loaded: form_helper
INFO - 2022-03-24 23:59:35 --> Helper loaded: common_helper
INFO - 2022-03-24 23:59:35 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:59:35 --> Controller Class Initialized
INFO - 2022-03-24 23:59:35 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:59:35 --> Encrypt Class Initialized
INFO - 2022-03-24 23:59:35 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:59:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:59:35 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:59:35 --> Model "Users_model" initialized
INFO - 2022-03-24 23:59:35 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:59:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:59:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-24 23:59:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:59:35 --> Final output sent to browser
DEBUG - 2022-03-24 23:59:35 --> Total execution time: 0.0412
INFO - 2022-03-24 23:59:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-24 23:59:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:59:44 --> Config Class Initialized
INFO - 2022-03-24 23:59:44 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:59:44 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:59:44 --> Utf8 Class Initialized
INFO - 2022-03-24 23:59:44 --> URI Class Initialized
INFO - 2022-03-24 23:59:44 --> Router Class Initialized
INFO - 2022-03-24 23:59:44 --> Output Class Initialized
INFO - 2022-03-24 23:59:44 --> Security Class Initialized
DEBUG - 2022-03-24 23:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:59:44 --> Input Class Initialized
INFO - 2022-03-24 23:59:44 --> Language Class Initialized
INFO - 2022-03-24 23:59:44 --> Loader Class Initialized
INFO - 2022-03-24 23:59:44 --> Helper loaded: url_helper
INFO - 2022-03-24 23:59:44 --> Helper loaded: form_helper
INFO - 2022-03-24 23:59:44 --> Helper loaded: common_helper
INFO - 2022-03-24 23:59:44 --> Database Driver Class Initialized
DEBUG - 2022-03-24 23:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-24 23:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-24 23:59:44 --> Controller Class Initialized
INFO - 2022-03-24 23:59:44 --> Form Validation Class Initialized
DEBUG - 2022-03-24 23:59:44 --> Encrypt Class Initialized
INFO - 2022-03-24 23:59:44 --> Model "Patient_model" initialized
INFO - 2022-03-24 23:59:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-24 23:59:44 --> Model "Referredby_model" initialized
INFO - 2022-03-24 23:59:44 --> Model "Prefix_master" initialized
INFO - 2022-03-24 23:59:44 --> Model "Hospital_model" initialized
INFO - 2022-03-24 23:59:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-24 23:59:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-24 23:59:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:59:44 --> Final output sent to browser
DEBUG - 2022-03-24 23:59:44 --> Total execution time: 0.0398
INFO - 2022-03-24 23:59:52 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-24 23:59:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-24 23:59:52 --> Final output sent to browser
DEBUG - 2022-03-24 23:59:52 --> Total execution time: 19.5123
ERROR - 2022-03-24 23:59:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-24 23:59:53 --> Config Class Initialized
INFO - 2022-03-24 23:59:53 --> Hooks Class Initialized
DEBUG - 2022-03-24 23:59:53 --> UTF-8 Support Enabled
INFO - 2022-03-24 23:59:53 --> Utf8 Class Initialized
INFO - 2022-03-24 23:59:53 --> URI Class Initialized
INFO - 2022-03-24 23:59:53 --> Router Class Initialized
INFO - 2022-03-24 23:59:53 --> Output Class Initialized
INFO - 2022-03-24 23:59:53 --> Security Class Initialized
DEBUG - 2022-03-24 23:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-24 23:59:53 --> Input Class Initialized
INFO - 2022-03-24 23:59:53 --> Language Class Initialized
ERROR - 2022-03-24 23:59:53 --> 404 Page Not Found: Karoclient/usersprofile
