<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-14 04:54:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 04:54:22 --> Config Class Initialized
INFO - 2022-02-14 04:54:22 --> Hooks Class Initialized
DEBUG - 2022-02-14 04:54:22 --> UTF-8 Support Enabled
INFO - 2022-02-14 04:54:22 --> Utf8 Class Initialized
INFO - 2022-02-14 04:54:22 --> URI Class Initialized
INFO - 2022-02-14 04:54:22 --> Router Class Initialized
INFO - 2022-02-14 04:54:22 --> Output Class Initialized
INFO - 2022-02-14 04:54:22 --> Security Class Initialized
DEBUG - 2022-02-14 04:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 04:54:22 --> Input Class Initialized
INFO - 2022-02-14 04:54:22 --> Language Class Initialized
ERROR - 2022-02-14 04:54:22 --> 404 Page Not Found: Infophp/index
ERROR - 2022-02-14 04:54:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 04:54:24 --> Config Class Initialized
INFO - 2022-02-14 04:54:24 --> Hooks Class Initialized
DEBUG - 2022-02-14 04:54:24 --> UTF-8 Support Enabled
INFO - 2022-02-14 04:54:24 --> Utf8 Class Initialized
INFO - 2022-02-14 04:54:24 --> URI Class Initialized
INFO - 2022-02-14 04:54:24 --> Router Class Initialized
INFO - 2022-02-14 04:54:24 --> Output Class Initialized
INFO - 2022-02-14 04:54:24 --> Security Class Initialized
DEBUG - 2022-02-14 04:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 04:54:24 --> Input Class Initialized
INFO - 2022-02-14 04:54:24 --> Language Class Initialized
ERROR - 2022-02-14 04:54:24 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2022-02-14 04:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 04:54:27 --> Config Class Initialized
INFO - 2022-02-14 04:54:27 --> Hooks Class Initialized
DEBUG - 2022-02-14 04:54:27 --> UTF-8 Support Enabled
INFO - 2022-02-14 04:54:27 --> Utf8 Class Initialized
INFO - 2022-02-14 04:54:27 --> URI Class Initialized
INFO - 2022-02-14 04:54:27 --> Router Class Initialized
INFO - 2022-02-14 04:54:27 --> Output Class Initialized
INFO - 2022-02-14 04:54:27 --> Security Class Initialized
DEBUG - 2022-02-14 04:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 04:54:27 --> Input Class Initialized
INFO - 2022-02-14 04:54:27 --> Language Class Initialized
ERROR - 2022-02-14 04:54:27 --> 404 Page Not Found: Info/index
ERROR - 2022-02-14 14:18:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 14:18:34 --> Config Class Initialized
INFO - 2022-02-14 14:18:34 --> Hooks Class Initialized
DEBUG - 2022-02-14 14:18:34 --> UTF-8 Support Enabled
INFO - 2022-02-14 14:18:34 --> Utf8 Class Initialized
INFO - 2022-02-14 14:18:34 --> URI Class Initialized
DEBUG - 2022-02-14 14:18:34 --> No URI present. Default controller set.
INFO - 2022-02-14 14:18:34 --> Router Class Initialized
INFO - 2022-02-14 14:18:34 --> Output Class Initialized
INFO - 2022-02-14 14:18:34 --> Security Class Initialized
DEBUG - 2022-02-14 14:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 14:18:34 --> Input Class Initialized
INFO - 2022-02-14 14:18:34 --> Language Class Initialized
INFO - 2022-02-14 14:18:34 --> Loader Class Initialized
INFO - 2022-02-14 14:18:34 --> Helper loaded: url_helper
INFO - 2022-02-14 14:18:34 --> Helper loaded: form_helper
INFO - 2022-02-14 14:18:34 --> Helper loaded: common_helper
INFO - 2022-02-14 14:18:34 --> Database Driver Class Initialized
DEBUG - 2022-02-14 14:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-14 14:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-14 14:18:34 --> Controller Class Initialized
INFO - 2022-02-14 14:18:34 --> Form Validation Class Initialized
DEBUG - 2022-02-14 14:18:34 --> Encrypt Class Initialized
DEBUG - 2022-02-14 14:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:18:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-14 14:18:34 --> Email Class Initialized
INFO - 2022-02-14 14:18:34 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-14 14:18:34 --> Calendar Class Initialized
INFO - 2022-02-14 14:18:34 --> Model "Login_model" initialized
INFO - 2022-02-14 14:18:34 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-14 14:18:34 --> Final output sent to browser
DEBUG - 2022-02-14 14:18:34 --> Total execution time: 0.0395
ERROR - 2022-02-14 14:18:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 14:18:36 --> Config Class Initialized
INFO - 2022-02-14 14:18:36 --> Hooks Class Initialized
DEBUG - 2022-02-14 14:18:36 --> UTF-8 Support Enabled
INFO - 2022-02-14 14:18:36 --> Utf8 Class Initialized
INFO - 2022-02-14 14:18:36 --> URI Class Initialized
INFO - 2022-02-14 14:18:36 --> Router Class Initialized
INFO - 2022-02-14 14:18:36 --> Output Class Initialized
INFO - 2022-02-14 14:18:36 --> Security Class Initialized
DEBUG - 2022-02-14 14:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 14:18:36 --> Input Class Initialized
INFO - 2022-02-14 14:18:36 --> Language Class Initialized
ERROR - 2022-02-14 14:18:36 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-02-14 14:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 14:19:36 --> Config Class Initialized
INFO - 2022-02-14 14:19:36 --> Hooks Class Initialized
DEBUG - 2022-02-14 14:19:36 --> UTF-8 Support Enabled
INFO - 2022-02-14 14:19:36 --> Utf8 Class Initialized
INFO - 2022-02-14 14:19:36 --> URI Class Initialized
INFO - 2022-02-14 14:19:36 --> Router Class Initialized
INFO - 2022-02-14 14:19:36 --> Output Class Initialized
INFO - 2022-02-14 14:19:36 --> Security Class Initialized
DEBUG - 2022-02-14 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 14:19:36 --> Input Class Initialized
INFO - 2022-02-14 14:19:36 --> Language Class Initialized
INFO - 2022-02-14 14:19:36 --> Loader Class Initialized
INFO - 2022-02-14 14:19:36 --> Helper loaded: url_helper
INFO - 2022-02-14 14:19:36 --> Helper loaded: form_helper
INFO - 2022-02-14 14:19:36 --> Helper loaded: common_helper
INFO - 2022-02-14 14:19:36 --> Database Driver Class Initialized
DEBUG - 2022-02-14 14:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-14 14:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-14 14:19:36 --> Controller Class Initialized
INFO - 2022-02-14 14:19:36 --> Form Validation Class Initialized
DEBUG - 2022-02-14 14:19:36 --> Encrypt Class Initialized
DEBUG - 2022-02-14 14:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-14 14:19:36 --> Email Class Initialized
INFO - 2022-02-14 14:19:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-14 14:19:36 --> Calendar Class Initialized
INFO - 2022-02-14 14:19:36 --> Model "Login_model" initialized
ERROR - 2022-02-14 14:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 14:19:36 --> Config Class Initialized
INFO - 2022-02-14 14:19:36 --> Hooks Class Initialized
DEBUG - 2022-02-14 14:19:36 --> UTF-8 Support Enabled
INFO - 2022-02-14 14:19:36 --> Utf8 Class Initialized
INFO - 2022-02-14 14:19:36 --> URI Class Initialized
INFO - 2022-02-14 14:19:36 --> Router Class Initialized
INFO - 2022-02-14 14:19:36 --> Output Class Initialized
INFO - 2022-02-14 14:19:36 --> Security Class Initialized
DEBUG - 2022-02-14 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 14:19:36 --> Input Class Initialized
INFO - 2022-02-14 14:19:36 --> Language Class Initialized
INFO - 2022-02-14 14:19:36 --> Loader Class Initialized
INFO - 2022-02-14 14:19:36 --> Helper loaded: url_helper
INFO - 2022-02-14 14:19:36 --> Helper loaded: form_helper
INFO - 2022-02-14 14:19:36 --> Helper loaded: common_helper
INFO - 2022-02-14 14:19:37 --> Database Driver Class Initialized
DEBUG - 2022-02-14 14:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-14 14:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-14 14:19:37 --> Controller Class Initialized
INFO - 2022-02-14 14:19:37 --> Form Validation Class Initialized
DEBUG - 2022-02-14 14:19:37 --> Encrypt Class Initialized
DEBUG - 2022-02-14 14:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-14 14:19:37 --> Email Class Initialized
INFO - 2022-02-14 14:19:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-14 14:19:37 --> Calendar Class Initialized
INFO - 2022-02-14 14:19:37 --> Model "Login_model" initialized
ERROR - 2022-02-14 14:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 14:19:38 --> Config Class Initialized
INFO - 2022-02-14 14:19:38 --> Hooks Class Initialized
DEBUG - 2022-02-14 14:19:38 --> UTF-8 Support Enabled
INFO - 2022-02-14 14:19:38 --> Utf8 Class Initialized
INFO - 2022-02-14 14:19:38 --> URI Class Initialized
DEBUG - 2022-02-14 14:19:38 --> No URI present. Default controller set.
INFO - 2022-02-14 14:19:38 --> Router Class Initialized
INFO - 2022-02-14 14:19:38 --> Output Class Initialized
INFO - 2022-02-14 14:19:38 --> Security Class Initialized
DEBUG - 2022-02-14 14:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 14:19:38 --> Input Class Initialized
INFO - 2022-02-14 14:19:38 --> Language Class Initialized
INFO - 2022-02-14 14:19:38 --> Loader Class Initialized
INFO - 2022-02-14 14:19:38 --> Helper loaded: url_helper
INFO - 2022-02-14 14:19:38 --> Helper loaded: form_helper
INFO - 2022-02-14 14:19:38 --> Helper loaded: common_helper
INFO - 2022-02-14 14:19:38 --> Database Driver Class Initialized
DEBUG - 2022-02-14 14:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-14 14:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-14 14:19:38 --> Controller Class Initialized
INFO - 2022-02-14 14:19:38 --> Form Validation Class Initialized
DEBUG - 2022-02-14 14:19:38 --> Encrypt Class Initialized
DEBUG - 2022-02-14 14:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-14 14:19:38 --> Email Class Initialized
INFO - 2022-02-14 14:19:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-14 14:19:38 --> Calendar Class Initialized
INFO - 2022-02-14 14:19:38 --> Model "Login_model" initialized
INFO - 2022-02-14 14:19:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-14 14:19:38 --> Final output sent to browser
DEBUG - 2022-02-14 14:19:38 --> Total execution time: 0.1575
ERROR - 2022-02-14 14:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 14:19:39 --> Config Class Initialized
INFO - 2022-02-14 14:19:39 --> Hooks Class Initialized
DEBUG - 2022-02-14 14:19:39 --> UTF-8 Support Enabled
INFO - 2022-02-14 14:19:39 --> Utf8 Class Initialized
INFO - 2022-02-14 14:19:39 --> URI Class Initialized
INFO - 2022-02-14 14:19:39 --> Router Class Initialized
INFO - 2022-02-14 14:19:39 --> Output Class Initialized
INFO - 2022-02-14 14:19:39 --> Security Class Initialized
DEBUG - 2022-02-14 14:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 14:19:39 --> Input Class Initialized
INFO - 2022-02-14 14:19:39 --> Language Class Initialized
INFO - 2022-02-14 14:19:39 --> Loader Class Initialized
INFO - 2022-02-14 14:19:39 --> Helper loaded: url_helper
INFO - 2022-02-14 14:19:39 --> Helper loaded: form_helper
INFO - 2022-02-14 14:19:39 --> Helper loaded: common_helper
INFO - 2022-02-14 14:19:39 --> Database Driver Class Initialized
DEBUG - 2022-02-14 14:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-14 14:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-14 14:19:39 --> Controller Class Initialized
INFO - 2022-02-14 14:19:39 --> Form Validation Class Initialized
DEBUG - 2022-02-14 14:19:39 --> Encrypt Class Initialized
DEBUG - 2022-02-14 14:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:19:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-14 14:19:39 --> Email Class Initialized
INFO - 2022-02-14 14:19:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-14 14:19:39 --> Calendar Class Initialized
INFO - 2022-02-14 14:19:39 --> Model "Login_model" initialized
INFO - 2022-02-14 14:19:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-14 14:19:39 --> Final output sent to browser
DEBUG - 2022-02-14 14:19:39 --> Total execution time: 0.0653
ERROR - 2022-02-14 15:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 15:09:20 --> Config Class Initialized
INFO - 2022-02-14 15:09:20 --> Hooks Class Initialized
DEBUG - 2022-02-14 15:09:20 --> UTF-8 Support Enabled
INFO - 2022-02-14 15:09:20 --> Utf8 Class Initialized
INFO - 2022-02-14 15:09:20 --> URI Class Initialized
DEBUG - 2022-02-14 15:09:20 --> No URI present. Default controller set.
INFO - 2022-02-14 15:09:20 --> Router Class Initialized
INFO - 2022-02-14 15:09:20 --> Output Class Initialized
INFO - 2022-02-14 15:09:20 --> Security Class Initialized
DEBUG - 2022-02-14 15:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 15:09:20 --> Input Class Initialized
INFO - 2022-02-14 15:09:20 --> Language Class Initialized
INFO - 2022-02-14 15:09:20 --> Loader Class Initialized
INFO - 2022-02-14 15:09:20 --> Helper loaded: url_helper
INFO - 2022-02-14 15:09:20 --> Helper loaded: form_helper
INFO - 2022-02-14 15:09:20 --> Helper loaded: common_helper
INFO - 2022-02-14 15:09:20 --> Database Driver Class Initialized
DEBUG - 2022-02-14 15:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-14 15:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-14 15:09:20 --> Controller Class Initialized
INFO - 2022-02-14 15:09:20 --> Form Validation Class Initialized
DEBUG - 2022-02-14 15:09:20 --> Encrypt Class Initialized
DEBUG - 2022-02-14 15:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:09:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-14 15:09:20 --> Email Class Initialized
INFO - 2022-02-14 15:09:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-14 15:09:20 --> Calendar Class Initialized
INFO - 2022-02-14 15:09:20 --> Model "Login_model" initialized
INFO - 2022-02-14 15:09:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-14 15:09:20 --> Final output sent to browser
DEBUG - 2022-02-14 15:09:20 --> Total execution time: 0.0268
ERROR - 2022-02-14 15:59:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-02-14 15:59:19 --> Config Class Initialized
INFO - 2022-02-14 15:59:19 --> Hooks Class Initialized
DEBUG - 2022-02-14 15:59:19 --> UTF-8 Support Enabled
INFO - 2022-02-14 15:59:19 --> Utf8 Class Initialized
INFO - 2022-02-14 15:59:19 --> URI Class Initialized
DEBUG - 2022-02-14 15:59:19 --> No URI present. Default controller set.
INFO - 2022-02-14 15:59:19 --> Router Class Initialized
INFO - 2022-02-14 15:59:19 --> Output Class Initialized
INFO - 2022-02-14 15:59:19 --> Security Class Initialized
DEBUG - 2022-02-14 15:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-02-14 15:59:19 --> Input Class Initialized
INFO - 2022-02-14 15:59:19 --> Language Class Initialized
INFO - 2022-02-14 15:59:19 --> Loader Class Initialized
INFO - 2022-02-14 15:59:19 --> Helper loaded: url_helper
INFO - 2022-02-14 15:59:19 --> Helper loaded: form_helper
INFO - 2022-02-14 15:59:19 --> Helper loaded: common_helper
INFO - 2022-02-14 15:59:19 --> Database Driver Class Initialized
DEBUG - 2022-02-14 15:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-02-14 15:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-02-14 15:59:19 --> Controller Class Initialized
INFO - 2022-02-14 15:59:19 --> Form Validation Class Initialized
DEBUG - 2022-02-14 15:59:19 --> Encrypt Class Initialized
DEBUG - 2022-02-14 15:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:59:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-02-14 15:59:19 --> Email Class Initialized
INFO - 2022-02-14 15:59:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-02-14 15:59:19 --> Calendar Class Initialized
INFO - 2022-02-14 15:59:19 --> Model "Login_model" initialized
INFO - 2022-02-14 15:59:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-02-14 15:59:19 --> Final output sent to browser
DEBUG - 2022-02-14 15:59:19 --> Total execution time: 0.0254
