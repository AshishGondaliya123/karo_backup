<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-02 02:00:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 02:00:28 --> Config Class Initialized
INFO - 2022-03-02 02:00:28 --> Hooks Class Initialized
DEBUG - 2022-03-02 02:00:28 --> UTF-8 Support Enabled
INFO - 2022-03-02 02:00:28 --> Utf8 Class Initialized
INFO - 2022-03-02 02:00:28 --> URI Class Initialized
DEBUG - 2022-03-02 02:00:28 --> No URI present. Default controller set.
INFO - 2022-03-02 02:00:28 --> Router Class Initialized
INFO - 2022-03-02 02:00:28 --> Output Class Initialized
INFO - 2022-03-02 02:00:28 --> Security Class Initialized
DEBUG - 2022-03-02 02:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 02:00:28 --> Input Class Initialized
INFO - 2022-03-02 02:00:28 --> Language Class Initialized
INFO - 2022-03-02 02:00:28 --> Loader Class Initialized
INFO - 2022-03-02 02:00:28 --> Helper loaded: url_helper
INFO - 2022-03-02 02:00:28 --> Helper loaded: form_helper
INFO - 2022-03-02 02:00:28 --> Helper loaded: common_helper
INFO - 2022-03-02 02:00:28 --> Database Driver Class Initialized
DEBUG - 2022-03-02 02:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 02:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 02:00:28 --> Controller Class Initialized
INFO - 2022-03-02 02:00:28 --> Form Validation Class Initialized
DEBUG - 2022-03-02 02:00:28 --> Encrypt Class Initialized
DEBUG - 2022-03-02 02:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 02:00:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 02:00:28 --> Email Class Initialized
INFO - 2022-03-02 02:00:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 02:00:28 --> Calendar Class Initialized
INFO - 2022-03-02 02:00:28 --> Model "Login_model" initialized
INFO - 2022-03-02 02:00:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 02:00:28 --> Final output sent to browser
DEBUG - 2022-03-02 02:00:28 --> Total execution time: 0.0420
ERROR - 2022-03-02 02:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 02:05:19 --> Config Class Initialized
INFO - 2022-03-02 02:05:19 --> Hooks Class Initialized
DEBUG - 2022-03-02 02:05:19 --> UTF-8 Support Enabled
INFO - 2022-03-02 02:05:19 --> Utf8 Class Initialized
INFO - 2022-03-02 02:05:19 --> URI Class Initialized
DEBUG - 2022-03-02 02:05:19 --> No URI present. Default controller set.
INFO - 2022-03-02 02:05:19 --> Router Class Initialized
INFO - 2022-03-02 02:05:19 --> Output Class Initialized
INFO - 2022-03-02 02:05:19 --> Security Class Initialized
DEBUG - 2022-03-02 02:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 02:05:19 --> Input Class Initialized
INFO - 2022-03-02 02:05:19 --> Language Class Initialized
INFO - 2022-03-02 02:05:19 --> Loader Class Initialized
INFO - 2022-03-02 02:05:19 --> Helper loaded: url_helper
INFO - 2022-03-02 02:05:19 --> Helper loaded: form_helper
INFO - 2022-03-02 02:05:19 --> Helper loaded: common_helper
INFO - 2022-03-02 02:05:19 --> Database Driver Class Initialized
DEBUG - 2022-03-02 02:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 02:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 02:05:19 --> Controller Class Initialized
INFO - 2022-03-02 02:05:19 --> Form Validation Class Initialized
DEBUG - 2022-03-02 02:05:19 --> Encrypt Class Initialized
DEBUG - 2022-03-02 02:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 02:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 02:05:19 --> Email Class Initialized
INFO - 2022-03-02 02:05:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 02:05:19 --> Calendar Class Initialized
INFO - 2022-03-02 02:05:19 --> Model "Login_model" initialized
INFO - 2022-03-02 02:05:19 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 02:05:19 --> Final output sent to browser
DEBUG - 2022-03-02 02:05:19 --> Total execution time: 0.0283
ERROR - 2022-03-02 03:52:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 03:52:13 --> Config Class Initialized
INFO - 2022-03-02 03:52:13 --> Hooks Class Initialized
DEBUG - 2022-03-02 03:52:13 --> UTF-8 Support Enabled
INFO - 2022-03-02 03:52:13 --> Utf8 Class Initialized
INFO - 2022-03-02 03:52:13 --> URI Class Initialized
DEBUG - 2022-03-02 03:52:13 --> No URI present. Default controller set.
INFO - 2022-03-02 03:52:13 --> Router Class Initialized
INFO - 2022-03-02 03:52:13 --> Output Class Initialized
INFO - 2022-03-02 03:52:13 --> Security Class Initialized
DEBUG - 2022-03-02 03:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 03:52:13 --> Input Class Initialized
INFO - 2022-03-02 03:52:13 --> Language Class Initialized
INFO - 2022-03-02 03:52:13 --> Loader Class Initialized
INFO - 2022-03-02 03:52:13 --> Helper loaded: url_helper
INFO - 2022-03-02 03:52:13 --> Helper loaded: form_helper
INFO - 2022-03-02 03:52:13 --> Helper loaded: common_helper
INFO - 2022-03-02 03:52:13 --> Database Driver Class Initialized
DEBUG - 2022-03-02 03:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 03:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 03:52:13 --> Controller Class Initialized
INFO - 2022-03-02 03:52:13 --> Form Validation Class Initialized
DEBUG - 2022-03-02 03:52:13 --> Encrypt Class Initialized
DEBUG - 2022-03-02 03:52:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 03:52:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 03:52:13 --> Email Class Initialized
INFO - 2022-03-02 03:52:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 03:52:13 --> Calendar Class Initialized
INFO - 2022-03-02 03:52:13 --> Model "Login_model" initialized
INFO - 2022-03-02 03:52:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 03:52:13 --> Final output sent to browser
DEBUG - 2022-03-02 03:52:13 --> Total execution time: 0.0315
ERROR - 2022-03-02 12:36:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 12:36:39 --> Config Class Initialized
INFO - 2022-03-02 12:36:39 --> Hooks Class Initialized
DEBUG - 2022-03-02 12:36:39 --> UTF-8 Support Enabled
INFO - 2022-03-02 12:36:39 --> Utf8 Class Initialized
INFO - 2022-03-02 12:36:39 --> URI Class Initialized
DEBUG - 2022-03-02 12:36:39 --> No URI present. Default controller set.
INFO - 2022-03-02 12:36:39 --> Router Class Initialized
INFO - 2022-03-02 12:36:39 --> Output Class Initialized
INFO - 2022-03-02 12:36:39 --> Security Class Initialized
DEBUG - 2022-03-02 12:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 12:36:39 --> Input Class Initialized
INFO - 2022-03-02 12:36:39 --> Language Class Initialized
INFO - 2022-03-02 12:36:39 --> Loader Class Initialized
INFO - 2022-03-02 12:36:39 --> Helper loaded: url_helper
INFO - 2022-03-02 12:36:39 --> Helper loaded: form_helper
INFO - 2022-03-02 12:36:39 --> Helper loaded: common_helper
INFO - 2022-03-02 12:36:39 --> Database Driver Class Initialized
DEBUG - 2022-03-02 12:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 12:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 12:36:39 --> Controller Class Initialized
INFO - 2022-03-02 12:36:39 --> Form Validation Class Initialized
DEBUG - 2022-03-02 12:36:39 --> Encrypt Class Initialized
DEBUG - 2022-03-02 12:36:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:36:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 12:36:39 --> Email Class Initialized
INFO - 2022-03-02 12:36:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 12:36:39 --> Calendar Class Initialized
INFO - 2022-03-02 12:36:39 --> Model "Login_model" initialized
INFO - 2022-03-02 12:36:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 12:36:39 --> Final output sent to browser
DEBUG - 2022-03-02 12:36:39 --> Total execution time: 0.0360
ERROR - 2022-03-02 14:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 14:19:16 --> Config Class Initialized
INFO - 2022-03-02 14:19:16 --> Hooks Class Initialized
DEBUG - 2022-03-02 14:19:16 --> UTF-8 Support Enabled
INFO - 2022-03-02 14:19:16 --> Utf8 Class Initialized
INFO - 2022-03-02 14:19:16 --> URI Class Initialized
DEBUG - 2022-03-02 14:19:16 --> No URI present. Default controller set.
INFO - 2022-03-02 14:19:16 --> Router Class Initialized
INFO - 2022-03-02 14:19:16 --> Output Class Initialized
INFO - 2022-03-02 14:19:16 --> Security Class Initialized
DEBUG - 2022-03-02 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 14:19:16 --> Input Class Initialized
INFO - 2022-03-02 14:19:16 --> Language Class Initialized
INFO - 2022-03-02 14:19:16 --> Loader Class Initialized
INFO - 2022-03-02 14:19:16 --> Helper loaded: url_helper
INFO - 2022-03-02 14:19:16 --> Helper loaded: form_helper
INFO - 2022-03-02 14:19:16 --> Helper loaded: common_helper
INFO - 2022-03-02 14:19:16 --> Database Driver Class Initialized
DEBUG - 2022-03-02 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 14:19:16 --> Controller Class Initialized
INFO - 2022-03-02 14:19:16 --> Form Validation Class Initialized
DEBUG - 2022-03-02 14:19:16 --> Encrypt Class Initialized
DEBUG - 2022-03-02 14:19:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:19:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 14:19:16 --> Email Class Initialized
INFO - 2022-03-02 14:19:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 14:19:16 --> Calendar Class Initialized
INFO - 2022-03-02 14:19:16 --> Model "Login_model" initialized
INFO - 2022-03-02 14:19:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 14:19:16 --> Final output sent to browser
DEBUG - 2022-03-02 14:19:16 --> Total execution time: 0.1269
ERROR - 2022-03-02 14:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 14:19:17 --> Config Class Initialized
INFO - 2022-03-02 14:19:17 --> Hooks Class Initialized
DEBUG - 2022-03-02 14:19:17 --> UTF-8 Support Enabled
INFO - 2022-03-02 14:19:17 --> Utf8 Class Initialized
INFO - 2022-03-02 14:19:17 --> URI Class Initialized
INFO - 2022-03-02 14:19:17 --> Router Class Initialized
INFO - 2022-03-02 14:19:17 --> Output Class Initialized
INFO - 2022-03-02 14:19:17 --> Security Class Initialized
DEBUG - 2022-03-02 14:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 14:19:17 --> Input Class Initialized
INFO - 2022-03-02 14:19:17 --> Language Class Initialized
ERROR - 2022-03-02 14:19:17 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-02 14:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 14:19:39 --> Config Class Initialized
INFO - 2022-03-02 14:19:39 --> Hooks Class Initialized
DEBUG - 2022-03-02 14:19:39 --> UTF-8 Support Enabled
INFO - 2022-03-02 14:19:39 --> Utf8 Class Initialized
INFO - 2022-03-02 14:19:39 --> URI Class Initialized
INFO - 2022-03-02 14:19:39 --> Router Class Initialized
INFO - 2022-03-02 14:19:39 --> Output Class Initialized
INFO - 2022-03-02 14:19:39 --> Security Class Initialized
DEBUG - 2022-03-02 14:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 14:19:39 --> Input Class Initialized
INFO - 2022-03-02 14:19:39 --> Language Class Initialized
INFO - 2022-03-02 14:19:39 --> Loader Class Initialized
INFO - 2022-03-02 14:19:39 --> Helper loaded: url_helper
INFO - 2022-03-02 14:19:39 --> Helper loaded: form_helper
INFO - 2022-03-02 14:19:39 --> Helper loaded: common_helper
INFO - 2022-03-02 14:19:39 --> Database Driver Class Initialized
DEBUG - 2022-03-02 14:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 14:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 14:19:39 --> Controller Class Initialized
INFO - 2022-03-02 14:19:39 --> Form Validation Class Initialized
DEBUG - 2022-03-02 14:19:39 --> Encrypt Class Initialized
DEBUG - 2022-03-02 14:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:19:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 14:19:39 --> Email Class Initialized
INFO - 2022-03-02 14:19:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 14:19:39 --> Calendar Class Initialized
INFO - 2022-03-02 14:19:39 --> Model "Login_model" initialized
INFO - 2022-03-02 14:19:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 14:19:39 --> Final output sent to browser
DEBUG - 2022-03-02 14:19:39 --> Total execution time: 0.0345
ERROR - 2022-03-02 14:19:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 14:19:40 --> Config Class Initialized
INFO - 2022-03-02 14:19:40 --> Hooks Class Initialized
DEBUG - 2022-03-02 14:19:40 --> UTF-8 Support Enabled
INFO - 2022-03-02 14:19:40 --> Utf8 Class Initialized
INFO - 2022-03-02 14:19:40 --> URI Class Initialized
DEBUG - 2022-03-02 14:19:40 --> No URI present. Default controller set.
INFO - 2022-03-02 14:19:40 --> Router Class Initialized
INFO - 2022-03-02 14:19:40 --> Output Class Initialized
INFO - 2022-03-02 14:19:40 --> Security Class Initialized
DEBUG - 2022-03-02 14:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 14:19:40 --> Input Class Initialized
INFO - 2022-03-02 14:19:40 --> Language Class Initialized
INFO - 2022-03-02 14:19:40 --> Loader Class Initialized
INFO - 2022-03-02 14:19:40 --> Helper loaded: url_helper
INFO - 2022-03-02 14:19:40 --> Helper loaded: form_helper
INFO - 2022-03-02 14:19:40 --> Helper loaded: common_helper
INFO - 2022-03-02 14:19:40 --> Database Driver Class Initialized
DEBUG - 2022-03-02 14:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 14:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 14:19:40 --> Controller Class Initialized
INFO - 2022-03-02 14:19:40 --> Form Validation Class Initialized
DEBUG - 2022-03-02 14:19:40 --> Encrypt Class Initialized
DEBUG - 2022-03-02 14:19:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:19:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 14:19:40 --> Email Class Initialized
INFO - 2022-03-02 14:19:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 14:19:40 --> Calendar Class Initialized
INFO - 2022-03-02 14:19:40 --> Model "Login_model" initialized
INFO - 2022-03-02 14:19:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 14:19:40 --> Final output sent to browser
DEBUG - 2022-03-02 14:19:40 --> Total execution time: 0.0644
ERROR - 2022-03-02 14:19:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 14:19:41 --> Config Class Initialized
INFO - 2022-03-02 14:19:41 --> Hooks Class Initialized
DEBUG - 2022-03-02 14:19:41 --> UTF-8 Support Enabled
INFO - 2022-03-02 14:19:41 --> Utf8 Class Initialized
INFO - 2022-03-02 14:19:41 --> URI Class Initialized
INFO - 2022-03-02 14:19:41 --> Router Class Initialized
INFO - 2022-03-02 14:19:41 --> Output Class Initialized
INFO - 2022-03-02 14:19:41 --> Security Class Initialized
DEBUG - 2022-03-02 14:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 14:19:41 --> Input Class Initialized
INFO - 2022-03-02 14:19:41 --> Language Class Initialized
INFO - 2022-03-02 14:19:41 --> Loader Class Initialized
INFO - 2022-03-02 14:19:41 --> Helper loaded: url_helper
INFO - 2022-03-02 14:19:41 --> Helper loaded: form_helper
INFO - 2022-03-02 14:19:41 --> Helper loaded: common_helper
INFO - 2022-03-02 14:19:41 --> Database Driver Class Initialized
DEBUG - 2022-03-02 14:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 14:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 14:19:41 --> Controller Class Initialized
INFO - 2022-03-02 14:19:41 --> Form Validation Class Initialized
DEBUG - 2022-03-02 14:19:41 --> Encrypt Class Initialized
DEBUG - 2022-03-02 14:19:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:19:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 14:19:41 --> Email Class Initialized
INFO - 2022-03-02 14:19:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 14:19:41 --> Calendar Class Initialized
INFO - 2022-03-02 14:19:41 --> Model "Login_model" initialized
ERROR - 2022-03-02 14:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 14:19:42 --> Config Class Initialized
INFO - 2022-03-02 14:19:42 --> Hooks Class Initialized
DEBUG - 2022-03-02 14:19:42 --> UTF-8 Support Enabled
INFO - 2022-03-02 14:19:42 --> Utf8 Class Initialized
INFO - 2022-03-02 14:19:42 --> URI Class Initialized
INFO - 2022-03-02 14:19:42 --> Router Class Initialized
INFO - 2022-03-02 14:19:42 --> Output Class Initialized
INFO - 2022-03-02 14:19:42 --> Security Class Initialized
DEBUG - 2022-03-02 14:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 14:19:42 --> Input Class Initialized
INFO - 2022-03-02 14:19:42 --> Language Class Initialized
INFO - 2022-03-02 14:19:42 --> Loader Class Initialized
INFO - 2022-03-02 14:19:42 --> Helper loaded: url_helper
INFO - 2022-03-02 14:19:42 --> Helper loaded: form_helper
INFO - 2022-03-02 14:19:42 --> Helper loaded: common_helper
INFO - 2022-03-02 14:19:42 --> Database Driver Class Initialized
DEBUG - 2022-03-02 14:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 14:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 14:19:42 --> Controller Class Initialized
INFO - 2022-03-02 14:19:42 --> Form Validation Class Initialized
DEBUG - 2022-03-02 14:19:42 --> Encrypt Class Initialized
DEBUG - 2022-03-02 14:19:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:19:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 14:19:42 --> Email Class Initialized
INFO - 2022-03-02 14:19:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 14:19:42 --> Calendar Class Initialized
INFO - 2022-03-02 14:19:42 --> Model "Login_model" initialized
ERROR - 2022-03-02 15:08:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 15:08:45 --> Config Class Initialized
INFO - 2022-03-02 15:08:45 --> Hooks Class Initialized
DEBUG - 2022-03-02 15:08:45 --> UTF-8 Support Enabled
INFO - 2022-03-02 15:08:45 --> Utf8 Class Initialized
INFO - 2022-03-02 15:08:45 --> URI Class Initialized
DEBUG - 2022-03-02 15:08:45 --> No URI present. Default controller set.
INFO - 2022-03-02 15:08:45 --> Router Class Initialized
INFO - 2022-03-02 15:08:45 --> Output Class Initialized
INFO - 2022-03-02 15:08:45 --> Security Class Initialized
DEBUG - 2022-03-02 15:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 15:08:45 --> Input Class Initialized
INFO - 2022-03-02 15:08:45 --> Language Class Initialized
INFO - 2022-03-02 15:08:45 --> Loader Class Initialized
INFO - 2022-03-02 15:08:45 --> Helper loaded: url_helper
INFO - 2022-03-02 15:08:45 --> Helper loaded: form_helper
INFO - 2022-03-02 15:08:45 --> Helper loaded: common_helper
INFO - 2022-03-02 15:08:45 --> Database Driver Class Initialized
DEBUG - 2022-03-02 15:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 15:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 15:08:45 --> Controller Class Initialized
INFO - 2022-03-02 15:08:45 --> Form Validation Class Initialized
DEBUG - 2022-03-02 15:08:45 --> Encrypt Class Initialized
DEBUG - 2022-03-02 15:08:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:08:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 15:08:45 --> Email Class Initialized
INFO - 2022-03-02 15:08:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 15:08:45 --> Calendar Class Initialized
INFO - 2022-03-02 15:08:45 --> Model "Login_model" initialized
INFO - 2022-03-02 15:08:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 15:08:45 --> Final output sent to browser
DEBUG - 2022-03-02 15:08:45 --> Total execution time: 0.0310
ERROR - 2022-03-02 15:22:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 15:22:52 --> Config Class Initialized
INFO - 2022-03-02 15:22:52 --> Hooks Class Initialized
DEBUG - 2022-03-02 15:22:52 --> UTF-8 Support Enabled
INFO - 2022-03-02 15:22:52 --> Utf8 Class Initialized
INFO - 2022-03-02 15:22:52 --> URI Class Initialized
DEBUG - 2022-03-02 15:22:52 --> No URI present. Default controller set.
INFO - 2022-03-02 15:22:52 --> Router Class Initialized
INFO - 2022-03-02 15:22:52 --> Output Class Initialized
INFO - 2022-03-02 15:22:52 --> Security Class Initialized
DEBUG - 2022-03-02 15:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 15:22:52 --> Input Class Initialized
INFO - 2022-03-02 15:22:52 --> Language Class Initialized
INFO - 2022-03-02 15:22:52 --> Loader Class Initialized
INFO - 2022-03-02 15:22:52 --> Helper loaded: url_helper
INFO - 2022-03-02 15:22:52 --> Helper loaded: form_helper
INFO - 2022-03-02 15:22:52 --> Helper loaded: common_helper
INFO - 2022-03-02 15:22:52 --> Database Driver Class Initialized
DEBUG - 2022-03-02 15:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 15:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 15:22:52 --> Controller Class Initialized
INFO - 2022-03-02 15:22:52 --> Form Validation Class Initialized
DEBUG - 2022-03-02 15:22:52 --> Encrypt Class Initialized
DEBUG - 2022-03-02 15:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:22:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 15:22:52 --> Email Class Initialized
INFO - 2022-03-02 15:22:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 15:22:52 --> Calendar Class Initialized
INFO - 2022-03-02 15:22:52 --> Model "Login_model" initialized
INFO - 2022-03-02 15:22:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 15:22:52 --> Final output sent to browser
DEBUG - 2022-03-02 15:22:52 --> Total execution time: 0.0234
ERROR - 2022-03-02 16:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 16:04:45 --> Config Class Initialized
INFO - 2022-03-02 16:04:45 --> Hooks Class Initialized
DEBUG - 2022-03-02 16:04:45 --> UTF-8 Support Enabled
INFO - 2022-03-02 16:04:45 --> Utf8 Class Initialized
INFO - 2022-03-02 16:04:45 --> URI Class Initialized
DEBUG - 2022-03-02 16:04:45 --> No URI present. Default controller set.
INFO - 2022-03-02 16:04:45 --> Router Class Initialized
INFO - 2022-03-02 16:04:45 --> Output Class Initialized
INFO - 2022-03-02 16:04:45 --> Security Class Initialized
DEBUG - 2022-03-02 16:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 16:04:45 --> Input Class Initialized
INFO - 2022-03-02 16:04:45 --> Language Class Initialized
INFO - 2022-03-02 16:04:45 --> Loader Class Initialized
INFO - 2022-03-02 16:04:45 --> Helper loaded: url_helper
INFO - 2022-03-02 16:04:45 --> Helper loaded: form_helper
INFO - 2022-03-02 16:04:45 --> Helper loaded: common_helper
INFO - 2022-03-02 16:04:45 --> Database Driver Class Initialized
DEBUG - 2022-03-02 16:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 16:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 16:04:45 --> Controller Class Initialized
INFO - 2022-03-02 16:04:45 --> Form Validation Class Initialized
DEBUG - 2022-03-02 16:04:45 --> Encrypt Class Initialized
DEBUG - 2022-03-02 16:04:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 16:04:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 16:04:45 --> Email Class Initialized
INFO - 2022-03-02 16:04:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 16:04:45 --> Calendar Class Initialized
INFO - 2022-03-02 16:04:45 --> Model "Login_model" initialized
INFO - 2022-03-02 16:04:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 16:04:45 --> Final output sent to browser
DEBUG - 2022-03-02 16:04:45 --> Total execution time: 0.0343
ERROR - 2022-03-02 19:58:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-02 19:58:04 --> Config Class Initialized
INFO - 2022-03-02 19:58:04 --> Hooks Class Initialized
DEBUG - 2022-03-02 19:58:04 --> UTF-8 Support Enabled
INFO - 2022-03-02 19:58:04 --> Utf8 Class Initialized
INFO - 2022-03-02 19:58:04 --> URI Class Initialized
DEBUG - 2022-03-02 19:58:04 --> No URI present. Default controller set.
INFO - 2022-03-02 19:58:04 --> Router Class Initialized
INFO - 2022-03-02 19:58:04 --> Output Class Initialized
INFO - 2022-03-02 19:58:04 --> Security Class Initialized
DEBUG - 2022-03-02 19:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-02 19:58:04 --> Input Class Initialized
INFO - 2022-03-02 19:58:04 --> Language Class Initialized
INFO - 2022-03-02 19:58:04 --> Loader Class Initialized
INFO - 2022-03-02 19:58:04 --> Helper loaded: url_helper
INFO - 2022-03-02 19:58:04 --> Helper loaded: form_helper
INFO - 2022-03-02 19:58:04 --> Helper loaded: common_helper
INFO - 2022-03-02 19:58:04 --> Database Driver Class Initialized
DEBUG - 2022-03-02 19:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-02 19:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-02 19:58:04 --> Controller Class Initialized
INFO - 2022-03-02 19:58:04 --> Form Validation Class Initialized
DEBUG - 2022-03-02 19:58:04 --> Encrypt Class Initialized
DEBUG - 2022-03-02 19:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 19:58:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-02 19:58:04 --> Email Class Initialized
INFO - 2022-03-02 19:58:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-02 19:58:04 --> Calendar Class Initialized
INFO - 2022-03-02 19:58:04 --> Model "Login_model" initialized
INFO - 2022-03-02 19:58:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-02 19:58:04 --> Final output sent to browser
DEBUG - 2022-03-02 19:58:04 --> Total execution time: 0.0356
