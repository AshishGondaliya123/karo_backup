<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-31 00:14:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:14:41 --> Config Class Initialized
INFO - 2022-03-31 00:14:41 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:14:41 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:14:41 --> Utf8 Class Initialized
INFO - 2022-03-31 00:14:41 --> URI Class Initialized
INFO - 2022-03-31 00:14:41 --> Router Class Initialized
INFO - 2022-03-31 00:14:41 --> Output Class Initialized
INFO - 2022-03-31 00:14:41 --> Security Class Initialized
DEBUG - 2022-03-31 00:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:14:41 --> Input Class Initialized
INFO - 2022-03-31 00:14:41 --> Language Class Initialized
INFO - 2022-03-31 00:14:41 --> Loader Class Initialized
INFO - 2022-03-31 00:14:41 --> Helper loaded: url_helper
INFO - 2022-03-31 00:14:41 --> Helper loaded: form_helper
INFO - 2022-03-31 00:14:41 --> Helper loaded: common_helper
INFO - 2022-03-31 00:14:41 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:14:41 --> Controller Class Initialized
INFO - 2022-03-31 00:14:41 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:14:41 --> Encrypt Class Initialized
INFO - 2022-03-31 00:14:41 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:14:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:14:41 --> Model "Referredby_model" initialized
INFO - 2022-03-31 00:14:41 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:14:41 --> Model "Hospital_model" initialized
INFO - 2022-03-31 00:14:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 00:14:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 00:14:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 00:14:41 --> Final output sent to browser
DEBUG - 2022-03-31 00:14:41 --> Total execution time: 0.0989
ERROR - 2022-03-31 00:14:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:14:48 --> Config Class Initialized
INFO - 2022-03-31 00:14:48 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:14:48 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:14:48 --> Utf8 Class Initialized
INFO - 2022-03-31 00:14:48 --> URI Class Initialized
DEBUG - 2022-03-31 00:14:48 --> No URI present. Default controller set.
INFO - 2022-03-31 00:14:48 --> Router Class Initialized
INFO - 2022-03-31 00:14:48 --> Output Class Initialized
INFO - 2022-03-31 00:14:48 --> Security Class Initialized
DEBUG - 2022-03-31 00:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:14:48 --> Input Class Initialized
INFO - 2022-03-31 00:14:48 --> Language Class Initialized
INFO - 2022-03-31 00:14:48 --> Loader Class Initialized
INFO - 2022-03-31 00:14:48 --> Helper loaded: url_helper
INFO - 2022-03-31 00:14:48 --> Helper loaded: form_helper
INFO - 2022-03-31 00:14:48 --> Helper loaded: common_helper
INFO - 2022-03-31 00:14:48 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:14:48 --> Controller Class Initialized
INFO - 2022-03-31 00:14:48 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:14:48 --> Encrypt Class Initialized
DEBUG - 2022-03-31 00:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 00:14:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 00:14:48 --> Email Class Initialized
INFO - 2022-03-31 00:14:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 00:14:48 --> Calendar Class Initialized
INFO - 2022-03-31 00:14:48 --> Model "Login_model" initialized
ERROR - 2022-03-31 00:14:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:14:49 --> Config Class Initialized
INFO - 2022-03-31 00:14:49 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:14:49 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:14:49 --> Utf8 Class Initialized
INFO - 2022-03-31 00:14:49 --> URI Class Initialized
INFO - 2022-03-31 00:14:49 --> Router Class Initialized
INFO - 2022-03-31 00:14:49 --> Output Class Initialized
INFO - 2022-03-31 00:14:49 --> Security Class Initialized
DEBUG - 2022-03-31 00:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:14:49 --> Input Class Initialized
INFO - 2022-03-31 00:14:49 --> Language Class Initialized
INFO - 2022-03-31 00:14:49 --> Loader Class Initialized
INFO - 2022-03-31 00:14:49 --> Helper loaded: url_helper
INFO - 2022-03-31 00:14:49 --> Helper loaded: form_helper
INFO - 2022-03-31 00:14:49 --> Helper loaded: common_helper
INFO - 2022-03-31 00:14:49 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:14:49 --> Controller Class Initialized
INFO - 2022-03-31 00:14:49 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:14:49 --> Encrypt Class Initialized
INFO - 2022-03-31 00:14:49 --> Model "Diseases_model" initialized
INFO - 2022-03-31 00:14:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 00:14:49 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-31 00:14:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 00:14:49 --> Final output sent to browser
DEBUG - 2022-03-31 00:14:49 --> Total execution time: 0.1584
ERROR - 2022-03-31 00:14:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:14:50 --> Config Class Initialized
INFO - 2022-03-31 00:14:50 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:14:50 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:14:50 --> Utf8 Class Initialized
INFO - 2022-03-31 00:14:50 --> URI Class Initialized
DEBUG - 2022-03-31 00:14:50 --> No URI present. Default controller set.
INFO - 2022-03-31 00:14:50 --> Router Class Initialized
INFO - 2022-03-31 00:14:50 --> Output Class Initialized
INFO - 2022-03-31 00:14:50 --> Security Class Initialized
DEBUG - 2022-03-31 00:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:14:50 --> Input Class Initialized
INFO - 2022-03-31 00:14:50 --> Language Class Initialized
INFO - 2022-03-31 00:14:50 --> Loader Class Initialized
INFO - 2022-03-31 00:14:50 --> Helper loaded: url_helper
INFO - 2022-03-31 00:14:50 --> Helper loaded: form_helper
INFO - 2022-03-31 00:14:50 --> Helper loaded: common_helper
INFO - 2022-03-31 00:14:50 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:14:50 --> Controller Class Initialized
INFO - 2022-03-31 00:14:50 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:14:50 --> Encrypt Class Initialized
DEBUG - 2022-03-31 00:14:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 00:14:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 00:14:50 --> Email Class Initialized
INFO - 2022-03-31 00:14:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 00:14:50 --> Calendar Class Initialized
INFO - 2022-03-31 00:14:50 --> Model "Login_model" initialized
ERROR - 2022-03-31 00:14:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:14:50 --> Config Class Initialized
INFO - 2022-03-31 00:14:50 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:14:50 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:14:50 --> Utf8 Class Initialized
INFO - 2022-03-31 00:14:50 --> URI Class Initialized
INFO - 2022-03-31 00:14:50 --> Router Class Initialized
INFO - 2022-03-31 00:14:50 --> Output Class Initialized
INFO - 2022-03-31 00:14:50 --> Security Class Initialized
DEBUG - 2022-03-31 00:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:14:50 --> Input Class Initialized
INFO - 2022-03-31 00:14:50 --> Language Class Initialized
INFO - 2022-03-31 00:14:50 --> Loader Class Initialized
INFO - 2022-03-31 00:14:50 --> Helper loaded: url_helper
INFO - 2022-03-31 00:14:50 --> Helper loaded: form_helper
INFO - 2022-03-31 00:14:50 --> Helper loaded: common_helper
INFO - 2022-03-31 00:14:50 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:14:50 --> Controller Class Initialized
INFO - 2022-03-31 00:14:50 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:14:50 --> Encrypt Class Initialized
INFO - 2022-03-31 00:14:50 --> Model "Diseases_model" initialized
INFO - 2022-03-31 00:14:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 00:14:50 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-31 00:14:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 00:14:50 --> Final output sent to browser
DEBUG - 2022-03-31 00:14:50 --> Total execution time: 0.0057
ERROR - 2022-03-31 00:14:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:14:58 --> Config Class Initialized
INFO - 2022-03-31 00:14:58 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:14:58 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:14:58 --> Utf8 Class Initialized
INFO - 2022-03-31 00:14:58 --> URI Class Initialized
INFO - 2022-03-31 00:14:58 --> Router Class Initialized
INFO - 2022-03-31 00:14:58 --> Output Class Initialized
INFO - 2022-03-31 00:14:58 --> Security Class Initialized
DEBUG - 2022-03-31 00:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:14:58 --> Input Class Initialized
INFO - 2022-03-31 00:14:58 --> Language Class Initialized
INFO - 2022-03-31 00:14:58 --> Loader Class Initialized
INFO - 2022-03-31 00:14:58 --> Helper loaded: url_helper
INFO - 2022-03-31 00:14:58 --> Helper loaded: form_helper
INFO - 2022-03-31 00:14:58 --> Helper loaded: common_helper
INFO - 2022-03-31 00:14:58 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:14:58 --> Controller Class Initialized
INFO - 2022-03-31 00:14:58 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:14:58 --> Encrypt Class Initialized
INFO - 2022-03-31 00:14:58 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:14:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:14:58 --> Model "Referredby_model" initialized
INFO - 2022-03-31 00:14:58 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:14:58 --> Model "Hospital_model" initialized
INFO - 2022-03-31 00:14:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 00:14:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 00:14:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 00:14:58 --> Final output sent to browser
DEBUG - 2022-03-31 00:14:58 --> Total execution time: 0.0087
ERROR - 2022-03-31 00:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:19:37 --> Config Class Initialized
INFO - 2022-03-31 00:19:37 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:19:37 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:19:37 --> Utf8 Class Initialized
INFO - 2022-03-31 00:19:37 --> URI Class Initialized
INFO - 2022-03-31 00:19:37 --> Router Class Initialized
INFO - 2022-03-31 00:19:37 --> Output Class Initialized
INFO - 2022-03-31 00:19:37 --> Security Class Initialized
DEBUG - 2022-03-31 00:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:19:37 --> Input Class Initialized
INFO - 2022-03-31 00:19:37 --> Language Class Initialized
INFO - 2022-03-31 00:19:37 --> Loader Class Initialized
INFO - 2022-03-31 00:19:37 --> Helper loaded: url_helper
INFO - 2022-03-31 00:19:37 --> Helper loaded: form_helper
INFO - 2022-03-31 00:19:37 --> Helper loaded: common_helper
INFO - 2022-03-31 00:19:37 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:19:37 --> Controller Class Initialized
INFO - 2022-03-31 00:19:37 --> Model "Referredby_model" initialized
INFO - 2022-03-31 00:19:37 --> Final output sent to browser
DEBUG - 2022-03-31 00:19:37 --> Total execution time: 0.0602
ERROR - 2022-03-31 00:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:19:50 --> Config Class Initialized
INFO - 2022-03-31 00:19:50 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:19:50 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:19:50 --> Utf8 Class Initialized
INFO - 2022-03-31 00:19:50 --> URI Class Initialized
INFO - 2022-03-31 00:19:50 --> Router Class Initialized
INFO - 2022-03-31 00:19:50 --> Output Class Initialized
INFO - 2022-03-31 00:19:50 --> Security Class Initialized
DEBUG - 2022-03-31 00:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:19:50 --> Input Class Initialized
INFO - 2022-03-31 00:19:50 --> Language Class Initialized
INFO - 2022-03-31 00:19:50 --> Loader Class Initialized
INFO - 2022-03-31 00:19:50 --> Helper loaded: url_helper
INFO - 2022-03-31 00:19:50 --> Helper loaded: form_helper
INFO - 2022-03-31 00:19:50 --> Helper loaded: common_helper
INFO - 2022-03-31 00:19:50 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:19:50 --> Controller Class Initialized
INFO - 2022-03-31 00:19:50 --> Model "Referredby_model" initialized
INFO - 2022-03-31 00:19:50 --> Final output sent to browser
DEBUG - 2022-03-31 00:19:50 --> Total execution time: 0.0482
ERROR - 2022-03-31 00:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:27:42 --> Config Class Initialized
INFO - 2022-03-31 00:27:42 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:27:42 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:27:42 --> Utf8 Class Initialized
INFO - 2022-03-31 00:27:42 --> URI Class Initialized
INFO - 2022-03-31 00:27:42 --> Router Class Initialized
INFO - 2022-03-31 00:27:42 --> Output Class Initialized
INFO - 2022-03-31 00:27:42 --> Security Class Initialized
DEBUG - 2022-03-31 00:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:27:42 --> Input Class Initialized
INFO - 2022-03-31 00:27:42 --> Language Class Initialized
INFO - 2022-03-31 00:27:42 --> Loader Class Initialized
INFO - 2022-03-31 00:27:42 --> Helper loaded: url_helper
INFO - 2022-03-31 00:27:42 --> Helper loaded: form_helper
INFO - 2022-03-31 00:27:42 --> Helper loaded: common_helper
INFO - 2022-03-31 00:27:42 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:27:42 --> Controller Class Initialized
INFO - 2022-03-31 00:27:42 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:27:42 --> Encrypt Class Initialized
INFO - 2022-03-31 00:27:42 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:27:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:27:42 --> Model "Referredby_model" initialized
INFO - 2022-03-31 00:27:42 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:27:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 00:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:27:42 --> Config Class Initialized
INFO - 2022-03-31 00:27:42 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:27:42 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:27:42 --> Utf8 Class Initialized
INFO - 2022-03-31 00:27:42 --> URI Class Initialized
INFO - 2022-03-31 00:27:42 --> Router Class Initialized
INFO - 2022-03-31 00:27:42 --> Output Class Initialized
INFO - 2022-03-31 00:27:42 --> Security Class Initialized
DEBUG - 2022-03-31 00:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:27:42 --> Input Class Initialized
INFO - 2022-03-31 00:27:42 --> Language Class Initialized
INFO - 2022-03-31 00:27:42 --> Loader Class Initialized
INFO - 2022-03-31 00:27:42 --> Helper loaded: url_helper
INFO - 2022-03-31 00:27:42 --> Helper loaded: form_helper
INFO - 2022-03-31 00:27:42 --> Helper loaded: common_helper
INFO - 2022-03-31 00:27:42 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:27:42 --> Controller Class Initialized
INFO - 2022-03-31 00:27:42 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:27:42 --> Encrypt Class Initialized
INFO - 2022-03-31 00:27:42 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:27:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:27:42 --> Model "Referredby_model" initialized
INFO - 2022-03-31 00:27:42 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:27:42 --> Model "Hospital_model" initialized
INFO - 2022-03-31 00:27:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 00:27:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 00:27:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 00:27:42 --> Final output sent to browser
DEBUG - 2022-03-31 00:27:42 --> Total execution time: 0.1060
ERROR - 2022-03-31 00:27:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:27:43 --> Config Class Initialized
INFO - 2022-03-31 00:27:43 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:27:43 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:27:43 --> Utf8 Class Initialized
INFO - 2022-03-31 00:27:43 --> URI Class Initialized
INFO - 2022-03-31 00:27:43 --> Router Class Initialized
INFO - 2022-03-31 00:27:43 --> Output Class Initialized
INFO - 2022-03-31 00:27:43 --> Security Class Initialized
DEBUG - 2022-03-31 00:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:27:43 --> Input Class Initialized
INFO - 2022-03-31 00:27:43 --> Language Class Initialized
INFO - 2022-03-31 00:27:43 --> Loader Class Initialized
INFO - 2022-03-31 00:27:43 --> Helper loaded: url_helper
INFO - 2022-03-31 00:27:43 --> Helper loaded: form_helper
INFO - 2022-03-31 00:27:43 --> Helper loaded: common_helper
INFO - 2022-03-31 00:27:43 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:27:43 --> Controller Class Initialized
INFO - 2022-03-31 00:27:43 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:27:43 --> Encrypt Class Initialized
INFO - 2022-03-31 00:27:43 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:27:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:27:43 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:27:43 --> Model "Users_model" initialized
INFO - 2022-03-31 00:27:43 --> Model "Hospital_model" initialized
INFO - 2022-03-31 00:27:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 00:27:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 00:27:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 00:27:43 --> Final output sent to browser
DEBUG - 2022-03-31 00:27:43 --> Total execution time: 0.1940
ERROR - 2022-03-31 00:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:35:52 --> Config Class Initialized
INFO - 2022-03-31 00:35:52 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:35:52 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:35:52 --> Utf8 Class Initialized
INFO - 2022-03-31 00:35:52 --> URI Class Initialized
INFO - 2022-03-31 00:35:52 --> Router Class Initialized
INFO - 2022-03-31 00:35:52 --> Output Class Initialized
INFO - 2022-03-31 00:35:52 --> Security Class Initialized
DEBUG - 2022-03-31 00:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:35:52 --> Input Class Initialized
INFO - 2022-03-31 00:35:52 --> Language Class Initialized
INFO - 2022-03-31 00:35:52 --> Loader Class Initialized
INFO - 2022-03-31 00:35:52 --> Helper loaded: url_helper
INFO - 2022-03-31 00:35:52 --> Helper loaded: form_helper
INFO - 2022-03-31 00:35:52 --> Helper loaded: common_helper
INFO - 2022-03-31 00:35:52 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:35:52 --> Controller Class Initialized
INFO - 2022-03-31 00:35:52 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:35:52 --> Encrypt Class Initialized
INFO - 2022-03-31 00:35:52 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:35:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:35:52 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:35:52 --> Model "Users_model" initialized
INFO - 2022-03-31 00:35:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 00:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:35:52 --> Config Class Initialized
INFO - 2022-03-31 00:35:52 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:35:52 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:35:52 --> Utf8 Class Initialized
INFO - 2022-03-31 00:35:52 --> URI Class Initialized
INFO - 2022-03-31 00:35:52 --> Router Class Initialized
INFO - 2022-03-31 00:35:52 --> Output Class Initialized
INFO - 2022-03-31 00:35:52 --> Security Class Initialized
DEBUG - 2022-03-31 00:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:35:52 --> Input Class Initialized
INFO - 2022-03-31 00:35:52 --> Language Class Initialized
INFO - 2022-03-31 00:35:52 --> Loader Class Initialized
INFO - 2022-03-31 00:35:52 --> Helper loaded: url_helper
INFO - 2022-03-31 00:35:52 --> Helper loaded: form_helper
INFO - 2022-03-31 00:35:52 --> Helper loaded: common_helper
INFO - 2022-03-31 00:35:52 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:35:52 --> Controller Class Initialized
INFO - 2022-03-31 00:35:52 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:35:52 --> Encrypt Class Initialized
INFO - 2022-03-31 00:35:52 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:35:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:35:52 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:35:52 --> Model "Users_model" initialized
INFO - 2022-03-31 00:35:52 --> Model "Hospital_model" initialized
INFO - 2022-03-31 00:35:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 00:35:53 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 00:35:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 00:35:53 --> Final output sent to browser
DEBUG - 2022-03-31 00:35:53 --> Total execution time: 0.0550
ERROR - 2022-03-31 00:44:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:44:12 --> Config Class Initialized
INFO - 2022-03-31 00:44:12 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:44:12 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:44:12 --> Utf8 Class Initialized
INFO - 2022-03-31 00:44:12 --> URI Class Initialized
INFO - 2022-03-31 00:44:12 --> Router Class Initialized
INFO - 2022-03-31 00:44:12 --> Output Class Initialized
INFO - 2022-03-31 00:44:12 --> Security Class Initialized
DEBUG - 2022-03-31 00:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:44:12 --> Input Class Initialized
INFO - 2022-03-31 00:44:12 --> Language Class Initialized
INFO - 2022-03-31 00:44:12 --> Loader Class Initialized
INFO - 2022-03-31 00:44:12 --> Helper loaded: url_helper
INFO - 2022-03-31 00:44:12 --> Helper loaded: form_helper
INFO - 2022-03-31 00:44:12 --> Helper loaded: common_helper
INFO - 2022-03-31 00:44:12 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:44:12 --> Controller Class Initialized
INFO - 2022-03-31 00:44:12 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:44:12 --> Encrypt Class Initialized
INFO - 2022-03-31 00:44:12 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:44:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:44:12 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:44:12 --> Model "Users_model" initialized
INFO - 2022-03-31 00:44:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 00:44:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:44:13 --> Config Class Initialized
INFO - 2022-03-31 00:44:13 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:44:13 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:44:13 --> Utf8 Class Initialized
INFO - 2022-03-31 00:44:13 --> URI Class Initialized
INFO - 2022-03-31 00:44:13 --> Router Class Initialized
INFO - 2022-03-31 00:44:13 --> Output Class Initialized
INFO - 2022-03-31 00:44:13 --> Security Class Initialized
DEBUG - 2022-03-31 00:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:44:13 --> Input Class Initialized
INFO - 2022-03-31 00:44:13 --> Language Class Initialized
INFO - 2022-03-31 00:44:13 --> Loader Class Initialized
INFO - 2022-03-31 00:44:13 --> Helper loaded: url_helper
INFO - 2022-03-31 00:44:13 --> Helper loaded: form_helper
INFO - 2022-03-31 00:44:13 --> Helper loaded: common_helper
INFO - 2022-03-31 00:44:13 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:44:13 --> Controller Class Initialized
INFO - 2022-03-31 00:44:13 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:44:13 --> Encrypt Class Initialized
INFO - 2022-03-31 00:44:13 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:44:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:44:13 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:44:13 --> Model "Users_model" initialized
INFO - 2022-03-31 00:44:13 --> Model "Hospital_model" initialized
INFO - 2022-03-31 00:44:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 00:44:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 00:44:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 00:44:13 --> Final output sent to browser
DEBUG - 2022-03-31 00:44:13 --> Total execution time: 0.0457
ERROR - 2022-03-31 00:56:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 00:56:21 --> Config Class Initialized
INFO - 2022-03-31 00:56:21 --> Hooks Class Initialized
DEBUG - 2022-03-31 00:56:21 --> UTF-8 Support Enabled
INFO - 2022-03-31 00:56:21 --> Utf8 Class Initialized
INFO - 2022-03-31 00:56:21 --> URI Class Initialized
INFO - 2022-03-31 00:56:21 --> Router Class Initialized
INFO - 2022-03-31 00:56:22 --> Output Class Initialized
INFO - 2022-03-31 00:56:22 --> Security Class Initialized
DEBUG - 2022-03-31 00:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 00:56:22 --> Input Class Initialized
INFO - 2022-03-31 00:56:22 --> Language Class Initialized
INFO - 2022-03-31 00:56:22 --> Loader Class Initialized
INFO - 2022-03-31 00:56:22 --> Helper loaded: url_helper
INFO - 2022-03-31 00:56:22 --> Helper loaded: form_helper
INFO - 2022-03-31 00:56:22 --> Helper loaded: common_helper
INFO - 2022-03-31 00:56:22 --> Database Driver Class Initialized
DEBUG - 2022-03-31 00:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 00:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 00:56:22 --> Controller Class Initialized
INFO - 2022-03-31 00:56:22 --> Form Validation Class Initialized
DEBUG - 2022-03-31 00:56:22 --> Encrypt Class Initialized
INFO - 2022-03-31 00:56:22 --> Model "Patient_model" initialized
INFO - 2022-03-31 00:56:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 00:56:22 --> Model "Prefix_master" initialized
INFO - 2022-03-31 00:56:22 --> Model "Users_model" initialized
INFO - 2022-03-31 00:56:22 --> Model "Hospital_model" initialized
INFO - 2022-03-31 00:56:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 00:56:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 00:56:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 00:56:22 --> Final output sent to browser
DEBUG - 2022-03-31 00:56:22 --> Total execution time: 0.0931
ERROR - 2022-03-31 01:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 01:58:15 --> Config Class Initialized
INFO - 2022-03-31 01:58:15 --> Hooks Class Initialized
DEBUG - 2022-03-31 01:58:15 --> UTF-8 Support Enabled
INFO - 2022-03-31 01:58:15 --> Utf8 Class Initialized
INFO - 2022-03-31 01:58:15 --> URI Class Initialized
DEBUG - 2022-03-31 01:58:15 --> No URI present. Default controller set.
INFO - 2022-03-31 01:58:15 --> Router Class Initialized
INFO - 2022-03-31 01:58:15 --> Output Class Initialized
INFO - 2022-03-31 01:58:15 --> Security Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 01:58:15 --> Input Class Initialized
INFO - 2022-03-31 01:58:15 --> Language Class Initialized
INFO - 2022-03-31 01:58:15 --> Loader Class Initialized
INFO - 2022-03-31 01:58:15 --> Helper loaded: url_helper
INFO - 2022-03-31 01:58:15 --> Helper loaded: form_helper
INFO - 2022-03-31 01:58:15 --> Helper loaded: common_helper
INFO - 2022-03-31 01:58:15 --> Database Driver Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 01:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 01:58:15 --> Controller Class Initialized
INFO - 2022-03-31 01:58:15 --> Form Validation Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Encrypt Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 01:58:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 01:58:15 --> Email Class Initialized
INFO - 2022-03-31 01:58:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 01:58:15 --> Calendar Class Initialized
INFO - 2022-03-31 01:58:15 --> Model "Login_model" initialized
ERROR - 2022-03-31 01:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 01:58:15 --> Config Class Initialized
INFO - 2022-03-31 01:58:15 --> Hooks Class Initialized
DEBUG - 2022-03-31 01:58:15 --> UTF-8 Support Enabled
INFO - 2022-03-31 01:58:15 --> Utf8 Class Initialized
INFO - 2022-03-31 01:58:15 --> URI Class Initialized
INFO - 2022-03-31 01:58:15 --> Router Class Initialized
INFO - 2022-03-31 01:58:15 --> Output Class Initialized
INFO - 2022-03-31 01:58:15 --> Security Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 01:58:15 --> Input Class Initialized
INFO - 2022-03-31 01:58:15 --> Language Class Initialized
INFO - 2022-03-31 01:58:15 --> Loader Class Initialized
INFO - 2022-03-31 01:58:15 --> Helper loaded: url_helper
INFO - 2022-03-31 01:58:15 --> Helper loaded: form_helper
INFO - 2022-03-31 01:58:15 --> Helper loaded: common_helper
INFO - 2022-03-31 01:58:15 --> Database Driver Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 01:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 01:58:15 --> Controller Class Initialized
INFO - 2022-03-31 01:58:15 --> Form Validation Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Encrypt Class Initialized
INFO - 2022-03-31 01:58:15 --> Model "Diseases_model" initialized
INFO - 2022-03-31 01:58:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 01:58:15 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-31 01:58:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 01:58:15 --> Final output sent to browser
DEBUG - 2022-03-31 01:58:15 --> Total execution time: 0.0109
ERROR - 2022-03-31 01:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 01:58:15 --> Config Class Initialized
INFO - 2022-03-31 01:58:15 --> Hooks Class Initialized
DEBUG - 2022-03-31 01:58:15 --> UTF-8 Support Enabled
INFO - 2022-03-31 01:58:15 --> Utf8 Class Initialized
INFO - 2022-03-31 01:58:15 --> URI Class Initialized
DEBUG - 2022-03-31 01:58:15 --> No URI present. Default controller set.
INFO - 2022-03-31 01:58:15 --> Router Class Initialized
INFO - 2022-03-31 01:58:15 --> Output Class Initialized
INFO - 2022-03-31 01:58:15 --> Security Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 01:58:15 --> Input Class Initialized
INFO - 2022-03-31 01:58:15 --> Language Class Initialized
INFO - 2022-03-31 01:58:15 --> Loader Class Initialized
INFO - 2022-03-31 01:58:15 --> Helper loaded: url_helper
INFO - 2022-03-31 01:58:15 --> Helper loaded: form_helper
INFO - 2022-03-31 01:58:15 --> Helper loaded: common_helper
INFO - 2022-03-31 01:58:15 --> Database Driver Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 01:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 01:58:15 --> Controller Class Initialized
INFO - 2022-03-31 01:58:15 --> Form Validation Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Encrypt Class Initialized
DEBUG - 2022-03-31 01:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 01:58:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 01:58:15 --> Email Class Initialized
INFO - 2022-03-31 01:58:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 01:58:15 --> Calendar Class Initialized
INFO - 2022-03-31 01:58:15 --> Model "Login_model" initialized
ERROR - 2022-03-31 01:58:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 01:58:16 --> Config Class Initialized
INFO - 2022-03-31 01:58:16 --> Hooks Class Initialized
DEBUG - 2022-03-31 01:58:16 --> UTF-8 Support Enabled
INFO - 2022-03-31 01:58:16 --> Utf8 Class Initialized
INFO - 2022-03-31 01:58:16 --> URI Class Initialized
INFO - 2022-03-31 01:58:16 --> Router Class Initialized
INFO - 2022-03-31 01:58:16 --> Output Class Initialized
INFO - 2022-03-31 01:58:16 --> Security Class Initialized
DEBUG - 2022-03-31 01:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 01:58:16 --> Input Class Initialized
INFO - 2022-03-31 01:58:16 --> Language Class Initialized
INFO - 2022-03-31 01:58:16 --> Loader Class Initialized
INFO - 2022-03-31 01:58:16 --> Helper loaded: url_helper
INFO - 2022-03-31 01:58:16 --> Helper loaded: form_helper
INFO - 2022-03-31 01:58:16 --> Helper loaded: common_helper
INFO - 2022-03-31 01:58:16 --> Database Driver Class Initialized
DEBUG - 2022-03-31 01:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 01:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 01:58:16 --> Controller Class Initialized
INFO - 2022-03-31 01:58:16 --> Form Validation Class Initialized
DEBUG - 2022-03-31 01:58:16 --> Encrypt Class Initialized
INFO - 2022-03-31 01:58:16 --> Model "Diseases_model" initialized
INFO - 2022-03-31 01:58:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 01:58:16 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-31 01:58:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 01:58:16 --> Final output sent to browser
DEBUG - 2022-03-31 01:58:16 --> Total execution time: 0.0211
ERROR - 2022-03-31 01:58:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 01:58:21 --> Config Class Initialized
INFO - 2022-03-31 01:58:21 --> Hooks Class Initialized
DEBUG - 2022-03-31 01:58:21 --> UTF-8 Support Enabled
INFO - 2022-03-31 01:58:21 --> Utf8 Class Initialized
INFO - 2022-03-31 01:58:21 --> URI Class Initialized
INFO - 2022-03-31 01:58:21 --> Router Class Initialized
INFO - 2022-03-31 01:58:21 --> Output Class Initialized
INFO - 2022-03-31 01:58:21 --> Security Class Initialized
DEBUG - 2022-03-31 01:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 01:58:21 --> Input Class Initialized
INFO - 2022-03-31 01:58:21 --> Language Class Initialized
INFO - 2022-03-31 01:58:21 --> Loader Class Initialized
INFO - 2022-03-31 01:58:21 --> Helper loaded: url_helper
INFO - 2022-03-31 01:58:21 --> Helper loaded: form_helper
INFO - 2022-03-31 01:58:21 --> Helper loaded: common_helper
INFO - 2022-03-31 01:58:21 --> Database Driver Class Initialized
DEBUG - 2022-03-31 01:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 01:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 01:58:21 --> Controller Class Initialized
INFO - 2022-03-31 01:58:21 --> Form Validation Class Initialized
DEBUG - 2022-03-31 01:58:21 --> Encrypt Class Initialized
INFO - 2022-03-31 01:58:21 --> Model "Patient_model" initialized
INFO - 2022-03-31 01:58:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 01:58:21 --> Model "Referredby_model" initialized
INFO - 2022-03-31 01:58:21 --> Model "Prefix_master" initialized
INFO - 2022-03-31 01:58:21 --> Model "Hospital_model" initialized
INFO - 2022-03-31 01:58:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 01:58:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 01:58:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 01:58:21 --> Final output sent to browser
DEBUG - 2022-03-31 01:58:21 --> Total execution time: 0.0740
ERROR - 2022-03-31 01:58:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 01:58:37 --> Config Class Initialized
INFO - 2022-03-31 01:58:37 --> Hooks Class Initialized
DEBUG - 2022-03-31 01:58:37 --> UTF-8 Support Enabled
INFO - 2022-03-31 01:58:37 --> Utf8 Class Initialized
INFO - 2022-03-31 01:58:37 --> URI Class Initialized
INFO - 2022-03-31 01:58:37 --> Router Class Initialized
INFO - 2022-03-31 01:58:37 --> Output Class Initialized
INFO - 2022-03-31 01:58:37 --> Security Class Initialized
DEBUG - 2022-03-31 01:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 01:58:37 --> Input Class Initialized
INFO - 2022-03-31 01:58:37 --> Language Class Initialized
INFO - 2022-03-31 01:58:37 --> Loader Class Initialized
INFO - 2022-03-31 01:58:37 --> Helper loaded: url_helper
INFO - 2022-03-31 01:58:37 --> Helper loaded: form_helper
INFO - 2022-03-31 01:58:37 --> Helper loaded: common_helper
INFO - 2022-03-31 01:58:37 --> Database Driver Class Initialized
DEBUG - 2022-03-31 01:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 01:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 01:58:37 --> Controller Class Initialized
INFO - 2022-03-31 01:58:37 --> Form Validation Class Initialized
DEBUG - 2022-03-31 01:58:37 --> Encrypt Class Initialized
INFO - 2022-03-31 01:58:37 --> Model "Patient_model" initialized
INFO - 2022-03-31 01:58:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 01:58:37 --> Model "Prefix_master" initialized
INFO - 2022-03-31 01:58:37 --> Model "Users_model" initialized
INFO - 2022-03-31 01:58:37 --> Model "Hospital_model" initialized
INFO - 2022-03-31 01:58:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 01:58:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 01:58:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 01:58:37 --> Final output sent to browser
DEBUG - 2022-03-31 01:58:37 --> Total execution time: 0.0472
ERROR - 2022-03-31 01:59:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 01:59:05 --> Config Class Initialized
INFO - 2022-03-31 01:59:05 --> Hooks Class Initialized
DEBUG - 2022-03-31 01:59:05 --> UTF-8 Support Enabled
INFO - 2022-03-31 01:59:05 --> Utf8 Class Initialized
INFO - 2022-03-31 01:59:05 --> URI Class Initialized
INFO - 2022-03-31 01:59:05 --> Router Class Initialized
INFO - 2022-03-31 01:59:05 --> Output Class Initialized
INFO - 2022-03-31 01:59:05 --> Security Class Initialized
DEBUG - 2022-03-31 01:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 01:59:05 --> Input Class Initialized
INFO - 2022-03-31 01:59:05 --> Language Class Initialized
INFO - 2022-03-31 01:59:05 --> Loader Class Initialized
INFO - 2022-03-31 01:59:05 --> Helper loaded: url_helper
INFO - 2022-03-31 01:59:05 --> Helper loaded: form_helper
INFO - 2022-03-31 01:59:05 --> Helper loaded: common_helper
INFO - 2022-03-31 01:59:05 --> Database Driver Class Initialized
DEBUG - 2022-03-31 01:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 01:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 01:59:05 --> Controller Class Initialized
INFO - 2022-03-31 01:59:05 --> Form Validation Class Initialized
DEBUG - 2022-03-31 01:59:05 --> Encrypt Class Initialized
INFO - 2022-03-31 01:59:05 --> Model "Patient_model" initialized
INFO - 2022-03-31 01:59:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 01:59:05 --> Model "Prefix_master" initialized
INFO - 2022-03-31 01:59:05 --> Model "Users_model" initialized
INFO - 2022-03-31 01:59:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 01:59:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 01:59:06 --> Config Class Initialized
INFO - 2022-03-31 01:59:06 --> Hooks Class Initialized
DEBUG - 2022-03-31 01:59:06 --> UTF-8 Support Enabled
INFO - 2022-03-31 01:59:06 --> Utf8 Class Initialized
INFO - 2022-03-31 01:59:06 --> URI Class Initialized
INFO - 2022-03-31 01:59:06 --> Router Class Initialized
INFO - 2022-03-31 01:59:06 --> Output Class Initialized
INFO - 2022-03-31 01:59:06 --> Security Class Initialized
DEBUG - 2022-03-31 01:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 01:59:06 --> Input Class Initialized
INFO - 2022-03-31 01:59:06 --> Language Class Initialized
INFO - 2022-03-31 01:59:06 --> Loader Class Initialized
INFO - 2022-03-31 01:59:06 --> Helper loaded: url_helper
INFO - 2022-03-31 01:59:06 --> Helper loaded: form_helper
INFO - 2022-03-31 01:59:06 --> Helper loaded: common_helper
INFO - 2022-03-31 01:59:06 --> Database Driver Class Initialized
DEBUG - 2022-03-31 01:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 01:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 01:59:06 --> Controller Class Initialized
INFO - 2022-03-31 01:59:06 --> Form Validation Class Initialized
DEBUG - 2022-03-31 01:59:06 --> Encrypt Class Initialized
INFO - 2022-03-31 01:59:06 --> Model "Patient_model" initialized
INFO - 2022-03-31 01:59:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 01:59:06 --> Model "Prefix_master" initialized
INFO - 2022-03-31 01:59:06 --> Model "Users_model" initialized
INFO - 2022-03-31 01:59:06 --> Model "Hospital_model" initialized
INFO - 2022-03-31 01:59:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 01:59:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 01:59:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 01:59:06 --> Final output sent to browser
DEBUG - 2022-03-31 01:59:06 --> Total execution time: 0.0360
ERROR - 2022-03-31 02:18:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:18:56 --> Config Class Initialized
INFO - 2022-03-31 02:18:56 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:18:56 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:18:56 --> Utf8 Class Initialized
INFO - 2022-03-31 02:18:56 --> URI Class Initialized
INFO - 2022-03-31 02:18:56 --> Router Class Initialized
INFO - 2022-03-31 02:18:56 --> Output Class Initialized
INFO - 2022-03-31 02:18:56 --> Security Class Initialized
DEBUG - 2022-03-31 02:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:18:56 --> Input Class Initialized
INFO - 2022-03-31 02:18:56 --> Language Class Initialized
INFO - 2022-03-31 02:18:56 --> Loader Class Initialized
INFO - 2022-03-31 02:18:56 --> Helper loaded: url_helper
INFO - 2022-03-31 02:18:56 --> Helper loaded: form_helper
INFO - 2022-03-31 02:18:56 --> Helper loaded: common_helper
INFO - 2022-03-31 02:18:56 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:18:56 --> Controller Class Initialized
INFO - 2022-03-31 02:18:56 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:18:56 --> Encrypt Class Initialized
INFO - 2022-03-31 02:18:57 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:18:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:18:57 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:18:57 --> Model "Users_model" initialized
INFO - 2022-03-31 02:18:57 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 02:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:18:57 --> Config Class Initialized
INFO - 2022-03-31 02:18:57 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:18:57 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:18:57 --> Utf8 Class Initialized
INFO - 2022-03-31 02:18:57 --> URI Class Initialized
INFO - 2022-03-31 02:18:57 --> Router Class Initialized
INFO - 2022-03-31 02:18:57 --> Output Class Initialized
INFO - 2022-03-31 02:18:57 --> Security Class Initialized
DEBUG - 2022-03-31 02:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:18:57 --> Input Class Initialized
INFO - 2022-03-31 02:18:57 --> Language Class Initialized
INFO - 2022-03-31 02:18:57 --> Loader Class Initialized
INFO - 2022-03-31 02:18:57 --> Helper loaded: url_helper
INFO - 2022-03-31 02:18:57 --> Helper loaded: form_helper
INFO - 2022-03-31 02:18:57 --> Helper loaded: common_helper
INFO - 2022-03-31 02:18:57 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:18:57 --> Controller Class Initialized
INFO - 2022-03-31 02:18:57 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:18:57 --> Encrypt Class Initialized
INFO - 2022-03-31 02:18:57 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:18:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:18:57 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:18:57 --> Model "Users_model" initialized
INFO - 2022-03-31 02:18:57 --> Model "Hospital_model" initialized
INFO - 2022-03-31 02:18:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 02:18:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 02:18:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 02:18:57 --> Final output sent to browser
DEBUG - 2022-03-31 02:18:57 --> Total execution time: 0.0860
ERROR - 2022-03-31 02:21:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:21:23 --> Config Class Initialized
INFO - 2022-03-31 02:21:23 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:21:23 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:21:23 --> Utf8 Class Initialized
INFO - 2022-03-31 02:21:23 --> URI Class Initialized
INFO - 2022-03-31 02:21:23 --> Router Class Initialized
INFO - 2022-03-31 02:21:23 --> Output Class Initialized
INFO - 2022-03-31 02:21:23 --> Security Class Initialized
DEBUG - 2022-03-31 02:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:21:23 --> Input Class Initialized
INFO - 2022-03-31 02:21:23 --> Language Class Initialized
INFO - 2022-03-31 02:21:23 --> Loader Class Initialized
INFO - 2022-03-31 02:21:23 --> Helper loaded: url_helper
INFO - 2022-03-31 02:21:23 --> Helper loaded: form_helper
INFO - 2022-03-31 02:21:23 --> Helper loaded: common_helper
INFO - 2022-03-31 02:21:23 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:21:23 --> Controller Class Initialized
INFO - 2022-03-31 02:21:23 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:21:23 --> Encrypt Class Initialized
INFO - 2022-03-31 02:21:23 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:21:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:21:23 --> Model "Referredby_model" initialized
INFO - 2022-03-31 02:21:23 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:21:23 --> Model "Hospital_model" initialized
INFO - 2022-03-31 02:21:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 02:21:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 02:21:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 02:21:23 --> Final output sent to browser
DEBUG - 2022-03-31 02:21:23 --> Total execution time: 0.2820
ERROR - 2022-03-31 02:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:21:58 --> Config Class Initialized
INFO - 2022-03-31 02:21:58 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:21:58 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:21:58 --> Utf8 Class Initialized
INFO - 2022-03-31 02:21:58 --> URI Class Initialized
INFO - 2022-03-31 02:21:58 --> Router Class Initialized
INFO - 2022-03-31 02:21:58 --> Output Class Initialized
INFO - 2022-03-31 02:21:58 --> Security Class Initialized
DEBUG - 2022-03-31 02:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:21:58 --> Input Class Initialized
INFO - 2022-03-31 02:21:58 --> Language Class Initialized
INFO - 2022-03-31 02:21:58 --> Loader Class Initialized
INFO - 2022-03-31 02:21:58 --> Helper loaded: url_helper
INFO - 2022-03-31 02:21:58 --> Helper loaded: form_helper
INFO - 2022-03-31 02:21:58 --> Helper loaded: common_helper
INFO - 2022-03-31 02:21:58 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:21:58 --> Controller Class Initialized
INFO - 2022-03-31 02:21:58 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:21:58 --> Encrypt Class Initialized
INFO - 2022-03-31 02:21:58 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:21:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:21:58 --> Model "Referredby_model" initialized
INFO - 2022-03-31 02:21:58 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:21:58 --> Model "Hospital_model" initialized
INFO - 2022-03-31 02:21:58 --> Upload Class Initialized
INFO - 2022-03-31 02:21:58 --> Final output sent to browser
DEBUG - 2022-03-31 02:21:58 --> Total execution time: 0.2357
ERROR - 2022-03-31 02:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:21:58 --> Config Class Initialized
INFO - 2022-03-31 02:21:58 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:21:58 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:21:58 --> Utf8 Class Initialized
INFO - 2022-03-31 02:21:58 --> URI Class Initialized
INFO - 2022-03-31 02:21:58 --> Router Class Initialized
INFO - 2022-03-31 02:21:58 --> Output Class Initialized
INFO - 2022-03-31 02:21:58 --> Security Class Initialized
DEBUG - 2022-03-31 02:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:21:58 --> Input Class Initialized
INFO - 2022-03-31 02:21:58 --> Language Class Initialized
INFO - 2022-03-31 02:21:58 --> Loader Class Initialized
INFO - 2022-03-31 02:21:58 --> Helper loaded: url_helper
INFO - 2022-03-31 02:21:58 --> Helper loaded: form_helper
INFO - 2022-03-31 02:21:58 --> Helper loaded: common_helper
INFO - 2022-03-31 02:21:58 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:21:58 --> Controller Class Initialized
INFO - 2022-03-31 02:21:58 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:21:58 --> Encrypt Class Initialized
INFO - 2022-03-31 02:21:58 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:21:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:21:58 --> Model "Referredby_model" initialized
INFO - 2022-03-31 02:21:58 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:21:58 --> Model "Hospital_model" initialized
INFO - 2022-03-31 02:21:58 --> Upload Class Initialized
INFO - 2022-03-31 02:21:58 --> Final output sent to browser
DEBUG - 2022-03-31 02:21:58 --> Total execution time: 0.0084
ERROR - 2022-03-31 02:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:22:06 --> Config Class Initialized
INFO - 2022-03-31 02:22:06 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:22:06 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:22:06 --> Utf8 Class Initialized
INFO - 2022-03-31 02:22:06 --> URI Class Initialized
INFO - 2022-03-31 02:22:06 --> Router Class Initialized
INFO - 2022-03-31 02:22:06 --> Output Class Initialized
INFO - 2022-03-31 02:22:06 --> Security Class Initialized
DEBUG - 2022-03-31 02:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:22:06 --> Input Class Initialized
INFO - 2022-03-31 02:22:06 --> Language Class Initialized
INFO - 2022-03-31 02:22:06 --> Loader Class Initialized
INFO - 2022-03-31 02:22:06 --> Helper loaded: url_helper
INFO - 2022-03-31 02:22:06 --> Helper loaded: form_helper
INFO - 2022-03-31 02:22:06 --> Helper loaded: common_helper
INFO - 2022-03-31 02:22:06 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:22:06 --> Controller Class Initialized
INFO - 2022-03-31 02:22:06 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:22:06 --> Encrypt Class Initialized
INFO - 2022-03-31 02:22:06 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:22:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:22:06 --> Model "Referredby_model" initialized
INFO - 2022-03-31 02:22:06 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:22:06 --> Model "Hospital_model" initialized
INFO - 2022-03-31 02:22:06 --> Upload Class Initialized
INFO - 2022-03-31 02:22:06 --> Final output sent to browser
DEBUG - 2022-03-31 02:22:06 --> Total execution time: 0.0089
ERROR - 2022-03-31 02:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:22:15 --> Config Class Initialized
INFO - 2022-03-31 02:22:15 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:22:15 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:22:15 --> Utf8 Class Initialized
INFO - 2022-03-31 02:22:15 --> URI Class Initialized
INFO - 2022-03-31 02:22:15 --> Router Class Initialized
INFO - 2022-03-31 02:22:15 --> Output Class Initialized
INFO - 2022-03-31 02:22:15 --> Security Class Initialized
DEBUG - 2022-03-31 02:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:22:15 --> Input Class Initialized
INFO - 2022-03-31 02:22:15 --> Language Class Initialized
INFO - 2022-03-31 02:22:15 --> Loader Class Initialized
INFO - 2022-03-31 02:22:15 --> Helper loaded: url_helper
INFO - 2022-03-31 02:22:15 --> Helper loaded: form_helper
INFO - 2022-03-31 02:22:15 --> Helper loaded: common_helper
INFO - 2022-03-31 02:22:15 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:22:15 --> Controller Class Initialized
INFO - 2022-03-31 02:22:15 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:22:15 --> Encrypt Class Initialized
INFO - 2022-03-31 02:22:15 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:22:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:22:15 --> Model "Referredby_model" initialized
INFO - 2022-03-31 02:22:15 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:22:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 02:22:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:22:15 --> Config Class Initialized
INFO - 2022-03-31 02:22:15 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:22:15 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:22:15 --> Utf8 Class Initialized
INFO - 2022-03-31 02:22:15 --> URI Class Initialized
INFO - 2022-03-31 02:22:15 --> Router Class Initialized
INFO - 2022-03-31 02:22:15 --> Output Class Initialized
INFO - 2022-03-31 02:22:15 --> Security Class Initialized
DEBUG - 2022-03-31 02:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:22:15 --> Input Class Initialized
INFO - 2022-03-31 02:22:15 --> Language Class Initialized
INFO - 2022-03-31 02:22:15 --> Loader Class Initialized
INFO - 2022-03-31 02:22:15 --> Helper loaded: url_helper
INFO - 2022-03-31 02:22:15 --> Helper loaded: form_helper
INFO - 2022-03-31 02:22:15 --> Helper loaded: common_helper
INFO - 2022-03-31 02:22:15 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:22:15 --> Controller Class Initialized
INFO - 2022-03-31 02:22:15 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:22:15 --> Encrypt Class Initialized
INFO - 2022-03-31 02:22:15 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:22:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:22:15 --> Model "Referredby_model" initialized
INFO - 2022-03-31 02:22:15 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:22:15 --> Model "Hospital_model" initialized
INFO - 2022-03-31 02:22:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 02:22:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 02:22:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 02:22:15 --> Final output sent to browser
DEBUG - 2022-03-31 02:22:15 --> Total execution time: 0.0264
ERROR - 2022-03-31 02:22:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:22:16 --> Config Class Initialized
INFO - 2022-03-31 02:22:16 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:22:16 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:22:16 --> Utf8 Class Initialized
INFO - 2022-03-31 02:22:16 --> URI Class Initialized
INFO - 2022-03-31 02:22:16 --> Router Class Initialized
INFO - 2022-03-31 02:22:16 --> Output Class Initialized
INFO - 2022-03-31 02:22:16 --> Security Class Initialized
DEBUG - 2022-03-31 02:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:22:16 --> Input Class Initialized
INFO - 2022-03-31 02:22:16 --> Language Class Initialized
INFO - 2022-03-31 02:22:16 --> Loader Class Initialized
INFO - 2022-03-31 02:22:16 --> Helper loaded: url_helper
INFO - 2022-03-31 02:22:16 --> Helper loaded: form_helper
INFO - 2022-03-31 02:22:16 --> Helper loaded: common_helper
INFO - 2022-03-31 02:22:16 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:22:16 --> Controller Class Initialized
INFO - 2022-03-31 02:22:16 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:22:16 --> Encrypt Class Initialized
INFO - 2022-03-31 02:22:16 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:22:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:22:16 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:22:16 --> Model "Users_model" initialized
INFO - 2022-03-31 02:22:16 --> Model "Hospital_model" initialized
INFO - 2022-03-31 02:22:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 02:22:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 02:22:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 02:22:16 --> Final output sent to browser
DEBUG - 2022-03-31 02:22:16 --> Total execution time: 0.0541
ERROR - 2022-03-31 02:29:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:29:19 --> Config Class Initialized
INFO - 2022-03-31 02:29:19 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:29:19 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:29:19 --> Utf8 Class Initialized
INFO - 2022-03-31 02:29:19 --> URI Class Initialized
INFO - 2022-03-31 02:29:19 --> Router Class Initialized
INFO - 2022-03-31 02:29:19 --> Output Class Initialized
INFO - 2022-03-31 02:29:19 --> Security Class Initialized
DEBUG - 2022-03-31 02:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:29:19 --> Input Class Initialized
INFO - 2022-03-31 02:29:19 --> Language Class Initialized
INFO - 2022-03-31 02:29:19 --> Loader Class Initialized
INFO - 2022-03-31 02:29:19 --> Helper loaded: url_helper
INFO - 2022-03-31 02:29:19 --> Helper loaded: form_helper
INFO - 2022-03-31 02:29:19 --> Helper loaded: common_helper
INFO - 2022-03-31 02:29:19 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:29:19 --> Controller Class Initialized
INFO - 2022-03-31 02:29:19 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:29:19 --> Encrypt Class Initialized
INFO - 2022-03-31 02:29:19 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:29:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:29:19 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:29:19 --> Model "Users_model" initialized
INFO - 2022-03-31 02:29:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 02:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:29:21 --> Config Class Initialized
INFO - 2022-03-31 02:29:21 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:29:21 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:29:21 --> Utf8 Class Initialized
INFO - 2022-03-31 02:29:21 --> URI Class Initialized
INFO - 2022-03-31 02:29:21 --> Router Class Initialized
INFO - 2022-03-31 02:29:21 --> Output Class Initialized
INFO - 2022-03-31 02:29:21 --> Security Class Initialized
DEBUG - 2022-03-31 02:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:29:21 --> Input Class Initialized
INFO - 2022-03-31 02:29:21 --> Language Class Initialized
INFO - 2022-03-31 02:29:21 --> Loader Class Initialized
INFO - 2022-03-31 02:29:21 --> Helper loaded: url_helper
INFO - 2022-03-31 02:29:21 --> Helper loaded: form_helper
INFO - 2022-03-31 02:29:21 --> Helper loaded: common_helper
INFO - 2022-03-31 02:29:21 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:29:21 --> Controller Class Initialized
INFO - 2022-03-31 02:29:21 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:29:21 --> Encrypt Class Initialized
INFO - 2022-03-31 02:29:21 --> Model "Patient_model" initialized
INFO - 2022-03-31 02:29:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 02:29:21 --> Model "Prefix_master" initialized
INFO - 2022-03-31 02:29:21 --> Model "Users_model" initialized
INFO - 2022-03-31 02:29:21 --> Model "Hospital_model" initialized
INFO - 2022-03-31 02:29:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 02:29:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 02:29:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 02:29:21 --> Final output sent to browser
DEBUG - 2022-03-31 02:29:21 --> Total execution time: 0.0408
ERROR - 2022-03-31 02:42:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 02:42:03 --> Config Class Initialized
INFO - 2022-03-31 02:42:03 --> Hooks Class Initialized
DEBUG - 2022-03-31 02:42:03 --> UTF-8 Support Enabled
INFO - 2022-03-31 02:42:03 --> Utf8 Class Initialized
INFO - 2022-03-31 02:42:03 --> URI Class Initialized
DEBUG - 2022-03-31 02:42:03 --> No URI present. Default controller set.
INFO - 2022-03-31 02:42:03 --> Router Class Initialized
INFO - 2022-03-31 02:42:03 --> Output Class Initialized
INFO - 2022-03-31 02:42:03 --> Security Class Initialized
DEBUG - 2022-03-31 02:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 02:42:03 --> Input Class Initialized
INFO - 2022-03-31 02:42:03 --> Language Class Initialized
INFO - 2022-03-31 02:42:03 --> Loader Class Initialized
INFO - 2022-03-31 02:42:03 --> Helper loaded: url_helper
INFO - 2022-03-31 02:42:03 --> Helper loaded: form_helper
INFO - 2022-03-31 02:42:03 --> Helper loaded: common_helper
INFO - 2022-03-31 02:42:03 --> Database Driver Class Initialized
DEBUG - 2022-03-31 02:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 02:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 02:42:03 --> Controller Class Initialized
INFO - 2022-03-31 02:42:03 --> Form Validation Class Initialized
DEBUG - 2022-03-31 02:42:03 --> Encrypt Class Initialized
DEBUG - 2022-03-31 02:42:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 02:42:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 02:42:03 --> Email Class Initialized
INFO - 2022-03-31 02:42:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 02:42:03 --> Calendar Class Initialized
INFO - 2022-03-31 02:42:03 --> Model "Login_model" initialized
INFO - 2022-03-31 02:42:03 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 02:42:03 --> Final output sent to browser
DEBUG - 2022-03-31 02:42:03 --> Total execution time: 0.1018
ERROR - 2022-03-31 03:36:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:36:40 --> Config Class Initialized
INFO - 2022-03-31 03:36:40 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:36:40 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:36:40 --> Utf8 Class Initialized
INFO - 2022-03-31 03:36:40 --> URI Class Initialized
DEBUG - 2022-03-31 03:36:40 --> No URI present. Default controller set.
INFO - 2022-03-31 03:36:40 --> Router Class Initialized
INFO - 2022-03-31 03:36:40 --> Output Class Initialized
INFO - 2022-03-31 03:36:40 --> Security Class Initialized
DEBUG - 2022-03-31 03:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:36:40 --> Input Class Initialized
INFO - 2022-03-31 03:36:40 --> Language Class Initialized
INFO - 2022-03-31 03:36:40 --> Loader Class Initialized
INFO - 2022-03-31 03:36:40 --> Helper loaded: url_helper
INFO - 2022-03-31 03:36:40 --> Helper loaded: form_helper
INFO - 2022-03-31 03:36:40 --> Helper loaded: common_helper
INFO - 2022-03-31 03:36:40 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:36:40 --> Controller Class Initialized
INFO - 2022-03-31 03:36:40 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:36:40 --> Encrypt Class Initialized
DEBUG - 2022-03-31 03:36:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 03:36:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 03:36:40 --> Email Class Initialized
INFO - 2022-03-31 03:36:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 03:36:40 --> Calendar Class Initialized
INFO - 2022-03-31 03:36:40 --> Model "Login_model" initialized
INFO - 2022-03-31 03:36:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 03:36:40 --> Final output sent to browser
DEBUG - 2022-03-31 03:36:40 --> Total execution time: 0.0663
ERROR - 2022-03-31 03:43:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:43:24 --> Config Class Initialized
INFO - 2022-03-31 03:43:24 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:43:24 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:43:24 --> Utf8 Class Initialized
INFO - 2022-03-31 03:43:24 --> URI Class Initialized
INFO - 2022-03-31 03:43:24 --> Router Class Initialized
INFO - 2022-03-31 03:43:24 --> Output Class Initialized
INFO - 2022-03-31 03:43:24 --> Security Class Initialized
DEBUG - 2022-03-31 03:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:43:24 --> Input Class Initialized
INFO - 2022-03-31 03:43:24 --> Language Class Initialized
INFO - 2022-03-31 03:43:24 --> Loader Class Initialized
INFO - 2022-03-31 03:43:24 --> Helper loaded: url_helper
INFO - 2022-03-31 03:43:24 --> Helper loaded: form_helper
INFO - 2022-03-31 03:43:24 --> Helper loaded: common_helper
INFO - 2022-03-31 03:43:24 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:43:24 --> Controller Class Initialized
ERROR - 2022-03-31 03:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:43:25 --> Config Class Initialized
INFO - 2022-03-31 03:43:25 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:43:25 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:43:25 --> Utf8 Class Initialized
INFO - 2022-03-31 03:43:25 --> URI Class Initialized
INFO - 2022-03-31 03:43:25 --> Router Class Initialized
INFO - 2022-03-31 03:43:25 --> Output Class Initialized
INFO - 2022-03-31 03:43:25 --> Security Class Initialized
DEBUG - 2022-03-31 03:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:43:25 --> Input Class Initialized
INFO - 2022-03-31 03:43:25 --> Language Class Initialized
INFO - 2022-03-31 03:43:25 --> Loader Class Initialized
INFO - 2022-03-31 03:43:25 --> Helper loaded: url_helper
INFO - 2022-03-31 03:43:25 --> Helper loaded: form_helper
INFO - 2022-03-31 03:43:25 --> Helper loaded: common_helper
INFO - 2022-03-31 03:43:25 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:43:25 --> Controller Class Initialized
INFO - 2022-03-31 03:43:25 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:43:25 --> Encrypt Class Initialized
DEBUG - 2022-03-31 03:43:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 03:43:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 03:43:25 --> Email Class Initialized
INFO - 2022-03-31 03:43:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 03:43:25 --> Calendar Class Initialized
INFO - 2022-03-31 03:43:25 --> Model "Login_model" initialized
INFO - 2022-03-31 03:43:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 03:43:25 --> Final output sent to browser
DEBUG - 2022-03-31 03:43:25 --> Total execution time: 0.0225
ERROR - 2022-03-31 03:43:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:43:48 --> Config Class Initialized
INFO - 2022-03-31 03:43:48 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:43:48 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:43:48 --> Utf8 Class Initialized
INFO - 2022-03-31 03:43:48 --> URI Class Initialized
INFO - 2022-03-31 03:43:48 --> Router Class Initialized
INFO - 2022-03-31 03:43:48 --> Output Class Initialized
INFO - 2022-03-31 03:43:48 --> Security Class Initialized
DEBUG - 2022-03-31 03:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:43:48 --> Input Class Initialized
INFO - 2022-03-31 03:43:48 --> Language Class Initialized
INFO - 2022-03-31 03:43:48 --> Loader Class Initialized
INFO - 2022-03-31 03:43:48 --> Helper loaded: url_helper
INFO - 2022-03-31 03:43:48 --> Helper loaded: form_helper
INFO - 2022-03-31 03:43:48 --> Helper loaded: common_helper
INFO - 2022-03-31 03:43:48 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:43:48 --> Controller Class Initialized
ERROR - 2022-03-31 03:43:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:43:49 --> Config Class Initialized
INFO - 2022-03-31 03:43:49 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:43:49 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:43:49 --> Utf8 Class Initialized
INFO - 2022-03-31 03:43:49 --> URI Class Initialized
INFO - 2022-03-31 03:43:49 --> Router Class Initialized
INFO - 2022-03-31 03:43:49 --> Output Class Initialized
INFO - 2022-03-31 03:43:49 --> Security Class Initialized
DEBUG - 2022-03-31 03:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:43:49 --> Input Class Initialized
INFO - 2022-03-31 03:43:49 --> Language Class Initialized
INFO - 2022-03-31 03:43:49 --> Loader Class Initialized
INFO - 2022-03-31 03:43:49 --> Helper loaded: url_helper
INFO - 2022-03-31 03:43:49 --> Helper loaded: form_helper
INFO - 2022-03-31 03:43:49 --> Helper loaded: common_helper
INFO - 2022-03-31 03:43:49 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:43:49 --> Controller Class Initialized
INFO - 2022-03-31 03:43:49 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:43:49 --> Encrypt Class Initialized
DEBUG - 2022-03-31 03:43:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 03:43:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 03:43:49 --> Email Class Initialized
INFO - 2022-03-31 03:43:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 03:43:49 --> Calendar Class Initialized
INFO - 2022-03-31 03:43:49 --> Model "Login_model" initialized
INFO - 2022-03-31 03:43:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 03:43:49 --> Final output sent to browser
DEBUG - 2022-03-31 03:43:49 --> Total execution time: 0.0074
ERROR - 2022-03-31 03:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:22 --> Config Class Initialized
INFO - 2022-03-31 03:44:22 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:22 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:22 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:22 --> URI Class Initialized
INFO - 2022-03-31 03:44:22 --> Router Class Initialized
INFO - 2022-03-31 03:44:22 --> Output Class Initialized
INFO - 2022-03-31 03:44:22 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:22 --> Input Class Initialized
INFO - 2022-03-31 03:44:22 --> Language Class Initialized
INFO - 2022-03-31 03:44:22 --> Loader Class Initialized
INFO - 2022-03-31 03:44:22 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:22 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:22 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:22 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:22 --> Controller Class Initialized
ERROR - 2022-03-31 03:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:22 --> Config Class Initialized
INFO - 2022-03-31 03:44:22 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:22 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:22 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:22 --> URI Class Initialized
INFO - 2022-03-31 03:44:22 --> Router Class Initialized
INFO - 2022-03-31 03:44:22 --> Output Class Initialized
INFO - 2022-03-31 03:44:22 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:22 --> Input Class Initialized
INFO - 2022-03-31 03:44:22 --> Language Class Initialized
INFO - 2022-03-31 03:44:22 --> Loader Class Initialized
INFO - 2022-03-31 03:44:22 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:22 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:22 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:22 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:22 --> Controller Class Initialized
INFO - 2022-03-31 03:44:22 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:44:22 --> Encrypt Class Initialized
DEBUG - 2022-03-31 03:44:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 03:44:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 03:44:22 --> Email Class Initialized
INFO - 2022-03-31 03:44:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 03:44:22 --> Calendar Class Initialized
INFO - 2022-03-31 03:44:22 --> Model "Login_model" initialized
INFO - 2022-03-31 03:44:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 03:44:22 --> Final output sent to browser
DEBUG - 2022-03-31 03:44:22 --> Total execution time: 0.0065
ERROR - 2022-03-31 03:44:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:33 --> Config Class Initialized
INFO - 2022-03-31 03:44:33 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:33 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:33 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:33 --> URI Class Initialized
INFO - 2022-03-31 03:44:33 --> Router Class Initialized
INFO - 2022-03-31 03:44:33 --> Output Class Initialized
INFO - 2022-03-31 03:44:33 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:33 --> Input Class Initialized
INFO - 2022-03-31 03:44:33 --> Language Class Initialized
INFO - 2022-03-31 03:44:33 --> Loader Class Initialized
INFO - 2022-03-31 03:44:33 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:33 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:33 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:33 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:33 --> Controller Class Initialized
INFO - 2022-03-31 03:44:33 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:44:33 --> Encrypt Class Initialized
DEBUG - 2022-03-31 03:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 03:44:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 03:44:33 --> Email Class Initialized
INFO - 2022-03-31 03:44:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 03:44:33 --> Calendar Class Initialized
INFO - 2022-03-31 03:44:33 --> Model "Login_model" initialized
INFO - 2022-03-31 03:44:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-31 03:44:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:33 --> Config Class Initialized
INFO - 2022-03-31 03:44:33 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:33 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:33 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:33 --> URI Class Initialized
INFO - 2022-03-31 03:44:33 --> Router Class Initialized
INFO - 2022-03-31 03:44:33 --> Output Class Initialized
INFO - 2022-03-31 03:44:33 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:33 --> Input Class Initialized
INFO - 2022-03-31 03:44:33 --> Language Class Initialized
INFO - 2022-03-31 03:44:33 --> Loader Class Initialized
INFO - 2022-03-31 03:44:33 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:33 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:33 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:33 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:33 --> Controller Class Initialized
INFO - 2022-03-31 03:44:33 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:44:33 --> Encrypt Class Initialized
INFO - 2022-03-31 03:44:33 --> Model "Login_model" initialized
INFO - 2022-03-31 03:44:33 --> Model "Dashboard_model" initialized
INFO - 2022-03-31 03:44:33 --> Model "Case_model" initialized
INFO - 2022-03-31 03:44:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:44:34 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-31 03:44:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:44:34 --> Final output sent to browser
DEBUG - 2022-03-31 03:44:34 --> Total execution time: 0.3565
ERROR - 2022-03-31 03:44:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:36 --> Config Class Initialized
INFO - 2022-03-31 03:44:36 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:36 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:36 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:36 --> URI Class Initialized
INFO - 2022-03-31 03:44:36 --> Router Class Initialized
INFO - 2022-03-31 03:44:36 --> Output Class Initialized
INFO - 2022-03-31 03:44:36 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:36 --> Input Class Initialized
INFO - 2022-03-31 03:44:36 --> Language Class Initialized
INFO - 2022-03-31 03:44:36 --> Loader Class Initialized
INFO - 2022-03-31 03:44:36 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:36 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:36 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:36 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:36 --> Controller Class Initialized
INFO - 2022-03-31 03:44:36 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:44:36 --> Encrypt Class Initialized
DEBUG - 2022-03-31 03:44:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 03:44:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 03:44:36 --> Email Class Initialized
INFO - 2022-03-31 03:44:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 03:44:36 --> Calendar Class Initialized
INFO - 2022-03-31 03:44:36 --> Model "Login_model" initialized
INFO - 2022-03-31 03:44:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 03:44:36 --> Final output sent to browser
DEBUG - 2022-03-31 03:44:36 --> Total execution time: 0.0069
ERROR - 2022-03-31 03:44:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:36 --> Config Class Initialized
INFO - 2022-03-31 03:44:36 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:36 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:36 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:36 --> URI Class Initialized
INFO - 2022-03-31 03:44:36 --> Router Class Initialized
INFO - 2022-03-31 03:44:36 --> Output Class Initialized
INFO - 2022-03-31 03:44:36 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:36 --> Input Class Initialized
INFO - 2022-03-31 03:44:36 --> Language Class Initialized
INFO - 2022-03-31 03:44:36 --> Loader Class Initialized
INFO - 2022-03-31 03:44:36 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:36 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:36 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:36 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:36 --> Controller Class Initialized
INFO - 2022-03-31 03:44:36 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:44:36 --> Encrypt Class Initialized
DEBUG - 2022-03-31 03:44:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 03:44:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 03:44:36 --> Email Class Initialized
INFO - 2022-03-31 03:44:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 03:44:36 --> Calendar Class Initialized
INFO - 2022-03-31 03:44:36 --> Model "Login_model" initialized
INFO - 2022-03-31 03:44:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 03:44:36 --> Final output sent to browser
DEBUG - 2022-03-31 03:44:36 --> Total execution time: 0.0056
ERROR - 2022-03-31 03:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:42 --> Config Class Initialized
INFO - 2022-03-31 03:44:42 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:42 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:42 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:42 --> URI Class Initialized
INFO - 2022-03-31 03:44:42 --> Router Class Initialized
INFO - 2022-03-31 03:44:42 --> Output Class Initialized
INFO - 2022-03-31 03:44:42 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:42 --> Input Class Initialized
INFO - 2022-03-31 03:44:42 --> Language Class Initialized
INFO - 2022-03-31 03:44:42 --> Loader Class Initialized
INFO - 2022-03-31 03:44:42 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:42 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:42 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:42 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:42 --> Controller Class Initialized
INFO - 2022-03-31 03:44:42 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:44:42 --> Encrypt Class Initialized
INFO - 2022-03-31 03:44:42 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:44:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:44:42 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:44:42 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:44:42 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:44:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:44:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 03:44:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:44:43 --> Final output sent to browser
DEBUG - 2022-03-31 03:44:43 --> Total execution time: 0.1465
ERROR - 2022-03-31 03:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:51 --> Config Class Initialized
INFO - 2022-03-31 03:44:51 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:51 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:51 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:51 --> URI Class Initialized
INFO - 2022-03-31 03:44:51 --> Router Class Initialized
INFO - 2022-03-31 03:44:51 --> Output Class Initialized
INFO - 2022-03-31 03:44:51 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:51 --> Input Class Initialized
INFO - 2022-03-31 03:44:51 --> Language Class Initialized
INFO - 2022-03-31 03:44:51 --> Loader Class Initialized
INFO - 2022-03-31 03:44:51 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:51 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:51 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:51 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:51 --> Controller Class Initialized
INFO - 2022-03-31 03:44:51 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Encrypt Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 03:44:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 03:44:51 --> Email Class Initialized
INFO - 2022-03-31 03:44:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 03:44:51 --> Calendar Class Initialized
INFO - 2022-03-31 03:44:51 --> Model "Login_model" initialized
INFO - 2022-03-31 03:44:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-31 03:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:51 --> Config Class Initialized
INFO - 2022-03-31 03:44:51 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:51 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:51 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:51 --> URI Class Initialized
INFO - 2022-03-31 03:44:51 --> Router Class Initialized
INFO - 2022-03-31 03:44:51 --> Output Class Initialized
INFO - 2022-03-31 03:44:51 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:51 --> Input Class Initialized
INFO - 2022-03-31 03:44:51 --> Language Class Initialized
INFO - 2022-03-31 03:44:51 --> Loader Class Initialized
INFO - 2022-03-31 03:44:51 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:51 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:51 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:51 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:51 --> Controller Class Initialized
INFO - 2022-03-31 03:44:51 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Encrypt Class Initialized
INFO - 2022-03-31 03:44:51 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:44:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:44:51 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:44:51 --> Model "Users_model" initialized
INFO - 2022-03-31 03:44:51 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:44:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:44:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:44:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:44:51 --> Final output sent to browser
DEBUG - 2022-03-31 03:44:51 --> Total execution time: 0.2924
ERROR - 2022-03-31 03:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:44:51 --> Config Class Initialized
INFO - 2022-03-31 03:44:51 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:44:51 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:44:51 --> Utf8 Class Initialized
INFO - 2022-03-31 03:44:51 --> URI Class Initialized
INFO - 2022-03-31 03:44:51 --> Router Class Initialized
INFO - 2022-03-31 03:44:51 --> Output Class Initialized
INFO - 2022-03-31 03:44:51 --> Security Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:44:51 --> Input Class Initialized
INFO - 2022-03-31 03:44:51 --> Language Class Initialized
INFO - 2022-03-31 03:44:51 --> Loader Class Initialized
INFO - 2022-03-31 03:44:51 --> Helper loaded: url_helper
INFO - 2022-03-31 03:44:51 --> Helper loaded: form_helper
INFO - 2022-03-31 03:44:51 --> Helper loaded: common_helper
INFO - 2022-03-31 03:44:51 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:44:51 --> Controller Class Initialized
INFO - 2022-03-31 03:44:51 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:44:51 --> Encrypt Class Initialized
INFO - 2022-03-31 03:44:51 --> Model "Login_model" initialized
INFO - 2022-03-31 03:44:51 --> Model "Dashboard_model" initialized
INFO - 2022-03-31 03:44:51 --> Model "Case_model" initialized
INFO - 2022-03-31 03:44:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:44:52 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-31 03:44:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:44:52 --> Final output sent to browser
DEBUG - 2022-03-31 03:44:52 --> Total execution time: 0.2438
ERROR - 2022-03-31 03:45:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:45:07 --> Config Class Initialized
INFO - 2022-03-31 03:45:07 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:45:07 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:45:07 --> Utf8 Class Initialized
INFO - 2022-03-31 03:45:07 --> URI Class Initialized
INFO - 2022-03-31 03:45:07 --> Router Class Initialized
INFO - 2022-03-31 03:45:07 --> Output Class Initialized
INFO - 2022-03-31 03:45:07 --> Security Class Initialized
DEBUG - 2022-03-31 03:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:45:07 --> Input Class Initialized
INFO - 2022-03-31 03:45:07 --> Language Class Initialized
INFO - 2022-03-31 03:45:07 --> Loader Class Initialized
INFO - 2022-03-31 03:45:07 --> Helper loaded: url_helper
INFO - 2022-03-31 03:45:07 --> Helper loaded: form_helper
INFO - 2022-03-31 03:45:07 --> Helper loaded: common_helper
INFO - 2022-03-31 03:45:07 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:45:07 --> Controller Class Initialized
INFO - 2022-03-31 03:45:07 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:45:07 --> Encrypt Class Initialized
INFO - 2022-03-31 03:45:07 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:45:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:45:07 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:45:07 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:45:07 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:45:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:45:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 03:45:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:45:07 --> Final output sent to browser
DEBUG - 2022-03-31 03:45:07 --> Total execution time: 0.0603
ERROR - 2022-03-31 03:45:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:45:14 --> Config Class Initialized
INFO - 2022-03-31 03:45:14 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:45:14 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:45:14 --> Utf8 Class Initialized
INFO - 2022-03-31 03:45:14 --> URI Class Initialized
INFO - 2022-03-31 03:45:14 --> Router Class Initialized
INFO - 2022-03-31 03:45:14 --> Output Class Initialized
INFO - 2022-03-31 03:45:14 --> Security Class Initialized
DEBUG - 2022-03-31 03:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:45:14 --> Input Class Initialized
INFO - 2022-03-31 03:45:14 --> Language Class Initialized
INFO - 2022-03-31 03:45:14 --> Loader Class Initialized
INFO - 2022-03-31 03:45:14 --> Helper loaded: url_helper
INFO - 2022-03-31 03:45:14 --> Helper loaded: form_helper
INFO - 2022-03-31 03:45:14 --> Helper loaded: common_helper
INFO - 2022-03-31 03:45:14 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:45:14 --> Controller Class Initialized
INFO - 2022-03-31 03:45:14 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:45:14 --> Encrypt Class Initialized
INFO - 2022-03-31 03:45:14 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:45:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:45:14 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:45:14 --> Model "Users_model" initialized
INFO - 2022-03-31 03:45:14 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:45:14 --> Upload Class Initialized
INFO - 2022-03-31 03:45:14 --> Final output sent to browser
DEBUG - 2022-03-31 03:45:14 --> Total execution time: 0.2290
ERROR - 2022-03-31 03:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:45:19 --> Config Class Initialized
INFO - 2022-03-31 03:45:19 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:45:19 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:45:19 --> Utf8 Class Initialized
INFO - 2022-03-31 03:45:19 --> URI Class Initialized
INFO - 2022-03-31 03:45:19 --> Router Class Initialized
INFO - 2022-03-31 03:45:19 --> Output Class Initialized
INFO - 2022-03-31 03:45:19 --> Security Class Initialized
DEBUG - 2022-03-31 03:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:45:19 --> Input Class Initialized
INFO - 2022-03-31 03:45:19 --> Language Class Initialized
INFO - 2022-03-31 03:45:19 --> Loader Class Initialized
INFO - 2022-03-31 03:45:19 --> Helper loaded: url_helper
INFO - 2022-03-31 03:45:19 --> Helper loaded: form_helper
INFO - 2022-03-31 03:45:19 --> Helper loaded: common_helper
INFO - 2022-03-31 03:45:19 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:45:19 --> Controller Class Initialized
INFO - 2022-03-31 03:45:19 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:45:19 --> Encrypt Class Initialized
INFO - 2022-03-31 03:45:19 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:45:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:45:19 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:45:19 --> Model "Users_model" initialized
INFO - 2022-03-31 03:45:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 03:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:45:19 --> Config Class Initialized
INFO - 2022-03-31 03:45:19 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:45:19 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:45:19 --> Utf8 Class Initialized
INFO - 2022-03-31 03:45:19 --> URI Class Initialized
INFO - 2022-03-31 03:45:19 --> Router Class Initialized
INFO - 2022-03-31 03:45:19 --> Output Class Initialized
INFO - 2022-03-31 03:45:19 --> Security Class Initialized
DEBUG - 2022-03-31 03:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:45:19 --> Input Class Initialized
INFO - 2022-03-31 03:45:19 --> Language Class Initialized
INFO - 2022-03-31 03:45:19 --> Loader Class Initialized
INFO - 2022-03-31 03:45:19 --> Helper loaded: url_helper
INFO - 2022-03-31 03:45:19 --> Helper loaded: form_helper
INFO - 2022-03-31 03:45:19 --> Helper loaded: common_helper
INFO - 2022-03-31 03:45:19 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:45:19 --> Controller Class Initialized
INFO - 2022-03-31 03:45:19 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:45:19 --> Encrypt Class Initialized
INFO - 2022-03-31 03:45:19 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:45:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:45:19 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:45:19 --> Model "Users_model" initialized
INFO - 2022-03-31 03:45:19 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:45:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:45:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:45:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:45:19 --> Final output sent to browser
DEBUG - 2022-03-31 03:45:19 --> Total execution time: 0.0770
ERROR - 2022-03-31 03:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:45:21 --> Config Class Initialized
INFO - 2022-03-31 03:45:21 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:45:21 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:45:21 --> Utf8 Class Initialized
INFO - 2022-03-31 03:45:21 --> URI Class Initialized
INFO - 2022-03-31 03:45:21 --> Router Class Initialized
INFO - 2022-03-31 03:45:21 --> Output Class Initialized
INFO - 2022-03-31 03:45:21 --> Security Class Initialized
DEBUG - 2022-03-31 03:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:45:21 --> Input Class Initialized
INFO - 2022-03-31 03:45:21 --> Language Class Initialized
INFO - 2022-03-31 03:45:21 --> Loader Class Initialized
INFO - 2022-03-31 03:45:21 --> Helper loaded: url_helper
INFO - 2022-03-31 03:45:21 --> Helper loaded: form_helper
INFO - 2022-03-31 03:45:21 --> Helper loaded: common_helper
INFO - 2022-03-31 03:45:21 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:45:21 --> Controller Class Initialized
INFO - 2022-03-31 03:45:21 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:45:21 --> Encrypt Class Initialized
INFO - 2022-03-31 03:45:21 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:45:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:45:21 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:45:21 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:45:21 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:45:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:45:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 03:45:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:45:21 --> Final output sent to browser
DEBUG - 2022-03-31 03:45:21 --> Total execution time: 0.0697
ERROR - 2022-03-31 03:45:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:45:26 --> Config Class Initialized
INFO - 2022-03-31 03:45:26 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:45:26 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:45:26 --> Utf8 Class Initialized
INFO - 2022-03-31 03:45:26 --> URI Class Initialized
INFO - 2022-03-31 03:45:26 --> Router Class Initialized
INFO - 2022-03-31 03:45:26 --> Output Class Initialized
INFO - 2022-03-31 03:45:26 --> Security Class Initialized
DEBUG - 2022-03-31 03:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:45:26 --> Input Class Initialized
INFO - 2022-03-31 03:45:26 --> Language Class Initialized
INFO - 2022-03-31 03:45:26 --> Loader Class Initialized
INFO - 2022-03-31 03:45:26 --> Helper loaded: url_helper
INFO - 2022-03-31 03:45:26 --> Helper loaded: form_helper
INFO - 2022-03-31 03:45:26 --> Helper loaded: common_helper
INFO - 2022-03-31 03:45:26 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:45:26 --> Controller Class Initialized
INFO - 2022-03-31 03:45:26 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:45:26 --> Encrypt Class Initialized
INFO - 2022-03-31 03:45:26 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:45:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:45:26 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:45:26 --> Model "Users_model" initialized
INFO - 2022-03-31 03:45:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 03:45:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:45:26 --> Config Class Initialized
INFO - 2022-03-31 03:45:26 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:45:26 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:45:26 --> Utf8 Class Initialized
INFO - 2022-03-31 03:45:26 --> URI Class Initialized
INFO - 2022-03-31 03:45:26 --> Router Class Initialized
INFO - 2022-03-31 03:45:26 --> Output Class Initialized
INFO - 2022-03-31 03:45:26 --> Security Class Initialized
DEBUG - 2022-03-31 03:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:45:26 --> Input Class Initialized
INFO - 2022-03-31 03:45:26 --> Language Class Initialized
INFO - 2022-03-31 03:45:26 --> Loader Class Initialized
INFO - 2022-03-31 03:45:26 --> Helper loaded: url_helper
INFO - 2022-03-31 03:45:26 --> Helper loaded: form_helper
INFO - 2022-03-31 03:45:26 --> Helper loaded: common_helper
INFO - 2022-03-31 03:45:26 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:45:26 --> Controller Class Initialized
INFO - 2022-03-31 03:45:26 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:45:26 --> Encrypt Class Initialized
INFO - 2022-03-31 03:45:26 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:45:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:45:26 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:45:26 --> Model "Users_model" initialized
INFO - 2022-03-31 03:45:26 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:45:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:45:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:45:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:45:26 --> Final output sent to browser
DEBUG - 2022-03-31 03:45:26 --> Total execution time: 0.0428
ERROR - 2022-03-31 03:45:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:45:34 --> Config Class Initialized
INFO - 2022-03-31 03:45:34 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:45:34 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:45:34 --> Utf8 Class Initialized
INFO - 2022-03-31 03:45:34 --> URI Class Initialized
INFO - 2022-03-31 03:45:34 --> Router Class Initialized
INFO - 2022-03-31 03:45:34 --> Output Class Initialized
INFO - 2022-03-31 03:45:34 --> Security Class Initialized
DEBUG - 2022-03-31 03:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:45:34 --> Input Class Initialized
INFO - 2022-03-31 03:45:34 --> Language Class Initialized
INFO - 2022-03-31 03:45:34 --> Loader Class Initialized
INFO - 2022-03-31 03:45:34 --> Helper loaded: url_helper
INFO - 2022-03-31 03:45:34 --> Helper loaded: form_helper
INFO - 2022-03-31 03:45:34 --> Helper loaded: common_helper
INFO - 2022-03-31 03:45:34 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:45:34 --> Controller Class Initialized
INFO - 2022-03-31 03:45:34 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:45:34 --> Encrypt Class Initialized
INFO - 2022-03-31 03:45:34 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:45:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:45:34 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:45:34 --> Model "Users_model" initialized
INFO - 2022-03-31 03:45:34 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:45:35 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-31 03:45:37 --> Final output sent to browser
DEBUG - 2022-03-31 03:45:37 --> Total execution time: 2.3097
ERROR - 2022-03-31 03:46:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:46:02 --> Config Class Initialized
INFO - 2022-03-31 03:46:02 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:46:02 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:46:02 --> Utf8 Class Initialized
INFO - 2022-03-31 03:46:02 --> URI Class Initialized
INFO - 2022-03-31 03:46:02 --> Router Class Initialized
INFO - 2022-03-31 03:46:02 --> Output Class Initialized
INFO - 2022-03-31 03:46:02 --> Security Class Initialized
DEBUG - 2022-03-31 03:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:46:02 --> Input Class Initialized
INFO - 2022-03-31 03:46:02 --> Language Class Initialized
INFO - 2022-03-31 03:46:02 --> Loader Class Initialized
INFO - 2022-03-31 03:46:02 --> Helper loaded: url_helper
INFO - 2022-03-31 03:46:02 --> Helper loaded: form_helper
INFO - 2022-03-31 03:46:02 --> Helper loaded: common_helper
INFO - 2022-03-31 03:46:02 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:46:02 --> Controller Class Initialized
INFO - 2022-03-31 03:46:02 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:46:02 --> Encrypt Class Initialized
INFO - 2022-03-31 03:46:02 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:46:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:46:02 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:46:02 --> Model "Users_model" initialized
INFO - 2022-03-31 03:46:02 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:46:02 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-31 03:46:02 --> Final output sent to browser
DEBUG - 2022-03-31 03:46:02 --> Total execution time: 0.7246
ERROR - 2022-03-31 03:48:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:48:19 --> Config Class Initialized
INFO - 2022-03-31 03:48:19 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:48:19 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:48:19 --> Utf8 Class Initialized
INFO - 2022-03-31 03:48:19 --> URI Class Initialized
INFO - 2022-03-31 03:48:19 --> Router Class Initialized
INFO - 2022-03-31 03:48:19 --> Output Class Initialized
INFO - 2022-03-31 03:48:19 --> Security Class Initialized
DEBUG - 2022-03-31 03:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:48:19 --> Input Class Initialized
INFO - 2022-03-31 03:48:19 --> Language Class Initialized
INFO - 2022-03-31 03:48:19 --> Loader Class Initialized
INFO - 2022-03-31 03:48:19 --> Helper loaded: url_helper
INFO - 2022-03-31 03:48:19 --> Helper loaded: form_helper
INFO - 2022-03-31 03:48:19 --> Helper loaded: common_helper
INFO - 2022-03-31 03:48:19 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:48:19 --> Controller Class Initialized
INFO - 2022-03-31 03:48:19 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:48:19 --> Encrypt Class Initialized
INFO - 2022-03-31 03:48:19 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:48:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:48:19 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:48:19 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:48:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 03:48:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:48:19 --> Config Class Initialized
INFO - 2022-03-31 03:48:19 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:48:19 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:48:19 --> Utf8 Class Initialized
INFO - 2022-03-31 03:48:19 --> URI Class Initialized
INFO - 2022-03-31 03:48:19 --> Router Class Initialized
INFO - 2022-03-31 03:48:19 --> Output Class Initialized
INFO - 2022-03-31 03:48:19 --> Security Class Initialized
DEBUG - 2022-03-31 03:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:48:19 --> Input Class Initialized
INFO - 2022-03-31 03:48:19 --> Language Class Initialized
INFO - 2022-03-31 03:48:19 --> Loader Class Initialized
INFO - 2022-03-31 03:48:19 --> Helper loaded: url_helper
INFO - 2022-03-31 03:48:19 --> Helper loaded: form_helper
INFO - 2022-03-31 03:48:19 --> Helper loaded: common_helper
INFO - 2022-03-31 03:48:19 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:48:19 --> Controller Class Initialized
INFO - 2022-03-31 03:48:19 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:48:19 --> Encrypt Class Initialized
INFO - 2022-03-31 03:48:19 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:48:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:48:19 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:48:19 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:48:19 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:48:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:48:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 03:48:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:48:19 --> Final output sent to browser
DEBUG - 2022-03-31 03:48:19 --> Total execution time: 0.0389
ERROR - 2022-03-31 03:48:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:48:20 --> Config Class Initialized
INFO - 2022-03-31 03:48:20 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:48:20 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:48:20 --> Utf8 Class Initialized
INFO - 2022-03-31 03:48:20 --> URI Class Initialized
INFO - 2022-03-31 03:48:20 --> Router Class Initialized
INFO - 2022-03-31 03:48:20 --> Output Class Initialized
INFO - 2022-03-31 03:48:20 --> Security Class Initialized
DEBUG - 2022-03-31 03:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:48:20 --> Input Class Initialized
INFO - 2022-03-31 03:48:20 --> Language Class Initialized
INFO - 2022-03-31 03:48:20 --> Loader Class Initialized
INFO - 2022-03-31 03:48:20 --> Helper loaded: url_helper
INFO - 2022-03-31 03:48:20 --> Helper loaded: form_helper
INFO - 2022-03-31 03:48:20 --> Helper loaded: common_helper
INFO - 2022-03-31 03:48:20 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:48:20 --> Controller Class Initialized
INFO - 2022-03-31 03:48:20 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:48:20 --> Encrypt Class Initialized
INFO - 2022-03-31 03:48:20 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:48:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:48:20 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:48:20 --> Model "Users_model" initialized
INFO - 2022-03-31 03:48:20 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:48:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:48:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:48:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:48:20 --> Final output sent to browser
DEBUG - 2022-03-31 03:48:20 --> Total execution time: 0.0481
ERROR - 2022-03-31 03:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:49:26 --> Config Class Initialized
INFO - 2022-03-31 03:49:26 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:49:26 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:49:26 --> Utf8 Class Initialized
INFO - 2022-03-31 03:49:26 --> URI Class Initialized
INFO - 2022-03-31 03:49:26 --> Router Class Initialized
INFO - 2022-03-31 03:49:26 --> Output Class Initialized
INFO - 2022-03-31 03:49:26 --> Security Class Initialized
DEBUG - 2022-03-31 03:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:49:26 --> Input Class Initialized
INFO - 2022-03-31 03:49:26 --> Language Class Initialized
INFO - 2022-03-31 03:49:26 --> Loader Class Initialized
INFO - 2022-03-31 03:49:26 --> Helper loaded: url_helper
INFO - 2022-03-31 03:49:26 --> Helper loaded: form_helper
INFO - 2022-03-31 03:49:26 --> Helper loaded: common_helper
INFO - 2022-03-31 03:49:26 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:49:26 --> Controller Class Initialized
INFO - 2022-03-31 03:49:26 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:49:26 --> Encrypt Class Initialized
INFO - 2022-03-31 03:49:26 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:49:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:49:26 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:49:26 --> Model "Users_model" initialized
INFO - 2022-03-31 03:49:26 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 03:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:49:26 --> Config Class Initialized
INFO - 2022-03-31 03:49:26 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:49:26 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:49:26 --> Utf8 Class Initialized
INFO - 2022-03-31 03:49:26 --> URI Class Initialized
INFO - 2022-03-31 03:49:26 --> Router Class Initialized
INFO - 2022-03-31 03:49:26 --> Output Class Initialized
INFO - 2022-03-31 03:49:26 --> Security Class Initialized
DEBUG - 2022-03-31 03:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:49:26 --> Input Class Initialized
INFO - 2022-03-31 03:49:26 --> Language Class Initialized
INFO - 2022-03-31 03:49:26 --> Loader Class Initialized
INFO - 2022-03-31 03:49:26 --> Helper loaded: url_helper
INFO - 2022-03-31 03:49:26 --> Helper loaded: form_helper
INFO - 2022-03-31 03:49:26 --> Helper loaded: common_helper
INFO - 2022-03-31 03:49:26 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:49:26 --> Controller Class Initialized
INFO - 2022-03-31 03:49:26 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:49:26 --> Encrypt Class Initialized
INFO - 2022-03-31 03:49:26 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:49:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:49:26 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:49:26 --> Model "Users_model" initialized
INFO - 2022-03-31 03:49:26 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:49:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:49:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:49:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:49:26 --> Final output sent to browser
DEBUG - 2022-03-31 03:49:26 --> Total execution time: 0.0412
ERROR - 2022-03-31 03:51:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:51:01 --> Config Class Initialized
INFO - 2022-03-31 03:51:01 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:51:01 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:51:01 --> Utf8 Class Initialized
INFO - 2022-03-31 03:51:01 --> URI Class Initialized
INFO - 2022-03-31 03:51:01 --> Router Class Initialized
INFO - 2022-03-31 03:51:01 --> Output Class Initialized
INFO - 2022-03-31 03:51:01 --> Security Class Initialized
DEBUG - 2022-03-31 03:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:51:01 --> Input Class Initialized
INFO - 2022-03-31 03:51:01 --> Language Class Initialized
INFO - 2022-03-31 03:51:01 --> Loader Class Initialized
INFO - 2022-03-31 03:51:01 --> Helper loaded: url_helper
INFO - 2022-03-31 03:51:01 --> Helper loaded: form_helper
INFO - 2022-03-31 03:51:01 --> Helper loaded: common_helper
INFO - 2022-03-31 03:51:01 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:51:01 --> Controller Class Initialized
INFO - 2022-03-31 03:51:01 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:51:01 --> Encrypt Class Initialized
INFO - 2022-03-31 03:51:01 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:51:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:51:01 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:51:01 --> Model "Users_model" initialized
INFO - 2022-03-31 03:51:01 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 03:51:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:51:01 --> Config Class Initialized
INFO - 2022-03-31 03:51:01 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:51:01 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:51:01 --> Utf8 Class Initialized
INFO - 2022-03-31 03:51:01 --> URI Class Initialized
INFO - 2022-03-31 03:51:01 --> Router Class Initialized
INFO - 2022-03-31 03:51:01 --> Output Class Initialized
INFO - 2022-03-31 03:51:01 --> Security Class Initialized
DEBUG - 2022-03-31 03:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:51:01 --> Input Class Initialized
INFO - 2022-03-31 03:51:01 --> Language Class Initialized
INFO - 2022-03-31 03:51:01 --> Loader Class Initialized
INFO - 2022-03-31 03:51:01 --> Helper loaded: url_helper
INFO - 2022-03-31 03:51:01 --> Helper loaded: form_helper
INFO - 2022-03-31 03:51:01 --> Helper loaded: common_helper
INFO - 2022-03-31 03:51:01 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:51:01 --> Controller Class Initialized
INFO - 2022-03-31 03:51:01 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:51:01 --> Encrypt Class Initialized
INFO - 2022-03-31 03:51:01 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:51:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:51:01 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:51:01 --> Model "Users_model" initialized
INFO - 2022-03-31 03:51:01 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:51:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:51:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:51:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:51:01 --> Final output sent to browser
DEBUG - 2022-03-31 03:51:01 --> Total execution time: 0.0389
ERROR - 2022-03-31 03:52:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:52:04 --> Config Class Initialized
INFO - 2022-03-31 03:52:04 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:52:04 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:52:04 --> Utf8 Class Initialized
INFO - 2022-03-31 03:52:04 --> URI Class Initialized
INFO - 2022-03-31 03:52:04 --> Router Class Initialized
INFO - 2022-03-31 03:52:04 --> Output Class Initialized
INFO - 2022-03-31 03:52:04 --> Security Class Initialized
DEBUG - 2022-03-31 03:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:52:04 --> Input Class Initialized
INFO - 2022-03-31 03:52:04 --> Language Class Initialized
INFO - 2022-03-31 03:52:04 --> Loader Class Initialized
INFO - 2022-03-31 03:52:04 --> Helper loaded: url_helper
INFO - 2022-03-31 03:52:04 --> Helper loaded: form_helper
INFO - 2022-03-31 03:52:04 --> Helper loaded: common_helper
INFO - 2022-03-31 03:52:04 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:52:04 --> Controller Class Initialized
INFO - 2022-03-31 03:52:04 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:52:04 --> Encrypt Class Initialized
INFO - 2022-03-31 03:52:04 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:52:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:52:04 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:52:04 --> Model "Users_model" initialized
INFO - 2022-03-31 03:52:04 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:52:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:52:04 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:52:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:52:04 --> Final output sent to browser
DEBUG - 2022-03-31 03:52:04 --> Total execution time: 0.0530
ERROR - 2022-03-31 03:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:52:52 --> Config Class Initialized
INFO - 2022-03-31 03:52:52 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:52:52 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:52:52 --> Utf8 Class Initialized
INFO - 2022-03-31 03:52:52 --> URI Class Initialized
INFO - 2022-03-31 03:52:52 --> Router Class Initialized
INFO - 2022-03-31 03:52:52 --> Output Class Initialized
INFO - 2022-03-31 03:52:52 --> Security Class Initialized
DEBUG - 2022-03-31 03:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:52:52 --> Input Class Initialized
INFO - 2022-03-31 03:52:52 --> Language Class Initialized
INFO - 2022-03-31 03:52:52 --> Loader Class Initialized
INFO - 2022-03-31 03:52:52 --> Helper loaded: url_helper
INFO - 2022-03-31 03:52:52 --> Helper loaded: form_helper
INFO - 2022-03-31 03:52:52 --> Helper loaded: common_helper
INFO - 2022-03-31 03:52:52 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:52:52 --> Controller Class Initialized
INFO - 2022-03-31 03:52:52 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:52:52 --> Encrypt Class Initialized
INFO - 2022-03-31 03:52:52 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:52:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:52:52 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:52:52 --> Model "Users_model" initialized
INFO - 2022-03-31 03:52:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 03:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:52:52 --> Config Class Initialized
INFO - 2022-03-31 03:52:52 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:52:52 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:52:52 --> Utf8 Class Initialized
INFO - 2022-03-31 03:52:52 --> URI Class Initialized
INFO - 2022-03-31 03:52:52 --> Router Class Initialized
INFO - 2022-03-31 03:52:52 --> Output Class Initialized
INFO - 2022-03-31 03:52:52 --> Security Class Initialized
DEBUG - 2022-03-31 03:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:52:52 --> Input Class Initialized
INFO - 2022-03-31 03:52:52 --> Language Class Initialized
INFO - 2022-03-31 03:52:52 --> Loader Class Initialized
INFO - 2022-03-31 03:52:52 --> Helper loaded: url_helper
INFO - 2022-03-31 03:52:52 --> Helper loaded: form_helper
INFO - 2022-03-31 03:52:52 --> Helper loaded: common_helper
INFO - 2022-03-31 03:52:52 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:52:52 --> Controller Class Initialized
INFO - 2022-03-31 03:52:52 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:52:52 --> Encrypt Class Initialized
INFO - 2022-03-31 03:52:52 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:52:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:52:52 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:52:52 --> Model "Users_model" initialized
INFO - 2022-03-31 03:52:52 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:52:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:52:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:52:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:52:52 --> Final output sent to browser
DEBUG - 2022-03-31 03:52:52 --> Total execution time: 0.0575
ERROR - 2022-03-31 03:52:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:52:59 --> Config Class Initialized
INFO - 2022-03-31 03:52:59 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:52:59 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:52:59 --> Utf8 Class Initialized
INFO - 2022-03-31 03:52:59 --> URI Class Initialized
INFO - 2022-03-31 03:52:59 --> Router Class Initialized
INFO - 2022-03-31 03:52:59 --> Output Class Initialized
INFO - 2022-03-31 03:52:59 --> Security Class Initialized
DEBUG - 2022-03-31 03:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:52:59 --> Input Class Initialized
INFO - 2022-03-31 03:52:59 --> Language Class Initialized
INFO - 2022-03-31 03:52:59 --> Loader Class Initialized
INFO - 2022-03-31 03:52:59 --> Helper loaded: url_helper
INFO - 2022-03-31 03:52:59 --> Helper loaded: form_helper
INFO - 2022-03-31 03:52:59 --> Helper loaded: common_helper
INFO - 2022-03-31 03:52:59 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:52:59 --> Controller Class Initialized
INFO - 2022-03-31 03:52:59 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:52:59 --> Encrypt Class Initialized
INFO - 2022-03-31 03:52:59 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:52:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:52:59 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:52:59 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:52:59 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:52:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:52:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 03:52:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:52:59 --> Final output sent to browser
DEBUG - 2022-03-31 03:52:59 --> Total execution time: 0.1162
ERROR - 2022-03-31 03:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:53:11 --> Config Class Initialized
INFO - 2022-03-31 03:53:11 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:53:11 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:53:11 --> Utf8 Class Initialized
INFO - 2022-03-31 03:53:11 --> URI Class Initialized
INFO - 2022-03-31 03:53:11 --> Router Class Initialized
INFO - 2022-03-31 03:53:11 --> Output Class Initialized
INFO - 2022-03-31 03:53:11 --> Security Class Initialized
DEBUG - 2022-03-31 03:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:53:11 --> Input Class Initialized
INFO - 2022-03-31 03:53:11 --> Language Class Initialized
INFO - 2022-03-31 03:53:11 --> Loader Class Initialized
INFO - 2022-03-31 03:53:11 --> Helper loaded: url_helper
INFO - 2022-03-31 03:53:11 --> Helper loaded: form_helper
INFO - 2022-03-31 03:53:11 --> Helper loaded: common_helper
INFO - 2022-03-31 03:53:11 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:53:11 --> Controller Class Initialized
INFO - 2022-03-31 03:53:11 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:53:11 --> Encrypt Class Initialized
INFO - 2022-03-31 03:53:11 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:53:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:53:11 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:53:11 --> Model "Users_model" initialized
INFO - 2022-03-31 03:53:11 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:53:11 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-31 03:53:12 --> Final output sent to browser
DEBUG - 2022-03-31 03:53:12 --> Total execution time: 0.9307
ERROR - 2022-03-31 03:57:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:57:52 --> Config Class Initialized
INFO - 2022-03-31 03:57:52 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:57:52 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:57:52 --> Utf8 Class Initialized
INFO - 2022-03-31 03:57:52 --> URI Class Initialized
INFO - 2022-03-31 03:57:52 --> Router Class Initialized
INFO - 2022-03-31 03:57:52 --> Output Class Initialized
INFO - 2022-03-31 03:57:52 --> Security Class Initialized
DEBUG - 2022-03-31 03:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:57:52 --> Input Class Initialized
INFO - 2022-03-31 03:57:52 --> Language Class Initialized
INFO - 2022-03-31 03:57:52 --> Loader Class Initialized
INFO - 2022-03-31 03:57:52 --> Helper loaded: url_helper
INFO - 2022-03-31 03:57:52 --> Helper loaded: form_helper
INFO - 2022-03-31 03:57:52 --> Helper loaded: common_helper
INFO - 2022-03-31 03:57:52 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:57:52 --> Controller Class Initialized
INFO - 2022-03-31 03:57:52 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:57:52 --> Encrypt Class Initialized
INFO - 2022-03-31 03:57:52 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:57:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:57:52 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:57:52 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:57:52 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:57:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:57:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 03:57:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:57:52 --> Final output sent to browser
DEBUG - 2022-03-31 03:57:52 --> Total execution time: 0.0755
ERROR - 2022-03-31 03:58:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:58:14 --> Config Class Initialized
INFO - 2022-03-31 03:58:14 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:58:14 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:58:14 --> Utf8 Class Initialized
INFO - 2022-03-31 03:58:14 --> URI Class Initialized
INFO - 2022-03-31 03:58:14 --> Router Class Initialized
INFO - 2022-03-31 03:58:14 --> Output Class Initialized
INFO - 2022-03-31 03:58:14 --> Security Class Initialized
DEBUG - 2022-03-31 03:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:58:14 --> Input Class Initialized
INFO - 2022-03-31 03:58:14 --> Language Class Initialized
INFO - 2022-03-31 03:58:14 --> Loader Class Initialized
INFO - 2022-03-31 03:58:14 --> Helper loaded: url_helper
INFO - 2022-03-31 03:58:14 --> Helper loaded: form_helper
INFO - 2022-03-31 03:58:14 --> Helper loaded: common_helper
INFO - 2022-03-31 03:58:14 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:58:14 --> Controller Class Initialized
INFO - 2022-03-31 03:58:14 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:58:14 --> Encrypt Class Initialized
INFO - 2022-03-31 03:58:14 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:58:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:58:14 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:58:14 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:58:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 03:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:58:15 --> Config Class Initialized
INFO - 2022-03-31 03:58:15 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:58:15 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:58:15 --> Utf8 Class Initialized
INFO - 2022-03-31 03:58:15 --> URI Class Initialized
INFO - 2022-03-31 03:58:15 --> Router Class Initialized
INFO - 2022-03-31 03:58:15 --> Output Class Initialized
INFO - 2022-03-31 03:58:15 --> Security Class Initialized
DEBUG - 2022-03-31 03:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:58:15 --> Input Class Initialized
INFO - 2022-03-31 03:58:15 --> Language Class Initialized
INFO - 2022-03-31 03:58:15 --> Loader Class Initialized
INFO - 2022-03-31 03:58:15 --> Helper loaded: url_helper
INFO - 2022-03-31 03:58:15 --> Helper loaded: form_helper
INFO - 2022-03-31 03:58:15 --> Helper loaded: common_helper
INFO - 2022-03-31 03:58:15 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:58:15 --> Controller Class Initialized
INFO - 2022-03-31 03:58:15 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:58:15 --> Encrypt Class Initialized
INFO - 2022-03-31 03:58:15 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:58:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:58:15 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:58:15 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:58:15 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:58:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:58:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 03:58:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:58:15 --> Final output sent to browser
DEBUG - 2022-03-31 03:58:15 --> Total execution time: 0.0388
ERROR - 2022-03-31 03:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:58:15 --> Config Class Initialized
INFO - 2022-03-31 03:58:15 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:58:15 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:58:15 --> Utf8 Class Initialized
INFO - 2022-03-31 03:58:15 --> URI Class Initialized
INFO - 2022-03-31 03:58:15 --> Router Class Initialized
INFO - 2022-03-31 03:58:15 --> Output Class Initialized
INFO - 2022-03-31 03:58:15 --> Security Class Initialized
DEBUG - 2022-03-31 03:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:58:15 --> Input Class Initialized
INFO - 2022-03-31 03:58:15 --> Language Class Initialized
INFO - 2022-03-31 03:58:15 --> Loader Class Initialized
INFO - 2022-03-31 03:58:15 --> Helper loaded: url_helper
INFO - 2022-03-31 03:58:15 --> Helper loaded: form_helper
INFO - 2022-03-31 03:58:15 --> Helper loaded: common_helper
INFO - 2022-03-31 03:58:15 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:58:15 --> Controller Class Initialized
INFO - 2022-03-31 03:58:15 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:58:15 --> Encrypt Class Initialized
INFO - 2022-03-31 03:58:15 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:58:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:58:15 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:58:15 --> Model "Users_model" initialized
INFO - 2022-03-31 03:58:15 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:58:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:58:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:58:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:58:15 --> Final output sent to browser
DEBUG - 2022-03-31 03:58:15 --> Total execution time: 0.0491
ERROR - 2022-03-31 03:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:58:19 --> Config Class Initialized
INFO - 2022-03-31 03:58:19 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:58:19 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:58:19 --> Utf8 Class Initialized
INFO - 2022-03-31 03:58:19 --> URI Class Initialized
INFO - 2022-03-31 03:58:19 --> Router Class Initialized
INFO - 2022-03-31 03:58:19 --> Output Class Initialized
INFO - 2022-03-31 03:58:19 --> Security Class Initialized
DEBUG - 2022-03-31 03:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:58:19 --> Input Class Initialized
INFO - 2022-03-31 03:58:19 --> Language Class Initialized
INFO - 2022-03-31 03:58:19 --> Loader Class Initialized
INFO - 2022-03-31 03:58:19 --> Helper loaded: url_helper
INFO - 2022-03-31 03:58:19 --> Helper loaded: form_helper
INFO - 2022-03-31 03:58:19 --> Helper loaded: common_helper
INFO - 2022-03-31 03:58:19 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:58:19 --> Controller Class Initialized
INFO - 2022-03-31 03:58:19 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:58:19 --> Encrypt Class Initialized
INFO - 2022-03-31 03:58:19 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:58:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:58:19 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:58:19 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:58:19 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:58:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:58:19 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 03:58:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:58:19 --> Final output sent to browser
DEBUG - 2022-03-31 03:58:19 --> Total execution time: 0.0331
ERROR - 2022-03-31 03:59:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:59:05 --> Config Class Initialized
INFO - 2022-03-31 03:59:05 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:59:05 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:59:05 --> Utf8 Class Initialized
INFO - 2022-03-31 03:59:05 --> URI Class Initialized
INFO - 2022-03-31 03:59:05 --> Router Class Initialized
INFO - 2022-03-31 03:59:05 --> Output Class Initialized
INFO - 2022-03-31 03:59:05 --> Security Class Initialized
DEBUG - 2022-03-31 03:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:59:05 --> Input Class Initialized
INFO - 2022-03-31 03:59:05 --> Language Class Initialized
INFO - 2022-03-31 03:59:05 --> Loader Class Initialized
INFO - 2022-03-31 03:59:05 --> Helper loaded: url_helper
INFO - 2022-03-31 03:59:05 --> Helper loaded: form_helper
INFO - 2022-03-31 03:59:05 --> Helper loaded: common_helper
INFO - 2022-03-31 03:59:05 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:59:05 --> Controller Class Initialized
INFO - 2022-03-31 03:59:05 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:59:05 --> Encrypt Class Initialized
INFO - 2022-03-31 03:59:05 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:59:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:59:05 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:59:05 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:59:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 03:59:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:59:05 --> Config Class Initialized
INFO - 2022-03-31 03:59:05 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:59:05 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:59:05 --> Utf8 Class Initialized
INFO - 2022-03-31 03:59:05 --> URI Class Initialized
INFO - 2022-03-31 03:59:05 --> Router Class Initialized
INFO - 2022-03-31 03:59:05 --> Output Class Initialized
INFO - 2022-03-31 03:59:05 --> Security Class Initialized
DEBUG - 2022-03-31 03:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:59:05 --> Input Class Initialized
INFO - 2022-03-31 03:59:05 --> Language Class Initialized
INFO - 2022-03-31 03:59:05 --> Loader Class Initialized
INFO - 2022-03-31 03:59:05 --> Helper loaded: url_helper
INFO - 2022-03-31 03:59:05 --> Helper loaded: form_helper
INFO - 2022-03-31 03:59:05 --> Helper loaded: common_helper
INFO - 2022-03-31 03:59:05 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:59:05 --> Controller Class Initialized
INFO - 2022-03-31 03:59:05 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:59:05 --> Encrypt Class Initialized
INFO - 2022-03-31 03:59:05 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:59:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:59:05 --> Model "Referredby_model" initialized
INFO - 2022-03-31 03:59:05 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:59:05 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:59:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:59:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 03:59:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:59:05 --> Final output sent to browser
DEBUG - 2022-03-31 03:59:05 --> Total execution time: 0.0362
ERROR - 2022-03-31 03:59:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:59:06 --> Config Class Initialized
INFO - 2022-03-31 03:59:06 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:59:06 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:59:06 --> Utf8 Class Initialized
INFO - 2022-03-31 03:59:06 --> URI Class Initialized
INFO - 2022-03-31 03:59:06 --> Router Class Initialized
INFO - 2022-03-31 03:59:06 --> Output Class Initialized
INFO - 2022-03-31 03:59:06 --> Security Class Initialized
DEBUG - 2022-03-31 03:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:59:06 --> Input Class Initialized
INFO - 2022-03-31 03:59:06 --> Language Class Initialized
INFO - 2022-03-31 03:59:06 --> Loader Class Initialized
INFO - 2022-03-31 03:59:06 --> Helper loaded: url_helper
INFO - 2022-03-31 03:59:06 --> Helper loaded: form_helper
INFO - 2022-03-31 03:59:06 --> Helper loaded: common_helper
INFO - 2022-03-31 03:59:06 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:59:06 --> Controller Class Initialized
INFO - 2022-03-31 03:59:06 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:59:06 --> Encrypt Class Initialized
INFO - 2022-03-31 03:59:06 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:59:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:59:06 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:59:06 --> Model "Users_model" initialized
INFO - 2022-03-31 03:59:06 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:59:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:59:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:59:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:59:06 --> Final output sent to browser
DEBUG - 2022-03-31 03:59:06 --> Total execution time: 0.0439
ERROR - 2022-03-31 03:59:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:59:23 --> Config Class Initialized
INFO - 2022-03-31 03:59:23 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:59:23 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:59:23 --> Utf8 Class Initialized
INFO - 2022-03-31 03:59:23 --> URI Class Initialized
INFO - 2022-03-31 03:59:23 --> Router Class Initialized
INFO - 2022-03-31 03:59:23 --> Output Class Initialized
INFO - 2022-03-31 03:59:23 --> Security Class Initialized
DEBUG - 2022-03-31 03:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:59:23 --> Input Class Initialized
INFO - 2022-03-31 03:59:23 --> Language Class Initialized
INFO - 2022-03-31 03:59:23 --> Loader Class Initialized
INFO - 2022-03-31 03:59:23 --> Helper loaded: url_helper
INFO - 2022-03-31 03:59:23 --> Helper loaded: form_helper
INFO - 2022-03-31 03:59:23 --> Helper loaded: common_helper
INFO - 2022-03-31 03:59:23 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:59:23 --> Controller Class Initialized
INFO - 2022-03-31 03:59:23 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:59:23 --> Encrypt Class Initialized
INFO - 2022-03-31 03:59:23 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:59:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:59:23 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:59:23 --> Model "Users_model" initialized
INFO - 2022-03-31 03:59:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 03:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 03:59:24 --> Config Class Initialized
INFO - 2022-03-31 03:59:24 --> Hooks Class Initialized
DEBUG - 2022-03-31 03:59:24 --> UTF-8 Support Enabled
INFO - 2022-03-31 03:59:24 --> Utf8 Class Initialized
INFO - 2022-03-31 03:59:24 --> URI Class Initialized
INFO - 2022-03-31 03:59:24 --> Router Class Initialized
INFO - 2022-03-31 03:59:24 --> Output Class Initialized
INFO - 2022-03-31 03:59:24 --> Security Class Initialized
DEBUG - 2022-03-31 03:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 03:59:24 --> Input Class Initialized
INFO - 2022-03-31 03:59:24 --> Language Class Initialized
INFO - 2022-03-31 03:59:24 --> Loader Class Initialized
INFO - 2022-03-31 03:59:24 --> Helper loaded: url_helper
INFO - 2022-03-31 03:59:24 --> Helper loaded: form_helper
INFO - 2022-03-31 03:59:24 --> Helper loaded: common_helper
INFO - 2022-03-31 03:59:24 --> Database Driver Class Initialized
DEBUG - 2022-03-31 03:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 03:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 03:59:24 --> Controller Class Initialized
INFO - 2022-03-31 03:59:24 --> Form Validation Class Initialized
DEBUG - 2022-03-31 03:59:24 --> Encrypt Class Initialized
INFO - 2022-03-31 03:59:24 --> Model "Patient_model" initialized
INFO - 2022-03-31 03:59:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 03:59:24 --> Model "Prefix_master" initialized
INFO - 2022-03-31 03:59:24 --> Model "Users_model" initialized
INFO - 2022-03-31 03:59:24 --> Model "Hospital_model" initialized
INFO - 2022-03-31 03:59:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 03:59:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 03:59:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 03:59:24 --> Final output sent to browser
DEBUG - 2022-03-31 03:59:24 --> Total execution time: 0.0366
ERROR - 2022-03-31 04:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 04:24:20 --> Config Class Initialized
INFO - 2022-03-31 04:24:20 --> Hooks Class Initialized
DEBUG - 2022-03-31 04:24:20 --> UTF-8 Support Enabled
INFO - 2022-03-31 04:24:20 --> Utf8 Class Initialized
INFO - 2022-03-31 04:24:20 --> URI Class Initialized
INFO - 2022-03-31 04:24:20 --> Router Class Initialized
INFO - 2022-03-31 04:24:20 --> Output Class Initialized
INFO - 2022-03-31 04:24:20 --> Security Class Initialized
DEBUG - 2022-03-31 04:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 04:24:20 --> Input Class Initialized
INFO - 2022-03-31 04:24:20 --> Language Class Initialized
INFO - 2022-03-31 04:24:20 --> Loader Class Initialized
INFO - 2022-03-31 04:24:20 --> Helper loaded: url_helper
INFO - 2022-03-31 04:24:20 --> Helper loaded: form_helper
INFO - 2022-03-31 04:24:20 --> Helper loaded: common_helper
INFO - 2022-03-31 04:24:20 --> Database Driver Class Initialized
DEBUG - 2022-03-31 04:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 04:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 04:24:20 --> Controller Class Initialized
INFO - 2022-03-31 04:24:20 --> Form Validation Class Initialized
DEBUG - 2022-03-31 04:24:20 --> Encrypt Class Initialized
INFO - 2022-03-31 04:24:20 --> Model "Patient_model" initialized
INFO - 2022-03-31 04:24:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 04:24:20 --> Model "Prefix_master" initialized
INFO - 2022-03-31 04:24:20 --> Model "Users_model" initialized
INFO - 2022-03-31 04:24:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 04:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 04:24:20 --> Config Class Initialized
INFO - 2022-03-31 04:24:20 --> Hooks Class Initialized
DEBUG - 2022-03-31 04:24:20 --> UTF-8 Support Enabled
INFO - 2022-03-31 04:24:20 --> Utf8 Class Initialized
INFO - 2022-03-31 04:24:20 --> URI Class Initialized
INFO - 2022-03-31 04:24:20 --> Router Class Initialized
INFO - 2022-03-31 04:24:20 --> Output Class Initialized
INFO - 2022-03-31 04:24:20 --> Security Class Initialized
DEBUG - 2022-03-31 04:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 04:24:20 --> Input Class Initialized
INFO - 2022-03-31 04:24:20 --> Language Class Initialized
INFO - 2022-03-31 04:24:20 --> Loader Class Initialized
INFO - 2022-03-31 04:24:20 --> Helper loaded: url_helper
INFO - 2022-03-31 04:24:20 --> Helper loaded: form_helper
INFO - 2022-03-31 04:24:20 --> Helper loaded: common_helper
INFO - 2022-03-31 04:24:20 --> Database Driver Class Initialized
DEBUG - 2022-03-31 04:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 04:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 04:24:20 --> Controller Class Initialized
INFO - 2022-03-31 04:24:20 --> Form Validation Class Initialized
DEBUG - 2022-03-31 04:24:20 --> Encrypt Class Initialized
INFO - 2022-03-31 04:24:20 --> Model "Patient_model" initialized
INFO - 2022-03-31 04:24:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 04:24:20 --> Model "Prefix_master" initialized
INFO - 2022-03-31 04:24:20 --> Model "Users_model" initialized
INFO - 2022-03-31 04:24:20 --> Model "Hospital_model" initialized
INFO - 2022-03-31 04:24:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 04:24:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 04:24:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 04:24:21 --> Final output sent to browser
DEBUG - 2022-03-31 04:24:21 --> Total execution time: 0.0504
ERROR - 2022-03-31 04:24:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 04:24:27 --> Config Class Initialized
INFO - 2022-03-31 04:24:27 --> Hooks Class Initialized
DEBUG - 2022-03-31 04:24:27 --> UTF-8 Support Enabled
INFO - 2022-03-31 04:24:27 --> Utf8 Class Initialized
INFO - 2022-03-31 04:24:27 --> URI Class Initialized
INFO - 2022-03-31 04:24:27 --> Router Class Initialized
INFO - 2022-03-31 04:24:27 --> Output Class Initialized
INFO - 2022-03-31 04:24:27 --> Security Class Initialized
DEBUG - 2022-03-31 04:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 04:24:27 --> Input Class Initialized
INFO - 2022-03-31 04:24:27 --> Language Class Initialized
INFO - 2022-03-31 04:24:27 --> Loader Class Initialized
INFO - 2022-03-31 04:24:27 --> Helper loaded: url_helper
INFO - 2022-03-31 04:24:27 --> Helper loaded: form_helper
INFO - 2022-03-31 04:24:27 --> Helper loaded: common_helper
INFO - 2022-03-31 04:24:27 --> Database Driver Class Initialized
DEBUG - 2022-03-31 04:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 04:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 04:24:27 --> Controller Class Initialized
INFO - 2022-03-31 04:24:27 --> Form Validation Class Initialized
DEBUG - 2022-03-31 04:24:27 --> Encrypt Class Initialized
INFO - 2022-03-31 04:24:27 --> Model "Patient_model" initialized
INFO - 2022-03-31 04:24:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 04:24:27 --> Model "Prefix_master" initialized
INFO - 2022-03-31 04:24:27 --> Model "Users_model" initialized
INFO - 2022-03-31 04:24:27 --> Model "Hospital_model" initialized
INFO - 2022-03-31 04:24:27 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-31 04:24:28 --> Final output sent to browser
DEBUG - 2022-03-31 04:24:28 --> Total execution time: 1.1194
ERROR - 2022-03-31 04:30:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 04:30:47 --> Config Class Initialized
INFO - 2022-03-31 04:30:47 --> Hooks Class Initialized
DEBUG - 2022-03-31 04:30:47 --> UTF-8 Support Enabled
INFO - 2022-03-31 04:30:47 --> Utf8 Class Initialized
INFO - 2022-03-31 04:30:47 --> URI Class Initialized
INFO - 2022-03-31 04:30:47 --> Router Class Initialized
INFO - 2022-03-31 04:30:47 --> Output Class Initialized
INFO - 2022-03-31 04:30:47 --> Security Class Initialized
DEBUG - 2022-03-31 04:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 04:30:47 --> Input Class Initialized
INFO - 2022-03-31 04:30:47 --> Language Class Initialized
INFO - 2022-03-31 04:30:47 --> Loader Class Initialized
INFO - 2022-03-31 04:30:47 --> Helper loaded: url_helper
INFO - 2022-03-31 04:30:47 --> Helper loaded: form_helper
INFO - 2022-03-31 04:30:47 --> Helper loaded: common_helper
INFO - 2022-03-31 04:30:47 --> Database Driver Class Initialized
DEBUG - 2022-03-31 04:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 04:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 04:30:47 --> Controller Class Initialized
INFO - 2022-03-31 04:30:48 --> Form Validation Class Initialized
DEBUG - 2022-03-31 04:30:48 --> Encrypt Class Initialized
INFO - 2022-03-31 04:30:48 --> Model "Patient_model" initialized
INFO - 2022-03-31 04:30:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 04:30:48 --> Model "Referredby_model" initialized
INFO - 2022-03-31 04:30:48 --> Model "Prefix_master" initialized
INFO - 2022-03-31 04:30:48 --> Model "Hospital_model" initialized
INFO - 2022-03-31 04:30:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 04:30:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 04:30:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 04:30:48 --> Final output sent to browser
DEBUG - 2022-03-31 04:30:48 --> Total execution time: 0.1175
ERROR - 2022-03-31 04:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 04:30:58 --> Config Class Initialized
INFO - 2022-03-31 04:30:58 --> Hooks Class Initialized
DEBUG - 2022-03-31 04:30:58 --> UTF-8 Support Enabled
INFO - 2022-03-31 04:30:58 --> Utf8 Class Initialized
INFO - 2022-03-31 04:30:58 --> URI Class Initialized
INFO - 2022-03-31 04:30:58 --> Router Class Initialized
INFO - 2022-03-31 04:30:58 --> Output Class Initialized
INFO - 2022-03-31 04:30:58 --> Security Class Initialized
DEBUG - 2022-03-31 04:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 04:30:58 --> Input Class Initialized
INFO - 2022-03-31 04:30:58 --> Language Class Initialized
INFO - 2022-03-31 04:30:58 --> Loader Class Initialized
INFO - 2022-03-31 04:30:58 --> Helper loaded: url_helper
INFO - 2022-03-31 04:30:58 --> Helper loaded: form_helper
INFO - 2022-03-31 04:30:58 --> Helper loaded: common_helper
INFO - 2022-03-31 04:30:58 --> Database Driver Class Initialized
DEBUG - 2022-03-31 04:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 04:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 04:30:58 --> Controller Class Initialized
INFO - 2022-03-31 04:30:58 --> Form Validation Class Initialized
DEBUG - 2022-03-31 04:30:58 --> Encrypt Class Initialized
INFO - 2022-03-31 04:30:58 --> Model "Patient_model" initialized
INFO - 2022-03-31 04:30:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 04:30:58 --> Model "Prefix_master" initialized
INFO - 2022-03-31 04:30:58 --> Model "Users_model" initialized
INFO - 2022-03-31 04:30:58 --> Model "Hospital_model" initialized
INFO - 2022-03-31 04:30:58 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-31 04:30:59 --> Final output sent to browser
DEBUG - 2022-03-31 04:30:59 --> Total execution time: 1.0376
ERROR - 2022-03-31 04:32:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 04:32:24 --> Config Class Initialized
INFO - 2022-03-31 04:32:24 --> Hooks Class Initialized
DEBUG - 2022-03-31 04:32:24 --> UTF-8 Support Enabled
INFO - 2022-03-31 04:32:24 --> Utf8 Class Initialized
INFO - 2022-03-31 04:32:24 --> URI Class Initialized
INFO - 2022-03-31 04:32:24 --> Router Class Initialized
INFO - 2022-03-31 04:32:24 --> Output Class Initialized
INFO - 2022-03-31 04:32:24 --> Security Class Initialized
DEBUG - 2022-03-31 04:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 04:32:24 --> Input Class Initialized
INFO - 2022-03-31 04:32:24 --> Language Class Initialized
INFO - 2022-03-31 04:32:24 --> Loader Class Initialized
INFO - 2022-03-31 04:32:24 --> Helper loaded: url_helper
INFO - 2022-03-31 04:32:24 --> Helper loaded: form_helper
INFO - 2022-03-31 04:32:24 --> Helper loaded: common_helper
INFO - 2022-03-31 04:32:24 --> Database Driver Class Initialized
DEBUG - 2022-03-31 04:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 04:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 04:32:24 --> Controller Class Initialized
INFO - 2022-03-31 04:32:24 --> Form Validation Class Initialized
DEBUG - 2022-03-31 04:32:24 --> Encrypt Class Initialized
INFO - 2022-03-31 04:32:24 --> Model "Patient_model" initialized
INFO - 2022-03-31 04:32:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 04:32:24 --> Model "Prefix_master" initialized
INFO - 2022-03-31 04:32:24 --> Model "Users_model" initialized
INFO - 2022-03-31 04:32:24 --> Model "Hospital_model" initialized
INFO - 2022-03-31 04:32:24 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-31 04:32:25 --> Final output sent to browser
DEBUG - 2022-03-31 04:32:25 --> Total execution time: 0.6152
ERROR - 2022-03-31 05:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:17:25 --> Config Class Initialized
INFO - 2022-03-31 05:17:25 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:17:25 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:17:25 --> Utf8 Class Initialized
INFO - 2022-03-31 05:17:25 --> URI Class Initialized
INFO - 2022-03-31 05:17:25 --> Router Class Initialized
INFO - 2022-03-31 05:17:25 --> Output Class Initialized
INFO - 2022-03-31 05:17:25 --> Security Class Initialized
DEBUG - 2022-03-31 05:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:17:25 --> Input Class Initialized
INFO - 2022-03-31 05:17:25 --> Language Class Initialized
INFO - 2022-03-31 05:17:25 --> Loader Class Initialized
INFO - 2022-03-31 05:17:25 --> Helper loaded: url_helper
INFO - 2022-03-31 05:17:25 --> Helper loaded: form_helper
INFO - 2022-03-31 05:17:25 --> Helper loaded: common_helper
INFO - 2022-03-31 05:17:25 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:17:25 --> Controller Class Initialized
INFO - 2022-03-31 05:17:25 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:17:25 --> Encrypt Class Initialized
INFO - 2022-03-31 05:17:25 --> Model "Patient_model" initialized
INFO - 2022-03-31 05:17:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 05:17:25 --> Model "Referredby_model" initialized
INFO - 2022-03-31 05:17:25 --> Model "Prefix_master" initialized
INFO - 2022-03-31 05:17:25 --> Model "Hospital_model" initialized
INFO - 2022-03-31 05:17:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 05:17:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 05:17:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 05:17:25 --> Final output sent to browser
DEBUG - 2022-03-31 05:17:25 --> Total execution time: 0.1146
ERROR - 2022-03-31 05:38:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:38:17 --> Config Class Initialized
INFO - 2022-03-31 05:38:17 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:38:17 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:38:17 --> Utf8 Class Initialized
INFO - 2022-03-31 05:38:17 --> URI Class Initialized
DEBUG - 2022-03-31 05:38:17 --> No URI present. Default controller set.
INFO - 2022-03-31 05:38:17 --> Router Class Initialized
INFO - 2022-03-31 05:38:17 --> Output Class Initialized
INFO - 2022-03-31 05:38:17 --> Security Class Initialized
DEBUG - 2022-03-31 05:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:38:17 --> Input Class Initialized
INFO - 2022-03-31 05:38:17 --> Language Class Initialized
INFO - 2022-03-31 05:38:17 --> Loader Class Initialized
INFO - 2022-03-31 05:38:17 --> Helper loaded: url_helper
INFO - 2022-03-31 05:38:17 --> Helper loaded: form_helper
INFO - 2022-03-31 05:38:17 --> Helper loaded: common_helper
INFO - 2022-03-31 05:38:17 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:38:17 --> Controller Class Initialized
INFO - 2022-03-31 05:38:17 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:38:17 --> Encrypt Class Initialized
DEBUG - 2022-03-31 05:38:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 05:38:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 05:38:17 --> Email Class Initialized
INFO - 2022-03-31 05:38:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 05:38:17 --> Calendar Class Initialized
INFO - 2022-03-31 05:38:17 --> Model "Login_model" initialized
INFO - 2022-03-31 05:38:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 05:38:17 --> Final output sent to browser
DEBUG - 2022-03-31 05:38:17 --> Total execution time: 0.0548
ERROR - 2022-03-31 05:38:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:38:22 --> Config Class Initialized
INFO - 2022-03-31 05:38:22 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:38:22 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:38:22 --> Utf8 Class Initialized
INFO - 2022-03-31 05:38:22 --> URI Class Initialized
INFO - 2022-03-31 05:38:22 --> Router Class Initialized
INFO - 2022-03-31 05:38:22 --> Output Class Initialized
INFO - 2022-03-31 05:38:22 --> Security Class Initialized
DEBUG - 2022-03-31 05:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:38:22 --> Input Class Initialized
INFO - 2022-03-31 05:38:22 --> Language Class Initialized
INFO - 2022-03-31 05:38:22 --> Loader Class Initialized
INFO - 2022-03-31 05:38:22 --> Helper loaded: url_helper
INFO - 2022-03-31 05:38:22 --> Helper loaded: form_helper
INFO - 2022-03-31 05:38:22 --> Helper loaded: common_helper
INFO - 2022-03-31 05:38:22 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:38:22 --> Controller Class Initialized
INFO - 2022-03-31 05:38:22 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:38:22 --> Encrypt Class Initialized
DEBUG - 2022-03-31 05:38:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 05:38:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 05:38:22 --> Email Class Initialized
INFO - 2022-03-31 05:38:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 05:38:22 --> Calendar Class Initialized
INFO - 2022-03-31 05:38:22 --> Model "Login_model" initialized
INFO - 2022-03-31 05:38:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-31 05:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:38:23 --> Config Class Initialized
INFO - 2022-03-31 05:38:23 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:38:23 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:38:23 --> Utf8 Class Initialized
INFO - 2022-03-31 05:38:23 --> URI Class Initialized
INFO - 2022-03-31 05:38:23 --> Router Class Initialized
INFO - 2022-03-31 05:38:23 --> Output Class Initialized
INFO - 2022-03-31 05:38:23 --> Security Class Initialized
DEBUG - 2022-03-31 05:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:38:23 --> Input Class Initialized
INFO - 2022-03-31 05:38:23 --> Language Class Initialized
INFO - 2022-03-31 05:38:23 --> Loader Class Initialized
INFO - 2022-03-31 05:38:23 --> Helper loaded: url_helper
INFO - 2022-03-31 05:38:23 --> Helper loaded: form_helper
INFO - 2022-03-31 05:38:23 --> Helper loaded: common_helper
INFO - 2022-03-31 05:38:23 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:38:23 --> Controller Class Initialized
INFO - 2022-03-31 05:38:23 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:38:23 --> Encrypt Class Initialized
INFO - 2022-03-31 05:38:23 --> Model "Login_model" initialized
INFO - 2022-03-31 05:38:23 --> Model "Dashboard_model" initialized
INFO - 2022-03-31 05:38:23 --> Model "Case_model" initialized
INFO - 2022-03-31 05:38:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 05:38:43 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-31 05:38:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 05:38:43 --> Final output sent to browser
DEBUG - 2022-03-31 05:38:43 --> Total execution time: 20.7263
ERROR - 2022-03-31 05:39:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:39:24 --> Config Class Initialized
INFO - 2022-03-31 05:39:24 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:39:24 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:39:24 --> Utf8 Class Initialized
INFO - 2022-03-31 05:39:24 --> URI Class Initialized
INFO - 2022-03-31 05:39:24 --> Router Class Initialized
INFO - 2022-03-31 05:39:24 --> Output Class Initialized
INFO - 2022-03-31 05:39:24 --> Security Class Initialized
DEBUG - 2022-03-31 05:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:39:24 --> Input Class Initialized
INFO - 2022-03-31 05:39:24 --> Language Class Initialized
INFO - 2022-03-31 05:39:24 --> Loader Class Initialized
INFO - 2022-03-31 05:39:24 --> Helper loaded: url_helper
INFO - 2022-03-31 05:39:24 --> Helper loaded: form_helper
INFO - 2022-03-31 05:39:24 --> Helper loaded: common_helper
INFO - 2022-03-31 05:39:24 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:39:24 --> Controller Class Initialized
INFO - 2022-03-31 05:39:24 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:39:24 --> Encrypt Class Initialized
INFO - 2022-03-31 05:39:24 --> Model "Patient_model" initialized
INFO - 2022-03-31 05:39:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 05:39:24 --> Model "Prefix_master" initialized
INFO - 2022-03-31 05:39:24 --> Model "Users_model" initialized
INFO - 2022-03-31 05:39:24 --> Model "Hospital_model" initialized
INFO - 2022-03-31 05:39:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 05:39:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 05:39:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 05:39:24 --> Final output sent to browser
DEBUG - 2022-03-31 05:39:24 --> Total execution time: 0.0856
ERROR - 2022-03-31 05:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:40:32 --> Config Class Initialized
INFO - 2022-03-31 05:40:32 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:40:32 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:40:32 --> Utf8 Class Initialized
INFO - 2022-03-31 05:40:32 --> URI Class Initialized
INFO - 2022-03-31 05:40:32 --> Router Class Initialized
INFO - 2022-03-31 05:40:32 --> Output Class Initialized
INFO - 2022-03-31 05:40:32 --> Security Class Initialized
DEBUG - 2022-03-31 05:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:40:32 --> Input Class Initialized
INFO - 2022-03-31 05:40:32 --> Language Class Initialized
INFO - 2022-03-31 05:40:32 --> Loader Class Initialized
INFO - 2022-03-31 05:40:32 --> Helper loaded: url_helper
INFO - 2022-03-31 05:40:32 --> Helper loaded: form_helper
INFO - 2022-03-31 05:40:32 --> Helper loaded: common_helper
INFO - 2022-03-31 05:40:32 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:40:32 --> Controller Class Initialized
INFO - 2022-03-31 05:40:32 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:40:32 --> Encrypt Class Initialized
INFO - 2022-03-31 05:40:32 --> Model "Patient_model" initialized
INFO - 2022-03-31 05:40:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 05:40:32 --> Model "Prefix_master" initialized
INFO - 2022-03-31 05:40:32 --> Model "Users_model" initialized
INFO - 2022-03-31 05:40:32 --> Model "Hospital_model" initialized
INFO - 2022-03-31 05:40:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 05:40:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 05:40:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 05:40:32 --> Final output sent to browser
DEBUG - 2022-03-31 05:40:32 --> Total execution time: 0.0433
ERROR - 2022-03-31 05:40:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:40:59 --> Config Class Initialized
INFO - 2022-03-31 05:40:59 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:40:59 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:40:59 --> Utf8 Class Initialized
INFO - 2022-03-31 05:40:59 --> URI Class Initialized
INFO - 2022-03-31 05:40:59 --> Router Class Initialized
INFO - 2022-03-31 05:40:59 --> Output Class Initialized
INFO - 2022-03-31 05:40:59 --> Security Class Initialized
DEBUG - 2022-03-31 05:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:40:59 --> Input Class Initialized
INFO - 2022-03-31 05:40:59 --> Language Class Initialized
INFO - 2022-03-31 05:40:59 --> Loader Class Initialized
INFO - 2022-03-31 05:40:59 --> Helper loaded: url_helper
INFO - 2022-03-31 05:40:59 --> Helper loaded: form_helper
INFO - 2022-03-31 05:40:59 --> Helper loaded: common_helper
INFO - 2022-03-31 05:40:59 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:40:59 --> Controller Class Initialized
INFO - 2022-03-31 05:40:59 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:40:59 --> Encrypt Class Initialized
INFO - 2022-03-31 05:40:59 --> Model "Patient_model" initialized
INFO - 2022-03-31 05:40:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 05:40:59 --> Model "Referredby_model" initialized
INFO - 2022-03-31 05:40:59 --> Model "Prefix_master" initialized
INFO - 2022-03-31 05:40:59 --> Model "Hospital_model" initialized
INFO - 2022-03-31 05:40:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 05:41:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 05:41:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 05:41:09 --> Final output sent to browser
DEBUG - 2022-03-31 05:41:09 --> Total execution time: 7.3911
ERROR - 2022-03-31 05:42:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:42:08 --> Config Class Initialized
INFO - 2022-03-31 05:42:08 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:42:08 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:42:08 --> Utf8 Class Initialized
INFO - 2022-03-31 05:42:08 --> URI Class Initialized
INFO - 2022-03-31 05:42:08 --> Router Class Initialized
INFO - 2022-03-31 05:42:08 --> Output Class Initialized
INFO - 2022-03-31 05:42:08 --> Security Class Initialized
DEBUG - 2022-03-31 05:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:42:08 --> Input Class Initialized
INFO - 2022-03-31 05:42:08 --> Language Class Initialized
INFO - 2022-03-31 05:42:08 --> Loader Class Initialized
INFO - 2022-03-31 05:42:08 --> Helper loaded: url_helper
INFO - 2022-03-31 05:42:08 --> Helper loaded: form_helper
INFO - 2022-03-31 05:42:08 --> Helper loaded: common_helper
INFO - 2022-03-31 05:42:08 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:42:08 --> Controller Class Initialized
INFO - 2022-03-31 05:42:08 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:42:08 --> Encrypt Class Initialized
INFO - 2022-03-31 05:42:08 --> Model "Patient_model" initialized
INFO - 2022-03-31 05:42:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 05:42:08 --> Model "Prefix_master" initialized
INFO - 2022-03-31 05:42:08 --> Model "Users_model" initialized
INFO - 2022-03-31 05:42:08 --> Model "Hospital_model" initialized
INFO - 2022-03-31 05:42:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 05:42:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 05:42:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 05:42:08 --> Final output sent to browser
DEBUG - 2022-03-31 05:42:08 --> Total execution time: 0.0395
ERROR - 2022-03-31 05:42:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:42:55 --> Config Class Initialized
INFO - 2022-03-31 05:42:55 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:42:55 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:42:55 --> Utf8 Class Initialized
INFO - 2022-03-31 05:42:55 --> URI Class Initialized
INFO - 2022-03-31 05:42:55 --> Router Class Initialized
INFO - 2022-03-31 05:42:55 --> Output Class Initialized
INFO - 2022-03-31 05:42:55 --> Security Class Initialized
DEBUG - 2022-03-31 05:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:42:55 --> Input Class Initialized
INFO - 2022-03-31 05:42:55 --> Language Class Initialized
INFO - 2022-03-31 05:42:55 --> Loader Class Initialized
INFO - 2022-03-31 05:42:55 --> Helper loaded: url_helper
INFO - 2022-03-31 05:42:55 --> Helper loaded: form_helper
INFO - 2022-03-31 05:42:55 --> Helper loaded: common_helper
INFO - 2022-03-31 05:42:55 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:42:55 --> Controller Class Initialized
INFO - 2022-03-31 05:42:55 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:42:55 --> Encrypt Class Initialized
INFO - 2022-03-31 05:42:55 --> Model "Patient_model" initialized
INFO - 2022-03-31 05:42:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 05:42:55 --> Model "Prefix_master" initialized
INFO - 2022-03-31 05:42:55 --> Model "Users_model" initialized
INFO - 2022-03-31 05:42:55 --> Model "Hospital_model" initialized
INFO - 2022-03-31 05:42:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 05:42:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 05:42:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 05:42:55 --> Final output sent to browser
DEBUG - 2022-03-31 05:42:55 --> Total execution time: 0.0459
ERROR - 2022-03-31 05:43:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:43:58 --> Config Class Initialized
INFO - 2022-03-31 05:43:58 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:43:58 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:43:58 --> Utf8 Class Initialized
INFO - 2022-03-31 05:43:58 --> URI Class Initialized
INFO - 2022-03-31 05:43:58 --> Router Class Initialized
INFO - 2022-03-31 05:43:58 --> Output Class Initialized
INFO - 2022-03-31 05:43:58 --> Security Class Initialized
DEBUG - 2022-03-31 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:43:58 --> Input Class Initialized
INFO - 2022-03-31 05:43:58 --> Language Class Initialized
INFO - 2022-03-31 05:43:58 --> Loader Class Initialized
INFO - 2022-03-31 05:43:58 --> Helper loaded: url_helper
INFO - 2022-03-31 05:43:58 --> Helper loaded: form_helper
INFO - 2022-03-31 05:43:58 --> Helper loaded: common_helper
INFO - 2022-03-31 05:43:58 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:43:58 --> Controller Class Initialized
INFO - 2022-03-31 05:43:58 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:43:58 --> Encrypt Class Initialized
INFO - 2022-03-31 05:43:58 --> Model "Patient_model" initialized
INFO - 2022-03-31 05:43:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 05:43:58 --> Model "Prefix_master" initialized
INFO - 2022-03-31 05:43:58 --> Model "Users_model" initialized
INFO - 2022-03-31 05:43:58 --> Model "Hospital_model" initialized
INFO - 2022-03-31 05:43:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 05:43:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 05:43:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 05:43:58 --> Final output sent to browser
DEBUG - 2022-03-31 05:43:58 --> Total execution time: 0.0632
ERROR - 2022-03-31 05:58:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 05:58:04 --> Config Class Initialized
INFO - 2022-03-31 05:58:04 --> Hooks Class Initialized
DEBUG - 2022-03-31 05:58:04 --> UTF-8 Support Enabled
INFO - 2022-03-31 05:58:04 --> Utf8 Class Initialized
INFO - 2022-03-31 05:58:04 --> URI Class Initialized
INFO - 2022-03-31 05:58:04 --> Router Class Initialized
INFO - 2022-03-31 05:58:04 --> Output Class Initialized
INFO - 2022-03-31 05:58:04 --> Security Class Initialized
DEBUG - 2022-03-31 05:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 05:58:04 --> Input Class Initialized
INFO - 2022-03-31 05:58:04 --> Language Class Initialized
INFO - 2022-03-31 05:58:04 --> Loader Class Initialized
INFO - 2022-03-31 05:58:04 --> Helper loaded: url_helper
INFO - 2022-03-31 05:58:04 --> Helper loaded: form_helper
INFO - 2022-03-31 05:58:04 --> Helper loaded: common_helper
INFO - 2022-03-31 05:58:04 --> Database Driver Class Initialized
DEBUG - 2022-03-31 05:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 05:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 05:58:04 --> Controller Class Initialized
INFO - 2022-03-31 05:58:04 --> Form Validation Class Initialized
DEBUG - 2022-03-31 05:58:04 --> Encrypt Class Initialized
INFO - 2022-03-31 05:58:04 --> Model "Patient_model" initialized
INFO - 2022-03-31 05:58:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 05:58:04 --> Model "Referredby_model" initialized
INFO - 2022-03-31 05:58:04 --> Model "Prefix_master" initialized
INFO - 2022-03-31 05:58:04 --> Model "Hospital_model" initialized
INFO - 2022-03-31 05:58:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 05:58:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 05:58:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 05:58:04 --> Final output sent to browser
DEBUG - 2022-03-31 05:58:04 --> Total execution time: 0.1810
ERROR - 2022-03-31 06:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:09:07 --> Config Class Initialized
INFO - 2022-03-31 06:09:07 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:09:07 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:09:07 --> Utf8 Class Initialized
INFO - 2022-03-31 06:09:07 --> URI Class Initialized
INFO - 2022-03-31 06:09:07 --> Router Class Initialized
INFO - 2022-03-31 06:09:07 --> Output Class Initialized
INFO - 2022-03-31 06:09:07 --> Security Class Initialized
DEBUG - 2022-03-31 06:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:09:07 --> Input Class Initialized
INFO - 2022-03-31 06:09:07 --> Language Class Initialized
INFO - 2022-03-31 06:09:07 --> Loader Class Initialized
INFO - 2022-03-31 06:09:07 --> Helper loaded: url_helper
INFO - 2022-03-31 06:09:07 --> Helper loaded: form_helper
INFO - 2022-03-31 06:09:07 --> Helper loaded: common_helper
INFO - 2022-03-31 06:09:07 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:09:07 --> Controller Class Initialized
INFO - 2022-03-31 06:09:07 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:09:07 --> Encrypt Class Initialized
INFO - 2022-03-31 06:09:07 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:09:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:09:07 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:09:07 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:09:07 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 06:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:09:07 --> Config Class Initialized
INFO - 2022-03-31 06:09:07 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:09:07 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:09:07 --> Utf8 Class Initialized
INFO - 2022-03-31 06:09:07 --> URI Class Initialized
INFO - 2022-03-31 06:09:07 --> Router Class Initialized
INFO - 2022-03-31 06:09:07 --> Output Class Initialized
INFO - 2022-03-31 06:09:07 --> Security Class Initialized
DEBUG - 2022-03-31 06:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:09:07 --> Input Class Initialized
INFO - 2022-03-31 06:09:07 --> Language Class Initialized
INFO - 2022-03-31 06:09:07 --> Loader Class Initialized
INFO - 2022-03-31 06:09:07 --> Helper loaded: url_helper
INFO - 2022-03-31 06:09:07 --> Helper loaded: form_helper
INFO - 2022-03-31 06:09:07 --> Helper loaded: common_helper
INFO - 2022-03-31 06:09:07 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:09:07 --> Controller Class Initialized
INFO - 2022-03-31 06:09:07 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:09:07 --> Encrypt Class Initialized
INFO - 2022-03-31 06:09:07 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:09:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:09:07 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:09:07 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:09:07 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:09:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:09:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 06:09:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:09:07 --> Final output sent to browser
DEBUG - 2022-03-31 06:09:07 --> Total execution time: 0.0281
ERROR - 2022-03-31 06:09:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:09:08 --> Config Class Initialized
INFO - 2022-03-31 06:09:08 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:09:08 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:09:08 --> Utf8 Class Initialized
INFO - 2022-03-31 06:09:08 --> URI Class Initialized
INFO - 2022-03-31 06:09:08 --> Router Class Initialized
INFO - 2022-03-31 06:09:08 --> Output Class Initialized
INFO - 2022-03-31 06:09:08 --> Security Class Initialized
DEBUG - 2022-03-31 06:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:09:08 --> Input Class Initialized
INFO - 2022-03-31 06:09:08 --> Language Class Initialized
INFO - 2022-03-31 06:09:08 --> Loader Class Initialized
INFO - 2022-03-31 06:09:08 --> Helper loaded: url_helper
INFO - 2022-03-31 06:09:08 --> Helper loaded: form_helper
INFO - 2022-03-31 06:09:08 --> Helper loaded: common_helper
INFO - 2022-03-31 06:09:08 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:09:08 --> Controller Class Initialized
INFO - 2022-03-31 06:09:08 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:09:08 --> Encrypt Class Initialized
INFO - 2022-03-31 06:09:08 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:09:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:09:08 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:09:08 --> Model "Users_model" initialized
INFO - 2022-03-31 06:09:08 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:09:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:09:08 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 06:09:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:09:08 --> Final output sent to browser
DEBUG - 2022-03-31 06:09:08 --> Total execution time: 0.0802
ERROR - 2022-03-31 06:29:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:29:49 --> Config Class Initialized
INFO - 2022-03-31 06:29:49 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:29:49 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:29:49 --> Utf8 Class Initialized
INFO - 2022-03-31 06:29:49 --> URI Class Initialized
INFO - 2022-03-31 06:29:49 --> Router Class Initialized
INFO - 2022-03-31 06:29:49 --> Output Class Initialized
INFO - 2022-03-31 06:29:49 --> Security Class Initialized
DEBUG - 2022-03-31 06:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:29:49 --> Input Class Initialized
INFO - 2022-03-31 06:29:49 --> Language Class Initialized
INFO - 2022-03-31 06:29:49 --> Loader Class Initialized
INFO - 2022-03-31 06:29:49 --> Helper loaded: url_helper
INFO - 2022-03-31 06:29:49 --> Helper loaded: form_helper
INFO - 2022-03-31 06:29:49 --> Helper loaded: common_helper
INFO - 2022-03-31 06:29:49 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:29:49 --> Controller Class Initialized
INFO - 2022-03-31 06:29:49 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:29:49 --> Encrypt Class Initialized
INFO - 2022-03-31 06:29:49 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:29:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:29:49 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:29:49 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:29:49 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:29:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:29:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 06:29:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:29:59 --> Final output sent to browser
DEBUG - 2022-03-31 06:29:59 --> Total execution time: 6.6026
ERROR - 2022-03-31 06:30:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:30:32 --> Config Class Initialized
INFO - 2022-03-31 06:30:32 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:30:32 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:30:32 --> Utf8 Class Initialized
INFO - 2022-03-31 06:30:32 --> URI Class Initialized
INFO - 2022-03-31 06:30:32 --> Router Class Initialized
INFO - 2022-03-31 06:30:32 --> Output Class Initialized
INFO - 2022-03-31 06:30:32 --> Security Class Initialized
DEBUG - 2022-03-31 06:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:30:32 --> Input Class Initialized
INFO - 2022-03-31 06:30:32 --> Language Class Initialized
INFO - 2022-03-31 06:30:32 --> Loader Class Initialized
INFO - 2022-03-31 06:30:32 --> Helper loaded: url_helper
INFO - 2022-03-31 06:30:32 --> Helper loaded: form_helper
INFO - 2022-03-31 06:30:32 --> Helper loaded: common_helper
INFO - 2022-03-31 06:30:32 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:30:32 --> Controller Class Initialized
INFO - 2022-03-31 06:30:32 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:30:32 --> Encrypt Class Initialized
INFO - 2022-03-31 06:30:32 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:30:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:30:32 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:30:32 --> Model "Users_model" initialized
INFO - 2022-03-31 06:30:32 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:30:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:30:32 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 06:30:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:30:32 --> Final output sent to browser
DEBUG - 2022-03-31 06:30:32 --> Total execution time: 0.0457
ERROR - 2022-03-31 06:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:30:54 --> Config Class Initialized
INFO - 2022-03-31 06:30:54 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:30:54 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:30:54 --> Utf8 Class Initialized
INFO - 2022-03-31 06:30:54 --> URI Class Initialized
INFO - 2022-03-31 06:30:54 --> Router Class Initialized
INFO - 2022-03-31 06:30:54 --> Output Class Initialized
INFO - 2022-03-31 06:30:54 --> Security Class Initialized
DEBUG - 2022-03-31 06:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:30:54 --> Input Class Initialized
INFO - 2022-03-31 06:30:54 --> Language Class Initialized
INFO - 2022-03-31 06:30:54 --> Loader Class Initialized
INFO - 2022-03-31 06:30:54 --> Helper loaded: url_helper
INFO - 2022-03-31 06:30:54 --> Helper loaded: form_helper
INFO - 2022-03-31 06:30:54 --> Helper loaded: common_helper
INFO - 2022-03-31 06:30:54 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:30:54 --> Controller Class Initialized
INFO - 2022-03-31 06:30:54 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:30:54 --> Encrypt Class Initialized
INFO - 2022-03-31 06:30:54 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:30:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:30:54 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:30:54 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:30:54 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:30:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:31:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 06:31:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:31:02 --> Final output sent to browser
DEBUG - 2022-03-31 06:31:02 --> Total execution time: 6.1513
ERROR - 2022-03-31 06:32:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:32:21 --> Config Class Initialized
INFO - 2022-03-31 06:32:21 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:32:21 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:32:21 --> Utf8 Class Initialized
INFO - 2022-03-31 06:32:21 --> URI Class Initialized
INFO - 2022-03-31 06:32:21 --> Router Class Initialized
INFO - 2022-03-31 06:32:21 --> Output Class Initialized
INFO - 2022-03-31 06:32:21 --> Security Class Initialized
DEBUG - 2022-03-31 06:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:32:21 --> Input Class Initialized
INFO - 2022-03-31 06:32:21 --> Language Class Initialized
INFO - 2022-03-31 06:32:21 --> Loader Class Initialized
INFO - 2022-03-31 06:32:21 --> Helper loaded: url_helper
INFO - 2022-03-31 06:32:21 --> Helper loaded: form_helper
INFO - 2022-03-31 06:32:21 --> Helper loaded: common_helper
INFO - 2022-03-31 06:32:21 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:32:21 --> Controller Class Initialized
INFO - 2022-03-31 06:32:21 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:32:21 --> Encrypt Class Initialized
INFO - 2022-03-31 06:32:21 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:32:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:32:21 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:32:21 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:32:21 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:32:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:32:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 06:32:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:32:21 --> Final output sent to browser
DEBUG - 2022-03-31 06:32:21 --> Total execution time: 0.0286
ERROR - 2022-03-31 06:35:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:35:20 --> Config Class Initialized
INFO - 2022-03-31 06:35:20 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:35:20 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:35:20 --> Utf8 Class Initialized
INFO - 2022-03-31 06:35:20 --> URI Class Initialized
INFO - 2022-03-31 06:35:20 --> Router Class Initialized
INFO - 2022-03-31 06:35:20 --> Output Class Initialized
INFO - 2022-03-31 06:35:20 --> Security Class Initialized
DEBUG - 2022-03-31 06:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:35:20 --> Input Class Initialized
INFO - 2022-03-31 06:35:20 --> Language Class Initialized
INFO - 2022-03-31 06:35:20 --> Loader Class Initialized
INFO - 2022-03-31 06:35:20 --> Helper loaded: url_helper
INFO - 2022-03-31 06:35:20 --> Helper loaded: form_helper
INFO - 2022-03-31 06:35:20 --> Helper loaded: common_helper
INFO - 2022-03-31 06:35:20 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:35:20 --> Controller Class Initialized
INFO - 2022-03-31 06:35:20 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:35:20 --> Encrypt Class Initialized
INFO - 2022-03-31 06:35:20 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:35:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:35:20 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:35:20 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:35:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 06:35:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:35:20 --> Config Class Initialized
INFO - 2022-03-31 06:35:20 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:35:20 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:35:20 --> Utf8 Class Initialized
INFO - 2022-03-31 06:35:20 --> URI Class Initialized
INFO - 2022-03-31 06:35:20 --> Router Class Initialized
INFO - 2022-03-31 06:35:20 --> Output Class Initialized
INFO - 2022-03-31 06:35:20 --> Security Class Initialized
DEBUG - 2022-03-31 06:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:35:20 --> Input Class Initialized
INFO - 2022-03-31 06:35:20 --> Language Class Initialized
INFO - 2022-03-31 06:35:20 --> Loader Class Initialized
INFO - 2022-03-31 06:35:20 --> Helper loaded: url_helper
INFO - 2022-03-31 06:35:20 --> Helper loaded: form_helper
INFO - 2022-03-31 06:35:20 --> Helper loaded: common_helper
INFO - 2022-03-31 06:35:20 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:35:20 --> Controller Class Initialized
INFO - 2022-03-31 06:35:20 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:35:20 --> Encrypt Class Initialized
INFO - 2022-03-31 06:35:20 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:35:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:35:20 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:35:20 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:35:20 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:35:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:35:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 06:35:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:35:20 --> Final output sent to browser
DEBUG - 2022-03-31 06:35:20 --> Total execution time: 0.0264
ERROR - 2022-03-31 06:35:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:35:21 --> Config Class Initialized
INFO - 2022-03-31 06:35:21 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:35:21 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:35:21 --> Utf8 Class Initialized
INFO - 2022-03-31 06:35:21 --> URI Class Initialized
INFO - 2022-03-31 06:35:21 --> Router Class Initialized
INFO - 2022-03-31 06:35:21 --> Output Class Initialized
INFO - 2022-03-31 06:35:21 --> Security Class Initialized
DEBUG - 2022-03-31 06:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:35:21 --> Input Class Initialized
INFO - 2022-03-31 06:35:21 --> Language Class Initialized
INFO - 2022-03-31 06:35:21 --> Loader Class Initialized
INFO - 2022-03-31 06:35:21 --> Helper loaded: url_helper
INFO - 2022-03-31 06:35:21 --> Helper loaded: form_helper
INFO - 2022-03-31 06:35:21 --> Helper loaded: common_helper
INFO - 2022-03-31 06:35:21 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:35:21 --> Controller Class Initialized
INFO - 2022-03-31 06:35:21 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:35:21 --> Encrypt Class Initialized
INFO - 2022-03-31 06:35:21 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:35:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:35:21 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:35:21 --> Model "Users_model" initialized
INFO - 2022-03-31 06:35:21 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:35:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:35:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 06:35:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:35:21 --> Final output sent to browser
DEBUG - 2022-03-31 06:35:21 --> Total execution time: 0.0578
ERROR - 2022-03-31 06:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:42:24 --> Config Class Initialized
INFO - 2022-03-31 06:42:24 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:42:24 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:42:24 --> Utf8 Class Initialized
INFO - 2022-03-31 06:42:24 --> URI Class Initialized
INFO - 2022-03-31 06:42:24 --> Router Class Initialized
INFO - 2022-03-31 06:42:24 --> Output Class Initialized
INFO - 2022-03-31 06:42:24 --> Security Class Initialized
DEBUG - 2022-03-31 06:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:42:24 --> Input Class Initialized
INFO - 2022-03-31 06:42:24 --> Language Class Initialized
INFO - 2022-03-31 06:42:24 --> Loader Class Initialized
INFO - 2022-03-31 06:42:24 --> Helper loaded: url_helper
INFO - 2022-03-31 06:42:24 --> Helper loaded: form_helper
INFO - 2022-03-31 06:42:24 --> Helper loaded: common_helper
INFO - 2022-03-31 06:42:24 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:42:24 --> Controller Class Initialized
INFO - 2022-03-31 06:42:24 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:42:24 --> Encrypt Class Initialized
INFO - 2022-03-31 06:42:24 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:42:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:42:24 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:42:24 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:42:24 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:42:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:42:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 06:42:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:42:33 --> Final output sent to browser
DEBUG - 2022-03-31 06:42:33 --> Total execution time: 6.2183
ERROR - 2022-03-31 06:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:43:04 --> Config Class Initialized
INFO - 2022-03-31 06:43:04 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:43:04 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:43:04 --> Utf8 Class Initialized
INFO - 2022-03-31 06:43:04 --> URI Class Initialized
INFO - 2022-03-31 06:43:04 --> Router Class Initialized
INFO - 2022-03-31 06:43:04 --> Output Class Initialized
INFO - 2022-03-31 06:43:04 --> Security Class Initialized
DEBUG - 2022-03-31 06:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:43:04 --> Input Class Initialized
INFO - 2022-03-31 06:43:04 --> Language Class Initialized
INFO - 2022-03-31 06:43:04 --> Loader Class Initialized
INFO - 2022-03-31 06:43:04 --> Helper loaded: url_helper
INFO - 2022-03-31 06:43:04 --> Helper loaded: form_helper
INFO - 2022-03-31 06:43:04 --> Helper loaded: common_helper
INFO - 2022-03-31 06:43:04 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:43:04 --> Controller Class Initialized
INFO - 2022-03-31 06:43:04 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:43:04 --> Encrypt Class Initialized
INFO - 2022-03-31 06:43:04 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:43:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:43:04 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:43:04 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:43:04 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:43:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:43:04 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 06:43:04 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:43:04 --> Final output sent to browser
DEBUG - 2022-03-31 06:43:04 --> Total execution time: 0.0407
ERROR - 2022-03-31 06:47:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:47:02 --> Config Class Initialized
INFO - 2022-03-31 06:47:02 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:47:02 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:47:02 --> Utf8 Class Initialized
INFO - 2022-03-31 06:47:02 --> URI Class Initialized
INFO - 2022-03-31 06:47:02 --> Router Class Initialized
INFO - 2022-03-31 06:47:02 --> Output Class Initialized
INFO - 2022-03-31 06:47:02 --> Security Class Initialized
DEBUG - 2022-03-31 06:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:47:02 --> Input Class Initialized
INFO - 2022-03-31 06:47:02 --> Language Class Initialized
INFO - 2022-03-31 06:47:02 --> Loader Class Initialized
INFO - 2022-03-31 06:47:02 --> Helper loaded: url_helper
INFO - 2022-03-31 06:47:02 --> Helper loaded: form_helper
INFO - 2022-03-31 06:47:02 --> Helper loaded: common_helper
INFO - 2022-03-31 06:47:02 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:47:02 --> Controller Class Initialized
INFO - 2022-03-31 06:47:02 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:47:02 --> Encrypt Class Initialized
INFO - 2022-03-31 06:47:02 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:47:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:47:02 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:47:02 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:47:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 06:47:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:47:02 --> Config Class Initialized
INFO - 2022-03-31 06:47:02 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:47:02 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:47:02 --> Utf8 Class Initialized
INFO - 2022-03-31 06:47:02 --> URI Class Initialized
INFO - 2022-03-31 06:47:02 --> Router Class Initialized
INFO - 2022-03-31 06:47:02 --> Output Class Initialized
INFO - 2022-03-31 06:47:02 --> Security Class Initialized
DEBUG - 2022-03-31 06:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:47:02 --> Input Class Initialized
INFO - 2022-03-31 06:47:02 --> Language Class Initialized
INFO - 2022-03-31 06:47:02 --> Loader Class Initialized
INFO - 2022-03-31 06:47:02 --> Helper loaded: url_helper
INFO - 2022-03-31 06:47:02 --> Helper loaded: form_helper
INFO - 2022-03-31 06:47:02 --> Helper loaded: common_helper
INFO - 2022-03-31 06:47:02 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:47:02 --> Controller Class Initialized
INFO - 2022-03-31 06:47:02 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:47:02 --> Encrypt Class Initialized
INFO - 2022-03-31 06:47:02 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:47:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:47:02 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:47:02 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:47:02 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:47:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:47:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 06:47:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:47:02 --> Final output sent to browser
DEBUG - 2022-03-31 06:47:02 --> Total execution time: 0.0337
ERROR - 2022-03-31 06:47:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:47:03 --> Config Class Initialized
INFO - 2022-03-31 06:47:03 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:47:03 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:47:03 --> Utf8 Class Initialized
INFO - 2022-03-31 06:47:03 --> URI Class Initialized
INFO - 2022-03-31 06:47:03 --> Router Class Initialized
INFO - 2022-03-31 06:47:03 --> Output Class Initialized
INFO - 2022-03-31 06:47:03 --> Security Class Initialized
DEBUG - 2022-03-31 06:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:47:03 --> Input Class Initialized
INFO - 2022-03-31 06:47:03 --> Language Class Initialized
INFO - 2022-03-31 06:47:03 --> Loader Class Initialized
INFO - 2022-03-31 06:47:03 --> Helper loaded: url_helper
INFO - 2022-03-31 06:47:03 --> Helper loaded: form_helper
INFO - 2022-03-31 06:47:03 --> Helper loaded: common_helper
INFO - 2022-03-31 06:47:03 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:47:03 --> Controller Class Initialized
INFO - 2022-03-31 06:47:03 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:47:03 --> Encrypt Class Initialized
INFO - 2022-03-31 06:47:03 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:47:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:47:03 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:47:03 --> Model "Users_model" initialized
INFO - 2022-03-31 06:47:03 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:47:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:47:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 06:47:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:47:03 --> Final output sent to browser
DEBUG - 2022-03-31 06:47:03 --> Total execution time: 0.0702
ERROR - 2022-03-31 06:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:58:00 --> Config Class Initialized
INFO - 2022-03-31 06:58:00 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:58:00 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:58:00 --> Utf8 Class Initialized
INFO - 2022-03-31 06:58:00 --> URI Class Initialized
INFO - 2022-03-31 06:58:00 --> Router Class Initialized
INFO - 2022-03-31 06:58:00 --> Output Class Initialized
INFO - 2022-03-31 06:58:00 --> Security Class Initialized
DEBUG - 2022-03-31 06:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:58:00 --> Input Class Initialized
INFO - 2022-03-31 06:58:00 --> Language Class Initialized
INFO - 2022-03-31 06:58:00 --> Loader Class Initialized
INFO - 2022-03-31 06:58:00 --> Helper loaded: url_helper
INFO - 2022-03-31 06:58:00 --> Helper loaded: form_helper
INFO - 2022-03-31 06:58:00 --> Helper loaded: common_helper
INFO - 2022-03-31 06:58:00 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:58:00 --> Controller Class Initialized
INFO - 2022-03-31 06:58:00 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:58:00 --> Encrypt Class Initialized
INFO - 2022-03-31 06:58:00 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:58:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:58:00 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:58:00 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:58:00 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:58:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:58:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 06:58:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:58:10 --> Final output sent to browser
DEBUG - 2022-03-31 06:58:10 --> Total execution time: 7.0909
ERROR - 2022-03-31 06:58:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 06:58:43 --> Config Class Initialized
INFO - 2022-03-31 06:58:43 --> Hooks Class Initialized
DEBUG - 2022-03-31 06:58:43 --> UTF-8 Support Enabled
INFO - 2022-03-31 06:58:43 --> Utf8 Class Initialized
INFO - 2022-03-31 06:58:43 --> URI Class Initialized
INFO - 2022-03-31 06:58:43 --> Router Class Initialized
INFO - 2022-03-31 06:58:43 --> Output Class Initialized
INFO - 2022-03-31 06:58:43 --> Security Class Initialized
DEBUG - 2022-03-31 06:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 06:58:43 --> Input Class Initialized
INFO - 2022-03-31 06:58:43 --> Language Class Initialized
INFO - 2022-03-31 06:58:43 --> Loader Class Initialized
INFO - 2022-03-31 06:58:43 --> Helper loaded: url_helper
INFO - 2022-03-31 06:58:43 --> Helper loaded: form_helper
INFO - 2022-03-31 06:58:43 --> Helper loaded: common_helper
INFO - 2022-03-31 06:58:43 --> Database Driver Class Initialized
DEBUG - 2022-03-31 06:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 06:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 06:58:43 --> Controller Class Initialized
INFO - 2022-03-31 06:58:43 --> Form Validation Class Initialized
DEBUG - 2022-03-31 06:58:43 --> Encrypt Class Initialized
INFO - 2022-03-31 06:58:43 --> Model "Patient_model" initialized
INFO - 2022-03-31 06:58:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 06:58:43 --> Model "Referredby_model" initialized
INFO - 2022-03-31 06:58:43 --> Model "Prefix_master" initialized
INFO - 2022-03-31 06:58:43 --> Model "Hospital_model" initialized
INFO - 2022-03-31 06:58:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 06:58:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 06:58:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 06:58:43 --> Final output sent to browser
DEBUG - 2022-03-31 06:58:43 --> Total execution time: 0.0323
ERROR - 2022-03-31 07:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:04:16 --> Config Class Initialized
INFO - 2022-03-31 07:04:16 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:04:16 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:04:16 --> Utf8 Class Initialized
INFO - 2022-03-31 07:04:16 --> URI Class Initialized
INFO - 2022-03-31 07:04:16 --> Router Class Initialized
INFO - 2022-03-31 07:04:16 --> Output Class Initialized
INFO - 2022-03-31 07:04:16 --> Security Class Initialized
DEBUG - 2022-03-31 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:04:16 --> Input Class Initialized
INFO - 2022-03-31 07:04:16 --> Language Class Initialized
INFO - 2022-03-31 07:04:16 --> Loader Class Initialized
INFO - 2022-03-31 07:04:16 --> Helper loaded: url_helper
INFO - 2022-03-31 07:04:16 --> Helper loaded: form_helper
INFO - 2022-03-31 07:04:16 --> Helper loaded: common_helper
INFO - 2022-03-31 07:04:16 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:04:16 --> Controller Class Initialized
INFO - 2022-03-31 07:04:16 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:04:16 --> Encrypt Class Initialized
INFO - 2022-03-31 07:04:16 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:04:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:04:16 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:04:16 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:04:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 07:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:04:16 --> Config Class Initialized
INFO - 2022-03-31 07:04:16 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:04:16 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:04:16 --> Utf8 Class Initialized
INFO - 2022-03-31 07:04:16 --> URI Class Initialized
INFO - 2022-03-31 07:04:16 --> Router Class Initialized
INFO - 2022-03-31 07:04:16 --> Output Class Initialized
INFO - 2022-03-31 07:04:16 --> Security Class Initialized
DEBUG - 2022-03-31 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:04:16 --> Input Class Initialized
INFO - 2022-03-31 07:04:16 --> Language Class Initialized
INFO - 2022-03-31 07:04:16 --> Loader Class Initialized
INFO - 2022-03-31 07:04:16 --> Helper loaded: url_helper
INFO - 2022-03-31 07:04:16 --> Helper loaded: form_helper
INFO - 2022-03-31 07:04:16 --> Helper loaded: common_helper
INFO - 2022-03-31 07:04:16 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:04:16 --> Controller Class Initialized
INFO - 2022-03-31 07:04:16 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:04:16 --> Encrypt Class Initialized
INFO - 2022-03-31 07:04:16 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:04:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:04:16 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:04:16 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:04:16 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:04:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:04:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 07:04:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:04:16 --> Final output sent to browser
DEBUG - 2022-03-31 07:04:16 --> Total execution time: 0.0287
ERROR - 2022-03-31 07:04:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:04:17 --> Config Class Initialized
INFO - 2022-03-31 07:04:17 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:04:17 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:04:17 --> Utf8 Class Initialized
INFO - 2022-03-31 07:04:17 --> URI Class Initialized
INFO - 2022-03-31 07:04:17 --> Router Class Initialized
INFO - 2022-03-31 07:04:17 --> Output Class Initialized
INFO - 2022-03-31 07:04:17 --> Security Class Initialized
DEBUG - 2022-03-31 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:04:17 --> Input Class Initialized
INFO - 2022-03-31 07:04:17 --> Language Class Initialized
INFO - 2022-03-31 07:04:17 --> Loader Class Initialized
INFO - 2022-03-31 07:04:17 --> Helper loaded: url_helper
INFO - 2022-03-31 07:04:17 --> Helper loaded: form_helper
INFO - 2022-03-31 07:04:17 --> Helper loaded: common_helper
INFO - 2022-03-31 07:04:17 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:04:17 --> Controller Class Initialized
INFO - 2022-03-31 07:04:17 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:04:17 --> Encrypt Class Initialized
INFO - 2022-03-31 07:04:17 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:04:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:04:17 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:04:17 --> Model "Users_model" initialized
INFO - 2022-03-31 07:04:17 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:04:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:04:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 07:04:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:04:17 --> Final output sent to browser
DEBUG - 2022-03-31 07:04:17 --> Total execution time: 0.0541
ERROR - 2022-03-31 07:12:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:12:17 --> Config Class Initialized
INFO - 2022-03-31 07:12:17 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:12:17 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:12:17 --> Utf8 Class Initialized
INFO - 2022-03-31 07:12:17 --> URI Class Initialized
INFO - 2022-03-31 07:12:17 --> Router Class Initialized
INFO - 2022-03-31 07:12:17 --> Output Class Initialized
INFO - 2022-03-31 07:12:17 --> Security Class Initialized
DEBUG - 2022-03-31 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:12:17 --> Input Class Initialized
INFO - 2022-03-31 07:12:17 --> Language Class Initialized
INFO - 2022-03-31 07:12:17 --> Loader Class Initialized
INFO - 2022-03-31 07:12:17 --> Helper loaded: url_helper
INFO - 2022-03-31 07:12:17 --> Helper loaded: form_helper
INFO - 2022-03-31 07:12:17 --> Helper loaded: common_helper
INFO - 2022-03-31 07:12:17 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:12:17 --> Controller Class Initialized
INFO - 2022-03-31 07:12:17 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:12:17 --> Encrypt Class Initialized
INFO - 2022-03-31 07:12:17 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:12:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:12:17 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:12:17 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:12:17 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:12:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:12:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 07:12:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:12:28 --> Final output sent to browser
DEBUG - 2022-03-31 07:12:28 --> Total execution time: 6.9938
ERROR - 2022-03-31 07:13:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:13:01 --> Config Class Initialized
INFO - 2022-03-31 07:13:01 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:13:01 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:13:01 --> Utf8 Class Initialized
INFO - 2022-03-31 07:13:01 --> URI Class Initialized
INFO - 2022-03-31 07:13:01 --> Router Class Initialized
INFO - 2022-03-31 07:13:01 --> Output Class Initialized
INFO - 2022-03-31 07:13:01 --> Security Class Initialized
DEBUG - 2022-03-31 07:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:13:01 --> Input Class Initialized
INFO - 2022-03-31 07:13:01 --> Language Class Initialized
INFO - 2022-03-31 07:13:01 --> Loader Class Initialized
INFO - 2022-03-31 07:13:01 --> Helper loaded: url_helper
INFO - 2022-03-31 07:13:01 --> Helper loaded: form_helper
INFO - 2022-03-31 07:13:01 --> Helper loaded: common_helper
INFO - 2022-03-31 07:13:01 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:13:01 --> Controller Class Initialized
INFO - 2022-03-31 07:13:01 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:13:01 --> Encrypt Class Initialized
INFO - 2022-03-31 07:13:01 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:13:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:13:01 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:13:01 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:13:01 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:13:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:13:01 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 07:13:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:13:01 --> Final output sent to browser
DEBUG - 2022-03-31 07:13:01 --> Total execution time: 0.0312
ERROR - 2022-03-31 07:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:18:58 --> Config Class Initialized
INFO - 2022-03-31 07:18:58 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:18:58 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:18:58 --> Utf8 Class Initialized
INFO - 2022-03-31 07:18:58 --> URI Class Initialized
INFO - 2022-03-31 07:18:58 --> Router Class Initialized
INFO - 2022-03-31 07:18:58 --> Output Class Initialized
INFO - 2022-03-31 07:18:58 --> Security Class Initialized
DEBUG - 2022-03-31 07:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:18:58 --> Input Class Initialized
INFO - 2022-03-31 07:18:58 --> Language Class Initialized
INFO - 2022-03-31 07:18:58 --> Loader Class Initialized
INFO - 2022-03-31 07:18:58 --> Helper loaded: url_helper
INFO - 2022-03-31 07:18:58 --> Helper loaded: form_helper
INFO - 2022-03-31 07:18:58 --> Helper loaded: common_helper
INFO - 2022-03-31 07:18:58 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:18:58 --> Controller Class Initialized
INFO - 2022-03-31 07:18:58 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:18:58 --> Encrypt Class Initialized
INFO - 2022-03-31 07:18:58 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:18:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:18:58 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:18:58 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:18:58 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 07:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:18:58 --> Config Class Initialized
INFO - 2022-03-31 07:18:58 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:18:58 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:18:58 --> Utf8 Class Initialized
INFO - 2022-03-31 07:18:58 --> URI Class Initialized
INFO - 2022-03-31 07:18:58 --> Router Class Initialized
INFO - 2022-03-31 07:18:58 --> Output Class Initialized
INFO - 2022-03-31 07:18:58 --> Security Class Initialized
DEBUG - 2022-03-31 07:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:18:58 --> Input Class Initialized
INFO - 2022-03-31 07:18:58 --> Language Class Initialized
INFO - 2022-03-31 07:18:58 --> Loader Class Initialized
INFO - 2022-03-31 07:18:58 --> Helper loaded: url_helper
INFO - 2022-03-31 07:18:58 --> Helper loaded: form_helper
INFO - 2022-03-31 07:18:58 --> Helper loaded: common_helper
INFO - 2022-03-31 07:18:58 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:18:58 --> Controller Class Initialized
INFO - 2022-03-31 07:18:58 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:18:58 --> Encrypt Class Initialized
INFO - 2022-03-31 07:18:58 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:18:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:18:58 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:18:58 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:18:58 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:18:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:18:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 07:18:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:18:58 --> Final output sent to browser
DEBUG - 2022-03-31 07:18:58 --> Total execution time: 0.0277
ERROR - 2022-03-31 07:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:18:59 --> Config Class Initialized
INFO - 2022-03-31 07:18:59 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:18:59 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:18:59 --> Utf8 Class Initialized
INFO - 2022-03-31 07:18:59 --> URI Class Initialized
INFO - 2022-03-31 07:18:59 --> Router Class Initialized
INFO - 2022-03-31 07:18:59 --> Output Class Initialized
INFO - 2022-03-31 07:18:59 --> Security Class Initialized
DEBUG - 2022-03-31 07:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:18:59 --> Input Class Initialized
INFO - 2022-03-31 07:18:59 --> Language Class Initialized
INFO - 2022-03-31 07:18:59 --> Loader Class Initialized
INFO - 2022-03-31 07:18:59 --> Helper loaded: url_helper
INFO - 2022-03-31 07:18:59 --> Helper loaded: form_helper
INFO - 2022-03-31 07:18:59 --> Helper loaded: common_helper
INFO - 2022-03-31 07:18:59 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:18:59 --> Controller Class Initialized
INFO - 2022-03-31 07:18:59 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:18:59 --> Encrypt Class Initialized
INFO - 2022-03-31 07:18:59 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:18:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:18:59 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:18:59 --> Model "Users_model" initialized
INFO - 2022-03-31 07:18:59 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:18:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:18:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 07:18:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:18:59 --> Final output sent to browser
DEBUG - 2022-03-31 07:18:59 --> Total execution time: 0.0712
ERROR - 2022-03-31 07:24:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:24:05 --> Config Class Initialized
INFO - 2022-03-31 07:24:05 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:24:05 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:24:05 --> Utf8 Class Initialized
INFO - 2022-03-31 07:24:05 --> URI Class Initialized
INFO - 2022-03-31 07:24:05 --> Router Class Initialized
INFO - 2022-03-31 07:24:05 --> Output Class Initialized
INFO - 2022-03-31 07:24:05 --> Security Class Initialized
DEBUG - 2022-03-31 07:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:24:05 --> Input Class Initialized
INFO - 2022-03-31 07:24:05 --> Language Class Initialized
INFO - 2022-03-31 07:24:05 --> Loader Class Initialized
INFO - 2022-03-31 07:24:05 --> Helper loaded: url_helper
INFO - 2022-03-31 07:24:05 --> Helper loaded: form_helper
INFO - 2022-03-31 07:24:05 --> Helper loaded: common_helper
INFO - 2022-03-31 07:24:05 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:24:05 --> Controller Class Initialized
INFO - 2022-03-31 07:24:05 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:24:05 --> Encrypt Class Initialized
INFO - 2022-03-31 07:24:05 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:24:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:24:05 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:24:05 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:24:05 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:24:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:24:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-31 07:24:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:24:15 --> Final output sent to browser
DEBUG - 2022-03-31 07:24:15 --> Total execution time: 7.3358
ERROR - 2022-03-31 07:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:24:42 --> Config Class Initialized
INFO - 2022-03-31 07:24:42 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:24:42 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:24:42 --> Utf8 Class Initialized
INFO - 2022-03-31 07:24:42 --> URI Class Initialized
INFO - 2022-03-31 07:24:42 --> Router Class Initialized
INFO - 2022-03-31 07:24:42 --> Output Class Initialized
INFO - 2022-03-31 07:24:42 --> Security Class Initialized
DEBUG - 2022-03-31 07:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:24:42 --> Input Class Initialized
INFO - 2022-03-31 07:24:42 --> Language Class Initialized
INFO - 2022-03-31 07:24:42 --> Loader Class Initialized
INFO - 2022-03-31 07:24:42 --> Helper loaded: url_helper
INFO - 2022-03-31 07:24:42 --> Helper loaded: form_helper
INFO - 2022-03-31 07:24:42 --> Helper loaded: common_helper
INFO - 2022-03-31 07:24:42 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:24:42 --> Controller Class Initialized
INFO - 2022-03-31 07:24:42 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:24:42 --> Encrypt Class Initialized
INFO - 2022-03-31 07:24:42 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:24:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:24:42 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:24:42 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:24:42 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:24:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:24:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 07:24:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:24:42 --> Final output sent to browser
DEBUG - 2022-03-31 07:24:42 --> Total execution time: 0.0317
ERROR - 2022-03-31 07:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:29:23 --> Config Class Initialized
INFO - 2022-03-31 07:29:23 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:29:23 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:29:23 --> Utf8 Class Initialized
INFO - 2022-03-31 07:29:23 --> URI Class Initialized
INFO - 2022-03-31 07:29:23 --> Router Class Initialized
INFO - 2022-03-31 07:29:23 --> Output Class Initialized
INFO - 2022-03-31 07:29:23 --> Security Class Initialized
DEBUG - 2022-03-31 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:29:23 --> Input Class Initialized
INFO - 2022-03-31 07:29:23 --> Language Class Initialized
INFO - 2022-03-31 07:29:23 --> Loader Class Initialized
INFO - 2022-03-31 07:29:23 --> Helper loaded: url_helper
INFO - 2022-03-31 07:29:23 --> Helper loaded: form_helper
INFO - 2022-03-31 07:29:23 --> Helper loaded: common_helper
INFO - 2022-03-31 07:29:23 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:29:23 --> Controller Class Initialized
INFO - 2022-03-31 07:29:23 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:29:23 --> Encrypt Class Initialized
INFO - 2022-03-31 07:29:23 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:29:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:29:23 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:29:23 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:29:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-31 07:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:29:23 --> Config Class Initialized
INFO - 2022-03-31 07:29:23 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:29:23 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:29:23 --> Utf8 Class Initialized
INFO - 2022-03-31 07:29:23 --> URI Class Initialized
INFO - 2022-03-31 07:29:23 --> Router Class Initialized
INFO - 2022-03-31 07:29:23 --> Output Class Initialized
INFO - 2022-03-31 07:29:23 --> Security Class Initialized
DEBUG - 2022-03-31 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:29:23 --> Input Class Initialized
INFO - 2022-03-31 07:29:23 --> Language Class Initialized
INFO - 2022-03-31 07:29:23 --> Loader Class Initialized
INFO - 2022-03-31 07:29:23 --> Helper loaded: url_helper
INFO - 2022-03-31 07:29:23 --> Helper loaded: form_helper
INFO - 2022-03-31 07:29:23 --> Helper loaded: common_helper
INFO - 2022-03-31 07:29:23 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:29:23 --> Controller Class Initialized
INFO - 2022-03-31 07:29:23 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:29:23 --> Encrypt Class Initialized
INFO - 2022-03-31 07:29:23 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:29:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:29:23 --> Model "Referredby_model" initialized
INFO - 2022-03-31 07:29:23 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:29:23 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:29:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:29:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-31 07:29:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:29:23 --> Final output sent to browser
DEBUG - 2022-03-31 07:29:23 --> Total execution time: 0.0411
ERROR - 2022-03-31 07:29:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 07:29:24 --> Config Class Initialized
INFO - 2022-03-31 07:29:24 --> Hooks Class Initialized
DEBUG - 2022-03-31 07:29:24 --> UTF-8 Support Enabled
INFO - 2022-03-31 07:29:24 --> Utf8 Class Initialized
INFO - 2022-03-31 07:29:24 --> URI Class Initialized
INFO - 2022-03-31 07:29:24 --> Router Class Initialized
INFO - 2022-03-31 07:29:24 --> Output Class Initialized
INFO - 2022-03-31 07:29:24 --> Security Class Initialized
DEBUG - 2022-03-31 07:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 07:29:24 --> Input Class Initialized
INFO - 2022-03-31 07:29:24 --> Language Class Initialized
INFO - 2022-03-31 07:29:24 --> Loader Class Initialized
INFO - 2022-03-31 07:29:24 --> Helper loaded: url_helper
INFO - 2022-03-31 07:29:24 --> Helper loaded: form_helper
INFO - 2022-03-31 07:29:24 --> Helper loaded: common_helper
INFO - 2022-03-31 07:29:24 --> Database Driver Class Initialized
DEBUG - 2022-03-31 07:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 07:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 07:29:24 --> Controller Class Initialized
INFO - 2022-03-31 07:29:24 --> Form Validation Class Initialized
DEBUG - 2022-03-31 07:29:24 --> Encrypt Class Initialized
INFO - 2022-03-31 07:29:24 --> Model "Patient_model" initialized
INFO - 2022-03-31 07:29:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-31 07:29:24 --> Model "Prefix_master" initialized
INFO - 2022-03-31 07:29:24 --> Model "Users_model" initialized
INFO - 2022-03-31 07:29:24 --> Model "Hospital_model" initialized
INFO - 2022-03-31 07:29:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-31 07:29:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-31 07:29:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-31 07:29:24 --> Final output sent to browser
DEBUG - 2022-03-31 07:29:24 --> Total execution time: 0.0649
ERROR - 2022-03-31 08:39:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 08:39:16 --> Config Class Initialized
INFO - 2022-03-31 08:39:16 --> Hooks Class Initialized
DEBUG - 2022-03-31 08:39:16 --> UTF-8 Support Enabled
INFO - 2022-03-31 08:39:16 --> Utf8 Class Initialized
INFO - 2022-03-31 08:39:16 --> URI Class Initialized
DEBUG - 2022-03-31 08:39:16 --> No URI present. Default controller set.
INFO - 2022-03-31 08:39:16 --> Router Class Initialized
INFO - 2022-03-31 08:39:16 --> Output Class Initialized
INFO - 2022-03-31 08:39:16 --> Security Class Initialized
DEBUG - 2022-03-31 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 08:39:16 --> Input Class Initialized
INFO - 2022-03-31 08:39:16 --> Language Class Initialized
INFO - 2022-03-31 08:39:16 --> Loader Class Initialized
INFO - 2022-03-31 08:39:16 --> Helper loaded: url_helper
INFO - 2022-03-31 08:39:16 --> Helper loaded: form_helper
INFO - 2022-03-31 08:39:16 --> Helper loaded: common_helper
INFO - 2022-03-31 08:39:16 --> Database Driver Class Initialized
DEBUG - 2022-03-31 08:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 08:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 08:39:16 --> Controller Class Initialized
INFO - 2022-03-31 08:39:16 --> Form Validation Class Initialized
DEBUG - 2022-03-31 08:39:16 --> Encrypt Class Initialized
DEBUG - 2022-03-31 08:39:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 08:39:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 08:39:16 --> Email Class Initialized
INFO - 2022-03-31 08:39:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 08:39:16 --> Calendar Class Initialized
INFO - 2022-03-31 08:39:16 --> Model "Login_model" initialized
INFO - 2022-03-31 08:39:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 08:39:16 --> Final output sent to browser
DEBUG - 2022-03-31 08:39:16 --> Total execution time: 0.0598
ERROR - 2022-03-31 10:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 10:44:00 --> Config Class Initialized
INFO - 2022-03-31 10:44:00 --> Hooks Class Initialized
DEBUG - 2022-03-31 10:44:00 --> UTF-8 Support Enabled
INFO - 2022-03-31 10:44:00 --> Utf8 Class Initialized
INFO - 2022-03-31 10:44:00 --> URI Class Initialized
INFO - 2022-03-31 10:44:00 --> Router Class Initialized
INFO - 2022-03-31 10:44:00 --> Output Class Initialized
INFO - 2022-03-31 10:44:00 --> Security Class Initialized
DEBUG - 2022-03-31 10:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 10:44:00 --> Input Class Initialized
INFO - 2022-03-31 10:44:00 --> Language Class Initialized
ERROR - 2022-03-31 10:44:00 --> 404 Page Not Found: Wordpress/license.txt
ERROR - 2022-03-31 11:23:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 11:23:14 --> Config Class Initialized
INFO - 2022-03-31 11:23:14 --> Hooks Class Initialized
DEBUG - 2022-03-31 11:23:14 --> UTF-8 Support Enabled
INFO - 2022-03-31 11:23:14 --> Utf8 Class Initialized
INFO - 2022-03-31 11:23:14 --> URI Class Initialized
INFO - 2022-03-31 11:23:14 --> Router Class Initialized
INFO - 2022-03-31 11:23:14 --> Output Class Initialized
INFO - 2022-03-31 11:23:14 --> Security Class Initialized
DEBUG - 2022-03-31 11:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 11:23:14 --> Input Class Initialized
INFO - 2022-03-31 11:23:14 --> Language Class Initialized
ERROR - 2022-03-31 11:23:14 --> 404 Page Not Found: Wordpress/license.txt
ERROR - 2022-03-31 14:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 14:21:30 --> Config Class Initialized
INFO - 2022-03-31 14:21:30 --> Hooks Class Initialized
DEBUG - 2022-03-31 14:21:30 --> UTF-8 Support Enabled
INFO - 2022-03-31 14:21:30 --> Utf8 Class Initialized
INFO - 2022-03-31 14:21:30 --> URI Class Initialized
DEBUG - 2022-03-31 14:21:30 --> No URI present. Default controller set.
INFO - 2022-03-31 14:21:30 --> Router Class Initialized
INFO - 2022-03-31 14:21:30 --> Output Class Initialized
INFO - 2022-03-31 14:21:30 --> Security Class Initialized
DEBUG - 2022-03-31 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 14:21:30 --> Input Class Initialized
INFO - 2022-03-31 14:21:30 --> Language Class Initialized
INFO - 2022-03-31 14:21:30 --> Loader Class Initialized
INFO - 2022-03-31 14:21:30 --> Helper loaded: url_helper
INFO - 2022-03-31 14:21:30 --> Helper loaded: form_helper
INFO - 2022-03-31 14:21:30 --> Helper loaded: common_helper
INFO - 2022-03-31 14:21:30 --> Database Driver Class Initialized
DEBUG - 2022-03-31 14:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 14:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 14:21:30 --> Controller Class Initialized
INFO - 2022-03-31 14:21:30 --> Form Validation Class Initialized
DEBUG - 2022-03-31 14:21:30 --> Encrypt Class Initialized
DEBUG - 2022-03-31 14:21:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 14:21:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 14:21:30 --> Email Class Initialized
INFO - 2022-03-31 14:21:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 14:21:30 --> Calendar Class Initialized
INFO - 2022-03-31 14:21:30 --> Model "Login_model" initialized
INFO - 2022-03-31 14:21:30 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 14:21:30 --> Final output sent to browser
DEBUG - 2022-03-31 14:21:30 --> Total execution time: 0.0676
ERROR - 2022-03-31 14:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 14:21:30 --> Config Class Initialized
INFO - 2022-03-31 14:21:30 --> Hooks Class Initialized
DEBUG - 2022-03-31 14:21:30 --> UTF-8 Support Enabled
INFO - 2022-03-31 14:21:30 --> Utf8 Class Initialized
INFO - 2022-03-31 14:21:30 --> URI Class Initialized
INFO - 2022-03-31 14:21:30 --> Router Class Initialized
INFO - 2022-03-31 14:21:30 --> Output Class Initialized
INFO - 2022-03-31 14:21:30 --> Security Class Initialized
DEBUG - 2022-03-31 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 14:21:30 --> Input Class Initialized
INFO - 2022-03-31 14:21:30 --> Language Class Initialized
ERROR - 2022-03-31 14:21:30 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-31 14:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 14:22:37 --> Config Class Initialized
INFO - 2022-03-31 14:22:37 --> Hooks Class Initialized
DEBUG - 2022-03-31 14:22:37 --> UTF-8 Support Enabled
INFO - 2022-03-31 14:22:37 --> Utf8 Class Initialized
INFO - 2022-03-31 14:22:37 --> URI Class Initialized
DEBUG - 2022-03-31 14:22:37 --> No URI present. Default controller set.
INFO - 2022-03-31 14:22:37 --> Router Class Initialized
INFO - 2022-03-31 14:22:37 --> Output Class Initialized
INFO - 2022-03-31 14:22:37 --> Security Class Initialized
DEBUG - 2022-03-31 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 14:22:37 --> Input Class Initialized
INFO - 2022-03-31 14:22:37 --> Language Class Initialized
INFO - 2022-03-31 14:22:37 --> Loader Class Initialized
INFO - 2022-03-31 14:22:37 --> Helper loaded: url_helper
INFO - 2022-03-31 14:22:37 --> Helper loaded: form_helper
INFO - 2022-03-31 14:22:37 --> Helper loaded: common_helper
INFO - 2022-03-31 14:22:37 --> Database Driver Class Initialized
DEBUG - 2022-03-31 14:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 14:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 14:22:37 --> Controller Class Initialized
INFO - 2022-03-31 14:22:37 --> Form Validation Class Initialized
DEBUG - 2022-03-31 14:22:37 --> Encrypt Class Initialized
DEBUG - 2022-03-31 14:22:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 14:22:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 14:22:37 --> Email Class Initialized
INFO - 2022-03-31 14:22:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 14:22:37 --> Calendar Class Initialized
INFO - 2022-03-31 14:22:37 --> Model "Login_model" initialized
INFO - 2022-03-31 14:22:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 14:22:37 --> Final output sent to browser
DEBUG - 2022-03-31 14:22:37 --> Total execution time: 0.0138
ERROR - 2022-03-31 14:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 14:22:38 --> Config Class Initialized
INFO - 2022-03-31 14:22:38 --> Hooks Class Initialized
DEBUG - 2022-03-31 14:22:38 --> UTF-8 Support Enabled
INFO - 2022-03-31 14:22:38 --> Utf8 Class Initialized
INFO - 2022-03-31 14:22:38 --> URI Class Initialized
INFO - 2022-03-31 14:22:38 --> Router Class Initialized
INFO - 2022-03-31 14:22:38 --> Output Class Initialized
INFO - 2022-03-31 14:22:38 --> Security Class Initialized
DEBUG - 2022-03-31 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 14:22:38 --> Input Class Initialized
INFO - 2022-03-31 14:22:38 --> Language Class Initialized
INFO - 2022-03-31 14:22:38 --> Loader Class Initialized
INFO - 2022-03-31 14:22:38 --> Helper loaded: url_helper
INFO - 2022-03-31 14:22:38 --> Helper loaded: form_helper
INFO - 2022-03-31 14:22:38 --> Helper loaded: common_helper
INFO - 2022-03-31 14:22:38 --> Database Driver Class Initialized
DEBUG - 2022-03-31 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 14:22:38 --> Controller Class Initialized
INFO - 2022-03-31 14:22:38 --> Form Validation Class Initialized
DEBUG - 2022-03-31 14:22:38 --> Encrypt Class Initialized
DEBUG - 2022-03-31 14:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 14:22:38 --> Email Class Initialized
INFO - 2022-03-31 14:22:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 14:22:38 --> Calendar Class Initialized
INFO - 2022-03-31 14:22:38 --> Model "Login_model" initialized
INFO - 2022-03-31 14:22:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 14:22:38 --> Final output sent to browser
DEBUG - 2022-03-31 14:22:38 --> Total execution time: 0.0167
ERROR - 2022-03-31 14:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 14:22:38 --> Config Class Initialized
INFO - 2022-03-31 14:22:38 --> Hooks Class Initialized
DEBUG - 2022-03-31 14:22:38 --> UTF-8 Support Enabled
INFO - 2022-03-31 14:22:38 --> Utf8 Class Initialized
INFO - 2022-03-31 14:22:38 --> URI Class Initialized
INFO - 2022-03-31 14:22:38 --> Router Class Initialized
INFO - 2022-03-31 14:22:38 --> Output Class Initialized
INFO - 2022-03-31 14:22:38 --> Security Class Initialized
DEBUG - 2022-03-31 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 14:22:38 --> Input Class Initialized
INFO - 2022-03-31 14:22:38 --> Language Class Initialized
INFO - 2022-03-31 14:22:38 --> Loader Class Initialized
INFO - 2022-03-31 14:22:38 --> Helper loaded: url_helper
INFO - 2022-03-31 14:22:38 --> Helper loaded: form_helper
INFO - 2022-03-31 14:22:38 --> Helper loaded: common_helper
INFO - 2022-03-31 14:22:38 --> Database Driver Class Initialized
DEBUG - 2022-03-31 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 14:22:38 --> Controller Class Initialized
INFO - 2022-03-31 14:22:38 --> Form Validation Class Initialized
DEBUG - 2022-03-31 14:22:38 --> Encrypt Class Initialized
DEBUG - 2022-03-31 14:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 14:22:38 --> Email Class Initialized
INFO - 2022-03-31 14:22:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 14:22:38 --> Calendar Class Initialized
INFO - 2022-03-31 14:22:38 --> Model "Login_model" initialized
ERROR - 2022-03-31 14:22:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 14:22:39 --> Config Class Initialized
INFO - 2022-03-31 14:22:39 --> Hooks Class Initialized
DEBUG - 2022-03-31 14:22:39 --> UTF-8 Support Enabled
INFO - 2022-03-31 14:22:39 --> Utf8 Class Initialized
INFO - 2022-03-31 14:22:39 --> URI Class Initialized
INFO - 2022-03-31 14:22:39 --> Router Class Initialized
INFO - 2022-03-31 14:22:39 --> Output Class Initialized
INFO - 2022-03-31 14:22:39 --> Security Class Initialized
DEBUG - 2022-03-31 14:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 14:22:39 --> Input Class Initialized
INFO - 2022-03-31 14:22:39 --> Language Class Initialized
INFO - 2022-03-31 14:22:39 --> Loader Class Initialized
INFO - 2022-03-31 14:22:39 --> Helper loaded: url_helper
INFO - 2022-03-31 14:22:39 --> Helper loaded: form_helper
INFO - 2022-03-31 14:22:39 --> Helper loaded: common_helper
INFO - 2022-03-31 14:22:39 --> Database Driver Class Initialized
DEBUG - 2022-03-31 14:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 14:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 14:22:39 --> Controller Class Initialized
INFO - 2022-03-31 14:22:39 --> Form Validation Class Initialized
DEBUG - 2022-03-31 14:22:39 --> Encrypt Class Initialized
DEBUG - 2022-03-31 14:22:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 14:22:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 14:22:39 --> Email Class Initialized
INFO - 2022-03-31 14:22:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 14:22:39 --> Calendar Class Initialized
INFO - 2022-03-31 14:22:39 --> Model "Login_model" initialized
ERROR - 2022-03-31 15:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 15:21:58 --> Config Class Initialized
INFO - 2022-03-31 15:21:58 --> Hooks Class Initialized
DEBUG - 2022-03-31 15:21:58 --> UTF-8 Support Enabled
INFO - 2022-03-31 15:21:58 --> Utf8 Class Initialized
INFO - 2022-03-31 15:21:58 --> URI Class Initialized
DEBUG - 2022-03-31 15:21:58 --> No URI present. Default controller set.
INFO - 2022-03-31 15:21:58 --> Router Class Initialized
INFO - 2022-03-31 15:21:58 --> Output Class Initialized
INFO - 2022-03-31 15:21:58 --> Security Class Initialized
DEBUG - 2022-03-31 15:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 15:21:58 --> Input Class Initialized
INFO - 2022-03-31 15:21:58 --> Language Class Initialized
INFO - 2022-03-31 15:21:58 --> Loader Class Initialized
INFO - 2022-03-31 15:21:58 --> Helper loaded: url_helper
INFO - 2022-03-31 15:21:58 --> Helper loaded: form_helper
INFO - 2022-03-31 15:21:58 --> Helper loaded: common_helper
INFO - 2022-03-31 15:21:58 --> Database Driver Class Initialized
DEBUG - 2022-03-31 15:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 15:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 15:21:58 --> Controller Class Initialized
INFO - 2022-03-31 15:21:58 --> Form Validation Class Initialized
DEBUG - 2022-03-31 15:21:58 --> Encrypt Class Initialized
DEBUG - 2022-03-31 15:21:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 15:21:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 15:21:58 --> Email Class Initialized
INFO - 2022-03-31 15:21:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 15:21:58 --> Calendar Class Initialized
INFO - 2022-03-31 15:21:58 --> Model "Login_model" initialized
INFO - 2022-03-31 15:21:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 15:21:58 --> Final output sent to browser
DEBUG - 2022-03-31 15:21:58 --> Total execution time: 0.0551
ERROR - 2022-03-31 18:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 18:09:48 --> Config Class Initialized
INFO - 2022-03-31 18:09:48 --> Hooks Class Initialized
DEBUG - 2022-03-31 18:09:48 --> UTF-8 Support Enabled
INFO - 2022-03-31 18:09:48 --> Utf8 Class Initialized
INFO - 2022-03-31 18:09:48 --> URI Class Initialized
DEBUG - 2022-03-31 18:09:48 --> No URI present. Default controller set.
INFO - 2022-03-31 18:09:48 --> Router Class Initialized
INFO - 2022-03-31 18:09:48 --> Output Class Initialized
INFO - 2022-03-31 18:09:48 --> Security Class Initialized
DEBUG - 2022-03-31 18:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 18:09:48 --> Input Class Initialized
INFO - 2022-03-31 18:09:48 --> Language Class Initialized
INFO - 2022-03-31 18:09:48 --> Loader Class Initialized
INFO - 2022-03-31 18:09:48 --> Helper loaded: url_helper
INFO - 2022-03-31 18:09:48 --> Helper loaded: form_helper
INFO - 2022-03-31 18:09:48 --> Helper loaded: common_helper
INFO - 2022-03-31 18:09:48 --> Database Driver Class Initialized
DEBUG - 2022-03-31 18:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 18:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 18:09:48 --> Controller Class Initialized
INFO - 2022-03-31 18:09:48 --> Form Validation Class Initialized
DEBUG - 2022-03-31 18:09:48 --> Encrypt Class Initialized
DEBUG - 2022-03-31 18:09:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 18:09:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 18:09:48 --> Email Class Initialized
INFO - 2022-03-31 18:09:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 18:09:48 --> Calendar Class Initialized
INFO - 2022-03-31 18:09:48 --> Model "Login_model" initialized
INFO - 2022-03-31 18:09:48 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 18:09:48 --> Final output sent to browser
DEBUG - 2022-03-31 18:09:48 --> Total execution time: 0.0696
ERROR - 2022-03-31 18:24:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 18:24:47 --> Config Class Initialized
INFO - 2022-03-31 18:24:47 --> Hooks Class Initialized
DEBUG - 2022-03-31 18:24:47 --> UTF-8 Support Enabled
INFO - 2022-03-31 18:24:47 --> Utf8 Class Initialized
INFO - 2022-03-31 18:24:47 --> URI Class Initialized
DEBUG - 2022-03-31 18:24:47 --> No URI present. Default controller set.
INFO - 2022-03-31 18:24:47 --> Router Class Initialized
INFO - 2022-03-31 18:24:47 --> Output Class Initialized
INFO - 2022-03-31 18:24:47 --> Security Class Initialized
DEBUG - 2022-03-31 18:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 18:24:47 --> Input Class Initialized
INFO - 2022-03-31 18:24:47 --> Language Class Initialized
INFO - 2022-03-31 18:24:47 --> Loader Class Initialized
INFO - 2022-03-31 18:24:47 --> Helper loaded: url_helper
INFO - 2022-03-31 18:24:47 --> Helper loaded: form_helper
INFO - 2022-03-31 18:24:47 --> Helper loaded: common_helper
INFO - 2022-03-31 18:24:47 --> Database Driver Class Initialized
DEBUG - 2022-03-31 18:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 18:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 18:24:47 --> Controller Class Initialized
INFO - 2022-03-31 18:24:47 --> Form Validation Class Initialized
DEBUG - 2022-03-31 18:24:47 --> Encrypt Class Initialized
DEBUG - 2022-03-31 18:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 18:24:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 18:24:47 --> Email Class Initialized
INFO - 2022-03-31 18:24:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 18:24:47 --> Calendar Class Initialized
INFO - 2022-03-31 18:24:47 --> Model "Login_model" initialized
INFO - 2022-03-31 18:24:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 18:24:47 --> Final output sent to browser
DEBUG - 2022-03-31 18:24:47 --> Total execution time: 0.0655
ERROR - 2022-03-31 20:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 20:13:25 --> Config Class Initialized
INFO - 2022-03-31 20:13:25 --> Hooks Class Initialized
DEBUG - 2022-03-31 20:13:25 --> UTF-8 Support Enabled
INFO - 2022-03-31 20:13:25 --> Utf8 Class Initialized
INFO - 2022-03-31 20:13:25 --> URI Class Initialized
DEBUG - 2022-03-31 20:13:25 --> No URI present. Default controller set.
INFO - 2022-03-31 20:13:25 --> Router Class Initialized
INFO - 2022-03-31 20:13:25 --> Output Class Initialized
INFO - 2022-03-31 20:13:25 --> Security Class Initialized
DEBUG - 2022-03-31 20:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 20:13:25 --> Input Class Initialized
INFO - 2022-03-31 20:13:25 --> Language Class Initialized
INFO - 2022-03-31 20:13:25 --> Loader Class Initialized
INFO - 2022-03-31 20:13:25 --> Helper loaded: url_helper
INFO - 2022-03-31 20:13:25 --> Helper loaded: form_helper
INFO - 2022-03-31 20:13:25 --> Helper loaded: common_helper
INFO - 2022-03-31 20:13:25 --> Database Driver Class Initialized
DEBUG - 2022-03-31 20:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 20:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 20:13:25 --> Controller Class Initialized
INFO - 2022-03-31 20:13:25 --> Form Validation Class Initialized
DEBUG - 2022-03-31 20:13:25 --> Encrypt Class Initialized
DEBUG - 2022-03-31 20:13:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 20:13:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 20:13:25 --> Email Class Initialized
INFO - 2022-03-31 20:13:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 20:13:25 --> Calendar Class Initialized
INFO - 2022-03-31 20:13:25 --> Model "Login_model" initialized
INFO - 2022-03-31 20:13:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 20:13:25 --> Final output sent to browser
DEBUG - 2022-03-31 20:13:25 --> Total execution time: 0.0528
ERROR - 2022-03-31 20:40:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 20:40:13 --> Config Class Initialized
INFO - 2022-03-31 20:40:13 --> Hooks Class Initialized
DEBUG - 2022-03-31 20:40:13 --> UTF-8 Support Enabled
INFO - 2022-03-31 20:40:13 --> Utf8 Class Initialized
INFO - 2022-03-31 20:40:13 --> URI Class Initialized
DEBUG - 2022-03-31 20:40:13 --> No URI present. Default controller set.
INFO - 2022-03-31 20:40:13 --> Router Class Initialized
INFO - 2022-03-31 20:40:13 --> Output Class Initialized
INFO - 2022-03-31 20:40:13 --> Security Class Initialized
DEBUG - 2022-03-31 20:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 20:40:13 --> Input Class Initialized
INFO - 2022-03-31 20:40:13 --> Language Class Initialized
INFO - 2022-03-31 20:40:13 --> Loader Class Initialized
INFO - 2022-03-31 20:40:13 --> Helper loaded: url_helper
INFO - 2022-03-31 20:40:13 --> Helper loaded: form_helper
INFO - 2022-03-31 20:40:13 --> Helper loaded: common_helper
INFO - 2022-03-31 20:40:13 --> Database Driver Class Initialized
DEBUG - 2022-03-31 20:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 20:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 20:40:13 --> Controller Class Initialized
INFO - 2022-03-31 20:40:13 --> Form Validation Class Initialized
DEBUG - 2022-03-31 20:40:13 --> Encrypt Class Initialized
DEBUG - 2022-03-31 20:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 20:40:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 20:40:13 --> Email Class Initialized
INFO - 2022-03-31 20:40:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 20:40:13 --> Calendar Class Initialized
INFO - 2022-03-31 20:40:13 --> Model "Login_model" initialized
INFO - 2022-03-31 20:40:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 20:40:13 --> Final output sent to browser
DEBUG - 2022-03-31 20:40:13 --> Total execution time: 0.0739
ERROR - 2022-03-31 20:40:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 20:40:14 --> Config Class Initialized
INFO - 2022-03-31 20:40:14 --> Hooks Class Initialized
DEBUG - 2022-03-31 20:40:14 --> UTF-8 Support Enabled
INFO - 2022-03-31 20:40:14 --> Utf8 Class Initialized
INFO - 2022-03-31 20:40:14 --> URI Class Initialized
INFO - 2022-03-31 20:40:14 --> Router Class Initialized
INFO - 2022-03-31 20:40:14 --> Output Class Initialized
INFO - 2022-03-31 20:40:14 --> Security Class Initialized
DEBUG - 2022-03-31 20:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 20:40:14 --> Input Class Initialized
INFO - 2022-03-31 20:40:14 --> Language Class Initialized
ERROR - 2022-03-31 20:40:14 --> 404 Page Not Found: Register/index
ERROR - 2022-03-31 20:40:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 20:40:15 --> Config Class Initialized
INFO - 2022-03-31 20:40:15 --> Hooks Class Initialized
DEBUG - 2022-03-31 20:40:15 --> UTF-8 Support Enabled
INFO - 2022-03-31 20:40:15 --> Utf8 Class Initialized
INFO - 2022-03-31 20:40:15 --> URI Class Initialized
INFO - 2022-03-31 20:40:15 --> Router Class Initialized
INFO - 2022-03-31 20:40:15 --> Output Class Initialized
INFO - 2022-03-31 20:40:15 --> Security Class Initialized
DEBUG - 2022-03-31 20:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 20:40:15 --> Input Class Initialized
INFO - 2022-03-31 20:40:15 --> Language Class Initialized
INFO - 2022-03-31 20:40:15 --> Loader Class Initialized
INFO - 2022-03-31 20:40:15 --> Helper loaded: url_helper
INFO - 2022-03-31 20:40:15 --> Helper loaded: form_helper
INFO - 2022-03-31 20:40:15 --> Helper loaded: common_helper
INFO - 2022-03-31 20:40:15 --> Database Driver Class Initialized
DEBUG - 2022-03-31 20:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 20:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 20:40:15 --> Controller Class Initialized
INFO - 2022-03-31 20:40:15 --> Form Validation Class Initialized
DEBUG - 2022-03-31 20:40:15 --> Encrypt Class Initialized
DEBUG - 2022-03-31 20:40:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 20:40:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 20:40:15 --> Email Class Initialized
INFO - 2022-03-31 20:40:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 20:40:15 --> Calendar Class Initialized
INFO - 2022-03-31 20:40:15 --> Model "Login_model" initialized
INFO - 2022-03-31 20:40:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 20:40:15 --> Final output sent to browser
DEBUG - 2022-03-31 20:40:15 --> Total execution time: 0.0043
ERROR - 2022-03-31 20:40:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 20:40:15 --> Config Class Initialized
INFO - 2022-03-31 20:40:15 --> Hooks Class Initialized
DEBUG - 2022-03-31 20:40:15 --> UTF-8 Support Enabled
INFO - 2022-03-31 20:40:15 --> Utf8 Class Initialized
INFO - 2022-03-31 20:40:15 --> URI Class Initialized
DEBUG - 2022-03-31 20:40:15 --> No URI present. Default controller set.
INFO - 2022-03-31 20:40:15 --> Router Class Initialized
INFO - 2022-03-31 20:40:15 --> Output Class Initialized
INFO - 2022-03-31 20:40:15 --> Security Class Initialized
DEBUG - 2022-03-31 20:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 20:40:15 --> Input Class Initialized
INFO - 2022-03-31 20:40:15 --> Language Class Initialized
INFO - 2022-03-31 20:40:15 --> Loader Class Initialized
INFO - 2022-03-31 20:40:15 --> Helper loaded: url_helper
INFO - 2022-03-31 20:40:15 --> Helper loaded: form_helper
INFO - 2022-03-31 20:40:15 --> Helper loaded: common_helper
INFO - 2022-03-31 20:40:15 --> Database Driver Class Initialized
DEBUG - 2022-03-31 20:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 20:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 20:40:15 --> Controller Class Initialized
INFO - 2022-03-31 20:40:15 --> Form Validation Class Initialized
DEBUG - 2022-03-31 20:40:15 --> Encrypt Class Initialized
DEBUG - 2022-03-31 20:40:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 20:40:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 20:40:15 --> Email Class Initialized
INFO - 2022-03-31 20:40:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 20:40:15 --> Calendar Class Initialized
INFO - 2022-03-31 20:40:15 --> Model "Login_model" initialized
INFO - 2022-03-31 20:40:15 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 20:40:15 --> Final output sent to browser
DEBUG - 2022-03-31 20:40:15 --> Total execution time: 0.0044
ERROR - 2022-03-31 20:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 20:40:16 --> Config Class Initialized
INFO - 2022-03-31 20:40:16 --> Hooks Class Initialized
DEBUG - 2022-03-31 20:40:16 --> UTF-8 Support Enabled
INFO - 2022-03-31 20:40:16 --> Utf8 Class Initialized
INFO - 2022-03-31 20:40:16 --> URI Class Initialized
INFO - 2022-03-31 20:40:16 --> Router Class Initialized
INFO - 2022-03-31 20:40:16 --> Output Class Initialized
INFO - 2022-03-31 20:40:16 --> Security Class Initialized
DEBUG - 2022-03-31 20:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 20:40:16 --> Input Class Initialized
INFO - 2022-03-31 20:40:16 --> Language Class Initialized
INFO - 2022-03-31 20:40:16 --> Loader Class Initialized
INFO - 2022-03-31 20:40:16 --> Helper loaded: url_helper
INFO - 2022-03-31 20:40:16 --> Helper loaded: form_helper
INFO - 2022-03-31 20:40:16 --> Helper loaded: common_helper
INFO - 2022-03-31 20:40:16 --> Database Driver Class Initialized
DEBUG - 2022-03-31 20:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 20:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 20:40:16 --> Controller Class Initialized
INFO - 2022-03-31 20:40:16 --> Form Validation Class Initialized
DEBUG - 2022-03-31 20:40:16 --> Encrypt Class Initialized
DEBUG - 2022-03-31 20:40:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 20:40:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 20:40:16 --> Email Class Initialized
INFO - 2022-03-31 20:40:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 20:40:16 --> Calendar Class Initialized
INFO - 2022-03-31 20:40:16 --> Model "Login_model" initialized
ERROR - 2022-03-31 20:40:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 20:40:17 --> Config Class Initialized
INFO - 2022-03-31 20:40:17 --> Hooks Class Initialized
DEBUG - 2022-03-31 20:40:17 --> UTF-8 Support Enabled
INFO - 2022-03-31 20:40:17 --> Utf8 Class Initialized
INFO - 2022-03-31 20:40:17 --> URI Class Initialized
INFO - 2022-03-31 20:40:17 --> Router Class Initialized
INFO - 2022-03-31 20:40:17 --> Output Class Initialized
INFO - 2022-03-31 20:40:17 --> Security Class Initialized
DEBUG - 2022-03-31 20:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 20:40:17 --> Input Class Initialized
INFO - 2022-03-31 20:40:17 --> Language Class Initialized
INFO - 2022-03-31 20:40:17 --> Loader Class Initialized
INFO - 2022-03-31 20:40:17 --> Helper loaded: url_helper
INFO - 2022-03-31 20:40:17 --> Helper loaded: form_helper
INFO - 2022-03-31 20:40:17 --> Helper loaded: common_helper
INFO - 2022-03-31 20:40:17 --> Database Driver Class Initialized
DEBUG - 2022-03-31 20:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 20:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 20:40:17 --> Controller Class Initialized
INFO - 2022-03-31 20:40:17 --> Form Validation Class Initialized
DEBUG - 2022-03-31 20:40:17 --> Encrypt Class Initialized
DEBUG - 2022-03-31 20:40:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 20:40:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 20:40:17 --> Email Class Initialized
INFO - 2022-03-31 20:40:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 20:40:17 --> Calendar Class Initialized
INFO - 2022-03-31 20:40:17 --> Model "Login_model" initialized
INFO - 2022-03-31 20:40:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 20:40:17 --> Final output sent to browser
DEBUG - 2022-03-31 20:40:17 --> Total execution time: 0.0042
ERROR - 2022-03-31 23:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-31 23:09:07 --> Config Class Initialized
INFO - 2022-03-31 23:09:07 --> Hooks Class Initialized
DEBUG - 2022-03-31 23:09:07 --> UTF-8 Support Enabled
INFO - 2022-03-31 23:09:07 --> Utf8 Class Initialized
INFO - 2022-03-31 23:09:07 --> URI Class Initialized
DEBUG - 2022-03-31 23:09:07 --> No URI present. Default controller set.
INFO - 2022-03-31 23:09:07 --> Router Class Initialized
INFO - 2022-03-31 23:09:07 --> Output Class Initialized
INFO - 2022-03-31 23:09:07 --> Security Class Initialized
DEBUG - 2022-03-31 23:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-31 23:09:07 --> Input Class Initialized
INFO - 2022-03-31 23:09:07 --> Language Class Initialized
INFO - 2022-03-31 23:09:07 --> Loader Class Initialized
INFO - 2022-03-31 23:09:07 --> Helper loaded: url_helper
INFO - 2022-03-31 23:09:07 --> Helper loaded: form_helper
INFO - 2022-03-31 23:09:07 --> Helper loaded: common_helper
INFO - 2022-03-31 23:09:07 --> Database Driver Class Initialized
DEBUG - 2022-03-31 23:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-31 23:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-31 23:09:07 --> Controller Class Initialized
INFO - 2022-03-31 23:09:07 --> Form Validation Class Initialized
DEBUG - 2022-03-31 23:09:07 --> Encrypt Class Initialized
DEBUG - 2022-03-31 23:09:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-31 23:09:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-31 23:09:07 --> Email Class Initialized
INFO - 2022-03-31 23:09:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-31 23:09:07 --> Calendar Class Initialized
INFO - 2022-03-31 23:09:07 --> Model "Login_model" initialized
INFO - 2022-03-31 23:09:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-31 23:09:07 --> Final output sent to browser
DEBUG - 2022-03-31 23:09:07 --> Total execution time: 0.0566
