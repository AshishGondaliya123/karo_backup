<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-30 00:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 00:42:40 --> Config Class Initialized
INFO - 2021-12-30 00:42:40 --> Hooks Class Initialized
DEBUG - 2021-12-30 00:42:40 --> UTF-8 Support Enabled
INFO - 2021-12-30 00:42:40 --> Utf8 Class Initialized
INFO - 2021-12-30 00:42:40 --> URI Class Initialized
DEBUG - 2021-12-30 00:42:40 --> No URI present. Default controller set.
INFO - 2021-12-30 00:42:40 --> Router Class Initialized
INFO - 2021-12-30 00:42:40 --> Output Class Initialized
INFO - 2021-12-30 00:42:40 --> Security Class Initialized
DEBUG - 2021-12-30 00:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 00:42:40 --> Input Class Initialized
INFO - 2021-12-30 00:42:40 --> Language Class Initialized
INFO - 2021-12-30 00:42:40 --> Loader Class Initialized
INFO - 2021-12-30 00:42:40 --> Helper loaded: url_helper
INFO - 2021-12-30 00:42:40 --> Helper loaded: form_helper
INFO - 2021-12-30 00:42:40 --> Helper loaded: common_helper
INFO - 2021-12-30 00:42:40 --> Database Driver Class Initialized
DEBUG - 2021-12-30 00:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 00:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 00:42:40 --> Controller Class Initialized
INFO - 2021-12-30 00:42:40 --> Form Validation Class Initialized
DEBUG - 2021-12-30 00:42:40 --> Encrypt Class Initialized
DEBUG - 2021-12-30 00:42:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 00:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 00:42:40 --> Email Class Initialized
INFO - 2021-12-30 00:42:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 00:42:40 --> Calendar Class Initialized
INFO - 2021-12-30 00:42:40 --> Model "Login_model" initialized
INFO - 2021-12-30 00:42:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 00:42:40 --> Final output sent to browser
DEBUG - 2021-12-30 00:42:40 --> Total execution time: 0.0447
ERROR - 2021-12-30 05:48:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 05:48:35 --> Config Class Initialized
INFO - 2021-12-30 05:48:35 --> Hooks Class Initialized
DEBUG - 2021-12-30 05:48:35 --> UTF-8 Support Enabled
INFO - 2021-12-30 05:48:35 --> Utf8 Class Initialized
INFO - 2021-12-30 05:48:35 --> URI Class Initialized
DEBUG - 2021-12-30 05:48:35 --> No URI present. Default controller set.
INFO - 2021-12-30 05:48:35 --> Router Class Initialized
INFO - 2021-12-30 05:48:35 --> Output Class Initialized
INFO - 2021-12-30 05:48:35 --> Security Class Initialized
DEBUG - 2021-12-30 05:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 05:48:35 --> Input Class Initialized
INFO - 2021-12-30 05:48:35 --> Language Class Initialized
INFO - 2021-12-30 05:48:35 --> Loader Class Initialized
INFO - 2021-12-30 05:48:35 --> Helper loaded: url_helper
INFO - 2021-12-30 05:48:35 --> Helper loaded: form_helper
INFO - 2021-12-30 05:48:35 --> Helper loaded: common_helper
INFO - 2021-12-30 05:48:35 --> Database Driver Class Initialized
DEBUG - 2021-12-30 05:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 05:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 05:48:35 --> Controller Class Initialized
INFO - 2021-12-30 05:48:35 --> Form Validation Class Initialized
DEBUG - 2021-12-30 05:48:35 --> Encrypt Class Initialized
DEBUG - 2021-12-30 05:48:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 05:48:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 05:48:35 --> Email Class Initialized
INFO - 2021-12-30 05:48:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 05:48:35 --> Calendar Class Initialized
INFO - 2021-12-30 05:48:35 --> Model "Login_model" initialized
INFO - 2021-12-30 05:48:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 05:48:35 --> Final output sent to browser
DEBUG - 2021-12-30 05:48:35 --> Total execution time: 0.0369
ERROR - 2021-12-30 05:48:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 05:48:47 --> Config Class Initialized
INFO - 2021-12-30 05:48:47 --> Hooks Class Initialized
DEBUG - 2021-12-30 05:48:47 --> UTF-8 Support Enabled
INFO - 2021-12-30 05:48:47 --> Utf8 Class Initialized
INFO - 2021-12-30 05:48:47 --> URI Class Initialized
DEBUG - 2021-12-30 05:48:47 --> No URI present. Default controller set.
INFO - 2021-12-30 05:48:47 --> Router Class Initialized
INFO - 2021-12-30 05:48:47 --> Output Class Initialized
INFO - 2021-12-30 05:48:47 --> Security Class Initialized
DEBUG - 2021-12-30 05:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 05:48:47 --> Input Class Initialized
INFO - 2021-12-30 05:48:47 --> Language Class Initialized
INFO - 2021-12-30 05:48:47 --> Loader Class Initialized
INFO - 2021-12-30 05:48:47 --> Helper loaded: url_helper
INFO - 2021-12-30 05:48:47 --> Helper loaded: form_helper
INFO - 2021-12-30 05:48:47 --> Helper loaded: common_helper
INFO - 2021-12-30 05:48:47 --> Database Driver Class Initialized
DEBUG - 2021-12-30 05:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 05:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 05:48:47 --> Controller Class Initialized
INFO - 2021-12-30 05:48:47 --> Form Validation Class Initialized
DEBUG - 2021-12-30 05:48:47 --> Encrypt Class Initialized
DEBUG - 2021-12-30 05:48:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 05:48:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 05:48:47 --> Email Class Initialized
INFO - 2021-12-30 05:48:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 05:48:47 --> Calendar Class Initialized
INFO - 2021-12-30 05:48:47 --> Model "Login_model" initialized
INFO - 2021-12-30 05:48:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 05:48:47 --> Final output sent to browser
DEBUG - 2021-12-30 05:48:47 --> Total execution time: 0.0336
ERROR - 2021-12-30 06:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:13:44 --> Config Class Initialized
INFO - 2021-12-30 06:13:44 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:13:44 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:13:44 --> Utf8 Class Initialized
INFO - 2021-12-30 06:13:44 --> URI Class Initialized
DEBUG - 2021-12-30 06:13:44 --> No URI present. Default controller set.
INFO - 2021-12-30 06:13:44 --> Router Class Initialized
INFO - 2021-12-30 06:13:44 --> Output Class Initialized
INFO - 2021-12-30 06:13:44 --> Security Class Initialized
DEBUG - 2021-12-30 06:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:13:44 --> Input Class Initialized
INFO - 2021-12-30 06:13:44 --> Language Class Initialized
INFO - 2021-12-30 06:13:44 --> Loader Class Initialized
INFO - 2021-12-30 06:13:44 --> Helper loaded: url_helper
INFO - 2021-12-30 06:13:44 --> Helper loaded: form_helper
INFO - 2021-12-30 06:13:44 --> Helper loaded: common_helper
INFO - 2021-12-30 06:13:44 --> Database Driver Class Initialized
DEBUG - 2021-12-30 06:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 06:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 06:13:44 --> Controller Class Initialized
INFO - 2021-12-30 06:13:44 --> Form Validation Class Initialized
DEBUG - 2021-12-30 06:13:44 --> Encrypt Class Initialized
DEBUG - 2021-12-30 06:13:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 06:13:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 06:13:44 --> Email Class Initialized
INFO - 2021-12-30 06:13:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 06:13:44 --> Calendar Class Initialized
INFO - 2021-12-30 06:13:44 --> Model "Login_model" initialized
INFO - 2021-12-30 06:13:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 06:13:44 --> Final output sent to browser
DEBUG - 2021-12-30 06:13:44 --> Total execution time: 0.0364
ERROR - 2021-12-30 06:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:09 --> Config Class Initialized
INFO - 2021-12-30 06:31:09 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:09 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:09 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:09 --> URI Class Initialized
DEBUG - 2021-12-30 06:31:09 --> No URI present. Default controller set.
INFO - 2021-12-30 06:31:09 --> Router Class Initialized
INFO - 2021-12-30 06:31:09 --> Output Class Initialized
INFO - 2021-12-30 06:31:09 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:09 --> Input Class Initialized
INFO - 2021-12-30 06:31:09 --> Language Class Initialized
INFO - 2021-12-30 06:31:09 --> Loader Class Initialized
INFO - 2021-12-30 06:31:09 --> Helper loaded: url_helper
INFO - 2021-12-30 06:31:09 --> Helper loaded: form_helper
INFO - 2021-12-30 06:31:09 --> Helper loaded: common_helper
INFO - 2021-12-30 06:31:09 --> Database Driver Class Initialized
DEBUG - 2021-12-30 06:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 06:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 06:31:09 --> Controller Class Initialized
INFO - 2021-12-30 06:31:09 --> Form Validation Class Initialized
DEBUG - 2021-12-30 06:31:09 --> Encrypt Class Initialized
DEBUG - 2021-12-30 06:31:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 06:31:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 06:31:09 --> Email Class Initialized
INFO - 2021-12-30 06:31:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 06:31:09 --> Calendar Class Initialized
INFO - 2021-12-30 06:31:09 --> Model "Login_model" initialized
INFO - 2021-12-30 06:31:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 06:31:09 --> Final output sent to browser
DEBUG - 2021-12-30 06:31:09 --> Total execution time: 0.0344
ERROR - 2021-12-30 06:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:10 --> Config Class Initialized
INFO - 2021-12-30 06:31:10 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:10 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:10 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:10 --> URI Class Initialized
DEBUG - 2021-12-30 06:31:10 --> No URI present. Default controller set.
INFO - 2021-12-30 06:31:10 --> Router Class Initialized
INFO - 2021-12-30 06:31:10 --> Output Class Initialized
INFO - 2021-12-30 06:31:10 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:10 --> Input Class Initialized
INFO - 2021-12-30 06:31:10 --> Language Class Initialized
INFO - 2021-12-30 06:31:10 --> Loader Class Initialized
INFO - 2021-12-30 06:31:10 --> Helper loaded: url_helper
INFO - 2021-12-30 06:31:10 --> Helper loaded: form_helper
INFO - 2021-12-30 06:31:10 --> Helper loaded: common_helper
INFO - 2021-12-30 06:31:10 --> Database Driver Class Initialized
DEBUG - 2021-12-30 06:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 06:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 06:31:10 --> Controller Class Initialized
INFO - 2021-12-30 06:31:10 --> Form Validation Class Initialized
DEBUG - 2021-12-30 06:31:10 --> Encrypt Class Initialized
DEBUG - 2021-12-30 06:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 06:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 06:31:10 --> Email Class Initialized
INFO - 2021-12-30 06:31:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 06:31:10 --> Calendar Class Initialized
INFO - 2021-12-30 06:31:10 --> Model "Login_model" initialized
INFO - 2021-12-30 06:31:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 06:31:10 --> Final output sent to browser
DEBUG - 2021-12-30 06:31:10 --> Total execution time: 0.0353
ERROR - 2021-12-30 06:31:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:11 --> Config Class Initialized
INFO - 2021-12-30 06:31:11 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:11 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:11 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:11 --> URI Class Initialized
INFO - 2021-12-30 06:31:11 --> Router Class Initialized
INFO - 2021-12-30 06:31:11 --> Output Class Initialized
INFO - 2021-12-30 06:31:11 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:11 --> Input Class Initialized
INFO - 2021-12-30 06:31:11 --> Language Class Initialized
ERROR - 2021-12-30 06:31:11 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-30 06:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:12 --> Config Class Initialized
INFO - 2021-12-30 06:31:12 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:12 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:12 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:12 --> URI Class Initialized
DEBUG - 2021-12-30 06:31:12 --> No URI present. Default controller set.
INFO - 2021-12-30 06:31:12 --> Router Class Initialized
INFO - 2021-12-30 06:31:12 --> Output Class Initialized
INFO - 2021-12-30 06:31:12 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:12 --> Input Class Initialized
INFO - 2021-12-30 06:31:12 --> Language Class Initialized
INFO - 2021-12-30 06:31:12 --> Loader Class Initialized
INFO - 2021-12-30 06:31:12 --> Helper loaded: url_helper
INFO - 2021-12-30 06:31:12 --> Helper loaded: form_helper
INFO - 2021-12-30 06:31:12 --> Helper loaded: common_helper
INFO - 2021-12-30 06:31:12 --> Database Driver Class Initialized
DEBUG - 2021-12-30 06:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 06:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 06:31:12 --> Controller Class Initialized
INFO - 2021-12-30 06:31:12 --> Form Validation Class Initialized
DEBUG - 2021-12-30 06:31:12 --> Encrypt Class Initialized
DEBUG - 2021-12-30 06:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 06:31:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 06:31:12 --> Email Class Initialized
INFO - 2021-12-30 06:31:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 06:31:12 --> Calendar Class Initialized
INFO - 2021-12-30 06:31:12 --> Model "Login_model" initialized
INFO - 2021-12-30 06:31:12 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 06:31:12 --> Final output sent to browser
DEBUG - 2021-12-30 06:31:12 --> Total execution time: 0.0369
ERROR - 2021-12-30 06:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:13 --> Config Class Initialized
INFO - 2021-12-30 06:31:13 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:13 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:13 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:13 --> URI Class Initialized
INFO - 2021-12-30 06:31:13 --> Router Class Initialized
INFO - 2021-12-30 06:31:13 --> Output Class Initialized
INFO - 2021-12-30 06:31:13 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:13 --> Input Class Initialized
INFO - 2021-12-30 06:31:13 --> Language Class Initialized
ERROR - 2021-12-30 06:31:13 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-30 06:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:14 --> Config Class Initialized
INFO - 2021-12-30 06:31:14 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:14 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:14 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:14 --> URI Class Initialized
INFO - 2021-12-30 06:31:14 --> Router Class Initialized
INFO - 2021-12-30 06:31:14 --> Output Class Initialized
INFO - 2021-12-30 06:31:14 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:14 --> Input Class Initialized
INFO - 2021-12-30 06:31:14 --> Language Class Initialized
ERROR - 2021-12-30 06:31:14 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-30 06:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:14 --> Config Class Initialized
INFO - 2021-12-30 06:31:14 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:14 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:14 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:14 --> URI Class Initialized
INFO - 2021-12-30 06:31:14 --> Router Class Initialized
INFO - 2021-12-30 06:31:14 --> Output Class Initialized
INFO - 2021-12-30 06:31:14 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:14 --> Input Class Initialized
INFO - 2021-12-30 06:31:14 --> Language Class Initialized
ERROR - 2021-12-30 06:31:14 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-30 06:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:15 --> Config Class Initialized
INFO - 2021-12-30 06:31:15 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:15 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:15 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:15 --> URI Class Initialized
INFO - 2021-12-30 06:31:15 --> Router Class Initialized
INFO - 2021-12-30 06:31:15 --> Output Class Initialized
INFO - 2021-12-30 06:31:15 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:15 --> Input Class Initialized
INFO - 2021-12-30 06:31:15 --> Language Class Initialized
ERROR - 2021-12-30 06:31:15 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-30 06:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:15 --> Config Class Initialized
INFO - 2021-12-30 06:31:15 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:15 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:15 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:15 --> URI Class Initialized
INFO - 2021-12-30 06:31:15 --> Router Class Initialized
INFO - 2021-12-30 06:31:15 --> Output Class Initialized
INFO - 2021-12-30 06:31:15 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:15 --> Input Class Initialized
INFO - 2021-12-30 06:31:15 --> Language Class Initialized
ERROR - 2021-12-30 06:31:15 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-30 06:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:16 --> Config Class Initialized
INFO - 2021-12-30 06:31:16 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:16 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:16 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:16 --> URI Class Initialized
INFO - 2021-12-30 06:31:16 --> Router Class Initialized
INFO - 2021-12-30 06:31:16 --> Output Class Initialized
INFO - 2021-12-30 06:31:16 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:16 --> Input Class Initialized
INFO - 2021-12-30 06:31:16 --> Language Class Initialized
ERROR - 2021-12-30 06:31:16 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-30 06:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:16 --> Config Class Initialized
INFO - 2021-12-30 06:31:16 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:16 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:16 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:16 --> URI Class Initialized
INFO - 2021-12-30 06:31:16 --> Router Class Initialized
INFO - 2021-12-30 06:31:16 --> Output Class Initialized
INFO - 2021-12-30 06:31:16 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:16 --> Input Class Initialized
INFO - 2021-12-30 06:31:16 --> Language Class Initialized
ERROR - 2021-12-30 06:31:16 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-30 06:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:17 --> Config Class Initialized
INFO - 2021-12-30 06:31:17 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:17 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:17 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:17 --> URI Class Initialized
INFO - 2021-12-30 06:31:17 --> Router Class Initialized
INFO - 2021-12-30 06:31:17 --> Output Class Initialized
INFO - 2021-12-30 06:31:17 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:17 --> Input Class Initialized
INFO - 2021-12-30 06:31:17 --> Language Class Initialized
ERROR - 2021-12-30 06:31:17 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-30 06:31:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:18 --> Config Class Initialized
INFO - 2021-12-30 06:31:18 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:18 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:18 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:18 --> URI Class Initialized
INFO - 2021-12-30 06:31:18 --> Router Class Initialized
INFO - 2021-12-30 06:31:18 --> Output Class Initialized
INFO - 2021-12-30 06:31:18 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:18 --> Input Class Initialized
INFO - 2021-12-30 06:31:18 --> Language Class Initialized
ERROR - 2021-12-30 06:31:18 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-30 06:31:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:18 --> Config Class Initialized
INFO - 2021-12-30 06:31:18 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:18 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:18 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:18 --> URI Class Initialized
INFO - 2021-12-30 06:31:18 --> Router Class Initialized
INFO - 2021-12-30 06:31:18 --> Output Class Initialized
INFO - 2021-12-30 06:31:18 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:18 --> Input Class Initialized
INFO - 2021-12-30 06:31:18 --> Language Class Initialized
ERROR - 2021-12-30 06:31:18 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-30 06:31:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:19 --> Config Class Initialized
INFO - 2021-12-30 06:31:19 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:19 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:19 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:19 --> URI Class Initialized
INFO - 2021-12-30 06:31:19 --> Router Class Initialized
INFO - 2021-12-30 06:31:19 --> Output Class Initialized
INFO - 2021-12-30 06:31:19 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:19 --> Input Class Initialized
INFO - 2021-12-30 06:31:19 --> Language Class Initialized
ERROR - 2021-12-30 06:31:19 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-30 06:31:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 06:31:19 --> Config Class Initialized
INFO - 2021-12-30 06:31:19 --> Hooks Class Initialized
DEBUG - 2021-12-30 06:31:19 --> UTF-8 Support Enabled
INFO - 2021-12-30 06:31:19 --> Utf8 Class Initialized
INFO - 2021-12-30 06:31:19 --> URI Class Initialized
INFO - 2021-12-30 06:31:19 --> Router Class Initialized
INFO - 2021-12-30 06:31:19 --> Output Class Initialized
INFO - 2021-12-30 06:31:19 --> Security Class Initialized
DEBUG - 2021-12-30 06:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 06:31:19 --> Input Class Initialized
INFO - 2021-12-30 06:31:19 --> Language Class Initialized
ERROR - 2021-12-30 06:31:19 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-30 09:51:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 09:51:40 --> Config Class Initialized
INFO - 2021-12-30 09:51:40 --> Hooks Class Initialized
DEBUG - 2021-12-30 09:51:40 --> UTF-8 Support Enabled
INFO - 2021-12-30 09:51:40 --> Utf8 Class Initialized
INFO - 2021-12-30 09:51:40 --> URI Class Initialized
DEBUG - 2021-12-30 09:51:40 --> No URI present. Default controller set.
INFO - 2021-12-30 09:51:40 --> Router Class Initialized
INFO - 2021-12-30 09:51:40 --> Output Class Initialized
INFO - 2021-12-30 09:51:40 --> Security Class Initialized
DEBUG - 2021-12-30 09:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 09:51:40 --> Input Class Initialized
INFO - 2021-12-30 09:51:40 --> Language Class Initialized
INFO - 2021-12-30 09:51:40 --> Loader Class Initialized
INFO - 2021-12-30 09:51:40 --> Helper loaded: url_helper
INFO - 2021-12-30 09:51:40 --> Helper loaded: form_helper
INFO - 2021-12-30 09:51:40 --> Helper loaded: common_helper
INFO - 2021-12-30 09:51:40 --> Database Driver Class Initialized
DEBUG - 2021-12-30 09:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 09:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 09:51:40 --> Controller Class Initialized
INFO - 2021-12-30 09:51:40 --> Form Validation Class Initialized
DEBUG - 2021-12-30 09:51:40 --> Encrypt Class Initialized
DEBUG - 2021-12-30 09:51:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 09:51:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 09:51:40 --> Email Class Initialized
INFO - 2021-12-30 09:51:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 09:51:40 --> Calendar Class Initialized
INFO - 2021-12-30 09:51:40 --> Model "Login_model" initialized
INFO - 2021-12-30 09:51:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 09:51:40 --> Final output sent to browser
DEBUG - 2021-12-30 09:51:40 --> Total execution time: 0.0229
ERROR - 2021-12-30 12:19:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 12:19:08 --> Config Class Initialized
INFO - 2021-12-30 12:19:08 --> Hooks Class Initialized
DEBUG - 2021-12-30 12:19:08 --> UTF-8 Support Enabled
INFO - 2021-12-30 12:19:08 --> Utf8 Class Initialized
INFO - 2021-12-30 12:19:08 --> URI Class Initialized
DEBUG - 2021-12-30 12:19:08 --> No URI present. Default controller set.
INFO - 2021-12-30 12:19:08 --> Router Class Initialized
INFO - 2021-12-30 12:19:08 --> Output Class Initialized
INFO - 2021-12-30 12:19:08 --> Security Class Initialized
DEBUG - 2021-12-30 12:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 12:19:08 --> Input Class Initialized
INFO - 2021-12-30 12:19:08 --> Language Class Initialized
INFO - 2021-12-30 12:19:08 --> Loader Class Initialized
INFO - 2021-12-30 12:19:08 --> Helper loaded: url_helper
INFO - 2021-12-30 12:19:08 --> Helper loaded: form_helper
INFO - 2021-12-30 12:19:08 --> Helper loaded: common_helper
INFO - 2021-12-30 12:19:08 --> Database Driver Class Initialized
DEBUG - 2021-12-30 12:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 12:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 12:19:08 --> Controller Class Initialized
INFO - 2021-12-30 12:19:08 --> Form Validation Class Initialized
DEBUG - 2021-12-30 12:19:08 --> Encrypt Class Initialized
DEBUG - 2021-12-30 12:19:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 12:19:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 12:19:08 --> Email Class Initialized
INFO - 2021-12-30 12:19:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 12:19:08 --> Calendar Class Initialized
INFO - 2021-12-30 12:19:08 --> Model "Login_model" initialized
INFO - 2021-12-30 12:19:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 12:19:08 --> Final output sent to browser
DEBUG - 2021-12-30 12:19:08 --> Total execution time: 0.0405
ERROR - 2021-12-30 12:19:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 12:19:13 --> Config Class Initialized
INFO - 2021-12-30 12:19:13 --> Hooks Class Initialized
DEBUG - 2021-12-30 12:19:13 --> UTF-8 Support Enabled
INFO - 2021-12-30 12:19:13 --> Utf8 Class Initialized
INFO - 2021-12-30 12:19:13 --> URI Class Initialized
DEBUG - 2021-12-30 12:19:13 --> No URI present. Default controller set.
INFO - 2021-12-30 12:19:13 --> Router Class Initialized
INFO - 2021-12-30 12:19:13 --> Output Class Initialized
INFO - 2021-12-30 12:19:13 --> Security Class Initialized
DEBUG - 2021-12-30 12:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 12:19:13 --> Input Class Initialized
INFO - 2021-12-30 12:19:13 --> Language Class Initialized
INFO - 2021-12-30 12:19:13 --> Loader Class Initialized
INFO - 2021-12-30 12:19:13 --> Helper loaded: url_helper
INFO - 2021-12-30 12:19:13 --> Helper loaded: form_helper
INFO - 2021-12-30 12:19:13 --> Helper loaded: common_helper
INFO - 2021-12-30 12:19:13 --> Database Driver Class Initialized
DEBUG - 2021-12-30 12:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 12:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 12:19:13 --> Controller Class Initialized
INFO - 2021-12-30 12:19:13 --> Form Validation Class Initialized
DEBUG - 2021-12-30 12:19:13 --> Encrypt Class Initialized
DEBUG - 2021-12-30 12:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 12:19:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 12:19:13 --> Email Class Initialized
INFO - 2021-12-30 12:19:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 12:19:13 --> Calendar Class Initialized
INFO - 2021-12-30 12:19:13 --> Model "Login_model" initialized
INFO - 2021-12-30 12:19:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 12:19:13 --> Final output sent to browser
DEBUG - 2021-12-30 12:19:13 --> Total execution time: 0.0564
ERROR - 2021-12-30 14:22:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:22:10 --> Config Class Initialized
INFO - 2021-12-30 14:22:10 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:22:10 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:22:10 --> Utf8 Class Initialized
INFO - 2021-12-30 14:22:10 --> URI Class Initialized
DEBUG - 2021-12-30 14:22:10 --> No URI present. Default controller set.
INFO - 2021-12-30 14:22:10 --> Router Class Initialized
INFO - 2021-12-30 14:22:10 --> Output Class Initialized
INFO - 2021-12-30 14:22:10 --> Security Class Initialized
DEBUG - 2021-12-30 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:22:10 --> Input Class Initialized
INFO - 2021-12-30 14:22:10 --> Language Class Initialized
INFO - 2021-12-30 14:22:10 --> Loader Class Initialized
INFO - 2021-12-30 14:22:10 --> Helper loaded: url_helper
INFO - 2021-12-30 14:22:10 --> Helper loaded: form_helper
INFO - 2021-12-30 14:22:10 --> Helper loaded: common_helper
INFO - 2021-12-30 14:22:10 --> Database Driver Class Initialized
DEBUG - 2021-12-30 14:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 14:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 14:22:10 --> Controller Class Initialized
INFO - 2021-12-30 14:22:10 --> Form Validation Class Initialized
DEBUG - 2021-12-30 14:22:10 --> Encrypt Class Initialized
DEBUG - 2021-12-30 14:22:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 14:22:10 --> Email Class Initialized
INFO - 2021-12-30 14:22:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 14:22:10 --> Calendar Class Initialized
INFO - 2021-12-30 14:22:10 --> Model "Login_model" initialized
INFO - 2021-12-30 14:22:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 14:22:10 --> Final output sent to browser
DEBUG - 2021-12-30 14:22:10 --> Total execution time: 0.0382
ERROR - 2021-12-30 14:22:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:22:10 --> Config Class Initialized
INFO - 2021-12-30 14:22:10 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:22:10 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:22:10 --> Utf8 Class Initialized
INFO - 2021-12-30 14:22:10 --> URI Class Initialized
INFO - 2021-12-30 14:22:10 --> Router Class Initialized
INFO - 2021-12-30 14:22:10 --> Output Class Initialized
INFO - 2021-12-30 14:22:10 --> Security Class Initialized
DEBUG - 2021-12-30 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:22:10 --> Input Class Initialized
INFO - 2021-12-30 14:22:10 --> Language Class Initialized
ERROR - 2021-12-30 14:22:10 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-30 14:22:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:22:18 --> Config Class Initialized
INFO - 2021-12-30 14:22:18 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:22:18 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:22:18 --> Utf8 Class Initialized
INFO - 2021-12-30 14:22:18 --> URI Class Initialized
INFO - 2021-12-30 14:22:18 --> Router Class Initialized
INFO - 2021-12-30 14:22:18 --> Output Class Initialized
INFO - 2021-12-30 14:22:18 --> Security Class Initialized
DEBUG - 2021-12-30 14:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:22:18 --> Input Class Initialized
INFO - 2021-12-30 14:22:18 --> Language Class Initialized
INFO - 2021-12-30 14:22:18 --> Loader Class Initialized
INFO - 2021-12-30 14:22:18 --> Helper loaded: url_helper
INFO - 2021-12-30 14:22:18 --> Helper loaded: form_helper
INFO - 2021-12-30 14:22:18 --> Helper loaded: common_helper
INFO - 2021-12-30 14:22:18 --> Database Driver Class Initialized
DEBUG - 2021-12-30 14:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 14:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 14:22:18 --> Controller Class Initialized
INFO - 2021-12-30 14:22:18 --> Form Validation Class Initialized
DEBUG - 2021-12-30 14:22:18 --> Encrypt Class Initialized
DEBUG - 2021-12-30 14:22:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:22:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 14:22:18 --> Email Class Initialized
INFO - 2021-12-30 14:22:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 14:22:18 --> Calendar Class Initialized
INFO - 2021-12-30 14:22:18 --> Model "Login_model" initialized
INFO - 2021-12-30 14:22:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 14:22:18 --> Final output sent to browser
DEBUG - 2021-12-30 14:22:18 --> Total execution time: 0.0232
ERROR - 2021-12-30 14:22:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:22:19 --> Config Class Initialized
INFO - 2021-12-30 14:22:19 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:22:19 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:22:19 --> Utf8 Class Initialized
INFO - 2021-12-30 14:22:19 --> URI Class Initialized
INFO - 2021-12-30 14:22:19 --> Router Class Initialized
INFO - 2021-12-30 14:22:19 --> Output Class Initialized
INFO - 2021-12-30 14:22:19 --> Security Class Initialized
DEBUG - 2021-12-30 14:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:22:19 --> Input Class Initialized
INFO - 2021-12-30 14:22:19 --> Language Class Initialized
INFO - 2021-12-30 14:22:19 --> Loader Class Initialized
INFO - 2021-12-30 14:22:19 --> Helper loaded: url_helper
INFO - 2021-12-30 14:22:19 --> Helper loaded: form_helper
INFO - 2021-12-30 14:22:19 --> Helper loaded: common_helper
INFO - 2021-12-30 14:22:19 --> Database Driver Class Initialized
DEBUG - 2021-12-30 14:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 14:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 14:22:19 --> Controller Class Initialized
INFO - 2021-12-30 14:22:19 --> Form Validation Class Initialized
DEBUG - 2021-12-30 14:22:19 --> Encrypt Class Initialized
DEBUG - 2021-12-30 14:22:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:22:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 14:22:19 --> Email Class Initialized
INFO - 2021-12-30 14:22:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 14:22:19 --> Calendar Class Initialized
INFO - 2021-12-30 14:22:19 --> Model "Login_model" initialized
ERROR - 2021-12-30 14:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:22:20 --> Config Class Initialized
INFO - 2021-12-30 14:22:20 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:22:20 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:22:20 --> Utf8 Class Initialized
INFO - 2021-12-30 14:22:20 --> URI Class Initialized
INFO - 2021-12-30 14:22:20 --> Router Class Initialized
INFO - 2021-12-30 14:22:20 --> Output Class Initialized
INFO - 2021-12-30 14:22:20 --> Security Class Initialized
DEBUG - 2021-12-30 14:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:22:20 --> Input Class Initialized
INFO - 2021-12-30 14:22:20 --> Language Class Initialized
INFO - 2021-12-30 14:22:20 --> Loader Class Initialized
INFO - 2021-12-30 14:22:20 --> Helper loaded: url_helper
INFO - 2021-12-30 14:22:20 --> Helper loaded: form_helper
INFO - 2021-12-30 14:22:20 --> Helper loaded: common_helper
INFO - 2021-12-30 14:22:20 --> Database Driver Class Initialized
DEBUG - 2021-12-30 14:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 14:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 14:22:20 --> Controller Class Initialized
INFO - 2021-12-30 14:22:20 --> Form Validation Class Initialized
DEBUG - 2021-12-30 14:22:20 --> Encrypt Class Initialized
DEBUG - 2021-12-30 14:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 14:22:20 --> Email Class Initialized
INFO - 2021-12-30 14:22:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 14:22:20 --> Calendar Class Initialized
INFO - 2021-12-30 14:22:20 --> Model "Login_model" initialized
ERROR - 2021-12-30 14:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:22:20 --> Config Class Initialized
INFO - 2021-12-30 14:22:20 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:22:20 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:22:20 --> Utf8 Class Initialized
INFO - 2021-12-30 14:22:20 --> URI Class Initialized
DEBUG - 2021-12-30 14:22:20 --> No URI present. Default controller set.
INFO - 2021-12-30 14:22:20 --> Router Class Initialized
INFO - 2021-12-30 14:22:20 --> Output Class Initialized
INFO - 2021-12-30 14:22:20 --> Security Class Initialized
DEBUG - 2021-12-30 14:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:22:20 --> Input Class Initialized
INFO - 2021-12-30 14:22:20 --> Language Class Initialized
INFO - 2021-12-30 14:22:20 --> Loader Class Initialized
INFO - 2021-12-30 14:22:20 --> Helper loaded: url_helper
INFO - 2021-12-30 14:22:20 --> Helper loaded: form_helper
INFO - 2021-12-30 14:22:20 --> Helper loaded: common_helper
INFO - 2021-12-30 14:22:20 --> Database Driver Class Initialized
DEBUG - 2021-12-30 14:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 14:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 14:22:20 --> Controller Class Initialized
INFO - 2021-12-30 14:22:20 --> Form Validation Class Initialized
DEBUG - 2021-12-30 14:22:20 --> Encrypt Class Initialized
DEBUG - 2021-12-30 14:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 14:22:20 --> Email Class Initialized
INFO - 2021-12-30 14:22:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 14:22:20 --> Calendar Class Initialized
INFO - 2021-12-30 14:22:20 --> Model "Login_model" initialized
INFO - 2021-12-30 14:22:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 14:22:20 --> Final output sent to browser
DEBUG - 2021-12-30 14:22:20 --> Total execution time: 0.0336
ERROR - 2021-12-30 14:29:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:36 --> Config Class Initialized
INFO - 2021-12-30 14:29:36 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:36 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:36 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:36 --> URI Class Initialized
DEBUG - 2021-12-30 14:29:36 --> No URI present. Default controller set.
INFO - 2021-12-30 14:29:36 --> Router Class Initialized
INFO - 2021-12-30 14:29:36 --> Output Class Initialized
INFO - 2021-12-30 14:29:36 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:36 --> Input Class Initialized
INFO - 2021-12-30 14:29:36 --> Language Class Initialized
INFO - 2021-12-30 14:29:36 --> Loader Class Initialized
INFO - 2021-12-30 14:29:36 --> Helper loaded: url_helper
INFO - 2021-12-30 14:29:36 --> Helper loaded: form_helper
INFO - 2021-12-30 14:29:36 --> Helper loaded: common_helper
INFO - 2021-12-30 14:29:36 --> Database Driver Class Initialized
DEBUG - 2021-12-30 14:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 14:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 14:29:36 --> Controller Class Initialized
INFO - 2021-12-30 14:29:36 --> Form Validation Class Initialized
DEBUG - 2021-12-30 14:29:36 --> Encrypt Class Initialized
DEBUG - 2021-12-30 14:29:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:29:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 14:29:36 --> Email Class Initialized
INFO - 2021-12-30 14:29:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 14:29:36 --> Calendar Class Initialized
INFO - 2021-12-30 14:29:36 --> Model "Login_model" initialized
INFO - 2021-12-30 14:29:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 14:29:36 --> Final output sent to browser
DEBUG - 2021-12-30 14:29:36 --> Total execution time: 0.0941
ERROR - 2021-12-30 14:29:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:38 --> Config Class Initialized
INFO - 2021-12-30 14:29:38 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:38 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:38 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:38 --> URI Class Initialized
INFO - 2021-12-30 14:29:38 --> Router Class Initialized
INFO - 2021-12-30 14:29:38 --> Output Class Initialized
INFO - 2021-12-30 14:29:38 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:38 --> Input Class Initialized
INFO - 2021-12-30 14:29:38 --> Language Class Initialized
ERROR - 2021-12-30 14:29:38 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-12-30 14:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:41 --> Config Class Initialized
INFO - 2021-12-30 14:29:41 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:41 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:41 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:41 --> URI Class Initialized
INFO - 2021-12-30 14:29:41 --> Router Class Initialized
INFO - 2021-12-30 14:29:41 --> Output Class Initialized
INFO - 2021-12-30 14:29:41 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:41 --> Input Class Initialized
INFO - 2021-12-30 14:29:41 --> Language Class Initialized
ERROR - 2021-12-30 14:29:41 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-12-30 14:29:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:44 --> Config Class Initialized
INFO - 2021-12-30 14:29:44 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:44 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:44 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:44 --> URI Class Initialized
INFO - 2021-12-30 14:29:44 --> Router Class Initialized
INFO - 2021-12-30 14:29:44 --> Output Class Initialized
INFO - 2021-12-30 14:29:44 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:44 --> Input Class Initialized
INFO - 2021-12-30 14:29:44 --> Language Class Initialized
ERROR - 2021-12-30 14:29:44 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-12-30 14:29:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:45 --> Config Class Initialized
INFO - 2021-12-30 14:29:45 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:45 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:45 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:45 --> URI Class Initialized
INFO - 2021-12-30 14:29:45 --> Router Class Initialized
INFO - 2021-12-30 14:29:45 --> Output Class Initialized
INFO - 2021-12-30 14:29:45 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:45 --> Input Class Initialized
INFO - 2021-12-30 14:29:45 --> Language Class Initialized
ERROR - 2021-12-30 14:29:45 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-12-30 14:29:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:46 --> Config Class Initialized
INFO - 2021-12-30 14:29:46 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:46 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:46 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:46 --> URI Class Initialized
INFO - 2021-12-30 14:29:46 --> Router Class Initialized
INFO - 2021-12-30 14:29:46 --> Output Class Initialized
INFO - 2021-12-30 14:29:46 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:46 --> Input Class Initialized
INFO - 2021-12-30 14:29:46 --> Language Class Initialized
ERROR - 2021-12-30 14:29:46 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-12-30 14:29:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:47 --> Config Class Initialized
INFO - 2021-12-30 14:29:47 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:47 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:47 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:47 --> URI Class Initialized
INFO - 2021-12-30 14:29:47 --> Router Class Initialized
INFO - 2021-12-30 14:29:47 --> Output Class Initialized
INFO - 2021-12-30 14:29:47 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:47 --> Input Class Initialized
INFO - 2021-12-30 14:29:47 --> Language Class Initialized
ERROR - 2021-12-30 14:29:47 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-12-30 14:29:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:49 --> Config Class Initialized
INFO - 2021-12-30 14:29:49 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:49 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:49 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:49 --> URI Class Initialized
INFO - 2021-12-30 14:29:49 --> Router Class Initialized
INFO - 2021-12-30 14:29:49 --> Output Class Initialized
INFO - 2021-12-30 14:29:49 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:49 --> Input Class Initialized
INFO - 2021-12-30 14:29:49 --> Language Class Initialized
ERROR - 2021-12-30 14:29:49 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-12-30 14:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:50 --> Config Class Initialized
INFO - 2021-12-30 14:29:50 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:50 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:50 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:50 --> URI Class Initialized
INFO - 2021-12-30 14:29:50 --> Router Class Initialized
INFO - 2021-12-30 14:29:50 --> Output Class Initialized
INFO - 2021-12-30 14:29:50 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:50 --> Input Class Initialized
INFO - 2021-12-30 14:29:50 --> Language Class Initialized
ERROR - 2021-12-30 14:29:50 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-12-30 14:29:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:51 --> Config Class Initialized
INFO - 2021-12-30 14:29:51 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:51 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:51 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:51 --> URI Class Initialized
INFO - 2021-12-30 14:29:51 --> Router Class Initialized
INFO - 2021-12-30 14:29:51 --> Output Class Initialized
INFO - 2021-12-30 14:29:51 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:51 --> Input Class Initialized
INFO - 2021-12-30 14:29:51 --> Language Class Initialized
ERROR - 2021-12-30 14:29:51 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-12-30 14:29:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:52 --> Config Class Initialized
INFO - 2021-12-30 14:29:52 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:52 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:52 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:52 --> URI Class Initialized
INFO - 2021-12-30 14:29:52 --> Router Class Initialized
INFO - 2021-12-30 14:29:52 --> Output Class Initialized
INFO - 2021-12-30 14:29:52 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:52 --> Input Class Initialized
INFO - 2021-12-30 14:29:52 --> Language Class Initialized
ERROR - 2021-12-30 14:29:52 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-12-30 14:29:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:53 --> Config Class Initialized
INFO - 2021-12-30 14:29:53 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:53 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:53 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:53 --> URI Class Initialized
INFO - 2021-12-30 14:29:53 --> Router Class Initialized
INFO - 2021-12-30 14:29:53 --> Output Class Initialized
INFO - 2021-12-30 14:29:53 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:53 --> Input Class Initialized
INFO - 2021-12-30 14:29:53 --> Language Class Initialized
ERROR - 2021-12-30 14:29:53 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-12-30 14:29:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:53 --> Config Class Initialized
INFO - 2021-12-30 14:29:53 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:53 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:53 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:53 --> URI Class Initialized
INFO - 2021-12-30 14:29:53 --> Router Class Initialized
INFO - 2021-12-30 14:29:53 --> Output Class Initialized
INFO - 2021-12-30 14:29:53 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:53 --> Input Class Initialized
INFO - 2021-12-30 14:29:53 --> Language Class Initialized
ERROR - 2021-12-30 14:29:53 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-12-30 14:29:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:54 --> Config Class Initialized
INFO - 2021-12-30 14:29:54 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:54 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:54 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:54 --> URI Class Initialized
INFO - 2021-12-30 14:29:54 --> Router Class Initialized
INFO - 2021-12-30 14:29:54 --> Output Class Initialized
INFO - 2021-12-30 14:29:54 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:54 --> Input Class Initialized
INFO - 2021-12-30 14:29:54 --> Language Class Initialized
ERROR - 2021-12-30 14:29:54 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-12-30 14:29:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:55 --> Config Class Initialized
INFO - 2021-12-30 14:29:55 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:55 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:55 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:55 --> URI Class Initialized
INFO - 2021-12-30 14:29:55 --> Router Class Initialized
INFO - 2021-12-30 14:29:55 --> Output Class Initialized
INFO - 2021-12-30 14:29:55 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:55 --> Input Class Initialized
INFO - 2021-12-30 14:29:55 --> Language Class Initialized
ERROR - 2021-12-30 14:29:55 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-12-30 14:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:56 --> Config Class Initialized
INFO - 2021-12-30 14:29:56 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:56 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:56 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:56 --> URI Class Initialized
INFO - 2021-12-30 14:29:56 --> Router Class Initialized
INFO - 2021-12-30 14:29:56 --> Output Class Initialized
INFO - 2021-12-30 14:29:56 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:56 --> Input Class Initialized
INFO - 2021-12-30 14:29:56 --> Language Class Initialized
ERROR - 2021-12-30 14:29:56 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-12-30 14:29:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:58 --> Config Class Initialized
INFO - 2021-12-30 14:29:58 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:58 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:58 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:58 --> URI Class Initialized
INFO - 2021-12-30 14:29:58 --> Router Class Initialized
INFO - 2021-12-30 14:29:58 --> Output Class Initialized
INFO - 2021-12-30 14:29:58 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:58 --> Input Class Initialized
INFO - 2021-12-30 14:29:58 --> Language Class Initialized
ERROR - 2021-12-30 14:29:58 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-12-30 14:29:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:29:59 --> Config Class Initialized
INFO - 2021-12-30 14:29:59 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:29:59 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:29:59 --> Utf8 Class Initialized
INFO - 2021-12-30 14:29:59 --> URI Class Initialized
INFO - 2021-12-30 14:29:59 --> Router Class Initialized
INFO - 2021-12-30 14:29:59 --> Output Class Initialized
INFO - 2021-12-30 14:29:59 --> Security Class Initialized
DEBUG - 2021-12-30 14:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:29:59 --> Input Class Initialized
INFO - 2021-12-30 14:29:59 --> Language Class Initialized
ERROR - 2021-12-30 14:29:59 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-12-30 14:49:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 14:49:10 --> Config Class Initialized
INFO - 2021-12-30 14:49:10 --> Hooks Class Initialized
DEBUG - 2021-12-30 14:49:10 --> UTF-8 Support Enabled
INFO - 2021-12-30 14:49:10 --> Utf8 Class Initialized
INFO - 2021-12-30 14:49:10 --> URI Class Initialized
DEBUG - 2021-12-30 14:49:10 --> No URI present. Default controller set.
INFO - 2021-12-30 14:49:10 --> Router Class Initialized
INFO - 2021-12-30 14:49:10 --> Output Class Initialized
INFO - 2021-12-30 14:49:10 --> Security Class Initialized
DEBUG - 2021-12-30 14:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 14:49:10 --> Input Class Initialized
INFO - 2021-12-30 14:49:10 --> Language Class Initialized
INFO - 2021-12-30 14:49:10 --> Loader Class Initialized
INFO - 2021-12-30 14:49:10 --> Helper loaded: url_helper
INFO - 2021-12-30 14:49:10 --> Helper loaded: form_helper
INFO - 2021-12-30 14:49:10 --> Helper loaded: common_helper
INFO - 2021-12-30 14:49:10 --> Database Driver Class Initialized
DEBUG - 2021-12-30 14:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 14:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 14:49:10 --> Controller Class Initialized
INFO - 2021-12-30 14:49:10 --> Form Validation Class Initialized
DEBUG - 2021-12-30 14:49:10 --> Encrypt Class Initialized
DEBUG - 2021-12-30 14:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:49:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 14:49:10 --> Email Class Initialized
INFO - 2021-12-30 14:49:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 14:49:10 --> Calendar Class Initialized
INFO - 2021-12-30 14:49:10 --> Model "Login_model" initialized
INFO - 2021-12-30 14:49:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 14:49:10 --> Final output sent to browser
DEBUG - 2021-12-30 14:49:10 --> Total execution time: 0.0229
ERROR - 2021-12-30 15:45:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-30 15:45:27 --> Config Class Initialized
INFO - 2021-12-30 15:45:27 --> Hooks Class Initialized
DEBUG - 2021-12-30 15:45:27 --> UTF-8 Support Enabled
INFO - 2021-12-30 15:45:27 --> Utf8 Class Initialized
INFO - 2021-12-30 15:45:27 --> URI Class Initialized
DEBUG - 2021-12-30 15:45:27 --> No URI present. Default controller set.
INFO - 2021-12-30 15:45:27 --> Router Class Initialized
INFO - 2021-12-30 15:45:27 --> Output Class Initialized
INFO - 2021-12-30 15:45:27 --> Security Class Initialized
DEBUG - 2021-12-30 15:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-30 15:45:27 --> Input Class Initialized
INFO - 2021-12-30 15:45:27 --> Language Class Initialized
INFO - 2021-12-30 15:45:27 --> Loader Class Initialized
INFO - 2021-12-30 15:45:27 --> Helper loaded: url_helper
INFO - 2021-12-30 15:45:27 --> Helper loaded: form_helper
INFO - 2021-12-30 15:45:27 --> Helper loaded: common_helper
INFO - 2021-12-30 15:45:27 --> Database Driver Class Initialized
DEBUG - 2021-12-30 15:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-30 15:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-30 15:45:27 --> Controller Class Initialized
INFO - 2021-12-30 15:45:27 --> Form Validation Class Initialized
DEBUG - 2021-12-30 15:45:27 --> Encrypt Class Initialized
DEBUG - 2021-12-30 15:45:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:45:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-30 15:45:27 --> Email Class Initialized
INFO - 2021-12-30 15:45:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-30 15:45:27 --> Calendar Class Initialized
INFO - 2021-12-30 15:45:27 --> Model "Login_model" initialized
INFO - 2021-12-30 15:45:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-30 15:45:27 --> Final output sent to browser
DEBUG - 2021-12-30 15:45:27 --> Total execution time: 0.0376
