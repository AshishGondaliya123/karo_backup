<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-08 00:19:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 00:19:53 --> Config Class Initialized
INFO - 2022-03-08 00:19:53 --> Hooks Class Initialized
DEBUG - 2022-03-08 00:19:53 --> UTF-8 Support Enabled
INFO - 2022-03-08 00:19:53 --> Utf8 Class Initialized
INFO - 2022-03-08 00:19:53 --> URI Class Initialized
INFO - 2022-03-08 00:19:53 --> Router Class Initialized
INFO - 2022-03-08 00:19:53 --> Output Class Initialized
INFO - 2022-03-08 00:19:53 --> Security Class Initialized
DEBUG - 2022-03-08 00:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 00:19:53 --> Input Class Initialized
INFO - 2022-03-08 00:19:53 --> Language Class Initialized
INFO - 2022-03-08 00:19:53 --> Loader Class Initialized
INFO - 2022-03-08 00:19:53 --> Helper loaded: url_helper
INFO - 2022-03-08 00:19:53 --> Helper loaded: form_helper
INFO - 2022-03-08 00:19:53 --> Helper loaded: common_helper
INFO - 2022-03-08 00:19:53 --> Database Driver Class Initialized
DEBUG - 2022-03-08 00:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 00:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 00:19:53 --> Controller Class Initialized
INFO - 2022-03-08 00:19:53 --> Form Validation Class Initialized
DEBUG - 2022-03-08 00:19:53 --> Encrypt Class Initialized
INFO - 2022-03-08 00:19:53 --> Model "Patient_model" initialized
INFO - 2022-03-08 00:19:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 00:19:53 --> Model "Referredby_model" initialized
INFO - 2022-03-08 00:19:53 --> Model "Prefix_master" initialized
INFO - 2022-03-08 00:19:53 --> Model "Hospital_model" initialized
INFO - 2022-03-08 00:19:53 --> Final output sent to browser
DEBUG - 2022-03-08 00:19:53 --> Total execution time: 0.0325
ERROR - 2022-03-08 00:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 00:20:10 --> Config Class Initialized
INFO - 2022-03-08 00:20:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 00:20:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 00:20:10 --> Utf8 Class Initialized
INFO - 2022-03-08 00:20:10 --> URI Class Initialized
INFO - 2022-03-08 00:20:10 --> Router Class Initialized
INFO - 2022-03-08 00:20:10 --> Output Class Initialized
INFO - 2022-03-08 00:20:10 --> Security Class Initialized
DEBUG - 2022-03-08 00:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 00:20:10 --> Input Class Initialized
INFO - 2022-03-08 00:20:10 --> Language Class Initialized
INFO - 2022-03-08 00:20:10 --> Loader Class Initialized
INFO - 2022-03-08 00:20:10 --> Helper loaded: url_helper
INFO - 2022-03-08 00:20:10 --> Helper loaded: form_helper
INFO - 2022-03-08 00:20:10 --> Helper loaded: common_helper
INFO - 2022-03-08 00:20:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 00:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 00:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 00:20:10 --> Controller Class Initialized
INFO - 2022-03-08 00:20:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 00:20:10 --> Encrypt Class Initialized
INFO - 2022-03-08 00:20:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 00:20:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 00:20:10 --> Model "Referredby_model" initialized
INFO - 2022-03-08 00:20:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 00:20:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 00:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 00:20:11 --> Config Class Initialized
INFO - 2022-03-08 00:20:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 00:20:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 00:20:11 --> Utf8 Class Initialized
INFO - 2022-03-08 00:20:11 --> URI Class Initialized
INFO - 2022-03-08 00:20:11 --> Router Class Initialized
INFO - 2022-03-08 00:20:11 --> Output Class Initialized
INFO - 2022-03-08 00:20:11 --> Security Class Initialized
DEBUG - 2022-03-08 00:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 00:20:11 --> Input Class Initialized
INFO - 2022-03-08 00:20:11 --> Language Class Initialized
INFO - 2022-03-08 00:20:11 --> Loader Class Initialized
INFO - 2022-03-08 00:20:11 --> Helper loaded: url_helper
INFO - 2022-03-08 00:20:11 --> Helper loaded: form_helper
INFO - 2022-03-08 00:20:11 --> Helper loaded: common_helper
INFO - 2022-03-08 00:20:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 00:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 00:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 00:20:11 --> Controller Class Initialized
INFO - 2022-03-08 00:20:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 00:20:11 --> Encrypt Class Initialized
INFO - 2022-03-08 00:20:11 --> Model "Patient_model" initialized
INFO - 2022-03-08 00:20:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 00:20:11 --> Model "Referredby_model" initialized
INFO - 2022-03-08 00:20:11 --> Model "Prefix_master" initialized
INFO - 2022-03-08 00:20:11 --> Model "Hospital_model" initialized
INFO - 2022-03-08 00:20:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 00:20:11 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 00:20:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 00:20:11 --> Final output sent to browser
DEBUG - 2022-03-08 00:20:11 --> Total execution time: 0.0853
ERROR - 2022-03-08 00:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 00:20:12 --> Config Class Initialized
INFO - 2022-03-08 00:20:12 --> Hooks Class Initialized
DEBUG - 2022-03-08 00:20:12 --> UTF-8 Support Enabled
INFO - 2022-03-08 00:20:12 --> Utf8 Class Initialized
INFO - 2022-03-08 00:20:12 --> URI Class Initialized
INFO - 2022-03-08 00:20:12 --> Router Class Initialized
INFO - 2022-03-08 00:20:12 --> Output Class Initialized
INFO - 2022-03-08 00:20:12 --> Security Class Initialized
DEBUG - 2022-03-08 00:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 00:20:12 --> Input Class Initialized
INFO - 2022-03-08 00:20:12 --> Language Class Initialized
INFO - 2022-03-08 00:20:12 --> Loader Class Initialized
INFO - 2022-03-08 00:20:12 --> Helper loaded: url_helper
INFO - 2022-03-08 00:20:12 --> Helper loaded: form_helper
INFO - 2022-03-08 00:20:12 --> Helper loaded: common_helper
INFO - 2022-03-08 00:20:12 --> Database Driver Class Initialized
DEBUG - 2022-03-08 00:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 00:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 00:20:12 --> Controller Class Initialized
INFO - 2022-03-08 00:20:12 --> Form Validation Class Initialized
DEBUG - 2022-03-08 00:20:12 --> Encrypt Class Initialized
INFO - 2022-03-08 00:20:12 --> Model "Patient_model" initialized
INFO - 2022-03-08 00:20:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 00:20:12 --> Model "Prefix_master" initialized
INFO - 2022-03-08 00:20:12 --> Model "Users_model" initialized
INFO - 2022-03-08 00:20:12 --> Model "Hospital_model" initialized
INFO - 2022-03-08 00:20:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 00:20:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 00:20:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 00:20:12 --> Final output sent to browser
DEBUG - 2022-03-08 00:20:12 --> Total execution time: 0.2108
ERROR - 2022-03-08 00:51:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 00:51:23 --> Config Class Initialized
INFO - 2022-03-08 00:51:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 00:51:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 00:51:23 --> Utf8 Class Initialized
INFO - 2022-03-08 00:51:23 --> URI Class Initialized
INFO - 2022-03-08 00:51:23 --> Router Class Initialized
INFO - 2022-03-08 00:51:23 --> Output Class Initialized
INFO - 2022-03-08 00:51:23 --> Security Class Initialized
DEBUG - 2022-03-08 00:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 00:51:23 --> Input Class Initialized
INFO - 2022-03-08 00:51:23 --> Language Class Initialized
INFO - 2022-03-08 00:51:23 --> Loader Class Initialized
INFO - 2022-03-08 00:51:23 --> Helper loaded: url_helper
INFO - 2022-03-08 00:51:23 --> Helper loaded: form_helper
INFO - 2022-03-08 00:51:23 --> Helper loaded: common_helper
INFO - 2022-03-08 00:51:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 00:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 00:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 00:51:23 --> Controller Class Initialized
INFO - 2022-03-08 00:51:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 00:51:23 --> Encrypt Class Initialized
INFO - 2022-03-08 00:51:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 00:51:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 00:51:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 00:51:23 --> Model "Users_model" initialized
INFO - 2022-03-08 00:51:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 00:51:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 00:51:24 --> Config Class Initialized
INFO - 2022-03-08 00:51:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 00:51:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 00:51:24 --> Utf8 Class Initialized
INFO - 2022-03-08 00:51:24 --> URI Class Initialized
INFO - 2022-03-08 00:51:24 --> Router Class Initialized
INFO - 2022-03-08 00:51:24 --> Output Class Initialized
INFO - 2022-03-08 00:51:24 --> Security Class Initialized
DEBUG - 2022-03-08 00:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 00:51:24 --> Input Class Initialized
INFO - 2022-03-08 00:51:24 --> Language Class Initialized
INFO - 2022-03-08 00:51:24 --> Loader Class Initialized
INFO - 2022-03-08 00:51:24 --> Helper loaded: url_helper
INFO - 2022-03-08 00:51:24 --> Helper loaded: form_helper
INFO - 2022-03-08 00:51:24 --> Helper loaded: common_helper
INFO - 2022-03-08 00:51:24 --> Database Driver Class Initialized
DEBUG - 2022-03-08 00:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 00:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 00:51:24 --> Controller Class Initialized
INFO - 2022-03-08 00:51:24 --> Form Validation Class Initialized
DEBUG - 2022-03-08 00:51:24 --> Encrypt Class Initialized
INFO - 2022-03-08 00:51:24 --> Model "Patient_model" initialized
INFO - 2022-03-08 00:51:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 00:51:24 --> Model "Prefix_master" initialized
INFO - 2022-03-08 00:51:24 --> Model "Users_model" initialized
INFO - 2022-03-08 00:51:24 --> Model "Hospital_model" initialized
INFO - 2022-03-08 00:51:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 00:51:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 00:51:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 00:51:24 --> Final output sent to browser
DEBUG - 2022-03-08 00:51:24 --> Total execution time: 0.0660
ERROR - 2022-03-08 01:03:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:03:23 --> Config Class Initialized
INFO - 2022-03-08 01:03:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:03:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:03:23 --> Utf8 Class Initialized
INFO - 2022-03-08 01:03:23 --> URI Class Initialized
INFO - 2022-03-08 01:03:23 --> Router Class Initialized
INFO - 2022-03-08 01:03:23 --> Output Class Initialized
INFO - 2022-03-08 01:03:23 --> Security Class Initialized
DEBUG - 2022-03-08 01:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:03:23 --> Input Class Initialized
INFO - 2022-03-08 01:03:23 --> Language Class Initialized
INFO - 2022-03-08 01:03:23 --> Loader Class Initialized
INFO - 2022-03-08 01:03:23 --> Helper loaded: url_helper
INFO - 2022-03-08 01:03:23 --> Helper loaded: form_helper
INFO - 2022-03-08 01:03:23 --> Helper loaded: common_helper
INFO - 2022-03-08 01:03:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:03:23 --> Controller Class Initialized
INFO - 2022-03-08 01:03:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:03:23 --> Encrypt Class Initialized
INFO - 2022-03-08 01:03:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:03:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:03:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:03:23 --> Model "Users_model" initialized
INFO - 2022-03-08 01:03:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 01:03:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:03:23 --> Config Class Initialized
INFO - 2022-03-08 01:03:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:03:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:03:23 --> Utf8 Class Initialized
INFO - 2022-03-08 01:03:23 --> URI Class Initialized
INFO - 2022-03-08 01:03:23 --> Router Class Initialized
INFO - 2022-03-08 01:03:23 --> Output Class Initialized
INFO - 2022-03-08 01:03:23 --> Security Class Initialized
DEBUG - 2022-03-08 01:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:03:23 --> Input Class Initialized
INFO - 2022-03-08 01:03:23 --> Language Class Initialized
INFO - 2022-03-08 01:03:23 --> Loader Class Initialized
INFO - 2022-03-08 01:03:23 --> Helper loaded: url_helper
INFO - 2022-03-08 01:03:23 --> Helper loaded: form_helper
INFO - 2022-03-08 01:03:23 --> Helper loaded: common_helper
INFO - 2022-03-08 01:03:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:03:23 --> Controller Class Initialized
INFO - 2022-03-08 01:03:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:03:23 --> Encrypt Class Initialized
INFO - 2022-03-08 01:03:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:03:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:03:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:03:23 --> Model "Users_model" initialized
INFO - 2022-03-08 01:03:23 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:03:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:03:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:03:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:03:24 --> Final output sent to browser
DEBUG - 2022-03-08 01:03:24 --> Total execution time: 0.0927
ERROR - 2022-03-08 01:07:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:07:46 --> Config Class Initialized
INFO - 2022-03-08 01:07:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:07:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:07:46 --> Utf8 Class Initialized
INFO - 2022-03-08 01:07:46 --> URI Class Initialized
INFO - 2022-03-08 01:07:46 --> Router Class Initialized
INFO - 2022-03-08 01:07:46 --> Output Class Initialized
INFO - 2022-03-08 01:07:46 --> Security Class Initialized
DEBUG - 2022-03-08 01:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:07:46 --> Input Class Initialized
INFO - 2022-03-08 01:07:46 --> Language Class Initialized
INFO - 2022-03-08 01:07:46 --> Loader Class Initialized
INFO - 2022-03-08 01:07:46 --> Helper loaded: url_helper
INFO - 2022-03-08 01:07:46 --> Helper loaded: form_helper
INFO - 2022-03-08 01:07:46 --> Helper loaded: common_helper
INFO - 2022-03-08 01:07:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:07:46 --> Controller Class Initialized
INFO - 2022-03-08 01:07:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:07:46 --> Encrypt Class Initialized
INFO - 2022-03-08 01:07:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:07:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:07:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:07:46 --> Model "Users_model" initialized
INFO - 2022-03-08 01:07:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:07:46 --> Upload Class Initialized
INFO - 2022-03-08 01:07:46 --> Final output sent to browser
DEBUG - 2022-03-08 01:07:46 --> Total execution time: 0.0863
ERROR - 2022-03-08 01:08:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:08:05 --> Config Class Initialized
INFO - 2022-03-08 01:08:05 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:08:05 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:08:05 --> Utf8 Class Initialized
INFO - 2022-03-08 01:08:05 --> URI Class Initialized
INFO - 2022-03-08 01:08:05 --> Router Class Initialized
INFO - 2022-03-08 01:08:05 --> Output Class Initialized
INFO - 2022-03-08 01:08:05 --> Security Class Initialized
DEBUG - 2022-03-08 01:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:08:05 --> Input Class Initialized
INFO - 2022-03-08 01:08:05 --> Language Class Initialized
INFO - 2022-03-08 01:08:05 --> Loader Class Initialized
INFO - 2022-03-08 01:08:05 --> Helper loaded: url_helper
INFO - 2022-03-08 01:08:05 --> Helper loaded: form_helper
INFO - 2022-03-08 01:08:05 --> Helper loaded: common_helper
INFO - 2022-03-08 01:08:05 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:08:05 --> Controller Class Initialized
INFO - 2022-03-08 01:08:05 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:08:05 --> Encrypt Class Initialized
INFO - 2022-03-08 01:08:05 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:08:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:08:05 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:08:05 --> Model "Users_model" initialized
INFO - 2022-03-08 01:08:05 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 01:08:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:08:06 --> Config Class Initialized
INFO - 2022-03-08 01:08:06 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:08:06 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:08:06 --> Utf8 Class Initialized
INFO - 2022-03-08 01:08:06 --> URI Class Initialized
INFO - 2022-03-08 01:08:06 --> Router Class Initialized
INFO - 2022-03-08 01:08:06 --> Output Class Initialized
INFO - 2022-03-08 01:08:06 --> Security Class Initialized
DEBUG - 2022-03-08 01:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:08:06 --> Input Class Initialized
INFO - 2022-03-08 01:08:06 --> Language Class Initialized
INFO - 2022-03-08 01:08:06 --> Loader Class Initialized
INFO - 2022-03-08 01:08:06 --> Helper loaded: url_helper
INFO - 2022-03-08 01:08:06 --> Helper loaded: form_helper
INFO - 2022-03-08 01:08:06 --> Helper loaded: common_helper
INFO - 2022-03-08 01:08:06 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:08:06 --> Controller Class Initialized
INFO - 2022-03-08 01:08:06 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:08:06 --> Encrypt Class Initialized
INFO - 2022-03-08 01:08:06 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:08:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:08:06 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:08:06 --> Model "Users_model" initialized
INFO - 2022-03-08 01:08:06 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:08:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:08:06 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:08:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:08:06 --> Final output sent to browser
DEBUG - 2022-03-08 01:08:06 --> Total execution time: 0.0808
ERROR - 2022-03-08 01:09:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:09:04 --> Config Class Initialized
INFO - 2022-03-08 01:09:04 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:09:04 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:09:04 --> Utf8 Class Initialized
INFO - 2022-03-08 01:09:04 --> URI Class Initialized
INFO - 2022-03-08 01:09:04 --> Router Class Initialized
INFO - 2022-03-08 01:09:04 --> Output Class Initialized
INFO - 2022-03-08 01:09:04 --> Security Class Initialized
DEBUG - 2022-03-08 01:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:09:04 --> Input Class Initialized
INFO - 2022-03-08 01:09:04 --> Language Class Initialized
INFO - 2022-03-08 01:09:04 --> Loader Class Initialized
INFO - 2022-03-08 01:09:04 --> Helper loaded: url_helper
INFO - 2022-03-08 01:09:04 --> Helper loaded: form_helper
INFO - 2022-03-08 01:09:04 --> Helper loaded: common_helper
INFO - 2022-03-08 01:09:04 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:09:04 --> Controller Class Initialized
INFO - 2022-03-08 01:09:04 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:09:04 --> Encrypt Class Initialized
INFO - 2022-03-08 01:09:04 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:09:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:09:04 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:09:04 --> Model "Users_model" initialized
INFO - 2022-03-08 01:09:04 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 01:09:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:09:05 --> Config Class Initialized
INFO - 2022-03-08 01:09:05 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:09:05 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:09:05 --> Utf8 Class Initialized
INFO - 2022-03-08 01:09:05 --> URI Class Initialized
INFO - 2022-03-08 01:09:05 --> Router Class Initialized
INFO - 2022-03-08 01:09:05 --> Output Class Initialized
INFO - 2022-03-08 01:09:05 --> Security Class Initialized
DEBUG - 2022-03-08 01:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:09:05 --> Input Class Initialized
INFO - 2022-03-08 01:09:05 --> Language Class Initialized
INFO - 2022-03-08 01:09:05 --> Loader Class Initialized
INFO - 2022-03-08 01:09:05 --> Helper loaded: url_helper
INFO - 2022-03-08 01:09:05 --> Helper loaded: form_helper
INFO - 2022-03-08 01:09:05 --> Helper loaded: common_helper
INFO - 2022-03-08 01:09:05 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:09:05 --> Controller Class Initialized
INFO - 2022-03-08 01:09:05 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:09:05 --> Encrypt Class Initialized
INFO - 2022-03-08 01:09:05 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:09:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:09:05 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:09:05 --> Model "Users_model" initialized
INFO - 2022-03-08 01:09:05 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:09:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:09:05 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:09:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:09:05 --> Final output sent to browser
DEBUG - 2022-03-08 01:09:05 --> Total execution time: 0.0517
ERROR - 2022-03-08 01:09:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:09:10 --> Config Class Initialized
INFO - 2022-03-08 01:09:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:09:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:09:10 --> Utf8 Class Initialized
INFO - 2022-03-08 01:09:10 --> URI Class Initialized
INFO - 2022-03-08 01:09:10 --> Router Class Initialized
INFO - 2022-03-08 01:09:10 --> Output Class Initialized
INFO - 2022-03-08 01:09:10 --> Security Class Initialized
DEBUG - 2022-03-08 01:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:09:10 --> Input Class Initialized
INFO - 2022-03-08 01:09:10 --> Language Class Initialized
INFO - 2022-03-08 01:09:10 --> Loader Class Initialized
INFO - 2022-03-08 01:09:10 --> Helper loaded: url_helper
INFO - 2022-03-08 01:09:10 --> Helper loaded: form_helper
INFO - 2022-03-08 01:09:10 --> Helper loaded: common_helper
INFO - 2022-03-08 01:09:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:09:10 --> Controller Class Initialized
INFO - 2022-03-08 01:09:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:09:10 --> Encrypt Class Initialized
INFO - 2022-03-08 01:09:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:09:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:09:10 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:09:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:09:10 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:09:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:09:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 01:09:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:09:10 --> Final output sent to browser
DEBUG - 2022-03-08 01:09:10 --> Total execution time: 0.0652
ERROR - 2022-03-08 01:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:09:35 --> Config Class Initialized
INFO - 2022-03-08 01:09:35 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:09:35 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:09:35 --> Utf8 Class Initialized
INFO - 2022-03-08 01:09:35 --> URI Class Initialized
INFO - 2022-03-08 01:09:35 --> Router Class Initialized
INFO - 2022-03-08 01:09:35 --> Output Class Initialized
INFO - 2022-03-08 01:09:35 --> Security Class Initialized
DEBUG - 2022-03-08 01:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:09:35 --> Input Class Initialized
INFO - 2022-03-08 01:09:35 --> Language Class Initialized
INFO - 2022-03-08 01:09:35 --> Loader Class Initialized
INFO - 2022-03-08 01:09:35 --> Helper loaded: url_helper
INFO - 2022-03-08 01:09:35 --> Helper loaded: form_helper
INFO - 2022-03-08 01:09:35 --> Helper loaded: common_helper
INFO - 2022-03-08 01:09:35 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:09:35 --> Controller Class Initialized
INFO - 2022-03-08 01:09:35 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:09:35 --> Encrypt Class Initialized
INFO - 2022-03-08 01:09:35 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:09:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:09:35 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:09:35 --> Model "Users_model" initialized
INFO - 2022-03-08 01:09:35 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:09:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:09:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:09:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:09:35 --> Final output sent to browser
DEBUG - 2022-03-08 01:09:35 --> Total execution time: 0.0533
ERROR - 2022-03-08 01:09:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:09:41 --> Config Class Initialized
INFO - 2022-03-08 01:09:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:09:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:09:41 --> Utf8 Class Initialized
INFO - 2022-03-08 01:09:41 --> URI Class Initialized
INFO - 2022-03-08 01:09:41 --> Router Class Initialized
INFO - 2022-03-08 01:09:41 --> Output Class Initialized
INFO - 2022-03-08 01:09:41 --> Security Class Initialized
DEBUG - 2022-03-08 01:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:09:41 --> Input Class Initialized
INFO - 2022-03-08 01:09:41 --> Language Class Initialized
INFO - 2022-03-08 01:09:41 --> Loader Class Initialized
INFO - 2022-03-08 01:09:41 --> Helper loaded: url_helper
INFO - 2022-03-08 01:09:41 --> Helper loaded: form_helper
INFO - 2022-03-08 01:09:41 --> Helper loaded: common_helper
INFO - 2022-03-08 01:09:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:09:41 --> Controller Class Initialized
INFO - 2022-03-08 01:09:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:09:41 --> Encrypt Class Initialized
INFO - 2022-03-08 01:09:41 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:09:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:09:41 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:09:41 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:09:41 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:09:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:09:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 01:09:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:09:41 --> Final output sent to browser
DEBUG - 2022-03-08 01:09:41 --> Total execution time: 0.1388
ERROR - 2022-03-08 01:10:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:10:06 --> Config Class Initialized
INFO - 2022-03-08 01:10:06 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:10:06 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:10:06 --> Utf8 Class Initialized
INFO - 2022-03-08 01:10:06 --> URI Class Initialized
INFO - 2022-03-08 01:10:06 --> Router Class Initialized
INFO - 2022-03-08 01:10:06 --> Output Class Initialized
INFO - 2022-03-08 01:10:06 --> Security Class Initialized
DEBUG - 2022-03-08 01:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:10:06 --> Input Class Initialized
INFO - 2022-03-08 01:10:06 --> Language Class Initialized
INFO - 2022-03-08 01:10:06 --> Loader Class Initialized
INFO - 2022-03-08 01:10:06 --> Helper loaded: url_helper
INFO - 2022-03-08 01:10:06 --> Helper loaded: form_helper
INFO - 2022-03-08 01:10:06 --> Helper loaded: common_helper
INFO - 2022-03-08 01:10:06 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:10:06 --> Controller Class Initialized
INFO - 2022-03-08 01:10:06 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:10:06 --> Encrypt Class Initialized
INFO - 2022-03-08 01:10:06 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:10:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:10:06 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:10:06 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:10:06 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:10:06 --> Upload Class Initialized
INFO - 2022-03-08 01:10:06 --> Final output sent to browser
DEBUG - 2022-03-08 01:10:06 --> Total execution time: 0.0279
ERROR - 2022-03-08 01:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:11:46 --> Config Class Initialized
INFO - 2022-03-08 01:11:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:11:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:11:46 --> Utf8 Class Initialized
INFO - 2022-03-08 01:11:46 --> URI Class Initialized
INFO - 2022-03-08 01:11:46 --> Router Class Initialized
INFO - 2022-03-08 01:11:46 --> Output Class Initialized
INFO - 2022-03-08 01:11:46 --> Security Class Initialized
DEBUG - 2022-03-08 01:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:11:46 --> Input Class Initialized
INFO - 2022-03-08 01:11:46 --> Language Class Initialized
INFO - 2022-03-08 01:11:46 --> Loader Class Initialized
INFO - 2022-03-08 01:11:46 --> Helper loaded: url_helper
INFO - 2022-03-08 01:11:46 --> Helper loaded: form_helper
INFO - 2022-03-08 01:11:46 --> Helper loaded: common_helper
INFO - 2022-03-08 01:11:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:11:46 --> Controller Class Initialized
INFO - 2022-03-08 01:11:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:11:46 --> Encrypt Class Initialized
INFO - 2022-03-08 01:11:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:11:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:11:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:11:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:11:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 01:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:11:47 --> Config Class Initialized
INFO - 2022-03-08 01:11:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:11:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:11:47 --> Utf8 Class Initialized
INFO - 2022-03-08 01:11:47 --> URI Class Initialized
INFO - 2022-03-08 01:11:47 --> Router Class Initialized
INFO - 2022-03-08 01:11:47 --> Output Class Initialized
INFO - 2022-03-08 01:11:47 --> Security Class Initialized
DEBUG - 2022-03-08 01:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:11:47 --> Input Class Initialized
INFO - 2022-03-08 01:11:47 --> Language Class Initialized
INFO - 2022-03-08 01:11:47 --> Loader Class Initialized
INFO - 2022-03-08 01:11:47 --> Helper loaded: url_helper
INFO - 2022-03-08 01:11:47 --> Helper loaded: form_helper
INFO - 2022-03-08 01:11:47 --> Helper loaded: common_helper
INFO - 2022-03-08 01:11:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:11:47 --> Controller Class Initialized
INFO - 2022-03-08 01:11:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:11:47 --> Encrypt Class Initialized
INFO - 2022-03-08 01:11:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:11:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:11:47 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:11:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:11:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:11:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:11:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 01:11:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:11:47 --> Final output sent to browser
DEBUG - 2022-03-08 01:11:47 --> Total execution time: 0.0427
ERROR - 2022-03-08 01:11:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:11:48 --> Config Class Initialized
INFO - 2022-03-08 01:11:48 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:11:48 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:11:48 --> Utf8 Class Initialized
INFO - 2022-03-08 01:11:48 --> URI Class Initialized
INFO - 2022-03-08 01:11:48 --> Router Class Initialized
INFO - 2022-03-08 01:11:48 --> Output Class Initialized
INFO - 2022-03-08 01:11:48 --> Security Class Initialized
DEBUG - 2022-03-08 01:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:11:48 --> Input Class Initialized
INFO - 2022-03-08 01:11:48 --> Language Class Initialized
INFO - 2022-03-08 01:11:48 --> Loader Class Initialized
INFO - 2022-03-08 01:11:48 --> Helper loaded: url_helper
INFO - 2022-03-08 01:11:48 --> Helper loaded: form_helper
INFO - 2022-03-08 01:11:48 --> Helper loaded: common_helper
INFO - 2022-03-08 01:11:48 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:11:48 --> Controller Class Initialized
INFO - 2022-03-08 01:11:48 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:11:48 --> Encrypt Class Initialized
INFO - 2022-03-08 01:11:48 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:11:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:11:48 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:11:48 --> Model "Users_model" initialized
INFO - 2022-03-08 01:11:48 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:11:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:11:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:11:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:11:48 --> Final output sent to browser
DEBUG - 2022-03-08 01:11:48 --> Total execution time: 0.0547
ERROR - 2022-03-08 01:15:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:15:10 --> Config Class Initialized
INFO - 2022-03-08 01:15:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:15:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:15:10 --> Utf8 Class Initialized
INFO - 2022-03-08 01:15:10 --> URI Class Initialized
INFO - 2022-03-08 01:15:10 --> Router Class Initialized
INFO - 2022-03-08 01:15:10 --> Output Class Initialized
INFO - 2022-03-08 01:15:10 --> Security Class Initialized
DEBUG - 2022-03-08 01:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:15:10 --> Input Class Initialized
INFO - 2022-03-08 01:15:10 --> Language Class Initialized
INFO - 2022-03-08 01:15:10 --> Loader Class Initialized
INFO - 2022-03-08 01:15:10 --> Helper loaded: url_helper
INFO - 2022-03-08 01:15:10 --> Helper loaded: form_helper
INFO - 2022-03-08 01:15:10 --> Helper loaded: common_helper
INFO - 2022-03-08 01:15:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:15:10 --> Controller Class Initialized
INFO - 2022-03-08 01:15:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:15:10 --> Encrypt Class Initialized
INFO - 2022-03-08 01:15:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:15:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:15:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:15:10 --> Model "Users_model" initialized
INFO - 2022-03-08 01:15:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 01:15:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:15:11 --> Config Class Initialized
INFO - 2022-03-08 01:15:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:15:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:15:11 --> Utf8 Class Initialized
INFO - 2022-03-08 01:15:11 --> URI Class Initialized
INFO - 2022-03-08 01:15:11 --> Router Class Initialized
INFO - 2022-03-08 01:15:11 --> Output Class Initialized
INFO - 2022-03-08 01:15:11 --> Security Class Initialized
DEBUG - 2022-03-08 01:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:15:11 --> Input Class Initialized
INFO - 2022-03-08 01:15:11 --> Language Class Initialized
INFO - 2022-03-08 01:15:11 --> Loader Class Initialized
INFO - 2022-03-08 01:15:11 --> Helper loaded: url_helper
INFO - 2022-03-08 01:15:11 --> Helper loaded: form_helper
INFO - 2022-03-08 01:15:11 --> Helper loaded: common_helper
INFO - 2022-03-08 01:15:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:15:11 --> Controller Class Initialized
INFO - 2022-03-08 01:15:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:15:11 --> Encrypt Class Initialized
INFO - 2022-03-08 01:15:11 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:15:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:15:11 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:15:11 --> Model "Users_model" initialized
INFO - 2022-03-08 01:15:11 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:15:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:15:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:15:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:15:11 --> Final output sent to browser
DEBUG - 2022-03-08 01:15:11 --> Total execution time: 0.0782
ERROR - 2022-03-08 01:15:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:15:46 --> Config Class Initialized
INFO - 2022-03-08 01:15:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:15:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:15:47 --> Utf8 Class Initialized
INFO - 2022-03-08 01:15:47 --> URI Class Initialized
DEBUG - 2022-03-08 01:15:47 --> No URI present. Default controller set.
INFO - 2022-03-08 01:15:47 --> Router Class Initialized
INFO - 2022-03-08 01:15:47 --> Output Class Initialized
INFO - 2022-03-08 01:15:47 --> Security Class Initialized
DEBUG - 2022-03-08 01:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:15:47 --> Input Class Initialized
INFO - 2022-03-08 01:15:47 --> Language Class Initialized
INFO - 2022-03-08 01:15:47 --> Loader Class Initialized
INFO - 2022-03-08 01:15:47 --> Helper loaded: url_helper
INFO - 2022-03-08 01:15:47 --> Helper loaded: form_helper
INFO - 2022-03-08 01:15:47 --> Helper loaded: common_helper
INFO - 2022-03-08 01:15:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:15:47 --> Controller Class Initialized
INFO - 2022-03-08 01:15:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:15:47 --> Encrypt Class Initialized
DEBUG - 2022-03-08 01:15:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 01:15:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 01:15:47 --> Email Class Initialized
INFO - 2022-03-08 01:15:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 01:15:47 --> Calendar Class Initialized
INFO - 2022-03-08 01:15:47 --> Model "Login_model" initialized
INFO - 2022-03-08 01:15:47 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 01:15:47 --> Final output sent to browser
DEBUG - 2022-03-08 01:15:47 --> Total execution time: 0.1043
ERROR - 2022-03-08 01:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:15:49 --> Config Class Initialized
INFO - 2022-03-08 01:15:49 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:15:49 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:15:49 --> Utf8 Class Initialized
INFO - 2022-03-08 01:15:49 --> URI Class Initialized
INFO - 2022-03-08 01:15:49 --> Router Class Initialized
INFO - 2022-03-08 01:15:49 --> Output Class Initialized
INFO - 2022-03-08 01:15:49 --> Security Class Initialized
DEBUG - 2022-03-08 01:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:15:49 --> Input Class Initialized
INFO - 2022-03-08 01:15:49 --> Language Class Initialized
INFO - 2022-03-08 01:15:49 --> Loader Class Initialized
INFO - 2022-03-08 01:15:49 --> Helper loaded: url_helper
INFO - 2022-03-08 01:15:49 --> Helper loaded: form_helper
INFO - 2022-03-08 01:15:49 --> Helper loaded: common_helper
INFO - 2022-03-08 01:15:49 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:15:49 --> Controller Class Initialized
INFO - 2022-03-08 01:15:49 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:15:49 --> Encrypt Class Initialized
INFO - 2022-03-08 01:15:49 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:15:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:15:49 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:15:49 --> Model "Users_model" initialized
INFO - 2022-03-08 01:15:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 01:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:15:49 --> Config Class Initialized
INFO - 2022-03-08 01:15:49 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:15:49 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:15:49 --> Utf8 Class Initialized
INFO - 2022-03-08 01:15:49 --> URI Class Initialized
INFO - 2022-03-08 01:15:49 --> Router Class Initialized
INFO - 2022-03-08 01:15:49 --> Output Class Initialized
INFO - 2022-03-08 01:15:49 --> Security Class Initialized
DEBUG - 2022-03-08 01:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:15:49 --> Input Class Initialized
INFO - 2022-03-08 01:15:49 --> Language Class Initialized
INFO - 2022-03-08 01:15:49 --> Loader Class Initialized
INFO - 2022-03-08 01:15:49 --> Helper loaded: url_helper
INFO - 2022-03-08 01:15:49 --> Helper loaded: form_helper
INFO - 2022-03-08 01:15:49 --> Helper loaded: common_helper
INFO - 2022-03-08 01:15:49 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:15:49 --> Controller Class Initialized
INFO - 2022-03-08 01:15:49 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:15:49 --> Encrypt Class Initialized
INFO - 2022-03-08 01:15:49 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:15:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:15:49 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:15:49 --> Model "Users_model" initialized
INFO - 2022-03-08 01:15:49 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:15:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:15:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:15:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:15:49 --> Final output sent to browser
DEBUG - 2022-03-08 01:15:49 --> Total execution time: 0.0801
ERROR - 2022-03-08 01:15:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:15:58 --> Config Class Initialized
INFO - 2022-03-08 01:15:58 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:15:58 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:15:58 --> Utf8 Class Initialized
INFO - 2022-03-08 01:15:58 --> URI Class Initialized
INFO - 2022-03-08 01:15:58 --> Router Class Initialized
INFO - 2022-03-08 01:15:58 --> Output Class Initialized
INFO - 2022-03-08 01:15:58 --> Security Class Initialized
DEBUG - 2022-03-08 01:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:15:58 --> Input Class Initialized
INFO - 2022-03-08 01:15:58 --> Language Class Initialized
INFO - 2022-03-08 01:15:58 --> Loader Class Initialized
INFO - 2022-03-08 01:15:58 --> Helper loaded: url_helper
INFO - 2022-03-08 01:15:58 --> Helper loaded: form_helper
INFO - 2022-03-08 01:15:58 --> Helper loaded: common_helper
INFO - 2022-03-08 01:15:58 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:15:58 --> Controller Class Initialized
INFO - 2022-03-08 01:15:58 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:15:58 --> Encrypt Class Initialized
DEBUG - 2022-03-08 01:15:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 01:15:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 01:15:58 --> Email Class Initialized
INFO - 2022-03-08 01:15:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 01:15:58 --> Calendar Class Initialized
INFO - 2022-03-08 01:15:58 --> Model "Login_model" initialized
INFO - 2022-03-08 01:15:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 01:15:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:15:59 --> Config Class Initialized
INFO - 2022-03-08 01:15:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:15:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:15:59 --> Utf8 Class Initialized
INFO - 2022-03-08 01:15:59 --> URI Class Initialized
INFO - 2022-03-08 01:15:59 --> Router Class Initialized
INFO - 2022-03-08 01:15:59 --> Output Class Initialized
INFO - 2022-03-08 01:15:59 --> Security Class Initialized
DEBUG - 2022-03-08 01:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:15:59 --> Input Class Initialized
INFO - 2022-03-08 01:15:59 --> Language Class Initialized
INFO - 2022-03-08 01:15:59 --> Loader Class Initialized
INFO - 2022-03-08 01:15:59 --> Helper loaded: url_helper
INFO - 2022-03-08 01:15:59 --> Helper loaded: form_helper
INFO - 2022-03-08 01:15:59 --> Helper loaded: common_helper
INFO - 2022-03-08 01:15:59 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:15:59 --> Controller Class Initialized
INFO - 2022-03-08 01:15:59 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:15:59 --> Encrypt Class Initialized
INFO - 2022-03-08 01:15:59 --> Model "Login_model" initialized
INFO - 2022-03-08 01:15:59 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 01:15:59 --> Model "Case_model" initialized
INFO - 2022-03-08 01:16:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:16:19 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 01:16:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:16:19 --> Final output sent to browser
DEBUG - 2022-03-08 01:16:19 --> Total execution time: 19.5082
ERROR - 2022-03-08 01:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:16:23 --> Config Class Initialized
INFO - 2022-03-08 01:16:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:16:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:16:23 --> Utf8 Class Initialized
INFO - 2022-03-08 01:16:23 --> URI Class Initialized
INFO - 2022-03-08 01:16:23 --> Router Class Initialized
INFO - 2022-03-08 01:16:23 --> Output Class Initialized
INFO - 2022-03-08 01:16:23 --> Security Class Initialized
DEBUG - 2022-03-08 01:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:16:23 --> Input Class Initialized
INFO - 2022-03-08 01:16:23 --> Language Class Initialized
INFO - 2022-03-08 01:16:23 --> Loader Class Initialized
INFO - 2022-03-08 01:16:23 --> Helper loaded: url_helper
INFO - 2022-03-08 01:16:23 --> Helper loaded: form_helper
INFO - 2022-03-08 01:16:23 --> Helper loaded: common_helper
INFO - 2022-03-08 01:16:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:16:23 --> Controller Class Initialized
INFO - 2022-03-08 01:16:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:16:23 --> Encrypt Class Initialized
INFO - 2022-03-08 01:16:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:16:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:16:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:16:23 --> Model "Users_model" initialized
INFO - 2022-03-08 01:16:23 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 01:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:16:24 --> Config Class Initialized
INFO - 2022-03-08 01:16:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:16:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:16:24 --> Utf8 Class Initialized
INFO - 2022-03-08 01:16:24 --> URI Class Initialized
INFO - 2022-03-08 01:16:24 --> Router Class Initialized
INFO - 2022-03-08 01:16:24 --> Output Class Initialized
INFO - 2022-03-08 01:16:24 --> Security Class Initialized
DEBUG - 2022-03-08 01:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:16:24 --> Input Class Initialized
INFO - 2022-03-08 01:16:24 --> Language Class Initialized
INFO - 2022-03-08 01:16:24 --> Loader Class Initialized
INFO - 2022-03-08 01:16:24 --> Helper loaded: url_helper
INFO - 2022-03-08 01:16:24 --> Helper loaded: form_helper
INFO - 2022-03-08 01:16:24 --> Helper loaded: common_helper
INFO - 2022-03-08 01:16:24 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:16:24 --> Controller Class Initialized
INFO - 2022-03-08 01:16:24 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:16:24 --> Encrypt Class Initialized
INFO - 2022-03-08 01:16:24 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:16:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:16:24 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:16:24 --> Model "Users_model" initialized
INFO - 2022-03-08 01:16:24 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:16:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:16:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:16:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:16:24 --> Final output sent to browser
DEBUG - 2022-03-08 01:16:24 --> Total execution time: 0.0836
ERROR - 2022-03-08 01:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:16:25 --> Config Class Initialized
INFO - 2022-03-08 01:16:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:16:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:16:25 --> Utf8 Class Initialized
INFO - 2022-03-08 01:16:25 --> URI Class Initialized
INFO - 2022-03-08 01:16:25 --> Router Class Initialized
INFO - 2022-03-08 01:16:25 --> Output Class Initialized
INFO - 2022-03-08 01:16:25 --> Security Class Initialized
DEBUG - 2022-03-08 01:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:16:25 --> Input Class Initialized
INFO - 2022-03-08 01:16:25 --> Language Class Initialized
INFO - 2022-03-08 01:16:25 --> Loader Class Initialized
INFO - 2022-03-08 01:16:25 --> Helper loaded: url_helper
INFO - 2022-03-08 01:16:25 --> Helper loaded: form_helper
INFO - 2022-03-08 01:16:25 --> Helper loaded: common_helper
INFO - 2022-03-08 01:16:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:16:25 --> Controller Class Initialized
INFO - 2022-03-08 01:16:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:16:25 --> Encrypt Class Initialized
INFO - 2022-03-08 01:16:25 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:16:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:16:25 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:16:25 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:16:25 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:16:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:16:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 01:16:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:16:33 --> Final output sent to browser
DEBUG - 2022-03-08 01:16:33 --> Total execution time: 5.8017
ERROR - 2022-03-08 01:17:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:17:12 --> Config Class Initialized
INFO - 2022-03-08 01:17:12 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:17:12 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:17:12 --> Utf8 Class Initialized
INFO - 2022-03-08 01:17:12 --> URI Class Initialized
INFO - 2022-03-08 01:17:12 --> Router Class Initialized
INFO - 2022-03-08 01:17:12 --> Output Class Initialized
INFO - 2022-03-08 01:17:12 --> Security Class Initialized
DEBUG - 2022-03-08 01:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:17:12 --> Input Class Initialized
INFO - 2022-03-08 01:17:12 --> Language Class Initialized
INFO - 2022-03-08 01:17:12 --> Loader Class Initialized
INFO - 2022-03-08 01:17:12 --> Helper loaded: url_helper
INFO - 2022-03-08 01:17:12 --> Helper loaded: form_helper
INFO - 2022-03-08 01:17:12 --> Helper loaded: common_helper
INFO - 2022-03-08 01:17:12 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:17:12 --> Controller Class Initialized
INFO - 2022-03-08 01:17:12 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:17:12 --> Encrypt Class Initialized
INFO - 2022-03-08 01:17:12 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:17:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:17:12 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:17:12 --> Model "Users_model" initialized
INFO - 2022-03-08 01:17:12 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 01:17:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:17:13 --> Config Class Initialized
INFO - 2022-03-08 01:17:13 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:17:13 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:17:13 --> Utf8 Class Initialized
INFO - 2022-03-08 01:17:13 --> URI Class Initialized
INFO - 2022-03-08 01:17:13 --> Router Class Initialized
INFO - 2022-03-08 01:17:13 --> Output Class Initialized
INFO - 2022-03-08 01:17:13 --> Security Class Initialized
DEBUG - 2022-03-08 01:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:17:13 --> Input Class Initialized
INFO - 2022-03-08 01:17:13 --> Language Class Initialized
INFO - 2022-03-08 01:17:13 --> Loader Class Initialized
INFO - 2022-03-08 01:17:13 --> Helper loaded: url_helper
INFO - 2022-03-08 01:17:13 --> Helper loaded: form_helper
INFO - 2022-03-08 01:17:13 --> Helper loaded: common_helper
INFO - 2022-03-08 01:17:13 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:17:13 --> Controller Class Initialized
INFO - 2022-03-08 01:17:13 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:17:13 --> Encrypt Class Initialized
INFO - 2022-03-08 01:17:13 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:17:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:17:13 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:17:13 --> Model "Users_model" initialized
INFO - 2022-03-08 01:17:13 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:17:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:17:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:17:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:17:13 --> Final output sent to browser
DEBUG - 2022-03-08 01:17:13 --> Total execution time: 0.0936
ERROR - 2022-03-08 01:17:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:17:16 --> Config Class Initialized
INFO - 2022-03-08 01:17:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:17:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:17:16 --> Utf8 Class Initialized
INFO - 2022-03-08 01:17:16 --> URI Class Initialized
INFO - 2022-03-08 01:17:16 --> Router Class Initialized
INFO - 2022-03-08 01:17:16 --> Output Class Initialized
INFO - 2022-03-08 01:17:16 --> Security Class Initialized
DEBUG - 2022-03-08 01:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:17:16 --> Input Class Initialized
INFO - 2022-03-08 01:17:16 --> Language Class Initialized
INFO - 2022-03-08 01:17:16 --> Loader Class Initialized
INFO - 2022-03-08 01:17:16 --> Helper loaded: url_helper
INFO - 2022-03-08 01:17:16 --> Helper loaded: form_helper
INFO - 2022-03-08 01:17:16 --> Helper loaded: common_helper
INFO - 2022-03-08 01:17:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:17:16 --> Controller Class Initialized
INFO - 2022-03-08 01:17:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:17:16 --> Encrypt Class Initialized
INFO - 2022-03-08 01:17:16 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:17:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:17:16 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:17:16 --> Model "Users_model" initialized
INFO - 2022-03-08 01:17:16 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:17:16 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-08 01:17:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:17:17 --> Config Class Initialized
INFO - 2022-03-08 01:17:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:17:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:17:17 --> Utf8 Class Initialized
INFO - 2022-03-08 01:17:17 --> URI Class Initialized
INFO - 2022-03-08 01:17:17 --> Router Class Initialized
INFO - 2022-03-08 01:17:17 --> Output Class Initialized
INFO - 2022-03-08 01:17:17 --> Security Class Initialized
DEBUG - 2022-03-08 01:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:17:17 --> Input Class Initialized
INFO - 2022-03-08 01:17:17 --> Language Class Initialized
ERROR - 2022-03-08 01:17:17 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-08 01:17:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:17:17 --> Config Class Initialized
INFO - 2022-03-08 01:17:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:17:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:17:17 --> Utf8 Class Initialized
INFO - 2022-03-08 01:17:17 --> URI Class Initialized
INFO - 2022-03-08 01:17:17 --> Router Class Initialized
INFO - 2022-03-08 01:17:17 --> Output Class Initialized
INFO - 2022-03-08 01:17:17 --> Security Class Initialized
DEBUG - 2022-03-08 01:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:17:17 --> Input Class Initialized
INFO - 2022-03-08 01:17:17 --> Language Class Initialized
ERROR - 2022-03-08 01:17:17 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-08 01:17:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:17:17 --> Config Class Initialized
INFO - 2022-03-08 01:17:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:17:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:17:17 --> Utf8 Class Initialized
INFO - 2022-03-08 01:17:17 --> URI Class Initialized
INFO - 2022-03-08 01:17:17 --> Router Class Initialized
INFO - 2022-03-08 01:17:17 --> Output Class Initialized
INFO - 2022-03-08 01:17:17 --> Security Class Initialized
DEBUG - 2022-03-08 01:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:17:17 --> Input Class Initialized
INFO - 2022-03-08 01:17:17 --> Language Class Initialized
ERROR - 2022-03-08 01:17:17 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-08 01:17:18 --> Final output sent to browser
DEBUG - 2022-03-08 01:17:18 --> Total execution time: 1.9615
ERROR - 2022-03-08 01:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:17:30 --> Config Class Initialized
INFO - 2022-03-08 01:17:30 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:17:30 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:17:30 --> Utf8 Class Initialized
INFO - 2022-03-08 01:17:30 --> URI Class Initialized
INFO - 2022-03-08 01:17:30 --> Router Class Initialized
INFO - 2022-03-08 01:17:30 --> Output Class Initialized
INFO - 2022-03-08 01:17:30 --> Security Class Initialized
DEBUG - 2022-03-08 01:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:17:30 --> Input Class Initialized
INFO - 2022-03-08 01:17:30 --> Language Class Initialized
INFO - 2022-03-08 01:17:30 --> Loader Class Initialized
INFO - 2022-03-08 01:17:30 --> Helper loaded: url_helper
INFO - 2022-03-08 01:17:30 --> Helper loaded: form_helper
INFO - 2022-03-08 01:17:30 --> Helper loaded: common_helper
INFO - 2022-03-08 01:17:30 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:17:30 --> Controller Class Initialized
INFO - 2022-03-08 01:17:30 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:17:30 --> Encrypt Class Initialized
INFO - 2022-03-08 01:17:30 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:17:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:17:30 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:17:30 --> Model "Users_model" initialized
INFO - 2022-03-08 01:17:30 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:17:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:17:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:17:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:17:30 --> Final output sent to browser
DEBUG - 2022-03-08 01:17:30 --> Total execution time: 0.0706
ERROR - 2022-03-08 01:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:17:41 --> Config Class Initialized
INFO - 2022-03-08 01:17:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:17:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:17:41 --> Utf8 Class Initialized
INFO - 2022-03-08 01:17:41 --> URI Class Initialized
INFO - 2022-03-08 01:17:41 --> Router Class Initialized
INFO - 2022-03-08 01:17:41 --> Output Class Initialized
INFO - 2022-03-08 01:17:41 --> Security Class Initialized
DEBUG - 2022-03-08 01:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:17:41 --> Input Class Initialized
INFO - 2022-03-08 01:17:41 --> Language Class Initialized
INFO - 2022-03-08 01:17:41 --> Loader Class Initialized
INFO - 2022-03-08 01:17:41 --> Helper loaded: url_helper
INFO - 2022-03-08 01:17:41 --> Helper loaded: form_helper
INFO - 2022-03-08 01:17:41 --> Helper loaded: common_helper
INFO - 2022-03-08 01:17:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:17:41 --> Controller Class Initialized
INFO - 2022-03-08 01:17:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:17:41 --> Encrypt Class Initialized
INFO - 2022-03-08 01:17:41 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:17:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:17:41 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:17:41 --> Model "Users_model" initialized
INFO - 2022-03-08 01:17:41 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:17:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:17:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:17:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:17:41 --> Final output sent to browser
DEBUG - 2022-03-08 01:17:41 --> Total execution time: 0.0883
ERROR - 2022-03-08 01:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:18:23 --> Config Class Initialized
INFO - 2022-03-08 01:18:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:18:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:18:23 --> Utf8 Class Initialized
INFO - 2022-03-08 01:18:23 --> URI Class Initialized
INFO - 2022-03-08 01:18:23 --> Router Class Initialized
INFO - 2022-03-08 01:18:23 --> Output Class Initialized
INFO - 2022-03-08 01:18:23 --> Security Class Initialized
DEBUG - 2022-03-08 01:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:18:23 --> Input Class Initialized
INFO - 2022-03-08 01:18:23 --> Language Class Initialized
INFO - 2022-03-08 01:18:23 --> Loader Class Initialized
INFO - 2022-03-08 01:18:23 --> Helper loaded: url_helper
INFO - 2022-03-08 01:18:23 --> Helper loaded: form_helper
INFO - 2022-03-08 01:18:23 --> Helper loaded: common_helper
INFO - 2022-03-08 01:18:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:18:23 --> Controller Class Initialized
INFO - 2022-03-08 01:18:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:18:23 --> Encrypt Class Initialized
INFO - 2022-03-08 01:18:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:18:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:18:23 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:18:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:18:23 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:18:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:18:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 01:18:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:18:31 --> Final output sent to browser
DEBUG - 2022-03-08 01:18:31 --> Total execution time: 6.1570
ERROR - 2022-03-08 01:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:18:57 --> Config Class Initialized
INFO - 2022-03-08 01:18:57 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:18:57 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:18:57 --> Utf8 Class Initialized
INFO - 2022-03-08 01:18:57 --> URI Class Initialized
INFO - 2022-03-08 01:18:57 --> Router Class Initialized
INFO - 2022-03-08 01:18:57 --> Output Class Initialized
INFO - 2022-03-08 01:18:57 --> Security Class Initialized
DEBUG - 2022-03-08 01:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:18:57 --> Input Class Initialized
INFO - 2022-03-08 01:18:57 --> Language Class Initialized
INFO - 2022-03-08 01:18:57 --> Loader Class Initialized
INFO - 2022-03-08 01:18:57 --> Helper loaded: url_helper
INFO - 2022-03-08 01:18:57 --> Helper loaded: form_helper
INFO - 2022-03-08 01:18:57 --> Helper loaded: common_helper
INFO - 2022-03-08 01:18:57 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:18:57 --> Controller Class Initialized
INFO - 2022-03-08 01:18:57 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:18:57 --> Encrypt Class Initialized
INFO - 2022-03-08 01:18:57 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:18:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:18:57 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:18:57 --> Model "Users_model" initialized
INFO - 2022-03-08 01:18:57 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:18:57 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-08 01:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:18:57 --> Config Class Initialized
INFO - 2022-03-08 01:18:57 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:18:57 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:18:57 --> Utf8 Class Initialized
INFO - 2022-03-08 01:18:57 --> URI Class Initialized
INFO - 2022-03-08 01:18:57 --> Router Class Initialized
INFO - 2022-03-08 01:18:58 --> Output Class Initialized
INFO - 2022-03-08 01:18:58 --> Security Class Initialized
DEBUG - 2022-03-08 01:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:18:58 --> Input Class Initialized
INFO - 2022-03-08 01:18:58 --> Language Class Initialized
ERROR - 2022-03-08 01:18:58 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-08 01:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:18:58 --> Config Class Initialized
INFO - 2022-03-08 01:18:58 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:18:58 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:18:58 --> Utf8 Class Initialized
INFO - 2022-03-08 01:18:58 --> URI Class Initialized
INFO - 2022-03-08 01:18:58 --> Router Class Initialized
INFO - 2022-03-08 01:18:58 --> Output Class Initialized
INFO - 2022-03-08 01:18:58 --> Security Class Initialized
DEBUG - 2022-03-08 01:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:18:58 --> Input Class Initialized
INFO - 2022-03-08 01:18:58 --> Language Class Initialized
ERROR - 2022-03-08 01:18:58 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-08 01:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:18:58 --> Config Class Initialized
INFO - 2022-03-08 01:18:58 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:18:58 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:18:58 --> Utf8 Class Initialized
INFO - 2022-03-08 01:18:58 --> URI Class Initialized
INFO - 2022-03-08 01:18:58 --> Router Class Initialized
INFO - 2022-03-08 01:18:58 --> Output Class Initialized
INFO - 2022-03-08 01:18:58 --> Security Class Initialized
DEBUG - 2022-03-08 01:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:18:58 --> Input Class Initialized
INFO - 2022-03-08 01:18:58 --> Language Class Initialized
ERROR - 2022-03-08 01:18:58 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-08 01:18:59 --> Final output sent to browser
DEBUG - 2022-03-08 01:18:59 --> Total execution time: 1.7109
ERROR - 2022-03-08 01:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:20:30 --> Config Class Initialized
INFO - 2022-03-08 01:20:30 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:20:30 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:20:30 --> Utf8 Class Initialized
INFO - 2022-03-08 01:20:30 --> URI Class Initialized
INFO - 2022-03-08 01:20:30 --> Router Class Initialized
INFO - 2022-03-08 01:20:30 --> Output Class Initialized
INFO - 2022-03-08 01:20:30 --> Security Class Initialized
DEBUG - 2022-03-08 01:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:20:30 --> Input Class Initialized
INFO - 2022-03-08 01:20:30 --> Language Class Initialized
INFO - 2022-03-08 01:20:30 --> Loader Class Initialized
INFO - 2022-03-08 01:20:30 --> Helper loaded: url_helper
INFO - 2022-03-08 01:20:30 --> Helper loaded: form_helper
INFO - 2022-03-08 01:20:30 --> Helper loaded: common_helper
INFO - 2022-03-08 01:20:30 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:20:30 --> Controller Class Initialized
INFO - 2022-03-08 01:20:30 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:20:30 --> Encrypt Class Initialized
INFO - 2022-03-08 01:20:30 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:20:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:20:30 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:20:30 --> Model "Users_model" initialized
INFO - 2022-03-08 01:20:30 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:20:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:20:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:20:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:20:31 --> Final output sent to browser
DEBUG - 2022-03-08 01:20:31 --> Total execution time: 0.0862
ERROR - 2022-03-08 01:21:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:21:16 --> Config Class Initialized
INFO - 2022-03-08 01:21:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:21:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:21:16 --> Utf8 Class Initialized
INFO - 2022-03-08 01:21:16 --> URI Class Initialized
INFO - 2022-03-08 01:21:16 --> Router Class Initialized
INFO - 2022-03-08 01:21:16 --> Output Class Initialized
INFO - 2022-03-08 01:21:16 --> Security Class Initialized
DEBUG - 2022-03-08 01:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:21:16 --> Input Class Initialized
INFO - 2022-03-08 01:21:16 --> Language Class Initialized
INFO - 2022-03-08 01:21:16 --> Loader Class Initialized
INFO - 2022-03-08 01:21:16 --> Helper loaded: url_helper
INFO - 2022-03-08 01:21:16 --> Helper loaded: form_helper
INFO - 2022-03-08 01:21:16 --> Helper loaded: common_helper
INFO - 2022-03-08 01:21:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:21:16 --> Controller Class Initialized
INFO - 2022-03-08 01:21:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:21:16 --> Encrypt Class Initialized
INFO - 2022-03-08 01:21:16 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:21:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:21:16 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:21:16 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:21:16 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:21:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:21:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 01:21:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:21:23 --> Final output sent to browser
DEBUG - 2022-03-08 01:21:23 --> Total execution time: 5.2164
ERROR - 2022-03-08 01:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:22:56 --> Config Class Initialized
INFO - 2022-03-08 01:22:56 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:22:56 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:22:56 --> Utf8 Class Initialized
INFO - 2022-03-08 01:22:56 --> URI Class Initialized
INFO - 2022-03-08 01:22:56 --> Router Class Initialized
INFO - 2022-03-08 01:22:56 --> Output Class Initialized
INFO - 2022-03-08 01:22:56 --> Security Class Initialized
DEBUG - 2022-03-08 01:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:22:56 --> Input Class Initialized
INFO - 2022-03-08 01:22:56 --> Language Class Initialized
INFO - 2022-03-08 01:22:56 --> Loader Class Initialized
INFO - 2022-03-08 01:22:56 --> Helper loaded: url_helper
INFO - 2022-03-08 01:22:56 --> Helper loaded: form_helper
INFO - 2022-03-08 01:22:56 --> Helper loaded: common_helper
INFO - 2022-03-08 01:22:56 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:22:56 --> Controller Class Initialized
INFO - 2022-03-08 01:22:56 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:22:56 --> Encrypt Class Initialized
INFO - 2022-03-08 01:22:56 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:22:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:22:56 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:22:56 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:22:56 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:22:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:23:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 01:23:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:23:08 --> Final output sent to browser
DEBUG - 2022-03-08 01:23:08 --> Total execution time: 9.8711
ERROR - 2022-03-08 01:23:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:23:22 --> Config Class Initialized
INFO - 2022-03-08 01:23:22 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:23:22 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:23:22 --> Utf8 Class Initialized
INFO - 2022-03-08 01:23:22 --> URI Class Initialized
INFO - 2022-03-08 01:23:22 --> Router Class Initialized
INFO - 2022-03-08 01:23:22 --> Output Class Initialized
INFO - 2022-03-08 01:23:22 --> Security Class Initialized
DEBUG - 2022-03-08 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:23:22 --> Input Class Initialized
INFO - 2022-03-08 01:23:22 --> Language Class Initialized
INFO - 2022-03-08 01:23:22 --> Loader Class Initialized
INFO - 2022-03-08 01:23:22 --> Helper loaded: url_helper
INFO - 2022-03-08 01:23:22 --> Helper loaded: form_helper
INFO - 2022-03-08 01:23:22 --> Helper loaded: common_helper
INFO - 2022-03-08 01:23:22 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:23:22 --> Controller Class Initialized
INFO - 2022-03-08 01:23:22 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:23:22 --> Encrypt Class Initialized
INFO - 2022-03-08 01:23:22 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:23:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:23:22 --> Model "Referredby_model" initialized
INFO - 2022-03-08 01:23:22 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:23:22 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:23:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:23:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 01:23:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:23:30 --> Final output sent to browser
DEBUG - 2022-03-08 01:23:30 --> Total execution time: 6.1977
ERROR - 2022-03-08 01:24:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:24:00 --> Config Class Initialized
INFO - 2022-03-08 01:24:00 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:24:00 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:24:00 --> Utf8 Class Initialized
INFO - 2022-03-08 01:24:00 --> URI Class Initialized
INFO - 2022-03-08 01:24:00 --> Router Class Initialized
INFO - 2022-03-08 01:24:00 --> Output Class Initialized
INFO - 2022-03-08 01:24:00 --> Security Class Initialized
DEBUG - 2022-03-08 01:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:24:00 --> Input Class Initialized
INFO - 2022-03-08 01:24:00 --> Language Class Initialized
INFO - 2022-03-08 01:24:00 --> Loader Class Initialized
INFO - 2022-03-08 01:24:00 --> Helper loaded: url_helper
INFO - 2022-03-08 01:24:00 --> Helper loaded: form_helper
INFO - 2022-03-08 01:24:00 --> Helper loaded: common_helper
INFO - 2022-03-08 01:24:00 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:24:00 --> Controller Class Initialized
INFO - 2022-03-08 01:24:00 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:24:00 --> Encrypt Class Initialized
INFO - 2022-03-08 01:24:00 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:24:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:24:01 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:24:01 --> Model "Users_model" initialized
INFO - 2022-03-08 01:24:01 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:24:01 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
ERROR - 2022-03-08 01:24:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:24:01 --> Config Class Initialized
INFO - 2022-03-08 01:24:01 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:24:01 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:24:01 --> Utf8 Class Initialized
INFO - 2022-03-08 01:24:01 --> URI Class Initialized
INFO - 2022-03-08 01:24:01 --> Router Class Initialized
INFO - 2022-03-08 01:24:01 --> Output Class Initialized
INFO - 2022-03-08 01:24:01 --> Security Class Initialized
DEBUG - 2022-03-08 01:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:24:01 --> Input Class Initialized
INFO - 2022-03-08 01:24:01 --> Language Class Initialized
ERROR - 2022-03-08 01:24:01 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-08 01:24:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:24:02 --> Config Class Initialized
INFO - 2022-03-08 01:24:02 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:24:02 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:24:02 --> Utf8 Class Initialized
INFO - 2022-03-08 01:24:02 --> URI Class Initialized
INFO - 2022-03-08 01:24:02 --> Router Class Initialized
INFO - 2022-03-08 01:24:02 --> Output Class Initialized
INFO - 2022-03-08 01:24:02 --> Security Class Initialized
DEBUG - 2022-03-08 01:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:24:02 --> Input Class Initialized
INFO - 2022-03-08 01:24:02 --> Language Class Initialized
ERROR - 2022-03-08 01:24:02 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-08 01:24:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:24:02 --> Config Class Initialized
INFO - 2022-03-08 01:24:02 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:24:02 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:24:02 --> Utf8 Class Initialized
INFO - 2022-03-08 01:24:02 --> URI Class Initialized
INFO - 2022-03-08 01:24:02 --> Router Class Initialized
INFO - 2022-03-08 01:24:02 --> Output Class Initialized
INFO - 2022-03-08 01:24:02 --> Security Class Initialized
DEBUG - 2022-03-08 01:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:24:02 --> Input Class Initialized
INFO - 2022-03-08 01:24:02 --> Language Class Initialized
ERROR - 2022-03-08 01:24:02 --> 404 Page Not Found: Karoclient/images
INFO - 2022-03-08 01:24:03 --> Final output sent to browser
DEBUG - 2022-03-08 01:24:03 --> Total execution time: 2.2141
ERROR - 2022-03-08 01:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 01:25:22 --> Config Class Initialized
INFO - 2022-03-08 01:25:22 --> Hooks Class Initialized
DEBUG - 2022-03-08 01:25:22 --> UTF-8 Support Enabled
INFO - 2022-03-08 01:25:22 --> Utf8 Class Initialized
INFO - 2022-03-08 01:25:22 --> URI Class Initialized
INFO - 2022-03-08 01:25:22 --> Router Class Initialized
INFO - 2022-03-08 01:25:22 --> Output Class Initialized
INFO - 2022-03-08 01:25:22 --> Security Class Initialized
DEBUG - 2022-03-08 01:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 01:25:22 --> Input Class Initialized
INFO - 2022-03-08 01:25:22 --> Language Class Initialized
INFO - 2022-03-08 01:25:22 --> Loader Class Initialized
INFO - 2022-03-08 01:25:22 --> Helper loaded: url_helper
INFO - 2022-03-08 01:25:22 --> Helper loaded: form_helper
INFO - 2022-03-08 01:25:22 --> Helper loaded: common_helper
INFO - 2022-03-08 01:25:22 --> Database Driver Class Initialized
DEBUG - 2022-03-08 01:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 01:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 01:25:22 --> Controller Class Initialized
INFO - 2022-03-08 01:25:22 --> Form Validation Class Initialized
DEBUG - 2022-03-08 01:25:22 --> Encrypt Class Initialized
INFO - 2022-03-08 01:25:22 --> Model "Patient_model" initialized
INFO - 2022-03-08 01:25:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 01:25:22 --> Model "Prefix_master" initialized
INFO - 2022-03-08 01:25:22 --> Model "Users_model" initialized
INFO - 2022-03-08 01:25:22 --> Model "Hospital_model" initialized
INFO - 2022-03-08 01:25:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 01:25:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 01:25:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 01:25:22 --> Final output sent to browser
DEBUG - 2022-03-08 01:25:22 --> Total execution time: 0.1520
ERROR - 2022-03-08 02:21:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 02:21:39 --> Config Class Initialized
INFO - 2022-03-08 02:21:39 --> Hooks Class Initialized
DEBUG - 2022-03-08 02:21:39 --> UTF-8 Support Enabled
INFO - 2022-03-08 02:21:39 --> Utf8 Class Initialized
INFO - 2022-03-08 02:21:39 --> URI Class Initialized
INFO - 2022-03-08 02:21:39 --> Router Class Initialized
INFO - 2022-03-08 02:21:39 --> Output Class Initialized
INFO - 2022-03-08 02:21:39 --> Security Class Initialized
DEBUG - 2022-03-08 02:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 02:21:39 --> Input Class Initialized
INFO - 2022-03-08 02:21:39 --> Language Class Initialized
INFO - 2022-03-08 02:21:39 --> Loader Class Initialized
INFO - 2022-03-08 02:21:39 --> Helper loaded: url_helper
INFO - 2022-03-08 02:21:39 --> Helper loaded: form_helper
INFO - 2022-03-08 02:21:39 --> Helper loaded: common_helper
INFO - 2022-03-08 02:21:39 --> Database Driver Class Initialized
DEBUG - 2022-03-08 02:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 02:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 02:21:39 --> Controller Class Initialized
INFO - 2022-03-08 02:21:39 --> Form Validation Class Initialized
DEBUG - 2022-03-08 02:21:39 --> Encrypt Class Initialized
INFO - 2022-03-08 02:21:39 --> Model "Patient_model" initialized
INFO - 2022-03-08 02:21:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 02:21:39 --> Model "Referredby_model" initialized
INFO - 2022-03-08 02:21:39 --> Model "Prefix_master" initialized
INFO - 2022-03-08 02:21:39 --> Model "Hospital_model" initialized
INFO - 2022-03-08 02:21:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 02:21:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 02:21:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 02:21:39 --> Final output sent to browser
DEBUG - 2022-03-08 02:21:39 --> Total execution time: 0.1484
ERROR - 2022-03-08 02:28:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 02:28:32 --> Config Class Initialized
INFO - 2022-03-08 02:28:32 --> Hooks Class Initialized
DEBUG - 2022-03-08 02:28:32 --> UTF-8 Support Enabled
INFO - 2022-03-08 02:28:32 --> Utf8 Class Initialized
INFO - 2022-03-08 02:28:32 --> URI Class Initialized
INFO - 2022-03-08 02:28:32 --> Router Class Initialized
INFO - 2022-03-08 02:28:32 --> Output Class Initialized
INFO - 2022-03-08 02:28:32 --> Security Class Initialized
DEBUG - 2022-03-08 02:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 02:28:32 --> Input Class Initialized
INFO - 2022-03-08 02:28:32 --> Language Class Initialized
INFO - 2022-03-08 02:28:32 --> Loader Class Initialized
INFO - 2022-03-08 02:28:32 --> Helper loaded: url_helper
INFO - 2022-03-08 02:28:32 --> Helper loaded: form_helper
INFO - 2022-03-08 02:28:32 --> Helper loaded: common_helper
INFO - 2022-03-08 02:28:32 --> Database Driver Class Initialized
DEBUG - 2022-03-08 02:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 02:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 02:28:33 --> Controller Class Initialized
INFO - 2022-03-08 02:28:33 --> Form Validation Class Initialized
DEBUG - 2022-03-08 02:28:33 --> Encrypt Class Initialized
INFO - 2022-03-08 02:28:33 --> Model "Patient_model" initialized
INFO - 2022-03-08 02:28:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 02:28:33 --> Model "Referredby_model" initialized
INFO - 2022-03-08 02:28:33 --> Model "Prefix_master" initialized
INFO - 2022-03-08 02:28:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 02:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 02:28:34 --> Config Class Initialized
INFO - 2022-03-08 02:28:34 --> Hooks Class Initialized
DEBUG - 2022-03-08 02:28:34 --> UTF-8 Support Enabled
INFO - 2022-03-08 02:28:34 --> Utf8 Class Initialized
INFO - 2022-03-08 02:28:34 --> URI Class Initialized
INFO - 2022-03-08 02:28:34 --> Router Class Initialized
INFO - 2022-03-08 02:28:34 --> Output Class Initialized
INFO - 2022-03-08 02:28:34 --> Security Class Initialized
DEBUG - 2022-03-08 02:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 02:28:34 --> Input Class Initialized
INFO - 2022-03-08 02:28:34 --> Language Class Initialized
INFO - 2022-03-08 02:28:34 --> Loader Class Initialized
INFO - 2022-03-08 02:28:34 --> Helper loaded: url_helper
INFO - 2022-03-08 02:28:34 --> Helper loaded: form_helper
INFO - 2022-03-08 02:28:34 --> Helper loaded: common_helper
INFO - 2022-03-08 02:28:34 --> Database Driver Class Initialized
DEBUG - 2022-03-08 02:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 02:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 02:28:34 --> Controller Class Initialized
INFO - 2022-03-08 02:28:34 --> Form Validation Class Initialized
DEBUG - 2022-03-08 02:28:34 --> Encrypt Class Initialized
INFO - 2022-03-08 02:28:34 --> Model "Patient_model" initialized
INFO - 2022-03-08 02:28:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 02:28:34 --> Model "Referredby_model" initialized
INFO - 2022-03-08 02:28:34 --> Model "Prefix_master" initialized
INFO - 2022-03-08 02:28:34 --> Model "Hospital_model" initialized
INFO - 2022-03-08 02:28:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 02:28:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 02:28:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 02:28:34 --> Final output sent to browser
DEBUG - 2022-03-08 02:28:34 --> Total execution time: 0.0605
ERROR - 2022-03-08 02:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 02:28:35 --> Config Class Initialized
INFO - 2022-03-08 02:28:35 --> Hooks Class Initialized
DEBUG - 2022-03-08 02:28:35 --> UTF-8 Support Enabled
INFO - 2022-03-08 02:28:35 --> Utf8 Class Initialized
INFO - 2022-03-08 02:28:35 --> URI Class Initialized
INFO - 2022-03-08 02:28:35 --> Router Class Initialized
INFO - 2022-03-08 02:28:35 --> Output Class Initialized
INFO - 2022-03-08 02:28:35 --> Security Class Initialized
DEBUG - 2022-03-08 02:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 02:28:35 --> Input Class Initialized
INFO - 2022-03-08 02:28:35 --> Language Class Initialized
INFO - 2022-03-08 02:28:35 --> Loader Class Initialized
INFO - 2022-03-08 02:28:35 --> Helper loaded: url_helper
INFO - 2022-03-08 02:28:35 --> Helper loaded: form_helper
INFO - 2022-03-08 02:28:35 --> Helper loaded: common_helper
INFO - 2022-03-08 02:28:35 --> Database Driver Class Initialized
DEBUG - 2022-03-08 02:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 02:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 02:28:35 --> Controller Class Initialized
INFO - 2022-03-08 02:28:35 --> Form Validation Class Initialized
DEBUG - 2022-03-08 02:28:35 --> Encrypt Class Initialized
INFO - 2022-03-08 02:28:35 --> Model "Patient_model" initialized
INFO - 2022-03-08 02:28:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 02:28:35 --> Model "Prefix_master" initialized
INFO - 2022-03-08 02:28:35 --> Model "Users_model" initialized
INFO - 2022-03-08 02:28:35 --> Model "Hospital_model" initialized
INFO - 2022-03-08 02:28:35 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 02:28:35 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 02:28:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 02:28:35 --> Final output sent to browser
DEBUG - 2022-03-08 02:28:35 --> Total execution time: 0.2154
ERROR - 2022-03-08 02:29:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 02:29:19 --> Config Class Initialized
INFO - 2022-03-08 02:29:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 02:29:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 02:29:19 --> Utf8 Class Initialized
INFO - 2022-03-08 02:29:19 --> URI Class Initialized
INFO - 2022-03-08 02:29:19 --> Router Class Initialized
INFO - 2022-03-08 02:29:19 --> Output Class Initialized
INFO - 2022-03-08 02:29:19 --> Security Class Initialized
DEBUG - 2022-03-08 02:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 02:29:19 --> Input Class Initialized
INFO - 2022-03-08 02:29:19 --> Language Class Initialized
INFO - 2022-03-08 02:29:19 --> Loader Class Initialized
INFO - 2022-03-08 02:29:19 --> Helper loaded: url_helper
INFO - 2022-03-08 02:29:19 --> Helper loaded: form_helper
INFO - 2022-03-08 02:29:19 --> Helper loaded: common_helper
INFO - 2022-03-08 02:29:19 --> Database Driver Class Initialized
DEBUG - 2022-03-08 02:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 02:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 02:29:20 --> Controller Class Initialized
INFO - 2022-03-08 02:29:20 --> Form Validation Class Initialized
DEBUG - 2022-03-08 02:29:20 --> Encrypt Class Initialized
INFO - 2022-03-08 02:29:20 --> Model "Patient_model" initialized
INFO - 2022-03-08 02:29:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 02:29:20 --> Model "Prefix_master" initialized
INFO - 2022-03-08 02:29:20 --> Model "Users_model" initialized
INFO - 2022-03-08 02:29:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 02:29:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 02:29:20 --> Config Class Initialized
INFO - 2022-03-08 02:29:20 --> Hooks Class Initialized
DEBUG - 2022-03-08 02:29:20 --> UTF-8 Support Enabled
INFO - 2022-03-08 02:29:20 --> Utf8 Class Initialized
INFO - 2022-03-08 02:29:20 --> URI Class Initialized
INFO - 2022-03-08 02:29:20 --> Router Class Initialized
INFO - 2022-03-08 02:29:20 --> Output Class Initialized
INFO - 2022-03-08 02:29:20 --> Security Class Initialized
DEBUG - 2022-03-08 02:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 02:29:20 --> Input Class Initialized
INFO - 2022-03-08 02:29:20 --> Language Class Initialized
INFO - 2022-03-08 02:29:20 --> Loader Class Initialized
INFO - 2022-03-08 02:29:20 --> Helper loaded: url_helper
INFO - 2022-03-08 02:29:20 --> Helper loaded: form_helper
INFO - 2022-03-08 02:29:20 --> Helper loaded: common_helper
INFO - 2022-03-08 02:29:20 --> Database Driver Class Initialized
DEBUG - 2022-03-08 02:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 02:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 02:29:20 --> Controller Class Initialized
INFO - 2022-03-08 02:29:20 --> Form Validation Class Initialized
DEBUG - 2022-03-08 02:29:20 --> Encrypt Class Initialized
INFO - 2022-03-08 02:29:20 --> Model "Patient_model" initialized
INFO - 2022-03-08 02:29:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 02:29:20 --> Model "Prefix_master" initialized
INFO - 2022-03-08 02:29:20 --> Model "Users_model" initialized
INFO - 2022-03-08 02:29:20 --> Model "Hospital_model" initialized
INFO - 2022-03-08 02:29:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 02:29:20 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 02:29:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 02:29:20 --> Final output sent to browser
DEBUG - 2022-03-08 02:29:20 --> Total execution time: 0.1417
ERROR - 2022-03-08 02:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 02:59:59 --> Config Class Initialized
INFO - 2022-03-08 02:59:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 02:59:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 02:59:59 --> Utf8 Class Initialized
INFO - 2022-03-08 02:59:59 --> URI Class Initialized
DEBUG - 2022-03-08 02:59:59 --> No URI present. Default controller set.
INFO - 2022-03-08 02:59:59 --> Router Class Initialized
INFO - 2022-03-08 02:59:59 --> Output Class Initialized
INFO - 2022-03-08 02:59:59 --> Security Class Initialized
DEBUG - 2022-03-08 02:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 02:59:59 --> Input Class Initialized
INFO - 2022-03-08 02:59:59 --> Language Class Initialized
INFO - 2022-03-08 02:59:59 --> Loader Class Initialized
INFO - 2022-03-08 02:59:59 --> Helper loaded: url_helper
INFO - 2022-03-08 02:59:59 --> Helper loaded: form_helper
INFO - 2022-03-08 02:59:59 --> Helper loaded: common_helper
INFO - 2022-03-08 02:59:59 --> Database Driver Class Initialized
DEBUG - 2022-03-08 02:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 02:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 02:59:59 --> Controller Class Initialized
INFO - 2022-03-08 02:59:59 --> Form Validation Class Initialized
DEBUG - 2022-03-08 02:59:59 --> Encrypt Class Initialized
DEBUG - 2022-03-08 02:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 02:59:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 02:59:59 --> Email Class Initialized
INFO - 2022-03-08 02:59:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 02:59:59 --> Calendar Class Initialized
INFO - 2022-03-08 02:59:59 --> Model "Login_model" initialized
INFO - 2022-03-08 02:59:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 02:59:59 --> Final output sent to browser
DEBUG - 2022-03-08 02:59:59 --> Total execution time: 0.2658
ERROR - 2022-03-08 03:00:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:00:37 --> Config Class Initialized
INFO - 2022-03-08 03:00:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:00:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:00:37 --> Utf8 Class Initialized
INFO - 2022-03-08 03:00:37 --> URI Class Initialized
INFO - 2022-03-08 03:00:37 --> Router Class Initialized
INFO - 2022-03-08 03:00:37 --> Output Class Initialized
INFO - 2022-03-08 03:00:37 --> Security Class Initialized
DEBUG - 2022-03-08 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:00:37 --> Input Class Initialized
INFO - 2022-03-08 03:00:37 --> Language Class Initialized
INFO - 2022-03-08 03:00:37 --> Loader Class Initialized
INFO - 2022-03-08 03:00:37 --> Helper loaded: url_helper
INFO - 2022-03-08 03:00:37 --> Helper loaded: form_helper
INFO - 2022-03-08 03:00:37 --> Helper loaded: common_helper
INFO - 2022-03-08 03:00:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:00:37 --> Controller Class Initialized
INFO - 2022-03-08 03:00:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:00:37 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:00:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:00:37 --> Email Class Initialized
INFO - 2022-03-08 03:00:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:00:37 --> Calendar Class Initialized
INFO - 2022-03-08 03:00:37 --> Model "Login_model" initialized
INFO - 2022-03-08 03:00:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 03:00:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:00:37 --> Config Class Initialized
INFO - 2022-03-08 03:00:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:00:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:00:37 --> Utf8 Class Initialized
INFO - 2022-03-08 03:00:37 --> URI Class Initialized
INFO - 2022-03-08 03:00:37 --> Router Class Initialized
INFO - 2022-03-08 03:00:37 --> Output Class Initialized
INFO - 2022-03-08 03:00:37 --> Security Class Initialized
DEBUG - 2022-03-08 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:00:37 --> Input Class Initialized
INFO - 2022-03-08 03:00:37 --> Language Class Initialized
INFO - 2022-03-08 03:00:37 --> Loader Class Initialized
INFO - 2022-03-08 03:00:37 --> Helper loaded: url_helper
INFO - 2022-03-08 03:00:37 --> Helper loaded: form_helper
INFO - 2022-03-08 03:00:37 --> Helper loaded: common_helper
INFO - 2022-03-08 03:00:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:00:37 --> Controller Class Initialized
INFO - 2022-03-08 03:00:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:00:37 --> Encrypt Class Initialized
INFO - 2022-03-08 03:00:37 --> Model "Login_model" initialized
INFO - 2022-03-08 03:00:37 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 03:00:37 --> Model "Case_model" initialized
ERROR - 2022-03-08 03:00:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:00:39 --> Config Class Initialized
INFO - 2022-03-08 03:00:39 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:00:39 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:00:39 --> Utf8 Class Initialized
INFO - 2022-03-08 03:00:39 --> URI Class Initialized
INFO - 2022-03-08 03:00:39 --> Router Class Initialized
INFO - 2022-03-08 03:00:39 --> Output Class Initialized
INFO - 2022-03-08 03:00:39 --> Security Class Initialized
DEBUG - 2022-03-08 03:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:00:39 --> Input Class Initialized
INFO - 2022-03-08 03:00:39 --> Language Class Initialized
INFO - 2022-03-08 03:00:39 --> Loader Class Initialized
INFO - 2022-03-08 03:00:39 --> Helper loaded: url_helper
INFO - 2022-03-08 03:00:39 --> Helper loaded: form_helper
INFO - 2022-03-08 03:00:39 --> Helper loaded: common_helper
INFO - 2022-03-08 03:00:39 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 03:00:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:00:41 --> Config Class Initialized
INFO - 2022-03-08 03:00:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:00:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:00:41 --> Utf8 Class Initialized
INFO - 2022-03-08 03:00:41 --> URI Class Initialized
INFO - 2022-03-08 03:00:41 --> Router Class Initialized
INFO - 2022-03-08 03:00:41 --> Output Class Initialized
INFO - 2022-03-08 03:00:41 --> Security Class Initialized
DEBUG - 2022-03-08 03:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:00:41 --> Input Class Initialized
INFO - 2022-03-08 03:00:41 --> Language Class Initialized
INFO - 2022-03-08 03:00:41 --> Loader Class Initialized
INFO - 2022-03-08 03:00:41 --> Helper loaded: url_helper
INFO - 2022-03-08 03:00:41 --> Helper loaded: form_helper
INFO - 2022-03-08 03:00:41 --> Helper loaded: common_helper
INFO - 2022-03-08 03:00:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:00:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:01:03 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 03:01:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:01:03 --> Final output sent to browser
DEBUG - 2022-03-08 03:01:03 --> Total execution time: 25.3911
INFO - 2022-03-08 03:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:01:03 --> Controller Class Initialized
INFO - 2022-03-08 03:01:03 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:01:03 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:01:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:01:03 --> Email Class Initialized
INFO - 2022-03-08 03:01:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:01:03 --> Calendar Class Initialized
INFO - 2022-03-08 03:01:03 --> Model "Login_model" initialized
INFO - 2022-03-08 03:01:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2022-03-08 03:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:01:03 --> Controller Class Initialized
INFO - 2022-03-08 03:01:03 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:01:03 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:01:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:01:03 --> Email Class Initialized
INFO - 2022-03-08 03:01:03 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:01:03 --> Calendar Class Initialized
INFO - 2022-03-08 03:01:03 --> Model "Login_model" initialized
INFO - 2022-03-08 03:01:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 03:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:01:04 --> Config Class Initialized
INFO - 2022-03-08 03:01:04 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:01:04 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:01:04 --> Utf8 Class Initialized
INFO - 2022-03-08 03:01:04 --> URI Class Initialized
INFO - 2022-03-08 03:01:04 --> Router Class Initialized
INFO - 2022-03-08 03:01:04 --> Output Class Initialized
INFO - 2022-03-08 03:01:04 --> Security Class Initialized
DEBUG - 2022-03-08 03:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:01:04 --> Input Class Initialized
INFO - 2022-03-08 03:01:04 --> Language Class Initialized
INFO - 2022-03-08 03:01:04 --> Loader Class Initialized
INFO - 2022-03-08 03:01:04 --> Helper loaded: url_helper
INFO - 2022-03-08 03:01:04 --> Helper loaded: form_helper
INFO - 2022-03-08 03:01:04 --> Helper loaded: common_helper
INFO - 2022-03-08 03:01:04 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:01:04 --> Controller Class Initialized
INFO - 2022-03-08 03:01:04 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:01:04 --> Encrypt Class Initialized
INFO - 2022-03-08 03:01:04 --> Model "Login_model" initialized
INFO - 2022-03-08 03:01:04 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 03:01:04 --> Model "Case_model" initialized
INFO - 2022-03-08 03:01:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 03:01:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:01:26 --> Config Class Initialized
INFO - 2022-03-08 03:01:26 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:01:26 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:01:26 --> Utf8 Class Initialized
INFO - 2022-03-08 03:01:26 --> URI Class Initialized
INFO - 2022-03-08 03:01:26 --> Router Class Initialized
INFO - 2022-03-08 03:01:26 --> Output Class Initialized
INFO - 2022-03-08 03:01:26 --> Security Class Initialized
DEBUG - 2022-03-08 03:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:01:26 --> Input Class Initialized
INFO - 2022-03-08 03:01:26 --> Language Class Initialized
INFO - 2022-03-08 03:01:26 --> Loader Class Initialized
INFO - 2022-03-08 03:01:26 --> Helper loaded: url_helper
INFO - 2022-03-08 03:01:26 --> Helper loaded: form_helper
INFO - 2022-03-08 03:01:26 --> Helper loaded: common_helper
INFO - 2022-03-08 03:01:26 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:01:30 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 03:01:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:01:30 --> Final output sent to browser
DEBUG - 2022-03-08 03:01:30 --> Total execution time: 26.4803
INFO - 2022-03-08 03:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:01:30 --> Controller Class Initialized
INFO - 2022-03-08 03:01:30 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:01:30 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:01:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:01:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:01:30 --> Email Class Initialized
INFO - 2022-03-08 03:01:30 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:01:30 --> Calendar Class Initialized
INFO - 2022-03-08 03:01:30 --> Model "Login_model" initialized
INFO - 2022-03-08 03:01:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 03:01:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:01:31 --> Config Class Initialized
INFO - 2022-03-08 03:01:31 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:01:31 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:01:31 --> Utf8 Class Initialized
INFO - 2022-03-08 03:01:31 --> URI Class Initialized
INFO - 2022-03-08 03:01:31 --> Router Class Initialized
INFO - 2022-03-08 03:01:31 --> Output Class Initialized
INFO - 2022-03-08 03:01:31 --> Security Class Initialized
DEBUG - 2022-03-08 03:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:01:31 --> Input Class Initialized
INFO - 2022-03-08 03:01:31 --> Language Class Initialized
INFO - 2022-03-08 03:01:31 --> Loader Class Initialized
INFO - 2022-03-08 03:01:31 --> Helper loaded: url_helper
INFO - 2022-03-08 03:01:31 --> Helper loaded: form_helper
INFO - 2022-03-08 03:01:31 --> Helper loaded: common_helper
INFO - 2022-03-08 03:01:31 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:01:31 --> Controller Class Initialized
INFO - 2022-03-08 03:01:31 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:01:31 --> Encrypt Class Initialized
INFO - 2022-03-08 03:01:31 --> Model "Login_model" initialized
INFO - 2022-03-08 03:01:31 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 03:01:31 --> Model "Case_model" initialized
INFO - 2022-03-08 03:01:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:01:51 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 03:01:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:01:51 --> Final output sent to browser
DEBUG - 2022-03-08 03:01:51 --> Total execution time: 20.5653
ERROR - 2022-03-08 03:01:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:01:52 --> Config Class Initialized
INFO - 2022-03-08 03:01:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:01:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:01:52 --> Utf8 Class Initialized
INFO - 2022-03-08 03:01:52 --> URI Class Initialized
INFO - 2022-03-08 03:01:52 --> Router Class Initialized
INFO - 2022-03-08 03:01:52 --> Output Class Initialized
INFO - 2022-03-08 03:01:52 --> Security Class Initialized
DEBUG - 2022-03-08 03:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:01:52 --> Input Class Initialized
INFO - 2022-03-08 03:01:52 --> Language Class Initialized
ERROR - 2022-03-08 03:01:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:02:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:02:23 --> Config Class Initialized
INFO - 2022-03-08 03:02:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:02:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:02:23 --> Utf8 Class Initialized
INFO - 2022-03-08 03:02:23 --> URI Class Initialized
INFO - 2022-03-08 03:02:23 --> Router Class Initialized
INFO - 2022-03-08 03:02:23 --> Output Class Initialized
INFO - 2022-03-08 03:02:23 --> Security Class Initialized
DEBUG - 2022-03-08 03:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:02:23 --> Input Class Initialized
INFO - 2022-03-08 03:02:23 --> Language Class Initialized
INFO - 2022-03-08 03:02:23 --> Loader Class Initialized
INFO - 2022-03-08 03:02:23 --> Helper loaded: url_helper
INFO - 2022-03-08 03:02:23 --> Helper loaded: form_helper
INFO - 2022-03-08 03:02:23 --> Helper loaded: common_helper
INFO - 2022-03-08 03:02:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:02:23 --> Controller Class Initialized
INFO - 2022-03-08 03:02:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:02:23 --> Encrypt Class Initialized
INFO - 2022-03-08 03:02:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:02:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:02:23 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:02:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:02:23 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:02:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:02:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 03:02:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 03:02:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:02:33 --> Config Class Initialized
INFO - 2022-03-08 03:02:33 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:02:33 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:02:33 --> Utf8 Class Initialized
INFO - 2022-03-08 03:02:33 --> URI Class Initialized
INFO - 2022-03-08 03:02:33 --> Router Class Initialized
INFO - 2022-03-08 03:02:33 --> Output Class Initialized
INFO - 2022-03-08 03:02:33 --> Security Class Initialized
DEBUG - 2022-03-08 03:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:02:33 --> Input Class Initialized
INFO - 2022-03-08 03:02:33 --> Language Class Initialized
ERROR - 2022-03-08 03:02:33 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 03:02:49 --> Final output sent to browser
DEBUG - 2022-03-08 03:02:49 --> Total execution time: 8.3843
ERROR - 2022-03-08 03:03:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:03:18 --> Config Class Initialized
INFO - 2022-03-08 03:03:18 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:03:18 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:03:18 --> Utf8 Class Initialized
INFO - 2022-03-08 03:03:18 --> URI Class Initialized
INFO - 2022-03-08 03:03:18 --> Router Class Initialized
INFO - 2022-03-08 03:03:18 --> Output Class Initialized
INFO - 2022-03-08 03:03:18 --> Security Class Initialized
DEBUG - 2022-03-08 03:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:03:18 --> Input Class Initialized
INFO - 2022-03-08 03:03:18 --> Language Class Initialized
INFO - 2022-03-08 03:03:18 --> Loader Class Initialized
INFO - 2022-03-08 03:03:18 --> Helper loaded: url_helper
INFO - 2022-03-08 03:03:18 --> Helper loaded: form_helper
INFO - 2022-03-08 03:03:18 --> Helper loaded: common_helper
INFO - 2022-03-08 03:03:18 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:03:18 --> Controller Class Initialized
INFO - 2022-03-08 03:03:18 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:03:18 --> Encrypt Class Initialized
INFO - 2022-03-08 03:03:18 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:03:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:03:18 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:03:18 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:03:18 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:03:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:03:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:03:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:03:18 --> Final output sent to browser
DEBUG - 2022-03-08 03:03:18 --> Total execution time: 0.0738
ERROR - 2022-03-08 03:03:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:03:19 --> Config Class Initialized
INFO - 2022-03-08 03:03:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:03:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:03:19 --> Utf8 Class Initialized
INFO - 2022-03-08 03:03:19 --> URI Class Initialized
INFO - 2022-03-08 03:03:19 --> Router Class Initialized
INFO - 2022-03-08 03:03:19 --> Output Class Initialized
INFO - 2022-03-08 03:03:19 --> Security Class Initialized
DEBUG - 2022-03-08 03:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:03:19 --> Input Class Initialized
INFO - 2022-03-08 03:03:19 --> Language Class Initialized
ERROR - 2022-03-08 03:03:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:05:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:05:31 --> Config Class Initialized
INFO - 2022-03-08 03:05:31 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:05:31 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:05:31 --> Utf8 Class Initialized
INFO - 2022-03-08 03:05:31 --> URI Class Initialized
INFO - 2022-03-08 03:05:31 --> Router Class Initialized
INFO - 2022-03-08 03:05:31 --> Output Class Initialized
INFO - 2022-03-08 03:05:31 --> Security Class Initialized
DEBUG - 2022-03-08 03:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:05:31 --> Input Class Initialized
INFO - 2022-03-08 03:05:31 --> Language Class Initialized
INFO - 2022-03-08 03:05:31 --> Loader Class Initialized
INFO - 2022-03-08 03:05:31 --> Helper loaded: url_helper
INFO - 2022-03-08 03:05:31 --> Helper loaded: form_helper
INFO - 2022-03-08 03:05:31 --> Helper loaded: common_helper
INFO - 2022-03-08 03:05:31 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:05:31 --> Controller Class Initialized
INFO - 2022-03-08 03:05:31 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:05:31 --> Encrypt Class Initialized
INFO - 2022-03-08 03:05:31 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:05:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:05:31 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:05:31 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:05:31 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:05:31 --> Upload Class Initialized
INFO - 2022-03-08 03:05:31 --> Final output sent to browser
DEBUG - 2022-03-08 03:05:31 --> Total execution time: 0.0358
ERROR - 2022-03-08 03:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:05:41 --> Config Class Initialized
INFO - 2022-03-08 03:05:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:05:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:05:41 --> Utf8 Class Initialized
INFO - 2022-03-08 03:05:41 --> URI Class Initialized
INFO - 2022-03-08 03:05:41 --> Router Class Initialized
INFO - 2022-03-08 03:05:41 --> Output Class Initialized
INFO - 2022-03-08 03:05:41 --> Security Class Initialized
DEBUG - 2022-03-08 03:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:05:41 --> Input Class Initialized
INFO - 2022-03-08 03:05:41 --> Language Class Initialized
INFO - 2022-03-08 03:05:41 --> Loader Class Initialized
INFO - 2022-03-08 03:05:41 --> Helper loaded: url_helper
INFO - 2022-03-08 03:05:41 --> Helper loaded: form_helper
INFO - 2022-03-08 03:05:41 --> Helper loaded: common_helper
INFO - 2022-03-08 03:05:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:05:41 --> Controller Class Initialized
INFO - 2022-03-08 03:05:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:05:41 --> Encrypt Class Initialized
INFO - 2022-03-08 03:05:41 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:05:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:05:41 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:05:41 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:05:41 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:05:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:05:42 --> Config Class Initialized
INFO - 2022-03-08 03:05:42 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:05:42 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:05:42 --> Utf8 Class Initialized
INFO - 2022-03-08 03:05:42 --> URI Class Initialized
INFO - 2022-03-08 03:05:42 --> Router Class Initialized
INFO - 2022-03-08 03:05:42 --> Output Class Initialized
INFO - 2022-03-08 03:05:42 --> Security Class Initialized
DEBUG - 2022-03-08 03:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:05:42 --> Input Class Initialized
INFO - 2022-03-08 03:05:42 --> Language Class Initialized
INFO - 2022-03-08 03:05:42 --> Loader Class Initialized
INFO - 2022-03-08 03:05:42 --> Helper loaded: url_helper
INFO - 2022-03-08 03:05:42 --> Helper loaded: form_helper
INFO - 2022-03-08 03:05:42 --> Helper loaded: common_helper
INFO - 2022-03-08 03:05:42 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:05:42 --> Controller Class Initialized
INFO - 2022-03-08 03:05:42 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:05:42 --> Encrypt Class Initialized
INFO - 2022-03-08 03:05:42 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:05:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:05:42 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:05:42 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:05:42 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:05:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:05:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:05:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:05:42 --> Final output sent to browser
DEBUG - 2022-03-08 03:05:42 --> Total execution time: 0.0688
ERROR - 2022-03-08 03:05:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:05:43 --> Config Class Initialized
INFO - 2022-03-08 03:05:43 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:05:43 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:05:43 --> Utf8 Class Initialized
INFO - 2022-03-08 03:05:43 --> URI Class Initialized
INFO - 2022-03-08 03:05:43 --> Router Class Initialized
INFO - 2022-03-08 03:05:43 --> Output Class Initialized
INFO - 2022-03-08 03:05:43 --> Security Class Initialized
DEBUG - 2022-03-08 03:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:05:43 --> Input Class Initialized
INFO - 2022-03-08 03:05:43 --> Language Class Initialized
ERROR - 2022-03-08 03:05:43 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:05:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:05:43 --> Config Class Initialized
INFO - 2022-03-08 03:05:43 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:05:43 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:05:43 --> Utf8 Class Initialized
INFO - 2022-03-08 03:05:43 --> URI Class Initialized
INFO - 2022-03-08 03:05:43 --> Router Class Initialized
INFO - 2022-03-08 03:05:43 --> Output Class Initialized
INFO - 2022-03-08 03:05:43 --> Security Class Initialized
DEBUG - 2022-03-08 03:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:05:43 --> Input Class Initialized
INFO - 2022-03-08 03:05:43 --> Language Class Initialized
INFO - 2022-03-08 03:05:43 --> Loader Class Initialized
INFO - 2022-03-08 03:05:43 --> Helper loaded: url_helper
INFO - 2022-03-08 03:05:43 --> Helper loaded: form_helper
INFO - 2022-03-08 03:05:43 --> Helper loaded: common_helper
INFO - 2022-03-08 03:05:43 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:05:43 --> Controller Class Initialized
INFO - 2022-03-08 03:05:43 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:05:43 --> Encrypt Class Initialized
INFO - 2022-03-08 03:05:43 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:05:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:05:43 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:05:43 --> Model "Users_model" initialized
INFO - 2022-03-08 03:05:43 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:05:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:05:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:05:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:05:43 --> Final output sent to browser
DEBUG - 2022-03-08 03:05:43 --> Total execution time: 0.0689
ERROR - 2022-03-08 03:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:05:44 --> Config Class Initialized
INFO - 2022-03-08 03:05:44 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:05:44 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:05:44 --> Utf8 Class Initialized
INFO - 2022-03-08 03:05:44 --> URI Class Initialized
INFO - 2022-03-08 03:05:44 --> Router Class Initialized
INFO - 2022-03-08 03:05:44 --> Output Class Initialized
INFO - 2022-03-08 03:05:44 --> Security Class Initialized
DEBUG - 2022-03-08 03:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:05:44 --> Input Class Initialized
INFO - 2022-03-08 03:05:44 --> Language Class Initialized
ERROR - 2022-03-08 03:05:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:05:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:05:48 --> Config Class Initialized
INFO - 2022-03-08 03:05:48 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:05:48 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:05:48 --> Utf8 Class Initialized
INFO - 2022-03-08 03:05:48 --> URI Class Initialized
INFO - 2022-03-08 03:05:48 --> Router Class Initialized
INFO - 2022-03-08 03:05:48 --> Output Class Initialized
INFO - 2022-03-08 03:05:48 --> Security Class Initialized
DEBUG - 2022-03-08 03:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:05:48 --> Input Class Initialized
INFO - 2022-03-08 03:05:48 --> Language Class Initialized
INFO - 2022-03-08 03:05:48 --> Loader Class Initialized
INFO - 2022-03-08 03:05:48 --> Helper loaded: url_helper
INFO - 2022-03-08 03:05:48 --> Helper loaded: form_helper
INFO - 2022-03-08 03:05:48 --> Helper loaded: common_helper
INFO - 2022-03-08 03:05:48 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:05:48 --> Controller Class Initialized
INFO - 2022-03-08 03:05:48 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:05:48 --> Encrypt Class Initialized
INFO - 2022-03-08 03:05:48 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:05:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:05:48 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:05:48 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:05:48 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:05:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:05:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:05:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:05:49 --> Final output sent to browser
DEBUG - 2022-03-08 03:05:49 --> Total execution time: 0.0524
ERROR - 2022-03-08 03:05:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:05:51 --> Config Class Initialized
INFO - 2022-03-08 03:05:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:05:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:05:51 --> Utf8 Class Initialized
INFO - 2022-03-08 03:05:51 --> URI Class Initialized
INFO - 2022-03-08 03:05:51 --> Router Class Initialized
INFO - 2022-03-08 03:05:51 --> Output Class Initialized
INFO - 2022-03-08 03:05:51 --> Security Class Initialized
DEBUG - 2022-03-08 03:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:05:51 --> Input Class Initialized
INFO - 2022-03-08 03:05:51 --> Language Class Initialized
ERROR - 2022-03-08 03:05:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:16:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:16:00 --> Config Class Initialized
INFO - 2022-03-08 03:16:00 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:16:00 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:16:00 --> Utf8 Class Initialized
INFO - 2022-03-08 03:16:00 --> URI Class Initialized
INFO - 2022-03-08 03:16:00 --> Router Class Initialized
INFO - 2022-03-08 03:16:00 --> Output Class Initialized
INFO - 2022-03-08 03:16:00 --> Security Class Initialized
DEBUG - 2022-03-08 03:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:16:00 --> Input Class Initialized
INFO - 2022-03-08 03:16:00 --> Language Class Initialized
INFO - 2022-03-08 03:16:00 --> Loader Class Initialized
INFO - 2022-03-08 03:16:00 --> Helper loaded: url_helper
INFO - 2022-03-08 03:16:00 --> Helper loaded: form_helper
INFO - 2022-03-08 03:16:00 --> Helper loaded: common_helper
INFO - 2022-03-08 03:16:00 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:16:00 --> Controller Class Initialized
INFO - 2022-03-08 03:16:00 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:16:00 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:16:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:16:00 --> Email Class Initialized
INFO - 2022-03-08 03:16:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:16:00 --> Calendar Class Initialized
INFO - 2022-03-08 03:16:00 --> Model "Login_model" initialized
INFO - 2022-03-08 03:16:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 03:16:00 --> Final output sent to browser
DEBUG - 2022-03-08 03:16:00 --> Total execution time: 0.0225
ERROR - 2022-03-08 03:16:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:16:12 --> Config Class Initialized
INFO - 2022-03-08 03:16:12 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:16:12 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:16:12 --> Utf8 Class Initialized
INFO - 2022-03-08 03:16:12 --> URI Class Initialized
INFO - 2022-03-08 03:16:12 --> Router Class Initialized
INFO - 2022-03-08 03:16:12 --> Output Class Initialized
INFO - 2022-03-08 03:16:12 --> Security Class Initialized
DEBUG - 2022-03-08 03:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:16:12 --> Input Class Initialized
INFO - 2022-03-08 03:16:12 --> Language Class Initialized
INFO - 2022-03-08 03:16:12 --> Loader Class Initialized
INFO - 2022-03-08 03:16:12 --> Helper loaded: url_helper
INFO - 2022-03-08 03:16:12 --> Helper loaded: form_helper
INFO - 2022-03-08 03:16:12 --> Helper loaded: common_helper
INFO - 2022-03-08 03:16:12 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:16:12 --> Controller Class Initialized
INFO - 2022-03-08 03:16:12 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:16:12 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:16:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:16:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:16:12 --> Email Class Initialized
INFO - 2022-03-08 03:16:12 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:16:12 --> Calendar Class Initialized
INFO - 2022-03-08 03:16:12 --> Model "Login_model" initialized
INFO - 2022-03-08 03:16:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 03:16:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:16:12 --> Config Class Initialized
INFO - 2022-03-08 03:16:12 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:16:12 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:16:12 --> Utf8 Class Initialized
INFO - 2022-03-08 03:16:12 --> URI Class Initialized
INFO - 2022-03-08 03:16:12 --> Router Class Initialized
INFO - 2022-03-08 03:16:12 --> Output Class Initialized
INFO - 2022-03-08 03:16:12 --> Security Class Initialized
DEBUG - 2022-03-08 03:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:16:12 --> Input Class Initialized
INFO - 2022-03-08 03:16:12 --> Language Class Initialized
INFO - 2022-03-08 03:16:12 --> Loader Class Initialized
INFO - 2022-03-08 03:16:12 --> Helper loaded: url_helper
INFO - 2022-03-08 03:16:12 --> Helper loaded: form_helper
INFO - 2022-03-08 03:16:12 --> Helper loaded: common_helper
INFO - 2022-03-08 03:16:12 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:16:12 --> Controller Class Initialized
INFO - 2022-03-08 03:16:12 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:16:12 --> Encrypt Class Initialized
INFO - 2022-03-08 03:16:12 --> Model "Login_model" initialized
INFO - 2022-03-08 03:16:12 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 03:16:12 --> Model "Case_model" initialized
INFO - 2022-03-08 03:16:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:16:13 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 03:16:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:16:13 --> Final output sent to browser
DEBUG - 2022-03-08 03:16:13 --> Total execution time: 0.2152
ERROR - 2022-03-08 03:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:16:28 --> Config Class Initialized
INFO - 2022-03-08 03:16:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:16:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:16:28 --> Utf8 Class Initialized
INFO - 2022-03-08 03:16:28 --> URI Class Initialized
INFO - 2022-03-08 03:16:28 --> Router Class Initialized
INFO - 2022-03-08 03:16:28 --> Output Class Initialized
INFO - 2022-03-08 03:16:28 --> Security Class Initialized
DEBUG - 2022-03-08 03:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:16:28 --> Input Class Initialized
INFO - 2022-03-08 03:16:28 --> Language Class Initialized
INFO - 2022-03-08 03:16:28 --> Loader Class Initialized
INFO - 2022-03-08 03:16:28 --> Helper loaded: url_helper
INFO - 2022-03-08 03:16:28 --> Helper loaded: form_helper
INFO - 2022-03-08 03:16:28 --> Helper loaded: common_helper
INFO - 2022-03-08 03:16:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:16:28 --> Controller Class Initialized
INFO - 2022-03-08 03:16:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:16:28 --> Encrypt Class Initialized
INFO - 2022-03-08 03:16:28 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:16:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:16:28 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:16:28 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:16:28 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:16:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:16:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patient_by_category.php
INFO - 2022-03-08 03:16:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:16:28 --> Final output sent to browser
DEBUG - 2022-03-08 03:16:28 --> Total execution time: 0.0588
ERROR - 2022-03-08 03:16:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:16:38 --> Config Class Initialized
INFO - 2022-03-08 03:16:38 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:16:38 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:16:38 --> Utf8 Class Initialized
INFO - 2022-03-08 03:16:38 --> URI Class Initialized
INFO - 2022-03-08 03:16:38 --> Router Class Initialized
INFO - 2022-03-08 03:16:38 --> Output Class Initialized
INFO - 2022-03-08 03:16:38 --> Security Class Initialized
DEBUG - 2022-03-08 03:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:16:38 --> Input Class Initialized
INFO - 2022-03-08 03:16:38 --> Language Class Initialized
INFO - 2022-03-08 03:16:38 --> Loader Class Initialized
INFO - 2022-03-08 03:16:38 --> Helper loaded: url_helper
INFO - 2022-03-08 03:16:38 --> Helper loaded: form_helper
INFO - 2022-03-08 03:16:38 --> Helper loaded: common_helper
INFO - 2022-03-08 03:16:38 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:16:38 --> Controller Class Initialized
INFO - 2022-03-08 03:16:38 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:16:38 --> Encrypt Class Initialized
INFO - 2022-03-08 03:16:38 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:16:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:16:38 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:16:38 --> Model "Users_model" initialized
INFO - 2022-03-08 03:16:38 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:16:38 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-08 03:16:39 --> Final output sent to browser
DEBUG - 2022-03-08 03:16:39 --> Total execution time: 1.1021
ERROR - 2022-03-08 03:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:17:41 --> Config Class Initialized
INFO - 2022-03-08 03:17:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:17:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:17:41 --> Utf8 Class Initialized
INFO - 2022-03-08 03:17:41 --> URI Class Initialized
INFO - 2022-03-08 03:17:41 --> Router Class Initialized
INFO - 2022-03-08 03:17:41 --> Output Class Initialized
INFO - 2022-03-08 03:17:41 --> Security Class Initialized
DEBUG - 2022-03-08 03:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:17:41 --> Input Class Initialized
INFO - 2022-03-08 03:17:41 --> Language Class Initialized
INFO - 2022-03-08 03:17:41 --> Loader Class Initialized
INFO - 2022-03-08 03:17:41 --> Helper loaded: url_helper
INFO - 2022-03-08 03:17:41 --> Helper loaded: form_helper
INFO - 2022-03-08 03:17:41 --> Helper loaded: common_helper
INFO - 2022-03-08 03:17:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:17:41 --> Controller Class Initialized
INFO - 2022-03-08 03:17:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:17:41 --> Encrypt Class Initialized
INFO - 2022-03-08 03:17:41 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:17:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:17:41 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:17:41 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:17:41 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:17:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:17:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/patient_by_category.php
INFO - 2022-03-08 03:17:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:17:41 --> Final output sent to browser
DEBUG - 2022-03-08 03:17:41 --> Total execution time: 0.0306
ERROR - 2022-03-08 03:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:17:44 --> Config Class Initialized
INFO - 2022-03-08 03:17:44 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:17:44 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:17:44 --> Utf8 Class Initialized
INFO - 2022-03-08 03:17:44 --> URI Class Initialized
INFO - 2022-03-08 03:17:44 --> Router Class Initialized
INFO - 2022-03-08 03:17:44 --> Output Class Initialized
INFO - 2022-03-08 03:17:44 --> Security Class Initialized
DEBUG - 2022-03-08 03:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:17:44 --> Input Class Initialized
INFO - 2022-03-08 03:17:44 --> Language Class Initialized
INFO - 2022-03-08 03:17:44 --> Loader Class Initialized
INFO - 2022-03-08 03:17:44 --> Helper loaded: url_helper
INFO - 2022-03-08 03:17:44 --> Helper loaded: form_helper
INFO - 2022-03-08 03:17:44 --> Helper loaded: common_helper
INFO - 2022-03-08 03:17:44 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:17:44 --> Controller Class Initialized
INFO - 2022-03-08 03:17:44 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:17:44 --> Encrypt Class Initialized
INFO - 2022-03-08 03:17:44 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:17:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:17:44 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:17:44 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:17:44 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:17:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:17:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:17:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:17:44 --> Final output sent to browser
DEBUG - 2022-03-08 03:17:44 --> Total execution time: 0.0544
ERROR - 2022-03-08 03:18:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:18:25 --> Config Class Initialized
INFO - 2022-03-08 03:18:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:18:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:18:25 --> Utf8 Class Initialized
INFO - 2022-03-08 03:18:25 --> URI Class Initialized
INFO - 2022-03-08 03:18:25 --> Router Class Initialized
INFO - 2022-03-08 03:18:25 --> Output Class Initialized
INFO - 2022-03-08 03:18:25 --> Security Class Initialized
DEBUG - 2022-03-08 03:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:18:25 --> Input Class Initialized
INFO - 2022-03-08 03:18:25 --> Language Class Initialized
INFO - 2022-03-08 03:18:25 --> Loader Class Initialized
INFO - 2022-03-08 03:18:25 --> Helper loaded: url_helper
INFO - 2022-03-08 03:18:25 --> Helper loaded: form_helper
INFO - 2022-03-08 03:18:25 --> Helper loaded: common_helper
INFO - 2022-03-08 03:18:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:18:25 --> Controller Class Initialized
INFO - 2022-03-08 03:18:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:18:25 --> Encrypt Class Initialized
INFO - 2022-03-08 03:18:25 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:18:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:18:25 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:18:25 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:18:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:18:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:18:26 --> Config Class Initialized
INFO - 2022-03-08 03:18:26 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:18:26 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:18:26 --> Utf8 Class Initialized
INFO - 2022-03-08 03:18:26 --> URI Class Initialized
INFO - 2022-03-08 03:18:26 --> Router Class Initialized
INFO - 2022-03-08 03:18:26 --> Output Class Initialized
INFO - 2022-03-08 03:18:26 --> Security Class Initialized
DEBUG - 2022-03-08 03:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:18:26 --> Input Class Initialized
INFO - 2022-03-08 03:18:26 --> Language Class Initialized
INFO - 2022-03-08 03:18:26 --> Loader Class Initialized
INFO - 2022-03-08 03:18:26 --> Helper loaded: url_helper
INFO - 2022-03-08 03:18:26 --> Helper loaded: form_helper
INFO - 2022-03-08 03:18:26 --> Helper loaded: common_helper
INFO - 2022-03-08 03:18:26 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:18:26 --> Controller Class Initialized
INFO - 2022-03-08 03:18:26 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:18:26 --> Encrypt Class Initialized
INFO - 2022-03-08 03:18:26 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:18:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:18:26 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:18:26 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:18:26 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:18:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:18:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:18:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:18:26 --> Final output sent to browser
DEBUG - 2022-03-08 03:18:26 --> Total execution time: 0.0612
ERROR - 2022-03-08 03:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:18:27 --> Config Class Initialized
INFO - 2022-03-08 03:18:27 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:18:27 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:18:27 --> Utf8 Class Initialized
INFO - 2022-03-08 03:18:27 --> URI Class Initialized
INFO - 2022-03-08 03:18:27 --> Router Class Initialized
INFO - 2022-03-08 03:18:27 --> Output Class Initialized
INFO - 2022-03-08 03:18:27 --> Security Class Initialized
DEBUG - 2022-03-08 03:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:18:27 --> Input Class Initialized
INFO - 2022-03-08 03:18:27 --> Language Class Initialized
INFO - 2022-03-08 03:18:27 --> Loader Class Initialized
INFO - 2022-03-08 03:18:27 --> Helper loaded: url_helper
INFO - 2022-03-08 03:18:27 --> Helper loaded: form_helper
INFO - 2022-03-08 03:18:27 --> Helper loaded: common_helper
INFO - 2022-03-08 03:18:27 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:18:27 --> Controller Class Initialized
INFO - 2022-03-08 03:18:27 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:18:27 --> Encrypt Class Initialized
INFO - 2022-03-08 03:18:27 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:18:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:18:27 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:18:27 --> Model "Users_model" initialized
INFO - 2022-03-08 03:18:27 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:18:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:18:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:18:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:18:27 --> Final output sent to browser
DEBUG - 2022-03-08 03:18:27 --> Total execution time: 0.0559
ERROR - 2022-03-08 03:18:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:18:44 --> Config Class Initialized
INFO - 2022-03-08 03:18:44 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:18:44 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:18:44 --> Utf8 Class Initialized
INFO - 2022-03-08 03:18:44 --> URI Class Initialized
INFO - 2022-03-08 03:18:44 --> Router Class Initialized
INFO - 2022-03-08 03:18:44 --> Output Class Initialized
INFO - 2022-03-08 03:18:44 --> Security Class Initialized
DEBUG - 2022-03-08 03:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:18:44 --> Input Class Initialized
INFO - 2022-03-08 03:18:44 --> Language Class Initialized
INFO - 2022-03-08 03:18:44 --> Loader Class Initialized
INFO - 2022-03-08 03:18:44 --> Helper loaded: url_helper
INFO - 2022-03-08 03:18:44 --> Helper loaded: form_helper
INFO - 2022-03-08 03:18:44 --> Helper loaded: common_helper
INFO - 2022-03-08 03:18:44 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:18:44 --> Controller Class Initialized
INFO - 2022-03-08 03:18:44 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:18:44 --> Encrypt Class Initialized
INFO - 2022-03-08 03:18:45 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:18:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:18:45 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:18:45 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:18:45 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:18:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:18:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:18:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:18:45 --> Final output sent to browser
DEBUG - 2022-03-08 03:18:45 --> Total execution time: 1.0086
ERROR - 2022-03-08 03:18:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:18:45 --> Config Class Initialized
INFO - 2022-03-08 03:18:45 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:18:45 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:18:45 --> Utf8 Class Initialized
INFO - 2022-03-08 03:18:45 --> URI Class Initialized
INFO - 2022-03-08 03:18:45 --> Router Class Initialized
INFO - 2022-03-08 03:18:45 --> Output Class Initialized
INFO - 2022-03-08 03:18:45 --> Security Class Initialized
DEBUG - 2022-03-08 03:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:18:45 --> Input Class Initialized
INFO - 2022-03-08 03:18:45 --> Language Class Initialized
ERROR - 2022-03-08 03:18:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:19:17 --> Config Class Initialized
INFO - 2022-03-08 03:19:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:19:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:19:17 --> Utf8 Class Initialized
INFO - 2022-03-08 03:19:17 --> URI Class Initialized
INFO - 2022-03-08 03:19:17 --> Router Class Initialized
INFO - 2022-03-08 03:19:17 --> Output Class Initialized
INFO - 2022-03-08 03:19:17 --> Security Class Initialized
DEBUG - 2022-03-08 03:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:19:17 --> Input Class Initialized
INFO - 2022-03-08 03:19:17 --> Language Class Initialized
INFO - 2022-03-08 03:19:17 --> Loader Class Initialized
INFO - 2022-03-08 03:19:17 --> Helper loaded: url_helper
INFO - 2022-03-08 03:19:17 --> Helper loaded: form_helper
INFO - 2022-03-08 03:19:17 --> Helper loaded: common_helper
INFO - 2022-03-08 03:19:17 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:19:17 --> Controller Class Initialized
INFO - 2022-03-08 03:19:17 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:19:17 --> Encrypt Class Initialized
INFO - 2022-03-08 03:19:17 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:19:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:19:17 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:19:17 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:19:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:19:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:19:18 --> Config Class Initialized
INFO - 2022-03-08 03:19:18 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:19:18 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:19:18 --> Utf8 Class Initialized
INFO - 2022-03-08 03:19:18 --> URI Class Initialized
INFO - 2022-03-08 03:19:18 --> Router Class Initialized
INFO - 2022-03-08 03:19:18 --> Output Class Initialized
INFO - 2022-03-08 03:19:18 --> Security Class Initialized
DEBUG - 2022-03-08 03:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:19:18 --> Input Class Initialized
INFO - 2022-03-08 03:19:18 --> Language Class Initialized
INFO - 2022-03-08 03:19:18 --> Loader Class Initialized
INFO - 2022-03-08 03:19:18 --> Helper loaded: url_helper
INFO - 2022-03-08 03:19:18 --> Helper loaded: form_helper
INFO - 2022-03-08 03:19:18 --> Helper loaded: common_helper
INFO - 2022-03-08 03:19:18 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:19:18 --> Controller Class Initialized
INFO - 2022-03-08 03:19:18 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:19:18 --> Encrypt Class Initialized
INFO - 2022-03-08 03:19:18 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:19:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:19:18 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:19:18 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:19:18 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:19:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:19:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:19:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:19:18 --> Final output sent to browser
DEBUG - 2022-03-08 03:19:18 --> Total execution time: 0.0601
ERROR - 2022-03-08 03:19:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:19:19 --> Config Class Initialized
INFO - 2022-03-08 03:19:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:19:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:19:19 --> Utf8 Class Initialized
INFO - 2022-03-08 03:19:19 --> URI Class Initialized
INFO - 2022-03-08 03:19:19 --> Router Class Initialized
INFO - 2022-03-08 03:19:19 --> Output Class Initialized
INFO - 2022-03-08 03:19:19 --> Security Class Initialized
DEBUG - 2022-03-08 03:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:19:19 --> Input Class Initialized
INFO - 2022-03-08 03:19:19 --> Language Class Initialized
ERROR - 2022-03-08 03:19:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:19:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:19:19 --> Config Class Initialized
INFO - 2022-03-08 03:19:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:19:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:19:19 --> Utf8 Class Initialized
INFO - 2022-03-08 03:19:19 --> URI Class Initialized
INFO - 2022-03-08 03:19:19 --> Router Class Initialized
INFO - 2022-03-08 03:19:19 --> Output Class Initialized
INFO - 2022-03-08 03:19:19 --> Security Class Initialized
DEBUG - 2022-03-08 03:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:19:19 --> Input Class Initialized
INFO - 2022-03-08 03:19:19 --> Language Class Initialized
INFO - 2022-03-08 03:19:19 --> Loader Class Initialized
INFO - 2022-03-08 03:19:19 --> Helper loaded: url_helper
INFO - 2022-03-08 03:19:19 --> Helper loaded: form_helper
INFO - 2022-03-08 03:19:19 --> Helper loaded: common_helper
INFO - 2022-03-08 03:19:19 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:19:19 --> Controller Class Initialized
INFO - 2022-03-08 03:19:19 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:19:19 --> Encrypt Class Initialized
INFO - 2022-03-08 03:19:19 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:19:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:19:19 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:19:19 --> Model "Users_model" initialized
INFO - 2022-03-08 03:19:19 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:19:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:19:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:19:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:19:19 --> Final output sent to browser
DEBUG - 2022-03-08 03:19:19 --> Total execution time: 0.0537
ERROR - 2022-03-08 03:19:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:19:19 --> Config Class Initialized
INFO - 2022-03-08 03:19:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:19:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:19:19 --> Utf8 Class Initialized
INFO - 2022-03-08 03:19:19 --> URI Class Initialized
INFO - 2022-03-08 03:19:19 --> Router Class Initialized
INFO - 2022-03-08 03:19:19 --> Output Class Initialized
INFO - 2022-03-08 03:19:19 --> Security Class Initialized
DEBUG - 2022-03-08 03:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:19:19 --> Input Class Initialized
INFO - 2022-03-08 03:19:19 --> Language Class Initialized
ERROR - 2022-03-08 03:19:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:19:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:19:20 --> Config Class Initialized
INFO - 2022-03-08 03:19:20 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:19:20 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:19:20 --> Utf8 Class Initialized
INFO - 2022-03-08 03:19:20 --> URI Class Initialized
INFO - 2022-03-08 03:19:20 --> Router Class Initialized
INFO - 2022-03-08 03:19:20 --> Output Class Initialized
INFO - 2022-03-08 03:19:20 --> Security Class Initialized
DEBUG - 2022-03-08 03:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:19:20 --> Input Class Initialized
INFO - 2022-03-08 03:19:20 --> Language Class Initialized
INFO - 2022-03-08 03:19:20 --> Loader Class Initialized
INFO - 2022-03-08 03:19:20 --> Helper loaded: url_helper
INFO - 2022-03-08 03:19:20 --> Helper loaded: form_helper
INFO - 2022-03-08 03:19:20 --> Helper loaded: common_helper
INFO - 2022-03-08 03:19:20 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:19:20 --> Controller Class Initialized
INFO - 2022-03-08 03:19:20 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:19:20 --> Encrypt Class Initialized
INFO - 2022-03-08 03:19:20 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:19:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:19:20 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:19:20 --> Model "Users_model" initialized
INFO - 2022-03-08 03:19:20 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:19:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:19:21 --> Config Class Initialized
INFO - 2022-03-08 03:19:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:19:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:19:21 --> Utf8 Class Initialized
INFO - 2022-03-08 03:19:21 --> URI Class Initialized
INFO - 2022-03-08 03:19:21 --> Router Class Initialized
INFO - 2022-03-08 03:19:21 --> Output Class Initialized
INFO - 2022-03-08 03:19:21 --> Security Class Initialized
DEBUG - 2022-03-08 03:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:19:21 --> Input Class Initialized
INFO - 2022-03-08 03:19:21 --> Language Class Initialized
INFO - 2022-03-08 03:19:21 --> Loader Class Initialized
INFO - 2022-03-08 03:19:21 --> Helper loaded: url_helper
INFO - 2022-03-08 03:19:21 --> Helper loaded: form_helper
INFO - 2022-03-08 03:19:21 --> Helper loaded: common_helper
INFO - 2022-03-08 03:19:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:19:21 --> Controller Class Initialized
INFO - 2022-03-08 03:19:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:19:21 --> Encrypt Class Initialized
INFO - 2022-03-08 03:19:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:19:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:19:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:19:21 --> Model "Users_model" initialized
INFO - 2022-03-08 03:19:21 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:19:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:19:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:19:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:19:21 --> Final output sent to browser
DEBUG - 2022-03-08 03:19:21 --> Total execution time: 0.0745
ERROR - 2022-03-08 03:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:19:54 --> Config Class Initialized
INFO - 2022-03-08 03:19:54 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:19:54 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:19:54 --> Utf8 Class Initialized
INFO - 2022-03-08 03:19:54 --> URI Class Initialized
INFO - 2022-03-08 03:19:54 --> Router Class Initialized
INFO - 2022-03-08 03:19:54 --> Output Class Initialized
INFO - 2022-03-08 03:19:54 --> Security Class Initialized
DEBUG - 2022-03-08 03:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:19:54 --> Input Class Initialized
INFO - 2022-03-08 03:19:54 --> Language Class Initialized
INFO - 2022-03-08 03:19:54 --> Loader Class Initialized
INFO - 2022-03-08 03:19:54 --> Helper loaded: url_helper
INFO - 2022-03-08 03:19:54 --> Helper loaded: form_helper
INFO - 2022-03-08 03:19:54 --> Helper loaded: common_helper
INFO - 2022-03-08 03:19:54 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:19:54 --> Controller Class Initialized
INFO - 2022-03-08 03:19:54 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:19:54 --> Encrypt Class Initialized
INFO - 2022-03-08 03:19:54 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:19:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:19:54 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:19:54 --> Model "Users_model" initialized
INFO - 2022-03-08 03:19:54 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:19:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:19:55 --> Config Class Initialized
INFO - 2022-03-08 03:19:55 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:19:55 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:19:55 --> Utf8 Class Initialized
INFO - 2022-03-08 03:19:55 --> URI Class Initialized
INFO - 2022-03-08 03:19:55 --> Router Class Initialized
INFO - 2022-03-08 03:19:55 --> Output Class Initialized
INFO - 2022-03-08 03:19:55 --> Security Class Initialized
DEBUG - 2022-03-08 03:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:19:55 --> Input Class Initialized
INFO - 2022-03-08 03:19:55 --> Language Class Initialized
INFO - 2022-03-08 03:19:55 --> Loader Class Initialized
INFO - 2022-03-08 03:19:55 --> Helper loaded: url_helper
INFO - 2022-03-08 03:19:55 --> Helper loaded: form_helper
INFO - 2022-03-08 03:19:55 --> Helper loaded: common_helper
INFO - 2022-03-08 03:19:55 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:19:55 --> Controller Class Initialized
INFO - 2022-03-08 03:19:55 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:19:55 --> Encrypt Class Initialized
INFO - 2022-03-08 03:19:55 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:19:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:19:55 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:19:55 --> Model "Users_model" initialized
INFO - 2022-03-08 03:19:55 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:19:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:19:55 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:19:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:19:55 --> Final output sent to browser
DEBUG - 2022-03-08 03:19:55 --> Total execution time: 0.0563
ERROR - 2022-03-08 03:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:20:13 --> Config Class Initialized
INFO - 2022-03-08 03:20:13 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:20:13 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:20:13 --> Utf8 Class Initialized
INFO - 2022-03-08 03:20:13 --> URI Class Initialized
INFO - 2022-03-08 03:20:13 --> Router Class Initialized
INFO - 2022-03-08 03:20:13 --> Output Class Initialized
INFO - 2022-03-08 03:20:13 --> Security Class Initialized
DEBUG - 2022-03-08 03:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:20:13 --> Input Class Initialized
INFO - 2022-03-08 03:20:13 --> Language Class Initialized
INFO - 2022-03-08 03:20:13 --> Loader Class Initialized
INFO - 2022-03-08 03:20:13 --> Helper loaded: url_helper
INFO - 2022-03-08 03:20:13 --> Helper loaded: form_helper
INFO - 2022-03-08 03:20:13 --> Helper loaded: common_helper
INFO - 2022-03-08 03:20:13 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:20:13 --> Controller Class Initialized
INFO - 2022-03-08 03:20:13 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:20:13 --> Encrypt Class Initialized
INFO - 2022-03-08 03:20:13 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:20:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:20:13 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:20:13 --> Model "Users_model" initialized
INFO - 2022-03-08 03:20:13 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:20:13 --> Config Class Initialized
INFO - 2022-03-08 03:20:13 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:20:13 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:20:13 --> Utf8 Class Initialized
INFO - 2022-03-08 03:20:13 --> URI Class Initialized
INFO - 2022-03-08 03:20:13 --> Router Class Initialized
INFO - 2022-03-08 03:20:13 --> Output Class Initialized
INFO - 2022-03-08 03:20:13 --> Security Class Initialized
DEBUG - 2022-03-08 03:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:20:13 --> Input Class Initialized
INFO - 2022-03-08 03:20:13 --> Language Class Initialized
INFO - 2022-03-08 03:20:13 --> Loader Class Initialized
INFO - 2022-03-08 03:20:13 --> Helper loaded: url_helper
INFO - 2022-03-08 03:20:13 --> Helper loaded: form_helper
INFO - 2022-03-08 03:20:13 --> Helper loaded: common_helper
INFO - 2022-03-08 03:20:13 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:20:13 --> Controller Class Initialized
INFO - 2022-03-08 03:20:13 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:20:13 --> Encrypt Class Initialized
INFO - 2022-03-08 03:20:13 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:20:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:20:13 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:20:13 --> Model "Users_model" initialized
INFO - 2022-03-08 03:20:13 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:20:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:20:13 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:20:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:20:13 --> Final output sent to browser
DEBUG - 2022-03-08 03:20:13 --> Total execution time: 0.0527
ERROR - 2022-03-08 03:21:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:21:38 --> Config Class Initialized
INFO - 2022-03-08 03:21:38 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:21:38 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:21:38 --> Utf8 Class Initialized
INFO - 2022-03-08 03:21:38 --> URI Class Initialized
INFO - 2022-03-08 03:21:38 --> Router Class Initialized
INFO - 2022-03-08 03:21:38 --> Output Class Initialized
INFO - 2022-03-08 03:21:38 --> Security Class Initialized
DEBUG - 2022-03-08 03:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:21:38 --> Input Class Initialized
INFO - 2022-03-08 03:21:38 --> Language Class Initialized
INFO - 2022-03-08 03:21:38 --> Loader Class Initialized
INFO - 2022-03-08 03:21:38 --> Helper loaded: url_helper
INFO - 2022-03-08 03:21:38 --> Helper loaded: form_helper
INFO - 2022-03-08 03:21:38 --> Helper loaded: common_helper
INFO - 2022-03-08 03:21:38 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:21:38 --> Controller Class Initialized
INFO - 2022-03-08 03:21:38 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:21:38 --> Encrypt Class Initialized
INFO - 2022-03-08 03:21:38 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:21:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:21:38 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:21:38 --> Model "Users_model" initialized
INFO - 2022-03-08 03:21:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:21:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:21:39 --> Config Class Initialized
INFO - 2022-03-08 03:21:39 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:21:39 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:21:39 --> Utf8 Class Initialized
INFO - 2022-03-08 03:21:39 --> URI Class Initialized
INFO - 2022-03-08 03:21:39 --> Router Class Initialized
INFO - 2022-03-08 03:21:39 --> Output Class Initialized
INFO - 2022-03-08 03:21:39 --> Security Class Initialized
DEBUG - 2022-03-08 03:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:21:39 --> Input Class Initialized
INFO - 2022-03-08 03:21:39 --> Language Class Initialized
INFO - 2022-03-08 03:21:39 --> Loader Class Initialized
INFO - 2022-03-08 03:21:39 --> Helper loaded: url_helper
INFO - 2022-03-08 03:21:39 --> Helper loaded: form_helper
INFO - 2022-03-08 03:21:39 --> Helper loaded: common_helper
INFO - 2022-03-08 03:21:39 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:21:39 --> Controller Class Initialized
INFO - 2022-03-08 03:21:39 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:21:39 --> Encrypt Class Initialized
INFO - 2022-03-08 03:21:39 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:21:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:21:39 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:21:39 --> Model "Users_model" initialized
INFO - 2022-03-08 03:21:39 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:21:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:21:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:21:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:21:39 --> Final output sent to browser
DEBUG - 2022-03-08 03:21:39 --> Total execution time: 0.0562
ERROR - 2022-03-08 03:23:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:23:17 --> Config Class Initialized
INFO - 2022-03-08 03:23:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:23:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:23:17 --> Utf8 Class Initialized
INFO - 2022-03-08 03:23:17 --> URI Class Initialized
INFO - 2022-03-08 03:23:17 --> Router Class Initialized
INFO - 2022-03-08 03:23:17 --> Output Class Initialized
INFO - 2022-03-08 03:23:17 --> Security Class Initialized
DEBUG - 2022-03-08 03:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:23:17 --> Input Class Initialized
INFO - 2022-03-08 03:23:17 --> Language Class Initialized
INFO - 2022-03-08 03:23:17 --> Loader Class Initialized
INFO - 2022-03-08 03:23:17 --> Helper loaded: url_helper
INFO - 2022-03-08 03:23:17 --> Helper loaded: form_helper
INFO - 2022-03-08 03:23:17 --> Helper loaded: common_helper
INFO - 2022-03-08 03:23:17 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:23:17 --> Controller Class Initialized
INFO - 2022-03-08 03:23:17 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:23:17 --> Encrypt Class Initialized
INFO - 2022-03-08 03:23:17 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:23:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:23:17 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:23:17 --> Model "Users_model" initialized
INFO - 2022-03-08 03:23:17 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:23:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:23:17 --> Config Class Initialized
INFO - 2022-03-08 03:23:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:23:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:23:17 --> Utf8 Class Initialized
INFO - 2022-03-08 03:23:17 --> URI Class Initialized
INFO - 2022-03-08 03:23:17 --> Router Class Initialized
INFO - 2022-03-08 03:23:17 --> Output Class Initialized
INFO - 2022-03-08 03:23:17 --> Security Class Initialized
DEBUG - 2022-03-08 03:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:23:17 --> Input Class Initialized
INFO - 2022-03-08 03:23:17 --> Language Class Initialized
INFO - 2022-03-08 03:23:17 --> Loader Class Initialized
INFO - 2022-03-08 03:23:17 --> Helper loaded: url_helper
INFO - 2022-03-08 03:23:17 --> Helper loaded: form_helper
INFO - 2022-03-08 03:23:17 --> Helper loaded: common_helper
INFO - 2022-03-08 03:23:17 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:23:17 --> Controller Class Initialized
INFO - 2022-03-08 03:23:17 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:23:17 --> Encrypt Class Initialized
INFO - 2022-03-08 03:23:17 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:23:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:23:17 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:23:17 --> Model "Users_model" initialized
INFO - 2022-03-08 03:23:17 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:23:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:23:17 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:23:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:23:17 --> Final output sent to browser
DEBUG - 2022-03-08 03:23:17 --> Total execution time: 0.0605
ERROR - 2022-03-08 03:23:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:23:19 --> Config Class Initialized
INFO - 2022-03-08 03:23:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:23:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:23:19 --> Utf8 Class Initialized
INFO - 2022-03-08 03:23:19 --> URI Class Initialized
INFO - 2022-03-08 03:23:19 --> Router Class Initialized
INFO - 2022-03-08 03:23:19 --> Output Class Initialized
INFO - 2022-03-08 03:23:19 --> Security Class Initialized
DEBUG - 2022-03-08 03:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:23:19 --> Input Class Initialized
INFO - 2022-03-08 03:23:19 --> Language Class Initialized
ERROR - 2022-03-08 03:23:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:24:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:24:16 --> Config Class Initialized
INFO - 2022-03-08 03:24:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:24:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:24:16 --> Utf8 Class Initialized
INFO - 2022-03-08 03:24:16 --> URI Class Initialized
INFO - 2022-03-08 03:24:16 --> Router Class Initialized
INFO - 2022-03-08 03:24:16 --> Output Class Initialized
INFO - 2022-03-08 03:24:16 --> Security Class Initialized
DEBUG - 2022-03-08 03:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:24:16 --> Input Class Initialized
INFO - 2022-03-08 03:24:16 --> Language Class Initialized
INFO - 2022-03-08 03:24:16 --> Loader Class Initialized
INFO - 2022-03-08 03:24:16 --> Helper loaded: url_helper
INFO - 2022-03-08 03:24:16 --> Helper loaded: form_helper
INFO - 2022-03-08 03:24:16 --> Helper loaded: common_helper
INFO - 2022-03-08 03:24:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:24:16 --> Controller Class Initialized
INFO - 2022-03-08 03:24:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:24:16 --> Encrypt Class Initialized
INFO - 2022-03-08 03:24:16 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:24:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:24:16 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:24:16 --> Model "Users_model" initialized
INFO - 2022-03-08 03:24:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:24:17 --> Config Class Initialized
INFO - 2022-03-08 03:24:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:24:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:24:17 --> Utf8 Class Initialized
INFO - 2022-03-08 03:24:17 --> URI Class Initialized
INFO - 2022-03-08 03:24:17 --> Router Class Initialized
INFO - 2022-03-08 03:24:17 --> Output Class Initialized
INFO - 2022-03-08 03:24:17 --> Security Class Initialized
DEBUG - 2022-03-08 03:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:24:18 --> Input Class Initialized
INFO - 2022-03-08 03:24:18 --> Language Class Initialized
INFO - 2022-03-08 03:24:18 --> Loader Class Initialized
INFO - 2022-03-08 03:24:18 --> Helper loaded: url_helper
INFO - 2022-03-08 03:24:18 --> Helper loaded: form_helper
INFO - 2022-03-08 03:24:18 --> Helper loaded: common_helper
INFO - 2022-03-08 03:24:18 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:24:18 --> Controller Class Initialized
INFO - 2022-03-08 03:24:18 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:24:18 --> Encrypt Class Initialized
INFO - 2022-03-08 03:24:18 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:24:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:24:18 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:24:18 --> Model "Users_model" initialized
INFO - 2022-03-08 03:24:18 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:24:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:24:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:24:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:24:18 --> Final output sent to browser
DEBUG - 2022-03-08 03:24:18 --> Total execution time: 0.0581
ERROR - 2022-03-08 03:24:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:24:40 --> Config Class Initialized
INFO - 2022-03-08 03:24:40 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:24:40 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:24:40 --> Utf8 Class Initialized
INFO - 2022-03-08 03:24:40 --> URI Class Initialized
INFO - 2022-03-08 03:24:40 --> Router Class Initialized
INFO - 2022-03-08 03:24:40 --> Output Class Initialized
INFO - 2022-03-08 03:24:40 --> Security Class Initialized
DEBUG - 2022-03-08 03:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:24:40 --> Input Class Initialized
INFO - 2022-03-08 03:24:40 --> Language Class Initialized
INFO - 2022-03-08 03:24:40 --> Loader Class Initialized
INFO - 2022-03-08 03:24:40 --> Helper loaded: url_helper
INFO - 2022-03-08 03:24:40 --> Helper loaded: form_helper
INFO - 2022-03-08 03:24:40 --> Helper loaded: common_helper
INFO - 2022-03-08 03:24:40 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:24:40 --> Controller Class Initialized
INFO - 2022-03-08 03:24:40 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:24:40 --> Encrypt Class Initialized
INFO - 2022-03-08 03:24:40 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:24:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:24:40 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:24:40 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:24:40 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:24:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:24:40 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 03:24:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:24:40 --> Final output sent to browser
DEBUG - 2022-03-08 03:24:40 --> Total execution time: 0.0818
ERROR - 2022-03-08 03:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:24:59 --> Config Class Initialized
INFO - 2022-03-08 03:24:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:24:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:24:59 --> Utf8 Class Initialized
INFO - 2022-03-08 03:24:59 --> URI Class Initialized
INFO - 2022-03-08 03:24:59 --> Router Class Initialized
INFO - 2022-03-08 03:24:59 --> Output Class Initialized
INFO - 2022-03-08 03:24:59 --> Security Class Initialized
DEBUG - 2022-03-08 03:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:24:59 --> Input Class Initialized
INFO - 2022-03-08 03:24:59 --> Language Class Initialized
INFO - 2022-03-08 03:24:59 --> Loader Class Initialized
INFO - 2022-03-08 03:24:59 --> Helper loaded: url_helper
INFO - 2022-03-08 03:24:59 --> Helper loaded: form_helper
INFO - 2022-03-08 03:24:59 --> Helper loaded: common_helper
INFO - 2022-03-08 03:24:59 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:24:59 --> Controller Class Initialized
INFO - 2022-03-08 03:24:59 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:24:59 --> Encrypt Class Initialized
INFO - 2022-03-08 03:24:59 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:24:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:24:59 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:24:59 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:24:59 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:24:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:24:59 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:24:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:24:59 --> Final output sent to browser
DEBUG - 2022-03-08 03:24:59 --> Total execution time: 0.0447
ERROR - 2022-03-08 03:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:25:10 --> Config Class Initialized
INFO - 2022-03-08 03:25:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:25:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:25:10 --> Utf8 Class Initialized
INFO - 2022-03-08 03:25:10 --> URI Class Initialized
INFO - 2022-03-08 03:25:10 --> Router Class Initialized
INFO - 2022-03-08 03:25:10 --> Output Class Initialized
INFO - 2022-03-08 03:25:10 --> Security Class Initialized
DEBUG - 2022-03-08 03:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:25:10 --> Input Class Initialized
INFO - 2022-03-08 03:25:10 --> Language Class Initialized
INFO - 2022-03-08 03:25:10 --> Loader Class Initialized
INFO - 2022-03-08 03:25:10 --> Helper loaded: url_helper
INFO - 2022-03-08 03:25:10 --> Helper loaded: form_helper
INFO - 2022-03-08 03:25:10 --> Helper loaded: common_helper
INFO - 2022-03-08 03:25:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:25:10 --> Controller Class Initialized
INFO - 2022-03-08 03:25:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:25:10 --> Encrypt Class Initialized
INFO - 2022-03-08 03:25:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:25:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:25:10 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:25:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:25:10 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 03:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:25:10 --> Config Class Initialized
INFO - 2022-03-08 03:25:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:25:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:25:10 --> Utf8 Class Initialized
INFO - 2022-03-08 03:25:10 --> URI Class Initialized
INFO - 2022-03-08 03:25:10 --> Router Class Initialized
INFO - 2022-03-08 03:25:10 --> Output Class Initialized
INFO - 2022-03-08 03:25:10 --> Security Class Initialized
DEBUG - 2022-03-08 03:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:25:10 --> Input Class Initialized
INFO - 2022-03-08 03:25:10 --> Language Class Initialized
INFO - 2022-03-08 03:25:10 --> Loader Class Initialized
INFO - 2022-03-08 03:25:10 --> Helper loaded: url_helper
INFO - 2022-03-08 03:25:10 --> Helper loaded: form_helper
INFO - 2022-03-08 03:25:10 --> Helper loaded: common_helper
INFO - 2022-03-08 03:25:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:25:10 --> Controller Class Initialized
INFO - 2022-03-08 03:25:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:25:10 --> Encrypt Class Initialized
INFO - 2022-03-08 03:25:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:25:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:25:10 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:25:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:25:10 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:25:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:25:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:25:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:25:10 --> Final output sent to browser
DEBUG - 2022-03-08 03:25:10 --> Total execution time: 0.0566
ERROR - 2022-03-08 03:25:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:25:11 --> Config Class Initialized
INFO - 2022-03-08 03:25:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:25:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:25:11 --> Utf8 Class Initialized
INFO - 2022-03-08 03:25:11 --> URI Class Initialized
INFO - 2022-03-08 03:25:11 --> Router Class Initialized
INFO - 2022-03-08 03:25:11 --> Output Class Initialized
INFO - 2022-03-08 03:25:11 --> Security Class Initialized
DEBUG - 2022-03-08 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:25:11 --> Input Class Initialized
INFO - 2022-03-08 03:25:11 --> Language Class Initialized
INFO - 2022-03-08 03:25:11 --> Loader Class Initialized
INFO - 2022-03-08 03:25:11 --> Helper loaded: url_helper
INFO - 2022-03-08 03:25:11 --> Helper loaded: form_helper
INFO - 2022-03-08 03:25:11 --> Helper loaded: common_helper
INFO - 2022-03-08 03:25:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:25:11 --> Controller Class Initialized
INFO - 2022-03-08 03:25:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:25:11 --> Encrypt Class Initialized
INFO - 2022-03-08 03:25:11 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:25:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:25:11 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:25:11 --> Model "Users_model" initialized
INFO - 2022-03-08 03:25:11 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:25:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:25:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 03:25:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:25:12 --> Final output sent to browser
DEBUG - 2022-03-08 03:25:12 --> Total execution time: 0.0728
ERROR - 2022-03-08 03:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:25:22 --> Config Class Initialized
INFO - 2022-03-08 03:25:22 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:25:22 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:25:22 --> Utf8 Class Initialized
INFO - 2022-03-08 03:25:22 --> URI Class Initialized
INFO - 2022-03-08 03:25:22 --> Router Class Initialized
INFO - 2022-03-08 03:25:22 --> Output Class Initialized
INFO - 2022-03-08 03:25:22 --> Security Class Initialized
DEBUG - 2022-03-08 03:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:25:22 --> Input Class Initialized
INFO - 2022-03-08 03:25:22 --> Language Class Initialized
INFO - 2022-03-08 03:25:22 --> Loader Class Initialized
INFO - 2022-03-08 03:25:22 --> Helper loaded: url_helper
INFO - 2022-03-08 03:25:22 --> Helper loaded: form_helper
INFO - 2022-03-08 03:25:22 --> Helper loaded: common_helper
INFO - 2022-03-08 03:25:22 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:25:22 --> Controller Class Initialized
INFO - 2022-03-08 03:25:22 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:25:22 --> Encrypt Class Initialized
INFO - 2022-03-08 03:25:22 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:25:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:25:22 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:25:22 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:25:22 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:25:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:25:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patient_by_category.php
INFO - 2022-03-08 03:25:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:25:22 --> Final output sent to browser
DEBUG - 2022-03-08 03:25:22 --> Total execution time: 0.0532
ERROR - 2022-03-08 03:25:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:25:26 --> Config Class Initialized
INFO - 2022-03-08 03:25:26 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:25:26 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:25:26 --> Utf8 Class Initialized
INFO - 2022-03-08 03:25:26 --> URI Class Initialized
INFO - 2022-03-08 03:25:26 --> Router Class Initialized
INFO - 2022-03-08 03:25:26 --> Output Class Initialized
INFO - 2022-03-08 03:25:26 --> Security Class Initialized
DEBUG - 2022-03-08 03:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:25:26 --> Input Class Initialized
INFO - 2022-03-08 03:25:26 --> Language Class Initialized
INFO - 2022-03-08 03:25:26 --> Loader Class Initialized
INFO - 2022-03-08 03:25:26 --> Helper loaded: url_helper
INFO - 2022-03-08 03:25:26 --> Helper loaded: form_helper
INFO - 2022-03-08 03:25:26 --> Helper loaded: common_helper
INFO - 2022-03-08 03:25:26 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:25:26 --> Controller Class Initialized
INFO - 2022-03-08 03:25:26 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:25:26 --> Encrypt Class Initialized
INFO - 2022-03-08 03:25:26 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:25:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:25:26 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:25:26 --> Model "Users_model" initialized
INFO - 2022-03-08 03:25:26 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:25:26 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-08 03:25:27 --> Final output sent to browser
DEBUG - 2022-03-08 03:25:27 --> Total execution time: 0.8555
ERROR - 2022-03-08 03:25:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:25:47 --> Config Class Initialized
INFO - 2022-03-08 03:25:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:25:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:25:47 --> Utf8 Class Initialized
INFO - 2022-03-08 03:25:47 --> URI Class Initialized
INFO - 2022-03-08 03:25:47 --> Router Class Initialized
INFO - 2022-03-08 03:25:47 --> Output Class Initialized
INFO - 2022-03-08 03:25:47 --> Security Class Initialized
DEBUG - 2022-03-08 03:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:25:47 --> Input Class Initialized
INFO - 2022-03-08 03:25:47 --> Language Class Initialized
INFO - 2022-03-08 03:25:47 --> Loader Class Initialized
INFO - 2022-03-08 03:25:47 --> Helper loaded: url_helper
INFO - 2022-03-08 03:25:47 --> Helper loaded: form_helper
INFO - 2022-03-08 03:25:47 --> Helper loaded: common_helper
INFO - 2022-03-08 03:25:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:25:47 --> Controller Class Initialized
INFO - 2022-03-08 03:25:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:25:47 --> Encrypt Class Initialized
INFO - 2022-03-08 03:25:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:25:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:25:47 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:25:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:25:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:25:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:25:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 03:25:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 03:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:25:56 --> Config Class Initialized
INFO - 2022-03-08 03:25:56 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:25:56 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:25:56 --> Utf8 Class Initialized
INFO - 2022-03-08 03:25:56 --> URI Class Initialized
INFO - 2022-03-08 03:25:56 --> Router Class Initialized
INFO - 2022-03-08 03:25:56 --> Output Class Initialized
INFO - 2022-03-08 03:25:56 --> Security Class Initialized
DEBUG - 2022-03-08 03:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:25:56 --> Input Class Initialized
INFO - 2022-03-08 03:25:56 --> Language Class Initialized
ERROR - 2022-03-08 03:25:56 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 03:26:09 --> Final output sent to browser
DEBUG - 2022-03-08 03:26:09 --> Total execution time: 6.7463
ERROR - 2022-03-08 03:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:26:46 --> Config Class Initialized
INFO - 2022-03-08 03:26:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:26:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:26:46 --> Utf8 Class Initialized
INFO - 2022-03-08 03:26:46 --> URI Class Initialized
INFO - 2022-03-08 03:26:46 --> Router Class Initialized
INFO - 2022-03-08 03:26:46 --> Output Class Initialized
INFO - 2022-03-08 03:26:46 --> Security Class Initialized
DEBUG - 2022-03-08 03:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:26:46 --> Input Class Initialized
INFO - 2022-03-08 03:26:46 --> Language Class Initialized
INFO - 2022-03-08 03:26:46 --> Loader Class Initialized
INFO - 2022-03-08 03:26:46 --> Helper loaded: url_helper
INFO - 2022-03-08 03:26:46 --> Helper loaded: form_helper
INFO - 2022-03-08 03:26:46 --> Helper loaded: common_helper
INFO - 2022-03-08 03:26:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:26:46 --> Controller Class Initialized
INFO - 2022-03-08 03:26:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:26:46 --> Encrypt Class Initialized
INFO - 2022-03-08 03:26:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 03:26:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 03:26:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 03:26:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 03:26:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 03:26:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 03:26:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 03:26:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 03:26:46 --> Final output sent to browser
DEBUG - 2022-03-08 03:26:46 --> Total execution time: 0.0532
ERROR - 2022-03-08 03:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:26:46 --> Config Class Initialized
INFO - 2022-03-08 03:26:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:26:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:26:46 --> Utf8 Class Initialized
INFO - 2022-03-08 03:26:46 --> URI Class Initialized
INFO - 2022-03-08 03:26:46 --> Router Class Initialized
INFO - 2022-03-08 03:26:46 --> Output Class Initialized
INFO - 2022-03-08 03:26:46 --> Security Class Initialized
DEBUG - 2022-03-08 03:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:26:46 --> Input Class Initialized
INFO - 2022-03-08 03:26:46 --> Language Class Initialized
ERROR - 2022-03-08 03:26:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 03:30:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:30:26 --> Config Class Initialized
INFO - 2022-03-08 03:30:26 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:30:26 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:30:26 --> Utf8 Class Initialized
INFO - 2022-03-08 03:30:26 --> URI Class Initialized
INFO - 2022-03-08 03:30:26 --> Router Class Initialized
INFO - 2022-03-08 03:30:26 --> Output Class Initialized
INFO - 2022-03-08 03:30:26 --> Security Class Initialized
DEBUG - 2022-03-08 03:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:30:26 --> Input Class Initialized
INFO - 2022-03-08 03:30:26 --> Language Class Initialized
INFO - 2022-03-08 03:30:26 --> Loader Class Initialized
INFO - 2022-03-08 03:30:26 --> Helper loaded: url_helper
INFO - 2022-03-08 03:30:26 --> Helper loaded: form_helper
INFO - 2022-03-08 03:30:26 --> Helper loaded: common_helper
INFO - 2022-03-08 03:30:26 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:30:26 --> Controller Class Initialized
INFO - 2022-03-08 03:30:26 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:30:26 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:30:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:30:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:30:26 --> Email Class Initialized
INFO - 2022-03-08 03:30:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:30:26 --> Calendar Class Initialized
INFO - 2022-03-08 03:30:26 --> Model "Login_model" initialized
ERROR - 2022-03-08 03:30:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:30:27 --> Config Class Initialized
INFO - 2022-03-08 03:30:27 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:30:27 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:30:27 --> Utf8 Class Initialized
INFO - 2022-03-08 03:30:27 --> URI Class Initialized
INFO - 2022-03-08 03:30:27 --> Router Class Initialized
INFO - 2022-03-08 03:30:27 --> Output Class Initialized
INFO - 2022-03-08 03:30:27 --> Security Class Initialized
DEBUG - 2022-03-08 03:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:30:27 --> Input Class Initialized
INFO - 2022-03-08 03:30:27 --> Language Class Initialized
INFO - 2022-03-08 03:30:27 --> Loader Class Initialized
INFO - 2022-03-08 03:30:27 --> Helper loaded: url_helper
INFO - 2022-03-08 03:30:27 --> Helper loaded: form_helper
INFO - 2022-03-08 03:30:27 --> Helper loaded: common_helper
INFO - 2022-03-08 03:30:27 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:30:27 --> Controller Class Initialized
INFO - 2022-03-08 03:30:27 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:30:27 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:30:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:30:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:30:27 --> Email Class Initialized
INFO - 2022-03-08 03:30:27 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:30:27 --> Calendar Class Initialized
INFO - 2022-03-08 03:30:27 --> Model "Login_model" initialized
INFO - 2022-03-08 03:30:27 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 03:30:27 --> Final output sent to browser
DEBUG - 2022-03-08 03:30:27 --> Total execution time: 0.0203
ERROR - 2022-03-08 03:30:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:30:29 --> Config Class Initialized
INFO - 2022-03-08 03:30:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:30:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:30:29 --> Utf8 Class Initialized
INFO - 2022-03-08 03:30:29 --> URI Class Initialized
INFO - 2022-03-08 03:30:29 --> Router Class Initialized
INFO - 2022-03-08 03:30:29 --> Output Class Initialized
INFO - 2022-03-08 03:30:29 --> Security Class Initialized
DEBUG - 2022-03-08 03:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:30:29 --> Input Class Initialized
INFO - 2022-03-08 03:30:29 --> Language Class Initialized
INFO - 2022-03-08 03:30:29 --> Loader Class Initialized
INFO - 2022-03-08 03:30:29 --> Helper loaded: url_helper
INFO - 2022-03-08 03:30:29 --> Helper loaded: form_helper
INFO - 2022-03-08 03:30:29 --> Helper loaded: common_helper
INFO - 2022-03-08 03:30:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:30:29 --> Controller Class Initialized
INFO - 2022-03-08 03:30:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:30:29 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:30:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:30:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:30:29 --> Email Class Initialized
INFO - 2022-03-08 03:30:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:30:29 --> Calendar Class Initialized
INFO - 2022-03-08 03:30:29 --> Model "Login_model" initialized
ERROR - 2022-03-08 03:30:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 03:30:29 --> Config Class Initialized
INFO - 2022-03-08 03:30:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 03:30:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 03:30:29 --> Utf8 Class Initialized
INFO - 2022-03-08 03:30:29 --> URI Class Initialized
INFO - 2022-03-08 03:30:29 --> Router Class Initialized
INFO - 2022-03-08 03:30:29 --> Output Class Initialized
INFO - 2022-03-08 03:30:29 --> Security Class Initialized
DEBUG - 2022-03-08 03:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 03:30:29 --> Input Class Initialized
INFO - 2022-03-08 03:30:29 --> Language Class Initialized
INFO - 2022-03-08 03:30:29 --> Loader Class Initialized
INFO - 2022-03-08 03:30:29 --> Helper loaded: url_helper
INFO - 2022-03-08 03:30:29 --> Helper loaded: form_helper
INFO - 2022-03-08 03:30:29 --> Helper loaded: common_helper
INFO - 2022-03-08 03:30:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 03:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 03:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 03:30:29 --> Controller Class Initialized
INFO - 2022-03-08 03:30:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 03:30:29 --> Encrypt Class Initialized
DEBUG - 2022-03-08 03:30:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 03:30:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 03:30:29 --> Email Class Initialized
INFO - 2022-03-08 03:30:29 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 03:30:29 --> Calendar Class Initialized
INFO - 2022-03-08 03:30:29 --> Model "Login_model" initialized
INFO - 2022-03-08 03:30:29 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 03:30:29 --> Final output sent to browser
DEBUG - 2022-03-08 03:30:29 --> Total execution time: 0.0331
ERROR - 2022-03-08 04:10:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:10:33 --> Config Class Initialized
INFO - 2022-03-08 04:10:33 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:10:33 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:10:33 --> Utf8 Class Initialized
INFO - 2022-03-08 04:10:33 --> URI Class Initialized
DEBUG - 2022-03-08 04:10:33 --> No URI present. Default controller set.
INFO - 2022-03-08 04:10:33 --> Router Class Initialized
INFO - 2022-03-08 04:10:33 --> Output Class Initialized
INFO - 2022-03-08 04:10:33 --> Security Class Initialized
DEBUG - 2022-03-08 04:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:10:33 --> Input Class Initialized
INFO - 2022-03-08 04:10:33 --> Language Class Initialized
INFO - 2022-03-08 04:10:33 --> Loader Class Initialized
INFO - 2022-03-08 04:10:33 --> Helper loaded: url_helper
INFO - 2022-03-08 04:10:33 --> Helper loaded: form_helper
INFO - 2022-03-08 04:10:33 --> Helper loaded: common_helper
INFO - 2022-03-08 04:10:33 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:10:33 --> Controller Class Initialized
INFO - 2022-03-08 04:10:33 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:10:33 --> Encrypt Class Initialized
DEBUG - 2022-03-08 04:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 04:10:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 04:10:33 --> Email Class Initialized
INFO - 2022-03-08 04:10:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 04:10:33 --> Calendar Class Initialized
INFO - 2022-03-08 04:10:33 --> Model "Login_model" initialized
ERROR - 2022-03-08 04:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:10:34 --> Config Class Initialized
INFO - 2022-03-08 04:10:34 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:10:34 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:10:34 --> Utf8 Class Initialized
INFO - 2022-03-08 04:10:34 --> URI Class Initialized
INFO - 2022-03-08 04:10:34 --> Router Class Initialized
INFO - 2022-03-08 04:10:34 --> Output Class Initialized
INFO - 2022-03-08 04:10:34 --> Security Class Initialized
DEBUG - 2022-03-08 04:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:10:34 --> Input Class Initialized
INFO - 2022-03-08 04:10:34 --> Language Class Initialized
INFO - 2022-03-08 04:10:34 --> Loader Class Initialized
INFO - 2022-03-08 04:10:34 --> Helper loaded: url_helper
INFO - 2022-03-08 04:10:34 --> Helper loaded: form_helper
INFO - 2022-03-08 04:10:34 --> Helper loaded: common_helper
INFO - 2022-03-08 04:10:34 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:10:34 --> Controller Class Initialized
INFO - 2022-03-08 04:10:34 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:10:34 --> Encrypt Class Initialized
INFO - 2022-03-08 04:10:34 --> Model "Diseases_model" initialized
INFO - 2022-03-08 04:10:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:10:34 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-08 04:10:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:10:34 --> Final output sent to browser
DEBUG - 2022-03-08 04:10:34 --> Total execution time: 0.1234
ERROR - 2022-03-08 04:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:10:52 --> Config Class Initialized
INFO - 2022-03-08 04:10:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:10:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:10:52 --> Utf8 Class Initialized
INFO - 2022-03-08 04:10:52 --> URI Class Initialized
INFO - 2022-03-08 04:10:52 --> Router Class Initialized
INFO - 2022-03-08 04:10:52 --> Output Class Initialized
INFO - 2022-03-08 04:10:52 --> Security Class Initialized
DEBUG - 2022-03-08 04:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:10:52 --> Input Class Initialized
INFO - 2022-03-08 04:10:52 --> Language Class Initialized
INFO - 2022-03-08 04:10:52 --> Loader Class Initialized
INFO - 2022-03-08 04:10:52 --> Helper loaded: url_helper
INFO - 2022-03-08 04:10:52 --> Helper loaded: form_helper
INFO - 2022-03-08 04:10:52 --> Helper loaded: common_helper
INFO - 2022-03-08 04:10:52 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:10:52 --> Controller Class Initialized
INFO - 2022-03-08 04:10:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:10:52 --> Encrypt Class Initialized
INFO - 2022-03-08 04:10:52 --> Model "Patient_model" initialized
INFO - 2022-03-08 04:10:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 04:10:52 --> Model "Referredby_model" initialized
INFO - 2022-03-08 04:10:52 --> Model "Prefix_master" initialized
INFO - 2022-03-08 04:10:52 --> Model "Hospital_model" initialized
INFO - 2022-03-08 04:10:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:10:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 04:10:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:10:52 --> Final output sent to browser
DEBUG - 2022-03-08 04:10:52 --> Total execution time: 0.0875
ERROR - 2022-03-08 04:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:11:11 --> Config Class Initialized
INFO - 2022-03-08 04:11:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:11:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:11:11 --> Utf8 Class Initialized
INFO - 2022-03-08 04:11:11 --> URI Class Initialized
INFO - 2022-03-08 04:11:11 --> Router Class Initialized
INFO - 2022-03-08 04:11:11 --> Output Class Initialized
INFO - 2022-03-08 04:11:11 --> Security Class Initialized
DEBUG - 2022-03-08 04:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:11:11 --> Input Class Initialized
INFO - 2022-03-08 04:11:11 --> Language Class Initialized
INFO - 2022-03-08 04:11:11 --> Loader Class Initialized
INFO - 2022-03-08 04:11:11 --> Helper loaded: url_helper
INFO - 2022-03-08 04:11:11 --> Helper loaded: form_helper
INFO - 2022-03-08 04:11:11 --> Helper loaded: common_helper
INFO - 2022-03-08 04:11:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:11:11 --> Controller Class Initialized
INFO - 2022-03-08 04:11:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:11:11 --> Encrypt Class Initialized
INFO - 2022-03-08 04:11:11 --> Model "Login_model" initialized
INFO - 2022-03-08 04:11:11 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 04:11:11 --> Model "Case_model" initialized
INFO - 2022-03-08 04:11:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:11:11 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 04:11:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:11:11 --> Final output sent to browser
DEBUG - 2022-03-08 04:11:11 --> Total execution time: 0.2279
ERROR - 2022-03-08 04:11:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:11:21 --> Config Class Initialized
INFO - 2022-03-08 04:11:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:11:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:11:21 --> Utf8 Class Initialized
INFO - 2022-03-08 04:11:21 --> URI Class Initialized
INFO - 2022-03-08 04:11:21 --> Router Class Initialized
INFO - 2022-03-08 04:11:21 --> Output Class Initialized
INFO - 2022-03-08 04:11:21 --> Security Class Initialized
DEBUG - 2022-03-08 04:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:11:21 --> Input Class Initialized
INFO - 2022-03-08 04:11:21 --> Language Class Initialized
INFO - 2022-03-08 04:11:21 --> Loader Class Initialized
INFO - 2022-03-08 04:11:21 --> Helper loaded: url_helper
INFO - 2022-03-08 04:11:21 --> Helper loaded: form_helper
INFO - 2022-03-08 04:11:21 --> Helper loaded: common_helper
INFO - 2022-03-08 04:11:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:11:21 --> Controller Class Initialized
INFO - 2022-03-08 04:11:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:11:21 --> Encrypt Class Initialized
INFO - 2022-03-08 04:11:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 04:11:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 04:11:21 --> Model "Referredby_model" initialized
INFO - 2022-03-08 04:11:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 04:11:21 --> Model "Hospital_model" initialized
INFO - 2022-03-08 04:11:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:11:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 04:11:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:11:21 --> Final output sent to browser
DEBUG - 2022-03-08 04:11:21 --> Total execution time: 0.0554
ERROR - 2022-03-08 04:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:11:37 --> Config Class Initialized
INFO - 2022-03-08 04:11:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:11:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:11:37 --> Utf8 Class Initialized
INFO - 2022-03-08 04:11:37 --> URI Class Initialized
INFO - 2022-03-08 04:11:37 --> Router Class Initialized
INFO - 2022-03-08 04:11:37 --> Output Class Initialized
INFO - 2022-03-08 04:11:37 --> Security Class Initialized
DEBUG - 2022-03-08 04:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:11:37 --> Input Class Initialized
INFO - 2022-03-08 04:11:37 --> Language Class Initialized
INFO - 2022-03-08 04:11:37 --> Loader Class Initialized
INFO - 2022-03-08 04:11:37 --> Helper loaded: url_helper
INFO - 2022-03-08 04:11:37 --> Helper loaded: form_helper
INFO - 2022-03-08 04:11:37 --> Helper loaded: common_helper
INFO - 2022-03-08 04:11:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:11:37 --> Controller Class Initialized
INFO - 2022-03-08 04:11:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:11:37 --> Encrypt Class Initialized
INFO - 2022-03-08 04:11:37 --> Model "Patient_model" initialized
INFO - 2022-03-08 04:11:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 04:11:37 --> Model "Prefix_master" initialized
INFO - 2022-03-08 04:11:37 --> Model "Users_model" initialized
INFO - 2022-03-08 04:11:37 --> Model "Hospital_model" initialized
INFO - 2022-03-08 04:11:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:11:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 04:11:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:11:37 --> Final output sent to browser
DEBUG - 2022-03-08 04:11:37 --> Total execution time: 0.1220
ERROR - 2022-03-08 04:12:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:12:04 --> Config Class Initialized
INFO - 2022-03-08 04:12:04 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:12:04 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:12:04 --> Utf8 Class Initialized
INFO - 2022-03-08 04:12:04 --> URI Class Initialized
DEBUG - 2022-03-08 04:12:04 --> No URI present. Default controller set.
INFO - 2022-03-08 04:12:04 --> Router Class Initialized
INFO - 2022-03-08 04:12:04 --> Output Class Initialized
INFO - 2022-03-08 04:12:04 --> Security Class Initialized
DEBUG - 2022-03-08 04:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:12:04 --> Input Class Initialized
INFO - 2022-03-08 04:12:04 --> Language Class Initialized
INFO - 2022-03-08 04:12:04 --> Loader Class Initialized
INFO - 2022-03-08 04:12:04 --> Helper loaded: url_helper
INFO - 2022-03-08 04:12:04 --> Helper loaded: form_helper
INFO - 2022-03-08 04:12:04 --> Helper loaded: common_helper
INFO - 2022-03-08 04:12:04 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:12:04 --> Controller Class Initialized
INFO - 2022-03-08 04:12:04 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:12:04 --> Encrypt Class Initialized
DEBUG - 2022-03-08 04:12:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 04:12:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 04:12:04 --> Email Class Initialized
INFO - 2022-03-08 04:12:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 04:12:04 --> Calendar Class Initialized
INFO - 2022-03-08 04:12:04 --> Model "Login_model" initialized
INFO - 2022-03-08 04:12:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 04:12:04 --> Final output sent to browser
DEBUG - 2022-03-08 04:12:04 --> Total execution time: 0.0287
ERROR - 2022-03-08 04:12:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:12:10 --> Config Class Initialized
INFO - 2022-03-08 04:12:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:12:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:12:10 --> Utf8 Class Initialized
INFO - 2022-03-08 04:12:10 --> URI Class Initialized
INFO - 2022-03-08 04:12:10 --> Router Class Initialized
INFO - 2022-03-08 04:12:10 --> Output Class Initialized
INFO - 2022-03-08 04:12:10 --> Security Class Initialized
DEBUG - 2022-03-08 04:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:12:10 --> Input Class Initialized
INFO - 2022-03-08 04:12:10 --> Language Class Initialized
INFO - 2022-03-08 04:12:10 --> Loader Class Initialized
INFO - 2022-03-08 04:12:10 --> Helper loaded: url_helper
INFO - 2022-03-08 04:12:10 --> Helper loaded: form_helper
INFO - 2022-03-08 04:12:10 --> Helper loaded: common_helper
INFO - 2022-03-08 04:12:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:12:10 --> Controller Class Initialized
INFO - 2022-03-08 04:12:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:12:10 --> Encrypt Class Initialized
DEBUG - 2022-03-08 04:12:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 04:12:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 04:12:10 --> Email Class Initialized
INFO - 2022-03-08 04:12:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 04:12:10 --> Calendar Class Initialized
INFO - 2022-03-08 04:12:10 --> Model "Login_model" initialized
INFO - 2022-03-08 04:12:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 04:12:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:12:11 --> Config Class Initialized
INFO - 2022-03-08 04:12:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:12:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:12:11 --> Utf8 Class Initialized
INFO - 2022-03-08 04:12:11 --> URI Class Initialized
INFO - 2022-03-08 04:12:11 --> Router Class Initialized
INFO - 2022-03-08 04:12:11 --> Output Class Initialized
INFO - 2022-03-08 04:12:11 --> Security Class Initialized
DEBUG - 2022-03-08 04:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:12:11 --> Input Class Initialized
INFO - 2022-03-08 04:12:11 --> Language Class Initialized
INFO - 2022-03-08 04:12:11 --> Loader Class Initialized
INFO - 2022-03-08 04:12:11 --> Helper loaded: url_helper
INFO - 2022-03-08 04:12:11 --> Helper loaded: form_helper
INFO - 2022-03-08 04:12:11 --> Helper loaded: common_helper
INFO - 2022-03-08 04:12:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:12:11 --> Controller Class Initialized
INFO - 2022-03-08 04:12:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:12:11 --> Encrypt Class Initialized
INFO - 2022-03-08 04:12:11 --> Model "Login_model" initialized
INFO - 2022-03-08 04:12:11 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 04:12:11 --> Model "Case_model" initialized
INFO - 2022-03-08 04:12:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:12:30 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 04:12:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:12:30 --> Final output sent to browser
DEBUG - 2022-03-08 04:12:30 --> Total execution time: 19.3389
ERROR - 2022-03-08 04:12:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:12:51 --> Config Class Initialized
INFO - 2022-03-08 04:12:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:12:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:12:51 --> Utf8 Class Initialized
INFO - 2022-03-08 04:12:51 --> URI Class Initialized
INFO - 2022-03-08 04:12:51 --> Router Class Initialized
INFO - 2022-03-08 04:12:51 --> Output Class Initialized
INFO - 2022-03-08 04:12:51 --> Security Class Initialized
DEBUG - 2022-03-08 04:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:12:51 --> Input Class Initialized
INFO - 2022-03-08 04:12:51 --> Language Class Initialized
INFO - 2022-03-08 04:12:51 --> Loader Class Initialized
INFO - 2022-03-08 04:12:51 --> Helper loaded: url_helper
INFO - 2022-03-08 04:12:51 --> Helper loaded: form_helper
INFO - 2022-03-08 04:12:51 --> Helper loaded: common_helper
INFO - 2022-03-08 04:12:51 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:12:51 --> Controller Class Initialized
INFO - 2022-03-08 04:12:51 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:12:51 --> Encrypt Class Initialized
INFO - 2022-03-08 04:12:51 --> Model "Patient_model" initialized
INFO - 2022-03-08 04:12:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 04:12:51 --> Model "Referredby_model" initialized
INFO - 2022-03-08 04:12:51 --> Model "Prefix_master" initialized
INFO - 2022-03-08 04:12:51 --> Model "Hospital_model" initialized
INFO - 2022-03-08 04:12:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:12:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 04:12:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:13:04 --> Final output sent to browser
DEBUG - 2022-03-08 04:13:04 --> Total execution time: 5.5616
ERROR - 2022-03-08 04:13:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:13:31 --> Config Class Initialized
INFO - 2022-03-08 04:13:31 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:13:31 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:13:31 --> Utf8 Class Initialized
INFO - 2022-03-08 04:13:31 --> URI Class Initialized
INFO - 2022-03-08 04:13:31 --> Router Class Initialized
INFO - 2022-03-08 04:13:31 --> Output Class Initialized
INFO - 2022-03-08 04:13:31 --> Security Class Initialized
DEBUG - 2022-03-08 04:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:13:31 --> Input Class Initialized
INFO - 2022-03-08 04:13:31 --> Language Class Initialized
INFO - 2022-03-08 04:13:31 --> Loader Class Initialized
INFO - 2022-03-08 04:13:31 --> Helper loaded: url_helper
INFO - 2022-03-08 04:13:31 --> Helper loaded: form_helper
INFO - 2022-03-08 04:13:31 --> Helper loaded: common_helper
INFO - 2022-03-08 04:13:31 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:13:31 --> Controller Class Initialized
INFO - 2022-03-08 04:13:31 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:13:31 --> Encrypt Class Initialized
INFO - 2022-03-08 04:13:31 --> Model "Patient_model" initialized
INFO - 2022-03-08 04:13:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 04:13:31 --> Model "Prefix_master" initialized
INFO - 2022-03-08 04:13:31 --> Model "Users_model" initialized
INFO - 2022-03-08 04:13:31 --> Model "Hospital_model" initialized
INFO - 2022-03-08 04:13:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:13:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 04:13:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:13:31 --> Final output sent to browser
DEBUG - 2022-03-08 04:13:31 --> Total execution time: 0.0640
ERROR - 2022-03-08 04:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:14:18 --> Config Class Initialized
INFO - 2022-03-08 04:14:18 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:14:18 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:14:18 --> Utf8 Class Initialized
INFO - 2022-03-08 04:14:18 --> URI Class Initialized
INFO - 2022-03-08 04:14:18 --> Router Class Initialized
INFO - 2022-03-08 04:14:18 --> Output Class Initialized
INFO - 2022-03-08 04:14:18 --> Security Class Initialized
DEBUG - 2022-03-08 04:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:14:18 --> Input Class Initialized
INFO - 2022-03-08 04:14:18 --> Language Class Initialized
INFO - 2022-03-08 04:14:18 --> Loader Class Initialized
INFO - 2022-03-08 04:14:18 --> Helper loaded: url_helper
INFO - 2022-03-08 04:14:18 --> Helper loaded: form_helper
INFO - 2022-03-08 04:14:18 --> Helper loaded: common_helper
INFO - 2022-03-08 04:14:18 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:14:18 --> Controller Class Initialized
INFO - 2022-03-08 04:14:18 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:14:18 --> Encrypt Class Initialized
INFO - 2022-03-08 04:14:18 --> Model "Patient_model" initialized
INFO - 2022-03-08 04:14:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 04:14:18 --> Model "Prefix_master" initialized
INFO - 2022-03-08 04:14:18 --> Model "Users_model" initialized
INFO - 2022-03-08 04:14:18 --> Model "Hospital_model" initialized
INFO - 2022-03-08 04:14:18 --> Upload Class Initialized
INFO - 2022-03-08 04:14:18 --> Final output sent to browser
DEBUG - 2022-03-08 04:14:18 --> Total execution time: 0.0903
ERROR - 2022-03-08 04:14:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:14:21 --> Config Class Initialized
INFO - 2022-03-08 04:14:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:14:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:14:21 --> Utf8 Class Initialized
INFO - 2022-03-08 04:14:21 --> URI Class Initialized
INFO - 2022-03-08 04:14:21 --> Router Class Initialized
INFO - 2022-03-08 04:14:21 --> Output Class Initialized
INFO - 2022-03-08 04:14:21 --> Security Class Initialized
DEBUG - 2022-03-08 04:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:14:21 --> Input Class Initialized
INFO - 2022-03-08 04:14:21 --> Language Class Initialized
INFO - 2022-03-08 04:14:21 --> Loader Class Initialized
INFO - 2022-03-08 04:14:21 --> Helper loaded: url_helper
INFO - 2022-03-08 04:14:21 --> Helper loaded: form_helper
INFO - 2022-03-08 04:14:21 --> Helper loaded: common_helper
INFO - 2022-03-08 04:14:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:14:21 --> Controller Class Initialized
INFO - 2022-03-08 04:14:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:14:21 --> Encrypt Class Initialized
INFO - 2022-03-08 04:14:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 04:14:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 04:14:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 04:14:21 --> Model "Users_model" initialized
INFO - 2022-03-08 04:14:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 04:14:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:14:21 --> Config Class Initialized
INFO - 2022-03-08 04:14:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:14:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:14:21 --> Utf8 Class Initialized
INFO - 2022-03-08 04:14:21 --> URI Class Initialized
INFO - 2022-03-08 04:14:21 --> Router Class Initialized
INFO - 2022-03-08 04:14:21 --> Output Class Initialized
INFO - 2022-03-08 04:14:21 --> Security Class Initialized
DEBUG - 2022-03-08 04:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:14:21 --> Input Class Initialized
INFO - 2022-03-08 04:14:21 --> Language Class Initialized
INFO - 2022-03-08 04:14:21 --> Loader Class Initialized
INFO - 2022-03-08 04:14:21 --> Helper loaded: url_helper
INFO - 2022-03-08 04:14:21 --> Helper loaded: form_helper
INFO - 2022-03-08 04:14:21 --> Helper loaded: common_helper
INFO - 2022-03-08 04:14:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:14:21 --> Controller Class Initialized
INFO - 2022-03-08 04:14:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:14:21 --> Encrypt Class Initialized
INFO - 2022-03-08 04:14:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 04:14:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 04:14:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 04:14:21 --> Model "Users_model" initialized
INFO - 2022-03-08 04:14:21 --> Model "Hospital_model" initialized
INFO - 2022-03-08 04:14:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:14:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 04:14:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:14:21 --> Final output sent to browser
DEBUG - 2022-03-08 04:14:21 --> Total execution time: 0.0710
ERROR - 2022-03-08 04:14:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 04:14:25 --> Config Class Initialized
INFO - 2022-03-08 04:14:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 04:14:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 04:14:25 --> Utf8 Class Initialized
INFO - 2022-03-08 04:14:25 --> URI Class Initialized
INFO - 2022-03-08 04:14:25 --> Router Class Initialized
INFO - 2022-03-08 04:14:25 --> Output Class Initialized
INFO - 2022-03-08 04:14:25 --> Security Class Initialized
DEBUG - 2022-03-08 04:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 04:14:25 --> Input Class Initialized
INFO - 2022-03-08 04:14:25 --> Language Class Initialized
INFO - 2022-03-08 04:14:25 --> Loader Class Initialized
INFO - 2022-03-08 04:14:25 --> Helper loaded: url_helper
INFO - 2022-03-08 04:14:25 --> Helper loaded: form_helper
INFO - 2022-03-08 04:14:25 --> Helper loaded: common_helper
INFO - 2022-03-08 04:14:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 04:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 04:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 04:14:25 --> Controller Class Initialized
INFO - 2022-03-08 04:14:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 04:14:25 --> Encrypt Class Initialized
INFO - 2022-03-08 04:14:25 --> Model "Patient_model" initialized
INFO - 2022-03-08 04:14:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 04:14:25 --> Model "Referredby_model" initialized
INFO - 2022-03-08 04:14:25 --> Model "Prefix_master" initialized
INFO - 2022-03-08 04:14:25 --> Model "Hospital_model" initialized
INFO - 2022-03-08 04:14:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 04:14:31 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 04:14:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 04:14:39 --> Final output sent to browser
DEBUG - 2022-03-08 04:14:39 --> Total execution time: 6.2567
ERROR - 2022-03-08 05:02:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:02:34 --> Config Class Initialized
INFO - 2022-03-08 05:02:34 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:02:34 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:02:34 --> Utf8 Class Initialized
INFO - 2022-03-08 05:02:34 --> URI Class Initialized
INFO - 2022-03-08 05:02:34 --> Router Class Initialized
INFO - 2022-03-08 05:02:34 --> Output Class Initialized
INFO - 2022-03-08 05:02:34 --> Security Class Initialized
DEBUG - 2022-03-08 05:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:02:34 --> Input Class Initialized
INFO - 2022-03-08 05:02:34 --> Language Class Initialized
INFO - 2022-03-08 05:02:34 --> Loader Class Initialized
INFO - 2022-03-08 05:02:34 --> Helper loaded: url_helper
INFO - 2022-03-08 05:02:34 --> Helper loaded: form_helper
INFO - 2022-03-08 05:02:34 --> Helper loaded: common_helper
INFO - 2022-03-08 05:02:34 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:02:34 --> Controller Class Initialized
INFO - 2022-03-08 05:02:34 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:02:34 --> Encrypt Class Initialized
INFO - 2022-03-08 05:02:34 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:02:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:02:34 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:02:34 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:02:34 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:02:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:02:34 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 05:02:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:02:34 --> Final output sent to browser
DEBUG - 2022-03-08 05:02:34 --> Total execution time: 0.0659
ERROR - 2022-03-08 05:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:03:22 --> Config Class Initialized
INFO - 2022-03-08 05:03:22 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:03:22 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:03:22 --> Utf8 Class Initialized
INFO - 2022-03-08 05:03:22 --> URI Class Initialized
INFO - 2022-03-08 05:03:22 --> Router Class Initialized
INFO - 2022-03-08 05:03:22 --> Output Class Initialized
INFO - 2022-03-08 05:03:22 --> Security Class Initialized
DEBUG - 2022-03-08 05:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:03:22 --> Input Class Initialized
INFO - 2022-03-08 05:03:22 --> Language Class Initialized
INFO - 2022-03-08 05:03:22 --> Loader Class Initialized
INFO - 2022-03-08 05:03:22 --> Helper loaded: url_helper
INFO - 2022-03-08 05:03:22 --> Helper loaded: form_helper
INFO - 2022-03-08 05:03:22 --> Helper loaded: common_helper
INFO - 2022-03-08 05:03:22 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:03:22 --> Controller Class Initialized
INFO - 2022-03-08 05:03:22 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:03:22 --> Encrypt Class Initialized
INFO - 2022-03-08 05:03:22 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:03:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:03:22 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:03:22 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:03:22 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:03:22 --> Final output sent to browser
DEBUG - 2022-03-08 05:03:22 --> Total execution time: 0.0711
ERROR - 2022-03-08 05:07:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:07:59 --> Config Class Initialized
INFO - 2022-03-08 05:07:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:07:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:07:59 --> Utf8 Class Initialized
INFO - 2022-03-08 05:07:59 --> URI Class Initialized
INFO - 2022-03-08 05:07:59 --> Router Class Initialized
INFO - 2022-03-08 05:07:59 --> Output Class Initialized
INFO - 2022-03-08 05:07:59 --> Security Class Initialized
DEBUG - 2022-03-08 05:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:07:59 --> Input Class Initialized
INFO - 2022-03-08 05:07:59 --> Language Class Initialized
INFO - 2022-03-08 05:07:59 --> Loader Class Initialized
INFO - 2022-03-08 05:07:59 --> Helper loaded: url_helper
INFO - 2022-03-08 05:07:59 --> Helper loaded: form_helper
INFO - 2022-03-08 05:07:59 --> Helper loaded: common_helper
INFO - 2022-03-08 05:07:59 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:07:59 --> Controller Class Initialized
INFO - 2022-03-08 05:07:59 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:07:59 --> Final output sent to browser
DEBUG - 2022-03-08 05:07:59 --> Total execution time: 0.0226
ERROR - 2022-03-08 05:08:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:08:36 --> Config Class Initialized
INFO - 2022-03-08 05:08:36 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:08:36 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:08:36 --> Utf8 Class Initialized
INFO - 2022-03-08 05:08:36 --> URI Class Initialized
INFO - 2022-03-08 05:08:36 --> Router Class Initialized
INFO - 2022-03-08 05:08:36 --> Output Class Initialized
INFO - 2022-03-08 05:08:36 --> Security Class Initialized
DEBUG - 2022-03-08 05:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:08:36 --> Input Class Initialized
INFO - 2022-03-08 05:08:36 --> Language Class Initialized
INFO - 2022-03-08 05:08:36 --> Loader Class Initialized
INFO - 2022-03-08 05:08:36 --> Helper loaded: url_helper
INFO - 2022-03-08 05:08:36 --> Helper loaded: form_helper
INFO - 2022-03-08 05:08:36 --> Helper loaded: common_helper
INFO - 2022-03-08 05:08:36 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:08:36 --> Controller Class Initialized
INFO - 2022-03-08 05:08:36 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:08:36 --> Final output sent to browser
DEBUG - 2022-03-08 05:08:36 --> Total execution time: 0.0193
ERROR - 2022-03-08 05:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:09:35 --> Config Class Initialized
INFO - 2022-03-08 05:09:35 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:09:35 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:09:35 --> Utf8 Class Initialized
INFO - 2022-03-08 05:09:35 --> URI Class Initialized
INFO - 2022-03-08 05:09:35 --> Router Class Initialized
INFO - 2022-03-08 05:09:35 --> Output Class Initialized
INFO - 2022-03-08 05:09:35 --> Security Class Initialized
DEBUG - 2022-03-08 05:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:09:35 --> Input Class Initialized
INFO - 2022-03-08 05:09:35 --> Language Class Initialized
INFO - 2022-03-08 05:09:35 --> Loader Class Initialized
INFO - 2022-03-08 05:09:35 --> Helper loaded: url_helper
INFO - 2022-03-08 05:09:35 --> Helper loaded: form_helper
INFO - 2022-03-08 05:09:35 --> Helper loaded: common_helper
INFO - 2022-03-08 05:09:35 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:09:35 --> Controller Class Initialized
INFO - 2022-03-08 05:09:35 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:09:35 --> Final output sent to browser
DEBUG - 2022-03-08 05:09:35 --> Total execution time: 0.0190
ERROR - 2022-03-08 05:10:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:10:08 --> Config Class Initialized
INFO - 2022-03-08 05:10:08 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:10:08 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:10:08 --> Utf8 Class Initialized
INFO - 2022-03-08 05:10:08 --> URI Class Initialized
INFO - 2022-03-08 05:10:08 --> Router Class Initialized
INFO - 2022-03-08 05:10:08 --> Output Class Initialized
INFO - 2022-03-08 05:10:08 --> Security Class Initialized
DEBUG - 2022-03-08 05:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:10:08 --> Input Class Initialized
INFO - 2022-03-08 05:10:08 --> Language Class Initialized
INFO - 2022-03-08 05:10:08 --> Loader Class Initialized
INFO - 2022-03-08 05:10:08 --> Helper loaded: url_helper
INFO - 2022-03-08 05:10:08 --> Helper loaded: form_helper
INFO - 2022-03-08 05:10:08 --> Helper loaded: common_helper
INFO - 2022-03-08 05:10:08 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:10:08 --> Controller Class Initialized
INFO - 2022-03-08 05:10:08 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:10:08 --> Encrypt Class Initialized
INFO - 2022-03-08 05:10:08 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:10:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:10:08 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:10:08 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:10:08 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:10:08 --> Final output sent to browser
DEBUG - 2022-03-08 05:10:08 --> Total execution time: 0.0293
ERROR - 2022-03-08 05:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:18:43 --> Config Class Initialized
INFO - 2022-03-08 05:18:43 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:18:43 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:18:43 --> Utf8 Class Initialized
INFO - 2022-03-08 05:18:43 --> URI Class Initialized
INFO - 2022-03-08 05:18:43 --> Router Class Initialized
INFO - 2022-03-08 05:18:43 --> Output Class Initialized
INFO - 2022-03-08 05:18:43 --> Security Class Initialized
DEBUG - 2022-03-08 05:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:18:43 --> Input Class Initialized
INFO - 2022-03-08 05:18:43 --> Language Class Initialized
INFO - 2022-03-08 05:18:43 --> Loader Class Initialized
INFO - 2022-03-08 05:18:43 --> Helper loaded: url_helper
INFO - 2022-03-08 05:18:43 --> Helper loaded: form_helper
INFO - 2022-03-08 05:18:43 --> Helper loaded: common_helper
INFO - 2022-03-08 05:18:43 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:18:43 --> Controller Class Initialized
INFO - 2022-03-08 05:18:43 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:18:43 --> Encrypt Class Initialized
INFO - 2022-03-08 05:18:43 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:18:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:18:43 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:18:43 --> Model "Users_model" initialized
INFO - 2022-03-08 05:18:43 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:18:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:18:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 05:18:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:18:43 --> Final output sent to browser
DEBUG - 2022-03-08 05:18:43 --> Total execution time: 0.4558
ERROR - 2022-03-08 05:19:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:19:22 --> Config Class Initialized
INFO - 2022-03-08 05:19:22 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:19:22 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:19:22 --> Utf8 Class Initialized
INFO - 2022-03-08 05:19:22 --> URI Class Initialized
INFO - 2022-03-08 05:19:22 --> Router Class Initialized
INFO - 2022-03-08 05:19:22 --> Output Class Initialized
INFO - 2022-03-08 05:19:22 --> Security Class Initialized
DEBUG - 2022-03-08 05:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:19:22 --> Input Class Initialized
INFO - 2022-03-08 05:19:22 --> Language Class Initialized
INFO - 2022-03-08 05:19:22 --> Loader Class Initialized
INFO - 2022-03-08 05:19:22 --> Helper loaded: url_helper
INFO - 2022-03-08 05:19:22 --> Helper loaded: form_helper
INFO - 2022-03-08 05:19:22 --> Helper loaded: common_helper
INFO - 2022-03-08 05:19:22 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:19:22 --> Controller Class Initialized
INFO - 2022-03-08 05:19:22 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:19:22 --> Encrypt Class Initialized
INFO - 2022-03-08 05:19:22 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:19:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:19:22 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:19:22 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:19:22 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:19:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:19:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 05:19:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:19:31 --> Final output sent to browser
DEBUG - 2022-03-08 05:19:31 --> Total execution time: 7.2179
ERROR - 2022-03-08 05:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:24:23 --> Config Class Initialized
INFO - 2022-03-08 05:24:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:24:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:24:23 --> Utf8 Class Initialized
INFO - 2022-03-08 05:24:23 --> URI Class Initialized
INFO - 2022-03-08 05:24:23 --> Router Class Initialized
INFO - 2022-03-08 05:24:23 --> Output Class Initialized
INFO - 2022-03-08 05:24:23 --> Security Class Initialized
DEBUG - 2022-03-08 05:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:24:23 --> Input Class Initialized
INFO - 2022-03-08 05:24:23 --> Language Class Initialized
INFO - 2022-03-08 05:24:23 --> Loader Class Initialized
INFO - 2022-03-08 05:24:23 --> Helper loaded: url_helper
INFO - 2022-03-08 05:24:23 --> Helper loaded: form_helper
INFO - 2022-03-08 05:24:23 --> Helper loaded: common_helper
INFO - 2022-03-08 05:24:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:24:23 --> Controller Class Initialized
INFO - 2022-03-08 05:24:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:24:23 --> Encrypt Class Initialized
INFO - 2022-03-08 05:24:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:24:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:24:23 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:24:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:24:23 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:24:23 --> Final output sent to browser
DEBUG - 2022-03-08 05:24:23 --> Total execution time: 0.0391
ERROR - 2022-03-08 05:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:24:43 --> Config Class Initialized
INFO - 2022-03-08 05:24:43 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:24:43 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:24:43 --> Utf8 Class Initialized
INFO - 2022-03-08 05:24:43 --> URI Class Initialized
INFO - 2022-03-08 05:24:43 --> Router Class Initialized
INFO - 2022-03-08 05:24:43 --> Output Class Initialized
INFO - 2022-03-08 05:24:43 --> Security Class Initialized
DEBUG - 2022-03-08 05:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:24:43 --> Input Class Initialized
INFO - 2022-03-08 05:24:43 --> Language Class Initialized
INFO - 2022-03-08 05:24:43 --> Loader Class Initialized
INFO - 2022-03-08 05:24:43 --> Helper loaded: url_helper
INFO - 2022-03-08 05:24:43 --> Helper loaded: form_helper
INFO - 2022-03-08 05:24:43 --> Helper loaded: common_helper
INFO - 2022-03-08 05:24:43 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:24:43 --> Controller Class Initialized
INFO - 2022-03-08 05:24:43 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:24:43 --> Final output sent to browser
DEBUG - 2022-03-08 05:24:43 --> Total execution time: 0.0290
ERROR - 2022-03-08 05:25:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:25:28 --> Config Class Initialized
INFO - 2022-03-08 05:25:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:25:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:25:28 --> Utf8 Class Initialized
INFO - 2022-03-08 05:25:28 --> URI Class Initialized
INFO - 2022-03-08 05:25:28 --> Router Class Initialized
INFO - 2022-03-08 05:25:28 --> Output Class Initialized
INFO - 2022-03-08 05:25:28 --> Security Class Initialized
DEBUG - 2022-03-08 05:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:25:28 --> Input Class Initialized
INFO - 2022-03-08 05:25:28 --> Language Class Initialized
INFO - 2022-03-08 05:25:28 --> Loader Class Initialized
INFO - 2022-03-08 05:25:28 --> Helper loaded: url_helper
INFO - 2022-03-08 05:25:28 --> Helper loaded: form_helper
INFO - 2022-03-08 05:25:28 --> Helper loaded: common_helper
INFO - 2022-03-08 05:25:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:25:28 --> Controller Class Initialized
INFO - 2022-03-08 05:25:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:25:28 --> Encrypt Class Initialized
INFO - 2022-03-08 05:25:28 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:25:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:25:28 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:25:28 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:25:28 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:25:28 --> Final output sent to browser
DEBUG - 2022-03-08 05:25:28 --> Total execution time: 0.0245
ERROR - 2022-03-08 05:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:25:29 --> Config Class Initialized
INFO - 2022-03-08 05:25:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:25:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:25:29 --> Utf8 Class Initialized
INFO - 2022-03-08 05:25:29 --> URI Class Initialized
INFO - 2022-03-08 05:25:29 --> Router Class Initialized
INFO - 2022-03-08 05:25:29 --> Output Class Initialized
INFO - 2022-03-08 05:25:29 --> Security Class Initialized
DEBUG - 2022-03-08 05:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:25:29 --> Input Class Initialized
INFO - 2022-03-08 05:25:29 --> Language Class Initialized
INFO - 2022-03-08 05:25:29 --> Loader Class Initialized
INFO - 2022-03-08 05:25:29 --> Helper loaded: url_helper
INFO - 2022-03-08 05:25:29 --> Helper loaded: form_helper
INFO - 2022-03-08 05:25:29 --> Helper loaded: common_helper
INFO - 2022-03-08 05:25:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:25:29 --> Controller Class Initialized
INFO - 2022-03-08 05:25:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:25:29 --> Encrypt Class Initialized
INFO - 2022-03-08 05:25:29 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:25:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:25:29 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:25:29 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:25:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 05:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:25:29 --> Config Class Initialized
INFO - 2022-03-08 05:25:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:25:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:25:29 --> Utf8 Class Initialized
INFO - 2022-03-08 05:25:29 --> URI Class Initialized
INFO - 2022-03-08 05:25:29 --> Router Class Initialized
INFO - 2022-03-08 05:25:29 --> Output Class Initialized
INFO - 2022-03-08 05:25:29 --> Security Class Initialized
DEBUG - 2022-03-08 05:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:25:29 --> Input Class Initialized
INFO - 2022-03-08 05:25:29 --> Language Class Initialized
INFO - 2022-03-08 05:25:29 --> Loader Class Initialized
INFO - 2022-03-08 05:25:29 --> Helper loaded: url_helper
INFO - 2022-03-08 05:25:29 --> Helper loaded: form_helper
INFO - 2022-03-08 05:25:29 --> Helper loaded: common_helper
INFO - 2022-03-08 05:25:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:25:29 --> Controller Class Initialized
INFO - 2022-03-08 05:25:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:25:29 --> Encrypt Class Initialized
INFO - 2022-03-08 05:25:29 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:25:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:25:29 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:25:29 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:25:29 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:25:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:25:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 05:25:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:25:29 --> Final output sent to browser
DEBUG - 2022-03-08 05:25:29 --> Total execution time: 0.2282
ERROR - 2022-03-08 05:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:25:30 --> Config Class Initialized
INFO - 2022-03-08 05:25:30 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:25:30 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:25:30 --> Utf8 Class Initialized
INFO - 2022-03-08 05:25:30 --> URI Class Initialized
INFO - 2022-03-08 05:25:30 --> Router Class Initialized
INFO - 2022-03-08 05:25:30 --> Output Class Initialized
INFO - 2022-03-08 05:25:30 --> Security Class Initialized
DEBUG - 2022-03-08 05:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:25:30 --> Input Class Initialized
INFO - 2022-03-08 05:25:30 --> Language Class Initialized
INFO - 2022-03-08 05:25:30 --> Loader Class Initialized
INFO - 2022-03-08 05:25:30 --> Helper loaded: url_helper
INFO - 2022-03-08 05:25:30 --> Helper loaded: form_helper
INFO - 2022-03-08 05:25:30 --> Helper loaded: common_helper
INFO - 2022-03-08 05:25:30 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:25:30 --> Controller Class Initialized
INFO - 2022-03-08 05:25:30 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:25:30 --> Encrypt Class Initialized
INFO - 2022-03-08 05:25:30 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:25:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:25:30 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:25:30 --> Model "Users_model" initialized
INFO - 2022-03-08 05:25:30 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:25:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:25:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 05:25:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:25:30 --> Final output sent to browser
DEBUG - 2022-03-08 05:25:30 --> Total execution time: 0.0595
ERROR - 2022-03-08 05:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:35:52 --> Config Class Initialized
INFO - 2022-03-08 05:35:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:35:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:35:52 --> Utf8 Class Initialized
INFO - 2022-03-08 05:35:52 --> URI Class Initialized
INFO - 2022-03-08 05:35:52 --> Router Class Initialized
INFO - 2022-03-08 05:35:52 --> Output Class Initialized
INFO - 2022-03-08 05:35:52 --> Security Class Initialized
DEBUG - 2022-03-08 05:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:35:52 --> Input Class Initialized
INFO - 2022-03-08 05:35:52 --> Language Class Initialized
INFO - 2022-03-08 05:35:52 --> Loader Class Initialized
INFO - 2022-03-08 05:35:52 --> Helper loaded: url_helper
INFO - 2022-03-08 05:35:52 --> Helper loaded: form_helper
INFO - 2022-03-08 05:35:52 --> Helper loaded: common_helper
INFO - 2022-03-08 05:35:52 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:35:52 --> Controller Class Initialized
INFO - 2022-03-08 05:35:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:35:52 --> Encrypt Class Initialized
INFO - 2022-03-08 05:35:52 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:35:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:35:52 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:35:52 --> Model "Users_model" initialized
INFO - 2022-03-08 05:35:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 05:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:35:52 --> Config Class Initialized
INFO - 2022-03-08 05:35:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:35:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:35:52 --> Utf8 Class Initialized
INFO - 2022-03-08 05:35:52 --> URI Class Initialized
INFO - 2022-03-08 05:35:52 --> Router Class Initialized
INFO - 2022-03-08 05:35:52 --> Output Class Initialized
INFO - 2022-03-08 05:35:52 --> Security Class Initialized
DEBUG - 2022-03-08 05:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:35:52 --> Input Class Initialized
INFO - 2022-03-08 05:35:52 --> Language Class Initialized
INFO - 2022-03-08 05:35:52 --> Loader Class Initialized
INFO - 2022-03-08 05:35:52 --> Helper loaded: url_helper
INFO - 2022-03-08 05:35:52 --> Helper loaded: form_helper
INFO - 2022-03-08 05:35:52 --> Helper loaded: common_helper
INFO - 2022-03-08 05:35:52 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:35:52 --> Controller Class Initialized
INFO - 2022-03-08 05:35:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:35:52 --> Encrypt Class Initialized
INFO - 2022-03-08 05:35:52 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:35:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:35:52 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:35:52 --> Model "Users_model" initialized
INFO - 2022-03-08 05:35:52 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:35:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:35:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 05:35:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:35:52 --> Final output sent to browser
DEBUG - 2022-03-08 05:35:52 --> Total execution time: 0.1388
ERROR - 2022-03-08 05:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:40:36 --> Config Class Initialized
INFO - 2022-03-08 05:40:36 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:40:36 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:40:36 --> Utf8 Class Initialized
INFO - 2022-03-08 05:40:36 --> URI Class Initialized
INFO - 2022-03-08 05:40:36 --> Router Class Initialized
INFO - 2022-03-08 05:40:36 --> Output Class Initialized
INFO - 2022-03-08 05:40:36 --> Security Class Initialized
DEBUG - 2022-03-08 05:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:40:36 --> Input Class Initialized
INFO - 2022-03-08 05:40:36 --> Language Class Initialized
INFO - 2022-03-08 05:40:36 --> Loader Class Initialized
INFO - 2022-03-08 05:40:36 --> Helper loaded: url_helper
INFO - 2022-03-08 05:40:36 --> Helper loaded: form_helper
INFO - 2022-03-08 05:40:36 --> Helper loaded: common_helper
INFO - 2022-03-08 05:40:36 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:40:36 --> Controller Class Initialized
INFO - 2022-03-08 05:40:36 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:40:36 --> Encrypt Class Initialized
INFO - 2022-03-08 05:40:36 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:40:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:40:36 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:40:36 --> Model "Users_model" initialized
INFO - 2022-03-08 05:40:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 05:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:40:36 --> Config Class Initialized
INFO - 2022-03-08 05:40:36 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:40:36 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:40:36 --> Utf8 Class Initialized
INFO - 2022-03-08 05:40:36 --> URI Class Initialized
INFO - 2022-03-08 05:40:36 --> Router Class Initialized
INFO - 2022-03-08 05:40:37 --> Output Class Initialized
INFO - 2022-03-08 05:40:37 --> Security Class Initialized
DEBUG - 2022-03-08 05:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:40:37 --> Input Class Initialized
INFO - 2022-03-08 05:40:37 --> Language Class Initialized
INFO - 2022-03-08 05:40:37 --> Loader Class Initialized
INFO - 2022-03-08 05:40:37 --> Helper loaded: url_helper
INFO - 2022-03-08 05:40:37 --> Helper loaded: form_helper
INFO - 2022-03-08 05:40:37 --> Helper loaded: common_helper
INFO - 2022-03-08 05:40:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:40:37 --> Controller Class Initialized
INFO - 2022-03-08 05:40:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:40:37 --> Encrypt Class Initialized
INFO - 2022-03-08 05:40:37 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:40:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:40:37 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:40:37 --> Model "Users_model" initialized
INFO - 2022-03-08 05:40:37 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:40:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:40:37 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 05:40:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:40:37 --> Final output sent to browser
DEBUG - 2022-03-08 05:40:37 --> Total execution time: 0.0651
ERROR - 2022-03-08 05:42:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:42:46 --> Config Class Initialized
INFO - 2022-03-08 05:42:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:42:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:42:46 --> Utf8 Class Initialized
INFO - 2022-03-08 05:42:46 --> URI Class Initialized
INFO - 2022-03-08 05:42:46 --> Router Class Initialized
INFO - 2022-03-08 05:42:46 --> Output Class Initialized
INFO - 2022-03-08 05:42:46 --> Security Class Initialized
DEBUG - 2022-03-08 05:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:42:46 --> Input Class Initialized
INFO - 2022-03-08 05:42:46 --> Language Class Initialized
INFO - 2022-03-08 05:42:46 --> Loader Class Initialized
INFO - 2022-03-08 05:42:46 --> Helper loaded: url_helper
INFO - 2022-03-08 05:42:46 --> Helper loaded: form_helper
INFO - 2022-03-08 05:42:46 --> Helper loaded: common_helper
INFO - 2022-03-08 05:42:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:42:46 --> Controller Class Initialized
INFO - 2022-03-08 05:42:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:42:46 --> Encrypt Class Initialized
INFO - 2022-03-08 05:42:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:42:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:42:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:42:46 --> Model "Users_model" initialized
INFO - 2022-03-08 05:42:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 05:42:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:42:47 --> Config Class Initialized
INFO - 2022-03-08 05:42:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:42:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:42:47 --> Utf8 Class Initialized
INFO - 2022-03-08 05:42:47 --> URI Class Initialized
INFO - 2022-03-08 05:42:47 --> Router Class Initialized
INFO - 2022-03-08 05:42:47 --> Output Class Initialized
INFO - 2022-03-08 05:42:47 --> Security Class Initialized
DEBUG - 2022-03-08 05:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:42:47 --> Input Class Initialized
INFO - 2022-03-08 05:42:47 --> Language Class Initialized
INFO - 2022-03-08 05:42:47 --> Loader Class Initialized
INFO - 2022-03-08 05:42:47 --> Helper loaded: url_helper
INFO - 2022-03-08 05:42:47 --> Helper loaded: form_helper
INFO - 2022-03-08 05:42:47 --> Helper loaded: common_helper
INFO - 2022-03-08 05:42:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:42:47 --> Controller Class Initialized
INFO - 2022-03-08 05:42:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:42:47 --> Encrypt Class Initialized
INFO - 2022-03-08 05:42:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:42:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:42:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:42:47 --> Model "Users_model" initialized
INFO - 2022-03-08 05:42:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:42:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:42:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 05:42:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:42:47 --> Final output sent to browser
DEBUG - 2022-03-08 05:42:47 --> Total execution time: 0.0858
ERROR - 2022-03-08 05:44:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:44:02 --> Config Class Initialized
INFO - 2022-03-08 05:44:02 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:44:02 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:44:02 --> Utf8 Class Initialized
INFO - 2022-03-08 05:44:02 --> URI Class Initialized
DEBUG - 2022-03-08 05:44:02 --> No URI present. Default controller set.
INFO - 2022-03-08 05:44:02 --> Router Class Initialized
INFO - 2022-03-08 05:44:02 --> Output Class Initialized
INFO - 2022-03-08 05:44:02 --> Security Class Initialized
DEBUG - 2022-03-08 05:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:44:02 --> Input Class Initialized
INFO - 2022-03-08 05:44:02 --> Language Class Initialized
INFO - 2022-03-08 05:44:02 --> Loader Class Initialized
INFO - 2022-03-08 05:44:02 --> Helper loaded: url_helper
INFO - 2022-03-08 05:44:02 --> Helper loaded: form_helper
INFO - 2022-03-08 05:44:02 --> Helper loaded: common_helper
INFO - 2022-03-08 05:44:02 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:44:02 --> Controller Class Initialized
INFO - 2022-03-08 05:44:02 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:44:02 --> Encrypt Class Initialized
DEBUG - 2022-03-08 05:44:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 05:44:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 05:44:02 --> Email Class Initialized
INFO - 2022-03-08 05:44:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 05:44:02 --> Calendar Class Initialized
INFO - 2022-03-08 05:44:02 --> Model "Login_model" initialized
INFO - 2022-03-08 05:44:02 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 05:44:02 --> Final output sent to browser
DEBUG - 2022-03-08 05:44:02 --> Total execution time: 0.0229
ERROR - 2022-03-08 05:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:44:26 --> Config Class Initialized
INFO - 2022-03-08 05:44:26 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:44:26 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:44:26 --> Utf8 Class Initialized
INFO - 2022-03-08 05:44:26 --> URI Class Initialized
INFO - 2022-03-08 05:44:26 --> Router Class Initialized
INFO - 2022-03-08 05:44:26 --> Output Class Initialized
INFO - 2022-03-08 05:44:26 --> Security Class Initialized
DEBUG - 2022-03-08 05:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:44:26 --> Input Class Initialized
INFO - 2022-03-08 05:44:26 --> Language Class Initialized
INFO - 2022-03-08 05:44:26 --> Loader Class Initialized
INFO - 2022-03-08 05:44:26 --> Helper loaded: url_helper
INFO - 2022-03-08 05:44:26 --> Helper loaded: form_helper
INFO - 2022-03-08 05:44:26 --> Helper loaded: common_helper
INFO - 2022-03-08 05:44:26 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:44:26 --> Controller Class Initialized
INFO - 2022-03-08 05:44:26 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:44:26 --> Encrypt Class Initialized
DEBUG - 2022-03-08 05:44:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 05:44:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 05:44:26 --> Email Class Initialized
INFO - 2022-03-08 05:44:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 05:44:26 --> Calendar Class Initialized
INFO - 2022-03-08 05:44:26 --> Model "Login_model" initialized
INFO - 2022-03-08 05:44:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 05:44:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:44:27 --> Config Class Initialized
INFO - 2022-03-08 05:44:27 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:44:27 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:44:27 --> Utf8 Class Initialized
INFO - 2022-03-08 05:44:27 --> URI Class Initialized
INFO - 2022-03-08 05:44:27 --> Router Class Initialized
INFO - 2022-03-08 05:44:27 --> Output Class Initialized
INFO - 2022-03-08 05:44:27 --> Security Class Initialized
DEBUG - 2022-03-08 05:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:44:27 --> Input Class Initialized
INFO - 2022-03-08 05:44:27 --> Language Class Initialized
INFO - 2022-03-08 05:44:27 --> Loader Class Initialized
INFO - 2022-03-08 05:44:27 --> Helper loaded: url_helper
INFO - 2022-03-08 05:44:27 --> Helper loaded: form_helper
INFO - 2022-03-08 05:44:27 --> Helper loaded: common_helper
INFO - 2022-03-08 05:44:27 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:44:27 --> Controller Class Initialized
INFO - 2022-03-08 05:44:27 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:44:27 --> Encrypt Class Initialized
INFO - 2022-03-08 05:44:27 --> Model "Login_model" initialized
INFO - 2022-03-08 05:44:27 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 05:44:27 --> Model "Case_model" initialized
INFO - 2022-03-08 05:44:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:44:50 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 05:44:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:44:50 --> Final output sent to browser
DEBUG - 2022-03-08 05:44:50 --> Total execution time: 22.7793
ERROR - 2022-03-08 05:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:44:51 --> Config Class Initialized
INFO - 2022-03-08 05:44:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:44:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:44:51 --> Utf8 Class Initialized
INFO - 2022-03-08 05:44:51 --> URI Class Initialized
INFO - 2022-03-08 05:44:51 --> Router Class Initialized
INFO - 2022-03-08 05:44:51 --> Output Class Initialized
INFO - 2022-03-08 05:44:51 --> Security Class Initialized
DEBUG - 2022-03-08 05:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:44:51 --> Input Class Initialized
INFO - 2022-03-08 05:44:51 --> Language Class Initialized
ERROR - 2022-03-08 05:44:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 05:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:44:56 --> Config Class Initialized
INFO - 2022-03-08 05:44:56 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:44:56 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:44:56 --> Utf8 Class Initialized
INFO - 2022-03-08 05:44:56 --> URI Class Initialized
INFO - 2022-03-08 05:44:56 --> Router Class Initialized
INFO - 2022-03-08 05:44:56 --> Output Class Initialized
INFO - 2022-03-08 05:44:56 --> Security Class Initialized
DEBUG - 2022-03-08 05:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:44:56 --> Input Class Initialized
INFO - 2022-03-08 05:44:56 --> Language Class Initialized
INFO - 2022-03-08 05:44:56 --> Loader Class Initialized
INFO - 2022-03-08 05:44:56 --> Helper loaded: url_helper
INFO - 2022-03-08 05:44:56 --> Helper loaded: form_helper
INFO - 2022-03-08 05:44:56 --> Helper loaded: common_helper
INFO - 2022-03-08 05:44:56 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:44:56 --> Controller Class Initialized
INFO - 2022-03-08 05:44:56 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:44:56 --> Encrypt Class Initialized
INFO - 2022-03-08 05:44:56 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:44:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:44:56 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:44:56 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:44:56 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:44:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:45:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 05:45:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 05:45:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:45:03 --> Config Class Initialized
INFO - 2022-03-08 05:45:03 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:45:03 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:45:03 --> Utf8 Class Initialized
INFO - 2022-03-08 05:45:03 --> URI Class Initialized
INFO - 2022-03-08 05:45:03 --> Router Class Initialized
INFO - 2022-03-08 05:45:03 --> Output Class Initialized
INFO - 2022-03-08 05:45:03 --> Security Class Initialized
DEBUG - 2022-03-08 05:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:45:03 --> Input Class Initialized
INFO - 2022-03-08 05:45:03 --> Language Class Initialized
ERROR - 2022-03-08 05:45:03 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 05:45:13 --> Final output sent to browser
DEBUG - 2022-03-08 05:45:13 --> Total execution time: 6.4428
ERROR - 2022-03-08 05:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:45:44 --> Config Class Initialized
INFO - 2022-03-08 05:45:44 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:45:44 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:45:44 --> Utf8 Class Initialized
INFO - 2022-03-08 05:45:44 --> URI Class Initialized
INFO - 2022-03-08 05:45:44 --> Router Class Initialized
INFO - 2022-03-08 05:45:44 --> Output Class Initialized
INFO - 2022-03-08 05:45:44 --> Security Class Initialized
DEBUG - 2022-03-08 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:45:44 --> Input Class Initialized
INFO - 2022-03-08 05:45:44 --> Language Class Initialized
INFO - 2022-03-08 05:45:44 --> Loader Class Initialized
INFO - 2022-03-08 05:45:44 --> Helper loaded: url_helper
INFO - 2022-03-08 05:45:44 --> Helper loaded: form_helper
INFO - 2022-03-08 05:45:44 --> Helper loaded: common_helper
INFO - 2022-03-08 05:45:44 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:45:44 --> Controller Class Initialized
INFO - 2022-03-08 05:45:45 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:45:45 --> Encrypt Class Initialized
INFO - 2022-03-08 05:45:45 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:45:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:45:45 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:45:45 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:45:45 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:45:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:45:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 05:45:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:45:45 --> Final output sent to browser
DEBUG - 2022-03-08 05:45:45 --> Total execution time: 0.0565
ERROR - 2022-03-08 05:45:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:45:45 --> Config Class Initialized
INFO - 2022-03-08 05:45:45 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:45:45 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:45:45 --> Utf8 Class Initialized
INFO - 2022-03-08 05:45:45 --> URI Class Initialized
INFO - 2022-03-08 05:45:45 --> Router Class Initialized
INFO - 2022-03-08 05:45:45 --> Output Class Initialized
INFO - 2022-03-08 05:45:45 --> Security Class Initialized
DEBUG - 2022-03-08 05:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:45:45 --> Input Class Initialized
INFO - 2022-03-08 05:45:45 --> Language Class Initialized
ERROR - 2022-03-08 05:45:45 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 05:46:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:46:56 --> Config Class Initialized
INFO - 2022-03-08 05:46:56 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:46:56 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:46:56 --> Utf8 Class Initialized
INFO - 2022-03-08 05:46:56 --> URI Class Initialized
INFO - 2022-03-08 05:46:56 --> Router Class Initialized
INFO - 2022-03-08 05:46:56 --> Output Class Initialized
INFO - 2022-03-08 05:46:56 --> Security Class Initialized
DEBUG - 2022-03-08 05:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:46:56 --> Input Class Initialized
INFO - 2022-03-08 05:46:56 --> Language Class Initialized
INFO - 2022-03-08 05:46:56 --> Loader Class Initialized
INFO - 2022-03-08 05:46:56 --> Helper loaded: url_helper
INFO - 2022-03-08 05:46:56 --> Helper loaded: form_helper
INFO - 2022-03-08 05:46:56 --> Helper loaded: common_helper
INFO - 2022-03-08 05:46:56 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:46:56 --> Controller Class Initialized
INFO - 2022-03-08 05:46:56 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:46:56 --> Encrypt Class Initialized
INFO - 2022-03-08 05:46:56 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:46:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:46:56 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:46:56 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:46:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 05:46:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:46:57 --> Config Class Initialized
INFO - 2022-03-08 05:46:57 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:46:57 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:46:57 --> Utf8 Class Initialized
INFO - 2022-03-08 05:46:57 --> URI Class Initialized
INFO - 2022-03-08 05:46:57 --> Router Class Initialized
INFO - 2022-03-08 05:46:57 --> Output Class Initialized
INFO - 2022-03-08 05:46:57 --> Security Class Initialized
DEBUG - 2022-03-08 05:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:46:57 --> Input Class Initialized
INFO - 2022-03-08 05:46:57 --> Language Class Initialized
INFO - 2022-03-08 05:46:57 --> Loader Class Initialized
INFO - 2022-03-08 05:46:57 --> Helper loaded: url_helper
INFO - 2022-03-08 05:46:57 --> Helper loaded: form_helper
INFO - 2022-03-08 05:46:57 --> Helper loaded: common_helper
INFO - 2022-03-08 05:46:57 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:46:57 --> Controller Class Initialized
INFO - 2022-03-08 05:46:57 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:46:57 --> Encrypt Class Initialized
INFO - 2022-03-08 05:46:57 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:46:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:46:57 --> Model "Referredby_model" initialized
INFO - 2022-03-08 05:46:57 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:46:57 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:46:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:46:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 05:46:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:46:57 --> Final output sent to browser
DEBUG - 2022-03-08 05:46:57 --> Total execution time: 0.0742
ERROR - 2022-03-08 05:46:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:46:57 --> Config Class Initialized
INFO - 2022-03-08 05:46:57 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:46:57 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:46:57 --> Utf8 Class Initialized
INFO - 2022-03-08 05:46:57 --> URI Class Initialized
INFO - 2022-03-08 05:46:57 --> Router Class Initialized
INFO - 2022-03-08 05:46:57 --> Output Class Initialized
INFO - 2022-03-08 05:46:57 --> Security Class Initialized
DEBUG - 2022-03-08 05:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:46:57 --> Input Class Initialized
INFO - 2022-03-08 05:46:57 --> Language Class Initialized
ERROR - 2022-03-08 05:46:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 05:46:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:46:58 --> Config Class Initialized
INFO - 2022-03-08 05:46:58 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:46:58 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:46:58 --> Utf8 Class Initialized
INFO - 2022-03-08 05:46:58 --> URI Class Initialized
INFO - 2022-03-08 05:46:58 --> Router Class Initialized
INFO - 2022-03-08 05:46:58 --> Output Class Initialized
INFO - 2022-03-08 05:46:58 --> Security Class Initialized
DEBUG - 2022-03-08 05:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:46:58 --> Input Class Initialized
INFO - 2022-03-08 05:46:58 --> Language Class Initialized
INFO - 2022-03-08 05:46:58 --> Loader Class Initialized
INFO - 2022-03-08 05:46:58 --> Helper loaded: url_helper
INFO - 2022-03-08 05:46:58 --> Helper loaded: form_helper
INFO - 2022-03-08 05:46:58 --> Helper loaded: common_helper
INFO - 2022-03-08 05:46:58 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:46:58 --> Controller Class Initialized
INFO - 2022-03-08 05:46:58 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:46:58 --> Encrypt Class Initialized
INFO - 2022-03-08 05:46:58 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:46:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:46:58 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:46:58 --> Model "Users_model" initialized
INFO - 2022-03-08 05:46:58 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:46:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:46:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 05:46:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:46:58 --> Final output sent to browser
DEBUG - 2022-03-08 05:46:58 --> Total execution time: 0.0828
ERROR - 2022-03-08 05:46:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:46:59 --> Config Class Initialized
INFO - 2022-03-08 05:46:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:46:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:46:59 --> Utf8 Class Initialized
INFO - 2022-03-08 05:46:59 --> URI Class Initialized
INFO - 2022-03-08 05:46:59 --> Router Class Initialized
INFO - 2022-03-08 05:46:59 --> Output Class Initialized
INFO - 2022-03-08 05:46:59 --> Security Class Initialized
DEBUG - 2022-03-08 05:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:46:59 --> Input Class Initialized
INFO - 2022-03-08 05:46:59 --> Language Class Initialized
ERROR - 2022-03-08 05:46:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 05:50:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:50:15 --> Config Class Initialized
INFO - 2022-03-08 05:50:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:50:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:50:15 --> Utf8 Class Initialized
INFO - 2022-03-08 05:50:15 --> URI Class Initialized
INFO - 2022-03-08 05:50:15 --> Router Class Initialized
INFO - 2022-03-08 05:50:15 --> Output Class Initialized
INFO - 2022-03-08 05:50:15 --> Security Class Initialized
DEBUG - 2022-03-08 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:50:15 --> Input Class Initialized
INFO - 2022-03-08 05:50:15 --> Language Class Initialized
INFO - 2022-03-08 05:50:15 --> Loader Class Initialized
INFO - 2022-03-08 05:50:15 --> Helper loaded: url_helper
INFO - 2022-03-08 05:50:15 --> Helper loaded: form_helper
INFO - 2022-03-08 05:50:15 --> Helper loaded: common_helper
INFO - 2022-03-08 05:50:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:50:15 --> Controller Class Initialized
INFO - 2022-03-08 05:50:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:50:15 --> Encrypt Class Initialized
INFO - 2022-03-08 05:50:15 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:50:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:50:15 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:50:15 --> Model "Users_model" initialized
INFO - 2022-03-08 05:50:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 05:50:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:50:15 --> Config Class Initialized
INFO - 2022-03-08 05:50:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:50:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:50:15 --> Utf8 Class Initialized
INFO - 2022-03-08 05:50:15 --> URI Class Initialized
INFO - 2022-03-08 05:50:15 --> Router Class Initialized
INFO - 2022-03-08 05:50:15 --> Output Class Initialized
INFO - 2022-03-08 05:50:15 --> Security Class Initialized
DEBUG - 2022-03-08 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:50:15 --> Input Class Initialized
INFO - 2022-03-08 05:50:15 --> Language Class Initialized
INFO - 2022-03-08 05:50:15 --> Loader Class Initialized
INFO - 2022-03-08 05:50:15 --> Helper loaded: url_helper
INFO - 2022-03-08 05:50:15 --> Helper loaded: form_helper
INFO - 2022-03-08 05:50:15 --> Helper loaded: common_helper
INFO - 2022-03-08 05:50:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:50:15 --> Controller Class Initialized
INFO - 2022-03-08 05:50:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:50:15 --> Encrypt Class Initialized
INFO - 2022-03-08 05:50:15 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:50:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:50:15 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:50:15 --> Model "Users_model" initialized
INFO - 2022-03-08 05:50:15 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:50:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:50:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 05:50:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:50:15 --> Final output sent to browser
DEBUG - 2022-03-08 05:50:15 --> Total execution time: 0.0766
ERROR - 2022-03-08 05:50:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:50:16 --> Config Class Initialized
INFO - 2022-03-08 05:50:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:50:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:50:16 --> Utf8 Class Initialized
INFO - 2022-03-08 05:50:16 --> URI Class Initialized
INFO - 2022-03-08 05:50:16 --> Router Class Initialized
INFO - 2022-03-08 05:50:16 --> Output Class Initialized
INFO - 2022-03-08 05:50:16 --> Security Class Initialized
DEBUG - 2022-03-08 05:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:50:16 --> Input Class Initialized
INFO - 2022-03-08 05:50:16 --> Language Class Initialized
ERROR - 2022-03-08 05:50:16 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 05:58:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:58:49 --> Config Class Initialized
INFO - 2022-03-08 05:58:49 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:58:49 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:58:49 --> Utf8 Class Initialized
INFO - 2022-03-08 05:58:49 --> URI Class Initialized
INFO - 2022-03-08 05:58:49 --> Router Class Initialized
INFO - 2022-03-08 05:58:49 --> Output Class Initialized
INFO - 2022-03-08 05:58:49 --> Security Class Initialized
DEBUG - 2022-03-08 05:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:58:49 --> Input Class Initialized
INFO - 2022-03-08 05:58:49 --> Language Class Initialized
INFO - 2022-03-08 05:58:49 --> Loader Class Initialized
INFO - 2022-03-08 05:58:49 --> Helper loaded: url_helper
INFO - 2022-03-08 05:58:49 --> Helper loaded: form_helper
INFO - 2022-03-08 05:58:49 --> Helper loaded: common_helper
INFO - 2022-03-08 05:58:49 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:58:49 --> Controller Class Initialized
INFO - 2022-03-08 05:58:49 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:58:49 --> Encrypt Class Initialized
INFO - 2022-03-08 05:58:49 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:58:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:58:49 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:58:49 --> Model "Users_model" initialized
INFO - 2022-03-08 05:58:49 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 05:58:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:58:50 --> Config Class Initialized
INFO - 2022-03-08 05:58:50 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:58:50 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:58:50 --> Utf8 Class Initialized
INFO - 2022-03-08 05:58:50 --> URI Class Initialized
INFO - 2022-03-08 05:58:50 --> Router Class Initialized
INFO - 2022-03-08 05:58:50 --> Output Class Initialized
INFO - 2022-03-08 05:58:50 --> Security Class Initialized
DEBUG - 2022-03-08 05:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:58:50 --> Input Class Initialized
INFO - 2022-03-08 05:58:50 --> Language Class Initialized
INFO - 2022-03-08 05:58:50 --> Loader Class Initialized
INFO - 2022-03-08 05:58:50 --> Helper loaded: url_helper
INFO - 2022-03-08 05:58:50 --> Helper loaded: form_helper
INFO - 2022-03-08 05:58:50 --> Helper loaded: common_helper
INFO - 2022-03-08 05:58:50 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:58:50 --> Controller Class Initialized
INFO - 2022-03-08 05:58:50 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:58:50 --> Encrypt Class Initialized
INFO - 2022-03-08 05:58:50 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:58:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:58:50 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:58:50 --> Model "Users_model" initialized
INFO - 2022-03-08 05:58:50 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:58:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:58:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 05:58:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:58:50 --> Final output sent to browser
DEBUG - 2022-03-08 05:58:50 --> Total execution time: 0.0718
ERROR - 2022-03-08 05:58:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:58:51 --> Config Class Initialized
INFO - 2022-03-08 05:58:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:58:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:58:51 --> Utf8 Class Initialized
INFO - 2022-03-08 05:58:51 --> URI Class Initialized
INFO - 2022-03-08 05:58:51 --> Router Class Initialized
INFO - 2022-03-08 05:58:51 --> Output Class Initialized
INFO - 2022-03-08 05:58:51 --> Security Class Initialized
DEBUG - 2022-03-08 05:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:58:51 --> Input Class Initialized
INFO - 2022-03-08 05:58:51 --> Language Class Initialized
ERROR - 2022-03-08 05:58:51 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 05:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:59:11 --> Config Class Initialized
INFO - 2022-03-08 05:59:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:59:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:59:11 --> Utf8 Class Initialized
INFO - 2022-03-08 05:59:11 --> URI Class Initialized
INFO - 2022-03-08 05:59:11 --> Router Class Initialized
INFO - 2022-03-08 05:59:11 --> Output Class Initialized
INFO - 2022-03-08 05:59:11 --> Security Class Initialized
DEBUG - 2022-03-08 05:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:59:11 --> Input Class Initialized
INFO - 2022-03-08 05:59:11 --> Language Class Initialized
INFO - 2022-03-08 05:59:11 --> Loader Class Initialized
INFO - 2022-03-08 05:59:11 --> Helper loaded: url_helper
INFO - 2022-03-08 05:59:11 --> Helper loaded: form_helper
INFO - 2022-03-08 05:59:11 --> Helper loaded: common_helper
INFO - 2022-03-08 05:59:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:59:11 --> Controller Class Initialized
INFO - 2022-03-08 05:59:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:59:11 --> Encrypt Class Initialized
INFO - 2022-03-08 05:59:11 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:59:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:59:11 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:59:11 --> Model "Users_model" initialized
INFO - 2022-03-08 05:59:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 05:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:59:11 --> Config Class Initialized
INFO - 2022-03-08 05:59:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:59:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:59:11 --> Utf8 Class Initialized
INFO - 2022-03-08 05:59:11 --> URI Class Initialized
INFO - 2022-03-08 05:59:11 --> Router Class Initialized
INFO - 2022-03-08 05:59:11 --> Output Class Initialized
INFO - 2022-03-08 05:59:11 --> Security Class Initialized
DEBUG - 2022-03-08 05:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:59:11 --> Input Class Initialized
INFO - 2022-03-08 05:59:11 --> Language Class Initialized
INFO - 2022-03-08 05:59:11 --> Loader Class Initialized
INFO - 2022-03-08 05:59:12 --> Helper loaded: url_helper
INFO - 2022-03-08 05:59:12 --> Helper loaded: form_helper
INFO - 2022-03-08 05:59:12 --> Helper loaded: common_helper
INFO - 2022-03-08 05:59:12 --> Database Driver Class Initialized
DEBUG - 2022-03-08 05:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 05:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 05:59:12 --> Controller Class Initialized
INFO - 2022-03-08 05:59:12 --> Form Validation Class Initialized
DEBUG - 2022-03-08 05:59:12 --> Encrypt Class Initialized
INFO - 2022-03-08 05:59:12 --> Model "Patient_model" initialized
INFO - 2022-03-08 05:59:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 05:59:12 --> Model "Prefix_master" initialized
INFO - 2022-03-08 05:59:12 --> Model "Users_model" initialized
INFO - 2022-03-08 05:59:12 --> Model "Hospital_model" initialized
INFO - 2022-03-08 05:59:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 05:59:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 05:59:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 05:59:12 --> Final output sent to browser
DEBUG - 2022-03-08 05:59:12 --> Total execution time: 0.0644
ERROR - 2022-03-08 05:59:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 05:59:12 --> Config Class Initialized
INFO - 2022-03-08 05:59:12 --> Hooks Class Initialized
DEBUG - 2022-03-08 05:59:12 --> UTF-8 Support Enabled
INFO - 2022-03-08 05:59:12 --> Utf8 Class Initialized
INFO - 2022-03-08 05:59:12 --> URI Class Initialized
INFO - 2022-03-08 05:59:12 --> Router Class Initialized
INFO - 2022-03-08 05:59:12 --> Output Class Initialized
INFO - 2022-03-08 05:59:12 --> Security Class Initialized
DEBUG - 2022-03-08 05:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 05:59:12 --> Input Class Initialized
INFO - 2022-03-08 05:59:12 --> Language Class Initialized
ERROR - 2022-03-08 05:59:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 06:02:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:02:18 --> Config Class Initialized
INFO - 2022-03-08 06:02:18 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:02:18 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:02:18 --> Utf8 Class Initialized
INFO - 2022-03-08 06:02:18 --> URI Class Initialized
INFO - 2022-03-08 06:02:18 --> Router Class Initialized
INFO - 2022-03-08 06:02:18 --> Output Class Initialized
INFO - 2022-03-08 06:02:18 --> Security Class Initialized
DEBUG - 2022-03-08 06:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:02:18 --> Input Class Initialized
INFO - 2022-03-08 06:02:18 --> Language Class Initialized
INFO - 2022-03-08 06:02:18 --> Loader Class Initialized
INFO - 2022-03-08 06:02:18 --> Helper loaded: url_helper
INFO - 2022-03-08 06:02:18 --> Helper loaded: form_helper
INFO - 2022-03-08 06:02:18 --> Helper loaded: common_helper
INFO - 2022-03-08 06:02:18 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:02:18 --> Controller Class Initialized
INFO - 2022-03-08 06:02:18 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:02:18 --> Encrypt Class Initialized
INFO - 2022-03-08 06:02:18 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:02:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:02:18 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:02:18 --> Model "Users_model" initialized
INFO - 2022-03-08 06:02:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 06:02:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:02:19 --> Config Class Initialized
INFO - 2022-03-08 06:02:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:02:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:02:19 --> Utf8 Class Initialized
INFO - 2022-03-08 06:02:19 --> URI Class Initialized
INFO - 2022-03-08 06:02:19 --> Router Class Initialized
INFO - 2022-03-08 06:02:19 --> Output Class Initialized
INFO - 2022-03-08 06:02:19 --> Security Class Initialized
DEBUG - 2022-03-08 06:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:02:19 --> Input Class Initialized
INFO - 2022-03-08 06:02:19 --> Language Class Initialized
INFO - 2022-03-08 06:02:19 --> Loader Class Initialized
INFO - 2022-03-08 06:02:19 --> Helper loaded: url_helper
INFO - 2022-03-08 06:02:19 --> Helper loaded: form_helper
INFO - 2022-03-08 06:02:19 --> Helper loaded: common_helper
INFO - 2022-03-08 06:02:19 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:02:19 --> Controller Class Initialized
INFO - 2022-03-08 06:02:19 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:02:19 --> Encrypt Class Initialized
INFO - 2022-03-08 06:02:19 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:02:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:02:19 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:02:19 --> Model "Users_model" initialized
INFO - 2022-03-08 06:02:19 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:02:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:02:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 06:02:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:02:19 --> Final output sent to browser
DEBUG - 2022-03-08 06:02:19 --> Total execution time: 0.1453
ERROR - 2022-03-08 06:06:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:06:13 --> Config Class Initialized
INFO - 2022-03-08 06:06:13 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:06:13 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:06:13 --> Utf8 Class Initialized
INFO - 2022-03-08 06:06:13 --> URI Class Initialized
INFO - 2022-03-08 06:06:13 --> Router Class Initialized
INFO - 2022-03-08 06:06:13 --> Output Class Initialized
INFO - 2022-03-08 06:06:13 --> Security Class Initialized
DEBUG - 2022-03-08 06:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:06:13 --> Input Class Initialized
INFO - 2022-03-08 06:06:13 --> Language Class Initialized
INFO - 2022-03-08 06:06:13 --> Loader Class Initialized
INFO - 2022-03-08 06:06:13 --> Helper loaded: url_helper
INFO - 2022-03-08 06:06:13 --> Helper loaded: form_helper
INFO - 2022-03-08 06:06:13 --> Helper loaded: common_helper
INFO - 2022-03-08 06:06:13 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:06:13 --> Controller Class Initialized
INFO - 2022-03-08 06:06:13 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:06:13 --> Encrypt Class Initialized
INFO - 2022-03-08 06:06:13 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:06:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:06:13 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:06:13 --> Model "Users_model" initialized
INFO - 2022-03-08 06:06:13 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 06:06:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:06:14 --> Config Class Initialized
INFO - 2022-03-08 06:06:14 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:06:14 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:06:14 --> Utf8 Class Initialized
INFO - 2022-03-08 06:06:14 --> URI Class Initialized
INFO - 2022-03-08 06:06:14 --> Router Class Initialized
INFO - 2022-03-08 06:06:14 --> Output Class Initialized
INFO - 2022-03-08 06:06:14 --> Security Class Initialized
DEBUG - 2022-03-08 06:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:06:14 --> Input Class Initialized
INFO - 2022-03-08 06:06:14 --> Language Class Initialized
INFO - 2022-03-08 06:06:14 --> Loader Class Initialized
INFO - 2022-03-08 06:06:14 --> Helper loaded: url_helper
INFO - 2022-03-08 06:06:14 --> Helper loaded: form_helper
INFO - 2022-03-08 06:06:14 --> Helper loaded: common_helper
INFO - 2022-03-08 06:06:14 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:06:14 --> Controller Class Initialized
INFO - 2022-03-08 06:06:14 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:06:14 --> Encrypt Class Initialized
INFO - 2022-03-08 06:06:14 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:06:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:06:14 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:06:14 --> Model "Users_model" initialized
INFO - 2022-03-08 06:06:14 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:06:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:06:14 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 06:06:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:06:14 --> Final output sent to browser
DEBUG - 2022-03-08 06:06:14 --> Total execution time: 0.0875
ERROR - 2022-03-08 06:06:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:06:14 --> Config Class Initialized
INFO - 2022-03-08 06:06:14 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:06:14 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:06:14 --> Utf8 Class Initialized
INFO - 2022-03-08 06:06:14 --> URI Class Initialized
INFO - 2022-03-08 06:06:14 --> Router Class Initialized
INFO - 2022-03-08 06:06:14 --> Output Class Initialized
INFO - 2022-03-08 06:06:14 --> Security Class Initialized
DEBUG - 2022-03-08 06:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:06:14 --> Input Class Initialized
INFO - 2022-03-08 06:06:14 --> Language Class Initialized
ERROR - 2022-03-08 06:06:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 06:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:06:22 --> Config Class Initialized
INFO - 2022-03-08 06:06:22 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:06:22 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:06:22 --> Utf8 Class Initialized
INFO - 2022-03-08 06:06:22 --> URI Class Initialized
INFO - 2022-03-08 06:06:22 --> Router Class Initialized
INFO - 2022-03-08 06:06:22 --> Output Class Initialized
INFO - 2022-03-08 06:06:22 --> Security Class Initialized
DEBUG - 2022-03-08 06:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:06:22 --> Input Class Initialized
INFO - 2022-03-08 06:06:22 --> Language Class Initialized
INFO - 2022-03-08 06:06:22 --> Loader Class Initialized
INFO - 2022-03-08 06:06:22 --> Helper loaded: url_helper
INFO - 2022-03-08 06:06:22 --> Helper loaded: form_helper
INFO - 2022-03-08 06:06:22 --> Helper loaded: common_helper
INFO - 2022-03-08 06:06:22 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:06:22 --> Controller Class Initialized
INFO - 2022-03-08 06:06:22 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:06:22 --> Encrypt Class Initialized
INFO - 2022-03-08 06:06:22 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:06:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:06:22 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:06:22 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:06:22 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:06:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:06:32 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 06:06:32 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 06:06:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:06:32 --> Config Class Initialized
INFO - 2022-03-08 06:06:32 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:06:32 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:06:32 --> Utf8 Class Initialized
INFO - 2022-03-08 06:06:32 --> URI Class Initialized
INFO - 2022-03-08 06:06:32 --> Router Class Initialized
INFO - 2022-03-08 06:06:32 --> Output Class Initialized
INFO - 2022-03-08 06:06:32 --> Security Class Initialized
DEBUG - 2022-03-08 06:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:06:32 --> Input Class Initialized
INFO - 2022-03-08 06:06:32 --> Language Class Initialized
INFO - 2022-03-08 06:06:32 --> Loader Class Initialized
INFO - 2022-03-08 06:06:32 --> Helper loaded: url_helper
INFO - 2022-03-08 06:06:32 --> Helper loaded: form_helper
INFO - 2022-03-08 06:06:32 --> Helper loaded: common_helper
INFO - 2022-03-08 06:06:32 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:06:32 --> Controller Class Initialized
INFO - 2022-03-08 06:06:32 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:06:32 --> Encrypt Class Initialized
INFO - 2022-03-08 06:06:32 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:06:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:06:32 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:06:32 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:06:32 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:06:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 06:06:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:06:37 --> Config Class Initialized
INFO - 2022-03-08 06:06:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:06:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:06:37 --> Utf8 Class Initialized
INFO - 2022-03-08 06:06:37 --> URI Class Initialized
INFO - 2022-03-08 06:06:37 --> Router Class Initialized
INFO - 2022-03-08 06:06:37 --> Output Class Initialized
INFO - 2022-03-08 06:06:37 --> Security Class Initialized
DEBUG - 2022-03-08 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:06:37 --> Input Class Initialized
INFO - 2022-03-08 06:06:37 --> Language Class Initialized
INFO - 2022-03-08 06:06:37 --> Loader Class Initialized
INFO - 2022-03-08 06:06:37 --> Helper loaded: url_helper
INFO - 2022-03-08 06:06:37 --> Helper loaded: form_helper
INFO - 2022-03-08 06:06:37 --> Helper loaded: common_helper
INFO - 2022-03-08 06:06:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:06:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 06:06:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:06:43 --> Controller Class Initialized
INFO - 2022-03-08 06:06:43 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:06:43 --> Encrypt Class Initialized
INFO - 2022-03-08 06:06:43 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:06:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:06:43 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:06:43 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:06:43 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:06:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 06:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:06:44 --> Config Class Initialized
INFO - 2022-03-08 06:06:44 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:06:44 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:06:44 --> Utf8 Class Initialized
INFO - 2022-03-08 06:06:44 --> URI Class Initialized
INFO - 2022-03-08 06:06:44 --> Router Class Initialized
INFO - 2022-03-08 06:06:44 --> Output Class Initialized
INFO - 2022-03-08 06:06:44 --> Security Class Initialized
DEBUG - 2022-03-08 06:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:06:44 --> Input Class Initialized
INFO - 2022-03-08 06:06:44 --> Language Class Initialized
INFO - 2022-03-08 06:06:44 --> Loader Class Initialized
INFO - 2022-03-08 06:06:44 --> Helper loaded: url_helper
INFO - 2022-03-08 06:06:44 --> Helper loaded: form_helper
INFO - 2022-03-08 06:06:44 --> Helper loaded: common_helper
INFO - 2022-03-08 06:06:44 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:06:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 06:06:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:06:52 --> Controller Class Initialized
INFO - 2022-03-08 06:06:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:06:52 --> Encrypt Class Initialized
INFO - 2022-03-08 06:06:52 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:06:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:06:52 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:06:52 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:06:52 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:06:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 06:06:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:06:53 --> Config Class Initialized
INFO - 2022-03-08 06:06:53 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:06:53 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:06:53 --> Utf8 Class Initialized
INFO - 2022-03-08 06:06:53 --> URI Class Initialized
INFO - 2022-03-08 06:06:53 --> Router Class Initialized
INFO - 2022-03-08 06:06:53 --> Output Class Initialized
INFO - 2022-03-08 06:06:53 --> Security Class Initialized
DEBUG - 2022-03-08 06:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:06:53 --> Input Class Initialized
INFO - 2022-03-08 06:06:53 --> Language Class Initialized
INFO - 2022-03-08 06:06:53 --> Loader Class Initialized
INFO - 2022-03-08 06:06:53 --> Helper loaded: url_helper
INFO - 2022-03-08 06:06:53 --> Helper loaded: form_helper
INFO - 2022-03-08 06:06:53 --> Helper loaded: common_helper
INFO - 2022-03-08 06:06:53 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:07:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 06:07:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:07:03 --> Controller Class Initialized
INFO - 2022-03-08 06:07:03 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:07:03 --> Encrypt Class Initialized
INFO - 2022-03-08 06:07:03 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:07:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:07:03 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:07:03 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:07:03 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:07:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:07:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 06:07:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 06:07:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:07:14 --> Config Class Initialized
INFO - 2022-03-08 06:07:14 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:07:14 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:07:14 --> Utf8 Class Initialized
INFO - 2022-03-08 06:07:14 --> URI Class Initialized
INFO - 2022-03-08 06:07:14 --> Router Class Initialized
INFO - 2022-03-08 06:07:14 --> Output Class Initialized
INFO - 2022-03-08 06:07:14 --> Security Class Initialized
DEBUG - 2022-03-08 06:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:07:14 --> Input Class Initialized
INFO - 2022-03-08 06:07:14 --> Language Class Initialized
ERROR - 2022-03-08 06:07:14 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 06:07:14 --> Final output sent to browser
DEBUG - 2022-03-08 06:07:14 --> Total execution time: 19.6248
ERROR - 2022-03-08 06:07:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:07:28 --> Config Class Initialized
INFO - 2022-03-08 06:07:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:07:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:07:28 --> Utf8 Class Initialized
INFO - 2022-03-08 06:07:28 --> URI Class Initialized
DEBUG - 2022-03-08 06:07:28 --> No URI present. Default controller set.
INFO - 2022-03-08 06:07:28 --> Router Class Initialized
INFO - 2022-03-08 06:07:28 --> Output Class Initialized
INFO - 2022-03-08 06:07:28 --> Security Class Initialized
DEBUG - 2022-03-08 06:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:07:28 --> Input Class Initialized
INFO - 2022-03-08 06:07:28 --> Language Class Initialized
INFO - 2022-03-08 06:07:28 --> Loader Class Initialized
INFO - 2022-03-08 06:07:28 --> Helper loaded: url_helper
INFO - 2022-03-08 06:07:28 --> Helper loaded: form_helper
INFO - 2022-03-08 06:07:28 --> Helper loaded: common_helper
INFO - 2022-03-08 06:07:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:07:28 --> Controller Class Initialized
INFO - 2022-03-08 06:07:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:07:28 --> Encrypt Class Initialized
DEBUG - 2022-03-08 06:07:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 06:07:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 06:07:28 --> Email Class Initialized
INFO - 2022-03-08 06:07:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 06:07:28 --> Calendar Class Initialized
INFO - 2022-03-08 06:07:28 --> Model "Login_model" initialized
ERROR - 2022-03-08 06:07:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:07:29 --> Config Class Initialized
INFO - 2022-03-08 06:07:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:07:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:07:29 --> Utf8 Class Initialized
INFO - 2022-03-08 06:07:29 --> URI Class Initialized
INFO - 2022-03-08 06:07:29 --> Router Class Initialized
INFO - 2022-03-08 06:07:29 --> Output Class Initialized
INFO - 2022-03-08 06:07:29 --> Security Class Initialized
DEBUG - 2022-03-08 06:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:07:29 --> Input Class Initialized
INFO - 2022-03-08 06:07:29 --> Language Class Initialized
INFO - 2022-03-08 06:07:29 --> Loader Class Initialized
INFO - 2022-03-08 06:07:29 --> Helper loaded: url_helper
INFO - 2022-03-08 06:07:29 --> Helper loaded: form_helper
INFO - 2022-03-08 06:07:29 --> Helper loaded: common_helper
INFO - 2022-03-08 06:07:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:07:29 --> Controller Class Initialized
INFO - 2022-03-08 06:07:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:07:29 --> Encrypt Class Initialized
INFO - 2022-03-08 06:07:29 --> Model "Diseases_model" initialized
INFO - 2022-03-08 06:07:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:07:29 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-08 06:07:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:07:29 --> Final output sent to browser
DEBUG - 2022-03-08 06:07:29 --> Total execution time: 0.0330
ERROR - 2022-03-08 06:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:07:30 --> Config Class Initialized
INFO - 2022-03-08 06:07:30 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:07:30 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:07:30 --> Utf8 Class Initialized
INFO - 2022-03-08 06:07:30 --> URI Class Initialized
INFO - 2022-03-08 06:07:30 --> Router Class Initialized
INFO - 2022-03-08 06:07:30 --> Output Class Initialized
INFO - 2022-03-08 06:07:30 --> Security Class Initialized
DEBUG - 2022-03-08 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:07:30 --> Input Class Initialized
INFO - 2022-03-08 06:07:30 --> Language Class Initialized
ERROR - 2022-03-08 06:07:30 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 06:07:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:07:33 --> Config Class Initialized
INFO - 2022-03-08 06:07:33 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:07:33 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:07:33 --> Utf8 Class Initialized
INFO - 2022-03-08 06:07:33 --> URI Class Initialized
INFO - 2022-03-08 06:07:33 --> Router Class Initialized
INFO - 2022-03-08 06:07:33 --> Output Class Initialized
INFO - 2022-03-08 06:07:33 --> Security Class Initialized
DEBUG - 2022-03-08 06:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:07:33 --> Input Class Initialized
INFO - 2022-03-08 06:07:33 --> Language Class Initialized
INFO - 2022-03-08 06:07:33 --> Loader Class Initialized
INFO - 2022-03-08 06:07:33 --> Helper loaded: url_helper
INFO - 2022-03-08 06:07:33 --> Helper loaded: form_helper
INFO - 2022-03-08 06:07:33 --> Helper loaded: common_helper
INFO - 2022-03-08 06:07:33 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:07:33 --> Controller Class Initialized
INFO - 2022-03-08 06:07:33 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:07:33 --> Encrypt Class Initialized
INFO - 2022-03-08 06:07:33 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:07:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:07:33 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:07:33 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:07:33 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:07:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:07:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 06:07:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 06:07:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:07:42 --> Config Class Initialized
INFO - 2022-03-08 06:07:42 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:07:42 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:07:42 --> Utf8 Class Initialized
INFO - 2022-03-08 06:07:42 --> URI Class Initialized
INFO - 2022-03-08 06:07:42 --> Router Class Initialized
INFO - 2022-03-08 06:07:42 --> Output Class Initialized
INFO - 2022-03-08 06:07:42 --> Security Class Initialized
DEBUG - 2022-03-08 06:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:07:42 --> Input Class Initialized
INFO - 2022-03-08 06:07:42 --> Language Class Initialized
ERROR - 2022-03-08 06:07:42 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 06:07:49 --> Final output sent to browser
DEBUG - 2022-03-08 06:07:49 --> Total execution time: 7.7371
ERROR - 2022-03-08 06:08:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:08:17 --> Config Class Initialized
INFO - 2022-03-08 06:08:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:08:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:08:17 --> Utf8 Class Initialized
INFO - 2022-03-08 06:08:17 --> URI Class Initialized
INFO - 2022-03-08 06:08:17 --> Router Class Initialized
INFO - 2022-03-08 06:08:17 --> Output Class Initialized
INFO - 2022-03-08 06:08:17 --> Security Class Initialized
DEBUG - 2022-03-08 06:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:08:17 --> Input Class Initialized
INFO - 2022-03-08 06:08:17 --> Language Class Initialized
INFO - 2022-03-08 06:08:17 --> Loader Class Initialized
INFO - 2022-03-08 06:08:17 --> Helper loaded: url_helper
INFO - 2022-03-08 06:08:17 --> Helper loaded: form_helper
INFO - 2022-03-08 06:08:17 --> Helper loaded: common_helper
INFO - 2022-03-08 06:08:17 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:08:17 --> Controller Class Initialized
INFO - 2022-03-08 06:08:17 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:08:17 --> Encrypt Class Initialized
INFO - 2022-03-08 06:08:17 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:08:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:08:17 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:08:17 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:08:17 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:08:17 --> Final output sent to browser
DEBUG - 2022-03-08 06:08:17 --> Total execution time: 0.0370
ERROR - 2022-03-08 06:08:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:08:49 --> Config Class Initialized
INFO - 2022-03-08 06:08:49 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:08:49 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:08:49 --> Utf8 Class Initialized
INFO - 2022-03-08 06:08:49 --> URI Class Initialized
INFO - 2022-03-08 06:08:49 --> Router Class Initialized
INFO - 2022-03-08 06:08:49 --> Output Class Initialized
INFO - 2022-03-08 06:08:49 --> Security Class Initialized
DEBUG - 2022-03-08 06:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:08:49 --> Input Class Initialized
INFO - 2022-03-08 06:08:49 --> Language Class Initialized
INFO - 2022-03-08 06:08:49 --> Loader Class Initialized
INFO - 2022-03-08 06:08:49 --> Helper loaded: url_helper
INFO - 2022-03-08 06:08:49 --> Helper loaded: form_helper
INFO - 2022-03-08 06:08:49 --> Helper loaded: common_helper
INFO - 2022-03-08 06:08:49 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:08:49 --> Controller Class Initialized
ERROR - 2022-03-08 06:08:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:08:50 --> Config Class Initialized
INFO - 2022-03-08 06:08:50 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:08:50 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:08:50 --> Utf8 Class Initialized
INFO - 2022-03-08 06:08:50 --> URI Class Initialized
INFO - 2022-03-08 06:08:50 --> Router Class Initialized
INFO - 2022-03-08 06:08:50 --> Output Class Initialized
INFO - 2022-03-08 06:08:50 --> Security Class Initialized
DEBUG - 2022-03-08 06:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:08:50 --> Input Class Initialized
INFO - 2022-03-08 06:08:50 --> Language Class Initialized
INFO - 2022-03-08 06:08:50 --> Loader Class Initialized
INFO - 2022-03-08 06:08:50 --> Helper loaded: url_helper
INFO - 2022-03-08 06:08:50 --> Helper loaded: form_helper
INFO - 2022-03-08 06:08:50 --> Helper loaded: common_helper
INFO - 2022-03-08 06:08:50 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:08:50 --> Controller Class Initialized
INFO - 2022-03-08 06:08:50 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:08:50 --> Encrypt Class Initialized
DEBUG - 2022-03-08 06:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 06:08:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 06:08:50 --> Email Class Initialized
INFO - 2022-03-08 06:08:50 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 06:08:50 --> Calendar Class Initialized
INFO - 2022-03-08 06:08:50 --> Model "Login_model" initialized
INFO - 2022-03-08 06:08:50 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 06:08:50 --> Final output sent to browser
DEBUG - 2022-03-08 06:08:50 --> Total execution time: 0.0431
ERROR - 2022-03-08 06:12:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:12:49 --> Config Class Initialized
INFO - 2022-03-08 06:12:49 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:12:49 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:12:49 --> Utf8 Class Initialized
INFO - 2022-03-08 06:12:49 --> URI Class Initialized
INFO - 2022-03-08 06:12:49 --> Router Class Initialized
INFO - 2022-03-08 06:12:49 --> Output Class Initialized
INFO - 2022-03-08 06:12:49 --> Security Class Initialized
DEBUG - 2022-03-08 06:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:12:49 --> Input Class Initialized
INFO - 2022-03-08 06:12:49 --> Language Class Initialized
INFO - 2022-03-08 06:12:49 --> Loader Class Initialized
INFO - 2022-03-08 06:12:49 --> Helper loaded: url_helper
INFO - 2022-03-08 06:12:49 --> Helper loaded: form_helper
INFO - 2022-03-08 06:12:49 --> Helper loaded: common_helper
INFO - 2022-03-08 06:12:49 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:12:49 --> Controller Class Initialized
INFO - 2022-03-08 06:12:49 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:12:49 --> Encrypt Class Initialized
DEBUG - 2022-03-08 06:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 06:12:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 06:12:49 --> Email Class Initialized
INFO - 2022-03-08 06:12:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 06:12:49 --> Calendar Class Initialized
INFO - 2022-03-08 06:12:49 --> Model "Login_model" initialized
INFO - 2022-03-08 06:12:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 06:12:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:12:49 --> Config Class Initialized
INFO - 2022-03-08 06:12:49 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:12:49 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:12:49 --> Utf8 Class Initialized
INFO - 2022-03-08 06:12:49 --> URI Class Initialized
INFO - 2022-03-08 06:12:49 --> Router Class Initialized
INFO - 2022-03-08 06:12:49 --> Output Class Initialized
INFO - 2022-03-08 06:12:49 --> Security Class Initialized
DEBUG - 2022-03-08 06:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:12:49 --> Input Class Initialized
INFO - 2022-03-08 06:12:49 --> Language Class Initialized
INFO - 2022-03-08 06:12:49 --> Loader Class Initialized
INFO - 2022-03-08 06:12:49 --> Helper loaded: url_helper
INFO - 2022-03-08 06:12:49 --> Helper loaded: form_helper
INFO - 2022-03-08 06:12:49 --> Helper loaded: common_helper
INFO - 2022-03-08 06:12:49 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:12:49 --> Controller Class Initialized
INFO - 2022-03-08 06:12:49 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:12:49 --> Encrypt Class Initialized
INFO - 2022-03-08 06:12:49 --> Model "Login_model" initialized
INFO - 2022-03-08 06:12:49 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 06:12:49 --> Model "Case_model" initialized
INFO - 2022-03-08 06:12:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:12:49 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 06:12:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:12:49 --> Final output sent to browser
DEBUG - 2022-03-08 06:12:49 --> Total execution time: 0.1508
ERROR - 2022-03-08 06:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:16:15 --> Config Class Initialized
INFO - 2022-03-08 06:16:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:16:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:16:15 --> Utf8 Class Initialized
INFO - 2022-03-08 06:16:15 --> URI Class Initialized
INFO - 2022-03-08 06:16:15 --> Router Class Initialized
INFO - 2022-03-08 06:16:15 --> Output Class Initialized
INFO - 2022-03-08 06:16:15 --> Security Class Initialized
DEBUG - 2022-03-08 06:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:16:15 --> Input Class Initialized
INFO - 2022-03-08 06:16:15 --> Language Class Initialized
INFO - 2022-03-08 06:16:15 --> Loader Class Initialized
INFO - 2022-03-08 06:16:15 --> Helper loaded: url_helper
INFO - 2022-03-08 06:16:15 --> Helper loaded: form_helper
INFO - 2022-03-08 06:16:15 --> Helper loaded: common_helper
INFO - 2022-03-08 06:16:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:16:15 --> Controller Class Initialized
INFO - 2022-03-08 06:16:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:16:15 --> Encrypt Class Initialized
INFO - 2022-03-08 06:16:15 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:16:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:16:15 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:16:15 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:16:15 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:16:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:16:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 06:16:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:16:15 --> Final output sent to browser
DEBUG - 2022-03-08 06:16:15 --> Total execution time: 0.0803
ERROR - 2022-03-08 06:28:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:28:23 --> Config Class Initialized
INFO - 2022-03-08 06:28:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:28:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:28:23 --> Utf8 Class Initialized
INFO - 2022-03-08 06:28:23 --> URI Class Initialized
INFO - 2022-03-08 06:28:23 --> Router Class Initialized
INFO - 2022-03-08 06:28:23 --> Output Class Initialized
INFO - 2022-03-08 06:28:23 --> Security Class Initialized
DEBUG - 2022-03-08 06:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:28:23 --> Input Class Initialized
INFO - 2022-03-08 06:28:23 --> Language Class Initialized
INFO - 2022-03-08 06:28:23 --> Loader Class Initialized
INFO - 2022-03-08 06:28:23 --> Helper loaded: url_helper
INFO - 2022-03-08 06:28:23 --> Helper loaded: form_helper
INFO - 2022-03-08 06:28:23 --> Helper loaded: common_helper
INFO - 2022-03-08 06:28:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:28:23 --> Controller Class Initialized
INFO - 2022-03-08 06:28:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:28:23 --> Encrypt Class Initialized
INFO - 2022-03-08 06:28:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:28:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:28:23 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:28:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:28:23 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:28:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:28:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 06:28:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:28:23 --> Final output sent to browser
DEBUG - 2022-03-08 06:28:23 --> Total execution time: 0.1317
ERROR - 2022-03-08 06:28:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:28:31 --> Config Class Initialized
INFO - 2022-03-08 06:28:31 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:28:31 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:28:31 --> Utf8 Class Initialized
INFO - 2022-03-08 06:28:31 --> URI Class Initialized
INFO - 2022-03-08 06:28:31 --> Router Class Initialized
INFO - 2022-03-08 06:28:31 --> Output Class Initialized
INFO - 2022-03-08 06:28:31 --> Security Class Initialized
DEBUG - 2022-03-08 06:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:28:31 --> Input Class Initialized
INFO - 2022-03-08 06:28:31 --> Language Class Initialized
INFO - 2022-03-08 06:28:31 --> Loader Class Initialized
INFO - 2022-03-08 06:28:31 --> Helper loaded: url_helper
INFO - 2022-03-08 06:28:31 --> Helper loaded: form_helper
INFO - 2022-03-08 06:28:31 --> Helper loaded: common_helper
INFO - 2022-03-08 06:28:31 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:28:31 --> Controller Class Initialized
INFO - 2022-03-08 06:28:31 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:28:31 --> Encrypt Class Initialized
INFO - 2022-03-08 06:28:31 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:28:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:28:31 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:28:31 --> Model "Users_model" initialized
INFO - 2022-03-08 06:28:31 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:28:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:28:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 06:28:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:28:31 --> Final output sent to browser
DEBUG - 2022-03-08 06:28:31 --> Total execution time: 0.0983
ERROR - 2022-03-08 06:29:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:29:03 --> Config Class Initialized
INFO - 2022-03-08 06:29:03 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:29:03 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:29:03 --> Utf8 Class Initialized
INFO - 2022-03-08 06:29:03 --> URI Class Initialized
INFO - 2022-03-08 06:29:03 --> Router Class Initialized
INFO - 2022-03-08 06:29:03 --> Output Class Initialized
INFO - 2022-03-08 06:29:03 --> Security Class Initialized
DEBUG - 2022-03-08 06:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:29:03 --> Input Class Initialized
INFO - 2022-03-08 06:29:03 --> Language Class Initialized
INFO - 2022-03-08 06:29:03 --> Loader Class Initialized
INFO - 2022-03-08 06:29:03 --> Helper loaded: url_helper
INFO - 2022-03-08 06:29:03 --> Helper loaded: form_helper
INFO - 2022-03-08 06:29:03 --> Helper loaded: common_helper
INFO - 2022-03-08 06:29:03 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:29:03 --> Controller Class Initialized
INFO - 2022-03-08 06:29:03 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:29:03 --> Encrypt Class Initialized
INFO - 2022-03-08 06:29:03 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:29:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:29:03 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:29:03 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:29:03 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:29:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:29:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 06:29:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:29:03 --> Final output sent to browser
DEBUG - 2022-03-08 06:29:03 --> Total execution time: 0.0744
ERROR - 2022-03-08 06:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:29:23 --> Config Class Initialized
INFO - 2022-03-08 06:29:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:29:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:29:23 --> Utf8 Class Initialized
INFO - 2022-03-08 06:29:23 --> URI Class Initialized
INFO - 2022-03-08 06:29:23 --> Router Class Initialized
INFO - 2022-03-08 06:29:23 --> Output Class Initialized
INFO - 2022-03-08 06:29:23 --> Security Class Initialized
DEBUG - 2022-03-08 06:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:29:23 --> Input Class Initialized
INFO - 2022-03-08 06:29:23 --> Language Class Initialized
INFO - 2022-03-08 06:29:23 --> Loader Class Initialized
INFO - 2022-03-08 06:29:23 --> Helper loaded: url_helper
INFO - 2022-03-08 06:29:23 --> Helper loaded: form_helper
INFO - 2022-03-08 06:29:23 --> Helper loaded: common_helper
INFO - 2022-03-08 06:29:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:29:23 --> Controller Class Initialized
INFO - 2022-03-08 06:29:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:29:23 --> Encrypt Class Initialized
INFO - 2022-03-08 06:29:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:29:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:29:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:29:23 --> Model "Users_model" initialized
INFO - 2022-03-08 06:29:23 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:29:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:29:23 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 06:29:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:29:23 --> Final output sent to browser
DEBUG - 2022-03-08 06:29:23 --> Total execution time: 0.0649
ERROR - 2022-03-08 06:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:30:03 --> Config Class Initialized
INFO - 2022-03-08 06:30:03 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:30:03 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:30:03 --> Utf8 Class Initialized
INFO - 2022-03-08 06:30:03 --> URI Class Initialized
INFO - 2022-03-08 06:30:03 --> Router Class Initialized
INFO - 2022-03-08 06:30:03 --> Output Class Initialized
INFO - 2022-03-08 06:30:03 --> Security Class Initialized
DEBUG - 2022-03-08 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:30:03 --> Input Class Initialized
INFO - 2022-03-08 06:30:03 --> Language Class Initialized
INFO - 2022-03-08 06:30:03 --> Loader Class Initialized
INFO - 2022-03-08 06:30:03 --> Helper loaded: url_helper
INFO - 2022-03-08 06:30:03 --> Helper loaded: form_helper
INFO - 2022-03-08 06:30:03 --> Helper loaded: common_helper
INFO - 2022-03-08 06:30:03 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:30:03 --> Controller Class Initialized
INFO - 2022-03-08 06:30:03 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:30:03 --> Encrypt Class Initialized
INFO - 2022-03-08 06:30:03 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:30:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:30:03 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:30:03 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:30:03 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:30:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:30:03 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 06:30:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:30:03 --> Final output sent to browser
DEBUG - 2022-03-08 06:30:03 --> Total execution time: 0.0604
ERROR - 2022-03-08 06:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:31:12 --> Config Class Initialized
INFO - 2022-03-08 06:31:12 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:31:12 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:31:12 --> Utf8 Class Initialized
INFO - 2022-03-08 06:31:12 --> URI Class Initialized
INFO - 2022-03-08 06:31:12 --> Router Class Initialized
INFO - 2022-03-08 06:31:12 --> Output Class Initialized
INFO - 2022-03-08 06:31:12 --> Security Class Initialized
DEBUG - 2022-03-08 06:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:31:12 --> Input Class Initialized
INFO - 2022-03-08 06:31:12 --> Language Class Initialized
INFO - 2022-03-08 06:31:12 --> Loader Class Initialized
INFO - 2022-03-08 06:31:12 --> Helper loaded: url_helper
INFO - 2022-03-08 06:31:12 --> Helper loaded: form_helper
INFO - 2022-03-08 06:31:12 --> Helper loaded: common_helper
INFO - 2022-03-08 06:31:12 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:31:12 --> Controller Class Initialized
INFO - 2022-03-08 06:31:12 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:31:12 --> Encrypt Class Initialized
INFO - 2022-03-08 06:31:12 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:31:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:31:12 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:31:12 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:31:12 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:31:12 --> Upload Class Initialized
INFO - 2022-03-08 06:31:12 --> Final output sent to browser
DEBUG - 2022-03-08 06:31:12 --> Total execution time: 0.0268
ERROR - 2022-03-08 06:31:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:31:45 --> Config Class Initialized
INFO - 2022-03-08 06:31:45 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:31:45 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:31:45 --> Utf8 Class Initialized
INFO - 2022-03-08 06:31:45 --> URI Class Initialized
INFO - 2022-03-08 06:31:45 --> Router Class Initialized
INFO - 2022-03-08 06:31:45 --> Output Class Initialized
INFO - 2022-03-08 06:31:45 --> Security Class Initialized
DEBUG - 2022-03-08 06:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:31:45 --> Input Class Initialized
INFO - 2022-03-08 06:31:45 --> Language Class Initialized
INFO - 2022-03-08 06:31:45 --> Loader Class Initialized
INFO - 2022-03-08 06:31:45 --> Helper loaded: url_helper
INFO - 2022-03-08 06:31:45 --> Helper loaded: form_helper
INFO - 2022-03-08 06:31:45 --> Helper loaded: common_helper
INFO - 2022-03-08 06:31:45 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:31:45 --> Controller Class Initialized
INFO - 2022-03-08 06:31:45 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:31:45 --> Encrypt Class Initialized
INFO - 2022-03-08 06:31:45 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:31:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:31:45 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:31:45 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:31:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 06:31:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:31:46 --> Config Class Initialized
INFO - 2022-03-08 06:31:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:31:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:31:46 --> Utf8 Class Initialized
INFO - 2022-03-08 06:31:46 --> URI Class Initialized
INFO - 2022-03-08 06:31:46 --> Router Class Initialized
INFO - 2022-03-08 06:31:46 --> Output Class Initialized
INFO - 2022-03-08 06:31:46 --> Security Class Initialized
DEBUG - 2022-03-08 06:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:31:46 --> Input Class Initialized
INFO - 2022-03-08 06:31:46 --> Language Class Initialized
INFO - 2022-03-08 06:31:46 --> Loader Class Initialized
INFO - 2022-03-08 06:31:46 --> Helper loaded: url_helper
INFO - 2022-03-08 06:31:46 --> Helper loaded: form_helper
INFO - 2022-03-08 06:31:46 --> Helper loaded: common_helper
INFO - 2022-03-08 06:31:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:31:46 --> Controller Class Initialized
INFO - 2022-03-08 06:31:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:31:46 --> Encrypt Class Initialized
INFO - 2022-03-08 06:31:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:31:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:31:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 06:31:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:31:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:31:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:31:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 06:31:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:31:46 --> Final output sent to browser
DEBUG - 2022-03-08 06:31:46 --> Total execution time: 0.0529
ERROR - 2022-03-08 06:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:31:47 --> Config Class Initialized
INFO - 2022-03-08 06:31:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:31:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:31:47 --> Utf8 Class Initialized
INFO - 2022-03-08 06:31:47 --> URI Class Initialized
INFO - 2022-03-08 06:31:47 --> Router Class Initialized
INFO - 2022-03-08 06:31:47 --> Output Class Initialized
INFO - 2022-03-08 06:31:47 --> Security Class Initialized
DEBUG - 2022-03-08 06:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:31:47 --> Input Class Initialized
INFO - 2022-03-08 06:31:47 --> Language Class Initialized
INFO - 2022-03-08 06:31:47 --> Loader Class Initialized
INFO - 2022-03-08 06:31:47 --> Helper loaded: url_helper
INFO - 2022-03-08 06:31:47 --> Helper loaded: form_helper
INFO - 2022-03-08 06:31:47 --> Helper loaded: common_helper
INFO - 2022-03-08 06:31:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:31:47 --> Controller Class Initialized
INFO - 2022-03-08 06:31:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:31:47 --> Encrypt Class Initialized
INFO - 2022-03-08 06:31:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:31:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:31:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:31:47 --> Model "Users_model" initialized
INFO - 2022-03-08 06:31:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:31:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:31:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 06:31:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:31:47 --> Final output sent to browser
DEBUG - 2022-03-08 06:31:47 --> Total execution time: 0.0937
ERROR - 2022-03-08 06:33:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:33:13 --> Config Class Initialized
INFO - 2022-03-08 06:33:13 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:33:13 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:33:13 --> Utf8 Class Initialized
INFO - 2022-03-08 06:33:13 --> URI Class Initialized
INFO - 2022-03-08 06:33:13 --> Router Class Initialized
INFO - 2022-03-08 06:33:13 --> Output Class Initialized
INFO - 2022-03-08 06:33:13 --> Security Class Initialized
DEBUG - 2022-03-08 06:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:33:13 --> Input Class Initialized
INFO - 2022-03-08 06:33:13 --> Language Class Initialized
INFO - 2022-03-08 06:33:13 --> Loader Class Initialized
INFO - 2022-03-08 06:33:13 --> Helper loaded: url_helper
INFO - 2022-03-08 06:33:13 --> Helper loaded: form_helper
INFO - 2022-03-08 06:33:13 --> Helper loaded: common_helper
INFO - 2022-03-08 06:33:14 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:33:14 --> Controller Class Initialized
INFO - 2022-03-08 06:33:14 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:33:14 --> Encrypt Class Initialized
INFO - 2022-03-08 06:33:14 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:33:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:33:14 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:33:14 --> Model "Users_model" initialized
INFO - 2022-03-08 06:33:14 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:33:14 --> Upload Class Initialized
INFO - 2022-03-08 06:33:14 --> Final output sent to browser
DEBUG - 2022-03-08 06:33:14 --> Total execution time: 0.0730
ERROR - 2022-03-08 06:33:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:33:18 --> Config Class Initialized
INFO - 2022-03-08 06:33:18 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:33:18 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:33:18 --> Utf8 Class Initialized
INFO - 2022-03-08 06:33:18 --> URI Class Initialized
INFO - 2022-03-08 06:33:18 --> Router Class Initialized
INFO - 2022-03-08 06:33:18 --> Output Class Initialized
INFO - 2022-03-08 06:33:18 --> Security Class Initialized
DEBUG - 2022-03-08 06:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:33:18 --> Input Class Initialized
INFO - 2022-03-08 06:33:18 --> Language Class Initialized
INFO - 2022-03-08 06:33:18 --> Loader Class Initialized
INFO - 2022-03-08 06:33:18 --> Helper loaded: url_helper
INFO - 2022-03-08 06:33:18 --> Helper loaded: form_helper
INFO - 2022-03-08 06:33:18 --> Helper loaded: common_helper
INFO - 2022-03-08 06:33:18 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:33:18 --> Controller Class Initialized
INFO - 2022-03-08 06:33:18 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:33:18 --> Encrypt Class Initialized
INFO - 2022-03-08 06:33:18 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:33:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:33:18 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:33:18 --> Model "Users_model" initialized
INFO - 2022-03-08 06:33:18 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 06:33:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 06:33:19 --> Config Class Initialized
INFO - 2022-03-08 06:33:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 06:33:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 06:33:19 --> Utf8 Class Initialized
INFO - 2022-03-08 06:33:19 --> URI Class Initialized
INFO - 2022-03-08 06:33:19 --> Router Class Initialized
INFO - 2022-03-08 06:33:19 --> Output Class Initialized
INFO - 2022-03-08 06:33:19 --> Security Class Initialized
DEBUG - 2022-03-08 06:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 06:33:19 --> Input Class Initialized
INFO - 2022-03-08 06:33:19 --> Language Class Initialized
INFO - 2022-03-08 06:33:19 --> Loader Class Initialized
INFO - 2022-03-08 06:33:19 --> Helper loaded: url_helper
INFO - 2022-03-08 06:33:19 --> Helper loaded: form_helper
INFO - 2022-03-08 06:33:19 --> Helper loaded: common_helper
INFO - 2022-03-08 06:33:19 --> Database Driver Class Initialized
DEBUG - 2022-03-08 06:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 06:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 06:33:19 --> Controller Class Initialized
INFO - 2022-03-08 06:33:19 --> Form Validation Class Initialized
DEBUG - 2022-03-08 06:33:19 --> Encrypt Class Initialized
INFO - 2022-03-08 06:33:19 --> Model "Patient_model" initialized
INFO - 2022-03-08 06:33:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 06:33:19 --> Model "Prefix_master" initialized
INFO - 2022-03-08 06:33:19 --> Model "Users_model" initialized
INFO - 2022-03-08 06:33:19 --> Model "Hospital_model" initialized
INFO - 2022-03-08 06:33:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 06:33:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 06:33:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 06:33:19 --> Final output sent to browser
DEBUG - 2022-03-08 06:33:19 --> Total execution time: 0.0896
ERROR - 2022-03-08 09:21:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 09:21:16 --> Config Class Initialized
INFO - 2022-03-08 09:21:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 09:21:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 09:21:16 --> Utf8 Class Initialized
INFO - 2022-03-08 09:21:16 --> URI Class Initialized
DEBUG - 2022-03-08 09:21:16 --> No URI present. Default controller set.
INFO - 2022-03-08 09:21:16 --> Router Class Initialized
INFO - 2022-03-08 09:21:16 --> Output Class Initialized
INFO - 2022-03-08 09:21:16 --> Security Class Initialized
DEBUG - 2022-03-08 09:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 09:21:16 --> Input Class Initialized
INFO - 2022-03-08 09:21:16 --> Language Class Initialized
INFO - 2022-03-08 09:21:16 --> Loader Class Initialized
INFO - 2022-03-08 09:21:16 --> Helper loaded: url_helper
INFO - 2022-03-08 09:21:16 --> Helper loaded: form_helper
INFO - 2022-03-08 09:21:16 --> Helper loaded: common_helper
INFO - 2022-03-08 09:21:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 09:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 09:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 09:21:16 --> Controller Class Initialized
INFO - 2022-03-08 09:21:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 09:21:16 --> Encrypt Class Initialized
DEBUG - 2022-03-08 09:21:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 09:21:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 09:21:16 --> Email Class Initialized
INFO - 2022-03-08 09:21:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 09:21:16 --> Calendar Class Initialized
INFO - 2022-03-08 09:21:16 --> Model "Login_model" initialized
INFO - 2022-03-08 09:21:16 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 09:21:16 --> Final output sent to browser
DEBUG - 2022-03-08 09:21:16 --> Total execution time: 0.0747
ERROR - 2022-03-08 09:21:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 09:21:17 --> Config Class Initialized
INFO - 2022-03-08 09:21:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 09:21:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 09:21:17 --> Utf8 Class Initialized
INFO - 2022-03-08 09:21:17 --> URI Class Initialized
DEBUG - 2022-03-08 09:21:17 --> No URI present. Default controller set.
INFO - 2022-03-08 09:21:17 --> Router Class Initialized
INFO - 2022-03-08 09:21:17 --> Output Class Initialized
INFO - 2022-03-08 09:21:17 --> Security Class Initialized
DEBUG - 2022-03-08 09:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 09:21:17 --> Input Class Initialized
INFO - 2022-03-08 09:21:17 --> Language Class Initialized
INFO - 2022-03-08 09:21:17 --> Loader Class Initialized
INFO - 2022-03-08 09:21:17 --> Helper loaded: url_helper
INFO - 2022-03-08 09:21:17 --> Helper loaded: form_helper
INFO - 2022-03-08 09:21:17 --> Helper loaded: common_helper
INFO - 2022-03-08 09:21:17 --> Database Driver Class Initialized
DEBUG - 2022-03-08 09:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 09:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 09:21:17 --> Controller Class Initialized
INFO - 2022-03-08 09:21:17 --> Form Validation Class Initialized
DEBUG - 2022-03-08 09:21:17 --> Encrypt Class Initialized
DEBUG - 2022-03-08 09:21:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 09:21:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 09:21:17 --> Email Class Initialized
INFO - 2022-03-08 09:21:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 09:21:17 --> Calendar Class Initialized
INFO - 2022-03-08 09:21:17 --> Model "Login_model" initialized
INFO - 2022-03-08 09:21:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 09:21:17 --> Final output sent to browser
DEBUG - 2022-03-08 09:21:17 --> Total execution time: 0.0205
ERROR - 2022-03-08 11:41:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:19 --> Config Class Initialized
INFO - 2022-03-08 11:41:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:19 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:19 --> URI Class Initialized
INFO - 2022-03-08 11:41:19 --> Router Class Initialized
INFO - 2022-03-08 11:41:19 --> Output Class Initialized
INFO - 2022-03-08 11:41:19 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:19 --> Input Class Initialized
INFO - 2022-03-08 11:41:19 --> Language Class Initialized
ERROR - 2022-03-08 11:41:19 --> 404 Page Not Found: %20-%20env/index
ERROR - 2022-03-08 11:41:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:20 --> Config Class Initialized
INFO - 2022-03-08 11:41:20 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:20 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:20 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:20 --> URI Class Initialized
INFO - 2022-03-08 11:41:20 --> Router Class Initialized
INFO - 2022-03-08 11:41:20 --> Output Class Initialized
INFO - 2022-03-08 11:41:20 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:20 --> Input Class Initialized
INFO - 2022-03-08 11:41:20 --> Language Class Initialized
ERROR - 2022-03-08 11:41:20 --> 404 Page Not Found: %20-%20Copyenv/index
ERROR - 2022-03-08 11:41:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:21 --> Config Class Initialized
INFO - 2022-03-08 11:41:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:21 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:21 --> URI Class Initialized
INFO - 2022-03-08 11:41:21 --> Router Class Initialized
INFO - 2022-03-08 11:41:21 --> Output Class Initialized
INFO - 2022-03-08 11:41:21 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:21 --> Input Class Initialized
INFO - 2022-03-08 11:41:21 --> Language Class Initialized
ERROR - 2022-03-08 11:41:21 --> 404 Page Not Found: %21env/index
ERROR - 2022-03-08 11:41:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:21 --> Config Class Initialized
INFO - 2022-03-08 11:41:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:21 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:21 --> URI Class Initialized
INFO - 2022-03-08 11:41:21 --> Router Class Initialized
INFO - 2022-03-08 11:41:21 --> Output Class Initialized
INFO - 2022-03-08 11:41:21 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:21 --> Input Class Initialized
INFO - 2022-03-08 11:41:21 --> Language Class Initialized
ERROR - 2022-03-08 11:41:21 --> 404 Page Not Found: -%20Copyenv/index
ERROR - 2022-03-08 11:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:22 --> Config Class Initialized
INFO - 2022-03-08 11:41:22 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:22 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:22 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:22 --> URI Class Initialized
INFO - 2022-03-08 11:41:22 --> Router Class Initialized
INFO - 2022-03-08 11:41:22 --> Output Class Initialized
INFO - 2022-03-08 11:41:22 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:22 --> Input Class Initialized
INFO - 2022-03-08 11:41:22 --> Language Class Initialized
ERROR - 2022-03-08 11:41:22 --> 404 Page Not Found: Config/app.php
ERROR - 2022-03-08 11:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:22 --> Config Class Initialized
INFO - 2022-03-08 11:41:22 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:22 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:22 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:22 --> URI Class Initialized
INFO - 2022-03-08 11:41:22 --> Router Class Initialized
INFO - 2022-03-08 11:41:22 --> Output Class Initialized
INFO - 2022-03-08 11:41:22 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:22 --> Input Class Initialized
INFO - 2022-03-08 11:41:22 --> Language Class Initialized
ERROR - 2022-03-08 11:41:22 --> 404 Page Not Found: App/config
ERROR - 2022-03-08 11:41:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:23 --> Config Class Initialized
INFO - 2022-03-08 11:41:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:23 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:23 --> URI Class Initialized
INFO - 2022-03-08 11:41:23 --> Router Class Initialized
INFO - 2022-03-08 11:41:23 --> Output Class Initialized
INFO - 2022-03-08 11:41:23 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:23 --> Input Class Initialized
INFO - 2022-03-08 11:41:23 --> Language Class Initialized
ERROR - 2022-03-08 11:41:23 --> 404 Page Not Found: App/parameters.yml
ERROR - 2022-03-08 11:41:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:24 --> Config Class Initialized
INFO - 2022-03-08 11:41:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:24 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:24 --> URI Class Initialized
INFO - 2022-03-08 11:41:24 --> Router Class Initialized
INFO - 2022-03-08 11:41:24 --> Output Class Initialized
INFO - 2022-03-08 11:41:24 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:24 --> Input Class Initialized
INFO - 2022-03-08 11:41:24 --> Language Class Initialized
ERROR - 2022-03-08 11:41:24 --> 404 Page Not Found: Config/app.php
ERROR - 2022-03-08 11:41:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:24 --> Config Class Initialized
INFO - 2022-03-08 11:41:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:24 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:24 --> URI Class Initialized
INFO - 2022-03-08 11:41:24 --> Router Class Initialized
INFO - 2022-03-08 11:41:24 --> Output Class Initialized
INFO - 2022-03-08 11:41:24 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:24 --> Input Class Initialized
INFO - 2022-03-08 11:41:24 --> Language Class Initialized
ERROR - 2022-03-08 11:41:24 --> 404 Page Not Found: Config/parameters.yml
ERROR - 2022-03-08 11:41:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:24 --> Config Class Initialized
INFO - 2022-03-08 11:41:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:24 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:24 --> URI Class Initialized
INFO - 2022-03-08 11:41:24 --> Router Class Initialized
INFO - 2022-03-08 11:41:24 --> Output Class Initialized
INFO - 2022-03-08 11:41:24 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:24 --> Input Class Initialized
INFO - 2022-03-08 11:41:24 --> Language Class Initialized
ERROR - 2022-03-08 11:41:24 --> 404 Page Not Found: Copyenv/index
ERROR - 2022-03-08 11:41:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:25 --> Config Class Initialized
INFO - 2022-03-08 11:41:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:25 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:25 --> URI Class Initialized
INFO - 2022-03-08 11:41:25 --> Router Class Initialized
INFO - 2022-03-08 11:41:25 --> Output Class Initialized
INFO - 2022-03-08 11:41:25 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:25 --> Input Class Initialized
INFO - 2022-03-08 11:41:25 --> Language Class Initialized
ERROR - 2022-03-08 11:41:25 --> 404 Page Not Found: Maintenances/index
ERROR - 2022-03-08 11:41:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 11:41:25 --> Config Class Initialized
INFO - 2022-03-08 11:41:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 11:41:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 11:41:25 --> Utf8 Class Initialized
INFO - 2022-03-08 11:41:25 --> URI Class Initialized
INFO - 2022-03-08 11:41:25 --> Router Class Initialized
INFO - 2022-03-08 11:41:25 --> Output Class Initialized
INFO - 2022-03-08 11:41:25 --> Security Class Initialized
DEBUG - 2022-03-08 11:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 11:41:25 --> Input Class Initialized
INFO - 2022-03-08 11:41:25 --> Language Class Initialized
ERROR - 2022-03-08 11:41:25 --> 404 Page Not Found: Parametersyml/index
ERROR - 2022-03-08 12:24:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 12:24:25 --> Config Class Initialized
INFO - 2022-03-08 12:24:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 12:24:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 12:24:25 --> Utf8 Class Initialized
INFO - 2022-03-08 12:24:25 --> URI Class Initialized
DEBUG - 2022-03-08 12:24:25 --> No URI present. Default controller set.
INFO - 2022-03-08 12:24:25 --> Router Class Initialized
INFO - 2022-03-08 12:24:25 --> Output Class Initialized
INFO - 2022-03-08 12:24:25 --> Security Class Initialized
DEBUG - 2022-03-08 12:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 12:24:25 --> Input Class Initialized
INFO - 2022-03-08 12:24:25 --> Language Class Initialized
INFO - 2022-03-08 12:24:25 --> Loader Class Initialized
INFO - 2022-03-08 12:24:25 --> Helper loaded: url_helper
INFO - 2022-03-08 12:24:25 --> Helper loaded: form_helper
INFO - 2022-03-08 12:24:25 --> Helper loaded: common_helper
INFO - 2022-03-08 12:24:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 12:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 12:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 12:24:25 --> Controller Class Initialized
INFO - 2022-03-08 12:24:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 12:24:25 --> Encrypt Class Initialized
DEBUG - 2022-03-08 12:24:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:24:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 12:24:25 --> Email Class Initialized
INFO - 2022-03-08 12:24:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 12:24:25 --> Calendar Class Initialized
INFO - 2022-03-08 12:24:25 --> Model "Login_model" initialized
INFO - 2022-03-08 12:24:25 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 12:24:25 --> Final output sent to browser
DEBUG - 2022-03-08 12:24:25 --> Total execution time: 0.0359
ERROR - 2022-03-08 14:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 14:17:07 --> Config Class Initialized
INFO - 2022-03-08 14:17:07 --> Hooks Class Initialized
DEBUG - 2022-03-08 14:17:07 --> UTF-8 Support Enabled
INFO - 2022-03-08 14:17:07 --> Utf8 Class Initialized
INFO - 2022-03-08 14:17:07 --> URI Class Initialized
DEBUG - 2022-03-08 14:17:07 --> No URI present. Default controller set.
INFO - 2022-03-08 14:17:07 --> Router Class Initialized
INFO - 2022-03-08 14:17:07 --> Output Class Initialized
INFO - 2022-03-08 14:17:07 --> Security Class Initialized
DEBUG - 2022-03-08 14:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 14:17:07 --> Input Class Initialized
INFO - 2022-03-08 14:17:07 --> Language Class Initialized
INFO - 2022-03-08 14:17:07 --> Loader Class Initialized
INFO - 2022-03-08 14:17:07 --> Helper loaded: url_helper
INFO - 2022-03-08 14:17:07 --> Helper loaded: form_helper
INFO - 2022-03-08 14:17:07 --> Helper loaded: common_helper
INFO - 2022-03-08 14:17:07 --> Database Driver Class Initialized
DEBUG - 2022-03-08 14:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 14:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 14:17:07 --> Controller Class Initialized
INFO - 2022-03-08 14:17:07 --> Form Validation Class Initialized
DEBUG - 2022-03-08 14:17:07 --> Encrypt Class Initialized
DEBUG - 2022-03-08 14:17:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:17:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 14:17:07 --> Email Class Initialized
INFO - 2022-03-08 14:17:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 14:17:07 --> Calendar Class Initialized
INFO - 2022-03-08 14:17:07 --> Model "Login_model" initialized
INFO - 2022-03-08 14:17:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 14:17:07 --> Final output sent to browser
DEBUG - 2022-03-08 14:17:07 --> Total execution time: 0.0240
ERROR - 2022-03-08 14:17:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 14:17:10 --> Config Class Initialized
INFO - 2022-03-08 14:17:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 14:17:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 14:17:10 --> Utf8 Class Initialized
INFO - 2022-03-08 14:17:10 --> URI Class Initialized
INFO - 2022-03-08 14:17:10 --> Router Class Initialized
INFO - 2022-03-08 14:17:10 --> Output Class Initialized
INFO - 2022-03-08 14:17:10 --> Security Class Initialized
DEBUG - 2022-03-08 14:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 14:17:10 --> Input Class Initialized
INFO - 2022-03-08 14:17:10 --> Language Class Initialized
ERROR - 2022-03-08 14:17:10 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-08 14:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 14:18:43 --> Config Class Initialized
INFO - 2022-03-08 14:18:43 --> Hooks Class Initialized
DEBUG - 2022-03-08 14:18:43 --> UTF-8 Support Enabled
INFO - 2022-03-08 14:18:43 --> Utf8 Class Initialized
INFO - 2022-03-08 14:18:43 --> URI Class Initialized
INFO - 2022-03-08 14:18:43 --> Router Class Initialized
INFO - 2022-03-08 14:18:43 --> Output Class Initialized
INFO - 2022-03-08 14:18:43 --> Security Class Initialized
DEBUG - 2022-03-08 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 14:18:43 --> Input Class Initialized
INFO - 2022-03-08 14:18:43 --> Language Class Initialized
INFO - 2022-03-08 14:18:43 --> Loader Class Initialized
INFO - 2022-03-08 14:18:43 --> Helper loaded: url_helper
INFO - 2022-03-08 14:18:43 --> Helper loaded: form_helper
INFO - 2022-03-08 14:18:43 --> Helper loaded: common_helper
INFO - 2022-03-08 14:18:43 --> Database Driver Class Initialized
DEBUG - 2022-03-08 14:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 14:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 14:18:43 --> Controller Class Initialized
INFO - 2022-03-08 14:18:43 --> Form Validation Class Initialized
DEBUG - 2022-03-08 14:18:43 --> Encrypt Class Initialized
DEBUG - 2022-03-08 14:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 14:18:43 --> Email Class Initialized
INFO - 2022-03-08 14:18:43 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 14:18:43 --> Calendar Class Initialized
INFO - 2022-03-08 14:18:43 --> Model "Login_model" initialized
INFO - 2022-03-08 14:18:43 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 14:18:43 --> Final output sent to browser
DEBUG - 2022-03-08 14:18:43 --> Total execution time: 0.0447
ERROR - 2022-03-08 14:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 14:18:43 --> Config Class Initialized
INFO - 2022-03-08 14:18:43 --> Hooks Class Initialized
DEBUG - 2022-03-08 14:18:43 --> UTF-8 Support Enabled
INFO - 2022-03-08 14:18:43 --> Utf8 Class Initialized
INFO - 2022-03-08 14:18:43 --> URI Class Initialized
DEBUG - 2022-03-08 14:18:43 --> No URI present. Default controller set.
INFO - 2022-03-08 14:18:43 --> Router Class Initialized
INFO - 2022-03-08 14:18:43 --> Output Class Initialized
INFO - 2022-03-08 14:18:43 --> Security Class Initialized
DEBUG - 2022-03-08 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 14:18:43 --> Input Class Initialized
INFO - 2022-03-08 14:18:43 --> Language Class Initialized
INFO - 2022-03-08 14:18:44 --> Loader Class Initialized
INFO - 2022-03-08 14:18:44 --> Helper loaded: url_helper
INFO - 2022-03-08 14:18:44 --> Helper loaded: form_helper
INFO - 2022-03-08 14:18:44 --> Helper loaded: common_helper
INFO - 2022-03-08 14:18:44 --> Database Driver Class Initialized
DEBUG - 2022-03-08 14:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 14:18:44 --> Controller Class Initialized
INFO - 2022-03-08 14:18:44 --> Form Validation Class Initialized
DEBUG - 2022-03-08 14:18:44 --> Encrypt Class Initialized
DEBUG - 2022-03-08 14:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 14:18:44 --> Email Class Initialized
INFO - 2022-03-08 14:18:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 14:18:44 --> Calendar Class Initialized
INFO - 2022-03-08 14:18:44 --> Model "Login_model" initialized
INFO - 2022-03-08 14:18:44 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 14:18:44 --> Final output sent to browser
DEBUG - 2022-03-08 14:18:44 --> Total execution time: 0.0344
ERROR - 2022-03-08 14:18:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 14:18:44 --> Config Class Initialized
INFO - 2022-03-08 14:18:44 --> Hooks Class Initialized
DEBUG - 2022-03-08 14:18:44 --> UTF-8 Support Enabled
INFO - 2022-03-08 14:18:44 --> Utf8 Class Initialized
INFO - 2022-03-08 14:18:44 --> URI Class Initialized
INFO - 2022-03-08 14:18:44 --> Router Class Initialized
INFO - 2022-03-08 14:18:44 --> Output Class Initialized
INFO - 2022-03-08 14:18:44 --> Security Class Initialized
DEBUG - 2022-03-08 14:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 14:18:44 --> Input Class Initialized
INFO - 2022-03-08 14:18:44 --> Language Class Initialized
INFO - 2022-03-08 14:18:44 --> Loader Class Initialized
INFO - 2022-03-08 14:18:44 --> Helper loaded: url_helper
INFO - 2022-03-08 14:18:44 --> Helper loaded: form_helper
INFO - 2022-03-08 14:18:44 --> Helper loaded: common_helper
INFO - 2022-03-08 14:18:44 --> Database Driver Class Initialized
DEBUG - 2022-03-08 14:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 14:18:44 --> Controller Class Initialized
INFO - 2022-03-08 14:18:44 --> Form Validation Class Initialized
DEBUG - 2022-03-08 14:18:44 --> Encrypt Class Initialized
DEBUG - 2022-03-08 14:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 14:18:44 --> Email Class Initialized
INFO - 2022-03-08 14:18:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 14:18:44 --> Calendar Class Initialized
INFO - 2022-03-08 14:18:44 --> Model "Login_model" initialized
ERROR - 2022-03-08 14:18:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 14:18:45 --> Config Class Initialized
INFO - 2022-03-08 14:18:45 --> Hooks Class Initialized
DEBUG - 2022-03-08 14:18:45 --> UTF-8 Support Enabled
INFO - 2022-03-08 14:18:45 --> Utf8 Class Initialized
INFO - 2022-03-08 14:18:45 --> URI Class Initialized
INFO - 2022-03-08 14:18:45 --> Router Class Initialized
INFO - 2022-03-08 14:18:45 --> Output Class Initialized
INFO - 2022-03-08 14:18:45 --> Security Class Initialized
DEBUG - 2022-03-08 14:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 14:18:45 --> Input Class Initialized
INFO - 2022-03-08 14:18:45 --> Language Class Initialized
INFO - 2022-03-08 14:18:45 --> Loader Class Initialized
INFO - 2022-03-08 14:18:45 --> Helper loaded: url_helper
INFO - 2022-03-08 14:18:45 --> Helper loaded: form_helper
INFO - 2022-03-08 14:18:45 --> Helper loaded: common_helper
INFO - 2022-03-08 14:18:45 --> Database Driver Class Initialized
DEBUG - 2022-03-08 14:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 14:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 14:18:45 --> Controller Class Initialized
INFO - 2022-03-08 14:18:45 --> Form Validation Class Initialized
DEBUG - 2022-03-08 14:18:45 --> Encrypt Class Initialized
DEBUG - 2022-03-08 14:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:18:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 14:18:45 --> Email Class Initialized
INFO - 2022-03-08 14:18:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 14:18:45 --> Calendar Class Initialized
INFO - 2022-03-08 14:18:45 --> Model "Login_model" initialized
ERROR - 2022-03-08 15:42:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 15:42:14 --> Config Class Initialized
INFO - 2022-03-08 15:42:14 --> Hooks Class Initialized
DEBUG - 2022-03-08 15:42:14 --> UTF-8 Support Enabled
INFO - 2022-03-08 15:42:14 --> Utf8 Class Initialized
INFO - 2022-03-08 15:42:14 --> URI Class Initialized
DEBUG - 2022-03-08 15:42:14 --> No URI present. Default controller set.
INFO - 2022-03-08 15:42:14 --> Router Class Initialized
INFO - 2022-03-08 15:42:14 --> Output Class Initialized
INFO - 2022-03-08 15:42:14 --> Security Class Initialized
DEBUG - 2022-03-08 15:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 15:42:14 --> Input Class Initialized
INFO - 2022-03-08 15:42:14 --> Language Class Initialized
INFO - 2022-03-08 15:42:14 --> Loader Class Initialized
INFO - 2022-03-08 15:42:14 --> Helper loaded: url_helper
INFO - 2022-03-08 15:42:14 --> Helper loaded: form_helper
INFO - 2022-03-08 15:42:14 --> Helper loaded: common_helper
INFO - 2022-03-08 15:42:14 --> Database Driver Class Initialized
DEBUG - 2022-03-08 15:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 15:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 15:42:14 --> Controller Class Initialized
INFO - 2022-03-08 15:42:14 --> Form Validation Class Initialized
DEBUG - 2022-03-08 15:42:14 --> Encrypt Class Initialized
DEBUG - 2022-03-08 15:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:42:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 15:42:14 --> Email Class Initialized
INFO - 2022-03-08 15:42:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 15:42:14 --> Calendar Class Initialized
INFO - 2022-03-08 15:42:14 --> Model "Login_model" initialized
INFO - 2022-03-08 15:42:14 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 15:42:14 --> Final output sent to browser
DEBUG - 2022-03-08 15:42:14 --> Total execution time: 0.0255
ERROR - 2022-03-08 15:52:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 15:52:58 --> Config Class Initialized
INFO - 2022-03-08 15:52:58 --> Hooks Class Initialized
DEBUG - 2022-03-08 15:52:58 --> UTF-8 Support Enabled
INFO - 2022-03-08 15:52:58 --> Utf8 Class Initialized
INFO - 2022-03-08 15:52:58 --> URI Class Initialized
DEBUG - 2022-03-08 15:52:58 --> No URI present. Default controller set.
INFO - 2022-03-08 15:52:58 --> Router Class Initialized
INFO - 2022-03-08 15:52:58 --> Output Class Initialized
INFO - 2022-03-08 15:52:58 --> Security Class Initialized
DEBUG - 2022-03-08 15:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 15:52:58 --> Input Class Initialized
INFO - 2022-03-08 15:52:58 --> Language Class Initialized
INFO - 2022-03-08 15:52:58 --> Loader Class Initialized
INFO - 2022-03-08 15:52:58 --> Helper loaded: url_helper
INFO - 2022-03-08 15:52:58 --> Helper loaded: form_helper
INFO - 2022-03-08 15:52:58 --> Helper loaded: common_helper
INFO - 2022-03-08 15:52:58 --> Database Driver Class Initialized
DEBUG - 2022-03-08 15:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 15:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 15:52:58 --> Controller Class Initialized
INFO - 2022-03-08 15:52:58 --> Form Validation Class Initialized
DEBUG - 2022-03-08 15:52:58 --> Encrypt Class Initialized
DEBUG - 2022-03-08 15:52:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:52:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 15:52:58 --> Email Class Initialized
INFO - 2022-03-08 15:52:58 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 15:52:58 --> Calendar Class Initialized
INFO - 2022-03-08 15:52:58 --> Model "Login_model" initialized
INFO - 2022-03-08 15:52:58 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 15:52:58 --> Final output sent to browser
DEBUG - 2022-03-08 15:52:58 --> Total execution time: 0.0281
ERROR - 2022-03-08 22:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:03:53 --> Config Class Initialized
INFO - 2022-03-08 22:03:53 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:03:53 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:03:53 --> Utf8 Class Initialized
INFO - 2022-03-08 22:03:53 --> URI Class Initialized
INFO - 2022-03-08 22:03:53 --> Router Class Initialized
INFO - 2022-03-08 22:03:53 --> Output Class Initialized
INFO - 2022-03-08 22:03:53 --> Security Class Initialized
DEBUG - 2022-03-08 22:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:03:53 --> Input Class Initialized
INFO - 2022-03-08 22:03:53 --> Language Class Initialized
INFO - 2022-03-08 22:03:53 --> Loader Class Initialized
INFO - 2022-03-08 22:03:53 --> Helper loaded: url_helper
INFO - 2022-03-08 22:03:53 --> Helper loaded: form_helper
INFO - 2022-03-08 22:03:53 --> Helper loaded: common_helper
INFO - 2022-03-08 22:03:53 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:03:53 --> Controller Class Initialized
INFO - 2022-03-08 22:03:53 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:03:53 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:03:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:03:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:03:53 --> Email Class Initialized
INFO - 2022-03-08 22:03:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:03:53 --> Calendar Class Initialized
INFO - 2022-03-08 22:03:53 --> Model "Login_model" initialized
INFO - 2022-03-08 22:03:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 22:03:53 --> Final output sent to browser
DEBUG - 2022-03-08 22:03:53 --> Total execution time: 0.3127
ERROR - 2022-03-08 22:04:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:04:37 --> Config Class Initialized
INFO - 2022-03-08 22:04:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:04:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:04:37 --> Utf8 Class Initialized
INFO - 2022-03-08 22:04:37 --> URI Class Initialized
INFO - 2022-03-08 22:04:37 --> Router Class Initialized
INFO - 2022-03-08 22:04:37 --> Output Class Initialized
INFO - 2022-03-08 22:04:37 --> Security Class Initialized
DEBUG - 2022-03-08 22:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:04:37 --> Input Class Initialized
INFO - 2022-03-08 22:04:37 --> Language Class Initialized
INFO - 2022-03-08 22:04:37 --> Loader Class Initialized
INFO - 2022-03-08 22:04:37 --> Helper loaded: url_helper
INFO - 2022-03-08 22:04:37 --> Helper loaded: form_helper
INFO - 2022-03-08 22:04:37 --> Helper loaded: common_helper
INFO - 2022-03-08 22:04:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:04:37 --> Controller Class Initialized
INFO - 2022-03-08 22:04:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:04:37 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:04:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:04:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:04:37 --> Email Class Initialized
INFO - 2022-03-08 22:04:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:04:37 --> Calendar Class Initialized
INFO - 2022-03-08 22:04:37 --> Model "Login_model" initialized
INFO - 2022-03-08 22:04:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 22:04:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:04:38 --> Config Class Initialized
INFO - 2022-03-08 22:04:38 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:04:38 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:04:38 --> Utf8 Class Initialized
INFO - 2022-03-08 22:04:38 --> URI Class Initialized
INFO - 2022-03-08 22:04:38 --> Router Class Initialized
INFO - 2022-03-08 22:04:38 --> Output Class Initialized
INFO - 2022-03-08 22:04:38 --> Security Class Initialized
DEBUG - 2022-03-08 22:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:04:38 --> Input Class Initialized
INFO - 2022-03-08 22:04:38 --> Language Class Initialized
INFO - 2022-03-08 22:04:38 --> Loader Class Initialized
INFO - 2022-03-08 22:04:38 --> Helper loaded: url_helper
INFO - 2022-03-08 22:04:38 --> Helper loaded: form_helper
INFO - 2022-03-08 22:04:38 --> Helper loaded: common_helper
INFO - 2022-03-08 22:04:38 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:04:38 --> Controller Class Initialized
INFO - 2022-03-08 22:04:38 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:04:38 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:04:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:04:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:04:38 --> Email Class Initialized
INFO - 2022-03-08 22:04:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:04:38 --> Calendar Class Initialized
INFO - 2022-03-08 22:04:38 --> Model "Login_model" initialized
INFO - 2022-03-08 22:04:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 22:04:38 --> Final output sent to browser
DEBUG - 2022-03-08 22:04:38 --> Total execution time: 0.0265
ERROR - 2022-03-08 22:04:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:04:59 --> Config Class Initialized
INFO - 2022-03-08 22:04:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:04:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:04:59 --> Utf8 Class Initialized
INFO - 2022-03-08 22:04:59 --> URI Class Initialized
INFO - 2022-03-08 22:04:59 --> Router Class Initialized
INFO - 2022-03-08 22:04:59 --> Output Class Initialized
INFO - 2022-03-08 22:04:59 --> Security Class Initialized
DEBUG - 2022-03-08 22:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:04:59 --> Input Class Initialized
INFO - 2022-03-08 22:04:59 --> Language Class Initialized
INFO - 2022-03-08 22:04:59 --> Loader Class Initialized
INFO - 2022-03-08 22:04:59 --> Helper loaded: url_helper
INFO - 2022-03-08 22:04:59 --> Helper loaded: form_helper
INFO - 2022-03-08 22:04:59 --> Helper loaded: common_helper
INFO - 2022-03-08 22:04:59 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:04:59 --> Controller Class Initialized
INFO - 2022-03-08 22:04:59 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:04:59 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:04:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:04:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:04:59 --> Email Class Initialized
INFO - 2022-03-08 22:04:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:04:59 --> Calendar Class Initialized
INFO - 2022-03-08 22:04:59 --> Model "Login_model" initialized
INFO - 2022-03-08 22:04:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 22:04:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:04:59 --> Config Class Initialized
INFO - 2022-03-08 22:04:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:04:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:04:59 --> Utf8 Class Initialized
INFO - 2022-03-08 22:04:59 --> URI Class Initialized
INFO - 2022-03-08 22:04:59 --> Router Class Initialized
INFO - 2022-03-08 22:04:59 --> Output Class Initialized
INFO - 2022-03-08 22:04:59 --> Security Class Initialized
DEBUG - 2022-03-08 22:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:04:59 --> Input Class Initialized
INFO - 2022-03-08 22:04:59 --> Language Class Initialized
INFO - 2022-03-08 22:04:59 --> Loader Class Initialized
INFO - 2022-03-08 22:04:59 --> Helper loaded: url_helper
INFO - 2022-03-08 22:04:59 --> Helper loaded: form_helper
INFO - 2022-03-08 22:04:59 --> Helper loaded: common_helper
INFO - 2022-03-08 22:04:59 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:04:59 --> Controller Class Initialized
INFO - 2022-03-08 22:04:59 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:04:59 --> Encrypt Class Initialized
INFO - 2022-03-08 22:04:59 --> Model "Login_model" initialized
INFO - 2022-03-08 22:04:59 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 22:04:59 --> Model "Case_model" initialized
INFO - 2022-03-08 22:05:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:05:00 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 22:05:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:05:00 --> Final output sent to browser
DEBUG - 2022-03-08 22:05:00 --> Total execution time: 0.6089
ERROR - 2022-03-08 22:05:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:05:15 --> Config Class Initialized
INFO - 2022-03-08 22:05:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:05:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:05:15 --> Utf8 Class Initialized
INFO - 2022-03-08 22:05:15 --> URI Class Initialized
INFO - 2022-03-08 22:05:15 --> Router Class Initialized
INFO - 2022-03-08 22:05:15 --> Output Class Initialized
INFO - 2022-03-08 22:05:15 --> Security Class Initialized
DEBUG - 2022-03-08 22:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:05:15 --> Input Class Initialized
INFO - 2022-03-08 22:05:15 --> Language Class Initialized
INFO - 2022-03-08 22:05:15 --> Loader Class Initialized
INFO - 2022-03-08 22:05:15 --> Helper loaded: url_helper
INFO - 2022-03-08 22:05:15 --> Helper loaded: form_helper
INFO - 2022-03-08 22:05:15 --> Helper loaded: common_helper
INFO - 2022-03-08 22:05:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:05:15 --> Controller Class Initialized
INFO - 2022-03-08 22:05:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:05:15 --> Encrypt Class Initialized
INFO - 2022-03-08 22:05:15 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:05:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:05:15 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:05:15 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:05:15 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:05:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:05:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patient_by_category.php
INFO - 2022-03-08 22:05:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:05:15 --> Final output sent to browser
DEBUG - 2022-03-08 22:05:15 --> Total execution time: 0.0379
ERROR - 2022-03-08 22:05:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:05:21 --> Config Class Initialized
INFO - 2022-03-08 22:05:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:05:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:05:21 --> Utf8 Class Initialized
INFO - 2022-03-08 22:05:21 --> URI Class Initialized
INFO - 2022-03-08 22:05:21 --> Router Class Initialized
INFO - 2022-03-08 22:05:21 --> Output Class Initialized
INFO - 2022-03-08 22:05:21 --> Security Class Initialized
DEBUG - 2022-03-08 22:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:05:21 --> Input Class Initialized
INFO - 2022-03-08 22:05:21 --> Language Class Initialized
INFO - 2022-03-08 22:05:21 --> Loader Class Initialized
INFO - 2022-03-08 22:05:21 --> Helper loaded: url_helper
INFO - 2022-03-08 22:05:21 --> Helper loaded: form_helper
INFO - 2022-03-08 22:05:21 --> Helper loaded: common_helper
INFO - 2022-03-08 22:05:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:05:21 --> Controller Class Initialized
INFO - 2022-03-08 22:05:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:05:21 --> Encrypt Class Initialized
INFO - 2022-03-08 22:05:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:05:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:05:21 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:05:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:05:21 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:05:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:05:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:05:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:05:21 --> Final output sent to browser
DEBUG - 2022-03-08 22:05:21 --> Total execution time: 0.1074
ERROR - 2022-03-08 22:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:05:41 --> Config Class Initialized
INFO - 2022-03-08 22:05:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:05:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:05:41 --> Utf8 Class Initialized
INFO - 2022-03-08 22:05:41 --> URI Class Initialized
INFO - 2022-03-08 22:05:41 --> Router Class Initialized
INFO - 2022-03-08 22:05:41 --> Output Class Initialized
INFO - 2022-03-08 22:05:41 --> Security Class Initialized
DEBUG - 2022-03-08 22:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:05:41 --> Input Class Initialized
INFO - 2022-03-08 22:05:41 --> Language Class Initialized
INFO - 2022-03-08 22:05:41 --> Loader Class Initialized
INFO - 2022-03-08 22:05:41 --> Helper loaded: url_helper
INFO - 2022-03-08 22:05:41 --> Helper loaded: form_helper
INFO - 2022-03-08 22:05:41 --> Helper loaded: common_helper
INFO - 2022-03-08 22:05:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:05:41 --> Controller Class Initialized
INFO - 2022-03-08 22:05:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:05:41 --> Encrypt Class Initialized
INFO - 2022-03-08 22:05:41 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:05:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:05:41 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:05:41 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:05:41 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:05:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:05:41 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:05:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:05:41 --> Final output sent to browser
DEBUG - 2022-03-08 22:05:41 --> Total execution time: 0.0871
ERROR - 2022-03-08 22:06:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:06:58 --> Config Class Initialized
INFO - 2022-03-08 22:06:58 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:06:58 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:06:58 --> Utf8 Class Initialized
INFO - 2022-03-08 22:06:58 --> URI Class Initialized
INFO - 2022-03-08 22:06:58 --> Router Class Initialized
INFO - 2022-03-08 22:06:58 --> Output Class Initialized
INFO - 2022-03-08 22:06:58 --> Security Class Initialized
DEBUG - 2022-03-08 22:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:06:58 --> Input Class Initialized
INFO - 2022-03-08 22:06:58 --> Language Class Initialized
INFO - 2022-03-08 22:06:58 --> Loader Class Initialized
INFO - 2022-03-08 22:06:58 --> Helper loaded: url_helper
INFO - 2022-03-08 22:06:58 --> Helper loaded: form_helper
INFO - 2022-03-08 22:06:58 --> Helper loaded: common_helper
INFO - 2022-03-08 22:06:58 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:06:58 --> Controller Class Initialized
INFO - 2022-03-08 22:06:58 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:06:58 --> Encrypt Class Initialized
INFO - 2022-03-08 22:06:58 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:06:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:06:58 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:06:58 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:06:58 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:06:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:06:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:06:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:06:58 --> Final output sent to browser
DEBUG - 2022-03-08 22:06:58 --> Total execution time: 0.2052
ERROR - 2022-03-08 22:08:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:08:05 --> Config Class Initialized
INFO - 2022-03-08 22:08:05 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:08:05 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:08:05 --> Utf8 Class Initialized
INFO - 2022-03-08 22:08:05 --> URI Class Initialized
INFO - 2022-03-08 22:08:05 --> Router Class Initialized
INFO - 2022-03-08 22:08:05 --> Output Class Initialized
INFO - 2022-03-08 22:08:05 --> Security Class Initialized
DEBUG - 2022-03-08 22:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:08:05 --> Input Class Initialized
INFO - 2022-03-08 22:08:05 --> Language Class Initialized
INFO - 2022-03-08 22:08:05 --> Loader Class Initialized
INFO - 2022-03-08 22:08:05 --> Helper loaded: url_helper
INFO - 2022-03-08 22:08:05 --> Helper loaded: form_helper
INFO - 2022-03-08 22:08:05 --> Helper loaded: common_helper
INFO - 2022-03-08 22:08:05 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:08:05 --> Controller Class Initialized
INFO - 2022-03-08 22:08:05 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:08:05 --> Encrypt Class Initialized
INFO - 2022-03-08 22:08:05 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:08:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:08:05 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:08:05 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:08:05 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:08:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:08:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:08:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:08:05 --> Final output sent to browser
DEBUG - 2022-03-08 22:08:05 --> Total execution time: 0.0575
ERROR - 2022-03-08 22:08:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:08:05 --> Config Class Initialized
INFO - 2022-03-08 22:08:05 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:08:05 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:08:05 --> Utf8 Class Initialized
INFO - 2022-03-08 22:08:05 --> URI Class Initialized
INFO - 2022-03-08 22:08:05 --> Router Class Initialized
INFO - 2022-03-08 22:08:05 --> Output Class Initialized
INFO - 2022-03-08 22:08:05 --> Security Class Initialized
DEBUG - 2022-03-08 22:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:08:05 --> Input Class Initialized
INFO - 2022-03-08 22:08:05 --> Language Class Initialized
INFO - 2022-03-08 22:08:05 --> Loader Class Initialized
INFO - 2022-03-08 22:08:05 --> Helper loaded: url_helper
INFO - 2022-03-08 22:08:05 --> Helper loaded: form_helper
INFO - 2022-03-08 22:08:05 --> Helper loaded: common_helper
INFO - 2022-03-08 22:08:05 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:08:05 --> Controller Class Initialized
INFO - 2022-03-08 22:08:05 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:08:05 --> Encrypt Class Initialized
INFO - 2022-03-08 22:08:05 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:08:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:08:05 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:08:05 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:08:05 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:08:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:08:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:08:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:08:05 --> Final output sent to browser
DEBUG - 2022-03-08 22:08:05 --> Total execution time: 0.0419
ERROR - 2022-03-08 22:08:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:08:06 --> Config Class Initialized
INFO - 2022-03-08 22:08:06 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:08:06 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:08:06 --> Utf8 Class Initialized
INFO - 2022-03-08 22:08:06 --> URI Class Initialized
INFO - 2022-03-08 22:08:06 --> Router Class Initialized
INFO - 2022-03-08 22:08:06 --> Output Class Initialized
INFO - 2022-03-08 22:08:06 --> Security Class Initialized
DEBUG - 2022-03-08 22:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:08:06 --> Input Class Initialized
INFO - 2022-03-08 22:08:06 --> Language Class Initialized
INFO - 2022-03-08 22:08:06 --> Loader Class Initialized
INFO - 2022-03-08 22:08:06 --> Helper loaded: url_helper
INFO - 2022-03-08 22:08:06 --> Helper loaded: form_helper
INFO - 2022-03-08 22:08:06 --> Helper loaded: common_helper
INFO - 2022-03-08 22:08:06 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:08:06 --> Controller Class Initialized
INFO - 2022-03-08 22:08:06 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:08:06 --> Encrypt Class Initialized
INFO - 2022-03-08 22:08:06 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:08:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:08:06 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:08:06 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:08:06 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:08:06 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:08:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:08:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:08:06 --> Final output sent to browser
DEBUG - 2022-03-08 22:08:06 --> Total execution time: 0.0499
ERROR - 2022-03-08 22:08:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:08:47 --> Config Class Initialized
INFO - 2022-03-08 22:08:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:08:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:08:47 --> Utf8 Class Initialized
INFO - 2022-03-08 22:08:47 --> URI Class Initialized
INFO - 2022-03-08 22:08:47 --> Router Class Initialized
INFO - 2022-03-08 22:08:47 --> Output Class Initialized
INFO - 2022-03-08 22:08:47 --> Security Class Initialized
DEBUG - 2022-03-08 22:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:08:47 --> Input Class Initialized
INFO - 2022-03-08 22:08:47 --> Language Class Initialized
INFO - 2022-03-08 22:08:47 --> Loader Class Initialized
INFO - 2022-03-08 22:08:47 --> Helper loaded: url_helper
INFO - 2022-03-08 22:08:47 --> Helper loaded: form_helper
INFO - 2022-03-08 22:08:47 --> Helper loaded: common_helper
INFO - 2022-03-08 22:08:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:08:47 --> Controller Class Initialized
INFO - 2022-03-08 22:08:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:08:47 --> Encrypt Class Initialized
INFO - 2022-03-08 22:08:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:08:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:08:47 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:08:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:08:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:08:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:08:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:08:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:08:47 --> Final output sent to browser
DEBUG - 2022-03-08 22:08:47 --> Total execution time: 0.0919
ERROR - 2022-03-08 22:17:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:17:20 --> Config Class Initialized
INFO - 2022-03-08 22:17:20 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:17:20 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:17:20 --> Utf8 Class Initialized
INFO - 2022-03-08 22:17:20 --> URI Class Initialized
DEBUG - 2022-03-08 22:17:20 --> No URI present. Default controller set.
INFO - 2022-03-08 22:17:20 --> Router Class Initialized
INFO - 2022-03-08 22:17:20 --> Output Class Initialized
INFO - 2022-03-08 22:17:20 --> Security Class Initialized
DEBUG - 2022-03-08 22:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:17:20 --> Input Class Initialized
INFO - 2022-03-08 22:17:20 --> Language Class Initialized
INFO - 2022-03-08 22:17:20 --> Loader Class Initialized
INFO - 2022-03-08 22:17:20 --> Helper loaded: url_helper
INFO - 2022-03-08 22:17:20 --> Helper loaded: form_helper
INFO - 2022-03-08 22:17:20 --> Helper loaded: common_helper
INFO - 2022-03-08 22:17:20 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:17:20 --> Controller Class Initialized
INFO - 2022-03-08 22:17:20 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:17:20 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:17:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:17:20 --> Email Class Initialized
INFO - 2022-03-08 22:17:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:17:20 --> Calendar Class Initialized
INFO - 2022-03-08 22:17:20 --> Model "Login_model" initialized
INFO - 2022-03-08 22:17:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 22:17:20 --> Final output sent to browser
DEBUG - 2022-03-08 22:17:20 --> Total execution time: 0.0312
ERROR - 2022-03-08 22:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:17:36 --> Config Class Initialized
INFO - 2022-03-08 22:17:36 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:17:36 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:17:36 --> Utf8 Class Initialized
INFO - 2022-03-08 22:17:36 --> URI Class Initialized
INFO - 2022-03-08 22:17:36 --> Router Class Initialized
INFO - 2022-03-08 22:17:36 --> Output Class Initialized
INFO - 2022-03-08 22:17:36 --> Security Class Initialized
DEBUG - 2022-03-08 22:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:17:36 --> Input Class Initialized
INFO - 2022-03-08 22:17:36 --> Language Class Initialized
INFO - 2022-03-08 22:17:36 --> Loader Class Initialized
INFO - 2022-03-08 22:17:36 --> Helper loaded: url_helper
INFO - 2022-03-08 22:17:36 --> Helper loaded: form_helper
INFO - 2022-03-08 22:17:36 --> Helper loaded: common_helper
INFO - 2022-03-08 22:17:36 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:17:36 --> Controller Class Initialized
INFO - 2022-03-08 22:17:36 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:17:36 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:17:36 --> Email Class Initialized
INFO - 2022-03-08 22:17:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:17:36 --> Calendar Class Initialized
INFO - 2022-03-08 22:17:36 --> Model "Login_model" initialized
INFO - 2022-03-08 22:17:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 22:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:17:36 --> Config Class Initialized
INFO - 2022-03-08 22:17:36 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:17:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:17:37 --> Utf8 Class Initialized
INFO - 2022-03-08 22:17:37 --> URI Class Initialized
INFO - 2022-03-08 22:17:37 --> Router Class Initialized
INFO - 2022-03-08 22:17:37 --> Output Class Initialized
INFO - 2022-03-08 22:17:37 --> Security Class Initialized
DEBUG - 2022-03-08 22:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:17:37 --> Input Class Initialized
INFO - 2022-03-08 22:17:37 --> Language Class Initialized
INFO - 2022-03-08 22:17:37 --> Loader Class Initialized
INFO - 2022-03-08 22:17:37 --> Helper loaded: url_helper
INFO - 2022-03-08 22:17:37 --> Helper loaded: form_helper
INFO - 2022-03-08 22:17:37 --> Helper loaded: common_helper
INFO - 2022-03-08 22:17:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:17:37 --> Controller Class Initialized
INFO - 2022-03-08 22:17:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:17:37 --> Encrypt Class Initialized
INFO - 2022-03-08 22:17:37 --> Model "Login_model" initialized
INFO - 2022-03-08 22:17:37 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 22:17:37 --> Model "Case_model" initialized
INFO - 2022-03-08 22:17:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:17:37 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 22:17:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:17:37 --> Final output sent to browser
DEBUG - 2022-03-08 22:17:37 --> Total execution time: 0.2137
ERROR - 2022-03-08 22:18:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:18:07 --> Config Class Initialized
INFO - 2022-03-08 22:18:07 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:18:07 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:18:07 --> Utf8 Class Initialized
INFO - 2022-03-08 22:18:07 --> URI Class Initialized
INFO - 2022-03-08 22:18:07 --> Router Class Initialized
INFO - 2022-03-08 22:18:07 --> Output Class Initialized
INFO - 2022-03-08 22:18:07 --> Security Class Initialized
DEBUG - 2022-03-08 22:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:18:07 --> Input Class Initialized
INFO - 2022-03-08 22:18:07 --> Language Class Initialized
INFO - 2022-03-08 22:18:07 --> Loader Class Initialized
INFO - 2022-03-08 22:18:07 --> Helper loaded: url_helper
INFO - 2022-03-08 22:18:07 --> Helper loaded: form_helper
INFO - 2022-03-08 22:18:07 --> Helper loaded: common_helper
INFO - 2022-03-08 22:18:07 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:18:07 --> Controller Class Initialized
INFO - 2022-03-08 22:18:07 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:18:07 --> Encrypt Class Initialized
INFO - 2022-03-08 22:18:07 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:18:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:18:07 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:18:07 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:18:07 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:18:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:18:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:18:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:18:07 --> Final output sent to browser
DEBUG - 2022-03-08 22:18:07 --> Total execution time: 0.0649
ERROR - 2022-03-08 22:22:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:22:57 --> Config Class Initialized
INFO - 2022-03-08 22:22:57 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:22:57 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:22:57 --> Utf8 Class Initialized
INFO - 2022-03-08 22:22:57 --> URI Class Initialized
INFO - 2022-03-08 22:22:57 --> Router Class Initialized
INFO - 2022-03-08 22:22:57 --> Output Class Initialized
INFO - 2022-03-08 22:22:57 --> Security Class Initialized
DEBUG - 2022-03-08 22:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:22:57 --> Input Class Initialized
INFO - 2022-03-08 22:22:57 --> Language Class Initialized
INFO - 2022-03-08 22:22:57 --> Loader Class Initialized
INFO - 2022-03-08 22:22:57 --> Helper loaded: url_helper
INFO - 2022-03-08 22:22:57 --> Helper loaded: form_helper
INFO - 2022-03-08 22:22:57 --> Helper loaded: common_helper
INFO - 2022-03-08 22:22:57 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:22:57 --> Controller Class Initialized
INFO - 2022-03-08 22:22:57 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:22:57 --> Encrypt Class Initialized
INFO - 2022-03-08 22:22:57 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:22:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:22:57 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:22:57 --> Model "Users_model" initialized
INFO - 2022-03-08 22:22:57 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:22:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:22:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:22:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:22:57 --> Final output sent to browser
DEBUG - 2022-03-08 22:22:57 --> Total execution time: 0.3655
ERROR - 2022-03-08 22:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:23:09 --> Config Class Initialized
INFO - 2022-03-08 22:23:09 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:23:09 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:23:09 --> Utf8 Class Initialized
INFO - 2022-03-08 22:23:09 --> URI Class Initialized
INFO - 2022-03-08 22:23:09 --> Router Class Initialized
INFO - 2022-03-08 22:23:09 --> Output Class Initialized
INFO - 2022-03-08 22:23:09 --> Security Class Initialized
DEBUG - 2022-03-08 22:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:23:09 --> Input Class Initialized
INFO - 2022-03-08 22:23:09 --> Language Class Initialized
INFO - 2022-03-08 22:23:09 --> Loader Class Initialized
INFO - 2022-03-08 22:23:09 --> Helper loaded: url_helper
INFO - 2022-03-08 22:23:09 --> Helper loaded: form_helper
INFO - 2022-03-08 22:23:09 --> Helper loaded: common_helper
INFO - 2022-03-08 22:23:09 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:23:10 --> Controller Class Initialized
INFO - 2022-03-08 22:23:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:23:10 --> Encrypt Class Initialized
INFO - 2022-03-08 22:23:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:23:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:23:10 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:23:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:23:10 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:23:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:23:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 22:23:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:23:10 --> Final output sent to browser
DEBUG - 2022-03-08 22:23:10 --> Total execution time: 1.0983
ERROR - 2022-03-08 22:23:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:23:24 --> Config Class Initialized
INFO - 2022-03-08 22:23:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:23:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:23:24 --> Utf8 Class Initialized
INFO - 2022-03-08 22:23:24 --> URI Class Initialized
INFO - 2022-03-08 22:23:24 --> Router Class Initialized
INFO - 2022-03-08 22:23:24 --> Output Class Initialized
INFO - 2022-03-08 22:23:24 --> Security Class Initialized
DEBUG - 2022-03-08 22:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:23:24 --> Input Class Initialized
INFO - 2022-03-08 22:23:24 --> Language Class Initialized
INFO - 2022-03-08 22:23:24 --> Loader Class Initialized
INFO - 2022-03-08 22:23:24 --> Helper loaded: url_helper
INFO - 2022-03-08 22:23:24 --> Helper loaded: form_helper
INFO - 2022-03-08 22:23:24 --> Helper loaded: common_helper
INFO - 2022-03-08 22:23:24 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:23:24 --> Controller Class Initialized
INFO - 2022-03-08 22:23:24 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:23:24 --> Encrypt Class Initialized
INFO - 2022-03-08 22:23:24 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:23:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:23:24 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:23:24 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:23:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 22:23:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:23:25 --> Config Class Initialized
INFO - 2022-03-08 22:23:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:23:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:23:25 --> Utf8 Class Initialized
INFO - 2022-03-08 22:23:25 --> URI Class Initialized
INFO - 2022-03-08 22:23:25 --> Router Class Initialized
INFO - 2022-03-08 22:23:25 --> Output Class Initialized
INFO - 2022-03-08 22:23:25 --> Security Class Initialized
DEBUG - 2022-03-08 22:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:23:25 --> Input Class Initialized
INFO - 2022-03-08 22:23:25 --> Language Class Initialized
INFO - 2022-03-08 22:23:25 --> Loader Class Initialized
INFO - 2022-03-08 22:23:25 --> Helper loaded: url_helper
INFO - 2022-03-08 22:23:25 --> Helper loaded: form_helper
INFO - 2022-03-08 22:23:25 --> Helper loaded: common_helper
INFO - 2022-03-08 22:23:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:23:25 --> Controller Class Initialized
INFO - 2022-03-08 22:23:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:23:25 --> Encrypt Class Initialized
INFO - 2022-03-08 22:23:25 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:23:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:23:25 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:23:25 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:23:25 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:23:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:23:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 22:23:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:23:25 --> Final output sent to browser
DEBUG - 2022-03-08 22:23:25 --> Total execution time: 0.0949
ERROR - 2022-03-08 22:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:23:26 --> Config Class Initialized
INFO - 2022-03-08 22:23:26 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:23:26 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:23:26 --> Utf8 Class Initialized
INFO - 2022-03-08 22:23:26 --> URI Class Initialized
INFO - 2022-03-08 22:23:26 --> Router Class Initialized
INFO - 2022-03-08 22:23:26 --> Output Class Initialized
INFO - 2022-03-08 22:23:26 --> Security Class Initialized
DEBUG - 2022-03-08 22:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:23:26 --> Input Class Initialized
INFO - 2022-03-08 22:23:26 --> Language Class Initialized
INFO - 2022-03-08 22:23:26 --> Loader Class Initialized
INFO - 2022-03-08 22:23:26 --> Helper loaded: url_helper
INFO - 2022-03-08 22:23:26 --> Helper loaded: form_helper
INFO - 2022-03-08 22:23:26 --> Helper loaded: common_helper
INFO - 2022-03-08 22:23:26 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:23:26 --> Controller Class Initialized
INFO - 2022-03-08 22:23:26 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:23:26 --> Encrypt Class Initialized
INFO - 2022-03-08 22:23:26 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:23:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:23:26 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:23:26 --> Model "Users_model" initialized
INFO - 2022-03-08 22:23:26 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:23:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:23:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:23:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:23:26 --> Final output sent to browser
DEBUG - 2022-03-08 22:23:26 --> Total execution time: 0.0731
ERROR - 2022-03-08 22:23:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:23:47 --> Config Class Initialized
INFO - 2022-03-08 22:23:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:23:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:23:47 --> Utf8 Class Initialized
INFO - 2022-03-08 22:23:47 --> URI Class Initialized
INFO - 2022-03-08 22:23:47 --> Router Class Initialized
INFO - 2022-03-08 22:23:47 --> Output Class Initialized
INFO - 2022-03-08 22:23:47 --> Security Class Initialized
DEBUG - 2022-03-08 22:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:23:47 --> Input Class Initialized
INFO - 2022-03-08 22:23:47 --> Language Class Initialized
INFO - 2022-03-08 22:23:47 --> Loader Class Initialized
INFO - 2022-03-08 22:23:47 --> Helper loaded: url_helper
INFO - 2022-03-08 22:23:47 --> Helper loaded: form_helper
INFO - 2022-03-08 22:23:47 --> Helper loaded: common_helper
INFO - 2022-03-08 22:23:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:23:47 --> Controller Class Initialized
INFO - 2022-03-08 22:23:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:23:47 --> Encrypt Class Initialized
INFO - 2022-03-08 22:23:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:23:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:23:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:23:47 --> Model "Users_model" initialized
INFO - 2022-03-08 22:23:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 22:23:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:23:48 --> Config Class Initialized
INFO - 2022-03-08 22:23:48 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:23:48 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:23:48 --> Utf8 Class Initialized
INFO - 2022-03-08 22:23:48 --> URI Class Initialized
INFO - 2022-03-08 22:23:48 --> Router Class Initialized
INFO - 2022-03-08 22:23:48 --> Output Class Initialized
INFO - 2022-03-08 22:23:48 --> Security Class Initialized
DEBUG - 2022-03-08 22:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:23:48 --> Input Class Initialized
INFO - 2022-03-08 22:23:48 --> Language Class Initialized
INFO - 2022-03-08 22:23:48 --> Loader Class Initialized
INFO - 2022-03-08 22:23:48 --> Helper loaded: url_helper
INFO - 2022-03-08 22:23:48 --> Helper loaded: form_helper
INFO - 2022-03-08 22:23:48 --> Helper loaded: common_helper
INFO - 2022-03-08 22:23:48 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:23:48 --> Controller Class Initialized
INFO - 2022-03-08 22:23:48 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:23:48 --> Encrypt Class Initialized
INFO - 2022-03-08 22:23:48 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:23:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:23:48 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:23:48 --> Model "Users_model" initialized
INFO - 2022-03-08 22:23:48 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:23:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:23:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:23:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:23:48 --> Final output sent to browser
DEBUG - 2022-03-08 22:23:48 --> Total execution time: 0.1248
ERROR - 2022-03-08 22:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:24:11 --> Config Class Initialized
INFO - 2022-03-08 22:24:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:24:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:24:11 --> Utf8 Class Initialized
INFO - 2022-03-08 22:24:11 --> URI Class Initialized
INFO - 2022-03-08 22:24:11 --> Router Class Initialized
INFO - 2022-03-08 22:24:11 --> Output Class Initialized
INFO - 2022-03-08 22:24:11 --> Security Class Initialized
DEBUG - 2022-03-08 22:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:24:11 --> Input Class Initialized
INFO - 2022-03-08 22:24:11 --> Language Class Initialized
INFO - 2022-03-08 22:24:11 --> Loader Class Initialized
INFO - 2022-03-08 22:24:11 --> Helper loaded: url_helper
INFO - 2022-03-08 22:24:11 --> Helper loaded: form_helper
INFO - 2022-03-08 22:24:11 --> Helper loaded: common_helper
INFO - 2022-03-08 22:24:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:24:11 --> Controller Class Initialized
INFO - 2022-03-08 22:24:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:24:11 --> Encrypt Class Initialized
INFO - 2022-03-08 22:24:11 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:24:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:24:11 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:24:11 --> Model "Users_model" initialized
INFO - 2022-03-08 22:24:11 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 22:24:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:24:12 --> Config Class Initialized
INFO - 2022-03-08 22:24:12 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:24:12 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:24:12 --> Utf8 Class Initialized
INFO - 2022-03-08 22:24:12 --> URI Class Initialized
INFO - 2022-03-08 22:24:12 --> Router Class Initialized
INFO - 2022-03-08 22:24:12 --> Output Class Initialized
INFO - 2022-03-08 22:24:12 --> Security Class Initialized
DEBUG - 2022-03-08 22:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:24:12 --> Input Class Initialized
INFO - 2022-03-08 22:24:12 --> Language Class Initialized
INFO - 2022-03-08 22:24:12 --> Loader Class Initialized
INFO - 2022-03-08 22:24:12 --> Helper loaded: url_helper
INFO - 2022-03-08 22:24:12 --> Helper loaded: form_helper
INFO - 2022-03-08 22:24:12 --> Helper loaded: common_helper
INFO - 2022-03-08 22:24:12 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:24:12 --> Controller Class Initialized
INFO - 2022-03-08 22:24:12 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:24:12 --> Encrypt Class Initialized
INFO - 2022-03-08 22:24:12 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:24:12 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:24:12 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:24:12 --> Model "Users_model" initialized
INFO - 2022-03-08 22:24:12 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:24:12 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:24:12 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:24:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:24:12 --> Final output sent to browser
DEBUG - 2022-03-08 22:24:12 --> Total execution time: 0.1134
ERROR - 2022-03-08 22:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:25:09 --> Config Class Initialized
INFO - 2022-03-08 22:25:09 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:25:09 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:25:09 --> Utf8 Class Initialized
INFO - 2022-03-08 22:25:09 --> URI Class Initialized
INFO - 2022-03-08 22:25:09 --> Router Class Initialized
INFO - 2022-03-08 22:25:09 --> Output Class Initialized
INFO - 2022-03-08 22:25:09 --> Security Class Initialized
DEBUG - 2022-03-08 22:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:25:09 --> Input Class Initialized
INFO - 2022-03-08 22:25:09 --> Language Class Initialized
INFO - 2022-03-08 22:25:09 --> Loader Class Initialized
INFO - 2022-03-08 22:25:09 --> Helper loaded: url_helper
INFO - 2022-03-08 22:25:09 --> Helper loaded: form_helper
INFO - 2022-03-08 22:25:09 --> Helper loaded: common_helper
INFO - 2022-03-08 22:25:09 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:25:09 --> Controller Class Initialized
INFO - 2022-03-08 22:25:09 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:25:09 --> Encrypt Class Initialized
INFO - 2022-03-08 22:25:09 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:25:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:25:09 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:25:09 --> Model "Users_model" initialized
INFO - 2022-03-08 22:25:09 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 22:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:25:10 --> Config Class Initialized
INFO - 2022-03-08 22:25:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:25:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:25:10 --> Utf8 Class Initialized
INFO - 2022-03-08 22:25:10 --> URI Class Initialized
INFO - 2022-03-08 22:25:10 --> Router Class Initialized
INFO - 2022-03-08 22:25:10 --> Output Class Initialized
INFO - 2022-03-08 22:25:10 --> Security Class Initialized
DEBUG - 2022-03-08 22:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:25:10 --> Input Class Initialized
INFO - 2022-03-08 22:25:10 --> Language Class Initialized
INFO - 2022-03-08 22:25:10 --> Loader Class Initialized
INFO - 2022-03-08 22:25:10 --> Helper loaded: url_helper
INFO - 2022-03-08 22:25:10 --> Helper loaded: form_helper
INFO - 2022-03-08 22:25:10 --> Helper loaded: common_helper
INFO - 2022-03-08 22:25:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:25:10 --> Controller Class Initialized
INFO - 2022-03-08 22:25:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:25:10 --> Encrypt Class Initialized
INFO - 2022-03-08 22:25:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:25:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:25:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:25:10 --> Model "Users_model" initialized
INFO - 2022-03-08 22:25:10 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:25:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:25:10 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:25:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:25:10 --> Final output sent to browser
DEBUG - 2022-03-08 22:25:10 --> Total execution time: 0.3929
ERROR - 2022-03-08 22:27:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:27:30 --> Config Class Initialized
INFO - 2022-03-08 22:27:30 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:27:30 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:27:30 --> Utf8 Class Initialized
INFO - 2022-03-08 22:27:30 --> URI Class Initialized
INFO - 2022-03-08 22:27:30 --> Router Class Initialized
INFO - 2022-03-08 22:27:30 --> Output Class Initialized
INFO - 2022-03-08 22:27:30 --> Security Class Initialized
DEBUG - 2022-03-08 22:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:27:30 --> Input Class Initialized
INFO - 2022-03-08 22:27:30 --> Language Class Initialized
INFO - 2022-03-08 22:27:30 --> Loader Class Initialized
INFO - 2022-03-08 22:27:30 --> Helper loaded: url_helper
INFO - 2022-03-08 22:27:30 --> Helper loaded: form_helper
INFO - 2022-03-08 22:27:30 --> Helper loaded: common_helper
INFO - 2022-03-08 22:27:30 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:27:30 --> Controller Class Initialized
INFO - 2022-03-08 22:27:30 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:27:30 --> Encrypt Class Initialized
INFO - 2022-03-08 22:27:30 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:27:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:27:30 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:27:30 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:27:30 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:27:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:27:30 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 22:27:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:27:30 --> Final output sent to browser
DEBUG - 2022-03-08 22:27:30 --> Total execution time: 0.0809
ERROR - 2022-03-08 22:28:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:28:16 --> Config Class Initialized
INFO - 2022-03-08 22:28:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:28:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:28:16 --> Utf8 Class Initialized
INFO - 2022-03-08 22:28:16 --> URI Class Initialized
INFO - 2022-03-08 22:28:16 --> Router Class Initialized
INFO - 2022-03-08 22:28:16 --> Output Class Initialized
INFO - 2022-03-08 22:28:16 --> Security Class Initialized
DEBUG - 2022-03-08 22:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:28:16 --> Input Class Initialized
INFO - 2022-03-08 22:28:16 --> Language Class Initialized
INFO - 2022-03-08 22:28:16 --> Loader Class Initialized
INFO - 2022-03-08 22:28:17 --> Helper loaded: url_helper
INFO - 2022-03-08 22:28:17 --> Helper loaded: form_helper
INFO - 2022-03-08 22:28:17 --> Helper loaded: common_helper
INFO - 2022-03-08 22:28:17 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:28:17 --> Controller Class Initialized
INFO - 2022-03-08 22:28:17 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:28:17 --> Encrypt Class Initialized
INFO - 2022-03-08 22:28:17 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:28:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:28:17 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:28:17 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:28:17 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:28:17 --> Final output sent to browser
DEBUG - 2022-03-08 22:28:17 --> Total execution time: 0.0401
ERROR - 2022-03-08 22:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:28:37 --> Config Class Initialized
INFO - 2022-03-08 22:28:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:28:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:28:37 --> Utf8 Class Initialized
INFO - 2022-03-08 22:28:37 --> URI Class Initialized
INFO - 2022-03-08 22:28:37 --> Router Class Initialized
INFO - 2022-03-08 22:28:37 --> Output Class Initialized
INFO - 2022-03-08 22:28:37 --> Security Class Initialized
DEBUG - 2022-03-08 22:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:28:37 --> Input Class Initialized
INFO - 2022-03-08 22:28:37 --> Language Class Initialized
INFO - 2022-03-08 22:28:37 --> Loader Class Initialized
INFO - 2022-03-08 22:28:37 --> Helper loaded: url_helper
INFO - 2022-03-08 22:28:37 --> Helper loaded: form_helper
INFO - 2022-03-08 22:28:37 --> Helper loaded: common_helper
INFO - 2022-03-08 22:28:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:28:37 --> Controller Class Initialized
INFO - 2022-03-08 22:28:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:28:37 --> Encrypt Class Initialized
INFO - 2022-03-08 22:28:37 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:28:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:28:37 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:28:37 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:28:37 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 22:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:28:38 --> Config Class Initialized
INFO - 2022-03-08 22:28:38 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:28:38 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:28:38 --> Utf8 Class Initialized
INFO - 2022-03-08 22:28:38 --> URI Class Initialized
INFO - 2022-03-08 22:28:38 --> Router Class Initialized
INFO - 2022-03-08 22:28:38 --> Output Class Initialized
INFO - 2022-03-08 22:28:38 --> Security Class Initialized
DEBUG - 2022-03-08 22:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:28:38 --> Input Class Initialized
INFO - 2022-03-08 22:28:38 --> Language Class Initialized
INFO - 2022-03-08 22:28:38 --> Loader Class Initialized
INFO - 2022-03-08 22:28:38 --> Helper loaded: url_helper
INFO - 2022-03-08 22:28:38 --> Helper loaded: form_helper
INFO - 2022-03-08 22:28:38 --> Helper loaded: common_helper
INFO - 2022-03-08 22:28:38 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:28:38 --> Controller Class Initialized
INFO - 2022-03-08 22:28:38 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:28:38 --> Encrypt Class Initialized
INFO - 2022-03-08 22:28:38 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:28:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:28:38 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:28:38 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:28:38 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:28:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:28:38 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 22:28:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:28:38 --> Final output sent to browser
DEBUG - 2022-03-08 22:28:38 --> Total execution time: 0.0578
ERROR - 2022-03-08 22:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:28:39 --> Config Class Initialized
INFO - 2022-03-08 22:28:39 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:28:39 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:28:39 --> Utf8 Class Initialized
INFO - 2022-03-08 22:28:39 --> URI Class Initialized
INFO - 2022-03-08 22:28:39 --> Router Class Initialized
INFO - 2022-03-08 22:28:39 --> Output Class Initialized
INFO - 2022-03-08 22:28:39 --> Security Class Initialized
DEBUG - 2022-03-08 22:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:28:39 --> Input Class Initialized
INFO - 2022-03-08 22:28:39 --> Language Class Initialized
INFO - 2022-03-08 22:28:39 --> Loader Class Initialized
INFO - 2022-03-08 22:28:39 --> Helper loaded: url_helper
INFO - 2022-03-08 22:28:39 --> Helper loaded: form_helper
INFO - 2022-03-08 22:28:39 --> Helper loaded: common_helper
INFO - 2022-03-08 22:28:39 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:28:39 --> Controller Class Initialized
INFO - 2022-03-08 22:28:39 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:28:39 --> Encrypt Class Initialized
INFO - 2022-03-08 22:28:39 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:28:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:28:39 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:28:39 --> Model "Users_model" initialized
INFO - 2022-03-08 22:28:39 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:28:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:28:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:28:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:28:39 --> Final output sent to browser
DEBUG - 2022-03-08 22:28:39 --> Total execution time: 0.0778
ERROR - 2022-03-08 22:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:36:20 --> Config Class Initialized
INFO - 2022-03-08 22:36:20 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:36:20 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:36:20 --> Utf8 Class Initialized
INFO - 2022-03-08 22:36:20 --> URI Class Initialized
INFO - 2022-03-08 22:36:20 --> Router Class Initialized
INFO - 2022-03-08 22:36:20 --> Output Class Initialized
INFO - 2022-03-08 22:36:20 --> Security Class Initialized
DEBUG - 2022-03-08 22:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:36:20 --> Input Class Initialized
INFO - 2022-03-08 22:36:20 --> Language Class Initialized
INFO - 2022-03-08 22:36:20 --> Loader Class Initialized
INFO - 2022-03-08 22:36:20 --> Helper loaded: url_helper
INFO - 2022-03-08 22:36:20 --> Helper loaded: form_helper
INFO - 2022-03-08 22:36:20 --> Helper loaded: common_helper
INFO - 2022-03-08 22:36:20 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:36:20 --> Controller Class Initialized
INFO - 2022-03-08 22:36:20 --> Form Validation Class Initialized
INFO - 2022-03-08 22:36:20 --> Model "Case_model" initialized
INFO - 2022-03-08 22:36:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:36:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:36:20 --> Model "Case_model" initialized
INFO - 2022-03-08 22:36:20 --> File loaded: /home3/karoteam/public_html/application/views/cases/all_case.php
INFO - 2022-03-08 22:36:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:36:20 --> Final output sent to browser
DEBUG - 2022-03-08 22:36:20 --> Total execution time: 0.0406
ERROR - 2022-03-08 22:36:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:36:25 --> Config Class Initialized
INFO - 2022-03-08 22:36:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:36:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:36:25 --> Utf8 Class Initialized
INFO - 2022-03-08 22:36:25 --> URI Class Initialized
INFO - 2022-03-08 22:36:25 --> Router Class Initialized
INFO - 2022-03-08 22:36:25 --> Output Class Initialized
INFO - 2022-03-08 22:36:25 --> Security Class Initialized
DEBUG - 2022-03-08 22:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:36:25 --> Input Class Initialized
INFO - 2022-03-08 22:36:25 --> Language Class Initialized
INFO - 2022-03-08 22:36:25 --> Loader Class Initialized
INFO - 2022-03-08 22:36:25 --> Helper loaded: url_helper
INFO - 2022-03-08 22:36:25 --> Helper loaded: form_helper
INFO - 2022-03-08 22:36:25 --> Helper loaded: common_helper
INFO - 2022-03-08 22:36:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:36:25 --> Controller Class Initialized
INFO - 2022-03-08 22:36:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:36:25 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:36:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:36:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:36:25 --> Email Class Initialized
INFO - 2022-03-08 22:36:25 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:36:25 --> Calendar Class Initialized
INFO - 2022-03-08 22:36:25 --> Model "Login_model" initialized
ERROR - 2022-03-08 22:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:36:26 --> Config Class Initialized
INFO - 2022-03-08 22:36:26 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:36:26 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:36:26 --> Utf8 Class Initialized
INFO - 2022-03-08 22:36:26 --> URI Class Initialized
INFO - 2022-03-08 22:36:26 --> Router Class Initialized
INFO - 2022-03-08 22:36:26 --> Output Class Initialized
INFO - 2022-03-08 22:36:26 --> Security Class Initialized
DEBUG - 2022-03-08 22:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:36:26 --> Input Class Initialized
INFO - 2022-03-08 22:36:26 --> Language Class Initialized
INFO - 2022-03-08 22:36:26 --> Loader Class Initialized
INFO - 2022-03-08 22:36:26 --> Helper loaded: url_helper
INFO - 2022-03-08 22:36:26 --> Helper loaded: form_helper
INFO - 2022-03-08 22:36:26 --> Helper loaded: common_helper
INFO - 2022-03-08 22:36:26 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:36:26 --> Controller Class Initialized
INFO - 2022-03-08 22:36:26 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:36:26 --> Encrypt Class Initialized
INFO - 2022-03-08 22:36:26 --> Model "Diseases_model" initialized
INFO - 2022-03-08 22:36:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:36:26 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-08 22:36:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:36:26 --> Final output sent to browser
DEBUG - 2022-03-08 22:36:26 --> Total execution time: 0.0247
ERROR - 2022-03-08 22:36:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:36:33 --> Config Class Initialized
INFO - 2022-03-08 22:36:33 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:36:33 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:36:33 --> Utf8 Class Initialized
INFO - 2022-03-08 22:36:33 --> URI Class Initialized
INFO - 2022-03-08 22:36:33 --> Router Class Initialized
INFO - 2022-03-08 22:36:33 --> Output Class Initialized
INFO - 2022-03-08 22:36:33 --> Security Class Initialized
DEBUG - 2022-03-08 22:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:36:33 --> Input Class Initialized
INFO - 2022-03-08 22:36:33 --> Language Class Initialized
INFO - 2022-03-08 22:36:33 --> Loader Class Initialized
INFO - 2022-03-08 22:36:33 --> Helper loaded: url_helper
INFO - 2022-03-08 22:36:33 --> Helper loaded: form_helper
INFO - 2022-03-08 22:36:33 --> Helper loaded: common_helper
INFO - 2022-03-08 22:36:33 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:36:33 --> Controller Class Initialized
INFO - 2022-03-08 22:36:33 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:36:33 --> Encrypt Class Initialized
INFO - 2022-03-08 22:36:33 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:36:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:36:33 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:36:33 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:36:33 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:36:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:36:33 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:36:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:36:33 --> Final output sent to browser
DEBUG - 2022-03-08 22:36:33 --> Total execution time: 0.0667
ERROR - 2022-03-08 22:36:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:36:39 --> Config Class Initialized
INFO - 2022-03-08 22:36:39 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:36:39 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:36:39 --> Utf8 Class Initialized
INFO - 2022-03-08 22:36:39 --> URI Class Initialized
INFO - 2022-03-08 22:36:39 --> Router Class Initialized
INFO - 2022-03-08 22:36:39 --> Output Class Initialized
INFO - 2022-03-08 22:36:39 --> Security Class Initialized
DEBUG - 2022-03-08 22:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:36:39 --> Input Class Initialized
INFO - 2022-03-08 22:36:39 --> Language Class Initialized
INFO - 2022-03-08 22:36:39 --> Loader Class Initialized
INFO - 2022-03-08 22:36:39 --> Helper loaded: url_helper
INFO - 2022-03-08 22:36:39 --> Helper loaded: form_helper
INFO - 2022-03-08 22:36:39 --> Helper loaded: common_helper
INFO - 2022-03-08 22:36:39 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:36:39 --> Controller Class Initialized
INFO - 2022-03-08 22:36:39 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:36:39 --> Encrypt Class Initialized
INFO - 2022-03-08 22:36:39 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:36:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:36:39 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:36:39 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:36:39 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:36:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:36:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:36:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:36:39 --> Final output sent to browser
DEBUG - 2022-03-08 22:36:39 --> Total execution time: 0.0638
ERROR - 2022-03-08 22:46:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:46:09 --> Config Class Initialized
INFO - 2022-03-08 22:46:09 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:46:09 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:46:09 --> Utf8 Class Initialized
INFO - 2022-03-08 22:46:09 --> URI Class Initialized
DEBUG - 2022-03-08 22:46:09 --> No URI present. Default controller set.
INFO - 2022-03-08 22:46:09 --> Router Class Initialized
INFO - 2022-03-08 22:46:09 --> Output Class Initialized
INFO - 2022-03-08 22:46:09 --> Security Class Initialized
DEBUG - 2022-03-08 22:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:46:09 --> Input Class Initialized
INFO - 2022-03-08 22:46:09 --> Language Class Initialized
INFO - 2022-03-08 22:46:09 --> Loader Class Initialized
INFO - 2022-03-08 22:46:09 --> Helper loaded: url_helper
INFO - 2022-03-08 22:46:09 --> Helper loaded: form_helper
INFO - 2022-03-08 22:46:09 --> Helper loaded: common_helper
INFO - 2022-03-08 22:46:09 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:46:09 --> Controller Class Initialized
INFO - 2022-03-08 22:46:09 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:46:09 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:46:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:46:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:46:09 --> Email Class Initialized
INFO - 2022-03-08 22:46:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:46:09 --> Calendar Class Initialized
INFO - 2022-03-08 22:46:09 --> Model "Login_model" initialized
INFO - 2022-03-08 22:46:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 22:46:09 --> Final output sent to browser
DEBUG - 2022-03-08 22:46:09 --> Total execution time: 0.0238
ERROR - 2022-03-08 22:46:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:46:48 --> Config Class Initialized
INFO - 2022-03-08 22:46:48 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:46:48 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:46:48 --> Utf8 Class Initialized
INFO - 2022-03-08 22:46:48 --> URI Class Initialized
INFO - 2022-03-08 22:46:48 --> Router Class Initialized
INFO - 2022-03-08 22:46:48 --> Output Class Initialized
INFO - 2022-03-08 22:46:48 --> Security Class Initialized
DEBUG - 2022-03-08 22:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:46:48 --> Input Class Initialized
INFO - 2022-03-08 22:46:48 --> Language Class Initialized
INFO - 2022-03-08 22:46:48 --> Loader Class Initialized
INFO - 2022-03-08 22:46:48 --> Helper loaded: url_helper
INFO - 2022-03-08 22:46:48 --> Helper loaded: form_helper
INFO - 2022-03-08 22:46:48 --> Helper loaded: common_helper
INFO - 2022-03-08 22:46:48 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:46:48 --> Controller Class Initialized
INFO - 2022-03-08 22:46:48 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:46:48 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:46:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:46:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:46:48 --> Email Class Initialized
INFO - 2022-03-08 22:46:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:46:48 --> Calendar Class Initialized
INFO - 2022-03-08 22:46:48 --> Model "Login_model" initialized
INFO - 2022-03-08 22:46:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 22:46:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:46:48 --> Config Class Initialized
INFO - 2022-03-08 22:46:48 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:46:48 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:46:48 --> Utf8 Class Initialized
INFO - 2022-03-08 22:46:48 --> URI Class Initialized
INFO - 2022-03-08 22:46:48 --> Router Class Initialized
INFO - 2022-03-08 22:46:48 --> Output Class Initialized
INFO - 2022-03-08 22:46:48 --> Security Class Initialized
DEBUG - 2022-03-08 22:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:46:48 --> Input Class Initialized
INFO - 2022-03-08 22:46:48 --> Language Class Initialized
INFO - 2022-03-08 22:46:48 --> Loader Class Initialized
INFO - 2022-03-08 22:46:48 --> Helper loaded: url_helper
INFO - 2022-03-08 22:46:48 --> Helper loaded: form_helper
INFO - 2022-03-08 22:46:48 --> Helper loaded: common_helper
INFO - 2022-03-08 22:46:48 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:46:48 --> Controller Class Initialized
INFO - 2022-03-08 22:46:48 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:46:48 --> Encrypt Class Initialized
INFO - 2022-03-08 22:46:48 --> Model "Login_model" initialized
INFO - 2022-03-08 22:46:48 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 22:46:48 --> Model "Case_model" initialized
INFO - 2022-03-08 22:46:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:47:07 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 22:47:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:47:07 --> Final output sent to browser
DEBUG - 2022-03-08 22:47:07 --> Total execution time: 18.5945
ERROR - 2022-03-08 22:47:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:47:08 --> Config Class Initialized
INFO - 2022-03-08 22:47:08 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:47:08 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:47:08 --> Utf8 Class Initialized
INFO - 2022-03-08 22:47:08 --> URI Class Initialized
INFO - 2022-03-08 22:47:08 --> Router Class Initialized
INFO - 2022-03-08 22:47:08 --> Output Class Initialized
INFO - 2022-03-08 22:47:08 --> Security Class Initialized
DEBUG - 2022-03-08 22:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:47:08 --> Input Class Initialized
INFO - 2022-03-08 22:47:08 --> Language Class Initialized
ERROR - 2022-03-08 22:47:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 22:47:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:47:17 --> Config Class Initialized
INFO - 2022-03-08 22:47:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:47:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:47:17 --> Utf8 Class Initialized
INFO - 2022-03-08 22:47:17 --> URI Class Initialized
INFO - 2022-03-08 22:47:17 --> Router Class Initialized
INFO - 2022-03-08 22:47:17 --> Output Class Initialized
INFO - 2022-03-08 22:47:17 --> Security Class Initialized
DEBUG - 2022-03-08 22:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:47:17 --> Input Class Initialized
INFO - 2022-03-08 22:47:17 --> Language Class Initialized
INFO - 2022-03-08 22:47:17 --> Loader Class Initialized
INFO - 2022-03-08 22:47:17 --> Helper loaded: url_helper
INFO - 2022-03-08 22:47:17 --> Helper loaded: form_helper
INFO - 2022-03-08 22:47:17 --> Helper loaded: common_helper
INFO - 2022-03-08 22:47:17 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:47:17 --> Controller Class Initialized
INFO - 2022-03-08 22:47:17 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:47:17 --> Encrypt Class Initialized
INFO - 2022-03-08 22:47:17 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:47:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:47:17 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:47:17 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:47:17 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:47:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:47:22 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:47:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 22:47:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:47:24 --> Config Class Initialized
INFO - 2022-03-08 22:47:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:47:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:47:24 --> Utf8 Class Initialized
INFO - 2022-03-08 22:47:24 --> URI Class Initialized
INFO - 2022-03-08 22:47:24 --> Router Class Initialized
INFO - 2022-03-08 22:47:24 --> Output Class Initialized
INFO - 2022-03-08 22:47:24 --> Security Class Initialized
DEBUG - 2022-03-08 22:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:47:24 --> Input Class Initialized
INFO - 2022-03-08 22:47:24 --> Language Class Initialized
ERROR - 2022-03-08 22:47:24 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 22:47:24 --> Final output sent to browser
DEBUG - 2022-03-08 22:47:24 --> Total execution time: 5.5799
ERROR - 2022-03-08 22:47:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:47:53 --> Config Class Initialized
INFO - 2022-03-08 22:47:53 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:47:53 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:47:53 --> Utf8 Class Initialized
INFO - 2022-03-08 22:47:53 --> URI Class Initialized
INFO - 2022-03-08 22:47:53 --> Router Class Initialized
INFO - 2022-03-08 22:47:53 --> Output Class Initialized
INFO - 2022-03-08 22:47:53 --> Security Class Initialized
DEBUG - 2022-03-08 22:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:47:53 --> Input Class Initialized
INFO - 2022-03-08 22:47:53 --> Language Class Initialized
INFO - 2022-03-08 22:47:53 --> Loader Class Initialized
INFO - 2022-03-08 22:47:53 --> Helper loaded: url_helper
INFO - 2022-03-08 22:47:53 --> Helper loaded: form_helper
INFO - 2022-03-08 22:47:53 --> Helper loaded: common_helper
INFO - 2022-03-08 22:47:53 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:47:53 --> Controller Class Initialized
INFO - 2022-03-08 22:47:53 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:47:53 --> Encrypt Class Initialized
INFO - 2022-03-08 22:47:53 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:47:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:47:53 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:47:53 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:47:53 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:47:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:47:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 22:47:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:47:53 --> Final output sent to browser
DEBUG - 2022-03-08 22:47:53 --> Total execution time: 0.0426
ERROR - 2022-03-08 22:47:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:47:54 --> Config Class Initialized
INFO - 2022-03-08 22:47:54 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:47:54 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:47:54 --> Utf8 Class Initialized
INFO - 2022-03-08 22:47:54 --> URI Class Initialized
INFO - 2022-03-08 22:47:54 --> Router Class Initialized
INFO - 2022-03-08 22:47:54 --> Output Class Initialized
INFO - 2022-03-08 22:47:54 --> Security Class Initialized
DEBUG - 2022-03-08 22:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:47:54 --> Input Class Initialized
INFO - 2022-03-08 22:47:54 --> Language Class Initialized
ERROR - 2022-03-08 22:47:54 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 22:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:48:17 --> Config Class Initialized
INFO - 2022-03-08 22:48:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:48:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:48:17 --> Utf8 Class Initialized
INFO - 2022-03-08 22:48:17 --> URI Class Initialized
INFO - 2022-03-08 22:48:17 --> Router Class Initialized
INFO - 2022-03-08 22:48:17 --> Output Class Initialized
INFO - 2022-03-08 22:48:17 --> Security Class Initialized
DEBUG - 2022-03-08 22:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:48:17 --> Input Class Initialized
INFO - 2022-03-08 22:48:17 --> Language Class Initialized
INFO - 2022-03-08 22:48:17 --> Loader Class Initialized
INFO - 2022-03-08 22:48:17 --> Helper loaded: url_helper
INFO - 2022-03-08 22:48:17 --> Helper loaded: form_helper
INFO - 2022-03-08 22:48:17 --> Helper loaded: common_helper
INFO - 2022-03-08 22:48:17 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:48:17 --> Controller Class Initialized
INFO - 2022-03-08 22:48:17 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:48:17 --> Encrypt Class Initialized
INFO - 2022-03-08 22:48:17 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:48:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:48:17 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:48:17 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:48:17 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:48:17 --> Upload Class Initialized
INFO - 2022-03-08 22:48:17 --> Final output sent to browser
DEBUG - 2022-03-08 22:48:17 --> Total execution time: 0.0556
ERROR - 2022-03-08 22:48:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:48:19 --> Config Class Initialized
INFO - 2022-03-08 22:48:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:48:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:48:19 --> Utf8 Class Initialized
INFO - 2022-03-08 22:48:19 --> URI Class Initialized
INFO - 2022-03-08 22:48:19 --> Router Class Initialized
INFO - 2022-03-08 22:48:19 --> Output Class Initialized
INFO - 2022-03-08 22:48:19 --> Security Class Initialized
DEBUG - 2022-03-08 22:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:48:19 --> Input Class Initialized
INFO - 2022-03-08 22:48:19 --> Language Class Initialized
INFO - 2022-03-08 22:48:19 --> Loader Class Initialized
INFO - 2022-03-08 22:48:19 --> Helper loaded: url_helper
INFO - 2022-03-08 22:48:19 --> Helper loaded: form_helper
INFO - 2022-03-08 22:48:19 --> Helper loaded: common_helper
INFO - 2022-03-08 22:48:19 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:48:19 --> Controller Class Initialized
INFO - 2022-03-08 22:48:19 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:48:19 --> Encrypt Class Initialized
INFO - 2022-03-08 22:48:19 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:48:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:48:19 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:48:19 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:48:19 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:48:19 --> Upload Class Initialized
INFO - 2022-03-08 22:48:19 --> Final output sent to browser
DEBUG - 2022-03-08 22:48:19 --> Total execution time: 0.0240
ERROR - 2022-03-08 22:48:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:48:46 --> Config Class Initialized
INFO - 2022-03-08 22:48:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:48:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:48:46 --> Utf8 Class Initialized
INFO - 2022-03-08 22:48:46 --> URI Class Initialized
INFO - 2022-03-08 22:48:46 --> Router Class Initialized
INFO - 2022-03-08 22:48:46 --> Output Class Initialized
INFO - 2022-03-08 22:48:46 --> Security Class Initialized
DEBUG - 2022-03-08 22:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:48:46 --> Input Class Initialized
INFO - 2022-03-08 22:48:46 --> Language Class Initialized
INFO - 2022-03-08 22:48:46 --> Loader Class Initialized
INFO - 2022-03-08 22:48:46 --> Helper loaded: url_helper
INFO - 2022-03-08 22:48:46 --> Helper loaded: form_helper
INFO - 2022-03-08 22:48:46 --> Helper loaded: common_helper
INFO - 2022-03-08 22:48:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:48:46 --> Controller Class Initialized
INFO - 2022-03-08 22:48:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:48:46 --> Encrypt Class Initialized
INFO - 2022-03-08 22:48:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:48:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:48:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:48:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:48:46 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 22:48:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:48:46 --> Config Class Initialized
INFO - 2022-03-08 22:48:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:48:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:48:46 --> Utf8 Class Initialized
INFO - 2022-03-08 22:48:46 --> URI Class Initialized
INFO - 2022-03-08 22:48:46 --> Router Class Initialized
INFO - 2022-03-08 22:48:46 --> Output Class Initialized
INFO - 2022-03-08 22:48:46 --> Security Class Initialized
DEBUG - 2022-03-08 22:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:48:46 --> Input Class Initialized
INFO - 2022-03-08 22:48:46 --> Language Class Initialized
INFO - 2022-03-08 22:48:46 --> Loader Class Initialized
INFO - 2022-03-08 22:48:46 --> Helper loaded: url_helper
INFO - 2022-03-08 22:48:46 --> Helper loaded: form_helper
INFO - 2022-03-08 22:48:46 --> Helper loaded: common_helper
INFO - 2022-03-08 22:48:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:48:46 --> Controller Class Initialized
INFO - 2022-03-08 22:48:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:48:46 --> Encrypt Class Initialized
INFO - 2022-03-08 22:48:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:48:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:48:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:48:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:48:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:48:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:48:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 22:48:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:48:46 --> Final output sent to browser
DEBUG - 2022-03-08 22:48:46 --> Total execution time: 0.0443
ERROR - 2022-03-08 22:48:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:48:47 --> Config Class Initialized
INFO - 2022-03-08 22:48:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:48:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:48:47 --> Utf8 Class Initialized
INFO - 2022-03-08 22:48:47 --> URI Class Initialized
INFO - 2022-03-08 22:48:47 --> Router Class Initialized
INFO - 2022-03-08 22:48:47 --> Output Class Initialized
INFO - 2022-03-08 22:48:47 --> Security Class Initialized
DEBUG - 2022-03-08 22:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:48:47 --> Input Class Initialized
INFO - 2022-03-08 22:48:47 --> Language Class Initialized
ERROR - 2022-03-08 22:48:47 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 22:48:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:48:47 --> Config Class Initialized
INFO - 2022-03-08 22:48:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:48:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:48:47 --> Utf8 Class Initialized
INFO - 2022-03-08 22:48:47 --> URI Class Initialized
INFO - 2022-03-08 22:48:47 --> Router Class Initialized
INFO - 2022-03-08 22:48:47 --> Output Class Initialized
INFO - 2022-03-08 22:48:47 --> Security Class Initialized
DEBUG - 2022-03-08 22:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:48:47 --> Input Class Initialized
INFO - 2022-03-08 22:48:47 --> Language Class Initialized
INFO - 2022-03-08 22:48:47 --> Loader Class Initialized
INFO - 2022-03-08 22:48:47 --> Helper loaded: url_helper
INFO - 2022-03-08 22:48:47 --> Helper loaded: form_helper
INFO - 2022-03-08 22:48:47 --> Helper loaded: common_helper
INFO - 2022-03-08 22:48:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:48:47 --> Controller Class Initialized
INFO - 2022-03-08 22:48:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:48:47 --> Encrypt Class Initialized
INFO - 2022-03-08 22:48:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:48:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:48:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:48:47 --> Model "Users_model" initialized
INFO - 2022-03-08 22:48:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:48:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:48:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:48:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:48:47 --> Final output sent to browser
DEBUG - 2022-03-08 22:48:47 --> Total execution time: 0.0531
ERROR - 2022-03-08 22:48:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:48:48 --> Config Class Initialized
INFO - 2022-03-08 22:48:48 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:48:48 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:48:48 --> Utf8 Class Initialized
INFO - 2022-03-08 22:48:48 --> URI Class Initialized
INFO - 2022-03-08 22:48:48 --> Router Class Initialized
INFO - 2022-03-08 22:48:48 --> Output Class Initialized
INFO - 2022-03-08 22:48:48 --> Security Class Initialized
DEBUG - 2022-03-08 22:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:48:48 --> Input Class Initialized
INFO - 2022-03-08 22:48:48 --> Language Class Initialized
ERROR - 2022-03-08 22:48:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 22:50:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:50:37 --> Config Class Initialized
INFO - 2022-03-08 22:50:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:50:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:50:37 --> Utf8 Class Initialized
INFO - 2022-03-08 22:50:37 --> URI Class Initialized
INFO - 2022-03-08 22:50:37 --> Router Class Initialized
INFO - 2022-03-08 22:50:37 --> Output Class Initialized
INFO - 2022-03-08 22:50:37 --> Security Class Initialized
DEBUG - 2022-03-08 22:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:50:37 --> Input Class Initialized
INFO - 2022-03-08 22:50:37 --> Language Class Initialized
INFO - 2022-03-08 22:50:37 --> Loader Class Initialized
INFO - 2022-03-08 22:50:37 --> Helper loaded: url_helper
INFO - 2022-03-08 22:50:37 --> Helper loaded: form_helper
INFO - 2022-03-08 22:50:37 --> Helper loaded: common_helper
INFO - 2022-03-08 22:50:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:50:37 --> Controller Class Initialized
INFO - 2022-03-08 22:50:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:50:37 --> Encrypt Class Initialized
INFO - 2022-03-08 22:50:37 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:50:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:50:37 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:50:37 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:50:37 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:50:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:50:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:50:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:50:37 --> Final output sent to browser
DEBUG - 2022-03-08 22:50:37 --> Total execution time: 0.0303
ERROR - 2022-03-08 22:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:50:47 --> Config Class Initialized
INFO - 2022-03-08 22:50:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:50:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:50:47 --> Utf8 Class Initialized
INFO - 2022-03-08 22:50:47 --> URI Class Initialized
INFO - 2022-03-08 22:50:47 --> Router Class Initialized
INFO - 2022-03-08 22:50:47 --> Output Class Initialized
INFO - 2022-03-08 22:50:47 --> Security Class Initialized
DEBUG - 2022-03-08 22:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:50:47 --> Input Class Initialized
INFO - 2022-03-08 22:50:47 --> Language Class Initialized
INFO - 2022-03-08 22:50:47 --> Loader Class Initialized
INFO - 2022-03-08 22:50:47 --> Helper loaded: url_helper
INFO - 2022-03-08 22:50:47 --> Helper loaded: form_helper
INFO - 2022-03-08 22:50:47 --> Helper loaded: common_helper
INFO - 2022-03-08 22:50:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:50:47 --> Controller Class Initialized
INFO - 2022-03-08 22:50:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:50:47 --> Encrypt Class Initialized
INFO - 2022-03-08 22:50:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:50:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:50:47 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:50:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:50:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:50:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:50:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:50:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:50:47 --> Final output sent to browser
DEBUG - 2022-03-08 22:50:47 --> Total execution time: 0.0514
ERROR - 2022-03-08 22:51:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:51:56 --> Config Class Initialized
INFO - 2022-03-08 22:51:56 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:51:56 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:51:56 --> Utf8 Class Initialized
INFO - 2022-03-08 22:51:56 --> URI Class Initialized
INFO - 2022-03-08 22:51:56 --> Router Class Initialized
INFO - 2022-03-08 22:51:56 --> Output Class Initialized
INFO - 2022-03-08 22:51:56 --> Security Class Initialized
DEBUG - 2022-03-08 22:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:51:56 --> Input Class Initialized
INFO - 2022-03-08 22:51:56 --> Language Class Initialized
INFO - 2022-03-08 22:51:56 --> Loader Class Initialized
INFO - 2022-03-08 22:51:56 --> Helper loaded: url_helper
INFO - 2022-03-08 22:51:56 --> Helper loaded: form_helper
INFO - 2022-03-08 22:51:56 --> Helper loaded: common_helper
INFO - 2022-03-08 22:51:56 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:51:56 --> Controller Class Initialized
INFO - 2022-03-08 22:51:56 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:51:56 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:51:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:51:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:51:56 --> Email Class Initialized
INFO - 2022-03-08 22:51:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:51:56 --> Calendar Class Initialized
INFO - 2022-03-08 22:51:56 --> Model "Login_model" initialized
ERROR - 2022-03-08 22:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:51:57 --> Config Class Initialized
INFO - 2022-03-08 22:51:57 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:51:57 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:51:57 --> Utf8 Class Initialized
INFO - 2022-03-08 22:51:57 --> URI Class Initialized
INFO - 2022-03-08 22:51:57 --> Router Class Initialized
INFO - 2022-03-08 22:51:57 --> Output Class Initialized
INFO - 2022-03-08 22:51:57 --> Security Class Initialized
DEBUG - 2022-03-08 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:51:57 --> Input Class Initialized
INFO - 2022-03-08 22:51:57 --> Language Class Initialized
INFO - 2022-03-08 22:51:57 --> Loader Class Initialized
INFO - 2022-03-08 22:51:57 --> Helper loaded: url_helper
INFO - 2022-03-08 22:51:57 --> Helper loaded: form_helper
INFO - 2022-03-08 22:51:57 --> Helper loaded: common_helper
INFO - 2022-03-08 22:51:57 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:51:57 --> Controller Class Initialized
INFO - 2022-03-08 22:51:57 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:51:57 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:51:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:51:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:51:57 --> Email Class Initialized
INFO - 2022-03-08 22:51:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:51:57 --> Calendar Class Initialized
INFO - 2022-03-08 22:51:57 --> Model "Login_model" initialized
INFO - 2022-03-08 22:51:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 22:51:57 --> Final output sent to browser
DEBUG - 2022-03-08 22:51:57 --> Total execution time: 0.0226
ERROR - 2022-03-08 22:52:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:52:04 --> Config Class Initialized
INFO - 2022-03-08 22:52:04 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:52:04 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:52:04 --> Utf8 Class Initialized
INFO - 2022-03-08 22:52:04 --> URI Class Initialized
INFO - 2022-03-08 22:52:04 --> Router Class Initialized
INFO - 2022-03-08 22:52:04 --> Output Class Initialized
INFO - 2022-03-08 22:52:04 --> Security Class Initialized
DEBUG - 2022-03-08 22:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:52:04 --> Input Class Initialized
INFO - 2022-03-08 22:52:04 --> Language Class Initialized
INFO - 2022-03-08 22:52:04 --> Loader Class Initialized
INFO - 2022-03-08 22:52:04 --> Helper loaded: url_helper
INFO - 2022-03-08 22:52:04 --> Helper loaded: form_helper
INFO - 2022-03-08 22:52:04 --> Helper loaded: common_helper
INFO - 2022-03-08 22:52:04 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:52:04 --> Controller Class Initialized
INFO - 2022-03-08 22:52:04 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:52:04 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:52:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:52:04 --> Email Class Initialized
INFO - 2022-03-08 22:52:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:52:04 --> Calendar Class Initialized
INFO - 2022-03-08 22:52:04 --> Model "Login_model" initialized
INFO - 2022-03-08 22:52:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 22:52:04 --> Final output sent to browser
DEBUG - 2022-03-08 22:52:04 --> Total execution time: 0.0332
ERROR - 2022-03-08 22:52:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:52:16 --> Config Class Initialized
INFO - 2022-03-08 22:52:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:52:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:52:16 --> Utf8 Class Initialized
INFO - 2022-03-08 22:52:16 --> URI Class Initialized
INFO - 2022-03-08 22:52:16 --> Router Class Initialized
INFO - 2022-03-08 22:52:16 --> Output Class Initialized
INFO - 2022-03-08 22:52:16 --> Security Class Initialized
DEBUG - 2022-03-08 22:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:52:16 --> Input Class Initialized
INFO - 2022-03-08 22:52:16 --> Language Class Initialized
INFO - 2022-03-08 22:52:16 --> Loader Class Initialized
INFO - 2022-03-08 22:52:16 --> Helper loaded: url_helper
INFO - 2022-03-08 22:52:16 --> Helper loaded: form_helper
INFO - 2022-03-08 22:52:16 --> Helper loaded: common_helper
INFO - 2022-03-08 22:52:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:52:16 --> Controller Class Initialized
INFO - 2022-03-08 22:52:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:52:16 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:52:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:52:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:52:16 --> Email Class Initialized
INFO - 2022-03-08 22:52:16 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:52:16 --> Calendar Class Initialized
INFO - 2022-03-08 22:52:16 --> Model "Login_model" initialized
INFO - 2022-03-08 22:52:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 22:52:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:52:16 --> Config Class Initialized
INFO - 2022-03-08 22:52:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:52:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:52:16 --> Utf8 Class Initialized
INFO - 2022-03-08 22:52:16 --> URI Class Initialized
INFO - 2022-03-08 22:52:16 --> Router Class Initialized
INFO - 2022-03-08 22:52:16 --> Output Class Initialized
INFO - 2022-03-08 22:52:16 --> Security Class Initialized
DEBUG - 2022-03-08 22:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:52:16 --> Input Class Initialized
INFO - 2022-03-08 22:52:16 --> Language Class Initialized
INFO - 2022-03-08 22:52:16 --> Loader Class Initialized
INFO - 2022-03-08 22:52:16 --> Helper loaded: url_helper
INFO - 2022-03-08 22:52:16 --> Helper loaded: form_helper
INFO - 2022-03-08 22:52:16 --> Helper loaded: common_helper
INFO - 2022-03-08 22:52:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:52:16 --> Controller Class Initialized
INFO - 2022-03-08 22:52:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:52:16 --> Encrypt Class Initialized
INFO - 2022-03-08 22:52:16 --> Model "Login_model" initialized
INFO - 2022-03-08 22:52:16 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 22:52:16 --> Model "Case_model" initialized
INFO - 2022-03-08 22:52:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:52:16 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 22:52:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:52:16 --> Final output sent to browser
DEBUG - 2022-03-08 22:52:16 --> Total execution time: 0.1184
ERROR - 2022-03-08 22:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:52:24 --> Config Class Initialized
INFO - 2022-03-08 22:52:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:52:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:52:24 --> Utf8 Class Initialized
INFO - 2022-03-08 22:52:24 --> URI Class Initialized
INFO - 2022-03-08 22:52:24 --> Router Class Initialized
INFO - 2022-03-08 22:52:24 --> Output Class Initialized
INFO - 2022-03-08 22:52:24 --> Security Class Initialized
DEBUG - 2022-03-08 22:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:52:24 --> Input Class Initialized
INFO - 2022-03-08 22:52:24 --> Language Class Initialized
INFO - 2022-03-08 22:52:24 --> Loader Class Initialized
INFO - 2022-03-08 22:52:24 --> Helper loaded: url_helper
INFO - 2022-03-08 22:52:24 --> Helper loaded: form_helper
INFO - 2022-03-08 22:52:24 --> Helper loaded: common_helper
INFO - 2022-03-08 22:52:24 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:52:24 --> Controller Class Initialized
INFO - 2022-03-08 22:52:24 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:52:24 --> Encrypt Class Initialized
INFO - 2022-03-08 22:52:24 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:52:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:52:24 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:52:24 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:52:24 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:52:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:52:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:52:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:52:24 --> Final output sent to browser
DEBUG - 2022-03-08 22:52:24 --> Total execution time: 0.0451
ERROR - 2022-03-08 22:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:52:41 --> Config Class Initialized
INFO - 2022-03-08 22:52:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:52:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:52:41 --> Utf8 Class Initialized
INFO - 2022-03-08 22:52:41 --> URI Class Initialized
INFO - 2022-03-08 22:52:41 --> Router Class Initialized
INFO - 2022-03-08 22:52:41 --> Output Class Initialized
INFO - 2022-03-08 22:52:41 --> Security Class Initialized
DEBUG - 2022-03-08 22:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:52:41 --> Input Class Initialized
INFO - 2022-03-08 22:52:41 --> Language Class Initialized
INFO - 2022-03-08 22:52:41 --> Loader Class Initialized
INFO - 2022-03-08 22:52:41 --> Helper loaded: url_helper
INFO - 2022-03-08 22:52:41 --> Helper loaded: form_helper
INFO - 2022-03-08 22:52:41 --> Helper loaded: common_helper
INFO - 2022-03-08 22:52:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:52:41 --> Controller Class Initialized
INFO - 2022-03-08 22:52:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:52:41 --> Encrypt Class Initialized
INFO - 2022-03-08 22:52:41 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:52:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:52:41 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:52:41 --> Model "Users_model" initialized
INFO - 2022-03-08 22:52:41 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:52:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:52:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:52:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:52:41 --> Final output sent to browser
DEBUG - 2022-03-08 22:52:41 --> Total execution time: 0.0584
ERROR - 2022-03-08 22:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:52:48 --> Config Class Initialized
INFO - 2022-03-08 22:52:48 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:52:48 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:52:48 --> Utf8 Class Initialized
INFO - 2022-03-08 22:52:48 --> URI Class Initialized
INFO - 2022-03-08 22:52:48 --> Router Class Initialized
INFO - 2022-03-08 22:52:48 --> Output Class Initialized
INFO - 2022-03-08 22:52:48 --> Security Class Initialized
DEBUG - 2022-03-08 22:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:52:48 --> Input Class Initialized
INFO - 2022-03-08 22:52:48 --> Language Class Initialized
INFO - 2022-03-08 22:52:48 --> Loader Class Initialized
INFO - 2022-03-08 22:52:48 --> Helper loaded: url_helper
INFO - 2022-03-08 22:52:48 --> Helper loaded: form_helper
INFO - 2022-03-08 22:52:48 --> Helper loaded: common_helper
INFO - 2022-03-08 22:52:48 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:52:48 --> Controller Class Initialized
INFO - 2022-03-08 22:52:48 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:52:48 --> Encrypt Class Initialized
INFO - 2022-03-08 22:52:48 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:52:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:52:48 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:52:48 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:52:48 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:52:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:52:48 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 22:52:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:52:48 --> Final output sent to browser
DEBUG - 2022-03-08 22:52:48 --> Total execution time: 0.0472
ERROR - 2022-03-08 22:53:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:53:08 --> Config Class Initialized
INFO - 2022-03-08 22:53:08 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:53:08 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:53:08 --> Utf8 Class Initialized
INFO - 2022-03-08 22:53:08 --> URI Class Initialized
INFO - 2022-03-08 22:53:08 --> Router Class Initialized
INFO - 2022-03-08 22:53:08 --> Output Class Initialized
INFO - 2022-03-08 22:53:08 --> Security Class Initialized
DEBUG - 2022-03-08 22:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:53:08 --> Input Class Initialized
INFO - 2022-03-08 22:53:08 --> Language Class Initialized
INFO - 2022-03-08 22:53:08 --> Loader Class Initialized
INFO - 2022-03-08 22:53:08 --> Helper loaded: url_helper
INFO - 2022-03-08 22:53:08 --> Helper loaded: form_helper
INFO - 2022-03-08 22:53:08 --> Helper loaded: common_helper
INFO - 2022-03-08 22:53:08 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:53:08 --> Controller Class Initialized
INFO - 2022-03-08 22:53:08 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:53:08 --> Encrypt Class Initialized
INFO - 2022-03-08 22:53:08 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:53:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:53:08 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:53:08 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:53:08 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 22:53:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:53:08 --> Config Class Initialized
INFO - 2022-03-08 22:53:08 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:53:08 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:53:08 --> Utf8 Class Initialized
INFO - 2022-03-08 22:53:08 --> URI Class Initialized
INFO - 2022-03-08 22:53:08 --> Router Class Initialized
INFO - 2022-03-08 22:53:08 --> Output Class Initialized
INFO - 2022-03-08 22:53:08 --> Security Class Initialized
DEBUG - 2022-03-08 22:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:53:08 --> Input Class Initialized
INFO - 2022-03-08 22:53:08 --> Language Class Initialized
INFO - 2022-03-08 22:53:08 --> Loader Class Initialized
INFO - 2022-03-08 22:53:08 --> Helper loaded: url_helper
INFO - 2022-03-08 22:53:08 --> Helper loaded: form_helper
INFO - 2022-03-08 22:53:08 --> Helper loaded: common_helper
INFO - 2022-03-08 22:53:08 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:53:08 --> Controller Class Initialized
INFO - 2022-03-08 22:53:08 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:53:08 --> Encrypt Class Initialized
INFO - 2022-03-08 22:53:08 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:53:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:53:08 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:53:08 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:53:08 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:53:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:53:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 22:53:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:53:08 --> Final output sent to browser
DEBUG - 2022-03-08 22:53:08 --> Total execution time: 0.0483
ERROR - 2022-03-08 22:53:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:53:09 --> Config Class Initialized
INFO - 2022-03-08 22:53:09 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:53:09 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:53:09 --> Utf8 Class Initialized
INFO - 2022-03-08 22:53:09 --> URI Class Initialized
INFO - 2022-03-08 22:53:09 --> Router Class Initialized
INFO - 2022-03-08 22:53:09 --> Output Class Initialized
INFO - 2022-03-08 22:53:09 --> Security Class Initialized
DEBUG - 2022-03-08 22:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:53:09 --> Input Class Initialized
INFO - 2022-03-08 22:53:09 --> Language Class Initialized
INFO - 2022-03-08 22:53:09 --> Loader Class Initialized
INFO - 2022-03-08 22:53:09 --> Helper loaded: url_helper
INFO - 2022-03-08 22:53:09 --> Helper loaded: form_helper
INFO - 2022-03-08 22:53:09 --> Helper loaded: common_helper
INFO - 2022-03-08 22:53:09 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:53:09 --> Controller Class Initialized
INFO - 2022-03-08 22:53:09 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:53:09 --> Encrypt Class Initialized
INFO - 2022-03-08 22:53:09 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:53:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:53:09 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:53:09 --> Model "Users_model" initialized
INFO - 2022-03-08 22:53:09 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:53:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:53:09 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:53:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:53:09 --> Final output sent to browser
DEBUG - 2022-03-08 22:53:09 --> Total execution time: 0.0866
ERROR - 2022-03-08 22:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:53:46 --> Config Class Initialized
INFO - 2022-03-08 22:53:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:53:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:53:46 --> Utf8 Class Initialized
INFO - 2022-03-08 22:53:46 --> URI Class Initialized
INFO - 2022-03-08 22:53:46 --> Router Class Initialized
INFO - 2022-03-08 22:53:46 --> Output Class Initialized
INFO - 2022-03-08 22:53:46 --> Security Class Initialized
DEBUG - 2022-03-08 22:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:53:46 --> Input Class Initialized
INFO - 2022-03-08 22:53:46 --> Language Class Initialized
INFO - 2022-03-08 22:53:46 --> Loader Class Initialized
INFO - 2022-03-08 22:53:46 --> Helper loaded: url_helper
INFO - 2022-03-08 22:53:46 --> Helper loaded: form_helper
INFO - 2022-03-08 22:53:46 --> Helper loaded: common_helper
INFO - 2022-03-08 22:53:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:53:46 --> Controller Class Initialized
INFO - 2022-03-08 22:53:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:53:46 --> Encrypt Class Initialized
INFO - 2022-03-08 22:53:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:53:46 --> Model "Users_model" initialized
INFO - 2022-03-08 22:53:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:53:46 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2022-03-08 22:53:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:53:46 --> Final output sent to browser
DEBUG - 2022-03-08 22:53:46 --> Total execution time: 0.0275
ERROR - 2022-03-08 22:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:53:46 --> Config Class Initialized
INFO - 2022-03-08 22:53:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:53:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:53:46 --> Utf8 Class Initialized
INFO - 2022-03-08 22:53:46 --> URI Class Initialized
INFO - 2022-03-08 22:53:46 --> Router Class Initialized
INFO - 2022-03-08 22:53:46 --> Output Class Initialized
INFO - 2022-03-08 22:53:46 --> Security Class Initialized
DEBUG - 2022-03-08 22:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:53:46 --> Input Class Initialized
INFO - 2022-03-08 22:53:46 --> Language Class Initialized
ERROR - 2022-03-08 22:53:46 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 22:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:00 --> Config Class Initialized
INFO - 2022-03-08 22:54:00 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:00 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:00 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:00 --> URI Class Initialized
INFO - 2022-03-08 22:54:00 --> Router Class Initialized
INFO - 2022-03-08 22:54:00 --> Output Class Initialized
INFO - 2022-03-08 22:54:00 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:00 --> Input Class Initialized
INFO - 2022-03-08 22:54:00 --> Language Class Initialized
INFO - 2022-03-08 22:54:00 --> Loader Class Initialized
INFO - 2022-03-08 22:54:00 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:00 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:00 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:00 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:00 --> Controller Class Initialized
INFO - 2022-03-08 22:54:00 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:00 --> Encrypt Class Initialized
INFO - 2022-03-08 22:54:00 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:54:00 --> Model "Users_model" initialized
INFO - 2022-03-08 22:54:00 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:54:00 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2022-03-08 22:54:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:54:00 --> Final output sent to browser
DEBUG - 2022-03-08 22:54:00 --> Total execution time: 0.0422
ERROR - 2022-03-08 22:54:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:01 --> Config Class Initialized
INFO - 2022-03-08 22:54:01 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:01 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:01 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:01 --> URI Class Initialized
INFO - 2022-03-08 22:54:01 --> Router Class Initialized
INFO - 2022-03-08 22:54:01 --> Output Class Initialized
INFO - 2022-03-08 22:54:01 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:01 --> Input Class Initialized
INFO - 2022-03-08 22:54:01 --> Language Class Initialized
ERROR - 2022-03-08 22:54:01 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 22:54:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:10 --> Config Class Initialized
INFO - 2022-03-08 22:54:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:10 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:10 --> URI Class Initialized
INFO - 2022-03-08 22:54:10 --> Router Class Initialized
INFO - 2022-03-08 22:54:10 --> Output Class Initialized
INFO - 2022-03-08 22:54:10 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:10 --> Input Class Initialized
INFO - 2022-03-08 22:54:10 --> Language Class Initialized
INFO - 2022-03-08 22:54:10 --> Loader Class Initialized
INFO - 2022-03-08 22:54:10 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:10 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:10 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:10 --> Controller Class Initialized
INFO - 2022-03-08 22:54:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:10 --> Encrypt Class Initialized
INFO - 2022-03-08 22:54:10 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:54:10 --> Model "Users_model" initialized
INFO - 2022-03-08 22:54:10 --> Upload Class Initialized
ERROR - 2022-03-08 22:54:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:11 --> Config Class Initialized
INFO - 2022-03-08 22:54:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:11 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:11 --> URI Class Initialized
INFO - 2022-03-08 22:54:11 --> Router Class Initialized
INFO - 2022-03-08 22:54:11 --> Output Class Initialized
INFO - 2022-03-08 22:54:11 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:11 --> Input Class Initialized
INFO - 2022-03-08 22:54:11 --> Language Class Initialized
INFO - 2022-03-08 22:54:11 --> Loader Class Initialized
INFO - 2022-03-08 22:54:11 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:11 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:11 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:11 --> Controller Class Initialized
INFO - 2022-03-08 22:54:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:11 --> Encrypt Class Initialized
INFO - 2022-03-08 22:54:11 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:54:11 --> Model "Users_model" initialized
INFO - 2022-03-08 22:54:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:54:11 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2022-03-08 22:54:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:54:11 --> Final output sent to browser
DEBUG - 2022-03-08 22:54:11 --> Total execution time: 0.0268
ERROR - 2022-03-08 22:54:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:12 --> Config Class Initialized
INFO - 2022-03-08 22:54:12 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:12 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:12 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:12 --> URI Class Initialized
INFO - 2022-03-08 22:54:12 --> Router Class Initialized
INFO - 2022-03-08 22:54:12 --> Output Class Initialized
INFO - 2022-03-08 22:54:12 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:12 --> Input Class Initialized
INFO - 2022-03-08 22:54:12 --> Language Class Initialized
ERROR - 2022-03-08 22:54:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 22:54:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:28 --> Config Class Initialized
INFO - 2022-03-08 22:54:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:28 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:28 --> URI Class Initialized
INFO - 2022-03-08 22:54:28 --> Router Class Initialized
INFO - 2022-03-08 22:54:28 --> Output Class Initialized
INFO - 2022-03-08 22:54:28 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:28 --> Input Class Initialized
INFO - 2022-03-08 22:54:28 --> Language Class Initialized
INFO - 2022-03-08 22:54:28 --> Loader Class Initialized
INFO - 2022-03-08 22:54:28 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:28 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:28 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:28 --> Controller Class Initialized
INFO - 2022-03-08 22:54:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:28 --> Encrypt Class Initialized
INFO - 2022-03-08 22:54:28 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:54:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:54:28 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:54:28 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:54:28 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:54:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:54:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:54:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:54:28 --> Final output sent to browser
DEBUG - 2022-03-08 22:54:28 --> Total execution time: 0.0691
ERROR - 2022-03-08 22:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:35 --> Config Class Initialized
INFO - 2022-03-08 22:54:35 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:35 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:35 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:35 --> URI Class Initialized
INFO - 2022-03-08 22:54:35 --> Router Class Initialized
INFO - 2022-03-08 22:54:35 --> Output Class Initialized
INFO - 2022-03-08 22:54:35 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:35 --> Input Class Initialized
INFO - 2022-03-08 22:54:35 --> Language Class Initialized
INFO - 2022-03-08 22:54:35 --> Loader Class Initialized
INFO - 2022-03-08 22:54:35 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:35 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:35 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:35 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:35 --> Controller Class Initialized
INFO - 2022-03-08 22:54:35 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:35 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:54:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:54:35 --> Email Class Initialized
INFO - 2022-03-08 22:54:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:54:35 --> Calendar Class Initialized
INFO - 2022-03-08 22:54:35 --> Model "Login_model" initialized
ERROR - 2022-03-08 22:54:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:36 --> Config Class Initialized
INFO - 2022-03-08 22:54:36 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:36 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:36 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:36 --> URI Class Initialized
INFO - 2022-03-08 22:54:36 --> Router Class Initialized
INFO - 2022-03-08 22:54:36 --> Output Class Initialized
INFO - 2022-03-08 22:54:36 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:36 --> Input Class Initialized
INFO - 2022-03-08 22:54:36 --> Language Class Initialized
INFO - 2022-03-08 22:54:36 --> Loader Class Initialized
INFO - 2022-03-08 22:54:36 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:36 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:36 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:36 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:36 --> Controller Class Initialized
INFO - 2022-03-08 22:54:36 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:36 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:54:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:54:36 --> Email Class Initialized
INFO - 2022-03-08 22:54:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:54:36 --> Calendar Class Initialized
INFO - 2022-03-08 22:54:36 --> Model "Login_model" initialized
INFO - 2022-03-08 22:54:36 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 22:54:36 --> Final output sent to browser
DEBUG - 2022-03-08 22:54:36 --> Total execution time: 0.0239
ERROR - 2022-03-08 22:54:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:36 --> Config Class Initialized
INFO - 2022-03-08 22:54:36 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:36 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:36 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:36 --> URI Class Initialized
INFO - 2022-03-08 22:54:36 --> Router Class Initialized
INFO - 2022-03-08 22:54:36 --> Output Class Initialized
INFO - 2022-03-08 22:54:36 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:36 --> Input Class Initialized
INFO - 2022-03-08 22:54:36 --> Language Class Initialized
INFO - 2022-03-08 22:54:36 --> Loader Class Initialized
INFO - 2022-03-08 22:54:36 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:36 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:36 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:36 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:36 --> Controller Class Initialized
INFO - 2022-03-08 22:54:36 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:36 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:54:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:54:36 --> Email Class Initialized
INFO - 2022-03-08 22:54:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:54:36 --> Calendar Class Initialized
INFO - 2022-03-08 22:54:37 --> Model "Login_model" initialized
ERROR - 2022-03-08 22:54:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:37 --> Config Class Initialized
INFO - 2022-03-08 22:54:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:37 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:37 --> URI Class Initialized
INFO - 2022-03-08 22:54:37 --> Router Class Initialized
INFO - 2022-03-08 22:54:37 --> Output Class Initialized
INFO - 2022-03-08 22:54:37 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:37 --> Input Class Initialized
INFO - 2022-03-08 22:54:37 --> Language Class Initialized
INFO - 2022-03-08 22:54:37 --> Loader Class Initialized
INFO - 2022-03-08 22:54:37 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:37 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:37 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:37 --> Controller Class Initialized
INFO - 2022-03-08 22:54:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:37 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:54:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:54:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:54:37 --> Email Class Initialized
INFO - 2022-03-08 22:54:37 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:54:37 --> Calendar Class Initialized
INFO - 2022-03-08 22:54:37 --> Model "Login_model" initialized
INFO - 2022-03-08 22:54:37 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 22:54:37 --> Final output sent to browser
DEBUG - 2022-03-08 22:54:37 --> Total execution time: 0.0244
ERROR - 2022-03-08 22:54:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:41 --> Config Class Initialized
INFO - 2022-03-08 22:54:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:41 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:41 --> URI Class Initialized
INFO - 2022-03-08 22:54:41 --> Router Class Initialized
INFO - 2022-03-08 22:54:41 --> Output Class Initialized
INFO - 2022-03-08 22:54:41 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:41 --> Input Class Initialized
INFO - 2022-03-08 22:54:41 --> Language Class Initialized
INFO - 2022-03-08 22:54:41 --> Loader Class Initialized
INFO - 2022-03-08 22:54:41 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:41 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:41 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:41 --> Controller Class Initialized
INFO - 2022-03-08 22:54:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:41 --> Encrypt Class Initialized
INFO - 2022-03-08 22:54:41 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:54:41 --> Model "Users_model" initialized
ERROR - 2022-03-08 22:54:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:42 --> Config Class Initialized
INFO - 2022-03-08 22:54:42 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:42 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:42 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:42 --> URI Class Initialized
INFO - 2022-03-08 22:54:42 --> Router Class Initialized
INFO - 2022-03-08 22:54:42 --> Output Class Initialized
INFO - 2022-03-08 22:54:42 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:42 --> Input Class Initialized
INFO - 2022-03-08 22:54:42 --> Language Class Initialized
INFO - 2022-03-08 22:54:42 --> Loader Class Initialized
INFO - 2022-03-08 22:54:42 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:42 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:42 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:42 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:42 --> Controller Class Initialized
INFO - 2022-03-08 22:54:42 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:42 --> Encrypt Class Initialized
INFO - 2022-03-08 22:54:42 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:54:42 --> Model "Users_model" initialized
INFO - 2022-03-08 22:54:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:54:42 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2022-03-08 22:54:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:54:42 --> Final output sent to browser
DEBUG - 2022-03-08 22:54:42 --> Total execution time: 0.0246
ERROR - 2022-03-08 22:54:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:42 --> Config Class Initialized
INFO - 2022-03-08 22:54:42 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:42 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:42 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:42 --> URI Class Initialized
INFO - 2022-03-08 22:54:42 --> Router Class Initialized
INFO - 2022-03-08 22:54:42 --> Output Class Initialized
INFO - 2022-03-08 22:54:42 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:42 --> Input Class Initialized
INFO - 2022-03-08 22:54:42 --> Language Class Initialized
ERROR - 2022-03-08 22:54:42 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 22:54:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:51 --> Config Class Initialized
INFO - 2022-03-08 22:54:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:51 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:51 --> URI Class Initialized
INFO - 2022-03-08 22:54:51 --> Router Class Initialized
INFO - 2022-03-08 22:54:51 --> Output Class Initialized
INFO - 2022-03-08 22:54:51 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:51 --> Input Class Initialized
INFO - 2022-03-08 22:54:51 --> Language Class Initialized
INFO - 2022-03-08 22:54:51 --> Loader Class Initialized
INFO - 2022-03-08 22:54:51 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:51 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:51 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:51 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:51 --> Controller Class Initialized
INFO - 2022-03-08 22:54:51 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:51 --> Encrypt Class Initialized
DEBUG - 2022-03-08 22:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 22:54:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 22:54:51 --> Email Class Initialized
INFO - 2022-03-08 22:54:51 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 22:54:51 --> Calendar Class Initialized
INFO - 2022-03-08 22:54:51 --> Model "Login_model" initialized
INFO - 2022-03-08 22:54:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 22:54:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:54:52 --> Config Class Initialized
INFO - 2022-03-08 22:54:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:54:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:54:52 --> Utf8 Class Initialized
INFO - 2022-03-08 22:54:52 --> URI Class Initialized
INFO - 2022-03-08 22:54:52 --> Router Class Initialized
INFO - 2022-03-08 22:54:52 --> Output Class Initialized
INFO - 2022-03-08 22:54:52 --> Security Class Initialized
DEBUG - 2022-03-08 22:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:54:52 --> Input Class Initialized
INFO - 2022-03-08 22:54:52 --> Language Class Initialized
INFO - 2022-03-08 22:54:52 --> Loader Class Initialized
INFO - 2022-03-08 22:54:52 --> Helper loaded: url_helper
INFO - 2022-03-08 22:54:52 --> Helper loaded: form_helper
INFO - 2022-03-08 22:54:52 --> Helper loaded: common_helper
INFO - 2022-03-08 22:54:52 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:54:52 --> Controller Class Initialized
INFO - 2022-03-08 22:54:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:54:52 --> Encrypt Class Initialized
INFO - 2022-03-08 22:54:52 --> Model "Login_model" initialized
INFO - 2022-03-08 22:54:52 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 22:54:52 --> Model "Case_model" initialized
INFO - 2022-03-08 22:55:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:55:11 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 22:55:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:55:11 --> Final output sent to browser
DEBUG - 2022-03-08 22:55:11 --> Total execution time: 19.1141
ERROR - 2022-03-08 22:55:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:55:55 --> Config Class Initialized
INFO - 2022-03-08 22:55:55 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:55:55 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:55:55 --> Utf8 Class Initialized
INFO - 2022-03-08 22:55:55 --> URI Class Initialized
INFO - 2022-03-08 22:55:55 --> Router Class Initialized
INFO - 2022-03-08 22:55:55 --> Output Class Initialized
INFO - 2022-03-08 22:55:55 --> Security Class Initialized
DEBUG - 2022-03-08 22:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:55:55 --> Input Class Initialized
INFO - 2022-03-08 22:55:55 --> Language Class Initialized
INFO - 2022-03-08 22:55:55 --> Loader Class Initialized
INFO - 2022-03-08 22:55:55 --> Helper loaded: url_helper
INFO - 2022-03-08 22:55:55 --> Helper loaded: form_helper
INFO - 2022-03-08 22:55:55 --> Helper loaded: common_helper
INFO - 2022-03-08 22:55:55 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:55:55 --> Controller Class Initialized
INFO - 2022-03-08 22:55:55 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:55:55 --> Encrypt Class Initialized
INFO - 2022-03-08 22:55:55 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:55:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:55:55 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:55:55 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:55:55 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:55:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 22:55:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:55:57 --> Config Class Initialized
INFO - 2022-03-08 22:55:57 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:55:57 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:55:57 --> Utf8 Class Initialized
INFO - 2022-03-08 22:55:57 --> URI Class Initialized
INFO - 2022-03-08 22:55:57 --> Router Class Initialized
INFO - 2022-03-08 22:55:57 --> Output Class Initialized
INFO - 2022-03-08 22:55:57 --> Security Class Initialized
DEBUG - 2022-03-08 22:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:55:57 --> Input Class Initialized
INFO - 2022-03-08 22:55:57 --> Language Class Initialized
INFO - 2022-03-08 22:55:57 --> Loader Class Initialized
INFO - 2022-03-08 22:55:57 --> Helper loaded: url_helper
INFO - 2022-03-08 22:55:57 --> Helper loaded: form_helper
INFO - 2022-03-08 22:55:57 --> Helper loaded: common_helper
INFO - 2022-03-08 22:55:57 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:56:02 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:56:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:56:02 --> Controller Class Initialized
INFO - 2022-03-08 22:56:02 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:56:02 --> Encrypt Class Initialized
INFO - 2022-03-08 22:56:02 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:56:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:56:02 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:56:02 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:56:02 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:56:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 22:56:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:56:02 --> Config Class Initialized
INFO - 2022-03-08 22:56:02 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:56:02 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:56:02 --> Utf8 Class Initialized
INFO - 2022-03-08 22:56:02 --> URI Class Initialized
INFO - 2022-03-08 22:56:02 --> Router Class Initialized
INFO - 2022-03-08 22:56:02 --> Output Class Initialized
INFO - 2022-03-08 22:56:02 --> Security Class Initialized
DEBUG - 2022-03-08 22:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:56:02 --> Input Class Initialized
INFO - 2022-03-08 22:56:02 --> Language Class Initialized
INFO - 2022-03-08 22:56:02 --> Loader Class Initialized
INFO - 2022-03-08 22:56:02 --> Helper loaded: url_helper
INFO - 2022-03-08 22:56:02 --> Helper loaded: form_helper
INFO - 2022-03-08 22:56:02 --> Helper loaded: common_helper
INFO - 2022-03-08 22:56:02 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:56:08 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:56:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:56:08 --> Controller Class Initialized
INFO - 2022-03-08 22:56:08 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:56:08 --> Encrypt Class Initialized
INFO - 2022-03-08 22:56:08 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:56:08 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:56:08 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:56:08 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:56:08 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:56:08 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 22:56:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:56:08 --> Config Class Initialized
INFO - 2022-03-08 22:56:08 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:56:08 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:56:08 --> Utf8 Class Initialized
INFO - 2022-03-08 22:56:08 --> URI Class Initialized
INFO - 2022-03-08 22:56:08 --> Router Class Initialized
INFO - 2022-03-08 22:56:08 --> Output Class Initialized
INFO - 2022-03-08 22:56:08 --> Security Class Initialized
DEBUG - 2022-03-08 22:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:56:08 --> Input Class Initialized
INFO - 2022-03-08 22:56:08 --> Language Class Initialized
INFO - 2022-03-08 22:56:08 --> Loader Class Initialized
INFO - 2022-03-08 22:56:08 --> Helper loaded: url_helper
INFO - 2022-03-08 22:56:08 --> Helper loaded: form_helper
INFO - 2022-03-08 22:56:08 --> Helper loaded: common_helper
INFO - 2022-03-08 22:56:08 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:56:13 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:56:13 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:56:13 --> Controller Class Initialized
INFO - 2022-03-08 22:56:13 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:56:13 --> Encrypt Class Initialized
INFO - 2022-03-08 22:56:13 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:56:13 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:56:13 --> Model "Referredby_model" initialized
INFO - 2022-03-08 22:56:13 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:56:13 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:56:13 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 22:56:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:56:15 --> Config Class Initialized
INFO - 2022-03-08 22:56:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:56:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:56:15 --> Utf8 Class Initialized
INFO - 2022-03-08 22:56:15 --> URI Class Initialized
INFO - 2022-03-08 22:56:15 --> Router Class Initialized
INFO - 2022-03-08 22:56:15 --> Output Class Initialized
INFO - 2022-03-08 22:56:15 --> Security Class Initialized
DEBUG - 2022-03-08 22:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:56:15 --> Input Class Initialized
INFO - 2022-03-08 22:56:15 --> Language Class Initialized
INFO - 2022-03-08 22:56:15 --> Loader Class Initialized
INFO - 2022-03-08 22:56:15 --> Helper loaded: url_helper
INFO - 2022-03-08 22:56:15 --> Helper loaded: form_helper
INFO - 2022-03-08 22:56:15 --> Helper loaded: common_helper
INFO - 2022-03-08 22:56:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:56:18 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 22:56:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:56:20 --> Final output sent to browser
DEBUG - 2022-03-08 22:56:20 --> Total execution time: 10.0660
INFO - 2022-03-08 22:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:56:20 --> Controller Class Initialized
INFO - 2022-03-08 22:56:20 --> Form Validation Class Initialized
INFO - 2022-03-08 22:56:20 --> Model "Case_model" initialized
INFO - 2022-03-08 22:56:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:56:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:56:21 --> File loaded: /home3/karoteam/public_html/application/views/cases/new_case.php
INFO - 2022-03-08 22:56:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:56:21 --> Final output sent to browser
DEBUG - 2022-03-08 22:56:21 --> Total execution time: 5.2713
ERROR - 2022-03-08 22:56:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 22:56:43 --> Config Class Initialized
INFO - 2022-03-08 22:56:43 --> Hooks Class Initialized
DEBUG - 2022-03-08 22:56:43 --> UTF-8 Support Enabled
INFO - 2022-03-08 22:56:43 --> Utf8 Class Initialized
INFO - 2022-03-08 22:56:43 --> URI Class Initialized
INFO - 2022-03-08 22:56:43 --> Router Class Initialized
INFO - 2022-03-08 22:56:43 --> Output Class Initialized
INFO - 2022-03-08 22:56:43 --> Security Class Initialized
DEBUG - 2022-03-08 22:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 22:56:43 --> Input Class Initialized
INFO - 2022-03-08 22:56:43 --> Language Class Initialized
INFO - 2022-03-08 22:56:43 --> Loader Class Initialized
INFO - 2022-03-08 22:56:43 --> Helper loaded: url_helper
INFO - 2022-03-08 22:56:43 --> Helper loaded: form_helper
INFO - 2022-03-08 22:56:43 --> Helper loaded: common_helper
INFO - 2022-03-08 22:56:43 --> Database Driver Class Initialized
DEBUG - 2022-03-08 22:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 22:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 22:56:43 --> Controller Class Initialized
INFO - 2022-03-08 22:56:43 --> Form Validation Class Initialized
DEBUG - 2022-03-08 22:56:43 --> Encrypt Class Initialized
INFO - 2022-03-08 22:56:43 --> Model "Patient_model" initialized
INFO - 2022-03-08 22:56:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 22:56:43 --> Model "Prefix_master" initialized
INFO - 2022-03-08 22:56:43 --> Model "Users_model" initialized
INFO - 2022-03-08 22:56:43 --> Model "Hospital_model" initialized
INFO - 2022-03-08 22:56:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 22:56:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 22:56:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 22:56:43 --> Final output sent to browser
DEBUG - 2022-03-08 22:56:43 --> Total execution time: 0.0721
ERROR - 2022-03-08 23:03:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:03:11 --> Config Class Initialized
INFO - 2022-03-08 23:03:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:03:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:03:11 --> Utf8 Class Initialized
INFO - 2022-03-08 23:03:11 --> URI Class Initialized
INFO - 2022-03-08 23:03:11 --> Router Class Initialized
INFO - 2022-03-08 23:03:11 --> Output Class Initialized
INFO - 2022-03-08 23:03:11 --> Security Class Initialized
DEBUG - 2022-03-08 23:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:03:11 --> Input Class Initialized
INFO - 2022-03-08 23:03:11 --> Language Class Initialized
INFO - 2022-03-08 23:03:11 --> Loader Class Initialized
INFO - 2022-03-08 23:03:11 --> Helper loaded: url_helper
INFO - 2022-03-08 23:03:11 --> Helper loaded: form_helper
INFO - 2022-03-08 23:03:11 --> Helper loaded: common_helper
INFO - 2022-03-08 23:03:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:03:11 --> Controller Class Initialized
INFO - 2022-03-08 23:03:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:03:11 --> Encrypt Class Initialized
INFO - 2022-03-08 23:03:11 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:03:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:03:11 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:03:11 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:03:11 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:03:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 23:03:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:03:16 --> Config Class Initialized
INFO - 2022-03-08 23:03:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:03:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:03:16 --> Utf8 Class Initialized
INFO - 2022-03-08 23:03:16 --> URI Class Initialized
INFO - 2022-03-08 23:03:16 --> Router Class Initialized
INFO - 2022-03-08 23:03:16 --> Output Class Initialized
INFO - 2022-03-08 23:03:16 --> Security Class Initialized
DEBUG - 2022-03-08 23:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:03:16 --> Input Class Initialized
INFO - 2022-03-08 23:03:16 --> Language Class Initialized
INFO - 2022-03-08 23:03:16 --> Loader Class Initialized
INFO - 2022-03-08 23:03:16 --> Helper loaded: url_helper
INFO - 2022-03-08 23:03:16 --> Helper loaded: form_helper
INFO - 2022-03-08 23:03:16 --> Helper loaded: common_helper
INFO - 2022-03-08 23:03:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:03:16 --> Controller Class Initialized
INFO - 2022-03-08 23:03:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:03:16 --> Encrypt Class Initialized
INFO - 2022-03-08 23:03:16 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:03:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:03:16 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:03:16 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:03:16 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:03:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:03:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:03:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:03:24 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:03:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 23:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:03:25 --> Config Class Initialized
INFO - 2022-03-08 23:03:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:03:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:03:25 --> Utf8 Class Initialized
INFO - 2022-03-08 23:03:25 --> URI Class Initialized
INFO - 2022-03-08 23:03:25 --> Router Class Initialized
INFO - 2022-03-08 23:03:25 --> Output Class Initialized
INFO - 2022-03-08 23:03:25 --> Security Class Initialized
DEBUG - 2022-03-08 23:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:03:25 --> Input Class Initialized
INFO - 2022-03-08 23:03:25 --> Language Class Initialized
ERROR - 2022-03-08 23:03:25 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 23:03:26 --> Final output sent to browser
DEBUG - 2022-03-08 23:03:26 --> Total execution time: 8.1750
ERROR - 2022-03-08 23:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:04:16 --> Config Class Initialized
INFO - 2022-03-08 23:04:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:04:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:04:16 --> Utf8 Class Initialized
INFO - 2022-03-08 23:04:16 --> URI Class Initialized
INFO - 2022-03-08 23:04:16 --> Router Class Initialized
INFO - 2022-03-08 23:04:16 --> Output Class Initialized
INFO - 2022-03-08 23:04:16 --> Security Class Initialized
DEBUG - 2022-03-08 23:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:04:16 --> Input Class Initialized
INFO - 2022-03-08 23:04:16 --> Language Class Initialized
INFO - 2022-03-08 23:04:16 --> Loader Class Initialized
INFO - 2022-03-08 23:04:16 --> Helper loaded: url_helper
INFO - 2022-03-08 23:04:16 --> Helper loaded: form_helper
INFO - 2022-03-08 23:04:16 --> Helper loaded: common_helper
INFO - 2022-03-08 23:04:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:04:16 --> Controller Class Initialized
INFO - 2022-03-08 23:04:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:04:16 --> Encrypt Class Initialized
INFO - 2022-03-08 23:04:16 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:04:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:04:16 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:04:16 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:04:16 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:04:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:04:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:04:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:04:16 --> Final output sent to browser
DEBUG - 2022-03-08 23:04:16 --> Total execution time: 0.2438
ERROR - 2022-03-08 23:04:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:04:17 --> Config Class Initialized
INFO - 2022-03-08 23:04:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:04:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:04:17 --> Utf8 Class Initialized
INFO - 2022-03-08 23:04:17 --> URI Class Initialized
INFO - 2022-03-08 23:04:17 --> Router Class Initialized
INFO - 2022-03-08 23:04:17 --> Output Class Initialized
INFO - 2022-03-08 23:04:17 --> Security Class Initialized
DEBUG - 2022-03-08 23:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:04:17 --> Input Class Initialized
INFO - 2022-03-08 23:04:17 --> Language Class Initialized
ERROR - 2022-03-08 23:04:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:04:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:04:29 --> Config Class Initialized
INFO - 2022-03-08 23:04:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:04:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:04:29 --> Utf8 Class Initialized
INFO - 2022-03-08 23:04:29 --> URI Class Initialized
INFO - 2022-03-08 23:04:29 --> Router Class Initialized
INFO - 2022-03-08 23:04:29 --> Output Class Initialized
INFO - 2022-03-08 23:04:29 --> Security Class Initialized
DEBUG - 2022-03-08 23:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:04:29 --> Input Class Initialized
INFO - 2022-03-08 23:04:29 --> Language Class Initialized
INFO - 2022-03-08 23:04:29 --> Loader Class Initialized
INFO - 2022-03-08 23:04:29 --> Helper loaded: url_helper
INFO - 2022-03-08 23:04:29 --> Helper loaded: form_helper
INFO - 2022-03-08 23:04:29 --> Helper loaded: common_helper
INFO - 2022-03-08 23:04:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:04:29 --> Controller Class Initialized
INFO - 2022-03-08 23:04:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:04:29 --> Encrypt Class Initialized
INFO - 2022-03-08 23:04:29 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:04:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:04:29 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:04:29 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:04:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:04:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:04:29 --> Config Class Initialized
INFO - 2022-03-08 23:04:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:04:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:04:29 --> Utf8 Class Initialized
INFO - 2022-03-08 23:04:29 --> URI Class Initialized
INFO - 2022-03-08 23:04:29 --> Router Class Initialized
INFO - 2022-03-08 23:04:29 --> Output Class Initialized
INFO - 2022-03-08 23:04:29 --> Security Class Initialized
DEBUG - 2022-03-08 23:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:04:29 --> Input Class Initialized
INFO - 2022-03-08 23:04:29 --> Language Class Initialized
INFO - 2022-03-08 23:04:29 --> Loader Class Initialized
INFO - 2022-03-08 23:04:29 --> Helper loaded: url_helper
INFO - 2022-03-08 23:04:29 --> Helper loaded: form_helper
INFO - 2022-03-08 23:04:29 --> Helper loaded: common_helper
INFO - 2022-03-08 23:04:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:04:29 --> Controller Class Initialized
INFO - 2022-03-08 23:04:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:04:29 --> Encrypt Class Initialized
INFO - 2022-03-08 23:04:29 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:04:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:04:29 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:04:29 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:04:29 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:04:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:04:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:04:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 23:04:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:04:38 --> Config Class Initialized
INFO - 2022-03-08 23:04:38 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:04:38 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:04:38 --> Utf8 Class Initialized
INFO - 2022-03-08 23:04:38 --> URI Class Initialized
INFO - 2022-03-08 23:04:38 --> Router Class Initialized
INFO - 2022-03-08 23:04:38 --> Output Class Initialized
INFO - 2022-03-08 23:04:38 --> Security Class Initialized
DEBUG - 2022-03-08 23:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:04:38 --> Input Class Initialized
INFO - 2022-03-08 23:04:38 --> Language Class Initialized
ERROR - 2022-03-08 23:04:38 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 23:04:39 --> Final output sent to browser
DEBUG - 2022-03-08 23:04:39 --> Total execution time: 7.8666
ERROR - 2022-03-08 23:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:04:52 --> Config Class Initialized
INFO - 2022-03-08 23:04:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:04:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:04:52 --> Utf8 Class Initialized
INFO - 2022-03-08 23:04:52 --> URI Class Initialized
INFO - 2022-03-08 23:04:52 --> Router Class Initialized
INFO - 2022-03-08 23:04:52 --> Output Class Initialized
INFO - 2022-03-08 23:04:52 --> Security Class Initialized
DEBUG - 2022-03-08 23:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:04:52 --> Input Class Initialized
INFO - 2022-03-08 23:04:52 --> Language Class Initialized
INFO - 2022-03-08 23:04:52 --> Loader Class Initialized
INFO - 2022-03-08 23:04:52 --> Helper loaded: url_helper
INFO - 2022-03-08 23:04:52 --> Helper loaded: form_helper
INFO - 2022-03-08 23:04:52 --> Helper loaded: common_helper
INFO - 2022-03-08 23:04:52 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:04:52 --> Controller Class Initialized
INFO - 2022-03-08 23:04:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:04:52 --> Encrypt Class Initialized
INFO - 2022-03-08 23:04:52 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:04:52 --> Model "Users_model" initialized
INFO - 2022-03-08 23:04:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:04:52 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2022-03-08 23:04:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:04:52 --> Final output sent to browser
DEBUG - 2022-03-08 23:04:52 --> Total execution time: 0.0339
ERROR - 2022-03-08 23:04:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:04:53 --> Config Class Initialized
INFO - 2022-03-08 23:04:53 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:04:53 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:04:53 --> Utf8 Class Initialized
INFO - 2022-03-08 23:04:53 --> URI Class Initialized
INFO - 2022-03-08 23:04:53 --> Router Class Initialized
INFO - 2022-03-08 23:04:53 --> Output Class Initialized
INFO - 2022-03-08 23:04:53 --> Security Class Initialized
DEBUG - 2022-03-08 23:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:04:53 --> Input Class Initialized
INFO - 2022-03-08 23:04:53 --> Language Class Initialized
ERROR - 2022-03-08 23:04:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:02 --> Config Class Initialized
INFO - 2022-03-08 23:05:02 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:02 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:02 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:02 --> URI Class Initialized
INFO - 2022-03-08 23:05:02 --> Router Class Initialized
INFO - 2022-03-08 23:05:02 --> Output Class Initialized
INFO - 2022-03-08 23:05:02 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:02 --> Input Class Initialized
INFO - 2022-03-08 23:05:02 --> Language Class Initialized
INFO - 2022-03-08 23:05:02 --> Loader Class Initialized
INFO - 2022-03-08 23:05:02 --> Helper loaded: url_helper
INFO - 2022-03-08 23:05:02 --> Helper loaded: form_helper
INFO - 2022-03-08 23:05:02 --> Helper loaded: common_helper
INFO - 2022-03-08 23:05:02 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:05:02 --> Controller Class Initialized
INFO - 2022-03-08 23:05:02 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:05:02 --> Encrypt Class Initialized
INFO - 2022-03-08 23:05:02 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:05:02 --> Model "Users_model" initialized
INFO - 2022-03-08 23:05:02 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:05:02 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2022-03-08 23:05:02 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:05:02 --> Final output sent to browser
DEBUG - 2022-03-08 23:05:02 --> Total execution time: 0.0304
ERROR - 2022-03-08 23:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:02 --> Config Class Initialized
INFO - 2022-03-08 23:05:02 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:02 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:02 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:02 --> URI Class Initialized
INFO - 2022-03-08 23:05:02 --> Router Class Initialized
INFO - 2022-03-08 23:05:02 --> Output Class Initialized
INFO - 2022-03-08 23:05:02 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:02 --> Input Class Initialized
INFO - 2022-03-08 23:05:02 --> Language Class Initialized
ERROR - 2022-03-08 23:05:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:13 --> Config Class Initialized
INFO - 2022-03-08 23:05:13 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:13 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:13 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:13 --> URI Class Initialized
INFO - 2022-03-08 23:05:13 --> Router Class Initialized
INFO - 2022-03-08 23:05:13 --> Output Class Initialized
INFO - 2022-03-08 23:05:13 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:13 --> Input Class Initialized
INFO - 2022-03-08 23:05:13 --> Language Class Initialized
INFO - 2022-03-08 23:05:13 --> Loader Class Initialized
INFO - 2022-03-08 23:05:13 --> Helper loaded: url_helper
INFO - 2022-03-08 23:05:13 --> Helper loaded: form_helper
INFO - 2022-03-08 23:05:13 --> Helper loaded: common_helper
INFO - 2022-03-08 23:05:13 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:05:13 --> Controller Class Initialized
INFO - 2022-03-08 23:05:13 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:05:13 --> Encrypt Class Initialized
INFO - 2022-03-08 23:05:13 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:05:13 --> Model "Users_model" initialized
INFO - 2022-03-08 23:05:13 --> Upload Class Initialized
ERROR - 2022-03-08 23:05:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:14 --> Config Class Initialized
INFO - 2022-03-08 23:05:14 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:14 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:14 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:14 --> URI Class Initialized
INFO - 2022-03-08 23:05:14 --> Router Class Initialized
INFO - 2022-03-08 23:05:14 --> Output Class Initialized
INFO - 2022-03-08 23:05:14 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:14 --> Input Class Initialized
INFO - 2022-03-08 23:05:14 --> Language Class Initialized
INFO - 2022-03-08 23:05:14 --> Loader Class Initialized
INFO - 2022-03-08 23:05:14 --> Helper loaded: url_helper
INFO - 2022-03-08 23:05:14 --> Helper loaded: form_helper
INFO - 2022-03-08 23:05:14 --> Helper loaded: common_helper
INFO - 2022-03-08 23:05:14 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:05:14 --> Controller Class Initialized
INFO - 2022-03-08 23:05:14 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:05:14 --> Encrypt Class Initialized
INFO - 2022-03-08 23:05:14 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:05:14 --> Model "Users_model" initialized
INFO - 2022-03-08 23:05:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:05:14 --> File loaded: /home3/karoteam/public_html/application/views/users/index.php
INFO - 2022-03-08 23:05:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:05:14 --> Final output sent to browser
DEBUG - 2022-03-08 23:05:14 --> Total execution time: 0.0460
ERROR - 2022-03-08 23:05:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:14 --> Config Class Initialized
INFO - 2022-03-08 23:05:14 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:14 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:14 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:14 --> URI Class Initialized
INFO - 2022-03-08 23:05:14 --> Router Class Initialized
INFO - 2022-03-08 23:05:14 --> Output Class Initialized
INFO - 2022-03-08 23:05:14 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:14 --> Input Class Initialized
INFO - 2022-03-08 23:05:14 --> Language Class Initialized
ERROR - 2022-03-08 23:05:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:41 --> Config Class Initialized
INFO - 2022-03-08 23:05:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:41 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:41 --> URI Class Initialized
INFO - 2022-03-08 23:05:41 --> Router Class Initialized
INFO - 2022-03-08 23:05:41 --> Output Class Initialized
INFO - 2022-03-08 23:05:41 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:41 --> Input Class Initialized
INFO - 2022-03-08 23:05:41 --> Language Class Initialized
INFO - 2022-03-08 23:05:41 --> Loader Class Initialized
INFO - 2022-03-08 23:05:41 --> Helper loaded: url_helper
INFO - 2022-03-08 23:05:41 --> Helper loaded: form_helper
INFO - 2022-03-08 23:05:41 --> Helper loaded: common_helper
INFO - 2022-03-08 23:05:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:05:41 --> Controller Class Initialized
INFO - 2022-03-08 23:05:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:05:41 --> Encrypt Class Initialized
INFO - 2022-03-08 23:05:41 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:05:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:05:41 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:05:41 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:05:41 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:05:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 23:05:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:46 --> Config Class Initialized
INFO - 2022-03-08 23:05:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:46 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:46 --> URI Class Initialized
INFO - 2022-03-08 23:05:46 --> Router Class Initialized
INFO - 2022-03-08 23:05:46 --> Output Class Initialized
INFO - 2022-03-08 23:05:46 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:46 --> Input Class Initialized
INFO - 2022-03-08 23:05:46 --> Language Class Initialized
INFO - 2022-03-08 23:05:46 --> Loader Class Initialized
INFO - 2022-03-08 23:05:46 --> Helper loaded: url_helper
INFO - 2022-03-08 23:05:46 --> Helper loaded: form_helper
INFO - 2022-03-08 23:05:46 --> Helper loaded: common_helper
INFO - 2022-03-08 23:05:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:05:46 --> Controller Class Initialized
INFO - 2022-03-08 23:05:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:05:46 --> Encrypt Class Initialized
INFO - 2022-03-08 23:05:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:05:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:05:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:05:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:05:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:05:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:05:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:05:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 23:05:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:48 --> Config Class Initialized
INFO - 2022-03-08 23:05:48 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:48 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:48 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:48 --> URI Class Initialized
INFO - 2022-03-08 23:05:48 --> Router Class Initialized
INFO - 2022-03-08 23:05:48 --> Output Class Initialized
INFO - 2022-03-08 23:05:48 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:48 --> Input Class Initialized
INFO - 2022-03-08 23:05:48 --> Language Class Initialized
ERROR - 2022-03-08 23:05:48 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 23:05:49 --> Final output sent to browser
DEBUG - 2022-03-08 23:05:49 --> Total execution time: 6.1655
INFO - 2022-03-08 23:05:52 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:05:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 23:05:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:55 --> Config Class Initialized
INFO - 2022-03-08 23:05:55 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:55 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:55 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:55 --> URI Class Initialized
INFO - 2022-03-08 23:05:55 --> Router Class Initialized
INFO - 2022-03-08 23:05:55 --> Output Class Initialized
INFO - 2022-03-08 23:05:55 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:55 --> Input Class Initialized
INFO - 2022-03-08 23:05:55 --> Language Class Initialized
INFO - 2022-03-08 23:05:55 --> Loader Class Initialized
INFO - 2022-03-08 23:05:55 --> Helper loaded: url_helper
INFO - 2022-03-08 23:05:55 --> Helper loaded: form_helper
INFO - 2022-03-08 23:05:55 --> Helper loaded: common_helper
INFO - 2022-03-08 23:05:55 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:05:55 --> Controller Class Initialized
INFO - 2022-03-08 23:05:55 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:05:55 --> Encrypt Class Initialized
DEBUG - 2022-03-08 23:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 23:05:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 23:05:55 --> Email Class Initialized
INFO - 2022-03-08 23:05:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 23:05:55 --> Calendar Class Initialized
INFO - 2022-03-08 23:05:55 --> Model "Login_model" initialized
ERROR - 2022-03-08 23:05:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:05:55 --> Config Class Initialized
INFO - 2022-03-08 23:05:55 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:05:55 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:05:55 --> Utf8 Class Initialized
INFO - 2022-03-08 23:05:55 --> URI Class Initialized
INFO - 2022-03-08 23:05:55 --> Router Class Initialized
INFO - 2022-03-08 23:05:55 --> Output Class Initialized
INFO - 2022-03-08 23:05:55 --> Security Class Initialized
DEBUG - 2022-03-08 23:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:05:55 --> Input Class Initialized
INFO - 2022-03-08 23:05:55 --> Language Class Initialized
INFO - 2022-03-08 23:05:55 --> Loader Class Initialized
INFO - 2022-03-08 23:05:55 --> Helper loaded: url_helper
INFO - 2022-03-08 23:05:55 --> Helper loaded: form_helper
INFO - 2022-03-08 23:05:55 --> Helper loaded: common_helper
INFO - 2022-03-08 23:05:55 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:05:55 --> Controller Class Initialized
INFO - 2022-03-08 23:05:55 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:05:55 --> Encrypt Class Initialized
DEBUG - 2022-03-08 23:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 23:05:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 23:05:55 --> Email Class Initialized
INFO - 2022-03-08 23:05:55 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 23:05:55 --> Calendar Class Initialized
INFO - 2022-03-08 23:05:55 --> Model "Login_model" initialized
INFO - 2022-03-08 23:05:55 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 23:05:55 --> Final output sent to browser
DEBUG - 2022-03-08 23:05:55 --> Total execution time: 0.0226
ERROR - 2022-03-08 23:06:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:06:07 --> Config Class Initialized
INFO - 2022-03-08 23:06:07 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:06:07 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:06:07 --> Utf8 Class Initialized
INFO - 2022-03-08 23:06:07 --> URI Class Initialized
INFO - 2022-03-08 23:06:07 --> Router Class Initialized
INFO - 2022-03-08 23:06:07 --> Output Class Initialized
INFO - 2022-03-08 23:06:07 --> Security Class Initialized
DEBUG - 2022-03-08 23:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:06:07 --> Input Class Initialized
INFO - 2022-03-08 23:06:07 --> Language Class Initialized
INFO - 2022-03-08 23:06:07 --> Loader Class Initialized
INFO - 2022-03-08 23:06:07 --> Helper loaded: url_helper
INFO - 2022-03-08 23:06:07 --> Helper loaded: form_helper
INFO - 2022-03-08 23:06:07 --> Helper loaded: common_helper
INFO - 2022-03-08 23:06:07 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:06:07 --> Controller Class Initialized
INFO - 2022-03-08 23:06:07 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:06:07 --> Encrypt Class Initialized
DEBUG - 2022-03-08 23:06:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 23:06:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 23:06:07 --> Email Class Initialized
INFO - 2022-03-08 23:06:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 23:06:07 --> Calendar Class Initialized
INFO - 2022-03-08 23:06:07 --> Model "Login_model" initialized
INFO - 2022-03-08 23:06:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 23:06:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:06:07 --> Config Class Initialized
INFO - 2022-03-08 23:06:07 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:06:07 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:06:07 --> Utf8 Class Initialized
INFO - 2022-03-08 23:06:07 --> URI Class Initialized
INFO - 2022-03-08 23:06:07 --> Router Class Initialized
INFO - 2022-03-08 23:06:07 --> Output Class Initialized
INFO - 2022-03-08 23:06:07 --> Security Class Initialized
DEBUG - 2022-03-08 23:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:06:07 --> Input Class Initialized
INFO - 2022-03-08 23:06:07 --> Language Class Initialized
INFO - 2022-03-08 23:06:07 --> Loader Class Initialized
INFO - 2022-03-08 23:06:07 --> Helper loaded: url_helper
INFO - 2022-03-08 23:06:07 --> Helper loaded: form_helper
INFO - 2022-03-08 23:06:07 --> Helper loaded: common_helper
INFO - 2022-03-08 23:06:07 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:06:07 --> Controller Class Initialized
INFO - 2022-03-08 23:06:07 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:06:07 --> Encrypt Class Initialized
INFO - 2022-03-08 23:06:07 --> Model "Login_model" initialized
INFO - 2022-03-08 23:06:07 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 23:06:07 --> Model "Case_model" initialized
INFO - 2022-03-08 23:06:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:06:08 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 23:06:08 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:06:08 --> Final output sent to browser
DEBUG - 2022-03-08 23:06:08 --> Total execution time: 0.1394
ERROR - 2022-03-08 23:06:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:06:15 --> Config Class Initialized
INFO - 2022-03-08 23:06:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:06:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:06:15 --> Utf8 Class Initialized
INFO - 2022-03-08 23:06:15 --> URI Class Initialized
INFO - 2022-03-08 23:06:15 --> Router Class Initialized
INFO - 2022-03-08 23:06:15 --> Output Class Initialized
INFO - 2022-03-08 23:06:15 --> Security Class Initialized
DEBUG - 2022-03-08 23:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:06:15 --> Input Class Initialized
INFO - 2022-03-08 23:06:15 --> Language Class Initialized
INFO - 2022-03-08 23:06:15 --> Loader Class Initialized
INFO - 2022-03-08 23:06:15 --> Helper loaded: url_helper
INFO - 2022-03-08 23:06:15 --> Helper loaded: form_helper
INFO - 2022-03-08 23:06:15 --> Helper loaded: common_helper
INFO - 2022-03-08 23:06:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:06:15 --> Controller Class Initialized
INFO - 2022-03-08 23:06:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:06:15 --> Encrypt Class Initialized
INFO - 2022-03-08 23:06:15 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:06:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:06:15 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:06:15 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:06:15 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:06:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:06:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patient_by_category.php
INFO - 2022-03-08 23:06:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:06:15 --> Final output sent to browser
DEBUG - 2022-03-08 23:06:15 --> Total execution time: 0.0334
ERROR - 2022-03-08 23:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:06:28 --> Config Class Initialized
INFO - 2022-03-08 23:06:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:06:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:06:28 --> Utf8 Class Initialized
INFO - 2022-03-08 23:06:28 --> URI Class Initialized
INFO - 2022-03-08 23:06:28 --> Router Class Initialized
INFO - 2022-03-08 23:06:28 --> Output Class Initialized
INFO - 2022-03-08 23:06:28 --> Security Class Initialized
DEBUG - 2022-03-08 23:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:06:28 --> Input Class Initialized
INFO - 2022-03-08 23:06:28 --> Language Class Initialized
INFO - 2022-03-08 23:06:28 --> Loader Class Initialized
INFO - 2022-03-08 23:06:28 --> Helper loaded: url_helper
INFO - 2022-03-08 23:06:28 --> Helper loaded: form_helper
INFO - 2022-03-08 23:06:28 --> Helper loaded: common_helper
INFO - 2022-03-08 23:06:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:06:28 --> Controller Class Initialized
INFO - 2022-03-08 23:06:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:06:28 --> Encrypt Class Initialized
INFO - 2022-03-08 23:06:28 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:06:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:06:28 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:06:28 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:06:28 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:06:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:06:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:06:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:06:28 --> Final output sent to browser
DEBUG - 2022-03-08 23:06:28 --> Total execution time: 0.0544
ERROR - 2022-03-08 23:12:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:12:45 --> Config Class Initialized
INFO - 2022-03-08 23:12:45 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:12:45 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:12:45 --> Utf8 Class Initialized
INFO - 2022-03-08 23:12:45 --> URI Class Initialized
INFO - 2022-03-08 23:12:45 --> Router Class Initialized
INFO - 2022-03-08 23:12:45 --> Output Class Initialized
INFO - 2022-03-08 23:12:45 --> Security Class Initialized
DEBUG - 2022-03-08 23:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:12:45 --> Input Class Initialized
INFO - 2022-03-08 23:12:45 --> Language Class Initialized
INFO - 2022-03-08 23:12:45 --> Loader Class Initialized
INFO - 2022-03-08 23:12:45 --> Helper loaded: url_helper
INFO - 2022-03-08 23:12:45 --> Helper loaded: form_helper
INFO - 2022-03-08 23:12:45 --> Helper loaded: common_helper
INFO - 2022-03-08 23:12:45 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:12:45 --> Controller Class Initialized
INFO - 2022-03-08 23:12:45 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:12:45 --> Encrypt Class Initialized
INFO - 2022-03-08 23:12:45 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:12:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:12:45 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:12:45 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:12:45 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:12:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:12:46 --> Config Class Initialized
INFO - 2022-03-08 23:12:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:12:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:12:46 --> Utf8 Class Initialized
INFO - 2022-03-08 23:12:46 --> URI Class Initialized
INFO - 2022-03-08 23:12:46 --> Router Class Initialized
INFO - 2022-03-08 23:12:46 --> Output Class Initialized
INFO - 2022-03-08 23:12:46 --> Security Class Initialized
DEBUG - 2022-03-08 23:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:12:46 --> Input Class Initialized
INFO - 2022-03-08 23:12:46 --> Language Class Initialized
INFO - 2022-03-08 23:12:46 --> Loader Class Initialized
INFO - 2022-03-08 23:12:46 --> Helper loaded: url_helper
INFO - 2022-03-08 23:12:46 --> Helper loaded: form_helper
INFO - 2022-03-08 23:12:46 --> Helper loaded: common_helper
INFO - 2022-03-08 23:12:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:12:46 --> Controller Class Initialized
INFO - 2022-03-08 23:12:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:12:46 --> Encrypt Class Initialized
INFO - 2022-03-08 23:12:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:12:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:12:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:12:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:12:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:12:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:12:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:12:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:12:46 --> Final output sent to browser
DEBUG - 2022-03-08 23:12:46 --> Total execution time: 0.0468
ERROR - 2022-03-08 23:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:12:47 --> Config Class Initialized
INFO - 2022-03-08 23:12:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:12:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:12:47 --> Utf8 Class Initialized
INFO - 2022-03-08 23:12:47 --> URI Class Initialized
INFO - 2022-03-08 23:12:47 --> Router Class Initialized
INFO - 2022-03-08 23:12:47 --> Output Class Initialized
INFO - 2022-03-08 23:12:47 --> Security Class Initialized
DEBUG - 2022-03-08 23:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:12:47 --> Input Class Initialized
INFO - 2022-03-08 23:12:47 --> Language Class Initialized
INFO - 2022-03-08 23:12:47 --> Loader Class Initialized
INFO - 2022-03-08 23:12:47 --> Helper loaded: url_helper
INFO - 2022-03-08 23:12:47 --> Helper loaded: form_helper
INFO - 2022-03-08 23:12:47 --> Helper loaded: common_helper
INFO - 2022-03-08 23:12:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:12:47 --> Controller Class Initialized
INFO - 2022-03-08 23:12:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:12:47 --> Encrypt Class Initialized
INFO - 2022-03-08 23:12:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:12:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:12:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:12:47 --> Model "Users_model" initialized
INFO - 2022-03-08 23:12:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:12:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:12:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:12:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:12:47 --> Final output sent to browser
DEBUG - 2022-03-08 23:12:47 --> Total execution time: 0.0876
ERROR - 2022-03-08 23:13:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:13:23 --> Config Class Initialized
INFO - 2022-03-08 23:13:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:13:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:13:23 --> Utf8 Class Initialized
INFO - 2022-03-08 23:13:23 --> URI Class Initialized
INFO - 2022-03-08 23:13:23 --> Router Class Initialized
INFO - 2022-03-08 23:13:23 --> Output Class Initialized
INFO - 2022-03-08 23:13:23 --> Security Class Initialized
DEBUG - 2022-03-08 23:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:13:23 --> Input Class Initialized
INFO - 2022-03-08 23:13:23 --> Language Class Initialized
INFO - 2022-03-08 23:13:23 --> Loader Class Initialized
INFO - 2022-03-08 23:13:23 --> Helper loaded: url_helper
INFO - 2022-03-08 23:13:24 --> Helper loaded: form_helper
INFO - 2022-03-08 23:13:24 --> Helper loaded: common_helper
INFO - 2022-03-08 23:13:24 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:13:24 --> Controller Class Initialized
INFO - 2022-03-08 23:13:24 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:13:24 --> Encrypt Class Initialized
INFO - 2022-03-08 23:13:24 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:13:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:13:24 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:13:24 --> Model "Users_model" initialized
INFO - 2022-03-08 23:13:24 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:13:25 --> Config Class Initialized
INFO - 2022-03-08 23:13:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:13:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:13:25 --> Utf8 Class Initialized
INFO - 2022-03-08 23:13:25 --> URI Class Initialized
INFO - 2022-03-08 23:13:25 --> Router Class Initialized
INFO - 2022-03-08 23:13:25 --> Output Class Initialized
INFO - 2022-03-08 23:13:25 --> Security Class Initialized
DEBUG - 2022-03-08 23:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:13:25 --> Input Class Initialized
INFO - 2022-03-08 23:13:25 --> Language Class Initialized
INFO - 2022-03-08 23:13:25 --> Loader Class Initialized
INFO - 2022-03-08 23:13:25 --> Helper loaded: url_helper
INFO - 2022-03-08 23:13:25 --> Helper loaded: form_helper
INFO - 2022-03-08 23:13:25 --> Helper loaded: common_helper
INFO - 2022-03-08 23:13:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:13:25 --> Controller Class Initialized
INFO - 2022-03-08 23:13:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:13:25 --> Encrypt Class Initialized
INFO - 2022-03-08 23:13:25 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:13:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:13:25 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:13:25 --> Model "Users_model" initialized
INFO - 2022-03-08 23:13:25 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:13:25 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:13:25 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:13:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:13:25 --> Final output sent to browser
DEBUG - 2022-03-08 23:13:25 --> Total execution time: 0.1218
ERROR - 2022-03-08 23:14:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:14:55 --> Config Class Initialized
INFO - 2022-03-08 23:14:55 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:14:55 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:14:55 --> Utf8 Class Initialized
INFO - 2022-03-08 23:14:55 --> URI Class Initialized
INFO - 2022-03-08 23:14:55 --> Router Class Initialized
INFO - 2022-03-08 23:14:55 --> Output Class Initialized
INFO - 2022-03-08 23:14:55 --> Security Class Initialized
DEBUG - 2022-03-08 23:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:14:55 --> Input Class Initialized
INFO - 2022-03-08 23:14:55 --> Language Class Initialized
INFO - 2022-03-08 23:14:55 --> Loader Class Initialized
INFO - 2022-03-08 23:14:55 --> Helper loaded: url_helper
INFO - 2022-03-08 23:14:55 --> Helper loaded: form_helper
INFO - 2022-03-08 23:14:55 --> Helper loaded: common_helper
INFO - 2022-03-08 23:14:55 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:14:55 --> Controller Class Initialized
INFO - 2022-03-08 23:14:55 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:14:55 --> Encrypt Class Initialized
INFO - 2022-03-08 23:14:55 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:14:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:14:55 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:14:55 --> Model "Users_model" initialized
INFO - 2022-03-08 23:14:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:14:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:14:56 --> Config Class Initialized
INFO - 2022-03-08 23:14:56 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:14:56 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:14:56 --> Utf8 Class Initialized
INFO - 2022-03-08 23:14:56 --> URI Class Initialized
INFO - 2022-03-08 23:14:56 --> Router Class Initialized
INFO - 2022-03-08 23:14:56 --> Output Class Initialized
INFO - 2022-03-08 23:14:56 --> Security Class Initialized
DEBUG - 2022-03-08 23:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:14:56 --> Input Class Initialized
INFO - 2022-03-08 23:14:56 --> Language Class Initialized
INFO - 2022-03-08 23:14:56 --> Loader Class Initialized
INFO - 2022-03-08 23:14:56 --> Helper loaded: url_helper
INFO - 2022-03-08 23:14:56 --> Helper loaded: form_helper
INFO - 2022-03-08 23:14:56 --> Helper loaded: common_helper
INFO - 2022-03-08 23:14:56 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:14:56 --> Controller Class Initialized
INFO - 2022-03-08 23:14:56 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:14:56 --> Encrypt Class Initialized
INFO - 2022-03-08 23:14:56 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:14:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:14:56 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:14:56 --> Model "Users_model" initialized
INFO - 2022-03-08 23:14:56 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:14:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:14:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:14:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:14:56 --> Final output sent to browser
DEBUG - 2022-03-08 23:14:56 --> Total execution time: 0.0652
ERROR - 2022-03-08 23:15:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:15:15 --> Config Class Initialized
INFO - 2022-03-08 23:15:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:15:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:15:15 --> Utf8 Class Initialized
INFO - 2022-03-08 23:15:15 --> URI Class Initialized
INFO - 2022-03-08 23:15:15 --> Router Class Initialized
INFO - 2022-03-08 23:15:15 --> Output Class Initialized
INFO - 2022-03-08 23:15:15 --> Security Class Initialized
DEBUG - 2022-03-08 23:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:15:15 --> Input Class Initialized
INFO - 2022-03-08 23:15:15 --> Language Class Initialized
INFO - 2022-03-08 23:15:15 --> Loader Class Initialized
INFO - 2022-03-08 23:15:15 --> Helper loaded: url_helper
INFO - 2022-03-08 23:15:15 --> Helper loaded: form_helper
INFO - 2022-03-08 23:15:15 --> Helper loaded: common_helper
INFO - 2022-03-08 23:15:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:15:15 --> Controller Class Initialized
INFO - 2022-03-08 23:15:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:15:15 --> Encrypt Class Initialized
INFO - 2022-03-08 23:15:15 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:15:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:15:15 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:15:15 --> Model "Users_model" initialized
INFO - 2022-03-08 23:15:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:15:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:15:16 --> Config Class Initialized
INFO - 2022-03-08 23:15:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:15:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:15:16 --> Utf8 Class Initialized
INFO - 2022-03-08 23:15:16 --> URI Class Initialized
INFO - 2022-03-08 23:15:16 --> Router Class Initialized
INFO - 2022-03-08 23:15:16 --> Output Class Initialized
INFO - 2022-03-08 23:15:16 --> Security Class Initialized
DEBUG - 2022-03-08 23:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:15:16 --> Input Class Initialized
INFO - 2022-03-08 23:15:16 --> Language Class Initialized
INFO - 2022-03-08 23:15:16 --> Loader Class Initialized
INFO - 2022-03-08 23:15:16 --> Helper loaded: url_helper
INFO - 2022-03-08 23:15:16 --> Helper loaded: form_helper
INFO - 2022-03-08 23:15:16 --> Helper loaded: common_helper
INFO - 2022-03-08 23:15:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:15:16 --> Controller Class Initialized
INFO - 2022-03-08 23:15:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:15:16 --> Encrypt Class Initialized
INFO - 2022-03-08 23:15:16 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:15:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:15:16 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:15:16 --> Model "Users_model" initialized
INFO - 2022-03-08 23:15:16 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:15:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:15:16 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:15:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:15:16 --> Final output sent to browser
DEBUG - 2022-03-08 23:15:16 --> Total execution time: 0.0853
ERROR - 2022-03-08 23:16:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:16:37 --> Config Class Initialized
INFO - 2022-03-08 23:16:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:16:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:16:37 --> Utf8 Class Initialized
INFO - 2022-03-08 23:16:37 --> URI Class Initialized
INFO - 2022-03-08 23:16:37 --> Router Class Initialized
INFO - 2022-03-08 23:16:37 --> Output Class Initialized
INFO - 2022-03-08 23:16:37 --> Security Class Initialized
DEBUG - 2022-03-08 23:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:16:37 --> Input Class Initialized
INFO - 2022-03-08 23:16:37 --> Language Class Initialized
INFO - 2022-03-08 23:16:37 --> Loader Class Initialized
INFO - 2022-03-08 23:16:37 --> Helper loaded: url_helper
INFO - 2022-03-08 23:16:37 --> Helper loaded: form_helper
INFO - 2022-03-08 23:16:37 --> Helper loaded: common_helper
INFO - 2022-03-08 23:16:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:16:37 --> Controller Class Initialized
INFO - 2022-03-08 23:16:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:16:37 --> Encrypt Class Initialized
INFO - 2022-03-08 23:16:37 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:16:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:16:37 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:16:37 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:16:37 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:16:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:16:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:16:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:16:37 --> Final output sent to browser
DEBUG - 2022-03-08 23:16:37 --> Total execution time: 0.1049
ERROR - 2022-03-08 23:16:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:16:45 --> Config Class Initialized
INFO - 2022-03-08 23:16:45 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:16:45 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:16:45 --> Utf8 Class Initialized
INFO - 2022-03-08 23:16:45 --> URI Class Initialized
INFO - 2022-03-08 23:16:45 --> Router Class Initialized
INFO - 2022-03-08 23:16:45 --> Output Class Initialized
INFO - 2022-03-08 23:16:45 --> Security Class Initialized
DEBUG - 2022-03-08 23:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:16:45 --> Input Class Initialized
INFO - 2022-03-08 23:16:45 --> Language Class Initialized
INFO - 2022-03-08 23:16:45 --> Loader Class Initialized
INFO - 2022-03-08 23:16:45 --> Helper loaded: url_helper
INFO - 2022-03-08 23:16:45 --> Helper loaded: form_helper
INFO - 2022-03-08 23:16:45 --> Helper loaded: common_helper
INFO - 2022-03-08 23:16:45 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:16:45 --> Controller Class Initialized
INFO - 2022-03-08 23:16:45 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:16:45 --> Encrypt Class Initialized
INFO - 2022-03-08 23:16:45 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:16:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:16:45 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:16:45 --> Model "Users_model" initialized
INFO - 2022-03-08 23:16:45 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:16:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:16:45 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:16:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:16:45 --> Final output sent to browser
DEBUG - 2022-03-08 23:16:45 --> Total execution time: 0.0654
ERROR - 2022-03-08 23:16:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:16:51 --> Config Class Initialized
INFO - 2022-03-08 23:16:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:16:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:16:51 --> Utf8 Class Initialized
INFO - 2022-03-08 23:16:51 --> URI Class Initialized
INFO - 2022-03-08 23:16:51 --> Router Class Initialized
INFO - 2022-03-08 23:16:51 --> Output Class Initialized
INFO - 2022-03-08 23:16:51 --> Security Class Initialized
DEBUG - 2022-03-08 23:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:16:51 --> Input Class Initialized
INFO - 2022-03-08 23:16:51 --> Language Class Initialized
INFO - 2022-03-08 23:16:51 --> Loader Class Initialized
INFO - 2022-03-08 23:16:51 --> Helper loaded: url_helper
INFO - 2022-03-08 23:16:51 --> Helper loaded: form_helper
INFO - 2022-03-08 23:16:51 --> Helper loaded: common_helper
INFO - 2022-03-08 23:16:51 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:16:51 --> Controller Class Initialized
INFO - 2022-03-08 23:16:51 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:16:51 --> Encrypt Class Initialized
INFO - 2022-03-08 23:16:51 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:16:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:16:51 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:16:51 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:16:51 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:16:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:16:51 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:16:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:16:51 --> Final output sent to browser
DEBUG - 2022-03-08 23:16:51 --> Total execution time: 0.0557
ERROR - 2022-03-08 23:17:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:17:19 --> Config Class Initialized
INFO - 2022-03-08 23:17:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:17:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:17:19 --> Utf8 Class Initialized
INFO - 2022-03-08 23:17:19 --> URI Class Initialized
INFO - 2022-03-08 23:17:19 --> Router Class Initialized
INFO - 2022-03-08 23:17:19 --> Output Class Initialized
INFO - 2022-03-08 23:17:19 --> Security Class Initialized
DEBUG - 2022-03-08 23:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:17:19 --> Input Class Initialized
INFO - 2022-03-08 23:17:19 --> Language Class Initialized
INFO - 2022-03-08 23:17:19 --> Loader Class Initialized
INFO - 2022-03-08 23:17:19 --> Helper loaded: url_helper
INFO - 2022-03-08 23:17:19 --> Helper loaded: form_helper
INFO - 2022-03-08 23:17:19 --> Helper loaded: common_helper
INFO - 2022-03-08 23:17:19 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:17:19 --> Controller Class Initialized
INFO - 2022-03-08 23:17:19 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:17:19 --> Encrypt Class Initialized
INFO - 2022-03-08 23:17:19 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:17:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:17:19 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:17:19 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:17:19 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:17:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:17:20 --> Config Class Initialized
INFO - 2022-03-08 23:17:20 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:17:20 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:17:20 --> Utf8 Class Initialized
INFO - 2022-03-08 23:17:20 --> URI Class Initialized
INFO - 2022-03-08 23:17:20 --> Router Class Initialized
INFO - 2022-03-08 23:17:20 --> Output Class Initialized
INFO - 2022-03-08 23:17:20 --> Security Class Initialized
DEBUG - 2022-03-08 23:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:17:20 --> Input Class Initialized
INFO - 2022-03-08 23:17:20 --> Language Class Initialized
INFO - 2022-03-08 23:17:20 --> Loader Class Initialized
INFO - 2022-03-08 23:17:20 --> Helper loaded: url_helper
INFO - 2022-03-08 23:17:20 --> Helper loaded: form_helper
INFO - 2022-03-08 23:17:20 --> Helper loaded: common_helper
INFO - 2022-03-08 23:17:20 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:17:20 --> Controller Class Initialized
INFO - 2022-03-08 23:17:20 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:17:20 --> Encrypt Class Initialized
INFO - 2022-03-08 23:17:20 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:17:20 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:17:20 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:17:20 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:17:20 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:17:20 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:17:20 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:17:20 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:17:20 --> Final output sent to browser
DEBUG - 2022-03-08 23:17:20 --> Total execution time: 0.0687
ERROR - 2022-03-08 23:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:17:21 --> Config Class Initialized
INFO - 2022-03-08 23:17:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:17:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:17:21 --> Utf8 Class Initialized
INFO - 2022-03-08 23:17:21 --> URI Class Initialized
INFO - 2022-03-08 23:17:21 --> Router Class Initialized
INFO - 2022-03-08 23:17:21 --> Output Class Initialized
INFO - 2022-03-08 23:17:21 --> Security Class Initialized
DEBUG - 2022-03-08 23:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:17:21 --> Input Class Initialized
INFO - 2022-03-08 23:17:21 --> Language Class Initialized
INFO - 2022-03-08 23:17:21 --> Loader Class Initialized
INFO - 2022-03-08 23:17:21 --> Helper loaded: url_helper
INFO - 2022-03-08 23:17:21 --> Helper loaded: form_helper
INFO - 2022-03-08 23:17:21 --> Helper loaded: common_helper
INFO - 2022-03-08 23:17:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:17:21 --> Controller Class Initialized
INFO - 2022-03-08 23:17:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:17:21 --> Encrypt Class Initialized
INFO - 2022-03-08 23:17:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:17:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:17:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:17:21 --> Model "Users_model" initialized
INFO - 2022-03-08 23:17:21 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:17:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:17:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:17:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:17:21 --> Final output sent to browser
DEBUG - 2022-03-08 23:17:21 --> Total execution time: 0.0958
ERROR - 2022-03-08 23:19:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:19:32 --> Config Class Initialized
INFO - 2022-03-08 23:19:32 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:19:32 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:19:32 --> Utf8 Class Initialized
INFO - 2022-03-08 23:19:32 --> URI Class Initialized
INFO - 2022-03-08 23:19:32 --> Router Class Initialized
INFO - 2022-03-08 23:19:32 --> Output Class Initialized
INFO - 2022-03-08 23:19:32 --> Security Class Initialized
DEBUG - 2022-03-08 23:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:19:32 --> Input Class Initialized
INFO - 2022-03-08 23:19:32 --> Language Class Initialized
INFO - 2022-03-08 23:19:32 --> Loader Class Initialized
INFO - 2022-03-08 23:19:32 --> Helper loaded: url_helper
INFO - 2022-03-08 23:19:32 --> Helper loaded: form_helper
INFO - 2022-03-08 23:19:32 --> Helper loaded: common_helper
INFO - 2022-03-08 23:19:32 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:19:32 --> Controller Class Initialized
INFO - 2022-03-08 23:19:32 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:19:32 --> Encrypt Class Initialized
INFO - 2022-03-08 23:19:32 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:19:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:19:32 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:19:32 --> Model "Users_model" initialized
INFO - 2022-03-08 23:19:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:19:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:19:33 --> Config Class Initialized
INFO - 2022-03-08 23:19:33 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:19:33 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:19:33 --> Utf8 Class Initialized
INFO - 2022-03-08 23:19:33 --> URI Class Initialized
INFO - 2022-03-08 23:19:33 --> Router Class Initialized
INFO - 2022-03-08 23:19:33 --> Output Class Initialized
INFO - 2022-03-08 23:19:33 --> Security Class Initialized
DEBUG - 2022-03-08 23:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:19:33 --> Input Class Initialized
INFO - 2022-03-08 23:19:33 --> Language Class Initialized
INFO - 2022-03-08 23:19:33 --> Loader Class Initialized
INFO - 2022-03-08 23:19:33 --> Helper loaded: url_helper
INFO - 2022-03-08 23:19:33 --> Helper loaded: form_helper
INFO - 2022-03-08 23:19:33 --> Helper loaded: common_helper
INFO - 2022-03-08 23:19:33 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:19:33 --> Controller Class Initialized
INFO - 2022-03-08 23:19:33 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:19:33 --> Encrypt Class Initialized
INFO - 2022-03-08 23:19:33 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:19:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:19:33 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:19:33 --> Model "Users_model" initialized
INFO - 2022-03-08 23:19:33 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:19:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:19:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:19:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:19:33 --> Final output sent to browser
DEBUG - 2022-03-08 23:19:33 --> Total execution time: 0.1043
ERROR - 2022-03-08 23:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:19:58 --> Config Class Initialized
INFO - 2022-03-08 23:19:58 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:19:58 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:19:58 --> Utf8 Class Initialized
INFO - 2022-03-08 23:19:58 --> URI Class Initialized
INFO - 2022-03-08 23:19:58 --> Router Class Initialized
INFO - 2022-03-08 23:19:58 --> Output Class Initialized
INFO - 2022-03-08 23:19:58 --> Security Class Initialized
DEBUG - 2022-03-08 23:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:19:58 --> Input Class Initialized
INFO - 2022-03-08 23:19:58 --> Language Class Initialized
INFO - 2022-03-08 23:19:58 --> Loader Class Initialized
INFO - 2022-03-08 23:19:58 --> Helper loaded: url_helper
INFO - 2022-03-08 23:19:58 --> Helper loaded: form_helper
INFO - 2022-03-08 23:19:58 --> Helper loaded: common_helper
INFO - 2022-03-08 23:19:58 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:19:58 --> Controller Class Initialized
INFO - 2022-03-08 23:19:58 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:19:58 --> Encrypt Class Initialized
INFO - 2022-03-08 23:19:58 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:19:58 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:19:58 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:19:58 --> Model "Users_model" initialized
INFO - 2022-03-08 23:19:58 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:19:58 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:19:58 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:19:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:19:58 --> Final output sent to browser
DEBUG - 2022-03-08 23:19:58 --> Total execution time: 0.0740
ERROR - 2022-03-08 23:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:19:59 --> Config Class Initialized
INFO - 2022-03-08 23:19:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:19:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:19:59 --> Utf8 Class Initialized
INFO - 2022-03-08 23:19:59 --> URI Class Initialized
INFO - 2022-03-08 23:19:59 --> Router Class Initialized
INFO - 2022-03-08 23:19:59 --> Output Class Initialized
INFO - 2022-03-08 23:19:59 --> Security Class Initialized
DEBUG - 2022-03-08 23:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:19:59 --> Input Class Initialized
INFO - 2022-03-08 23:19:59 --> Language Class Initialized
ERROR - 2022-03-08 23:19:59 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:21:25 --> Config Class Initialized
INFO - 2022-03-08 23:21:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:21:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:21:25 --> Utf8 Class Initialized
INFO - 2022-03-08 23:21:25 --> URI Class Initialized
INFO - 2022-03-08 23:21:25 --> Router Class Initialized
INFO - 2022-03-08 23:21:25 --> Output Class Initialized
INFO - 2022-03-08 23:21:25 --> Security Class Initialized
DEBUG - 2022-03-08 23:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:21:25 --> Input Class Initialized
INFO - 2022-03-08 23:21:25 --> Language Class Initialized
INFO - 2022-03-08 23:21:25 --> Loader Class Initialized
INFO - 2022-03-08 23:21:25 --> Helper loaded: url_helper
INFO - 2022-03-08 23:21:25 --> Helper loaded: form_helper
INFO - 2022-03-08 23:21:25 --> Helper loaded: common_helper
INFO - 2022-03-08 23:21:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:21:25 --> Controller Class Initialized
INFO - 2022-03-08 23:21:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:21:25 --> Encrypt Class Initialized
INFO - 2022-03-08 23:21:25 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:21:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:21:25 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:21:25 --> Model "Users_model" initialized
INFO - 2022-03-08 23:21:25 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:21:25 --> Upload Class Initialized
INFO - 2022-03-08 23:21:25 --> Final output sent to browser
DEBUG - 2022-03-08 23:21:25 --> Total execution time: 0.0636
ERROR - 2022-03-08 23:22:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:22:45 --> Config Class Initialized
INFO - 2022-03-08 23:22:45 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:22:45 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:22:45 --> Utf8 Class Initialized
INFO - 2022-03-08 23:22:45 --> URI Class Initialized
INFO - 2022-03-08 23:22:45 --> Router Class Initialized
INFO - 2022-03-08 23:22:45 --> Output Class Initialized
INFO - 2022-03-08 23:22:45 --> Security Class Initialized
DEBUG - 2022-03-08 23:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:22:45 --> Input Class Initialized
INFO - 2022-03-08 23:22:45 --> Language Class Initialized
INFO - 2022-03-08 23:22:45 --> Loader Class Initialized
INFO - 2022-03-08 23:22:45 --> Helper loaded: url_helper
INFO - 2022-03-08 23:22:45 --> Helper loaded: form_helper
INFO - 2022-03-08 23:22:45 --> Helper loaded: common_helper
INFO - 2022-03-08 23:22:45 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:22:45 --> Controller Class Initialized
INFO - 2022-03-08 23:22:45 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:22:45 --> Encrypt Class Initialized
INFO - 2022-03-08 23:22:45 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:22:45 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:22:45 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:22:45 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:22:45 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:22:45 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:22:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/patient_by_category.php
INFO - 2022-03-08 23:22:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:22:45 --> Final output sent to browser
DEBUG - 2022-03-08 23:22:45 --> Total execution time: 0.0561
ERROR - 2022-03-08 23:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:22:49 --> Config Class Initialized
INFO - 2022-03-08 23:22:49 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:22:49 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:22:49 --> Utf8 Class Initialized
INFO - 2022-03-08 23:22:49 --> URI Class Initialized
INFO - 2022-03-08 23:22:49 --> Router Class Initialized
INFO - 2022-03-08 23:22:49 --> Output Class Initialized
INFO - 2022-03-08 23:22:49 --> Security Class Initialized
DEBUG - 2022-03-08 23:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:22:49 --> Input Class Initialized
INFO - 2022-03-08 23:22:49 --> Language Class Initialized
INFO - 2022-03-08 23:22:49 --> Loader Class Initialized
INFO - 2022-03-08 23:22:49 --> Helper loaded: url_helper
INFO - 2022-03-08 23:22:49 --> Helper loaded: form_helper
INFO - 2022-03-08 23:22:49 --> Helper loaded: common_helper
INFO - 2022-03-08 23:22:49 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:22:49 --> Controller Class Initialized
INFO - 2022-03-08 23:22:49 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:22:49 --> Encrypt Class Initialized
INFO - 2022-03-08 23:22:49 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:22:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:22:49 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:22:49 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:22:49 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:22:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:22:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:22:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:22:49 --> Final output sent to browser
DEBUG - 2022-03-08 23:22:49 --> Total execution time: 0.0491
ERROR - 2022-03-08 23:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:22:55 --> Config Class Initialized
INFO - 2022-03-08 23:22:55 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:22:55 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:22:55 --> Utf8 Class Initialized
INFO - 2022-03-08 23:22:55 --> URI Class Initialized
INFO - 2022-03-08 23:22:55 --> Router Class Initialized
INFO - 2022-03-08 23:22:55 --> Output Class Initialized
INFO - 2022-03-08 23:22:55 --> Security Class Initialized
DEBUG - 2022-03-08 23:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:22:55 --> Input Class Initialized
INFO - 2022-03-08 23:22:55 --> Language Class Initialized
INFO - 2022-03-08 23:22:55 --> Loader Class Initialized
INFO - 2022-03-08 23:22:55 --> Helper loaded: url_helper
INFO - 2022-03-08 23:22:55 --> Helper loaded: form_helper
INFO - 2022-03-08 23:22:55 --> Helper loaded: common_helper
INFO - 2022-03-08 23:22:55 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:22:55 --> Controller Class Initialized
INFO - 2022-03-08 23:22:55 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:22:55 --> Encrypt Class Initialized
INFO - 2022-03-08 23:22:55 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:22:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:22:55 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:22:55 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:22:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:22:55 --> Config Class Initialized
INFO - 2022-03-08 23:22:55 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:22:55 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:22:55 --> Utf8 Class Initialized
INFO - 2022-03-08 23:22:55 --> URI Class Initialized
INFO - 2022-03-08 23:22:55 --> Router Class Initialized
INFO - 2022-03-08 23:22:55 --> Output Class Initialized
INFO - 2022-03-08 23:22:55 --> Security Class Initialized
DEBUG - 2022-03-08 23:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:22:55 --> Input Class Initialized
INFO - 2022-03-08 23:22:55 --> Language Class Initialized
INFO - 2022-03-08 23:22:55 --> Loader Class Initialized
INFO - 2022-03-08 23:22:55 --> Helper loaded: url_helper
INFO - 2022-03-08 23:22:55 --> Helper loaded: form_helper
INFO - 2022-03-08 23:22:55 --> Helper loaded: common_helper
INFO - 2022-03-08 23:22:55 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:22:55 --> Controller Class Initialized
INFO - 2022-03-08 23:22:55 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:22:55 --> Encrypt Class Initialized
INFO - 2022-03-08 23:22:55 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:22:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:22:55 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:22:55 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:22:55 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:22:55 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:22:55 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:22:55 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:22:55 --> Final output sent to browser
DEBUG - 2022-03-08 23:22:55 --> Total execution time: 0.0428
ERROR - 2022-03-08 23:22:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:22:56 --> Config Class Initialized
INFO - 2022-03-08 23:22:56 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:22:56 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:22:56 --> Utf8 Class Initialized
INFO - 2022-03-08 23:22:56 --> URI Class Initialized
INFO - 2022-03-08 23:22:56 --> Router Class Initialized
INFO - 2022-03-08 23:22:56 --> Output Class Initialized
INFO - 2022-03-08 23:22:56 --> Security Class Initialized
DEBUG - 2022-03-08 23:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:22:56 --> Input Class Initialized
INFO - 2022-03-08 23:22:56 --> Language Class Initialized
INFO - 2022-03-08 23:22:56 --> Loader Class Initialized
INFO - 2022-03-08 23:22:56 --> Helper loaded: url_helper
INFO - 2022-03-08 23:22:56 --> Helper loaded: form_helper
INFO - 2022-03-08 23:22:56 --> Helper loaded: common_helper
INFO - 2022-03-08 23:22:56 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:22:56 --> Controller Class Initialized
INFO - 2022-03-08 23:22:56 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:22:56 --> Encrypt Class Initialized
INFO - 2022-03-08 23:22:56 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:22:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:22:56 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:22:56 --> Model "Users_model" initialized
INFO - 2022-03-08 23:22:56 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:22:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:22:56 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:22:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:22:56 --> Final output sent to browser
DEBUG - 2022-03-08 23:22:56 --> Total execution time: 0.0756
ERROR - 2022-03-08 23:23:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:13 --> Config Class Initialized
INFO - 2022-03-08 23:23:13 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:13 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:13 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:13 --> URI Class Initialized
DEBUG - 2022-03-08 23:23:13 --> No URI present. Default controller set.
INFO - 2022-03-08 23:23:13 --> Router Class Initialized
INFO - 2022-03-08 23:23:13 --> Output Class Initialized
INFO - 2022-03-08 23:23:13 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:13 --> Input Class Initialized
INFO - 2022-03-08 23:23:13 --> Language Class Initialized
INFO - 2022-03-08 23:23:13 --> Loader Class Initialized
INFO - 2022-03-08 23:23:13 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:13 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:13 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:13 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:13 --> Controller Class Initialized
INFO - 2022-03-08 23:23:13 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:13 --> Encrypt Class Initialized
DEBUG - 2022-03-08 23:23:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 23:23:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 23:23:13 --> Email Class Initialized
INFO - 2022-03-08 23:23:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 23:23:13 --> Calendar Class Initialized
INFO - 2022-03-08 23:23:13 --> Model "Login_model" initialized
INFO - 2022-03-08 23:23:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-08 23:23:13 --> Final output sent to browser
DEBUG - 2022-03-08 23:23:13 --> Total execution time: 0.0359
ERROR - 2022-03-08 23:23:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:19 --> Config Class Initialized
INFO - 2022-03-08 23:23:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:19 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:19 --> URI Class Initialized
INFO - 2022-03-08 23:23:19 --> Router Class Initialized
INFO - 2022-03-08 23:23:19 --> Output Class Initialized
INFO - 2022-03-08 23:23:19 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:19 --> Input Class Initialized
INFO - 2022-03-08 23:23:19 --> Language Class Initialized
INFO - 2022-03-08 23:23:19 --> Loader Class Initialized
INFO - 2022-03-08 23:23:19 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:19 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:19 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:19 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:19 --> Controller Class Initialized
INFO - 2022-03-08 23:23:19 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:19 --> Encrypt Class Initialized
DEBUG - 2022-03-08 23:23:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 23:23:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 23:23:19 --> Email Class Initialized
INFO - 2022-03-08 23:23:19 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 23:23:19 --> Calendar Class Initialized
INFO - 2022-03-08 23:23:19 --> Model "Login_model" initialized
INFO - 2022-03-08 23:23:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-08 23:23:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:20 --> Config Class Initialized
INFO - 2022-03-08 23:23:20 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:20 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:20 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:20 --> URI Class Initialized
INFO - 2022-03-08 23:23:20 --> Router Class Initialized
INFO - 2022-03-08 23:23:20 --> Output Class Initialized
INFO - 2022-03-08 23:23:20 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:20 --> Input Class Initialized
INFO - 2022-03-08 23:23:20 --> Language Class Initialized
INFO - 2022-03-08 23:23:20 --> Loader Class Initialized
INFO - 2022-03-08 23:23:20 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:20 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:20 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:20 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:20 --> Controller Class Initialized
INFO - 2022-03-08 23:23:20 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:20 --> Encrypt Class Initialized
INFO - 2022-03-08 23:23:20 --> Model "Login_model" initialized
INFO - 2022-03-08 23:23:20 --> Model "Dashboard_model" initialized
INFO - 2022-03-08 23:23:20 --> Model "Case_model" initialized
ERROR - 2022-03-08 23:23:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:24 --> Config Class Initialized
INFO - 2022-03-08 23:23:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:24 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:24 --> URI Class Initialized
INFO - 2022-03-08 23:23:24 --> Router Class Initialized
INFO - 2022-03-08 23:23:24 --> Output Class Initialized
INFO - 2022-03-08 23:23:24 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:24 --> Input Class Initialized
INFO - 2022-03-08 23:23:24 --> Language Class Initialized
INFO - 2022-03-08 23:23:24 --> Loader Class Initialized
INFO - 2022-03-08 23:23:24 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:24 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:24 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:24 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:24 --> Controller Class Initialized
INFO - 2022-03-08 23:23:24 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:24 --> Encrypt Class Initialized
INFO - 2022-03-08 23:23:24 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:23:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:23:24 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:23:25 --> Model "Users_model" initialized
INFO - 2022-03-08 23:23:25 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:23:25 --> Final output sent to browser
DEBUG - 2022-03-08 23:23:25 --> Total execution time: 0.0274
INFO - 2022-03-08 23:23:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 23:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:37 --> Config Class Initialized
INFO - 2022-03-08 23:23:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:37 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:37 --> URI Class Initialized
INFO - 2022-03-08 23:23:37 --> Router Class Initialized
INFO - 2022-03-08 23:23:37 --> Output Class Initialized
INFO - 2022-03-08 23:23:37 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:37 --> Input Class Initialized
INFO - 2022-03-08 23:23:37 --> Language Class Initialized
INFO - 2022-03-08 23:23:37 --> Loader Class Initialized
INFO - 2022-03-08 23:23:37 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:37 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:37 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:37 --> Controller Class Initialized
INFO - 2022-03-08 23:23:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:37 --> Encrypt Class Initialized
INFO - 2022-03-08 23:23:37 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:23:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:23:37 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:23:37 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:23:37 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:23:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:23:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:23:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:23:37 --> Final output sent to browser
DEBUG - 2022-03-08 23:23:37 --> Total execution time: 0.0558
ERROR - 2022-03-08 23:23:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:39 --> Config Class Initialized
INFO - 2022-03-08 23:23:39 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:39 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:39 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:39 --> URI Class Initialized
INFO - 2022-03-08 23:23:39 --> Router Class Initialized
INFO - 2022-03-08 23:23:39 --> Output Class Initialized
INFO - 2022-03-08 23:23:39 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:39 --> Input Class Initialized
INFO - 2022-03-08 23:23:39 --> Language Class Initialized
INFO - 2022-03-08 23:23:39 --> Loader Class Initialized
INFO - 2022-03-08 23:23:39 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:39 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:39 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:39 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:39 --> Controller Class Initialized
INFO - 2022-03-08 23:23:39 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:39 --> Encrypt Class Initialized
INFO - 2022-03-08 23:23:39 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:23:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:23:39 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:23:39 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:23:39 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:23:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:23:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:23:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:23:39 --> Final output sent to browser
DEBUG - 2022-03-08 23:23:39 --> Total execution time: 0.0791
INFO - 2022-03-08 23:23:43 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-08 23:23:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:23:43 --> Final output sent to browser
DEBUG - 2022-03-08 23:23:43 --> Total execution time: 23.6945
ERROR - 2022-03-08 23:23:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:46 --> Config Class Initialized
INFO - 2022-03-08 23:23:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:46 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:46 --> URI Class Initialized
INFO - 2022-03-08 23:23:46 --> Router Class Initialized
INFO - 2022-03-08 23:23:46 --> Output Class Initialized
INFO - 2022-03-08 23:23:46 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:46 --> Input Class Initialized
INFO - 2022-03-08 23:23:46 --> Language Class Initialized
INFO - 2022-03-08 23:23:46 --> Loader Class Initialized
INFO - 2022-03-08 23:23:46 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:46 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:46 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:46 --> Controller Class Initialized
INFO - 2022-03-08 23:23:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:46 --> Encrypt Class Initialized
INFO - 2022-03-08 23:23:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:23:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:23:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:23:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:23:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:23:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:23:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:23:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:23:46 --> Final output sent to browser
DEBUG - 2022-03-08 23:23:46 --> Total execution time: 0.0513
ERROR - 2022-03-08 23:23:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:52 --> Config Class Initialized
INFO - 2022-03-08 23:23:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:52 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:52 --> URI Class Initialized
INFO - 2022-03-08 23:23:52 --> Router Class Initialized
INFO - 2022-03-08 23:23:52 --> Output Class Initialized
INFO - 2022-03-08 23:23:52 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:52 --> Input Class Initialized
INFO - 2022-03-08 23:23:52 --> Language Class Initialized
INFO - 2022-03-08 23:23:52 --> Loader Class Initialized
INFO - 2022-03-08 23:23:52 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:52 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:52 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:52 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:52 --> Controller Class Initialized
INFO - 2022-03-08 23:23:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:52 --> Encrypt Class Initialized
INFO - 2022-03-08 23:23:52 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:23:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:23:52 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:23:52 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:23:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:53 --> Config Class Initialized
INFO - 2022-03-08 23:23:53 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:53 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:53 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:53 --> URI Class Initialized
INFO - 2022-03-08 23:23:53 --> Router Class Initialized
INFO - 2022-03-08 23:23:53 --> Output Class Initialized
INFO - 2022-03-08 23:23:53 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:53 --> Input Class Initialized
INFO - 2022-03-08 23:23:53 --> Language Class Initialized
INFO - 2022-03-08 23:23:53 --> Loader Class Initialized
INFO - 2022-03-08 23:23:53 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:53 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:53 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:53 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:53 --> Controller Class Initialized
INFO - 2022-03-08 23:23:53 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:53 --> Encrypt Class Initialized
INFO - 2022-03-08 23:23:53 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:23:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:23:53 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:23:53 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:23:53 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:23:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:23:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:23:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:23:53 --> Final output sent to browser
DEBUG - 2022-03-08 23:23:53 --> Total execution time: 0.0496
ERROR - 2022-03-08 23:23:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:23:54 --> Config Class Initialized
INFO - 2022-03-08 23:23:54 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:23:54 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:23:54 --> Utf8 Class Initialized
INFO - 2022-03-08 23:23:54 --> URI Class Initialized
INFO - 2022-03-08 23:23:54 --> Router Class Initialized
INFO - 2022-03-08 23:23:54 --> Output Class Initialized
INFO - 2022-03-08 23:23:54 --> Security Class Initialized
DEBUG - 2022-03-08 23:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:23:54 --> Input Class Initialized
INFO - 2022-03-08 23:23:54 --> Language Class Initialized
INFO - 2022-03-08 23:23:54 --> Loader Class Initialized
INFO - 2022-03-08 23:23:54 --> Helper loaded: url_helper
INFO - 2022-03-08 23:23:54 --> Helper loaded: form_helper
INFO - 2022-03-08 23:23:54 --> Helper loaded: common_helper
INFO - 2022-03-08 23:23:54 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:23:54 --> Controller Class Initialized
INFO - 2022-03-08 23:23:54 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:23:54 --> Encrypt Class Initialized
INFO - 2022-03-08 23:23:54 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:23:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:23:54 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:23:54 --> Model "Users_model" initialized
INFO - 2022-03-08 23:23:54 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:23:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:23:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:23:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:23:54 --> Final output sent to browser
DEBUG - 2022-03-08 23:23:54 --> Total execution time: 0.0844
ERROR - 2022-03-08 23:24:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:10 --> Config Class Initialized
INFO - 2022-03-08 23:24:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:10 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:10 --> URI Class Initialized
INFO - 2022-03-08 23:24:10 --> Router Class Initialized
INFO - 2022-03-08 23:24:10 --> Output Class Initialized
INFO - 2022-03-08 23:24:10 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:10 --> Input Class Initialized
INFO - 2022-03-08 23:24:10 --> Language Class Initialized
INFO - 2022-03-08 23:24:10 --> Loader Class Initialized
INFO - 2022-03-08 23:24:10 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:10 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:10 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:10 --> Controller Class Initialized
INFO - 2022-03-08 23:24:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:10 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:10 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:24:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:10 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:24:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:24:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:24:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:24:17 --> Final output sent to browser
DEBUG - 2022-03-08 23:24:17 --> Total execution time: 5.4271
ERROR - 2022-03-08 23:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:28 --> Config Class Initialized
INFO - 2022-03-08 23:24:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:28 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:28 --> URI Class Initialized
INFO - 2022-03-08 23:24:28 --> Router Class Initialized
INFO - 2022-03-08 23:24:28 --> Output Class Initialized
INFO - 2022-03-08 23:24:28 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:28 --> Input Class Initialized
INFO - 2022-03-08 23:24:28 --> Language Class Initialized
INFO - 2022-03-08 23:24:28 --> Loader Class Initialized
INFO - 2022-03-08 23:24:28 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:28 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:28 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:28 --> Controller Class Initialized
INFO - 2022-03-08 23:24:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:28 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:28 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:28 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:24:28 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:28 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:24:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 23:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:28 --> Config Class Initialized
INFO - 2022-03-08 23:24:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:28 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:28 --> URI Class Initialized
INFO - 2022-03-08 23:24:28 --> Router Class Initialized
INFO - 2022-03-08 23:24:28 --> Output Class Initialized
INFO - 2022-03-08 23:24:28 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:28 --> Input Class Initialized
INFO - 2022-03-08 23:24:28 --> Language Class Initialized
INFO - 2022-03-08 23:24:28 --> Loader Class Initialized
INFO - 2022-03-08 23:24:28 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:28 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:28 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:28 --> Controller Class Initialized
INFO - 2022-03-08 23:24:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:28 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:28 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:28 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:28 --> Model "Users_model" initialized
INFO - 2022-03-08 23:24:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:29 --> Config Class Initialized
INFO - 2022-03-08 23:24:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:29 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:29 --> URI Class Initialized
INFO - 2022-03-08 23:24:29 --> Router Class Initialized
INFO - 2022-03-08 23:24:29 --> Output Class Initialized
INFO - 2022-03-08 23:24:29 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:29 --> Input Class Initialized
INFO - 2022-03-08 23:24:29 --> Language Class Initialized
INFO - 2022-03-08 23:24:29 --> Loader Class Initialized
INFO - 2022-03-08 23:24:29 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:29 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:29 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:29 --> Controller Class Initialized
INFO - 2022-03-08 23:24:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:29 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:29 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:29 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:29 --> Model "Users_model" initialized
INFO - 2022-03-08 23:24:29 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:24:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:30 --> Config Class Initialized
INFO - 2022-03-08 23:24:30 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:30 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:30 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:30 --> URI Class Initialized
INFO - 2022-03-08 23:24:30 --> Router Class Initialized
INFO - 2022-03-08 23:24:30 --> Output Class Initialized
INFO - 2022-03-08 23:24:30 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:30 --> Input Class Initialized
INFO - 2022-03-08 23:24:30 --> Language Class Initialized
INFO - 2022-03-08 23:24:30 --> Loader Class Initialized
INFO - 2022-03-08 23:24:30 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:30 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:30 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:30 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:30 --> Controller Class Initialized
INFO - 2022-03-08 23:24:30 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:30 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:30 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:30 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:30 --> Model "Users_model" initialized
INFO - 2022-03-08 23:24:30 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:24:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:24:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:24:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:24:31 --> Final output sent to browser
DEBUG - 2022-03-08 23:24:31 --> Total execution time: 0.1301
ERROR - 2022-03-08 23:24:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:33 --> Config Class Initialized
INFO - 2022-03-08 23:24:33 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:33 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:33 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:33 --> URI Class Initialized
INFO - 2022-03-08 23:24:33 --> Router Class Initialized
INFO - 2022-03-08 23:24:33 --> Output Class Initialized
INFO - 2022-03-08 23:24:33 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:33 --> Input Class Initialized
INFO - 2022-03-08 23:24:33 --> Language Class Initialized
INFO - 2022-03-08 23:24:33 --> Loader Class Initialized
INFO - 2022-03-08 23:24:33 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:33 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:33 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:33 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:33 --> Controller Class Initialized
INFO - 2022-03-08 23:24:33 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:33 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:33 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:33 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:33 --> Model "Users_model" initialized
INFO - 2022-03-08 23:24:33 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:24:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:34 --> Config Class Initialized
INFO - 2022-03-08 23:24:34 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:34 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:34 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:34 --> URI Class Initialized
INFO - 2022-03-08 23:24:34 --> Router Class Initialized
INFO - 2022-03-08 23:24:34 --> Output Class Initialized
INFO - 2022-03-08 23:24:34 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:34 --> Input Class Initialized
INFO - 2022-03-08 23:24:34 --> Language Class Initialized
INFO - 2022-03-08 23:24:34 --> Loader Class Initialized
INFO - 2022-03-08 23:24:34 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:34 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:34 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:34 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:34 --> Controller Class Initialized
INFO - 2022-03-08 23:24:34 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:34 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:34 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:34 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:34 --> Model "Users_model" initialized
INFO - 2022-03-08 23:24:34 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:24:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:24:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:24:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:24:34 --> Final output sent to browser
DEBUG - 2022-03-08 23:24:34 --> Total execution time: 0.0947
ERROR - 2022-03-08 23:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:39 --> Config Class Initialized
INFO - 2022-03-08 23:24:39 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:39 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:39 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:39 --> URI Class Initialized
INFO - 2022-03-08 23:24:39 --> Router Class Initialized
INFO - 2022-03-08 23:24:39 --> Output Class Initialized
INFO - 2022-03-08 23:24:39 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:39 --> Input Class Initialized
INFO - 2022-03-08 23:24:39 --> Language Class Initialized
INFO - 2022-03-08 23:24:39 --> Loader Class Initialized
INFO - 2022-03-08 23:24:39 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:39 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:39 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:39 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:39 --> Controller Class Initialized
INFO - 2022-03-08 23:24:39 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:39 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:39 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:39 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:24:39 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:39 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:24:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:24:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:24:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:24:39 --> Final output sent to browser
DEBUG - 2022-03-08 23:24:39 --> Total execution time: 0.1185
INFO - 2022-03-08 23:24:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:24:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:24:40 --> Final output sent to browser
DEBUG - 2022-03-08 23:24:40 --> Total execution time: 11.1166
ERROR - 2022-03-08 23:24:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:46 --> Config Class Initialized
INFO - 2022-03-08 23:24:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:46 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:46 --> URI Class Initialized
INFO - 2022-03-08 23:24:46 --> Router Class Initialized
INFO - 2022-03-08 23:24:46 --> Output Class Initialized
INFO - 2022-03-08 23:24:46 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:46 --> Input Class Initialized
INFO - 2022-03-08 23:24:46 --> Language Class Initialized
INFO - 2022-03-08 23:24:46 --> Loader Class Initialized
INFO - 2022-03-08 23:24:46 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:46 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:46 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:46 --> Controller Class Initialized
INFO - 2022-03-08 23:24:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:46 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:24:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:24:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:24:46 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:24:46 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:24:46 --> Final output sent to browser
DEBUG - 2022-03-08 23:24:46 --> Total execution time: 0.0707
ERROR - 2022-03-08 23:24:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:52 --> Config Class Initialized
INFO - 2022-03-08 23:24:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:52 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:52 --> URI Class Initialized
INFO - 2022-03-08 23:24:52 --> Router Class Initialized
INFO - 2022-03-08 23:24:52 --> Output Class Initialized
INFO - 2022-03-08 23:24:52 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:52 --> Input Class Initialized
INFO - 2022-03-08 23:24:52 --> Language Class Initialized
INFO - 2022-03-08 23:24:52 --> Loader Class Initialized
INFO - 2022-03-08 23:24:52 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:52 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:52 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:52 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:52 --> Controller Class Initialized
INFO - 2022-03-08 23:24:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:52 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:52 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:52 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:24:52 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:53 --> Config Class Initialized
INFO - 2022-03-08 23:24:53 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:53 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:53 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:53 --> URI Class Initialized
INFO - 2022-03-08 23:24:53 --> Router Class Initialized
INFO - 2022-03-08 23:24:53 --> Output Class Initialized
INFO - 2022-03-08 23:24:53 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:53 --> Input Class Initialized
INFO - 2022-03-08 23:24:53 --> Language Class Initialized
INFO - 2022-03-08 23:24:53 --> Loader Class Initialized
INFO - 2022-03-08 23:24:53 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:53 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:53 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:53 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:53 --> Controller Class Initialized
INFO - 2022-03-08 23:24:53 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:53 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:53 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:53 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:24:53 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:53 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:24:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:24:53 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:24:53 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:24:53 --> Final output sent to browser
DEBUG - 2022-03-08 23:24:53 --> Total execution time: 0.0449
ERROR - 2022-03-08 23:24:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:24:54 --> Config Class Initialized
INFO - 2022-03-08 23:24:54 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:24:54 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:24:54 --> Utf8 Class Initialized
INFO - 2022-03-08 23:24:54 --> URI Class Initialized
INFO - 2022-03-08 23:24:54 --> Router Class Initialized
INFO - 2022-03-08 23:24:54 --> Output Class Initialized
INFO - 2022-03-08 23:24:54 --> Security Class Initialized
DEBUG - 2022-03-08 23:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:24:54 --> Input Class Initialized
INFO - 2022-03-08 23:24:54 --> Language Class Initialized
INFO - 2022-03-08 23:24:54 --> Loader Class Initialized
INFO - 2022-03-08 23:24:54 --> Helper loaded: url_helper
INFO - 2022-03-08 23:24:54 --> Helper loaded: form_helper
INFO - 2022-03-08 23:24:54 --> Helper loaded: common_helper
INFO - 2022-03-08 23:24:54 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:24:54 --> Controller Class Initialized
INFO - 2022-03-08 23:24:54 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:24:54 --> Encrypt Class Initialized
INFO - 2022-03-08 23:24:54 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:24:54 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:24:54 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:24:54 --> Model "Users_model" initialized
INFO - 2022-03-08 23:24:54 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:24:54 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:24:54 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:24:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:24:54 --> Final output sent to browser
DEBUG - 2022-03-08 23:24:54 --> Total execution time: 0.1133
ERROR - 2022-03-08 23:25:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:25:06 --> Config Class Initialized
INFO - 2022-03-08 23:25:06 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:25:06 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:25:06 --> Utf8 Class Initialized
INFO - 2022-03-08 23:25:06 --> URI Class Initialized
INFO - 2022-03-08 23:25:06 --> Router Class Initialized
INFO - 2022-03-08 23:25:06 --> Output Class Initialized
INFO - 2022-03-08 23:25:06 --> Security Class Initialized
DEBUG - 2022-03-08 23:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:25:06 --> Input Class Initialized
INFO - 2022-03-08 23:25:06 --> Language Class Initialized
INFO - 2022-03-08 23:25:06 --> Loader Class Initialized
INFO - 2022-03-08 23:25:06 --> Helper loaded: url_helper
INFO - 2022-03-08 23:25:06 --> Helper loaded: form_helper
INFO - 2022-03-08 23:25:06 --> Helper loaded: common_helper
INFO - 2022-03-08 23:25:06 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:25:06 --> Controller Class Initialized
INFO - 2022-03-08 23:25:06 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:25:06 --> Encrypt Class Initialized
INFO - 2022-03-08 23:25:06 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:25:06 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:25:06 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:25:06 --> Model "Users_model" initialized
INFO - 2022-03-08 23:25:06 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:25:06 --> Final output sent to browser
DEBUG - 2022-03-08 23:25:06 --> Total execution time: 0.0422
ERROR - 2022-03-08 23:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:25:09 --> Config Class Initialized
INFO - 2022-03-08 23:25:09 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:25:09 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:25:09 --> Utf8 Class Initialized
INFO - 2022-03-08 23:25:09 --> URI Class Initialized
INFO - 2022-03-08 23:25:09 --> Router Class Initialized
INFO - 2022-03-08 23:25:09 --> Output Class Initialized
INFO - 2022-03-08 23:25:09 --> Security Class Initialized
DEBUG - 2022-03-08 23:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:25:09 --> Input Class Initialized
INFO - 2022-03-08 23:25:09 --> Language Class Initialized
INFO - 2022-03-08 23:25:09 --> Loader Class Initialized
INFO - 2022-03-08 23:25:09 --> Helper loaded: url_helper
INFO - 2022-03-08 23:25:09 --> Helper loaded: form_helper
INFO - 2022-03-08 23:25:09 --> Helper loaded: common_helper
INFO - 2022-03-08 23:25:09 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:25:09 --> Controller Class Initialized
INFO - 2022-03-08 23:25:09 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:25:09 --> Encrypt Class Initialized
INFO - 2022-03-08 23:25:09 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:25:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:25:09 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:25:09 --> Model "Users_model" initialized
INFO - 2022-03-08 23:25:09 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:25:09 --> Final output sent to browser
DEBUG - 2022-03-08 23:25:09 --> Total execution time: 0.0306
ERROR - 2022-03-08 23:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:25:24 --> Config Class Initialized
INFO - 2022-03-08 23:25:24 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:25:24 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:25:24 --> Utf8 Class Initialized
INFO - 2022-03-08 23:25:24 --> URI Class Initialized
INFO - 2022-03-08 23:25:24 --> Router Class Initialized
INFO - 2022-03-08 23:25:24 --> Output Class Initialized
INFO - 2022-03-08 23:25:24 --> Security Class Initialized
DEBUG - 2022-03-08 23:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:25:24 --> Input Class Initialized
INFO - 2022-03-08 23:25:24 --> Language Class Initialized
INFO - 2022-03-08 23:25:24 --> Loader Class Initialized
INFO - 2022-03-08 23:25:24 --> Helper loaded: url_helper
INFO - 2022-03-08 23:25:24 --> Helper loaded: form_helper
INFO - 2022-03-08 23:25:24 --> Helper loaded: common_helper
INFO - 2022-03-08 23:25:24 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:25:24 --> Controller Class Initialized
INFO - 2022-03-08 23:25:24 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:25:24 --> Encrypt Class Initialized
INFO - 2022-03-08 23:25:24 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:25:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:25:24 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:25:24 --> Model "Users_model" initialized
INFO - 2022-03-08 23:25:24 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:25:24 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:25:24 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:25:24 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:25:24 --> Final output sent to browser
DEBUG - 2022-03-08 23:25:24 --> Total execution time: 0.0870
ERROR - 2022-03-08 23:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:25:27 --> Config Class Initialized
INFO - 2022-03-08 23:25:27 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:25:27 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:25:27 --> Utf8 Class Initialized
INFO - 2022-03-08 23:25:27 --> URI Class Initialized
INFO - 2022-03-08 23:25:27 --> Router Class Initialized
INFO - 2022-03-08 23:25:27 --> Output Class Initialized
INFO - 2022-03-08 23:25:27 --> Security Class Initialized
DEBUG - 2022-03-08 23:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:25:27 --> Input Class Initialized
INFO - 2022-03-08 23:25:27 --> Language Class Initialized
INFO - 2022-03-08 23:25:27 --> Loader Class Initialized
INFO - 2022-03-08 23:25:27 --> Helper loaded: url_helper
INFO - 2022-03-08 23:25:27 --> Helper loaded: form_helper
INFO - 2022-03-08 23:25:27 --> Helper loaded: common_helper
INFO - 2022-03-08 23:25:27 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:25:27 --> Controller Class Initialized
INFO - 2022-03-08 23:25:27 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:25:27 --> Encrypt Class Initialized
INFO - 2022-03-08 23:25:27 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:25:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:25:27 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:25:27 --> Model "Users_model" initialized
INFO - 2022-03-08 23:25:27 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:25:27 --> Upload Class Initialized
INFO - 2022-03-08 23:25:27 --> Final output sent to browser
DEBUG - 2022-03-08 23:25:27 --> Total execution time: 0.0461
ERROR - 2022-03-08 23:25:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:25:38 --> Config Class Initialized
INFO - 2022-03-08 23:25:38 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:25:38 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:25:38 --> Utf8 Class Initialized
INFO - 2022-03-08 23:25:38 --> URI Class Initialized
INFO - 2022-03-08 23:25:38 --> Router Class Initialized
INFO - 2022-03-08 23:25:38 --> Output Class Initialized
INFO - 2022-03-08 23:25:38 --> Security Class Initialized
DEBUG - 2022-03-08 23:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:25:38 --> Input Class Initialized
INFO - 2022-03-08 23:25:38 --> Language Class Initialized
INFO - 2022-03-08 23:25:38 --> Loader Class Initialized
INFO - 2022-03-08 23:25:38 --> Helper loaded: url_helper
INFO - 2022-03-08 23:25:38 --> Helper loaded: form_helper
INFO - 2022-03-08 23:25:38 --> Helper loaded: common_helper
INFO - 2022-03-08 23:25:38 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:25:38 --> Controller Class Initialized
INFO - 2022-03-08 23:25:38 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:25:38 --> Encrypt Class Initialized
INFO - 2022-03-08 23:25:38 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:25:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:25:38 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:25:38 --> Model "Users_model" initialized
INFO - 2022-03-08 23:25:38 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:25:38 --> Upload Class Initialized
INFO - 2022-03-08 23:25:38 --> Final output sent to browser
DEBUG - 2022-03-08 23:25:38 --> Total execution time: 0.0356
ERROR - 2022-03-08 23:25:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:25:46 --> Config Class Initialized
INFO - 2022-03-08 23:25:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:25:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:25:46 --> Utf8 Class Initialized
INFO - 2022-03-08 23:25:46 --> URI Class Initialized
INFO - 2022-03-08 23:25:46 --> Router Class Initialized
INFO - 2022-03-08 23:25:46 --> Output Class Initialized
INFO - 2022-03-08 23:25:46 --> Security Class Initialized
DEBUG - 2022-03-08 23:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:25:46 --> Input Class Initialized
INFO - 2022-03-08 23:25:46 --> Language Class Initialized
INFO - 2022-03-08 23:25:46 --> Loader Class Initialized
INFO - 2022-03-08 23:25:46 --> Helper loaded: url_helper
INFO - 2022-03-08 23:25:46 --> Helper loaded: form_helper
INFO - 2022-03-08 23:25:46 --> Helper loaded: common_helper
INFO - 2022-03-08 23:25:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:25:46 --> Controller Class Initialized
INFO - 2022-03-08 23:25:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:25:46 --> Encrypt Class Initialized
INFO - 2022-03-08 23:25:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:25:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:25:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:25:46 --> Model "Users_model" initialized
INFO - 2022-03-08 23:25:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:25:46 --> Final output sent to browser
DEBUG - 2022-03-08 23:25:46 --> Total execution time: 0.0235
ERROR - 2022-03-08 23:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:26:10 --> Config Class Initialized
INFO - 2022-03-08 23:26:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:26:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:26:10 --> Utf8 Class Initialized
INFO - 2022-03-08 23:26:10 --> URI Class Initialized
INFO - 2022-03-08 23:26:10 --> Router Class Initialized
INFO - 2022-03-08 23:26:10 --> Output Class Initialized
INFO - 2022-03-08 23:26:10 --> Security Class Initialized
DEBUG - 2022-03-08 23:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:26:10 --> Input Class Initialized
INFO - 2022-03-08 23:26:10 --> Language Class Initialized
INFO - 2022-03-08 23:26:10 --> Loader Class Initialized
INFO - 2022-03-08 23:26:10 --> Helper loaded: url_helper
INFO - 2022-03-08 23:26:10 --> Helper loaded: form_helper
INFO - 2022-03-08 23:26:10 --> Helper loaded: common_helper
INFO - 2022-03-08 23:26:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:26:10 --> Controller Class Initialized
INFO - 2022-03-08 23:26:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:26:10 --> Encrypt Class Initialized
INFO - 2022-03-08 23:26:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:26:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:26:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:26:10 --> Model "Users_model" initialized
INFO - 2022-03-08 23:26:10 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:26:10 --> Upload Class Initialized
INFO - 2022-03-08 23:26:10 --> Final output sent to browser
DEBUG - 2022-03-08 23:26:10 --> Total execution time: 0.0761
ERROR - 2022-03-08 23:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:26:14 --> Config Class Initialized
INFO - 2022-03-08 23:26:14 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:26:14 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:26:14 --> Utf8 Class Initialized
INFO - 2022-03-08 23:26:14 --> URI Class Initialized
INFO - 2022-03-08 23:26:14 --> Router Class Initialized
INFO - 2022-03-08 23:26:14 --> Output Class Initialized
INFO - 2022-03-08 23:26:14 --> Security Class Initialized
DEBUG - 2022-03-08 23:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:26:14 --> Input Class Initialized
INFO - 2022-03-08 23:26:14 --> Language Class Initialized
INFO - 2022-03-08 23:26:14 --> Loader Class Initialized
INFO - 2022-03-08 23:26:14 --> Helper loaded: url_helper
INFO - 2022-03-08 23:26:14 --> Helper loaded: form_helper
INFO - 2022-03-08 23:26:14 --> Helper loaded: common_helper
INFO - 2022-03-08 23:26:14 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:26:14 --> Controller Class Initialized
INFO - 2022-03-08 23:26:14 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:26:14 --> Encrypt Class Initialized
INFO - 2022-03-08 23:26:14 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:26:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:26:14 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:26:14 --> Model "Users_model" initialized
INFO - 2022-03-08 23:26:14 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:26:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:26:15 --> Config Class Initialized
INFO - 2022-03-08 23:26:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:26:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:26:15 --> Utf8 Class Initialized
INFO - 2022-03-08 23:26:15 --> URI Class Initialized
INFO - 2022-03-08 23:26:15 --> Router Class Initialized
INFO - 2022-03-08 23:26:15 --> Output Class Initialized
INFO - 2022-03-08 23:26:15 --> Security Class Initialized
DEBUG - 2022-03-08 23:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:26:15 --> Input Class Initialized
INFO - 2022-03-08 23:26:15 --> Language Class Initialized
INFO - 2022-03-08 23:26:15 --> Loader Class Initialized
INFO - 2022-03-08 23:26:15 --> Helper loaded: url_helper
INFO - 2022-03-08 23:26:15 --> Helper loaded: form_helper
INFO - 2022-03-08 23:26:15 --> Helper loaded: common_helper
INFO - 2022-03-08 23:26:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:26:15 --> Controller Class Initialized
INFO - 2022-03-08 23:26:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:26:15 --> Encrypt Class Initialized
INFO - 2022-03-08 23:26:15 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:26:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:26:15 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:26:15 --> Model "Users_model" initialized
INFO - 2022-03-08 23:26:15 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:26:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:26:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:26:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:26:15 --> Final output sent to browser
DEBUG - 2022-03-08 23:26:15 --> Total execution time: 0.1141
ERROR - 2022-03-08 23:26:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:26:21 --> Config Class Initialized
INFO - 2022-03-08 23:26:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:26:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:26:21 --> Utf8 Class Initialized
INFO - 2022-03-08 23:26:21 --> URI Class Initialized
INFO - 2022-03-08 23:26:21 --> Router Class Initialized
INFO - 2022-03-08 23:26:21 --> Output Class Initialized
INFO - 2022-03-08 23:26:21 --> Security Class Initialized
DEBUG - 2022-03-08 23:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:26:21 --> Input Class Initialized
INFO - 2022-03-08 23:26:21 --> Language Class Initialized
INFO - 2022-03-08 23:26:21 --> Loader Class Initialized
INFO - 2022-03-08 23:26:21 --> Helper loaded: url_helper
INFO - 2022-03-08 23:26:21 --> Helper loaded: form_helper
INFO - 2022-03-08 23:26:21 --> Helper loaded: common_helper
INFO - 2022-03-08 23:26:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:26:21 --> Controller Class Initialized
INFO - 2022-03-08 23:26:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:26:21 --> Encrypt Class Initialized
INFO - 2022-03-08 23:26:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:26:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:26:21 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:26:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:26:21 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:26:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 23:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:26:25 --> Config Class Initialized
INFO - 2022-03-08 23:26:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:26:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:26:25 --> Utf8 Class Initialized
INFO - 2022-03-08 23:26:25 --> URI Class Initialized
INFO - 2022-03-08 23:26:25 --> Router Class Initialized
INFO - 2022-03-08 23:26:25 --> Output Class Initialized
INFO - 2022-03-08 23:26:25 --> Security Class Initialized
DEBUG - 2022-03-08 23:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:26:25 --> Input Class Initialized
INFO - 2022-03-08 23:26:25 --> Language Class Initialized
INFO - 2022-03-08 23:26:25 --> Loader Class Initialized
INFO - 2022-03-08 23:26:25 --> Helper loaded: url_helper
INFO - 2022-03-08 23:26:25 --> Helper loaded: form_helper
INFO - 2022-03-08 23:26:25 --> Helper loaded: common_helper
INFO - 2022-03-08 23:26:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:26:25 --> Controller Class Initialized
INFO - 2022-03-08 23:26:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:26:25 --> Encrypt Class Initialized
INFO - 2022-03-08 23:26:25 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:26:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:26:25 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:26:25 --> Model "Users_model" initialized
INFO - 2022-03-08 23:26:25 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:26:25 --> Upload Class Initialized
INFO - 2022-03-08 23:26:25 --> Final output sent to browser
DEBUG - 2022-03-08 23:26:25 --> Total execution time: 0.0751
INFO - 2022-03-08 23:26:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:26:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:26:31 --> Final output sent to browser
DEBUG - 2022-03-08 23:26:31 --> Total execution time: 8.1939
ERROR - 2022-03-08 23:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:26:51 --> Config Class Initialized
INFO - 2022-03-08 23:26:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:26:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:26:51 --> Utf8 Class Initialized
INFO - 2022-03-08 23:26:51 --> URI Class Initialized
INFO - 2022-03-08 23:26:51 --> Router Class Initialized
INFO - 2022-03-08 23:26:51 --> Output Class Initialized
INFO - 2022-03-08 23:26:51 --> Security Class Initialized
DEBUG - 2022-03-08 23:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:26:51 --> Input Class Initialized
INFO - 2022-03-08 23:26:51 --> Language Class Initialized
INFO - 2022-03-08 23:26:51 --> Loader Class Initialized
INFO - 2022-03-08 23:26:51 --> Helper loaded: url_helper
INFO - 2022-03-08 23:26:51 --> Helper loaded: form_helper
INFO - 2022-03-08 23:26:51 --> Helper loaded: common_helper
INFO - 2022-03-08 23:26:51 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:26:51 --> Controller Class Initialized
INFO - 2022-03-08 23:26:51 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:26:51 --> Encrypt Class Initialized
INFO - 2022-03-08 23:26:51 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:26:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:26:51 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:26:51 --> Model "Users_model" initialized
INFO - 2022-03-08 23:26:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:26:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:26:52 --> Config Class Initialized
INFO - 2022-03-08 23:26:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:26:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:26:52 --> Utf8 Class Initialized
INFO - 2022-03-08 23:26:52 --> URI Class Initialized
INFO - 2022-03-08 23:26:52 --> Router Class Initialized
INFO - 2022-03-08 23:26:52 --> Output Class Initialized
INFO - 2022-03-08 23:26:52 --> Security Class Initialized
DEBUG - 2022-03-08 23:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:26:52 --> Input Class Initialized
INFO - 2022-03-08 23:26:52 --> Language Class Initialized
INFO - 2022-03-08 23:26:52 --> Loader Class Initialized
INFO - 2022-03-08 23:26:52 --> Helper loaded: url_helper
INFO - 2022-03-08 23:26:52 --> Helper loaded: form_helper
INFO - 2022-03-08 23:26:52 --> Helper loaded: common_helper
INFO - 2022-03-08 23:26:52 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:26:52 --> Controller Class Initialized
INFO - 2022-03-08 23:26:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:26:52 --> Encrypt Class Initialized
INFO - 2022-03-08 23:26:52 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:26:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:26:52 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:26:52 --> Model "Users_model" initialized
INFO - 2022-03-08 23:26:52 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:26:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:26:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:26:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:26:52 --> Final output sent to browser
DEBUG - 2022-03-08 23:26:52 --> Total execution time: 0.0929
ERROR - 2022-03-08 23:27:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:27:44 --> Config Class Initialized
INFO - 2022-03-08 23:27:44 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:27:44 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:27:44 --> Utf8 Class Initialized
INFO - 2022-03-08 23:27:44 --> URI Class Initialized
INFO - 2022-03-08 23:27:44 --> Router Class Initialized
INFO - 2022-03-08 23:27:44 --> Output Class Initialized
INFO - 2022-03-08 23:27:44 --> Security Class Initialized
DEBUG - 2022-03-08 23:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:27:44 --> Input Class Initialized
INFO - 2022-03-08 23:27:44 --> Language Class Initialized
INFO - 2022-03-08 23:27:44 --> Loader Class Initialized
INFO - 2022-03-08 23:27:44 --> Helper loaded: url_helper
INFO - 2022-03-08 23:27:44 --> Helper loaded: form_helper
INFO - 2022-03-08 23:27:44 --> Helper loaded: common_helper
INFO - 2022-03-08 23:27:44 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:27:44 --> Controller Class Initialized
INFO - 2022-03-08 23:27:44 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:27:44 --> Encrypt Class Initialized
INFO - 2022-03-08 23:27:44 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:27:44 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:27:44 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:27:44 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:27:44 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:27:44 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:27:44 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:27:44 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:27:44 --> Final output sent to browser
DEBUG - 2022-03-08 23:27:44 --> Total execution time: 0.0617
ERROR - 2022-03-08 23:27:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:27:50 --> Config Class Initialized
INFO - 2022-03-08 23:27:50 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:27:50 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:27:50 --> Utf8 Class Initialized
INFO - 2022-03-08 23:27:50 --> URI Class Initialized
INFO - 2022-03-08 23:27:50 --> Router Class Initialized
INFO - 2022-03-08 23:27:50 --> Output Class Initialized
INFO - 2022-03-08 23:27:50 --> Security Class Initialized
DEBUG - 2022-03-08 23:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:27:50 --> Input Class Initialized
INFO - 2022-03-08 23:27:50 --> Language Class Initialized
INFO - 2022-03-08 23:27:50 --> Loader Class Initialized
INFO - 2022-03-08 23:27:50 --> Helper loaded: url_helper
INFO - 2022-03-08 23:27:50 --> Helper loaded: form_helper
INFO - 2022-03-08 23:27:50 --> Helper loaded: common_helper
INFO - 2022-03-08 23:27:50 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:27:50 --> Controller Class Initialized
INFO - 2022-03-08 23:27:50 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:27:50 --> Encrypt Class Initialized
INFO - 2022-03-08 23:27:50 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:27:50 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:27:50 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:27:50 --> Model "Users_model" initialized
INFO - 2022-03-08 23:27:50 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:27:50 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:27:50 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:27:50 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:27:50 --> Final output sent to browser
DEBUG - 2022-03-08 23:27:50 --> Total execution time: 0.0557
ERROR - 2022-03-08 23:28:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:28:07 --> Config Class Initialized
INFO - 2022-03-08 23:28:07 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:28:07 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:28:07 --> Utf8 Class Initialized
INFO - 2022-03-08 23:28:07 --> URI Class Initialized
INFO - 2022-03-08 23:28:07 --> Router Class Initialized
INFO - 2022-03-08 23:28:07 --> Output Class Initialized
INFO - 2022-03-08 23:28:07 --> Security Class Initialized
DEBUG - 2022-03-08 23:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:28:07 --> Input Class Initialized
INFO - 2022-03-08 23:28:07 --> Language Class Initialized
INFO - 2022-03-08 23:28:07 --> Loader Class Initialized
INFO - 2022-03-08 23:28:07 --> Helper loaded: url_helper
INFO - 2022-03-08 23:28:07 --> Helper loaded: form_helper
INFO - 2022-03-08 23:28:07 --> Helper loaded: common_helper
INFO - 2022-03-08 23:28:07 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:28:07 --> Controller Class Initialized
INFO - 2022-03-08 23:28:07 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:28:07 --> Encrypt Class Initialized
INFO - 2022-03-08 23:28:07 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:28:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:28:07 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:28:07 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:28:07 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:28:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:28:07 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:28:07 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:28:07 --> Final output sent to browser
DEBUG - 2022-03-08 23:28:07 --> Total execution time: 0.0419
ERROR - 2022-03-08 23:28:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:28:10 --> Config Class Initialized
INFO - 2022-03-08 23:28:10 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:28:10 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:28:10 --> Utf8 Class Initialized
INFO - 2022-03-08 23:28:10 --> URI Class Initialized
INFO - 2022-03-08 23:28:10 --> Router Class Initialized
INFO - 2022-03-08 23:28:10 --> Output Class Initialized
INFO - 2022-03-08 23:28:10 --> Security Class Initialized
DEBUG - 2022-03-08 23:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:28:10 --> Input Class Initialized
INFO - 2022-03-08 23:28:10 --> Language Class Initialized
INFO - 2022-03-08 23:28:10 --> Loader Class Initialized
INFO - 2022-03-08 23:28:10 --> Helper loaded: url_helper
INFO - 2022-03-08 23:28:10 --> Helper loaded: form_helper
INFO - 2022-03-08 23:28:10 --> Helper loaded: common_helper
INFO - 2022-03-08 23:28:10 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:28:10 --> Controller Class Initialized
INFO - 2022-03-08 23:28:10 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:28:10 --> Encrypt Class Initialized
INFO - 2022-03-08 23:28:10 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:28:10 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:28:10 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:28:10 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:28:10 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:28:10 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:28:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:28:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:28:10 --> Final output sent to browser
DEBUG - 2022-03-08 23:28:10 --> Total execution time: 0.0538
ERROR - 2022-03-08 23:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:28:21 --> Config Class Initialized
INFO - 2022-03-08 23:28:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:28:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:28:21 --> Utf8 Class Initialized
INFO - 2022-03-08 23:28:21 --> URI Class Initialized
INFO - 2022-03-08 23:28:21 --> Router Class Initialized
INFO - 2022-03-08 23:28:21 --> Output Class Initialized
INFO - 2022-03-08 23:28:21 --> Security Class Initialized
DEBUG - 2022-03-08 23:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:28:21 --> Input Class Initialized
INFO - 2022-03-08 23:28:21 --> Language Class Initialized
INFO - 2022-03-08 23:28:21 --> Loader Class Initialized
INFO - 2022-03-08 23:28:21 --> Helper loaded: url_helper
INFO - 2022-03-08 23:28:21 --> Helper loaded: form_helper
INFO - 2022-03-08 23:28:21 --> Helper loaded: common_helper
INFO - 2022-03-08 23:28:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:28:21 --> Controller Class Initialized
INFO - 2022-03-08 23:28:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:28:21 --> Encrypt Class Initialized
INFO - 2022-03-08 23:28:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:28:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:28:21 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:28:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:28:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:28:21 --> Config Class Initialized
INFO - 2022-03-08 23:28:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:28:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:28:21 --> Utf8 Class Initialized
INFO - 2022-03-08 23:28:21 --> URI Class Initialized
INFO - 2022-03-08 23:28:21 --> Router Class Initialized
INFO - 2022-03-08 23:28:21 --> Output Class Initialized
INFO - 2022-03-08 23:28:21 --> Security Class Initialized
DEBUG - 2022-03-08 23:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:28:21 --> Input Class Initialized
INFO - 2022-03-08 23:28:21 --> Language Class Initialized
INFO - 2022-03-08 23:28:21 --> Loader Class Initialized
INFO - 2022-03-08 23:28:21 --> Helper loaded: url_helper
INFO - 2022-03-08 23:28:21 --> Helper loaded: form_helper
INFO - 2022-03-08 23:28:21 --> Helper loaded: common_helper
INFO - 2022-03-08 23:28:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:28:21 --> Controller Class Initialized
INFO - 2022-03-08 23:28:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:28:21 --> Encrypt Class Initialized
INFO - 2022-03-08 23:28:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:28:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:28:21 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:28:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:28:21 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:28:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:28:21 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:28:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:28:21 --> Final output sent to browser
DEBUG - 2022-03-08 23:28:21 --> Total execution time: 0.0441
ERROR - 2022-03-08 23:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:28:22 --> Config Class Initialized
INFO - 2022-03-08 23:28:22 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:28:22 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:28:22 --> Utf8 Class Initialized
INFO - 2022-03-08 23:28:22 --> URI Class Initialized
INFO - 2022-03-08 23:28:22 --> Router Class Initialized
INFO - 2022-03-08 23:28:22 --> Output Class Initialized
INFO - 2022-03-08 23:28:22 --> Security Class Initialized
DEBUG - 2022-03-08 23:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:28:22 --> Input Class Initialized
INFO - 2022-03-08 23:28:22 --> Language Class Initialized
INFO - 2022-03-08 23:28:22 --> Loader Class Initialized
INFO - 2022-03-08 23:28:22 --> Helper loaded: url_helper
INFO - 2022-03-08 23:28:22 --> Helper loaded: form_helper
INFO - 2022-03-08 23:28:22 --> Helper loaded: common_helper
INFO - 2022-03-08 23:28:22 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:28:22 --> Controller Class Initialized
INFO - 2022-03-08 23:28:22 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:28:22 --> Encrypt Class Initialized
INFO - 2022-03-08 23:28:22 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:28:22 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:28:22 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:28:22 --> Model "Users_model" initialized
INFO - 2022-03-08 23:28:22 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:28:22 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:28:22 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:28:22 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:28:22 --> Final output sent to browser
DEBUG - 2022-03-08 23:28:22 --> Total execution time: 0.0599
ERROR - 2022-03-08 23:28:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:28:28 --> Config Class Initialized
INFO - 2022-03-08 23:28:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:28:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:28:28 --> Utf8 Class Initialized
INFO - 2022-03-08 23:28:28 --> URI Class Initialized
INFO - 2022-03-08 23:28:28 --> Router Class Initialized
INFO - 2022-03-08 23:28:28 --> Output Class Initialized
INFO - 2022-03-08 23:28:28 --> Security Class Initialized
DEBUG - 2022-03-08 23:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:28:28 --> Input Class Initialized
INFO - 2022-03-08 23:28:28 --> Language Class Initialized
INFO - 2022-03-08 23:28:28 --> Loader Class Initialized
INFO - 2022-03-08 23:28:28 --> Helper loaded: url_helper
INFO - 2022-03-08 23:28:28 --> Helper loaded: form_helper
INFO - 2022-03-08 23:28:28 --> Helper loaded: common_helper
INFO - 2022-03-08 23:28:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:28:28 --> Controller Class Initialized
INFO - 2022-03-08 23:28:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:28:28 --> Encrypt Class Initialized
INFO - 2022-03-08 23:28:28 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:28:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:28:28 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:28:28 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:28:28 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:28:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:28:28 --> Config Class Initialized
INFO - 2022-03-08 23:28:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:28:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:28:28 --> Utf8 Class Initialized
INFO - 2022-03-08 23:28:28 --> URI Class Initialized
INFO - 2022-03-08 23:28:28 --> Router Class Initialized
INFO - 2022-03-08 23:28:28 --> Output Class Initialized
INFO - 2022-03-08 23:28:28 --> Security Class Initialized
DEBUG - 2022-03-08 23:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:28:28 --> Input Class Initialized
INFO - 2022-03-08 23:28:28 --> Language Class Initialized
INFO - 2022-03-08 23:28:28 --> Loader Class Initialized
INFO - 2022-03-08 23:28:28 --> Helper loaded: url_helper
INFO - 2022-03-08 23:28:28 --> Helper loaded: form_helper
INFO - 2022-03-08 23:28:28 --> Helper loaded: common_helper
INFO - 2022-03-08 23:28:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:28:28 --> Controller Class Initialized
INFO - 2022-03-08 23:28:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:28:28 --> Encrypt Class Initialized
INFO - 2022-03-08 23:28:29 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:28:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:28:29 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:28:29 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:28:29 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:28:29 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:28:29 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:28:29 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:28:29 --> Final output sent to browser
DEBUG - 2022-03-08 23:28:29 --> Total execution time: 0.0615
ERROR - 2022-03-08 23:28:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:28:29 --> Config Class Initialized
INFO - 2022-03-08 23:28:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:28:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:28:29 --> Utf8 Class Initialized
INFO - 2022-03-08 23:28:29 --> URI Class Initialized
INFO - 2022-03-08 23:28:29 --> Router Class Initialized
INFO - 2022-03-08 23:28:29 --> Output Class Initialized
INFO - 2022-03-08 23:28:29 --> Security Class Initialized
DEBUG - 2022-03-08 23:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:28:29 --> Input Class Initialized
INFO - 2022-03-08 23:28:29 --> Language Class Initialized
INFO - 2022-03-08 23:28:29 --> Loader Class Initialized
INFO - 2022-03-08 23:28:29 --> Helper loaded: url_helper
INFO - 2022-03-08 23:28:29 --> Helper loaded: form_helper
INFO - 2022-03-08 23:28:29 --> Helper loaded: common_helper
INFO - 2022-03-08 23:28:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:28:29 --> Controller Class Initialized
INFO - 2022-03-08 23:28:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:28:29 --> Encrypt Class Initialized
INFO - 2022-03-08 23:28:29 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:28:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:28:29 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:28:29 --> Model "Users_model" initialized
INFO - 2022-03-08 23:28:29 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:28:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:28:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:28:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:28:30 --> Final output sent to browser
DEBUG - 2022-03-08 23:28:30 --> Total execution time: 0.0861
ERROR - 2022-03-08 23:30:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:30:01 --> Config Class Initialized
INFO - 2022-03-08 23:30:01 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:30:01 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:30:01 --> Utf8 Class Initialized
INFO - 2022-03-08 23:30:01 --> URI Class Initialized
INFO - 2022-03-08 23:30:01 --> Router Class Initialized
INFO - 2022-03-08 23:30:01 --> Output Class Initialized
INFO - 2022-03-08 23:30:01 --> Security Class Initialized
DEBUG - 2022-03-08 23:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:30:01 --> Input Class Initialized
INFO - 2022-03-08 23:30:01 --> Language Class Initialized
INFO - 2022-03-08 23:30:01 --> Loader Class Initialized
INFO - 2022-03-08 23:30:01 --> Helper loaded: url_helper
INFO - 2022-03-08 23:30:01 --> Helper loaded: form_helper
INFO - 2022-03-08 23:30:01 --> Helper loaded: common_helper
INFO - 2022-03-08 23:30:01 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:30:01 --> Controller Class Initialized
INFO - 2022-03-08 23:30:01 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:30:01 --> Encrypt Class Initialized
INFO - 2022-03-08 23:30:01 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:30:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:30:01 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:30:01 --> Model "Users_model" initialized
INFO - 2022-03-08 23:30:01 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:30:01 --> Upload Class Initialized
INFO - 2022-03-08 23:30:01 --> Final output sent to browser
DEBUG - 2022-03-08 23:30:01 --> Total execution time: 0.0708
ERROR - 2022-03-08 23:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:31:14 --> Config Class Initialized
INFO - 2022-03-08 23:31:14 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:31:14 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:31:14 --> Utf8 Class Initialized
INFO - 2022-03-08 23:31:14 --> URI Class Initialized
INFO - 2022-03-08 23:31:14 --> Router Class Initialized
INFO - 2022-03-08 23:31:14 --> Output Class Initialized
INFO - 2022-03-08 23:31:14 --> Security Class Initialized
DEBUG - 2022-03-08 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:31:14 --> Input Class Initialized
INFO - 2022-03-08 23:31:14 --> Language Class Initialized
INFO - 2022-03-08 23:31:14 --> Loader Class Initialized
INFO - 2022-03-08 23:31:14 --> Helper loaded: url_helper
INFO - 2022-03-08 23:31:14 --> Helper loaded: form_helper
INFO - 2022-03-08 23:31:14 --> Helper loaded: common_helper
INFO - 2022-03-08 23:31:14 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:31:14 --> Controller Class Initialized
INFO - 2022-03-08 23:31:14 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:31:14 --> Encrypt Class Initialized
INFO - 2022-03-08 23:31:14 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:31:14 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:31:14 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:31:14 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:31:14 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:31:14 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 23:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:31:16 --> Config Class Initialized
INFO - 2022-03-08 23:31:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:31:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:31:16 --> Utf8 Class Initialized
INFO - 2022-03-08 23:31:16 --> URI Class Initialized
INFO - 2022-03-08 23:31:16 --> Router Class Initialized
INFO - 2022-03-08 23:31:16 --> Output Class Initialized
INFO - 2022-03-08 23:31:16 --> Security Class Initialized
DEBUG - 2022-03-08 23:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:31:16 --> Input Class Initialized
INFO - 2022-03-08 23:31:16 --> Language Class Initialized
INFO - 2022-03-08 23:31:16 --> Loader Class Initialized
INFO - 2022-03-08 23:31:16 --> Helper loaded: url_helper
INFO - 2022-03-08 23:31:16 --> Helper loaded: form_helper
INFO - 2022-03-08 23:31:16 --> Helper loaded: common_helper
INFO - 2022-03-08 23:31:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:31:16 --> Controller Class Initialized
INFO - 2022-03-08 23:31:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:31:16 --> Encrypt Class Initialized
INFO - 2022-03-08 23:31:16 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:31:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:31:16 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:31:16 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:31:16 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:31:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:31:16 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:31:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:31:16 --> Final output sent to browser
DEBUG - 2022-03-08 23:31:16 --> Total execution time: 0.1385
ERROR - 2022-03-08 23:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:31:17 --> Config Class Initialized
INFO - 2022-03-08 23:31:17 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:31:17 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:31:17 --> Utf8 Class Initialized
INFO - 2022-03-08 23:31:17 --> URI Class Initialized
INFO - 2022-03-08 23:31:17 --> Router Class Initialized
INFO - 2022-03-08 23:31:17 --> Output Class Initialized
INFO - 2022-03-08 23:31:17 --> Security Class Initialized
DEBUG - 2022-03-08 23:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:31:17 --> Input Class Initialized
INFO - 2022-03-08 23:31:17 --> Language Class Initialized
ERROR - 2022-03-08 23:31:17 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 23:31:25 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:31:25 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 23:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:31:29 --> Config Class Initialized
INFO - 2022-03-08 23:31:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:31:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:31:29 --> Utf8 Class Initialized
INFO - 2022-03-08 23:31:29 --> URI Class Initialized
INFO - 2022-03-08 23:31:29 --> Router Class Initialized
INFO - 2022-03-08 23:31:29 --> Output Class Initialized
INFO - 2022-03-08 23:31:29 --> Security Class Initialized
DEBUG - 2022-03-08 23:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:31:29 --> Input Class Initialized
INFO - 2022-03-08 23:31:29 --> Language Class Initialized
INFO - 2022-03-08 23:31:29 --> Loader Class Initialized
INFO - 2022-03-08 23:31:29 --> Helper loaded: url_helper
INFO - 2022-03-08 23:31:29 --> Helper loaded: form_helper
INFO - 2022-03-08 23:31:29 --> Helper loaded: common_helper
INFO - 2022-03-08 23:31:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:31:29 --> Controller Class Initialized
INFO - 2022-03-08 23:31:29 --> Form Validation Class Initialized
INFO - 2022-03-08 23:31:29 --> Model "Case_model" initialized
INFO - 2022-03-08 23:31:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:31:32 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:31:32 --> Model "Case_model" initialized
INFO - 2022-03-08 23:31:35 --> File loaded: /home3/karoteam/public_html/application/views/cases/open_case.php
INFO - 2022-03-08 23:31:35 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:31:36 --> Final output sent to browser
DEBUG - 2022-03-08 23:31:36 --> Total execution time: 6.6910
ERROR - 2022-03-08 23:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:31:36 --> Config Class Initialized
INFO - 2022-03-08 23:31:36 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:31:36 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:31:36 --> Utf8 Class Initialized
INFO - 2022-03-08 23:31:36 --> URI Class Initialized
INFO - 2022-03-08 23:31:36 --> Router Class Initialized
INFO - 2022-03-08 23:31:36 --> Output Class Initialized
INFO - 2022-03-08 23:31:36 --> Security Class Initialized
DEBUG - 2022-03-08 23:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:31:36 --> Input Class Initialized
INFO - 2022-03-08 23:31:36 --> Language Class Initialized
ERROR - 2022-03-08 23:31:36 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:32:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:32:11 --> Config Class Initialized
INFO - 2022-03-08 23:32:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:32:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:32:11 --> Utf8 Class Initialized
INFO - 2022-03-08 23:32:11 --> URI Class Initialized
INFO - 2022-03-08 23:32:11 --> Router Class Initialized
INFO - 2022-03-08 23:32:11 --> Output Class Initialized
INFO - 2022-03-08 23:32:11 --> Security Class Initialized
DEBUG - 2022-03-08 23:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:32:11 --> Input Class Initialized
INFO - 2022-03-08 23:32:11 --> Language Class Initialized
INFO - 2022-03-08 23:32:11 --> Loader Class Initialized
INFO - 2022-03-08 23:32:11 --> Helper loaded: url_helper
INFO - 2022-03-08 23:32:11 --> Helper loaded: form_helper
INFO - 2022-03-08 23:32:11 --> Helper loaded: common_helper
INFO - 2022-03-08 23:32:11 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:32:11 --> Controller Class Initialized
INFO - 2022-03-08 23:32:11 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:32:11 --> Encrypt Class Initialized
INFO - 2022-03-08 23:32:11 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:32:11 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:32:11 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:32:11 --> Model "Users_model" initialized
INFO - 2022-03-08 23:32:11 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:32:11 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:32:11 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:32:11 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:32:11 --> Final output sent to browser
DEBUG - 2022-03-08 23:32:11 --> Total execution time: 0.0838
ERROR - 2022-03-08 23:32:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:32:11 --> Config Class Initialized
INFO - 2022-03-08 23:32:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:32:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:32:11 --> Utf8 Class Initialized
INFO - 2022-03-08 23:32:11 --> URI Class Initialized
INFO - 2022-03-08 23:32:11 --> Router Class Initialized
INFO - 2022-03-08 23:32:11 --> Output Class Initialized
INFO - 2022-03-08 23:32:11 --> Security Class Initialized
DEBUG - 2022-03-08 23:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:32:11 --> Input Class Initialized
INFO - 2022-03-08 23:32:11 --> Language Class Initialized
ERROR - 2022-03-08 23:32:11 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:32:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:32:37 --> Config Class Initialized
INFO - 2022-03-08 23:32:37 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:32:37 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:32:37 --> Utf8 Class Initialized
INFO - 2022-03-08 23:32:37 --> URI Class Initialized
INFO - 2022-03-08 23:32:37 --> Router Class Initialized
INFO - 2022-03-08 23:32:37 --> Output Class Initialized
INFO - 2022-03-08 23:32:37 --> Security Class Initialized
DEBUG - 2022-03-08 23:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:32:37 --> Input Class Initialized
INFO - 2022-03-08 23:32:37 --> Language Class Initialized
INFO - 2022-03-08 23:32:37 --> Loader Class Initialized
INFO - 2022-03-08 23:32:37 --> Helper loaded: url_helper
INFO - 2022-03-08 23:32:37 --> Helper loaded: form_helper
INFO - 2022-03-08 23:32:37 --> Helper loaded: common_helper
INFO - 2022-03-08 23:32:37 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:32:37 --> Controller Class Initialized
INFO - 2022-03-08 23:32:37 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:32:37 --> Encrypt Class Initialized
INFO - 2022-03-08 23:32:37 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:32:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:32:37 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:32:37 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:32:37 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:32:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:32:45 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:32:45 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 23:32:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:32:46 --> Config Class Initialized
INFO - 2022-03-08 23:32:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:32:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:32:46 --> Utf8 Class Initialized
INFO - 2022-03-08 23:32:46 --> URI Class Initialized
INFO - 2022-03-08 23:32:46 --> Router Class Initialized
INFO - 2022-03-08 23:32:46 --> Output Class Initialized
INFO - 2022-03-08 23:32:46 --> Security Class Initialized
DEBUG - 2022-03-08 23:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:32:46 --> Input Class Initialized
INFO - 2022-03-08 23:32:46 --> Language Class Initialized
ERROR - 2022-03-08 23:32:46 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 23:32:47 --> Final output sent to browser
DEBUG - 2022-03-08 23:32:47 --> Total execution time: 7.5313
ERROR - 2022-03-08 23:33:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:33:18 --> Config Class Initialized
INFO - 2022-03-08 23:33:18 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:33:18 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:33:18 --> Utf8 Class Initialized
INFO - 2022-03-08 23:33:18 --> URI Class Initialized
INFO - 2022-03-08 23:33:18 --> Router Class Initialized
INFO - 2022-03-08 23:33:18 --> Output Class Initialized
INFO - 2022-03-08 23:33:18 --> Security Class Initialized
DEBUG - 2022-03-08 23:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:33:18 --> Input Class Initialized
INFO - 2022-03-08 23:33:18 --> Language Class Initialized
INFO - 2022-03-08 23:33:18 --> Loader Class Initialized
INFO - 2022-03-08 23:33:18 --> Helper loaded: url_helper
INFO - 2022-03-08 23:33:18 --> Helper loaded: form_helper
INFO - 2022-03-08 23:33:18 --> Helper loaded: common_helper
INFO - 2022-03-08 23:33:18 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:33:18 --> Controller Class Initialized
INFO - 2022-03-08 23:33:18 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:33:18 --> Encrypt Class Initialized
INFO - 2022-03-08 23:33:18 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:33:18 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:33:18 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:33:18 --> Model "Users_model" initialized
INFO - 2022-03-08 23:33:18 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:33:18 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:33:18 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:33:18 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:33:18 --> Final output sent to browser
DEBUG - 2022-03-08 23:33:18 --> Total execution time: 0.0820
ERROR - 2022-03-08 23:33:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:33:19 --> Config Class Initialized
INFO - 2022-03-08 23:33:19 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:33:19 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:33:19 --> Utf8 Class Initialized
INFO - 2022-03-08 23:33:19 --> URI Class Initialized
INFO - 2022-03-08 23:33:19 --> Router Class Initialized
INFO - 2022-03-08 23:33:19 --> Output Class Initialized
INFO - 2022-03-08 23:33:19 --> Security Class Initialized
DEBUG - 2022-03-08 23:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:33:19 --> Input Class Initialized
INFO - 2022-03-08 23:33:19 --> Language Class Initialized
ERROR - 2022-03-08 23:33:19 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:33:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:33:43 --> Config Class Initialized
INFO - 2022-03-08 23:33:43 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:33:43 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:33:43 --> Utf8 Class Initialized
INFO - 2022-03-08 23:33:43 --> URI Class Initialized
INFO - 2022-03-08 23:33:43 --> Router Class Initialized
INFO - 2022-03-08 23:33:43 --> Output Class Initialized
INFO - 2022-03-08 23:33:43 --> Security Class Initialized
DEBUG - 2022-03-08 23:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:33:43 --> Input Class Initialized
INFO - 2022-03-08 23:33:43 --> Language Class Initialized
INFO - 2022-03-08 23:33:43 --> Loader Class Initialized
INFO - 2022-03-08 23:33:43 --> Helper loaded: url_helper
INFO - 2022-03-08 23:33:43 --> Helper loaded: form_helper
INFO - 2022-03-08 23:33:43 --> Helper loaded: common_helper
INFO - 2022-03-08 23:33:43 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:33:43 --> Controller Class Initialized
INFO - 2022-03-08 23:33:43 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:33:43 --> Encrypt Class Initialized
INFO - 2022-03-08 23:33:43 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:33:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:33:43 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:33:43 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:33:43 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:33:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:33:43 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:33:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:33:43 --> Final output sent to browser
DEBUG - 2022-03-08 23:33:43 --> Total execution time: 0.0578
ERROR - 2022-03-08 23:33:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:33:44 --> Config Class Initialized
INFO - 2022-03-08 23:33:44 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:33:44 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:33:44 --> Utf8 Class Initialized
INFO - 2022-03-08 23:33:44 --> URI Class Initialized
INFO - 2022-03-08 23:33:44 --> Router Class Initialized
INFO - 2022-03-08 23:33:44 --> Output Class Initialized
INFO - 2022-03-08 23:33:44 --> Security Class Initialized
DEBUG - 2022-03-08 23:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:33:44 --> Input Class Initialized
INFO - 2022-03-08 23:33:44 --> Language Class Initialized
ERROR - 2022-03-08 23:33:44 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:35:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:35:09 --> Config Class Initialized
INFO - 2022-03-08 23:35:09 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:35:09 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:35:09 --> Utf8 Class Initialized
INFO - 2022-03-08 23:35:09 --> URI Class Initialized
INFO - 2022-03-08 23:35:09 --> Router Class Initialized
INFO - 2022-03-08 23:35:09 --> Output Class Initialized
INFO - 2022-03-08 23:35:09 --> Security Class Initialized
DEBUG - 2022-03-08 23:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:35:09 --> Input Class Initialized
INFO - 2022-03-08 23:35:09 --> Language Class Initialized
INFO - 2022-03-08 23:35:09 --> Loader Class Initialized
INFO - 2022-03-08 23:35:09 --> Helper loaded: url_helper
INFO - 2022-03-08 23:35:09 --> Helper loaded: form_helper
INFO - 2022-03-08 23:35:09 --> Helper loaded: common_helper
INFO - 2022-03-08 23:35:09 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:35:09 --> Controller Class Initialized
INFO - 2022-03-08 23:35:09 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:35:09 --> Encrypt Class Initialized
INFO - 2022-03-08 23:35:09 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:35:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:35:09 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:35:09 --> Model "Users_model" initialized
INFO - 2022-03-08 23:35:09 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:35:09 --> Final output sent to browser
DEBUG - 2022-03-08 23:35:09 --> Total execution time: 0.0269
ERROR - 2022-03-08 23:35:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:35:28 --> Config Class Initialized
INFO - 2022-03-08 23:35:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:35:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:35:28 --> Utf8 Class Initialized
INFO - 2022-03-08 23:35:28 --> URI Class Initialized
INFO - 2022-03-08 23:35:28 --> Router Class Initialized
INFO - 2022-03-08 23:35:28 --> Output Class Initialized
INFO - 2022-03-08 23:35:28 --> Security Class Initialized
DEBUG - 2022-03-08 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:35:28 --> Input Class Initialized
INFO - 2022-03-08 23:35:28 --> Language Class Initialized
INFO - 2022-03-08 23:35:28 --> Loader Class Initialized
INFO - 2022-03-08 23:35:28 --> Helper loaded: url_helper
INFO - 2022-03-08 23:35:28 --> Helper loaded: form_helper
INFO - 2022-03-08 23:35:28 --> Helper loaded: common_helper
INFO - 2022-03-08 23:35:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:35:28 --> Controller Class Initialized
INFO - 2022-03-08 23:35:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:35:28 --> Encrypt Class Initialized
INFO - 2022-03-08 23:35:28 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:35:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:35:28 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:35:28 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:35:28 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:35:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:35:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/patient_by_category.php
INFO - 2022-03-08 23:35:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:35:28 --> Final output sent to browser
DEBUG - 2022-03-08 23:35:28 --> Total execution time: 0.0273
ERROR - 2022-03-08 23:35:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:35:33 --> Config Class Initialized
INFO - 2022-03-08 23:35:33 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:35:33 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:35:33 --> Utf8 Class Initialized
INFO - 2022-03-08 23:35:33 --> URI Class Initialized
INFO - 2022-03-08 23:35:33 --> Router Class Initialized
INFO - 2022-03-08 23:35:33 --> Output Class Initialized
INFO - 2022-03-08 23:35:33 --> Security Class Initialized
DEBUG - 2022-03-08 23:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:35:33 --> Input Class Initialized
INFO - 2022-03-08 23:35:33 --> Language Class Initialized
INFO - 2022-03-08 23:35:33 --> Loader Class Initialized
INFO - 2022-03-08 23:35:33 --> Helper loaded: url_helper
INFO - 2022-03-08 23:35:33 --> Helper loaded: form_helper
INFO - 2022-03-08 23:35:33 --> Helper loaded: common_helper
INFO - 2022-03-08 23:35:33 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:35:33 --> Controller Class Initialized
INFO - 2022-03-08 23:35:33 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:35:33 --> Encrypt Class Initialized
INFO - 2022-03-08 23:35:33 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:35:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:35:33 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:35:33 --> Model "Users_model" initialized
INFO - 2022-03-08 23:35:33 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:35:33 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-08 23:35:34 --> Final output sent to browser
DEBUG - 2022-03-08 23:35:34 --> Total execution time: 1.1319
ERROR - 2022-03-08 23:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:35:47 --> Config Class Initialized
INFO - 2022-03-08 23:35:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:35:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:35:47 --> Utf8 Class Initialized
INFO - 2022-03-08 23:35:47 --> URI Class Initialized
INFO - 2022-03-08 23:35:47 --> Router Class Initialized
INFO - 2022-03-08 23:35:47 --> Output Class Initialized
INFO - 2022-03-08 23:35:47 --> Security Class Initialized
DEBUG - 2022-03-08 23:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:35:47 --> Input Class Initialized
INFO - 2022-03-08 23:35:47 --> Language Class Initialized
INFO - 2022-03-08 23:35:47 --> Loader Class Initialized
INFO - 2022-03-08 23:35:47 --> Helper loaded: url_helper
INFO - 2022-03-08 23:35:47 --> Helper loaded: form_helper
INFO - 2022-03-08 23:35:47 --> Helper loaded: common_helper
INFO - 2022-03-08 23:35:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:35:47 --> Controller Class Initialized
INFO - 2022-03-08 23:35:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:35:47 --> Encrypt Class Initialized
INFO - 2022-03-08 23:35:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:35:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:35:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:35:47 --> Model "Users_model" initialized
INFO - 2022-03-08 23:35:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:35:47 --> Upload Class Initialized
INFO - 2022-03-08 23:35:47 --> Final output sent to browser
DEBUG - 2022-03-08 23:35:47 --> Total execution time: 0.1490
ERROR - 2022-03-08 23:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:38:15 --> Config Class Initialized
INFO - 2022-03-08 23:38:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:38:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:38:15 --> Utf8 Class Initialized
INFO - 2022-03-08 23:38:15 --> URI Class Initialized
INFO - 2022-03-08 23:38:15 --> Router Class Initialized
INFO - 2022-03-08 23:38:15 --> Output Class Initialized
INFO - 2022-03-08 23:38:15 --> Security Class Initialized
DEBUG - 2022-03-08 23:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:38:15 --> Input Class Initialized
INFO - 2022-03-08 23:38:15 --> Language Class Initialized
INFO - 2022-03-08 23:38:15 --> Loader Class Initialized
INFO - 2022-03-08 23:38:15 --> Helper loaded: url_helper
INFO - 2022-03-08 23:38:15 --> Helper loaded: form_helper
INFO - 2022-03-08 23:38:15 --> Helper loaded: common_helper
INFO - 2022-03-08 23:38:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:38:15 --> Controller Class Initialized
INFO - 2022-03-08 23:38:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:38:15 --> Encrypt Class Initialized
INFO - 2022-03-08 23:38:15 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:38:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:38:15 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:38:15 --> Model "Users_model" initialized
INFO - 2022-03-08 23:38:15 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:38:15 --> Config Class Initialized
INFO - 2022-03-08 23:38:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:38:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:38:15 --> Utf8 Class Initialized
INFO - 2022-03-08 23:38:15 --> URI Class Initialized
INFO - 2022-03-08 23:38:15 --> Router Class Initialized
INFO - 2022-03-08 23:38:15 --> Output Class Initialized
INFO - 2022-03-08 23:38:15 --> Security Class Initialized
DEBUG - 2022-03-08 23:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:38:15 --> Input Class Initialized
INFO - 2022-03-08 23:38:15 --> Language Class Initialized
INFO - 2022-03-08 23:38:15 --> Loader Class Initialized
INFO - 2022-03-08 23:38:15 --> Helper loaded: url_helper
INFO - 2022-03-08 23:38:15 --> Helper loaded: form_helper
INFO - 2022-03-08 23:38:15 --> Helper loaded: common_helper
INFO - 2022-03-08 23:38:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:38:15 --> Controller Class Initialized
INFO - 2022-03-08 23:38:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:38:15 --> Encrypt Class Initialized
INFO - 2022-03-08 23:38:15 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:38:15 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:38:15 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:38:15 --> Model "Users_model" initialized
INFO - 2022-03-08 23:38:15 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:38:15 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:38:15 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:38:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:38:15 --> Final output sent to browser
DEBUG - 2022-03-08 23:38:15 --> Total execution time: 0.0535
ERROR - 2022-03-08 23:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:38:21 --> Config Class Initialized
INFO - 2022-03-08 23:38:21 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:38:21 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:38:21 --> Utf8 Class Initialized
INFO - 2022-03-08 23:38:21 --> URI Class Initialized
INFO - 2022-03-08 23:38:21 --> Router Class Initialized
INFO - 2022-03-08 23:38:21 --> Output Class Initialized
INFO - 2022-03-08 23:38:21 --> Security Class Initialized
DEBUG - 2022-03-08 23:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:38:21 --> Input Class Initialized
INFO - 2022-03-08 23:38:21 --> Language Class Initialized
INFO - 2022-03-08 23:38:21 --> Loader Class Initialized
INFO - 2022-03-08 23:38:21 --> Helper loaded: url_helper
INFO - 2022-03-08 23:38:21 --> Helper loaded: form_helper
INFO - 2022-03-08 23:38:21 --> Helper loaded: common_helper
INFO - 2022-03-08 23:38:21 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:38:21 --> Controller Class Initialized
INFO - 2022-03-08 23:38:21 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:38:21 --> Encrypt Class Initialized
INFO - 2022-03-08 23:38:21 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:38:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:38:21 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:38:21 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:38:21 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:38:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:38:27 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:38:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:38:29 --> Final output sent to browser
DEBUG - 2022-03-08 23:38:29 --> Total execution time: 6.3415
ERROR - 2022-03-08 23:39:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:39:28 --> Config Class Initialized
INFO - 2022-03-08 23:39:28 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:39:28 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:39:28 --> Utf8 Class Initialized
INFO - 2022-03-08 23:39:28 --> URI Class Initialized
INFO - 2022-03-08 23:39:28 --> Router Class Initialized
INFO - 2022-03-08 23:39:28 --> Output Class Initialized
INFO - 2022-03-08 23:39:28 --> Security Class Initialized
DEBUG - 2022-03-08 23:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:39:28 --> Input Class Initialized
INFO - 2022-03-08 23:39:28 --> Language Class Initialized
INFO - 2022-03-08 23:39:28 --> Loader Class Initialized
INFO - 2022-03-08 23:39:28 --> Helper loaded: url_helper
INFO - 2022-03-08 23:39:28 --> Helper loaded: form_helper
INFO - 2022-03-08 23:39:28 --> Helper loaded: common_helper
INFO - 2022-03-08 23:39:28 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:39:28 --> Controller Class Initialized
INFO - 2022-03-08 23:39:28 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:39:28 --> Encrypt Class Initialized
INFO - 2022-03-08 23:39:28 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:39:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:39:28 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:39:28 --> Model "Users_model" initialized
INFO - 2022-03-08 23:39:28 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:39:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:39:28 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:39:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:39:28 --> Final output sent to browser
DEBUG - 2022-03-08 23:39:28 --> Total execution time: 0.0628
ERROR - 2022-03-08 23:40:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:40:05 --> Config Class Initialized
INFO - 2022-03-08 23:40:05 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:40:05 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:40:05 --> Utf8 Class Initialized
INFO - 2022-03-08 23:40:05 --> URI Class Initialized
INFO - 2022-03-08 23:40:05 --> Router Class Initialized
INFO - 2022-03-08 23:40:05 --> Output Class Initialized
INFO - 2022-03-08 23:40:05 --> Security Class Initialized
DEBUG - 2022-03-08 23:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:40:05 --> Input Class Initialized
INFO - 2022-03-08 23:40:05 --> Language Class Initialized
INFO - 2022-03-08 23:40:05 --> Loader Class Initialized
INFO - 2022-03-08 23:40:05 --> Helper loaded: url_helper
INFO - 2022-03-08 23:40:05 --> Helper loaded: form_helper
INFO - 2022-03-08 23:40:05 --> Helper loaded: common_helper
INFO - 2022-03-08 23:40:05 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:40:05 --> Controller Class Initialized
INFO - 2022-03-08 23:40:05 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:40:05 --> Encrypt Class Initialized
INFO - 2022-03-08 23:40:05 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:40:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:40:05 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:40:05 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:40:05 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:40:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:40:12 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:40:12 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:40:14 --> Final output sent to browser
DEBUG - 2022-03-08 23:40:14 --> Total execution time: 7.1607
ERROR - 2022-03-08 23:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:40:41 --> Config Class Initialized
INFO - 2022-03-08 23:40:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:40:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:40:41 --> Utf8 Class Initialized
INFO - 2022-03-08 23:40:41 --> URI Class Initialized
INFO - 2022-03-08 23:40:41 --> Router Class Initialized
INFO - 2022-03-08 23:40:41 --> Output Class Initialized
INFO - 2022-03-08 23:40:41 --> Security Class Initialized
DEBUG - 2022-03-08 23:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:40:41 --> Input Class Initialized
INFO - 2022-03-08 23:40:41 --> Language Class Initialized
INFO - 2022-03-08 23:40:41 --> Loader Class Initialized
INFO - 2022-03-08 23:40:41 --> Helper loaded: url_helper
INFO - 2022-03-08 23:40:41 --> Helper loaded: form_helper
INFO - 2022-03-08 23:40:41 --> Helper loaded: common_helper
INFO - 2022-03-08 23:40:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:40:41 --> Controller Class Initialized
INFO - 2022-03-08 23:40:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:40:41 --> Encrypt Class Initialized
INFO - 2022-03-08 23:40:41 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:40:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:40:41 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:40:41 --> Model "Users_model" initialized
INFO - 2022-03-08 23:40:41 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:40:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:40:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:40:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:40:41 --> Final output sent to browser
DEBUG - 2022-03-08 23:40:41 --> Total execution time: 0.0889
ERROR - 2022-03-08 23:40:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:40:59 --> Config Class Initialized
INFO - 2022-03-08 23:40:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:40:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:40:59 --> Utf8 Class Initialized
INFO - 2022-03-08 23:40:59 --> URI Class Initialized
INFO - 2022-03-08 23:40:59 --> Router Class Initialized
INFO - 2022-03-08 23:40:59 --> Output Class Initialized
INFO - 2022-03-08 23:40:59 --> Security Class Initialized
DEBUG - 2022-03-08 23:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:40:59 --> Input Class Initialized
INFO - 2022-03-08 23:40:59 --> Language Class Initialized
INFO - 2022-03-08 23:40:59 --> Loader Class Initialized
INFO - 2022-03-08 23:40:59 --> Helper loaded: url_helper
INFO - 2022-03-08 23:40:59 --> Helper loaded: form_helper
INFO - 2022-03-08 23:40:59 --> Helper loaded: common_helper
INFO - 2022-03-08 23:40:59 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:40:59 --> Controller Class Initialized
INFO - 2022-03-08 23:40:59 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:40:59 --> Encrypt Class Initialized
INFO - 2022-03-08 23:40:59 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:40:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:40:59 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:40:59 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:40:59 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:40:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:41:06 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:41:06 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:41:07 --> Final output sent to browser
DEBUG - 2022-03-08 23:41:07 --> Total execution time: 6.8743
ERROR - 2022-03-08 23:41:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:41:47 --> Config Class Initialized
INFO - 2022-03-08 23:41:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:41:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:41:47 --> Utf8 Class Initialized
INFO - 2022-03-08 23:41:47 --> URI Class Initialized
INFO - 2022-03-08 23:41:47 --> Router Class Initialized
INFO - 2022-03-08 23:41:47 --> Output Class Initialized
INFO - 2022-03-08 23:41:47 --> Security Class Initialized
DEBUG - 2022-03-08 23:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:41:47 --> Input Class Initialized
INFO - 2022-03-08 23:41:47 --> Language Class Initialized
INFO - 2022-03-08 23:41:47 --> Loader Class Initialized
INFO - 2022-03-08 23:41:47 --> Helper loaded: url_helper
INFO - 2022-03-08 23:41:47 --> Helper loaded: form_helper
INFO - 2022-03-08 23:41:47 --> Helper loaded: common_helper
INFO - 2022-03-08 23:41:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:41:47 --> Controller Class Initialized
INFO - 2022-03-08 23:41:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:41:47 --> Encrypt Class Initialized
INFO - 2022-03-08 23:41:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:41:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:41:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:41:47 --> Model "Users_model" initialized
INFO - 2022-03-08 23:41:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:41:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:41:47 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:41:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:41:47 --> Final output sent to browser
DEBUG - 2022-03-08 23:41:47 --> Total execution time: 0.0802
ERROR - 2022-03-08 23:42:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:42:07 --> Config Class Initialized
INFO - 2022-03-08 23:42:07 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:42:07 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:42:07 --> Utf8 Class Initialized
INFO - 2022-03-08 23:42:07 --> URI Class Initialized
INFO - 2022-03-08 23:42:07 --> Router Class Initialized
INFO - 2022-03-08 23:42:07 --> Output Class Initialized
INFO - 2022-03-08 23:42:07 --> Security Class Initialized
DEBUG - 2022-03-08 23:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:42:07 --> Input Class Initialized
INFO - 2022-03-08 23:42:07 --> Language Class Initialized
INFO - 2022-03-08 23:42:07 --> Loader Class Initialized
INFO - 2022-03-08 23:42:07 --> Helper loaded: url_helper
INFO - 2022-03-08 23:42:07 --> Helper loaded: form_helper
INFO - 2022-03-08 23:42:07 --> Helper loaded: common_helper
INFO - 2022-03-08 23:42:07 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:42:07 --> Controller Class Initialized
INFO - 2022-03-08 23:42:07 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:42:07 --> Encrypt Class Initialized
INFO - 2022-03-08 23:42:07 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:42:07 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:42:07 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:42:07 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:42:07 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:42:07 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:42:14 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:42:14 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:42:16 --> Final output sent to browser
DEBUG - 2022-03-08 23:42:16 --> Total execution time: 7.3159
ERROR - 2022-03-08 23:42:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:42:41 --> Config Class Initialized
INFO - 2022-03-08 23:42:41 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:42:41 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:42:41 --> Utf8 Class Initialized
INFO - 2022-03-08 23:42:41 --> URI Class Initialized
INFO - 2022-03-08 23:42:41 --> Router Class Initialized
INFO - 2022-03-08 23:42:41 --> Output Class Initialized
INFO - 2022-03-08 23:42:41 --> Security Class Initialized
DEBUG - 2022-03-08 23:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:42:41 --> Input Class Initialized
INFO - 2022-03-08 23:42:41 --> Language Class Initialized
INFO - 2022-03-08 23:42:41 --> Loader Class Initialized
INFO - 2022-03-08 23:42:41 --> Helper loaded: url_helper
INFO - 2022-03-08 23:42:41 --> Helper loaded: form_helper
INFO - 2022-03-08 23:42:41 --> Helper loaded: common_helper
INFO - 2022-03-08 23:42:41 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:42:41 --> Controller Class Initialized
INFO - 2022-03-08 23:42:41 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:42:41 --> Encrypt Class Initialized
INFO - 2022-03-08 23:42:41 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:42:41 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:42:41 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:42:41 --> Model "Users_model" initialized
INFO - 2022-03-08 23:42:41 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:42:41 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:42:41 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:42:41 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:42:41 --> Final output sent to browser
DEBUG - 2022-03-08 23:42:41 --> Total execution time: 0.0565
ERROR - 2022-03-08 23:43:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:43:23 --> Config Class Initialized
INFO - 2022-03-08 23:43:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:43:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:43:23 --> Utf8 Class Initialized
INFO - 2022-03-08 23:43:23 --> URI Class Initialized
INFO - 2022-03-08 23:43:23 --> Router Class Initialized
INFO - 2022-03-08 23:43:23 --> Output Class Initialized
INFO - 2022-03-08 23:43:23 --> Security Class Initialized
DEBUG - 2022-03-08 23:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:43:23 --> Input Class Initialized
INFO - 2022-03-08 23:43:23 --> Language Class Initialized
INFO - 2022-03-08 23:43:23 --> Loader Class Initialized
INFO - 2022-03-08 23:43:23 --> Helper loaded: url_helper
INFO - 2022-03-08 23:43:23 --> Helper loaded: form_helper
INFO - 2022-03-08 23:43:23 --> Helper loaded: common_helper
INFO - 2022-03-08 23:43:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:43:23 --> Controller Class Initialized
INFO - 2022-03-08 23:43:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:43:23 --> Encrypt Class Initialized
INFO - 2022-03-08 23:43:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:43:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:43:23 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:43:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:43:23 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:43:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:43:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:43:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:43:23 --> Final output sent to browser
DEBUG - 2022-03-08 23:43:23 --> Total execution time: 0.0560
ERROR - 2022-03-08 23:43:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:43:23 --> Config Class Initialized
INFO - 2022-03-08 23:43:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:43:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:43:23 --> Utf8 Class Initialized
INFO - 2022-03-08 23:43:23 --> URI Class Initialized
INFO - 2022-03-08 23:43:23 --> Router Class Initialized
INFO - 2022-03-08 23:43:23 --> Output Class Initialized
INFO - 2022-03-08 23:43:23 --> Security Class Initialized
DEBUG - 2022-03-08 23:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:43:23 --> Input Class Initialized
INFO - 2022-03-08 23:43:23 --> Language Class Initialized
ERROR - 2022-03-08 23:43:23 --> 404 Page Not Found: Karoclient/images
ERROR - 2022-03-08 23:43:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:43:36 --> Config Class Initialized
INFO - 2022-03-08 23:43:36 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:43:36 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:43:36 --> Utf8 Class Initialized
INFO - 2022-03-08 23:43:36 --> URI Class Initialized
INFO - 2022-03-08 23:43:36 --> Router Class Initialized
INFO - 2022-03-08 23:43:36 --> Output Class Initialized
INFO - 2022-03-08 23:43:36 --> Security Class Initialized
DEBUG - 2022-03-08 23:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:43:36 --> Input Class Initialized
INFO - 2022-03-08 23:43:36 --> Language Class Initialized
INFO - 2022-03-08 23:43:36 --> Loader Class Initialized
INFO - 2022-03-08 23:43:36 --> Helper loaded: url_helper
INFO - 2022-03-08 23:43:36 --> Helper loaded: form_helper
INFO - 2022-03-08 23:43:36 --> Helper loaded: common_helper
INFO - 2022-03-08 23:43:36 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:43:36 --> Controller Class Initialized
INFO - 2022-03-08 23:43:36 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:43:36 --> Encrypt Class Initialized
INFO - 2022-03-08 23:43:36 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:43:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:43:36 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:43:36 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:43:36 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:43:36 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:43:42 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:43:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:43:45 --> Final output sent to browser
DEBUG - 2022-03-08 23:43:45 --> Total execution time: 6.1450
ERROR - 2022-03-08 23:45:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:45:34 --> Config Class Initialized
INFO - 2022-03-08 23:45:34 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:45:34 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:45:34 --> Utf8 Class Initialized
INFO - 2022-03-08 23:45:34 --> URI Class Initialized
INFO - 2022-03-08 23:45:34 --> Router Class Initialized
INFO - 2022-03-08 23:45:34 --> Output Class Initialized
INFO - 2022-03-08 23:45:34 --> Security Class Initialized
DEBUG - 2022-03-08 23:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:45:34 --> Input Class Initialized
INFO - 2022-03-08 23:45:34 --> Language Class Initialized
INFO - 2022-03-08 23:45:34 --> Loader Class Initialized
INFO - 2022-03-08 23:45:34 --> Helper loaded: url_helper
INFO - 2022-03-08 23:45:34 --> Helper loaded: form_helper
INFO - 2022-03-08 23:45:34 --> Helper loaded: common_helper
INFO - 2022-03-08 23:45:34 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:45:34 --> Controller Class Initialized
INFO - 2022-03-08 23:45:34 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:45:34 --> Encrypt Class Initialized
INFO - 2022-03-08 23:45:34 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:45:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:45:34 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:45:34 --> Model "Users_model" initialized
INFO - 2022-03-08 23:45:34 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:45:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:45:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:45:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:45:34 --> Final output sent to browser
DEBUG - 2022-03-08 23:45:34 --> Total execution time: 0.0600
ERROR - 2022-03-08 23:45:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:45:52 --> Config Class Initialized
INFO - 2022-03-08 23:45:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:45:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:45:52 --> Utf8 Class Initialized
INFO - 2022-03-08 23:45:52 --> URI Class Initialized
INFO - 2022-03-08 23:45:53 --> Router Class Initialized
INFO - 2022-03-08 23:45:53 --> Output Class Initialized
INFO - 2022-03-08 23:45:53 --> Security Class Initialized
DEBUG - 2022-03-08 23:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:45:53 --> Input Class Initialized
INFO - 2022-03-08 23:45:53 --> Language Class Initialized
INFO - 2022-03-08 23:45:53 --> Loader Class Initialized
INFO - 2022-03-08 23:45:53 --> Helper loaded: url_helper
INFO - 2022-03-08 23:45:53 --> Helper loaded: form_helper
INFO - 2022-03-08 23:45:53 --> Helper loaded: common_helper
INFO - 2022-03-08 23:45:53 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:45:53 --> Controller Class Initialized
INFO - 2022-03-08 23:45:53 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:45:53 --> Encrypt Class Initialized
INFO - 2022-03-08 23:45:53 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:45:53 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:45:53 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:45:53 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:45:53 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:45:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:46:00 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:46:00 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:46:02 --> Final output sent to browser
DEBUG - 2022-03-08 23:46:02 --> Total execution time: 7.6505
ERROR - 2022-03-08 23:46:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:46:29 --> Config Class Initialized
INFO - 2022-03-08 23:46:29 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:46:29 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:46:29 --> Utf8 Class Initialized
INFO - 2022-03-08 23:46:29 --> URI Class Initialized
INFO - 2022-03-08 23:46:29 --> Router Class Initialized
INFO - 2022-03-08 23:46:29 --> Output Class Initialized
INFO - 2022-03-08 23:46:29 --> Security Class Initialized
DEBUG - 2022-03-08 23:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:46:29 --> Input Class Initialized
INFO - 2022-03-08 23:46:29 --> Language Class Initialized
INFO - 2022-03-08 23:46:29 --> Loader Class Initialized
INFO - 2022-03-08 23:46:29 --> Helper loaded: url_helper
INFO - 2022-03-08 23:46:29 --> Helper loaded: form_helper
INFO - 2022-03-08 23:46:29 --> Helper loaded: common_helper
INFO - 2022-03-08 23:46:29 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:46:29 --> Controller Class Initialized
INFO - 2022-03-08 23:46:29 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:46:29 --> Encrypt Class Initialized
INFO - 2022-03-08 23:46:29 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:46:29 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:46:29 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:46:29 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:46:30 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:46:30 --> Upload Class Initialized
INFO - 2022-03-08 23:46:30 --> Final output sent to browser
DEBUG - 2022-03-08 23:46:30 --> Total execution time: 0.0416
ERROR - 2022-03-08 23:46:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:46:39 --> Config Class Initialized
INFO - 2022-03-08 23:46:39 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:46:39 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:46:39 --> Utf8 Class Initialized
INFO - 2022-03-08 23:46:39 --> URI Class Initialized
INFO - 2022-03-08 23:46:39 --> Router Class Initialized
INFO - 2022-03-08 23:46:39 --> Output Class Initialized
INFO - 2022-03-08 23:46:39 --> Security Class Initialized
DEBUG - 2022-03-08 23:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:46:39 --> Input Class Initialized
INFO - 2022-03-08 23:46:39 --> Language Class Initialized
INFO - 2022-03-08 23:46:39 --> Loader Class Initialized
INFO - 2022-03-08 23:46:39 --> Helper loaded: url_helper
INFO - 2022-03-08 23:46:39 --> Helper loaded: form_helper
INFO - 2022-03-08 23:46:39 --> Helper loaded: common_helper
INFO - 2022-03-08 23:46:39 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:46:39 --> Controller Class Initialized
INFO - 2022-03-08 23:46:39 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:46:39 --> Encrypt Class Initialized
INFO - 2022-03-08 23:46:39 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:46:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:46:39 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:46:39 --> Model "Users_model" initialized
INFO - 2022-03-08 23:46:39 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:46:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:46:39 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:46:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:46:39 --> Final output sent to browser
DEBUG - 2022-03-08 23:46:39 --> Total execution time: 0.0620
ERROR - 2022-03-08 23:46:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:46:52 --> Config Class Initialized
INFO - 2022-03-08 23:46:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:46:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:46:52 --> Utf8 Class Initialized
INFO - 2022-03-08 23:46:52 --> URI Class Initialized
INFO - 2022-03-08 23:46:52 --> Router Class Initialized
INFO - 2022-03-08 23:46:52 --> Output Class Initialized
INFO - 2022-03-08 23:46:52 --> Security Class Initialized
DEBUG - 2022-03-08 23:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:46:52 --> Input Class Initialized
INFO - 2022-03-08 23:46:52 --> Language Class Initialized
INFO - 2022-03-08 23:46:52 --> Loader Class Initialized
INFO - 2022-03-08 23:46:52 --> Helper loaded: url_helper
INFO - 2022-03-08 23:46:52 --> Helper loaded: form_helper
INFO - 2022-03-08 23:46:52 --> Helper loaded: common_helper
INFO - 2022-03-08 23:46:52 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:46:52 --> Controller Class Initialized
INFO - 2022-03-08 23:46:52 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:46:52 --> Encrypt Class Initialized
INFO - 2022-03-08 23:46:52 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:46:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:46:52 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:46:52 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:46:52 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:46:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 23:46:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:46:55 --> Config Class Initialized
INFO - 2022-03-08 23:46:55 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:46:55 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:46:55 --> Utf8 Class Initialized
INFO - 2022-03-08 23:46:55 --> URI Class Initialized
INFO - 2022-03-08 23:46:55 --> Router Class Initialized
INFO - 2022-03-08 23:46:55 --> Output Class Initialized
INFO - 2022-03-08 23:46:55 --> Security Class Initialized
DEBUG - 2022-03-08 23:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:46:55 --> Input Class Initialized
INFO - 2022-03-08 23:46:55 --> Language Class Initialized
INFO - 2022-03-08 23:46:55 --> Loader Class Initialized
INFO - 2022-03-08 23:46:55 --> Helper loaded: url_helper
INFO - 2022-03-08 23:46:55 --> Helper loaded: form_helper
INFO - 2022-03-08 23:46:55 --> Helper loaded: common_helper
INFO - 2022-03-08 23:46:55 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:46:55 --> Controller Class Initialized
INFO - 2022-03-08 23:46:55 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:46:55 --> Encrypt Class Initialized
INFO - 2022-03-08 23:46:55 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:46:55 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:46:55 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:46:55 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:46:55 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:46:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:46:56 --> Config Class Initialized
INFO - 2022-03-08 23:46:56 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:46:56 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:46:56 --> Utf8 Class Initialized
INFO - 2022-03-08 23:46:56 --> URI Class Initialized
INFO - 2022-03-08 23:46:56 --> Router Class Initialized
INFO - 2022-03-08 23:46:56 --> Output Class Initialized
INFO - 2022-03-08 23:46:56 --> Security Class Initialized
DEBUG - 2022-03-08 23:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:46:56 --> Input Class Initialized
INFO - 2022-03-08 23:46:56 --> Language Class Initialized
INFO - 2022-03-08 23:46:56 --> Loader Class Initialized
INFO - 2022-03-08 23:46:56 --> Helper loaded: url_helper
INFO - 2022-03-08 23:46:56 --> Helper loaded: form_helper
INFO - 2022-03-08 23:46:56 --> Helper loaded: common_helper
INFO - 2022-03-08 23:46:56 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:46:56 --> Controller Class Initialized
INFO - 2022-03-08 23:46:56 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:46:56 --> Encrypt Class Initialized
INFO - 2022-03-08 23:46:56 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:46:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:46:56 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:46:56 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:46:56 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:46:56 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:46:56 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:46:56 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:46:56 --> Final output sent to browser
DEBUG - 2022-03-08 23:46:56 --> Total execution time: 0.0450
ERROR - 2022-03-08 23:46:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:46:57 --> Config Class Initialized
INFO - 2022-03-08 23:46:57 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:46:57 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:46:57 --> Utf8 Class Initialized
INFO - 2022-03-08 23:46:57 --> URI Class Initialized
INFO - 2022-03-08 23:46:57 --> Router Class Initialized
INFO - 2022-03-08 23:46:57 --> Output Class Initialized
INFO - 2022-03-08 23:46:57 --> Security Class Initialized
DEBUG - 2022-03-08 23:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:46:57 --> Input Class Initialized
INFO - 2022-03-08 23:46:57 --> Language Class Initialized
ERROR - 2022-03-08 23:46:57 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:46:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:46:57 --> Config Class Initialized
INFO - 2022-03-08 23:46:57 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:46:57 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:46:57 --> Utf8 Class Initialized
INFO - 2022-03-08 23:46:57 --> URI Class Initialized
INFO - 2022-03-08 23:46:57 --> Router Class Initialized
INFO - 2022-03-08 23:46:57 --> Output Class Initialized
INFO - 2022-03-08 23:46:57 --> Security Class Initialized
DEBUG - 2022-03-08 23:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:46:57 --> Input Class Initialized
INFO - 2022-03-08 23:46:57 --> Language Class Initialized
INFO - 2022-03-08 23:46:57 --> Loader Class Initialized
INFO - 2022-03-08 23:46:57 --> Helper loaded: url_helper
INFO - 2022-03-08 23:46:57 --> Helper loaded: form_helper
INFO - 2022-03-08 23:46:57 --> Helper loaded: common_helper
INFO - 2022-03-08 23:46:57 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:46:57 --> Controller Class Initialized
INFO - 2022-03-08 23:46:57 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:46:57 --> Encrypt Class Initialized
INFO - 2022-03-08 23:46:57 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:46:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:46:57 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:46:57 --> Model "Users_model" initialized
INFO - 2022-03-08 23:46:57 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:46:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:46:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:46:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:46:57 --> Final output sent to browser
DEBUG - 2022-03-08 23:46:57 --> Total execution time: 0.0549
ERROR - 2022-03-08 23:46:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:46:58 --> Config Class Initialized
INFO - 2022-03-08 23:46:58 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:46:58 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:46:58 --> Utf8 Class Initialized
INFO - 2022-03-08 23:46:58 --> URI Class Initialized
INFO - 2022-03-08 23:46:58 --> Router Class Initialized
INFO - 2022-03-08 23:46:58 --> Output Class Initialized
INFO - 2022-03-08 23:46:58 --> Security Class Initialized
DEBUG - 2022-03-08 23:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:46:58 --> Input Class Initialized
INFO - 2022-03-08 23:46:58 --> Language Class Initialized
ERROR - 2022-03-08 23:46:58 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 23:46:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:46:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:47:00 --> Final output sent to browser
DEBUG - 2022-03-08 23:47:00 --> Total execution time: 6.2925
ERROR - 2022-03-08 23:47:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:47:04 --> Config Class Initialized
INFO - 2022-03-08 23:47:04 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:47:04 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:47:04 --> Utf8 Class Initialized
INFO - 2022-03-08 23:47:04 --> URI Class Initialized
INFO - 2022-03-08 23:47:04 --> Router Class Initialized
INFO - 2022-03-08 23:47:04 --> Output Class Initialized
INFO - 2022-03-08 23:47:04 --> Security Class Initialized
DEBUG - 2022-03-08 23:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:47:04 --> Input Class Initialized
INFO - 2022-03-08 23:47:04 --> Language Class Initialized
INFO - 2022-03-08 23:47:04 --> Loader Class Initialized
INFO - 2022-03-08 23:47:04 --> Helper loaded: url_helper
INFO - 2022-03-08 23:47:04 --> Helper loaded: form_helper
INFO - 2022-03-08 23:47:04 --> Helper loaded: common_helper
INFO - 2022-03-08 23:47:04 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:47:04 --> Controller Class Initialized
INFO - 2022-03-08 23:47:04 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:47:04 --> Encrypt Class Initialized
INFO - 2022-03-08 23:47:04 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:47:04 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:47:04 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:47:04 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:47:04 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:47:04 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:47:10 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:47:10 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 23:47:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:47:11 --> Config Class Initialized
INFO - 2022-03-08 23:47:11 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:47:11 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:47:11 --> Utf8 Class Initialized
INFO - 2022-03-08 23:47:11 --> URI Class Initialized
INFO - 2022-03-08 23:47:11 --> Router Class Initialized
INFO - 2022-03-08 23:47:11 --> Output Class Initialized
INFO - 2022-03-08 23:47:11 --> Security Class Initialized
DEBUG - 2022-03-08 23:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:47:11 --> Input Class Initialized
INFO - 2022-03-08 23:47:11 --> Language Class Initialized
ERROR - 2022-03-08 23:47:11 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 23:47:12 --> Final output sent to browser
DEBUG - 2022-03-08 23:47:12 --> Total execution time: 5.4704
ERROR - 2022-03-08 23:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:47:27 --> Config Class Initialized
INFO - 2022-03-08 23:47:27 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:47:27 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:47:27 --> Utf8 Class Initialized
INFO - 2022-03-08 23:47:27 --> URI Class Initialized
INFO - 2022-03-08 23:47:27 --> Router Class Initialized
INFO - 2022-03-08 23:47:27 --> Output Class Initialized
INFO - 2022-03-08 23:47:27 --> Security Class Initialized
DEBUG - 2022-03-08 23:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:47:27 --> Input Class Initialized
INFO - 2022-03-08 23:47:27 --> Language Class Initialized
INFO - 2022-03-08 23:47:27 --> Loader Class Initialized
INFO - 2022-03-08 23:47:27 --> Helper loaded: url_helper
INFO - 2022-03-08 23:47:27 --> Helper loaded: form_helper
INFO - 2022-03-08 23:47:27 --> Helper loaded: common_helper
INFO - 2022-03-08 23:47:27 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:47:27 --> Controller Class Initialized
INFO - 2022-03-08 23:47:27 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:47:27 --> Encrypt Class Initialized
INFO - 2022-03-08 23:47:27 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:47:27 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:47:27 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:47:27 --> Model "Users_model" initialized
INFO - 2022-03-08 23:47:27 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:47:27 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:47:27 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:47:27 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:47:27 --> Final output sent to browser
DEBUG - 2022-03-08 23:47:27 --> Total execution time: 0.0809
ERROR - 2022-03-08 23:47:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:47:38 --> Config Class Initialized
INFO - 2022-03-08 23:47:38 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:47:38 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:47:38 --> Utf8 Class Initialized
INFO - 2022-03-08 23:47:38 --> URI Class Initialized
INFO - 2022-03-08 23:47:38 --> Router Class Initialized
INFO - 2022-03-08 23:47:38 --> Output Class Initialized
INFO - 2022-03-08 23:47:38 --> Security Class Initialized
DEBUG - 2022-03-08 23:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:47:38 --> Input Class Initialized
INFO - 2022-03-08 23:47:38 --> Language Class Initialized
INFO - 2022-03-08 23:47:38 --> Loader Class Initialized
INFO - 2022-03-08 23:47:38 --> Helper loaded: url_helper
INFO - 2022-03-08 23:47:38 --> Helper loaded: form_helper
INFO - 2022-03-08 23:47:38 --> Helper loaded: common_helper
INFO - 2022-03-08 23:47:38 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:47:38 --> Controller Class Initialized
INFO - 2022-03-08 23:47:38 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:47:38 --> Encrypt Class Initialized
INFO - 2022-03-08 23:47:38 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:47:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:47:38 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:47:38 --> Model "Users_model" initialized
INFO - 2022-03-08 23:47:38 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:47:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:47:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:47:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:47:38 --> Final output sent to browser
DEBUG - 2022-03-08 23:47:38 --> Total execution time: 0.0784
ERROR - 2022-03-08 23:47:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:47:38 --> Config Class Initialized
INFO - 2022-03-08 23:47:38 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:47:38 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:47:38 --> Utf8 Class Initialized
INFO - 2022-03-08 23:47:38 --> URI Class Initialized
INFO - 2022-03-08 23:47:38 --> Router Class Initialized
INFO - 2022-03-08 23:47:38 --> Output Class Initialized
INFO - 2022-03-08 23:47:38 --> Security Class Initialized
DEBUG - 2022-03-08 23:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:47:38 --> Input Class Initialized
INFO - 2022-03-08 23:47:38 --> Language Class Initialized
ERROR - 2022-03-08 23:47:38 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:47:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:47:42 --> Config Class Initialized
INFO - 2022-03-08 23:47:42 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:47:42 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:47:42 --> Utf8 Class Initialized
INFO - 2022-03-08 23:47:42 --> URI Class Initialized
INFO - 2022-03-08 23:47:42 --> Router Class Initialized
INFO - 2022-03-08 23:47:42 --> Output Class Initialized
INFO - 2022-03-08 23:47:42 --> Security Class Initialized
DEBUG - 2022-03-08 23:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:47:42 --> Input Class Initialized
INFO - 2022-03-08 23:47:42 --> Language Class Initialized
INFO - 2022-03-08 23:47:42 --> Loader Class Initialized
INFO - 2022-03-08 23:47:42 --> Helper loaded: url_helper
INFO - 2022-03-08 23:47:42 --> Helper loaded: form_helper
INFO - 2022-03-08 23:47:42 --> Helper loaded: common_helper
INFO - 2022-03-08 23:47:42 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:47:42 --> Controller Class Initialized
INFO - 2022-03-08 23:47:42 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:47:42 --> Encrypt Class Initialized
INFO - 2022-03-08 23:47:42 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:47:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:47:42 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:47:42 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:47:42 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:47:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:47:49 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:47:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:47:51 --> Final output sent to browser
DEBUG - 2022-03-08 23:47:51 --> Total execution time: 7.6312
ERROR - 2022-03-08 23:48:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:48:05 --> Config Class Initialized
INFO - 2022-03-08 23:48:05 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:48:05 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:48:05 --> Utf8 Class Initialized
INFO - 2022-03-08 23:48:05 --> URI Class Initialized
INFO - 2022-03-08 23:48:05 --> Router Class Initialized
INFO - 2022-03-08 23:48:05 --> Output Class Initialized
INFO - 2022-03-08 23:48:05 --> Security Class Initialized
DEBUG - 2022-03-08 23:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:48:05 --> Input Class Initialized
INFO - 2022-03-08 23:48:05 --> Language Class Initialized
INFO - 2022-03-08 23:48:05 --> Loader Class Initialized
INFO - 2022-03-08 23:48:05 --> Helper loaded: url_helper
INFO - 2022-03-08 23:48:05 --> Helper loaded: form_helper
INFO - 2022-03-08 23:48:05 --> Helper loaded: common_helper
INFO - 2022-03-08 23:48:05 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:48:05 --> Controller Class Initialized
INFO - 2022-03-08 23:48:05 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:48:05 --> Encrypt Class Initialized
INFO - 2022-03-08 23:48:05 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:48:05 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:48:05 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:48:05 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:48:05 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:48:05 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:48:05 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-08 23:48:05 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:48:05 --> Final output sent to browser
DEBUG - 2022-03-08 23:48:05 --> Total execution time: 0.0531
ERROR - 2022-03-08 23:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:48:06 --> Config Class Initialized
INFO - 2022-03-08 23:48:06 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:48:06 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:48:06 --> Utf8 Class Initialized
INFO - 2022-03-08 23:48:06 --> URI Class Initialized
INFO - 2022-03-08 23:48:06 --> Router Class Initialized
INFO - 2022-03-08 23:48:06 --> Output Class Initialized
INFO - 2022-03-08 23:48:06 --> Security Class Initialized
DEBUG - 2022-03-08 23:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:48:06 --> Input Class Initialized
INFO - 2022-03-08 23:48:06 --> Language Class Initialized
ERROR - 2022-03-08 23:48:06 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:48:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:48:30 --> Config Class Initialized
INFO - 2022-03-08 23:48:30 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:48:30 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:48:30 --> Utf8 Class Initialized
INFO - 2022-03-08 23:48:30 --> URI Class Initialized
INFO - 2022-03-08 23:48:30 --> Router Class Initialized
INFO - 2022-03-08 23:48:30 --> Output Class Initialized
INFO - 2022-03-08 23:48:30 --> Security Class Initialized
DEBUG - 2022-03-08 23:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:48:30 --> Input Class Initialized
INFO - 2022-03-08 23:48:30 --> Language Class Initialized
INFO - 2022-03-08 23:48:30 --> Loader Class Initialized
INFO - 2022-03-08 23:48:30 --> Helper loaded: url_helper
INFO - 2022-03-08 23:48:30 --> Helper loaded: form_helper
INFO - 2022-03-08 23:48:30 --> Helper loaded: common_helper
INFO - 2022-03-08 23:48:30 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:48:30 --> Controller Class Initialized
INFO - 2022-03-08 23:48:30 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:48:30 --> Encrypt Class Initialized
INFO - 2022-03-08 23:48:30 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:48:30 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:48:30 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:48:30 --> Model "Users_model" initialized
INFO - 2022-03-08 23:48:30 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:48:30 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:48:30 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:48:30 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:48:30 --> Final output sent to browser
DEBUG - 2022-03-08 23:48:30 --> Total execution time: 0.0676
ERROR - 2022-03-08 23:48:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:48:46 --> Config Class Initialized
INFO - 2022-03-08 23:48:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:48:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:48:46 --> Utf8 Class Initialized
INFO - 2022-03-08 23:48:46 --> URI Class Initialized
INFO - 2022-03-08 23:48:46 --> Router Class Initialized
INFO - 2022-03-08 23:48:46 --> Output Class Initialized
INFO - 2022-03-08 23:48:46 --> Security Class Initialized
DEBUG - 2022-03-08 23:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:48:46 --> Input Class Initialized
INFO - 2022-03-08 23:48:46 --> Language Class Initialized
INFO - 2022-03-08 23:48:46 --> Loader Class Initialized
INFO - 2022-03-08 23:48:46 --> Helper loaded: url_helper
INFO - 2022-03-08 23:48:46 --> Helper loaded: form_helper
INFO - 2022-03-08 23:48:46 --> Helper loaded: common_helper
INFO - 2022-03-08 23:48:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:48:46 --> Controller Class Initialized
INFO - 2022-03-08 23:48:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:48:46 --> Encrypt Class Initialized
INFO - 2022-03-08 23:48:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:48:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:48:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:48:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:48:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:48:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
ERROR - 2022-03-08 23:48:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:48:46 --> Config Class Initialized
INFO - 2022-03-08 23:48:46 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:48:46 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:48:46 --> Utf8 Class Initialized
INFO - 2022-03-08 23:48:46 --> URI Class Initialized
INFO - 2022-03-08 23:48:46 --> Router Class Initialized
INFO - 2022-03-08 23:48:46 --> Output Class Initialized
INFO - 2022-03-08 23:48:46 --> Security Class Initialized
DEBUG - 2022-03-08 23:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:48:46 --> Input Class Initialized
INFO - 2022-03-08 23:48:46 --> Language Class Initialized
INFO - 2022-03-08 23:48:46 --> Loader Class Initialized
INFO - 2022-03-08 23:48:46 --> Helper loaded: url_helper
INFO - 2022-03-08 23:48:46 --> Helper loaded: form_helper
INFO - 2022-03-08 23:48:46 --> Helper loaded: common_helper
INFO - 2022-03-08 23:48:46 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:48:46 --> Controller Class Initialized
INFO - 2022-03-08 23:48:46 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:48:46 --> Encrypt Class Initialized
INFO - 2022-03-08 23:48:46 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:48:46 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:48:46 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:48:46 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:48:46 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:48:46 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:48:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:48:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:48:54 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:48:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 23:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:48:55 --> Config Class Initialized
INFO - 2022-03-08 23:48:55 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:48:55 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:48:55 --> Utf8 Class Initialized
INFO - 2022-03-08 23:48:55 --> URI Class Initialized
INFO - 2022-03-08 23:48:55 --> Router Class Initialized
INFO - 2022-03-08 23:48:55 --> Output Class Initialized
INFO - 2022-03-08 23:48:55 --> Security Class Initialized
DEBUG - 2022-03-08 23:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:48:55 --> Input Class Initialized
INFO - 2022-03-08 23:48:55 --> Language Class Initialized
ERROR - 2022-03-08 23:48:55 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 23:48:55 --> Final output sent to browser
DEBUG - 2022-03-08 23:48:55 --> Total execution time: 8.3113
INFO - 2022-03-08 23:48:56 --> Final output sent to browser
DEBUG - 2022-03-08 23:48:56 --> Total execution time: 8.3239
ERROR - 2022-03-08 23:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:49:34 --> Config Class Initialized
INFO - 2022-03-08 23:49:34 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:49:34 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:49:34 --> Utf8 Class Initialized
INFO - 2022-03-08 23:49:34 --> URI Class Initialized
INFO - 2022-03-08 23:49:34 --> Router Class Initialized
INFO - 2022-03-08 23:49:34 --> Output Class Initialized
INFO - 2022-03-08 23:49:34 --> Security Class Initialized
DEBUG - 2022-03-08 23:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:49:34 --> Input Class Initialized
INFO - 2022-03-08 23:49:34 --> Language Class Initialized
INFO - 2022-03-08 23:49:34 --> Loader Class Initialized
INFO - 2022-03-08 23:49:34 --> Helper loaded: url_helper
INFO - 2022-03-08 23:49:34 --> Helper loaded: form_helper
INFO - 2022-03-08 23:49:34 --> Helper loaded: common_helper
INFO - 2022-03-08 23:49:34 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:49:34 --> Controller Class Initialized
INFO - 2022-03-08 23:49:34 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:49:34 --> Encrypt Class Initialized
INFO - 2022-03-08 23:49:34 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:49:34 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:49:34 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:49:34 --> Model "Users_model" initialized
INFO - 2022-03-08 23:49:34 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:49:34 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:49:34 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:49:34 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:49:34 --> Final output sent to browser
DEBUG - 2022-03-08 23:49:34 --> Total execution time: 0.0528
ERROR - 2022-03-08 23:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:50:03 --> Config Class Initialized
INFO - 2022-03-08 23:50:03 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:50:03 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:50:03 --> Utf8 Class Initialized
INFO - 2022-03-08 23:50:03 --> URI Class Initialized
INFO - 2022-03-08 23:50:03 --> Router Class Initialized
INFO - 2022-03-08 23:50:03 --> Output Class Initialized
INFO - 2022-03-08 23:50:03 --> Security Class Initialized
DEBUG - 2022-03-08 23:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:50:03 --> Input Class Initialized
INFO - 2022-03-08 23:50:03 --> Language Class Initialized
INFO - 2022-03-08 23:50:03 --> Loader Class Initialized
INFO - 2022-03-08 23:50:03 --> Helper loaded: url_helper
INFO - 2022-03-08 23:50:03 --> Helper loaded: form_helper
INFO - 2022-03-08 23:50:03 --> Helper loaded: common_helper
INFO - 2022-03-08 23:50:03 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:50:03 --> Controller Class Initialized
INFO - 2022-03-08 23:50:03 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:50:03 --> Encrypt Class Initialized
INFO - 2022-03-08 23:50:03 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:50:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:50:03 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:50:03 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:50:03 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:50:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:50:09 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:50:09 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:50:10 --> Final output sent to browser
DEBUG - 2022-03-08 23:50:10 --> Total execution time: 5.9451
ERROR - 2022-03-08 23:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:50:38 --> Config Class Initialized
INFO - 2022-03-08 23:50:38 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:50:38 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:50:38 --> Utf8 Class Initialized
INFO - 2022-03-08 23:50:38 --> URI Class Initialized
INFO - 2022-03-08 23:50:38 --> Router Class Initialized
INFO - 2022-03-08 23:50:38 --> Output Class Initialized
INFO - 2022-03-08 23:50:38 --> Security Class Initialized
DEBUG - 2022-03-08 23:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:50:38 --> Input Class Initialized
INFO - 2022-03-08 23:50:38 --> Language Class Initialized
INFO - 2022-03-08 23:50:38 --> Loader Class Initialized
INFO - 2022-03-08 23:50:38 --> Helper loaded: url_helper
INFO - 2022-03-08 23:50:38 --> Helper loaded: form_helper
INFO - 2022-03-08 23:50:38 --> Helper loaded: common_helper
INFO - 2022-03-08 23:50:38 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:50:38 --> Controller Class Initialized
INFO - 2022-03-08 23:50:38 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:50:38 --> Encrypt Class Initialized
INFO - 2022-03-08 23:50:38 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:50:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:50:38 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:50:38 --> Model "Users_model" initialized
INFO - 2022-03-08 23:50:38 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:50:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:50:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:50:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:50:38 --> Final output sent to browser
DEBUG - 2022-03-08 23:50:38 --> Total execution time: 0.1159
ERROR - 2022-03-08 23:50:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:50:51 --> Config Class Initialized
INFO - 2022-03-08 23:50:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:50:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:50:51 --> Utf8 Class Initialized
INFO - 2022-03-08 23:50:51 --> URI Class Initialized
INFO - 2022-03-08 23:50:51 --> Router Class Initialized
INFO - 2022-03-08 23:50:51 --> Output Class Initialized
INFO - 2022-03-08 23:50:51 --> Security Class Initialized
DEBUG - 2022-03-08 23:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:50:51 --> Input Class Initialized
INFO - 2022-03-08 23:50:51 --> Language Class Initialized
INFO - 2022-03-08 23:50:51 --> Loader Class Initialized
INFO - 2022-03-08 23:50:51 --> Helper loaded: url_helper
INFO - 2022-03-08 23:50:51 --> Helper loaded: form_helper
INFO - 2022-03-08 23:50:51 --> Helper loaded: common_helper
INFO - 2022-03-08 23:50:51 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:50:51 --> Controller Class Initialized
INFO - 2022-03-08 23:50:51 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:50:51 --> Encrypt Class Initialized
INFO - 2022-03-08 23:50:51 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:50:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:50:51 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:50:51 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:50:51 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:50:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:50:58 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:50:58 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-08 23:50:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:50:59 --> Config Class Initialized
INFO - 2022-03-08 23:50:59 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:50:59 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:50:59 --> Utf8 Class Initialized
INFO - 2022-03-08 23:50:59 --> URI Class Initialized
INFO - 2022-03-08 23:50:59 --> Router Class Initialized
INFO - 2022-03-08 23:50:59 --> Output Class Initialized
INFO - 2022-03-08 23:50:59 --> Security Class Initialized
DEBUG - 2022-03-08 23:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:50:59 --> Input Class Initialized
INFO - 2022-03-08 23:50:59 --> Language Class Initialized
ERROR - 2022-03-08 23:50:59 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-08 23:51:00 --> Final output sent to browser
DEBUG - 2022-03-08 23:51:00 --> Total execution time: 7.3987
ERROR - 2022-03-08 23:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:51:09 --> Config Class Initialized
INFO - 2022-03-08 23:51:09 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:51:09 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:51:09 --> Utf8 Class Initialized
INFO - 2022-03-08 23:51:09 --> URI Class Initialized
INFO - 2022-03-08 23:51:09 --> Router Class Initialized
INFO - 2022-03-08 23:51:09 --> Output Class Initialized
INFO - 2022-03-08 23:51:09 --> Security Class Initialized
DEBUG - 2022-03-08 23:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:51:09 --> Input Class Initialized
INFO - 2022-03-08 23:51:09 --> Language Class Initialized
INFO - 2022-03-08 23:51:09 --> Loader Class Initialized
INFO - 2022-03-08 23:51:09 --> Helper loaded: url_helper
INFO - 2022-03-08 23:51:09 --> Helper loaded: form_helper
INFO - 2022-03-08 23:51:09 --> Helper loaded: common_helper
INFO - 2022-03-08 23:51:09 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:51:09 --> Controller Class Initialized
INFO - 2022-03-08 23:51:09 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:51:09 --> Encrypt Class Initialized
INFO - 2022-03-08 23:51:09 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:51:09 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:51:09 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:51:09 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:51:09 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:51:09 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:51:15 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:51:15 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:51:17 --> Final output sent to browser
DEBUG - 2022-03-08 23:51:17 --> Total execution time: 5.9946
ERROR - 2022-03-08 23:52:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:52:49 --> Config Class Initialized
INFO - 2022-03-08 23:52:49 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:52:49 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:52:49 --> Utf8 Class Initialized
INFO - 2022-03-08 23:52:49 --> URI Class Initialized
INFO - 2022-03-08 23:52:49 --> Router Class Initialized
INFO - 2022-03-08 23:52:49 --> Output Class Initialized
INFO - 2022-03-08 23:52:49 --> Security Class Initialized
DEBUG - 2022-03-08 23:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:52:49 --> Input Class Initialized
INFO - 2022-03-08 23:52:49 --> Language Class Initialized
INFO - 2022-03-08 23:52:49 --> Loader Class Initialized
INFO - 2022-03-08 23:52:49 --> Helper loaded: url_helper
INFO - 2022-03-08 23:52:49 --> Helper loaded: form_helper
INFO - 2022-03-08 23:52:49 --> Helper loaded: common_helper
INFO - 2022-03-08 23:52:49 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:52:49 --> Controller Class Initialized
INFO - 2022-03-08 23:52:49 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:52:49 --> Encrypt Class Initialized
INFO - 2022-03-08 23:52:49 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:52:49 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:52:49 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:52:49 --> Model "Users_model" initialized
INFO - 2022-03-08 23:52:49 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:52:49 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:52:49 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:52:49 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:52:49 --> Final output sent to browser
DEBUG - 2022-03-08 23:52:49 --> Total execution time: 0.0620
ERROR - 2022-03-08 23:52:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:52:50 --> Config Class Initialized
INFO - 2022-03-08 23:52:50 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:52:50 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:52:50 --> Utf8 Class Initialized
INFO - 2022-03-08 23:52:50 --> URI Class Initialized
INFO - 2022-03-08 23:52:50 --> Router Class Initialized
INFO - 2022-03-08 23:52:50 --> Output Class Initialized
INFO - 2022-03-08 23:52:50 --> Security Class Initialized
DEBUG - 2022-03-08 23:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:52:50 --> Input Class Initialized
INFO - 2022-03-08 23:52:50 --> Language Class Initialized
ERROR - 2022-03-08 23:52:50 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:55:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:55:47 --> Config Class Initialized
INFO - 2022-03-08 23:55:47 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:55:47 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:55:47 --> Utf8 Class Initialized
INFO - 2022-03-08 23:55:47 --> URI Class Initialized
INFO - 2022-03-08 23:55:47 --> Router Class Initialized
INFO - 2022-03-08 23:55:47 --> Output Class Initialized
INFO - 2022-03-08 23:55:47 --> Security Class Initialized
DEBUG - 2022-03-08 23:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:55:47 --> Input Class Initialized
INFO - 2022-03-08 23:55:47 --> Language Class Initialized
INFO - 2022-03-08 23:55:47 --> Loader Class Initialized
INFO - 2022-03-08 23:55:47 --> Helper loaded: url_helper
INFO - 2022-03-08 23:55:47 --> Helper loaded: form_helper
INFO - 2022-03-08 23:55:47 --> Helper loaded: common_helper
INFO - 2022-03-08 23:55:47 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:55:47 --> Controller Class Initialized
INFO - 2022-03-08 23:55:47 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:55:47 --> Encrypt Class Initialized
INFO - 2022-03-08 23:55:47 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:55:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:55:47 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:55:47 --> Model "Users_model" initialized
INFO - 2022-03-08 23:55:47 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:55:47 --> Upload Class Initialized
INFO - 2022-03-08 23:55:47 --> Final output sent to browser
DEBUG - 2022-03-08 23:55:47 --> Total execution time: 0.0401
ERROR - 2022-03-08 23:55:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:55:51 --> Config Class Initialized
INFO - 2022-03-08 23:55:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:55:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:55:51 --> Utf8 Class Initialized
INFO - 2022-03-08 23:55:51 --> URI Class Initialized
INFO - 2022-03-08 23:55:51 --> Router Class Initialized
INFO - 2022-03-08 23:55:51 --> Output Class Initialized
INFO - 2022-03-08 23:55:51 --> Security Class Initialized
DEBUG - 2022-03-08 23:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:55:51 --> Input Class Initialized
INFO - 2022-03-08 23:55:51 --> Language Class Initialized
INFO - 2022-03-08 23:55:51 --> Loader Class Initialized
INFO - 2022-03-08 23:55:51 --> Helper loaded: url_helper
INFO - 2022-03-08 23:55:51 --> Helper loaded: form_helper
INFO - 2022-03-08 23:55:51 --> Helper loaded: common_helper
INFO - 2022-03-08 23:55:51 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:55:51 --> Controller Class Initialized
INFO - 2022-03-08 23:55:51 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:55:51 --> Encrypt Class Initialized
INFO - 2022-03-08 23:55:51 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:55:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:55:51 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:55:51 --> Model "Users_model" initialized
INFO - 2022-03-08 23:55:51 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:55:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:55:51 --> Config Class Initialized
INFO - 2022-03-08 23:55:51 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:55:51 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:55:51 --> Utf8 Class Initialized
INFO - 2022-03-08 23:55:51 --> URI Class Initialized
INFO - 2022-03-08 23:55:51 --> Router Class Initialized
INFO - 2022-03-08 23:55:51 --> Output Class Initialized
INFO - 2022-03-08 23:55:51 --> Security Class Initialized
DEBUG - 2022-03-08 23:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:55:51 --> Input Class Initialized
INFO - 2022-03-08 23:55:51 --> Language Class Initialized
INFO - 2022-03-08 23:55:51 --> Loader Class Initialized
INFO - 2022-03-08 23:55:51 --> Helper loaded: url_helper
INFO - 2022-03-08 23:55:51 --> Helper loaded: form_helper
INFO - 2022-03-08 23:55:51 --> Helper loaded: common_helper
INFO - 2022-03-08 23:55:51 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:55:51 --> Controller Class Initialized
INFO - 2022-03-08 23:55:51 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:55:51 --> Encrypt Class Initialized
INFO - 2022-03-08 23:55:51 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:55:51 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:55:51 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:55:51 --> Model "Users_model" initialized
INFO - 2022-03-08 23:55:51 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:55:51 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:55:51 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:55:51 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:55:51 --> Final output sent to browser
DEBUG - 2022-03-08 23:55:51 --> Total execution time: 0.0681
ERROR - 2022-03-08 23:55:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:55:52 --> Config Class Initialized
INFO - 2022-03-08 23:55:52 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:55:52 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:55:52 --> Utf8 Class Initialized
INFO - 2022-03-08 23:55:52 --> URI Class Initialized
INFO - 2022-03-08 23:55:52 --> Router Class Initialized
INFO - 2022-03-08 23:55:52 --> Output Class Initialized
INFO - 2022-03-08 23:55:52 --> Security Class Initialized
DEBUG - 2022-03-08 23:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:55:52 --> Input Class Initialized
INFO - 2022-03-08 23:55:52 --> Language Class Initialized
ERROR - 2022-03-08 23:55:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-08 23:56:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:56:15 --> Config Class Initialized
INFO - 2022-03-08 23:56:15 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:56:15 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:56:15 --> Utf8 Class Initialized
INFO - 2022-03-08 23:56:15 --> URI Class Initialized
DEBUG - 2022-03-08 23:56:15 --> No URI present. Default controller set.
INFO - 2022-03-08 23:56:15 --> Router Class Initialized
INFO - 2022-03-08 23:56:15 --> Output Class Initialized
INFO - 2022-03-08 23:56:15 --> Security Class Initialized
DEBUG - 2022-03-08 23:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:56:15 --> Input Class Initialized
INFO - 2022-03-08 23:56:15 --> Language Class Initialized
INFO - 2022-03-08 23:56:15 --> Loader Class Initialized
INFO - 2022-03-08 23:56:15 --> Helper loaded: url_helper
INFO - 2022-03-08 23:56:15 --> Helper loaded: form_helper
INFO - 2022-03-08 23:56:15 --> Helper loaded: common_helper
INFO - 2022-03-08 23:56:15 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:56:15 --> Controller Class Initialized
INFO - 2022-03-08 23:56:15 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:56:15 --> Encrypt Class Initialized
DEBUG - 2022-03-08 23:56:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 23:56:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-08 23:56:15 --> Email Class Initialized
INFO - 2022-03-08 23:56:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-08 23:56:15 --> Calendar Class Initialized
INFO - 2022-03-08 23:56:15 --> Model "Login_model" initialized
ERROR - 2022-03-08 23:56:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:56:16 --> Config Class Initialized
INFO - 2022-03-08 23:56:16 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:56:16 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:56:16 --> Utf8 Class Initialized
INFO - 2022-03-08 23:56:16 --> URI Class Initialized
INFO - 2022-03-08 23:56:16 --> Router Class Initialized
INFO - 2022-03-08 23:56:16 --> Output Class Initialized
INFO - 2022-03-08 23:56:16 --> Security Class Initialized
DEBUG - 2022-03-08 23:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:56:16 --> Input Class Initialized
INFO - 2022-03-08 23:56:16 --> Language Class Initialized
INFO - 2022-03-08 23:56:16 --> Loader Class Initialized
INFO - 2022-03-08 23:56:16 --> Helper loaded: url_helper
INFO - 2022-03-08 23:56:16 --> Helper loaded: form_helper
INFO - 2022-03-08 23:56:16 --> Helper loaded: common_helper
INFO - 2022-03-08 23:56:16 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:56:16 --> Controller Class Initialized
INFO - 2022-03-08 23:56:16 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:56:16 --> Encrypt Class Initialized
INFO - 2022-03-08 23:56:16 --> Model "Diseases_model" initialized
INFO - 2022-03-08 23:56:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:56:16 --> File loaded: /home3/karoteam/public_html/application/views/diseases/index.php
INFO - 2022-03-08 23:56:16 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:56:16 --> Final output sent to browser
DEBUG - 2022-03-08 23:56:16 --> Total execution time: 0.0215
ERROR - 2022-03-08 23:56:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:56:23 --> Config Class Initialized
INFO - 2022-03-08 23:56:23 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:56:23 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:56:23 --> Utf8 Class Initialized
INFO - 2022-03-08 23:56:23 --> URI Class Initialized
INFO - 2022-03-08 23:56:23 --> Router Class Initialized
INFO - 2022-03-08 23:56:23 --> Output Class Initialized
INFO - 2022-03-08 23:56:23 --> Security Class Initialized
DEBUG - 2022-03-08 23:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:56:23 --> Input Class Initialized
INFO - 2022-03-08 23:56:23 --> Language Class Initialized
INFO - 2022-03-08 23:56:23 --> Loader Class Initialized
INFO - 2022-03-08 23:56:23 --> Helper loaded: url_helper
INFO - 2022-03-08 23:56:23 --> Helper loaded: form_helper
INFO - 2022-03-08 23:56:23 --> Helper loaded: common_helper
INFO - 2022-03-08 23:56:23 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:56:23 --> Controller Class Initialized
INFO - 2022-03-08 23:56:23 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:56:23 --> Encrypt Class Initialized
INFO - 2022-03-08 23:56:23 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:56:23 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:56:23 --> Model "Referredby_model" initialized
INFO - 2022-03-08 23:56:23 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:56:23 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:56:23 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:56:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-08 23:56:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:56:23 --> Final output sent to browser
DEBUG - 2022-03-08 23:56:23 --> Total execution time: 0.0472
ERROR - 2022-03-08 23:56:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:56:31 --> Config Class Initialized
INFO - 2022-03-08 23:56:31 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:56:31 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:56:31 --> Utf8 Class Initialized
INFO - 2022-03-08 23:56:31 --> URI Class Initialized
INFO - 2022-03-08 23:56:31 --> Router Class Initialized
INFO - 2022-03-08 23:56:31 --> Output Class Initialized
INFO - 2022-03-08 23:56:31 --> Security Class Initialized
DEBUG - 2022-03-08 23:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:56:31 --> Input Class Initialized
INFO - 2022-03-08 23:56:31 --> Language Class Initialized
INFO - 2022-03-08 23:56:31 --> Loader Class Initialized
INFO - 2022-03-08 23:56:31 --> Helper loaded: url_helper
INFO - 2022-03-08 23:56:31 --> Helper loaded: form_helper
INFO - 2022-03-08 23:56:31 --> Helper loaded: common_helper
INFO - 2022-03-08 23:56:31 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:56:31 --> Controller Class Initialized
INFO - 2022-03-08 23:56:31 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:56:31 --> Encrypt Class Initialized
INFO - 2022-03-08 23:56:31 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:56:31 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:56:31 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:56:31 --> Model "Users_model" initialized
INFO - 2022-03-08 23:56:31 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:56:31 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:56:31 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:56:31 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:56:31 --> Final output sent to browser
DEBUG - 2022-03-08 23:56:31 --> Total execution time: 0.0638
ERROR - 2022-03-08 23:59:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:59:25 --> Config Class Initialized
INFO - 2022-03-08 23:59:25 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:59:25 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:59:25 --> Utf8 Class Initialized
INFO - 2022-03-08 23:59:25 --> URI Class Initialized
INFO - 2022-03-08 23:59:25 --> Router Class Initialized
INFO - 2022-03-08 23:59:25 --> Output Class Initialized
INFO - 2022-03-08 23:59:25 --> Security Class Initialized
DEBUG - 2022-03-08 23:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:59:25 --> Input Class Initialized
INFO - 2022-03-08 23:59:25 --> Language Class Initialized
INFO - 2022-03-08 23:59:25 --> Loader Class Initialized
INFO - 2022-03-08 23:59:25 --> Helper loaded: url_helper
INFO - 2022-03-08 23:59:25 --> Helper loaded: form_helper
INFO - 2022-03-08 23:59:25 --> Helper loaded: common_helper
INFO - 2022-03-08 23:59:25 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:59:25 --> Controller Class Initialized
INFO - 2022-03-08 23:59:25 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:59:25 --> Encrypt Class Initialized
INFO - 2022-03-08 23:59:25 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:59:25 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:59:25 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:59:25 --> Model "Users_model" initialized
INFO - 2022-03-08 23:59:25 --> Model "Hospital_model" initialized
ERROR - 2022-03-08 23:59:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-08 23:59:26 --> Config Class Initialized
INFO - 2022-03-08 23:59:26 --> Hooks Class Initialized
DEBUG - 2022-03-08 23:59:26 --> UTF-8 Support Enabled
INFO - 2022-03-08 23:59:26 --> Utf8 Class Initialized
INFO - 2022-03-08 23:59:26 --> URI Class Initialized
INFO - 2022-03-08 23:59:26 --> Router Class Initialized
INFO - 2022-03-08 23:59:26 --> Output Class Initialized
INFO - 2022-03-08 23:59:26 --> Security Class Initialized
DEBUG - 2022-03-08 23:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-08 23:59:26 --> Input Class Initialized
INFO - 2022-03-08 23:59:26 --> Language Class Initialized
INFO - 2022-03-08 23:59:26 --> Loader Class Initialized
INFO - 2022-03-08 23:59:26 --> Helper loaded: url_helper
INFO - 2022-03-08 23:59:26 --> Helper loaded: form_helper
INFO - 2022-03-08 23:59:26 --> Helper loaded: common_helper
INFO - 2022-03-08 23:59:26 --> Database Driver Class Initialized
DEBUG - 2022-03-08 23:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-08 23:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-08 23:59:26 --> Controller Class Initialized
INFO - 2022-03-08 23:59:26 --> Form Validation Class Initialized
DEBUG - 2022-03-08 23:59:26 --> Encrypt Class Initialized
INFO - 2022-03-08 23:59:26 --> Model "Patient_model" initialized
INFO - 2022-03-08 23:59:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-08 23:59:26 --> Model "Prefix_master" initialized
INFO - 2022-03-08 23:59:26 --> Model "Users_model" initialized
INFO - 2022-03-08 23:59:26 --> Model "Hospital_model" initialized
INFO - 2022-03-08 23:59:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-08 23:59:26 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-08 23:59:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-08 23:59:26 --> Final output sent to browser
DEBUG - 2022-03-08 23:59:26 --> Total execution time: 0.1008
