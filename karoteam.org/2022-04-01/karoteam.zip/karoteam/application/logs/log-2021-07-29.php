<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-29 15:15:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-29 15:15:15 --> Config Class Initialized
INFO - 2021-07-29 15:15:15 --> Hooks Class Initialized
DEBUG - 2021-07-29 15:15:15 --> UTF-8 Support Enabled
INFO - 2021-07-29 15:15:15 --> Utf8 Class Initialized
INFO - 2021-07-29 15:15:15 --> URI Class Initialized
DEBUG - 2021-07-29 15:15:15 --> No URI present. Default controller set.
INFO - 2021-07-29 15:15:15 --> Router Class Initialized
INFO - 2021-07-29 15:15:15 --> Output Class Initialized
INFO - 2021-07-29 15:15:15 --> Security Class Initialized
DEBUG - 2021-07-29 15:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 15:15:15 --> Input Class Initialized
INFO - 2021-07-29 15:15:15 --> Language Class Initialized
INFO - 2021-07-29 15:15:15 --> Loader Class Initialized
INFO - 2021-07-29 15:15:15 --> Helper loaded: url_helper
INFO - 2021-07-29 15:15:15 --> Helper loaded: form_helper
INFO - 2021-07-29 15:15:15 --> Helper loaded: common_helper
INFO - 2021-07-29 15:15:15 --> Database Driver Class Initialized
DEBUG - 2021-07-29 15:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 15:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 15:15:15 --> Controller Class Initialized
INFO - 2021-07-29 15:15:15 --> Form Validation Class Initialized
DEBUG - 2021-07-29 15:15:15 --> Encrypt Class Initialized
DEBUG - 2021-07-29 15:15:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-29 15:15:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-29 15:15:15 --> Email Class Initialized
INFO - 2021-07-29 15:15:15 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-29 15:15:15 --> Calendar Class Initialized
INFO - 2021-07-29 15:15:15 --> Model "Login_model" initialized
INFO - 2021-07-29 15:15:15 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-29 15:15:15 --> Final output sent to browser
DEBUG - 2021-07-29 15:15:15 --> Total execution time: 0.0568
ERROR - 2021-07-29 15:15:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-29 15:15:17 --> Config Class Initialized
INFO - 2021-07-29 15:15:17 --> Hooks Class Initialized
DEBUG - 2021-07-29 15:15:17 --> UTF-8 Support Enabled
INFO - 2021-07-29 15:15:17 --> Utf8 Class Initialized
INFO - 2021-07-29 15:15:17 --> URI Class Initialized
INFO - 2021-07-29 15:15:17 --> Router Class Initialized
INFO - 2021-07-29 15:15:17 --> Output Class Initialized
INFO - 2021-07-29 15:15:17 --> Security Class Initialized
DEBUG - 2021-07-29 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 15:15:17 --> Input Class Initialized
INFO - 2021-07-29 15:15:17 --> Language Class Initialized
ERROR - 2021-07-29 15:15:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 15:15:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-29 15:15:23 --> Config Class Initialized
INFO - 2021-07-29 15:15:23 --> Hooks Class Initialized
DEBUG - 2021-07-29 15:15:23 --> UTF-8 Support Enabled
INFO - 2021-07-29 15:15:23 --> Utf8 Class Initialized
INFO - 2021-07-29 15:15:23 --> URI Class Initialized
INFO - 2021-07-29 15:15:23 --> Router Class Initialized
INFO - 2021-07-29 15:15:23 --> Output Class Initialized
INFO - 2021-07-29 15:15:23 --> Security Class Initialized
DEBUG - 2021-07-29 15:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 15:15:23 --> Input Class Initialized
INFO - 2021-07-29 15:15:23 --> Language Class Initialized
INFO - 2021-07-29 15:15:23 --> Loader Class Initialized
INFO - 2021-07-29 15:15:23 --> Helper loaded: url_helper
INFO - 2021-07-29 15:15:23 --> Helper loaded: form_helper
INFO - 2021-07-29 15:15:23 --> Helper loaded: common_helper
INFO - 2021-07-29 15:15:23 --> Database Driver Class Initialized
DEBUG - 2021-07-29 15:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 15:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 15:15:23 --> Controller Class Initialized
INFO - 2021-07-29 15:15:23 --> Form Validation Class Initialized
DEBUG - 2021-07-29 15:15:23 --> Encrypt Class Initialized
DEBUG - 2021-07-29 15:15:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-29 15:15:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-29 15:15:23 --> Email Class Initialized
INFO - 2021-07-29 15:15:23 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-29 15:15:23 --> Calendar Class Initialized
INFO - 2021-07-29 15:15:23 --> Model "Login_model" initialized
INFO - 2021-07-29 15:15:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-07-29 15:15:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-29 15:15:25 --> Config Class Initialized
INFO - 2021-07-29 15:15:25 --> Hooks Class Initialized
DEBUG - 2021-07-29 15:15:25 --> UTF-8 Support Enabled
INFO - 2021-07-29 15:15:25 --> Utf8 Class Initialized
INFO - 2021-07-29 15:15:25 --> URI Class Initialized
INFO - 2021-07-29 15:15:25 --> Router Class Initialized
INFO - 2021-07-29 15:15:25 --> Output Class Initialized
INFO - 2021-07-29 15:15:25 --> Security Class Initialized
DEBUG - 2021-07-29 15:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 15:15:25 --> Input Class Initialized
INFO - 2021-07-29 15:15:25 --> Language Class Initialized
INFO - 2021-07-29 15:15:25 --> Loader Class Initialized
INFO - 2021-07-29 15:15:25 --> Helper loaded: url_helper
INFO - 2021-07-29 15:15:25 --> Helper loaded: form_helper
INFO - 2021-07-29 15:15:25 --> Helper loaded: common_helper
INFO - 2021-07-29 15:15:25 --> Database Driver Class Initialized
DEBUG - 2021-07-29 15:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 15:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 15:15:25 --> Controller Class Initialized
INFO - 2021-07-29 15:15:25 --> Form Validation Class Initialized
DEBUG - 2021-07-29 15:15:25 --> Encrypt Class Initialized
INFO - 2021-07-29 15:15:25 --> Model "Login_model" initialized
INFO - 2021-07-29 15:15:25 --> Model "Dashboard_model" initialized
INFO - 2021-07-29 15:15:25 --> Model "Case_model" initialized
INFO - 2021-07-29 15:15:28 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-07-29 15:15:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-07-29 15:15:37 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-07-29 15:15:37 --> Final output sent to browser
DEBUG - 2021-07-29 15:15:37 --> Total execution time: 12.3362
ERROR - 2021-07-29 15:15:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-29 15:15:39 --> Config Class Initialized
INFO - 2021-07-29 15:15:39 --> Hooks Class Initialized
DEBUG - 2021-07-29 15:15:39 --> UTF-8 Support Enabled
INFO - 2021-07-29 15:15:39 --> Utf8 Class Initialized
INFO - 2021-07-29 15:15:39 --> URI Class Initialized
INFO - 2021-07-29 15:15:39 --> Router Class Initialized
INFO - 2021-07-29 15:15:39 --> Output Class Initialized
INFO - 2021-07-29 15:15:39 --> Security Class Initialized
DEBUG - 2021-07-29 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 15:15:39 --> Input Class Initialized
INFO - 2021-07-29 15:15:39 --> Language Class Initialized
ERROR - 2021-07-29 15:15:39 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-07-29 15:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-29 15:16:03 --> Config Class Initialized
INFO - 2021-07-29 15:16:03 --> Hooks Class Initialized
DEBUG - 2021-07-29 15:16:03 --> UTF-8 Support Enabled
INFO - 2021-07-29 15:16:03 --> Utf8 Class Initialized
INFO - 2021-07-29 15:16:03 --> URI Class Initialized
INFO - 2021-07-29 15:16:03 --> Router Class Initialized
INFO - 2021-07-29 15:16:03 --> Output Class Initialized
INFO - 2021-07-29 15:16:03 --> Security Class Initialized
DEBUG - 2021-07-29 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 15:16:03 --> Input Class Initialized
INFO - 2021-07-29 15:16:03 --> Language Class Initialized
INFO - 2021-07-29 15:16:03 --> Loader Class Initialized
INFO - 2021-07-29 15:16:03 --> Helper loaded: url_helper
INFO - 2021-07-29 15:16:03 --> Helper loaded: form_helper
INFO - 2021-07-29 15:16:03 --> Helper loaded: common_helper
INFO - 2021-07-29 15:16:03 --> Database Driver Class Initialized
DEBUG - 2021-07-29 15:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-29 15:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-29 15:16:03 --> Controller Class Initialized
INFO - 2021-07-29 15:16:03 --> Form Validation Class Initialized
INFO - 2021-07-29 15:16:03 --> Model "Case_model" initialized
INFO - 2021-07-29 15:16:03 --> Model "Hospital_model" initialized
INFO - 2021-07-29 15:16:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-07-29 15:16:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/transaction/upcomingFollowup.php
INFO - 2021-07-29 15:16:03 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-07-29 15:16:03 --> Final output sent to browser
DEBUG - 2021-07-29 15:16:03 --> Total execution time: 0.0376
ERROR - 2021-07-29 15:16:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-29 15:16:04 --> Config Class Initialized
INFO - 2021-07-29 15:16:04 --> Hooks Class Initialized
DEBUG - 2021-07-29 15:16:04 --> UTF-8 Support Enabled
INFO - 2021-07-29 15:16:04 --> Utf8 Class Initialized
INFO - 2021-07-29 15:16:04 --> URI Class Initialized
INFO - 2021-07-29 15:16:04 --> Router Class Initialized
INFO - 2021-07-29 15:16:04 --> Output Class Initialized
INFO - 2021-07-29 15:16:04 --> Security Class Initialized
DEBUG - 2021-07-29 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-29 15:16:04 --> Input Class Initialized
INFO - 2021-07-29 15:16:04 --> Language Class Initialized
ERROR - 2021-07-29 15:16:04 --> 404 Page Not Found: Karoclient/usersprofile
