<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-25 04:52:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-25 04:52:54 --> Config Class Initialized
INFO - 2021-12-25 04:52:54 --> Hooks Class Initialized
DEBUG - 2021-12-25 04:52:54 --> UTF-8 Support Enabled
INFO - 2021-12-25 04:52:54 --> Utf8 Class Initialized
INFO - 2021-12-25 04:52:54 --> URI Class Initialized
DEBUG - 2021-12-25 04:52:54 --> No URI present. Default controller set.
INFO - 2021-12-25 04:52:54 --> Router Class Initialized
INFO - 2021-12-25 04:52:54 --> Output Class Initialized
INFO - 2021-12-25 04:52:54 --> Security Class Initialized
DEBUG - 2021-12-25 04:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 04:52:54 --> Input Class Initialized
INFO - 2021-12-25 04:52:54 --> Language Class Initialized
INFO - 2021-12-25 04:52:54 --> Loader Class Initialized
INFO - 2021-12-25 04:52:54 --> Helper loaded: url_helper
INFO - 2021-12-25 04:52:54 --> Helper loaded: form_helper
INFO - 2021-12-25 04:52:54 --> Helper loaded: common_helper
INFO - 2021-12-25 04:52:54 --> Database Driver Class Initialized
DEBUG - 2021-12-25 04:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 04:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 04:52:54 --> Controller Class Initialized
INFO - 2021-12-25 04:52:54 --> Form Validation Class Initialized
DEBUG - 2021-12-25 04:52:54 --> Encrypt Class Initialized
DEBUG - 2021-12-25 04:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 04:52:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-25 04:52:54 --> Email Class Initialized
INFO - 2021-12-25 04:52:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-25 04:52:54 --> Calendar Class Initialized
INFO - 2021-12-25 04:52:54 --> Model "Login_model" initialized
INFO - 2021-12-25 04:52:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-25 04:52:54 --> Final output sent to browser
DEBUG - 2021-12-25 04:52:54 --> Total execution time: 0.0308
ERROR - 2021-12-25 14:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-25 14:22:35 --> Config Class Initialized
INFO - 2021-12-25 14:22:35 --> Hooks Class Initialized
DEBUG - 2021-12-25 14:22:35 --> UTF-8 Support Enabled
INFO - 2021-12-25 14:22:35 --> Utf8 Class Initialized
INFO - 2021-12-25 14:22:35 --> URI Class Initialized
DEBUG - 2021-12-25 14:22:35 --> No URI present. Default controller set.
INFO - 2021-12-25 14:22:35 --> Router Class Initialized
INFO - 2021-12-25 14:22:35 --> Output Class Initialized
INFO - 2021-12-25 14:22:35 --> Security Class Initialized
DEBUG - 2021-12-25 14:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 14:22:35 --> Input Class Initialized
INFO - 2021-12-25 14:22:35 --> Language Class Initialized
INFO - 2021-12-25 14:22:35 --> Loader Class Initialized
INFO - 2021-12-25 14:22:35 --> Helper loaded: url_helper
INFO - 2021-12-25 14:22:35 --> Helper loaded: form_helper
INFO - 2021-12-25 14:22:35 --> Helper loaded: common_helper
INFO - 2021-12-25 14:22:35 --> Database Driver Class Initialized
DEBUG - 2021-12-25 14:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 14:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 14:22:35 --> Controller Class Initialized
INFO - 2021-12-25 14:22:35 --> Form Validation Class Initialized
DEBUG - 2021-12-25 14:22:35 --> Encrypt Class Initialized
DEBUG - 2021-12-25 14:22:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 14:22:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-25 14:22:35 --> Email Class Initialized
INFO - 2021-12-25 14:22:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-25 14:22:35 --> Calendar Class Initialized
INFO - 2021-12-25 14:22:35 --> Model "Login_model" initialized
INFO - 2021-12-25 14:22:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-25 14:22:35 --> Final output sent to browser
DEBUG - 2021-12-25 14:22:35 --> Total execution time: 0.0256
ERROR - 2021-12-25 14:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-25 14:22:36 --> Config Class Initialized
INFO - 2021-12-25 14:22:36 --> Hooks Class Initialized
DEBUG - 2021-12-25 14:22:36 --> UTF-8 Support Enabled
INFO - 2021-12-25 14:22:36 --> Utf8 Class Initialized
INFO - 2021-12-25 14:22:36 --> URI Class Initialized
INFO - 2021-12-25 14:22:36 --> Router Class Initialized
INFO - 2021-12-25 14:22:36 --> Output Class Initialized
INFO - 2021-12-25 14:22:36 --> Security Class Initialized
DEBUG - 2021-12-25 14:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 14:22:36 --> Input Class Initialized
INFO - 2021-12-25 14:22:36 --> Language Class Initialized
ERROR - 2021-12-25 14:22:36 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2021-12-25 14:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-25 14:22:47 --> Config Class Initialized
INFO - 2021-12-25 14:22:47 --> Hooks Class Initialized
DEBUG - 2021-12-25 14:22:47 --> UTF-8 Support Enabled
INFO - 2021-12-25 14:22:47 --> Utf8 Class Initialized
INFO - 2021-12-25 14:22:47 --> URI Class Initialized
INFO - 2021-12-25 14:22:47 --> Router Class Initialized
INFO - 2021-12-25 14:22:47 --> Output Class Initialized
INFO - 2021-12-25 14:22:47 --> Security Class Initialized
DEBUG - 2021-12-25 14:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 14:22:47 --> Input Class Initialized
INFO - 2021-12-25 14:22:47 --> Language Class Initialized
INFO - 2021-12-25 14:22:47 --> Loader Class Initialized
INFO - 2021-12-25 14:22:47 --> Helper loaded: url_helper
INFO - 2021-12-25 14:22:47 --> Helper loaded: form_helper
INFO - 2021-12-25 14:22:47 --> Helper loaded: common_helper
INFO - 2021-12-25 14:22:47 --> Database Driver Class Initialized
DEBUG - 2021-12-25 14:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 14:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 14:22:47 --> Controller Class Initialized
INFO - 2021-12-25 14:22:47 --> Form Validation Class Initialized
DEBUG - 2021-12-25 14:22:47 --> Encrypt Class Initialized
DEBUG - 2021-12-25 14:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 14:22:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-25 14:22:47 --> Email Class Initialized
INFO - 2021-12-25 14:22:47 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-25 14:22:47 --> Calendar Class Initialized
INFO - 2021-12-25 14:22:47 --> Model "Login_model" initialized
ERROR - 2021-12-25 14:22:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-25 14:22:48 --> Config Class Initialized
INFO - 2021-12-25 14:22:48 --> Hooks Class Initialized
DEBUG - 2021-12-25 14:22:48 --> UTF-8 Support Enabled
INFO - 2021-12-25 14:22:48 --> Utf8 Class Initialized
INFO - 2021-12-25 14:22:48 --> URI Class Initialized
INFO - 2021-12-25 14:22:48 --> Router Class Initialized
INFO - 2021-12-25 14:22:48 --> Output Class Initialized
INFO - 2021-12-25 14:22:48 --> Security Class Initialized
DEBUG - 2021-12-25 14:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 14:22:48 --> Input Class Initialized
INFO - 2021-12-25 14:22:48 --> Language Class Initialized
INFO - 2021-12-25 14:22:48 --> Loader Class Initialized
INFO - 2021-12-25 14:22:48 --> Helper loaded: url_helper
INFO - 2021-12-25 14:22:48 --> Helper loaded: form_helper
INFO - 2021-12-25 14:22:48 --> Helper loaded: common_helper
INFO - 2021-12-25 14:22:48 --> Database Driver Class Initialized
DEBUG - 2021-12-25 14:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 14:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 14:22:48 --> Controller Class Initialized
INFO - 2021-12-25 14:22:48 --> Form Validation Class Initialized
DEBUG - 2021-12-25 14:22:48 --> Encrypt Class Initialized
DEBUG - 2021-12-25 14:22:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 14:22:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-25 14:22:48 --> Email Class Initialized
INFO - 2021-12-25 14:22:48 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-25 14:22:48 --> Calendar Class Initialized
INFO - 2021-12-25 14:22:48 --> Model "Login_model" initialized
ERROR - 2021-12-25 14:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-25 14:22:49 --> Config Class Initialized
INFO - 2021-12-25 14:22:49 --> Hooks Class Initialized
DEBUG - 2021-12-25 14:22:49 --> UTF-8 Support Enabled
INFO - 2021-12-25 14:22:49 --> Utf8 Class Initialized
INFO - 2021-12-25 14:22:49 --> URI Class Initialized
DEBUG - 2021-12-25 14:22:49 --> No URI present. Default controller set.
INFO - 2021-12-25 14:22:49 --> Router Class Initialized
INFO - 2021-12-25 14:22:49 --> Output Class Initialized
INFO - 2021-12-25 14:22:49 --> Security Class Initialized
DEBUG - 2021-12-25 14:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 14:22:49 --> Input Class Initialized
INFO - 2021-12-25 14:22:49 --> Language Class Initialized
INFO - 2021-12-25 14:22:49 --> Loader Class Initialized
INFO - 2021-12-25 14:22:49 --> Helper loaded: url_helper
INFO - 2021-12-25 14:22:49 --> Helper loaded: form_helper
INFO - 2021-12-25 14:22:49 --> Helper loaded: common_helper
INFO - 2021-12-25 14:22:49 --> Database Driver Class Initialized
DEBUG - 2021-12-25 14:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 14:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 14:22:49 --> Controller Class Initialized
INFO - 2021-12-25 14:22:49 --> Form Validation Class Initialized
DEBUG - 2021-12-25 14:22:49 --> Encrypt Class Initialized
DEBUG - 2021-12-25 14:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 14:22:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-25 14:22:49 --> Email Class Initialized
INFO - 2021-12-25 14:22:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-25 14:22:49 --> Calendar Class Initialized
INFO - 2021-12-25 14:22:49 --> Model "Login_model" initialized
INFO - 2021-12-25 14:22:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-25 14:22:49 --> Final output sent to browser
DEBUG - 2021-12-25 14:22:49 --> Total execution time: 0.0223
ERROR - 2021-12-25 14:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-12-25 14:22:49 --> Config Class Initialized
INFO - 2021-12-25 14:22:49 --> Hooks Class Initialized
DEBUG - 2021-12-25 14:22:49 --> UTF-8 Support Enabled
INFO - 2021-12-25 14:22:49 --> Utf8 Class Initialized
INFO - 2021-12-25 14:22:49 --> URI Class Initialized
INFO - 2021-12-25 14:22:49 --> Router Class Initialized
INFO - 2021-12-25 14:22:49 --> Output Class Initialized
INFO - 2021-12-25 14:22:49 --> Security Class Initialized
DEBUG - 2021-12-25 14:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 14:22:49 --> Input Class Initialized
INFO - 2021-12-25 14:22:49 --> Language Class Initialized
INFO - 2021-12-25 14:22:49 --> Loader Class Initialized
INFO - 2021-12-25 14:22:49 --> Helper loaded: url_helper
INFO - 2021-12-25 14:22:49 --> Helper loaded: form_helper
INFO - 2021-12-25 14:22:49 --> Helper loaded: common_helper
INFO - 2021-12-25 14:22:49 --> Database Driver Class Initialized
DEBUG - 2021-12-25 14:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 14:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 14:22:49 --> Controller Class Initialized
INFO - 2021-12-25 14:22:49 --> Form Validation Class Initialized
DEBUG - 2021-12-25 14:22:49 --> Encrypt Class Initialized
DEBUG - 2021-12-25 14:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 14:22:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-12-25 14:22:49 --> Email Class Initialized
INFO - 2021-12-25 14:22:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-12-25 14:22:49 --> Calendar Class Initialized
INFO - 2021-12-25 14:22:49 --> Model "Login_model" initialized
INFO - 2021-12-25 14:22:49 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-12-25 14:22:49 --> Final output sent to browser
DEBUG - 2021-12-25 14:22:49 --> Total execution time: 0.0206
