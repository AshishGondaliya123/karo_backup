<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-29 00:25:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 00:25:28 --> Config Class Initialized
INFO - 2021-11-29 00:25:28 --> Hooks Class Initialized
DEBUG - 2021-11-29 00:25:28 --> UTF-8 Support Enabled
INFO - 2021-11-29 00:25:28 --> Utf8 Class Initialized
INFO - 2021-11-29 00:25:28 --> URI Class Initialized
DEBUG - 2021-11-29 00:25:28 --> No URI present. Default controller set.
INFO - 2021-11-29 00:25:28 --> Router Class Initialized
INFO - 2021-11-29 00:25:28 --> Output Class Initialized
INFO - 2021-11-29 00:25:28 --> Security Class Initialized
DEBUG - 2021-11-29 00:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 00:25:28 --> Input Class Initialized
INFO - 2021-11-29 00:25:28 --> Language Class Initialized
INFO - 2021-11-29 00:25:28 --> Loader Class Initialized
INFO - 2021-11-29 00:25:28 --> Helper loaded: url_helper
INFO - 2021-11-29 00:25:28 --> Helper loaded: form_helper
INFO - 2021-11-29 00:25:28 --> Helper loaded: common_helper
INFO - 2021-11-29 00:25:28 --> Database Driver Class Initialized
DEBUG - 2021-11-29 00:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 00:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 00:25:28 --> Controller Class Initialized
INFO - 2021-11-29 00:25:28 --> Form Validation Class Initialized
DEBUG - 2021-11-29 00:25:28 --> Encrypt Class Initialized
DEBUG - 2021-11-29 00:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 00:25:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 00:25:28 --> Email Class Initialized
INFO - 2021-11-29 00:25:28 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 00:25:28 --> Calendar Class Initialized
INFO - 2021-11-29 00:25:28 --> Model "Login_model" initialized
INFO - 2021-11-29 00:25:28 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 00:25:28 --> Final output sent to browser
DEBUG - 2021-11-29 00:25:28 --> Total execution time: 0.0237
ERROR - 2021-11-29 04:16:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 04:16:10 --> Config Class Initialized
INFO - 2021-11-29 04:16:10 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:16:10 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:16:10 --> Utf8 Class Initialized
INFO - 2021-11-29 04:16:10 --> URI Class Initialized
DEBUG - 2021-11-29 04:16:10 --> No URI present. Default controller set.
INFO - 2021-11-29 04:16:10 --> Router Class Initialized
INFO - 2021-11-29 04:16:10 --> Output Class Initialized
INFO - 2021-11-29 04:16:10 --> Security Class Initialized
DEBUG - 2021-11-29 04:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:16:10 --> Input Class Initialized
INFO - 2021-11-29 04:16:10 --> Language Class Initialized
INFO - 2021-11-29 04:16:10 --> Loader Class Initialized
INFO - 2021-11-29 04:16:10 --> Helper loaded: url_helper
INFO - 2021-11-29 04:16:10 --> Helper loaded: form_helper
INFO - 2021-11-29 04:16:10 --> Helper loaded: common_helper
INFO - 2021-11-29 04:16:10 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:16:10 --> Controller Class Initialized
INFO - 2021-11-29 04:16:10 --> Form Validation Class Initialized
DEBUG - 2021-11-29 04:16:10 --> Encrypt Class Initialized
DEBUG - 2021-11-29 04:16:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 04:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 04:16:10 --> Email Class Initialized
INFO - 2021-11-29 04:16:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 04:16:10 --> Calendar Class Initialized
INFO - 2021-11-29 04:16:10 --> Model "Login_model" initialized
INFO - 2021-11-29 04:16:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 04:16:10 --> Final output sent to browser
DEBUG - 2021-11-29 04:16:10 --> Total execution time: 0.0236
ERROR - 2021-11-29 09:44:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 09:44:01 --> Config Class Initialized
INFO - 2021-11-29 09:44:01 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:44:01 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:44:01 --> Utf8 Class Initialized
INFO - 2021-11-29 09:44:01 --> URI Class Initialized
DEBUG - 2021-11-29 09:44:01 --> No URI present. Default controller set.
INFO - 2021-11-29 09:44:01 --> Router Class Initialized
INFO - 2021-11-29 09:44:01 --> Output Class Initialized
INFO - 2021-11-29 09:44:01 --> Security Class Initialized
DEBUG - 2021-11-29 09:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:44:01 --> Input Class Initialized
INFO - 2021-11-29 09:44:01 --> Language Class Initialized
INFO - 2021-11-29 09:44:01 --> Loader Class Initialized
INFO - 2021-11-29 09:44:01 --> Helper loaded: url_helper
INFO - 2021-11-29 09:44:01 --> Helper loaded: form_helper
INFO - 2021-11-29 09:44:01 --> Helper loaded: common_helper
INFO - 2021-11-29 09:44:01 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:44:01 --> Controller Class Initialized
INFO - 2021-11-29 09:44:01 --> Form Validation Class Initialized
DEBUG - 2021-11-29 09:44:01 --> Encrypt Class Initialized
DEBUG - 2021-11-29 09:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 09:44:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 09:44:01 --> Email Class Initialized
INFO - 2021-11-29 09:44:01 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 09:44:01 --> Calendar Class Initialized
INFO - 2021-11-29 09:44:01 --> Model "Login_model" initialized
INFO - 2021-11-29 09:44:01 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 09:44:01 --> Final output sent to browser
DEBUG - 2021-11-29 09:44:01 --> Total execution time: 0.0470
ERROR - 2021-11-29 09:44:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 09:44:04 --> Config Class Initialized
INFO - 2021-11-29 09:44:04 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:44:04 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:44:04 --> Utf8 Class Initialized
INFO - 2021-11-29 09:44:04 --> URI Class Initialized
DEBUG - 2021-11-29 09:44:04 --> No URI present. Default controller set.
INFO - 2021-11-29 09:44:04 --> Router Class Initialized
INFO - 2021-11-29 09:44:04 --> Output Class Initialized
INFO - 2021-11-29 09:44:04 --> Security Class Initialized
DEBUG - 2021-11-29 09:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:44:04 --> Input Class Initialized
INFO - 2021-11-29 09:44:04 --> Language Class Initialized
INFO - 2021-11-29 09:44:04 --> Loader Class Initialized
INFO - 2021-11-29 09:44:04 --> Helper loaded: url_helper
INFO - 2021-11-29 09:44:04 --> Helper loaded: form_helper
INFO - 2021-11-29 09:44:04 --> Helper loaded: common_helper
INFO - 2021-11-29 09:44:04 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:44:04 --> Controller Class Initialized
INFO - 2021-11-29 09:44:04 --> Form Validation Class Initialized
DEBUG - 2021-11-29 09:44:04 --> Encrypt Class Initialized
DEBUG - 2021-11-29 09:44:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 09:44:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 09:44:04 --> Email Class Initialized
INFO - 2021-11-29 09:44:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 09:44:04 --> Calendar Class Initialized
INFO - 2021-11-29 09:44:04 --> Model "Login_model" initialized
INFO - 2021-11-29 09:44:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 09:44:04 --> Final output sent to browser
DEBUG - 2021-11-29 09:44:04 --> Total execution time: 0.0354
ERROR - 2021-11-29 10:14:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 10:14:54 --> Config Class Initialized
INFO - 2021-11-29 10:14:54 --> Hooks Class Initialized
DEBUG - 2021-11-29 10:14:54 --> UTF-8 Support Enabled
INFO - 2021-11-29 10:14:54 --> Utf8 Class Initialized
INFO - 2021-11-29 10:14:54 --> URI Class Initialized
DEBUG - 2021-11-29 10:14:54 --> No URI present. Default controller set.
INFO - 2021-11-29 10:14:54 --> Router Class Initialized
INFO - 2021-11-29 10:14:54 --> Output Class Initialized
INFO - 2021-11-29 10:14:54 --> Security Class Initialized
DEBUG - 2021-11-29 10:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 10:14:54 --> Input Class Initialized
INFO - 2021-11-29 10:14:54 --> Language Class Initialized
INFO - 2021-11-29 10:14:54 --> Loader Class Initialized
INFO - 2021-11-29 10:14:54 --> Helper loaded: url_helper
INFO - 2021-11-29 10:14:54 --> Helper loaded: form_helper
INFO - 2021-11-29 10:14:54 --> Helper loaded: common_helper
INFO - 2021-11-29 10:14:54 --> Database Driver Class Initialized
DEBUG - 2021-11-29 10:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 10:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 10:14:54 --> Controller Class Initialized
INFO - 2021-11-29 10:14:54 --> Form Validation Class Initialized
DEBUG - 2021-11-29 10:14:54 --> Encrypt Class Initialized
DEBUG - 2021-11-29 10:14:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 10:14:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 10:14:54 --> Email Class Initialized
INFO - 2021-11-29 10:14:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 10:14:54 --> Calendar Class Initialized
INFO - 2021-11-29 10:14:54 --> Model "Login_model" initialized
INFO - 2021-11-29 10:14:54 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 10:14:54 --> Final output sent to browser
DEBUG - 2021-11-29 10:14:54 --> Total execution time: 0.0228
ERROR - 2021-11-29 10:15:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 10:15:00 --> Config Class Initialized
INFO - 2021-11-29 10:15:00 --> Hooks Class Initialized
DEBUG - 2021-11-29 10:15:00 --> UTF-8 Support Enabled
INFO - 2021-11-29 10:15:00 --> Utf8 Class Initialized
INFO - 2021-11-29 10:15:00 --> URI Class Initialized
DEBUG - 2021-11-29 10:15:00 --> No URI present. Default controller set.
INFO - 2021-11-29 10:15:00 --> Router Class Initialized
INFO - 2021-11-29 10:15:00 --> Output Class Initialized
INFO - 2021-11-29 10:15:00 --> Security Class Initialized
DEBUG - 2021-11-29 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 10:15:00 --> Input Class Initialized
INFO - 2021-11-29 10:15:00 --> Language Class Initialized
INFO - 2021-11-29 10:15:00 --> Loader Class Initialized
INFO - 2021-11-29 10:15:00 --> Helper loaded: url_helper
INFO - 2021-11-29 10:15:00 --> Helper loaded: form_helper
INFO - 2021-11-29 10:15:00 --> Helper loaded: common_helper
INFO - 2021-11-29 10:15:00 --> Database Driver Class Initialized
DEBUG - 2021-11-29 10:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 10:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 10:15:00 --> Controller Class Initialized
INFO - 2021-11-29 10:15:00 --> Form Validation Class Initialized
DEBUG - 2021-11-29 10:15:00 --> Encrypt Class Initialized
DEBUG - 2021-11-29 10:15:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 10:15:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 10:15:00 --> Email Class Initialized
INFO - 2021-11-29 10:15:00 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 10:15:00 --> Calendar Class Initialized
INFO - 2021-11-29 10:15:00 --> Model "Login_model" initialized
INFO - 2021-11-29 10:15:00 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 10:15:00 --> Final output sent to browser
DEBUG - 2021-11-29 10:15:00 --> Total execution time: 0.0215
ERROR - 2021-11-29 11:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 11:21:09 --> Config Class Initialized
INFO - 2021-11-29 11:21:09 --> Hooks Class Initialized
DEBUG - 2021-11-29 11:21:09 --> UTF-8 Support Enabled
INFO - 2021-11-29 11:21:09 --> Utf8 Class Initialized
INFO - 2021-11-29 11:21:09 --> URI Class Initialized
DEBUG - 2021-11-29 11:21:09 --> No URI present. Default controller set.
INFO - 2021-11-29 11:21:09 --> Router Class Initialized
INFO - 2021-11-29 11:21:09 --> Output Class Initialized
INFO - 2021-11-29 11:21:09 --> Security Class Initialized
DEBUG - 2021-11-29 11:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 11:21:09 --> Input Class Initialized
INFO - 2021-11-29 11:21:09 --> Language Class Initialized
INFO - 2021-11-29 11:21:09 --> Loader Class Initialized
INFO - 2021-11-29 11:21:09 --> Helper loaded: url_helper
INFO - 2021-11-29 11:21:09 --> Helper loaded: form_helper
INFO - 2021-11-29 11:21:09 --> Helper loaded: common_helper
INFO - 2021-11-29 11:21:09 --> Database Driver Class Initialized
DEBUG - 2021-11-29 11:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 11:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 11:21:09 --> Controller Class Initialized
INFO - 2021-11-29 11:21:09 --> Form Validation Class Initialized
DEBUG - 2021-11-29 11:21:09 --> Encrypt Class Initialized
DEBUG - 2021-11-29 11:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 11:21:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 11:21:09 --> Email Class Initialized
INFO - 2021-11-29 11:21:09 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 11:21:09 --> Calendar Class Initialized
INFO - 2021-11-29 11:21:09 --> Model "Login_model" initialized
INFO - 2021-11-29 11:21:09 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 11:21:09 --> Final output sent to browser
DEBUG - 2021-11-29 11:21:09 --> Total execution time: 0.0239
ERROR - 2021-11-29 11:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 11:21:22 --> Config Class Initialized
INFO - 2021-11-29 11:21:22 --> Hooks Class Initialized
DEBUG - 2021-11-29 11:21:22 --> UTF-8 Support Enabled
INFO - 2021-11-29 11:21:22 --> Utf8 Class Initialized
INFO - 2021-11-29 11:21:22 --> URI Class Initialized
DEBUG - 2021-11-29 11:21:22 --> No URI present. Default controller set.
INFO - 2021-11-29 11:21:22 --> Router Class Initialized
INFO - 2021-11-29 11:21:22 --> Output Class Initialized
INFO - 2021-11-29 11:21:22 --> Security Class Initialized
DEBUG - 2021-11-29 11:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 11:21:22 --> Input Class Initialized
INFO - 2021-11-29 11:21:22 --> Language Class Initialized
INFO - 2021-11-29 11:21:22 --> Loader Class Initialized
INFO - 2021-11-29 11:21:22 --> Helper loaded: url_helper
INFO - 2021-11-29 11:21:22 --> Helper loaded: form_helper
INFO - 2021-11-29 11:21:22 --> Helper loaded: common_helper
INFO - 2021-11-29 11:21:22 --> Database Driver Class Initialized
DEBUG - 2021-11-29 11:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 11:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 11:21:22 --> Controller Class Initialized
INFO - 2021-11-29 11:21:22 --> Form Validation Class Initialized
DEBUG - 2021-11-29 11:21:22 --> Encrypt Class Initialized
DEBUG - 2021-11-29 11:21:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 11:21:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 11:21:22 --> Email Class Initialized
INFO - 2021-11-29 11:21:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 11:21:22 --> Calendar Class Initialized
INFO - 2021-11-29 11:21:22 --> Model "Login_model" initialized
INFO - 2021-11-29 11:21:22 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 11:21:22 --> Final output sent to browser
DEBUG - 2021-11-29 11:21:22 --> Total execution time: 0.0512
ERROR - 2021-11-29 11:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 11:22:20 --> Config Class Initialized
INFO - 2021-11-29 11:22:20 --> Hooks Class Initialized
DEBUG - 2021-11-29 11:22:20 --> UTF-8 Support Enabled
INFO - 2021-11-29 11:22:20 --> Utf8 Class Initialized
INFO - 2021-11-29 11:22:20 --> URI Class Initialized
DEBUG - 2021-11-29 11:22:20 --> No URI present. Default controller set.
INFO - 2021-11-29 11:22:20 --> Router Class Initialized
INFO - 2021-11-29 11:22:20 --> Output Class Initialized
INFO - 2021-11-29 11:22:20 --> Security Class Initialized
DEBUG - 2021-11-29 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 11:22:20 --> Input Class Initialized
INFO - 2021-11-29 11:22:20 --> Language Class Initialized
INFO - 2021-11-29 11:22:20 --> Loader Class Initialized
INFO - 2021-11-29 11:22:20 --> Helper loaded: url_helper
INFO - 2021-11-29 11:22:20 --> Helper loaded: form_helper
INFO - 2021-11-29 11:22:20 --> Helper loaded: common_helper
INFO - 2021-11-29 11:22:20 --> Database Driver Class Initialized
DEBUG - 2021-11-29 11:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 11:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 11:22:20 --> Controller Class Initialized
INFO - 2021-11-29 11:22:20 --> Form Validation Class Initialized
DEBUG - 2021-11-29 11:22:20 --> Encrypt Class Initialized
DEBUG - 2021-11-29 11:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 11:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 11:22:20 --> Email Class Initialized
INFO - 2021-11-29 11:22:20 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 11:22:20 --> Calendar Class Initialized
INFO - 2021-11-29 11:22:20 --> Model "Login_model" initialized
INFO - 2021-11-29 11:22:20 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 11:22:20 --> Final output sent to browser
DEBUG - 2021-11-29 11:22:20 --> Total execution time: 0.0334
ERROR - 2021-11-29 14:19:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 14:19:53 --> Config Class Initialized
INFO - 2021-11-29 14:19:53 --> Hooks Class Initialized
DEBUG - 2021-11-29 14:19:53 --> UTF-8 Support Enabled
INFO - 2021-11-29 14:19:53 --> Utf8 Class Initialized
INFO - 2021-11-29 14:19:53 --> URI Class Initialized
DEBUG - 2021-11-29 14:19:53 --> No URI present. Default controller set.
INFO - 2021-11-29 14:19:53 --> Router Class Initialized
INFO - 2021-11-29 14:19:53 --> Output Class Initialized
INFO - 2021-11-29 14:19:53 --> Security Class Initialized
DEBUG - 2021-11-29 14:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 14:19:53 --> Input Class Initialized
INFO - 2021-11-29 14:19:53 --> Language Class Initialized
INFO - 2021-11-29 14:19:53 --> Loader Class Initialized
INFO - 2021-11-29 14:19:53 --> Helper loaded: url_helper
INFO - 2021-11-29 14:19:53 --> Helper loaded: form_helper
INFO - 2021-11-29 14:19:53 --> Helper loaded: common_helper
INFO - 2021-11-29 14:19:53 --> Database Driver Class Initialized
DEBUG - 2021-11-29 14:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 14:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 14:19:53 --> Controller Class Initialized
INFO - 2021-11-29 14:19:53 --> Form Validation Class Initialized
DEBUG - 2021-11-29 14:19:53 --> Encrypt Class Initialized
DEBUG - 2021-11-29 14:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 14:19:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 14:19:53 --> Email Class Initialized
INFO - 2021-11-29 14:19:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 14:19:53 --> Calendar Class Initialized
INFO - 2021-11-29 14:19:53 --> Model "Login_model" initialized
INFO - 2021-11-29 14:19:53 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 14:19:53 --> Final output sent to browser
DEBUG - 2021-11-29 14:19:53 --> Total execution time: 0.0337
ERROR - 2021-11-29 15:45:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 15:45:41 --> Config Class Initialized
INFO - 2021-11-29 15:45:41 --> Hooks Class Initialized
DEBUG - 2021-11-29 15:45:41 --> UTF-8 Support Enabled
INFO - 2021-11-29 15:45:41 --> Utf8 Class Initialized
INFO - 2021-11-29 15:45:41 --> URI Class Initialized
DEBUG - 2021-11-29 15:45:41 --> No URI present. Default controller set.
INFO - 2021-11-29 15:45:41 --> Router Class Initialized
INFO - 2021-11-29 15:45:41 --> Output Class Initialized
INFO - 2021-11-29 15:45:41 --> Security Class Initialized
DEBUG - 2021-11-29 15:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 15:45:41 --> Input Class Initialized
INFO - 2021-11-29 15:45:41 --> Language Class Initialized
INFO - 2021-11-29 15:45:41 --> Loader Class Initialized
INFO - 2021-11-29 15:45:41 --> Helper loaded: url_helper
INFO - 2021-11-29 15:45:41 --> Helper loaded: form_helper
INFO - 2021-11-29 15:45:41 --> Helper loaded: common_helper
INFO - 2021-11-29 15:45:41 --> Database Driver Class Initialized
DEBUG - 2021-11-29 15:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 15:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 15:45:41 --> Controller Class Initialized
INFO - 2021-11-29 15:45:41 --> Form Validation Class Initialized
DEBUG - 2021-11-29 15:45:41 --> Encrypt Class Initialized
DEBUG - 2021-11-29 15:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 15:45:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 15:45:41 --> Email Class Initialized
INFO - 2021-11-29 15:45:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 15:45:41 --> Calendar Class Initialized
INFO - 2021-11-29 15:45:41 --> Model "Login_model" initialized
INFO - 2021-11-29 15:45:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 15:45:41 --> Final output sent to browser
DEBUG - 2021-11-29 15:45:41 --> Total execution time: 0.0349
ERROR - 2021-11-29 17:23:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 17:23:59 --> Config Class Initialized
INFO - 2021-11-29 17:23:59 --> Hooks Class Initialized
DEBUG - 2021-11-29 17:23:59 --> UTF-8 Support Enabled
INFO - 2021-11-29 17:23:59 --> Utf8 Class Initialized
INFO - 2021-11-29 17:23:59 --> URI Class Initialized
DEBUG - 2021-11-29 17:23:59 --> No URI present. Default controller set.
INFO - 2021-11-29 17:23:59 --> Router Class Initialized
INFO - 2021-11-29 17:23:59 --> Output Class Initialized
INFO - 2021-11-29 17:23:59 --> Security Class Initialized
DEBUG - 2021-11-29 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 17:23:59 --> Input Class Initialized
INFO - 2021-11-29 17:23:59 --> Language Class Initialized
INFO - 2021-11-29 17:23:59 --> Loader Class Initialized
INFO - 2021-11-29 17:23:59 --> Helper loaded: url_helper
INFO - 2021-11-29 17:23:59 --> Helper loaded: form_helper
INFO - 2021-11-29 17:23:59 --> Helper loaded: common_helper
INFO - 2021-11-29 17:23:59 --> Database Driver Class Initialized
DEBUG - 2021-11-29 17:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 17:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 17:23:59 --> Controller Class Initialized
INFO - 2021-11-29 17:23:59 --> Form Validation Class Initialized
DEBUG - 2021-11-29 17:23:59 --> Encrypt Class Initialized
DEBUG - 2021-11-29 17:23:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 17:23:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 17:23:59 --> Email Class Initialized
INFO - 2021-11-29 17:23:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 17:23:59 --> Calendar Class Initialized
INFO - 2021-11-29 17:23:59 --> Model "Login_model" initialized
INFO - 2021-11-29 17:23:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 17:23:59 --> Final output sent to browser
DEBUG - 2021-11-29 17:23:59 --> Total execution time: 0.0242
ERROR - 2021-11-29 22:57:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-11-29 22:57:31 --> Config Class Initialized
INFO - 2021-11-29 22:57:31 --> Hooks Class Initialized
DEBUG - 2021-11-29 22:57:31 --> UTF-8 Support Enabled
INFO - 2021-11-29 22:57:31 --> Utf8 Class Initialized
INFO - 2021-11-29 22:57:31 --> URI Class Initialized
DEBUG - 2021-11-29 22:57:31 --> No URI present. Default controller set.
INFO - 2021-11-29 22:57:31 --> Router Class Initialized
INFO - 2021-11-29 22:57:31 --> Output Class Initialized
INFO - 2021-11-29 22:57:31 --> Security Class Initialized
DEBUG - 2021-11-29 22:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 22:57:31 --> Input Class Initialized
INFO - 2021-11-29 22:57:31 --> Language Class Initialized
INFO - 2021-11-29 22:57:31 --> Loader Class Initialized
INFO - 2021-11-29 22:57:31 --> Helper loaded: url_helper
INFO - 2021-11-29 22:57:31 --> Helper loaded: form_helper
INFO - 2021-11-29 22:57:31 --> Helper loaded: common_helper
INFO - 2021-11-29 22:57:31 --> Database Driver Class Initialized
DEBUG - 2021-11-29 22:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 22:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 22:57:31 --> Controller Class Initialized
INFO - 2021-11-29 22:57:31 --> Form Validation Class Initialized
DEBUG - 2021-11-29 22:57:31 --> Encrypt Class Initialized
DEBUG - 2021-11-29 22:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-11-29 22:57:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-11-29 22:57:31 --> Email Class Initialized
INFO - 2021-11-29 22:57:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-11-29 22:57:31 --> Calendar Class Initialized
INFO - 2021-11-29 22:57:31 --> Model "Login_model" initialized
INFO - 2021-11-29 22:57:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2021-11-29 22:57:31 --> Final output sent to browser
DEBUG - 2021-11-29 22:57:31 --> Total execution time: 0.0241
