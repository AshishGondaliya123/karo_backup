<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-14 06:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-14 06:23:26 --> Config Class Initialized
INFO - 2021-07-14 06:23:26 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:23:26 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:23:26 --> Utf8 Class Initialized
INFO - 2021-07-14 06:23:26 --> URI Class Initialized
DEBUG - 2021-07-14 06:23:26 --> No URI present. Default controller set.
INFO - 2021-07-14 06:23:26 --> Router Class Initialized
INFO - 2021-07-14 06:23:26 --> Output Class Initialized
INFO - 2021-07-14 06:23:26 --> Security Class Initialized
DEBUG - 2021-07-14 06:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:23:26 --> Input Class Initialized
INFO - 2021-07-14 06:23:26 --> Language Class Initialized
INFO - 2021-07-14 06:23:26 --> Loader Class Initialized
INFO - 2021-07-14 06:23:26 --> Helper loaded: url_helper
INFO - 2021-07-14 06:23:26 --> Helper loaded: form_helper
INFO - 2021-07-14 06:23:26 --> Helper loaded: common_helper
INFO - 2021-07-14 06:23:26 --> Database Driver Class Initialized
DEBUG - 2021-07-14 06:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 06:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 06:23:26 --> Controller Class Initialized
INFO - 2021-07-14 06:23:26 --> Form Validation Class Initialized
DEBUG - 2021-07-14 06:23:26 --> Encrypt Class Initialized
DEBUG - 2021-07-14 06:23:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-07-14 06:23:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-14 06:23:26 --> Email Class Initialized
INFO - 2021-07-14 06:23:26 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-07-14 06:23:26 --> Calendar Class Initialized
INFO - 2021-07-14 06:23:26 --> Model "Login_model" initialized
INFO - 2021-07-14 06:23:26 --> File loaded: /home1/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-07-14 06:23:26 --> Final output sent to browser
DEBUG - 2021-07-14 06:23:26 --> Total execution time: 0.0580
ERROR - 2021-07-14 06:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-14 06:23:27 --> Config Class Initialized
INFO - 2021-07-14 06:23:27 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:23:27 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:23:27 --> Utf8 Class Initialized
INFO - 2021-07-14 06:23:27 --> URI Class Initialized
INFO - 2021-07-14 06:23:27 --> Router Class Initialized
INFO - 2021-07-14 06:23:27 --> Output Class Initialized
INFO - 2021-07-14 06:23:27 --> Security Class Initialized
DEBUG - 2021-07-14 06:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:23:27 --> Input Class Initialized
INFO - 2021-07-14 06:23:27 --> Language Class Initialized
ERROR - 2021-07-14 06:23:27 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2021-07-14 06:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-14 06:23:27 --> Config Class Initialized
INFO - 2021-07-14 06:23:27 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:23:27 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:23:27 --> Utf8 Class Initialized
INFO - 2021-07-14 06:23:27 --> URI Class Initialized
INFO - 2021-07-14 06:23:27 --> Router Class Initialized
INFO - 2021-07-14 06:23:27 --> Output Class Initialized
INFO - 2021-07-14 06:23:27 --> Security Class Initialized
DEBUG - 2021-07-14 06:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:23:27 --> Input Class Initialized
INFO - 2021-07-14 06:23:27 --> Language Class Initialized
ERROR - 2021-07-14 06:23:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 06:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-07-14 06:23:27 --> Config Class Initialized
INFO - 2021-07-14 06:23:27 --> Hooks Class Initialized
DEBUG - 2021-07-14 06:23:27 --> UTF-8 Support Enabled
INFO - 2021-07-14 06:23:27 --> Utf8 Class Initialized
INFO - 2021-07-14 06:23:27 --> URI Class Initialized
INFO - 2021-07-14 06:23:27 --> Router Class Initialized
INFO - 2021-07-14 06:23:27 --> Output Class Initialized
INFO - 2021-07-14 06:23:27 --> Security Class Initialized
DEBUG - 2021-07-14 06:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 06:23:27 --> Input Class Initialized
INFO - 2021-07-14 06:23:27 --> Language Class Initialized
ERROR - 2021-07-14 06:23:27 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
