<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-15 17:02:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:02:17 --> Config Class Initialized
INFO - 2021-05-15 17:02:17 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:02:17 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:02:17 --> Utf8 Class Initialized
INFO - 2021-05-15 17:02:17 --> URI Class Initialized
DEBUG - 2021-05-15 17:02:17 --> No URI present. Default controller set.
INFO - 2021-05-15 17:02:17 --> Router Class Initialized
INFO - 2021-05-15 17:02:17 --> Output Class Initialized
INFO - 2021-05-15 17:02:17 --> Security Class Initialized
DEBUG - 2021-05-15 17:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:02:17 --> Input Class Initialized
INFO - 2021-05-15 17:02:17 --> Language Class Initialized
INFO - 2021-05-15 17:02:17 --> Loader Class Initialized
INFO - 2021-05-15 17:02:17 --> Helper loaded: url_helper
INFO - 2021-05-15 17:02:17 --> Helper loaded: form_helper
INFO - 2021-05-15 17:02:17 --> Helper loaded: common_helper
INFO - 2021-05-15 17:02:18 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:02:18 --> Controller Class Initialized
INFO - 2021-05-15 17:02:18 --> Form Validation Class Initialized
INFO - 2021-05-15 17:02:18 --> Encrypt Class Initialized
DEBUG - 2021-05-15 17:02:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 17:02:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 17:02:18 --> Email Class Initialized
INFO - 2021-05-15 17:02:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 17:02:18 --> Calendar Class Initialized
INFO - 2021-05-15 17:02:18 --> Model "Login_model" initialized
INFO - 2021-05-15 17:02:18 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\login/index.php
INFO - 2021-05-15 17:02:18 --> Final output sent to browser
DEBUG - 2021-05-15 17:02:18 --> Total execution time: 1.3066
ERROR - 2021-05-15 17:02:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:02:53 --> Config Class Initialized
INFO - 2021-05-15 17:02:53 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:02:53 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:02:53 --> Utf8 Class Initialized
INFO - 2021-05-15 17:02:54 --> URI Class Initialized
INFO - 2021-05-15 17:02:54 --> Router Class Initialized
INFO - 2021-05-15 17:02:54 --> Output Class Initialized
INFO - 2021-05-15 17:02:54 --> Security Class Initialized
DEBUG - 2021-05-15 17:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:02:54 --> Input Class Initialized
INFO - 2021-05-15 17:02:54 --> Language Class Initialized
INFO - 2021-05-15 17:02:54 --> Loader Class Initialized
INFO - 2021-05-15 17:02:54 --> Helper loaded: url_helper
INFO - 2021-05-15 17:02:54 --> Helper loaded: form_helper
INFO - 2021-05-15 17:02:54 --> Helper loaded: common_helper
INFO - 2021-05-15 17:02:54 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:02:54 --> Controller Class Initialized
INFO - 2021-05-15 17:02:54 --> Form Validation Class Initialized
INFO - 2021-05-15 17:02:54 --> Encrypt Class Initialized
DEBUG - 2021-05-15 17:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 17:02:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 17:02:54 --> Email Class Initialized
INFO - 2021-05-15 17:02:54 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 17:02:54 --> Calendar Class Initialized
INFO - 2021-05-15 17:02:54 --> Model "Login_model" initialized
INFO - 2021-05-15 17:02:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-05-15 17:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:02:54 --> Config Class Initialized
INFO - 2021-05-15 17:02:54 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:02:54 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:02:54 --> Utf8 Class Initialized
INFO - 2021-05-15 17:02:54 --> URI Class Initialized
INFO - 2021-05-15 17:02:54 --> Router Class Initialized
INFO - 2021-05-15 17:02:54 --> Output Class Initialized
INFO - 2021-05-15 17:02:54 --> Security Class Initialized
DEBUG - 2021-05-15 17:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:02:54 --> Input Class Initialized
INFO - 2021-05-15 17:02:54 --> Language Class Initialized
INFO - 2021-05-15 17:02:54 --> Loader Class Initialized
INFO - 2021-05-15 17:02:54 --> Helper loaded: url_helper
INFO - 2021-05-15 17:02:54 --> Helper loaded: form_helper
INFO - 2021-05-15 17:02:54 --> Helper loaded: common_helper
INFO - 2021-05-15 17:02:54 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:02:54 --> Controller Class Initialized
INFO - 2021-05-15 17:02:54 --> Form Validation Class Initialized
INFO - 2021-05-15 17:02:54 --> Encrypt Class Initialized
INFO - 2021-05-15 17:02:54 --> Model "Login_model" initialized
INFO - 2021-05-15 17:02:54 --> Model "Dashboard_model" initialized
INFO - 2021-05-15 17:02:54 --> Model "Case_model" initialized
INFO - 2021-05-15 17:03:02 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-15 17:03:22 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\dashboard/index.php
INFO - 2021-05-15 17:03:22 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-15 17:03:22 --> Final output sent to browser
DEBUG - 2021-05-15 17:03:22 --> Total execution time: 28.0835
ERROR - 2021-05-15 17:03:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:03:23 --> Config Class Initialized
INFO - 2021-05-15 17:03:23 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:03:23 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:03:23 --> Utf8 Class Initialized
INFO - 2021-05-15 17:03:23 --> URI Class Initialized
INFO - 2021-05-15 17:03:23 --> Router Class Initialized
INFO - 2021-05-15 17:03:23 --> Output Class Initialized
INFO - 2021-05-15 17:03:23 --> Security Class Initialized
DEBUG - 2021-05-15 17:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:03:23 --> Input Class Initialized
INFO - 2021-05-15 17:03:23 --> Language Class Initialized
ERROR - 2021-05-15 17:03:23 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 17:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:33:04 --> Config Class Initialized
INFO - 2021-05-15 17:33:04 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:33:04 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:33:04 --> Utf8 Class Initialized
INFO - 2021-05-15 17:33:04 --> URI Class Initialized
INFO - 2021-05-15 17:33:04 --> Router Class Initialized
INFO - 2021-05-15 17:33:04 --> Output Class Initialized
INFO - 2021-05-15 17:33:04 --> Security Class Initialized
DEBUG - 2021-05-15 17:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:33:04 --> Input Class Initialized
INFO - 2021-05-15 17:33:04 --> Language Class Initialized
INFO - 2021-05-15 17:33:04 --> Loader Class Initialized
INFO - 2021-05-15 17:33:04 --> Helper loaded: url_helper
INFO - 2021-05-15 17:33:04 --> Helper loaded: form_helper
INFO - 2021-05-15 17:33:04 --> Helper loaded: common_helper
INFO - 2021-05-15 17:33:04 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:33:04 --> Controller Class Initialized
INFO - 2021-05-15 17:33:04 --> Form Validation Class Initialized
INFO - 2021-05-15 17:33:04 --> Model "Report_model" initialized
INFO - 2021-05-15 17:33:04 --> Model "Case_model" initialized
INFO - 2021-05-15 17:33:04 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-15 17:33:04 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-15 17:33:04 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-15 17:33:04 --> Final output sent to browser
DEBUG - 2021-05-15 17:33:04 --> Total execution time: 0.0539
ERROR - 2021-05-15 17:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:33:04 --> Config Class Initialized
INFO - 2021-05-15 17:33:04 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:33:04 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:33:04 --> Utf8 Class Initialized
INFO - 2021-05-15 17:33:04 --> URI Class Initialized
INFO - 2021-05-15 17:33:04 --> Router Class Initialized
INFO - 2021-05-15 17:33:04 --> Output Class Initialized
INFO - 2021-05-15 17:33:04 --> Security Class Initialized
DEBUG - 2021-05-15 17:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:33:04 --> Input Class Initialized
INFO - 2021-05-15 17:33:04 --> Language Class Initialized
ERROR - 2021-05-15 17:33:04 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 17:33:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:33:13 --> Config Class Initialized
INFO - 2021-05-15 17:33:13 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:33:13 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:33:13 --> Utf8 Class Initialized
INFO - 2021-05-15 17:33:13 --> URI Class Initialized
INFO - 2021-05-15 17:33:13 --> Router Class Initialized
INFO - 2021-05-15 17:33:13 --> Output Class Initialized
INFO - 2021-05-15 17:33:13 --> Security Class Initialized
DEBUG - 2021-05-15 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:33:13 --> Input Class Initialized
INFO - 2021-05-15 17:33:13 --> Language Class Initialized
INFO - 2021-05-15 17:33:13 --> Loader Class Initialized
INFO - 2021-05-15 17:33:13 --> Helper loaded: url_helper
INFO - 2021-05-15 17:33:13 --> Helper loaded: form_helper
INFO - 2021-05-15 17:33:13 --> Helper loaded: common_helper
INFO - 2021-05-15 17:33:13 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:33:13 --> Controller Class Initialized
INFO - 2021-05-15 17:33:13 --> Form Validation Class Initialized
INFO - 2021-05-15 17:33:13 --> Model "Report_model" initialized
INFO - 2021-05-15 17:33:13 --> Model "Case_model" initialized
INFO - 2021-05-15 17:33:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\header.php
INFO - 2021-05-15 17:33:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\reports/patient_details.php
INFO - 2021-05-15 17:33:13 --> File loaded: C:\xampp\htdocs\study\karosoftware\application\views\footer.php
INFO - 2021-05-15 17:33:13 --> Final output sent to browser
DEBUG - 2021-05-15 17:33:13 --> Total execution time: 0.0553
ERROR - 2021-05-15 17:33:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:33:14 --> Config Class Initialized
INFO - 2021-05-15 17:33:14 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:33:14 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:33:14 --> Utf8 Class Initialized
INFO - 2021-05-15 17:33:14 --> URI Class Initialized
INFO - 2021-05-15 17:33:14 --> Router Class Initialized
INFO - 2021-05-15 17:33:14 --> Output Class Initialized
INFO - 2021-05-15 17:33:14 --> Security Class Initialized
DEBUG - 2021-05-15 17:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:33:14 --> Input Class Initialized
INFO - 2021-05-15 17:33:14 --> Language Class Initialized
ERROR - 2021-05-15 17:33:14 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 15:44:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 15:44:41 --> Config Class Initialized
INFO - 2021-05-15 15:44:41 --> Hooks Class Initialized
DEBUG - 2021-05-15 15:44:41 --> UTF-8 Support Enabled
INFO - 2021-05-15 15:44:41 --> Utf8 Class Initialized
INFO - 2021-05-15 15:44:41 --> URI Class Initialized
DEBUG - 2021-05-15 15:44:41 --> No URI present. Default controller set.
INFO - 2021-05-15 15:44:41 --> Router Class Initialized
INFO - 2021-05-15 15:44:41 --> Output Class Initialized
INFO - 2021-05-15 15:44:41 --> Security Class Initialized
DEBUG - 2021-05-15 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 15:44:41 --> Input Class Initialized
INFO - 2021-05-15 15:44:41 --> Language Class Initialized
INFO - 2021-05-15 15:44:41 --> Loader Class Initialized
INFO - 2021-05-15 15:44:41 --> Helper loaded: url_helper
INFO - 2021-05-15 15:44:41 --> Helper loaded: form_helper
INFO - 2021-05-15 15:44:41 --> Helper loaded: common_helper
INFO - 2021-05-15 15:44:41 --> Database Driver Class Initialized
ERROR - 2021-05-15 15:44:41 --> Unable to connect to the database
INFO - 2021-05-15 15:44:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:34:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:34:43 --> Config Class Initialized
INFO - 2021-05-15 16:34:43 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:34:43 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:34:43 --> Utf8 Class Initialized
INFO - 2021-05-15 16:34:43 --> URI Class Initialized
DEBUG - 2021-05-15 16:34:43 --> No URI present. Default controller set.
INFO - 2021-05-15 16:34:43 --> Router Class Initialized
INFO - 2021-05-15 16:34:43 --> Output Class Initialized
INFO - 2021-05-15 16:34:43 --> Security Class Initialized
DEBUG - 2021-05-15 16:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:34:43 --> Input Class Initialized
INFO - 2021-05-15 16:34:43 --> Language Class Initialized
INFO - 2021-05-15 16:34:43 --> Loader Class Initialized
INFO - 2021-05-15 16:34:43 --> Helper loaded: url_helper
INFO - 2021-05-15 16:34:43 --> Helper loaded: form_helper
INFO - 2021-05-15 16:34:43 --> Helper loaded: common_helper
INFO - 2021-05-15 16:34:43 --> Database Driver Class Initialized
ERROR - 2021-05-15 16:34:43 --> Unable to connect to the database
INFO - 2021-05-15 16:34:43 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:35:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:35:10 --> Config Class Initialized
INFO - 2021-05-15 16:35:10 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:35:10 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:35:10 --> Utf8 Class Initialized
INFO - 2021-05-15 16:35:10 --> URI Class Initialized
DEBUG - 2021-05-15 16:35:10 --> No URI present. Default controller set.
INFO - 2021-05-15 16:35:10 --> Router Class Initialized
INFO - 2021-05-15 16:35:10 --> Output Class Initialized
INFO - 2021-05-15 16:35:10 --> Security Class Initialized
DEBUG - 2021-05-15 16:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:35:10 --> Input Class Initialized
INFO - 2021-05-15 16:35:10 --> Language Class Initialized
INFO - 2021-05-15 16:35:10 --> Loader Class Initialized
INFO - 2021-05-15 16:35:10 --> Helper loaded: url_helper
INFO - 2021-05-15 16:35:10 --> Helper loaded: form_helper
INFO - 2021-05-15 16:35:10 --> Helper loaded: common_helper
INFO - 2021-05-15 16:35:10 --> Database Driver Class Initialized
ERROR - 2021-05-15 16:35:10 --> Unable to connect to the database
INFO - 2021-05-15 16:35:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:37:19 --> Config Class Initialized
INFO - 2021-05-15 16:37:19 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:37:19 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:37:19 --> Utf8 Class Initialized
INFO - 2021-05-15 16:37:19 --> URI Class Initialized
DEBUG - 2021-05-15 16:37:19 --> No URI present. Default controller set.
INFO - 2021-05-15 16:37:19 --> Router Class Initialized
INFO - 2021-05-15 16:37:19 --> Output Class Initialized
INFO - 2021-05-15 16:37:19 --> Security Class Initialized
DEBUG - 2021-05-15 16:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:37:19 --> Input Class Initialized
INFO - 2021-05-15 16:37:19 --> Language Class Initialized
INFO - 2021-05-15 16:37:19 --> Loader Class Initialized
INFO - 2021-05-15 16:37:19 --> Helper loaded: url_helper
INFO - 2021-05-15 16:37:19 --> Helper loaded: form_helper
INFO - 2021-05-15 16:37:19 --> Helper loaded: common_helper
INFO - 2021-05-15 16:37:19 --> Database Driver Class Initialized
ERROR - 2021-05-15 16:37:19 --> Unable to connect to the database
INFO - 2021-05-15 16:37:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:39:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:39:04 --> Config Class Initialized
INFO - 2021-05-15 16:39:04 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:39:04 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:39:04 --> Utf8 Class Initialized
INFO - 2021-05-15 16:39:04 --> URI Class Initialized
DEBUG - 2021-05-15 16:39:04 --> No URI present. Default controller set.
INFO - 2021-05-15 16:39:04 --> Router Class Initialized
INFO - 2021-05-15 16:39:04 --> Output Class Initialized
INFO - 2021-05-15 16:39:04 --> Security Class Initialized
DEBUG - 2021-05-15 16:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:39:04 --> Input Class Initialized
INFO - 2021-05-15 16:39:04 --> Language Class Initialized
INFO - 2021-05-15 16:39:04 --> Loader Class Initialized
INFO - 2021-05-15 16:39:04 --> Helper loaded: url_helper
INFO - 2021-05-15 16:39:04 --> Helper loaded: form_helper
INFO - 2021-05-15 16:39:04 --> Helper loaded: common_helper
INFO - 2021-05-15 16:39:04 --> Database Driver Class Initialized
ERROR - 2021-05-15 16:39:04 --> Unable to connect to the database
INFO - 2021-05-15 16:39:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:39:15 --> Config Class Initialized
INFO - 2021-05-15 16:39:15 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:39:15 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:39:15 --> Utf8 Class Initialized
INFO - 2021-05-15 16:39:15 --> URI Class Initialized
DEBUG - 2021-05-15 16:39:15 --> No URI present. Default controller set.
INFO - 2021-05-15 16:39:15 --> Router Class Initialized
INFO - 2021-05-15 16:39:15 --> Output Class Initialized
INFO - 2021-05-15 16:39:15 --> Security Class Initialized
DEBUG - 2021-05-15 16:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:39:15 --> Input Class Initialized
INFO - 2021-05-15 16:39:15 --> Language Class Initialized
INFO - 2021-05-15 16:39:15 --> Loader Class Initialized
INFO - 2021-05-15 16:39:15 --> Helper loaded: url_helper
INFO - 2021-05-15 16:39:15 --> Helper loaded: form_helper
INFO - 2021-05-15 16:39:15 --> Helper loaded: common_helper
INFO - 2021-05-15 16:39:15 --> Database Driver Class Initialized
ERROR - 2021-05-15 16:39:15 --> Unable to connect to the database
INFO - 2021-05-15 16:39:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:39:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:39:16 --> Config Class Initialized
INFO - 2021-05-15 16:39:16 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:39:16 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:39:16 --> Utf8 Class Initialized
INFO - 2021-05-15 16:39:16 --> URI Class Initialized
INFO - 2021-05-15 16:39:16 --> Router Class Initialized
INFO - 2021-05-15 16:39:16 --> Output Class Initialized
INFO - 2021-05-15 16:39:16 --> Security Class Initialized
DEBUG - 2021-05-15 16:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:39:16 --> Input Class Initialized
INFO - 2021-05-15 16:39:16 --> Language Class Initialized
ERROR - 2021-05-15 16:39:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:40:37 --> Config Class Initialized
INFO - 2021-05-15 16:40:37 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:40:37 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:40:37 --> Utf8 Class Initialized
INFO - 2021-05-15 16:40:37 --> URI Class Initialized
DEBUG - 2021-05-15 16:40:37 --> No URI present. Default controller set.
INFO - 2021-05-15 16:40:37 --> Router Class Initialized
INFO - 2021-05-15 16:40:37 --> Output Class Initialized
INFO - 2021-05-15 16:40:37 --> Security Class Initialized
DEBUG - 2021-05-15 16:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:40:37 --> Input Class Initialized
INFO - 2021-05-15 16:40:37 --> Language Class Initialized
ERROR - 2021-05-15 16:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:40:38 --> Config Class Initialized
INFO - 2021-05-15 16:40:38 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:40:38 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:40:38 --> Utf8 Class Initialized
INFO - 2021-05-15 16:40:38 --> URI Class Initialized
INFO - 2021-05-15 16:40:38 --> Router Class Initialized
INFO - 2021-05-15 16:40:38 --> Output Class Initialized
INFO - 2021-05-15 16:40:38 --> Security Class Initialized
DEBUG - 2021-05-15 16:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:40:38 --> Input Class Initialized
INFO - 2021-05-15 16:40:38 --> Language Class Initialized
ERROR - 2021-05-15 16:40:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:41:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:41:02 --> Config Class Initialized
INFO - 2021-05-15 16:41:02 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:41:02 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:41:02 --> Utf8 Class Initialized
INFO - 2021-05-15 16:41:02 --> URI Class Initialized
DEBUG - 2021-05-15 16:41:02 --> No URI present. Default controller set.
INFO - 2021-05-15 16:41:02 --> Router Class Initialized
INFO - 2021-05-15 16:41:02 --> Output Class Initialized
INFO - 2021-05-15 16:41:02 --> Security Class Initialized
DEBUG - 2021-05-15 16:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:41:02 --> Input Class Initialized
INFO - 2021-05-15 16:41:02 --> Language Class Initialized
INFO - 2021-05-15 16:41:02 --> Loader Class Initialized
INFO - 2021-05-15 16:41:02 --> Helper loaded: url_helper
INFO - 2021-05-15 16:41:02 --> Helper loaded: form_helper
INFO - 2021-05-15 16:41:02 --> Helper loaded: common_helper
INFO - 2021-05-15 16:41:02 --> Database Driver Class Initialized
ERROR - 2021-05-15 16:41:02 --> Unable to connect to the database
INFO - 2021-05-15 16:41:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:41:03 --> Config Class Initialized
INFO - 2021-05-15 16:41:03 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:41:03 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:41:03 --> Utf8 Class Initialized
INFO - 2021-05-15 16:41:03 --> URI Class Initialized
INFO - 2021-05-15 16:41:03 --> Router Class Initialized
INFO - 2021-05-15 16:41:03 --> Output Class Initialized
INFO - 2021-05-15 16:41:03 --> Security Class Initialized
DEBUG - 2021-05-15 16:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:41:03 --> Input Class Initialized
INFO - 2021-05-15 16:41:03 --> Language Class Initialized
ERROR - 2021-05-15 16:41:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:43:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:43:29 --> Config Class Initialized
INFO - 2021-05-15 16:43:29 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:43:29 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:43:29 --> Utf8 Class Initialized
INFO - 2021-05-15 16:43:29 --> URI Class Initialized
DEBUG - 2021-05-15 16:43:29 --> No URI present. Default controller set.
INFO - 2021-05-15 16:43:29 --> Router Class Initialized
INFO - 2021-05-15 16:43:29 --> Output Class Initialized
INFO - 2021-05-15 16:43:29 --> Security Class Initialized
DEBUG - 2021-05-15 16:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:43:29 --> Input Class Initialized
INFO - 2021-05-15 16:43:29 --> Language Class Initialized
INFO - 2021-05-15 16:43:29 --> Loader Class Initialized
INFO - 2021-05-15 16:43:29 --> Helper loaded: url_helper
INFO - 2021-05-15 16:43:29 --> Helper loaded: form_helper
INFO - 2021-05-15 16:43:29 --> Helper loaded: common_helper
INFO - 2021-05-15 16:43:29 --> Database Driver Class Initialized
ERROR - 2021-05-15 16:43:29 --> Unable to connect to the database
INFO - 2021-05-15 16:43:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:43:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:43:36 --> Config Class Initialized
INFO - 2021-05-15 16:43:36 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:43:36 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:43:36 --> Utf8 Class Initialized
INFO - 2021-05-15 16:43:36 --> URI Class Initialized
DEBUG - 2021-05-15 16:43:36 --> No URI present. Default controller set.
INFO - 2021-05-15 16:43:36 --> Router Class Initialized
INFO - 2021-05-15 16:43:36 --> Output Class Initialized
INFO - 2021-05-15 16:43:36 --> Security Class Initialized
DEBUG - 2021-05-15 16:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:43:36 --> Input Class Initialized
INFO - 2021-05-15 16:43:36 --> Language Class Initialized
INFO - 2021-05-15 16:43:36 --> Loader Class Initialized
INFO - 2021-05-15 16:43:36 --> Helper loaded: url_helper
INFO - 2021-05-15 16:43:36 --> Helper loaded: form_helper
INFO - 2021-05-15 16:43:36 --> Helper loaded: common_helper
INFO - 2021-05-15 16:43:36 --> Database Driver Class Initialized
ERROR - 2021-05-15 16:43:36 --> Unable to connect to the database
INFO - 2021-05-15 16:43:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:43:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:43:49 --> Config Class Initialized
INFO - 2021-05-15 16:43:49 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:43:49 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:43:49 --> Utf8 Class Initialized
INFO - 2021-05-15 16:43:49 --> URI Class Initialized
DEBUG - 2021-05-15 16:43:49 --> No URI present. Default controller set.
INFO - 2021-05-15 16:43:49 --> Router Class Initialized
INFO - 2021-05-15 16:43:49 --> Output Class Initialized
INFO - 2021-05-15 16:43:49 --> Security Class Initialized
DEBUG - 2021-05-15 16:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:43:49 --> Input Class Initialized
INFO - 2021-05-15 16:43:49 --> Language Class Initialized
INFO - 2021-05-15 16:43:49 --> Loader Class Initialized
INFO - 2021-05-15 16:43:49 --> Helper loaded: url_helper
INFO - 2021-05-15 16:43:49 --> Helper loaded: form_helper
INFO - 2021-05-15 16:43:49 --> Helper loaded: common_helper
INFO - 2021-05-15 16:43:49 --> Database Driver Class Initialized
ERROR - 2021-05-15 16:43:49 --> Unable to connect to the database
INFO - 2021-05-15 16:43:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2021-05-15 16:46:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:46:38 --> Config Class Initialized
INFO - 2021-05-15 16:46:38 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:46:38 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:46:38 --> Utf8 Class Initialized
INFO - 2021-05-15 16:46:38 --> URI Class Initialized
DEBUG - 2021-05-15 16:46:38 --> No URI present. Default controller set.
INFO - 2021-05-15 16:46:38 --> Router Class Initialized
INFO - 2021-05-15 16:46:38 --> Output Class Initialized
INFO - 2021-05-15 16:46:38 --> Security Class Initialized
DEBUG - 2021-05-15 16:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:46:38 --> Input Class Initialized
INFO - 2021-05-15 16:46:38 --> Language Class Initialized
INFO - 2021-05-15 16:46:38 --> Loader Class Initialized
INFO - 2021-05-15 16:46:38 --> Helper loaded: url_helper
INFO - 2021-05-15 16:46:38 --> Helper loaded: form_helper
INFO - 2021-05-15 16:46:38 --> Helper loaded: common_helper
INFO - 2021-05-15 16:46:38 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:46:38 --> Controller Class Initialized
INFO - 2021-05-15 16:46:38 --> Form Validation Class Initialized
ERROR - 2021-05-15 16:53:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:53:31 --> Config Class Initialized
INFO - 2021-05-15 16:53:31 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:53:31 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:53:31 --> Utf8 Class Initialized
INFO - 2021-05-15 16:53:31 --> URI Class Initialized
DEBUG - 2021-05-15 16:53:31 --> No URI present. Default controller set.
INFO - 2021-05-15 16:53:31 --> Router Class Initialized
INFO - 2021-05-15 16:53:31 --> Output Class Initialized
INFO - 2021-05-15 16:53:31 --> Security Class Initialized
DEBUG - 2021-05-15 16:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:53:31 --> Input Class Initialized
INFO - 2021-05-15 16:53:31 --> Language Class Initialized
INFO - 2021-05-15 16:53:31 --> Loader Class Initialized
INFO - 2021-05-15 16:53:31 --> Helper loaded: url_helper
INFO - 2021-05-15 16:53:31 --> Helper loaded: form_helper
INFO - 2021-05-15 16:53:31 --> Helper loaded: common_helper
INFO - 2021-05-15 16:53:31 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:53:31 --> Controller Class Initialized
INFO - 2021-05-15 16:53:31 --> Form Validation Class Initialized
DEBUG - 2021-05-15 16:53:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-05-15 16:53:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-05-15 16:53:31 --> Encryption Class Initialized
DEBUG - 2021-05-15 16:53:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:53:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 16:53:31 --> Email Class Initialized
INFO - 2021-05-15 16:53:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 16:53:31 --> Calendar Class Initialized
INFO - 2021-05-15 16:53:31 --> Model "Login_model" initialized
INFO - 2021-05-15 16:53:31 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 16:53:31 --> Final output sent to browser
DEBUG - 2021-05-15 16:53:31 --> Total execution time: 0.0228
ERROR - 2021-05-15 16:53:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:53:33 --> Config Class Initialized
INFO - 2021-05-15 16:53:33 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:53:33 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:53:33 --> Utf8 Class Initialized
INFO - 2021-05-15 16:53:33 --> URI Class Initialized
INFO - 2021-05-15 16:53:33 --> Router Class Initialized
INFO - 2021-05-15 16:53:33 --> Output Class Initialized
INFO - 2021-05-15 16:53:33 --> Security Class Initialized
DEBUG - 2021-05-15 16:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:53:33 --> Input Class Initialized
INFO - 2021-05-15 16:53:33 --> Language Class Initialized
ERROR - 2021-05-15 16:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:53:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:53:59 --> Config Class Initialized
INFO - 2021-05-15 16:53:59 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:53:59 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:53:59 --> Utf8 Class Initialized
INFO - 2021-05-15 16:53:59 --> URI Class Initialized
DEBUG - 2021-05-15 16:53:59 --> No URI present. Default controller set.
INFO - 2021-05-15 16:53:59 --> Router Class Initialized
INFO - 2021-05-15 16:53:59 --> Output Class Initialized
INFO - 2021-05-15 16:53:59 --> Security Class Initialized
DEBUG - 2021-05-15 16:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:53:59 --> Input Class Initialized
INFO - 2021-05-15 16:53:59 --> Language Class Initialized
INFO - 2021-05-15 16:53:59 --> Loader Class Initialized
INFO - 2021-05-15 16:53:59 --> Helper loaded: url_helper
INFO - 2021-05-15 16:53:59 --> Helper loaded: form_helper
INFO - 2021-05-15 16:53:59 --> Helper loaded: common_helper
INFO - 2021-05-15 16:53:59 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:53:59 --> Controller Class Initialized
INFO - 2021-05-15 16:53:59 --> Form Validation Class Initialized
DEBUG - 2021-05-15 16:53:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-05-15 16:53:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-05-15 16:53:59 --> Encryption Class Initialized
DEBUG - 2021-05-15 16:53:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:53:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 16:53:59 --> Email Class Initialized
INFO - 2021-05-15 16:53:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 16:53:59 --> Calendar Class Initialized
INFO - 2021-05-15 16:53:59 --> Model "Login_model" initialized
INFO - 2021-05-15 16:53:59 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 16:53:59 --> Final output sent to browser
DEBUG - 2021-05-15 16:53:59 --> Total execution time: 0.0214
ERROR - 2021-05-15 16:54:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:54:09 --> Config Class Initialized
INFO - 2021-05-15 16:54:09 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:54:09 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:54:09 --> Utf8 Class Initialized
INFO - 2021-05-15 16:54:09 --> URI Class Initialized
INFO - 2021-05-15 16:54:09 --> Router Class Initialized
INFO - 2021-05-15 16:54:09 --> Output Class Initialized
INFO - 2021-05-15 16:54:09 --> Security Class Initialized
DEBUG - 2021-05-15 16:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:54:09 --> Input Class Initialized
INFO - 2021-05-15 16:54:09 --> Language Class Initialized
ERROR - 2021-05-15 16:54:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:54:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:54:22 --> Config Class Initialized
INFO - 2021-05-15 16:54:22 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:54:22 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:54:22 --> Utf8 Class Initialized
INFO - 2021-05-15 16:54:22 --> URI Class Initialized
DEBUG - 2021-05-15 16:54:22 --> No URI present. Default controller set.
INFO - 2021-05-15 16:54:22 --> Router Class Initialized
INFO - 2021-05-15 16:54:22 --> Output Class Initialized
INFO - 2021-05-15 16:54:22 --> Security Class Initialized
DEBUG - 2021-05-15 16:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:54:22 --> Input Class Initialized
INFO - 2021-05-15 16:54:22 --> Language Class Initialized
INFO - 2021-05-15 16:54:22 --> Loader Class Initialized
INFO - 2021-05-15 16:54:22 --> Helper loaded: url_helper
INFO - 2021-05-15 16:54:22 --> Helper loaded: form_helper
INFO - 2021-05-15 16:54:22 --> Helper loaded: common_helper
INFO - 2021-05-15 16:54:22 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:54:22 --> Controller Class Initialized
INFO - 2021-05-15 16:54:22 --> Form Validation Class Initialized
DEBUG - 2021-05-15 16:54:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2021-05-15 16:54:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2021-05-15 16:54:22 --> Encryption Class Initialized
DEBUG - 2021-05-15 16:54:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:54:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 16:54:22 --> Email Class Initialized
INFO - 2021-05-15 16:54:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 16:54:22 --> Calendar Class Initialized
INFO - 2021-05-15 16:54:22 --> Model "Login_model" initialized
INFO - 2021-05-15 16:54:22 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 16:54:22 --> Final output sent to browser
DEBUG - 2021-05-15 16:54:22 --> Total execution time: 0.0222
ERROR - 2021-05-15 16:54:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:54:25 --> Config Class Initialized
INFO - 2021-05-15 16:54:25 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:54:25 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:54:25 --> Utf8 Class Initialized
INFO - 2021-05-15 16:54:25 --> URI Class Initialized
INFO - 2021-05-15 16:54:25 --> Router Class Initialized
INFO - 2021-05-15 16:54:25 --> Output Class Initialized
INFO - 2021-05-15 16:54:25 --> Security Class Initialized
DEBUG - 2021-05-15 16:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:54:25 --> Input Class Initialized
INFO - 2021-05-15 16:54:25 --> Language Class Initialized
ERROR - 2021-05-15 16:54:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:55:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:55:14 --> Config Class Initialized
INFO - 2021-05-15 16:55:14 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:55:14 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:55:14 --> Utf8 Class Initialized
INFO - 2021-05-15 16:55:14 --> URI Class Initialized
DEBUG - 2021-05-15 16:55:14 --> No URI present. Default controller set.
INFO - 2021-05-15 16:55:14 --> Router Class Initialized
INFO - 2021-05-15 16:55:14 --> Output Class Initialized
INFO - 2021-05-15 16:55:14 --> Security Class Initialized
DEBUG - 2021-05-15 16:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:55:14 --> Input Class Initialized
INFO - 2021-05-15 16:55:14 --> Language Class Initialized
INFO - 2021-05-15 16:55:14 --> Loader Class Initialized
INFO - 2021-05-15 16:55:14 --> Helper loaded: url_helper
INFO - 2021-05-15 16:55:14 --> Helper loaded: form_helper
INFO - 2021-05-15 16:55:14 --> Helper loaded: common_helper
INFO - 2021-05-15 16:55:14 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:55:14 --> Controller Class Initialized
INFO - 2021-05-15 16:55:14 --> Form Validation Class Initialized
DEBUG - 2021-05-15 16:55:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:55:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 16:55:14 --> Email Class Initialized
INFO - 2021-05-15 16:55:14 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 16:55:14 --> Calendar Class Initialized
INFO - 2021-05-15 16:55:14 --> Model "Login_model" initialized
INFO - 2021-05-15 16:55:14 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 16:55:14 --> Final output sent to browser
DEBUG - 2021-05-15 16:55:14 --> Total execution time: 0.0196
ERROR - 2021-05-15 16:55:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:55:16 --> Config Class Initialized
INFO - 2021-05-15 16:55:16 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:55:16 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:55:16 --> Utf8 Class Initialized
INFO - 2021-05-15 16:55:16 --> URI Class Initialized
INFO - 2021-05-15 16:55:16 --> Router Class Initialized
INFO - 2021-05-15 16:55:16 --> Output Class Initialized
INFO - 2021-05-15 16:55:16 --> Security Class Initialized
DEBUG - 2021-05-15 16:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:55:16 --> Input Class Initialized
INFO - 2021-05-15 16:55:16 --> Language Class Initialized
ERROR - 2021-05-15 16:55:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:55:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:55:41 --> Config Class Initialized
INFO - 2021-05-15 16:55:41 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:55:41 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:55:41 --> Utf8 Class Initialized
INFO - 2021-05-15 16:55:41 --> URI Class Initialized
DEBUG - 2021-05-15 16:55:41 --> No URI present. Default controller set.
INFO - 2021-05-15 16:55:41 --> Router Class Initialized
INFO - 2021-05-15 16:55:41 --> Output Class Initialized
INFO - 2021-05-15 16:55:41 --> Security Class Initialized
DEBUG - 2021-05-15 16:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:55:41 --> Input Class Initialized
INFO - 2021-05-15 16:55:41 --> Language Class Initialized
INFO - 2021-05-15 16:55:41 --> Loader Class Initialized
INFO - 2021-05-15 16:55:41 --> Helper loaded: url_helper
INFO - 2021-05-15 16:55:41 --> Helper loaded: form_helper
INFO - 2021-05-15 16:55:41 --> Helper loaded: common_helper
INFO - 2021-05-15 16:55:41 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:55:41 --> Controller Class Initialized
INFO - 2021-05-15 16:55:41 --> Form Validation Class Initialized
DEBUG - 2021-05-15 16:55:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:55:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 16:55:41 --> Email Class Initialized
INFO - 2021-05-15 16:55:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 16:55:41 --> Calendar Class Initialized
INFO - 2021-05-15 16:55:41 --> Model "Login_model" initialized
INFO - 2021-05-15 16:55:41 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 16:55:41 --> Final output sent to browser
DEBUG - 2021-05-15 16:55:41 --> Total execution time: 0.0214
ERROR - 2021-05-15 16:56:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:56:38 --> Config Class Initialized
INFO - 2021-05-15 16:56:38 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:56:38 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:56:38 --> Utf8 Class Initialized
INFO - 2021-05-15 16:56:38 --> URI Class Initialized
DEBUG - 2021-05-15 16:56:38 --> No URI present. Default controller set.
INFO - 2021-05-15 16:56:38 --> Router Class Initialized
INFO - 2021-05-15 16:56:38 --> Output Class Initialized
INFO - 2021-05-15 16:56:38 --> Security Class Initialized
DEBUG - 2021-05-15 16:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:56:38 --> Input Class Initialized
INFO - 2021-05-15 16:56:38 --> Language Class Initialized
INFO - 2021-05-15 16:56:38 --> Loader Class Initialized
INFO - 2021-05-15 16:56:38 --> Helper loaded: url_helper
INFO - 2021-05-15 16:56:38 --> Helper loaded: form_helper
INFO - 2021-05-15 16:56:38 --> Helper loaded: common_helper
INFO - 2021-05-15 16:56:38 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:56:38 --> Controller Class Initialized
INFO - 2021-05-15 16:56:38 --> Form Validation Class Initialized
DEBUG - 2021-05-15 16:56:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:56:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 16:56:38 --> Email Class Initialized
INFO - 2021-05-15 16:56:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 16:56:38 --> Calendar Class Initialized
INFO - 2021-05-15 16:56:38 --> Model "Login_model" initialized
INFO - 2021-05-15 16:56:38 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 16:56:38 --> Final output sent to browser
DEBUG - 2021-05-15 16:56:38 --> Total execution time: 0.0183
ERROR - 2021-05-15 16:56:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:56:40 --> Config Class Initialized
INFO - 2021-05-15 16:56:40 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:56:40 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:56:40 --> Utf8 Class Initialized
INFO - 2021-05-15 16:56:40 --> URI Class Initialized
INFO - 2021-05-15 16:56:40 --> Router Class Initialized
INFO - 2021-05-15 16:56:40 --> Output Class Initialized
INFO - 2021-05-15 16:56:40 --> Security Class Initialized
DEBUG - 2021-05-15 16:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:56:40 --> Input Class Initialized
INFO - 2021-05-15 16:56:40 --> Language Class Initialized
ERROR - 2021-05-15 16:56:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:59:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:59:22 --> Config Class Initialized
INFO - 2021-05-15 16:59:22 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:59:22 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:59:22 --> Utf8 Class Initialized
INFO - 2021-05-15 16:59:22 --> URI Class Initialized
DEBUG - 2021-05-15 16:59:22 --> No URI present. Default controller set.
INFO - 2021-05-15 16:59:22 --> Router Class Initialized
INFO - 2021-05-15 16:59:22 --> Output Class Initialized
INFO - 2021-05-15 16:59:22 --> Security Class Initialized
DEBUG - 2021-05-15 16:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:59:22 --> Input Class Initialized
INFO - 2021-05-15 16:59:22 --> Language Class Initialized
INFO - 2021-05-15 16:59:22 --> Loader Class Initialized
INFO - 2021-05-15 16:59:22 --> Helper loaded: url_helper
INFO - 2021-05-15 16:59:22 --> Helper loaded: form_helper
INFO - 2021-05-15 16:59:22 --> Helper loaded: common_helper
INFO - 2021-05-15 16:59:22 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:59:22 --> Controller Class Initialized
INFO - 2021-05-15 16:59:22 --> Form Validation Class Initialized
INFO - 2021-05-15 16:59:22 --> Email Class Initialized
DEBUG - 2021-05-15 16:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:59:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:59:22 --> Email class already loaded. Second attempt ignored.
INFO - 2021-05-15 16:59:22 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 16:59:22 --> Calendar Class Initialized
INFO - 2021-05-15 16:59:22 --> Model "Login_model" initialized
INFO - 2021-05-15 16:59:22 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 16:59:22 --> Final output sent to browser
DEBUG - 2021-05-15 16:59:22 --> Total execution time: 0.0181
ERROR - 2021-05-15 16:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:59:24 --> Config Class Initialized
INFO - 2021-05-15 16:59:24 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:59:24 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:59:24 --> Utf8 Class Initialized
INFO - 2021-05-15 16:59:24 --> URI Class Initialized
INFO - 2021-05-15 16:59:24 --> Router Class Initialized
INFO - 2021-05-15 16:59:24 --> Output Class Initialized
INFO - 2021-05-15 16:59:24 --> Security Class Initialized
DEBUG - 2021-05-15 16:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:59:24 --> Input Class Initialized
INFO - 2021-05-15 16:59:24 --> Language Class Initialized
ERROR - 2021-05-15 16:59:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:59:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:59:33 --> Config Class Initialized
INFO - 2021-05-15 16:59:33 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:59:33 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:59:33 --> Utf8 Class Initialized
INFO - 2021-05-15 16:59:33 --> URI Class Initialized
DEBUG - 2021-05-15 16:59:33 --> No URI present. Default controller set.
INFO - 2021-05-15 16:59:33 --> Router Class Initialized
INFO - 2021-05-15 16:59:33 --> Output Class Initialized
INFO - 2021-05-15 16:59:33 --> Security Class Initialized
DEBUG - 2021-05-15 16:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:59:33 --> Input Class Initialized
INFO - 2021-05-15 16:59:33 --> Language Class Initialized
INFO - 2021-05-15 16:59:33 --> Loader Class Initialized
INFO - 2021-05-15 16:59:33 --> Helper loaded: url_helper
INFO - 2021-05-15 16:59:33 --> Helper loaded: form_helper
INFO - 2021-05-15 16:59:33 --> Helper loaded: common_helper
INFO - 2021-05-15 16:59:33 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:59:33 --> Controller Class Initialized
INFO - 2021-05-15 16:59:33 --> Form Validation Class Initialized
DEBUG - 2021-05-15 16:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:59:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 16:59:33 --> Email Class Initialized
INFO - 2021-05-15 16:59:33 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 16:59:33 --> Calendar Class Initialized
INFO - 2021-05-15 16:59:33 --> Model "Login_model" initialized
INFO - 2021-05-15 16:59:33 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 16:59:33 --> Final output sent to browser
DEBUG - 2021-05-15 16:59:33 --> Total execution time: 0.0186
ERROR - 2021-05-15 16:59:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:59:34 --> Config Class Initialized
INFO - 2021-05-15 16:59:34 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:59:34 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:59:34 --> Utf8 Class Initialized
INFO - 2021-05-15 16:59:34 --> URI Class Initialized
INFO - 2021-05-15 16:59:34 --> Router Class Initialized
INFO - 2021-05-15 16:59:34 --> Output Class Initialized
INFO - 2021-05-15 16:59:34 --> Security Class Initialized
DEBUG - 2021-05-15 16:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:59:34 --> Input Class Initialized
INFO - 2021-05-15 16:59:34 --> Language Class Initialized
ERROR - 2021-05-15 16:59:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:59:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:59:38 --> Config Class Initialized
INFO - 2021-05-15 16:59:38 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:59:38 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:59:38 --> Utf8 Class Initialized
INFO - 2021-05-15 16:59:38 --> URI Class Initialized
INFO - 2021-05-15 16:59:38 --> Router Class Initialized
INFO - 2021-05-15 16:59:38 --> Output Class Initialized
INFO - 2021-05-15 16:59:38 --> Security Class Initialized
DEBUG - 2021-05-15 16:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:59:38 --> Input Class Initialized
INFO - 2021-05-15 16:59:38 --> Language Class Initialized
ERROR - 2021-05-15 16:59:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 16:59:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:59:49 --> Config Class Initialized
INFO - 2021-05-15 16:59:49 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:59:49 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:59:49 --> Utf8 Class Initialized
INFO - 2021-05-15 16:59:49 --> URI Class Initialized
DEBUG - 2021-05-15 16:59:49 --> No URI present. Default controller set.
INFO - 2021-05-15 16:59:49 --> Router Class Initialized
INFO - 2021-05-15 16:59:49 --> Output Class Initialized
INFO - 2021-05-15 16:59:49 --> Security Class Initialized
DEBUG - 2021-05-15 16:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:59:49 --> Input Class Initialized
INFO - 2021-05-15 16:59:49 --> Language Class Initialized
INFO - 2021-05-15 16:59:49 --> Loader Class Initialized
INFO - 2021-05-15 16:59:49 --> Helper loaded: url_helper
INFO - 2021-05-15 16:59:49 --> Helper loaded: form_helper
INFO - 2021-05-15 16:59:49 --> Helper loaded: common_helper
INFO - 2021-05-15 16:59:49 --> Database Driver Class Initialized
DEBUG - 2021-05-15 16:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 16:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 16:59:49 --> Controller Class Initialized
INFO - 2021-05-15 16:59:49 --> Form Validation Class Initialized
DEBUG - 2021-05-15 16:59:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 16:59:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 16:59:49 --> Email Class Initialized
INFO - 2021-05-15 16:59:49 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 16:59:49 --> Calendar Class Initialized
INFO - 2021-05-15 16:59:49 --> Model "Login_model" initialized
INFO - 2021-05-15 16:59:49 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 16:59:49 --> Final output sent to browser
DEBUG - 2021-05-15 16:59:49 --> Total execution time: 0.0202
ERROR - 2021-05-15 16:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 16:59:51 --> Config Class Initialized
INFO - 2021-05-15 16:59:51 --> Hooks Class Initialized
DEBUG - 2021-05-15 16:59:51 --> UTF-8 Support Enabled
INFO - 2021-05-15 16:59:51 --> Utf8 Class Initialized
INFO - 2021-05-15 16:59:51 --> URI Class Initialized
INFO - 2021-05-15 16:59:51 --> Router Class Initialized
INFO - 2021-05-15 16:59:51 --> Output Class Initialized
INFO - 2021-05-15 16:59:51 --> Security Class Initialized
DEBUG - 2021-05-15 16:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 16:59:51 --> Input Class Initialized
INFO - 2021-05-15 16:59:51 --> Language Class Initialized
ERROR - 2021-05-15 16:59:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 17:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:02:02 --> Config Class Initialized
INFO - 2021-05-15 17:02:02 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:02:02 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:02:02 --> Utf8 Class Initialized
INFO - 2021-05-15 17:02:02 --> URI Class Initialized
DEBUG - 2021-05-15 17:02:02 --> No URI present. Default controller set.
INFO - 2021-05-15 17:02:02 --> Router Class Initialized
INFO - 2021-05-15 17:02:02 --> Output Class Initialized
INFO - 2021-05-15 17:02:02 --> Security Class Initialized
DEBUG - 2021-05-15 17:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:02:02 --> Input Class Initialized
INFO - 2021-05-15 17:02:02 --> Language Class Initialized
INFO - 2021-05-15 17:02:02 --> Loader Class Initialized
INFO - 2021-05-15 17:02:02 --> Helper loaded: url_helper
INFO - 2021-05-15 17:02:02 --> Helper loaded: form_helper
INFO - 2021-05-15 17:02:02 --> Helper loaded: common_helper
INFO - 2021-05-15 17:02:02 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:02:02 --> Controller Class Initialized
INFO - 2021-05-15 17:02:02 --> Form Validation Class Initialized
DEBUG - 2021-05-15 17:02:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 17:02:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 17:02:02 --> Email Class Initialized
INFO - 2021-05-15 17:02:02 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 17:02:02 --> Calendar Class Initialized
INFO - 2021-05-15 17:02:02 --> Model "Login_model" initialized
INFO - 2021-05-15 17:02:02 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 17:02:02 --> Final output sent to browser
DEBUG - 2021-05-15 17:02:02 --> Total execution time: 0.0192
ERROR - 2021-05-15 17:02:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:02:11 --> Config Class Initialized
INFO - 2021-05-15 17:02:11 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:02:11 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:02:11 --> Utf8 Class Initialized
INFO - 2021-05-15 17:02:11 --> URI Class Initialized
DEBUG - 2021-05-15 17:02:11 --> No URI present. Default controller set.
INFO - 2021-05-15 17:02:11 --> Router Class Initialized
INFO - 2021-05-15 17:02:11 --> Output Class Initialized
INFO - 2021-05-15 17:02:11 --> Security Class Initialized
DEBUG - 2021-05-15 17:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:02:11 --> Input Class Initialized
INFO - 2021-05-15 17:02:11 --> Language Class Initialized
INFO - 2021-05-15 17:02:11 --> Loader Class Initialized
INFO - 2021-05-15 17:02:11 --> Helper loaded: url_helper
INFO - 2021-05-15 17:02:11 --> Helper loaded: form_helper
INFO - 2021-05-15 17:02:11 --> Helper loaded: common_helper
INFO - 2021-05-15 17:02:11 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:02:11 --> Controller Class Initialized
INFO - 2021-05-15 17:02:11 --> Form Validation Class Initialized
DEBUG - 2021-05-15 17:02:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 17:02:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 17:02:11 --> Email Class Initialized
INFO - 2021-05-15 17:02:11 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 17:02:11 --> Calendar Class Initialized
INFO - 2021-05-15 17:02:11 --> Model "Login_model" initialized
INFO - 2021-05-15 17:02:11 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 17:02:11 --> Final output sent to browser
DEBUG - 2021-05-15 17:02:11 --> Total execution time: 0.0195
ERROR - 2021-05-15 17:02:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:02:17 --> Config Class Initialized
INFO - 2021-05-15 17:02:17 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:02:17 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:02:17 --> Utf8 Class Initialized
INFO - 2021-05-15 17:02:17 --> URI Class Initialized
INFO - 2021-05-15 17:02:17 --> Router Class Initialized
INFO - 2021-05-15 17:02:17 --> Output Class Initialized
INFO - 2021-05-15 17:02:17 --> Security Class Initialized
DEBUG - 2021-05-15 17:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:02:17 --> Input Class Initialized
INFO - 2021-05-15 17:02:17 --> Language Class Initialized
ERROR - 2021-05-15 17:02:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 17:02:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:02:56 --> Config Class Initialized
INFO - 2021-05-15 17:02:56 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:02:56 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:02:56 --> Utf8 Class Initialized
INFO - 2021-05-15 17:02:56 --> URI Class Initialized
DEBUG - 2021-05-15 17:02:56 --> No URI present. Default controller set.
INFO - 2021-05-15 17:02:56 --> Router Class Initialized
INFO - 2021-05-15 17:02:56 --> Output Class Initialized
INFO - 2021-05-15 17:02:56 --> Security Class Initialized
DEBUG - 2021-05-15 17:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:02:56 --> Input Class Initialized
INFO - 2021-05-15 17:02:56 --> Language Class Initialized
INFO - 2021-05-15 17:02:56 --> Loader Class Initialized
INFO - 2021-05-15 17:02:56 --> Helper loaded: url_helper
INFO - 2021-05-15 17:02:56 --> Helper loaded: form_helper
INFO - 2021-05-15 17:02:56 --> Helper loaded: common_helper
INFO - 2021-05-15 17:02:56 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:02:56 --> Controller Class Initialized
INFO - 2021-05-15 17:02:56 --> Form Validation Class Initialized
ERROR - 2021-05-15 17:02:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:02:57 --> Config Class Initialized
INFO - 2021-05-15 17:02:57 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:02:57 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:02:57 --> Utf8 Class Initialized
INFO - 2021-05-15 17:02:57 --> URI Class Initialized
INFO - 2021-05-15 17:02:57 --> Router Class Initialized
INFO - 2021-05-15 17:02:57 --> Output Class Initialized
INFO - 2021-05-15 17:02:57 --> Security Class Initialized
DEBUG - 2021-05-15 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:02:57 --> Input Class Initialized
INFO - 2021-05-15 17:02:57 --> Language Class Initialized
ERROR - 2021-05-15 17:02:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 17:03:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:03:08 --> Config Class Initialized
INFO - 2021-05-15 17:03:08 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:03:08 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:03:08 --> Utf8 Class Initialized
INFO - 2021-05-15 17:03:08 --> URI Class Initialized
DEBUG - 2021-05-15 17:03:08 --> No URI present. Default controller set.
INFO - 2021-05-15 17:03:08 --> Router Class Initialized
INFO - 2021-05-15 17:03:08 --> Output Class Initialized
INFO - 2021-05-15 17:03:08 --> Security Class Initialized
DEBUG - 2021-05-15 17:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:03:08 --> Input Class Initialized
INFO - 2021-05-15 17:03:08 --> Language Class Initialized
INFO - 2021-05-15 17:03:08 --> Loader Class Initialized
INFO - 2021-05-15 17:03:08 --> Helper loaded: url_helper
INFO - 2021-05-15 17:03:08 --> Helper loaded: form_helper
INFO - 2021-05-15 17:03:08 --> Helper loaded: common_helper
INFO - 2021-05-15 17:03:08 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:03:08 --> Controller Class Initialized
INFO - 2021-05-15 17:03:08 --> Form Validation Class Initialized
DEBUG - 2021-05-15 17:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 17:03:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 17:03:08 --> Email Class Initialized
INFO - 2021-05-15 17:03:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 17:03:08 --> Calendar Class Initialized
INFO - 2021-05-15 17:03:08 --> Model "Login_model" initialized
INFO - 2021-05-15 17:03:08 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 17:03:08 --> Final output sent to browser
DEBUG - 2021-05-15 17:03:08 --> Total execution time: 0.0196
ERROR - 2021-05-15 17:11:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:11:30 --> Config Class Initialized
INFO - 2021-05-15 17:11:30 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:11:30 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:11:30 --> Utf8 Class Initialized
INFO - 2021-05-15 17:11:30 --> URI Class Initialized
INFO - 2021-05-15 17:11:30 --> Router Class Initialized
INFO - 2021-05-15 17:11:30 --> Output Class Initialized
INFO - 2021-05-15 17:11:30 --> Security Class Initialized
DEBUG - 2021-05-15 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:11:30 --> Input Class Initialized
INFO - 2021-05-15 17:11:30 --> Language Class Initialized
ERROR - 2021-05-15 17:11:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 17:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:11:53 --> Config Class Initialized
INFO - 2021-05-15 17:11:53 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:11:53 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:11:53 --> Utf8 Class Initialized
INFO - 2021-05-15 17:11:53 --> URI Class Initialized
DEBUG - 2021-05-15 17:11:53 --> No URI present. Default controller set.
INFO - 2021-05-15 17:11:53 --> Router Class Initialized
INFO - 2021-05-15 17:11:53 --> Output Class Initialized
INFO - 2021-05-15 17:11:53 --> Security Class Initialized
DEBUG - 2021-05-15 17:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:11:53 --> Input Class Initialized
INFO - 2021-05-15 17:11:53 --> Language Class Initialized
INFO - 2021-05-15 17:11:53 --> Loader Class Initialized
INFO - 2021-05-15 17:11:53 --> Helper loaded: url_helper
INFO - 2021-05-15 17:11:53 --> Helper loaded: form_helper
INFO - 2021-05-15 17:11:53 --> Helper loaded: common_helper
INFO - 2021-05-15 17:11:53 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:11:53 --> Controller Class Initialized
INFO - 2021-05-15 17:11:53 --> Form Validation Class Initialized
DEBUG - 2021-05-15 17:11:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 17:11:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 17:11:53 --> Email Class Initialized
INFO - 2021-05-15 17:11:53 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 17:11:53 --> Calendar Class Initialized
INFO - 2021-05-15 17:11:53 --> Model "Login_model" initialized
INFO - 2021-05-15 17:11:53 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 17:11:53 --> Final output sent to browser
DEBUG - 2021-05-15 17:11:53 --> Total execution time: 0.0189
ERROR - 2021-05-15 17:12:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:12:10 --> Config Class Initialized
INFO - 2021-05-15 17:12:10 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:12:10 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:12:10 --> Utf8 Class Initialized
INFO - 2021-05-15 17:12:10 --> URI Class Initialized
INFO - 2021-05-15 17:12:10 --> Router Class Initialized
INFO - 2021-05-15 17:12:10 --> Output Class Initialized
INFO - 2021-05-15 17:12:10 --> Security Class Initialized
DEBUG - 2021-05-15 17:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:12:10 --> Input Class Initialized
INFO - 2021-05-15 17:12:10 --> Language Class Initialized
INFO - 2021-05-15 17:12:10 --> Loader Class Initialized
INFO - 2021-05-15 17:12:10 --> Helper loaded: url_helper
INFO - 2021-05-15 17:12:10 --> Helper loaded: form_helper
INFO - 2021-05-15 17:12:10 --> Helper loaded: common_helper
INFO - 2021-05-15 17:12:10 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:12:10 --> Controller Class Initialized
INFO - 2021-05-15 17:12:10 --> Form Validation Class Initialized
DEBUG - 2021-05-15 17:12:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 17:12:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 17:12:10 --> Email Class Initialized
INFO - 2021-05-15 17:12:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 17:12:10 --> Calendar Class Initialized
INFO - 2021-05-15 17:12:10 --> Model "Login_model" initialized
INFO - 2021-05-15 17:12:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-05-15 17:12:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:12:11 --> Config Class Initialized
INFO - 2021-05-15 17:12:11 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:12:11 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:12:11 --> Utf8 Class Initialized
INFO - 2021-05-15 17:12:11 --> URI Class Initialized
INFO - 2021-05-15 17:12:11 --> Router Class Initialized
INFO - 2021-05-15 17:12:11 --> Output Class Initialized
INFO - 2021-05-15 17:12:11 --> Security Class Initialized
DEBUG - 2021-05-15 17:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:12:11 --> Input Class Initialized
INFO - 2021-05-15 17:12:11 --> Language Class Initialized
INFO - 2021-05-15 17:12:11 --> Loader Class Initialized
INFO - 2021-05-15 17:12:11 --> Helper loaded: url_helper
INFO - 2021-05-15 17:12:11 --> Helper loaded: form_helper
INFO - 2021-05-15 17:12:11 --> Helper loaded: common_helper
INFO - 2021-05-15 17:12:11 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:12:11 --> Controller Class Initialized
INFO - 2021-05-15 17:12:11 --> Form Validation Class Initialized
ERROR - 2021-05-15 17:14:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:14:53 --> Config Class Initialized
INFO - 2021-05-15 17:14:53 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:14:53 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:14:53 --> Utf8 Class Initialized
INFO - 2021-05-15 17:14:53 --> URI Class Initialized
INFO - 2021-05-15 17:14:53 --> Router Class Initialized
INFO - 2021-05-15 17:14:53 --> Output Class Initialized
INFO - 2021-05-15 17:14:53 --> Security Class Initialized
DEBUG - 2021-05-15 17:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:14:53 --> Input Class Initialized
INFO - 2021-05-15 17:14:53 --> Language Class Initialized
INFO - 2021-05-15 17:14:53 --> Loader Class Initialized
INFO - 2021-05-15 17:14:53 --> Helper loaded: url_helper
INFO - 2021-05-15 17:14:53 --> Helper loaded: form_helper
INFO - 2021-05-15 17:14:53 --> Helper loaded: common_helper
INFO - 2021-05-15 17:14:53 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:14:53 --> Controller Class Initialized
INFO - 2021-05-15 17:14:53 --> Form Validation Class Initialized
DEBUG - 2021-05-15 17:14:53 --> Encrypt Class Initialized
INFO - 2021-05-15 17:14:53 --> Model "Login_model" initialized
INFO - 2021-05-15 17:14:53 --> Model "Dashboard_model" initialized
INFO - 2021-05-15 17:14:53 --> Model "Case_model" initialized
INFO - 2021-05-15 17:14:56 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 17:15:02 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-05-15 17:15:02 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 17:15:02 --> Final output sent to browser
DEBUG - 2021-05-15 17:15:02 --> Total execution time: 9.8102
ERROR - 2021-05-15 17:15:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:15:03 --> Config Class Initialized
INFO - 2021-05-15 17:15:03 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:15:03 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:15:03 --> Utf8 Class Initialized
INFO - 2021-05-15 17:15:03 --> URI Class Initialized
INFO - 2021-05-15 17:15:03 --> Router Class Initialized
INFO - 2021-05-15 17:15:03 --> Output Class Initialized
INFO - 2021-05-15 17:15:03 --> Security Class Initialized
DEBUG - 2021-05-15 17:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:15:03 --> Input Class Initialized
INFO - 2021-05-15 17:15:03 --> Language Class Initialized
ERROR - 2021-05-15 17:15:03 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 17:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:16:01 --> Config Class Initialized
INFO - 2021-05-15 17:16:01 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:16:01 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:16:01 --> Utf8 Class Initialized
INFO - 2021-05-15 17:16:01 --> URI Class Initialized
INFO - 2021-05-15 17:16:01 --> Router Class Initialized
INFO - 2021-05-15 17:16:01 --> Output Class Initialized
INFO - 2021-05-15 17:16:01 --> Security Class Initialized
DEBUG - 2021-05-15 17:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:16:01 --> Input Class Initialized
INFO - 2021-05-15 17:16:01 --> Language Class Initialized
INFO - 2021-05-15 17:16:01 --> Loader Class Initialized
INFO - 2021-05-15 17:16:01 --> Helper loaded: url_helper
INFO - 2021-05-15 17:16:01 --> Helper loaded: form_helper
INFO - 2021-05-15 17:16:01 --> Helper loaded: common_helper
INFO - 2021-05-15 17:16:01 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:16:01 --> Controller Class Initialized
INFO - 2021-05-15 17:16:01 --> Form Validation Class Initialized
ERROR - 2021-05-15 17:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:16:01 --> Config Class Initialized
INFO - 2021-05-15 17:16:01 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:16:01 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:16:01 --> Utf8 Class Initialized
INFO - 2021-05-15 17:16:01 --> URI Class Initialized
INFO - 2021-05-15 17:16:01 --> Router Class Initialized
INFO - 2021-05-15 17:16:01 --> Output Class Initialized
INFO - 2021-05-15 17:16:01 --> Security Class Initialized
DEBUG - 2021-05-15 17:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:16:01 --> Input Class Initialized
INFO - 2021-05-15 17:16:01 --> Language Class Initialized
ERROR - 2021-05-15 17:16:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 17:16:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:16:14 --> Config Class Initialized
INFO - 2021-05-15 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:16:14 --> Utf8 Class Initialized
INFO - 2021-05-15 17:16:14 --> URI Class Initialized
INFO - 2021-05-15 17:16:14 --> Router Class Initialized
INFO - 2021-05-15 17:16:14 --> Output Class Initialized
INFO - 2021-05-15 17:16:14 --> Security Class Initialized
DEBUG - 2021-05-15 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:16:14 --> Input Class Initialized
INFO - 2021-05-15 17:16:14 --> Language Class Initialized
INFO - 2021-05-15 17:16:14 --> Loader Class Initialized
INFO - 2021-05-15 17:16:14 --> Helper loaded: url_helper
INFO - 2021-05-15 17:16:14 --> Helper loaded: form_helper
INFO - 2021-05-15 17:16:14 --> Helper loaded: common_helper
INFO - 2021-05-15 17:16:14 --> Database Driver Class Initialized
DEBUG - 2021-05-15 17:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 17:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 17:16:14 --> Controller Class Initialized
INFO - 2021-05-15 17:16:14 --> Form Validation Class Initialized
DEBUG - 2021-05-15 17:16:14 --> Encrypt Class Initialized
INFO - 2021-05-15 17:16:14 --> Model "Login_model" initialized
INFO - 2021-05-15 17:16:14 --> Model "Dashboard_model" initialized
INFO - 2021-05-15 17:16:14 --> Model "Case_model" initialized
INFO - 2021-05-15 17:16:17 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 17:16:23 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-05-15 17:16:23 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 17:16:23 --> Final output sent to browser
DEBUG - 2021-05-15 17:16:23 --> Total execution time: 9.1915
ERROR - 2021-05-15 17:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 17:16:25 --> Config Class Initialized
INFO - 2021-05-15 17:16:25 --> Hooks Class Initialized
DEBUG - 2021-05-15 17:16:25 --> UTF-8 Support Enabled
INFO - 2021-05-15 17:16:25 --> Utf8 Class Initialized
INFO - 2021-05-15 17:16:25 --> URI Class Initialized
INFO - 2021-05-15 17:16:25 --> Router Class Initialized
INFO - 2021-05-15 17:16:25 --> Output Class Initialized
INFO - 2021-05-15 17:16:25 --> Security Class Initialized
DEBUG - 2021-05-15 17:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 17:16:25 --> Input Class Initialized
INFO - 2021-05-15 17:16:25 --> Language Class Initialized
ERROR - 2021-05-15 17:16:25 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:16:23 --> Config Class Initialized
INFO - 2021-05-15 18:16:23 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:16:23 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:16:23 --> Utf8 Class Initialized
INFO - 2021-05-15 18:16:23 --> URI Class Initialized
DEBUG - 2021-05-15 18:16:23 --> No URI present. Default controller set.
INFO - 2021-05-15 18:16:23 --> Router Class Initialized
INFO - 2021-05-15 18:16:23 --> Output Class Initialized
INFO - 2021-05-15 18:16:23 --> Security Class Initialized
DEBUG - 2021-05-15 18:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:16:23 --> Input Class Initialized
INFO - 2021-05-15 18:16:23 --> Language Class Initialized
ERROR - 2021-05-15 18:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:16:24 --> Config Class Initialized
INFO - 2021-05-15 18:16:24 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:16:24 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:16:24 --> Utf8 Class Initialized
INFO - 2021-05-15 18:16:24 --> URI Class Initialized
INFO - 2021-05-15 18:16:24 --> Router Class Initialized
INFO - 2021-05-15 18:16:24 --> Output Class Initialized
INFO - 2021-05-15 18:16:24 --> Security Class Initialized
DEBUG - 2021-05-15 18:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:16:24 --> Input Class Initialized
INFO - 2021-05-15 18:16:24 --> Language Class Initialized
ERROR - 2021-05-15 18:16:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 18:16:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:16:44 --> Config Class Initialized
INFO - 2021-05-15 18:16:44 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:16:44 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:16:44 --> Utf8 Class Initialized
INFO - 2021-05-15 18:16:44 --> URI Class Initialized
DEBUG - 2021-05-15 18:16:44 --> No URI present. Default controller set.
INFO - 2021-05-15 18:16:44 --> Router Class Initialized
INFO - 2021-05-15 18:16:44 --> Output Class Initialized
INFO - 2021-05-15 18:16:44 --> Security Class Initialized
DEBUG - 2021-05-15 18:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:16:44 --> Input Class Initialized
INFO - 2021-05-15 18:16:44 --> Language Class Initialized
ERROR - 2021-05-15 18:16:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:16:55 --> Config Class Initialized
INFO - 2021-05-15 18:16:55 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:16:55 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:16:55 --> Utf8 Class Initialized
INFO - 2021-05-15 18:16:55 --> URI Class Initialized
DEBUG - 2021-05-15 18:16:55 --> No URI present. Default controller set.
INFO - 2021-05-15 18:16:55 --> Router Class Initialized
INFO - 2021-05-15 18:16:55 --> Output Class Initialized
INFO - 2021-05-15 18:16:55 --> Security Class Initialized
DEBUG - 2021-05-15 18:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:16:55 --> Input Class Initialized
INFO - 2021-05-15 18:16:55 --> Language Class Initialized
ERROR - 2021-05-15 18:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:17:44 --> Config Class Initialized
INFO - 2021-05-15 18:17:44 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:17:44 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:17:44 --> Utf8 Class Initialized
INFO - 2021-05-15 18:17:44 --> URI Class Initialized
DEBUG - 2021-05-15 18:17:44 --> No URI present. Default controller set.
INFO - 2021-05-15 18:17:44 --> Router Class Initialized
INFO - 2021-05-15 18:17:44 --> Output Class Initialized
INFO - 2021-05-15 18:17:44 --> Security Class Initialized
DEBUG - 2021-05-15 18:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:17:44 --> Input Class Initialized
INFO - 2021-05-15 18:17:44 --> Language Class Initialized
ERROR - 2021-05-15 18:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:18:01 --> Config Class Initialized
INFO - 2021-05-15 18:18:01 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:18:01 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:18:01 --> Utf8 Class Initialized
INFO - 2021-05-15 18:18:01 --> URI Class Initialized
DEBUG - 2021-05-15 18:18:01 --> No URI present. Default controller set.
INFO - 2021-05-15 18:18:01 --> Router Class Initialized
INFO - 2021-05-15 18:18:01 --> Output Class Initialized
INFO - 2021-05-15 18:18:01 --> Security Class Initialized
DEBUG - 2021-05-15 18:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:18:01 --> Input Class Initialized
INFO - 2021-05-15 18:18:01 --> Language Class Initialized
ERROR - 2021-05-15 18:18:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:18:02 --> Config Class Initialized
INFO - 2021-05-15 18:18:02 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:18:02 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:18:02 --> Utf8 Class Initialized
INFO - 2021-05-15 18:18:02 --> URI Class Initialized
INFO - 2021-05-15 18:18:02 --> Router Class Initialized
INFO - 2021-05-15 18:18:02 --> Output Class Initialized
INFO - 2021-05-15 18:18:02 --> Security Class Initialized
DEBUG - 2021-05-15 18:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:18:02 --> Input Class Initialized
INFO - 2021-05-15 18:18:02 --> Language Class Initialized
ERROR - 2021-05-15 18:18:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 18:18:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:18:09 --> Config Class Initialized
INFO - 2021-05-15 18:18:09 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:18:09 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:18:09 --> Utf8 Class Initialized
INFO - 2021-05-15 18:18:09 --> URI Class Initialized
DEBUG - 2021-05-15 18:18:09 --> No URI present. Default controller set.
INFO - 2021-05-15 18:18:09 --> Router Class Initialized
INFO - 2021-05-15 18:18:09 --> Output Class Initialized
INFO - 2021-05-15 18:18:09 --> Security Class Initialized
DEBUG - 2021-05-15 18:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:18:09 --> Input Class Initialized
INFO - 2021-05-15 18:18:09 --> Language Class Initialized
ERROR - 2021-05-15 18:18:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:18:40 --> Config Class Initialized
INFO - 2021-05-15 18:18:40 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:18:40 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:18:40 --> Utf8 Class Initialized
INFO - 2021-05-15 18:18:40 --> URI Class Initialized
DEBUG - 2021-05-15 18:18:40 --> No URI present. Default controller set.
INFO - 2021-05-15 18:18:40 --> Router Class Initialized
INFO - 2021-05-15 18:18:40 --> Output Class Initialized
INFO - 2021-05-15 18:18:40 --> Security Class Initialized
DEBUG - 2021-05-15 18:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:18:40 --> Input Class Initialized
INFO - 2021-05-15 18:18:40 --> Language Class Initialized
ERROR - 2021-05-15 18:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:18:41 --> Config Class Initialized
INFO - 2021-05-15 18:18:41 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:18:41 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:18:41 --> Utf8 Class Initialized
INFO - 2021-05-15 18:18:41 --> URI Class Initialized
INFO - 2021-05-15 18:18:41 --> Router Class Initialized
INFO - 2021-05-15 18:18:41 --> Output Class Initialized
INFO - 2021-05-15 18:18:41 --> Security Class Initialized
DEBUG - 2021-05-15 18:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:18:41 --> Input Class Initialized
INFO - 2021-05-15 18:18:41 --> Language Class Initialized
ERROR - 2021-05-15 18:18:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 18:18:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:18:51 --> Config Class Initialized
INFO - 2021-05-15 18:18:51 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:18:51 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:18:51 --> Utf8 Class Initialized
INFO - 2021-05-15 18:18:51 --> URI Class Initialized
DEBUG - 2021-05-15 18:18:51 --> No URI present. Default controller set.
INFO - 2021-05-15 18:18:51 --> Router Class Initialized
INFO - 2021-05-15 18:18:51 --> Output Class Initialized
INFO - 2021-05-15 18:18:51 --> Security Class Initialized
DEBUG - 2021-05-15 18:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:18:51 --> Input Class Initialized
INFO - 2021-05-15 18:18:51 --> Language Class Initialized
ERROR - 2021-05-15 18:19:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:19:35 --> Config Class Initialized
INFO - 2021-05-15 18:19:35 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:19:35 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:19:35 --> Utf8 Class Initialized
INFO - 2021-05-15 18:19:35 --> URI Class Initialized
DEBUG - 2021-05-15 18:19:35 --> No URI present. Default controller set.
INFO - 2021-05-15 18:19:35 --> Router Class Initialized
INFO - 2021-05-15 18:19:35 --> Output Class Initialized
INFO - 2021-05-15 18:19:35 --> Security Class Initialized
DEBUG - 2021-05-15 18:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:19:35 --> Input Class Initialized
INFO - 2021-05-15 18:19:35 --> Language Class Initialized
INFO - 2021-05-15 18:19:35 --> Loader Class Initialized
INFO - 2021-05-15 18:19:35 --> Helper loaded: url_helper
INFO - 2021-05-15 18:19:35 --> Helper loaded: form_helper
INFO - 2021-05-15 18:19:35 --> Helper loaded: common_helper
INFO - 2021-05-15 18:19:35 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:19:35 --> Controller Class Initialized
INFO - 2021-05-15 18:19:35 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:19:35 --> Encrypt Class Initialized
DEBUG - 2021-05-15 18:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 18:19:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 18:19:35 --> Email Class Initialized
INFO - 2021-05-15 18:19:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 18:19:35 --> Calendar Class Initialized
INFO - 2021-05-15 18:19:35 --> Model "Login_model" initialized
ERROR - 2021-05-15 18:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:19:36 --> Config Class Initialized
INFO - 2021-05-15 18:19:36 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:19:36 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:19:36 --> Utf8 Class Initialized
INFO - 2021-05-15 18:19:36 --> URI Class Initialized
INFO - 2021-05-15 18:19:36 --> Router Class Initialized
INFO - 2021-05-15 18:19:36 --> Output Class Initialized
INFO - 2021-05-15 18:19:36 --> Security Class Initialized
DEBUG - 2021-05-15 18:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:19:36 --> Input Class Initialized
INFO - 2021-05-15 18:19:36 --> Language Class Initialized
INFO - 2021-05-15 18:19:36 --> Loader Class Initialized
INFO - 2021-05-15 18:19:36 --> Helper loaded: url_helper
INFO - 2021-05-15 18:19:36 --> Helper loaded: form_helper
INFO - 2021-05-15 18:19:36 --> Helper loaded: common_helper
INFO - 2021-05-15 18:19:36 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:19:36 --> Controller Class Initialized
INFO - 2021-05-15 18:19:36 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:19:36 --> Encrypt Class Initialized
INFO - 2021-05-15 18:19:36 --> Model "Diseases_model" initialized
INFO - 2021-05-15 18:19:36 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:19:36 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/diseases/index.php
INFO - 2021-05-15 18:19:36 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 18:19:36 --> Final output sent to browser
DEBUG - 2021-05-15 18:19:36 --> Total execution time: 0.0199
ERROR - 2021-05-15 18:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:19:37 --> Config Class Initialized
INFO - 2021-05-15 18:19:37 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:19:37 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:19:37 --> Utf8 Class Initialized
INFO - 2021-05-15 18:19:37 --> URI Class Initialized
INFO - 2021-05-15 18:19:37 --> Router Class Initialized
INFO - 2021-05-15 18:19:37 --> Output Class Initialized
INFO - 2021-05-15 18:19:37 --> Security Class Initialized
DEBUG - 2021-05-15 18:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:19:37 --> Input Class Initialized
INFO - 2021-05-15 18:19:37 --> Language Class Initialized
ERROR - 2021-05-15 18:19:37 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:20:50 --> Config Class Initialized
INFO - 2021-05-15 18:20:50 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:20:50 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:20:50 --> Utf8 Class Initialized
INFO - 2021-05-15 18:20:50 --> URI Class Initialized
INFO - 2021-05-15 18:20:50 --> Router Class Initialized
INFO - 2021-05-15 18:20:50 --> Output Class Initialized
INFO - 2021-05-15 18:20:50 --> Security Class Initialized
DEBUG - 2021-05-15 18:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:20:50 --> Input Class Initialized
INFO - 2021-05-15 18:20:50 --> Language Class Initialized
INFO - 2021-05-15 18:20:50 --> Loader Class Initialized
INFO - 2021-05-15 18:20:50 --> Helper loaded: url_helper
INFO - 2021-05-15 18:20:50 --> Helper loaded: form_helper
INFO - 2021-05-15 18:20:50 --> Helper loaded: common_helper
INFO - 2021-05-15 18:20:50 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:20:50 --> Controller Class Initialized
INFO - 2021-05-15 18:20:50 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:20:50 --> Encrypt Class Initialized
INFO - 2021-05-15 18:20:50 --> Model "Diseases_model" initialized
INFO - 2021-05-15 18:20:50 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:20:50 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/diseases/index.php
INFO - 2021-05-15 18:20:50 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 18:20:50 --> Final output sent to browser
DEBUG - 2021-05-15 18:20:50 --> Total execution time: 0.0187
ERROR - 2021-05-15 18:20:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:20:52 --> Config Class Initialized
INFO - 2021-05-15 18:20:52 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:20:52 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:20:52 --> Utf8 Class Initialized
INFO - 2021-05-15 18:20:52 --> URI Class Initialized
INFO - 2021-05-15 18:20:52 --> Router Class Initialized
INFO - 2021-05-15 18:20:52 --> Output Class Initialized
INFO - 2021-05-15 18:20:52 --> Security Class Initialized
DEBUG - 2021-05-15 18:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:20:52 --> Input Class Initialized
INFO - 2021-05-15 18:20:52 --> Language Class Initialized
ERROR - 2021-05-15 18:20:52 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:20:57 --> Config Class Initialized
INFO - 2021-05-15 18:20:57 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:20:57 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:20:57 --> Utf8 Class Initialized
INFO - 2021-05-15 18:20:57 --> URI Class Initialized
INFO - 2021-05-15 18:20:57 --> Router Class Initialized
INFO - 2021-05-15 18:20:57 --> Output Class Initialized
INFO - 2021-05-15 18:20:57 --> Security Class Initialized
DEBUG - 2021-05-15 18:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:20:57 --> Input Class Initialized
INFO - 2021-05-15 18:20:57 --> Language Class Initialized
ERROR - 2021-05-15 18:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:20:57 --> Config Class Initialized
INFO - 2021-05-15 18:20:57 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:20:57 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:20:57 --> Utf8 Class Initialized
INFO - 2021-05-15 18:20:57 --> URI Class Initialized
INFO - 2021-05-15 18:20:57 --> Router Class Initialized
INFO - 2021-05-15 18:20:57 --> Output Class Initialized
INFO - 2021-05-15 18:20:57 --> Security Class Initialized
DEBUG - 2021-05-15 18:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:20:57 --> Input Class Initialized
INFO - 2021-05-15 18:20:57 --> Language Class Initialized
ERROR - 2021-05-15 18:20:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 18:21:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:21:04 --> Config Class Initialized
INFO - 2021-05-15 18:21:04 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:21:04 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:21:04 --> Utf8 Class Initialized
INFO - 2021-05-15 18:21:04 --> URI Class Initialized
DEBUG - 2021-05-15 18:21:04 --> No URI present. Default controller set.
INFO - 2021-05-15 18:21:04 --> Router Class Initialized
INFO - 2021-05-15 18:21:04 --> Output Class Initialized
INFO - 2021-05-15 18:21:04 --> Security Class Initialized
DEBUG - 2021-05-15 18:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:21:04 --> Input Class Initialized
INFO - 2021-05-15 18:21:04 --> Language Class Initialized
ERROR - 2021-05-15 18:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:21:08 --> Config Class Initialized
INFO - 2021-05-15 18:21:08 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:21:08 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:21:08 --> Utf8 Class Initialized
INFO - 2021-05-15 18:21:08 --> URI Class Initialized
DEBUG - 2021-05-15 18:21:08 --> No URI present. Default controller set.
INFO - 2021-05-15 18:21:08 --> Router Class Initialized
INFO - 2021-05-15 18:21:08 --> Output Class Initialized
INFO - 2021-05-15 18:21:08 --> Security Class Initialized
DEBUG - 2021-05-15 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:21:08 --> Input Class Initialized
INFO - 2021-05-15 18:21:08 --> Language Class Initialized
ERROR - 2021-05-15 18:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:21:09 --> Config Class Initialized
INFO - 2021-05-15 18:21:09 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:21:09 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:21:09 --> Utf8 Class Initialized
INFO - 2021-05-15 18:21:09 --> URI Class Initialized
INFO - 2021-05-15 18:21:09 --> Router Class Initialized
INFO - 2021-05-15 18:21:09 --> Output Class Initialized
INFO - 2021-05-15 18:21:09 --> Security Class Initialized
DEBUG - 2021-05-15 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:21:09 --> Input Class Initialized
INFO - 2021-05-15 18:21:09 --> Language Class Initialized
ERROR - 2021-05-15 18:21:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 18:23:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:23:05 --> Config Class Initialized
INFO - 2021-05-15 18:23:05 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:23:05 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:23:05 --> Utf8 Class Initialized
INFO - 2021-05-15 18:23:05 --> URI Class Initialized
DEBUG - 2021-05-15 18:23:05 --> No URI present. Default controller set.
INFO - 2021-05-15 18:23:05 --> Router Class Initialized
INFO - 2021-05-15 18:23:05 --> Output Class Initialized
INFO - 2021-05-15 18:23:05 --> Security Class Initialized
DEBUG - 2021-05-15 18:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:23:05 --> Input Class Initialized
INFO - 2021-05-15 18:23:05 --> Language Class Initialized
INFO - 2021-05-15 18:23:05 --> Loader Class Initialized
INFO - 2021-05-15 18:23:05 --> Helper loaded: url_helper
INFO - 2021-05-15 18:23:05 --> Helper loaded: form_helper
INFO - 2021-05-15 18:23:05 --> Helper loaded: common_helper
INFO - 2021-05-15 18:23:05 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:23:05 --> Controller Class Initialized
INFO - 2021-05-15 18:23:05 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:23:05 --> Encrypt Class Initialized
DEBUG - 2021-05-15 18:23:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 18:23:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 18:23:05 --> Email Class Initialized
INFO - 2021-05-15 18:23:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 18:23:05 --> Calendar Class Initialized
INFO - 2021-05-15 18:23:05 --> Model "Login_model" initialized
ERROR - 2021-05-15 18:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:23:06 --> Config Class Initialized
INFO - 2021-05-15 18:23:06 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:23:06 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:23:06 --> Utf8 Class Initialized
INFO - 2021-05-15 18:23:06 --> URI Class Initialized
INFO - 2021-05-15 18:23:06 --> Router Class Initialized
INFO - 2021-05-15 18:23:06 --> Output Class Initialized
INFO - 2021-05-15 18:23:06 --> Security Class Initialized
DEBUG - 2021-05-15 18:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:23:06 --> Input Class Initialized
INFO - 2021-05-15 18:23:06 --> Language Class Initialized
INFO - 2021-05-15 18:23:06 --> Loader Class Initialized
INFO - 2021-05-15 18:23:06 --> Helper loaded: url_helper
INFO - 2021-05-15 18:23:06 --> Helper loaded: form_helper
INFO - 2021-05-15 18:23:06 --> Helper loaded: common_helper
INFO - 2021-05-15 18:23:06 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:23:06 --> Controller Class Initialized
INFO - 2021-05-15 18:23:06 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:23:06 --> Encrypt Class Initialized
INFO - 2021-05-15 18:23:06 --> Model "Diseases_model" initialized
INFO - 2021-05-15 18:23:06 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:23:06 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/diseases/index.php
INFO - 2021-05-15 18:23:06 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 18:23:06 --> Final output sent to browser
DEBUG - 2021-05-15 18:23:06 --> Total execution time: 0.0191
ERROR - 2021-05-15 18:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:23:08 --> Config Class Initialized
INFO - 2021-05-15 18:23:08 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:23:08 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:23:08 --> Utf8 Class Initialized
INFO - 2021-05-15 18:23:08 --> URI Class Initialized
INFO - 2021-05-15 18:23:08 --> Router Class Initialized
INFO - 2021-05-15 18:23:08 --> Output Class Initialized
INFO - 2021-05-15 18:23:08 --> Security Class Initialized
DEBUG - 2021-05-15 18:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:23:08 --> Input Class Initialized
INFO - 2021-05-15 18:23:08 --> Language Class Initialized
ERROR - 2021-05-15 18:23:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:23:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:23:11 --> Config Class Initialized
INFO - 2021-05-15 18:23:11 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:23:11 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:23:11 --> Utf8 Class Initialized
INFO - 2021-05-15 18:23:11 --> URI Class Initialized
INFO - 2021-05-15 18:23:11 --> Router Class Initialized
INFO - 2021-05-15 18:23:11 --> Output Class Initialized
INFO - 2021-05-15 18:23:11 --> Security Class Initialized
DEBUG - 2021-05-15 18:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:23:11 --> Input Class Initialized
INFO - 2021-05-15 18:23:11 --> Language Class Initialized
INFO - 2021-05-15 18:23:11 --> Loader Class Initialized
INFO - 2021-05-15 18:23:11 --> Helper loaded: url_helper
INFO - 2021-05-15 18:23:11 --> Helper loaded: form_helper
INFO - 2021-05-15 18:23:11 --> Helper loaded: common_helper
INFO - 2021-05-15 18:23:11 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:23:11 --> Controller Class Initialized
INFO - 2021-05-15 18:23:11 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:23:11 --> Encrypt Class Initialized
INFO - 2021-05-15 18:23:11 --> Model "Login_model" initialized
INFO - 2021-05-15 18:23:11 --> Model "Dashboard_model" initialized
INFO - 2021-05-15 18:23:11 --> Model "Case_model" initialized
INFO - 2021-05-15 18:23:14 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:23:20 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/dashboard/index.php
INFO - 2021-05-15 18:23:20 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 18:23:20 --> Final output sent to browser
DEBUG - 2021-05-15 18:23:20 --> Total execution time: 8.8395
ERROR - 2021-05-15 18:23:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:23:21 --> Config Class Initialized
INFO - 2021-05-15 18:23:21 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:23:21 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:23:21 --> Utf8 Class Initialized
INFO - 2021-05-15 18:23:21 --> URI Class Initialized
INFO - 2021-05-15 18:23:21 --> Router Class Initialized
INFO - 2021-05-15 18:23:21 --> Output Class Initialized
INFO - 2021-05-15 18:23:21 --> Security Class Initialized
DEBUG - 2021-05-15 18:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:23:21 --> Input Class Initialized
INFO - 2021-05-15 18:23:21 --> Language Class Initialized
ERROR - 2021-05-15 18:23:21 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:23:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:23:44 --> Config Class Initialized
INFO - 2021-05-15 18:23:44 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:23:44 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:23:44 --> Utf8 Class Initialized
INFO - 2021-05-15 18:23:44 --> URI Class Initialized
DEBUG - 2021-05-15 18:23:44 --> No URI present. Default controller set.
INFO - 2021-05-15 18:23:44 --> Router Class Initialized
INFO - 2021-05-15 18:23:44 --> Output Class Initialized
INFO - 2021-05-15 18:23:44 --> Security Class Initialized
DEBUG - 2021-05-15 18:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:23:44 --> Input Class Initialized
INFO - 2021-05-15 18:23:44 --> Language Class Initialized
INFO - 2021-05-15 18:23:44 --> Loader Class Initialized
INFO - 2021-05-15 18:23:44 --> Helper loaded: url_helper
INFO - 2021-05-15 18:23:44 --> Helper loaded: form_helper
INFO - 2021-05-15 18:23:44 --> Helper loaded: common_helper
INFO - 2021-05-15 18:23:44 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:23:44 --> Controller Class Initialized
INFO - 2021-05-15 18:23:44 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:23:44 --> Encrypt Class Initialized
DEBUG - 2021-05-15 18:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-05-15 18:23:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-05-15 18:23:44 --> Email Class Initialized
INFO - 2021-05-15 18:23:44 --> Language file loaded: language/english/calendar_lang.php
INFO - 2021-05-15 18:23:44 --> Calendar Class Initialized
INFO - 2021-05-15 18:23:44 --> Model "Login_model" initialized
INFO - 2021-05-15 18:23:44 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/login/index.php
INFO - 2021-05-15 18:23:44 --> Final output sent to browser
DEBUG - 2021-05-15 18:23:44 --> Total execution time: 0.0200
ERROR - 2021-05-15 18:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:23:45 --> Config Class Initialized
INFO - 2021-05-15 18:23:45 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:23:45 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:23:45 --> Utf8 Class Initialized
INFO - 2021-05-15 18:23:45 --> URI Class Initialized
INFO - 2021-05-15 18:23:45 --> Router Class Initialized
INFO - 2021-05-15 18:23:45 --> Output Class Initialized
INFO - 2021-05-15 18:23:45 --> Security Class Initialized
DEBUG - 2021-05-15 18:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:23:45 --> Input Class Initialized
INFO - 2021-05-15 18:23:45 --> Language Class Initialized
ERROR - 2021-05-15 18:23:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-15 18:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:07 --> Config Class Initialized
INFO - 2021-05-15 18:29:07 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:07 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:07 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:07 --> URI Class Initialized
INFO - 2021-05-15 18:29:07 --> Router Class Initialized
INFO - 2021-05-15 18:29:07 --> Output Class Initialized
INFO - 2021-05-15 18:29:07 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:07 --> Input Class Initialized
INFO - 2021-05-15 18:29:07 --> Language Class Initialized
INFO - 2021-05-15 18:29:07 --> Loader Class Initialized
INFO - 2021-05-15 18:29:07 --> Helper loaded: url_helper
INFO - 2021-05-15 18:29:07 --> Helper loaded: form_helper
INFO - 2021-05-15 18:29:07 --> Helper loaded: common_helper
INFO - 2021-05-15 18:29:07 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:29:07 --> Controller Class Initialized
INFO - 2021-05-15 18:29:07 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:29:07 --> Encrypt Class Initialized
INFO - 2021-05-15 18:29:07 --> Model "Payment_model" initialized
INFO - 2021-05-15 18:29:07 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:29:07 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/payment/index.php
INFO - 2021-05-15 18:29:07 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 18:29:07 --> Final output sent to browser
DEBUG - 2021-05-15 18:29:07 --> Total execution time: 0.0239
ERROR - 2021-05-15 18:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:08 --> Config Class Initialized
INFO - 2021-05-15 18:29:08 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:08 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:08 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:08 --> URI Class Initialized
INFO - 2021-05-15 18:29:08 --> Router Class Initialized
INFO - 2021-05-15 18:29:08 --> Output Class Initialized
INFO - 2021-05-15 18:29:08 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:08 --> Input Class Initialized
INFO - 2021-05-15 18:29:08 --> Language Class Initialized
ERROR - 2021-05-15 18:29:08 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:29:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:10 --> Config Class Initialized
INFO - 2021-05-15 18:29:10 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:10 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:10 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:10 --> URI Class Initialized
INFO - 2021-05-15 18:29:10 --> Router Class Initialized
INFO - 2021-05-15 18:29:10 --> Output Class Initialized
INFO - 2021-05-15 18:29:10 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:10 --> Input Class Initialized
INFO - 2021-05-15 18:29:10 --> Language Class Initialized
INFO - 2021-05-15 18:29:10 --> Loader Class Initialized
INFO - 2021-05-15 18:29:10 --> Helper loaded: url_helper
INFO - 2021-05-15 18:29:10 --> Helper loaded: form_helper
INFO - 2021-05-15 18:29:10 --> Helper loaded: common_helper
INFO - 2021-05-15 18:29:10 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:29:10 --> Controller Class Initialized
INFO - 2021-05-15 18:29:10 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:29:10 --> Encrypt Class Initialized
INFO - 2021-05-15 18:29:10 --> Model "Referredby_model" initialized
INFO - 2021-05-15 18:29:10 --> Model "Users_model" initialized
INFO - 2021-05-15 18:29:10 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:29:10 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/users/index.php
INFO - 2021-05-15 18:29:10 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 18:29:10 --> Final output sent to browser
DEBUG - 2021-05-15 18:29:10 --> Total execution time: 0.0217
ERROR - 2021-05-15 18:29:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:10 --> Config Class Initialized
INFO - 2021-05-15 18:29:10 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:10 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:10 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:10 --> URI Class Initialized
INFO - 2021-05-15 18:29:10 --> Router Class Initialized
INFO - 2021-05-15 18:29:10 --> Output Class Initialized
INFO - 2021-05-15 18:29:10 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:10 --> Input Class Initialized
INFO - 2021-05-15 18:29:10 --> Language Class Initialized
ERROR - 2021-05-15 18:29:10 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:29:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:12 --> Config Class Initialized
INFO - 2021-05-15 18:29:12 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:12 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:12 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:12 --> URI Class Initialized
INFO - 2021-05-15 18:29:12 --> Router Class Initialized
INFO - 2021-05-15 18:29:12 --> Output Class Initialized
INFO - 2021-05-15 18:29:12 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:12 --> Input Class Initialized
INFO - 2021-05-15 18:29:12 --> Language Class Initialized
INFO - 2021-05-15 18:29:12 --> Loader Class Initialized
INFO - 2021-05-15 18:29:12 --> Helper loaded: url_helper
INFO - 2021-05-15 18:29:12 --> Helper loaded: form_helper
INFO - 2021-05-15 18:29:12 --> Helper loaded: common_helper
INFO - 2021-05-15 18:29:12 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:29:12 --> Controller Class Initialized
INFO - 2021-05-15 18:29:12 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:29:12 --> Encrypt Class Initialized
INFO - 2021-05-15 18:29:12 --> Model "Hospital_model" initialized
INFO - 2021-05-15 18:29:12 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:29:12 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/hospital/index.php
INFO - 2021-05-15 18:29:12 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 18:29:12 --> Final output sent to browser
DEBUG - 2021-05-15 18:29:12 --> Total execution time: 0.0226
ERROR - 2021-05-15 18:29:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:12 --> Config Class Initialized
INFO - 2021-05-15 18:29:12 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:12 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:12 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:12 --> URI Class Initialized
INFO - 2021-05-15 18:29:12 --> Router Class Initialized
INFO - 2021-05-15 18:29:12 --> Output Class Initialized
INFO - 2021-05-15 18:29:12 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:12 --> Input Class Initialized
INFO - 2021-05-15 18:29:12 --> Language Class Initialized
ERROR - 2021-05-15 18:29:12 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:29:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:17 --> Config Class Initialized
INFO - 2021-05-15 18:29:17 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:17 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:17 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:17 --> URI Class Initialized
INFO - 2021-05-15 18:29:17 --> Router Class Initialized
INFO - 2021-05-15 18:29:17 --> Output Class Initialized
INFO - 2021-05-15 18:29:17 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:17 --> Input Class Initialized
INFO - 2021-05-15 18:29:17 --> Language Class Initialized
INFO - 2021-05-15 18:29:17 --> Loader Class Initialized
INFO - 2021-05-15 18:29:17 --> Helper loaded: url_helper
INFO - 2021-05-15 18:29:17 --> Helper loaded: form_helper
INFO - 2021-05-15 18:29:17 --> Helper loaded: common_helper
INFO - 2021-05-15 18:29:17 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:29:17 --> Controller Class Initialized
INFO - 2021-05-15 18:29:17 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:29:17 --> Encrypt Class Initialized
INFO - 2021-05-15 18:29:17 --> Model "Referredby_model" initialized
INFO - 2021-05-15 18:29:17 --> Model "Donner_model" initialized
INFO - 2021-05-15 18:29:17 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:29:17 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/donner/index.php
INFO - 2021-05-15 18:29:17 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 18:29:17 --> Final output sent to browser
DEBUG - 2021-05-15 18:29:17 --> Total execution time: 0.0214
ERROR - 2021-05-15 18:29:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:17 --> Config Class Initialized
INFO - 2021-05-15 18:29:17 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:17 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:17 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:17 --> URI Class Initialized
INFO - 2021-05-15 18:29:17 --> Router Class Initialized
INFO - 2021-05-15 18:29:17 --> Output Class Initialized
INFO - 2021-05-15 18:29:17 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:17 --> Input Class Initialized
INFO - 2021-05-15 18:29:17 --> Language Class Initialized
ERROR - 2021-05-15 18:29:17 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:21 --> Config Class Initialized
INFO - 2021-05-15 18:29:21 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:21 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:21 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:21 --> URI Class Initialized
INFO - 2021-05-15 18:29:21 --> Router Class Initialized
INFO - 2021-05-15 18:29:21 --> Output Class Initialized
INFO - 2021-05-15 18:29:21 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:21 --> Input Class Initialized
INFO - 2021-05-15 18:29:21 --> Language Class Initialized
INFO - 2021-05-15 18:29:21 --> Loader Class Initialized
INFO - 2021-05-15 18:29:21 --> Helper loaded: url_helper
INFO - 2021-05-15 18:29:21 --> Helper loaded: form_helper
INFO - 2021-05-15 18:29:21 --> Helper loaded: common_helper
INFO - 2021-05-15 18:29:21 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:29:21 --> Controller Class Initialized
INFO - 2021-05-15 18:29:21 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:29:21 --> Encrypt Class Initialized
INFO - 2021-05-15 18:29:21 --> Model "Hospital_model" initialized
INFO - 2021-05-15 18:29:21 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:29:21 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/hospital/depart.php
INFO - 2021-05-15 18:29:21 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
INFO - 2021-05-15 18:29:21 --> Final output sent to browser
DEBUG - 2021-05-15 18:29:21 --> Total execution time: 0.0176
ERROR - 2021-05-15 18:29:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:22 --> Config Class Initialized
INFO - 2021-05-15 18:29:22 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:22 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:22 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:22 --> URI Class Initialized
INFO - 2021-05-15 18:29:22 --> Router Class Initialized
INFO - 2021-05-15 18:29:22 --> Output Class Initialized
INFO - 2021-05-15 18:29:22 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:22 --> Input Class Initialized
INFO - 2021-05-15 18:29:22 --> Language Class Initialized
ERROR - 2021-05-15 18:29:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2021-05-15 18:29:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:29 --> Config Class Initialized
INFO - 2021-05-15 18:29:29 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:29 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:29 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:29 --> URI Class Initialized
INFO - 2021-05-15 18:29:29 --> Router Class Initialized
INFO - 2021-05-15 18:29:29 --> Output Class Initialized
INFO - 2021-05-15 18:29:29 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:29 --> Input Class Initialized
INFO - 2021-05-15 18:29:29 --> Language Class Initialized
INFO - 2021-05-15 18:29:29 --> Loader Class Initialized
INFO - 2021-05-15 18:29:29 --> Helper loaded: url_helper
INFO - 2021-05-15 18:29:29 --> Helper loaded: form_helper
INFO - 2021-05-15 18:29:29 --> Helper loaded: common_helper
INFO - 2021-05-15 18:29:29 --> Database Driver Class Initialized
DEBUG - 2021-05-15 18:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-15 18:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-15 18:29:29 --> Controller Class Initialized
INFO - 2021-05-15 18:29:29 --> Form Validation Class Initialized
DEBUG - 2021-05-15 18:29:29 --> Encrypt Class Initialized
INFO - 2021-05-15 18:29:29 --> Model "Patient_model" initialized
INFO - 2021-05-15 18:29:29 --> Model "Patientcase_model" initialized
INFO - 2021-05-15 18:29:29 --> Model "Referredby_model" initialized
INFO - 2021-05-15 18:29:29 --> Model "Prefix_master" initialized
INFO - 2021-05-15 18:29:29 --> Model "Hospital_model" initialized
INFO - 2021-05-15 18:29:29 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/header.php
INFO - 2021-05-15 18:29:32 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/patient/patientview.php
INFO - 2021-05-15 18:29:32 --> File loaded: /home/techywbu/karo.notioninfosoft.com/application/views/footer.php
ERROR - 2021-05-15 18:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-05-15 18:29:33 --> Config Class Initialized
INFO - 2021-05-15 18:29:33 --> Hooks Class Initialized
DEBUG - 2021-05-15 18:29:33 --> UTF-8 Support Enabled
INFO - 2021-05-15 18:29:33 --> Utf8 Class Initialized
INFO - 2021-05-15 18:29:33 --> URI Class Initialized
INFO - 2021-05-15 18:29:33 --> Router Class Initialized
INFO - 2021-05-15 18:29:33 --> Output Class Initialized
INFO - 2021-05-15 18:29:33 --> Security Class Initialized
DEBUG - 2021-05-15 18:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-15 18:29:33 --> Input Class Initialized
INFO - 2021-05-15 18:29:33 --> Language Class Initialized
ERROR - 2021-05-15 18:29:33 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2021-05-15 18:29:38 --> Final output sent to browser
DEBUG - 2021-05-15 18:29:38 --> Total execution time: 3.3876
