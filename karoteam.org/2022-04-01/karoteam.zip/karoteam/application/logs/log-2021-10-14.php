<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-14 15:47:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-14 15:47:10 --> Config Class Initialized
INFO - 2021-10-14 15:47:10 --> Hooks Class Initialized
DEBUG - 2021-10-14 15:47:10 --> UTF-8 Support Enabled
INFO - 2021-10-14 15:47:10 --> Utf8 Class Initialized
INFO - 2021-10-14 15:47:10 --> URI Class Initialized
INFO - 2021-10-14 15:47:10 --> Router Class Initialized
INFO - 2021-10-14 15:47:10 --> Output Class Initialized
INFO - 2021-10-14 15:47:10 --> Security Class Initialized
DEBUG - 2021-10-14 15:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-14 15:47:10 --> Input Class Initialized
INFO - 2021-10-14 15:47:10 --> Language Class Initialized
ERROR - 2021-10-14 15:47:10 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-10-14 17:03:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2021-10-14 17:03:09 --> Config Class Initialized
INFO - 2021-10-14 17:03:09 --> Hooks Class Initialized
DEBUG - 2021-10-14 17:03:09 --> UTF-8 Support Enabled
INFO - 2021-10-14 17:03:09 --> Utf8 Class Initialized
INFO - 2021-10-14 17:03:09 --> URI Class Initialized
INFO - 2021-10-14 17:03:09 --> Router Class Initialized
INFO - 2021-10-14 17:03:09 --> Output Class Initialized
INFO - 2021-10-14 17:03:09 --> Security Class Initialized
DEBUG - 2021-10-14 17:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-14 17:03:09 --> Input Class Initialized
INFO - 2021-10-14 17:03:09 --> Language Class Initialized
ERROR - 2021-10-14 17:03:09 --> 404 Page Not Found: Vendor/phpunit
