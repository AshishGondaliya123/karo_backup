<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-27 00:29:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 00:29:04 --> Config Class Initialized
INFO - 2022-03-27 00:29:04 --> Hooks Class Initialized
DEBUG - 2022-03-27 00:29:04 --> UTF-8 Support Enabled
INFO - 2022-03-27 00:29:04 --> Utf8 Class Initialized
INFO - 2022-03-27 00:29:04 --> URI Class Initialized
DEBUG - 2022-03-27 00:29:04 --> No URI present. Default controller set.
INFO - 2022-03-27 00:29:04 --> Router Class Initialized
INFO - 2022-03-27 00:29:04 --> Output Class Initialized
INFO - 2022-03-27 00:29:04 --> Security Class Initialized
DEBUG - 2022-03-27 00:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 00:29:04 --> Input Class Initialized
INFO - 2022-03-27 00:29:04 --> Language Class Initialized
INFO - 2022-03-27 00:29:04 --> Loader Class Initialized
INFO - 2022-03-27 00:29:04 --> Helper loaded: url_helper
INFO - 2022-03-27 00:29:04 --> Helper loaded: form_helper
INFO - 2022-03-27 00:29:04 --> Helper loaded: common_helper
INFO - 2022-03-27 00:29:04 --> Database Driver Class Initialized
DEBUG - 2022-03-27 00:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 00:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 00:29:04 --> Controller Class Initialized
INFO - 2022-03-27 00:29:04 --> Form Validation Class Initialized
DEBUG - 2022-03-27 00:29:04 --> Encrypt Class Initialized
DEBUG - 2022-03-27 00:29:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 00:29:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 00:29:04 --> Email Class Initialized
INFO - 2022-03-27 00:29:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 00:29:04 --> Calendar Class Initialized
INFO - 2022-03-27 00:29:04 --> Model "Login_model" initialized
INFO - 2022-03-27 00:29:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 00:29:04 --> Final output sent to browser
DEBUG - 2022-03-27 00:29:04 --> Total execution time: 0.0548
ERROR - 2022-03-27 02:38:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 02:38:05 --> Config Class Initialized
INFO - 2022-03-27 02:38:05 --> Hooks Class Initialized
DEBUG - 2022-03-27 02:38:05 --> UTF-8 Support Enabled
INFO - 2022-03-27 02:38:05 --> Utf8 Class Initialized
INFO - 2022-03-27 02:38:05 --> URI Class Initialized
DEBUG - 2022-03-27 02:38:05 --> No URI present. Default controller set.
INFO - 2022-03-27 02:38:05 --> Router Class Initialized
INFO - 2022-03-27 02:38:05 --> Output Class Initialized
INFO - 2022-03-27 02:38:05 --> Security Class Initialized
DEBUG - 2022-03-27 02:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 02:38:05 --> Input Class Initialized
INFO - 2022-03-27 02:38:05 --> Language Class Initialized
INFO - 2022-03-27 02:38:05 --> Loader Class Initialized
INFO - 2022-03-27 02:38:05 --> Helper loaded: url_helper
INFO - 2022-03-27 02:38:05 --> Helper loaded: form_helper
INFO - 2022-03-27 02:38:05 --> Helper loaded: common_helper
INFO - 2022-03-27 02:38:05 --> Database Driver Class Initialized
DEBUG - 2022-03-27 02:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 02:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 02:38:05 --> Controller Class Initialized
INFO - 2022-03-27 02:38:05 --> Form Validation Class Initialized
DEBUG - 2022-03-27 02:38:05 --> Encrypt Class Initialized
DEBUG - 2022-03-27 02:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 02:38:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 02:38:05 --> Email Class Initialized
INFO - 2022-03-27 02:38:05 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 02:38:05 --> Calendar Class Initialized
INFO - 2022-03-27 02:38:05 --> Model "Login_model" initialized
INFO - 2022-03-27 02:38:05 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 02:38:05 --> Final output sent to browser
DEBUG - 2022-03-27 02:38:05 --> Total execution time: 0.0558
ERROR - 2022-03-27 04:18:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 04:18:04 --> Config Class Initialized
INFO - 2022-03-27 04:18:04 --> Hooks Class Initialized
DEBUG - 2022-03-27 04:18:04 --> UTF-8 Support Enabled
INFO - 2022-03-27 04:18:04 --> Utf8 Class Initialized
INFO - 2022-03-27 04:18:04 --> URI Class Initialized
DEBUG - 2022-03-27 04:18:04 --> No URI present. Default controller set.
INFO - 2022-03-27 04:18:04 --> Router Class Initialized
INFO - 2022-03-27 04:18:04 --> Output Class Initialized
INFO - 2022-03-27 04:18:04 --> Security Class Initialized
DEBUG - 2022-03-27 04:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 04:18:04 --> Input Class Initialized
INFO - 2022-03-27 04:18:04 --> Language Class Initialized
INFO - 2022-03-27 04:18:04 --> Loader Class Initialized
INFO - 2022-03-27 04:18:04 --> Helper loaded: url_helper
INFO - 2022-03-27 04:18:04 --> Helper loaded: form_helper
INFO - 2022-03-27 04:18:04 --> Helper loaded: common_helper
INFO - 2022-03-27 04:18:04 --> Database Driver Class Initialized
DEBUG - 2022-03-27 04:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 04:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 04:18:04 --> Controller Class Initialized
INFO - 2022-03-27 04:18:04 --> Form Validation Class Initialized
DEBUG - 2022-03-27 04:18:04 --> Encrypt Class Initialized
DEBUG - 2022-03-27 04:18:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 04:18:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 04:18:04 --> Email Class Initialized
INFO - 2022-03-27 04:18:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 04:18:04 --> Calendar Class Initialized
INFO - 2022-03-27 04:18:04 --> Model "Login_model" initialized
INFO - 2022-03-27 04:18:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 04:18:04 --> Final output sent to browser
DEBUG - 2022-03-27 04:18:04 --> Total execution time: 0.0545
ERROR - 2022-03-27 08:08:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 08:08:13 --> Config Class Initialized
INFO - 2022-03-27 08:08:13 --> Hooks Class Initialized
DEBUG - 2022-03-27 08:08:13 --> UTF-8 Support Enabled
INFO - 2022-03-27 08:08:13 --> Utf8 Class Initialized
INFO - 2022-03-27 08:08:13 --> URI Class Initialized
DEBUG - 2022-03-27 08:08:13 --> No URI present. Default controller set.
INFO - 2022-03-27 08:08:13 --> Router Class Initialized
INFO - 2022-03-27 08:08:13 --> Output Class Initialized
INFO - 2022-03-27 08:08:13 --> Security Class Initialized
DEBUG - 2022-03-27 08:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 08:08:13 --> Input Class Initialized
INFO - 2022-03-27 08:08:13 --> Language Class Initialized
INFO - 2022-03-27 08:08:13 --> Loader Class Initialized
INFO - 2022-03-27 08:08:13 --> Helper loaded: url_helper
INFO - 2022-03-27 08:08:13 --> Helper loaded: form_helper
INFO - 2022-03-27 08:08:13 --> Helper loaded: common_helper
INFO - 2022-03-27 08:08:13 --> Database Driver Class Initialized
DEBUG - 2022-03-27 08:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 08:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 08:08:13 --> Controller Class Initialized
INFO - 2022-03-27 08:08:13 --> Form Validation Class Initialized
DEBUG - 2022-03-27 08:08:13 --> Encrypt Class Initialized
DEBUG - 2022-03-27 08:08:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 08:08:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 08:08:13 --> Email Class Initialized
INFO - 2022-03-27 08:08:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 08:08:13 --> Calendar Class Initialized
INFO - 2022-03-27 08:08:13 --> Model "Login_model" initialized
INFO - 2022-03-27 08:08:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 08:08:13 --> Final output sent to browser
DEBUG - 2022-03-27 08:08:13 --> Total execution time: 0.0769
ERROR - 2022-03-27 11:58:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 11:58:04 --> Config Class Initialized
INFO - 2022-03-27 11:58:04 --> Hooks Class Initialized
DEBUG - 2022-03-27 11:58:04 --> UTF-8 Support Enabled
INFO - 2022-03-27 11:58:04 --> Utf8 Class Initialized
INFO - 2022-03-27 11:58:04 --> URI Class Initialized
DEBUG - 2022-03-27 11:58:04 --> No URI present. Default controller set.
INFO - 2022-03-27 11:58:04 --> Router Class Initialized
INFO - 2022-03-27 11:58:04 --> Output Class Initialized
INFO - 2022-03-27 11:58:04 --> Security Class Initialized
DEBUG - 2022-03-27 11:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 11:58:04 --> Input Class Initialized
INFO - 2022-03-27 11:58:04 --> Language Class Initialized
INFO - 2022-03-27 11:58:04 --> Loader Class Initialized
INFO - 2022-03-27 11:58:04 --> Helper loaded: url_helper
INFO - 2022-03-27 11:58:04 --> Helper loaded: form_helper
INFO - 2022-03-27 11:58:04 --> Helper loaded: common_helper
INFO - 2022-03-27 11:58:04 --> Database Driver Class Initialized
DEBUG - 2022-03-27 11:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 11:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 11:58:04 --> Controller Class Initialized
INFO - 2022-03-27 11:58:04 --> Form Validation Class Initialized
DEBUG - 2022-03-27 11:58:04 --> Encrypt Class Initialized
DEBUG - 2022-03-27 11:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 11:58:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 11:58:04 --> Email Class Initialized
INFO - 2022-03-27 11:58:04 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 11:58:04 --> Calendar Class Initialized
INFO - 2022-03-27 11:58:04 --> Model "Login_model" initialized
INFO - 2022-03-27 11:58:04 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 11:58:04 --> Final output sent to browser
DEBUG - 2022-03-27 11:58:04 --> Total execution time: 0.0546
ERROR - 2022-03-27 12:00:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:57 --> Config Class Initialized
INFO - 2022-03-27 12:00:57 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:57 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:57 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:57 --> URI Class Initialized
DEBUG - 2022-03-27 12:00:57 --> No URI present. Default controller set.
INFO - 2022-03-27 12:00:57 --> Router Class Initialized
INFO - 2022-03-27 12:00:57 --> Output Class Initialized
INFO - 2022-03-27 12:00:57 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:57 --> Input Class Initialized
INFO - 2022-03-27 12:00:57 --> Language Class Initialized
INFO - 2022-03-27 12:00:57 --> Loader Class Initialized
INFO - 2022-03-27 12:00:57 --> Helper loaded: url_helper
INFO - 2022-03-27 12:00:57 --> Helper loaded: form_helper
INFO - 2022-03-27 12:00:57 --> Helper loaded: common_helper
INFO - 2022-03-27 12:00:57 --> Database Driver Class Initialized
DEBUG - 2022-03-27 12:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 12:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 12:00:57 --> Controller Class Initialized
INFO - 2022-03-27 12:00:57 --> Form Validation Class Initialized
DEBUG - 2022-03-27 12:00:57 --> Encrypt Class Initialized
DEBUG - 2022-03-27 12:00:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 12:00:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 12:00:57 --> Email Class Initialized
INFO - 2022-03-27 12:00:57 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 12:00:57 --> Calendar Class Initialized
INFO - 2022-03-27 12:00:57 --> Model "Login_model" initialized
INFO - 2022-03-27 12:00:57 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 12:00:57 --> Final output sent to browser
DEBUG - 2022-03-27 12:00:57 --> Total execution time: 0.0678
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: Web/wp-includes
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: Website/wp-includes
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: News/wp-includes
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2022-03-27 12:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:58 --> Config Class Initialized
INFO - 2022-03-27 12:00:58 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:58 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:58 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:58 --> URI Class Initialized
INFO - 2022-03-27 12:00:58 --> Router Class Initialized
INFO - 2022-03-27 12:00:58 --> Output Class Initialized
INFO - 2022-03-27 12:00:58 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:58 --> Input Class Initialized
INFO - 2022-03-27 12:00:58 --> Language Class Initialized
ERROR - 2022-03-27 12:00:58 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2022-03-27 12:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:59 --> Config Class Initialized
INFO - 2022-03-27 12:00:59 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:59 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:59 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:59 --> URI Class Initialized
INFO - 2022-03-27 12:00:59 --> Router Class Initialized
INFO - 2022-03-27 12:00:59 --> Output Class Initialized
INFO - 2022-03-27 12:00:59 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:59 --> Input Class Initialized
INFO - 2022-03-27 12:00:59 --> Language Class Initialized
ERROR - 2022-03-27 12:00:59 --> 404 Page Not Found: Test/wp-includes
ERROR - 2022-03-27 12:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:59 --> Config Class Initialized
INFO - 2022-03-27 12:00:59 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:59 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:59 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:59 --> URI Class Initialized
INFO - 2022-03-27 12:00:59 --> Router Class Initialized
INFO - 2022-03-27 12:00:59 --> Output Class Initialized
INFO - 2022-03-27 12:00:59 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:59 --> Input Class Initialized
INFO - 2022-03-27 12:00:59 --> Language Class Initialized
ERROR - 2022-03-27 12:00:59 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2022-03-27 12:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:59 --> Config Class Initialized
INFO - 2022-03-27 12:00:59 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:59 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:59 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:59 --> URI Class Initialized
INFO - 2022-03-27 12:00:59 --> Router Class Initialized
INFO - 2022-03-27 12:00:59 --> Output Class Initialized
INFO - 2022-03-27 12:00:59 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:59 --> Input Class Initialized
INFO - 2022-03-27 12:00:59 --> Language Class Initialized
ERROR - 2022-03-27 12:00:59 --> 404 Page Not Found: Site/wp-includes
ERROR - 2022-03-27 12:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:59 --> Config Class Initialized
INFO - 2022-03-27 12:00:59 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:59 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:59 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:59 --> URI Class Initialized
INFO - 2022-03-27 12:00:59 --> Router Class Initialized
INFO - 2022-03-27 12:00:59 --> Output Class Initialized
INFO - 2022-03-27 12:00:59 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:59 --> Input Class Initialized
INFO - 2022-03-27 12:00:59 --> Language Class Initialized
ERROR - 2022-03-27 12:00:59 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2022-03-27 12:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:00:59 --> Config Class Initialized
INFO - 2022-03-27 12:00:59 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:00:59 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:00:59 --> Utf8 Class Initialized
INFO - 2022-03-27 12:00:59 --> URI Class Initialized
INFO - 2022-03-27 12:00:59 --> Router Class Initialized
INFO - 2022-03-27 12:00:59 --> Output Class Initialized
INFO - 2022-03-27 12:00:59 --> Security Class Initialized
DEBUG - 2022-03-27 12:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:00:59 --> Input Class Initialized
INFO - 2022-03-27 12:00:59 --> Language Class Initialized
ERROR - 2022-03-27 12:00:59 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2022-03-27 12:47:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 12:47:10 --> Config Class Initialized
INFO - 2022-03-27 12:47:10 --> Hooks Class Initialized
DEBUG - 2022-03-27 12:47:10 --> UTF-8 Support Enabled
INFO - 2022-03-27 12:47:10 --> Utf8 Class Initialized
INFO - 2022-03-27 12:47:10 --> URI Class Initialized
DEBUG - 2022-03-27 12:47:10 --> No URI present. Default controller set.
INFO - 2022-03-27 12:47:10 --> Router Class Initialized
INFO - 2022-03-27 12:47:10 --> Output Class Initialized
INFO - 2022-03-27 12:47:10 --> Security Class Initialized
DEBUG - 2022-03-27 12:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 12:47:10 --> Input Class Initialized
INFO - 2022-03-27 12:47:10 --> Language Class Initialized
INFO - 2022-03-27 12:47:10 --> Loader Class Initialized
INFO - 2022-03-27 12:47:10 --> Helper loaded: url_helper
INFO - 2022-03-27 12:47:10 --> Helper loaded: form_helper
INFO - 2022-03-27 12:47:10 --> Helper loaded: common_helper
INFO - 2022-03-27 12:47:10 --> Database Driver Class Initialized
DEBUG - 2022-03-27 12:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 12:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 12:47:10 --> Controller Class Initialized
INFO - 2022-03-27 12:47:10 --> Form Validation Class Initialized
DEBUG - 2022-03-27 12:47:10 --> Encrypt Class Initialized
DEBUG - 2022-03-27 12:47:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 12:47:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 12:47:10 --> Email Class Initialized
INFO - 2022-03-27 12:47:10 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 12:47:10 --> Calendar Class Initialized
INFO - 2022-03-27 12:47:10 --> Model "Login_model" initialized
INFO - 2022-03-27 12:47:10 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 12:47:10 --> Final output sent to browser
DEBUG - 2022-03-27 12:47:10 --> Total execution time: 0.0624
ERROR - 2022-03-27 14:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 14:18:41 --> Config Class Initialized
INFO - 2022-03-27 14:18:41 --> Hooks Class Initialized
DEBUG - 2022-03-27 14:18:41 --> UTF-8 Support Enabled
INFO - 2022-03-27 14:18:41 --> Utf8 Class Initialized
INFO - 2022-03-27 14:18:41 --> URI Class Initialized
DEBUG - 2022-03-27 14:18:41 --> No URI present. Default controller set.
INFO - 2022-03-27 14:18:41 --> Router Class Initialized
INFO - 2022-03-27 14:18:41 --> Output Class Initialized
INFO - 2022-03-27 14:18:41 --> Security Class Initialized
DEBUG - 2022-03-27 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 14:18:41 --> Input Class Initialized
INFO - 2022-03-27 14:18:41 --> Language Class Initialized
INFO - 2022-03-27 14:18:41 --> Loader Class Initialized
INFO - 2022-03-27 14:18:41 --> Helper loaded: url_helper
INFO - 2022-03-27 14:18:41 --> Helper loaded: form_helper
INFO - 2022-03-27 14:18:41 --> Helper loaded: common_helper
INFO - 2022-03-27 14:18:41 --> Database Driver Class Initialized
DEBUG - 2022-03-27 14:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 14:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 14:18:41 --> Controller Class Initialized
INFO - 2022-03-27 14:18:41 --> Form Validation Class Initialized
DEBUG - 2022-03-27 14:18:41 --> Encrypt Class Initialized
DEBUG - 2022-03-27 14:18:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 14:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 14:18:41 --> Email Class Initialized
INFO - 2022-03-27 14:18:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 14:18:41 --> Calendar Class Initialized
INFO - 2022-03-27 14:18:41 --> Model "Login_model" initialized
INFO - 2022-03-27 14:18:41 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 14:18:41 --> Final output sent to browser
DEBUG - 2022-03-27 14:18:41 --> Total execution time: 0.0712
ERROR - 2022-03-27 14:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 14:18:43 --> Config Class Initialized
INFO - 2022-03-27 14:18:43 --> Hooks Class Initialized
DEBUG - 2022-03-27 14:18:43 --> UTF-8 Support Enabled
INFO - 2022-03-27 14:18:43 --> Utf8 Class Initialized
INFO - 2022-03-27 14:18:43 --> URI Class Initialized
INFO - 2022-03-27 14:18:43 --> Router Class Initialized
INFO - 2022-03-27 14:18:43 --> Output Class Initialized
INFO - 2022-03-27 14:18:43 --> Security Class Initialized
DEBUG - 2022-03-27 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 14:18:43 --> Input Class Initialized
INFO - 2022-03-27 14:18:43 --> Language Class Initialized
ERROR - 2022-03-27 14:18:43 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-27 14:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 14:19:06 --> Config Class Initialized
INFO - 2022-03-27 14:19:06 --> Hooks Class Initialized
DEBUG - 2022-03-27 14:19:06 --> UTF-8 Support Enabled
INFO - 2022-03-27 14:19:06 --> Utf8 Class Initialized
INFO - 2022-03-27 14:19:06 --> URI Class Initialized
INFO - 2022-03-27 14:19:06 --> Router Class Initialized
INFO - 2022-03-27 14:19:06 --> Output Class Initialized
INFO - 2022-03-27 14:19:06 --> Security Class Initialized
DEBUG - 2022-03-27 14:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 14:19:06 --> Input Class Initialized
INFO - 2022-03-27 14:19:06 --> Language Class Initialized
INFO - 2022-03-27 14:19:06 --> Loader Class Initialized
INFO - 2022-03-27 14:19:06 --> Helper loaded: url_helper
INFO - 2022-03-27 14:19:06 --> Helper loaded: form_helper
INFO - 2022-03-27 14:19:06 --> Helper loaded: common_helper
INFO - 2022-03-27 14:19:06 --> Database Driver Class Initialized
DEBUG - 2022-03-27 14:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 14:19:06 --> Controller Class Initialized
INFO - 2022-03-27 14:19:06 --> Form Validation Class Initialized
DEBUG - 2022-03-27 14:19:06 --> Encrypt Class Initialized
DEBUG - 2022-03-27 14:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 14:19:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 14:19:06 --> Email Class Initialized
INFO - 2022-03-27 14:19:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 14:19:06 --> Calendar Class Initialized
INFO - 2022-03-27 14:19:06 --> Model "Login_model" initialized
ERROR - 2022-03-27 14:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 14:19:06 --> Config Class Initialized
INFO - 2022-03-27 14:19:06 --> Hooks Class Initialized
DEBUG - 2022-03-27 14:19:06 --> UTF-8 Support Enabled
INFO - 2022-03-27 14:19:06 --> Utf8 Class Initialized
INFO - 2022-03-27 14:19:06 --> URI Class Initialized
INFO - 2022-03-27 14:19:06 --> Router Class Initialized
INFO - 2022-03-27 14:19:06 --> Output Class Initialized
INFO - 2022-03-27 14:19:06 --> Security Class Initialized
DEBUG - 2022-03-27 14:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 14:19:06 --> Input Class Initialized
INFO - 2022-03-27 14:19:06 --> Language Class Initialized
INFO - 2022-03-27 14:19:06 --> Loader Class Initialized
INFO - 2022-03-27 14:19:06 --> Helper loaded: url_helper
INFO - 2022-03-27 14:19:06 --> Helper loaded: form_helper
INFO - 2022-03-27 14:19:06 --> Helper loaded: common_helper
INFO - 2022-03-27 14:19:06 --> Database Driver Class Initialized
DEBUG - 2022-03-27 14:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 14:19:06 --> Controller Class Initialized
INFO - 2022-03-27 14:19:06 --> Form Validation Class Initialized
DEBUG - 2022-03-27 14:19:06 --> Encrypt Class Initialized
DEBUG - 2022-03-27 14:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 14:19:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 14:19:06 --> Email Class Initialized
INFO - 2022-03-27 14:19:06 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 14:19:06 --> Calendar Class Initialized
INFO - 2022-03-27 14:19:06 --> Model "Login_model" initialized
ERROR - 2022-03-27 14:19:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 14:19:07 --> Config Class Initialized
INFO - 2022-03-27 14:19:07 --> Hooks Class Initialized
DEBUG - 2022-03-27 14:19:07 --> UTF-8 Support Enabled
INFO - 2022-03-27 14:19:07 --> Utf8 Class Initialized
INFO - 2022-03-27 14:19:07 --> URI Class Initialized
INFO - 2022-03-27 14:19:07 --> Router Class Initialized
INFO - 2022-03-27 14:19:07 --> Output Class Initialized
INFO - 2022-03-27 14:19:07 --> Security Class Initialized
DEBUG - 2022-03-27 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 14:19:07 --> Input Class Initialized
INFO - 2022-03-27 14:19:07 --> Language Class Initialized
INFO - 2022-03-27 14:19:07 --> Loader Class Initialized
INFO - 2022-03-27 14:19:07 --> Helper loaded: url_helper
INFO - 2022-03-27 14:19:07 --> Helper loaded: form_helper
INFO - 2022-03-27 14:19:07 --> Helper loaded: common_helper
INFO - 2022-03-27 14:19:07 --> Database Driver Class Initialized
DEBUG - 2022-03-27 14:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 14:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 14:19:07 --> Controller Class Initialized
INFO - 2022-03-27 14:19:07 --> Form Validation Class Initialized
DEBUG - 2022-03-27 14:19:07 --> Encrypt Class Initialized
DEBUG - 2022-03-27 14:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 14:19:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 14:19:07 --> Email Class Initialized
INFO - 2022-03-27 14:19:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 14:19:07 --> Calendar Class Initialized
INFO - 2022-03-27 14:19:07 --> Model "Login_model" initialized
INFO - 2022-03-27 14:19:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 14:19:07 --> Final output sent to browser
DEBUG - 2022-03-27 14:19:07 --> Total execution time: 0.0076
ERROR - 2022-03-27 14:19:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 14:19:07 --> Config Class Initialized
INFO - 2022-03-27 14:19:07 --> Hooks Class Initialized
DEBUG - 2022-03-27 14:19:07 --> UTF-8 Support Enabled
INFO - 2022-03-27 14:19:07 --> Utf8 Class Initialized
INFO - 2022-03-27 14:19:07 --> URI Class Initialized
DEBUG - 2022-03-27 14:19:07 --> No URI present. Default controller set.
INFO - 2022-03-27 14:19:07 --> Router Class Initialized
INFO - 2022-03-27 14:19:07 --> Output Class Initialized
INFO - 2022-03-27 14:19:07 --> Security Class Initialized
DEBUG - 2022-03-27 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 14:19:07 --> Input Class Initialized
INFO - 2022-03-27 14:19:07 --> Language Class Initialized
INFO - 2022-03-27 14:19:07 --> Loader Class Initialized
INFO - 2022-03-27 14:19:07 --> Helper loaded: url_helper
INFO - 2022-03-27 14:19:07 --> Helper loaded: form_helper
INFO - 2022-03-27 14:19:07 --> Helper loaded: common_helper
INFO - 2022-03-27 14:19:07 --> Database Driver Class Initialized
DEBUG - 2022-03-27 14:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 14:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 14:19:07 --> Controller Class Initialized
INFO - 2022-03-27 14:19:07 --> Form Validation Class Initialized
DEBUG - 2022-03-27 14:19:07 --> Encrypt Class Initialized
DEBUG - 2022-03-27 14:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 14:19:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 14:19:07 --> Email Class Initialized
INFO - 2022-03-27 14:19:07 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 14:19:07 --> Calendar Class Initialized
INFO - 2022-03-27 14:19:07 --> Model "Login_model" initialized
INFO - 2022-03-27 14:19:07 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 14:19:07 --> Final output sent to browser
DEBUG - 2022-03-27 14:19:07 --> Total execution time: 0.0050
ERROR - 2022-03-27 15:47:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 15:47:56 --> Config Class Initialized
INFO - 2022-03-27 15:47:56 --> Hooks Class Initialized
DEBUG - 2022-03-27 15:47:56 --> UTF-8 Support Enabled
INFO - 2022-03-27 15:47:56 --> Utf8 Class Initialized
INFO - 2022-03-27 15:47:56 --> URI Class Initialized
DEBUG - 2022-03-27 15:47:56 --> No URI present. Default controller set.
INFO - 2022-03-27 15:47:56 --> Router Class Initialized
INFO - 2022-03-27 15:47:56 --> Output Class Initialized
INFO - 2022-03-27 15:47:56 --> Security Class Initialized
DEBUG - 2022-03-27 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 15:47:56 --> Input Class Initialized
INFO - 2022-03-27 15:47:56 --> Language Class Initialized
INFO - 2022-03-27 15:47:56 --> Loader Class Initialized
INFO - 2022-03-27 15:47:56 --> Helper loaded: url_helper
INFO - 2022-03-27 15:47:56 --> Helper loaded: form_helper
INFO - 2022-03-27 15:47:56 --> Helper loaded: common_helper
INFO - 2022-03-27 15:47:56 --> Database Driver Class Initialized
DEBUG - 2022-03-27 15:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 15:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 15:47:56 --> Controller Class Initialized
INFO - 2022-03-27 15:47:56 --> Form Validation Class Initialized
DEBUG - 2022-03-27 15:47:56 --> Encrypt Class Initialized
DEBUG - 2022-03-27 15:47:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 15:47:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 15:47:56 --> Email Class Initialized
INFO - 2022-03-27 15:47:56 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 15:47:56 --> Calendar Class Initialized
INFO - 2022-03-27 15:47:56 --> Model "Login_model" initialized
INFO - 2022-03-27 15:47:56 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 15:47:56 --> Final output sent to browser
DEBUG - 2022-03-27 15:47:56 --> Total execution time: 0.0718
ERROR - 2022-03-27 17:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 17:40:37 --> Config Class Initialized
INFO - 2022-03-27 17:40:37 --> Hooks Class Initialized
DEBUG - 2022-03-27 17:40:37 --> UTF-8 Support Enabled
INFO - 2022-03-27 17:40:37 --> Utf8 Class Initialized
INFO - 2022-03-27 17:40:37 --> URI Class Initialized
INFO - 2022-03-27 17:40:37 --> Router Class Initialized
INFO - 2022-03-27 17:40:37 --> Output Class Initialized
INFO - 2022-03-27 17:40:37 --> Security Class Initialized
DEBUG - 2022-03-27 17:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 17:40:37 --> Input Class Initialized
INFO - 2022-03-27 17:40:37 --> Language Class Initialized
ERROR - 2022-03-27 17:40:37 --> 404 Page Not Found: _ignition/health-check
ERROR - 2022-03-27 17:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 17:40:39 --> Config Class Initialized
INFO - 2022-03-27 17:40:39 --> Hooks Class Initialized
DEBUG - 2022-03-27 17:40:39 --> UTF-8 Support Enabled
INFO - 2022-03-27 17:40:39 --> Utf8 Class Initialized
INFO - 2022-03-27 17:40:39 --> URI Class Initialized
INFO - 2022-03-27 17:40:39 --> Router Class Initialized
INFO - 2022-03-27 17:40:39 --> Output Class Initialized
INFO - 2022-03-27 17:40:39 --> Security Class Initialized
DEBUG - 2022-03-27 17:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 17:40:39 --> Input Class Initialized
INFO - 2022-03-27 17:40:39 --> Language Class Initialized
ERROR - 2022-03-27 17:40:39 --> 404 Page Not Found: Public/_ignition
ERROR - 2022-03-27 17:40:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 17:40:42 --> Config Class Initialized
INFO - 2022-03-27 17:40:42 --> Hooks Class Initialized
DEBUG - 2022-03-27 17:40:42 --> UTF-8 Support Enabled
INFO - 2022-03-27 17:40:42 --> Utf8 Class Initialized
INFO - 2022-03-27 17:40:42 --> URI Class Initialized
INFO - 2022-03-27 17:40:42 --> Router Class Initialized
INFO - 2022-03-27 17:40:42 --> Output Class Initialized
INFO - 2022-03-27 17:40:42 --> Security Class Initialized
DEBUG - 2022-03-27 17:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 17:40:42 --> Input Class Initialized
INFO - 2022-03-27 17:40:42 --> Language Class Initialized
ERROR - 2022-03-27 17:40:42 --> 404 Page Not Found: Laravel/_ignition
ERROR - 2022-03-27 19:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 19:02:27 --> Config Class Initialized
INFO - 2022-03-27 19:02:27 --> Hooks Class Initialized
DEBUG - 2022-03-27 19:02:27 --> UTF-8 Support Enabled
INFO - 2022-03-27 19:02:27 --> Utf8 Class Initialized
INFO - 2022-03-27 19:02:27 --> URI Class Initialized
INFO - 2022-03-27 19:02:27 --> Router Class Initialized
INFO - 2022-03-27 19:02:27 --> Output Class Initialized
INFO - 2022-03-27 19:02:27 --> Security Class Initialized
DEBUG - 2022-03-27 19:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 19:02:27 --> Input Class Initialized
INFO - 2022-03-27 19:02:27 --> Language Class Initialized
ERROR - 2022-03-27 19:02:27 --> 404 Page Not Found: Filezillaxml/index
ERROR - 2022-03-27 20:38:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 20:38:08 --> Config Class Initialized
INFO - 2022-03-27 20:38:08 --> Hooks Class Initialized
DEBUG - 2022-03-27 20:38:08 --> UTF-8 Support Enabled
INFO - 2022-03-27 20:38:08 --> Utf8 Class Initialized
INFO - 2022-03-27 20:38:08 --> URI Class Initialized
DEBUG - 2022-03-27 20:38:08 --> No URI present. Default controller set.
INFO - 2022-03-27 20:38:08 --> Router Class Initialized
INFO - 2022-03-27 20:38:08 --> Output Class Initialized
INFO - 2022-03-27 20:38:08 --> Security Class Initialized
DEBUG - 2022-03-27 20:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 20:38:08 --> Input Class Initialized
INFO - 2022-03-27 20:38:08 --> Language Class Initialized
INFO - 2022-03-27 20:38:08 --> Loader Class Initialized
INFO - 2022-03-27 20:38:08 --> Helper loaded: url_helper
INFO - 2022-03-27 20:38:08 --> Helper loaded: form_helper
INFO - 2022-03-27 20:38:08 --> Helper loaded: common_helper
INFO - 2022-03-27 20:38:08 --> Database Driver Class Initialized
DEBUG - 2022-03-27 20:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 20:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 20:38:08 --> Controller Class Initialized
INFO - 2022-03-27 20:38:08 --> Form Validation Class Initialized
DEBUG - 2022-03-27 20:38:08 --> Encrypt Class Initialized
DEBUG - 2022-03-27 20:38:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 20:38:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 20:38:08 --> Email Class Initialized
INFO - 2022-03-27 20:38:08 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 20:38:08 --> Calendar Class Initialized
INFO - 2022-03-27 20:38:08 --> Model "Login_model" initialized
INFO - 2022-03-27 20:38:08 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 20:38:08 --> Final output sent to browser
DEBUG - 2022-03-27 20:38:08 --> Total execution time: 0.0645
ERROR - 2022-03-27 23:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 23:04:31 --> Config Class Initialized
INFO - 2022-03-27 23:04:31 --> Hooks Class Initialized
DEBUG - 2022-03-27 23:04:31 --> UTF-8 Support Enabled
INFO - 2022-03-27 23:04:31 --> Utf8 Class Initialized
INFO - 2022-03-27 23:04:31 --> URI Class Initialized
DEBUG - 2022-03-27 23:04:31 --> No URI present. Default controller set.
INFO - 2022-03-27 23:04:31 --> Router Class Initialized
INFO - 2022-03-27 23:04:31 --> Output Class Initialized
INFO - 2022-03-27 23:04:31 --> Security Class Initialized
DEBUG - 2022-03-27 23:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 23:04:31 --> Input Class Initialized
INFO - 2022-03-27 23:04:31 --> Language Class Initialized
INFO - 2022-03-27 23:04:31 --> Loader Class Initialized
INFO - 2022-03-27 23:04:31 --> Helper loaded: url_helper
INFO - 2022-03-27 23:04:31 --> Helper loaded: form_helper
INFO - 2022-03-27 23:04:31 --> Helper loaded: common_helper
INFO - 2022-03-27 23:04:31 --> Database Driver Class Initialized
DEBUG - 2022-03-27 23:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 23:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 23:04:31 --> Controller Class Initialized
INFO - 2022-03-27 23:04:31 --> Form Validation Class Initialized
DEBUG - 2022-03-27 23:04:31 --> Encrypt Class Initialized
DEBUG - 2022-03-27 23:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 23:04:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 23:04:31 --> Email Class Initialized
INFO - 2022-03-27 23:04:31 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 23:04:31 --> Calendar Class Initialized
INFO - 2022-03-27 23:04:31 --> Model "Login_model" initialized
INFO - 2022-03-27 23:04:31 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-27 23:04:31 --> Final output sent to browser
DEBUG - 2022-03-27 23:04:31 --> Total execution time: 0.0607
ERROR - 2022-03-27 23:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 23:04:52 --> Config Class Initialized
INFO - 2022-03-27 23:04:52 --> Hooks Class Initialized
DEBUG - 2022-03-27 23:04:52 --> UTF-8 Support Enabled
INFO - 2022-03-27 23:04:52 --> Utf8 Class Initialized
INFO - 2022-03-27 23:04:52 --> URI Class Initialized
INFO - 2022-03-27 23:04:52 --> Router Class Initialized
INFO - 2022-03-27 23:04:52 --> Output Class Initialized
INFO - 2022-03-27 23:04:52 --> Security Class Initialized
DEBUG - 2022-03-27 23:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 23:04:52 --> Input Class Initialized
INFO - 2022-03-27 23:04:52 --> Language Class Initialized
INFO - 2022-03-27 23:04:52 --> Loader Class Initialized
INFO - 2022-03-27 23:04:52 --> Helper loaded: url_helper
INFO - 2022-03-27 23:04:52 --> Helper loaded: form_helper
INFO - 2022-03-27 23:04:52 --> Helper loaded: common_helper
INFO - 2022-03-27 23:04:52 --> Database Driver Class Initialized
DEBUG - 2022-03-27 23:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 23:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 23:04:52 --> Controller Class Initialized
INFO - 2022-03-27 23:04:52 --> Form Validation Class Initialized
DEBUG - 2022-03-27 23:04:52 --> Encrypt Class Initialized
DEBUG - 2022-03-27 23:04:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-27 23:04:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-27 23:04:52 --> Email Class Initialized
INFO - 2022-03-27 23:04:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-27 23:04:52 --> Calendar Class Initialized
INFO - 2022-03-27 23:04:52 --> Model "Login_model" initialized
INFO - 2022-03-27 23:04:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2022-03-27 23:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 23:04:52 --> Config Class Initialized
INFO - 2022-03-27 23:04:52 --> Hooks Class Initialized
DEBUG - 2022-03-27 23:04:52 --> UTF-8 Support Enabled
INFO - 2022-03-27 23:04:52 --> Utf8 Class Initialized
INFO - 2022-03-27 23:04:52 --> URI Class Initialized
INFO - 2022-03-27 23:04:52 --> Router Class Initialized
INFO - 2022-03-27 23:04:52 --> Output Class Initialized
INFO - 2022-03-27 23:04:52 --> Security Class Initialized
DEBUG - 2022-03-27 23:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 23:04:52 --> Input Class Initialized
INFO - 2022-03-27 23:04:52 --> Language Class Initialized
INFO - 2022-03-27 23:04:52 --> Loader Class Initialized
INFO - 2022-03-27 23:04:52 --> Helper loaded: url_helper
INFO - 2022-03-27 23:04:52 --> Helper loaded: form_helper
INFO - 2022-03-27 23:04:52 --> Helper loaded: common_helper
INFO - 2022-03-27 23:04:52 --> Database Driver Class Initialized
DEBUG - 2022-03-27 23:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 23:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 23:04:52 --> Controller Class Initialized
INFO - 2022-03-27 23:04:52 --> Form Validation Class Initialized
DEBUG - 2022-03-27 23:04:52 --> Encrypt Class Initialized
INFO - 2022-03-27 23:04:52 --> Model "Login_model" initialized
INFO - 2022-03-27 23:04:52 --> Model "Dashboard_model" initialized
INFO - 2022-03-27 23:04:52 --> Model "Case_model" initialized
INFO - 2022-03-27 23:04:53 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-27 23:04:54 --> File loaded: /home3/karoteam/public_html/application/views/dashboard/index.php
INFO - 2022-03-27 23:04:54 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-27 23:04:54 --> Final output sent to browser
DEBUG - 2022-03-27 23:04:54 --> Total execution time: 1.4610
ERROR - 2022-03-27 23:07:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-27 23:07:47 --> Config Class Initialized
INFO - 2022-03-27 23:07:47 --> Hooks Class Initialized
DEBUG - 2022-03-27 23:07:47 --> UTF-8 Support Enabled
INFO - 2022-03-27 23:07:47 --> Utf8 Class Initialized
INFO - 2022-03-27 23:07:47 --> URI Class Initialized
INFO - 2022-03-27 23:07:47 --> Router Class Initialized
INFO - 2022-03-27 23:07:47 --> Output Class Initialized
INFO - 2022-03-27 23:07:47 --> Security Class Initialized
DEBUG - 2022-03-27 23:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-27 23:07:47 --> Input Class Initialized
INFO - 2022-03-27 23:07:47 --> Language Class Initialized
INFO - 2022-03-27 23:07:47 --> Loader Class Initialized
INFO - 2022-03-27 23:07:47 --> Helper loaded: url_helper
INFO - 2022-03-27 23:07:47 --> Helper loaded: form_helper
INFO - 2022-03-27 23:07:47 --> Helper loaded: common_helper
INFO - 2022-03-27 23:07:47 --> Database Driver Class Initialized
DEBUG - 2022-03-27 23:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-27 23:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-27 23:07:47 --> Controller Class Initialized
INFO - 2022-03-27 23:07:47 --> Form Validation Class Initialized
DEBUG - 2022-03-27 23:07:47 --> Encrypt Class Initialized
INFO - 2022-03-27 23:07:47 --> Model "Patient_model" initialized
INFO - 2022-03-27 23:07:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-27 23:07:47 --> Model "Referredby_model" initialized
INFO - 2022-03-27 23:07:47 --> Model "Prefix_master" initialized
INFO - 2022-03-27 23:07:47 --> Model "Hospital_model" initialized
INFO - 2022-03-27 23:07:47 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-27 23:07:47 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-27 23:07:47 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-27 23:07:47 --> Final output sent to browser
DEBUG - 2022-03-27 23:07:47 --> Total execution time: 0.1634
