<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-12 00:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:06:42 --> Config Class Initialized
INFO - 2022-03-12 00:06:42 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:06:42 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:06:42 --> Utf8 Class Initialized
INFO - 2022-03-12 00:06:42 --> URI Class Initialized
INFO - 2022-03-12 00:06:42 --> Router Class Initialized
INFO - 2022-03-12 00:06:42 --> Output Class Initialized
INFO - 2022-03-12 00:06:42 --> Security Class Initialized
DEBUG - 2022-03-12 00:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:06:42 --> Input Class Initialized
INFO - 2022-03-12 00:06:42 --> Language Class Initialized
INFO - 2022-03-12 00:06:42 --> Loader Class Initialized
INFO - 2022-03-12 00:06:42 --> Helper loaded: url_helper
INFO - 2022-03-12 00:06:42 --> Helper loaded: form_helper
INFO - 2022-03-12 00:06:42 --> Helper loaded: common_helper
INFO - 2022-03-12 00:06:42 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:06:42 --> Controller Class Initialized
INFO - 2022-03-12 00:06:42 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:06:42 --> Encrypt Class Initialized
INFO - 2022-03-12 00:06:42 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:06:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:06:42 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:06:42 --> Model "Users_model" initialized
INFO - 2022-03-12 00:06:42 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:06:42 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-12 00:06:43 --> Final output sent to browser
DEBUG - 2022-03-12 00:06:43 --> Total execution time: 1.1091
ERROR - 2022-03-12 00:10:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:10:35 --> Config Class Initialized
INFO - 2022-03-12 00:10:35 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:10:35 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:10:35 --> Utf8 Class Initialized
INFO - 2022-03-12 00:10:35 --> URI Class Initialized
INFO - 2022-03-12 00:10:35 --> Router Class Initialized
INFO - 2022-03-12 00:10:35 --> Output Class Initialized
INFO - 2022-03-12 00:10:35 --> Security Class Initialized
DEBUG - 2022-03-12 00:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:10:35 --> Input Class Initialized
INFO - 2022-03-12 00:10:35 --> Language Class Initialized
INFO - 2022-03-12 00:10:35 --> Loader Class Initialized
INFO - 2022-03-12 00:10:35 --> Helper loaded: url_helper
INFO - 2022-03-12 00:10:35 --> Helper loaded: form_helper
INFO - 2022-03-12 00:10:35 --> Helper loaded: common_helper
INFO - 2022-03-12 00:10:35 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:10:35 --> Controller Class Initialized
INFO - 2022-03-12 00:10:35 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:10:35 --> Encrypt Class Initialized
INFO - 2022-03-12 00:10:35 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:10:35 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:10:35 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:10:35 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:10:35 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:10:35 --> Final output sent to browser
DEBUG - 2022-03-12 00:10:35 --> Total execution time: 0.0245
ERROR - 2022-03-12 00:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:10:36 --> Config Class Initialized
INFO - 2022-03-12 00:10:36 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:10:36 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:10:36 --> Utf8 Class Initialized
INFO - 2022-03-12 00:10:36 --> URI Class Initialized
INFO - 2022-03-12 00:10:36 --> Router Class Initialized
INFO - 2022-03-12 00:10:36 --> Output Class Initialized
INFO - 2022-03-12 00:10:36 --> Security Class Initialized
DEBUG - 2022-03-12 00:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:10:36 --> Input Class Initialized
INFO - 2022-03-12 00:10:36 --> Language Class Initialized
INFO - 2022-03-12 00:10:36 --> Loader Class Initialized
INFO - 2022-03-12 00:10:36 --> Helper loaded: url_helper
INFO - 2022-03-12 00:10:36 --> Helper loaded: form_helper
INFO - 2022-03-12 00:10:36 --> Helper loaded: common_helper
INFO - 2022-03-12 00:10:36 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:10:36 --> Controller Class Initialized
INFO - 2022-03-12 00:10:36 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:10:36 --> Encrypt Class Initialized
INFO - 2022-03-12 00:10:36 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:10:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:10:36 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:10:36 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:10:36 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:10:37 --> Config Class Initialized
INFO - 2022-03-12 00:10:37 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:10:37 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:10:37 --> Utf8 Class Initialized
INFO - 2022-03-12 00:10:37 --> URI Class Initialized
INFO - 2022-03-12 00:10:37 --> Router Class Initialized
INFO - 2022-03-12 00:10:37 --> Output Class Initialized
INFO - 2022-03-12 00:10:37 --> Security Class Initialized
DEBUG - 2022-03-12 00:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:10:37 --> Input Class Initialized
INFO - 2022-03-12 00:10:37 --> Language Class Initialized
INFO - 2022-03-12 00:10:37 --> Loader Class Initialized
INFO - 2022-03-12 00:10:37 --> Helper loaded: url_helper
INFO - 2022-03-12 00:10:37 --> Helper loaded: form_helper
INFO - 2022-03-12 00:10:37 --> Helper loaded: common_helper
INFO - 2022-03-12 00:10:37 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:10:37 --> Controller Class Initialized
INFO - 2022-03-12 00:10:37 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:10:37 --> Encrypt Class Initialized
INFO - 2022-03-12 00:10:37 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:10:37 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:10:37 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:10:37 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:10:37 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:10:37 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:10:37 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-12 00:10:37 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:10:37 --> Final output sent to browser
DEBUG - 2022-03-12 00:10:37 --> Total execution time: 0.0404
ERROR - 2022-03-12 00:10:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:10:38 --> Config Class Initialized
INFO - 2022-03-12 00:10:38 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:10:38 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:10:38 --> Utf8 Class Initialized
INFO - 2022-03-12 00:10:38 --> URI Class Initialized
INFO - 2022-03-12 00:10:38 --> Router Class Initialized
INFO - 2022-03-12 00:10:38 --> Output Class Initialized
INFO - 2022-03-12 00:10:38 --> Security Class Initialized
DEBUG - 2022-03-12 00:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:10:38 --> Input Class Initialized
INFO - 2022-03-12 00:10:38 --> Language Class Initialized
INFO - 2022-03-12 00:10:38 --> Loader Class Initialized
INFO - 2022-03-12 00:10:38 --> Helper loaded: url_helper
INFO - 2022-03-12 00:10:38 --> Helper loaded: form_helper
INFO - 2022-03-12 00:10:38 --> Helper loaded: common_helper
INFO - 2022-03-12 00:10:38 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:10:38 --> Controller Class Initialized
INFO - 2022-03-12 00:10:38 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:10:38 --> Encrypt Class Initialized
INFO - 2022-03-12 00:10:38 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:10:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:10:38 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:10:38 --> Model "Users_model" initialized
INFO - 2022-03-12 00:10:38 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:10:38 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:10:38 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:10:38 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:10:38 --> Final output sent to browser
DEBUG - 2022-03-12 00:10:38 --> Total execution time: 0.0666
ERROR - 2022-03-12 00:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:11:37 --> Config Class Initialized
INFO - 2022-03-12 00:11:37 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:11:37 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:11:37 --> Utf8 Class Initialized
INFO - 2022-03-12 00:11:37 --> URI Class Initialized
INFO - 2022-03-12 00:11:37 --> Router Class Initialized
INFO - 2022-03-12 00:11:37 --> Output Class Initialized
INFO - 2022-03-12 00:11:37 --> Security Class Initialized
DEBUG - 2022-03-12 00:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:11:37 --> Input Class Initialized
INFO - 2022-03-12 00:11:37 --> Language Class Initialized
INFO - 2022-03-12 00:11:37 --> Loader Class Initialized
INFO - 2022-03-12 00:11:37 --> Helper loaded: url_helper
INFO - 2022-03-12 00:11:37 --> Helper loaded: form_helper
INFO - 2022-03-12 00:11:37 --> Helper loaded: common_helper
INFO - 2022-03-12 00:11:37 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:11:37 --> Controller Class Initialized
INFO - 2022-03-12 00:11:37 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:11:37 --> Final output sent to browser
DEBUG - 2022-03-12 00:11:37 --> Total execution time: 0.0291
ERROR - 2022-03-12 00:12:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:12:56 --> Config Class Initialized
INFO - 2022-03-12 00:12:56 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:12:56 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:12:56 --> Utf8 Class Initialized
INFO - 2022-03-12 00:12:56 --> URI Class Initialized
INFO - 2022-03-12 00:12:56 --> Router Class Initialized
INFO - 2022-03-12 00:12:56 --> Output Class Initialized
INFO - 2022-03-12 00:12:56 --> Security Class Initialized
DEBUG - 2022-03-12 00:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:12:56 --> Input Class Initialized
INFO - 2022-03-12 00:12:56 --> Language Class Initialized
INFO - 2022-03-12 00:12:56 --> Loader Class Initialized
INFO - 2022-03-12 00:12:56 --> Helper loaded: url_helper
INFO - 2022-03-12 00:12:56 --> Helper loaded: form_helper
INFO - 2022-03-12 00:12:56 --> Helper loaded: common_helper
INFO - 2022-03-12 00:12:56 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:12:56 --> Controller Class Initialized
INFO - 2022-03-12 00:12:56 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:12:56 --> Encrypt Class Initialized
INFO - 2022-03-12 00:12:56 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:12:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:12:56 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:12:56 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:12:56 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:12:56 --> Final output sent to browser
DEBUG - 2022-03-12 00:12:56 --> Total execution time: 0.0287
ERROR - 2022-03-12 00:14:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:14:16 --> Config Class Initialized
INFO - 2022-03-12 00:14:16 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:14:16 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:14:16 --> Utf8 Class Initialized
INFO - 2022-03-12 00:14:16 --> URI Class Initialized
INFO - 2022-03-12 00:14:16 --> Router Class Initialized
INFO - 2022-03-12 00:14:16 --> Output Class Initialized
INFO - 2022-03-12 00:14:16 --> Security Class Initialized
DEBUG - 2022-03-12 00:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:14:16 --> Input Class Initialized
INFO - 2022-03-12 00:14:16 --> Language Class Initialized
INFO - 2022-03-12 00:14:16 --> Loader Class Initialized
INFO - 2022-03-12 00:14:16 --> Helper loaded: url_helper
INFO - 2022-03-12 00:14:16 --> Helper loaded: form_helper
INFO - 2022-03-12 00:14:16 --> Helper loaded: common_helper
INFO - 2022-03-12 00:14:16 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:14:16 --> Controller Class Initialized
INFO - 2022-03-12 00:14:16 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:14:16 --> Encrypt Class Initialized
INFO - 2022-03-12 00:14:16 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:14:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:14:16 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:14:16 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:14:16 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:14:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:14:17 --> Config Class Initialized
INFO - 2022-03-12 00:14:17 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:14:17 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:14:17 --> Utf8 Class Initialized
INFO - 2022-03-12 00:14:17 --> URI Class Initialized
INFO - 2022-03-12 00:14:17 --> Router Class Initialized
INFO - 2022-03-12 00:14:17 --> Output Class Initialized
INFO - 2022-03-12 00:14:17 --> Security Class Initialized
DEBUG - 2022-03-12 00:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:14:17 --> Input Class Initialized
INFO - 2022-03-12 00:14:17 --> Language Class Initialized
INFO - 2022-03-12 00:14:17 --> Loader Class Initialized
INFO - 2022-03-12 00:14:17 --> Helper loaded: url_helper
INFO - 2022-03-12 00:14:17 --> Helper loaded: form_helper
INFO - 2022-03-12 00:14:17 --> Helper loaded: common_helper
INFO - 2022-03-12 00:14:17 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:14:17 --> Controller Class Initialized
INFO - 2022-03-12 00:14:17 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:14:17 --> Encrypt Class Initialized
INFO - 2022-03-12 00:14:17 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:14:17 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:14:17 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:14:17 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:14:17 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:14:17 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:14:17 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-12 00:14:17 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:14:17 --> Final output sent to browser
DEBUG - 2022-03-12 00:14:17 --> Total execution time: 0.2028
ERROR - 2022-03-12 00:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:14:18 --> Config Class Initialized
INFO - 2022-03-12 00:14:18 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:14:18 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:14:18 --> Utf8 Class Initialized
INFO - 2022-03-12 00:14:18 --> URI Class Initialized
INFO - 2022-03-12 00:14:18 --> Router Class Initialized
INFO - 2022-03-12 00:14:18 --> Output Class Initialized
INFO - 2022-03-12 00:14:18 --> Security Class Initialized
DEBUG - 2022-03-12 00:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:14:18 --> Input Class Initialized
INFO - 2022-03-12 00:14:18 --> Language Class Initialized
ERROR - 2022-03-12 00:14:18 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-12 00:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:14:18 --> Config Class Initialized
INFO - 2022-03-12 00:14:18 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:14:18 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:14:18 --> Utf8 Class Initialized
INFO - 2022-03-12 00:14:18 --> URI Class Initialized
INFO - 2022-03-12 00:14:18 --> Router Class Initialized
INFO - 2022-03-12 00:14:18 --> Output Class Initialized
INFO - 2022-03-12 00:14:18 --> Security Class Initialized
DEBUG - 2022-03-12 00:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:14:18 --> Input Class Initialized
INFO - 2022-03-12 00:14:18 --> Language Class Initialized
INFO - 2022-03-12 00:14:18 --> Loader Class Initialized
INFO - 2022-03-12 00:14:18 --> Helper loaded: url_helper
INFO - 2022-03-12 00:14:18 --> Helper loaded: form_helper
INFO - 2022-03-12 00:14:18 --> Helper loaded: common_helper
INFO - 2022-03-12 00:14:18 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:14:19 --> Controller Class Initialized
INFO - 2022-03-12 00:14:19 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:14:19 --> Encrypt Class Initialized
INFO - 2022-03-12 00:14:19 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:14:19 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:14:19 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:14:19 --> Model "Users_model" initialized
INFO - 2022-03-12 00:14:19 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:14:19 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:14:19 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:14:19 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:14:19 --> Final output sent to browser
DEBUG - 2022-03-12 00:14:19 --> Total execution time: 0.6607
ERROR - 2022-03-12 00:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:14:20 --> Config Class Initialized
INFO - 2022-03-12 00:14:20 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:14:20 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:14:20 --> Utf8 Class Initialized
INFO - 2022-03-12 00:14:20 --> URI Class Initialized
INFO - 2022-03-12 00:14:20 --> Router Class Initialized
INFO - 2022-03-12 00:14:20 --> Output Class Initialized
INFO - 2022-03-12 00:14:20 --> Security Class Initialized
DEBUG - 2022-03-12 00:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:14:20 --> Input Class Initialized
INFO - 2022-03-12 00:14:20 --> Language Class Initialized
ERROR - 2022-03-12 00:14:20 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-12 00:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:18:42 --> Config Class Initialized
INFO - 2022-03-12 00:18:42 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:18:42 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:18:42 --> Utf8 Class Initialized
INFO - 2022-03-12 00:18:42 --> URI Class Initialized
INFO - 2022-03-12 00:18:42 --> Router Class Initialized
INFO - 2022-03-12 00:18:42 --> Output Class Initialized
INFO - 2022-03-12 00:18:42 --> Security Class Initialized
DEBUG - 2022-03-12 00:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:18:42 --> Input Class Initialized
INFO - 2022-03-12 00:18:42 --> Language Class Initialized
INFO - 2022-03-12 00:18:42 --> Loader Class Initialized
INFO - 2022-03-12 00:18:42 --> Helper loaded: url_helper
INFO - 2022-03-12 00:18:42 --> Helper loaded: form_helper
INFO - 2022-03-12 00:18:42 --> Helper loaded: common_helper
INFO - 2022-03-12 00:18:42 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:18:42 --> Controller Class Initialized
INFO - 2022-03-12 00:18:42 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:18:42 --> Encrypt Class Initialized
INFO - 2022-03-12 00:18:42 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:18:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:18:42 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:18:42 --> Model "Users_model" initialized
INFO - 2022-03-12 00:18:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:18:43 --> Config Class Initialized
INFO - 2022-03-12 00:18:43 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:18:43 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:18:43 --> Utf8 Class Initialized
INFO - 2022-03-12 00:18:43 --> URI Class Initialized
INFO - 2022-03-12 00:18:43 --> Router Class Initialized
INFO - 2022-03-12 00:18:43 --> Output Class Initialized
INFO - 2022-03-12 00:18:43 --> Security Class Initialized
DEBUG - 2022-03-12 00:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:18:43 --> Input Class Initialized
INFO - 2022-03-12 00:18:43 --> Language Class Initialized
INFO - 2022-03-12 00:18:43 --> Loader Class Initialized
INFO - 2022-03-12 00:18:43 --> Helper loaded: url_helper
INFO - 2022-03-12 00:18:43 --> Helper loaded: form_helper
INFO - 2022-03-12 00:18:43 --> Helper loaded: common_helper
INFO - 2022-03-12 00:18:43 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:18:43 --> Controller Class Initialized
INFO - 2022-03-12 00:18:43 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:18:43 --> Encrypt Class Initialized
INFO - 2022-03-12 00:18:43 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:18:43 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:18:43 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:18:43 --> Model "Users_model" initialized
INFO - 2022-03-12 00:18:43 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:18:43 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:18:43 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:18:43 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:18:43 --> Final output sent to browser
DEBUG - 2022-03-12 00:18:43 --> Total execution time: 0.2794
ERROR - 2022-03-12 00:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:18:57 --> Config Class Initialized
INFO - 2022-03-12 00:18:57 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:18:57 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:18:57 --> Utf8 Class Initialized
INFO - 2022-03-12 00:18:57 --> URI Class Initialized
INFO - 2022-03-12 00:18:57 --> Router Class Initialized
INFO - 2022-03-12 00:18:57 --> Output Class Initialized
INFO - 2022-03-12 00:18:57 --> Security Class Initialized
DEBUG - 2022-03-12 00:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:18:57 --> Input Class Initialized
INFO - 2022-03-12 00:18:57 --> Language Class Initialized
INFO - 2022-03-12 00:18:57 --> Loader Class Initialized
INFO - 2022-03-12 00:18:57 --> Helper loaded: url_helper
INFO - 2022-03-12 00:18:57 --> Helper loaded: form_helper
INFO - 2022-03-12 00:18:57 --> Helper loaded: common_helper
INFO - 2022-03-12 00:18:57 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:18:57 --> Controller Class Initialized
INFO - 2022-03-12 00:18:57 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:18:57 --> Encrypt Class Initialized
INFO - 2022-03-12 00:18:57 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:18:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:18:57 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:18:57 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:18:57 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:18:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:18:57 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-12 00:18:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:18:57 --> Final output sent to browser
DEBUG - 2022-03-12 00:18:57 --> Total execution time: 0.3647
ERROR - 2022-03-12 00:19:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:19:27 --> Config Class Initialized
INFO - 2022-03-12 00:19:27 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:19:27 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:19:27 --> Utf8 Class Initialized
INFO - 2022-03-12 00:19:27 --> URI Class Initialized
INFO - 2022-03-12 00:19:27 --> Router Class Initialized
INFO - 2022-03-12 00:19:27 --> Output Class Initialized
INFO - 2022-03-12 00:19:27 --> Security Class Initialized
DEBUG - 2022-03-12 00:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:19:27 --> Input Class Initialized
INFO - 2022-03-12 00:19:27 --> Language Class Initialized
INFO - 2022-03-12 00:19:27 --> Loader Class Initialized
INFO - 2022-03-12 00:19:27 --> Helper loaded: url_helper
INFO - 2022-03-12 00:19:27 --> Helper loaded: form_helper
INFO - 2022-03-12 00:19:27 --> Helper loaded: common_helper
INFO - 2022-03-12 00:19:27 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:19:28 --> Controller Class Initialized
INFO - 2022-03-12 00:19:28 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:19:28 --> Encrypt Class Initialized
INFO - 2022-03-12 00:19:28 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:19:28 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:19:28 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:19:28 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:19:28 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-12 00:19:28 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:19:28 --> Final output sent to browser
DEBUG - 2022-03-12 00:19:28 --> Total execution time: 0.0557
ERROR - 2022-03-12 00:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:19:38 --> Config Class Initialized
INFO - 2022-03-12 00:19:38 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:19:38 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:19:38 --> Utf8 Class Initialized
INFO - 2022-03-12 00:19:38 --> URI Class Initialized
INFO - 2022-03-12 00:19:38 --> Router Class Initialized
INFO - 2022-03-12 00:19:38 --> Output Class Initialized
INFO - 2022-03-12 00:19:38 --> Security Class Initialized
DEBUG - 2022-03-12 00:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:19:38 --> Input Class Initialized
INFO - 2022-03-12 00:19:38 --> Language Class Initialized
INFO - 2022-03-12 00:19:38 --> Loader Class Initialized
INFO - 2022-03-12 00:19:38 --> Helper loaded: url_helper
INFO - 2022-03-12 00:19:38 --> Helper loaded: form_helper
INFO - 2022-03-12 00:19:38 --> Helper loaded: common_helper
INFO - 2022-03-12 00:19:38 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:19:38 --> Controller Class Initialized
INFO - 2022-03-12 00:19:38 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:19:38 --> Encrypt Class Initialized
INFO - 2022-03-12 00:19:38 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:19:38 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:19:38 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:19:38 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:19:38 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:19:39 --> Config Class Initialized
INFO - 2022-03-12 00:19:39 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:19:39 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:19:39 --> Utf8 Class Initialized
INFO - 2022-03-12 00:19:39 --> URI Class Initialized
INFO - 2022-03-12 00:19:39 --> Router Class Initialized
INFO - 2022-03-12 00:19:39 --> Output Class Initialized
INFO - 2022-03-12 00:19:39 --> Security Class Initialized
DEBUG - 2022-03-12 00:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:19:39 --> Input Class Initialized
INFO - 2022-03-12 00:19:39 --> Language Class Initialized
INFO - 2022-03-12 00:19:39 --> Loader Class Initialized
INFO - 2022-03-12 00:19:39 --> Helper loaded: url_helper
INFO - 2022-03-12 00:19:39 --> Helper loaded: form_helper
INFO - 2022-03-12 00:19:39 --> Helper loaded: common_helper
INFO - 2022-03-12 00:19:39 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:19:39 --> Controller Class Initialized
INFO - 2022-03-12 00:19:39 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:19:39 --> Encrypt Class Initialized
INFO - 2022-03-12 00:19:39 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:19:39 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:19:39 --> Model "Referredby_model" initialized
INFO - 2022-03-12 00:19:39 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:19:39 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:19:39 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:19:39 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-12 00:19:39 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:19:39 --> Final output sent to browser
DEBUG - 2022-03-12 00:19:39 --> Total execution time: 0.0462
ERROR - 2022-03-12 00:19:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:19:40 --> Config Class Initialized
INFO - 2022-03-12 00:19:40 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:19:40 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:19:40 --> Utf8 Class Initialized
INFO - 2022-03-12 00:19:40 --> URI Class Initialized
INFO - 2022-03-12 00:19:40 --> Router Class Initialized
INFO - 2022-03-12 00:19:40 --> Output Class Initialized
INFO - 2022-03-12 00:19:40 --> Security Class Initialized
DEBUG - 2022-03-12 00:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:19:40 --> Input Class Initialized
INFO - 2022-03-12 00:19:40 --> Language Class Initialized
INFO - 2022-03-12 00:19:40 --> Loader Class Initialized
INFO - 2022-03-12 00:19:40 --> Helper loaded: url_helper
INFO - 2022-03-12 00:19:40 --> Helper loaded: form_helper
INFO - 2022-03-12 00:19:40 --> Helper loaded: common_helper
INFO - 2022-03-12 00:19:40 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:19:40 --> Controller Class Initialized
INFO - 2022-03-12 00:19:40 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:19:40 --> Encrypt Class Initialized
INFO - 2022-03-12 00:19:40 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:19:40 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:19:40 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:19:40 --> Model "Users_model" initialized
INFO - 2022-03-12 00:19:40 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:19:40 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:19:40 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:19:40 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:19:40 --> Final output sent to browser
DEBUG - 2022-03-12 00:19:40 --> Total execution time: 0.0588
ERROR - 2022-03-12 00:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:19:47 --> Config Class Initialized
INFO - 2022-03-12 00:19:47 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:19:47 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:19:47 --> Utf8 Class Initialized
INFO - 2022-03-12 00:19:47 --> URI Class Initialized
INFO - 2022-03-12 00:19:47 --> Router Class Initialized
INFO - 2022-03-12 00:19:47 --> Output Class Initialized
INFO - 2022-03-12 00:19:47 --> Security Class Initialized
DEBUG - 2022-03-12 00:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:19:47 --> Input Class Initialized
INFO - 2022-03-12 00:19:47 --> Language Class Initialized
INFO - 2022-03-12 00:19:47 --> Loader Class Initialized
INFO - 2022-03-12 00:19:47 --> Helper loaded: url_helper
INFO - 2022-03-12 00:19:47 --> Helper loaded: form_helper
INFO - 2022-03-12 00:19:47 --> Helper loaded: common_helper
INFO - 2022-03-12 00:19:47 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:19:47 --> Controller Class Initialized
INFO - 2022-03-12 00:19:47 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:19:47 --> Encrypt Class Initialized
INFO - 2022-03-12 00:19:47 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:19:47 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:19:47 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:19:47 --> Model "Users_model" initialized
INFO - 2022-03-12 00:19:47 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:19:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:19:48 --> Config Class Initialized
INFO - 2022-03-12 00:19:48 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:19:48 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:19:48 --> Utf8 Class Initialized
INFO - 2022-03-12 00:19:48 --> URI Class Initialized
INFO - 2022-03-12 00:19:48 --> Router Class Initialized
INFO - 2022-03-12 00:19:48 --> Output Class Initialized
INFO - 2022-03-12 00:19:48 --> Security Class Initialized
DEBUG - 2022-03-12 00:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:19:48 --> Input Class Initialized
INFO - 2022-03-12 00:19:48 --> Language Class Initialized
INFO - 2022-03-12 00:19:48 --> Loader Class Initialized
INFO - 2022-03-12 00:19:48 --> Helper loaded: url_helper
INFO - 2022-03-12 00:19:48 --> Helper loaded: form_helper
INFO - 2022-03-12 00:19:48 --> Helper loaded: common_helper
INFO - 2022-03-12 00:19:48 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:19:48 --> Controller Class Initialized
INFO - 2022-03-12 00:19:48 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:19:48 --> Encrypt Class Initialized
INFO - 2022-03-12 00:19:48 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:19:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:19:48 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:19:48 --> Model "Users_model" initialized
INFO - 2022-03-12 00:19:48 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:19:48 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:19:48 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:19:48 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:19:48 --> Final output sent to browser
DEBUG - 2022-03-12 00:19:48 --> Total execution time: 0.0608
ERROR - 2022-03-12 00:19:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:19:48 --> Config Class Initialized
INFO - 2022-03-12 00:19:48 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:19:48 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:19:48 --> Utf8 Class Initialized
INFO - 2022-03-12 00:19:48 --> URI Class Initialized
INFO - 2022-03-12 00:19:48 --> Router Class Initialized
INFO - 2022-03-12 00:19:48 --> Output Class Initialized
INFO - 2022-03-12 00:19:48 --> Security Class Initialized
DEBUG - 2022-03-12 00:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:19:48 --> Input Class Initialized
INFO - 2022-03-12 00:19:48 --> Language Class Initialized
ERROR - 2022-03-12 00:19:48 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-12 00:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:19:59 --> Config Class Initialized
INFO - 2022-03-12 00:19:59 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:19:59 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:19:59 --> Utf8 Class Initialized
INFO - 2022-03-12 00:19:59 --> URI Class Initialized
INFO - 2022-03-12 00:19:59 --> Router Class Initialized
INFO - 2022-03-12 00:19:59 --> Output Class Initialized
INFO - 2022-03-12 00:19:59 --> Security Class Initialized
DEBUG - 2022-03-12 00:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:19:59 --> Input Class Initialized
INFO - 2022-03-12 00:19:59 --> Language Class Initialized
INFO - 2022-03-12 00:19:59 --> Loader Class Initialized
INFO - 2022-03-12 00:19:59 --> Helper loaded: url_helper
INFO - 2022-03-12 00:19:59 --> Helper loaded: form_helper
INFO - 2022-03-12 00:19:59 --> Helper loaded: common_helper
INFO - 2022-03-12 00:19:59 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:19:59 --> Controller Class Initialized
INFO - 2022-03-12 00:19:59 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:19:59 --> Encrypt Class Initialized
INFO - 2022-03-12 00:19:59 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:19:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:19:59 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:19:59 --> Model "Users_model" initialized
INFO - 2022-03-12 00:19:59 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:19:59 --> Config Class Initialized
INFO - 2022-03-12 00:19:59 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:19:59 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:19:59 --> Utf8 Class Initialized
INFO - 2022-03-12 00:19:59 --> URI Class Initialized
INFO - 2022-03-12 00:19:59 --> Router Class Initialized
INFO - 2022-03-12 00:19:59 --> Output Class Initialized
INFO - 2022-03-12 00:19:59 --> Security Class Initialized
DEBUG - 2022-03-12 00:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:19:59 --> Input Class Initialized
INFO - 2022-03-12 00:19:59 --> Language Class Initialized
INFO - 2022-03-12 00:19:59 --> Loader Class Initialized
INFO - 2022-03-12 00:19:59 --> Helper loaded: url_helper
INFO - 2022-03-12 00:19:59 --> Helper loaded: form_helper
INFO - 2022-03-12 00:19:59 --> Helper loaded: common_helper
INFO - 2022-03-12 00:19:59 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:19:59 --> Controller Class Initialized
INFO - 2022-03-12 00:19:59 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:19:59 --> Encrypt Class Initialized
INFO - 2022-03-12 00:19:59 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:19:59 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:19:59 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:19:59 --> Model "Users_model" initialized
INFO - 2022-03-12 00:19:59 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:19:59 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:19:59 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:19:59 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:19:59 --> Final output sent to browser
DEBUG - 2022-03-12 00:19:59 --> Total execution time: 0.0629
ERROR - 2022-03-12 00:22:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:22:32 --> Config Class Initialized
INFO - 2022-03-12 00:22:32 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:22:32 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:22:32 --> Utf8 Class Initialized
INFO - 2022-03-12 00:22:32 --> URI Class Initialized
INFO - 2022-03-12 00:22:32 --> Router Class Initialized
INFO - 2022-03-12 00:22:32 --> Output Class Initialized
INFO - 2022-03-12 00:22:32 --> Security Class Initialized
DEBUG - 2022-03-12 00:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:22:32 --> Input Class Initialized
INFO - 2022-03-12 00:22:32 --> Language Class Initialized
INFO - 2022-03-12 00:22:32 --> Loader Class Initialized
INFO - 2022-03-12 00:22:32 --> Helper loaded: url_helper
INFO - 2022-03-12 00:22:32 --> Helper loaded: form_helper
INFO - 2022-03-12 00:22:32 --> Helper loaded: common_helper
INFO - 2022-03-12 00:22:32 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:22:32 --> Controller Class Initialized
INFO - 2022-03-12 00:22:32 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:22:32 --> Encrypt Class Initialized
INFO - 2022-03-12 00:22:32 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:22:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:22:32 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:22:32 --> Model "Users_model" initialized
INFO - 2022-03-12 00:22:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:22:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:22:32 --> Config Class Initialized
INFO - 2022-03-12 00:22:32 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:22:32 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:22:32 --> Utf8 Class Initialized
INFO - 2022-03-12 00:22:32 --> URI Class Initialized
INFO - 2022-03-12 00:22:32 --> Router Class Initialized
INFO - 2022-03-12 00:22:32 --> Output Class Initialized
INFO - 2022-03-12 00:22:32 --> Security Class Initialized
DEBUG - 2022-03-12 00:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:22:32 --> Input Class Initialized
INFO - 2022-03-12 00:22:32 --> Language Class Initialized
INFO - 2022-03-12 00:22:32 --> Loader Class Initialized
INFO - 2022-03-12 00:22:32 --> Helper loaded: url_helper
INFO - 2022-03-12 00:22:32 --> Helper loaded: form_helper
INFO - 2022-03-12 00:22:32 --> Helper loaded: common_helper
INFO - 2022-03-12 00:22:32 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:22:32 --> Controller Class Initialized
INFO - 2022-03-12 00:22:32 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:22:32 --> Encrypt Class Initialized
INFO - 2022-03-12 00:22:32 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:22:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:22:32 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:22:32 --> Model "Users_model" initialized
INFO - 2022-03-12 00:22:32 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:22:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:22:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:22:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:22:33 --> Final output sent to browser
DEBUG - 2022-03-12 00:22:33 --> Total execution time: 0.0916
ERROR - 2022-03-12 00:23:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:23:42 --> Config Class Initialized
INFO - 2022-03-12 00:23:42 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:23:42 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:23:42 --> Utf8 Class Initialized
INFO - 2022-03-12 00:23:42 --> URI Class Initialized
INFO - 2022-03-12 00:23:42 --> Router Class Initialized
INFO - 2022-03-12 00:23:42 --> Output Class Initialized
INFO - 2022-03-12 00:23:42 --> Security Class Initialized
DEBUG - 2022-03-12 00:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:23:42 --> Input Class Initialized
INFO - 2022-03-12 00:23:42 --> Language Class Initialized
INFO - 2022-03-12 00:23:42 --> Loader Class Initialized
INFO - 2022-03-12 00:23:42 --> Helper loaded: url_helper
INFO - 2022-03-12 00:23:42 --> Helper loaded: form_helper
INFO - 2022-03-12 00:23:42 --> Helper loaded: common_helper
INFO - 2022-03-12 00:23:42 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:23:42 --> Controller Class Initialized
INFO - 2022-03-12 00:23:42 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:23:42 --> Encrypt Class Initialized
INFO - 2022-03-12 00:23:42 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:23:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:23:42 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:23:42 --> Model "Users_model" initialized
INFO - 2022-03-12 00:23:42 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:23:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:23:42 --> Config Class Initialized
INFO - 2022-03-12 00:23:42 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:23:42 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:23:42 --> Utf8 Class Initialized
INFO - 2022-03-12 00:23:42 --> URI Class Initialized
INFO - 2022-03-12 00:23:42 --> Router Class Initialized
INFO - 2022-03-12 00:23:42 --> Output Class Initialized
INFO - 2022-03-12 00:23:42 --> Security Class Initialized
DEBUG - 2022-03-12 00:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:23:42 --> Input Class Initialized
INFO - 2022-03-12 00:23:42 --> Language Class Initialized
INFO - 2022-03-12 00:23:42 --> Loader Class Initialized
INFO - 2022-03-12 00:23:42 --> Helper loaded: url_helper
INFO - 2022-03-12 00:23:42 --> Helper loaded: form_helper
INFO - 2022-03-12 00:23:42 --> Helper loaded: common_helper
INFO - 2022-03-12 00:23:42 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:23:42 --> Controller Class Initialized
INFO - 2022-03-12 00:23:42 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:23:42 --> Encrypt Class Initialized
INFO - 2022-03-12 00:23:42 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:23:42 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:23:42 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:23:42 --> Model "Users_model" initialized
INFO - 2022-03-12 00:23:42 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:23:42 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:23:42 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:23:42 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:23:42 --> Final output sent to browser
DEBUG - 2022-03-12 00:23:42 --> Total execution time: 0.0625
ERROR - 2022-03-12 00:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:39:21 --> Config Class Initialized
INFO - 2022-03-12 00:39:21 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:39:21 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:39:21 --> Utf8 Class Initialized
INFO - 2022-03-12 00:39:21 --> URI Class Initialized
INFO - 2022-03-12 00:39:21 --> Router Class Initialized
INFO - 2022-03-12 00:39:21 --> Output Class Initialized
INFO - 2022-03-12 00:39:21 --> Security Class Initialized
DEBUG - 2022-03-12 00:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:39:21 --> Input Class Initialized
INFO - 2022-03-12 00:39:21 --> Language Class Initialized
INFO - 2022-03-12 00:39:21 --> Loader Class Initialized
INFO - 2022-03-12 00:39:21 --> Helper loaded: url_helper
INFO - 2022-03-12 00:39:21 --> Helper loaded: form_helper
INFO - 2022-03-12 00:39:21 --> Helper loaded: common_helper
INFO - 2022-03-12 00:39:21 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:39:21 --> Controller Class Initialized
INFO - 2022-03-12 00:39:21 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:39:21 --> Encrypt Class Initialized
INFO - 2022-03-12 00:39:21 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:39:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:39:21 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:39:21 --> Model "Users_model" initialized
INFO - 2022-03-12 00:39:21 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:39:21 --> Config Class Initialized
INFO - 2022-03-12 00:39:21 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:39:21 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:39:21 --> Utf8 Class Initialized
INFO - 2022-03-12 00:39:21 --> URI Class Initialized
INFO - 2022-03-12 00:39:21 --> Router Class Initialized
INFO - 2022-03-12 00:39:21 --> Output Class Initialized
INFO - 2022-03-12 00:39:21 --> Security Class Initialized
DEBUG - 2022-03-12 00:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:39:21 --> Input Class Initialized
INFO - 2022-03-12 00:39:21 --> Language Class Initialized
INFO - 2022-03-12 00:39:21 --> Loader Class Initialized
INFO - 2022-03-12 00:39:21 --> Helper loaded: url_helper
INFO - 2022-03-12 00:39:21 --> Helper loaded: form_helper
INFO - 2022-03-12 00:39:21 --> Helper loaded: common_helper
INFO - 2022-03-12 00:39:21 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:39:21 --> Controller Class Initialized
INFO - 2022-03-12 00:39:21 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:39:21 --> Encrypt Class Initialized
INFO - 2022-03-12 00:39:21 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:39:21 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:39:21 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:39:21 --> Model "Users_model" initialized
INFO - 2022-03-12 00:39:21 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:39:21 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:39:21 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:39:21 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:39:21 --> Final output sent to browser
DEBUG - 2022-03-12 00:39:21 --> Total execution time: 0.0672
ERROR - 2022-03-12 00:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:39:22 --> Config Class Initialized
INFO - 2022-03-12 00:39:22 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:39:22 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:39:22 --> Utf8 Class Initialized
INFO - 2022-03-12 00:39:22 --> URI Class Initialized
INFO - 2022-03-12 00:39:22 --> Router Class Initialized
INFO - 2022-03-12 00:39:22 --> Output Class Initialized
INFO - 2022-03-12 00:39:22 --> Security Class Initialized
DEBUG - 2022-03-12 00:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:39:22 --> Input Class Initialized
INFO - 2022-03-12 00:39:22 --> Language Class Initialized
ERROR - 2022-03-12 00:39:22 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-12 00:41:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:41:02 --> Config Class Initialized
INFO - 2022-03-12 00:41:02 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:41:02 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:41:02 --> Utf8 Class Initialized
INFO - 2022-03-12 00:41:02 --> URI Class Initialized
INFO - 2022-03-12 00:41:02 --> Router Class Initialized
INFO - 2022-03-12 00:41:02 --> Output Class Initialized
INFO - 2022-03-12 00:41:02 --> Security Class Initialized
DEBUG - 2022-03-12 00:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:41:02 --> Input Class Initialized
INFO - 2022-03-12 00:41:02 --> Language Class Initialized
INFO - 2022-03-12 00:41:02 --> Loader Class Initialized
INFO - 2022-03-12 00:41:02 --> Helper loaded: url_helper
INFO - 2022-03-12 00:41:02 --> Helper loaded: form_helper
INFO - 2022-03-12 00:41:02 --> Helper loaded: common_helper
INFO - 2022-03-12 00:41:02 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:41:02 --> Controller Class Initialized
INFO - 2022-03-12 00:41:02 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:41:02 --> Encrypt Class Initialized
INFO - 2022-03-12 00:41:02 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:41:02 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:41:02 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:41:02 --> Model "Users_model" initialized
INFO - 2022-03-12 00:41:02 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:41:03 --> Config Class Initialized
INFO - 2022-03-12 00:41:03 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:41:03 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:41:03 --> Utf8 Class Initialized
INFO - 2022-03-12 00:41:03 --> URI Class Initialized
INFO - 2022-03-12 00:41:03 --> Router Class Initialized
INFO - 2022-03-12 00:41:03 --> Output Class Initialized
INFO - 2022-03-12 00:41:03 --> Security Class Initialized
DEBUG - 2022-03-12 00:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:41:03 --> Input Class Initialized
INFO - 2022-03-12 00:41:03 --> Language Class Initialized
INFO - 2022-03-12 00:41:03 --> Loader Class Initialized
INFO - 2022-03-12 00:41:03 --> Helper loaded: url_helper
INFO - 2022-03-12 00:41:03 --> Helper loaded: form_helper
INFO - 2022-03-12 00:41:03 --> Helper loaded: common_helper
INFO - 2022-03-12 00:41:03 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:41:03 --> Controller Class Initialized
INFO - 2022-03-12 00:41:03 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:41:03 --> Encrypt Class Initialized
INFO - 2022-03-12 00:41:03 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:41:03 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:41:03 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:41:03 --> Model "Users_model" initialized
INFO - 2022-03-12 00:41:03 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:41:03 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:41:03 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:41:03 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:41:03 --> Final output sent to browser
DEBUG - 2022-03-12 00:41:03 --> Total execution time: 0.0646
ERROR - 2022-03-12 00:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:41:04 --> Config Class Initialized
INFO - 2022-03-12 00:41:04 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:41:04 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:41:04 --> Utf8 Class Initialized
INFO - 2022-03-12 00:41:04 --> URI Class Initialized
INFO - 2022-03-12 00:41:04 --> Router Class Initialized
INFO - 2022-03-12 00:41:04 --> Output Class Initialized
INFO - 2022-03-12 00:41:04 --> Security Class Initialized
DEBUG - 2022-03-12 00:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:41:04 --> Input Class Initialized
INFO - 2022-03-12 00:41:04 --> Language Class Initialized
ERROR - 2022-03-12 00:41:04 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-12 00:43:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:43:36 --> Config Class Initialized
INFO - 2022-03-12 00:43:36 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:43:36 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:43:36 --> Utf8 Class Initialized
INFO - 2022-03-12 00:43:36 --> URI Class Initialized
INFO - 2022-03-12 00:43:36 --> Router Class Initialized
INFO - 2022-03-12 00:43:36 --> Output Class Initialized
INFO - 2022-03-12 00:43:36 --> Security Class Initialized
DEBUG - 2022-03-12 00:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:43:36 --> Input Class Initialized
INFO - 2022-03-12 00:43:36 --> Language Class Initialized
INFO - 2022-03-12 00:43:36 --> Loader Class Initialized
INFO - 2022-03-12 00:43:36 --> Helper loaded: url_helper
INFO - 2022-03-12 00:43:36 --> Helper loaded: form_helper
INFO - 2022-03-12 00:43:36 --> Helper loaded: common_helper
INFO - 2022-03-12 00:43:36 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:43:36 --> Controller Class Initialized
INFO - 2022-03-12 00:43:36 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:43:36 --> Encrypt Class Initialized
INFO - 2022-03-12 00:43:36 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:43:36 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:43:36 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:43:36 --> Model "Users_model" initialized
INFO - 2022-03-12 00:43:36 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:43:36 --> Upload Class Initialized
INFO - 2022-03-12 00:43:36 --> Final output sent to browser
DEBUG - 2022-03-12 00:43:36 --> Total execution time: 0.0753
ERROR - 2022-03-12 00:43:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:43:48 --> Config Class Initialized
INFO - 2022-03-12 00:43:48 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:43:48 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:43:48 --> Utf8 Class Initialized
INFO - 2022-03-12 00:43:48 --> URI Class Initialized
INFO - 2022-03-12 00:43:48 --> Router Class Initialized
INFO - 2022-03-12 00:43:48 --> Output Class Initialized
INFO - 2022-03-12 00:43:48 --> Security Class Initialized
DEBUG - 2022-03-12 00:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:43:48 --> Input Class Initialized
INFO - 2022-03-12 00:43:48 --> Language Class Initialized
INFO - 2022-03-12 00:43:48 --> Loader Class Initialized
INFO - 2022-03-12 00:43:48 --> Helper loaded: url_helper
INFO - 2022-03-12 00:43:48 --> Helper loaded: form_helper
INFO - 2022-03-12 00:43:48 --> Helper loaded: common_helper
INFO - 2022-03-12 00:43:48 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:43:48 --> Controller Class Initialized
INFO - 2022-03-12 00:43:48 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:43:48 --> Encrypt Class Initialized
INFO - 2022-03-12 00:43:48 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:43:48 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:43:48 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:43:48 --> Model "Users_model" initialized
INFO - 2022-03-12 00:43:48 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:43:48 --> Upload Class Initialized
INFO - 2022-03-12 00:43:48 --> Final output sent to browser
DEBUG - 2022-03-12 00:43:48 --> Total execution time: 0.0445
ERROR - 2022-03-12 00:43:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:43:52 --> Config Class Initialized
INFO - 2022-03-12 00:43:52 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:43:52 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:43:52 --> Utf8 Class Initialized
INFO - 2022-03-12 00:43:52 --> URI Class Initialized
INFO - 2022-03-12 00:43:52 --> Router Class Initialized
INFO - 2022-03-12 00:43:52 --> Output Class Initialized
INFO - 2022-03-12 00:43:52 --> Security Class Initialized
DEBUG - 2022-03-12 00:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:43:52 --> Input Class Initialized
INFO - 2022-03-12 00:43:52 --> Language Class Initialized
INFO - 2022-03-12 00:43:52 --> Loader Class Initialized
INFO - 2022-03-12 00:43:52 --> Helper loaded: url_helper
INFO - 2022-03-12 00:43:52 --> Helper loaded: form_helper
INFO - 2022-03-12 00:43:52 --> Helper loaded: common_helper
INFO - 2022-03-12 00:43:52 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:43:52 --> Controller Class Initialized
INFO - 2022-03-12 00:43:52 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:43:52 --> Encrypt Class Initialized
INFO - 2022-03-12 00:43:52 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:43:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:43:52 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:43:52 --> Model "Users_model" initialized
INFO - 2022-03-12 00:43:52 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:43:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:43:52 --> Config Class Initialized
INFO - 2022-03-12 00:43:52 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:43:52 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:43:52 --> Utf8 Class Initialized
INFO - 2022-03-12 00:43:52 --> URI Class Initialized
INFO - 2022-03-12 00:43:52 --> Router Class Initialized
INFO - 2022-03-12 00:43:52 --> Output Class Initialized
INFO - 2022-03-12 00:43:52 --> Security Class Initialized
DEBUG - 2022-03-12 00:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:43:52 --> Input Class Initialized
INFO - 2022-03-12 00:43:52 --> Language Class Initialized
INFO - 2022-03-12 00:43:52 --> Loader Class Initialized
INFO - 2022-03-12 00:43:52 --> Helper loaded: url_helper
INFO - 2022-03-12 00:43:52 --> Helper loaded: form_helper
INFO - 2022-03-12 00:43:52 --> Helper loaded: common_helper
INFO - 2022-03-12 00:43:52 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:43:52 --> Controller Class Initialized
INFO - 2022-03-12 00:43:52 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:43:52 --> Encrypt Class Initialized
INFO - 2022-03-12 00:43:52 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:43:52 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:43:52 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:43:52 --> Model "Users_model" initialized
INFO - 2022-03-12 00:43:52 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:43:52 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:43:52 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:43:52 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:43:52 --> Final output sent to browser
DEBUG - 2022-03-12 00:43:52 --> Total execution time: 0.0528
ERROR - 2022-03-12 00:43:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:43:53 --> Config Class Initialized
INFO - 2022-03-12 00:43:53 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:43:53 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:43:53 --> Utf8 Class Initialized
INFO - 2022-03-12 00:43:53 --> URI Class Initialized
INFO - 2022-03-12 00:43:53 --> Router Class Initialized
INFO - 2022-03-12 00:43:53 --> Output Class Initialized
INFO - 2022-03-12 00:43:53 --> Security Class Initialized
DEBUG - 2022-03-12 00:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:43:53 --> Input Class Initialized
INFO - 2022-03-12 00:43:53 --> Language Class Initialized
ERROR - 2022-03-12 00:43:53 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-12 00:53:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:53:56 --> Config Class Initialized
INFO - 2022-03-12 00:53:56 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:53:56 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:53:56 --> Utf8 Class Initialized
INFO - 2022-03-12 00:53:56 --> URI Class Initialized
INFO - 2022-03-12 00:53:56 --> Router Class Initialized
INFO - 2022-03-12 00:53:56 --> Output Class Initialized
INFO - 2022-03-12 00:53:56 --> Security Class Initialized
DEBUG - 2022-03-12 00:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:53:56 --> Input Class Initialized
INFO - 2022-03-12 00:53:56 --> Language Class Initialized
INFO - 2022-03-12 00:53:56 --> Loader Class Initialized
INFO - 2022-03-12 00:53:56 --> Helper loaded: url_helper
INFO - 2022-03-12 00:53:56 --> Helper loaded: form_helper
INFO - 2022-03-12 00:53:56 --> Helper loaded: common_helper
INFO - 2022-03-12 00:53:56 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:53:56 --> Controller Class Initialized
INFO - 2022-03-12 00:53:56 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:53:56 --> Encrypt Class Initialized
INFO - 2022-03-12 00:53:56 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:53:56 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:53:56 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:53:56 --> Model "Users_model" initialized
INFO - 2022-03-12 00:53:56 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 00:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 00:53:57 --> Config Class Initialized
INFO - 2022-03-12 00:53:57 --> Hooks Class Initialized
DEBUG - 2022-03-12 00:53:57 --> UTF-8 Support Enabled
INFO - 2022-03-12 00:53:57 --> Utf8 Class Initialized
INFO - 2022-03-12 00:53:57 --> URI Class Initialized
INFO - 2022-03-12 00:53:57 --> Router Class Initialized
INFO - 2022-03-12 00:53:57 --> Output Class Initialized
INFO - 2022-03-12 00:53:57 --> Security Class Initialized
DEBUG - 2022-03-12 00:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 00:53:57 --> Input Class Initialized
INFO - 2022-03-12 00:53:57 --> Language Class Initialized
INFO - 2022-03-12 00:53:57 --> Loader Class Initialized
INFO - 2022-03-12 00:53:57 --> Helper loaded: url_helper
INFO - 2022-03-12 00:53:57 --> Helper loaded: form_helper
INFO - 2022-03-12 00:53:57 --> Helper loaded: common_helper
INFO - 2022-03-12 00:53:57 --> Database Driver Class Initialized
DEBUG - 2022-03-12 00:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 00:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 00:53:57 --> Controller Class Initialized
INFO - 2022-03-12 00:53:57 --> Form Validation Class Initialized
DEBUG - 2022-03-12 00:53:57 --> Encrypt Class Initialized
INFO - 2022-03-12 00:53:57 --> Model "Patient_model" initialized
INFO - 2022-03-12 00:53:57 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 00:53:57 --> Model "Prefix_master" initialized
INFO - 2022-03-12 00:53:57 --> Model "Users_model" initialized
INFO - 2022-03-12 00:53:57 --> Model "Hospital_model" initialized
INFO - 2022-03-12 00:53:57 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 00:53:57 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 00:53:57 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 00:53:57 --> Final output sent to browser
DEBUG - 2022-03-12 00:53:57 --> Total execution time: 0.0720
ERROR - 2022-03-12 01:05:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:05:00 --> Config Class Initialized
INFO - 2022-03-12 01:05:00 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:05:00 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:05:00 --> Utf8 Class Initialized
INFO - 2022-03-12 01:05:00 --> URI Class Initialized
INFO - 2022-03-12 01:05:00 --> Router Class Initialized
INFO - 2022-03-12 01:05:00 --> Output Class Initialized
INFO - 2022-03-12 01:05:00 --> Security Class Initialized
DEBUG - 2022-03-12 01:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:05:00 --> Input Class Initialized
INFO - 2022-03-12 01:05:00 --> Language Class Initialized
INFO - 2022-03-12 01:05:00 --> Loader Class Initialized
INFO - 2022-03-12 01:05:00 --> Helper loaded: url_helper
INFO - 2022-03-12 01:05:00 --> Helper loaded: form_helper
INFO - 2022-03-12 01:05:00 --> Helper loaded: common_helper
INFO - 2022-03-12 01:05:00 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:05:00 --> Controller Class Initialized
INFO - 2022-03-12 01:05:00 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:05:00 --> Encrypt Class Initialized
INFO - 2022-03-12 01:05:00 --> Model "Patient_model" initialized
INFO - 2022-03-12 01:05:00 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 01:05:00 --> Model "Prefix_master" initialized
INFO - 2022-03-12 01:05:00 --> Model "Users_model" initialized
INFO - 2022-03-12 01:05:00 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 01:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:05:01 --> Config Class Initialized
INFO - 2022-03-12 01:05:01 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:05:01 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:05:01 --> Utf8 Class Initialized
INFO - 2022-03-12 01:05:01 --> URI Class Initialized
INFO - 2022-03-12 01:05:01 --> Router Class Initialized
INFO - 2022-03-12 01:05:01 --> Output Class Initialized
INFO - 2022-03-12 01:05:01 --> Security Class Initialized
DEBUG - 2022-03-12 01:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:05:01 --> Input Class Initialized
INFO - 2022-03-12 01:05:01 --> Language Class Initialized
INFO - 2022-03-12 01:05:01 --> Loader Class Initialized
INFO - 2022-03-12 01:05:01 --> Helper loaded: url_helper
INFO - 2022-03-12 01:05:01 --> Helper loaded: form_helper
INFO - 2022-03-12 01:05:01 --> Helper loaded: common_helper
INFO - 2022-03-12 01:05:01 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:05:01 --> Controller Class Initialized
INFO - 2022-03-12 01:05:01 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:05:01 --> Encrypt Class Initialized
INFO - 2022-03-12 01:05:01 --> Model "Patient_model" initialized
INFO - 2022-03-12 01:05:01 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 01:05:01 --> Model "Prefix_master" initialized
INFO - 2022-03-12 01:05:01 --> Model "Users_model" initialized
INFO - 2022-03-12 01:05:01 --> Model "Hospital_model" initialized
INFO - 2022-03-12 01:05:01 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 01:05:01 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 01:05:01 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 01:05:01 --> Final output sent to browser
DEBUG - 2022-03-12 01:05:01 --> Total execution time: 0.0896
ERROR - 2022-03-12 01:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:05:02 --> Config Class Initialized
INFO - 2022-03-12 01:05:02 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:05:02 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:05:02 --> Utf8 Class Initialized
INFO - 2022-03-12 01:05:02 --> URI Class Initialized
INFO - 2022-03-12 01:05:02 --> Router Class Initialized
INFO - 2022-03-12 01:05:02 --> Output Class Initialized
INFO - 2022-03-12 01:05:02 --> Security Class Initialized
DEBUG - 2022-03-12 01:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:05:02 --> Input Class Initialized
INFO - 2022-03-12 01:05:02 --> Language Class Initialized
ERROR - 2022-03-12 01:05:02 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-12 01:06:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:06:32 --> Config Class Initialized
INFO - 2022-03-12 01:06:32 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:06:32 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:06:32 --> Utf8 Class Initialized
INFO - 2022-03-12 01:06:32 --> URI Class Initialized
INFO - 2022-03-12 01:06:32 --> Router Class Initialized
INFO - 2022-03-12 01:06:32 --> Output Class Initialized
INFO - 2022-03-12 01:06:32 --> Security Class Initialized
DEBUG - 2022-03-12 01:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:06:32 --> Input Class Initialized
INFO - 2022-03-12 01:06:32 --> Language Class Initialized
INFO - 2022-03-12 01:06:32 --> Loader Class Initialized
INFO - 2022-03-12 01:06:32 --> Helper loaded: url_helper
INFO - 2022-03-12 01:06:32 --> Helper loaded: form_helper
INFO - 2022-03-12 01:06:32 --> Helper loaded: common_helper
INFO - 2022-03-12 01:06:32 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:06:32 --> Controller Class Initialized
INFO - 2022-03-12 01:06:32 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:06:32 --> Encrypt Class Initialized
INFO - 2022-03-12 01:06:32 --> Model "Patient_model" initialized
INFO - 2022-03-12 01:06:32 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 01:06:32 --> Model "Prefix_master" initialized
INFO - 2022-03-12 01:06:32 --> Model "Users_model" initialized
INFO - 2022-03-12 01:06:32 --> Model "Hospital_model" initialized
ERROR - 2022-03-12 01:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:06:33 --> Config Class Initialized
INFO - 2022-03-12 01:06:33 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:06:33 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:06:33 --> Utf8 Class Initialized
INFO - 2022-03-12 01:06:33 --> URI Class Initialized
INFO - 2022-03-12 01:06:33 --> Router Class Initialized
INFO - 2022-03-12 01:06:33 --> Output Class Initialized
INFO - 2022-03-12 01:06:33 --> Security Class Initialized
DEBUG - 2022-03-12 01:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:06:33 --> Input Class Initialized
INFO - 2022-03-12 01:06:33 --> Language Class Initialized
INFO - 2022-03-12 01:06:33 --> Loader Class Initialized
INFO - 2022-03-12 01:06:33 --> Helper loaded: url_helper
INFO - 2022-03-12 01:06:33 --> Helper loaded: form_helper
INFO - 2022-03-12 01:06:33 --> Helper loaded: common_helper
INFO - 2022-03-12 01:06:33 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:06:33 --> Controller Class Initialized
INFO - 2022-03-12 01:06:33 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:06:33 --> Encrypt Class Initialized
INFO - 2022-03-12 01:06:33 --> Model "Patient_model" initialized
INFO - 2022-03-12 01:06:33 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 01:06:33 --> Model "Prefix_master" initialized
INFO - 2022-03-12 01:06:33 --> Model "Users_model" initialized
INFO - 2022-03-12 01:06:33 --> Model "Hospital_model" initialized
INFO - 2022-03-12 01:06:33 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 01:06:33 --> File loaded: /home3/karoteam/public_html/application/views/patientcase/index.php
INFO - 2022-03-12 01:06:33 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 01:06:33 --> Final output sent to browser
DEBUG - 2022-03-12 01:06:33 --> Total execution time: 0.0767
ERROR - 2022-03-12 01:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:06:34 --> Config Class Initialized
INFO - 2022-03-12 01:06:34 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:06:34 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:06:34 --> Utf8 Class Initialized
INFO - 2022-03-12 01:06:34 --> URI Class Initialized
INFO - 2022-03-12 01:06:34 --> Router Class Initialized
INFO - 2022-03-12 01:06:34 --> Output Class Initialized
INFO - 2022-03-12 01:06:34 --> Security Class Initialized
DEBUG - 2022-03-12 01:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:06:34 --> Input Class Initialized
INFO - 2022-03-12 01:06:34 --> Language Class Initialized
ERROR - 2022-03-12 01:06:34 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-12 01:07:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:07:16 --> Config Class Initialized
INFO - 2022-03-12 01:07:16 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:07:16 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:07:16 --> Utf8 Class Initialized
INFO - 2022-03-12 01:07:16 --> URI Class Initialized
INFO - 2022-03-12 01:07:16 --> Router Class Initialized
INFO - 2022-03-12 01:07:16 --> Output Class Initialized
INFO - 2022-03-12 01:07:16 --> Security Class Initialized
DEBUG - 2022-03-12 01:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:07:16 --> Input Class Initialized
INFO - 2022-03-12 01:07:16 --> Language Class Initialized
INFO - 2022-03-12 01:07:16 --> Loader Class Initialized
INFO - 2022-03-12 01:07:16 --> Helper loaded: url_helper
INFO - 2022-03-12 01:07:16 --> Helper loaded: form_helper
INFO - 2022-03-12 01:07:16 --> Helper loaded: common_helper
INFO - 2022-03-12 01:07:16 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:07:16 --> Controller Class Initialized
INFO - 2022-03-12 01:07:16 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:07:16 --> Encrypt Class Initialized
INFO - 2022-03-12 01:07:16 --> Model "Patient_model" initialized
INFO - 2022-03-12 01:07:16 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 01:07:16 --> Model "Referredby_model" initialized
INFO - 2022-03-12 01:07:16 --> Model "Prefix_master" initialized
INFO - 2022-03-12 01:07:16 --> Model "Hospital_model" initialized
INFO - 2022-03-12 01:07:16 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 01:07:23 --> File loaded: /home3/karoteam/public_html/application/views/patient/patientview.php
INFO - 2022-03-12 01:07:23 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
ERROR - 2022-03-12 01:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:07:24 --> Config Class Initialized
INFO - 2022-03-12 01:07:24 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:07:24 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:07:24 --> Utf8 Class Initialized
INFO - 2022-03-12 01:07:24 --> URI Class Initialized
INFO - 2022-03-12 01:07:24 --> Router Class Initialized
INFO - 2022-03-12 01:07:24 --> Output Class Initialized
INFO - 2022-03-12 01:07:24 --> Security Class Initialized
DEBUG - 2022-03-12 01:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:07:24 --> Input Class Initialized
INFO - 2022-03-12 01:07:24 --> Language Class Initialized
ERROR - 2022-03-12 01:07:24 --> 404 Page Not Found: Karoclient/usersprofile
INFO - 2022-03-12 01:07:25 --> Final output sent to browser
DEBUG - 2022-03-12 01:07:25 --> Total execution time: 6.7921
ERROR - 2022-03-12 01:10:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:10:23 --> Config Class Initialized
INFO - 2022-03-12 01:10:23 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:10:23 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:10:23 --> Utf8 Class Initialized
INFO - 2022-03-12 01:10:23 --> URI Class Initialized
INFO - 2022-03-12 01:10:23 --> Router Class Initialized
INFO - 2022-03-12 01:10:23 --> Output Class Initialized
INFO - 2022-03-12 01:10:23 --> Security Class Initialized
DEBUG - 2022-03-12 01:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:10:23 --> Input Class Initialized
INFO - 2022-03-12 01:10:23 --> Language Class Initialized
INFO - 2022-03-12 01:10:23 --> Loader Class Initialized
INFO - 2022-03-12 01:10:23 --> Helper loaded: url_helper
INFO - 2022-03-12 01:10:23 --> Helper loaded: form_helper
INFO - 2022-03-12 01:10:23 --> Helper loaded: common_helper
INFO - 2022-03-12 01:10:24 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:10:24 --> Controller Class Initialized
INFO - 2022-03-12 01:10:24 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:10:24 --> Encrypt Class Initialized
INFO - 2022-03-12 01:10:24 --> Model "Patient_model" initialized
INFO - 2022-03-12 01:10:24 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 01:10:24 --> Model "Prefix_master" initialized
INFO - 2022-03-12 01:10:24 --> Model "Users_model" initialized
INFO - 2022-03-12 01:10:24 --> Model "Hospital_model" initialized
INFO - 2022-03-12 01:10:24 --> File loaded: /home3/karoteam/public_html/application/views//patientcase/patient_pdf.php
INFO - 2022-03-12 01:10:25 --> Final output sent to browser
DEBUG - 2022-03-12 01:10:25 --> Total execution time: 1.0577
ERROR - 2022-03-12 01:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:11:52 --> Config Class Initialized
INFO - 2022-03-12 01:11:52 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:11:52 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:11:52 --> Utf8 Class Initialized
INFO - 2022-03-12 01:11:52 --> URI Class Initialized
DEBUG - 2022-03-12 01:11:52 --> No URI present. Default controller set.
INFO - 2022-03-12 01:11:52 --> Router Class Initialized
INFO - 2022-03-12 01:11:52 --> Output Class Initialized
INFO - 2022-03-12 01:11:52 --> Security Class Initialized
DEBUG - 2022-03-12 01:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:11:52 --> Input Class Initialized
INFO - 2022-03-12 01:11:52 --> Language Class Initialized
INFO - 2022-03-12 01:11:52 --> Loader Class Initialized
INFO - 2022-03-12 01:11:52 --> Helper loaded: url_helper
INFO - 2022-03-12 01:11:52 --> Helper loaded: form_helper
INFO - 2022-03-12 01:11:52 --> Helper loaded: common_helper
INFO - 2022-03-12 01:11:52 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:11:52 --> Controller Class Initialized
INFO - 2022-03-12 01:11:52 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:11:52 --> Encrypt Class Initialized
DEBUG - 2022-03-12 01:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 01:11:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 01:11:52 --> Email Class Initialized
INFO - 2022-03-12 01:11:52 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 01:11:52 --> Calendar Class Initialized
INFO - 2022-03-12 01:11:52 --> Model "Login_model" initialized
INFO - 2022-03-12 01:11:52 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 01:11:52 --> Final output sent to browser
DEBUG - 2022-03-12 01:11:52 --> Total execution time: 0.0990
ERROR - 2022-03-12 01:58:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:58:26 --> Config Class Initialized
INFO - 2022-03-12 01:58:26 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:58:26 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:58:26 --> Utf8 Class Initialized
INFO - 2022-03-12 01:58:26 --> URI Class Initialized
INFO - 2022-03-12 01:58:26 --> Router Class Initialized
INFO - 2022-03-12 01:58:26 --> Output Class Initialized
INFO - 2022-03-12 01:58:26 --> Security Class Initialized
DEBUG - 2022-03-12 01:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:58:26 --> Input Class Initialized
INFO - 2022-03-12 01:58:26 --> Language Class Initialized
INFO - 2022-03-12 01:58:26 --> Loader Class Initialized
INFO - 2022-03-12 01:58:26 --> Helper loaded: url_helper
INFO - 2022-03-12 01:58:26 --> Helper loaded: form_helper
INFO - 2022-03-12 01:58:26 --> Helper loaded: common_helper
INFO - 2022-03-12 01:58:26 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:58:26 --> Controller Class Initialized
INFO - 2022-03-12 01:58:26 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:58:26 --> Encrypt Class Initialized
INFO - 2022-03-12 01:58:26 --> Model "Patient_model" initialized
INFO - 2022-03-12 01:58:26 --> Model "Patientcase_model" initialized
INFO - 2022-03-12 01:58:26 --> Model "Referredby_model" initialized
INFO - 2022-03-12 01:58:26 --> Model "Prefix_master" initialized
INFO - 2022-03-12 01:58:26 --> Model "Hospital_model" initialized
INFO - 2022-03-12 01:58:26 --> File loaded: /home3/karoteam/public_html/application/views/header.php
INFO - 2022-03-12 01:58:26 --> File loaded: /home3/karoteam/public_html/application/views/patient/index.php
INFO - 2022-03-12 01:58:26 --> File loaded: /home3/karoteam/public_html/application/views/footer.php
INFO - 2022-03-12 01:58:26 --> Final output sent to browser
DEBUG - 2022-03-12 01:58:26 --> Total execution time: 0.3591
ERROR - 2022-03-12 01:58:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:58:27 --> Config Class Initialized
INFO - 2022-03-12 01:58:27 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:58:27 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:58:27 --> Utf8 Class Initialized
INFO - 2022-03-12 01:58:27 --> URI Class Initialized
INFO - 2022-03-12 01:58:27 --> Router Class Initialized
INFO - 2022-03-12 01:58:27 --> Output Class Initialized
INFO - 2022-03-12 01:58:27 --> Security Class Initialized
DEBUG - 2022-03-12 01:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:58:27 --> Input Class Initialized
INFO - 2022-03-12 01:58:27 --> Language Class Initialized
ERROR - 2022-03-12 01:58:27 --> 404 Page Not Found: Karoclient/usersprofile
ERROR - 2022-03-12 01:58:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:58:41 --> Config Class Initialized
INFO - 2022-03-12 01:58:41 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:58:41 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:58:41 --> Utf8 Class Initialized
INFO - 2022-03-12 01:58:41 --> URI Class Initialized
INFO - 2022-03-12 01:58:41 --> Router Class Initialized
INFO - 2022-03-12 01:58:41 --> Output Class Initialized
INFO - 2022-03-12 01:58:41 --> Security Class Initialized
DEBUG - 2022-03-12 01:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:58:41 --> Input Class Initialized
INFO - 2022-03-12 01:58:41 --> Language Class Initialized
INFO - 2022-03-12 01:58:41 --> Loader Class Initialized
INFO - 2022-03-12 01:58:41 --> Helper loaded: url_helper
INFO - 2022-03-12 01:58:41 --> Helper loaded: form_helper
INFO - 2022-03-12 01:58:41 --> Helper loaded: common_helper
INFO - 2022-03-12 01:58:41 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:58:41 --> Controller Class Initialized
INFO - 2022-03-12 01:58:41 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:58:41 --> Encrypt Class Initialized
DEBUG - 2022-03-12 01:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 01:58:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 01:58:41 --> Email Class Initialized
INFO - 2022-03-12 01:58:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 01:58:41 --> Calendar Class Initialized
INFO - 2022-03-12 01:58:41 --> Model "Login_model" initialized
ERROR - 2022-03-12 01:58:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 01:58:42 --> Config Class Initialized
INFO - 2022-03-12 01:58:42 --> Hooks Class Initialized
DEBUG - 2022-03-12 01:58:42 --> UTF-8 Support Enabled
INFO - 2022-03-12 01:58:42 --> Utf8 Class Initialized
INFO - 2022-03-12 01:58:42 --> URI Class Initialized
INFO - 2022-03-12 01:58:42 --> Router Class Initialized
INFO - 2022-03-12 01:58:42 --> Output Class Initialized
INFO - 2022-03-12 01:58:42 --> Security Class Initialized
DEBUG - 2022-03-12 01:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 01:58:42 --> Input Class Initialized
INFO - 2022-03-12 01:58:42 --> Language Class Initialized
INFO - 2022-03-12 01:58:42 --> Loader Class Initialized
INFO - 2022-03-12 01:58:42 --> Helper loaded: url_helper
INFO - 2022-03-12 01:58:42 --> Helper loaded: form_helper
INFO - 2022-03-12 01:58:42 --> Helper loaded: common_helper
INFO - 2022-03-12 01:58:42 --> Database Driver Class Initialized
DEBUG - 2022-03-12 01:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 01:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 01:58:42 --> Controller Class Initialized
INFO - 2022-03-12 01:58:42 --> Form Validation Class Initialized
DEBUG - 2022-03-12 01:58:42 --> Encrypt Class Initialized
DEBUG - 2022-03-12 01:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 01:58:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 01:58:42 --> Email Class Initialized
INFO - 2022-03-12 01:58:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 01:58:42 --> Calendar Class Initialized
INFO - 2022-03-12 01:58:42 --> Model "Login_model" initialized
INFO - 2022-03-12 01:58:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 01:58:42 --> Final output sent to browser
DEBUG - 2022-03-12 01:58:42 --> Total execution time: 0.0269
ERROR - 2022-03-12 05:15:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 05:15:09 --> Config Class Initialized
INFO - 2022-03-12 05:15:09 --> Hooks Class Initialized
DEBUG - 2022-03-12 05:15:09 --> UTF-8 Support Enabled
INFO - 2022-03-12 05:15:09 --> Utf8 Class Initialized
INFO - 2022-03-12 05:15:09 --> URI Class Initialized
INFO - 2022-03-12 05:15:09 --> Router Class Initialized
INFO - 2022-03-12 05:15:09 --> Output Class Initialized
INFO - 2022-03-12 05:15:09 --> Security Class Initialized
DEBUG - 2022-03-12 05:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 05:15:09 --> Input Class Initialized
INFO - 2022-03-12 05:15:09 --> Language Class Initialized
ERROR - 2022-03-12 05:15:09 --> 404 Page Not Found: Aws/.credentials
ERROR - 2022-03-12 05:15:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 05:15:09 --> Config Class Initialized
INFO - 2022-03-12 05:15:09 --> Hooks Class Initialized
DEBUG - 2022-03-12 05:15:09 --> UTF-8 Support Enabled
INFO - 2022-03-12 05:15:09 --> Utf8 Class Initialized
INFO - 2022-03-12 05:15:09 --> URI Class Initialized
INFO - 2022-03-12 05:15:09 --> Router Class Initialized
INFO - 2022-03-12 05:15:09 --> Output Class Initialized
INFO - 2022-03-12 05:15:09 --> Security Class Initialized
DEBUG - 2022-03-12 05:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 05:15:09 --> Input Class Initialized
INFO - 2022-03-12 05:15:09 --> Language Class Initialized
ERROR - 2022-03-12 05:15:09 --> 404 Page Not Found: Aws/.credentials
ERROR - 2022-03-12 13:22:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 13:22:13 --> Config Class Initialized
INFO - 2022-03-12 13:22:13 --> Hooks Class Initialized
DEBUG - 2022-03-12 13:22:13 --> UTF-8 Support Enabled
INFO - 2022-03-12 13:22:13 --> Utf8 Class Initialized
INFO - 2022-03-12 13:22:13 --> URI Class Initialized
DEBUG - 2022-03-12 13:22:13 --> No URI present. Default controller set.
INFO - 2022-03-12 13:22:13 --> Router Class Initialized
INFO - 2022-03-12 13:22:13 --> Output Class Initialized
INFO - 2022-03-12 13:22:13 --> Security Class Initialized
DEBUG - 2022-03-12 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 13:22:13 --> Input Class Initialized
INFO - 2022-03-12 13:22:13 --> Language Class Initialized
INFO - 2022-03-12 13:22:13 --> Loader Class Initialized
INFO - 2022-03-12 13:22:13 --> Helper loaded: url_helper
INFO - 2022-03-12 13:22:13 --> Helper loaded: form_helper
INFO - 2022-03-12 13:22:13 --> Helper loaded: common_helper
INFO - 2022-03-12 13:22:13 --> Database Driver Class Initialized
DEBUG - 2022-03-12 13:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 13:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 13:22:13 --> Controller Class Initialized
INFO - 2022-03-12 13:22:13 --> Form Validation Class Initialized
DEBUG - 2022-03-12 13:22:13 --> Encrypt Class Initialized
DEBUG - 2022-03-12 13:22:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 13:22:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 13:22:13 --> Email Class Initialized
INFO - 2022-03-12 13:22:13 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 13:22:13 --> Calendar Class Initialized
INFO - 2022-03-12 13:22:13 --> Model "Login_model" initialized
INFO - 2022-03-12 13:22:13 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 13:22:13 --> Final output sent to browser
DEBUG - 2022-03-12 13:22:13 --> Total execution time: 0.0546
ERROR - 2022-03-12 13:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 13:22:17 --> Config Class Initialized
INFO - 2022-03-12 13:22:17 --> Hooks Class Initialized
DEBUG - 2022-03-12 13:22:17 --> UTF-8 Support Enabled
INFO - 2022-03-12 13:22:17 --> Utf8 Class Initialized
INFO - 2022-03-12 13:22:17 --> URI Class Initialized
DEBUG - 2022-03-12 13:22:17 --> No URI present. Default controller set.
INFO - 2022-03-12 13:22:17 --> Router Class Initialized
INFO - 2022-03-12 13:22:17 --> Output Class Initialized
INFO - 2022-03-12 13:22:17 --> Security Class Initialized
DEBUG - 2022-03-12 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 13:22:17 --> Input Class Initialized
INFO - 2022-03-12 13:22:17 --> Language Class Initialized
INFO - 2022-03-12 13:22:17 --> Loader Class Initialized
INFO - 2022-03-12 13:22:17 --> Helper loaded: url_helper
INFO - 2022-03-12 13:22:17 --> Helper loaded: form_helper
INFO - 2022-03-12 13:22:17 --> Helper loaded: common_helper
INFO - 2022-03-12 13:22:17 --> Database Driver Class Initialized
DEBUG - 2022-03-12 13:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 13:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 13:22:17 --> Controller Class Initialized
INFO - 2022-03-12 13:22:17 --> Form Validation Class Initialized
DEBUG - 2022-03-12 13:22:17 --> Encrypt Class Initialized
DEBUG - 2022-03-12 13:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 13:22:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 13:22:17 --> Email Class Initialized
INFO - 2022-03-12 13:22:17 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 13:22:17 --> Calendar Class Initialized
INFO - 2022-03-12 13:22:17 --> Model "Login_model" initialized
INFO - 2022-03-12 13:22:17 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 13:22:17 --> Final output sent to browser
DEBUG - 2022-03-12 13:22:17 --> Total execution time: 0.0301
ERROR - 2022-03-12 13:22:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 13:22:24 --> Config Class Initialized
INFO - 2022-03-12 13:22:24 --> Hooks Class Initialized
DEBUG - 2022-03-12 13:22:24 --> UTF-8 Support Enabled
INFO - 2022-03-12 13:22:24 --> Utf8 Class Initialized
INFO - 2022-03-12 13:22:24 --> URI Class Initialized
DEBUG - 2022-03-12 13:22:24 --> No URI present. Default controller set.
INFO - 2022-03-12 13:22:24 --> Router Class Initialized
INFO - 2022-03-12 13:22:24 --> Output Class Initialized
INFO - 2022-03-12 13:22:24 --> Security Class Initialized
DEBUG - 2022-03-12 13:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 13:22:24 --> Input Class Initialized
INFO - 2022-03-12 13:22:24 --> Language Class Initialized
INFO - 2022-03-12 13:22:24 --> Loader Class Initialized
INFO - 2022-03-12 13:22:24 --> Helper loaded: url_helper
INFO - 2022-03-12 13:22:24 --> Helper loaded: form_helper
INFO - 2022-03-12 13:22:24 --> Helper loaded: common_helper
INFO - 2022-03-12 13:22:24 --> Database Driver Class Initialized
DEBUG - 2022-03-12 13:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 13:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 13:22:24 --> Controller Class Initialized
INFO - 2022-03-12 13:22:24 --> Form Validation Class Initialized
DEBUG - 2022-03-12 13:22:24 --> Encrypt Class Initialized
DEBUG - 2022-03-12 13:22:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 13:22:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 13:22:24 --> Email Class Initialized
INFO - 2022-03-12 13:22:24 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 13:22:24 --> Calendar Class Initialized
INFO - 2022-03-12 13:22:24 --> Model "Login_model" initialized
INFO - 2022-03-12 13:22:24 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 13:22:24 --> Final output sent to browser
DEBUG - 2022-03-12 13:22:24 --> Total execution time: 0.0266
ERROR - 2022-03-12 14:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 14:17:45 --> Config Class Initialized
INFO - 2022-03-12 14:17:45 --> Hooks Class Initialized
DEBUG - 2022-03-12 14:17:45 --> UTF-8 Support Enabled
INFO - 2022-03-12 14:17:45 --> Utf8 Class Initialized
INFO - 2022-03-12 14:17:45 --> URI Class Initialized
DEBUG - 2022-03-12 14:17:45 --> No URI present. Default controller set.
INFO - 2022-03-12 14:17:45 --> Router Class Initialized
INFO - 2022-03-12 14:17:45 --> Output Class Initialized
INFO - 2022-03-12 14:17:45 --> Security Class Initialized
DEBUG - 2022-03-12 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 14:17:45 --> Input Class Initialized
INFO - 2022-03-12 14:17:45 --> Language Class Initialized
INFO - 2022-03-12 14:17:45 --> Loader Class Initialized
INFO - 2022-03-12 14:17:45 --> Helper loaded: url_helper
INFO - 2022-03-12 14:17:45 --> Helper loaded: form_helper
INFO - 2022-03-12 14:17:45 --> Helper loaded: common_helper
INFO - 2022-03-12 14:17:45 --> Database Driver Class Initialized
DEBUG - 2022-03-12 14:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 14:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 14:17:45 --> Controller Class Initialized
INFO - 2022-03-12 14:17:45 --> Form Validation Class Initialized
DEBUG - 2022-03-12 14:17:45 --> Encrypt Class Initialized
DEBUG - 2022-03-12 14:17:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 14:17:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 14:17:45 --> Email Class Initialized
INFO - 2022-03-12 14:17:45 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 14:17:45 --> Calendar Class Initialized
INFO - 2022-03-12 14:17:45 --> Model "Login_model" initialized
INFO - 2022-03-12 14:17:45 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 14:17:45 --> Final output sent to browser
DEBUG - 2022-03-12 14:17:45 --> Total execution time: 0.0251
ERROR - 2022-03-12 14:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 14:17:47 --> Config Class Initialized
INFO - 2022-03-12 14:17:47 --> Hooks Class Initialized
DEBUG - 2022-03-12 14:17:47 --> UTF-8 Support Enabled
INFO - 2022-03-12 14:17:47 --> Utf8 Class Initialized
INFO - 2022-03-12 14:17:47 --> URI Class Initialized
INFO - 2022-03-12 14:17:47 --> Router Class Initialized
INFO - 2022-03-12 14:17:47 --> Output Class Initialized
INFO - 2022-03-12 14:17:47 --> Security Class Initialized
DEBUG - 2022-03-12 14:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 14:17:47 --> Input Class Initialized
INFO - 2022-03-12 14:17:47 --> Language Class Initialized
ERROR - 2022-03-12 14:17:47 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2022-03-12 14:19:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 14:19:35 --> Config Class Initialized
INFO - 2022-03-12 14:19:35 --> Hooks Class Initialized
DEBUG - 2022-03-12 14:19:35 --> UTF-8 Support Enabled
INFO - 2022-03-12 14:19:35 --> Utf8 Class Initialized
INFO - 2022-03-12 14:19:35 --> URI Class Initialized
INFO - 2022-03-12 14:19:35 --> Router Class Initialized
INFO - 2022-03-12 14:19:35 --> Output Class Initialized
INFO - 2022-03-12 14:19:35 --> Security Class Initialized
DEBUG - 2022-03-12 14:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 14:19:35 --> Input Class Initialized
INFO - 2022-03-12 14:19:35 --> Language Class Initialized
INFO - 2022-03-12 14:19:35 --> Loader Class Initialized
INFO - 2022-03-12 14:19:35 --> Helper loaded: url_helper
INFO - 2022-03-12 14:19:35 --> Helper loaded: form_helper
INFO - 2022-03-12 14:19:35 --> Helper loaded: common_helper
INFO - 2022-03-12 14:19:35 --> Database Driver Class Initialized
DEBUG - 2022-03-12 14:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 14:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 14:19:35 --> Controller Class Initialized
INFO - 2022-03-12 14:19:35 --> Form Validation Class Initialized
DEBUG - 2022-03-12 14:19:35 --> Encrypt Class Initialized
DEBUG - 2022-03-12 14:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 14:19:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 14:19:35 --> Email Class Initialized
INFO - 2022-03-12 14:19:35 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 14:19:35 --> Calendar Class Initialized
INFO - 2022-03-12 14:19:35 --> Model "Login_model" initialized
INFO - 2022-03-12 14:19:35 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 14:19:35 --> Final output sent to browser
DEBUG - 2022-03-12 14:19:35 --> Total execution time: 0.0351
ERROR - 2022-03-12 14:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 14:19:36 --> Config Class Initialized
INFO - 2022-03-12 14:19:36 --> Hooks Class Initialized
DEBUG - 2022-03-12 14:19:36 --> UTF-8 Support Enabled
INFO - 2022-03-12 14:19:36 --> Utf8 Class Initialized
INFO - 2022-03-12 14:19:36 --> URI Class Initialized
INFO - 2022-03-12 14:19:36 --> Router Class Initialized
INFO - 2022-03-12 14:19:36 --> Output Class Initialized
INFO - 2022-03-12 14:19:36 --> Security Class Initialized
DEBUG - 2022-03-12 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 14:19:36 --> Input Class Initialized
INFO - 2022-03-12 14:19:36 --> Language Class Initialized
INFO - 2022-03-12 14:19:36 --> Loader Class Initialized
INFO - 2022-03-12 14:19:36 --> Helper loaded: url_helper
INFO - 2022-03-12 14:19:36 --> Helper loaded: form_helper
INFO - 2022-03-12 14:19:36 --> Helper loaded: common_helper
INFO - 2022-03-12 14:19:36 --> Database Driver Class Initialized
DEBUG - 2022-03-12 14:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 14:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 14:19:36 --> Controller Class Initialized
INFO - 2022-03-12 14:19:36 --> Form Validation Class Initialized
DEBUG - 2022-03-12 14:19:36 --> Encrypt Class Initialized
DEBUG - 2022-03-12 14:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 14:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 14:19:36 --> Email Class Initialized
INFO - 2022-03-12 14:19:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 14:19:36 --> Calendar Class Initialized
INFO - 2022-03-12 14:19:36 --> Model "Login_model" initialized
ERROR - 2022-03-12 14:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 14:19:36 --> Config Class Initialized
INFO - 2022-03-12 14:19:36 --> Hooks Class Initialized
DEBUG - 2022-03-12 14:19:36 --> UTF-8 Support Enabled
INFO - 2022-03-12 14:19:36 --> Utf8 Class Initialized
INFO - 2022-03-12 14:19:36 --> URI Class Initialized
INFO - 2022-03-12 14:19:36 --> Router Class Initialized
INFO - 2022-03-12 14:19:36 --> Output Class Initialized
INFO - 2022-03-12 14:19:36 --> Security Class Initialized
DEBUG - 2022-03-12 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 14:19:36 --> Input Class Initialized
INFO - 2022-03-12 14:19:36 --> Language Class Initialized
INFO - 2022-03-12 14:19:36 --> Loader Class Initialized
INFO - 2022-03-12 14:19:36 --> Helper loaded: url_helper
INFO - 2022-03-12 14:19:36 --> Helper loaded: form_helper
INFO - 2022-03-12 14:19:36 --> Helper loaded: common_helper
INFO - 2022-03-12 14:19:36 --> Database Driver Class Initialized
DEBUG - 2022-03-12 14:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 14:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 14:19:36 --> Controller Class Initialized
INFO - 2022-03-12 14:19:36 --> Form Validation Class Initialized
DEBUG - 2022-03-12 14:19:36 --> Encrypt Class Initialized
DEBUG - 2022-03-12 14:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 14:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 14:19:36 --> Email Class Initialized
INFO - 2022-03-12 14:19:36 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 14:19:36 --> Calendar Class Initialized
INFO - 2022-03-12 14:19:36 --> Model "Login_model" initialized
ERROR - 2022-03-12 14:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 14:19:38 --> Config Class Initialized
INFO - 2022-03-12 14:19:38 --> Hooks Class Initialized
DEBUG - 2022-03-12 14:19:38 --> UTF-8 Support Enabled
INFO - 2022-03-12 14:19:38 --> Utf8 Class Initialized
INFO - 2022-03-12 14:19:38 --> URI Class Initialized
DEBUG - 2022-03-12 14:19:38 --> No URI present. Default controller set.
INFO - 2022-03-12 14:19:38 --> Router Class Initialized
INFO - 2022-03-12 14:19:38 --> Output Class Initialized
INFO - 2022-03-12 14:19:38 --> Security Class Initialized
DEBUG - 2022-03-12 14:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 14:19:38 --> Input Class Initialized
INFO - 2022-03-12 14:19:38 --> Language Class Initialized
INFO - 2022-03-12 14:19:38 --> Loader Class Initialized
INFO - 2022-03-12 14:19:38 --> Helper loaded: url_helper
INFO - 2022-03-12 14:19:38 --> Helper loaded: form_helper
INFO - 2022-03-12 14:19:38 --> Helper loaded: common_helper
INFO - 2022-03-12 14:19:38 --> Database Driver Class Initialized
DEBUG - 2022-03-12 14:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 14:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 14:19:38 --> Controller Class Initialized
INFO - 2022-03-12 14:19:38 --> Form Validation Class Initialized
DEBUG - 2022-03-12 14:19:38 --> Encrypt Class Initialized
DEBUG - 2022-03-12 14:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 14:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 14:19:38 --> Email Class Initialized
INFO - 2022-03-12 14:19:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 14:19:38 --> Calendar Class Initialized
INFO - 2022-03-12 14:19:38 --> Model "Login_model" initialized
INFO - 2022-03-12 14:19:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 14:19:38 --> Final output sent to browser
DEBUG - 2022-03-12 14:19:38 --> Total execution time: 0.0230
ERROR - 2022-03-12 14:54:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 14:54:59 --> Config Class Initialized
INFO - 2022-03-12 14:54:59 --> Hooks Class Initialized
DEBUG - 2022-03-12 14:54:59 --> UTF-8 Support Enabled
INFO - 2022-03-12 14:54:59 --> Utf8 Class Initialized
INFO - 2022-03-12 14:54:59 --> URI Class Initialized
DEBUG - 2022-03-12 14:54:59 --> No URI present. Default controller set.
INFO - 2022-03-12 14:54:59 --> Router Class Initialized
INFO - 2022-03-12 14:54:59 --> Output Class Initialized
INFO - 2022-03-12 14:54:59 --> Security Class Initialized
DEBUG - 2022-03-12 14:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 14:54:59 --> Input Class Initialized
INFO - 2022-03-12 14:54:59 --> Language Class Initialized
INFO - 2022-03-12 14:54:59 --> Loader Class Initialized
INFO - 2022-03-12 14:54:59 --> Helper loaded: url_helper
INFO - 2022-03-12 14:54:59 --> Helper loaded: form_helper
INFO - 2022-03-12 14:54:59 --> Helper loaded: common_helper
INFO - 2022-03-12 14:54:59 --> Database Driver Class Initialized
DEBUG - 2022-03-12 14:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 14:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 14:54:59 --> Controller Class Initialized
INFO - 2022-03-12 14:54:59 --> Form Validation Class Initialized
DEBUG - 2022-03-12 14:54:59 --> Encrypt Class Initialized
DEBUG - 2022-03-12 14:54:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 14:54:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 14:54:59 --> Email Class Initialized
INFO - 2022-03-12 14:54:59 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 14:54:59 --> Calendar Class Initialized
INFO - 2022-03-12 14:54:59 --> Model "Login_model" initialized
INFO - 2022-03-12 14:54:59 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 14:54:59 --> Final output sent to browser
DEBUG - 2022-03-12 14:54:59 --> Total execution time: 0.0289
ERROR - 2022-03-12 17:04:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 17:04:18 --> Config Class Initialized
INFO - 2022-03-12 17:04:18 --> Hooks Class Initialized
DEBUG - 2022-03-12 17:04:18 --> UTF-8 Support Enabled
INFO - 2022-03-12 17:04:18 --> Utf8 Class Initialized
INFO - 2022-03-12 17:04:18 --> URI Class Initialized
DEBUG - 2022-03-12 17:04:18 --> No URI present. Default controller set.
INFO - 2022-03-12 17:04:18 --> Router Class Initialized
INFO - 2022-03-12 17:04:18 --> Output Class Initialized
INFO - 2022-03-12 17:04:18 --> Security Class Initialized
DEBUG - 2022-03-12 17:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 17:04:18 --> Input Class Initialized
INFO - 2022-03-12 17:04:18 --> Language Class Initialized
INFO - 2022-03-12 17:04:18 --> Loader Class Initialized
INFO - 2022-03-12 17:04:18 --> Helper loaded: url_helper
INFO - 2022-03-12 17:04:18 --> Helper loaded: form_helper
INFO - 2022-03-12 17:04:18 --> Helper loaded: common_helper
INFO - 2022-03-12 17:04:18 --> Database Driver Class Initialized
DEBUG - 2022-03-12 17:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 17:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 17:04:18 --> Controller Class Initialized
INFO - 2022-03-12 17:04:18 --> Form Validation Class Initialized
DEBUG - 2022-03-12 17:04:18 --> Encrypt Class Initialized
DEBUG - 2022-03-12 17:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 17:04:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 17:04:18 --> Email Class Initialized
INFO - 2022-03-12 17:04:18 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 17:04:18 --> Calendar Class Initialized
INFO - 2022-03-12 17:04:18 --> Model "Login_model" initialized
INFO - 2022-03-12 17:04:18 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 17:04:18 --> Final output sent to browser
DEBUG - 2022-03-12 17:04:18 --> Total execution time: 0.0439
ERROR - 2022-03-12 22:49:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 22:49:38 --> Config Class Initialized
INFO - 2022-03-12 22:49:38 --> Hooks Class Initialized
DEBUG - 2022-03-12 22:49:38 --> UTF-8 Support Enabled
INFO - 2022-03-12 22:49:38 --> Utf8 Class Initialized
INFO - 2022-03-12 22:49:38 --> URI Class Initialized
DEBUG - 2022-03-12 22:49:38 --> No URI present. Default controller set.
INFO - 2022-03-12 22:49:38 --> Router Class Initialized
INFO - 2022-03-12 22:49:38 --> Output Class Initialized
INFO - 2022-03-12 22:49:38 --> Security Class Initialized
DEBUG - 2022-03-12 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 22:49:38 --> Input Class Initialized
INFO - 2022-03-12 22:49:38 --> Language Class Initialized
INFO - 2022-03-12 22:49:38 --> Loader Class Initialized
INFO - 2022-03-12 22:49:38 --> Helper loaded: url_helper
INFO - 2022-03-12 22:49:38 --> Helper loaded: form_helper
INFO - 2022-03-12 22:49:38 --> Helper loaded: common_helper
INFO - 2022-03-12 22:49:38 --> Database Driver Class Initialized
DEBUG - 2022-03-12 22:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 22:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 22:49:38 --> Controller Class Initialized
INFO - 2022-03-12 22:49:38 --> Form Validation Class Initialized
DEBUG - 2022-03-12 22:49:38 --> Encrypt Class Initialized
DEBUG - 2022-03-12 22:49:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 22:49:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 22:49:38 --> Email Class Initialized
INFO - 2022-03-12 22:49:38 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 22:49:38 --> Calendar Class Initialized
INFO - 2022-03-12 22:49:38 --> Model "Login_model" initialized
INFO - 2022-03-12 22:49:38 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 22:49:38 --> Final output sent to browser
DEBUG - 2022-03-12 22:49:38 --> Total execution time: 0.0286
ERROR - 2022-03-12 22:49:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 22:49:39 --> Config Class Initialized
INFO - 2022-03-12 22:49:39 --> Hooks Class Initialized
DEBUG - 2022-03-12 22:49:39 --> UTF-8 Support Enabled
INFO - 2022-03-12 22:49:39 --> Utf8 Class Initialized
INFO - 2022-03-12 22:49:39 --> URI Class Initialized
INFO - 2022-03-12 22:49:39 --> Router Class Initialized
INFO - 2022-03-12 22:49:39 --> Output Class Initialized
INFO - 2022-03-12 22:49:39 --> Security Class Initialized
DEBUG - 2022-03-12 22:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 22:49:39 --> Input Class Initialized
INFO - 2022-03-12 22:49:39 --> Language Class Initialized
INFO - 2022-03-12 22:49:39 --> Loader Class Initialized
INFO - 2022-03-12 22:49:39 --> Helper loaded: url_helper
INFO - 2022-03-12 22:49:39 --> Helper loaded: form_helper
INFO - 2022-03-12 22:49:39 --> Helper loaded: common_helper
INFO - 2022-03-12 22:49:39 --> Database Driver Class Initialized
DEBUG - 2022-03-12 22:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 22:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 22:49:39 --> Controller Class Initialized
INFO - 2022-03-12 22:49:39 --> Form Validation Class Initialized
DEBUG - 2022-03-12 22:49:39 --> Encrypt Class Initialized
DEBUG - 2022-03-12 22:49:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 22:49:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 22:49:39 --> Email Class Initialized
INFO - 2022-03-12 22:49:39 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 22:49:39 --> Calendar Class Initialized
INFO - 2022-03-12 22:49:39 --> Model "Login_model" initialized
INFO - 2022-03-12 22:49:39 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 22:49:39 --> Final output sent to browser
DEBUG - 2022-03-12 22:49:39 --> Total execution time: 0.0303
ERROR - 2022-03-12 22:49:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 22:49:40 --> Config Class Initialized
INFO - 2022-03-12 22:49:40 --> Hooks Class Initialized
DEBUG - 2022-03-12 22:49:40 --> UTF-8 Support Enabled
INFO - 2022-03-12 22:49:40 --> Utf8 Class Initialized
INFO - 2022-03-12 22:49:40 --> URI Class Initialized
DEBUG - 2022-03-12 22:49:40 --> No URI present. Default controller set.
INFO - 2022-03-12 22:49:40 --> Router Class Initialized
INFO - 2022-03-12 22:49:40 --> Output Class Initialized
INFO - 2022-03-12 22:49:40 --> Security Class Initialized
DEBUG - 2022-03-12 22:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 22:49:40 --> Input Class Initialized
INFO - 2022-03-12 22:49:40 --> Language Class Initialized
INFO - 2022-03-12 22:49:40 --> Loader Class Initialized
INFO - 2022-03-12 22:49:40 --> Helper loaded: url_helper
INFO - 2022-03-12 22:49:40 --> Helper loaded: form_helper
INFO - 2022-03-12 22:49:40 --> Helper loaded: common_helper
INFO - 2022-03-12 22:49:40 --> Database Driver Class Initialized
DEBUG - 2022-03-12 22:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 22:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 22:49:40 --> Controller Class Initialized
INFO - 2022-03-12 22:49:40 --> Form Validation Class Initialized
DEBUG - 2022-03-12 22:49:40 --> Encrypt Class Initialized
DEBUG - 2022-03-12 22:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 22:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 22:49:40 --> Email Class Initialized
INFO - 2022-03-12 22:49:40 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 22:49:40 --> Calendar Class Initialized
INFO - 2022-03-12 22:49:40 --> Model "Login_model" initialized
INFO - 2022-03-12 22:49:40 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 22:49:40 --> Final output sent to browser
DEBUG - 2022-03-12 22:49:40 --> Total execution time: 0.0239
ERROR - 2022-03-12 22:49:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 22:49:41 --> Config Class Initialized
INFO - 2022-03-12 22:49:41 --> Hooks Class Initialized
DEBUG - 2022-03-12 22:49:41 --> UTF-8 Support Enabled
INFO - 2022-03-12 22:49:41 --> Utf8 Class Initialized
INFO - 2022-03-12 22:49:41 --> URI Class Initialized
INFO - 2022-03-12 22:49:41 --> Router Class Initialized
INFO - 2022-03-12 22:49:41 --> Output Class Initialized
INFO - 2022-03-12 22:49:41 --> Security Class Initialized
DEBUG - 2022-03-12 22:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 22:49:41 --> Input Class Initialized
INFO - 2022-03-12 22:49:41 --> Language Class Initialized
INFO - 2022-03-12 22:49:41 --> Loader Class Initialized
INFO - 2022-03-12 22:49:41 --> Helper loaded: url_helper
INFO - 2022-03-12 22:49:41 --> Helper loaded: form_helper
INFO - 2022-03-12 22:49:41 --> Helper loaded: common_helper
INFO - 2022-03-12 22:49:41 --> Database Driver Class Initialized
DEBUG - 2022-03-12 22:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 22:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 22:49:41 --> Controller Class Initialized
INFO - 2022-03-12 22:49:41 --> Form Validation Class Initialized
DEBUG - 2022-03-12 22:49:41 --> Encrypt Class Initialized
DEBUG - 2022-03-12 22:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 22:49:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 22:49:41 --> Email Class Initialized
INFO - 2022-03-12 22:49:41 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 22:49:41 --> Calendar Class Initialized
INFO - 2022-03-12 22:49:41 --> Model "Login_model" initialized
ERROR - 2022-03-12 22:49:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2022-03-12 22:49:42 --> Config Class Initialized
INFO - 2022-03-12 22:49:42 --> Hooks Class Initialized
DEBUG - 2022-03-12 22:49:42 --> UTF-8 Support Enabled
INFO - 2022-03-12 22:49:42 --> Utf8 Class Initialized
INFO - 2022-03-12 22:49:42 --> URI Class Initialized
INFO - 2022-03-12 22:49:42 --> Router Class Initialized
INFO - 2022-03-12 22:49:42 --> Output Class Initialized
INFO - 2022-03-12 22:49:42 --> Security Class Initialized
DEBUG - 2022-03-12 22:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-12 22:49:42 --> Input Class Initialized
INFO - 2022-03-12 22:49:42 --> Language Class Initialized
INFO - 2022-03-12 22:49:42 --> Loader Class Initialized
INFO - 2022-03-12 22:49:42 --> Helper loaded: url_helper
INFO - 2022-03-12 22:49:42 --> Helper loaded: form_helper
INFO - 2022-03-12 22:49:42 --> Helper loaded: common_helper
INFO - 2022-03-12 22:49:42 --> Database Driver Class Initialized
DEBUG - 2022-03-12 22:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-12 22:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-12 22:49:42 --> Controller Class Initialized
INFO - 2022-03-12 22:49:42 --> Form Validation Class Initialized
DEBUG - 2022-03-12 22:49:42 --> Encrypt Class Initialized
DEBUG - 2022-03-12 22:49:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 22:49:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2022-03-12 22:49:42 --> Email Class Initialized
INFO - 2022-03-12 22:49:42 --> Language file loaded: language/english/calendar_lang.php
INFO - 2022-03-12 22:49:42 --> Calendar Class Initialized
INFO - 2022-03-12 22:49:42 --> Model "Login_model" initialized
INFO - 2022-03-12 22:49:42 --> File loaded: /home3/karoteam/public_html/application/views/login/index.php
INFO - 2022-03-12 22:49:42 --> Final output sent to browser
DEBUG - 2022-03-12 22:49:42 --> Total execution time: 0.0241
